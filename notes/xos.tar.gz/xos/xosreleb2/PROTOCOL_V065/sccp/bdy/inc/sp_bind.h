#ifndef __SP_BINDH__

#define __SP_BINDH__


void spBndItReq(void);

#endif