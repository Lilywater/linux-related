/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

    Name:   SCCP Message Database.

    Type:   C include file

    Desc:   Defines required by the message functions

    File:   cp_db.h

    Sid:      cp_db.h@@/main/7_1 - Tue Jan 22 15:16:35 2002

    Prg:    fmg

*********************************************************************21*/

#ifndef __CPDBH__
#define __CPDBH__


/*
*     The structures and variables declared in this file
*     correspond to structures and variables used by
*     the following TRILLIUM software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000030      SS7 - SCCP
*
*/
  

/*
 *
 * All comments enclosed in brackets "()" are references to page numbers in: 
 *
 * CCITT Blue Book
 * ---------------
 * Specifications of Signalling System No. 7
 * Recommendations Q.700-Q.716
 * ISBN 92-61-03511-6
 *
 */


/* defines */

#define SP_MAX_SWITCH     3      /* maximum switches */
#define SP_TST            0      /* Test Switch */

/* Message Ids (pg. 412 ) */

#define M_CONREQ          0x01   /* Connection Request */
#define M_CONCFM          0x02   /* Connection Confirmed */
#define M_CONREF          0x03   /* Connection Refused */
#define M_RELSD           0x04   /* Released */
#define M_RELCMP          0x05   /* Release Complete */
#define M_DATA1           0x06   /* Data Form 1 */
#define M_DATA2           0x07   /* Data Form 2 */
#define M_DATAACK         0x08   /* Data Acknowledgement */
#define M_UNITDATA        0x09   /* Unitdata */
#define M_UNITDATASRV     0x0a   /* Unitdata Service */
#define M_EXPDATA         0x0b   /* Expedited Data */
#define M_EXPDATAACK      0x0c   /* Expedited Data Acknowledgement */
#define M_RSTREQ          0x0d   /* Reset Request */
#define M_RSTCFM          0x0e   /* Reset Confirm */
#define M_PDUERR          0x0f   /* Protocol Data Unit Error */
#define M_INACTST         0x10   /* Inactivity Test */

/* New specs in ANSI 92 (pg T1.112.3-24) */
#define M_XUNITDATA       0x11   /* Extended Unit Data */
#define M_XUNITDATASRV    0x12   /* Extended Unit Data Service */

#define M_LUNITDATA       0x13   /* Long unit data */
#define M_LUNITDATASRV    0x14   /* Long unit data service */

#define NMB_MID           0x14

/* Message Indecies  (Lower) */

#define MI_CONREQ         0x00   /* Connection Request */
#define MI_CONCFM         0x01   /* Connection Confirmed */
#define MI_CONREF         0x02   /* Connection Refused */
#define MI_RELSD          0x03   /* Released */
#define MI_RELCMP         0x04   /* Release Complete */
#define MI_DATA1          0x05   /* Data Form 1 */
#define MI_DATA2          0x06   /* Data Form 2 */
#define MI_DATAACK        0x07   /* Data Acknowledgement */
#define MI_UNITDATA       0x08   /* Unitdata */
#define MI_UNITDATASRV    0x09   /* Unitdata Service */
#define MI_EXPDATA        0x0a   /* Expedited Data */
#define MI_EXPDATAACK     0x0b   /* Expedited Data Acknowledgement */
#define MI_RSTREQ         0x0c   /* Reset Request */
#define MI_RSTCFM         0x0d   /* Reset Confirm */
#define MI_PDUERR         0x0e   /* Protocol Data Unit Error */
#define MI_INACTST        0x0f   /* Inactivity Test */

#define MI_XUNITDATA      0x11   /* Extended unit data */
#define MI_XUNITDATASRV   0x12   /* Extended unit data service */

#define MI_LUNITDATA      0x13   /* Long unit data */
#define MI_LUNITDATASRV   0x14   /* Long unit data service */

#define NMB_MIDX          0x14

/* Event Indecies  (Upper) */

#define EI_CONREQ        0x10   /* Connection Request */
#define EI_CONCFM        0x11   /* Connection Confirmed */
#define EI_CONREF        0x12   /* Connection Refused */
#define EI_REL           0x13   /* Released */
#define EI_RELCMP        0x14   /* Release Complete */
#define EI_DATA1         0x15   /* Data Form 1 */
#define EI_DATA2         0x16   /* Data Form 2 */
#define EI_DTACK         0x17   /* Data Acknowledgement */
#define EI_UNITDATA      0x18   /* Unitdata */
#define EI_UNITDATASRV   0x19   /* Unitdata Service */
#define EI_EXPDT         0x1a   /* Expedited Data */
#define EI_EXPDTACK      0x1b   /* Expedited Data Acknowledgement */
#define EI_RSTREQ        0x1c   /* Reset Request */
#define EI_RSTCFM        0x1d   /* Reset Confirm */
#define EI_PRODTUERR     0x1e   /* Protocol Data Unit Error */
#define EI_INACTST       0x1f   /* Inactivity Test */

#define EI_XUNITDATA     0x20   /* Extended unit data */
#define EI_XUNITDATASRV  0x21   /* Extended unit data service */

#define EI_LUNITDATA     0x22   /* Long unit data */
#define EI_LUNITDATASRV  0x23   /* Long unit data service */

#define NMB_EIDX         0x14

#define NMB_EVNT     (NMB_MIDX + NMB_EIDX )  /* Number of Events */

/* Special Information Element Ids (not listed) */

#define ME_HEDR           0xff   /* Mask for Message Header Element */

/* Information Element ID tags (pg 413) */

#define ME_ENDOP          0x00   /* End of Optional Parameters */
#define ME_DSTLCLREF      0x01   /* Destination Local Reference */
#define ME_SRCLCLREF      0x02   /* Source Local Reference */
#define ME_CDPTYADDR      0x03   /* Called Party Address */
#define ME_CGPTYADDR      0x04   /* Calling Party Address */
#define ME_PROTCLASS      0x05   /* Protocol Class */
#define ME_SEGREAS        0x06   /* Segmenting/reassembling */
#define ME_RECSEQNUM      0x07   /* Receive Sequence Number */
#define ME_SEQSEG         0x08   /* Sequencing/segmenting */
#define ME_CREDIT         0x09   /* Credit */
#define ME_RELLCM_CAUSE       0x0a   /* Release Cause */
#define ME_RETLCM_CAUSE       0x0b   /* Return Cause */
#define ME_RESLCM_CAUSE       0x0c   /* Reset Cause */
#define ME_ERRLCM_CAUSE       0x0d   /* Error Cause */
#define ME_REFLCM_CAUSE       0x0e   /* Refusal Cause */
#define ME_DATA           0x0f   /* Data */

/* New specs in ANSI 92 (pg T1.112.3-24) */
#define ME_SEGMENTATION   0x10   /* Segmentation */
#define ME_HOPCNTR        0x11   /* Hop Counter */
#define ISNI              0xfa   /* To be specified in future documents */

/* New defines for ITU-T 96 (Table 2/Q.713) and BELL 05 */
#define ME_IMPORTANCE     0x12   /* Importance */
#define ME_LONG_DATA      0x13   /* Long Data */

/* define for ANSI 96 and BELL 05 */
#if (SS7_ANS96 || SS7_BELL05)
#define ME_ISNI           0x14   /* ISNI */
#endif /* SS7_ANS96 || SS7_BELL05 */

/* define for BELL 05 */
#ifdef SS7_BELL05
#define ME_INS            0x15   /* INS */
#define ME_MTI            0x16   /* MTI */
#endif /* SS7_BELL05 */

/* Special Information Element Indicies (not listed) */

#define MEI_HEDR           0x00   /* Mask for Message Header Element */

/* Internal Information Element ID tags (pg 413) */

#define MEI_ENDOP          0x01   /* End of Optional Parameters */
#define MEI_DSTLCLREF      0x02   /* Destination Local Reference */
#define MEI_SRCLCLREF      0x03   /* Source Local Reference */
#define MEI_CDPTYADDR      0x04   /* Called Party Address */
#define MEI_CGPTYADDR      0x05   /* Calling Party Address */
#define MEI_PROTCLASS      0x06   /* Protocol Class */
#define MEI_SEGREAS        0x07   /* Segmenting/reassembling */
#define MEI_RECSEQNUM      0x08   /* Receive Sequence Number */
#define MEI_SEQSEG         0x09   /* Sequencing/segmenting */
#define MEI_CREDIT         0x0a   /* Credit */
#define MEI_RELLCM_CAUSE       0x0b   /* Release Cause */
#define MEI_RETLCM_CAUSE       0x0c   /* Return Cause */
#define MEI_RESLCM_CAUSE       0x0d   /* Reset Cause */
#define MEI_ERRLCM_CAUSE       0x0e   /* Error Cause */
#define MEI_REFLCM_CAUSE       0x0f   /* Refusal Cause */
#define MEI_DATA           0x10   /* Data */

/* New specs in ANSI 92 (pg T1.112.3-24) */
#define MEI_SEGMENTATION   0x11   /* Segmentation */
#define MEI_HOPCNTR        0x12   /* Hop Counter */

/* New defines for ITU-T 96 (Table 2/Q.713) and BELL 05 */
#define MEI_IMPORTANCE     0x13   /* Importance */
#define MEI_LONG_DATA      0x14   /* Long Data */

/* define for ANS 96 and BELL 05 */
#if (SS7_ANS96 || SS7_BELL05)
#define MEI_ISNI           0x15   /* ISNI */
#endif /* SS7_ANS96 || SS7_BELL05 */

/* defines for BELL 05 */
#ifdef SS7_BELL05
#define MEI_INS            0x16   /* INS */
#define MEI_MTI            0x17   /* MTI */
#endif /* SS7_BELL05 */

#define MAXNUMSEG    16        /* max number of segments allowed in */
                               /* extended unit data                */
#define SP_MAX_DLEN  255       /* max data for DT1 and DT2 */
#define SP_MAX_DLEN1 130       /* max data for CR, CC, CREF, RLSD */
#define SP_MAX_DLEN2  33       /* max data for EXPDT */ 

#define SP_MAX_LDLEN 3952      /* max data for LUDT */

#endif


/********************************************************************30**
  
         End of file:     cp_db.h@@/main/7_1 - Tue Jan 22 15:16:35 2002
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. text changes

1.3          ---  scc   1. add extended unit data and extended unit data
                           service message type for ANSI 92
1.4          ---  scc   1. correct max length of EXPDT to 33 octets instead 
                           of 30.

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.5          ---      vb   1. Added defines for ITU96

/main/7      ---      cp   1. Cosmetic changes. 
/main/7_1    ---      rc   1. Flag SS7_ITU96 removed and defines under this
                              flag made available unconditionally.
                           2. indices for ISNI, INS and MTI are defined.
           sp001.302  rc   1. Sid correction
*********************************************************************91*/

