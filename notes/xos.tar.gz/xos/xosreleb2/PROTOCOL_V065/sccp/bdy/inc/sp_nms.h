/**********************************************************************

    Name:   sp_nms.h 

    Type:   C include file

    Desc:   

    File:   sp_nms.h

    Sid:    

    Created by: 

**********************************************************************/


#ifndef _SP_NMS_H_
#define _SP_NMS_H_

#ifdef __cplusplus
extern "C" {
#endif

/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
extern S16 spRecvInitCfg(tb_record* prow);
extern VOID spInitCfgData();
extern VOID spResetCfgData( );
extern S16 spRecvDynCfg(U32 msgtype, tb_record* prow);
extern S16 spDynCfgMsg(tb_record *prow);
extern S16 spInitCfgMsg();
extern unsigned char spInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow);
extern unsigned char spDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);
extern VOID spStatusCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);
extern VOID spCntrlCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);
extern VOID spStatisticCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);


#ifdef CP_OAM_DATA_SHOW
extern VOID    spPrintGenCfgTst();
extern VOID    spPrintNwCfgTst();
extern VOID    spPrintGtRuleCfgTst();
extern VOID    spPrintGtAddrCfgTst();
extern VOID    spPrintRteCbTst();
extern VOID    spPrintOneNwCfgTst(NwId nwId);
extern VOID    spPrintOneGtRuleCfgTst(U8 gtAssoId);

#endif

#ifdef __cplusplus
}
#endif



#endif

