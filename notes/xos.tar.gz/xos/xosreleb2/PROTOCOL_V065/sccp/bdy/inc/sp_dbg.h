
/**********************************************************************
 
     Name:     sp_cfg.h - Debug print for SCCP
  
     Type:     C include file
  
     Desc:     sccp debug function
  
     File:      sp_dbg.h
  
     Sid:      sp_dbg.h
  
     Prg:      wanglijun  
**********************************************************************/

/************************************************************************/
#ifndef _SP_DFG_H_
#define _SP_DFG_H_

#ifdef SSI_WITH_CLI_ENABLED


/* ERROR STRING */
#define SP_DBG_ERR_STR_LOCK                             "����ִ����һ��������!"
#define SP_DBG_ERR_STR_VARNULLP                     "��ָ��Ϊ��ָ��!!!����λ��%s �ļ���%d ��\r\n"
#define SP_DBG_ERR_STR_VARIAVLIDNUM             "���������������"
#define SP_DBG_ERR_VAR_IAVLIDRANAGE          "���������Χ����"


EXTERN void spSetDbgMask(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spGetDbgMask(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintSpCb(CLI_ENV *pCliEnv, XS32 Argc, XCHAR **ppArgv);
EXTERN void spPrintGenCfg(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintNwCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintOneNwCb(CLI_ENV *pCliEnv, NwId nwId);
EXTERN void spPrintSapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintOneSapCb(CLI_ENV *pCliEnv, SpId spId);
EXTERN void spPrintNSapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintOneNSapCb(CLI_ENV *pCliEnv, SuId suId);
EXTERN void spPrintGtAssoCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintOneGtAssoCb(CLI_ENV *pCliEnv, XCHAR gtAssoId);
EXTERN void spPrintRteCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintOneRteCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintGtAddrMapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spPrintGLBSts(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spAddGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spDelGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spModGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);

EXTERN void spAddGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spDelGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spModGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);

EXTERN void spAddRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spDelRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spModRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);

EXTERN void spAddRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spDelRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN void spModRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);

#ifndef ZP
#ifdef SPCO
EXTERN void spPrintLclRef(CLI_ENV *pCliEnv, SpLclRef *ref);
#endif
#endif

EXTERN void spPrintSpConKey(CLI_ENV *pCliEnv, SpConKey *key);
EXTERN void cmPrintXPostInfo(CLI_ENV *pCliEnv, Pst *pst);
EXTERN void cmPrintXTmrCfg(CLI_ENV *pCliEnv, TmrCfg *cfg);
EXTERN void cmPrintXTskInit(CLI_ENV *pCliEnv, TskInit *init);
EXTERN void cmPrintXBndCfg(CLI_ENV *pCliEnv, BndCfg *cfg);
EXTERN Void spGetSwTypeStr(S16 swType, U8 *swStr);
EXTERN Void spGetSccpStsStr(U8 sccpSts, U8 *swStr);
EXTERN Void spGetVariantStr(S16 swType, U8 *swStr);
EXTERN Void spGetPcLenStr(U8 pcLen, U8 *swStr);
EXTERN Void spPrintSapNSapStatus(CLI_ENV *pCliEnv, U16 status);
EXTERN Void spPrintSpStatus(CLI_ENV *pCliEnv, U8 status);
EXTERN Void spPrintRteStatus(CLI_ENV *pCliEnv, U8 status);

#ifdef DEBUGP
EXTERN Void cmPrintXDbgmsk(CLI_ENV *pCliEnv, U32 mask);
#endif

#endif/*SSI_WITH_CLI_ENABLED*/


EXTERN Void spSetDbgMaskFromShell(U32 dbgMask);


#endif/*_SP_DFG_H_*/
