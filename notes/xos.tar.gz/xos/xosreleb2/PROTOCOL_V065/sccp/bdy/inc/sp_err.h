/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     SCCP - error
  
     Type:     C include file
  
     Desc:     Error defines required by SCCP.
  
     File:     sp_err.h
  
     Sid:      sp_err.h@@/main/13_1 - Tue Jan 22 15:12:59 2002
  
     Prg:      fmg
  
*********************************************************************21*/
  
#ifndef __SPERRH__
#define __SPERRH__


/* defines */
  
#define  ESPBASE 0
#define  ESPXXX      (ESPBASE)      /* reserved */

#define   ESP001      (ERRSP +    1)    /*    cp_bdy1.c: 356 */
#define   ESP002      (ERRSP +    2)    /*    cp_bdy1.c: 431 */
#define   ESP003      (ERRSP +    3)    /*    cp_bdy1.c: 557 */
#define   ESP004      (ERRSP +    4)    /*    cp_bdy1.c: 565 */
#define   ESP005      (ERRSP +    5)    /*    cp_bdy1.c: 578 */
#define   ESP006      (ERRSP +    6)    /*    cp_bdy1.c: 589 */
#define   ESP007      (ERRSP +    7)    /*    cp_bdy1.c: 603 */
#define   ESP008      (ERRSP +    8)    /*    cp_bdy1.c: 957 */
#define   ESP009      (ERRSP +    9)    /*    cp_bdy1.c: 975 */
#define   ESP010      (ERRSP +   10)    /*    cp_bdy1.c:1107 */
#define   ESP011      (ERRSP +   11)    /*    cp_bdy1.c:1184 */
#define   ESP012      (ERRSP +   12)    /*    cp_bdy1.c:1195 */
#define   ESP013      (ERRSP +   13)    /*    cp_bdy1.c:1224 */
#define   ESP014      (ERRSP +   14)    /*    cp_bdy1.c:1249 */
#define   ESP015      (ERRSP +   15)    /*    cp_bdy1.c:1279 */
#define   ESP016      (ERRSP +   16)    /*    cp_bdy1.c:1380 */
#define   ESP017      (ERRSP +   17)    /*    cp_bdy1.c:1392 */
#define   ESP018      (ERRSP +   18)    /*    cp_bdy1.c:1404 */
#define   ESP019      (ERRSP +   19)    /*    cp_bdy1.c:1457 */
#define   ESP020      (ERRSP +   20)    /*    cp_bdy1.c:1551 */
#define   ESP021      (ERRSP +   21)    /*    cp_bdy1.c:1562 */
#define   ESP022      (ERRSP +   22)    /*    cp_bdy1.c:1573 */
#define   ESP023      (ERRSP +   23)    /*    cp_bdy1.c:1738 */
#define   ESP024      (ERRSP +   24)    /*    cp_bdy1.c:1756 */
#define   ESP025      (ERRSP +   25)    /*    cp_bdy1.c:1798 */
#define   ESP026      (ERRSP +   26)    /*    cp_bdy1.c:1807 */
#define   ESP027      (ERRSP +   27)    /*    cp_bdy1.c:1921 */
#define   ESP028      (ERRSP +   28)    /*    cp_bdy1.c:1936 */
#define   ESP029      (ERRSP +   29)    /*    cp_bdy1.c:1980 */
#define   ESP030      (ERRSP +   30)    /*    cp_bdy1.c:2194 */
#define   ESP031      (ERRSP +   31)    /*    cp_bdy1.c:2332 */
#define   ESP032      (ERRSP +   32)    /*    cp_bdy1.c:2477 */
#define   ESP033      (ERRSP +   33)    /*    cp_bdy1.c:2578 */
#define   ESP034      (ERRSP +   34)    /*    cp_bdy1.c:2729 */
#define   ESP035      (ERRSP +   35)    /*    cp_bdy1.c:2791 */
#define   ESP036      (ERRSP +   36)    /*    cp_bdy1.c:2803 */
#define   ESP037      (ERRSP +   37)    /*    cp_bdy1.c:2846 */
#define   ESP038      (ERRSP +   38)    /*    cp_bdy1.c:2900 */
#define   ESP039      (ERRSP +   39)    /*    cp_bdy1.c:2912 */
#define   ESP040      (ERRSP +   40)    /*    cp_bdy1.c:2922 */
#define   ESP041      (ERRSP +   41)    /*    cp_bdy1.c:2993 */
#define   ESP042      (ERRSP +   42)    /*    cp_bdy1.c:3005 */
#define   ESP043      (ERRSP +   43)    /*    cp_bdy1.c:3093 */
#define   ESP044      (ERRSP +   44)    /*    cp_bdy1.c:3104 */
#define   ESP045      (ERRSP +   45)    /*    cp_bdy1.c:3117 */
#define   ESP046      (ERRSP +   46)    /*    cp_bdy1.c:3207 */
#define   ESP047      (ERRSP +   47)    /*    cp_bdy1.c:3218 */
#define   ESP048      (ERRSP +   48)    /*    cp_bdy1.c:3231 */
#define   ESP049      (ERRSP +   49)    /*    cp_bdy1.c:3316 */
#define   ESP050      (ERRSP +   50)    /*    cp_bdy1.c:3327 */
#define   ESP051      (ERRSP +   51)    /*    cp_bdy1.c:3339 */
#define   ESP052      (ERRSP +   52)    /*    cp_bdy1.c:3454 */
#define   ESP053      (ERRSP +   53)    /*    cp_bdy1.c:3527 */
#define   ESP054      (ERRSP +   54)    /*    cp_bdy1.c:3539 */
#define   ESP055      (ERRSP +   55)    /*    cp_bdy1.c:3551 */
#define   ESP056      (ERRSP +   56)    /*    cp_bdy1.c:3613 */
#define   ESP057      (ERRSP +   57)    /*    cp_bdy1.c:3736 */
#define   ESP058      (ERRSP +   58)    /*    cp_bdy1.c:3843 */
#define   ESP059      (ERRSP +   59)    /*    cp_bdy1.c:4609 */
#define   ESP060      (ERRSP +   60)    /*    cp_bdy1.c:4964 */
#define   ESP061      (ERRSP +   61)    /*    cp_bdy1.c:4979 */
#define   ESP062      (ERRSP +   62)    /*    cp_bdy1.c:5071 */
#define   ESP063      (ERRSP +   63)    /*    cp_bdy1.c:5086 */

#define   ESP064      (ERRSP +   64)    /*    cp_bdy2.c:1903 */
#define   ESP065      (ERRSP +   65)    /*    cp_bdy2.c:1991 */
#define   ESP066      (ERRSP +   66)    /*    cp_bdy2.c:2002 */
#define   ESP067      (ERRSP +   67)    /*    cp_bdy2.c:2015 */
#define   ESP068      (ERRSP +   68)    /*    cp_bdy2.c:2138 */
#define   ESP069      (ERRSP +   69)    /*    cp_bdy2.c:2149 */
#define   ESP070      (ERRSP +   70)    /*    cp_bdy2.c:2162 */
#define   ESP071      (ERRSP +   71)    /*    cp_bdy2.c:2199 */
#define   ESP072      (ERRSP +   72)    /*    cp_bdy2.c:2210 */
#define   ESP073      (ERRSP +   73)    /*    cp_bdy2.c:2223 */
#define   ESP074      (ERRSP +   74)    /*    cp_bdy2.c:2345 */
#define   ESP075      (ERRSP +   75)    /*    cp_bdy2.c:2356 */
#define   ESP076      (ERRSP +   76)    /*    cp_bdy2.c:2369 */
#define   ESP077      (ERRSP +   77)    /*    cp_bdy2.c:2383 */
#define   ESP078      (ERRSP +   78)    /*    cp_bdy2.c:2685 */
#define   ESP079      (ERRSP +   79)    /*    cp_bdy2.c:3117 */
#define   ESP080      (ERRSP +   80)    /*    cp_bdy2.c:3502 */
#define   ESP081      (ERRSP +   81)    /*    cp_bdy2.c:3735 */
#define   ESP082      (ERRSP +   82)    /*    cp_bdy2.c:3757 */
#define   ESP083      (ERRSP +   83)    /*    cp_bdy2.c:4085 */
#define   ESP084      (ERRSP +   84)    /*    cp_bdy2.c:4232 */
#define   ESP085      (ERRSP +   85)    /*    cp_bdy2.c:4284 */
#define   ESP086      (ERRSP +   86)    /*    cp_bdy2.c:4430 */
#define   ESP087      (ERRSP +   87)    /*    cp_bdy2.c:4477 */
#define   ESP088      (ERRSP +   88)    /*    cp_bdy2.c:4495 */
#define   ESP089      (ERRSP +   89)    /*    cp_bdy2.c:4501 */
#define   ESP090      (ERRSP +   90)    /*    cp_bdy2.c:4969 */
#define   ESP091      (ERRSP +   91)    /*    cp_bdy2.c:5088 */
#define   ESP092      (ERRSP +   92)    /*    cp_bdy2.c:5098 */
#define   ESP093      (ERRSP +   93)    /*    cp_bdy2.c:5111 */
#define   ESP094      (ERRSP +   94)    /*    cp_bdy2.c:5119 */
#define   ESP095      (ERRSP +   95)    /*    cp_bdy2.c:5165 */
#define   ESP096      (ERRSP +   96)    /*    cp_bdy2.c:5179 */
#define   ESP097      (ERRSP +   97)    /*    cp_bdy2.c:5188 */
#define   ESP098      (ERRSP +   98)    /*    cp_bdy2.c:5235 */
#define   ESP099      (ERRSP +   99)    /*    cp_bdy2.c:5248 */
#define   ESP100      (ERRSP +  100)    /*    cp_bdy2.c:5256 */
#define   ESP101      (ERRSP +  101)    /*    cp_bdy2.c:5264 */
#define   ESP102      (ERRSP +  102)    /*    cp_bdy2.c:5283 */
#define   ESP103      (ERRSP +  103)    /*    cp_bdy2.c:5299 */
#define   ESP104      (ERRSP +  104)    /*    cp_bdy2.c:5310 */
#define   ESP105      (ERRSP +  105)    /*    cp_bdy2.c:5321 */
#define   ESP106      (ERRSP +  106)    /*    cp_bdy2.c:5329 */
#define   ESP107      (ERRSP +  107)    /*    cp_bdy2.c:5341 */
#define   ESP108      (ERRSP +  108)    /*    cp_bdy2.c:5350 */
#define   ESP109      (ERRSP +  109)    /*    cp_bdy2.c:5369 */
#define   ESP110      (ERRSP +  110)    /*    cp_bdy2.c:5386 */
#define   ESP111      (ERRSP +  111)    /*    cp_bdy2.c:5400 */
#define   ESP112      (ERRSP +  112)    /*    cp_bdy2.c:5430 */
#define   ESP113      (ERRSP +  113)    /*    cp_bdy2.c:5447 */
#define   ESP114      (ERRSP +  114)    /*    cp_bdy2.c:5455 */
#define   ESP115      (ERRSP +  115)    /*    cp_bdy2.c:5479 */
#define   ESP116      (ERRSP +  116)    /*    cp_bdy2.c:5494 */
#define   ESP117      (ERRSP +  117)    /*    cp_bdy2.c:5508 */
#define   ESP118      (ERRSP +  118)    /*    cp_bdy2.c:5516 */
#define   ESP119      (ERRSP +  119)    /*    cp_bdy2.c:5600 */
#define   ESP120      (ERRSP +  120)    /*    cp_bdy2.c:5622 */
#define   ESP121      (ERRSP +  121)    /*    cp_bdy2.c:5647 */
#define   ESP122      (ERRSP +  122)    /*    cp_bdy2.c:5658 */
#define   ESP123      (ERRSP +  123)    /*    cp_bdy2.c:5709 */
#define   ESP124      (ERRSP +  124)    /*    cp_bdy2.c:5734 */
#define   ESP125      (ERRSP +  125)    /*    cp_bdy2.c:5759 */
#define   ESP126      (ERRSP +  126)    /*    cp_bdy2.c:5778 */
#define   ESP127      (ERRSP +  127)    /*    cp_bdy2.c:5825 */
#define   ESP128      (ERRSP +  128)    /*    cp_bdy2.c:5891 */
#define   ESP129      (ERRSP +  129)    /*    cp_bdy2.c:6015 */
#define   ESP130      (ERRSP +  130)    /*    cp_bdy2.c:6074 */
#define   ESP131      (ERRSP +  131)    /*    cp_bdy2.c:6125 */
#define   ESP132      (ERRSP +  132)    /*    cp_bdy2.c:6174 */
#define   ESP133      (ERRSP +  133)    /*    cp_bdy2.c:6261 */
#define   ESP134      (ERRSP +  134)    /*    cp_bdy2.c:6558 */
#define   ESP135      (ERRSP +  135)    /*    cp_bdy2.c:6658 */
#define   ESP136      (ERRSP +  136)    /*    cp_bdy2.c:7131 */
#define   ESP137      (ERRSP +  137)    /*    cp_bdy2.c:7144 */
#define   ESP138      (ERRSP +  138)    /*    cp_bdy2.c:7235 */
#define   ESP139      (ERRSP +  139)    /*    cp_bdy2.c:7252 */
#define   ESP140      (ERRSP +  140)    /*    cp_bdy2.c:7332 */
#define   ESP141      (ERRSP +  141)    /*    cp_bdy2.c:7350 */
#define   ESP142      (ERRSP +  142)    /*    cp_bdy2.c:7371 */
#define   ESP143      (ERRSP +  143)    /*    cp_bdy2.c:7432 */
#define   ESP144      (ERRSP +  144)    /*    cp_bdy2.c:7511 */
#define   ESP145      (ERRSP +  145)    /*    cp_bdy2.c:7539 */
#define   ESP146      (ERRSP +  146)    /*    cp_bdy2.c:7633 */
#define   ESP147      (ERRSP +  147)    /*    cp_bdy2.c:7666 */
#define   ESP148      (ERRSP +  148)    /*    cp_bdy2.c:7765 */
#define   ESP149      (ERRSP +  149)    /*    cp_bdy2.c:7794 */
#define   ESP150      (ERRSP +  150)    /*    cp_bdy2.c:7907 */
#define   ESP151      (ERRSP +  151)    /*    cp_bdy2.c:7931 */
#define   ESP152      (ERRSP +  152)    /*    cp_bdy2.c:7947 */
#define   ESP153      (ERRSP +  153)    /*    cp_bdy2.c:8101 */
#define   ESP154      (ERRSP +  154)    /*    cp_bdy2.c:8204 */
#define   ESP155      (ERRSP +  155)    /*    cp_bdy2.c:8219 */
#define   ESP156      (ERRSP +  156)    /*    cp_bdy2.c:8232 */
#define   ESP157      (ERRSP +  157)    /*    cp_bdy2.c:8262 */
#define   ESP158      (ERRSP +  158)    /*    cp_bdy2.c:8279 */
#define   ESP159      (ERRSP +  159)    /*    cp_bdy2.c:8289 */
#define   ESP160      (ERRSP +  160)    /*    cp_bdy2.c:8375 */
#define   ESP161      (ERRSP +  161)    /*    cp_bdy2.c:8430 */
#define   ESP162      (ERRSP +  162)    /*    cp_bdy2.c:8437 */
#define   ESP163      (ERRSP +  163)    /*    cp_bdy2.c:8514 */
#define   ESP164      (ERRSP +  164)    /*    cp_bdy2.c:8683 */
#define   ESP165      (ERRSP +  165)    /*    cp_bdy2.c:8786 */
#define   ESP166      (ERRSP +  166)    /*    cp_bdy2.c:8830 */
#define   ESP167      (ERRSP +  167)    /*    cp_bdy2.c:8839 */
#define   ESP168      (ERRSP +  168)    /*    cp_bdy2.c:9004 */
#define   ESP169      (ERRSP +  169)    /*    cp_bdy2.c:9608 */
#define   ESP170      (ERRSP +  170)    /*    cp_bdy2.c:9663 */
#define   ESP171      (ERRSP +  171)    /*    cp_bdy2.c:9822 */
#define   ESP172      (ERRSP +  172)    /*    cp_bdy2.c:10470 */
#define   ESP173      (ERRSP +  173)    /*    cp_bdy2.c:10645 */
#define   ESP174      (ERRSP +  174)    /*    cp_bdy2.c:10704 */
#define   ESP175      (ERRSP +  175)    /*    cp_bdy2.c:10716 */
#define   ESP176      (ERRSP +  176)    /*    cp_bdy2.c:11230 */
#define   ESP177      (ERRSP +  177)    /*    cp_bdy2.c:11304 */
#define   ESP178      (ERRSP +  178)    /*    cp_bdy2.c:11438 */
#define   ESP179      (ERRSP +  179)    /*    cp_bdy2.c:11442 */
#define   ESP180      (ERRSP +  180)    /*    cp_bdy2.c:11578 */
#define   ESP181      (ERRSP +  181)    /*    cp_bdy2.c:11657 */
#define   ESP182      (ERRSP +  182)    /*    cp_bdy2.c:11668 */
#define   ESP183      (ERRSP +  183)    /*    cp_bdy2.c:11758 */
#define   ESP184      (ERRSP +  184)    /*    cp_bdy2.c:11836 */
#define   ESP185      (ERRSP +  185)    /*    cp_bdy2.c:11855 */
#define   ESP186      (ERRSP +  186)    /*    cp_bdy2.c:11915 */
#define   ESP187      (ERRSP +  187)    /*    cp_bdy2.c:11927 */
#define   ESP188      (ERRSP +  188)    /*    cp_bdy2.c:12055 */
#define   ESP189      (ERRSP +  189)    /*    cp_bdy2.c:12067 */
#define   ESP190      (ERRSP +  190)    /*    cp_bdy2.c:12085 */
#define   ESP191      (ERRSP +  191)    /*    cp_bdy2.c:12123 */
#define   ESP192      (ERRSP +  192)    /*    cp_bdy2.c:12135 */
#define   ESP193      (ERRSP +  193)    /*    cp_bdy2.c:12251 */
#define   ESP194      (ERRSP +  194)    /*    cp_bdy2.c:12280 */
#define   ESP195      (ERRSP +  195)    /*    cp_bdy2.c:12329 */
#define   ESP196      (ERRSP +  196)    /*    cp_bdy2.c:12354 */
#define   ESP197      (ERRSP +  197)    /*    cp_bdy2.c:12408 */
#define   ESP198      (ERRSP +  198)    /*    cp_bdy2.c:12424 */
#define   ESP199      (ERRSP +  199)    /*    cp_bdy2.c:12432 */
#define   ESP200      (ERRSP +  200)    /*    cp_bdy2.c:12439 */
#define   ESP201      (ERRSP +  201)    /*    cp_bdy2.c:12446 */
#define   ESP202      (ERRSP +  202)    /*    cp_bdy2.c:12457 */
#define   ESP203      (ERRSP +  203)    /*    cp_bdy2.c:12542 */
#define   ESP204      (ERRSP +  204)    /*    cp_bdy2.c:12553 */
#define   ESP205      (ERRSP +  205)    /*    cp_bdy2.c:12567 */
#define   ESP206      (ERRSP +  206)    /*    cp_bdy2.c:12632 */
#define   ESP207      (ERRSP +  207)    /*    cp_bdy2.c:12643 */
#define   ESP208      (ERRSP +  208)    /*    cp_bdy2.c:12654 */
#define   ESP209      (ERRSP +  209)    /*    cp_bdy2.c:12661 */
#define   ESP210      (ERRSP +  210)    /*    cp_bdy2.c:12718 */
#define   ESP211      (ERRSP +  211)    /*    cp_bdy2.c:12770 */
#define   ESP212      (ERRSP +  212)    /*    cp_bdy2.c:12898 */
#define   ESP213      (ERRSP +  213)    /*    cp_bdy2.c:12939 */
#define   ESP214      (ERRSP +  214)    /*    cp_bdy2.c:12951 */
#define   ESP215      (ERRSP +  215)    /*    cp_bdy2.c:13110 */
#define   ESP216      (ERRSP +  216)    /*    cp_bdy2.c:13120 */
#define   ESP217      (ERRSP +  217)    /*    cp_bdy2.c:13172 */
#define   ESP218      (ERRSP +  218)    /*    cp_bdy2.c:13182 */
#define   ESP219      (ERRSP +  219)    /*    cp_bdy2.c:13232 */
#define   ESP220      (ERRSP +  220)    /*    cp_bdy2.c:13280 */
#define   ESP221      (ERRSP +  221)    /*    cp_bdy2.c:13627 */
#define   ESP222      (ERRSP +  222)    /*    cp_bdy2.c:14694 */

#define   ESP223      (ERRSP +  223)    /*    cp_bdy3.c: 924 */
#define   ESP224      (ERRSP +  224)    /*    cp_bdy3.c:1056 */
#define   ESP225      (ERRSP +  225)    /*    cp_bdy3.c:1069 */
#define   ESP226      (ERRSP +  226)    /*    cp_bdy3.c:1080 */
#define   ESP227      (ERRSP +  227)    /*    cp_bdy3.c:1098 */
#define   ESP228      (ERRSP +  228)    /*    cp_bdy3.c:1106 */
#define   ESP229      (ERRSP +  229)    /*    cp_bdy3.c:1115 */
#define   ESP230      (ERRSP +  230)    /*    cp_bdy3.c:1125 */
#define   ESP231      (ERRSP +  231)    /*    cp_bdy3.c:1258 */
#define   ESP232      (ERRSP +  232)    /*    cp_bdy3.c:1270 */
#define   ESP233      (ERRSP +  233)    /*    cp_bdy3.c:1343 */
#define   ESP234      (ERRSP +  234)    /*    cp_bdy3.c:2069 */

#define   ESP235      (ERRSP +  235)    /*    cp_bdy4.c: 253 */
#define   ESP236      (ERRSP +  236)    /*    cp_bdy4.c: 335 */
#define   ESP237      (ERRSP +  237)    /*    cp_bdy4.c: 412 */
#define   ESP238      (ERRSP +  238)    /*    cp_bdy4.c: 419 */
#define   ESP239      (ERRSP +  239)    /*    cp_bdy4.c: 425 */
#define   ESP240      (ERRSP +  240)    /*    cp_bdy4.c: 512 */
#define   ESP241      (ERRSP +  241)    /*    cp_bdy4.c: 706 */
#define   ESP242      (ERRSP +  242)    /*    cp_bdy4.c:1047 */
#define   ESP243      (ERRSP +  243)    /*    cp_bdy4.c:1150 */
#define   ESP244      (ERRSP +  244)    /*    cp_bdy4.c:1235 */
#define   ESP245      (ERRSP +  245)    /*    cp_bdy4.c:1247 */
#define   ESP246      (ERRSP +  246)    /*    cp_bdy4.c:1258 */
#define   ESP247      (ERRSP +  247)    /*    cp_bdy4.c:1330 */
#define   ESP248      (ERRSP +  248)    /*    cp_bdy4.c:1403 */
#define   ESP249      (ERRSP +  249)    /*    cp_bdy4.c:1415 */
#define   ESP250      (ERRSP +  250)    /*    cp_bdy4.c:1426 */
#define   ESP251      (ERRSP +  251)    /*    cp_bdy4.c:1555 */
#define   ESP252      (ERRSP +  252)    /*    cp_bdy4.c:1565 */
#define   ESP253      (ERRSP +  253)    /*    cp_bdy4.c:1574 */
#define   ESP254      (ERRSP +  254)    /*    cp_bdy4.c:1730 */
#define   ESP255      (ERRSP +  255)    /*    cp_bdy4.c:1850 */
#define   ESP256      (ERRSP +  256)    /*    cp_bdy4.c:1862 */
#define   ESP257      (ERRSP +  257)    /*    cp_bdy4.c:1873 */
#define   ESP258      (ERRSP +  258)    /*    cp_bdy4.c:1961 */
#define   ESP259      (ERRSP +  259)    /*    cp_bdy4.c:2050 */
#define   ESP260      (ERRSP +  260)    /*    cp_bdy4.c:2061 */
#define   ESP261      (ERRSP +  261)    /*    cp_bdy4.c:2080 */
#define   ESP262      (ERRSP +  262)    /*    cp_bdy4.c:2219 */
#define   ESP263      (ERRSP +  263)    /*    cp_bdy4.c:2228 */
#define   ESP264      (ERRSP +  264)    /*    cp_bdy4.c:2237 */
#define   ESP265      (ERRSP +  265)    /*    cp_bdy4.c:2377 */
#define   ESP266      (ERRSP +  266)    /*    cp_bdy4.c:2386 */
#define   ESP267      (ERRSP +  267)    /*    cp_bdy4.c:2394 */
#define   ESP268      (ERRSP +  268)    /*    cp_bdy4.c:2558 */
#define   ESP269      (ERRSP +  269)    /*    cp_bdy4.c:2565 */
#define   ESP270      (ERRSP +  270)    /*    cp_bdy4.c:2591 */
#define   ESP271      (ERRSP +  271)    /*    cp_bdy4.c:2600 */
#define   ESP272      (ERRSP +  272)    /*    cp_bdy4.c:2693 */
#define   ESP273      (ERRSP +  273)    /*    cp_bdy4.c:2916 */
#define   ESP274      (ERRSP +  274)    /*    cp_bdy4.c:2967 */
#define   ESP275      (ERRSP +  275)    /*    cp_bdy4.c:2975 */
#define   ESP276      (ERRSP +  276)    /*    cp_bdy4.c:3123 */
#define   ESP277      (ERRSP +  277)    /*    cp_bdy4.c:3136 */
#define   ESP278      (ERRSP +  278)    /*    cp_bdy4.c:3147 */
#define   ESP279      (ERRSP +  279)    /*    cp_bdy4.c:3325 */
#define   ESP280      (ERRSP +  280)    /*    cp_bdy4.c:3338 */
#define   ESP281      (ERRSP +  281)    /*    cp_bdy4.c:3349 */
#define   ESP282      (ERRSP +  282)    /*    cp_bdy4.c:3370 */
#define   ESP283      (ERRSP +  283)    /*    cp_bdy4.c:3473 */
#define   ESP284      (ERRSP +  284)    /*    cp_bdy4.c:3486 */
#define   ESP285      (ERRSP +  285)    /*    cp_bdy4.c:3499 */
#define   ESP286      (ERRSP +  286)    /*    cp_bdy4.c:3514 */
#define   ESP287      (ERRSP +  287)    /*    cp_bdy4.c:3577 */
#define   ESP288      (ERRSP +  288)    /*    cp_bdy4.c:3750 */
#define   ESP289      (ERRSP +  289)    /*    cp_bdy4.c:3760 */
#define   ESP290      (ERRSP +  290)    /*    cp_bdy4.c:3769 */
#define   ESP291      (ERRSP +  291)    /*    cp_bdy4.c:3840 */
#define   ESP292      (ERRSP +  292)    /*    cp_bdy4.c:3852 */
#define   ESP293      (ERRSP +  293)    /*    cp_bdy4.c:3862 */
#define   ESP294      (ERRSP +  294)    /*    cp_bdy4.c:3930 */
#define   ESP295      (ERRSP +  295)    /*    cp_bdy4.c:3939 */
#define   ESP296      (ERRSP +  296)    /*    cp_bdy4.c:3956 */
#define   ESP297      (ERRSP +  297)    /*    cp_bdy4.c:3966 */
#define   ESP298      (ERRSP +  298)    /*    cp_bdy4.c:3975 */
#define   ESP299      (ERRSP +  299)    /*    cp_bdy4.c:3981 */
#define   ESP300      (ERRSP +  300)    /*    cp_bdy4.c:3998 */
#define   ESP301      (ERRSP +  301)    /*    cp_bdy4.c:4038 */
#define   ESP302      (ERRSP +  302)    /*    cp_bdy4.c:4083 */
#define   ESP303      (ERRSP +  303)    /*    cp_bdy4.c:4142 */
#define   ESP304      (ERRSP +  304)    /*    cp_bdy4.c:4205 */
#define   ESP305      (ERRSP +  305)    /*    cp_bdy4.c:4460 */
#define   ESP306      (ERRSP +  306)    /*    cp_bdy4.c:4791 */
#define   ESP307      (ERRSP +  307)    /*    cp_bdy4.c:4846 */
#define   ESP308      (ERRSP +  308)    /*    cp_bdy4.c:4888 */
#define   ESP309      (ERRSP +  309)    /*    cp_bdy4.c:4898 */
#define   ESP310      (ERRSP +  310)    /*    cp_bdy4.c:4907 */
#define   ESP311      (ERRSP +  311)    /*    cp_bdy4.c:5044 */
#define   ESP312      (ERRSP +  312)    /*    cp_bdy4.c:5150 */
#define   ESP313      (ERRSP +  313)    /*    cp_bdy4.c:5160 */
#define   ESP314      (ERRSP +  314)    /*    cp_bdy4.c:5169 */
#define   ESP315      (ERRSP +  315)    /*    cp_bdy4.c:5241 */
#define   ESP316      (ERRSP +  316)    /*    cp_bdy4.c:5314 */
#define   ESP317      (ERRSP +  317)    /*    cp_bdy4.c:5323 */
#define   ESP318      (ERRSP +  318)    /*    cp_bdy4.c:5339 */
#define   ESP319      (ERRSP +  319)    /*    cp_bdy4.c:5508 */
#define   ESP320      (ERRSP +  320)    /*    cp_bdy4.c:5735 */
#define   ESP321      (ERRSP +  321)    /*    cp_bdy4.c:5749 */
#define   ESP322      (ERRSP +  322)    /*    cp_bdy4.c:5827 */
#define   ESP323      (ERRSP +  323)    /*    cp_bdy4.c:5869 */
#define   ESP324      (ERRSP +  324)    /*    cp_bdy4.c:6001 */
#define   ESP325      (ERRSP +  325)    /*    cp_bdy4.c:6053 */
#define   ESP326      (ERRSP +  326)    /*    cp_bdy4.c:6135 */
#define   ESP327      (ERRSP +  327)    /*    cp_bdy4.c:6234 */
#define   ESP328      (ERRSP +  328)    /*    cp_bdy4.c:6249 */
#define   ESP329      (ERRSP +  329)    /*    cp_bdy4.c:6260 */
#define   ESP330      (ERRSP +  330)    /*    cp_bdy4.c:6311 */

#define   ESP331      (ERRSP +  331)    /*    cp_bdy5.c: 744 */
#define   ESP332      (ERRSP +  332)    /*    cp_bdy5.c: 859 */
#define   ESP333      (ERRSP +  333)    /*    cp_bdy5.c:1069 */
#define   ESP334      (ERRSP +  334)    /*    cp_bdy5.c:1203 */
#define   ESP335      (ERRSP +  335)    /*    cp_bdy5.c:1258 */
#define   ESP336      (ERRSP +  336)    /*    cp_bdy5.c:1273 */
#define   ESP337      (ERRSP +  337)    /*    cp_bdy5.c:1486 */
#define   ESP338      (ERRSP +  338)    /*    cp_bdy5.c:1551 */
#define   ESP339      (ERRSP +  339)    /*    cp_bdy5.c:2277 */
#define   ESP340      (ERRSP +  340)    /*    cp_bdy5.c:2286 */
#define   ESP341      (ERRSP +  341)    /*    cp_bdy5.c:2320 */
#define   ESP342      (ERRSP +  342)    /*    cp_bdy5.c:2676 */
#define   ESP343      (ERRSP +  343)    /*    cp_bdy5.c:2739 */
#define   ESP344      (ERRSP +  344)    /*    cp_bdy5.c:2852 */

#define   ESP345      (ERRSP +  345)    /*    cp_bdy6.c: 316 */
#define   ESP346      (ERRSP +  346)    /*    cp_bdy6.c: 978 */
#define   ESP347      (ERRSP +  347)    /*    cp_bdy6.c:1023 */
#define   ESP348      (ERRSP +  348)    /*    cp_bdy6.c:1057 */
#define   ESP349      (ERRSP +  349)    /*    cp_bdy6.c:1078 */
#define   ESP350      (ERRSP +  350)    /*    cp_bdy6.c:1104 */
#define   ESP351      (ERRSP +  351)    /*    cp_bdy6.c:1109 */
#define   ESP352      (ERRSP +  352)    /*    cp_bdy6.c:1116 */
#define   ESP353      (ERRSP +  353)    /*    cp_bdy6.c:1194 */
#define   ESP354      (ERRSP +  354)    /*    cp_bdy6.c:1206 */
#define   ESP355      (ERRSP +  355)    /*    cp_bdy6.c:1237 */
#define   ESP356      (ERRSP +  356)    /*    cp_bdy6.c:1241 */
#define   ESP357      (ERRSP +  357)    /*    cp_bdy6.c:1247 */
#define   ESP358      (ERRSP +  358)    /*    cp_bdy6.c:1315 */
#define   ESP359      (ERRSP +  359)    /*    cp_bdy6.c:1335 */

#define   ESP360      (ERRSP +  360)    /*    cp_bdy7.c: 273 */
#define   ESP361      (ERRSP +  361)    /*    cp_bdy7.c: 358 */
#define   ESP362      (ERRSP +  362)    /*    cp_bdy7.c: 391 */
#define   ESP363      (ERRSP +  363)    /*    cp_bdy7.c: 424 */
#define   ESP364      (ERRSP +  364)    /*    cp_bdy7.c: 454 */
#define   ESP365      (ERRSP +  365)    /*    cp_bdy7.c: 490 */

#define   ESP366      (ERRSP +  366)    /*   cp_ex_ms.c: 348 */
#define   ESP367      (ERRSP +  367)    /*   cp_ex_ms.c: 376 */
#define   ESP368      (ERRSP +  368)    /*   cp_ex_ms.c: 411 */
#define   ESP369      (ERRSP +  369)    /*   cp_ex_ms.c: 432 */
#define   ESP370      (ERRSP +  370)    /*   cp_ex_ms.c: 448 */

#define   ESP371      (ERRSP +  371)    /*    l3_ptui.c: 576 */
#define   ESP372      (ERRSP +  372)    /*    l3_ptui.c: 623 */
#define   ESP373      (ERRSP +  373)    /*    l3_ptui.c: 666 */
#define   ESP374      (ERRSP +  374)    /*    l3_ptui.c: 713 */

#define   ESP375      (ERRSP +  375)    /*     layer3.c: 278 */
#define   ESP376      (ERRSP +  376)    /*     layer3.c: 327 */
#define   ESP377      (ERRSP +  377)    /*     layer3.c: 341 */
#define   ESP378      (ERRSP +  378)    /*     layer3.c: 348 */
#define   ESP379      (ERRSP +  379)    /*     layer3.c: 400 */
#define   ESP380      (ERRSP +  380)    /*     layer3.c: 717 */
#define   ESP381      (ERRSP +  381)    /*     layer3.c: 718 */
#define   ESP382      (ERRSP +  382)    /*     layer3.c: 719 */
#define   ESP383      (ERRSP +  383)    /*     layer3.c: 720 */
#define   ESP384      (ERRSP +  384)    /*     layer3.c: 721 */
#define   ESP385      (ERRSP +  385)    /*     layer3.c: 722 */
#define   ESP386      (ERRSP +  386)    /*     layer3.c: 724 */
#define   ESP387      (ERRSP +  387)    /*     layer3.c: 726 */
#define   ESP388      (ERRSP +  388)    /*     layer3.c: 776 */
#define   ESP389      (ERRSP +  389)    /*     layer3.c: 782 */
#define   ESP390      (ERRSP +  390)    /*     layer3.c: 783 */
#define   ESP391      (ERRSP +  391)    /*     layer3.c: 784 */
#define   ESP392      (ERRSP +  392)    /*     layer3.c: 785 */
#define   ESP393      (ERRSP +  393)    /*     layer3.c: 787 */
#define   ESP394      (ERRSP +  394)    /*     layer3.c: 789 */
#define   ESP395      (ERRSP +  395)    /*     layer3.c: 829 */
#define   ESP396      (ERRSP +  396)    /*     layer3.c: 830 */
#define   ESP397      (ERRSP +  397)    /*     layer3.c: 831 */
#define   ESP398      (ERRSP +  398)    /*     layer3.c: 833 */
#define   ESP399      (ERRSP +  399)    /*     layer3.c: 835 */
#define   ESP400      (ERRSP +  400)    /*     layer3.c: 883 */

#define   ESP401      (ERRSP +  401)    /*     layer4.c: 252 */
#define   ESP402      (ERRSP +  402)    /*     layer4.c: 253 */
#define   ESP403      (ERRSP +  403)    /*     layer4.c: 254 */
#define   ESP404      (ERRSP +  404)    /*     layer4.c: 256 */
#define   ESP405      (ERRSP +  405)    /*     layer4.c: 258 */
#define   ESP406      (ERRSP +  406)    /*     layer4.c: 307 */
#define   ESP407      (ERRSP +  407)    /*     layer4.c: 308 */
#define   ESP408      (ERRSP +  408)    /*     layer4.c: 309 */
#define   ESP409      (ERRSP +  409)    /*     layer4.c: 311 */
#define   ESP410      (ERRSP +  410)    /*     layer4.c: 313 */
#define   ESP411      (ERRSP +  411)    /*     layer4.c: 383 */
#define   ESP412      (ERRSP +  412)    /*     layer4.c: 391 */
#define   ESP413      (ERRSP +  413)    /*     layer4.c: 392 */
#define   ESP414      (ERRSP +  414)    /*     layer4.c: 393 */
#define   ESP415      (ERRSP +  415)    /*     layer4.c: 394 */
#define   ESP416      (ERRSP +  416)    /*     layer4.c: 395 */
#define   ESP417      (ERRSP +  417)    /*     layer4.c: 396 */
#define   ESP418      (ERRSP +  418)    /*     layer4.c: 397 */
#define   ESP419      (ERRSP +  419)    /*     layer4.c: 399 */
#define   ESP420      (ERRSP +  420)    /*     layer4.c: 401 */
#define   ESP421      (ERRSP +  421)    /*     layer4.c: 460 */
#define   ESP422      (ERRSP +  422)    /*     layer4.c: 482 */
#define   ESP423      (ERRSP +  423)    /*     layer4.c: 483 */
#define   ESP424      (ERRSP +  424)    /*     layer4.c: 484 */
#define   ESP425      (ERRSP +  425)    /*     layer4.c: 486 */
#define   ESP426      (ERRSP +  426)    /*     layer4.c: 488 */
#define   ESP427      (ERRSP +  427)    /*     layer4.c: 569 */
#define   ESP428      (ERRSP +  428)    /*     layer4.c: 576 */
#define   ESP429      (ERRSP +  429)    /*     layer4.c: 577 */
#define   ESP430      (ERRSP +  430)    /*     layer4.c: 578 */
#define   ESP431      (ERRSP +  431)    /*     layer4.c: 579 */
#define   ESP432      (ERRSP +  432)    /*     layer4.c: 581 */
#define   ESP433      (ERRSP +  433)    /*     layer4.c: 583 */
#define   ESP434      (ERRSP +  434)    /*     layer4.c: 647 */
#define   ESP435      (ERRSP +  435)    /*     layer4.c: 648 */
#define   ESP436      (ERRSP +  436)    /*     layer4.c: 649 */
#define   ESP437      (ERRSP +  437)    /*     layer4.c: 650 */
#define   ESP438      (ERRSP +  438)    /*     layer4.c: 651 */
#define   ESP439      (ERRSP +  439)    /*     layer4.c: 652 */
#define   ESP440      (ERRSP +  440)    /*     layer4.c: 654 */
#define   ESP441      (ERRSP +  441)    /*     layer4.c: 656 */
#define   ESP442      (ERRSP +  442)    /*     layer4.c: 701 */
#define   ESP443      (ERRSP +  443)    /*     layer4.c: 702 */
#define   ESP444      (ERRSP +  444)    /*     layer4.c: 703 */
#define   ESP445      (ERRSP +  445)    /*     layer4.c: 704 */
#define   ESP446      (ERRSP +  446)    /*     layer4.c: 706 */
#define   ESP447      (ERRSP +  447)    /*     layer4.c: 708 */
#define   ESP448      (ERRSP +  448)    /*     layer4.c: 754 */
#define   ESP449      (ERRSP +  449)    /*     layer4.c: 755 */
#define   ESP450      (ERRSP +  450)    /*     layer4.c: 756 */
#define   ESP451      (ERRSP +  451)    /*     layer4.c: 757 */
#define   ESP452      (ERRSP +  452)    /*     layer4.c: 759 */
#define   ESP453      (ERRSP +  453)    /*     layer4.c: 761 */
#define   ESP454      (ERRSP +  454)    /*     layer4.c: 832 */
#define   ESP455      (ERRSP +  455)    /*     layer4.c: 834 */
#define   ESP456      (ERRSP +  456)    /*     layer4.c: 835 */
#define   ESP457      (ERRSP +  457)    /*     layer4.c: 837 */
#define   ESP458      (ERRSP +  458)    /*     layer4.c: 838 */
#define   ESP459      (ERRSP +  459)    /*     layer4.c: 839 */
#define   ESP460      (ERRSP +  460)    /*     layer4.c: 841 */
#define   ESP461      (ERRSP +  461)    /*     layer4.c: 843 */
#define   ESP462      (ERRSP +  462)    /*     layer4.c: 889 */
#define   ESP463      (ERRSP +  463)    /*     layer4.c: 891 */
#define   ESP464      (ERRSP +  464)    /*     layer4.c: 893 */
#define   ESP465      (ERRSP +  465)    /*     layer4.c: 941 */
#define   ESP466      (ERRSP +  466)    /*     layer4.c: 943 */
#define   ESP467      (ERRSP +  467)    /*     layer4.c: 945 */
#define   ESP468      (ERRSP +  468)    /*     layer4.c: 987 */
#define   ESP469      (ERRSP +  469)    /*     layer4.c: 994 */
#define   ESP470      (ERRSP +  470)    /*     layer4.c: 995 */
#define   ESP471      (ERRSP +  471)    /*     layer4.c: 997 */
#define   ESP472      (ERRSP +  472)    /*     layer4.c: 999 */
#define   ESP473      (ERRSP +  473)    /*     layer4.c:1042 */
#define   ESP474      (ERRSP +  474)    /*     layer4.c:1044 */
#define   ESP475      (ERRSP +  475)    /*     layer4.c:1046 */
#define   ESP476      (ERRSP +  476)    /*     layer4.c:1089 */
#define   ESP477      (ERRSP +  477)    /*     layer4.c:1090 */
#define   ESP478      (ERRSP +  478)    /*     layer4.c:1092 */
#define   ESP479      (ERRSP +  479)    /*     layer4.c:1132 */
#define   ESP480      (ERRSP +  480)    /*     layer4.c:1133 */
#define   ESP481      (ERRSP +  481)    /*     layer4.c:1134 */
#define   ESP482      (ERRSP +  482)    /*     layer4.c:1135 */
#define   ESP483      (ERRSP +  483)    /*     layer4.c:1137 */
#define   ESP484      (ERRSP +  484)    /*     layer4.c:1139 */
#define   ESP485      (ERRSP +  485)    /*     layer4.c:1180 */
#define   ESP486      (ERRSP +  486)    /*     layer4.c:1181 */
#define   ESP487      (ERRSP +  487)    /*     layer4.c:1182 */
#define   ESP488      (ERRSP +  488)    /*     layer4.c:1183 */
#define   ESP489      (ERRSP +  489)    /*     layer4.c:1185 */
#define   ESP490      (ERRSP +  490)    /*     layer4.c:1187 */
#define   ESP491      (ERRSP +  491)    /*     layer4.c:1233 */
#define   ESP492      (ERRSP +  492)    /*     layer4.c:1238 */
#define   ESP493      (ERRSP +  493)    /*     layer4.c:1239 */
#define   ESP494      (ERRSP +  494)    /*     layer4.c:1241 */
#define   ESP495      (ERRSP +  495)    /*     layer4.c:1243 */
#define   ESP496      (ERRSP +  496)    /*     layer4.c:1245 */
#define   ESP497      (ERRSP +  497)    /*     layer4.c:1288 */
#define   ESP498      (ERRSP +  498)    /*     layer4.c:1289 */
#define   ESP499      (ERRSP +  499)    /*     layer4.c:1290 */
#define   ESP500      (ERRSP +  500)    /*     layer4.c:1291 */
#define   ESP501      (ERRSP +  501)    /*     layer4.c:1293 */
#define   ESP502      (ERRSP +  502)    /*     layer4.c:1295 */
#define   ESP503      (ERRSP +  503)    /*     layer4.c:1337 */
#define   ESP504      (ERRSP +  504)    /*     layer4.c:1338 */
#define   ESP505      (ERRSP +  505)    /*     layer4.c:1339 */
#define   ESP506      (ERRSP +  506)    /*     layer4.c:1341 */
#define   ESP507      (ERRSP +  507)    /*     layer4.c:1382 */
#define   ESP508      (ERRSP +  508)    /*     layer4.c:1383 */
#define   ESP509      (ERRSP +  509)    /*     layer4.c:1384 */
#define   ESP510      (ERRSP +  510)    /*     layer4.c:1386 */

#define   ESP511      (ERRSP +  511)    /*     sp_acc.c: 255 */
#define   ESP512      (ERRSP +  512)    /*     sp_acc.c: 274 */
#define   ESP513      (ERRSP +  513)    /*     sp_acc.c: 293 */
#define   ESP514      (ERRSP +  514)    /*     sp_acc.c:3203 */
#define   ESP515      (ERRSP +  515)    /*     sp_acc.c:3246 */
#define   ESP516      (ERRSP +  516)    /*     sp_acc.c:3288 */
#define   ESP517      (ERRSP +  517)    /*     sp_acc.c:3330 */
#define   ESP518      (ERRSP +  518)    /*     sp_acc.c:3371 */
#define   ESP519      (ERRSP +  519)    /*     sp_acc.c:3411 */
#define   ESP520      (ERRSP +  520)    /*     sp_acc.c:3446 */
#define   ESP521      (ERRSP +  521)    /*     sp_acc.c:6821 */
#define   ESP522      (ERRSP +  522)    /*     sp_acc.c:6824 */
#define   ESP523      (ERRSP +  523)    /*     sp_acc.c:7664 */
#define   ESP524      (ERRSP +  524)    /*     sp_acc.c:7781 */
#define   ESP525      (ERRSP +  525)    /*     sp_acc.c:7963 */
#define   ESP526      (ERRSP +  526)    /*     sp_acc.c:8020 */
#define   ESP527      (ERRSP +  527)    /*     sp_acc.c:8023 */
#define   ESP528      (ERRSP +  528)    /*     sp_acc.c:8026 */
#define   ESP529      (ERRSP +  529)    /*     sp_acc.c:8032 */
#define   ESP530      (ERRSP +  530)    /*     sp_acc.c:8034 */
#define   ESP531      (ERRSP +  531)    /*     sp_acc.c:8036 */
#define   ESP532      (ERRSP +  532)    /*     sp_acc.c:8042 */
#define   ESP533      (ERRSP +  533)    /*     sp_acc.c:8047 */
#define   ESP534      (ERRSP +  534)    /*     sp_acc.c:8050 */
#define   ESP535      (ERRSP +  535)    /*     sp_acc.c:8053 */
#define   ESP536      (ERRSP +  536)    /*     sp_acc.c:8060 */
#define   ESP537      (ERRSP +  537)    /*     sp_acc.c:8065 */
#define   ESP538      (ERRSP +  538)    /*     sp_acc.c:8067 */
#define   ESP539      (ERRSP +  539)    /*     sp_acc.c:8069 */
#define   ESP540      (ERRSP +  540)    /*     sp_acc.c:8071 */
#define   ESP541      (ERRSP +  541)    /*     sp_acc.c:8073 */
#define   ESP542      (ERRSP +  542)    /*     sp_acc.c:8077 */
#define   ESP543      (ERRSP +  543)    /*     sp_acc.c:8079 */
#define   ESP544      (ERRSP +  544)    /*     sp_acc.c:8081 */
#define   ESP545      (ERRSP +  545)    /*     sp_acc.c:8091 */
#define   ESP546      (ERRSP +  546)    /*     sp_acc.c:8093 */
#define   ESP547      (ERRSP +  547)    /*     sp_acc.c:8095 */
#define   ESP548      (ERRSP +  548)    /*     sp_acc.c:8102 */
#define   ESP549      (ERRSP +  549)    /*     sp_acc.c:8108 */
#define   ESP550      (ERRSP +  550)    /*     sp_acc.c:8114 */
#define   ESP551      (ERRSP +  551)    /*     sp_acc.c:8120 */
#define   ESP552      (ERRSP +  552)    /*     sp_acc.c:8123 */
#define   ESP553      (ERRSP +  553)    /*     sp_acc.c:8133 */
#define   ESP554      (ERRSP +  554)    /*     sp_acc.c:8135 */
#define   ESP555      (ERRSP +  555)    /*     sp_acc.c:8142 */
#define   ESP556      (ERRSP +  556)    /*     sp_acc.c:8146 */
#define   ESP557      (ERRSP +  557)    /*     sp_acc.c:8148 */
#define   ESP558      (ERRSP +  558)    /*     sp_acc.c:8154 */
#define   ESP559      (ERRSP +  559)    /*     sp_acc.c:8159 */
#define   ESP560      (ERRSP +  560)    /*     sp_acc.c:8161 */
#define   ESP561      (ERRSP +  561)    /*     sp_acc.c:8165 */
#define   ESP562      (ERRSP +  562)    /*     sp_acc.c:8176 */
#define   ESP563      (ERRSP +  563)    /*     sp_acc.c:8178 */
#define   ESP564      (ERRSP +  564)    /*     sp_acc.c:8245 */

#define   ESP565      (ERRSP +  565)    /*    sp_acc1.c: 308 */
#define   ESP566      (ERRSP +  566)    /*    sp_acc1.c: 312 */
#define   ESP567      (ERRSP +  567)    /*    sp_acc1.c: 317 */
#define   ESP568      (ERRSP +  568)    /*    sp_acc1.c: 355 */
#define   ESP569      (ERRSP +  569)    /*    sp_acc1.c: 616 */
#define   ESP570      (ERRSP +  570)    /*    sp_acc1.c: 620 */
#define   ESP571      (ERRSP +  571)    /*    sp_acc1.c: 624 */
#define   ESP572      (ERRSP +  572)    /*    sp_acc1.c: 673 */
#define   ESP573      (ERRSP +  573)    /*    sp_acc1.c: 709 */
#define   ESP574      (ERRSP +  574)    /*    sp_acc1.c: 713 */
#define   ESP575      (ERRSP +  575)    /*    sp_acc1.c: 718 */
#define   ESP576      (ERRSP +  576)    /*    sp_acc1.c: 778 */
#define   ESP577      (ERRSP +  577)    /*    sp_acc1.c: 824 */
#define   ESP578      (ERRSP +  578)    /*    sp_acc1.c: 849 */
#define   ESP579      (ERRSP +  579)    /*    sp_acc1.c: 853 */
#define   ESP580      (ERRSP +  580)    /*    sp_acc1.c: 857 */
#define   ESP581      (ERRSP +  581)    /*    sp_acc1.c: 947 */
#define   ESP582      (ERRSP +  582)    /*    sp_acc1.c: 958 */
#define   ESP583      (ERRSP +  583)    /*    sp_acc1.c: 962 */
#define   ESP584      (ERRSP +  584)    /*    sp_acc1.c: 966 */
#define   ESP585      (ERRSP +  585)    /*    sp_acc1.c:1029 */
#define   ESP586      (ERRSP +  586)    /*    sp_acc1.c:1034 */
#define   ESP587      (ERRSP +  587)    /*    sp_acc1.c:1072 */
#define   ESP588      (ERRSP +  588)    /*    sp_acc1.c:1084 */
#define   ESP589      (ERRSP +  589)    /*    sp_acc1.c:1089 */
#define   ESP590      (ERRSP +  590)    /*    sp_acc1.c:1099 */
#define   ESP591      (ERRSP +  591)    /*    sp_acc1.c:1108 */
#define   ESP592      (ERRSP +  592)    /*    sp_acc1.c:1112 */
#define   ESP593      (ERRSP +  593)    /*    sp_acc1.c:1117 */
#define   ESP594      (ERRSP +  594)    /*    sp_acc1.c:1181 */
#define   ESP595      (ERRSP +  595)    /*    sp_acc1.c:1191 */
#define   ESP596      (ERRSP +  596)    /*    sp_acc1.c:1232 */
#define   ESP597      (ERRSP +  597)    /*    sp_acc1.c:1246 */
#define   ESP598      (ERRSP +  598)    /*    sp_acc1.c:1258 */
#define   ESP599      (ERRSP +  599)    /*    sp_acc1.c:1279 */
#define   ESP600      (ERRSP +  600)    /*    sp_acc1.c:1284 */
#define   ESP601      (ERRSP +  601)    /*    sp_acc1.c:1294 */
#define   ESP602      (ERRSP +  602)    /*    sp_acc1.c:1303 */
#define   ESP603      (ERRSP +  603)    /*    sp_acc1.c:1307 */
#define   ESP604      (ERRSP +  604)    /*    sp_acc1.c:1314 */
#define   ESP605      (ERRSP +  605)    /*    sp_acc1.c:1395 */
#define   ESP606      (ERRSP +  606)    /*    sp_acc1.c:1401 */
#define   ESP607      (ERRSP +  607)    /*    sp_acc1.c:1410 */
#define   ESP608      (ERRSP +  608)    /*    sp_acc1.c:1414 */
#define   ESP609      (ERRSP +  609)    /*    sp_acc1.c:1419 */
#define   ESP610      (ERRSP +  610)    /*    sp_acc1.c:1526 */
#define   ESP611      (ERRSP +  611)    /*    sp_acc1.c:1538 */
#define   ESP612      (ERRSP +  612)    /*    sp_acc1.c:1543 */
#define   ESP613      (ERRSP +  613)    /*    sp_acc1.c:1547 */
#define   ESP614      (ERRSP +  614)    /*    sp_acc1.c:1552 */
#define   ESP615      (ERRSP +  615)    /*    sp_acc1.c:1555 */
#define   ESP616      (ERRSP +  616)    /*    sp_acc1.c:1702 */
#define   ESP617      (ERRSP +  617)    /*    sp_acc1.c:1727 */
#define   ESP618      (ERRSP +  618)    /*    sp_acc1.c:1766 */
#define   ESP619      (ERRSP +  619)    /*    sp_acc1.c:1775 */
#define   ESP620      (ERRSP +  620)    /*    sp_acc1.c:1779 */
#define   ESP621      (ERRSP +  621)    /*    sp_acc1.c:1784 */
#define   ESP622      (ERRSP +  622)    /*    sp_acc1.c:1872 */
#define   ESP623      (ERRSP +  623)    /*    sp_acc1.c:1877 */
#define   ESP624      (ERRSP +  624)    /*    sp_acc1.c:1881 */
#define   ESP625      (ERRSP +  625)    /*    sp_acc1.c:1886 */
#define   ESP626      (ERRSP +  626)    /*    sp_acc1.c:1935 */
#define   ESP627      (ERRSP +  627)    /*    sp_acc1.c:1952 */
#define   ESP628      (ERRSP +  628)    /*    sp_acc1.c:1963 */
#define   ESP629      (ERRSP +  629)    /*    sp_acc1.c:1972 */
#define   ESP630      (ERRSP +  630)    /*    sp_acc1.c:1976 */
#define   ESP631      (ERRSP +  631)    /*    sp_acc1.c:1981 */
#define   ESP632      (ERRSP +  632)    /*    sp_acc1.c:2048 */
#define   ESP633      (ERRSP +  633)    /*    sp_acc1.c:2053 */
#define   ESP634      (ERRSP +  634)    /*    sp_acc1.c:2076 */
#define   ESP635      (ERRSP +  635)    /*    sp_acc1.c:2081 */
#define   ESP636      (ERRSP +  636)    /*    sp_acc1.c:2085 */
#define   ESP637      (ERRSP +  637)    /*    sp_acc1.c:2090 */
#define   ESP638      (ERRSP +  638)    /*    sp_acc1.c:2150 */
#define   ESP639      (ERRSP +  639)    /*    sp_acc1.c:2154 */
#define   ESP640      (ERRSP +  640)    /*    sp_acc1.c:2167 */
#define   ESP641      (ERRSP +  641)    /*    sp_acc1.c:2172 */
#define   ESP642      (ERRSP +  642)    /*    sp_acc1.c:2176 */
#define   ESP643      (ERRSP +  643)    /*    sp_acc1.c:2181 */
#define   ESP644      (ERRSP +  644)    /*    sp_acc1.c:2234 */
#define   ESP645      (ERRSP +  645)    /*    sp_acc1.c:2238 */
#define   ESP646      (ERRSP +  646)    /*    sp_acc1.c:2249 */
#define   ESP647      (ERRSP +  647)    /*    sp_acc1.c:2286 */
#define   ESP648      (ERRSP +  648)    /*    sp_acc1.c:2379 */
#define   ESP649      (ERRSP +  649)    /*    sp_acc1.c:2422 */
#define   ESP650      (ERRSP +  650)    /*    sp_acc1.c:2452 */
#define   ESP651      (ERRSP +  651)    /*    sp_acc1.c:2556 */
#define   ESP652      (ERRSP +  652)    /*    sp_acc1.c:2611 */
#define   ESP653      (ERRSP +  653)    /*    sp_acc1.c:2617 */
#define   ESP654      (ERRSP +  654)    /*    sp_acc1.c:2621 */
#define   ESP655      (ERRSP +  655)    /*    sp_acc1.c:2630 */
#define   ESP656      (ERRSP +  656)    /*    sp_acc1.c:2669 */
#define   ESP657      (ERRSP +  657)    /*    sp_acc1.c:2675 */
#define   ESP658      (ERRSP +  658)    /*    sp_acc1.c:2679 */
#define   ESP659      (ERRSP +  659)    /*    sp_acc1.c:2684 */
#define   ESP660      (ERRSP +  660)    /*    sp_acc1.c:2821 */
#define   ESP661      (ERRSP +  661)    /*    sp_acc1.c:2827 */
#define   ESP662      (ERRSP +  662)    /*    sp_acc1.c:2831 */
#define   ESP663      (ERRSP +  663)    /*    sp_acc1.c:2840 */
#define   ESP664      (ERRSP +  664)    /*    sp_acc1.c:2966 */
#define   ESP665      (ERRSP +  665)    /*    sp_acc1.c:2972 */
#define   ESP666      (ERRSP +  666)    /*    sp_acc1.c:2976 */
#define   ESP667      (ERRSP +  667)    /*    sp_acc1.c:2981 */
#define   ESP668      (ERRSP +  668)    /*    sp_acc1.c:2987 */
#define   ESP669      (ERRSP +  669)    /*    sp_acc1.c:3114 */
#define   ESP670      (ERRSP +  670)    /*    sp_acc1.c:3318 */
#define   ESP671      (ERRSP +  671)    /*    sp_acc1.c:3348 */
#define   ESP672      (ERRSP +  672)    /*    sp_acc1.c:3352 */
#define   ESP673      (ERRSP +  673)    /*    sp_acc1.c:3421 */
#define   ESP674      (ERRSP +  674)    /*    sp_acc1.c:3424 */
#define   ESP675      (ERRSP +  675)    /*    sp_acc1.c:3427 */
#define   ESP676      (ERRSP +  676)    /*    sp_acc1.c:3430 */
#define   ESP677      (ERRSP +  677)    /*    sp_acc1.c:3480 */
#define   ESP678      (ERRSP +  678)    /*    sp_acc1.c:3517 */
#define   ESP679      (ERRSP +  679)    /*    sp_acc1.c:3520 */
#define   ESP680      (ERRSP +  680)    /*    sp_acc1.c:3523 */
#define   ESP681      (ERRSP +  681)    /*    sp_acc1.c:3570 */
#define   ESP682      (ERRSP +  682)    /*    sp_acc1.c:3598 */
#define   ESP683      (ERRSP +  683)    /*    sp_acc1.c:3601 */
#define   ESP684      (ERRSP +  684)    /*    sp_acc1.c:3735 */
#define   ESP685      (ERRSP +  685)    /*    sp_acc1.c:3767 */

#define   ESP686      (ERRSP +  686)    /*    sp_acc3.c:1604 */
#define   ESP687      (ERRSP +  687)    /*    sp_acc3.c:1765 */
#define   ESP688      (ERRSP +  688)    /*    sp_acc3.c:2057 */
#define   ESP689      (ERRSP +  689)    /*    sp_acc3.c:2313 */
#define   ESP690      (ERRSP +  690)    /*    sp_acc3.c:2495 */
#define   ESP691      (ERRSP +  691)    /*    sp_acc3.c:2763 */
#define   ESP692      (ERRSP +  692)    /*    sp_acc3.c:3006 */
#define   ESP693      (ERRSP +  693)    /*    sp_acc3.c:3172 */
#define   ESP694      (ERRSP +  694)    /*    sp_acc3.c:3339 */
#define   ESP695      (ERRSP +  695)    /*    sp_acc3.c:3629 */
#define   ESP696      (ERRSP +  696)    /*    sp_acc3.c:3889 */
#define   ESP697      (ERRSP +  697)    /*    sp_acc3.c:4080 */
#define   ESP698      (ERRSP +  698)    /*    sp_acc3.c:4268 */
#define   ESP699      (ERRSP +  699)    /*    sp_acc3.c:4541 */
#define   ESP700      (ERRSP +  700)    /*    sp_acc3.c:4790 */
#define   ESP701      (ERRSP +  701)    /*    sp_acc3.c:4983 */
#define   ESP702      (ERRSP +  702)    /*    sp_acc3.c:5241 */
#define   ESP703      (ERRSP +  703)    /*    sp_acc3.c:5470 */
#define   ESP704      (ERRSP +  704)    /*    sp_acc3.c:5652 */
#define   ESP705      (ERRSP +  705)    /*    sp_acc3.c:5863 */
#define   ESP706      (ERRSP +  706)    /*    sp_acc3.c:6025 */
#define   ESP707      (ERRSP +  707)    /*    sp_acc3.c:6218 */
#define   ESP708      (ERRSP +  708)    /*    sp_acc3.c:6520 */
#define   ESP709      (ERRSP +  709)    /*    sp_acc3.c:6779 */
#define   ESP710      (ERRSP +  710)    /*    sp_acc3.c:6973 */
#define   ESP711      (ERRSP +  711)    /*    sp_acc3.c:7164 */
#define   ESP712      (ERRSP +  712)    /*    sp_acc3.c:7311 */
#define   ESP713      (ERRSP +  713)    /*    sp_acc3.c:7488 */
#define   ESP714      (ERRSP +  714)    /*    sp_acc3.c:7662 */
#define   ESP715      (ERRSP +  715)    /*    sp_acc3.c:7923 */
#define   ESP716      (ERRSP +  716)    /*    sp_acc3.c:8141 */
#define   ESP717      (ERRSP +  717)    /*    sp_acc3.c:8336 */
#define   ESP718      (ERRSP +  718)    /*    sp_acc3.c:8539 */
#define   ESP719      (ERRSP +  719)    /*    sp_acc3.c:8693 */
#define   ESP720      (ERRSP +  720)    /*    sp_acc3.c:8856 */
#define   ESP721      (ERRSP +  721)    /*    sp_acc3.c:9035 */
#define   ESP722      (ERRSP +  722)    /*    sp_acc3.c:9185 */
#define   ESP723      (ERRSP +  723)    /*    sp_acc3.c:9366 */
#define   ESP724      (ERRSP +  724)    /*    sp_acc3.c:9528 */
#define   ESP725      (ERRSP +  725)    /*    sp_acc3.c:9818 */
#define   ESP726      (ERRSP +  726)    /*    sp_acc3.c:10075 */
#define   ESP727      (ERRSP +  727)    /*    sp_acc3.c:10293 */
#define   ESP728      (ERRSP +  728)    /*    sp_acc3.c:10563 */
#define   ESP729      (ERRSP +  729)    /*    sp_acc3.c:10808 */
#define   ESP730      (ERRSP +  730)    /*    sp_acc3.c:10976 */
#define   ESP731      (ERRSP +  731)    /*    sp_acc3.c:11144 */
#define   ESP732      (ERRSP +  732)    /*    sp_acc3.c:11436 */
#define   ESP733      (ERRSP +  733)    /*    sp_acc3.c:11697 */
#define   ESP734      (ERRSP +  734)    /*    sp_acc3.c:11889 */
#define   ESP735      (ERRSP +  735)    /*    sp_acc3.c:12076 */
#define   ESP736      (ERRSP +  736)    /*    sp_acc3.c:12354 */
#define   ESP737      (ERRSP +  737)    /*    sp_acc3.c:12605 */
#define   ESP738      (ERRSP +  738)    /*    sp_acc3.c:12799 */
#define   ESP739      (ERRSP +  739)    /*    sp_acc3.c:13059 */
#define   ESP740      (ERRSP +  740)    /*    sp_acc3.c:13289 */
#define   ESP741      (ERRSP +  741)    /*    sp_acc3.c:13473 */
#define   ESP742      (ERRSP +  742)    /*    sp_acc3.c:13688 */
#define   ESP743      (ERRSP +  743)    /*    sp_acc3.c:13852 */
#define   ESP744      (ERRSP +  744)    /*    sp_acc3.c:14046 */
#define   ESP745      (ERRSP +  745)    /*    sp_acc3.c:14351 */
#define   ESP746      (ERRSP +  746)    /*    sp_acc3.c:14613 */
#define   ESP747      (ERRSP +  747)    /*    sp_acc3.c:14808 */
#define   ESP748      (ERRSP +  748)    /*    sp_acc3.c:15001 */
#define   ESP749      (ERRSP +  749)    /*    sp_acc3.c:15150 */
#define   ESP750      (ERRSP +  750)    /*    sp_acc3.c:15333 */
#define   ESP751      (ERRSP +  751)    /*    sp_acc3.c:15503 */
#define   ESP752      (ERRSP +  752)    /*    sp_acc3.c:15765 */
#define   ESP753      (ERRSP +  753)    /*    sp_acc3.c:15984 */
#define   ESP754      (ERRSP +  754)    /*    sp_acc3.c:16139 */
#define   ESP755      (ERRSP +  755)    /*    sp_acc3.c:16319 */
#define   ESP756      (ERRSP +  756)    /*    sp_acc3.c:16480 */
#define   ESP757      (ERRSP +  757)    /*    sp_acc3.c:16807 */
#define   ESP758      (ERRSP +  758)    /*    sp_acc3.c:17099 */
#define   ESP759      (ERRSP +  759)    /*    sp_acc3.c:17278 */
#define   ESP760      (ERRSP +  760)    /*    sp_acc3.c:17547 */
#define   ESP761      (ERRSP +  761)    /*    sp_acc3.c:17790 */
#define   ESP762      (ERRSP +  762)    /*    sp_acc3.c:17957 */
#define   ESP763      (ERRSP +  763)    /*    sp_acc3.c:18124 */
#define   ESP764      (ERRSP +  764)    /*    sp_acc3.c:18451 */
#define   ESP765      (ERRSP +  765)    /*    sp_acc3.c:18747 */
#define   ESP766      (ERRSP +  766)    /*    sp_acc3.c:18935 */
#define   ESP767      (ERRSP +  767)    /*    sp_acc3.c:19121 */
#define   ESP768      (ERRSP +  768)    /*    sp_acc3.c:19395 */
#define   ESP769      (ERRSP +  769)    /*    sp_acc3.c:19643 */
#define   ESP770      (ERRSP +  770)    /*    sp_acc3.c:19835 */
#define   ESP771      (ERRSP +  771)    /*    sp_acc3.c:20090 */
#define   ESP772      (ERRSP +  772)    /*    sp_acc3.c:20318 */
#define   ESP773      (ERRSP +  773)    /*    sp_acc3.c:20495 */
#define   ESP774      (ERRSP +  774)    /*    sp_acc3.c:20708 */
#define   ESP775      (ERRSP +  775)    /*    sp_acc3.c:20870 */
#define   ESP776      (ERRSP +  776)    /*    sp_acc3.c:21063 */
#define   ESP777      (ERRSP +  777)    /*    sp_acc3.c:21366 */
#define   ESP778      (ERRSP +  778)    /*    sp_acc3.c:21625 */
#define   ESP779      (ERRSP +  779)    /*    sp_acc3.c:21823 */
#define   ESP780      (ERRSP +  780)    /*    sp_acc3.c:22014 */
#define   ESP781      (ERRSP +  781)    /*    sp_acc3.c:22161 */
#define   ESP782      (ERRSP +  782)    /*    sp_acc3.c:22338 */
#define   ESP783      (ERRSP +  783)    /*    sp_acc3.c:22507 */
#define   ESP784      (ERRSP +  784)    /*    sp_acc3.c:22768 */
#define   ESP785      (ERRSP +  785)    /*    sp_acc3.c:22986 */
#define   ESP786      (ERRSP +  786)    /*    sp_acc3.c:23180 */
#define   ESP787      (ERRSP +  787)    /*    sp_acc3.c:23383 */
#define   ESP788      (ERRSP +  788)    /*    sp_acc3.c:23537 */
#define   ESP789      (ERRSP +  789)    /*    sp_acc3.c:23700 */
#define   ESP790      (ERRSP +  790)    /*    sp_acc3.c:23880 */
#define   ESP791      (ERRSP +  791)    /*    sp_acc3.c:24030 */
#define   ESP792      (ERRSP +  792)    /*    sp_acc3.c:24211 */
#define   ESP793      (ERRSP +  793)    /*    sp_acc3.c:24373 */
#define   ESP794      (ERRSP +  794)    /*    sp_acc3.c:24700 */
#define   ESP795      (ERRSP +  795)    /*    sp_acc3.c:24993 */
#define   ESP796      (ERRSP +  796)    /*    sp_acc3.c:25173 */
#define   ESP797      (ERRSP +  797)    /*    sp_acc3.c:25428 */
#define   ESP798      (ERRSP +  798)    /*    sp_acc3.c:25673 */
#define   ESP799      (ERRSP +  799)    /*    sp_acc3.c:25840 */
#define   ESP800      (ERRSP +  800)    /*    sp_acc3.c:26007 */
#define   ESP801      (ERRSP +  801)    /*    sp_acc3.c:26335 */
#define   ESP802      (ERRSP +  802)    /*    sp_acc3.c:26632 */
#define   ESP803      (ERRSP +  803)    /*    sp_acc3.c:26821 */
#define   ESP804      (ERRSP +  804)    /*    sp_acc3.c:27009 */
#define   ESP805      (ERRSP +  805)    /*    sp_acc3.c:27285 */
#define   ESP806      (ERRSP +  806)    /*    sp_acc3.c:27535 */
#define   ESP807      (ERRSP +  807)    /*    sp_acc3.c:27728 */
#define   ESP808      (ERRSP +  808)    /*    sp_acc3.c:27968 */
#define   ESP809      (ERRSP +  809)    /*    sp_acc3.c:28197 */
#define   ESP810      (ERRSP +  810)    /*    sp_acc3.c:28374 */
#define   ESP811      (ERRSP +  811)    /*    sp_acc3.c:28590 */
#define   ESP812      (ERRSP +  812)    /*    sp_acc3.c:28754 */
#define   ESP813      (ERRSP +  813)    /*    sp_acc3.c:28948 */
#define   ESP814      (ERRSP +  814)    /*    sp_acc3.c:29253 */
#define   ESP815      (ERRSP +  815)    /*    sp_acc3.c:29515 */
#define   ESP816      (ERRSP +  816)    /*    sp_acc3.c:29714 */
#define   ESP817      (ERRSP +  817)    /*    sp_acc3.c:29907 */
#define   ESP818      (ERRSP +  818)    /*    sp_acc3.c:30056 */
#define   ESP819      (ERRSP +  819)    /*    sp_acc3.c:30234 */
#define   ESP820      (ERRSP +  820)    /*    sp_acc3.c:30405 */
#define   ESP821      (ERRSP +  821)    /*    sp_acc3.c:30667 */
#define   ESP822      (ERRSP +  822)    /*    sp_acc3.c:30887 */
#define   ESP823      (ERRSP +  823)    /*    sp_acc3.c:31041 */

#define   ESP824      (ERRSP +  824)    /*    sp_acc4.c:7528 */
#define   ESP825      (ERRSP +  825)    /*    sp_acc4.c:7583 */

#define   ESP826      (ERRSP +  826)    /*   sp_accsh.c: 220 */
#define   ESP827      (ERRSP +  827)    /*   sp_accsh.c: 229 */
#define   ESP828      (ERRSP +  828)    /*   sp_accsh.c: 234 */
#define   ESP829      (ERRSP +  829)    /*   sp_accsh.c: 307 */
#define   ESP830      (ERRSP +  830)    /*   sp_accsh.c: 309 */
#define   ESP831      (ERRSP +  831)    /*   sp_accsh.c: 367 */

#define   ESP832      (ERRSP +  832)    /*    sp_ptli.c: 502 */
#define   ESP833      (ERRSP +  833)    /*    sp_ptli.c: 556 */
#define   ESP834      (ERRSP +  834)    /*    sp_ptli.c: 597 */

#define   ESP835      (ERRSP +  835)    /*    sp_ptmi.c: 606 */
#define   ESP836      (ERRSP +  836)    /*    sp_ptmi.c: 643 */
#define   ESP837      (ERRSP +  837)    /*    sp_ptmi.c: 680 */
#define   ESP838      (ERRSP +  838)    /*    sp_ptmi.c: 722 */
#define   ESP839      (ERRSP +  839)    /*    sp_ptmi.c: 762 */
#define   ESP840      (ERRSP +  840)    /*    sp_ptmi.c: 800 */
#define   ESP841      (ERRSP +  841)    /*    sp_ptmi.c: 872 */

#define   ESP842      (ERRSP +  842)    /*    sp_ptui.c:1194 */
#define   ESP843      (ERRSP +  843)    /*    sp_ptui.c:1256 */
#define   ESP844      (ERRSP +  844)    /*    sp_ptui.c:1322 */
#define   ESP845      (ERRSP +  845)    /*    sp_ptui.c:1395 */
#define   ESP846      (ERRSP +  846)    /*    sp_ptui.c:2103 */
#define   ESP847      (ERRSP +  847)    /*    sp_ptui.c:2150 */
#define   ESP848      (ERRSP +  848)    /*    sp_ptui.c:2191 */
#define   ESP849      (ERRSP +  849)    /*    sp_ptui.c:2233 */
#define   ESP850      (ERRSP +  850)    /*    sp_ptui.c:2281 */
#define   ESP851      (ERRSP +  851)    /*    sp_ptui.c:2340 */
#define   ESP852      (ERRSP +  852)    /*    sp_ptui.c:2381 */
#define   ESP853      (ERRSP +  853)    /*    sp_ptui.c:2421 */
#define   ESP854      (ERRSP +  854)    /*    sp_ptui.c:2490 */
#define   ESP855      (ERRSP +  855)    /*    sp_ptui.c:2532 */
#define   ESP856      (ERRSP +  856)    /*    sp_ptui.c:2571 */
#define   ESP857      (ERRSP +  857)    /*    sp_ptui.c:2610 */
#define   ESP858      (ERRSP +  858)    /*    sp_ptui.c:2649 */
#define   ESP859      (ERRSP +  859)    /*    sp_ptui.c:2686 */
#define   ESP860      (ERRSP +  860)    /*    sp_ptui.c:2723 */
#define   ESP861      (ERRSP +  861)    /*    sp_ptui.c:2760 */
#define   ESP862      (ERRSP +  862)    /*    sp_ptui.c:2799 */
#define   ESP863      (ERRSP +  863)    /*    sp_ptui.c:2836 */
#define   ESP864      (ERRSP +  864)    /*    sp_ptui.c:2874 */
#define   ESP865      (ERRSP +  865)    /*    sp_ptui.c:2911 */


#if ERRCLASS
#define SPLOGERROR(errCls, errCode, errVal, errDesc) \
      SLogError(spCb.spInit.ent, spCb.spInit.inst, spCb.spInit.procId, \
                __FILE__, __LINE__, errCls, errCode, errVal, errDesc)
#else
#define SPLOGERROR(errCls, errCode, errVal, errDesc)
#endif /* ERRCLASS */
/* sp049.302 - addition - new macro to avoid using spCb (for SS_MULTIPLE_PROCS
 * case) since it can cause crash if SGetXxCb() returns NULLP.
 */
/* sp050.302 - modification - renamed SLOGERROR to SPERROR and changed order
 * of arguments to SLogError.
 */
#if ERRCLASS
#ifdef SPERROR
#undef SPERROR
#endif /* SPERROR */
#define SPERROR(pst, errCls, errCode, errVal, errDesc) \
      SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, \
                __FILE__, __LINE__, errCls, errCode, errVal, errDesc)
#endif /* ERRCLASS */

#endif /* __SPERRH__ */

/********************************************************************30**
  
         End of file:     sp_err.h@@/main/13_1 - Tue Jan 22 15:12:59 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. Added support for connection oriented control

1.3          ---  fmg   1. add error codes

1.4          ---  scc   1. add error codes

1.5          ---  scc   1. add error codes

1.6          ---  scc   1. add error codes for CCITT92 and ANSI92 
                           modifications

1.7          ---  fmg   1. add error codes.

1.8          ---  mjp   1. add SPLOGERROR
             ---  mjp   2. update error codes

1.9          ---  mjp   1. ERRSP replaced with ESPBASE

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.10         ---      ash  1. Changed error defines
  
/main/11     ---      vb   1. Changed error defines

/main/13     ---      cp   1. Err defines changed.
/main/13_1   ---        rc   1. Macro SPLOGERROR defined conditionally.
             sp001.302  rc   1. Sid correction
             sp049.302  mc   1. SLOGERROR macro to avoid using spCb
                                (for SS_MULTIPLE_PROCS case) since it can
                                cause crash if SGetXxCb() returns NULLP.
             sp050.302  mc   1. SLOGERROR macro renamed to SPERROR and order
                                of arguments to SLogError corrected.
*********************************************************************91*/
