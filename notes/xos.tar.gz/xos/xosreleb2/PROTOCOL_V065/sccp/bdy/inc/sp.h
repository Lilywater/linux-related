/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp
  
     Type:     C include file
  
     Desc:     Defines required by sccp.
  
     File:     sp.h
  
     Sid:      sp.h@@/main/11 - Tue Jan 22 15:12:31 2002
  
     Prg:      fmg
  
*********************************************************************21*/
  
#ifndef __SPH__
#define __SPH__
  

/****************************************************
 * Misc defines.                                    *
 ****************************************************/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
#ifndef SP_MAX_INSTANCES
#define SP_MAX_INSTANCES 2
#endif
#define spCb (*spCbPtr) 
#endif /* SS_MULTIPLE_PROCS */

#ifndef CMFTHA_RES_RSETID
#define CMFTHA_RES_RSETID      0x0
#endif

#define SP_OFFSET(s, m) (&(((s *)0)->m))
#define SPLAYERNAME   "SCCP"    /* layer name */

#define MAXSPLI          3      /* maximum number of lower interfaces */
/* sp047.302 - Modify - Changed MAXSPUI from 6 to 7 to handle SCCP user for
 * SPU.
 */
#define MAXSPUI          7      /* maximum upper interface entries */
#define MAXSPMI          3      /* maximum number of management interfaces */

#define TQNUMENT     64          /* maximum number of timer Q entries */
#define MODTQNUM (TQNUMENT - 1)  /* modulo 64 (63) */

#define SCCP_SI      0x03        /* SCCP service indicator */

#define NOTUSED         0        /* arg not used */
#define FROM_UPPER   0x01        /* from upper interface */
#define FROM_LOWER   0x02        /* from lower interface */

/* maximum size for unit data delivered to MTP-3 */
#define MAXNSAPSIZE       268    /* maximum size of data deleivered to NSap */
#define MAXUDATSIZE       256    /* max size for unit data */
#define MAXUDATSIZE_ANSI  251    /* max size for unit data (ANSI96 & BELL05) */
#define MAXUDATSIZE_JAPAN 255    /* max size for unit data (JAPAN) */

#define MAXISNILEN   18          /* max len of ISNI param (ANSI96 & BELL05) */
#define MAXINSLEN    7           /* max len of INS param (BELL05) */

/* DPC mask */
#define DPC14MSK 0x00003fff      /* 14 bit point codes */
#define DPC24MSK 0x00ffffff      /* 24 bit point codes */
#define DPC16MSK 0x0000ffff      /* 16 bit point codes for SCCP JAPAN */

/* sls Mask */   
#define SLSMASK_CCITT 0x0f       /* CCITT sls mask */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
#define SLSMASK_ANS88 0x1f       /* ANSI-88 sls mask */
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05) */

/* connection side */
#ifdef SPCO
/* These values have to be sequential. Lot of PSF code depends on it */
#define CG_SIDE 0                /* calling Side */
#define CD_SIDE 1                /* called Side */
#endif /* SPCO */

#ifdef SP_RUG
/* hash defs for return value of function setver */
#define SP_NOP   0xff     /* No further operation */
#define SP_ADD   0x01     /* add intf ver info control block to DLL in 
                             rsetCb and run time update to peer */
#define SP_UPD   0x02     /* update intf ver info to peer */
#endif /* SP_RUG */
/****************************************************
 * Hash lists related defines                       *
 ****************************************************/
/* Route hash list */
#define KEY_RTE              2

/* sp026.302 - comment added - to configure large number of routes, the number
 * of hash bins should be increased for efficient hash search. Further, The
 * hash bin size should be defined to a value which is in the power of 2 so
 * that hash function will be efficient.
 */
#define RTE_HL_SIZE        256   /* Route hash list size - tunable */

/* sp026.302 - modification - change the GTT hash list bin size to 256.
 * The reason for defining the hash list size as 256 is that under a
 * practical scenario the default hash function which we use, will always
 * compute the key to be less than 500. This is because the def hash fn adds
 * up the octets in the key. Assuming that GTT is done on first 10 digits of
 * GT then the number of octets will be 8 (start digit, end digit, length of
 * shrtAddr and 5 bytes of shrtAddrs). The sum of all these octets (in most of
 * the cases) will be less than 500. That is, if we have 256 bins then at the
 * most 2 entries per bin, which is very efficient.
 *
 * Above assumption for GTT to use first 10 digits of GT is applicable in most
 * of the cases. So, in most of the cases the bin size is not required to be
 * changed and _not-tunable_, however if GTT is done on larger range of digits
 * (more than 10 digits of GT) then bin size can be increased. In any case, the
 * bin size should be defined a value which is in the power of 2 so that hash
 * func will be efficient.
 */
#define GTT_HL_SIZE 256          /* Hash List size for GTT - not tunable */

#ifdef SPCO
#define NUM_CON_KEYS         3   /* number of connection keys */
#define CON_HL_SIZE        256   /* con hash list size - tunable */
#define CG_KEY            0x01   /* calling key */
#define CD_KEY            0x02   /* called key */
#define SU_KEY            0x04   /* service user key */
#define KEY_CON              3
#endif /* SPCO */
  
/****************************************************
 * Status of SCCP
 ****************************************************/
#define SP_GUARD     0x04      /* guard after reset */

/* sp027.302 - modification - move defines for SAP status to lsp.h file.
 * SAP status values will be reported to LM in LspStaCfm in bitMask format.
 */


/****************************************************
 * Return codes - spResolveAddr, spCheckRoute, etc  *
 ****************************************************/
#define SP_OK        0x00        /* OK */
#define SP_LOCAL     0x01        /* address is local */
#define SP_REMOTE    0x02        /* address is remote */
#define SP_SSFAIL    0x03        /* subsystem is prohibited */
#define SP_SPFAIL    0x04        /* signalling point is prohibited */
#define SP_INVALID   0x05        /* data invalid */

#ifdef SP_ERROR
#undef SP_ERROR
#endif
#define SP_ERROR     0xff        /* plain old error */

#define SP_DISCARD   0x0f        /* discard msg as part of traffic limitation */

#if (SS7_ANS96 || SS7_BELL05)
#define SP_CDPY      0x11        /* routing based on called party address */
#define SP_ISNI      0x10        /* routing based on ISNI */
#define SP_ISNI_ERR  0x1f        /* error in ISNI based routing */
#endif /* SS7_ANS96 || SS7_BELL05 */
  
#ifdef SS7_BELL05
#define SP_INS       0x20        /* routing based on INS */
#define SP_INS_ERR   0x2f        /* error in INS based routing */
#endif /* SS7_BELL05 */

#define SP_UNEQUIP   0x3f        /* SSN unequipped */

#define INTLBCDPCLENGTH  3       /* length of point code (in octets) when 
                                    represented in BCD format in international
                                    network */

/****************************************************
 * Message formats                                  *
 ****************************************************/
/* Managment message types */
#define SCMG_SSA  0x01           /* Subsystem Allowed */
#define SCMG_SSP  0x02           /* Subsystem Prohibited */
#define SCMG_SST  0x03           /* Subsystem Status Test */
#define SCMG_SOR  0x04           /* Subsystem Out of Service Request */
#define SCMG_SOG  0x05           /* Subsystem Out of Service Grant */
#define SCMG_SSC  0x06           /* Subsystem Congested */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
#define SCMG_SBR  0xfd           /* Subsystem Backup Routing */
/* sp008.301 - Changed value of SNR from 0xed to 0xfe */
#define SCMG_SNR  0xfe           /* Subsystem Normal Routing */
#define SCMG_SRT  0xff           /* Subsystem Routing Test Routing */
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */

/****************************************************
 * Timers                                           *
 ****************************************************/
/* Global timers */
#define MAXSPTMR   1             /* maximum global timer */
#define TMR_GRD    0x02          /* guard timer */

/* NSAP timers */
#define MAXNSAPTMR 2             /* maximum network sap timer... */
#define TMR_RSTEND 0x03          /* MTP3 reset end timer */

#define TMR_INT    0x04          /* interval(bind request) timer */

/* Upper SAP timers */
#define MAXSAPTMR  1             /* maximum simultaneous upper sap timers */

#define TMR_IGN  0x01            /* Sap Timer Ignore Flag */
#define TMR_GRT  0x02            /* Sap Timer Grant Flag */

#define SP_MAX_INTRETRY     2    /* maximum primitive retries */


/* Route timers */
/* 
 * NOTE : If you are adding a subsystem or a route timer ..
 * please keep distinct values for the sake of PSF 
 */
#define MAXRTETMR  4             /* maximum timers on a route */
#define TMR_ATTACK 0x08          /* attack timer */
#define TMR_DECAY  0x10          /* decay timer */
#define TMR_CON    0x20          /* remote sccp congestion timer */

/* sp040.302 - modification - keep unique val for sta timer */
#define TMR_STA    0x40          /* status enquiry timer */

/* Subsystem timers */
#define MAXSSNTMR 2              /* maximum simultaneous ssn timers */
#define TMR_SST  0x01            /* Subsystem Timer is Status Flag */
#define TMR_CONTSST 0x04         /* Continue SST after it expires Flag */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
#define TMR_SRT  0x02            /* Subsystem Timer is Route Flag */
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */

/* Connection control block timer */
#ifdef SPCO
#define MAXCONTMR 6             /* maximum simultaneous connection timers */
#define CON_TMR     0x01        /* Connectiong timer */
#define CG_IAS_TMR  0x02        /* Calling send timer */
#define CG_IAR_TMR  0x03        /* Calling receive timer */
#define CD_IAS_TMR  0x04        /* Called send timer */
#define CD_IAR_TMR  0x05        /* Called receive timer */
#define CG_REL_TMR  0x06        /* Calling Release timer */
#define CD_REL_TMR  0x07        /* Called Release timer */
#define CG_INT_TMR  0x08        /* Calling Interval timer */
#define CD_INT_TMR  0x09        /* Called Interval timer */
#define CG_REPREL_TMR 0x0a      /* Calling Repeat Release timer */
#define CD_REPREL_TMR 0x0b      /* Called Repeat Release timer */
#define GUA_TMR     0x0c        /* Guard timer */
#define CD_RST_TMR  0x0d        /* Called Reset Timer */
#define CG_RST_TMR  0x0e        /* Called Reset Timer */
#define LAST_TMR    CG_RST_TMR  /* Last Connection timer */
#endif /* SPCO */


/****************************************************
 * Misc Macros                                      *
 ****************************************************/
/* sp004.302 - modification - macro modified such that mf func to encode 
 * message header is no more called
 */
#define SPENCPDUHDR(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   Swtch v1;             /* variant */ \
   /* for SCCP message encoding, only two variants itu and ansi are \
    * passed to mf. So for china and japan also pass the variant \
    * switch as itu only \
    */ \
   ret = MFROK; \
   switch (a6) \
   { \
      case LSP_SW_CHINA: \
      case LSP_SW_JAPAN: \
      case LSP_SW_ITU: \
         v1 = LSP_SW_ITU; \
         break; \
      case LSP_SW_ANS: \
         v1 = LSP_SW_ANS; \
         break; \
      default: \
         /* sp044.302 - addition - Initialized v1 to default ITU */ \
         v1 = LSP_SW_ITU; \
         ret = MFRFAILED; \
         break; \
   } /* switch (a6) */ \
   if (ret == MFROK) \
   { \
      SpPduHdr *pHdr; \
      pHdr = (SpPduHdr *) a2; \
      (ctlp)->mp = a1; \
      if (SAddPstMsg((U8) (pHdr->msgType.val), a1) == ROK) \
      { \
         (ctlp)->validate = a4; \
         (ctlp)->encode = a5; \
         (ctlp)->swtch = v1; \
         (ctlp)->flags = a7; \
         (ctlp)->baseIdx = 0; \
         (ctlp)->errCnt = 0; \
         if (spChkMsgType((ctlp), (PTR) (&(pHdr->msgType.val))) == MFROK) \
         { \
            (ctlp)->melp1 = (ctlp)->smelp1; \
            (ctlp)->octIdx = 1; \
            (ctlp)->bitIdx = 8; \
            (ctlp)->elen = 1; \
         } \
         else \
            ret = MFRFAILED; \
      } \
      else \
         ret = MFRFAILED; \
   } \
}

#define SPENCPDU(ctlp, ret, a1)   MFENCPDU(ctlp, ret, a1)

/* sp004.302 - modification - macro modified such that mf func to decode 
 * message header is no more called
 */
#define SPDECPDUHDR(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   Swtch v1;             /* variant */ \
   /* for SCCP message decoding only two variants itu and ansi are \
    * passed to mf. So for china and japan also pass the variant \
    * switch as itu only \
    */ \
   ret = MFROK; \
   switch (a6) \
   { \
      case LSP_SW_CHINA: \
      case LSP_SW_JAPAN: \
      case LSP_SW_ITU: \
         v1 = LSP_SW_ITU; \
         break; \
      case LSP_SW_ANS: \
         v1 = LSP_SW_ANS; \
         break; \
      default: \
         /* sp044.302 - addition - Initialized v1 to default ITU */ \
         v1 = LSP_SW_ITU; \
         ret = MFRFAILED; \
         break; \
   } /* switch (a6) */ \
   if (ret == MFROK) \
   { \
      SpPduHdr *pHdr; \
      pHdr = (SpPduHdr *) a2; \
      (ctlp)->mp = a1; \
      if (SExamMsg((U8 *) (&(pHdr->msgType.val)), a1, 0) == ROK) \
      { \
         (ctlp)->validate = a4; \
         (ctlp)->decode = a5; \
         (ctlp)->swtch = v1; \
         (ctlp)->flags = a7; \
         (ctlp)->baseIdx = 0; \
         (ctlp)->errCnt = 0; \
         if (spChkMsgType((ctlp), (PTR) (&(pHdr->msgType.val))) == MFROK) \
         { \
            (ctlp)->melp1 = (ctlp)->smelp1; \
            (ctlp)->octIdx = 1; \
            (ctlp)->bitIdx = 8; \
            (ctlp)->elen = 0; \
         } \
         else \
            ret = MFRFAILED; \
      } \
      else \
         ret = MFRFAILED; \
   } \
}

/* decode pdu */
#define SPDECPDU(ctlp, ret, a1)  MFDECPDU(ctlp, ret, a1)

/* macros to get correct side timer */
#ifdef SPCO
#define IAS_TMR(side) ((U8) (side ? CD_IAS_TMR : CG_IAS_TMR))
#define IAR_TMR(side) ((U8) (side ? CD_IAR_TMR : CG_IAR_TMR))
#define RST_TMR(side) ((U8) (side ? CD_RST_TMR : CG_RST_TMR))
#define REL_TMR(side) ((U8) (side ? CD_REL_TMR : CG_REL_TMR))
#define INT_TMR(side) ((U8) (side ? CD_INT_TMR : CG_INT_TMR))
#define REPREL_TMR(side) ((U8) (side ? CD_REPREL_TMR : CG_REPREL_TMR))

/* macros to determine connection side */
#define SIDE(cb) (cb->side)
#define OPSIDE(cb) ((U8) (cb->side ? CG_SIDE : CD_SIDE))

/* return correct freeze flag */
#define FRZ_SIDE(side) ((U8) (side ? SP_FRZ_CD : SP_FRZ_CG))

/* return correct reset state */
#define RST_ST(side) (side ? RCD_ST : RCG_ST)
#define DEC_RST_ST(cb) \
(cb->state == RBT_ST ? (SIDE(cb) ? RCG_ST : RCD_ST) : DTX_ST)
#define INC_RST_ST(cb) \
(cb->state == DTX_ST ? (SIDE(cb) ? RCD_ST : RCG_ST) : RBT_ST)
#endif  /* SPCO */

#ifdef DEBUGP
/* debug macro */
#define SPDBGP(_msgClass, _arg) \
          DBGP(&spCb.spInit, SPLAYERNAME, _msgClass, _arg) 
#else
#define SPDBGP(_msgClass, _arg)
#endif /* DEBUGP */

/* trace macro */
#define SP_GEN_TRC(suId, trcEvnt, mBuf) \
        if(spCb.nSapList[(suId)]->trc != FALSE)\
           spGenTrc(suId, trcEvnt, mBuf);



/****************************************************
 * SpFreezeSlr args                                 *
 ****************************************************/
#define SP_FRZ_CG 0x01
#define SP_FRZ_CD 0x02
#define SP_FRZ_BT (SP_FRZ_CG | SP_FRZ_CD)

/****************************************************
 * Connection states                                *
 ****************************************************/
#define RDY_ST 0x00       /* Ready State */
#define CON_ST 0x01       /* Connecting State */
#define DTX_ST 0x02       /* Data Transfer State */
#define RCG_ST 0x03       /* Reset Calling State */
#define RCD_ST 0x04       /* Reset Called State */
#define RBT_ST 0x05       /* Reset Both State */
#define RLS_ST 0x06       /* Releasing */

/****************************************************
 *  spUiConMt[][] related defines                   *
 ****************************************************/
#ifdef SPCO
/* primitives indexes in the mapping table */
#define SP_CONREQ0   0x00
#define SP_CONREQ1   0x01
#define SP_CONREQ2   0x02
#define SP_CONRSP    0x03
#define SP_DATREQ    0x04
#define SP_EDATREQ   0x05
#define SP_DACKREQ   0x06
#define SP_DISREQ    0x07
#define SP_RSTREQ    0x08
#define SP_RSTRSP    0x09
/* misc */
#define SP_NMB_ST 7       /* Number of States */
#define SP_NMB_MSG 16     /* Number of Messages */
#define SP_NMB_DIR 2      /* Number of Directions */
#define SP_NMB_PRIM 10    /* Number of Primitives (spUiConMt) */
/* cb->cType values */
#define SP_ORIG   0x01     /* originating node  */
#define SP_DEST   0x02     /* destination node  */
#define SP_INTR   0x04     /* intermediate node */
#define SP_REQ0   0x10     /* request type 0 connection */
#define SP_REQ1   0x20     /* request type 1 connection */
#define SP_REQ2   0x40     /* request type 2 connection */
#define SP_DEAD   0x80     /* Control Block Is Dead */
/* 
 * calling side of connection received a disconnect request from
 * user prior to the connection confirm message being received
 */
#define CG_RCVD_DIS   0x01        /* Calling side received disconnect */
/* SpSide.flags */
#define RST_INT       0x01        /* Reset action internally initiated */
#define RST_EXT       0x02        /* Reset action externally initiated */
#define EDA_PEN       0x04        /* expedited data acknowledgement pending */
#ifndef MODULO_128
#define MODULO_128 128
#endif
#endif /* SPCO */

/****************************************************
 *  Lengths                                         *
 ****************************************************/
#define CCITT_DPCLEN 2   /* DPC length in octet of CCITT DPC */ 
#define ANSI_DPCLEN 3    /* DPC length in octet of ANSI DPC */ 
#define CCITT_FM1HDLEN 1 /* header length of CCITT address format 1 */
#define CCITT_FM2HDLEN 1 /* header length of CCITT address format 2 */
#define CCITT_FM3HDLEN 2 /* header length of CCITT address format 3 */
#define CCITT_FM4HDLEN 3 /* header length of CCITT address format 4 */
#define ANSI_FM1HDLEN 2  /* header length of CCITT address format 1 */
#define ANSI_FM2HDLEN 1  /* header length of CCITT address format 2 */
#define MAXNSAPMSGSIZE 272 /* payload size to mtp3 (incl. mtp3 routing lbl */
#define UDHDRLEN  15       /* UDT header length for itu, japan and china */
#define XUDHDRLEN 23       /* XUDT header length for itu, japan and china */
#define LUDHDRLEN 29       /* XUDT header length for itu */
#define UDHDRLEN_ANSI  15       /* UDT header length for ansi */
#define XUDHDRLEN_ANSI 27       /* XUDT header length for ansi */
#define UDHDRLEN_BELL05  15     /* UDT header length for bell 05 */
#define XUDHDRLEN_BELL05 35     /* XUDT header length for bell 05 */
#define LUDHDRLEN_BELL05 37     /* XUDT header length for bell05 */
#define SSNLEN    1      /* length of subsystem number in octet */
#define ADDRINDLEN 1     /* length of address indicator in octet */
/* sp003.302 - Corrected maximum unit data reference no */
#define SP_MAXXUDREF 0xffffff  /* maximum unit data reference no */

/* 
 * Macro to check the incoming and outgoing present and value fields.
 * The macro contains two flags dupFlag and diffFlag. 
 * dFlag is made true when the present fields are TRUE and the values 
 * are different.
 * oFlag is made TRUE when only one of the present flag is FALSE. which 
 * means that the values overlap.
 * See this macro with assoForrule functions and you will understand.
 * This macro is used in Rule comparison. -- Chirayu
 */

#define FIELDS_CMP(iPres, i, oPres, o, oFlag, dFlag) \
           { \
              if ((iPres != oPres)) \
                 oFlag = TRUE; \
              else \
                 { \
                    if ((iPres == TRUE) && (oPres == TRUE) && (i != o))\
                       dFlag = TRUE; \
                 } \
           } 



#endif /* __SPH__ */


/********************************************************************30**
  
         End of file:     sp.h@@/main/11 - Tue Jan 22 15:12:31 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  fmg   1. added support for CCITT 1988 
                           connection-oriented control

1.4          ---  fmg   1. Up'd MAXSPUI, MAXSPLI by 1, and added MAXSPMI

1.5          ---  scc   1. added M_XUNITDATA and M_XUNITDATASRV for 
                           ANSI 92 and CCITT 92 standards
             ---  scc   2. added MAXUDATSIZE

1.6          ---  mjp   1. replaced NAT_SPID and INAT_SPID with SCCP_SI
                        2. changed SP_FLCOFF to SP_FLCON
                        3. removed status defines used in SpLiSntStaInd
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.7          ---      ash  1. Changes for fault tolerant SCCP
             sp006.27 ash  2. Changed SP_DEAD to 0x80 from 0xff and also
                              SP_PERM removed
             ---      cp   3. Now passing the correct Init structure 
                              pointer to DBGP macro in SPDBGP.
                           4. Defines added for Release, Interval and 
                              Repeat Relase timers on the CDS and CGS.
                           5. Macros added to get the correct side timer.
                      ash  6. Moved SP_GEN_TRC from lsp.h file

1.8          sp004.28 cp   1. Changes made for the new GTT framework.
             ---      vb   2. Clean Up of the patches
                      cp   3. Added SP_SNRST state for NSAP and TMR_RSTEND
                              for NSap.
                      cp   4. Removed the GETSLS macro.
                      cp   5. Misc reorganization for clarity.
                      cp   6. Changed SP_FRZ_BT define to make the meaning 
                              clear.

/main/8      ---      vb   1. Updated for ver 2.9
                      cp   2. Clean up 

/main/10     ---       cp   1. DFTHA mods
             sp005.301 sg  2. Add a define for the maximum ammount of bpc
                              we will check for when doing routing.
             sp008.301 sg  4. Changed value of SNR to correspond with SPEC.

             sp014.301 rc  5. Rolling upgrade changes, under compile flag
                              SP_RUG as per tcr0020.txt:
                           -  Hash define for SP_NOP, SP_ADD and SP_UPD.
                           -  DEPENDENCY CHECK for rolling upgrade feature is
                              added. This check list to be moved to envopt
                              file in next release.
             sp018.301 zq  1. Increased the maximum upper interface entries to
                              six because of adding BSSAP+ as one of SCCP
                              users.
/main/11     ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp003.302  qz   1. Corrected maximum unit data reference no.
             sp004.302 rc 1. Macros for encoding/decoding message header are
                             modified such that mf functions to encode/decode
                             message header shall not be called.
             sp026.302 rc 1. Modifying the bin size of GTT hash list to 256
                             for optimum hash search.
             sp027.302 rc 1. Defines for SAP status moved from sp.h file to 
                             lsp.h file to report sap status in bitMask format
                             in LspStaCfm primitive to LM. 
             sp038.302 mc   1. SS_MULTIPLE_PROCS flag added.
             sp040.302 rc   1. TMR_STA redefined for unique value as bitmask.
             sp044.302 sm   1. Initialized the local variables to default.
             sp047.302 sm   1. Modified MAXSPUI to 7 to handle SCCP User for 
                               SPU.
*********************************************************************91*/
