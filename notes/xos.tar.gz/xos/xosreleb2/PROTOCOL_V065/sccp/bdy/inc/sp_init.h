
#ifndef __SP_INITH__
#define __SP_INITH__
#define TSTINST_0     0          /* instance 0 */
extern  PUBLIC S16 sp_init_fun(SSTskId    tskId);

#ifdef SP_CFG_TEST
extern PUBLIC S16 sm_init_fun(SSTskId tskId);
#endif

#endif /*__SP_INITH__*/