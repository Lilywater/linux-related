#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "cm_llist.x"
#include "cm_llist.h"
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#include "sht.h"           /* SHT */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"

#endif /* ZP */
#include "sp_err.h"        /* sccp - error */


/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#include "sht.x"           /* SHT */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

#include "sp_init.h"

#ifdef SSI_WITH_CLI_ENABLED
#include "xosshell.h"
#endif

#ifdef CP_OAM_SUPPORT
#include "oam_interface.h"
#include "sp_nms.h"
#include "sp_cfg.h"
#include "sm.h"
#include "sm.x"
#include "cp_tab_def.h"
#include "oam_tab_def.h"
#include "cp_oam_stru.x"
#include "sp_oam.x"
#endif


#ifdef SP_CFG_TEST
EXTERN S16 l3ActvInit ARGS((Ent ,Inst ,Region ,Reason));
EXTERN S16 l3ActvTsk ARGS(( Pst *, Buffer*));
EXTERN S16 l4ActvInit ARGS((Ent ,Inst ,Region ,Reason));
EXTERN S16 l4ActvTsk ARGS((Pst *, Buffer*));
EXTERN S16 l3ActvInit ARGS ((Ent entity, Inst inst, 
                             Region region, Reason reason));
EXTERN S16 l4ActvInit ARGS ((Ent entity, Inst inst, 
                             Region region, Reason reason));
#endif

#ifdef ANSI
PUBLIC S16 sp_init_fun
(
SSTskId    tskId
)
#else
PUBLIC S16 sp_init_fun(tskId)
SSTskId    tskId;
#endif
{   
   t_XOSMUTEXID *plock = NULL;

  
   if(tskId == 0)
   {
	   if(SCreateSTsk(PRIOR0, &tskId)!= ROK)
	   {
	      SPrint("INIT SCreateSTsk for SCCP failed.\n");
	      RETVALUE(RFAILED);   	
	   }
   }

   if(SRegTTsk(ENTSP, TSTINST_0, TTNORM, 0,(PAIFS16) spActvInit, spActvTsk)!= ROK)
   	{
      SPrint("INIT:SRegTTsk() for SCCP failed.\n");
      RETVALUE(RFAILED);   	
   	}
   if(SAttachTTsk(ENTSP, TSTINST_0, tskId)!= ROK)
   	{
      SPrint("INIT:SAttachTTsk() for SCCP failed.\n");
      RETVALUE(RFAILED);   	
   	}

#ifdef CP_OAM_SUPPORT
   spInitCfgData();

   if( ROK != smRegCb((Ent)ENTSP, gSpSmQ, sizeof(gSpSmQ)/sizeof(CmLListCp), smSpSendReqQ, spResetCfgData))
   {
      RETVALUE(RFAILED);
   }

	if( OAM_CALL_SUCC != register_msg_proc(CP_MODULE_ID_SS7_SCCP,  APP_SYNC_MSG,  spInitCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_RULE, SA_INSERT_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_ADDR, SA_INSERT_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE, SA_INSERT_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE_SSN, SA_INSERT_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_RULE, SA_UPDATE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_ADDR, SA_UPDATE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE, SA_UPDATE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE_SSN, SA_UPDATE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	


	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_RULE, SA_DELETE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_GT_ADDR, SA_DELETE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE, SA_DELETE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

	if( OAM_CALL_SUCC != register_tb_proc(CP_MODULE_ID_SS7_SCCP, APP_TABLE_ID_SS7_SCCP_ROUTE_SSN, SA_DELETE_MSG,  spDynCfgCallback, plock))
   {
     RETVALUE(RFAILED);
   } 	

   (unsigned char)get_resource(xwCpSS7NwkTable, sizeof(CP_OAM_SS7_NETWORK_TAB), xwCpSS7NwkTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7UpTable, sizeof(CP_OAM_SS7_UP_TAB), xwCpSS7UpTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7SpcTable, sizeof(CP_OAM_SS7_SPC_TAB), xwCpSS7SpcTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSS7SsnTable, sizeof(CP_OAM_SS7_SSN_TAB), xwCpSS7SsnTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpGenCfg, sizeof(SpCfgGenTab), xwCpSccpGenCfg_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpNwCfgTable, sizeof(SpCfgNwAttrTab), xwCpSccpNwCfgTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpGtRuleTable, sizeof(SpCfgGtRuleTab), xwCpSccpGtRuleTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpGtAddrTable, sizeof(SpCfgGtAddressTab), xwCpSccpGtAddrTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpRteTable, sizeof(SpCfgRouteTab), xwCpSccpRteTable_ROW_NUM);
   (unsigned char)get_resource(xwCpSccpRteSsnTable, sizeof(SpCfgRouteSsnTab), xwCpSccpRteSsnTable_ROW_NUM);

   if( OAM_CALL_SUCC != app_register(CP_MODULE_ID_SS7_SCCP, spCfgTbl, sizeof(spCfgTbl)/sizeof(spCfgTbl[0])))
   {
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE(ROK);
}


#ifdef SP_CFG_TEST

#ifdef ANSI
PUBLIC S16 sm_init_fun
(
SSTskId tskId
)
#else
PUBLIC S16 sm_init_fun(tskId)
SSTskId tskId;
#endif
{
	
	if (ROK != SRegTTsk(ENTSM, 0, TTNORM, PRIOR0, smActvInit, smActvTsk))
	{
		RETVALUE(RFAILED);
	}

	if(tskId == 0)
	{
	    if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	    {
	         RETVALUE(RFAILED);
	    }
	}

	if (ROK != SAttachTTsk(ENTSM, 0, tskId))
	{
		RETVALUE(RFAILED);
	}

	RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 it_init_fun
(
SSTskId tskId
)
#else 
PUBLIC S16 it_init_fun(tskId)
SSTskId tskId;
#endif
{
#ifdef SS_MULTIPLE_PROCS
    ProcId     procs[]={ PROC1 };
#endif
	
	
    TRC3(accRegTTsk)

   if(tskId == 0)
   {
	   /* Create Test Code System Task */
	   if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	   {
	        RETVALUE(RFAILED);
	   }
   }

   /* Register M3UA TAPA Task */
   if (SRegTTsk(ENTIT, TSTINST_0, TTNORM, PRIOR0, l3ActvInit, l3ActvTsk) != ROK)
   {
        RETVALUE(RFAILED);
   }

   /* Attach M3UA TAPA Task to its own thread (LC) or the test thread (TC) */
   if (SAttachTTsk(ENTIT, TSTINST_0, tskId) != ROK)
   {
        RETVALUE(RFAILED);
   }
   

    RETVALUE(ROK);
}


#ifdef ANSI
PUBLIC S16 st_init_fun
(
SSTskId    tskId
)
#else
PUBLIC S16 st_init_fun(tskId)
SSTskId    tskId;
#endif
{
#ifdef SS_MULTIPLE_PROCS
    ProcId     procs[]={ PROC1 };
#endif
	
	
    TRC3(accRegTTsk)

   if(tskId == 0)
   {
	   /* Create Test Code System Task */
	   if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	   {
	        RETVALUE(RFAILED);
	   }
   }

   if (SRegTTsk(ENTST, TSTINST_0, TTNORM, PRIOR0, l4ActvInit, l4ActvInit) != ROK)
   {
        RETVALUE(RFAILED);
   }

   /* Attach M3UA TAPA Task to its own thread (LC) or the test thread (TC) */
   if (SAttachTTsk(ENTST, TSTINST_0, tskId) != ROK)
   {
        RETVALUE(RFAILED);
   }
   

    RETVALUE(ROK);
}

#endif

