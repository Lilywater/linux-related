/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - portable upper interface
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Upper Interface
  
     File:     sp_ptui.c
  
     Sid:      sp_ptui.c@@/main/16 - Tue Jan 22 15:13:59 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */
  

/*
  
The following functions are provided in this file:
  
     SpUiSptUDatInd   upper interface - Unit Data Indication
     SpUiSptStaInd    upper interface - Call Status Indication
     SpUiSptCordInd   upper interface - Coordinated Response
     SpUiSptCordCfm   upper interface - Coordinated Confirmation
     SpUiSptSteInd    upper interface - State Indication
     SpUiSptPCSteInd  upper interface - PC State Indication
     SpUiSptConInd    upper interface - Connect Indication 
     SpUiSptConCfm    upper interface - Connect Confirm
     SpUiSptDatInd    upper interface - Data Indication
     SpUiSptEDatInd   upper interface - Expedited Data Indication
     SpUiSptDatAckInd upper interface - Data Acknowledge
     SpUiSptRstInd    upper interface - Reset Indication
     SpUiSptRstCfm    upper interface - Reset Confirm
     SpUiSptDisInd    upper interface - Disconnect Indication
     SpUiSptInfInd    upper interface - Information Indication
     Following functions are available only under SPT2 and higher versions
     SpUiSptBndCfm    upper interface - Bind confirmation
     SpUiSptStaCfm    upper interface - status confirmation 
     SpUiSptSteCfm    upper interface - state confirmation 
  
     Following functions are added for audit of signalling connection

     SpUiSptAudInd    upper interface - Audit indication
     SpUiSptAudCfm    upper interface - Audit confirmation

It should be noted that not all of these functions may be required
by a particular network layer service user.
  
It is assumed that the following functions are provided in ....:
  
*/


/* local defines */
#define ST_SEL 1
#define SI_SEL 2
#define RA_SEL 3
#define RN_SEL 4
#define GA_SEL 5
/* sp047.302 - Addition - generic SCCP user selector */
#define SPU_SEL 6
  
/* local typedefs */
  
/* local externs */
  
/* forward references */

PRIVATE S16 PtUiSptUDatInd ARGS((Pst *pst, SuId suId, Dpc opc,
                                 SpUDatEvnt* ud, Buffer *mBuf));
PRIVATE S16 PtUiSptStaInd ARGS((Pst *pst, SuId suId, Dpc opc,
                                SpUDatEvnt *ud, RCause rc, Buffer* mBuf));
PRIVATE S16 PtUiSptCordInd ARGS((Pst *pst, SuId suId, Ssn aSsn, Smi smi));
PRIVATE S16 PtUiSptCordCfm ARGS((Pst *pst, SuId suId, Ssn aSsn, Smi smi));
PRIVATE S16 PtUiSptSteInd ARGS((Pst *pst, SuId suId, Dpc aDpc, Ssn aSsn,
                                UStat uStat, Smi smi));
#ifdef SPTV2
PRIVATE S16 PtUiSptPCSteInd ARGS((Pst *pst, SuId suId, Dpc aDpc, Sps sps,
                                  U8 sccpState, U8 ril));
#else
PRIVATE S16 PtUiSptPCSteInd ARGS((Pst *pst, SuId suId, Dpc aDpc, Sps sps));
#endif /* SPTV2 */

#ifdef SPT2
PRIVATE S16 PtUiSptSteCfm ARGS((Pst *pst, SuId suId, U8 status));
PRIVATE S16 PtUiSptBndCfm ARGS((Pst *pst, SuId suId, U8 status));
#ifdef SPTV2
PRIVATE S16 PtUiSptStaCfm ARGS((Pst *pst, SuId suId, U8 status, Dpc dpc, 
                                Ssn ssn, UStat ustat, Smi smi, U8 sccpState,
                                U8 ril));
#else
PRIVATE S16 PtUiSptStaCfm ARGS((Pst *pst, SuId suId, U8 status, Dpc dpc, 
                                Ssn ssn, UStat ustat, Smi smi));
#endif /* SPTV2 */
#endif /* SPT2 */

#ifdef SPCO
PRIVATE S16 PtUiSptConInd ARGS((Pst *pst, SpConEvnt *conEvnt, Buffer *mBuf));
PRIVATE S16 PtUiSptConCfm ARGS((Pst *pst, SpConEvnt *conEvnt, Buffer *mBuf));
PRIVATE S16 PtUiSptDatInd ARGS((Pst *pst, SpDatEvnt *datEvnt, Buffer *mBuf));
PRIVATE S16 PtUiSptEDatInd ARGS((Pst *pst, SpConId *conId, Buffer *mBuf));
PRIVATE S16 PtUiSptDatAckInd ARGS((Pst *pst, SpConId *conId));
PRIVATE S16 PtUiSptRstInd ARGS((Pst *pst, SpRstEvnt *rstEvnt));
PRIVATE S16 PtUiSptRstCfm ARGS((Pst *pst, SpRstEvnt *rstEvnt));
PRIVATE S16 PtUiSptDisInd ARGS((Pst *pst, SpDisEvnt *disEvnt, Buffer *mBuf));
PRIVATE S16 PtUiSptInfInd ARGS((Pst *pst, SpInfEvnt *infEvnt));
#ifdef SPTV2
PRIVATE S16 PtUiSptAudInd ARGS((Pst *pst, SpAudEvnt *audEvnt));
PRIVATE S16 PtUiSptAudCfm ARGS((Pst *pst, SpAudEvnt *audEvnt));
#endif /* SPTV2 */
#endif /* SPCO */

/* functions in other modules */

/* public variable declarations */


/*
  
  the following matrices define the mapping between the primitives
  called by the upper interface of SCCP and the corresponding
  primitives of the SCCP service user(s).
  
  The parameter MAXSPUI defines the maximum number of service users on
  top of SCCP. There is an array of functions per primitive
  invoked by SCCP. Every array is MAXSPUI long (i.e. there
  are as many functions as the number of service users).
  
  The dispatching is performed by the configurable variable: selector.
  The selector is configured on a per SAP basis.
  
  The selectors are:
  
  0 - loosely coupled (#define LCSPUISPT)
  2 - TCAP (#define ST)
  3 - ISUP (#define SI)
  
  */


/* Data Indication primitive */

PUBLIC SptUDatInd SpUiSptUDatIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptUDatInd,         /* 0 - loosely coupled */
#else
   PtUiSptUDatInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptUDatInd,         /* 1 - tightly coupled, TCAP */
#else
   PtUiSptUDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptUDatInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptUDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptUDatInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptUDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptUDatInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptUDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptUDatInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptUDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptUDatInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptUDatInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Status Indication primitive */

PUBLIC SptStaInd SpUiSptStaIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptStaInd,          /* 0 - loosely coupled, */
#else
   PtUiSptStaInd,          /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptStaInd,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptStaInd,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptStaInd,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptStaInd,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptStaInd,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptStaInd,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptStaInd,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptStaInd,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptStaInd,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptStaInd,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptStaInd,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptStaInd,          /* 6 - tightly coupled, portable */
#endif
};


/* Coordinated Indication primitive */
PUBLIC SptCordInd SpUiSptCordIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptCordInd,          /* 0 - loosely coupled, */
#else
   PtUiSptCordInd,          /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptCordInd,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptCordInd,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptCordInd,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptCordInd,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptCordInd,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptCordInd,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptCordInd,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptCordInd,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptCordInd,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptCordInd,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptCordInd,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptCordInd,          /* 6 - tightly coupled, portable */
#endif
};


/* Coordinated Confirmation primitive */
PUBLIC SptCordCfm SpUiSptCordCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptCordCfm,          /* 0 - loosely coupled, */
#else
   PtUiSptCordCfm,          /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptCordCfm,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptCordCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptCordCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptCordCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptCordCfm,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptCordCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptCordCfm,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptCordCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptCordCfm,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptCordCfm,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptCordCfm,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptCordCfm,          /* 6 - tightly coupled, portable */
#endif
};


/* State Indication primitive */
PUBLIC SptSteInd SpUiSptSteIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptSteInd,          /* 0 - loosely coupled, */
#else
   PtUiSptSteInd,          /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptSteInd,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptSteInd,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptSteInd,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptSteInd,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptSteInd,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptSteInd,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptSteInd,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptSteInd,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptSteInd,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptSteInd,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptSteInd,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptSteInd,          /* 6 - tightly coupled, portable */
#endif
};


/* PC State Indication primitive */
PUBLIC SptPCSteInd SpUiSptPCSteIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptPCSteInd,          /* 0 - loosely coupled, */
#else
   PtUiSptPCSteInd,          /* 0 - loosely coupled, portable  */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptPCSteInd,          /* 1 - tightly coupled, SCCP */
#else
   PtUiSptPCSteInd,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptPCSteInd,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptPCSteInd,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptPCSteInd,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptPCSteInd,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptPCSteInd,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptPCSteInd,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptPCSteInd,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptPCSteInd,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptPCSteInd,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptPCSteInd,          /* 6 - tightly coupled, portable */
#endif
};



#ifdef SPT2
/* Status confirmation primitive */
PUBLIC SptStaCfm SpUiSptStaCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptStaCfm,          /* 0 - loosely coupled, */
#else
   PtUiSptStaCfm,          /* 0 - loosely coupled, portable  */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptStaCfm,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptStaCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptStaCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptStaCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptStaCfm,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptStaCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptStaCfm,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptStaCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptStaCfm,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptStaCfm,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptStaCfm,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptStaCfm,          /* 6 - tightly coupled, portable */
#endif
};


/* State confirmation primitive */
PUBLIC SptSteCfm SpUiSptSteCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptSteCfm,          /* 0 - loosely coupled, */
#else
   PtUiSptSteCfm,          /* 0 - loosely coupled, portable  */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptSteCfm,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptSteCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptSteCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptSteCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptSteCfm,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptSteCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptSteCfm,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptSteCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptSteCfm,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptSteCfm,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptSteCfm,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptSteCfm,          /* 6 - tightly coupled, portable */
#endif
};


/* State confirmation primitive */
PUBLIC SptBndCfm SpUiSptBndCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptBndCfm,          /* 0 - loosely coupled, */
#else
   PtUiSptBndCfm,          /* 0 - loosely coupled, portable  */
#endif
#if (defined(ST) || defined(L4ST))
   StLiSptBndCfm,          /* 1 - tightly coupled, TCAP */
#else
   PtUiSptBndCfm,          /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptBndCfm,          /* 2 - tightly coupled, ISUP */
#else
   PtUiSptBndCfm,          /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptBndCfm,          /* 3 - tightly coupled, RANAP */
#else
   PtUiSptBndCfm,          /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptBndCfm,          /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptBndCfm,          /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptBndCfm,          /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptBndCfm,          /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptBndCfm,         /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptBndCfm,          /* 6 - tightly coupled, portable */
#endif
};
#endif /* SPT2 */

#ifdef SPCO

/* Connection Indication Primitive */
PUBLIC SptConInd SpUiSptConIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptConInd,         /* 0 - loosely coupled, */
#else
   PtUiSptConInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
 /*wanglijun*/   
#ifdef SP_TEST_TYPE
   StLiSptConInd,
#else
   PtUiSptConInd,         /* 1 - tightly coupled, TCAP */
#endif
 /*wanglijun*/      
#else
   PtUiSptConInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptConInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptConInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptConInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptConInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptConInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptConInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptConInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptConInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptConInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptConInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Connection Confirm Primitive */
PUBLIC SptConCfm SpUiSptConCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptConCfm,         /* 0 - loosely coupled, */
#else
   PtUiSptConCfm,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
/*wanglijun*/
#ifdef SP_TEST_TYPE
   StLiSptConCfm,
#else
   PtUiSptConCfm,         /* 1 - tightly coupled, TCAP */
#endif
/*wanglijun*/   
#else
   PtUiSptConCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptConCfm,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptConCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptConCfm,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptConCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptConCfm,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptConCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptConCfm,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptConCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptConCfm,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptConCfm,         /* 6 - tightly coupled, portable */
#endif
};


/* Data Indication Primitive */
PUBLIC SptDatInd SpUiSptDatIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptDatInd,         /* 0 - loosely coupled, */
#else
   PtUiSptDatInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
/*wanglijun*/
#ifdef SP_TEST_TYPE
   StLiSptDatInd,
#else
   PtUiSptDatInd,         /* 1 - tightly coupled, TCAP */
#endif
/*wanglijun*/   
#else
   PtUiSptDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptDatInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptDatInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptDatInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptDatInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptDatInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptDatInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Expedited Data Indication Primitive */
PUBLIC SptEDatInd SpUiSptEDatIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptEDatInd,         /* 0 - loosely coupled, */
#else
   PtUiSptEDatInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
   PtUiSptEDatInd,         /* 1 - tightly coupled, SCCP */
#else
   PtUiSptEDatInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptEDatInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptEDatInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptEDatInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptEDatInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptEDatInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptEDatInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptEDatInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptEDatInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptEDatInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptEDatInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Data Acknowledgement Indication Primitive */
PUBLIC SptDatAckInd SpUiSptDatAckIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptDatAckInd,         /* 0 - loosely coupled, */
#else
   PtUiSptDatAckInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
   PtUiSptDatAckInd,         /* 1 - tightly coupled, TCAP */
#else
   PtUiSptDatAckInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptDatAckInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptDatAckInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptDatAckInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptDatAckInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptDatAckInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptDatAckInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptDatAckInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptDatAckInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptDatAckInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptDatAckInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Reset Indication Primitive */
PUBLIC SptRstInd SpUiSptRstIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptRstInd,         /* 0 - loosely coupled, */
#else
   PtUiSptRstInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
   PtUiSptRstInd,         /* 1 - tightly coupled, TCAP */
#else
   PtUiSptRstInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptRstInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptRstInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptRstInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptRstInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptRstInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptRstInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptRstInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptRstInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptRstInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptRstInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Reset Confirmation Primitive */
PUBLIC SptRstCfm SpUiSptRstCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptRstCfm,         /* 0 - loosely coupled, */
#else
   PtUiSptRstCfm,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
   PtUiSptRstCfm,         /* 1 - tightly coupled, SCCP */
#else
   PtUiSptRstCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptRstCfm,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptRstCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptRstCfm,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptRstCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptRstCfm,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptRstCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptRstCfm,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptRstCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptRstCfm,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptRstCfm,         /* 6 - tightly coupled, portable */
#endif
};


/* Disconnect Indication Primitive */
PUBLIC SptDisInd SpUiSptDisIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptDisInd,         /* 0 - loosely coupled, */
#else
   PtUiSptDisInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
/*wanglijun*/    
#ifdef SP_TEST_TYPE
   StLiSptDisInd,
#else
   PtUiSptDisInd,         /* 1 - tightly coupled, TCAP */
#endif
/*wanglijun*/   
#else
   PtUiSptDisInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptDisInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptDisInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptDisInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptDisInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptDisInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptDisInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptDisInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptDisInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptDisInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptDisInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Disconnect Indication Primitive */
PUBLIC SptInfInd SpUiSptInfIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptInfInd,         /* 0 - loosely coupled, */
#else
   PtUiSptInfInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
   /* sp023.302 - modification - TCAP does not use connection-oriented SCCP.
    * Replace conection-oriented StLi function with PtUi function
    */
   PtUiSptInfInd,         /* 1 - tightly coupled, TCAP */
#else
   PtUiSptInfInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptInfInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptInfInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptInfInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptInfInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptInfInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptInfInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptInfInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptInfInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptInfInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptInfInd,         /* 6 - tightly coupled, portable */
#endif
};

#ifdef SPTV2

/* Audit Indication Primitive */
PUBLIC SptAudInd SpUiSptAudIndMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptAudInd,         /* 0 - loosely coupled, */
#else
   PtUiSptAudInd,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
/*wanglijun*/
#ifdef SP_TEST_TYPE
   StLiSptAudInd,
#else
   PtUiSptAudInd,         /* 1 - tightly coupled, TCAP (not appl for TCAP) */
#endif
/*wanglijun*/
#else
   PtUiSptAudInd,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptAudInd,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptAudInd,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptAudInd,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptAudInd,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptAudInd,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptAudInd,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptAudInd,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptAudInd,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptAudInd,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptAudInd,         /* 6 - tightly coupled, portable */
#endif
};


/* Audit Confirmation Primitive */
PUBLIC SptAudCfm SpUiSptAudCfmMt[MAXSPUI] =
{
#ifdef LCSPUISPT
   cmPkSptAudCfm,         /* 0 - loosely coupled, */
#else
   PtUiSptAudCfm,         /* 0 - loosely coupled, portable */
#endif
#if (defined(ST) || defined(L4ST))
/*wanglijun*/
#ifdef SP_TEST_TYPE
   StLiSptAudCfm,
#else
   PtUiSptAudCfm,         /* 1 - tightly coupled, TCAP (not appl for TCAP) */
#endif
/*wanglijun*/
#else
   PtUiSptAudCfm,         /* 1 - tightly coupled, portable */
#endif
#ifdef SCCP_SI_T     /*chendh modify*/
   SiLiSptAudCfm,         /* 2 - tightly coupled, ISUP */
#else
   PtUiSptAudCfm,         /* 2 - tightly coupled, portable */
#endif
#ifdef RA
   RaLiSptAudCfm,         /* 3 - tightly coupled, RANAP */
#else
   PtUiSptAudCfm,         /* 3 - tightly coupled, portable */
#endif
#ifdef RN
   RnLiSptAudCfm,         /* 4 - tightly coupled, RNSAP */
#else
   PtUiSptAudCfm,         /* 4 - tightly coupled, portable */
#endif
#ifdef GA
   GaLiSptAudCfm,         /* 5 - tightly coupled, BSSAP+ */
#else
   PtUiSptAudCfm,         /* 5 - tightly coupled, portable */
#endif
#ifdef SPU
   SpuLiSptAudCfm,        /* 6 - tightly coupled, SCCP User*/
#else
   PtUiSptAudCfm,         /* 6 - tightly coupled, portable */
#endif
};
#endif /* SPTV2 */
#endif /* SPCO */  




/*
*     upper interface functions
*/
  
  
/*
*
*       Fun:   Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  sp_ptui.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpUiSptUDatInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc opc,                        /* originating point code */
SpUDatEvnt* ud,                 /* unit data event */
Buffer *mBuf                    /* Pointer to the Buffer */
)
#else
PUBLIC S16 SpUiSptUDatInd(pst, suId, opc, ud, mBuf)
Pst *pst;                       /* post strucutre */
SuId suId;                      /* Service User Id */
Dpc opc;                        /* originating point code */
SpUDatEvnt* ud;                 /* unit data event */
Buffer *mBuf;                   /* Pointer to the Buffer */
#endif
{
   TRC3(SpUiSptUDatInd);

#ifdef CMSS7_SPHDROPT
   /* 
    * We have to do teh check for the SPT_DISABLE_PC
    * flag before handing over teh data to the user. 
    * We are also resetting the flag before passing it to 
    * teh user as teh usage of the flag is uni-driectional.
    */
   if (ud->cdAddr.spHdrOpt == CMSS7_NO_SP_PC)
      ud->cdAddr.pcInd = FALSE;
   if (ud->cgAddr.spHdrOpt == CMSS7_NO_SP_PC)
      ud->cgAddr.pcInd = FALSE;
#endif /* CMSS7_SPHDROPT */

#ifdef SPTV2
   /* importance is not relevant in data indication to user
    * mark it as not present
    */
   ud->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* sp001.302 - addition - sequence control is not relevant in data
    * indication to upper user, initialize it to zero
    */
   ud->sc = 0;

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptUDatIndMt[pst->selector])(pst, suId, opc, ud, mBuf);
         else
            DtLiSptUDatInd(pst, suId, opc, ud, mBuf);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptUDatIndMt[pst->selector])(pst, suId, opc, ud, mBuf);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptUDatInd */
  
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to Indicate Error status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptStaInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User ID */
Dpc opc,                        /* originating point code  */
SpUDatEvnt *ud,                 /* unit data event */
RCause ret,                     /* return cause */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 SpUiSptStaInd(pst, suId, opc, ud, ret, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User ID */
Dpc opc;                        /* originating point code */
SpUDatEvnt *ud;                 /* unit data event */
RCause ret;                     /* Status */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(SpUiSptStaInd);

#ifdef CMSS7_SPHDROPT
   /* We have to take care of the cd/cgAddr */
   if (ud->cdAddr.spHdrOpt == CMSS7_NO_SP_PC)
      ud->cdAddr.pcInd = FALSE;
   if (ud->cgAddr.spHdrOpt == CMSS7_NO_SP_PC)
      ud->cgAddr.pcInd = FALSE;
#endif /* CMSS7_SPHDROPT */

#ifdef SPTV2
   /* importance is not relevant in status indication to user
    * mark it as not present
    */
   ud->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* sp001.302 - addition - sequence control is not relevant in data
    * indication to upper user, initialize it to zero
    */
   ud->sc = 0;

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptStaIndMt[pst->selector])(pst, suId, opc, ud, ret, mBuf);
         else
            DtLiSptStaInd(pst, suId, opc, ud, ret, mBuf);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptStaIndMt[pst->selector])(pst, suId, opc, ud, ret, mBuf);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptStaInd */

  
/*
*
*       Fun:   Coordinated Indication
*
*       Desc:  SCCP Management Primitive for a coordinated state change
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptCordInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SpUiSptCordInd(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Calling Address */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{

#ifdef SP_CFGMG /* check to see if we should send this message */
   if (!spCb.spCfg.mngmntOn)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPLOGERROR(ERRCLS_DEBUG, ESP842, (ErrVal)ERRZERO, "SpUiSptCordInd");
#endif /* ERRCLASS */
      RETVALUE(RFAILED);
   }
#endif

   TRC3(SpUiSptCordInd)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptCordCfmMt[pst->selector])(pst, suId, aSsn, smi);
         else
            DtLiSptCordInd(pst, suId, aSsn, smi);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptCordIndMt[pst->selector])(pst, suId, aSsn, smi);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptCordInd */

  
/*
*
*       Fun:   Coordinated Confirmation
*
*       Desc:  SCCP Management Primitive for a coordinated state change
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptCordCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SpUiSptCordCfm(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Calling Address */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{

#ifdef SP_CFGMG /* check to see if we should send this message */
   if (!spCb.spCfg.mngmntOn)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPLOGERROR(ERRCLS_DEBUG, ESP843, (ErrVal)ERRZERO, "SpUiSptCordInd");
#endif /* ERRCLASS */
      RETVALUE(RFAILED);
   }
#endif

   TRC3(SpUiSptCordCfm)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptCordCfmMt[pst->selector])(pst, suId, aSsn, smi);
         else
            DtLiSptCordCfm(pst, suId, aSsn, smi);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptCordCfmMt[pst->selector])(pst, suId, aSsn, smi);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptCordCfm */

  
/*
*
*       Fun:   State Indication
*
*       Desc:  SCCP Management State Indication
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination point code */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat,                    /* user status */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 SpUiSptSteInd(pst, suId, aDpc, aSsn, uStat, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination point code */
Ssn aSsn;                       /* Calling Address */
UStat uStat;                    /* user status */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{

#ifdef SP_CFGMG /* check to see if we should send this message */
   if (!spCb.spCfg.mngmntOn)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPLOGERROR(ERRCLS_DEBUG, ESP844, (ErrVal)ERRZERO, "SpUiSptSteInd");
#endif /* ERRCLASS */
      RETVALUE(RFAILED);
   }
#endif

   TRC3(SpUiSptSteInd);

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptSteIndMt[pst->selector])(pst, suId, aDpc, aSsn, uStat, smi);
         else
            DtLiSptSteInd(pst, suId, aDpc, aSsn, uStat, smi);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptSteIndMt[pst->selector])(pst, suId, aDpc, aSsn, uStat, smi);
         break;
   }
   RETVALUE(ROK);
} /* end of SpUiSptSteInd */
  
/*
*
*       Fun:   PC State Indication
*
*       Desc:  SCCP PC-STATE Indication
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptPCSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination point code */
Sps sps                         /* signalling point status */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PUBLIC S16 SpUiSptPCSteInd(pst, suId, aDpc, sps
#ifdef SPTV2
, sccpState, ril
#endif /* SPTV2 */
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination point code */
Sps sps;                        /* signalling point status */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   TRC3(SpUiSptPCSteInd)

#ifdef SP_CFGMG /* check to see if we should send this message */
   if (!spCb.spCfg.mngmntOn)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SPLOGERROR(ERRCLS_DEBUG, ESP845, (ErrVal)ERRZERO, "SpUiSptPCSteInd");
#endif /* ERRCLASS */
      RETVALUE(RFAILED);
   }
#endif

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
#ifdef SPTV2
            (*SpUiSptPCSteIndMt[pst->selector])(pst, suId, aDpc, sps, sccpState,
                                                ril);
#else
            (*SpUiSptPCSteIndMt[pst->selector])(pst, suId, aDpc, sps);
#endif /* SPTV2 */
         else
#ifdef SPTV2
            DtLiSptPCSteInd(pst, suId, aDpc, sps, sccpState, ril);
#else
            DtLiSptPCSteInd(pst, suId, aDpc, sps);
#endif /* SPTV2 */
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
#ifdef SPTV2
         (*SpUiSptPCSteIndMt[pst->selector])(pst, suId, aDpc, sps, sccpState,
                                             ril);
#else
         (*SpUiSptPCSteIndMt[pst->selector])(pst, suId, aDpc, sps);
#endif /* SPTV2 */
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptPCSteInd */

#ifdef SPT2

/*
*
*       Fun:   State Confirmation
*
*       Desc:  Conformation for State Request primitive
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptSteCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* confirmation status */
)
#else
PUBLIC S16 SpUiSptSteCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* confirmation status */
#endif
{
   TRC3(SpUiSptSteCfm)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptSteCfmMt[pst->selector])(pst, suId, status);
         else
            DtLiSptSteCfm(pst, suId, status);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptSteCfmMt[pst->selector])(pst, suId, status);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptSteCfm */

  
/*
*
*       Fun:   Bind Confirmation
*
*       Desc:  Confirmation for Bind Request primitive
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptBndCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* confirmation status */
)
#else
PUBLIC S16 SpUiSptBndCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* confirmation status */
#endif
{
   TRC3(SpUiSptBndCfm)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
            (*SpUiSptBndCfmMt[pst->selector])(pst, suId, status);
         else
            DtLiSptBndCfm(pst, suId, status);
         break;
#endif      
      default:
         /* jump to specific primitive depending on configured selector */
         (*SpUiSptBndCfmMt[pst->selector])(pst, suId, status);
         break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptBndCfm */

  
/*
*
*       Fun:   status Confirmation
*
*       Desc:  Confirmation for status Request primitive from upper layer
*
*       Ret:   ROK   - ok
*
*       Notes: None.
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptStaCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status,                      /* status value */
Dpc dpc,                        /* pointcode */
Ssn ssn,                        /* subsystem number */
UStat uStat,                    /* status value */
Smi smi                         /* subsystem multiplicity indicator */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PUBLIC S16 SpUiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi
#ifdef SPTV2
, sccpState, ril
#endif /* SPTV2 */
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* confirmation status */
Dpc dpc;                        /* pointcode */
Ssn ssn;                        /* subsystem number */
UStat uStat;                    /* status value */
Smi smi;                        /* subsystem multiplicity indicator */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   TRC3(SpUiSptStaCfm)

   switch (pst->dstEnt)
   {
#ifdef DT
      case ENTST :
         if (pst->route == RTE_PROTO)
#ifdef SPTV2
            (*SpUiSptStaCfmMt[pst->selector])(pst, suId, status, dpc, ssn,
                                              uStat, smi, sccpState, ril);
#else
            (*SpUiSptStaCfmMt[pst->selector])(pst, suId, status, dpc, ssn,
                                              uStat, smi);
#endif /* SPTV2 */
         else
#ifdef SPTV2
            DtLiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi, sccpState,
                          ril);
#else
            DtLiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi);
#endif /* SPTV2 */
         break;
#endif      
       default:
         /* jump to specific primitive depending on configured selector */
#ifdef SPTV2
          (*SpUiSptStaCfmMt[pst->selector])(pst, suId, status, dpc, ssn, uStat,
                                            smi, sccpState, ril);
#else
          (*SpUiSptStaCfmMt[pst->selector])(pst, suId, status, dpc, ssn, uStat,
                                            smi);
#endif /* SPTV2 */
          break;
   }

   RETVALUE(ROK);
} /* end of SpUiSptStaCfm */
#endif /* SPT2 */


#ifdef SPCO
  
/*
*
*       Fun:   Connection Indication
*
*       Desc:  Connection Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptConInd
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 SpUiSptConInd(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(SpUiSptConInd)

#ifdef SPTV2
   /* importance is not relevant in connection indication
    * to user, initialize it to not present
    */
   conEvnt->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptConIndMt[pst->selector])(pst, conEvnt, mBuf);

   RETVALUE(ROK);

} /* end of SpUiSptConInd */
  
/*
*
*       Fun:   Connection Confirmation
*
*       Desc:  Connection Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptConCfm
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 SpUiSptConCfm(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(SpUiSptConCfm)

#ifdef SPTV2
   /* importance is not relevant in connection confirmation
    * to user, initialize it to not present
    */
   conEvnt->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptConCfmMt[pst->selector])(pst, conEvnt, mBuf);

   RETVALUE(ROK);

} /* end of SpUiSptConCfm */
  
/*
*
*       Fun:   Data Indication
*
*       Desc:  Data Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDatInd
(
Pst *pst,                       /* post structure */
SpDatEvnt *datEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 SpUiSptDatInd(pst, datEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDatEvnt *datEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(SpUiSptDatInd)

#ifdef SPTV2
   /* importance is not relevant in data indication
    * to user, initialize it to not present
    */
   datEvnt->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptDatIndMt[pst->selector])(pst, datEvnt, mBuf);

   RETVALUE(ROK);

} /* end of SpUiSptDatInd */
  
/*
*
*       Fun:   Expedited Data Indication
*
*       Desc:  Expedited Data Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptEDatInd
(
Pst *pst,                       /* post structure */
SpConId *conId,                 /* connection id */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 SpUiSptEDatInd(pst, conId, mBuf)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(SpUiSptEDatInd)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptEDatIndMt[pst->selector])(pst, conId, mBuf);

   RETVALUE(ROK);

} /* end of SpUiSptEDatInd */


/*
*
*       Fun:   Data Acknowledgement Indication
*
*       Desc:  Data Acknowledgement Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDatAckInd
(
Pst *pst,                       /* post structure */
SpConId *conId                  /* connection id */
)
#else
PUBLIC S16 SpUiSptDatAckInd(pst, conId)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
#endif
{
   TRC3(SpUiSptDatAckInd)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptDatAckIndMt[pst->selector])(pst, conId);

   RETVALUE(ROK);

} /* end of SpUiSptDatAckInd */

  
/*
*
*       Fun:   Reset Indication
*
*       Desc:  Reset Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptRstInd
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 SpUiSptRstInd(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   TRC3(SpUiSptRstInd)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptRstIndMt[pst->selector])(pst, rstEvnt);

   RETVALUE(ROK);

} /* end of SpUiSptRstInd */

  
/*
*
*       Fun:   Reset Confirmation
*
*       Desc:  Reset Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptRstCfm
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 SpUiSptRstCfm(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   TRC3(SpUiSptRstCfm)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptRstCfmMt[pst->selector])(pst, rstEvnt);

   RETVALUE(ROK);

} /* end of SpUiSptRstCfm */
  
/*
*
*       Fun:   Disconnect Indication
*
*       Desc:  Disconnect Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDisInd
(
Pst *pst,                       /* post structure */
SpDisEvnt *disEvnt,             /* disconnect event */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 SpUiSptDisInd(pst, disEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDisEvnt *disEvnt;             /* disconnect event */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(SpUiSptDisInd)

#ifdef SPTV2
   /* importance is not relevant in disconnect indication
    * to user, initialize it to not present
    */
   disEvnt->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptDisIndMt[pst->selector])(pst, disEvnt, mBuf);

   RETVALUE(ROK);

} /* end of SpUiSptDisInd */

  
/*
*
*       Fun:   Inform Indication
*
*       Desc:  Inform Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptInfInd
(
Pst *pst,                       /* post structure */
SpInfEvnt *infEvnt              /* inform event */
)
#else
PUBLIC S16 SpUiSptInfInd(pst, infEvnt )
Pst *pst;                       /* post structure */
SpInfEvnt *infEvnt;             /* inform event */
#endif
{
   TRC3(SpUiSptInfInd)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptInfIndMt[pst->selector])(pst, infEvnt);

   RETVALUE(ROK);

} /* end of SpUiSptInfInd */

#ifdef SPTV2

/*
*
*       Fun:   Audit Indication
*
*       Desc:  Audit Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptAudInd
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 SpUiSptAudInd(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   TRC3(SpUiSptAudInd)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptAudIndMt[pst->selector])(pst, audEvnt);

   RETVALUE(ROK);

} /* end of SpUiSptAudInd */

  
/*
*
*       Fun:   Audit Confirmation
*
*       Desc:  Audit Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptAudCfm
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 SpUiSptAudCfm(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   TRC3(SpUiSptAudCfm)

   /* jump to specific primitive depending on configured selector */

   (*SpUiSptAudCfmMt[pst->selector])(pst, audEvnt);

   RETVALUE(ROK);

} /* end of SpUiSptAudCfm */
#endif /* SPTV2 */
#endif /* SPCO */


/*
*     upper interface portable functions
*/

  
/*
*
*       Fun:   portable - Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  sp_ptui.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtUiSptUDatInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc opc,                        /* originating point code*/
SpUDatEvnt *ud,                 /* unit data event */
Buffer *mBuf                    /* Pointer to the Buffer */
)
#else
PRIVATE S16 PtUiSptUDatInd(pst, suId, opc, ud, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc opc;                        /* originating point code*/
SpUDatEvnt *ud;                 /* unit data event */
Buffer *mBuf;                   /* Pointer to the Buffer */
#endif
{
   TRC3(PtUiSptUDatInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(opc);
   UNUSED(ud);
   UNUSED(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP846, (ErrVal)ERRZERO, "PtUiSptUDatInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptUDatInd */
  
/*
*
*       Fun:   portable - Status Indication
*
*       Desc:  This function is used to Indicate Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PRIVATE S16 PtUiSptStaInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service user id */
Dpc opc,                        /* originating point code */
SpUDatEvnt *ud,                 /* unit data event */
RCause ret,                     /* return cause */
Buffer *mBuf                    /* message buffer  */
)
#else
PRIVATE S16 PtUiSptStaInd(pst, suId, opc, ud, ret, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user iD */
Dpc opc;                        /* originating point code */
SpUDatEvnt *ud;                 /* unit data event */
RCause ret;                     /* retrun cause */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(PtUiSptStaInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(opc);
   UNUSED(ud);
   UNUSED(ret);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP847, (ErrVal)ERRZERO, "PtUiSptStaInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptStaInd */
  
/*
*
*       Fun:   portable - Coordinated Indication
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptCordInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PRIVATE S16 PtUiSptCordInd(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Calling Address */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   TRC3(PtUiSptCordInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aSsn);
   UNUSED(smi);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP848, (ErrVal)ERRZERO, "PtUiSptCordInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptCordInd */
  
/*
*
*       Fun:   portable - Coordinated Confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptCordCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PRIVATE S16 PtUiSptCordCfm(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Calling Address */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   TRC3(PtUiSptCordCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aSsn);
   UNUSED(smi);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP849, (ErrVal)ERRZERO, "PtUiSptCordCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptCordCfm */
  
/*
*
*       Fun:   portable - State Indication
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat,                    /* user status */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PRIVATE S16 PtUiSptSteInd(pst, suId, aDpc, aSsn, uStat, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Calling Address */
UStat uStat;                    /* user status */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   TRC3(PtUiSptSteInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aDpc);
   UNUSED(aSsn);
   UNUSED(uStat);
   UNUSED(smi);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP850, (ErrVal)ERRZERO, "PtUiSptSteInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptSteInd */
  
/*
*
*       Fun:   portable - PC State Indication
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptPCSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination point code */
Sps sps                         /* signalling point status */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PRIVATE S16 PtUiSptPCSteInd(pst, suId, aDpc, sps
#ifdef SPTV2
, sccpState, ril
#endif
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination point code */
Sps sps;                        /* signalling point status */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   TRC3(PtUiSptPCSteInd)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(aDpc);
   UNUSED(sps);
#ifdef SPTV2
   UNUSED(sccpState);
   UNUSED(ril);
#endif /* SPTV2 */

#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP851, (ErrVal)ERRZERO, "PtUiSptPCSteInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptPCSteInd */

#ifdef SPT2

/*
*
*       Fun:   portable - State confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptSteCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* status */
)
#else
PRIVATE S16 PtUiSptSteCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
#endif
{
   TRC3(PtUiSptSteCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP852, (ErrVal)ERRZERO, "PtUiSptSteCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptSteCfm */

  
/*
*
*       Fun:   portable - Bind confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptBndCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* status */
)
#else
PRIVATE S16 PtUiSptBndCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
#endif
{
   TRC3(PtUiSptBndCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP853, (ErrVal)ERRZERO, "PtUiSptBndCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptBndCfm */

  
/*
*
*       Fun:   portable - status confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptStaCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status,                      /* status */
Dpc dpc,                        /* point code */
Ssn ssn,                        /* subsystem number */
UStat uStat,                    /* status */
Smi smi                         /* subsystem multiplicity indicator */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PRIVATE S16 PtUiSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi
#ifdef SPTV2
, sccpState, ril
#endif /* SPTV2 */
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
Dpc dpc;                        /* point code */
Ssn ssn;                        /* subsystem number */
UStat uStat;                    /* status */
Smi smi;                        /* subsystem multiplicity indicator */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   TRC3(PtUiSptStaCfm)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(status);
   UNUSED(dpc);
   UNUSED(ssn);
   UNUSED(uStat);
   UNUSED(smi);
#ifdef SPTV2
   UNUSED(sccpState);
   UNUSED(ril);
#endif /* SPTV2 */

#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP854, (ErrVal)ERRZERO, "PtUiSptStaCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtUiSptStaCfm */

#endif /* SPT2 */

#ifdef SPCO
  
/*
*
*       Fun:   Connection Indication
*
*       Desc:  portable - Connection Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptConInd
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 PtUiSptConInd(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(PtUiSptConInd)

   UNUSED(pst);
   UNUSED(conEvnt);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP855, (ErrVal)ERRZERO, "PtUiSptConInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptConInd */
  
/*
*
*       Fun:   Connection Confirmation
*
*       Desc:  portable - Connection Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptConCfm
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 PtUiSptConCfm(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(PtUiSptConCfm)

   UNUSED(pst);
   UNUSED(conEvnt);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP856, (ErrVal)ERRZERO, "PtUiSptConCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptConCfm */
  
/*
*
*       Fun:   Data Indication
*
*       Desc:  portable - Data Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptDatInd
(
Pst *pst,                       /* post structure */
SpDatEvnt *datEvnt,             /* connection event structure */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 PtUiSptDatInd(pst, datEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDatEvnt *datEvnt;             /* connection event structure */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(PtUiSptDatInd)

   UNUSED(pst);
   UNUSED(datEvnt);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP857, (ErrVal)ERRZERO, "PtUiSptDatInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptDatInd */
  
/*
*
*       Fun:   Expedited Data Indication
*
*       Desc:  portable - Expedited Data Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptEDatInd
(
Pst *pst,                       /* post structure */
SpConId *conId,                 /* connection id */
Buffer *mBuf                    /* Buffer */
)
#else
PUBLIC S16 PtUiSptEDatInd(pst, conId, mBuf)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(PtUiSptEDatInd)

   UNUSED(pst);
   UNUSED(conId);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP858, (ErrVal)ERRZERO, "PtUiSptEDatInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptEDatInd */


/*
*
*       Fun:   Data Acknowledgement Indication
*
*       Desc:  portable - Data Acknowledgement Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptDatAckInd
(
Pst *pst,                       /* post structure */
SpConId *conId                  /* connection id */
)
#else
PUBLIC S16 PtUiSptDatAckInd(pst, conId)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
#endif
{
   TRC3(PtUiSptDatAckInd)

   UNUSED(pst);
   UNUSED(conId);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP859, (ErrVal)ERRZERO, "PtUiSptDatAckInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptDatAckInd */

  
/*
*
*       Fun:   Reset Indication
*
*       Desc:  portable - Reset Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptRstInd
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 PtUiSptRstInd(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   TRC3(PtUiSptRstInd)

   UNUSED(pst);
   UNUSED(rstEvnt);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP860, (ErrVal)ERRZERO, "PtUiSptRstInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptRstInd */

  
/*
*
*       Fun:   Reset Confirmation
*
*       Desc:  portable - Reset Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptRstCfm
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 PtUiSptRstCfm(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   TRC3(PtUiSptRstCfm)

   UNUSED(pst);
   UNUSED(rstEvnt);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP861, (ErrVal)ERRZERO, "PtUiSptRstCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptRstCfm */
  
/*
*
*       Fun:   Disconnect Indication
*
*       Desc:  portable - Disconnect Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptDisInd
(
Pst *pst,                       /* post structure */
SpDisEvnt *disEvnt,             /* disconnect event */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 PtUiSptDisInd(pst, disEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDisEvnt *disEvnt;             /* disconnect event */
Buffer *mBuf;                   /* buffer */
#endif
{
   TRC3(PtUiSptDisInd)

   UNUSED(pst);
   UNUSED(disEvnt);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP862, (ErrVal)ERRZERO, "PtUiSptDisInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptDisInd */

  
/*
*
*       Fun:   Inform Indication
*
*       Desc:  Inform Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptInfInd
(
Pst *pst,                       /* post structure */
SpInfEvnt *infEvnt              /* inform event */
)
#else
PUBLIC S16 PtUiSptInfInd(pst, infEvnt)
Pst *pst;                       /* post structure */
SpInfEvnt *infEvnt;             /* inform event */
#endif
{
   TRC3(PtUiSptInfInd)

   UNUSED(pst);
   UNUSED(infEvnt);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP863, (ErrVal)ERRZERO, "PtUiSptInfInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptInfInd */

#ifdef SPTV2
  
/*
*
*       Fun:   Audit Indication
*
*       Desc:  portable - Audit Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptAudInd
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 PtUiSptAudInd(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   TRC3(PtUiSptAudInd)

   UNUSED(pst);
   UNUSED(audEvnt);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP864, (ErrVal)ERRZERO, "PtUiSptAudInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptAudInd */

  
/*
*
*       Fun:   Audit Confirmation
*
*       Desc:  portable - Audit Confirmation
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  sp_ptui.c
*
*/
#ifdef ANSI
PUBLIC S16 PtUiSptAudCfm
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 PtUiSptAudCfm(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   TRC3(PtUiSptAudCfm)

   UNUSED(pst);
   UNUSED(audEvnt);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP865, (ErrVal)ERRZERO, "PtUiSptAudCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);

} /* end of PtUiSptAudCfm */
#endif /* SPTV2 */
#endif /* SPCO */


/********************************************************************30**
  
         End of file:     sp_ptui.c@@/main/16 - Tue Jan 22 15:13:59 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. text changes

1.3          ---  fmg   1. added support for CCITT 1988 
                           connection-oriented control

1.4          ---  fmg   1. change EVTSTAIND to EVTSTAXXIND

1.5          ---  fmg   1. added support for new system services

1.6          ---  scc   1. Added checking to see if messages from
                           SCCP management should be send to user.
                           Code changed at flag SP_CFGMG.

1.7          ---  scc   1. change cmPkSpAddr

1.8          ---  fmg   1. removed cm2.x include

1.9          ---  fmg   2. added includes

1.10         ---  mjp   1. replace old error function with SPLOGERROR
             ---  mjp   2. CMCHKPKLOG used with all pack functions 
1.11         ---  mjp   1. move cm_ss7.(h/x) above lsp.(x/h)
             ---  mjp   2. removed all ref to SEL_LC_OLD and SPostTsk

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.12         sp005.27 ash  1. Added aDpc parameter to SteInd primitive
                           2. New primtives added for SPT2
             ---      cp   3. Removed the packing functions as per 
                              TCO0001
/main/13     ---      cp   1. fillOption related changes.             
             ---      vb   2. Clean up of the patches
             ---      vb   3. Added support for RANAP and RNSAP

/main/15     ---      cp   1. DFTHA mods
           sp014.301  rc   2. In function SpUiSptStaCfm, ldf dt function call
                              is replaced with function call based on selector
                              in case route is rte_proto
           sp018.301  zq   1. Added BSSAP+ as one of SCCP users.
/main/16     ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
           sp001.302   rc   1. initializing sequence control to zero in data
                               indication and status indication to upper user.
           sp023.302   rc   1. TCAP does not use connection-oriented SCCP.
                               Replacing conection-oriented StLi functions with
                               PtUi functions.
           sp047.302   sm   1. Added support for generic SCCP User entity 
                               ENTSPU.
*********************************************************************91*/
