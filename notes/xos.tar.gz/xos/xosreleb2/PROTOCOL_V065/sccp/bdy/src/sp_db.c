/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp message database
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Message Database.
  
     File:     cp_db.c
  
     Sid:      cp_db.c@@/main/13_1 - Tue Jan 22 15:16:24 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/*
 *
 * All comments enclosed in brackets "()" are references to page numbers in: 
 *
 * CCITT Blue Book
 * ---------------
 * Specifications of Signalling System No. 7
 * Recommendations Q.700-Q.716
 * ISBN 92-61-03511-6
 *
 */


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


/* local defines */

/* foward references */

/* sp004.302 - removal - forward reference to function spChkMsgType removed,
 * as scope of function is changed from private to public
 */

#ifdef SPCO
PRIVATE S16 spSetDstLclRef ARGS((MfMsgCtl*, PTR));
PRIVATE S16 spSetSrcLclRef ARGS((MfMsgCtl*, PTR));
#endif /* SPCO */

/* database contents */

/* Token Flags */
PRIVATE CONSTANT U32 teMndFlgs = TF_MAND;
PRIVATE CONSTANT U32 teMndLstFlgs  = TF_MAND | TF_LAST;
PRIVATE CONSTANT U32 teLstFlgs  = TF_LAST;

#ifdef SPCO
PRIVATE CONSTANT U32 teZeroFlgs  = 0;
#endif

/* Message Level Flags */
PRIVATE CONSTANT U32 mfNoOpFlgs[SP_MAX_SWITCH] = 
{
   MF_NO_OP,                     /* switch test */
   MF_NO_OP,                     /* switch ccitt */
   MF_NO_OP,                     /* switch ansi */
};

PRIVATE CONSTANT U32 mfOpFlgs[SP_MAX_SWITCH] = 
{
   MF_OP,                        /* switch test */
   MF_OP,                        /* switch ccitt */
   MF_OP,                        /* switch ansi */
};

/* Message Element Flags */
PRIVATE CONSTANT U32 meMandFlgs[SP_MAX_SWITCH] = 
{
   EF_MAND,                     /* switch test */
   EF_MAND,                     /* switch ccitt */
   EF_MAND,                     /* switch ansi */
};

PRIVATE CONSTANT U32 meOptFlgs[SP_MAX_SWITCH] = 
{
   0,                           /* switch test */
   0,                           /* switch ccitt */
   EF_NA,                       /* switch ansi */
};


PRIVATE CONSTANT U32 meZeroFlgs[SP_MAX_SWITCH] = 
{
   0,                           /* switch test */
   0,                           /* switch ccitt */
   0,                           /* switch ansi */
};

/*
 * Token validation enums and default values...
 */


/*
 * Token validation enums and default values...
 */

/* Message Type */

PRIVATE TknEnum teMsgTypeEnums0[] = 
{
   NMB_MID, M_CONREQ, M_CONCFM, M_CONREF, M_RELSD, M_RELCMP, M_DATA1,
   M_DATA2, M_DATAACK, M_UNITDATA, M_UNITDATASRV, M_EXPDATA, M_EXPDATAACK, 
   M_RSTREQ, M_RSTCFM, M_PDUERR, M_INACTST, M_XUNITDATA, M_XUNITDATASRV, 
   M_LUNITDATA, M_LUNITDATASRV,
};

PRIVATE TknEnum *teMsgTypeEnums[] =
{
   NULLP,                       /* switch - test */
   teMsgTypeEnums0,             /* switch - ccitt */
   teMsgTypeEnums0,             /* switch - ansi */
};

/* Protocol Classe (spt.h) */

PRIVATE TknEnum teProtClassEnums0[] = 
{
   4, PCLASS0, PCLASS1, PCLASS2, PCLASS3
};

PRIVATE TknEnum *teProtClassEnums[] =
{
   NULLP,                       /* switch - test */
   teProtClassEnums0,           /* switch - ccitt */
   teProtClassEnums0,           /* switch - ansi92/ansi88 */
};

/* Protocol Classe (spt.h) */

PRIVATE TknEnum teRetOptEnums0[] = 
{
   2, REC_NSO, REC_ROE
};

PRIVATE TknEnum *teRetOptEnums[] =
{
   NULLP,                       /* switch - test */
   teRetOptEnums0,              /* switch - ccitt */
   teRetOptEnums0,              /* switch - ansi */
};

#ifdef SPCO
/* Release Cause (spt.h) */

PRIVATE TknEnum teRelCausEnums0[] = 
{
   17, RLC_EUORIG, RLC_EUCONG, RLC_EUFAIL, RLC_SUFAIL, RLC_REMPROC,
   RLC_INCONDT, RLC_ACCFAIL, RLC_ACCCONG, RLC_SSFAIL, RLC_SSCONG,
   RLC_NETFAIL, RLC_NETCONG, RLC_EXRSTTMR, RLC_EXRIATMR, RLC_NOTOBTN,
   RLC_UNQUAL, RLC_FAILSCCP
};

PRIVATE TknEnum teRelCausEnums1[] = 
{
   17, RLC_EUORIG, RLC_EUCONG, RLC_EUFAIL, RLC_SUFAIL, RLC_REMPROC,
   RLC_INCONDT, RLC_ACCFAIL, RLC_ACCCONG, RLC_SSFAIL, RLC_SSCONG,
   RLC_NETFAIL, RLC_NETCONG, RLC_EXRSTTMR, RLC_EXRIATMR, RLC_NOTOBTN,
   RLC_UNQUAL, RLC_FAILSCCP
};

PRIVATE TknEnum *teRelCausEnums[] =
{
   NULLP,                       /* switch - test */
   teRelCausEnums0,             /* switch - ccitt */
   teRelCausEnums1,             /* switch - ansi */
};
#endif /* SPCO */

/* Return Cause (spt.h) */

PRIVATE TknEnum teRetCausEnums0[] = 
{
   15,
   RTC_NTBADADDR, RTC_NTSPECADDR, RTC_SSCONG, RTC_SSFAIL, RTC_UNEQUIP,
   RTC_NETFAIL, RTC_NETCONG, RTC_UNQUAL, RTC_ERRMSGTPRT, RTC_ERRLCLPROC,
   RTC_NOREASSEMB, RTC_SCCPFAIL, RTC_HOPVIOLATE2, RTC_NOSEGSPRT,
   RTC_SEGFAILURE,
};

PRIVATE TknEnum teRetCausEnums1[] = 
{
   22, 
   RTC_NTBADADDR, RTC_NTSPECADDR, RTC_SSCONG, RTC_SSFAIL, RTC_UNEQUIP,
   RTC_NETFAIL, RTC_NETCONG, RTC_UNQUAL, RTC_HOPVIOLATE, RTC_ERRLCLPROC,
   RTC_NOREASSEMB, RTC_HOPVIOLATE2, RTC_NOSEGSPRT, RTC_SEGFAILURE,
   RTC_MSGCHGFAIL, RTC_INVINSRTREQ, RTC_INVISNIRTREQ, RTC_UNAUTHMSG,
   RTC_INCOMPMSG, RTC_ISNICONRTFL, RTC_REDISNICONRT, RTC_UNISNIID,
};

PRIVATE TknEnum *teRetCausEnums[] =
{
   NULLP,                       /* switch - test */
   teRetCausEnums0,             /* switch - ccitt */
   teRetCausEnums1,             /* switch - ansi */
};

#ifdef SPCO
/* Reset Cause (spt.h) */
PRIVATE TknEnum teResCausEnums0[] = 
{
   13, RSC_EUORIG, RSC_SUFAIL, RSC_MOOINCPS, RSC_MOOINCPR, RSC_RPEMOW,
   RSC_RPEIPSR, RSC_RPEGEN, RSC_REUOP, RSC_NETOP, RSC_ACCOP, RSC_NETCONG,
   RSC_NOTOBTN, RSC_UNQUAL
};

PRIVATE TknEnum *teResCausEnums[] =
{
   NULLP,                       /* switch - test */
   teResCausEnums0,             /* switch - ccitt */
   teResCausEnums0,             /* switch - ansi92 */
};

/* Error Cause (spt.h) */

PRIVATE TknEnum teErrCausEnums0[] = 
{
   5, ERR_LRNUD, ERR_LRNIS, ERR_PCMM, ERR_SCMM, ERR_UNQUAL
};

PRIVATE TknEnum *teErrCausEnums[] =
{
   NULLP,                       /* switch - test */
   teErrCausEnums0,             /* switch - ccitt */
   teErrCausEnums0,             /* switch - ansi92 */
};

/* Refusal Cause (spt.h) */

PRIVATE TknEnum teRefCausEnums0[] = 
{
   20,
   RFC_EUORIG, RFC_EUCONG, RFC_EUFAIL, RFC_SUFAIL, RFC_DSTADRUK, 
   RFC_DSTADRIN, RFC_NRQOSNT, RFC_NRQOST, RFC_ACCFAIL, RFC_ACCCONG,
   RFC_SSFAIL, RFC_SSCONG, RFC_EXCETMR, RFC_INCUDT, RFC_NOTOBTN, 
   RFC_UNQUAL, RFC_HOPVIOLATE, RFC_SCCPFAIL, RFC_NTBADADDR, RFC_UNEQUIP
};

PRIVATE TknEnum *teRefCausEnums[] =
{
   NULLP,                       /* switch - test */
   teRefCausEnums0,             /* switch - ccitt */
   teRefCausEnums0,             /* switch - ansi */
};
#endif /* SPCO */

/*
* Token Definitions
*/


PRIVATE CONSTANT TknElmtDef teSpAddr =    /* SCCP Address */
{
   TET_STR,                      /* token element type */
   1,                            /* minimum length (octets) */
   MF_SIZE_TKNSTR,               /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0,                            /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teHopCntr =  /* Hop Counter */
{
   TET_U8,                       /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef teSegReas =   /* Segmenting/Reassembling */
{
   TET_U8,                       /* token element type */
   1,                            /* minimum length (bits) */
   1,                            /* maximum length (bits) */
   0x01,                         /* bit mask */
   0,                            /* minimum value */
   1,                            /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teRecSeqNum = /* Receive Sequence Number */
{
   TET_U8,                       /* token element type */
   7,                            /* minimum length (bits) */
   7,                            /* maximum length (bits) */
   0x7f,                         /* bit mask */
   0,                            /* minimum value */
   0x7f,                         /* maximum value */
   NULLP,                        /* token default value flags */
   1,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teSenSeqNum = /* Send Sequence number*/
{
   TET_U8,                       /* token element type */
   7,                            /* minimum length (bits) */
   7,                            /* maximum length (bits) */
   0x7f,                         /* bit mask */
   0,                            /* minimum value */
   0x7f,                         /* maximum value */
   NULLP,                        /* token default value flags */
   1,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teMoreData =  /* More Data */
{
   TET_U8,                       /* token element type */
   1,                            /* minimum length (bits) */
   1,                            /* maximum length (bits) */
   0x01,                         /* bit mask */
   0,                            /* minimum value */
   0x1,                          /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teRelCause =  /* Release Cause */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teRelCausEnums,               /* pointer to enumerated validation list */
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef teRetCause =  /* Return Cause */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teRetCausEnums,               /* pointer to enumerated validation list */
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef teResCause =  /* Reset Cause */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teResCausEnums,               /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teErrCause =  /* Error Cause */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teErrCausEnums,               /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teRefCause =  /* Refusal Cause */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (bits) */
   8,                            /* maximum length (bits) */
   0xff,                         /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teRefCausEnums,               /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teSrcLclRef=  /* Source Local Reference */
{
   TET_BITS,                     /* token element type */
   3,                            /* minimum length (octets) */
   3,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xffffff,                     /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   spSetSrcLclRef,               /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teDstLclRef=  /* Destination Local Reference */
{
   TET_BITS,                     /* token element type */
   3,                            /* minimum length (octets) */
   3,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xffffff,                     /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   spSetDstLclRef,               /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef teRemainSeg = /* Number of remaining segments */
{
   TET_U8,                       /* token element type */
   4,                            /* minimum length (bits) */
   4,                            /* maximum length (bits) */
   0xf,                          /* bit mask */
   0,                            /* minimum value */
   0xf,                          /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teInSeq =  /* In Sequence */
{
   TET_U8,                       /* token element type */
   1,                            /* minimum length (bits) */
   1,                            /* maximum length (bits) */
   0x01,                         /* bit mask */
   0,                            /* minimum value */
   0x1,                          /* maximum value */
   NULLP,                        /* token default value flags */
   6,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teFirstSeg =  /* First Segment */
{
   TET_U8,                       /* token element type */
   1,                            /* minimum length (bits) */
   1,                            /* maximum length (bits) */
   0x01,                         /* bit mask */
   0,                            /* minimum value */
   0x1,                          /* maximum value */
   NULLP,                        /* token default value flags */
   7,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teXUdRef=  /* Destination Local Reference */
{
   TET_U24,                      /* token element type */
   3,                            /* minimum length (octets) */
   3,                            /* maximum length (octets) */
   0xffffff,                     /* bit mask */
   0,                            /* minimum value */
   0xffffff,                     /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teProtClass=  /* Protocol Class */
{
   TET_U8_ENUM,                  /* token element type */
   4,                            /* minimum length (octets) */
   4,                            /* maximum length (octets) */
   0x0f,                         /* bit mask */
   0,                            /* minimum value */
   0x0f,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teProtClassEnums,             /* pointer to enumerated validation list */
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef teProtClass1= /* Protocol Class */
{
   TET_U8_ENUM,                  /* token element type */
   4,                            /* minimum length (octets) */
   4,                            /* maximum length (octets) */
   0x0f,                         /* bit mask */
   0,                            /* minimum value */
   0x0f,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teProtClassEnums,             /* pointer to enumerated validation list */
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef teRetOpt=     /* Return Options */
{
   TET_U8_ENUM,                  /* token element type */
   4,                            /* minimum length (octets) */
   4,                            /* maximum length (octets) */
   0x0f,                         /* bit mask */
   0,                            /* minimum value */
   0x0f,                         /* maximum value */
   NULLP,                        /* token default value flags */
   4,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   teRetOptEnums,                /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teMsgType=    /* Message Type */
{
   TET_U8_ENUM,                  /* token element type */
   8,                            /* minimum length (octets) */
   8,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0,                            /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   spChkMsgType,                 /* escape to special function */
   teMsgTypeEnums,               /* pointer to enumerated validation list */
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef teCredit=     /* Credit */
{
   TET_U8,                       /* token element type */
   8,                            /* minimum length (octets) */
   8,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teLstFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teCredit1=    /* Credit */
{
   TET_U8,                       /* token element type */
   8,                            /* minimum length (octets) */
   8,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef teEndOp=      /* End Optional Parameters */
{
   TET_U8,                       /* token element type */
   8,                            /* minimum length (octets) */
   8,                            /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0,                            /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teLstFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teData=       /* Data Index */
{
   TET_DATA,                     /* token element type */
   2,                            /* minimum length (octets) */
   SP_MAX_DLEN,                  /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teLongData=   /* Long Data Index */
{
   TET_DATA,                     /* token element type */
   3,                            /* minimum length (octets) */
   SP_MAX_LDLEN,                 /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xffff,                       /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teImportance=   /* Importance Index */
{
   TET_U8,                       /* token element type */
   3,                            /* minimum length (bita) */
   3,                            /* maximum length (bits) */
   0x07,                         /* bit mask */
   0,                            /* minimum value */
   0x07,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndLstFlgs,                /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};



#ifdef SPCO
PRIVATE CONSTANT TknElmtDef teData1=      /* Data Index */
{
   TET_DATA,                     /* token element type */
   1,                            /* minimum length (octets) */
   SP_MAX_DLEN1,                 /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teZeroFlgs,                  /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};

PRIVATE CONSTANT TknElmtDef teData2=      /* Data Index */
{
   TET_DATA,                     /* token element type */
   2,                            /* minimum length (octets) */
   SP_MAX_DLEN2,                 /* maximum length (octets) */
   0,                            /* bit mask */
   0,                            /* minimum value */
   0xff,                         /* maximum value */
   NULLP,                        /* token default value flags */
   0,                            /* bit offset */
   &teMndFlgs,                   /* flags */
   0,                            /* general register value */
   NULLP,                        /* escape to special function */
   NULLP,                        /* pointer to enumerated validation list */
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef *pduHdrTkns[] =       /* Protocol Data Unit Header */
{
   &teMsgType,                   /* message type */
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *endOpTkns[] =        /* End of optional parameters*/
{
   &teEndOp,                     /* message type */
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *hopCntrTkns[] =      /* Hop Counter */
{
   &teHopCntr,                   /* hop counter */ 
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *segmentTkns[] =      /* Segmentation */
{
   &teRemainSeg,                /* remaining segment */
   &teInSeq,                    /* in sequence delivery indicator */
   &teFirstSeg,                 /* first segment indicator */
   &teXUdRef,                   /* local reference for extended unit data */
   NULLP,                       /* null termination */
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef *srcLclRefTkns[] =    /* Source Local Reference */
{
   &teSrcLclRef,                 /* Source Local Reference */
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *dstLclRefTkns[] =    /* Destination Local Reference */
{
   &teDstLclRef,                 /* Destination Local Reference */
   NULLP,                        /* null termination */
};
#endif /* SPCO */
PRIVATE CONSTANT TknElmtDef *protClassTkns[] =    /* Protocol Class */
{
   &teProtClass,                 /* protocol class */
   &teRetOpt,                    /* return option */
   NULLP,                        /* null termination */
};
#ifdef SPCO
PRIVATE CONSTANT TknElmtDef *protClass1Tkns[] =   /* Protocol Class */
{
   &teProtClass1,                /* protocol class */
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *segReasTkns[] =      /* Segmenting/Reassembling*/
{
   &teSegReas,                   /* segmenting/reassembling */
   NULLP,                        /* null termination */
};

PRIVATE CONSTANT TknElmtDef *seqSegTkns[] =       /* Sequencing/Segmenting*/
{
   &teSenSeqNum,                 /* send sequence */
   &teMoreData,                  /* more data */
   &teRecSeqNum,                 /* receive sequence */
   NULLP,                        /* null termination */
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef *cdPtyAddrTkns[] =    /* Called party Address */
{
   &teSpAddr,                    /* SCCP Address */
   NULLP,
};
#ifdef SPCO
PRIVATE CONSTANT TknElmtDef *creditTkns[] =       /* Credit */
{
   &teCredit,                    /* SCCP Address */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *credit1Tkns[] =       /* Credit */
{
   &teCredit1,                    /* SCCP Address */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *refCauseTkns[] =     /* Refusal Cause */
{
   &teRefCause,                  /* SCCP Address */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *recSeqNumTkns[] =    /* Receive Sequence Number */
{
   &teRecSeqNum,                 /* Receive Sequence Number */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *relCauseTkns[] =     /* Release Cause */
{
   &teRelCause,                  /* SCCP Address */
   NULLP,
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef *retCauseTkns[] =     /* Return Cause */
{
   &teRetCause,                  /* SCCP Address */
   NULLP,
};

#ifdef SPCO
PRIVATE CONSTANT TknElmtDef *resCauseTkns[] =     /* Reset Cause */
{
   &teResCause,                  /* Reset Cause */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *errCauseTkns[] =     /* Error Cause */
{
   &teErrCause,                  /* Reset Cause */
   NULLP,
};
#endif /* SPCO */

PRIVATE CONSTANT TknElmtDef *cgPtyAddrTkns[] =    /* Calling Address */
{
   &teSpAddr,                    /* SCCP Address */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *dataTkns[] = /* Data */
{
   &teData,                      /* Data Idx */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *longDataTkns[] = /* Long Data */
{
   &teLongData,                  /* Long Data Idx */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *importanceTkns[] = /* Importance */
{
   &teImportance,                  /* Importance Idx */
   NULLP,
};



#ifdef SPCO
PRIVATE CONSTANT TknElmtDef *data1Tkns[] = /* Data */
{
   &teData1,                      /* Data Idx */
   NULLP,
};

PRIVATE CONSTANT TknElmtDef *data2Tkns[] = /* Data */
{
   &teData2,                      /* Data Idx */
   NULLP,
};
#endif /* SPCO */
#define SP_MAX_ADDRLEN 255               /* maximum address length */

/* Message Element Definitions */

PRIVATE CONSTANT MsgElmtDef mePduHdr =            /* Pdu Header */
{
   MET_FIXED,                   /* element type */
   ME_HEDR,                     /* element id */
   MEI_HEDR,                    /* internal element index ( ) */
   1,                           /* minimum length (octets) */
   1,                           /* maximum length (octets) */
   0,                           /* element error code */
   meMandFlgs,                  /* element switch flag */
   pduHdrTkns,                  /* pointer to token definition list */
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef meSrcLclRef =         /* Source Local Reference */
{
   MET_FIXED,                    /* element type */
   ME_SRCLCLREF,                 /* element id */
   MEI_SRCLCLREF,                /* internal element index ( ) */
   3,                            /* minimum length (octets) */
   3,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   srcLclRefTkns,                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meDstLclRef =         /* Source Local Reference */
{
   MET_FIXED,                    /* element type */
   ME_DSTLCLREF,                 /* element id */
   MEI_DSTLCLREF,                /* internal element index ( ) */
   3,                            /* minimum length (octets) */
   3,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   dstLclRefTkns,                /* pointer to token definition list */
};
#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef meSegment =
{
   MET_VARIABLE,                 /* element type */
   ME_SEGMENTATION,              /* element id */
   MEI_SEGMENTATION,             /* internal element index ( ) */
   4,                            /* minimum length (octets) */
   4,                            /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   segmentTkns,                  /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meProtClass =         /* Protocol Class */
{
   MET_FIXED,                    /* element type */
   ME_PROTCLASS,                 /* element id */
   MEI_PROTCLASS,                /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   protClassTkns,                /* pointer to token definition list */
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef meProtClass1 =        /* Protocol Class */
{
   MET_FIXED,                    /* element type */
   ME_PROTCLASS,                 /* element id */
   MEI_PROTCLASS,                /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   protClass1Tkns,               /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meSegReas =           /* Segmenting/Reassembling */
{
   MET_FIXED,                    /* element type */
   ME_SEGREAS,                   /* element id */
   MEI_SEGREAS,                  /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   segReasTkns,                  /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meSeqSeg =            /* Sequencing/Segmenting */
{
   MET_FIXED,                    /* element type */
   ME_SEQSEG,                    /* element id */
   MEI_SEQSEG,                   /* internal element index ( ) */
   2,                            /* minimum length (octets) */
   2,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   seqSegTkns,                   /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meRefCause =          /* Refusal Cause */
{
   MET_FIXED,                    /* element type */
   ME_REFLCM_CAUSE,                  /* element id */
   MEI_REFLCM_CAUSE,                 /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   refCauseTkns,                 /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meRecSeqNum =         /* Receive Sequence Number */
{
   MET_FIXED,                    /* element type */
   ME_RECSEQNUM,                 /* element id */
   MEI_RECSEQNUM,                /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   recSeqNumTkns,                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meRelCause =          /* Release Cause */
{
   MET_FIXED,                    /* element type */
   ME_RELLCM_CAUSE,              /* element id */
   MEI_RELLCM_CAUSE,             /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   relCauseTkns,                 /* pointer to token definition list */
};
#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef meRetCause =          /* Return Cause */
{
   MET_FIXED,                    /* element type */
   ME_RETLCM_CAUSE,              /* element id */
   MEI_RETLCM_CAUSE,             /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   retCauseTkns,                 /* pointer to token definition list */
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef meResCause =          /* Release Cause */
{
   MET_FIXED,                    /* element type */
   ME_RESLCM_CAUSE,              /* element id */
   MEI_RESLCM_CAUSE,             /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   resCauseTkns,                 /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meErrCause =          /* Error Cause */
{
   MET_FIXED,                    /* element type */
   ME_ERRLCM_CAUSE,              /* element id */
   MEI_ERRLCM_CAUSE,             /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   errCauseTkns,                 /* pointer to token definition list */
};


PRIVATE CONSTANT MsgElmtDef meCdPtyAddr1 =        /* Called Party Address */
{
   MET_VARIABLE,                 /* element type */
   ME_CDPTYADDR,                 /* element id */
   MEI_CDPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   cdPtyAddrTkns,                /* pointer to token definition list */
};

#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef meCdPtyAddr =         /* Called Party Address */
{
   MET_FIXED_PTR,                /* element type */
   ME_CDPTYADDR,                 /* element id */
   MEI_CDPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   cdPtyAddrTkns,                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meCdPtyAddr2 =        /* Called Party Address */
{
   MET_FIXED_PTR2,               /* element type */
   ME_CDPTYADDR,                 /* element id */
   MEI_CDPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   cdPtyAddrTkns,                /* pointer to token definition list */
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef meCredit =    /* meCredit */
{
   MET_VARIABLE,                 /* element type */
   ME_CREDIT,                    /* element id */
   MEI_CREDIT,                   /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   creditTkns,                   /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meCredit1 =   /* meCredit */
{
   MET_FIXED,                    /* element type */
   ME_CREDIT,                    /* element id */
   MEI_CREDIT,                   /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   credit1Tkns,                  /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meCgPtyAddr1 =        /* Called Party Address */
{
   MET_VARIABLE,                 /* element type */
   ME_CGPTYADDR,                 /* element id */
   MEI_CGPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   cgPtyAddrTkns,                /* pointer to token definition list */
};

#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef meCgPtyAddr =        /* Called Party Address */
{
   MET_FIXED_PTR,                /* element type */
   ME_CGPTYADDR,                 /* element id */
   MEI_CGPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   cgPtyAddrTkns,                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meCgPtyAddr2 =        /* Called Party Address */
{
   MET_FIXED_PTR2,               /* element type */
   ME_CGPTYADDR,                 /* element id */
   MEI_CGPTYADDR,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_ADDRLEN,               /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   cgPtyAddrTkns,                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meData =      /* Data */
{
   MET_FIXED_PTR,                /* element type */
   ME_DATA,                      /* element id */
   MEI_DATA,                     /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_DLEN,                  /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   dataTkns,                     /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meHopCntr =   /* Hop Counnter */
{
   MET_FIXED,                    /* element type */
   ME_HOPCNTR,                   /* element id */
   MEI_HOPCNTR,                  /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   hopCntrTkns,                  /* pointer to token definition list */
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef meHopCntr1 =   /* Hop Counter */
{
   MET_VARIABLE,                 /* element type */
   ME_HOPCNTR,                   /* element id */
   MEI_HOPCNTR,                  /* internal element index ( ) */
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   hopCntrTkns,                  /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meData1 =     /* Data */
{
   MET_VARIABLE,                 /* element type */
   ME_DATA,                      /* element id */
   MEI_DATA,                     /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_DLEN1,                 /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   data1Tkns,                    /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meData2 =     /* Data */
{
   MET_FIXED_PTR,                /* element type */
   ME_DATA,                      /* element id */
   MEI_DATA,                     /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_DLEN2,                 /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   data2Tkns,                    /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meData3 =      /* Data */
{
   MET_FIXED_PTR,                /* element type */
   ME_DATA,                      /* element id */
   MEI_DATA,                     /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_DLEN,                  /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   dataTkns,                     /* pointer to token definition list */
};
#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef meEndOp =     /* End of Optional Parameters */
{
   MET_FIXED,                    /* element type (really only 1 octet) */
   ME_ENDOP,                     /* element id */
   MEI_ENDOP,                    /* internal element index( )*/
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meZeroFlgs,                   /* element switch flag */
   &endOpTkns[0],                /* pointer to token definition list */
};

/* sp008.302 - addition - defining endOp to encode dummy ptr for
 * optional param in ERR message
 */
PRIVATE CONSTANT MsgElmtDef meEndOp1 =     /* End of Optional Parameters */
{
   MET_FIXED,                    /* element type (really only 1 octet) */
   ME_ENDOP,                     /* element id */
   MEI_ENDOP,                    /* internal element index( )*/
   1,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meOptFlgs,                    /* element switch flag */
   &endOpTkns[0],                /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meLongData =      /* Data */
{
   MET_FIXED_PTR2,               /* element type */
   ME_LONG_DATA,                 /* element id */
   MEI_LONG_DATA,                /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   SP_MAX_LDLEN,                 /* maximum length (octets) */
   0,                            /* element error code */
   meMandFlgs,                   /* element switch flag */
   longDataTkns,                 /* pointer to token definition list */
};

PRIVATE CONSTANT MsgElmtDef meImportance =   /* Importance */
{
   MET_VARIABLE,                 /* element type */
   ME_IMPORTANCE,                /* element id */
   MEI_IMPORTANCE,               /* internal element index ( ) */
   0,                            /* minimum length (octets) */
   1,                            /* maximum length (octets) */
   0,                            /* element error code */
   meOptFlgs,                    /* element switch flag */
   importanceTkns,               /* pointer to token definition list */
};



/* Message Element List Defintions */

CONSTANT MsgElmtDef *pduHdrMsgDef[] =     /* PDU Header Message Definition */
{
   &mePduHdr,
   NULLP
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef *conReqMsgDef[] =    /* Connection Request */
{
   &meSrcLclRef,                 /* Source Local Reference */
   &meProtClass1,                /* Protocol Class */
   &meCdPtyAddr,                 /* Called Party Address */
   &meCredit,                    /* Credit */
   &meCgPtyAddr1,                /* Calling Party Address */
   &meData1,                     /* Data */
   &meHopCntr1,                  /* Hop Counter */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *conCfmMsgDef[] =    /* Connection Confirm */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   &meProtClass1,                /* Protocol Class */
   &meCredit,                    /* Credit */
   &meCdPtyAddr1,                /* Called Party Address */
   &meData1,                     /* Data */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *conRefMsgDef[] =     /* Connection Refused */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meRefCause,                  /* Refusal Cause */
   &meCdPtyAddr1,                /* Called Party Address */
   &meData1,                     /* Data */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *relsdMsgDef[] =      /* Released */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   &meRelCause,                  /* Refusal Cause */
   &meData1,                     /* Data */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *relCmpMsgDef[] =     /* Released */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *data1MsgDef[] =      /* Data 1 */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSegReas,                   /* Source Local Reference */
   &meData3,                     /* Data */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *data2MsgDef[] =      /* Data 2 */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSeqSeg,                    /* Segmenting/Sequencing*/
   &meData3,                     /* Data */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *dataAckMsgDef[] =    /* Data Acknowledgement */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meRecSeqNum,                 /* Receive Sequence Number */
   &meCredit1,                   /* Credit */
   NULLP
};
#endif /* SPCO */

PRIVATE CONSTANT MsgElmtDef *unitDataMsgDef[] =   /* Unit Data */
{
   &meProtClass,                 /* Protocol Class */
   &meCdPtyAddr,                 /* Called Party Address */
   &meCgPtyAddr,                 /* Calleding Party Address */
   &meData,                      /* Data */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *unitDataSrvMsgDef[] = /* Unit Data */
{
   &meRetCause,                  /* Return Cause */
   &meCdPtyAddr,                 /* Called Party Address */
   &meCgPtyAddr,                 /* Calleding Party Address */
   &meData,                      /* Data */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *xunitDataMsgDef[] =    /* Extended Unit Data */
{
   &meProtClass,                 /* Protocol Class */
   &meHopCntr,                   /* Hop Counter */
   &meCdPtyAddr,                 /* Called Party Address */
   &meCgPtyAddr,                 /* Calleding Party Address */
   &meData,                      /* Data */
   &meSegment,                   /* Segmentation */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *xunitDataSrvMsgDef[] = /* Extended Unit Data */
{
   &meRetCause,                  /* Return Cause */
   &meHopCntr,                   /* Hop Counter */
   &meCdPtyAddr,                 /* Called Party Address */
   &meCgPtyAddr,                 /* Calleding Party Address */
   &meData,                      /* Data */
   &meSegment,                   /* Segmentation */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *lunitDataMsgDef[] =    /* Extended Unit Data */
{
   &meProtClass,                 /* Protocol Class */
   &meHopCntr,                   /* Hop Counter */
   &meCdPtyAddr2,                /* Called Party Address */
   &meCgPtyAddr2,                /* Calleding Party Address */
   &meLongData,                  /* Data */
   &meSegment,                   /* Segmentation */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *lunitDataSrvMsgDef[] = /* Extended Unit Data */
{
   &meRetCause,                  /* Return Cause */
   &meHopCntr,                   /* Hop Counter */
   &meCdPtyAddr2,                /* Called Party Address */
   &meCgPtyAddr2,                /* Calleding Party Address */
   &meLongData,                  /* Data */
   &meSegment,                   /* Segmentation */
   &meImportance,                /* Importance */
   &meEndOp,                     /* End of Optional Parameters */
   NULLP
};

#ifdef SPCO
PRIVATE CONSTANT MsgElmtDef *expDataMsgDef[] =    /* Expedited Data */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meData2,                     /* Data */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *expDataAckMsgDef[] = /* Expedited Data Acknowledgement */
{
   &meDstLclRef,                 /* Destination Local Reference */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *resReqMsgDef[] =     /* Reset Request */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   &meResCause,                  /* Reset Cause */
   &meEndOp1,                    /* sp008.302 - addition - End of Opt Param */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *proDtUErrMsfDef[] =  /* Protocol Data Unit Error */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meErrCause,                  /* Reset Cause */
   &meEndOp1,                    /* sp008.302 - addition - End of Opt Param */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *resCfmMsgDef[] =     /* Reset Confirm */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   NULLP
};

PRIVATE CONSTANT MsgElmtDef *inactTstMsgDef[] =   /* Inactivty Test */
{
   &meDstLclRef,                 /* Destination Local Reference */
   &meSrcLclRef,                 /* Source Local Reference */
   &meProtClass1,                /* Protocol Class */
   &meSeqSeg,                    /* Sequencing/Seqmenting */
   &meCredit1,                   /* Credit */
   NULLP
};
#endif /* SPCO */

/* sp004.302 - modification - array elements are re-organized to
 * optimize message encoding/decoding
 */
CONSTANT MsgDef cpAllPduDefs[] =
{
   /* Unit Data */
   {
      M_UNITDATA,                   /* message type */
      MI_UNITDATA,                  /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      unitDataMsgDef,               /* message element definition list */
   },

   /* Extended Unit Data */
   {
      M_XUNITDATA,                  /* message type */
      MI_XUNITDATA,                 /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      xunitDataMsgDef,              /* message element definition list */
   },

   /* Long Unit Data */
   {
      M_LUNITDATA,                  /* message type */
      MI_LUNITDATA,                 /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      lunitDataMsgDef,              /* message element definition list */
   },

#ifdef SPCO
   /* Connection Request Message */
   {
      M_CONREQ,                     /* message type */
      MI_CONREQ,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      conReqMsgDef,                 /* message element definition list */
   },
   
   /* Connection Confirm Message */
   {
      M_CONCFM,                     /* message type */
      MI_CONCFM,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      conCfmMsgDef,                 /* message element definition list */
   },

   /* Data 1*/
   {
      M_DATA1,                      /* message type */
      MI_DATA1,                     /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      data1MsgDef,                  /* message element definition list */
   },

   /* Inactivity Test */
   {
      M_INACTST,                    /* message type */
      MI_INACTST,                   /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      inactTstMsgDef,               /* message element definition list */
   },

   /* Connection Refused Message */
   {
      M_CONREF,                     /* message type */
      MI_CONREF,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      conRefMsgDef,                 /* message element definition list */
   },

   /* Released */
   {
      M_RELSD,                      /* message type */
      MI_RELSD,                     /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      relsdMsgDef,                  /* message element definition list */
   },

   /* Release Complete */
   {
      M_RELCMP,                     /* message type */
      MI_RELCMP,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      relCmpMsgDef,                 /* message element definition list */
   },

#endif /* SPCO */

   /* Unit Data Service */
   {
      M_UNITDATASRV,                /* message type */
      MI_UNITDATASRV,               /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      unitDataSrvMsgDef,            /* message element definition list */
   },

   /* Extended Unit Data Service */
   {
      M_XUNITDATASRV,               /* message type */
      MI_XUNITDATASRV,              /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      xunitDataSrvMsgDef,           /* message element definition list */
   },

   /* Long Unit Data Service */
   {
      M_LUNITDATASRV,               /* message type */
      MI_LUNITDATASRV,              /* message index */
      0,                            /* protocol discriminator ( )*/
      mfOpFlgs,                     /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      lunitDataSrvMsgDef,           /* message element definition list */
   },

#ifdef SPCO
   /* Data 2 */
   {
      M_DATA2,                      /* message type */
      MI_DATA2,                     /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      data2MsgDef,                  /* message element definition list */
   },

   /* Expedited Data Acknowledgement */
   {
      M_EXPDATAACK,                 /* message type */
      MI_EXPDATAACK,                /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      expDataAckMsgDef,             /* message element definition list */
   },

   /* Expedited Data */
   {
      M_EXPDATA,                    /* message type */
      MI_EXPDATA,                   /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      expDataMsgDef,                /* message element definition list */
   },

   /* Reset Request */
   {
      M_RSTREQ,                     /* message type */
      MI_RSTREQ,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      resReqMsgDef,                 /* message element definition list */
   },

   /* Reset Confirm */
   {
      M_RSTCFM,                     /* message type */
      MI_RSTCFM,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      resCfmMsgDef,                 /* message element definition list */
   },

   /* Protocol Data Unit Error */
   {
      M_PDUERR,                     /* message type */
      MI_PDUERR,                    /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      proDtUErrMsfDef,              /* message element definition list */
   },

   /* Data Acknowledgement */
   {
      M_DATAACK,                    /* message type */
      MI_DATAACK,                   /* message index */
      0,                            /* protocol discriminator ( )*/
      mfNoOpFlgs,                   /* message switch flag ( ) */
      NULLP,                        /* escape to user function */
      dataAckMsgDef,                /* message element definition list */
   },
#endif /* SPCO */

   /* end of msg list */
   {
      0, 0, 0, 0, 0, 0,
   }
};


/* support functions */


/*
*
*       Fun:   spChkMsgType
*
*       Desc:  message function - decode/encode message type
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  cp_db.c
*
*/
/* sp004.302 - modification - scope of func changed from private to public */
#ifdef ANSI
PUBLIC S16 spChkMsgType
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
PTR valptr                 /* value passed to function */
)
#else
PUBLIC S16 spChkMsgType(msgCtlp, valptr)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
PTR valptr;                /* value passed to function */
#endif
{
   REG1 S16 i;             /* a counter */
   CONSTANT MsgElmtDef * CONSTANT *melp;
   CONSTANT MsgDef *spAllPduDefs;
   U8 *val;

   TRC2(spChkMsgType)

   val = (U8*) valptr;
   /* melp definition */
   melp = (CONSTANT MsgElmtDef **)NULLP;
   /* pointer to all pdu definition structure */
   spAllPduDefs = (CONSTANT MsgDef *)msgCtlp->cfgp->pduDefs; 

   /* loop through the pdus */
   for (i = 0; spAllPduDefs[i].melp; i++)
   {
      if (*val == spAllPduDefs[i].id)
      {
         melp = spAllPduDefs[i].melp;
         break;
      }
   }

   if (melp == NULLP)
       MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (i >= (S16) msgCtlp->cfgp->numPdus)
       MSGRET(msgCtlp, MFCCNOMSGTYP);

   /* initialize critical pieces */
   msgCtlp->msgType = (U8) *val;
   msgCtlp->msgIdx = spAllPduDefs[i].idx;
   msgCtlp->smelp1 = melp;
   msgCtlp->mdbp = &spAllPduDefs[i];
   RETVALUE(MFROK);
} /* end of spChkMsgType */

#ifdef SPCO

/*
*
*       Fun:   spSetDstLclRef
*
*       Desc:  set destination local reference
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  cp_db.c
*
*/
 
#ifdef ANSI
PRIVATE S16 spSetDstLclRef
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
PTR valptr                 /* value passed to function */
)
#else
PRIVATE S16 spSetDstLclRef(msgCtlp, valptr)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
PTR valptr;                /* value passed to function */
#endif
{
   U32 *val;

   TRC2(spSetDstLclRef)
   val = (U32*) valptr;
   if (msgCtlp->dir == MF_ENCODE)
      RETVALUE(MFROK);
   else
   {
      msgCtlp->sccpInfo.dlrPres = TRUE;
      msgCtlp->sccpInfo.dstLclRef = *val;
   }

   RETVALUE(MFROK);
} /* end of spSetDstLclRef */


/*
*
*       Fun:   spSetSrcLclRef
*
*       Desc:  set destination local reference
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  cp_db.c
*
*/
 
#ifdef ANSI
PRIVATE S16 spSetSrcLclRef
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
PTR valptr                 /* value passed to function */
)
#else
PRIVATE S16 spSetSrcLclRef(msgCtlp, valptr)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
PTR valptr;                /* value passed to function */
#endif
{
   U32 *val;

   TRC2(spSetSrcLclRef)
   val = (U32*) valptr;
   if (msgCtlp->dir == MF_ENCODE)
      RETVALUE(MFROK);
   else
   {
      msgCtlp->sccpInfo.slrPres = TRUE;
      msgCtlp->sccpInfo.srcLclRef = *val;
   }

   RETVALUE(MFROK);
} /* end of spSetSrcLclRef */
#endif /* SPCO */

/********************************************************************30**
  
         End of file:     cp_db.c@@/main/13_1 - Tue Jan 22 15:16:24 2002
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. text changes
             ---  fmg   2. add ifdef SPCO

1.3          ---  fmg   1. change sp_db.[hx] to cp_db.[hx]

1.4          ---  fmg   1. fixed called and calling address mesg
                           element definitions.
             ---  fmg   2. Change teRetCause flag from teMndFlgs to
                           teMndLstFlgs.
             ---  fmg   3. changes for new system service interface

1.5          ---  scc   1. add CONSTANT to initialized structures

1.6          ---  fmg   1. changes for new mf.
             ---  scc   2. add extended unit data types and hop counters
                           to conform to ANSI92 and CCITT92 standards.
             ---  scc   3. change val (U32) in parameter list of  
                           spChkMsgType, spSetDstLclRef and spSetSrcLclRef 
                           to valptr (PTR).
             ---  fmg   4. fixed CONSTANT usage

1.7          ---  fmg   1. changed PRIVATE CONSTANT **melp to
                           PRIVATE CONSTANT * CONSTANT *melp in
                           spChkMsgType (ChangeLogId: SP2_1ID001)

1.8          ---  mjp   1. removed SS7_ANS92 conditions

1.9          ---  mjp   1. added cm_ss7.h and cm_ss7.x

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.10         ---      ash  1. cm1.[hx] replaced by cm_hash.[hx]

/main/11     ---      vb   1. Added Importance field in the messages
                              for ITU96
                           2. Added LUDT and LUDTS messages

/main/13     ---      cp   1. DFTHA related mods.
/main/13_1   ---      rc   1. Compile flag SS7_ITU96 removed and defines and 
                              data under this flag are made available
                              unconditionally.
                           2. Elements ISNI, INS and MTI added in the msg elmt
                              definitions of xudt(s) and ludt(s).
                           3. Message element defn and token elment defn for 
                              ISNI, INS and MTI added.
                           4. Compile flag dependency from the definitions of
                              return cause, release cuase is removed.
             sp001.302  rc   1. Sid correction
             sp004.302  rc 1. cpAllPduDefs array elements are re-organized to
                              optimize message encoding/decoding
                           2. scope of function spChkMsgType is changed to
                              public from private and so its forward reference
                              is removed.
             sp008.302  rc 1. defining endOp to encode dummy ptr for optional
                              param in ERR and RSR message
                           2. adding field endOp in message element def for ERR
                              and RSR messages.
*********************************************************************91*/
