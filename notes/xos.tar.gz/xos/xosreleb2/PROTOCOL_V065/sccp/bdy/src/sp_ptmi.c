/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - layer management interface - portable
  
     Type:     C source file
  
     Desc:     C source code for the SCCP layer manager interface
               primitives, mapping to layer manager
 
     File:     sp_ptmi.c

     Sid:      sp_ptmi.c@@/main/9_1 - Tue Jan 22 15:13:48 2002
  
     Prg:      fmg
  
*********************************************************************21*/
  

/*
  
Layer management provides the necessary functions to control and
monitor the condition of each protocol layer.
 
The following functions are provided in this file:

     SpMiLspStaInd      Status Indication
     SpMiLspStaCfm      Status Confirm
     SpMiLspStsCfm      Statistics Confirm
     StMiLstTrcInd      Trace Indication

It is assumed that the following functions are provided in the
layer managment service user file:
  
     SpMiLspCfgReq      Configure Request
     SpMiLspStaReq      Status Request
     SpMiLspStsReq      Statistics Request
     SpMiLspCntrlReq    Control Request
 
*/
  

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - Stack manager
*
*/
 

/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"      /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"       /* common LDF-PSF */
#include "cmzpdplb.h"       /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"       /* common LDF-PSF */
#include "cmzpdplb.x"       /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */
/* sp035.302 - addition - following line added for removal of compilation
 * warning 
 */
#if (!defined(LCSPMILSP) || !defined(SM)) 
PRIVATE S16 PtMiLspStaInd ARGS((Pst *pst, SpMngmt *sta));
PRIVATE S16 PtMiLspStaCfm ARGS((Pst *pst, SpMngmt *sta));
PRIVATE S16 PtMiLspStsCfm ARGS((Pst *pst, Action action, SpMngmt *sts));
PRIVATE S16 PtMiLspTrcInd ARGS((Pst *pst, SpMngmt *trc));
#endif /* LCSPMILSP || SM */
#ifdef SP_FTHA
PRIVATE S16 PtMiShtCntrlCfm ARGS((Pst *pst, ShtCntrlCfmEvnt *cfmInfo));
#endif

#ifdef SP_LMINT3
/* sp035.302 - addition - following line added for removal of compilation
 * warning 
 */
#if (!defined(LCSPMILSP) || !defined(SM))
PRIVATE S16 PtMiLspCfgCfm ARGS((Pst *pst, SpMngmt *cfm));
PRIVATE S16 PtMiLspCntrlCfm ARGS((Pst *pst, SpMngmt *cfm));
#endif /* LCSPMILSP || SM */
#endif /* SP_LMINT3 */
 
/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */
 

/*

the following matrices define the mapping between the primitives
called by the layer management interface of MTP level 3 and the corresponding
primitives of the MTP level 3 service user(s).
 
The parameter MAXSPMI defines the maximum number of service users on
top of SCCP. There is an array of functions per primitive
invoked by SCCP. Every array is MAXSPMI long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
   0 - loosely coupled - new interface, forawrd cabability (#define LCSPLM)
   1 - Lsp (#define SM)
 
*/
 

/* Status Indication primitive */
 
PRIVATE LspStaInd SpMiLspStaIndMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspStaInd,        /* 0 - loosely coupled - fc */
#else
   PtMiLspStaInd,          /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLspStaInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspStaInd,          /* 1 - tightly coupled, portable */
#endif
};

/* Status confirm primitive */
 
PRIVATE LspStaCfm SpMiLspStaCfmMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspStaCfm,        /* 0 - loosely coupled - fc */
#else
   PtMiLspStaCfm,          /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLspStaCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspStaCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Trace Indication primitive */
 
PRIVATE LspTrcInd SpMiLspTrcIndMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspTrcInd,        /* 0 - loosely coupled */
#else
   PtMiLspTrcInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLspTrcInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspTrcInd,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistic Confirm primitive */
 
PRIVATE LspStsCfm SpMiLspStsCfmMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspStsCfm,        /* 0 - loosely coupled - fc */
#else
   PtMiLspStsCfm,          /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLspStsCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspStsCfm,          /* 1 - tightly coupled, portable */
#endif
};

#ifdef SP_LMINT3

/* configuration confirm primitive */
PRIVATE LspCfgCfm SpMiLspCfgCfmMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspCfgCfm,        /* 0 - loosely coupled - fc */
#else
   PtMiLspCfgCfm,          /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLspCfgCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspCfgCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* control confirm primitive */
PRIVATE LspCntrlCfm SpMiLspCntrlCfmMt[MAXSPMI] =
{
#ifdef LCSPMILSP
   cmPkLspCntrlCfm,        /* 0 - loosely coupled - fc */
#else
   PtMiLspCntrlCfm,          /* 0 - loosely coupled, portable */
#endif
#ifdef SM
   SmMiLspCntrlCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLspCntrlCfm,          /* 1 - tightly coupled, portable */
#endif
};
#endif /* SP_LMINT3 */

#ifdef SP_FTHA
/* System agent control Confirm primitive */
PRIVATE ShtCntrlCfm SpMiShtCntrlCfmMt[MAXSPMI] =
{
   cmPkMiShtCntrlCfm,               /* 0 - loosely coupled */
#ifdef SH   
   ShMiShtCntrlCfm,                 /* 1 - tightly coupled system agent */
#else
   PtMiShtCntrlCfm,                 /* 1 - tightly coupled, portable */
#endif
};
#endif /* SP_FTHA */


/*
*     support functions
*/


/*
*     layer management interface functions 
*/
 
/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to indicate the status of MTP level 3
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpMiLspStaInd
(
Pst *pst,                 /* post structure */
SpMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 SpMiLspStaInd(pst, sta)
Pst *pst;                 /* post structure */   
SpMngmt *sta;             /* unsolicited status */
#endif
{
   TRC3(SpMiLspStaInd)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspStaIndMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SpMiLspStaInd */
 
/*
*
*       Fun:   Trace Indication
*
*       Desc:  This function is used to indicate the trace of SCCP
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
#ifdef ANSI
PUBLIC S16 SpMiLspTrcInd
(
Pst *pst,   
SpMngmt *trc
)
#else
PUBLIC S16 SpMiLspTrcInd(pst, trc)
Pst *pst;    
SpMngmt *trc;
#endif
{
   TRC3(SpMiLspTrcInd)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspTrcIndMt[pst->selector])(pst, trc); 
   RETVALUE(ROK);
} /* end of SpMiLspTrcInd */ 


/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status of MTP level 3
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpMiLspStaCfm
(
Pst *pst,                 /* post structure */     
SpMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 SpMiLspStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SpMngmt *sta;             /* solicited status */
#endif
{
   TRC3(SpMiLspStaCfm)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspStaCfmMt[pst->selector])(pst, sta); 
   RETVALUE(ROK);
} /* end of SpMiLspStaCfm */
 

/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics of MTP
*              level 3 to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpMiLspStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SpMngmt *sts              /* statistics */
)
#else
PUBLIC S16 SpMiLspStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SpMngmt *sts;             /* statistics */
#endif
{
   TRC3(SpMiLspStsCfm)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspStsCfmMt[pst->selector])(pst, action, sts); 
   RETVALUE(ROK);
} /* end of SpMiLspStsCfm */
 
#ifdef SP_LMINT3


/*
*
*       Fun:   configuration  Confirm
*
*       Desc:  This function is used to confirm the receipt of configuration
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpMiLspCfgCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 SpMiLspCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   TRC3(SpMiLspCfgCfm)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspCfgCfmMt[pst->selector])(pst, cfm); 
   RETVALUE(ROK);
} /* end of SpMiLspCfgCfm */


/*
*
*       Fun:   control  Confirm
*
*       Desc:  This function is used to confirm the receipt of control
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SpMiLspCntrlCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 SpMiLspCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   TRC3(SpMiLspCntrlCfm)
   /* jump to specific primitive depending on configured selector */
   (*SpMiLspCntrlCfmMt[pst->selector])(pst, cfm); 
   RETVALUE(ROK);
} /* end of SpMiLspCntrlCfm */
#endif /* SP_LMINT3 */


/*
*     layer management interface portable functions
*/
/* sp035.302 - addition - following line added for removal of compilation
 * warning 
 */
#if (!defined(LCSPMILSP) || !defined(SM))
/*
*
*       Fun:   portable - Status Indication
*
*       Desc:  This function is used to indicate the status of MTP level 3
*              to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
 
#ifdef ANSI
PRIVATE S16 PtMiLspStaInd
(
Pst *pst,                 /* post structure */
SpMngmt *sta              /* unsolicited status */
)
#else
PRIVATE S16 PtMiLspStaInd(pst, sta)
Pst *pst;                 /* post structure */
SpMngmt *sta;             /* unsolicited status */
#endif
{
   TRC3(PtMiLspStaInd)

   UNUSED(pst);
   UNUSED(sta);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP835, (ErrVal)ERRZERO, "PtMiLspStaInd");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtMiLspStaInd */
 
/*
*
*       Fun:   portable - Status Confirm
*
*       Desc:  This function is used to return the status of MTP level 3
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspStaCfm
(
Pst *pst,                 /* post structure */     
SpMngmt *sta              /* solicited status */
)
#else
PRIVATE S16 PtMiLspStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SpMngmt *sta;             /* solicited status */
#endif
{
   TRC3(PtMiLspStaCfm)

   UNUSED(pst);
   UNUSED(sta);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP836, (ErrVal)ERRZERO, "PtMiLspStaCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtMiLspStaCfm */


/*
*
*       Fun:   Portable Trace Indication
*
*       Desc:  
*
*       Ret:   None
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
#ifdef ANSI
PRIVATE S16 PtMiLspTrcInd
(
Pst *pst,
SpMngmt *trc
)
#else
PRIVATE S16 PtMiLspTrcInd(pst, trc)
Pst *pst;
SpMngmt *trc;
#endif
{
  TRC3(PtMiLspTrcInd);
  
  UNUSED(pst);
  UNUSED(trc);
  
#if (ERRCLASS & ERRCLS_DEBUG)
  SPLOGERROR(ERRCLS_DEBUG, ESP837, (ErrVal)0, "PtMiLstStaCfm () Failed");
#endif
  
  RETVALUE(ROK);
} /* end of PtMiLstTrcInd */

 
/*
*
*       Fun:   portable - Statistics Confirm
*
*       Desc:  This function is used to return the statistics of MTP
*              level 3 to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLspStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SpMngmt *sts              /* statistics */
)
#else
PRIVATE S16 PtMiLspStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SpMngmt *sts;             /* statistics */
#endif
{
   TRC3(PtMiLspStsCfm)

   UNUSED(pst);
   UNUSED(action);
   UNUSED(sts);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP838, (ErrVal)ERRZERO, "PtMiLspStsCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtMiLspStsCfm */
#endif /*LCSPMILSP || SM */ 
#ifdef SP_LMINT3
/* sp035.302 - addition - following line added for removal of compilation
 * warning 
 */
#if (!defined(LCSPMILSP) || !defined(SM)) 

/*
*
*       Fun:   configuration  Confirm
*
*       Desc:  This function is used to confirm the receipt of configuration
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 PtMiLspCfgCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 PtMiLspCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   TRC3(PtMiLspCfgCfm)

   UNUSED(pst);
   UNUSED(cfm);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP839, (ErrVal)ERRZERO, "PtMiLspCfgCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtMiLspCfgCfm */


/*
*
*       Fun:   control  Confirm
*
*       Desc:  This function is used to confirm the receipt of control
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sp_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 PtMiLspCntrlCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 PtMiLspCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   TRC3(PtMiLspCntrlCfm)

   UNUSED(pst);
   UNUSED(cfm);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP840, (ErrVal)ERRZERO, "PtMiLspCntrlCfm");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtMiLspCntrlCfm */
#endif /*LCSPMILSP ||SM  */
#endif /* SP_LMINT3 */

#ifdef SP_FTHA
/*
 *
 *       Fun:   System agent control Confirm
 *
 *       Desc:  This function is used to send the system agent control confirm 
 *              primitive
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptmi.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PUBLIC S16 SpMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(SpMiShtCntrlCfm);

   /* jump to specific primitive depending on configured selector */
   (*SpMiShtCntrlCfmMt[pst->selector])(pst, cfmInfo); 

   RETVALUE(ROK);
} /* end of SpMiShtCntrlCfm */ 

/*
 *
 *       Fun:   System agent portable control Confirm
 *
 *       Desc:  This function is used to send the system agent control confirm 
 *              primitive
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptmi.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtMiShtCntrlCfm
(
Pst *pst,                /* post structure */
ShtCntrlCfmEvnt *cfmInfo     /* system agent control confirm event */
)
#else
PRIVATE S16 PtMiShtCntrlCfm(pst, cfmInfo)
Pst *pst;                /* post structure */
ShtCntrlCfmEvnt *cfmInfo;    /* system agent control confirm event */
#endif
{
   TRC3(PtMiShtCntrlCfm);

   UNUSED(pst);
   UNUSED(cfmInfo);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP841, 0, "PtMiShtCntrlCfm");
#endif /* ERRCLASS */

   RETVALUE(ROK);
} /* end of PtMiShtCntrlCfm */ 
#endif /* SP_FTHA */

  
/********************************************************************30**
  
         End of file:     sp_ptmi.c@@/main/9_1 - Tue Jan 22 15:13:48 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------

  
*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.

1.2          ---  scc   1. miscellaneous changes

1.3          ---  fmg   1. changed LCSPLM to LCSPMILSP

1.4          ---  mjp   1. replace old error function with SPLOGERROR
             ---  mjp   2. CMCHKPKLOG used with all pack functions 

1.5          ---  mjp   1. added cm_ss7.h and cm_ss7.x
             ---  mjp   2. removed all ref to SEL_LC_OLD and SPostTsk
             ---  mjp   3. removed old selector from interface matrices
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.6          ---      ash  1. Added changes for SP_LMINT3
             ---      cp   2. Removed the Packing functions.  
                           3. Added Mapping table for generating TrcInd.

/main/7               vb   1. Updated Error codes

/main/9      ---      cp   1. DFTHA mods
/main/9_1    ---      rc   1. copyright header changed
           sp001.302  rc   1. Sid correction
			  sp035.302  mc   1. Compilation warning for portability files
                                   removed.
*********************************************************************91*/
