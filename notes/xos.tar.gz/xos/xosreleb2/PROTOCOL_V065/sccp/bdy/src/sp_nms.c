/**********************************************************************

    Name:   sp_nms.c 

    Type:   C source file

    Desc:   

    File:   sp_nms.c

    Sid:    

    Created by: 

**********************************************************************/
#ifdef CP_OAM_SUPPORT

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "cm_llist.x"
#include "cm_llist.h"
#include "cm_lib.x"
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

#include "sm.h"
#include "sm.x"
#include "oam_interface.h"
#include "sp_nms.h"
#include "sp_cfg.h"
#include "sp_oam.x"
#include "cp_oam_stru.x"
#include "cp_oam_stru.h"
#include "xosshell.h"
#include "cp_tab_def.h"
#include "sp_bind.h"
EXTERN Void spGetVariantStr(S16 swType, U8 *swStr);
EXTERN Void spGetSwTypeStr(S16 swType, U8 *swStr);

VOID spInitCfgData( )
{
  gSpCfgData.SccpGenNum = 0;
  gSpCfgData.SccpNwAttriNum = 0;
  gSpCfgData.SccpGtRuleNum = 0;
  gSpCfgData.SccpGtAddressNum = 0;
  gSpCfgData.SccpRouteNum = 0;
  gSpCfgData.SccpRouteSsnNum = 0;
}

VOID spResetCfgData( )
{
  smOamDataReorg((U16*)&gSpCfgData.SccpGtRuleNum, (U8 *)&gSpCfgData.SccpGtRule[0].OprType, sizeof(SpGtRuleCfgTab));
  smOamDataReorg((U16*)&gSpCfgData.SccpGtAddressNum, (U8 *)&gSpCfgData.SccpGtAddress[0].OprType, sizeof(SpGtAddressCfgTab));
  smOamDataReorg((U16*)&gSpCfgData.SccpRouteNum, (U8 *)&gSpCfgData.SccpRoute[0].OprType, sizeof(SpRouteCfgTab));
  smOamDataReorg((U16*)&gSpCfgData.SccpRouteSsnNum, (U8 *)&gSpCfgData.SccpRouteSsn[0].OprType, sizeof(SpRouteSsnCfgTab));
}

S16 spRecvInitCfg(tb_record* prow)
{
  SpCfgGenTab              *  pspGenCfg;
  SpCfgNwAttrTab           *  pspNwAttrCfg;
  SpCfgGtRuleTab           *  pspGtRuleCfg;
  SpCfgGtAddressTab        *  pspGtAddrCfg;
  SpCfgRouteTab            *  pspRouteCfg;
  SpCfgRouteSsnTab         *  pspRouteSsnCfg;
  CP_OAM_SS7_NETWORK_TAB   *  pNetworkTab;
  CP_OAM_SS7_SSN_TAB       *  pSsnTab;
  CP_OAM_SS7_UP_TAB        *  pUpTab;
  CP_OAM_SS7_SPC_TAB       *  pSpcTab;


  S16  n = 0;
        
  while(prow)
  {
    switch(prow->tableid)
    {
      case APP_TABLE_ID_SS7_SCCP_GEN:
        pspGenCfg = (SpCfgGenTab *) prow->panytbrow;
        
        gSpCfgData.SccpGenNum++;
        gSpCfgData.SccpGen.NmbNws = pspGenCfg->NmbNws;                    
        gSpCfgData.SccpGen.NmbAsso = pspGenCfg->NmbAsso;
        gSpCfgData.SccpGen.NmbActns = pspGenCfg->NmbActns;
        gSpCfgData.SccpGen.NmbAddrs = pspGenCfg->NmbAddrs;
        gSpCfgData.SccpGen.NmbRtes = pspGenCfg->NmbRtes;  
        gSpCfgData.SccpGen.NmbXUdCb = pspGenCfg->NmbXUdCb;    
        gSpCfgData.SccpGen.NmbCon = pspGenCfg->NmbCon;
        gSpCfgData.SccpGen.GuaTmr = pspGenCfg->GuaTmr;    
        gSpCfgData.SccpGen.RstEndTmr = pspGenCfg->RstEndTmr;    
        break;

      case APP_TABLE_ID_SS7_SCCP_NW_ATTR:
        pspNwAttrCfg = (SpCfgNwAttrTab*) prow->panytbrow;
        
        n = gSpCfgData.SccpNwAttriNum++;
        /*sccp control block index begin with 0*/
        gSpCfgData.SccpNwAttri[n].NwAttrId = pspNwAttrCfg->NwAttrId;
        gSpCfgData.SccpNwAttri[n].SwitchType = pspNwAttrCfg->SwitchType;
        gSpCfgData.SccpNwAttri[n].SstTmr = pspNwAttrCfg->SstTmr;
        gSpCfgData.SccpNwAttri[n].IgnTmr = pspNwAttrCfg->IgnTmr;
        gSpCfgData.SccpNwAttri[n].CrdTmr = pspNwAttrCfg->CrdTmr;
        gSpCfgData.SccpNwAttri[n].AsmbTmr = pspNwAttrCfg->AsmbTmr;
        gSpCfgData.SccpNwAttri[n].FrzTmr = pspNwAttrCfg->FrzTmr;
        gSpCfgData.SccpNwAttri[n].ConTmr = pspNwAttrCfg->ConTmr;
        gSpCfgData.SccpNwAttri[n].IasTmr = pspNwAttrCfg->IasTmr;
        gSpCfgData.SccpNwAttri[n].IarTmr = pspNwAttrCfg->IarTmr;
        gSpCfgData.SccpNwAttri[n].RelTmr = pspNwAttrCfg->RelTmr;
        gSpCfgData.SccpNwAttri[n].RepRelTmr = pspNwAttrCfg->RepRelTmr;
        gSpCfgData.SccpNwAttri[n].IntTmr = pspNwAttrCfg->IntTmr;
        gSpCfgData.SccpNwAttri[n].RstTmr = pspNwAttrCfg->RstTmr;
        break;

      case APP_TABLE_ID_SS7_SCCP_GT_RULE:
        pspGtRuleCfg = (SpCfgGtRuleTab*) prow->panytbrow;
        
        n = gSpCfgData.SccpGtRuleNum++;
        /*sccp control block index begin with 0*/
        gSpCfgData.SccpGtRule[n].RuleId = pspGtRuleCfg->RuleId;
        gSpCfgData.SccpGtRule[n].NwId = pspGtRuleCfg->NwId;
        gSpCfgData.SccpGtRule[n].GtFormat = pspGtRuleCfg->GtFormat;
        gSpCfgData.SccpGtRule[n].TransType = pspGtRuleCfg->TransType;
        gSpCfgData.SccpGtRule[n].NumberPlan= pspGtRuleCfg->NumberPlan;
        gSpCfgData.SccpGtRule[n].NatAddrInd = pspGtRuleCfg->NatAddrInd;
        gSpCfgData.SccpGtRule[n].StartDigit = pspGtRuleCfg->StartDigit;
        gSpCfgData.SccpGtRule[n].EndDigit = pspGtRuleCfg->EndDigit;
        break;

      case APP_TABLE_ID_SS7_SCCP_GT_ADDR:
        pspGtAddrCfg = (SpCfgGtAddressTab*) prow->panytbrow;
        
        n = gSpCfgData.SccpGtAddressNum++;
        /*sccp control block index begin with 0*/
        gSpCfgData.SccpGtAddress[n].GtId = pspGtAddrCfg->GtId;
        gSpCfgData.SccpGtAddress[n].NwId = pspGtAddrCfg->NwId;
        gSpCfgData.SccpGtAddress[n].InRuleId = pspGtAddrCfg->InRuleId;
        gSpCfgData.SccpGtAddress[n].StartDigit = pspGtAddrCfg->StartDigit;
        gSpCfgData.SccpGtAddress[n].EndDigit = pspGtAddrCfg->EndDigit;
        cmCopy(&pspGtAddrCfg->InGtAddr[0], &gSpCfgData.SccpGtAddress[n].InGtAddr[0], 32);
        gSpCfgData.SccpGtAddress[n].SsfInd = pspGtAddrCfg->SsfInd;
        gSpCfgData.SccpGtAddress[n].Ssf = pspGtAddrCfg->Ssf;
        gSpCfgData.SccpGtAddress[n].NiInd = pspGtAddrCfg->NiInd;
        gSpCfgData.SccpGtAddress[n].RteInd = pspGtAddrCfg->RteInd;
        gSpCfgData.SccpGtAddress[n].SpcInd = pspGtAddrCfg->SpcInd;
        gSpCfgData.SccpGtAddress[n].SpcIndex = pspGtAddrCfg->SpcIndex;
        gSpCfgData.SccpGtAddress[n].SsnInd = pspGtAddrCfg->SsnInd;
        gSpCfgData.SccpGtAddress[n].Ssn = pspGtAddrCfg->Ssn;
        gSpCfgData.SccpGtAddress[n].OutRuleId = pspGtAddrCfg->OutRuleId;
        cmCopy(&pspGtAddrCfg->OutGtAddr[0], &gSpCfgData.SccpGtAddress[n].OutGtAddr[0], 32);
        gSpCfgData.SccpGtAddress[n].ReplGt = pspGtAddrCfg->ReplGt;
        break;

      case APP_TABLE_ID_SS7_SCCP_ROUTE:
        pspRouteCfg = (SpCfgRouteTab*) prow->panytbrow;
        
        n = gSpCfgData.SccpRouteNum++;
        /*sccp control block index begin with 0*/
        gSpCfgData.SccpRoute[n].RteId = pspRouteCfg->RteId;
        gSpCfgData.SccpRoute[n].SpcIndex = pspRouteCfg->SpcIndex;
        gSpCfgData.SccpRoute[n].NwId = pspRouteCfg->NwId;
        /*decrease 1 because UPTBL upIndex decrease 1*/
        gSpCfgData.SccpRoute[n].UpIndex = pspRouteCfg->UpIndex - 1;
        gSpCfgData.SccpRoute[n].SsnNum = pspRouteCfg->SsnNum;
        gSpCfgData.SccpRoute[n].SsnId[0] = pspRouteCfg->SsnIndex1;
        gSpCfgData.SccpRoute[n].SsnId[1] = pspRouteCfg->SsnIndex2;
        gSpCfgData.SccpRoute[n].SsnId[2] = pspRouteCfg->SsnIndex3;
        gSpCfgData.SccpRoute[n].SsnId[3] = pspRouteCfg->SsnIndex4;
        gSpCfgData.SccpRoute[n].SsnId[4] = pspRouteCfg->SsnIndex5;
        break;

      case APP_TABLE_ID_SS7_SCCP_ROUTE_SSN:
        pspRouteSsnCfg = (SpCfgRouteSsnTab*) prow->panytbrow;
        
        n = gSpCfgData.SccpRouteSsnNum++;
        /*sccp control block index begin with 0*/
        gSpCfgData.SccpRouteSsn[n].RteSsnId = pspRouteSsnCfg->RteSsnId;
        gSpCfgData.SccpRouteSsn[n].Ssn = pspRouteSsnCfg->Ssn;
        break;

      case APP_TABLE_ID_SS7_NWK:
        pNetworkTab = (CP_OAM_SS7_NETWORK_TAB*) prow->panytbrow;
        CpSs7SetOneNwkTab(EN_CP_OPR_ADD, pNetworkTab);
        break;

      case APP_TABLE_ID_SS7_SSN:
        pSsnTab = (CP_OAM_SS7_SSN_TAB*)prow->panytbrow;
        CpSs7SetOneSsnTab(EN_CP_OPR_ADD, pSsnTab);        
        break;
      case APP_TABLE_ID_SS7_UP:
        pUpTab = (CP_OAM_SS7_UP_TAB*)prow->panytbrow;
        CpSs7SetOneUpTab(EN_CP_OPR_ADD, pUpTab);        
        break;
        
      case APP_TABLE_ID_SS7_SPC:
        pSpcTab = (CP_OAM_SS7_SPC_TAB*)prow->panytbrow;
        CpSs7SetOneSpcTab(EN_CP_OPR_ADD, pSpcTab);        
        break;

      default:
        break;
    }

    prow = prow->next;
  }

  RETVALUE(ROK);
}


S16 spRecvDynCfg(U32 msgtype, tb_record* prow)
{
  SpCfgGtRuleTab            *  pspGtRuleCfg;
  SpCfgGtAddressTab       *  pspGtAddrCfg;
  SpCfgRouteTab             *  pspRouteCfg;
  SpCfgRouteSsnTab        *  pspRouteSsnCfg;
  S16  i, n = 0;
        
  while(prow)
  {
    switch(prow->tableid)
    {
      case APP_TABLE_ID_SS7_SCCP_GT_RULE:
        pspGtRuleCfg = (SpCfgGtRuleTab*) prow->panytbrow;

        if(SA_INSERT_MSG == msgtype)
        {
          n = gSpCfgData.SccpGtRuleNum++;
          /*sccp control block index begin with 0*/
          gSpCfgData.SccpGtRule[n].RuleId = pspGtRuleCfg->RuleId;
          gSpCfgData.SccpGtRule[n].NwId = pspGtRuleCfg->NwId;
          gSpCfgData.SccpGtRule[n].GtFormat = pspGtRuleCfg->GtFormat;
          gSpCfgData.SccpGtRule[n].TransType = pspGtRuleCfg->TransType;
          gSpCfgData.SccpGtRule[n].NumberPlan= pspGtRuleCfg->NumberPlan;
          gSpCfgData.SccpGtRule[n].NatAddrInd = pspGtRuleCfg->NatAddrInd;
          gSpCfgData.SccpGtRule[n].StartDigit = pspGtRuleCfg->StartDigit;
          gSpCfgData.SccpGtRule[n].EndDigit = pspGtRuleCfg->EndDigit;
          gSpCfgData.SccpGtRule[n].OprType = EN_CP_OPR_ADD;
          break;
        }
        else
        {
          for(i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
          {
            if(gSpCfgData.SccpGtRule[i].RuleId == pspGtRuleCfg->RuleId)
            {
              if (SA_UPDATE_MSG == msgtype)
              {
                 gSpCfgData.SccpGtRule[i].OprType = EN_CP_OPR_MOD;
              }
              else if (SA_DELETE_MSG == msgtype)
              {
                 gSpCfgData.SccpGtRule[i].OprType = EN_CP_OPR_DEL;
              }   
              
              break;
            }
          }          
          if(i == gSpCfgData.SccpGtRuleNum)
          {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spRecvDynCfg sccp cannot find match table.");
            RETVALUE(RFAILED);
          }
          break;
        }

      case APP_TABLE_ID_SS7_SCCP_GT_ADDR:
        pspGtAddrCfg = (SpCfgGtAddressTab*) prow->panytbrow;
        
        if(SA_INSERT_MSG == msgtype)
        {
          n = gSpCfgData.SccpGtAddressNum++;
          /*sccp control block index begin with 0*/
          gSpCfgData.SccpGtAddress[n].GtId = pspGtAddrCfg->GtId;
          gSpCfgData.SccpGtAddress[n].NwId = pspGtAddrCfg->NwId;
          gSpCfgData.SccpGtAddress[n].InRuleId = pspGtAddrCfg->InRuleId;
          gSpCfgData.SccpGtAddress[n].StartDigit = pspGtAddrCfg->StartDigit;
          gSpCfgData.SccpGtAddress[n].EndDigit = pspGtAddrCfg->EndDigit;
          cmCopy(&pspGtAddrCfg->InGtAddr[0], &gSpCfgData.SccpGtAddress[n].InGtAddr[0], 32);
          gSpCfgData.SccpGtAddress[n].SsfInd = pspGtAddrCfg->SsfInd;
          gSpCfgData.SccpGtAddress[n].Ssf = pspGtAddrCfg->Ssf;
          gSpCfgData.SccpGtAddress[n].NiInd = pspGtAddrCfg->NiInd;
          gSpCfgData.SccpGtAddress[n].RteInd = pspGtAddrCfg->RteInd;
          gSpCfgData.SccpGtAddress[n].SpcInd = pspGtAddrCfg->SpcInd;
          gSpCfgData.SccpGtAddress[n].SpcIndex = pspGtAddrCfg->SpcIndex;
          gSpCfgData.SccpGtAddress[n].SsnInd = pspGtAddrCfg->SsnInd;
          gSpCfgData.SccpGtAddress[n].Ssn = pspGtAddrCfg->Ssn;
          gSpCfgData.SccpGtAddress[n].OutRuleId = pspGtAddrCfg->OutRuleId;
          cmCopy(&pspGtAddrCfg->OutGtAddr[0], &gSpCfgData.SccpGtAddress[n].OutGtAddr[0], 32);
          gSpCfgData.SccpGtAddress[n].ReplGt = pspGtAddrCfg->ReplGt;
          gSpCfgData.SccpGtAddress[n].OprType = EN_CP_OPR_ADD;
          break;
        }
        else
        {
          for(i = 0; i < gSpCfgData.SccpGtAddressNum; i++)
          {
            if (gSpCfgData.SccpGtAddress[i].GtId == pspGtAddrCfg->GtId)
            {
              if (SA_UPDATE_MSG == msgtype)
              {
                gSpCfgData.SccpGtAddress[i].OprType = EN_CP_OPR_MOD;
              }
              else if (SA_DELETE_MSG == msgtype)
              {
                gSpCfgData.SccpGtAddress[i].OprType = EN_CP_OPR_DEL;
              }   
              
              break;
            }
          }          
          if(i == gSpCfgData.SccpGtAddressNum)
          {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spRecvDynCfg sccp cannot find match table.");
            RETVALUE(RFAILED);
          }
          break;
        }

      case APP_TABLE_ID_SS7_SCCP_ROUTE:
        pspRouteCfg = (SpCfgRouteTab*) prow->panytbrow;
        
        if(SA_INSERT_MSG == msgtype)
        {
          n = gSpCfgData.SccpRouteNum++;
          /*sccp control block index begin with 0*/
          gSpCfgData.SccpRoute[n].RteId = pspRouteCfg->RteId;
          gSpCfgData.SccpRoute[n].SpcIndex = pspRouteCfg->SpcIndex;
          gSpCfgData.SccpRoute[n].NwId = pspRouteCfg->NwId;
          /*decrease 1 because UPTBL upIndex decrease 1*/
          gSpCfgData.SccpRoute[n].UpIndex = pspRouteCfg->UpIndex - 1;
          gSpCfgData.SccpRoute[n].SsnNum = pspRouteCfg->SsnNum;
          gSpCfgData.SccpRoute[n].SsnId[0] = pspRouteCfg->SsnIndex1;
          gSpCfgData.SccpRoute[n].SsnId[1] = pspRouteCfg->SsnIndex2;
          gSpCfgData.SccpRoute[n].SsnId[2] = pspRouteCfg->SsnIndex3;
          gSpCfgData.SccpRoute[n].SsnId[3] = pspRouteCfg->SsnIndex4;
          gSpCfgData.SccpRoute[n].SsnId[4] = pspRouteCfg->SsnIndex5;
          gSpCfgData.SccpRoute[n].OprType = EN_CP_OPR_ADD;
          break;
        }
        else
        {
          for(i = 0; i < gSpCfgData.SccpRouteNum; i++)
          {
            if (gSpCfgData.SccpRoute[i].RteId == pspRouteCfg->RteId)
            {
              if (SA_UPDATE_MSG == msgtype)
              {
                gSpCfgData.SccpRoute[i].OprType = EN_CP_OPR_MOD;
              }
              else if (SA_DELETE_MSG == msgtype)
              {
                gSpCfgData.SccpRoute[i].OprType = EN_CP_OPR_DEL;
              }   
              
              break;
            }
          }          
          if(i == gSpCfgData.SccpRouteNum)
          {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spRecvDynCfg sccp cannot find match table.");
            RETVALUE(RFAILED);
          }
          break;
        }          

      case APP_TABLE_ID_SS7_SCCP_ROUTE_SSN:
        pspRouteSsnCfg = (SpCfgRouteSsnTab*) prow->panytbrow;
        
        if(SA_INSERT_MSG == msgtype)
        {
          n = gSpCfgData.SccpRouteSsnNum++;
          /*sccp control block index begin with 0*/
          gSpCfgData.SccpRouteSsn[n].RteSsnId = pspRouteSsnCfg->RteSsnId;
          gSpCfgData.SccpRouteSsn[n].Ssn = pspRouteSsnCfg->Ssn;
          gSpCfgData.SccpRouteSsn[n].OprType = EN_CP_OPR_ADD;
          break;
        }
        else
        {
          for(i = 0; i < gSpCfgData.SccpRouteSsnNum; i++)
          {
            if (gSpCfgData.SccpRouteSsn[i].RteSsnId == pspRouteSsnCfg->RteSsnId)
            {
              if (SA_UPDATE_MSG == msgtype)
              {
                gSpCfgData.SccpRouteSsn[i].OprType = EN_CP_OPR_MOD;
              }
              else if (SA_DELETE_MSG == msgtype)
              {
                gSpCfgData.SccpRouteSsn[i].OprType = EN_CP_OPR_DEL;
              }   
              break;
            }
          }          
          if(i == gSpCfgData.SccpRouteSsnNum)
          {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spRecvDynCfg sccp cannot find match table.");
            RETVALUE(RFAILED);
          }
          break;
        }

      default:
        break;
    }

    prow = prow->next;
  }

  RETVALUE(ROK);
}

S16 spInitCfgMsg()
{
  U16 i;
  S16 ret = ROK;


  /* static config data only be done in config start phase, and it would not change after system started*/
  if(gSmCb[ENTSP].smStatus == SM_INIT_CFG_STATE)
  {
    ret = sccpGenCfg();
    if(ROK != ret)
    {
      RETVALUE(ret);
    }
    /* create network and nsap config msg */
    for(i = 0; i < gstCpSs7Global.UPTabNum; i++)
    {
      ret = sccpAddSpc(i);
      if(ROK != ret)
      {
        RETVALUE(ret);
      }            
    }

    /* create tsap config msg */
    for(i = 0; i < gstCpSs7Global.SSNTabNum; i++)
    {
      ret = sccpAddSsn(i);
      if(ROK != ret)
      {
        RETVALUE(ret);
      }            
    }
  
    for(i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
    {
      ret = sccpAddGtRule(i);
      if(ROK != ret)
      {
        RETVALUE(ret);
      }
    }

    for(i = 0; i < gSpCfgData.SccpGtAddressNum; i++)
    {
      ret = sccpAddGtAddress(i);
      if(ROK != ret)
      {
        RETVALUE(ret);
      }
    }

    for(i = 0; i < gSpCfgData.SccpRouteNum; i++)
    {
      ret = sccpAddRoute(i);
      if(ROK != ret)
      {
        RETVALUE(ret);
      }
    }
  }

  RETVALUE(ROK);
}

S16 spDynCfgMsg(tb_record *prow)
{
  SpCfgGtRuleTab          *  pspGtRuleCfg;
  SpCfgGtAddressTab       *  pspGtAddrCfg;
  SpCfgRouteTab           *  pspRouteCfg;
  SpCfgRouteSsnTab        *  pspRouteSsnCfg;
  S16  i;
  S16 ret = ROK;


  if(gSmCb[ENTSP].smStatus == SM_DYN_STATE)
  {
    for(i = 0; i < gSpCfgData.SccpGtRuleNum; i++)
    {
      switch(gSpCfgData.SccpGtRule[i].OprType)
      {
        case(EN_CP_OPR_ADD):
          ret = sccpAddGtRule(i);
          if(ROK != ret)
          {
            RETVALUE(ret);
          }    
          break;
        case(EN_CP_OPR_DEL):
          ret = sccpDelGtRule(i);
          if(ROK != ret)
          {
            RETVALUE(ret);
          }            
          break;
        case(EN_CP_OPR_MOD):
          ret = sccpModGtRule(i, prow);
          if(ROK != ret)
          {
            RETVALUE(ret);
          }            
          break;
        default:
          break;
      }     
    }

    for(i = 0; i < gSpCfgData.SccpGtAddressNum; i++)
    {
      switch(gSpCfgData.SccpGtAddress[i].OprType)
      {
        case(EN_CP_OPR_ADD):
          ret = sccpAddGtAddress(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }    
          break;
        case(EN_CP_OPR_DEL):
          ret = sccpDelGtAddress(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }            
          break;
        case(EN_CP_OPR_MOD):
          ret = sccpModGtAddress(i, prow);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }            
          break;
        default:
          break;
      }     
    }

    for(i = 0; i < gSpCfgData.SccpRouteNum; i++)
    {
      switch(gSpCfgData.SccpRoute[i].OprType)
      {
        case(EN_CP_OPR_ADD):
          ret = sccpAddRoute(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }    
          break;
        case(EN_CP_OPR_DEL):
          ret = sccpDelRoute(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }            
          break;
        case(EN_CP_OPR_MOD):
          ret = sccpModRoute(i, prow);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }            
          break;
        default:
          break;
      }     
    }

    for(i = 0; i < gSpCfgData.SccpRouteSsnNum; i++)
    {
      switch(gSpCfgData.SccpRouteSsn[i].OprType)
      {
        case(EN_CP_OPR_ADD):
          ret = sccpAddRouteSsn(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }
          break;
        case(EN_CP_OPR_DEL):
          ret = sccpDelRouteSsn(i);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }                    
          break;
        case(EN_CP_OPR_MOD):
          ret = sccpModRouteSsn(i, prow);
          if(ROK != ret)
          {
              RETVALUE(ret);
          }                    
          break;    
        default:
          break;
      }
    }
    
  }

  RETVALUE(ROK);
}

unsigned char spInitCfgCallback(unsigned short msgtype, unsigned int sepuense, unsigned char pack_end, tb_record* prow)
{
  if(NULL == prow)
  {
    opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spInitCfgCallback SCCP recv null pointer.");
    RETVALUE(RFAILED);
  }

  if(ROK != spRecvInitCfg(prow))
  {
    opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spInitCfgCallback SCCP recv initial config data error");
    RETVALUE(RFAILED);
  }   

  if(TRUE == pack_end)
  {
    if(ROK != spInitCfgMsg())
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spInitCfgCallback sccp init config error");
      RETVALUE(RFAILED);
    }   

    /* send out a config req message to sm*/
    if(ROK != smSendCfgReq(ENTSP, SM_INIT_CFG_STATE))
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spInitCfgCallback send sm cfg req message error");
      RETVALUE(RFAILED);                         
    }

    /* wait initial cofiguration finished*/
    ssWaitSema(&gSmCb[ENTSP].sema);

    /* send response to subagent*/
    if(SM_SUCCESS_STATE ==  gSmCb[ENTSP].smStatus)
    {
      /* All the initialization configuration data is processed successfully */
      opt_response_batch(sepuense, OAM_RESPONSE_OK);
      spBndItReq();            /* SCCP BND M3UA */
    }
    else 
    {
      opt_response_batch(sepuense, OAM_RESPONSE_SYNC_ERROR);
    }

    smReset(ENTSP);

  }

#ifdef CP_OAM_DATA_SHOW
  printf("\n***********************SCCP Config Information Begin***********************\n\n");
  spPrintGenCfgTst();
  spPrintNwCfgTst();
  spPrintGtRuleCfgTst();
  spPrintGtAddrCfgTst();
  spPrintRteCbTst();
  printf("\n***********************SCCP Config Information End***********************\n\n");
#endif

  RETVALUE(ROK) ;
}


unsigned char spDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{
  /*dynamic callback return value initilized fail*/
  prow->head.col_index = OAM_ERRCOL_UNKNOWN;
  if(SA_INSERT_MSG == msgtype)
    prow->head.err_no = OAM_RESPONSE_INSERT_ERROR;
  else if(SA_UPDATE_MSG == msgtype)
    prow->head.err_no = OAM_RESPONSE_UPDATE_ERROR;
  else if(SA_DELETE_MSG == msgtype)
    prow->head.err_no = OAM_RESPONSE_DELETE_ERROR;
  else 
    prow->head.err_no = OAM_RESPONSE_PARAM_ERROR;

  if(NULL == prow)
  {
    opt_response_row(sequence, prow);
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spDynCfgCallback SCCP recv null pointer.");
    RETVALUE(RFAILED);
  }

  if(gSmCb[ENTSP].smStatus != SM_STATUS_TOTAL_NUM)
  {
    opt_response_row(sequence, prow);
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spDynCfgCallback SCCP init configuration do not complete.");
    RETVALUE(RFAILED);
  }
  else
  {
    gSmCb[ENTSP].smStatus = SM_DYN_STATE;
  }

  if(ROK != spRecvDynCfg(msgtype, prow))
  {
    opt_response_row(sequence, prow);
    SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spDynCfgCallback SCCP recv dynamic config data error");
    RETVALUE(RFAILED);
  }   

  if(TRUE == pack_end)
  {
    if(ROK != spDynCfgMsg(prow ))
    {
      opt_response_row(sequence, prow);
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spDynCfgCallback sccp dync config error");
      RETVALUE(RFAILED);
    }   

    /* send out a config req message to sm*/
    if(ROK != smSendCfgReq(ENTSP, SM_DYN_STATE))
    {
      opt_response_row(sequence, prow);
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spDynCfgCallback send sm cfg req message error");
      RETVALUE(RFAILED);                         
    }

    /* wait dynamic cofiguration finished*/
    ssWaitSema(&gSmCb[ENTSP].sema);

    /* send response to subagent*/
    if(SM_SUCCESS_STATE ==  gSmCb[ENTSP].smStatus)
    {
      prow->head.col_index = OAM_ERRCOL_OK;
      prow->head.err_no = OAM_RESPONSE_OK;
      /* All the initialization configuration data is processed successfully */
      opt_response_row(sequence, prow);
    }
    else 
    {
      opt_response_row(sequence, prow);
    }

    smReset(ENTSP);

  }

  RETVALUE(ROK) ;
}

VOID spStatusCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{

  RETVOID ;
}

VOID spCntrlCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{

  RETVOID ;
}

VOID spStatisticCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow)
{

  RETVOID ;
}

















#ifdef CP_OAM_DATA_SHOW

VOID spPrintGenCfgTst( )
{
  SpGenCfg *cfg = &spCb.spCfg;

  printf("-----------------------General Config Info-----------------------\r\n");
  printf("NmbNws NmbAsso NmbActns NmbAddrs NmbRtes NmbXUdCb NmbCon GuaTmr RstEndTmr\r\n"); 
  printf("--------------------------------------------------------------------------\r\n");
  printf("%-6d ",cfg->nmbNws);
  printf("%-7d ",cfg->nmbAsso);
  printf("%-8d ",cfg->nmbActns);
  printf("%-8d ",cfg->nmbAddrs);
  printf("%-7d ",cfg->nmbRtes);
  printf("%-8d ",cfg->nmbXUdCb);
  printf("%-6d ",cfg->nmbCon);
  printf("%-6d ",cfg->defGuaTmr.val);
  printf("%d \r\n",cfg->defRstEndTmr.val);
  printf("--------------------------------------------------------------------------\r\n");
  RETVOID;
}

/************************************************************/
/*****       Functions: Print sccp network block                                   ******/
/************************************************************/
VOID spPrintNwCfgTst( )
{
  U32 i;
  printf("\n--------------------------Network Config Info--------------------------\r\n");
  printf("Number of network is :%d \r\n", spCb.nmbNws);
  
  for(i = 0;i < spCb.nmbNws; i++)
  {
    spPrintOneNwCfgTst((NwId)i);
  }

  RETVOID;  
}

/************************************************************/
/*****       Functions: Print sccp one network block                         ******/
/************************************************************/
VOID spPrintOneNwCfgTst(NwId nwId)
{
  SpNwCb *nw=NULLP;
  U8 tmpStr[20];
#ifndef ZP
#ifdef SPCO
  U32 i;
#endif /* SPCO */
#endif /* ZP */
    
  if(nwId <= spCb.nmbNws)
  {
    nw = spCb.nwList[nwId];
  }
  if(nw == NULLP)
  {
    printf( "NwCb: id(%d) > nmbNws(%d) , or nwCb is NULLP!\r\n", 
        nwId+1, spCb.nmbNws);
    RETVOID;
  }
  
  printf("-----------------------Network%d-----------------------\r\n",nwId+1);
  printf("%-20s:%d \r\n","nwId",nw->nwId);
  spGetVariantStr(nw->variant, tmpStr);
  printf("%-20s:%s \r\n","switch",tmpStr);
  

  printf("--------------Timer Info-------------\r\n");
  printf("    timer      enable   value\r\n");
  printf("------------------------------\r\n");
  printf("%-15s %-5s    %-5d\r\n","sst",(nw->defSstTmr.enb?"TRUE":"FALSE"), nw->defSstTmr.val);
  printf("%-15s %-5s    %-5d\r\n","ignore",(nw->defIgnTmr.enb?"TRUE":"FALSE"), nw->defIgnTmr.val);
  printf("%-15s %-5s    %-5d\r\n","coordinate",(nw->defCrdTmr.enb?"TRUE":"FALSE"), nw->defCrdTmr.val);
  printf("%-15s %-5s    %-5d\r\n","assemble",(nw->defAsmbTmr.enb?"TRUE":"FALSE"), nw->defAsmbTmr.val);
  printf("%-15s %-5s    %-5d\r\n","freeze",(nw->defFrzTmr.enb?"TRUE":"FALSE"), nw->defFrzTmr.val);
  printf("%-15s %-5s    %-5d\r\n","connection",(nw->defConTmr.enb?"TRUE":"FALSE"), nw->defConTmr.val);
  printf("%-15s %-5s    %-5d\r\n","ias",(nw->defIasTmr.enb?"TRUE":"FALSE"), nw->defIasTmr.val);
  printf("%-15s %-5s    %-5d\r\n","iar",(nw->defIarTmr.enb?"TRUE":"FALSE"), nw->defIarTmr.val);
  printf("%-15s %-5s    %-5d\r\n","release",(nw->defRelTmr.enb?"TRUE":"FALSE"), nw->defRelTmr.val);
  printf("%-15s %-5s    %-5d\r\n","repeat release",(nw->defRepRelTmr.enb?"TRUE":"FALSE"), nw->defRepRelTmr.val);
  printf("%-15s %-5s    %-5d\r\n","interval",(nw->defIntTmr.enb?"TRUE":"FALSE"), nw->defIntTmr.val);
  printf("%-15s %-5s    %-5d\r\n","reset",(nw->defRstTmr.enb?"TRUE":"FALSE"), nw->defRstTmr.val);
  printf("------------------------------\r\n");

  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp gt association control block               ******/
/************************************************************/
VOID spPrintGtRuleCfgTst( )
{
  U32 i;
  printf("\n---------------------------GtRule Config Info---------------------------\r\n");
  printf("Number of GtRule is :%d \r\n", spCb.nmbAsso);
  printf("RuleId Switch GtFormat TransType NumberPlan NatAddrInd StartDigit EndDigit\r\n");
  printf("--------------------------------------------------------------------------\r\n");
  for(i = 0;i < spCb.nmbAsso; i++)
  {
    spPrintOneGtRuleCfgTst((U8) i);
  }
  printf("--------------------------------------------------------------------------\r\n");
  RETVOID;  
}


/************************************************************/
/*****       Functions: Print sccp one gt association control block         ******/
/************************************************************/
VOID spPrintOneGtRuleCfgTst(U8 gtAssoId)
{
  SpAssoCb *asso = NULLP;
  U8 tmpStr[20];
    
  if(gtAssoId < spCb.nmbAsso)
  {
    asso = spCb.assoList[gtAssoId];
  }
  if (asso == NULLP)
  {
    printf( "RuleCfg: id(%d) > nmbAsso(%d) , or AssoCb is NULLP!\r\n", 
        gtAssoId+1, spCb.nmbAsso);
    RETVOID;
  }

  spGetVariantStr(asso->rule.sw, tmpStr);
  printf( "%-6d %-6s %-8d  %-9d  %-10d  %-10d  %-10d  %-8d\r\n",
      gtAssoId+1, tmpStr, asso->rule.format, asso->rule.gt.f4.tType, asso->rule.gt.f4.numPlan,
      asso->rule.gt.f4.natAddr, asso->actnCb[0].actn.param.range.startDigit, asso->actnCb[0].actn.param.range.endDigit);

  RETVOID;
}

/************************************************************/
/*****       Functions: Print sccp all gt address map control block      ******/
/************************************************************/
VOID spPrintGtAddrCfgTst( )
{
  SpAssoCb *asso = NULLP;
  SpAddrMapCfg *addrMap = NULLP;    /* Address */
  DEntry *dEntry;        /* data base entry to store */
  PTR hl;            /* hash list entry */
  U32 i = 0, j = 0, k = 0, count = 0;
  S16 ret;               /* return value */
  U8 tmpStr[20];

  printf("\n---------------------------GtAddr Config Info---------------------------\r\n");
  for(i = 0;i < spCb.nmbAsso; i++)
  {
    asso = spCb.assoList[i];
    if (NULLP == asso)
    {
      printf( "AssoCb: id(%d) > nmbAsso(%d) , or AssoCb is NULLP!\r\n", 
          i+1, spCb.nmbAsso);
      continue;
    }

    hl = (PTR) NULLP;
    for(j = 0; j < asso->nmbActns; j++)
    {
      while (1)
      {
        if ((ret = cmHashListGetNext((CmHashListCp *)asso->dataFix, hl, (PTR *) &dEntry)) == ROK)
        {
          hl = (PTR) dEntry;

          printf("\n--------------------------GtAddr%d-------------------------\r\n", count+1);
          printf("%-20s:","InGtAddr");
          
          for(k = 0; k < dEntry->gtKey.addr.length; k++)
          {
            printf("%x%x", (dEntry->gtKey.addr.strg[k] & 0x0f), ((dEntry->gtKey.addr.strg[k] & 0xf0) >> 4) );
          }

          printf("\r\n");
          printf("%-20s:%d \r\n","startDigit",dEntry->gtKey.startDigit);
          printf("%-20s:%d \r\n","endDigit",dEntry->gtKey.endDigit);
          printf("%-20s:%d \r\n","pcInd",dEntry->outAddr[0].pcInd);
          printf("%-20s:%d \r\n","pc",dEntry->outAddr[0].pc);
          printf("%-20s:%d \r\n","ssnInd",dEntry->outAddr[0].ssnInd);
          printf("%-20s:%d \r\n","ssn",dEntry->outAddr[0].ssn);
          printf("%-20s:%d \r\n","ssfPres",dEntry->outAddr[0].ssfPres);
          printf("%-20s:%d \r\n","ssf",dEntry->outAddr[0].ssf);
          printf("%-20s:%d \r\n","niInd",dEntry->outAddr[0].niInd);
          printf("%-20s:%d \r\n","rtgInd",dEntry->outAddr[0].rtgInd);
          printf("%-20s:%d \r\n","replGt",dEntry->replGt);

          spGetVariantStr(dEntry->outAddr[0].sw, tmpStr);
          printf("%-20s:%s \r\n","outSwitch",tmpStr);
          printf("%-20s:%d \r\n","outGtType",dEntry->outAddr[0].gt.gt.f4.tType);
          printf("%-20s:%d \r\n","outGtNumPlan",dEntry->outAddr[0].gt.gt.f4.numPlan);
          printf("%-20s:%d \r\n","outGtEncSch",dEntry->outAddr[0].gt.gt.f4.encSch);
          printf("%-20s:%d \r\n","outGtNatAddr",dEntry->outAddr[0].gt.gt.f4.natAddr);
          printf("%-20s:","outGtAddr");

          for(k = 0; k < dEntry->outAddr[0].gt.addr.length; k++)
          {
            printf("%x%x", (dEntry->outAddr[0].gt.addr.strg[k] & 0x0f), ((dEntry->outAddr[0].gt.addr.strg[k] & 0xf0) >> 4) );
          }
          printf("\r\n");
          count++;
        }
        else
        {
           /* no more entries */
           break;
        }
      }
    }
  }

  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp all route control block                      ******/
/************************************************************/
VOID spPrintRteCbTst( )
{
  PTR hl;            /* hash list entry */
  SpRteCb *rteCb;      /* route control block */
  S16  ret;           /* return value */
  S32 i = 0, j = 0;
  U8 tmpStr[20];

  printf("\n---------------------------Route Config Info---------------------------\r\n");
  printf("RteId Spc     Switch UpIndex SsnNum Ssn1 Ssn2 Ssn3 Ssn4 Ssn5\r\n");
  printf("--------------------------------------------------------------------------\r\n");
  hl = (PTR) NULLP;
  for (;;)
  {
    if ((ret = cmHashListGetNext(&spCb.rteHlCp, hl, (PTR *) &rteCb)) == ROK)
    {
      hl = (PTR) rteCb;
      
      spGetSwTypeStr(rteCb->swtch, tmpStr);
      printf( "%-5d %-7d %-6s %-7d %-6d ",
          i+1, rteCb->dpc, tmpStr, rteCb->nSap->spId+1, rteCb->nmbSsns);
      
      for(j = 0;j < 5; j++)
      {
        printf( "%-4d ", rteCb->ssnList[j].ssn);
      }

      printf( "\r\n");
      i++;
    }
    else
    {
       /* no more entries */
       break;
    }
  } /* for (;;) */
  printf("--------------------------------------------------------------------------\r\n");

  RETVOID;
}

#endif /* CP_OAM_DATA_SHOW */

#endif

