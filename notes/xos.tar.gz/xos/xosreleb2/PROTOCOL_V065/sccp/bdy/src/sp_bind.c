#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "cm_llist.x"
#include "cm_llist.h"
#include "cm_lib.x"

#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

#ifdef CP_OAM_SUPPORT
#include "oam_interface.h"
#include "sp_nms.h"
#include "sp_cfg.h"
#include "sm.h"
#include "sm.x"
#endif

#include "sp_bind.h"




void spBndItReq(void)
{
	SpMngmt	cntrl;
	Pst		smSpPst;
	
	cmMemset((U8*)&cntrl, 0, sizeof(SpMngmt));
	
	spHdrInit(&cntrl.hdr);
	smSpPstInit(&smSpPst);
	
	smSpPst.event  = EVTLSPCNTRLREQ;
	cntrl.hdr.msgType = TCNTRL;
	cntrl.hdr.entId.ent = ENTSP;
	cntrl.hdr.entId.inst = 0;

	cntrl.hdr.elmId.elmnt = STGRNSAP;
	cntrl.t.cntrl.action = ABND_ENA;
	cntrl.t.cntrl.subAction = SAGR_DSTPROCID;
	
	(Void)SpMiLspCntrlReq(&smSpPst, &cntrl);

}				

