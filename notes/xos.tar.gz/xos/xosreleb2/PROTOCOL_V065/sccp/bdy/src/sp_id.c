/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp
  
     Type:     C source file
  
     Desc:     product id file 
  
     File:     sp_id.c
  
     Sid:      sp_id.c@@/main/13_1 - Tue Jan 22 15:13:18 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/* header include files (.h) */
  
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
  
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
  
/* header/extern include files (.x) */
  
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */
  
/* defines */
  
#define SPSWMV 3             /* sccp - main version */
#define SPSWMR 2             /* sccp - main revision */
#define SPSWBV 0             /* sccp - branch version */
/* sp050.302 - incremented the branch revision */
#define SPSWBR 50            /* sccp - branch revision */
#define SPSWPN "1000030"     /* sccp - part number */

/* forward references */
  
#ifdef __cplusplus
extern "C" {
#endif
EXTERN S16 spGetSId ARGS((SystemId *s));
#ifdef __cplusplus
}
#endif

/* public variable declarations */
  
/* system id */
  
PRIVATE CONSTANT SystemId sId ={
   SPSWMV,                    /* main version */
   SPSWMR,                    /* main revision */
   SPSWBV,                    /* branch version */
   SPSWBR,                    /* branch revision */
   SPSWPN,                    /* part number */
};


/*
*     support functions
*/


/*
*
*       Fun:   get system id
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   TRUE      - ok
*
*       Notes: None
*
*       File:  sp_id.c
*
*/
#ifdef ANSI
PUBLIC S16 spGetSId
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 spGetSId(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(spGetSId)
   s->mVer = sId.mVer;
   s->mRev = sId.mRev;
   s->bVer = sId.bVer;
   s->bRev = sId.bRev;
   s->ptNmb = sId.ptNmb;
   RETVALUE(TRUE);
} /* spGetSid */
  

/********************************************************************30**

         End of file:     sp_id.c@@/main/13_1 - Tue Jan 22 15:13:18 2002

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. change version

1.3          ---  scc   1. add prototype line for spGetSId
             ---  scc   2. remove lm_pt.h include file
             ---  scc   3. replaced ss_pt.? and ss_ms.? with ssi.? include
                           files.
             ---  scc   4. change version
             ---  scc   5. change ban1 and ban2 to PUBLIC.
             ---  scc   6. rename ban1 and ban2 to spBan1 and spBan2.

1.4          ---  scc   1. change version

1.5          ---  scc   1. change version

1.6          ---  fmg   1. bumped version

1.7          ---  fmg   1. change version

1.8          ---  mjp   1. change version

1.9          ---  mjp   1. change version

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.10         ---      ash  1. change version
  
/main/11     ---      vb   1. change version

/main/13     ---      cp   1. Changed version to 3.1
             sp001.31 sg   1. Incremented the branch number.
             sp002.31 sg   1. Incremented the branch number.
             sp003.31 sg   1. Incremented the branch number.
             sp004.301 sg  5. Incremented the branch number.
             sp005.301 sg  6. Incremented the branch number.
             sp006.301 sg  7. Incremented the branch number.
             sp007.301 rc  7. Incremented the branch number.
             sp008.301 sg  8. Incremented the branch number.
             sp009.301 sg  8. Incremented the branch number.
             sp010.301 rc  9. Incremented the branch number.
/main/13_1   ---        rc   1. Changes version to 3.2
             sp001.302  rc   1. Sid correction; incrementing the branch number
             sp002.302  rc   1. Incrementing the branch number
             sp003.302  qz   1. Incrementing the branch number
             sp004.302  rc   5. Incrementing the branch number
             sp005.302  rc   6. Incrementing the branch number
             sp006.302  rc   6. Incrementing the branch number
             sp007.302  rc   6. Incrementing the branch number
             sp008.302  rc   9. Incrementing the branch number
             sp009.302  sg   10.Incrementing the branch number
             sp010.302  sg   11.Incrementing the branch number
             sp011.302  sg   12.Incrementing the branch number
             sp012.302  sg   13.Incrementing the branch number
             sp013.302  sg   14.Incrementing the branch number
             sp014.302  sg   15.Incrementing the branch number
             sp015.302  sg   16.Incrementing the branch number
             sp016.302  sg   16.Incrementing the branch number
             sp017.302  rc   18.Incrementing the branch number
             sp018.302  rc   19.Incrementing the branch number
             sp019.302  rc   20.Incrementing the branch number
             sp020.302  rc   21.Incrementing the branch number
             sp021.302  rc   22.Incrementing the branch number
             sp022.302  rc   23.Incrementing the branch number
             sp023.302  rc   24.Incrementing the branch number
             sp024.302  rc   25.Incrementing the branch number
             sp025.302  rc   26.Incrementing the branch number
             sp026.302  rc   27.Incrementing the branch number
             sp027.302  rc   28.Incrementing the branch number
             sp028.302  rc   29.Incrementing the branch number
             sp029.302  rc   30.Incrementing the branch number
             sp030.302  cg   31.Incrementing the branch number
             sp031.302  cg   31.Incrementing the branch number
             sp032.302  cg   31.Incrementing the branch number
             sp033.302  rc   31.Incrementing the branch number
             sp034.302  rc   34.Incrementing the branch number
             sp035.302  mc   34.Incrementing the branch number
             sp036.302  mc   34.Incrementing the branch number
             sp037.302  mc   34.Incrementing the branch number
             sp038.302  rc   38.Incrementing the branch number
             sp039.302  mc   38.Incrementing the branch number
             sp040.302  mc   40.Incrementing the branch number
             sp041.302  sm   41.Incrementing the branch number
             sp042.302  mc   42.Incrementing the branch number
             sp043.302  mc   43.Incrementing the branch number
             sp044.302  sm   44.Incrementing the branch number
             sp045.302  mc   45.Incrementing the branch number
             sp046.302  mc   46.Incrementing the branch number
             sp047.302  sm   46.Incrementing the branch number
             sp048.302  sm   46.Incrementing the branch number
             sp049.302  mc   46.Incrementing the branch number
             sp050.302  mc   46.Incrementing the branch number
*********************************************************************91*/
