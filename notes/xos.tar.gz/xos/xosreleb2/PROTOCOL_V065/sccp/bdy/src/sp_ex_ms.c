/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - external - mos
  
     Type:     C source file
  
     Desc:     Functions required for scheduling and initialization.
  
     File:     cp_ex_ms.c
  
     Sid:      cp_ex_ms.c@@/main/17_1 - Tue Jan 22 15:17:05 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */
  

/* local externs */
  
/* forward references */
  
/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */



  
/*
*
*       Fun:    initialize external
*
*       Desc:   Initializes variables used to interface with Upper/Lower
*               Layer
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   cp_ex_ms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 spInitExt
(
void
)
#else
PUBLIC S16 spInitExt()
#endif
{
   TRC2(spInitExt)
   RETVALUE(ROK);
} /* end of spInitExt */


/*
*
*       Fun:   spActvTsk
*
*       Desc:   Activation function for SCCP
*
*       Ret:    ROK  - ok
*
*       Notes:  new version.
*
*       File:  cp_ex_ms.c
*
*/
#ifdef ANSI
PUBLIC S16 spActvTsk
(
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 spActvTsk(pst, mBuf)
Pst *pst;
Buffer *mBuf;
#endif
{
   S16 ret;

   TRC3(spActvTsk);

   ret = ROK;
   switch (pst->srcEnt)
   {
#ifdef LCSPUISPT
      case ENTSI:  /* ISUP */
      case ENTST:  /* TCAP */
      case ENTRA:  /* RANAP */
      case ENTRN:  /* RNSAP */
      case ENTNP:  /* SUA NIF */
      case ENTGA:  /* sp024.302 - addition - BSSAP+ */
      case ENTSPU: /* sp047.302 - addition - SCCP User Layer */
         switch (pst->event)
         {
            case EVTSPTBNDREQ:                     /* Bind Request */
               ret = cmUnpkSptBndReq(SpUiSptBndReq, pst, mBuf);
               break;
            case EVTSPTUBNDREQ:                    /* unbind Request */
               ret = cmUnpkSptUbndReq(SpUiSptUbndReq, pst, mBuf);
               break;
            case EVTSPTUDATREQ:
               ret = cmUnpkSptUDatReq(SpUiSptUDatReq, pst, mBuf);
               break;
            /* sp047.302 - Addition - Handler for unit data service request */
#ifdef SPTV2_1
            case EVTSPTUDATSRVREQ:
               ret = cmUnpkSptUDatSrvReq(SpUiSptUDatSrvReq, pst, mBuf);
               break;
#endif /* SPTV2_1 */
            case EVTSPTCRDREQ:                     /* Coordinated Request */
               ret = cmUnpkSptCordReq(SpUiSptCordReq, pst, mBuf);
               break;
            case EVTSPTCRDRSP:                     /* Coordinated Response */
               ret = cmUnpkSptCordRsp(SpUiSptCordRsp, pst, mBuf);
               break;
            case EVTSPTSTEREQ:                     /* State Request */
               ret = cmUnpkSptSteReq(SpUiSptSteReq, pst, mBuf);
               break;
#ifdef SPT2
            case EVTSPTSTAREQ:                     /* Status Request */
               ret = cmUnpkSptStaReq(SpUiSptStaReq, pst, mBuf);
               break;
#endif /* SPT2 */
#ifdef SPCO
            case EVTSPTCONREQ:                     /* Connect Request */
               ret = cmUnpkSptConReq(SpUiSptConReq, pst, mBuf);
               break;
            case EVTSPTCONRSP:                     /* Connect Response */
               ret = cmUnpkSptConRsp(SpUiSptConRsp, pst, mBuf);
               break;
            case EVTSPTDATREQ:                     /* Data Request */
               ret = cmUnpkSptDatReq(SpUiSptDatReq, pst, mBuf);
               break;
            case EVTSPTEDATREQ:                    /* Expedited Data Req. */
               ret = cmUnpkSptEDatReq(SpUiSptEDatReq, pst, mBuf);
               break;
            case EVTSPTRSTREQ:                     /* Reset Req. */
               ret = cmUnpkSptRstReq(SpUiSptRstReq, pst, mBuf);
               break;
            case EVTSPTRSTRSP:                     /* Reset Rsp. */
               ret = cmUnpkSptRstRsp(SpUiSptRstRsp, pst, mBuf);
               break;
            case EVTSPTDATACKREQ:                   /* Data Ack. Req. */
               ret = cmUnpkSptDatAckReq(SpUiSptDatAckReq, pst, mBuf);
               break;
            case EVTSPTDISREQ:                    /* Disconnect Req. */
               ret = cmUnpkSptDisReq(SpUiSptDisReq, pst, mBuf);
               break;
            case EVTSPTCNSTREQ:                    /* Information request */
               ret = cmUnpkSptInfReq(SpUiSptInfReq, pst, mBuf);
               break;
#ifdef SPTV2
            case EVTSPTAUDREQ:                     /* Audit Req. */
               ret = cmUnpkSptAudReq(SpUiSptAudReq, pst, mBuf);
               break;
            case EVTSPTAUDRSP:                     /* Audit Rsp. */
               ret = cmUnpkSptAudRsp(SpUiSptAudRsp, pst, mBuf);
               break;
#endif /* SPTV2 */
#endif /* SPCO */
            default:
               SPLOGERROR(ERRCLS_DEBUG, ESP366, (ErrVal) pst->event,
                    "spActvTsk invalid event from upper interface");
               /* sp007.302 - addition - release buffer and return failure */
               if (mBuf != (Buffer *) NULLP)
                  (Void) SPutMsg(mBuf);
               ret = RFAILED;
               break;
         } /* switch (pst->event) */
         break;
#endif /* LCSPUISPT */

#ifdef LCSPLISNT
      case ENTSN :  /* MTP3 */
      case ENTIT :  /* M3UA */
         switch (pst->event)
         {
            case EVTSNTUDATIND:                    /* Unit Data indication */
               ret = cmUnpkSntUDatInd(SpLiSntUDatInd, pst, mBuf);
               break;

            case EVTSNTSTAIND:                     /* Status indication */
               ret = cmUnpkSntStaInd(SpLiSntStaInd, pst, mBuf);
               break;
#ifdef SNT2
            case EVTSNTSTACFM:                     /* status confirmation*/
               ret = cmUnpkSntStaCfm(SpLiSntStaCfm, pst, mBuf);
               break;
            case EVTSNTBNDCFM:                     /* bind confirmation*/
               ret = cmUnpkSntBndCfm(SpLiSntBndCfm, pst, mBuf);
               break;
#endif /* SNT2 */
            default:
               SPLOGERROR(ERRCLS_DEBUG, ESP367, (ErrVal) pst->event,
                          "spActvTsk invalid event on lower interface");
               /* sp007.302 - addition - release buffer and return failure */
               if (mBuf != (Buffer *) NULLP)
                  (Void) SPutMsg(mBuf);
               ret = RFAILED;
               break;
         } /* switch (pst->event) */
         break;
#endif /* LCSPLISNT */

#ifdef LCSPMILSP
      case ENTSM:   /* stack manager */
#ifndef TDS_CORE2   /* Added in sp002 */
      case ENTSH:
#endif
         switch (pst->event)
         {
            case EVTLSPCNTRLREQ:             /* Control Request */
               ret = cmUnpkLspCntrlReq(SpMiLspCntrlReq, pst, mBuf);
               break;
            case EVTLSPSTSREQ:               /* Statistics Request */
               ret = cmUnpkLspStsReq(SpMiLspStsReq, pst, mBuf);
               break;
            case EVTLSPSTAREQ:               /* Status Request */
               ret = cmUnpkLspStaReq(SpMiLspStaReq, pst, mBuf);
               break;
            case EVTLSPCFGREQ:               /* Configuration Request */
#ifdef SP_RUG
               ret = cmUnpkLspCfgReq(SpMiLspCfgReq, spRetroCfgReq, pst, mBuf);
#else
               ret = cmUnpkLspCfgReq(SpMiLspCfgReq, spRetroErr, pst, mBuf);
#endif /* SP_RUG */
               break;
            default:
#ifdef ZP
               /* pass all the events to SCCP PSF */
               /* sp008.302 - removal - do not take ret val from psf */
               (Void) zpActvTsk(pst, mBuf);
#else
               SPLOGERROR(ERRCLS_DEBUG, ESP368, (ErrVal) pst->event,
                          "spActvTsk invalid event from stack manager");
               /* sp007.302 - addition - release buffer and return failure */
               if (mBuf != (Buffer *) NULLP)
                  (Void) SPutMsg(mBuf);
               ret = RFAILED;
#endif /* ZP */
               break;
         } /* switch (pst->event) */
         break;
#ifdef TDS_CORE2  /* Added in sp002 */
      case ENTSH:   /* system Agent */
         switch (pst->event)
         {
#ifdef SP_FTHA
            case EVTSHTCNTRLREQ:             /* system agent control request */
               /* call unpakcing function */
               ret = cmUnpkMiShtCntrlReq(SpMiShtCntrlReq, pst, mBuf);
               break;
#endif /* SP_FTHA */
            default:
#ifdef ZP
               /* pass all the events to SCCP PSF */
               /* sp008.302 - removal - do not take ret val from psf */
               (Void) zpActvTsk(pst, mBuf);
#else
               SPLOGERROR(ERRCLS_DEBUG, ESP369, (ErrVal) pst->event,
                          "spActvTsk invalid event from stack manager");
               /* sp007.302 - addition - release buffer and return failure */
               if (mBuf != (Buffer *) NULLP)
                  (Void) SPutMsg(mBuf);
               ret = RFAILED;
#endif /* ZP */
               break;
         } /* switch (pst->event) */
         break;
#endif /* TDS_CORE2 */
#endif /* LCSPMILSP */

#ifdef ZP
      case ENTSP:   /* from peer */
         /* sp008.302 - removal - do not take ret val from psf */
         (Void) zpActvTsk(pst, mBuf);
         break;
#endif /* ZP */

      default:
         SPLOGERROR(ERRCLS_DEBUG, ESP370, (ErrVal) pst->srcEnt,
                    "spActvTsk invalid srcEnt");
         /* sp007.302 - addition - release buffer and return failure */
         if (mBuf != (Buffer *) NULLP)
            (Void) SPutMsg(mBuf);
         ret = RFAILED;
         break;
   } /* switch (pst->srcEnt) */

#ifdef SP_RUG
   /* check return value */
   if (ret == RINVIFVER)
   {
      /* primitive with invalid interface version number recvd,
       * generate alarm
       */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_INV_EVT,
                  LCM_CAUSE_DECODE_ERR, (U8) (pst->event), 
                  (U8) (pst->intfVer));
   }
#endif /* SP_RUG */

   SExitTsk();
   RETVALUE(ret);
} /* spActvTsk */


  
/********************************************************************30**
  
         End of file:     cp_ex_ms.c@@/main/17_1 - Tue Jan 22 15:17:05 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/

  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  fmg   1. Added support for CCITT 1988
                           connection oriented control

1.4          ---  fmg   1. text changes

1.5          ---  fmg   1. change return( to RETVOID

1.6          ---  fmg   1. changes for new system service interface
             ---  ak    2. removed ent, inst from spSAPCfg unpacking

1.7          ---  scc   1. add error codes

1.8          ---  fmg   1. don't unpack statistics for StsReq
             ---  fmg   2. remove spActvTskNew (not BC)

1.9          ---  scc   1. added sccp management config flag
                           cfg.t.cfg.s.spGen.mngmntOn to 
                           spUnpkSpMiLspCfgReq 

1.10         ---  scc   1. added changes for ANSI 92 
             ---  scc   2. added changes for CCITT92 
                           (Unpack nmbXUdRefCb and nmbXUdCb)

1.11         ---  fmg   1. fixed parameter unpack order in UbndReq
             ---  fmg   2. added cm_ss7.? includes

1.12         ---  mjp   1. added unpack of dpc in spUnpkSpLiUdatInd function
             ---  mjp   2. changed all unpacking functions with macro
                           CMCHKUNPKLOG
             ---  mjp   3. changed all spUnpk functions to S16 due to 
                           CMCHKUNPKLOG
             ---  mjp   4. removed use of pst->selector to unpack in spUnpk*()
             ---  mjp   5. changed Void to S16 in all snUnpk functions
             ---  mjp   6. replaced previous error function with SPLOGERROR

1.13         ---  mjp   1. removed type parameter from spUnpkSpUiSptBndReq
             ---  mjp   2. add subService parameter to STNSAP in
                           spUnpkSpMiLspCfgReq.
             ---  mjp   3. unpack Qlen as U32 not S16
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.14         ---      ash  1. Changes for making SNT/SPT interfaces more 
                              robust under flag SPT2/SNT2
                           2. Fault tolerant SCCP changes
                           3. changed spActvTsk function to switch on 
                              srcEnt
                           4. Control request unpacking changed to support
                              group control request 
                           5. cm1.[hx] replaced by cm_hash.[hx]
                           6. Changes for debug TCO
             sp011.27      7. Unpacking for newly added niInd bit in 
                              network sap configuration          
                           8. Unpacking function spUnpkSpLiSntStaInd
                              should pass the priority instead of passing 0
                       cp  9. Moved all unpacking to common files as per
                              tco0001

/main/15     ---      cp  1. fixed NT compilation errors.
             ---      vb  1. Clean up of the patches
             ---      vb  2. Removed the Flow Control Primitive from SNT
                             interface

/main/17     ---      cp  1. DFTHA related mods.
             sp002    cp  2. Modified spActvTsk for CORE1 support.

            sp011.301 rc  1. Chenged entity of SUA NIF to ENTNP.
            sp014.301 rc  1. Rolling upgrade changes, under compile flag
                             SP_RUG as per tcr0020.txt:
                          -  Check on return value of unpacking primitive is
                             added for alarm indication to LM in case primitive
                             is received with invalid interface version number.
/main/17_1   ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302  rc   1. Sid correction
             sp007.302  rc   1. In spActvTsk, releasing mBuf and returning
                                failure in case of invalid event or src Ent.
             sp008.302  rc   1. Return value from PSF active task is not taken,
                                for, the PSF active task will always return ok.
             sp024.302  rc   1. Added support for BSSAP+ entity (ENTGA).
             sp047.302  sm   1. Added support for SCCP User entity (ENTSPU).
                             2. Added case for unit data service request.
*********************************************************************91*/
