/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     sccp - body 7
  
     Type:     C source file
  
     Desc:     C source code for portable SS7/SCCP GTT
  
     File:     cp_bdy7.c
  
     Sid:      cp_bdy7.c@@/main/3_1 - Tue Jan 22 15:17:46 2002
  
     Prg:      cp
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


/* external functions */

/* forward references */



/* 
 * support functions
 */

PUBLIC S16 ptGttInit ARGS((SpAssoCb *assoCb)); 
PUBLIC Size ptGttMemSize ARGS((U16 maxRules, U16 maxActns, U16 maxEntries));
/* sp045.302 - modification - replacing selfPc with ptr to network Cb 
 * returns ptr to outgoing network CB if incoming network is different
 * than outgoing network.
 */
PUBLIC S16 ptGttTrans ARGS((SpAssoCb *assoCb, SpAddr *inAddr, U8 pClass,
                            U8 *mode, U8 *numEntity, U8 *nextEntity,
                            SpAddr *outAddr, U8 *noCplng, SpNwCb *nwCb, 
                            SpNwCb **outNwCb));
PUBLIC S16 ptGttAdd ARGS((SpAssoCb *assoCb, SpAddrMapCfg *addrMap));
PUBLIC S16 ptGttDelete ARGS((SpAssoCb *assoCb, SpAddrMapCfg *addrMap));
PUBLIC S16 ptGttDeInit ARGS((SpAssoCb *assoCb));

#ifdef SP_PTTRFCOMP
/* function to compute traffic limitation data */
PUBLIC Void ptTrfCompute ARGS((SpRestrictLocal *rstLocal,
                               SpRestrictComp *rstComp, Dpc aDpc, NwId nwId));
#endif /* SP_PTTRFCOMP */
  
/* 
 * Mapping Tables for Trillium functions and Portable functions 
 */

GtFuncs ptFuncs = 
{
   &ptGttInit, &ptGttMemSize, &ptGttTrans, &ptGttAdd, &ptGttDelete, &ptGttDeInit
};

/* 
 * The portable GTT functions will be filled up by the customer.
 */


/*
 * 
 * Fun : ptGttInit
 *
 * Desc : This function initialises all the module controlled 
 *        fields in the Association Control Block. Like..
 *        - Database Pointer for each Action.
 *        It will also have to allocate all the memory required for the 
 *        databases. The actionCfg structure contains info about the 
 *        maxnumber of entries that will be configured for the database.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC S16 ptGttInit 
(
SpAssoCb *assoCb  /* Association Control Block */
)
#else
PUBLIC S16 ptGttInit (assoCb)
SpAssoCb *assoCb;  /* Association Control Block */
#endif 
{
   TRC2(ptGttInit);
   SPLOGERROR(ERRCLS_DEBUG, ESP360, (ErrVal) ERRZERO, "ptGttInit");
   RETVALUE(RFAILED);
} /* ptGttInit */


/*
 * 
 * Fun : ptGttMemSize
 *
 * Desc : The purpose of this function is to calculate the maximum memory 
 *        required for handling maxRules, maxActns and maxEntries. Our module 
 *        will have a database per rule (and not action). Memory requirements 
 *        arise for the following data structures.
 *        - maxRules number of CmHashListCp
 *        - maxEntries number of CmListEnt
 *
 * Returns: Memory required for maximal configuration.
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI 
PUBLIC Size ptGttMemSize 
(
U16 maxRules,  /* max number of Rules that will be handled */
U16 maxActns,  /* max number of actions that will be handled */
U16 maxEntries /* max number of Database entries */
)
#else
PUBLIC Size ptGttMemSize (maxRules, maxActns, maxEntries)
U16 maxRules;  /* max number of Rules that will be handled */
U16 maxActns;  /* max number of actions that will be handled */
U16 maxEntries;/* max number of Database entries */
#endif
{
   TRC2(ptGttMemSize);
   RETVALUE (0);
} /* ptGttMemSize */

/* sp045.302 - modification - replacing selfPc with ptr to network Cb */

/*
 * 
 * Fun : ptGttTrans
 *
 * Desc : This function is suppossed to look at the actions described 
 *        in the association control block in a _sequential_ manner. This is
 *        done till no more actions are left or a databsae entry is found.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC S16 ptGttTrans 
(
SpAssoCb *assoCb,   /* Association Control Block */
SpAddr *inAddr,     /* Incoming Address */
U8 pClass,           /* SCCP class of service */
U8 *mode,           /* mode of sccp entities */
U8 *numEntity,      /* number of sccp entities */
U8 *nextEntity,     /* next sccp entity to be selected */
SpAddr *outAddr,    /* Outgoing Address */
Bool *noCplng,      /* flag to indicate whether coupling of conn required */
SpNwCb *nwCb,       /* sp045.302 - modification - replacing selfPc with
                     * ptr to network Cb.
                     */
SpNwCb **outNwCb    /* sp045.302 - addition - ptr to network Cb of
                     * outgoing network.
                     */
)
#else
PUBLIC S16 ptGttTrans (assoCb, inAddr, pClass, mode, numEntity, nextEntity,
                        outAddr, noCplng, nwCb, outNwCb)
SpAssoCb *assoCb;    /* Association Control Block */
SpAddr *inAddr;      /* Incoming Address */
U8 pClass;           /* SCCP class of service */
U8 *mode;            /* mode of sccp entities */
U8 *numEntity;       /* number of sccp entities */
U8 *nextEntity;      /* next sccp entity to be selected */
SpAddr *outAddr;     /* Outgoing Address */
Bool *noCplng;       /* flag to indicate whether coupling of conn required */
SpNwCb *nwCb;        /* sp045.302 - modification - replacing selfPc with
                     * ptr to network Cb.
                     */
SpNwCb **outNwCb;    /* sp045.302 - addition - ptr to network Cb of
                     * outgoing network.
                     */
#endif
{
   TRC2(ptGttTrans);
   SPLOGERROR(ERRCLS_DEBUG, ESP361, (ErrVal) ERRZERO, "ptGttTrans");
   RETVALUE(RFAILED);
} /* ptGttTrans */


/*
 * 
 * Fun : ptGttAdd
 *
 * Desc : This function adds database entry. Before adding the database entry
 *        it will have to check if the action(in the addr map) exists
 *        for the the rule.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC S16 ptGttAdd 
(
SpAssoCb *assoCb,       /* Association Control Block */
SpAddrMapCfg *addrMap /* Address */
)
#else
PUBLIC S16 ptGttAdd (assoCb, addrMap)
SpAssoCb *assoCb;         /* Association Control Block */
SpAddrMapCfg *addrMap;  /* Address */
#endif
{
   TRC2(ptGttAdd);
   SPLOGERROR(ERRCLS_DEBUG, ESP362, (ErrVal) ERRZERO, "ptGttAdd");
   RETVALUE(RFAILED);
} /* ptGttAdd */


/*
 * 
 * Fun : ptGttDelete
 *
 * Desc : This function deletes database entry. Before deleting the 
 *        database entry it will have to check if the 
 *        action(in the addr map) exists for the the rule.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC S16 ptGttDelete
(
SpAssoCb *assoCb,        /* Association Control Block */
SpAddrMapCfg *addrMap    /* Address */
)
#else
PUBLIC S16 ptGttDelete (assoCb, addrMap)
SpAssoCb *assoCb;         /* Association Control Block */
SpAddrMapCfg *addrMap;    /* Address */
#endif
{
   TRC2(ptGttDelete);
   SPLOGERROR(ERRCLS_DEBUG, ESP363, (ErrVal) ERRZERO, "ptGttDelete");
   RETVALUE(RFAILED);
} /* ptGttDelete */


/*
 * 
 * Fun : ptGttDeInit
 *
 * Desc : The purpose of this function is to deallocate all teh memory 
 *        allocated for this Asociation control block
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC S16 ptGttDeInit
(
SpAssoCb *assoCb /* Association Control Block */
)
#else
PUBLIC S16 ptGttDeInit (assoCb)
SpAssoCb *assoCb;  /* Association Control Block */
#endif
{
   TRC2(ptGttDeInit);
   SPLOGERROR(ERRCLS_DEBUG, ESP364, (ErrVal) ERRZERO, "ptGttDeInit");
   RETVALUE(RFAILED);
} /* ptGttDeInit */

#ifdef SP_PTTRFCOMP

/*
 *
 *       Fun:   ptTrfCompute
 *
 *       Desc: This function computes traffic limitation data.
 *
 *       Ret: None.
 *       
 *       Notes: None.
 *
 *       File:  cp_bdy7.c
 *
 */
#ifdef ANSI
PUBLIC Void ptTrfCompute
(
SpRestrictLocal *rstLocal,  /* input restriction data */
SpRestrictComp *rstComp,    /* computed restriction data */
Dpc aDpc,                   /* dpc for which traffic limitation is computed */
NwId nwId                   /* network id */
)
#else
PUBLIC Void ptTrfCompute(rstLocal, rstComp, aDpc, nwId)
SpRestrictLocal *rstLocal;  /* input restriction data */
SpRestrictComp *rstComp;    /* computed restriction data */
Dpc aDpc;                   /* dpc for which traffic limitation is computed */
NwId nwId;                  /* network id */
#endif
{
   TRC2(ptTrfCompute);
   SPLOGERROR(ERRCLS_DEBUG, ESP365, (ErrVal) ERRZERO, "ptTrfCompute");
   RETVOID;
} /* ptTrfCompute */
#endif /* SP_PTTRFCOMP */


/********************************************************************30**
  
         End of file:     cp_bdy7.c@@/main/3_1 - Tue Jan 22 15:17:46 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      cp   1. Initial Release
             ---      vb   1. Clean up of the patches

/main/3      ---      cp   1. DFTHA related mods
/main/3_1    ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302  rc   1. Sid correction
             sp045.302  mc   1. Changing the prototype of ptGttTrans, replacing
                                self pc with ptr to network Cb.
                                also passing ptr to outgoing network CB.
                                function returns ptr to outgoing network CB if
                                network id of incoming and outgoing
                                network is different.
*********************************************************************91*/
