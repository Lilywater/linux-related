
/**********************************************************************
 
     Name:     sp_dbg.c - Debug print for SCCP
  
     Type:     C source file
  
     Desc:     C code for SCCP debug print
  
     File:     sp_dbg.c
  
     Sid:      sp_dbg.c
  
     Prg:      wanglijun  
**********************************************************************/


/************************************************************************

  
/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm_lib.x"
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

#include "clishell.h"
#include "sp_dbg.h"
#include "oam_public_data_def.h"
#include "sp_oam.x"
#include "xosshell.h"
#include "cp_tab_def.h"

#ifdef SSI_WITH_CLI_ENABLED
#ifdef CP_OAM_SUPPORT
EXTERN unsigned char spDynCfgCallback(unsigned int tableid, unsigned short msgtype, unsigned int sequence, unsigned char pack_end, tb_record *prow);
#endif
/***************************************************************************
*
* Interface Functions to OAM
*
***************************************************************************/
VOID spDbgShow(CLI_ENV *pCliEnv, XS32 Argc, XCHAR**ppArgv)
{
    SPrint("\n test in spDbgShow func. \n");
}

VOID spDbgControl(CLI_ENV *pCliEnv, XS32 Argc, XCHAR **ppArgv)
{
    SPrint("\n test in spDbgControl func. \n");
}

/************************************************************/
/*****       Functions: set sccp debug mask                                   ******/
/************************************************************/
void spSetDbgMask(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  SpCb *lSpCb = &spCb;
  XU32 dbgmask;
  S8   *stopstring;


  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  dbgmask = (XU32)strtoul( ppArgv[1], &stopstring, 0 );

  lSpCb->spInit.dbgMask = dbgmask;
  
  RETVOID;
}


/************************************************************/
/*****       Functions: get sccp debug mask                                   ******/
/************************************************************/
void spGetDbgMask(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  SpCb *lSpCb = &spCb;


  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  XOS_CliExtPrintf(pCliEnv,"-----------DbgMask Info-----------\r\n");

  if(lSpCb->spInit.dbgMask == 0)
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:0x%x\r\n","debugMask",lSpCb->spInit.dbgMask);
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:0x%x, ","debugMask",lSpCb->spInit.dbgMask);
    cmPrintXDbgmsk(pCliEnv, lSpCb->spInit.dbgMask);
  }
  
  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp control block                                   ******/
/************************************************************/
void spPrintSpCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  SpCb *lSpCb = &spCb;

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  XOS_CliExtPrintf(pCliEnv, "-----------General Info-----------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbRtes",lSpCb->nmbRtes);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbNws",lSpCb->nmbNws);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbSaps",lSpCb->nmbSaps);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbNSaps",lSpCb->nmbNSaps);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbAsso",lSpCb->nmbAsso);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbActns",lSpCb->nmbActns);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbAddrs",lSpCb->nmbAddrs);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","curAsso",lSpCb->curAsso);
  XOS_CliExtPrintf(pCliEnv,"%-20s:","status");
  spPrintSpStatus(pCliEnv, lSpCb->status);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d \r\n","ustaMask", lSpCb->ustaMask);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d \r\n","spTrfLimFlag", lSpCb->spTrfLimFlag);
#ifdef SP_CFGMG
  /* Flag to turn on/off SCCP (not layer) management */
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","mngmntOn",lSpCb->mngmntOn);
#endif /* SP_CFGMG */
#ifdef ZP
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d \r\n","conUpdFlg", lSpCb->conUpdFlg);
#endif /* ZP */

#if 0
  /* SCCP Global Timers e.g. Guard */
  XOS_CliExtPrintf(pCliEnv, "-----------Global Timer-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &lSpCb->tmr);
#endif

  XOS_CliExtPrintf(pCliEnv, "-----------Task Init Info-----------\r\n");
  cmPrintXTskInit(pCliEnv, &lSpCb->spInit);

    RETVOID;
}

/************************************************************/
/*****       Functions: Print sccp general config                                 ******/
/************************************************************/
void spPrintGenCfg(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  SpGenCfg *cfg = &spCb.spCfg;

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  XOS_CliExtPrintf(pCliEnv, "-----------General Config Info-----------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbNws",cfg->nmbNws);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbSaps",cfg->nmbSaps);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbNSaps",cfg->nmbNSaps);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbAsso",cfg->nmbAsso);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbActns",cfg->nmbActns);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbAddrs",cfg->nmbAddrs);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbRtes",cfg->nmbRtes);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbXUdCb",cfg->nmbXUdCb);

#ifdef SP_CFGMG
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","mngmntOn",cfg->mngmntOn);
#endif /* SP_CFGMG */

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","sogThresh",cfg->sogThresh);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssnTimeRes",cfg->ssnTimeRes);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","AsmbTimeRes",cfg->AsmbTimeRes);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","recTimeRes",cfg->recTimeRes);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","maxRstLvl",cfg->maxRstLvl);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","maxRstSubLvl",cfg->maxRstSubLvl);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","atkDecTimeRes",cfg->atkDecTimeRes);

#ifdef SPCO
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbCon",cfg->nmbCon);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","conThresh",cfg->conThresh);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","queThresh",cfg->queThresh);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","itThresh",cfg->itThresh);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","conTimeRes",cfg->conTimeRes);

  XOS_CliExtPrintf(pCliEnv, "-----------defGuaTmr Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &cfg->defGuaTmr);
#endif /* SPCO */

  XOS_CliExtPrintf(pCliEnv, "-----------defRstEndTmr Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &cfg->defRstEndTmr);

  XOS_CliExtPrintf(pCliEnv, "-----------tIntTmr Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &cfg->tIntTmr);

#ifdef SNT2
  XOS_CliExtPrintf(pCliEnv, "-----------defStatusEnqTmr Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &cfg->defStatusEnqTmr);
#endif 

  RETVOID;
}

/************************************************************/
/*****       Functions: Print sccp network block                                   ******/
/************************************************************/
void spPrintNwCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  XU32 i;

  NwId  nwId;
  

  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  if((cmStrcmp(ppArgv[1], "all")) != 0)
  {
    nwId = (NwId) atoi(ppArgv[1]);
    if((nwId <= spCb.nmbNws) && (nwId != 0))
    {
      spPrintOneNwCb(pCliEnv, --nwId);
    }
    else
    {
      XOS_CliExtPrintf(pCliEnv, "nwIndex(%d) , nmbNws(%d), please input correct nwIndex. \r\n", nwId, spCb.nmbNws);
    }
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Number of Nwcb is :%d\r\n",spCb.nmbNws);
    
    for(i = 0;i < spCb.nmbNws; i++)
    {
      spPrintOneNwCb(pCliEnv, (NwId)i);
    }
  }

  RETVOID;  
}

/************************************************************/
/*****       Functions: Print sccp one network block                            ******/
/************************************************************/
void spPrintOneNwCb(CLI_ENV *pCliEnv, NwId nwId)
{
  SpNwCb *nw=NULLP;
  U8 tmpStr[20];
#ifndef ZP
#ifdef SPCO
  XU32 i;
#endif /* SPCO */
#endif /* ZP */
    
  if(nwId <= spCb.nmbNws)
  {
    nw = spCb.nwList[nwId];
  }
  if (nw == NULLP)
  {
    XOS_CliExtPrintf(pCliEnv, "NwCb: id(%d) ,nmbNws(%d) , nwCb is NULLP!\r\n", 
        nwId, spCb.nmbNws);
    RETVOID;
  }
  
  XOS_CliExtPrintf(pCliEnv, "\n********************NwCb%d******************\r\n", nwId);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nwId",nw->nwId);
  spGetVariantStr(nw->variant, tmpStr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","switch",tmpStr);
  spGetPcLenStr(nw->pcLen, tmpStr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","pcLen",tmpStr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","selfPc",nw->selfPc);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","sInfo",nw->sInfo);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","defHopCnt",nw->defHopCnt);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","niInd",nw->niInd);
  
#ifndef ZP
#ifdef SPCO
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n", "nmbLclRef",nw->nmbLr);
  if(nw->nmbLr != 0)
  {
    XOS_CliExtPrintf(pCliEnv, "---------------Local Reference Info----------------\r\n");
    XOS_CliExtPrintf(pCliEnv, "lclRefId fflag nwId tmrEnb tmrVal conkeyFlag conkeyVal\r\n");
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------\r\n");
    for(i = 0; i < nw->nmbLr; i++)
    {
      XOS_CliExtPrintf(pCliEnv, "%-8d", i);
      spPrintLclRef(pCliEnv, &nw->lclRef[i]);
    }
    XOS_CliExtPrintf(pCliEnv, "----------------------------------------------\r\n");
  }
#endif /* SPCO */
#endif /* ZP */

  XOS_CliExtPrintf(pCliEnv, "--------------Timer Info-------------\r\n");
  XOS_CliExtPrintf(pCliEnv, "    timer      enable   value\r\n");
  XOS_CliExtPrintf(pCliEnv, "------------------------------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","sst",(nw->defSstTmr.enb?"TRUE":"FALSE"), nw->defSstTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","ignore",(nw->defIgnTmr.enb?"TRUE":"FALSE"), nw->defIgnTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","coordinate",(nw->defCrdTmr.enb?"TRUE":"FALSE"), nw->defCrdTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","assemble",(nw->defAsmbTmr.enb?"TRUE":"FALSE"), nw->defAsmbTmr.val);
#ifdef SPCO
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","freeze",(nw->defFrzTmr.enb?"TRUE":"FALSE"), nw->defFrzTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","connection",(nw->defConTmr.enb?"TRUE":"FALSE"), nw->defConTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","ias",(nw->defIasTmr.enb?"TRUE":"FALSE"), nw->defIasTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","iar",(nw->defIarTmr.enb?"TRUE":"FALSE"), nw->defIarTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","release",(nw->defRelTmr.enb?"TRUE":"FALSE"), nw->defRelTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","repeat release",(nw->defRepRelTmr.enb?"TRUE":"FALSE"), nw->defRepRelTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","interval",(nw->defIntTmr.enb?"TRUE":"FALSE"), nw->defIntTmr.val);
  XOS_CliExtPrintf(pCliEnv, "%-15s %-5s    %-5d\r\n","reset",(nw->defRstTmr.enb?"TRUE":"FALSE"), nw->defRstTmr.val);
#endif
  XOS_CliExtPrintf(pCliEnv, "------------------------------\r\n");

  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp sap block                                       ******/
/************************************************************/
void spPrintSapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  XU32 i;

  XCHAR sapId;
  
  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  if((cmStrcmp(ppArgv[1], "all")) != 0)
  {
    sapId = (XCHAR)atoi(ppArgv[1]);
    sapId--;
    if((sapId < spCb.nmbSaps) && (sapId >= 0))
    {
      spPrintOneSapCb(pCliEnv, (SpId)sapId);
    }
    else
    {
      XOS_CliExtPrintf(pCliEnv, "sapIndex(%d), nmbSaps(%d),  please input correct sapIndex.\r\n", sapId, spCb.nmbSaps);
    }
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Number of SapCb is :%d\r\n",spCb.nmbSaps);
    
    for(i = 0;i < spCb.nmbSaps; i++)
    {
      spPrintOneSapCb(pCliEnv, (SpId)i);
    }
  }

  RETVOID;  
}


/************************************************************/
/*****       Functions: Print sccp one sap block                                  ******/
/************************************************************/
void spPrintOneSapCb(CLI_ENV *pCliEnv, SpId spId)
{
  SpSapCb *sap = NULLP;
  U8 tmpStr[20];
    
  if(spId <= spCb.nmbSaps)
  {
    sap = spCb.sapList[spId];
  }
  if (sap == NULLP)
  {
    XOS_CliExtPrintf(pCliEnv, "SapId(%d) ,nmbSaps(%d) , SapCb is NULLP!\r\n", 
        spId, spCb.nmbSaps);
    RETVOID;
  }
  
  XOS_CliExtPrintf(pCliEnv, "\n*****************SapCb%d***************\r\n", spId);
  XOS_CliExtPrintf(pCliEnv,"-----------SapCb Post Info-----------\r\n");
  cmPrintXPostInfo(pCliEnv, &sap->pst);
  
  XOS_CliExtPrintf(pCliEnv,"-----------SapCb General Info-----------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","spId",sap->spId);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","suId",sap->suId);
  
  XOS_CliExtPrintf(pCliEnv, "%-20s:","status");
  spPrintSapNSapStatus(pCliEnv, sap->status);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssn",sap->ssn);
#if 0
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbBpc",sap->nmbBpc);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbConPc",sap->nmbConPc);
#endif

  if(sap->nwData)
  {
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nwId",sap->nwData->nwId);
    spGetVariantStr(sap->nwData->variant, tmpStr);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","Switch",tmpStr);
  }
  
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","aSsn",sap->aSsn);
  XOS_CliExtPrintf(pCliEnv, "%-20s:0x%x \r\n","sorPc",sap->sorPc);
  
#if 0   
  XOS_CliExtPrintf(pCliEnv, "-----------Sap Timer Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &sap->tmr);
#endif

  RETVOID;  
}


/************************************************************/
/*****       Functions: Print sccp nsap block                                       ******/
/************************************************************/
void spPrintNSapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  XU32 i;

  XCHAR nsapId;
  
  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }


  if((cmStrcmp(ppArgv[1], "all")) != 0)
  {
    nsapId = (XCHAR) atoi(ppArgv[1]);
    nsapId--;
    if((nsapId < spCb.nmbNSaps) && (nsapId >= 0))
    {
      spPrintOneNSapCb(pCliEnv, (SuId)nsapId);
    }
    else
    {
      XOS_CliExtPrintf(pCliEnv, "nsapIndex(%d), nmbNSaps(%d),  please input correct nsapIndex.\r\n", nsapId, spCb.nmbNSaps);
    }
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Number of NSapCb is :%d\r\n",spCb.nmbNSaps);
    
    for(i = 0; i < spCb.nmbNSaps; i++)
    {
      spPrintOneNSapCb(pCliEnv, (SuId)i);
    }
  }

  RETVOID;  
}


/************************************************************/
/*****       Functions: Print sccp one nsap block                                  ******/
/************************************************************/
void spPrintOneNSapCb(CLI_ENV *pCliEnv, SuId suId)
{
  SpNSapCb *nsap = NULLP;
  U8 tmpStr[20];
    
  if(suId <= spCb.nmbNSaps)
  {
    nsap = spCb.nSapList[suId];
  }
  if (nsap == NULLP)
  {
    XOS_CliExtPrintf(pCliEnv, "NSapId(%d), nmbNSaps(%d) , NsapCb is NULLP!\r\n", 
        suId, spCb.nmbNSaps);
    RETVOID;
  }
  
  XOS_CliExtPrintf(pCliEnv, "\n*****************NSapCb%d***************\r\n", suId);
  XOS_CliExtPrintf(pCliEnv,"-----------NSapCb Post Info-----------\r\n");
  cmPrintXPostInfo(pCliEnv, &nsap->pst);
  
  XOS_CliExtPrintf(pCliEnv,"-----------NSapCb General Info-----------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","suId",nsap->suId);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","spId",nsap->spId);
  XOS_CliExtPrintf(pCliEnv, "%-20s:","status");
  spPrintSapNSapStatus(pCliEnv, nsap->status);

  if(nsap->nwData)
  {
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nwId",nsap->nwData->nwId);
    spGetVariantStr(nsap->nwData->variant, tmpStr);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","Switch",tmpStr);
  }

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","trc",nsap->trc);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgLen",nsap->msgLen);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","contEnt",nsap->contEnt);
#ifdef SNT2
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","bndRetryCnt",nsap->bndRetryCnt);
#endif /* SNT2 */

#if 0
  XOS_CliExtPrintf(pCliEnv, "-----------NSap Timer Info-----------\r\n");
  cmPrintXTmrCfg(pCliEnv, &nsap->tmr);
#endif

  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp gt association control block               ******/
/************************************************************/
void spPrintGtAssoCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  XU32 i;

  XCHAR gtAssoId;
  

  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  if((cmStrcmp(ppArgv[1], "all")) != 0)
  {
    gtAssoId = (XCHAR) atoi(ppArgv[1]);
    if((gtAssoId <= spCb.nmbAsso) && (gtAssoId != 0))
    {
      spPrintOneGtAssoCb(pCliEnv, --gtAssoId);
    }
    else
    {
      XOS_CliExtPrintf(pCliEnv, "ruleId(%d), nmbRule(%d),  please input correct ruleId.\r\n", gtAssoId, spCb.nmbAsso);
    }
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Number of gt rule is :%d\r\n",spCb.nmbAsso);
    
    for(i = 0;i < spCb.nmbAsso; i++)
    {
      spPrintOneGtAssoCb(pCliEnv, (XCHAR) i);
    }
  }

  RETVOID;  
}


/************************************************************/
/*****       Functions: Print sccp one gt association control block         ******/
/************************************************************/
void spPrintOneGtAssoCb(CLI_ENV *pCliEnv, XCHAR gtAssoId)
{
  SpAssoCb *asso = NULLP;
  U8 tmpStr[20];
    
  if(gtAssoId < spCb.nmbAsso)
  {
    asso = spCb.assoList[gtAssoId];
  }
  if (asso == NULLP)
  {
    XOS_CliExtPrintf(pCliEnv, "ruleId(%d) , nmbRule(%d) , gtRuleCb is NULL!\r\n", 
        gtAssoId, spCb.nmbAsso);
    RETVOID;
  }

  XOS_CliExtPrintf(pCliEnv, "\n*****************GtRule%d***************\r\n", gtAssoId+1);
  XOS_CliExtPrintf(pCliEnv,"-----------Gt Rule Info-----------\r\n");
  spGetVariantStr(asso->rule.sw, tmpStr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","switch",tmpStr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","formatPres",asso->rule.formatPres);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","format",asso->rule.format);
  
  if(GTFRMT_4 == asso->rule.format)
  {
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","tTypePres",asso->rule.gt.f4.tTypePres);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","tType",asso->rule.gt.f4.tType);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","numPlanPres",asso->rule.gt.f4.numPlanPres);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","numPlan",asso->rule.gt.f4.numPlan);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","encSchPres",asso->rule.gt.f4.encSchPres);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","encSch",asso->rule.gt.f4.encSch);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","natAddrPres",asso->rule.gt.f4.natAddrPres);
    XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","natAddr",asso->rule.gt.f4.natAddr);
  }

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","replGt",asso->actnCb[0].replGt);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","startDigit",asso->actnCb[0].actn.param.range.startDigit);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","endDigit",asso->actnCb[0].actn.param.range.endDigit);
#if 0
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","nmbEntries",asso->nmbEntries);
#endif

  RETVOID;
}




/************************************************************/
/*****       Functions: Print sccp all gt address map control block                           ******/
/************************************************************/
void spPrintGtAddrMapCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  SpAssoCb *asso = NULLP;
  SpAddrMapCfg *addrMap = NULLP;    /* Address */
  DEntry *dEntry;        /* data base entry to store */
  PTR hl;            /* hash list entry */
  XU32 i = 0, j = 0, k = 0, count = 0;
  XS16 ret;               /* return value */
  U8 tmpStr[20];

  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  if((cmStrcmp(ppArgv[1], "all")) == 0)
  {
    for(i = 0;i < spCb.nmbAsso; i++)
    {
      asso = spCb.assoList[i];
      if (NULLP == asso)
      {
        XOS_CliExtPrintf(pCliEnv, "ruleId(%d) , nmbRule(%d) , gtRuleCb is NULLP!\r\n", 
            i, spCb.nmbAsso);
        continue;
      }

      hl = (PTR) NULLP;
      for(j = 0; j < asso->nmbActns; j++)
      {
        while (1)
        {
          if ((ret = cmHashListGetNext((CmHashListCp *)asso->dataFix, hl, (PTR *) &dEntry)) == ROK)
          {
            hl = (PTR) dEntry;

            XOS_CliExtPrintf(pCliEnv, "\n*******************GtAddr%d***************\r\n", count+1);
            XOS_CliExtPrintf(pCliEnv, "%-20s:","InGtAddr");
            
            for(k = 0; k < dEntry->gtKey.addr.length; k++)
            {
              XOS_CliExtPrintf(pCliEnv, "%x%x", (dEntry->gtKey.addr.strg[k] & 0x0f), ((dEntry->gtKey.addr.strg[k] & 0xf0) >> 4) );
            }

            XOS_CliExtPrintf(pCliEnv, "\r\n");
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","startDigit",dEntry->gtKey.startDigit);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","endDigit",dEntry->gtKey.endDigit);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","pcInd",dEntry->outAddr[0].pcInd);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","pc",dEntry->outAddr[0].pc);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssnInd",dEntry->outAddr[0].ssnInd);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssn",dEntry->outAddr[0].ssn);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssfPres",dEntry->outAddr[0].ssfPres);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","ssf",dEntry->outAddr[0].ssf);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","niInd",dEntry->outAddr[0].niInd);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rtgInd",dEntry->outAddr[0].rtgInd);
            XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","replGt",dEntry->replGt);

            if((RTE_GT == dEntry->outAddr[0].rtgInd) && (FALSE == dEntry->replGt))
            {
              spGetVariantStr(dEntry->outAddr[0].sw, tmpStr);
              XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","outSwitch",tmpStr);
              XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","outGtType",dEntry->outAddr[0].gt.gt.f4.tType);
              XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","outGtNumPlan",dEntry->outAddr[0].gt.gt.f4.numPlan);
              XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","outGtEncSch",dEntry->outAddr[0].gt.gt.f4.encSch);
              XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","outGtNatAddr",dEntry->outAddr[0].gt.gt.f4.natAddr);
              XOS_CliExtPrintf(pCliEnv, "%-20s:","outGtAddr");
              
              for(k = 0; k < dEntry->outAddr[0].gt.addr.length; k++)
              {
                XOS_CliExtPrintf(pCliEnv, "%x%x", (dEntry->outAddr[0].gt.addr.strg[k] & 0x0f), ((dEntry->outAddr[0].gt.addr.strg[k] & 0xf0) >> 4) );
              }
              XOS_CliExtPrintf(pCliEnv, "\r\n");
            }
            count++;
          }
          else
          {
             /* no more entries */
             break;
          }
        }
      }
    }
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Parameter only support \"all\".\r\n");
  }

  RETVOID;
}


/************************************************************/
/*****       Functions: Print sccp all route control block                      ******/
/************************************************************/
void spPrintRteCb(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  PTR hl;            /* hash list entry */
  SpRteCb *rteCb;      /* route control block */
  XS16  ret;           /* return value */
  XU32 i = 0, j = 0;
  U8 tmpStr[20];

  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 2)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }


  if((cmStrcmp(ppArgv[1], "all")) == 0)
  {
    hl = (PTR) NULLP;
    for (;;)
    {
      if ((ret = cmHashListGetNext(&spCb.rteHlCp, hl, (PTR *) &rteCb)) == ROK)
      {
        hl = (PTR) rteCb;
        
        XOS_CliExtPrintf(pCliEnv, "\n*******************Route%d***************\r\n", i+1);

        spGetSwTypeStr(rteCb->swtch, tmpStr);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","switch",tmpStr);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","dpc",rteCb->dpc);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","spId",rteCb->nSap->spId);

        XOS_CliExtPrintf(pCliEnv, "%-20s:","status");
        spPrintRteStatus(pCliEnv, rteCb->status);
#if 0
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","flag",rteCb->flag);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","replicatedMode",rteCb->replicatedMode);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","sls",rteCb->sls);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","slsMask",rteCb->slsMask);
#endif
        spGetSccpStsStr(rteCb->sccpSts, tmpStr);
        XOS_CliExtPrintf(pCliEnv, "%-20s:%s \r\n","sccpSts",tmpStr);

        for(j = 0;j < rteCb->nmbSsns; j++)
        {
          XOS_CliExtPrintf(pCliEnv, "ssn%-17d:%d \r\n", (j+1) ,rteCb->ssnList[j].ssn);
          if(rteCb->ssnList[j].status & SS_ACC)
          {
            XOS_CliExtPrintf(pCliEnv, "ssn%d %-15s:%s \r\n",(j+1), "status" ,"SS_ACC");
          }
          else
          {
            XOS_CliExtPrintf(pCliEnv, "ssn%d %-15s:%s \r\n",(j+1), "status" ,"SS_INACC");
          }
        }
        i++;
      }
      else
      {
         /* no more entries */
         break;
      }
    } /* for (;;) */
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "Parameter only support \"all\".\r\n");
  }


  RETVOID;
}



/************************************************************/
/*****       Functions: Print sccp local reference                                ******/
/************************************************************/
#ifndef ZP
#ifdef SPCO
void spPrintLclRef(CLI_ENV *pCliEnv, SpLclRef *ref)
{
  XOS_CliExtPrintf(pCliEnv, "%-5d ", ref->fflag);
  
  if(ref->nwData)
    XOS_CliExtPrintf(pCliEnv, "%-4d ",ref->nwData->nwId);
  else
    XOS_CliExtPrintf(pCliEnv, "%-4s ","NULL");

    XOS_CliExtPrintf(pCliEnv, "%-6s %-6d ",(ref->tmr.enb?"TRUE":"FALSE"), ref->tmr.val);
  
  if(ref->cb)
    spPrintSpConKey(pCliEnv, &ref->cb->key);
  else 
    XOS_CliExtPrintf(pCliEnv, "%-5s %s","NULL ", "NULL");

  RETVOID;
}
#endif /* SPCO */
#endif /* ZP */


/************************************************************/
/*****       Functions: Print sccp connection control block key              ******/
/************************************************************/
void spPrintSpConKey(CLI_ENV *pCliEnv, SpConKey *key)
{
  if(key == NULLP)
    RETVOID;
  XOS_CliExtPrintf(pCliEnv, "%-5d ", key->flags);
  if(key->flags & CG_KEY)
  {
    XOS_CliExtPrintf(pCliEnv, "%d\r\n", key->k1.cgPc);
  }
  if(key->flags & CD_KEY)
  {
    XOS_CliExtPrintf(pCliEnv, "%d\r\n", key->k2.cdPc);
  }
  if(key->flags & SU_KEY)
  {
    XOS_CliExtPrintf(pCliEnv, "%d+%d\r\n", 
        key->k3.spInstId, key->k3.suId);
  }

  RETVOID;
}


void cmPrintXPostInfo(CLI_ENV *pCliEnv, Pst *pst)
{
  if (pst == NULLP)
    RETVOID;

  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "dstProcId", pst->dstProcId);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "srcProcId", pst->srcProcId);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "dstEnt", pst->dstEnt);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "dstInst", pst->dstInst);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "srcEnt", pst->srcEnt);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "srcInst", pst->srcInst);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "prior", pst->prior);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "route", pst->route);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "event", pst->event);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "region", pst->region);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "pool", pst->pool);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "selector", pst->selector);

  RETVOID;
}



/************************************************************/
/*****       Functions: Print sccp timer value                                     ******/
/************************************************************/
void cmPrintXTmrCfg(CLI_ENV *pCliEnv, TmrCfg *cfg)
{
  if (cfg == NULLP)
    RETVOID;

  XOS_CliExtPrintf(pCliEnv, "%-20s:%s\r\n", "enable", (cfg->enb ? "TRUE" : "FALSE"));
  
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d\r\n", "value", cfg->val);
  RETVOID;
}

void cmPrintXTskInit(CLI_ENV *pCliEnv, TskInit *init)
{
  if (init == NULLP)
      RETVOID;
  
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","ent", init->ent);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","inst",init->inst);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","region",init->region);

  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","pool", init->pool);
  
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "reason",init->reason);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%s\r\n","cfgDone",(init->cfgDone)?"TRUE":"FALSE");
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","acnt",init->acnt);

  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","usta", init->usta);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n","trc",init->trc);
  
#if 0 
#ifdef DEBUGP

  XOS_CliExtPrintf(pCliEnv,"-----------DbgMask Info-----------\r\n");

  if(init->dbgMask == 0)
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:0x%x\r\n","debugMask",init->dbgMask);
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:0x%x, ","debugMask",init->dbgMask);
    cmPrintXDbgmsk(pCliEnv, init->dbgMask);
  }
#endif  
#endif

  XOS_CliExtPrintf(pCliEnv,"-----------Bind Config Info-----------\r\n");
  cmPrintXBndCfg(pCliEnv, &init->lmBnd);
  
  XOS_CliExtPrintf(pCliEnv,"-----------Layer Management Post-----------\r\n");
  cmPrintXPostInfo(pCliEnv, &init->lmPst);
}

void cmPrintXBndCfg(CLI_ENV *pCliEnv, BndCfg *cfg)
{
  if (cfg == NULLP)
    return;
  if (cfg->usrId != NULLP)
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:%s\r\n", "usrId", cfg->usrId);
  }

  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "bufOwnshp", cfg->bufOwnshp);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "flcTyp",cfg->flcTyp);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "wdw", cfg->wdw);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "ent", cfg->ent);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "inst", cfg->inst);

  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "region", cfg->region);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "pool", cfg->pool);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "prior", cfg->prior);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "route", cfg->route);
  XOS_CliExtPrintf(pCliEnv,"%-20s:%d\r\n", "selector", cfg->selector);

  
  if (cfg->sapAdr.length > 0)
  {
    XOS_CliExtPrintf(pCliEnv,"%-20s:%s\r\n", "sapAddr", cfg->sapAdr.strg);
  }

}

#ifdef DEBUGP
Void cmPrintXDbgmsk(CLI_ENV *pCliEnv, U32 mask)
{
  Bool enable=FALSE;
  if (mask & DBGMASK_SI)
  {
    XOS_CliExtPrintf(pCliEnv, "SI-");
    enable=TRUE;
  }
  if (mask & DBGMASK_MI)
  {
    XOS_CliExtPrintf(pCliEnv, "MI-");
    enable=TRUE;
  }
  if (mask & DBGMASK_UI)
  {
    XOS_CliExtPrintf(pCliEnv, "UI-");
    enable=TRUE;
  }
  if (mask & DBGMASK_LI)
  {
    XOS_CliExtPrintf(pCliEnv, "LI-");
    enable=TRUE;
  }
  if (mask & DBGMASK_PI)
  {
    XOS_CliExtPrintf(pCliEnv, "PI-");
    enable=TRUE;
  }
  if (mask & DBGMASK_PLI)
  {
    XOS_CliExtPrintf(pCliEnv, "PLI-");
    enable=TRUE;
  }
  if (enable)
    XOS_CliExtPrintf(pCliEnv, "DEBUG_ENABLED!\r\n");
}
#endif/*DEBUGP*/


void spPrintGLBSts(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
   SpGLBSts *sts = &spCb.sts;

  if (NULLP == pCliEnv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }

  XOS_CliExtPrintf(pCliEnv, "------------- General Statistic -------------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgHand",sts->msgHand);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgLoc",sts->msgLoc);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","gttReq",sts->gttReq);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgTxC0",sts->msgTxC0);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgTxC1",sts->msgTxC1);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgRxC0",sts->msgRxC0);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","msgRxC1",sts->msgRxC1);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","uDataTx",sts->uDataTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","uDataSrvTx",sts->uDataSrvTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","uDataRx",sts->uDataRx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","uDataSrvRx",sts->uDataSrvRx);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","xuDataTx",sts->xuDataTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","xuDataSrvTx",sts->xuDataSrvTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","xuDataRx",sts->xuDataRx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","xuDataSrvRx",sts->xuDataSrvRx);

#ifdef SS7_ITU96
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","luDataTx",sts->luDataTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","luDataSrvTx",sts->luDataSrvTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","luDataRx",sts->luDataRx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","luDataSrvRx",sts->luDataSrvRx);
#endif /* SS7_ITU96 */

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","segErr",sts->segErr);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","reassemErr",sts->reassemErr);

#ifdef SPCO
  XOS_CliExtPrintf(pCliEnv, "\n------------- Connection Oriented Statistic -------------\r\n");

#ifdef LSPV2_2
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","numConn",sts->numConn);
#endif
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","crTx",sts->crTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","crRx",sts->crRx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rsrTx",sts->rsrTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rsrRx",sts->rsrRx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","errTx",sts->errTx);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","errRx",sts->errRx);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rlsCmpFail",sts->rlsCmpFail);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","TiarExpiry",sts->TiarExpiry);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","prvInitReset",sts->prvInitReset);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","prvInitRel",sts->prvInitRel);
#endif /* SPCO */

  XOS_CliExtPrintf(pCliEnv, "\n----------- Routing Failure Statistic -----------\r\n");
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfNTASN",sts->rfNTASN);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfNTSA",sts->rfNTSA);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfNetFail",sts->rfNetFail);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfNetCong",sts->rfNetCong);

  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfSsnFail",sts->rfSsnFail);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfSsnCong",sts->rfSsnCong);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfUnequip",sts->rfUnequip);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfHopViolate",sts->rfHopViolate);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","synError",sts->synError);
  XOS_CliExtPrintf(pCliEnv, "%-20s:%d \r\n","rfUnknown",sts->rfUnknown);

  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
#ifdef CP_OAM_SUPPORT
void spAddGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtRuleTab   spGtRuleCfg;

  tb_record * prow = &row;
  SpCfgGtRuleTab   *pspGtRuleCfg = &spGtRuleCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  msgtype = SA_INSERT_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  
  pspGtRuleCfg->RuleId = 4;
  pspGtRuleCfg->NwId = 1;
  pspGtRuleCfg->GtFormat = 4;
  pspGtRuleCfg->TransType = 4;
  pspGtRuleCfg->NumberPlan = 1;
  pspGtRuleCfg->NatAddrInd= 1;
  pspGtRuleCfg->StartDigit = 1;
  pspGtRuleCfg->EndDigit = 16;

  prow->panytbrow = (void *)pspGtRuleCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);

  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spDelGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtRuleTab   spGtRuleCfg;


  tb_record * prow = &row;
  SpCfgGtRuleTab   *pspGtRuleCfg = &spGtRuleCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  msgtype = SA_DELETE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0X1;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  
  pspGtRuleCfg->RuleId = 3;

  prow->panytbrow = (void *)pspGtRuleCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}




/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spModGtRule(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtRuleTab   spGtRuleCfg;


  tb_record * prow = &row;
  SpCfgGtRuleTab   *pspGtRuleCfg = &spGtRuleCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  msgtype = SA_UPDATE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0x11;
  prow->head.col_count = 2;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_RULE;
  
  pspGtRuleCfg->RuleId = 2;
  pspGtRuleCfg->TransType = 11;

  prow->panytbrow = (void *)pspGtRuleCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spAddGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtAddressTab spGtAddrCfg;

  tb_record * prow = &row;
  SpCfgGtAddressTab   *pspGtAddrCfg = &spGtAddrCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  msgtype = SA_INSERT_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  
  pspGtAddrCfg->GtId = 4;
  pspGtAddrCfg->NwId = 1;
  pspGtAddrCfg->InRuleId =1;
  pspGtAddrCfg->StartDigit = 1;
  pspGtAddrCfg->EndDigit = 14;
  pspGtAddrCfg->InGtAddr[0] = '1';
  pspGtAddrCfg->InGtAddr[1] = '2';
  pspGtAddrCfg->InGtAddr[2] = '3';
  pspGtAddrCfg->InGtAddr[3] = '4';
  pspGtAddrCfg->InGtAddr[4] = 'a';
  pspGtAddrCfg->InGtAddr[5] = 'a';
  pspGtAddrCfg->InGtAddr[6] = 0;
  pspGtAddrCfg->SsfInd = 1;
  pspGtAddrCfg->Ssf = 1;
  pspGtAddrCfg->NiInd= 0;
  pspGtAddrCfg->RteInd = 0;
  pspGtAddrCfg->SpcInd = 0;
  pspGtAddrCfg->SpcIndex = 1;
  pspGtAddrCfg->SsnInd = 0;
  pspGtAddrCfg->Ssn = 6;
  pspGtAddrCfg->OutRuleId = 1;
  pspGtAddrCfg->OutGtAddr[32] = "222";
  pspGtAddrCfg->ReplGt = 1;

  prow->panytbrow = (void *)pspGtAddrCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spDelGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtAddressTab spGtAddrCfg;

  tb_record * prow = &row;
  SpCfgGtAddressTab   *pspGtAddrCfg = &spGtAddrCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  msgtype = SA_DELETE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0X1;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  
  pspGtAddrCfg->GtId = 3;

  prow->panytbrow = (void *)pspGtAddrCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);

  RETVOID;
}

/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spModGtAddr(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgGtAddressTab spGtAddrCfg;

  tb_record * prow = &row;
  SpCfgGtAddressTab   *pspGtAddrCfg = &spGtAddrCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  msgtype = SA_UPDATE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0x41;
  prow->head.col_count = 2;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_GT_ADDR;
  
  pspGtAddrCfg->GtId = 2;
  pspGtAddrCfg->InGtAddr[0] = '1';
  pspGtAddrCfg->InGtAddr[1] = '2';
  pspGtAddrCfg->InGtAddr[2] = '3';
  pspGtAddrCfg->InGtAddr[3] = '4';
  pspGtAddrCfg->InGtAddr[4] = 'f';
  pspGtAddrCfg->InGtAddr[5] = 'f';
  pspGtAddrCfg->InGtAddr[6] = 0;

  prow->panytbrow = (void *)pspGtAddrCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spAddRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteTab spRouteCfg;

  tb_record * prow = &row;
  SpCfgRouteTab   *pspRouteCfg = &spRouteCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  msgtype = SA_INSERT_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  
  pspRouteCfg->RteId = 4;    
  pspRouteCfg->SpcIndex = 1;      
  pspRouteCfg->NwId = 1;     
  pspRouteCfg->UpIndex = 1;    
  pspRouteCfg->SsnNum = 1;   
  pspRouteCfg->SsnIndex1 = 1;
  pspRouteCfg->SsnIndex2 = 2;
  pspRouteCfg->SsnIndex3 = 3;
  pspRouteCfg->SsnIndex4 = 4;
  pspRouteCfg->SsnIndex5 = 5;

  prow->panytbrow = (void *)pspRouteCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);

  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spDelRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteTab spRouteCfg;

  tb_record * prow = &row;
  SpCfgRouteTab   *pspRouteCfg = &spRouteCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  msgtype = SA_DELETE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0X1;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  
  pspRouteCfg->RteId = 3;

  prow->panytbrow = (void *)pspRouteCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}




/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spModRoute(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteTab spRouteCfg;

  tb_record * prow = &row;
  SpCfgRouteTab   *pspRouteCfg = &spRouteCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  msgtype = SA_UPDATE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0x5;
  prow->head.col_count = 2;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE;
  
  pspRouteCfg->RteId = 2;
  pspRouteCfg->SpcIndex = 2;

  prow->panytbrow = (void *)pspRouteCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}



/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spAddRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteSsnTab spRouteSsnCfg;

  tb_record * prow = &row;
  SpCfgRouteSsnTab   *pspRouteSsnCfg = &spRouteSsnCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  msgtype = SA_INSERT_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  
  pspRouteSsnCfg->RteSsnId = 4;
  pspRouteSsnCfg->Ssn = 444;     

  prow->panytbrow = (void *)pspRouteSsnCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spDelRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteSsnTab spRouteSsnCfg;

  tb_record * prow = &row;
  SpCfgRouteSsnTab   *pspRouteSsnCfg = &spRouteSsnCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  msgtype = SA_DELETE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0X1;
  prow->head.col_count = 1;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  
  pspRouteSsnCfg->RteSsnId = 3;

  prow->panytbrow = (void *)pspRouteSsnCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}


/************************************************************/
/*****       Functions: sccp dynamic config test                                 ******/ 
/************************************************************/
void spModRouteSsn(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
  unsigned int tableid;
  unsigned short msgtype;
  unsigned int sequence = 1;
  unsigned char pack_end = FALSE;

  tb_record row;
  SpCfgRouteSsnTab spRouteSsnCfg;

  tb_record * prow = &row;
  SpCfgRouteSsnTab   *pspRouteSsnCfg = &spRouteSsnCfg;

  cmMemset((U8 *)prow, 0, sizeof(tb_record));

  if ( NULLP == pCliEnv )
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if (NULLP == ppArgv)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARNULLP, __FILE__, __LINE__ );
    RETVOID;
  }

  if(argc != 1)
  {
    XOS_CliExtPrintf(pCliEnv, SP_DBG_ERR_STR_VARIAVLIDNUM, __FILE__, __LINE__ );
    RETVOID;
  }
  
  tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  msgtype = SA_UPDATE_MSG;
  pack_end = TRUE;
  
  prow->head.mask[0] = 0x5;
  prow->head.col_count = 2;
  prow->tableid = APP_TABLE_ID_SS7_SCCP_ROUTE_SSN;
  
  pspRouteSsnCfg->RteSsnId = 2;
  pspRouteSsnCfg->Ssn = 114;     

  prow->panytbrow = (void *)pspRouteSsnCfg;
  
  spDynCfgCallback(tableid, msgtype, sequence, pack_end, prow);


  RETVOID;
}
#endif /* CP_OAM_SUPPORT */


Void spGetSwTypeStr(S16 swType, U8 *swStr)
{
    switch( swType)
    {
        case LSP_SW_ANS88:
          cmMemcpy(swStr, "ANS88", 20);
            break;
        case LSP_SW_ANS92:
          cmMemcpy(swStr, "ANS92", 20);
            break;
        case LSP_SW_ANS96:
          cmMemcpy(swStr, "ANS96", 20);
             break;
        case LSP_SW_CHINA:
          cmMemcpy(swStr, "CHINA", 20);
            break;
        case LSP_SW_ITU88:
          cmMemcpy(swStr, "ITU88", 20);
            break;
        case LSP_SW_ITU92:
          cmMemcpy(swStr, "ITU92", 20);
            break;
#ifdef SS7_ITU96
      case LSP_SW_ITU96:
          cmMemcpy(swStr, "ITU96", 20);
            break;
#endif            
        case SW_JAPAN:
          cmMemcpy(swStr, "JAPAN", 20);
            break;
      default:
          cmMemcpy(swStr, "UNKOWN", 20);
            break;
    }
    
    RETVOID;
}

Void spGetSccpStsStr(U8 sccpSts, U8 *swStr)
{
    switch(sccpSts)
    {
        case RMT_SCCP_AVAIL:
          cmMemcpy(swStr, "RMT_SCCP_AVAIL", 20);
            break;
        case RMT_SCCP_UNAVAIL:
          cmMemcpy(swStr, "RMT_SCCP_UNAVAIL", 20);
            break;
        case RMT_SCCP_UNEQP:
          cmMemcpy(swStr, "RMT_SCCP_UNEQP", 20);
             break;
        case RMT_SCCP_INACC:
          cmMemcpy(swStr, "RMT_SCCP_INACC", 20);
            break;
        case RMT_SCCP_CONG:
          cmMemcpy(swStr, "RMT_SCCP_CONG", 20);
            break;
      default:
          cmMemcpy(swStr, "UNKNOWN", 20);
            break;
    }
    
    RETVOID;
}

Void spGetVariantStr(S16 swType, U8 *swStr)
{
    switch(swType)
    {
        case LSP_SW_ANS:
          cmMemcpy(swStr, "ANSI", 20);
            break;
        case LSP_SW_ITU:
          cmMemcpy(swStr, "ITU", 20);
            break;
        case LSP_SW_CHINA:
          cmMemcpy(swStr, "CHINA", 20);
             break;
        case SW_JAPAN:
          cmMemcpy(swStr, "JAPAN", 20);
            break;
      default:
          cmMemcpy(swStr, "UNKOWN", 20);
            break;
    }

    RETVOID;
}

Void spGetPcLenStr(U8 pcLen, U8 *swStr)
{
    switch(pcLen)
    {
        case DPC14:
          cmMemcpy(swStr, "DPC14", 20);
            break;
        case DPC24:
          cmMemcpy(swStr, "DPC24", 20);
            break;
        case DPC16:
          cmMemcpy(swStr, "DPC16", 20);
             break;
        case DPC_DEFAULT:
          cmMemcpy(swStr, "DPC_DEFAULT", 20);
            break;
      default:
          cmMemcpy(swStr, "UNKOWN", 20);
            break;
    }

    RETVOID;
}

Void spPrintSapNSapStatus(CLI_ENV *pCliEnv, U16 status)
{
  if (status & SP_BND)
  {
    XOS_CliExtPrintf(pCliEnv, "SP_BND");
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "SP_UNBND\r\n");
    RETVOID;
  }

  if (status & SP_SNRST)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_SNRST");
  }
  
  if (status & SP_GUARD)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_GUARD");
  }
  
  if (status & SP_BRT)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_BRT");
  }
  
  if (status & SP_GRNT)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_GRNT");
  }
  
  if (status & SP_IGNR)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_IGNR");
  }
  
  if (status & SP_PROH)
  {
    XOS_CliExtPrintf(pCliEnv, "| SP_PROH");
  }
  
  if (status & SP_WAIT_BNDCFM)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_WAIT_BNDCFM");
  }

  XOS_CliExtPrintf(pCliEnv, "\r\n");

  RETVOID;
}

Void spPrintSpStatus(CLI_ENV *pCliEnv, U8 status)
{
  if (status & SP_INACC)
  {
    XOS_CliExtPrintf(pCliEnv, "SP_INACC");
  }
  else
  {
    XOS_CliExtPrintf(pCliEnv, "SP_ACC");
  }
  
  if (status & SP_CONG)
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_CONG\r\n");
  }
  else 
  {
    XOS_CliExtPrintf(pCliEnv, " | SP_UNCONG\r\n");
  }
  
  RETVOID;
}



Void spPrintRteStatus(CLI_ENV *pCliEnv, U8 status)
{
  if (status & SP_ONLINE)
  {
    XOS_CliExtPrintf(pCliEnv, "SP_ONLINE ");
  }
  else  
  {
    XOS_CliExtPrintf(pCliEnv, "SP_OFFLINE ");
  }

  if (status & SP_CONG)
  {
    XOS_CliExtPrintf(pCliEnv, "| SP_CONG\r\n");
  }
  else  
  {
    XOS_CliExtPrintf(pCliEnv, "| SP_UNCONG\r\n");
  }
  
  RETVOID;
}


#endif/*SSI_WITH_CLI_ENABLED*/

/*added by wanglijun for set dbgmask from shell*/
#ifdef SP_DEBUG
U32 g_spDbgMask = DBGMASK_LI|DBGMASK_UI|DBGMASK_MI;
#else
U32 g_spDbgMask = 0;
#endif

Void spSetDbgMaskFromShell(U32 dbgMask)
{
  g_spDbgMask = dbgMask;
#ifdef DEBUGP
  spCb.spInit.dbgMask = g_spDbgMask;
#endif
  RETVOID;
}

/********************************************************************60**
  
  
*********************************************************************61*/
  

