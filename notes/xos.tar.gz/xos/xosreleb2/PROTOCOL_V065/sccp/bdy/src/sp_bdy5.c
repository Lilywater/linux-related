/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - body 5
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Connection-oriented
               Matrix Functions.
  
     File:     cp_bdy5.c
  
     Sid:      cp_bdy5.c@@/main/13_1 - Tue Jan 22 15:16:10 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

  
#ifdef SPCO

/* forward references */

/*
 * Lower interface state matric functions
 */
PRIVATE Void spDiscard           ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiSCMM            ARGS((SpConCb* conCb, Buffer *mBuf));

PRIVATE Void spLiErr             ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiRlsCol          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiErrCon          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiPduErr          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiCcConCd         ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiCfConCd         ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiRlsDtx          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiRcRls           ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiDataTx          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiDataAck         ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiEDatTx          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiEDatAck         ARGS((SpConCb* conCb, Buffer *mBuf));

PRIVATE Void spLiRrDtx           ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiRrOpp           ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiRstCfm          ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spLiIntRst          ARGS((SpConCb* conCb, Buffer *mBuf));

PRIVATE Void spLiInactTst        ARGS((SpConCb* conCb, Buffer *mBuf));
/*
 * Upper interface state matric functions
 */
PRIVATE Void spUiErrUp   ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiConReq0 ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiConReq1 ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiConReq2 ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiConRsp  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiDatTx   ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiDatRst  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiEDatTx  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiDisCon  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiDisDtx  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiDisRls  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiRstReq  ARGS((SpConCb* conCb, Buffer *mBuf));
PRIVATE Void spUiRstRsp  ARGS((SpConCb* conCb, Buffer *mBuf));

  
/* State Machine Matricies */

/* 
 * Legend of the states for a quick ref :
 * RDY_ST : Ready State
 * CON_ST : Connecting State
 * DTX_ST : Data Transfer State
 * RCG_ST : Reset Calling State
 * RCD_ST : Reset Called State
 * RBT_ST : Reset Both State
 * RLS_ST : Releasing State
 */

/* lower interface state matrix */
PFVM spLiConMt[SP_NMB_MSG][SP_NMB_DIR][SP_NMB_ST] = 
{
   {  /* Connection Request Calling Side */
      {
         spLiErr,               /* RDY_ST XXX - this fn will never be invoked */
         spDiscard,             /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      },
      /* Connection Request Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErr,               /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      }
   },

   {  /* Connection Confirm Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Connection Confirm Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiCcConCd,           /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Connection Refused Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Connection Refused Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiCfConCd,           /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Released Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiRlsDtx,            /* DTX_ST XXX */
         spLiRlsDtx,            /* RCG_ST XXX */
         spLiRlsDtx,            /* RCD_ST XXX */
         spLiRlsDtx,            /* RBT_ST XXX */
         spLiRcRls              /* RLS_ST XXX */
      },
      /* Released Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiRlsDtx,            /* DTX_ST XXX */
         spLiRlsDtx,            /* RCG_ST XXX */
         spLiRlsDtx,            /* RCD_ST XXX */
         spLiRlsDtx,            /* RBT_ST XXX */
         spLiRcRls              /* RLS_ST XXX */
      }
   },
   {  /* Release Complete Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spLiRcRls              /* RLS_ST XXX */
      },
      /* Release Complete Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spLiRcRls              /* RLS_ST XXX */
      }
   },
   {  /* Data Form 1 Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiDataTx,            /* DTX_ST XXX */
         spLiSCMM,              /* RCG_ST XXX */
         spLiSCMM,              /* RCD_ST XXX */
         spLiSCMM,              /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      },
      /* Data Form 1 Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiDataTx,            /* DTX_ST XXX */
         spLiSCMM,              /* RCG_ST XXX */
         spLiSCMM,              /* RCD_ST XXX */
         spLiSCMM,              /* RBT_ST XXX */
         spLiSCMM               /* RLS_ST XXX */
      }
   },
   {  /* Data Form 2 Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiDataTx,            /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiDataTx,            /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Data Form 2 Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiDataTx,            /* DTX_ST XXX */
         spLiDataTx,            /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Data Acknowledgement Calling Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiDataAck,           /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiDataAck,           /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Data Acknowlegement Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiDataAck,           /* DTX_ST XXX */
         spLiDataAck,           /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Unit Data Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErr,               /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      },
      /* Unit Data Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErr,               /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      }
   },
   {  /* Unit Data Service Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErr,               /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      },
      /* Unit Data Service Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErr,               /* CON_ST XXX */
         spLiErr,               /* DTX_ST XXX */
         spLiErr,               /* RCG_ST XXX */
         spLiErr,               /* RCD_ST XXX */
         spLiErr,               /* RBT_ST XXX */
         spLiErr                /* RLS_ST XXX */
      }
   },
   {  /* Expedited Data Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiEDatTx,            /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiEDatTx,            /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Expedited Data Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiEDatTx,            /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiEDatTx,            /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Expedited Data Acknowledgement Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiEDatAck,           /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiEDatAck,           /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Expedited Data Acknowledgement Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiEDatAck,           /* DTX_ST XXX */
         spLiEDatAck,           /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Reset Request Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiRrDtx,             /* DTX_ST XXX */
         spLiRstCfm,            /* RCG_ST XXX */
         spLiRrOpp,             /* RCD_ST XXX */
         spLiRstCfm,            /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Reset Request Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiRrDtx,             /* DTX_ST XXX */
         spLiRrOpp,             /* RCG_ST XXX */
         spLiRstCfm,            /* RCD_ST XXX */
         spLiRstCfm,            /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* Reset Confirm Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiIntRst,            /* DTX_ST XXX */
         spLiRstCfm,            /* RCG_ST XXX */
         spLiRrOpp,             /* RCD_ST XXX */
         spLiRstCfm,            /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      /* Reset Confirm Called Side */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiIntRst,            /* DTX_ST XXX */
         spLiRrOpp,             /* RCG_ST XXX */
         spLiRstCfm,            /* RCD_ST XXX */
         spLiRstCfm,            /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   },
   {  /* PDU Error Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiPduErr,            /* DTX_ST XXX */
         spLiPduErr,            /* RCG_ST XXX */
         spLiPduErr,            /* RCD_ST XXX */
         spLiPduErr,            /* RBT_ST XXX */
         spLiErrCon             /* RLS_ST XXX */
      },
      /* PDU Error Called */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiPduErr,            /* DTX_ST XXX */
         spLiPduErr,            /* RCG_ST XXX */
         spLiPduErr,            /* RCD_ST XXX */
         spLiPduErr,            /* RBT_ST XXX */
         spLiErrCon             /* RLS_ST XXX */
      }
   },
   {  /* Inactivity Test Calling */
      {
         spLiErr,               /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spLiInactTst,          /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spLiInactTst,          /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spLiRlsCol             /* RLS_ST XXX */
      },
      /* Inactivity Test Called */
      {
         spLiErr,               /* RDY_ST XXX */
         spLiErrCon,            /* CON_ST XXX */
         spLiInactTst,          /* DTX_ST XXX */
         spLiInactTst,          /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      }
   }
};

  
/* upper interface state matrix */
PFVM spUiConMt[SP_NMB_PRIM][SP_NMB_ST] =
{
      { /* Connection Request Primitive */
         spUiConReq0,           /* RDY_ST XXX */
         spUiErrUp,             /* CON_ST XXX */
         spUiErrUp,             /* DTX_ST XXX */
         spUiErrUp,             /* RCG_ST XXX */
         spUiErrUp,             /* RCD_ST XXX */
         spUiErrUp,             /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Connection Request Primitive */
         spUiConReq1,           /* RDY_ST XXX */
         spUiErrUp,             /* CON_ST XXX */
         spUiErrUp,             /* DTX_ST XXX */
         spUiErrUp,             /* RCG_ST XXX */
         spUiErrUp,             /* RCD_ST XXX */
         spUiErrUp,             /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Connection Request Primitive */
         spUiConReq2,           /* RDY_ST XXX */
         spUiErrUp,             /* CON_ST XXX */
         spUiErrUp,             /* DTX_ST XXX */
         spUiErrUp,             /* RCG_ST XXX */
         spUiErrUp,             /* RCD_ST XXX */
         spUiErrUp,             /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Connection Response Primitive */
         spUiErrUp,             /* RDY_ST XXX */
         spUiConRsp,            /* CON_ST XXX */
         spUiErrUp,             /* DTX_ST XXX */
         spUiErrUp,             /* RCG_ST XXX */
         spUiErrUp,             /* RCD_ST XXX */
         spUiErrUp,             /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Data Request Primitive */
         spUiErrUp,             /* RDY_ST XXX */
         spUiErrUp,             /* CON_ST XXX */
         spUiDatTx,             /* DTX_ST XXX */
         spUiDatRst,            /* RCG_ST XXX */
         spUiDatRst,            /* RCD_ST XXX */
         spUiDatRst,            /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Expedited Data Request */
         spUiErrUp,             /* RDY_ST XXX */
         spUiErrUp,             /* CON_ST XXX */
         spUiEDatTx,            /* DTX_ST XXX */
         spUiEDatTx,            /* RCG_ST XXX */
         spUiEDatTx,            /* RCD_ST XXX */
         spUiEDatTx,            /* RBT_ST XXX */
         spUiErrUp              /* RLS_ST XXX */
      },
      { /* Data Acknowledgement Request */
         spDiscard,             /* RDY_ST XXX */
         spDiscard,             /* CON_ST XXX */
         spDiscard,             /* DTX_ST XXX */
         spDiscard,             /* RCG_ST XXX */
         spDiscard,             /* RCD_ST XXX */
         spDiscard,             /* RBT_ST XXX */
         spDiscard              /* RLS_ST XXX */
      },
      { /* Disconnect Request */
         spDiscard,             /* RDY_ST XXX */
         spUiDisCon,            /* CON_ST XXX */
         spUiDisDtx,            /* DTX_ST XXX */
         spUiDisDtx,            /* RCG_ST XXX */
         spUiDisDtx,            /* RCD_ST XXX */
         spUiDisDtx,            /* RBT_ST XXX */
         spUiDisRls             /* RLS_ST */
      },
      { /* Reset Request */
         spDiscard,             /* RDY_ST */
         spDiscard,             /* CON_ST */
         spUiRstReq,            /* DTX_ST (reset) */
         spUiRstReq,            /* RCG_ST (reset) */
         spUiRstReq,            /* RCD_ST (reset) */
         spUiRstReq,            /* RBT_ST */ 
         spDiscard              /* RLS_ST */
      },
      { /* Reset Response */
         spDiscard,             /* RDY_ST */
         spDiscard,             /* CON_ST */
         spUiErrUp,             /* DTX_ST (error) */
         spUiRstRsp,            /* RCG_ST (cfm) */
         spUiRstRsp,            /* RCD_ST (cfm) */
         spUiRstRsp,            /* RBT_ST (cfm) */
         spDiscard              /* RLS_ST (ignore) */
      }
};

  
/* 
 * support functions 
 */

/*
 * Lower Interface State Matric Functions
 */


/*
*
*       Fun:   spLiErr
*
*       Desc:  This is an internal error and should therefore never happen.
*              and if you believe that, I've got some land for sale in
*              Louisiana... Kidding aside, this is very bad, something
*              is way outta wack.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiErr
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiErr(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiErr)

   /* sp015.302 - modification - replacing errlog prints with debug prints
    * and printing the connection state info and recvd message value to
    * debug further why sccp receives the unexpected message.
    */
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
   "spLiErr: unexpected msg recvd, msgType: %d cb->side: %d, cb->state: %d\n\n",
   spCb.pduHdr.msgType.val, cb->side, cb->state));

   spDiscard(cb, mBuf);
   RETVOID;
} /* spLiErr */


/*
*
*       Fun:   spDiscard
*
*       Desc:  Discard a message buffer...
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spDiscard
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spDiscard(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   TRC2(spDiscard)

   UNUSED(cb);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "spDiscard\n"));

   if (data)
   {
      (Void) SPutMsg(data);
      data = (Buffer*)NULLP;
   }
   RETVOID;
} /* end of spDiscard */


/*
*
*       Fun:   spLiErrCon
*
*       Desc:  Error in connection 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiErrCon
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spLiErrCon(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   TRC2(spLiErrCon)

   /* discard received message */
   if (data)
   {
      (Void) SPutMsg(data);
      data = (Buffer*)NULLP;
   }

   /* we are in connecting state, so stop connection timer */
   spRmvConCbTq(cb, CON_TMR);

   /* do we have a source local reference ? */
   if (!cb->cs[SIDE(cb)].nSap->mfMsgCtl.sccpInfo.slrPres)
   {  /* no source local reference */

      if (cb->cType & SP_INTR) /* intermediate node */
      {
          spFreezeSlr(cb, SP_FRZ_BT);
          /* send connection refused on calling side */
          spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);
          spFreeConCb(cb);
      }
      else if (cb->cType & SP_ORIG) /* originating node */
      {
          spFreezeSlr(cb, SP_FRZ_BT);
          if (!(cb->cbFlags & CG_RCVD_DIS))
          {
             /* if we haven't already been notified by our user 
              * about a local disconnect,inform user
              */
             spRelease(cb, SIDE(cb), RLC_REMPROC, ORIG_NET, NULLP);
             spCb.sts.prvInitRel++;
          }
          spFreeConCb(cb);
      }
      else if (cb->cType & SP_DEST)
      {
         /* This is an ugly error because our called side is
          * an upper user so how did we receive a message?
          * on the called side? A primitive sure, but an NPDU?
          * go figure...
          */
         SPLOGERROR(ERRCLS_INT_PAR, ESP332, (ErrVal) cb->cType,
                    "invalid connection type");
          /*
           * Do nothing, maybe it won't happen again, we'll keep
           * our fingers crossed.
           */
          RETVOID;
      }
   }
   RETVOID;
} /* spLiErrCon */


/*
*
*       Fun:   spLiRlsCol
*
*       Desc:  Release Collision...
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRlsCol
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRlsCol(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{

   TRC2(spLiRlsCol)

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /* Collision on release */
   spFreezeSlr(cb, SP_FRZ_BT);     /* Freeze & */
   spFreeConCb(cb);                /* Free */
   RETVOID;
} /* end of spLiRlsCol */


/*
*
*       Fun:   spLiCcConCd
*
*       Desc:  Li, Connection Confirm, Connecting State,  Called Side
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiCcConCd
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spLiCcConCd(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{

   TRC2(spLiCcConCd)
   
   cb->cs[SIDE(cb)].conId.suId = cb->cs[SIDE(cb)].nSap->suId;
   cb->cs[SIDE(cb)].conId.suInstId = 
                cb->cs[SIDE(cb)].nSap->mfMsgCtl.sccpInfo.srcLclRef;

   if (spCb.pdu.m.conCfm.cdAddr.spAddr.pres)
   {
       /* if there is a responding address convert and store it */
       /* sp045.302 - modification - nwData moved to cs[] */ 
       spTknStrToSpAddr(&spCb.pdu.m.conCfm.cdAddr.spAddr,
                        &cb->t.req0.cdAddr, cb->cs[SIDE(cb)].nwData->variant,
                        cb->ssf);
#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
       if (cb->t.req0.oCdAddr.pcInd == FALSE)
          cb->t.req0.oCdAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */
   }

   /* stop connection timer */
   spRmvConCbTq(cb, CON_TMR);

   /* adjust protocol class if necessary */
   if (spCb.pdu.m.conCfm.pClass.pClass.val != cb->qos.pClass)
        cb->qos.pClass = spCb.pdu.m.conCfm.pClass.pClass.val;

   /* adjust credit if necessary */
   if ((cb->qos.pClass == PCLASS3) && 
      (spCb.pdu.m.conCfm.credit.credit.pres != NOTPRSNT))
   {
      /* set of the deault credit */
      cb->qos.credit = spCb.pdu.m.conCfm.credit.credit.val;

      /* set up the current window */
      cb->cs[SIDE(cb)].txWin = cb->qos.credit;
      cb->cs[SIDE(cb)].rxWin = cb->qos.credit;
      cb->cs[OPSIDE(cb)].txWin = cb->qos.credit;
      cb->cs[OPSIDE(cb)].rxWin = cb->qos.credit;
   }

   if (cb->cbFlags == CG_RCVD_DIS)
   {
      /* our user has generated a disconnect request prior to this 
       * connect confirm from the called side... 
       */

      /* connection timer has already been stoped */
      /* slr has already been associated with connection */

      /* freeze the calling side local reference */
      spFreezeSlr(cb, SP_FRZ_CG);

      /* use default value of importance for RLSD */
      cb->imp.val = spCb.spMsgImp.defRlsdImp;

      /* send a release on the opposite side */
      spRelease(cb, OPSIDE(cb), RLC_EUORIG, ORIG_USR, NULLP);

      /* sp034.302 - addition - free conCb if its in dead state */
      if (cb->cType & SP_DEAD)
         spFreeConCb(cb);

      /* Discard Message */
      if (data)
      {
         (Void) SPutMsg(data);
         data = (Buffer *) NULLP;
      }
   }
   else
   {
      /* start inactivity timers on called side */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */ 
      cb->tmr.val = cb->cs[CD_SIDE].nwData->defIasTmr.val;
      spStartConCbTmr(cb, CD_IAS_TMR);
      /* sp045.302 - modification - nwData moved to cs[] */ 
      cb->tmr.val = cb->cs[CD_SIDE].nwData->defIarTmr.val;
      spStartConCbTmr(cb, CD_IAR_TMR);

      spConConfirm(cb, data);
   }
   RETVOID;
} /* end of spLiCcConCd */


/*
*
*       Fun:   spLiCfConCd
*
*       Desc:  Li Connection Refused , called side
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiCfConCd
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiCfConCd(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{

   TRC2(spLiCfConCd)

   /* stop connection timer */
   spRmvConCbTq(cb, CON_TMR);

   /* freeze both sides of call reference */
   spFreezeSlr(cb, SP_FRZ_BT);

   /* if we are Request Type 2 from ISUP (intermediate node) */
   if ((cb->cType & SP_REQ2) && (cb->cType & SP_INTR))
   {
       Buffer *data1;
       S16 ret;
       SpDisEvnt dis;

       data1 = (Buffer *)NULLP;
       if (mBuf != (Buffer *)NULLP)
       {
          /* duplicate data for upper user */
          ret  = SCpyMsgMsg(mBuf, cb->sap->pst.region, cb->sap->pst.pool, 
                                                                   &data1);
          if (ret != ROK)
          {
             SPLOGERROR(ERRCLS_ADD_RES, ESP333, (ErrVal) ret,
                        "SCPYMsgMsg failed");
          }
       }
       cmCopy((U8*)&cb->t.req2.usrId, (U8*)&dis.conId, sizeof(SpConId));
       cmZero((U8*)&dis.rspAddr, sizeof(SpAddr));
       dis.rsn = spCb.pdu.m.conRef.refCause.refCause.val;
       dis.orig = ORIG_NET;
       dis.conId.suId = cb->sap->suId;
#ifdef SPTV2
       /* importance is not revelant in discon indication to user,
        * mark it as not present
        */
       dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
          
       /* check if the user has bound */
       if (cb->sap->status & SP_BND)
          SpUiSptDisInd(&cb->sap->pst, &dis, data1);
       else
       {
          if (data1 != (Buffer *)NULLP)
          {
             (Void) SPutMsg (data1);
          }
       }
   }
   if ( !(cb->cbFlags & CG_RCVD_DIS) )
   {
      /* send connection refused */
      spConRefused(cb, spCb.pdu.m.conRef.refCause.refCause.val, ORIG_NET,mBuf);
   }
   else
   {
      if (mBuf != (Buffer *)NULLP)
      {
         (Void) SPutMsg(mBuf);
      }
   }
   /* free connection resources */
   spFreeConCb(cb);

   RETVOID;
} /* spLiCfConCd */


/*
*
*       Fun:   spLiRlsDtx
*
*       Desc:  Release data connection  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRlsDtx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRlsDtx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiRlsDtx)

   /* stop inactivity timers on both sides */

   if (cb->cType & SP_ORIG) /* I'm an originating node */
   {

      spRmvConCbTq(cb, CD_IAS_TMR);
      spRmvConCbTq(cb, CD_IAR_TMR);

      /* freeze calling side slr */
      spFreezeSlr(cb, SP_FRZ_BT);

      /* send release up (calling side) */
      spRelease(cb, CG_SIDE, spCb.pdu.m.relsd.relCause.relCause.val, 
          ORIG_NET, mBuf);

      /* send release complete on the called side */
      spRelCmp(cb, CD_SIDE);

      /* free connection control block */
      spFreeConCb(cb);
   }
   else if (cb->cType & SP_DEST) /* I'm an destination node */
   {

      spRmvConCbTq(cb, CG_IAS_TMR);
      spRmvConCbTq(cb, CG_IAR_TMR);
      /* freeze calling side slr */
      spFreezeSlr(cb, SP_FRZ_BT);

      /* send release up (called side) */
      spRelease(cb, CD_SIDE, spCb.pdu.m.relsd.relCause.relCause.val, 
          ORIG_NET, mBuf);

      /* send release complete on the called side */
      spRelCmp(cb, CG_SIDE);

      /* free connection control block */
      spFreeConCb(cb);
   }
   else if (cb->cType & SP_INTR) /* I'm an intermediate node */
   {

      /* stop inactivity timers on both sides */
      spRmvConCbTq(cb, CD_IAR_TMR);
      spRmvConCbTq(cb, CD_IAS_TMR);
      spRmvConCbTq(cb, CG_IAR_TMR);
      spRmvConCbTq(cb, CG_IAS_TMR);

      /* if were an intermediate node in an ISUP Request 2 */
      if ((cb->cType & SP_REQ2) && (cb->cType & SP_INTR))
      {
          Buffer *data1;
          S16 ret;
          SpDisEvnt dis;
        

          /* duplicate data for upper user */
          ret  = SCpyMsgMsg(mBuf, cb->sap->pst.region, cb->sap->pst.pool, 
                            &data1);
          if (ret != ROK)
          {
             SPLOGERROR(ERRCLS_ADD_RES, ESP334, (ErrVal) ret,
                        "SCPYMsgMsg failed");
          }
          else
          {
             cmCopy((U8*)&cb->t.req2.usrId, (U8*)&dis.conId, sizeof(SpConId));
             cmZero((U8*)&dis.rspAddr, sizeof(SpAddr));
             dis.rsn = spCb.pdu.m.relsd.relCause.relCause.val;
             dis.orig = ORIG_NET;
             dis.conId.suId = cb->sap->suId;
#ifdef SPTV2
             /* importance is not revelant in discon indication to user,
              * mark it as not present
              */
             dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

             /* check if the user has bound */
             if (cb->sap->status & SP_BND)
                (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data1);
             else
             {
                (Void) SPutMsg (data1);
             }
          }
      }
      if ( cb->side == CG_SIDE)
      {
          /* freeze calling side slr */
          spFreezeSlr(cb, SP_FRZ_CG);
          /* send release complete on the called side */
          spRelCmp(cb, CG_SIDE);
          /* send release on called side */
          spRelease(cb, CD_SIDE, spCb.pdu.m.relsd.relCause.relCause.val, 
             ORIG_NET, mBuf);
      }
      else if (cb->side == CD_SIDE)
      {
         /* freeze called side slr */
         spFreezeSlr(cb, SP_FRZ_CD);
         /* send release complete on the called side */
         spRelCmp(cb, CD_SIDE);
         /* send release on called side */
         spRelease(cb, CG_SIDE, spCb.pdu.m.relsd.relCause.relCause.val, 
            ORIG_NET, mBuf);
      }
#if (ERRCLASS & ERRCLS_DEBUG)
      else
      {
         /* Discard Message */
         if (mBuf)
         {
            (Void) SPutMsg(mBuf);
            mBuf = (Buffer*)NULLP;
         }
         SPLOGERROR(ERRCLS_DEBUG, ESP335, (ErrVal) cb->side,
                    "invalid cb->side");
         RETVOID;
      }
#endif /* ERRCLASS */

      /* sp034.302 - addition - free conCb if its in dead state */
      if (cb->cType & SP_DEAD)
         spFreeConCb(cb);
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   else
   {
      /* Discard Message */
      if (mBuf)
      {
         (Void) SPutMsg(mBuf);
         mBuf = (Buffer*)NULLP;
      }
      SPLOGERROR(ERRCLS_DEBUG, ESP336, (ErrVal) cb->cType,
                 "invalid cb->cType");
      RETVOID;
   }
#endif /* ERRCLASS */

   RETVOID;
} /* end of spLiRlsDtx */


/*
*
*       Fun:   spLiRcRls
*
*       Desc:  Release connection 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRcRls
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRcRls(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiRcRls)

   spFreezeSlr(cb, FRZ_SIDE(SIDE(cb)));
   
   /* We stop all the asociated timers */
   spRmvConCbTq(cb, REL_TMR(SIDE(cb)));
   spRmvConCbTq(cb, REPREL_TMR(SIDE(cb)));
   spRmvConCbTq(cb, INT_TMR(SIDE(cb)));

   /* sp013.302 - Free memory if freeze timer disabled */
   /* sp034.302 - modification - free conCb if its in dead state */
   if (cb->cType & SP_DEAD)
      spFreeConCb(cb);

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   RETVOID;
} /* end of spLiRcRls */

/*
*
*       Fun:   spLiDataTx
*
*       Desc:  Prepare data for transmission 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiDataTx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiDataTx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiDataTx)

   /* restart receive inactivity timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */ 
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));

   if (cb->cs[SIDE(cb)].nSap->mfMsgCtl.msgType == M_DATA1)
   {
      SpData1 *dat;

      /* the decoded data structure */
      dat = (SpData1*)&spCb.pdu.m.data1;

      /* validate protocol class */
      if (cb->qos.pClass != PCLASS2)
      {
         /* send service class mismatch error */
         spSendPduErr(cb->cs[SIDE(cb)].nSap, cb->cs[SIDE(cb)].pc, 
            cb->cs[SIDE(cb)].conId.suInstId, ERR_SCMM, cb->ssf);
         spFreezeSlr(cb, SP_FRZ_BT);
         /* release both sides (inconsistent connection data */
         spRelease(cb, SIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
         spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb unconditionally, lclref is
          * frozen both sides
          */
         spFreeConCb(cb);

         spCb.sts.prvInitRel++;

         /* Discard Message */
         if (mBuf)
         {
            (Void) SPutMsg(mBuf);
            mBuf = (Buffer*)NULLP;
         }
         RETVOID;
      }

      spDat1Tx(cb, mBuf, dat->segReas.segReas.val);
   }
   else if (cb->cs[SIDE(cb)].nSap->mfMsgCtl.msgType == M_DATA2)
   {
      SpData2 *dat;
      U8 ssn;   /* send sequence number */
      U8 rsn;   /* receive sequence number */

      dat = (SpData2*)&spCb.pdu.m.data2;
      if (cb->qos.pClass != PCLASS3)
      {
         /* send service class mismatch error */
         spSendPduErr(cb->cs[SIDE(cb)].nSap, cb->cs[SIDE(cb)].pc, 
            cb->cs[SIDE(cb)].conId.suInstId, ERR_SCMM, cb->ssf);
         spFreezeSlr(cb, SP_FRZ_BT);
         /* release both sides (inconsistent connection data */
         spRelease(cb, SIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
         spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb unconditionally, lclref is
          * frozen both sides
          */
         spFreeConCb(cb);

         spCb.sts.prvInitRel++;

         /* Discard Message */
         if (mBuf)
         {
            (Void) SPutMsg(mBuf);
            mBuf = (Buffer*)NULLP;
         }
         RETVOID;
      }

      ssn = dat->seqSeg.senSeqNum.val;
      rsn = dat->seqSeg.recSeqNum.val;
      cb->cs[SIDE(cb)].lstMoreRx = dat->seqSeg.moreData.val;

      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP: spLiDataTx - ssn: %d, rsn : %d\n", ssn, rsn));

      /* Okay, this is the flow control stuff */

      /* received P(S) is next in sequence? */
      if (ssn != cb->cs[SIDE(cb)].EPS)
      {
         if (mBuf)
            (Void) SPutMsg(mBuf);

         /* Initiate  Reset */
         spIntRst(cb, RSC_MOOINCPS);
         RETVOID;
      }

      /* receive P(R) range OK? */
      if (!spChkRxWdw(&cb->cs[SIDE(cb)], ssn))
      {
         if (mBuf)
            (Void) SPutMsg(mBuf);

         spIntRst(cb, RSC_RPEMOW);
         RETVOID;
      }

      if (!spChkPr(&cb->cs[SIDE(cb)], rsn))
      {

         if (mBuf)
            (Void) SPutMsg(mBuf);

         spIntRst(cb, RSC_MOOINCPR);
         RETVOID;
      }

      /* set lower edge of window to rsn */
      if (rsn != cb->cs[SIDE(cb)].LPR)
         cb->cs[SIDE(cb)].LPR = rsn;

      spCheckDatQ(cb, SIDE(cb));

      /* increment expected p(s) */
      cb->cs[SIDE(cb)].EPS = (U8)(cb->cs[SIDE(cb)].EPS + 1) % (U8)MODULO_128;

      /* are we at the top edge of our window? 
       * we're done with ssn, so go ahead and munge it;
       */

      if (ssn < cb->cs[SIDE(cb)].TPR)
         ssn+= MODULO_128;
      if (ssn == (cb->cs[SIDE(cb)].TPR + cb->cs[SIDE(cb)].rxWin -1))
         spDataAck(cb);

      spDat2Tx(cb, mBuf, dat->seqSeg.moreData.val);

   }
#if (ERRCLASS & ERRCLS_DEBUG)
   else
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP337, 
                 (ErrVal) cb->cs[SIDE(cb)].nSap->mfMsgCtl.msgType,
                 "invalid message type");
      /* Discard Message */
      if (mBuf)
      {
         (Void) SPutMsg(mBuf);
         mBuf = (Buffer *) NULLP;
      }
      RETVOID;
   }
#endif /* ERRCLASS */

   RETVOID;
} /* end of spLiDataTx */


/*
*
*       Fun:   spLiDataAck
*
*       Desc:  Data acknowledgement 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiDataAck
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiDataAck(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   SpDataAck *da;
   U8 rsn;          /* receive sequence number */

   TRC2(spLiDataAck)

   /* dispose of message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   da = (SpDataAck*)cb->info;
   rsn = da->recSeqNum.recSeqNum.val;

   /* restart receive timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));

   if (!spChkPr(&cb->cs[SIDE(cb)], rsn))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP338, (ErrVal) rsn,
                 "rsn in da event not in credit window");
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP: spLiDataAck SHOULD GENERATE RESET REQUEST\n"));
   }

   /* set sending credit to value received in DataAck */
   cb->cs[SIDE(cb)].txWin = da->credit.credit.val;


   if (rsn == cb->cs[SIDE(cb)].LPR)
   {
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP: spLiDataAck P(R) == lower edge = %d\n", rsn));
      RETVOID; /* rsn == lower edge of receive window */
   }
   else
      cb->cs[SIDE(cb)].LPR = rsn;

   /* drain queue */
   spCheckDatQ(cb, SIDE(cb));

   RETVOID;
} /* end of spLiDataAck */


/*
*
*       Fun:   spLiEDatTx
*
*       Desc:  Prepare expedited data for transmission 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiEDatTx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiEDatTx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiEDatTx)

   if (cb->cs[SIDE(cb)].flags & EDA_PEN)
   {
      /* if we're waiting for an acknowledgment,
       * this is an error, reset.
       */
      if (mBuf)
         (Void) SPutMsg(mBuf);

      spIntRst(cb, RSC_RPEGEN);
      RETVOID;
   }

   /* deliver */
   spEDatTx(cb, mBuf);

   /* sp034.302 - addition - check cb, cb might have been freed if func
    * spDropCall had been called in some error case during above EDatTx
    */
   if (cb != (SpConCb *) NULLP)
   {
      /* we acknowledge right away */
      spEDatAck(cb);
   }

   RETVOID;
} /* end of spLiEDatTx */


/*
*
*       Fun:   spLiEDatAck
*
*       Desc:  Expedited data acknowledgement  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiEDatAck
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiEDatAck(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiEDatAck)

   if (mBuf)
      (Void) SPutMsg(mBuf);

   /* unset pending flag */
   cb->cs[SIDE(cb)].flags &= (U8)(~(U8)EDA_PEN);

   /* check our queue */
   spCheckEDatQ(cb, SIDE(cb));

   RETVOID;
} /* end of spLiEDatAck */


/*
*
*       Fun:   spLiRrDtx
*
*       Desc:  Reset Request (DataTx State)
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRrDtx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRrDtx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{

   TRC2(spLiRrDtx)

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /* restart receive timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));

   /* reset this side's variables */
   cb->cs[SIDE(cb)].flags &= (U8)(~EDA_PEN); /* turn off exp data pending */
   cb->cs[SIDE(cb)].txWin = cb->qos.credit;
   cb->cs[SIDE(cb)].rxWin = cb->qos.credit;
   cb->cs[SIDE(cb)].NPS = 0;
   cb->cs[SIDE(cb)].EPS = 0;
   cb->cs[SIDE(cb)].LPR = 0;
   cb->cs[SIDE(cb)].TPR = 0;

   /* flush this side's queue */
   spFlushQueue(&cb->cs[SIDE(cb)].datQ);
   spFlushQueue(&cb->cs[SIDE(cb)].eDatQ);

   /* if we are an endpoint, reset incoming */
   if (!(cb->cType & SP_INTR))
   {
      cb->cs[SIDE(cb)].flags |= RST_EXT;
      /* set new sate */
      cb->state = RST_ST(SIDE(cb));
      /* propagate reset up */
      spRstReq(cb, OPSIDE(cb), ((SpResReq *)cb->info)->resCause.resCause.val);
      RETVOID;
   }

   /* we're intermediate node */

   /* reset calling side variables */
   cb->cs[OPSIDE(cb)].flags |= RST_EXT;
   cb->cs[OPSIDE(cb)].flags &= (U8)(~EDA_PEN); /* turn off exp data pending */
   cb->cs[OPSIDE(cb)].txWin = cb->qos.credit;
   cb->cs[OPSIDE(cb)].rxWin = cb->qos.credit;
   cb->cs[OPSIDE(cb)].NPS = 0;
   cb->cs[OPSIDE(cb)].EPS = 0;
   cb->cs[OPSIDE(cb)].LPR = 0;
   cb->cs[OPSIDE(cb)].TPR = 0;

   /* flush calling side queue */
   spFlushQueue(&cb->cs[OPSIDE(cb)].datQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].eDatQ);


   /* state is resetting called side */
   cb->state = RST_ST(OPSIDE(cb));

   /* send back reset confirm (spoofing) */
   spRstCfm(cb, SIDE(cb));

   /* sp034.302 - addition - check cb, cb might have been freed
    * in some error case during above func spRstCfm
    */
   if (cb != (SpConCb *) NULLP)
   {
      /* send reset request to opposite side */
      spRstReq(cb, OPSIDE(cb), ((SpResReq *)cb->info)->resCause.resCause.val);
   }

   RETVOID;
} /* end of spLiRrDtx */


/*
*
*       Fun:   spLiRrOpp
*
*       Desc:  Reset Request Either Side, Resetting Opposite
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRrOpp
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRrOpp(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiRrOpp)

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /* restart receive timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));

   /* reset this side's variables */
   cb->cs[SIDE(cb)].txWin = cb->qos.credit;
   cb->cs[SIDE(cb)].rxWin = cb->qos.credit;
   cb->cs[SIDE(cb)].NPS = 0;
   cb->cs[SIDE(cb)].EPS = 0;
   cb->cs[SIDE(cb)].LPR = 0;
   cb->cs[SIDE(cb)].TPR = 0;
   cb->cs[SIDE(cb)].flags = 0;
   cb->cs[SIDE(cb)].flags &= (U8)(~EDA_PEN); /* turn off exp data pending */

   /* flush this side's queue */
   spFlushQueue(&cb->cs[SIDE(cb)].datQ);
   spFlushQueue(&cb->cs[SIDE(cb)].eDatQ);

   /* new state is the same */
   /*
   cb->state = RST_ST(OPSIDE(cb));
   */

   /* send back reset confirm (spoofing) */
   spRstCfm(cb, SIDE(cb));

   RETVOID;
} /* end of spLiRrOpp */


/*
*
*       Fun:   spLiRstCfm
*
*       Desc:  Reset confirm  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiRstCfm
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiRstCfm(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiRstCfm)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP - Reset Confirm %s\n", SIDE(cb) ? "CD_SIDE" : "CG_SIDE"));

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /* stop reset timer */
   spRmvConCbTq(cb, RST_TMR(SIDE(cb)));

   /* restart receive timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));


   if (cb->state == RBT_ST)
      cb->state = RST_ST(OPSIDE(cb));
   else
      cb->state = DTX_ST;

   /* if this was an external reset
    * propagate confirm up
    */
   if (!(cb->cType & SP_INTR) && cb->cs[SIDE(cb)].flags & RST_EXT)
      spRstCfm(cb, OPSIDE(cb));

   /* sp034.302 - addition - check cb, cb might have been freed
    * in some error case during above func spRstCfm
    */
   if (cb != (SpConCb *) NULLP)
   {
      cb->cs[SIDE(cb)].flags = 0;

      spCheckDatQ(cb, SIDE(cb));
   }

   RETVOID;
} /* end of spLiRstCfm */


/*
*
*       Fun:   spLiInactTst
*
*       Desc:  Inactivity test
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiInactTst
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiInactTst(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   SpInactTst *it;

   TRC2(spLiInactTst)

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   it = (SpInactTst*)cb->info;

   /* restart receive inactivity timer */
   spRmvConCbTq(cb, IAR_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIarTmr.val;
   spStartConCbTmr(cb, IAR_TMR(SIDE(cb)));

   /* validate protocol class */
   if (cb->qos.pClass != it->pClass.pClass.val)
   {
      /* 
       * Since PCLASS is not a paramter for Relase message,
       * we cant dish out the same treatment as for a bad slr 
       */
      /* send service class mismatch error */
      spSendPduErr(cb->cs[SIDE(cb)].nSap, cb->cs[SIDE(cb)].pc, 
         cb->cs[SIDE(cb)].conId.suInstId, ERR_SCMM, cb->ssf);
      /* first stop any inactivity timers */
      if (cb->cType & SP_ORIG) /* I'm an originating node */
      {
         spRmvConCbTq(cb, CD_IAS_TMR);
         spRmvConCbTq(cb, CD_IAR_TMR);
      }
      else if (cb->cType & SP_DEST) /* I'm an destination node */
      {
         spRmvConCbTq(cb, CG_IAS_TMR);
         spRmvConCbTq(cb, CG_IAR_TMR);
      }
      else if (cb->cType & SP_INTR) /* I'm an intermediate node */
      {
         spRmvConCbTq(cb, CD_IAR_TMR);
         spRmvConCbTq(cb, CD_IAS_TMR);
         spRmvConCbTq(cb, CG_IAR_TMR);
         spRmvConCbTq(cb, CG_IAS_TMR);
      }
      /* release both sides (inconsistent connection data) */
      spRelease(cb, SIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
      spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
      spCb.sts.prvInitRel++;
      RETVOID;
   }

   if (cb->qos.pClass == PCLASS3)
   {
      /* AUDIT RECEIVED INFO */
      if (it->seqSeg.senSeqNum.val != cb->cs[SIDE(cb)].EPS)
      {
         /* Initiate reset */
         spIntRst(cb, RSC_MOOINCPS);
         RETVOID;
      }
      if (it->seqSeg.recSeqNum.val != cb->cs[SIDE(cb)].LPR)
      {

         spIntRst(cb, RSC_MOOINCPR);
         RETVOID;
      }
      if (it->seqSeg.moreData.val != cb->cs[SIDE(cb)].lstMoreRx)
      {

         spIntRst(cb, RSC_UNQUAL);
         RETVOID;
      }
   }

   RETVOID;
} /* end of spInactTst */


/*
*
*       Fun:   spLiPduErr
*
*       Desc:  Handle Pdu error 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiPduErr
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiPduErr(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   U8 ec;              /* error cause */
   SpAllPdus *pdu;     /* pdu */
   REG1 U8 tNum;       /* counter */

   TRC2(spLiPduErr)

   pdu = (SpAllPdus *) cb->info;
   ec = pdu->m.pduErr.errCause.errCause.val;

   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer *) NULLP;
   }

   switch (ec)
   {
      case ERR_SCMM:
         /* remove all timers! */
         for (tNum = 0; tNum < MAXCONTMR; tNum++)
            if (cb->timers[tNum].tmrEvnt != TMR_NONE)
               spRmvConCbTq(cb, (U8) cb->timers[tNum].tmrEvnt);

         /* freeze the opposite side if we're an endpoint */
         if (!(cb->cType & SP_INTR))
            spFreezeSlr(cb, FRZ_SIDE(OPSIDE(cb)));

         spRelease(cb, OPSIDE(cb), RLC_REMPROC, ORIG_NET, NULLP);
         spRelease(cb, SIDE(cb), RLC_REMPROC, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         spCb.sts.prvInitRel++;
         break;

      case ERR_LRNUD:
      case ERR_LRNIS:
      case ERR_PCMM:
      case ERR_UNQUAL:
      default:
         spFreezeSlr(cb, SP_FRZ_BT);
         spFreeConCb(cb);
   } /* switch (ec) */

   RETVOID;
} /* spLiPduErr */


/*
*
*       Fun:   spLiIntRst
*
*       Desc:  Lower interface, internal reset 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiIntRst
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiIntRst(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{

   TRC2(spLiIntRst)

   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   spIntRst(cb, RSC_UNQUAL); /* unqualified */
   RETVOID;

} /* end of spLiIntRst */


/*
*
*       Fun:   spLiSCMM
*
*       Desc:  Service Class Mismatch
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spLiSCMM
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spLiSCMM(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spLiSCMM)

   /* Send a service class mismatch error */
   /* sp005.302 - modification - pass suInstId (dstLclRef) in ERR msg,
    * and not spInstId
    */
   spSendPduErr(cb->cs[SIDE(cb)].nSap, cb->cs[SIDE(cb)].pc, 
                cb->cs[SIDE(cb)].conId.suInstId, ERR_SCMM, cb->ssf);

   /* Discard Message */
   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   RETVOID;
} /* end of spLiSCMM */


/*
 * Upper Interface State Matric Functions
 */

/*
*
*       Fun:   spUiErrUp
*
*       Desc:  error from upper interface
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiErrUp
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiErrUp(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spUiErrUp)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "SCCP -- ERR UI\n"));

   /* Send Release Back */
   switch(cb->state)
   {
      /* connected states */
      case DTX_ST:
      case RCG_ST:
      case RCD_ST:
      case RBT_ST:
      {
         /* sp016.302 - addition */
         S16 ret;
         Buffer *mBuf1;

         /* sp016.302 - addition - copy buffers */
         if (mBuf != (Buffer *) NULLP)
         {
            ret = SCpyMsgMsg(mBuf, spCb.spInit.region, spCb.spInit.pool,
                             &mBuf1);
            if (ret != ROK)
            {
               SPLOGERROR(ERRCLS_ADD_RES, ESPXXX, (ErrVal) ret,
                          "SCpyMsgMsg failed");
               RETVOID;
            }
         }
         else
         {
            mBuf1 = (Buffer *) NULLP;
         }

         /* release both sides */
         spFreezeSlr(cb, FRZ_SIDE(SIDE(cb)));
         spRelease(cb, SIDE(cb), RLC_NOTOBTN, ORIG_NET, mBuf);
         /* sp016.302 - modification - pass new duplicated buffer */
         spRelease(cb, OPSIDE(cb), RLC_NOTOBTN, ORIG_NET, mBuf1);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         spCb.sts.prvInitRel++;
         break;
      }
      default:
      {
         /* freeze both, we'll indicate to our user, and then punt */
         spFreezeSlr(cb, SP_FRZ_BT);
         /* error cause is Not Obtainable */
         spRelease(cb, SIDE(cb), RLC_NOTOBTN, ORIG_NET, mBuf);
         spFreeConCb(cb);
         spCb.sts.prvInitRel++;
         break;
      }
   }

   RETVOID;
} /* end of spUiErrUp */


/*
*
*       Fun:   spUiConReq0
*
*       Desc:  Connection Request from upper interface
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiConReq0
(
SpConCb *cb,                   /* calling connection control block */
Buffer *data                   /* data  buffer */
)
#else
PRIVATE Void spUiConReq0(cb, data)
SpConCb *cb;                   /* calling connection control block */
Buffer *data;                  /* data  buffer */
#endif
{
   SpConEvnt *ce;              /* the connection event */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing sccp entities */
   U8 nextEntity;              /* next sccp entity to be selected */
   U8 cause;                   /* cause of failure in routing/refusal cause */
   U8 mode;                    /* mode of operation of sccp entities */
   Bool noCplng;               /* coupling flag, not valid in orig conReq */
   U8 flag;                    /* return flags */
   SpRteCb *rCb;               /* Route Control Block */
   SpSapCb *cdSap;             /* called sap */
   S16 ret;                    /* return value */
   U8 i;                       /* loop counter */
   Bool foundRoute;            /* flag */
   U16 repCause;               /* sccp error perf/subsys availability report */
   SpNwCb *outNwData;          /* sp045.302 - addition - outgoing network CB */

   TRC2(spUiConReq0)

   /* sp044.302 - addition - Initialization of Local Variables */   
   cause = 0;   
   repCause = 0;   

   ce = (SpConEvnt *) cb->info;
   
   cb->cType = SP_ORIG|SP_REQ0;

   cb->t.req0.rcs = ce->t.req0.rcs;
   cb->t.req0.eds = ce->t.req0.eds;

   /* calling side */
   cb->cs[SIDE(cb)].conId.suId = cb->sap->suId;
   /* sp045.302 - modification - nwDAta moved to cs[] */
   cb->cs[SIDE(cb)].pc = cb->cs[SIDE(cb)].nwData->selfPc;
   cb->cs[SIDE(cb)].conId.suInstId = ce->conId.suInstId;

   /* sp045.302 - modification - initialise outNwData */
   outNwData = cb->cs[SIDE(cb)].nwData;
#ifdef CMSS7_SPHDROPT
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if the flag is uninitialised */
   if ((ce->t.req0.cgAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ce->t.req0.cgAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP339, (ErrVal) ce->t.req0.cgAddr.spHdrOpt,
                 "spUiConReq0, cgAddr spHdrOpt uninitialized  failed");
      ce->t.req0.cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field was uninitialized */
   }

   /* Check if the flag is uninitialised */
   if ((ce->t.req0.cdAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ce->t.req0.cdAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP340, (ErrVal) ce->t.req0.cdAddr.spHdrOpt,
                 "spUiConReq0, cdAddr spHdrOpt uninitialized  failed");
      ce->t.req0.cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field was uninitialized */
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
#endif /* CMSS7_SPHDROPT */

   /* sp024.302 - addition - perform calling party address treatment as per
    * ITU Q.714, section 2.7.5.2, (a). At this point, we can not determine
    * whether coupling will be done at next node or not so if routing ind of
    * called party addr is RTE_GT then fill cg pc and ssn as self pc and self
    * ssn in calling party address if they are not already provided in cgAddr.
    */
   if (ce->t.req0.cdAddr.rtgInd == RTE_GT)
   {
      if (ce->t.req0.cgAddr.pres == TRUE)
      {
         /* Fill pc and ssn in cgAddr. Inclusion of pc in cgAddr of
          * outgoing CR message depends on the value of spHdrOpt in
          * cgAddr. If the spHdrOpt indicates CMSS7_NO_SP_PC then
          * pc will not be encoded in cgAddr in outgoing CR and
          * the next node will have to construct it from opc of MTP
          * routing label. Otherwise pc will be endoced in cgAddr.
          */
         if (ce->t.req0.cgAddr.pcInd == FALSE)
         {
            /* sp045.302 - modification - nwDAta moved to cs[] */
            ce->t.req0.cgAddr.pc = cb->cs[SIDE(cb)].nwData->selfPc;
            ce->t.req0.cgAddr.pcInd = TRUE;
         }

         if (ce->t.req0.cgAddr.ssnInd == FALSE)
         {
            ce->t.req0.cgAddr.ssn = cb->sap->ssn;
            ce->t.req0.cgAddr.ssnInd = TRUE;
         }
      }
      else /* cgAddr absent, construct it from local pc and ssn */
      {
#ifdef CMSS7_SPHDROPT
         /* we are constructing cgAddr and so in this case we
          * always want to include PC in cgAddr unless the flag
          * SP_PRESERVE_ADDR is defined. If the flag is defined
          * then we will not include pc and the next node will
          * have to construct cgPc from opc of MTP routing label.
          * If flag is not defined then we will include the pc.
          */
#ifdef SP_PRESERVE_ADDR
         ce->t.req0.cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#else  /* SP_PRESERVE_ADDR */
         ce->t.req0.cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

         ce->t.req0.cgAddr.pres = TRUE;
         ce->t.req0.cgAddr.sw = ce->t.req0.cdAddr.sw;
         ce->t.req0.cgAddr.ssfPres = ce->t.req0.cdAddr.ssfPres;
         ce->t.req0.cgAddr.ssf = ce->t.req0.cdAddr.ssf;
         ce->t.req0.cgAddr.niInd = ce->t.req0.cdAddr.niInd;
         ce->t.req0.cgAddr.rtgInd = RTE_SSN;
         ce->t.req0.cgAddr.ssnInd = TRUE;
         ce->t.req0.cgAddr.pcInd = TRUE;
         ce->t.req0.cgAddr.ssn = cb->sap->ssn;
         /* sp045.302 - modification - nwDAta moved to cs[] */
         ce->t.req0.cgAddr.pc = cb->cs[SIDE(cb)].nwData->selfPc;
         ce->t.req0.cgAddr.gt.format = GTFRMT_0;
      }
   }

   /* copy called and calling address from conEvent struct into ConCb */
   cmCopySpAddr(&ce->t.req0.cgAddr, &cb->t.req0.cgAddr);
   cmCopySpAddr(&ce->t.req0.cdAddr, &cb->t.req0.oCdAddr);

   /* resolve called address, we pass class 0 for loadsharing */
   /* sp045.302 - modification - pass ptr to nwCb instead of selfPc 
    * pass ptr to outgoing network CB
    */
   ret = spResolveAddr(&cb->t.req0.oCdAddr, PCLASS0, &numEntity, &nextEntity,
                       &mode, &cdAddr[0], &noCplng, cb->cs[SIDE(cb)].nwData,
                       &outNwData);
   if (ret == SP_ERROR)
   {
      SpReport spRep;    /* sccp error perf report */

      /* fill sccp error report */
      cmZero((U8 *) &spRep, sizeof(SpReport));
      /* sp045.302 - modification - nwDAta moved to cs[] */
      spRep.nwId = cb->cs[SIDE(cb)].nwData->nwId;
      spRep.sw = cb->cs[SIDE(cb)].nwData->variant;
      cmCopySpAddr(&cb->t.req0.oCdAddr, &spRep.cdPa);
      cmCopySpAddr(&cb->t.req0.cgAddr, &spRep.cgPa);

      /* generate sccp error performance report */
      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NTSPECADDR,
                       &spRep);

      /* increment statistics counter */
      spCb.sts.rfNTSA++;

      /* refuse conn req and free conCb */
      SPLOGERROR(ERRCLS_INT_PAR, ESP341, (ErrVal) ret, "Invalid called addr");

      /* sp014.302 - addition - freeze slr */ 
      spFreezeSlr(cb, SP_FRZ_BT);

      spConRefused(cb, RFC_UNQUAL, ORIG_NET, data);
      spFreeConCb(cb);
      RETVOID;
   }
   else
   {
      /* for connection request, if mode of operation of sccp entities
       * is dominant then first the availability of sccp entity at
       * index 0 is being checked. Hence set nextEntity as zero. In
       * case of loadshare mode the first sccp entity to be checked for
       * availability is the entity at an index nextEntity, returned
       * by spResolveAddr.
       */
      if (mode == DOMINANT)
         nextEntity = 0;
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;

      /* sp045.302 - addition - check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * generate error report.
       */
      if ((cb->cs[SIDE(cb)].nwData->nwId != outNwData->nwId) && 
          (cb->cs[SIDE(cb)].nwData->variant != outNwData->variant))
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spUiHndlUDatReq: Varaints are not same for incoming and\
                 outgoing networks : incoming network id = %d,\
                 outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", cb->cs[SIDE(cb)].nwData->nwId,
                 outNwData->nwId, cb->cs[SIDE(cb)].nwData->variant,
                 outNwData->variant));

         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);

         /* sp014.302 - addition - freeze slr */ 
         spFreezeSlr(cb, SP_FRZ_BT);

         /* initiate connection refusal procedure */
         spConRefused(cb, (U8) cause, ORIG_NET, data);
         spFreeConCb(cb);
         RETVOID;
      }
      /* for checkRoute function, connection request is handled similar 
       * to class 0 data request. Hence class is passed as PCLASS0 only.
       */
      /* sp045.302 - modification - pass ptr to outgoing network CB */ 
      ret = spCheckRoute(outNwData, &cdAddr[nextEntity], 0, PCLASS0,
                            &rCb, &flag, &cdSap, FROM_UPPER);
      switch (ret)
      {
         case SP_UNEQUIP:     /* user unequipped, (Loop back ) */
            spCb.sts.rfUnequip++;
            cause = RFC_UNEQUIP;
            repCause = LSP_CAUSE_RTF_UNEQUIP;
            break;

         case SP_OK:          /* route up; destination accessible */
            /* copy new called address into con req event */
            cmCopySpAddr(&cdAddr[nextEntity], &cb->t.req0.cdAddr);
            foundRoute = TRUE;
            break;

         case SP_SSFAIL:      /* subsystem is prohibited */
            cause = (U8) RFC_SSFAIL;
            spCb.sts.rfSsnFail++;
            repCause = LSP_CAUSE_RTF_SSFAIL;
            break;

         case SP_SPFAIL:      /* signalling point is inaccessible */
            cause = (U8) RFC_DSTADRIN;
            spCb.sts.rfNetFail++;
            repCause = LSP_CAUSE_RTF_NETFAIL;
            break;

         case SP_LOCAL:       /* (Loop back) - fall through */
         default:             /* route doesn't exist, or other logical error */
            spCb.sts.rfUnknown++;
            cause = (U8) RFC_UNQUAL;
            break;
      } /* switch (ret) */

      /* increment nextEntity in modulo fashion with numEntity */
      nextEntity++;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)
   {
      /* sp046.302 - addition - debug prints to indicate routing error */
      if ((cause == RFC_UNQUAL) || (repCause == LSP_CAUSE_RTF_NETFAIL) || 
          (repCause == LSP_CAUSE_RTF_SSFAIL))
      {
         for (i = 0; i < numEntity; i++)
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   " Routing failure for dpc %x and ssn %x\n",
                   cdAddr[i].pc, cdAddr[i].ssn));
      }
      /* route not found, send alarm to LM */
      if (cause == RFC_UNQUAL)
      {
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
      }
      else
      {
         SpReport spRep;    /* sccp error perf/subsys availability report */

         cmZero((U8 *) &spRep, sizeof(SpReport));
         
         /* sp045.302 - modification - network id and variant of out network */ 
         spRep.nwId = cb->cs[SIDE(cb)].nwData->nwId;
         spRep.sw = cb->cs[SIDE(cb)].nwData->variant;
         cmCopySpAddr(&cdAddr[nextEntity - 1], &spRep.cdPa);
         cmCopySpAddr(&cb->t.req0.cgAddr, &spRep.cgPa);

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, repCause, &spRep);
      }

      /* sp014.302 - addition - freeze slr */ 
      spFreezeSlr(cb, SP_FRZ_BT);

      /* initiate connection refusal procedure */
      spConRefused(cb, (U8) cause, ORIG_NET, data);
      spFreeConCb(cb);
      RETVOID;
   }

   if (!(rCb->nSap->status & SP_BND))
   {
      SpDisEvnt dis;           /* disconnect event data */

      cmCopy((U8 *) &ce->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));

      /* do set responding address to true if route is GSM0806 */
      if (rCb->swtch != LSP_SW_GSM0806)
      {
         dis.rspAddr.pres = TRUE;
         dis.rspAddr.pc = rCb->nSap->nwData->selfPc;
      }
      else
         dis.rspAddr.pres = FALSE;

      dis.rsn =  RFC_NRQOSNT;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not revelant in discon indication to user,
       * mark it as not present
       */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* send disconnect indication up */
      (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data);

      /* sp014.302 - addition - freeze slr */ 
      spFreezeSlr(cb, SP_FRZ_BT);

      /* free connection control block */
      spFreeConCb(cb);

      RETVOID;
   }
  
   /* check if the guard timer has started */
   if (rCb->nSap->status & SP_GUARD)
   {
      SpDisEvnt dis;            /* disconnect event data */

      cmCopy((U8 *) &ce->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
      /* do set responding address to true if route is GSM0806 */
      if (rCb->swtch != LSP_SW_GSM0806)
      {
         dis.rspAddr.pres = TRUE;
         dis.rspAddr.pc = rCb->nSap->nwData->selfPc;
      }
      else
         dis.rspAddr.pres = FALSE;

      dis.rsn =  RFC_NRQOST;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not revelant in discon indication to user,
       * mark it as not present
       */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* send disconnect indication up */
      (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data);

      /* sp014.302 - addition - freeze slr */ 
      spFreezeSlr(cb, SP_FRZ_BT);

      /* free connection control block */
      spFreeConCb(cb);

      RETVOID;
   }

   /* Fill the default hop counter for ITU96, ANS92, ANS96 and BELL05 */
   switch (rCb->swtch)
   {
      case LSP_SW_ITU88:      /* fall through */


      case LSP_SW_ITU92:      /* fall through */

              
      case LSP_SW_CHINA:      /* fall through */
         cb->hopCntr.pres = FALSE;
         break;




      case LSP_SW_ITU96:
         cb->hopCntr.pres = TRUE;
         cb->hopCntr.val = rCb->nSap->nwData->defHopCnt;
         break;
         
      default:
         {
            /* Error case, this should never happen, refuse conReq */
            SpDisEvnt dis;            /* disconnect event data */

            cmCopy((U8 *) &ce->conId, (U8 *) &dis.conId, sizeof(SpConId));
            cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
            dis.rspAddr.pres = TRUE;
            dis.rspAddr.pc = rCb->nSap->nwData->selfPc;
            dis.rsn =  RFC_NRQOST;
            dis.orig = ORIG_NET;
#ifdef SPTV2
            /* importance is not revelant in discon indication to user,
             * mark it as not present
             */
            dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

            /* send disconnect indication up */
            (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data);

            /* sp014.302 - addition - freeze slr */ 
            spFreezeSlr(cb, SP_FRZ_BT);

            /* free connection control block */
            spFreeConCb(cb);

            RETVOID;
         }
   } /* switch (...swtch) */

   /* fill connection side info */
   cb->cs[OPSIDE(cb)].swtch = rCb->swtch;
   cb->cs[OPSIDE(cb)].nSap = rCb->nSap;
   cb->cs[OPSIDE(cb)].conId.suId = rCb->nSap->suId;

   /* cb->cd.conId.suInstId is set at connection confirm */

   cb->cs[OPSIDE(cb)].pc = cb->t.req0.cdAddr.pc;
   /* sp045.302 - addition - initialise the nwData of OPSIDE 
    * with outNwData. 
    */
   cb->cs[OPSIDE(cb)].nwData = outNwData;

   /* sp026.302 - removal - remove function call spAddCon. This
    * function was to maintain conn hash list based on CG_KEY,
    * CD_KEY and SU_KEY and is no longer used.
    */

   spConRequest(cb, data);

   RETVOID;
} /* spUiConReq0 */


/*
*
*       Fun:   spUiConReq1
*
*       Desc:  Connection Request type 1
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiConReq1
(
SpConCb *cb,           /* calling connection control block */
Buffer *data           /* data  buffer */
)
#else
PRIVATE Void spUiConReq1(cb, data)
SpConCb *cb;           /* calling connection control block */
Buffer *data;          /* data  buffer */
#endif
{
   SpConEvnt *ce;      /* the connection event */

   TRC2(spUiConReq1)

   ce = (SpConEvnt *) cb->info;
   
   cb->cType = SP_ORIG|SP_REQ1;

   cb->t.req1.rcs = ce->t.req1.rcs;
   cb->t.req1.eds = ce->t.req1.eds;

   /* calling side */
   cb->cs[SIDE(cb)].conId.suId = cb->sap->suId;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->cs[SIDE(cb)].pc = cb->cs[SIDE(cb)].nwData->selfPc;
   cb->cs[SIDE(cb)].conId.suInstId = ce->conId.suInstId;

   cb->cs[OPSIDE(cb)].conId.suId = cb->sap->suId;
   /* 
    * cb->cd.conId.suInstId is set at connection confirm
    */

   /* sp026.302 - removal - remove function call spAddCon. This
    * function was to maintain conn hash list based on CG_KEY,
    * CD_KEY and SU_KEY and is no longer used.
    */

   spConRequest(cb, data);

   RETVOID;
} /* spUiConReq1 */


/*
*
*       Fun:   spUiConReq2
*
*       Desc:  Connection request 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiConReq2
(
SpConCb *cb,           /* calling connection control block */
Buffer *data           /* data  buffer */
)
#else
PRIVATE Void spUiConReq2(cb, data)
SpConCb *cb;           /* calling connection control block */
Buffer *data;          /* data  buffer */
#endif
{

   SpConEvnt *ce;      /* the connection event */
   SpRteKey rKey;
   SpRteCb *rCb;


   TRC2(spUiConReq2)

   ce = (SpConEvnt*)cb->info;
   
   cb->t.req2.nwInd = ce->t.req2.nwInd;
   cb->t.req2.repReq = ce->t.req2.repReq;
   cb->t.req2.refInd = ce->t.req2.refInd;

   /* Form the route key for searching */
   rKey.k1.dpc = ce->t.req2.opc;
   rKey.k1.nwId = cb->sap->nwData->nwId;

   /* find route */
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   if (rCb == (SpRteCb *) NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP342, (ErrVal) ERRZERO, "No route");
      RETVOID;
   }

   /* calling side */
   if (cb->t.req2.repReq) /* we are an intermediate node */
   {
      cb->cType = SP_INTR|SP_REQ2;

      /* this for the mystical upper user */
      cb->t.req2.usrId.suInstId = ce->conId.suInstId;
      cb->t.req2.usrId.suId = cb->sap->suId;
      /* use the calling side instance id */
      cb->t.req2.usrId.spInstId = cb->cs[SIDE(cb)].conId.spInstId;

      /* calling side */
      cb->cs[SIDE(cb)].nSap = rCb->nSap;
      cb->cs[SIDE(cb)].conId.suId = cb->cs[SIDE(cb)].nSap->suId;
      cb->cs[SIDE(cb)].conId.suInstId = ce->t.req2.slr; 
      cb->cs[SIDE(cb)].pc = ce->t.req2.opc;

      /* called side */
      cb->cs[OPSIDE(cb)].conId.suId = cb->sap->suId;
      if (ce->t.req2.refInd)
      {
         /* freeze slr */ 
         spFreezeSlr(cb, SP_FRZ_BT);
         /* send connection refused */
         spConRefused(cb, RFC_EUORIG, ORIG_NET, data);
         /* free control block */
         spFreeConCb(cb);
         RETVOID;
      }
   }
   else /* destination */
   {
      cb->cType = SP_DEST|SP_REQ2;

      /* calling side */
      cb->cs[SIDE(cb)].nSap = rCb->nSap;
      cb->cs[SIDE(cb)].conId.suId = cb->cs[SIDE(cb)].nSap->suId;
      cb->cs[SIDE(cb)].conId.suInstId = ce->t.req2.slr; 
      cb->cs[SIDE(cb)].pc = ce->t.req2.opc;

      /* called side */
      cb->cs[OPSIDE(cb)].conId.suId = cb->sap->suId;
      cb->cs[OPSIDE(cb)].conId.suInstId = ce->conId.suInstId;
      /* sp045.302 - modification - nwData moved to cs[] */ 
      cb->cs[OPSIDE(cb)].pc = cb->cs[OPSIDE(cb)].nwData->selfPc;

   }

   if (cb->t.req2.refInd) /* disconnect */
   {
      Buffer *data1;
      SpDisEvnt dis;
      S16 ret;

      /* DISCONNECT INDICATION */

      /* duplicate data for upper user */
      ret  = SCpyMsgMsg(data, cb->sap->pst.region, cb->sap->pst.pool, &data1);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP343, (ErrVal) ret, "SCPYMsgMsg failed");
      }
      else
      {
         cmCopy((U8*)&cb->t.req2.usrId, (U8*)&dis.conId, sizeof(SpConId));
         cmZero((U8*)&dis.rspAddr, sizeof(SpAddr));
         dis.rsn = RFC_EUORIG;
         dis.orig = ORIG_USR;
         dis.conId.suId = cb->sap->suId;
#ifdef SPTV2
         /* importance is not revelant in discon indication to user,
          * mark it as not present
          */
         dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
      
         /* check if the user has bound */
         if (cb->sap->status & SP_BND)
            (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data1);
         else
         {
            (Void) SPutMsg (data1);
         }
      }

      /* SEND CONNECTION REFUSED ON CALLING SIDE */
      /* freeze slr */ 
      spFreezeSlr(cb, SP_FRZ_BT);
      /* send connection refused */
      spConRefused(cb, RFC_EUORIG, ORIG_USR, data);
      /* free control block */
      spFreeConCb(cb);
      RETVOID;
   }

   /* sp026.302 - removal - remove function call spAddCon. This
    * function was to maintain conn hash list based on CG_KEY,
    * CD_KEY and SU_KEY and is no longer used.
    */
   spConRequest(cb, data);

   RETVOID;
} /* end of spUiConReq2 */


/*
*
*       Fun:   spUiConRsp
*
*       Desc:  Connection response 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiConRsp
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spUiConRsp(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   TRC2(spUiConRsp)

   /* we jump into the matrix as a means of knowing what state we're in */
   spConConfirm(cb, data);

   RETVOID;
} /* end of spUiConRsp */


/*
*
*       Fun:   spUiDatTx
*
*       Desc:  The data transfer routine...
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiDatTx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiDatTx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   S16 ret;            /* return value */
   MsgLen mLen;        /* message length */
   Buffer *txData;     /* buffer to transmit data */
   Bool more;          /* flag for M bit */

   TRC2(spUiDatTx)

   ret = SFndLenMsg(mBuf, &mLen); 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      (Void) SPutMsg(mBuf);
      SPLOGERROR(ERRCLS_DEBUG, ESP344, (ErrVal) ret, "SFndLenMsg failed");
      RETVOID;
   }
#endif /* ERRCLASS */

   if (mLen == 0) 
   {
      /* no message, do nothing */
      SPutMsg(mBuf);
      RETVOID;
   }

   more = TRUE;
   txData = mBuf;
   for(;;)
   {
      Buffer *rmData;       /* remianing data */

      if (mLen > SP_MAX_DLEN) 
      {
        /* segmentation is necessary */
        SSegMsg(txData, SP_MAX_DLEN, &rmData);
        if (rmData == (Buffer *) NULLP)
           more = FALSE;              /* no more */
      }
      else
           more = FALSE;              /* no more */

      if (cb->qos.pClass == PCLASS2)
         spDat1Tx(cb, txData, more);
      else
         if (cb->qos.pClass == PCLASS3)
            spDat2Tx(cb, txData, more);

      if (!more)
         break;       /* we're done */
      else
      {               /* prepare for next loop */
         mLen -= SP_MAX_DLEN;
         txData = rmData;
         rmData = (Buffer *) NULLP;
      }
   }
   RETVOID;
} /* end of spUiDatTx */


/*
*
*       Fun:   spUiEDatTx
*
*       Desc:  Expedited data transmission 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiEDatTx
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spUiEDatTx(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   TRC2(spUiEDatTx)

   spEDatTx(cb, data);

   RETVOID;
} /* end of spUiEDatTx */


/*
*
*       Fun:   spUiDisCon
*
*       Desc:  Disconnect from sccp user 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiDisCon
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PRIVATE Void spUiDisCon(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   SpDisEvnt *de;   /* sp021.302 - addition - disEvnt struct */

   TRC2(spUiDisCon)

   spFreezeSlr(cb, SP_FRZ_BT);

   /* sp021.302 - modification - pass reason for disCon as passed by user */
   de = (SpDisEvnt *) cb->info;

   spConRefused(cb, de->rsn, ORIG_USR, data);
   spFreeConCb(cb);

   RETVOID;
} /* end of spUiDisCon */


/*
*
*       Fun:   spUiDisDtx
*
*       Desc:  Disconnect with user 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiDisDtx
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiDisDtx(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   SpDisEvnt *de;

   TRC2(spUiDisDtx)

   de = (SpDisEvnt*)cb->info;

#ifdef SPTV2
   de->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));
   spRmvConCbTq(cb, IAR_TMR(OPSIDE(cb)));
   spFreezeSlr(cb, FRZ_SIDE(SIDE(cb))); /* freeze calling side */
   spRelease(cb, OPSIDE(cb), de->rsn, ORIG_USR, mBuf);

   /* sp034.302 - addition - free conCb if its in dead state */
   if (cb->cType & SP_DEAD)
      spFreeConCb(cb);

   RETVOID;
} /* end of spUiDisDtx */


/*
*
*       Fun:   spUiDisRls
*
*       Desc:  Disconnect user 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiDisRls
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiDisRls(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spUiDisRls)

   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   spFreezeSlr(cb, FRZ_SIDE(SIDE(cb)));

   /* sp034.302 - addition - free conCb if its in dead state */
   if (cb->cType & SP_DEAD)
      spFreeConCb(cb);

   RETVOID;
} /* end of spUiDisRls */


/*
*
*       Fun:   spUiRstReq
*
*       Desc:  Disconnect request 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiRstReq
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiRstReq(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spUiRstReq)

   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /* we're either called or calling  */

   /* if this connection flags flags != 0
    * then this is a collision, unset flags and
    * return
    */
   if ( cb->cs[SIDE(cb)].flags != 0 )
   {
      cb->cs[SIDE(cb)].flags =0;
      if (cb->state == RBT_ST)
         cb->state = RST_ST(OPSIDE(cb));
      else
         cb->state = DTX_ST;
      RETVOID;
   }

   /* reset variables */
   cb->cs[OPSIDE(cb)].lstMoreTx = 0;
   cb->cs[OPSIDE(cb)].lstMoreRx = 0;
   cb->cs[OPSIDE(cb)].txWin = cb->qos.credit;
   cb->cs[OPSIDE(cb)].rxWin = cb->qos.credit;
   cb->cs[OPSIDE(cb)].NPS = 0;
   cb->cs[OPSIDE(cb)].EPS = 0;
   cb->cs[OPSIDE(cb)].LPR = 0;
   cb->cs[OPSIDE(cb)].TPR = 0;
   cb->cs[OPSIDE(cb)].flags |= RST_EXT;
   cb->cs[OPSIDE(cb)].flags &= (U8)(~EDA_PEN); /* turn off exp data pending */

   /* drain data transfer que */
   spFlushQueue(&cb->cs[OPSIDE(cb)].datQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].eDatQ);

   /* set new state */
   cb->state = RST_ST(OPSIDE(cb));

   /* send reset request to appropriate side */
   spRstReq(cb, OPSIDE(cb), ((SpRstEvnt*)cb->info)->rsn);

   RETVOID;
} /* end of spUiRstReq */


/*
*
*       Fun:   spUiRstRsp
*
*       Desc:  Reset response 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiRstRsp
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiRstRsp(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spUiRstRsp)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP - Reset Response\n"));

   if (mBuf)
   {
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   /*
    * if state == RBT_ST, we are resetting both due
    * to internal error, 
    */
   if (cb->state == RBT_ST) 
      cb->state = RST_ST(OPSIDE(cb));
   else
      cb->state = DTX_ST; /* we resume data tx */

   /* this side is done resetting */
   cb->cs[SIDE(cb)].flags = 0;

   /* if this is an external reset */
   if (cb->cs[OPSIDE(cb)].flags & RST_EXT)
   {
      /* confirm to remote */
      cb->cs[OPSIDE(cb)].flags = 0;
      spRstCfm(cb, OPSIDE(cb));

      /* sp034.302 - addition - check cb, cb might have been freed
       * in some error case during above func spRstCfm
       */
      if (cb != (SpConCb *) NULLP)
      {
         /* confirm to user */
         spRstCfm(cb, SIDE(cb));
      }
   }
   RETVOID;
} /* end of spUiRstRsp */


/*
*
*       Fun:   spUiDatRst
*
*       Desc:  Send data reset 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy5.c
*
*/
#ifdef ANSI
PRIVATE Void spUiDatRst
(
SpConCb *cb,           /* connection control block */
Buffer *mBuf           /* message buffer */
)
#else
PRIVATE Void spUiDatRst(cb, mBuf)
SpConCb *cb;           /* connection control block */
Buffer *mBuf;          /* message buffer */
#endif
{
   TRC2(spUiDatRst)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "SCCP - Data Reset\n"));

   /* we are resetting, either called, calling or both 
    *
    * If we are resetting the opposite side, allow transfer 
    * which will queue on opposite side.
    * Otherwise, discard...
    *
    */
   if ( cb->state == RST_ST(OPSIDE(cb)) )
       spUiDatTx(cb, mBuf);
   else 
   {
      /* Discard... */
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }

   RETVOID;
} /* end of spUiDatRst */
#endif /* SPCO */


/********************************************************************30**
  
         End of file:     cp_bdy5.c@@/main/13_1 - Tue Jan 22 15:16:10 2002
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.

1.2          ---  fmg   1. miscellaneous changes

1.3          ---  fmg   1. update for new system services

1.4          ---  scc   1. text changes

1.5          ---  scc   1. changes to handle ANSI 92 variant
             ---  scc   2. correct bug in spLiDataAck: inactivity
                           receive timer (IarTmr) was assigned interval 
                           timer (IntTmr) value. 

1.6          ---  fmg   1. removed cm2.x include
1.7          ---  fmg   1. fixed spId/suId problem

1.8          ---  mjp   1. check if user has bound before calling
                           primitives
             ---  mjp   2. update error codes

1.9          ---  mjp   1. replace previous error function with SPLOGERROR
             ---  mjp   3. changed SP_FLCOFF to SP_FLCON
             ---  mjp   4. added direction to spResolveAddr calls
             ---  mjp   5. add SPutMsg to spLiErr2, spLiSCMM, spLiRcRls, 
                           spLiInactTst, spLiCfConCd, spLiRstCfm, spLiRrOpp,
                           spLiRrDtx, spLiDataTx, spUiRstRsp, spLiCcConCd
             ---  mjp   6. remove SputMsg from spUiErrUp
             ---  mjp   7. spLiCfConCd - reference conRef pdu instead
                           of relsd pdu
********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.10         sp006.27 ash  1. Fix in spLiCfConCd function to avoid crash
                           2. support for common hash library
                      cp   3. Made changes as required by TCR0003 for 
                              Debug Msg generation.  
                           4. Stop all Release associated timers in spLiRcRls.
                           5. Correct handling of IT with wrong val of pclass.

/main/11     ---      cp   1. Changes for the new GTT framework.
             ---      vb   2. Clean up of the patches
                           3. Changes made for support of spHdrOpt for 
                              connection type CE_REQ0 _only_.
             ---      vb   4. Updated code as per design spec 1010030.12

/main/13     ---      cp   1. DFTHA related mods.
            sp005.301 sg   2. Modified code to check for the ammount of times
                              we have recurssivly called spCheckRoute.    If we
                              exceed a defined maximum, we should return an
                              error.  Otherwise, we can cause a core dump,
                              by infinitly calling the function recursivly.
/main/13_1   ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302  rc   1. Sid correction
             sp005.302  rc   1. Correction in lclRef sent in ERR message.
            sp013.302 sg  2. Free connection block when freeze timer disabled.
             sp014.302  rc   1. Before freeing conCb, freeze slr .
             sp015.302  rc   1. replacing errlog prints with debug prints and
                                printing the conn state info and rcvd msg value.
             sp016.302  rc   1. Passing diff data buffer to spRelease when
                                sending release to both local user and remote
                                at the same time.
             sp021.302  rc   1. In func spUiDisCon, when refusing conn pass
                                reason as specified by user in disEvnt struct.
             sp024.302  rc   1. Performing calling part address treatment as
                                per ITU Q.714, section 2.7.5.2
             sp026.302  rc   1. Removed function call spAddCon. This function
                                was to maintain conn hash list based on CG_KEY,
                                CD_KEY and SU_KEY and is no longer used.
             sp034.302  rc   1. Free conCb when connection becomes dead.
                             2. Check conCb becoming null beacuse of error case
                                in previous function call.
             sp044.302  sm   1. Initialized the local variables to avoid warnings.
             sp045.302  mc   1. In spResolveAddr replacing selfPc with ptr to 
                                nwCb of incoming network and passing
                                ptr to outgoing network CB.
                             2. replacing nwData with outNwData in spCheckRoute
                                call to find route status in outgoing network.
                             3. initializing the ConCb's cs[]->nwData with
                                incoming and outgoing network CB.
             sp046.302 mc    1.  Added debug prints in case of spCheckRoute
                                 return indicates SP/SSN routing failure. This 
                                 is added because the present USTA indication
                                 doesnt indicate the PC or SSN.
*********************************************************************91*/
