/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - body 3
  
     Type:     C source file
 
     Desc:     C source code for SS7/SCCP Management Functions.
  
     File:     cp_bdy3.c
  
     Sid:      cp_bdy3.c@@/main/18_1 - Tue Jan 22 15:15:39 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */
  
/* local defines */
  
/* local externs */
  
/* forward references */
PRIVATE Void spHndlSSA ARGS((SpNSapCb*, Dpc, Dpc, Ssn));
PRIVATE Void spHndlSSP ARGS((SpNSapCb*, Dpc, Dpc, Ssn));
PRIVATE Void spHndlSST ARGS((SpNSapCb*, Dpc, Dpc, Ssn));
PRIVATE Void spHndlSOG ARGS((SpNSapCb*, Dpc, Dpc, Ssn, Smi));
PRIVATE Void spHndlSOR ARGS((NwId, Dpc, Dpc, Ssn, Smi));
PRIVATE Void spHndlSSC ARGS((SpNSapCb *, Dpc, U8));
  
/* public variable declarations */

/* private variable declarations */

/*
 *     support functions
 */
  
/*
 *
 *       Fun:   spMngtResume
 *
 *       Desc:  SCCP Management - resume
 *
 *       Ret:   None
 *
 *       Notes: Rec Q.714  
 *              Updated for ANSI T1.112-1988
 *
         File:  cp_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void spMngtResume
(
SpNSapCb *nSap,         /* network sap */
Dpc apc                 /* affected point code */
)
#else
PUBLIC Void spMngtResume(nSap, apc)
SpNSapCb *nSap;         /* network sap */
Dpc apc;                /* affected point code */
#endif
{
   SpRteCb* rCb;        /* route control block */
   SpRteKey rKey;       /* route key */
   REG1 S32 i;          /* counter */
   SpReport spRep;     /* sp035.302 - addition- sccp error perf/subsystem
                           availability report */
   
   TRC2(spMngtResume)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management Resume\n"));

   /* find resume route */
   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
      RETVOID;                   /* route does not exist, ignore */
 
   /* sp014.302 - modification - stop STA tmr and SST for rem sccp
    * if they are running. Mark rem sccp as available
    */
#ifdef SNT2
   spRmvRteCbTq(rCb, TMR_STA);       /* stop status check timer */
   rCb->rteStsFlag &= (U8) (~TMR_STA);
#endif /* SNT2 */

   /* stop SST timer for remote sccp if running */
   if (rCb->rteStsFlag & TMR_SST)
   {
      spRmvRteCbTq(rCb, TMR_SST);
      rCb->rteStsFlag &= (U8) (~TMR_SST);
   }

   rCb->sccpSts = RMT_SCCP_AVAIL;    /* remote sccp accessible */

   /* sp008.301 - Need to also check to make sure SCCP is uncongested.
      An online congested node should still process the MTP-RESUME */ 
   if ((rCb->status & SP_ONLINE) && !(rCb->status & SP_CONG)) /* sanity check */
      RETVOID;

   rCb->status |= SP_ONLINE;         /* mark sp allowed */
   rCb->status &= SP_UNCONG;         /* mark sp uncongested */

   if (rCb->nSap->status & SP_SNRST) /* MTP3 is still doin the restart proc */
   {
      /* Q.714 5.2.5 point 3 - mark SCCP and all subsystems as accessible */
      for (i = 0; i < (S32)rCb->nmbSsns; i++)
      {
         rCb->ssnList[i].status |= SS_ACC;  
         /* No timers should be running here as the route was already offline */
      }
   }
   else
   {
   /* sp008.301 - SCCP should mark the remote subsystem as available, starting 
    * the subsystem test timer is optional.  This is in accordance with ITU 92 
    * Q.714 section 5.2.3.  For our purposes, we will put the new functionality 
    * under a compile time flag. 
    */
/* sp021.302 - modification - change if to ifdef */
#ifdef SP_SSA_AVAILABLE
      for (i = 0; i < (S32)rCb->nmbSsns; i++)
         rCb->ssnList[i].status |= SS_ACC;
#else /* SP_SSA_AVAILABLE */
   /* sp047.302 - Addition - If management is turned off then mark all SSN'c
    * accessible. 
    */
#ifdef SP_CFGMG
   if (spCb.spCfg.mngmntOn == FALSE)
   {
      for (i = 0; i < (S32)rCb->nmbSsns; i++)
         rCb->ssnList[i].status |= SS_ACC;
   }
   else
#endif /* SP_CFGMG */
   {
      {
         /* set all subsystems to testing... */
         for (i = 0; i < (S32)rCb->nmbSsns; i++)
         {
            if (rCb->ssnList[i].ssFlgs & TMR_SST)
               continue;
            rCb->ssnList[i].ssFlgs |= TMR_SST;
            /* Start control block timer */
            rCb->ssnList[i].tmr.enb = rCb->nSap->nwData->defSstTmr.enb;
            rCb->ssnList[i].tmr.val = rCb->nSap->nwData->defSstTmr.val;
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                   "SCCP -- Management Resume Starting SST on %lx %d\n", apc,
                   rCb->ssnList[i].ssn));
         
            spStartSsnCbTmr(&rCb->ssnList[i], TMR_SST);
         }
      }
   }
#endif /* SP_SSA_AVAILABLE */

      spLocalBroadcast((U8) SP_ACC, nSap->nwData->variant, apc, (Ssn) NOTUSED, 
                        (Smi) NOTUSED, rCb->sccpSts, rCb->spRestrictComp.ril,
                        (U8) NOTUSED);
   }

   /* sp043.302 - modification - moving sccp report generation on receiving 
    * MTP-RESUME to after the nsap SP_SNRST check.
    */
      cmZero((U8 *) &spRep, sizeof(SpReport));   /* initialize spReport */
      /*fill spReport parameters */
      spRep.nwId = nSap->nwData->nwId;
      spRep.sw = nSap->nwData->variant;
      spRep.dpc = apc;
      spRep.ssn = SS_SCCPMNGT;
  
      /* send SCCP report */
      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RMT_SP_ACC, &spRep);

#ifdef ZP
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */   
   RETVOID;
} /* spMngtResume */

  
/*
 *
 *       Fun:   spMngtPause
 *
 *       Desc:  SCCP Management - pause
 *
 *       Ret:   None
 *
 *       Notes: Rec Q.714  
 *              Updated for ANSI T1.112-1988
 *
 *       File:  cp_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void spMngtPause
(
SpNSapCb *nSap,          /* network sap */
Dpc apc                  /* affected point code */
)
#else
PUBLIC Void spMngtPause(nSap, apc)
SpNSapCb *nSap;          /* network sap */
Dpc apc;                 /* affected point code */
#endif
{
   REG1 U8 i;       /* counter */
   SpReport spRep;   /* sp035.302 - addition - sccp error perf report */
   SpRteCb* rCb;    /* route control block */
   SpRteKey rKey;   /* route key */
   Smi smi;         /* subsystem multiplicity indicator */
  
   TRC2(spMngtPause)
  
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management Pause\n"));

   /* Find route pause route */
   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
      RETVOID;                      /* route does not exist, ignore */
  
   /* if sp is already prohibited, return */
   if (!(rCb->status & SP_ONLINE))
      RETVOID;

   rCb->status &= SP_OFFLINE;       /* mark sp prohibited */
   rCb->sccpSts = RMT_SCCP_INACC;   /* remote sccp inaccessible */

   /* reset rlm, rslm, cls and ril to zero */
   rCb->spRestrictLocal.rlm = 0;
   rCb->spRestrictLocal.rslm = 0;
   rCb->spRestrictLocal.cls = 0;
   rCb->spRestrictComp.ril = 0;

#ifdef SNT2
   if (!(rCb->status & SP_CONG))
   {
      /* start status enquiry timer for route to come up */
      rCb->rteStsFlag |= TMR_STA;
      rCb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
      rCb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
      spStartRteCbTmr(rCb, TMR_STA);
   }
#endif /* SNT2 */
  
   /* stop SST for remote sccp if running */
   if (rCb->rteStsFlag & TMR_SST)
   {
      spRmvRteCbTq(rCb, TMR_SST);
      rCb->rteStsFlag &= (U8) (~TMR_SST);
   }

   /* stop congestion timer for remote sccp if running */
   if (rCb->rteStsFlag & TMR_CON)
   {
      spRmvRteCbTq(rCb, TMR_CON);
      rCb->rteStsFlag &= (U8) (~TMR_CON);
   }

   /* loop through the subsystems */
   for (i = 0; i < rCb->nmbSsns; i++)
   {
      /* disable subsystem status test */
      if (rCb->ssnList[i].ssFlgs & TMR_SST)
      {
         spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
         rCb->ssnList[i].ssFlgs &= (U8)(~TMR_SST); /* unset SST flag */
      }
      
      /* set smi */
      if (rCb->ssnList[i].nmbBpc)
         smi = SMI_DUP;
      else
         smi = SMI_SOL;
      
      /* mark subsystem prohibited && translate to backup */
      rCb->ssnList[i].status &= SS_INACC;

      /* local broadcast of UOS */
      spLocalBroadcast((U8) SS_UOS, nSap->nwData->variant, apc,
                       rCb->ssnList[i].ssn, smi, rCb->sccpSts,
                       rCb->spRestrictComp.ril, (U8) FROM_LOWER);
   }


   /* local broadcast of PAUSE (SP_INACC) */
   spLocalBroadcast((U8) SP_INACC, nSap->nwData->variant, apc, (Ssn) NOTUSED, 
                    (Smi) (rCb->nmbBpc?SMI_DUP:SMI_SOL), rCb->sccpSts,
                    rCb->spRestrictComp.ril, (U8) FROM_LOWER);

          /* sp035.302 - addition - generate SCCP error perf/subsystem
           * availablity report indicating remote SP INACC.
           */
          cmZero((U8 *) &spRep, sizeof(SpReport));

          /* fill spReport parameters and send SCCP report */
          spRep.nwId = nSap->nwData->nwId;
          spRep.sw = nSap->nwData->variant;
          spRep.dpc = apc;
          spRep.ssn = SS_SCCPMNGT;

          spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE,
                           LSP_CAUSE_RMT_SP_INACC, &spRep);

#ifdef ZP
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
   RETVOID;
} /* spMngtPause */


/*
*
*       Fun:   spMngtCong
*
*       Desc:  SCCP Management - congestion
*
*       Ret:   None
*
*       Notes: Rec Q.714 
*              Updated for ANSI T1.112-1988
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spMngtCong
(
SpNSapCb* nSap,          /* network sap */
Dpc apc,                 /* affected point code */
Priority prior           /* affected priority */
)
#else
PUBLIC Void spMngtCong(nSap, apc, prior)
SpNSapCb* nSap;          /* network sap */
Dpc apc;                 /* affected point code */
Priority prior;          /* affected priority */
#endif
{
   SpRteCb* rCb;    /* route control block */
   SpRteKey rKey;   /* route key */
  
   TRC2(spMngtCong);
  
   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb*)NULLP)
      RETVOID;           /* route does not exist, ignore */
  
   if (!(rCb->status & SP_ONLINE))   /* sanity check */
      RETVOID;

   if (prior == SN_PRI0)        /* lowest priority (uncongested) */
   {
      rCb->status &= SP_UNCONG; 
      rCb->cLvl = prior;        /* set priority to 0 */
#ifdef SNT2
      /* stop timer for status request */
      spRmvRteCbTq(rCb, TMR_STA);
      rCb->rteStsFlag &= (U8) (~TMR_STA);
#endif /* SNT2 */
      spLocalBroadcast((U8) SP_ACC, nSap->nwData->variant, apc, (Ssn) NOTUSED,
                       NOTUSED, rCb->sccpSts, rCb->spRestrictComp.ril,
                       (U8) NOTUSED);
#ifdef ZP
      zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
      RETVOID;
   }

#ifdef SNT2
   if (!(rCb->status & SP_CONG)) 
   {
      /* start status enquiry timer for route to come up */
      rCb->rteStsFlag |= TMR_STA;
      rCb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
      rCb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
      spStartRteCbTmr(rCb, TMR_STA);
   }
#endif /* SNT2 */

   rCb->status |= SP_CONG;        /* mark sp congested */
   rCb->cLvl = prior;

   /* compute rl, rsl and ril if the route towards affected pc is itu96
    * and traffic limitation mechanism is turned on
    */
   if ((rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* if attack timer is not running already, start attack and
       * decay timers. Compute restriction data
       */
      if (!(rCb->rteStsFlag & TMR_ATTACK))
      {
         /* start attack timer */
         rCb->rteStsFlag |= TMR_ATTACK;
         rCb->tmr.enb = rCb->nSap->nwData->defAttackTmr.enb;
         rCb->tmr.val = rCb->nSap->nwData->defAttackTmr.val;
         spStartRteCbTmr(rCb, TMR_ATTACK);

         /* if decay timer is running, then stop it and restert again */
         if (rCb->rteStsFlag & TMR_DECAY)
         {
            spRmvRteCbTq(rCb, TMR_DECAY);
         }
         /* re-start decay timer */
         rCb->rteStsFlag |= TMR_DECAY;
         rCb->tmr.enb = rCb->nSap->nwData->defDecayTmr.enb;
         rCb->tmr.val = rCb->nSap->nwData->defDecayTmr.val;
         spStartRteCbTmr(rCb, TMR_DECAY);

         /* update rlm and rslm */
         if (rCb->spRestrictLocal.rlm != spCb.spCfg.maxRstLvl)
         {
            rCb->spRestrictLocal.rslm++;
            if (rCb->spRestrictLocal.rslm == spCb.spCfg.maxRstSubLvl)
            {
               rCb->spRestrictLocal.rslm = 0;
               rCb->spRestrictLocal.rlm++;
            }
         }
         
         /* compute rl, rsl and ril */
         spTrfCompute(&rCb->spRestrictLocal, &rCb->spRestrictComp, rCb->dpc,
                      rCb->nSap->nwData->nwId);
      } /* if (!(rCb->rteStsFlag & TMR_ATTACK)) */
   } /* if ((rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE)) */
  

   SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
          "MTP-STATUS(CONG): spRestrictLocal(RLm: %d\t, RSLm: %d\t, CLs: %d)\n",
          rCb->spRestrictLocal.rlm, rCb->spRestrictLocal.rslm,
          rCb->spRestrictLocal.cls));

   SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
          "MTP-STATUS(CONG): spRestrictComp(RL: %d\t, RSL: %d\t, RIL: %d)\n",
          rCb->spRestrictComp.rl, rCb->spRestrictComp.rsl,
          rCb->spRestrictComp.ril));

   spLocalBroadcast((U8) SP_CONG, nSap->nwData->variant, apc, (Ssn) NOTUSED,
                    (Smi) NOTUSED, rCb->sccpSts, rCb->spRestrictComp.ril,
                    (U8) NOTUSED);
#ifdef ZP
   /* sp024.302 - modification - change upd type to Normal to avoid blocking
    * of thread in sync update when the route remains congested for a longer
    * duration and MTP3 is indicating congestion repeateldy.
    */
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */
   RETVOID;
} /* spMngtCong */

  
/*
*
*       Fun:   spLocalBroadcast
*
*       Desc: Initiate local broadcast
*
*       Ret:   None
*
*       Notes: Rec Q.714
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spLocalBroadcast
(
U8 type,            /* type of broadcast */
Swtch swtch,        /* network sap switch */
Dpc apc,            /* affected point code */
Ssn ssn,            /* subsystem number */
Smi smi,            /* subsystem multiplicity indicator */
U8 sccpState,       /* remote sccp status */
U8 ril,             /* restricted importance level */
U8 from             /* direction from */
)
#else
PUBLIC Void spLocalBroadcast(type, swtch, apc, ssn, smi, sccpState, ril, from)
U8 type;            /* type of broadcast */
Swtch swtch;        /* network sap switch */
Dpc apc;            /* affected point code */
Ssn ssn;            /* subsystem number */
Smi smi;            /* subsystem multiplicity indicator */
U8 sccpState;       /* remote sccp status */
U8 ril;             /* restricted importance level */
U8 from;            /* direction from */
#endif
{
   REG1 U8 i;       /* counter */
   REG1 U8 j;       /* counter */
   Bool found;
   SpSapCb *sap;
   
   TRC2(spLocalBroadcast)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Local Broadcast\n"));

   switch (type)
   {
      /* PC-STATE Goes To All Our Users */
      case SP_CONG:
      case SP_INACC:
      case SP_ACC:
      {
         /* SS_ACC is sent to every user */
         sap = (SpSapCb *) NULLP;
         for (i = 0; i < spCb.spCfg.nmbSaps; i++)
         {
            sap = *(spCb.sapList + i);
            if ((sap == (SpSapCb *) NULLP) || (!(sap->status & SP_BND)) ||
                (sap->status & SP_PROH) 
               )
               continue;

            found = FALSE;
            for (j = 0; j < sap->nmbConPc; j++)
            {
               if (sap->conPc[j] == apc)
               {
                  found = TRUE;
                  break;
               }
            }
            /* only post indication  if apc is in our concerned list */
            if (!found)
                continue;
#ifdef SP_CFGMG
            if (spCb.spCfg.mngmntOn) /* only report if management is on */
#ifdef SPTV2
               SpUiSptPCSteInd(&sap->pst, sap->suId, apc, (Sps)type, sccpState,
                               ril);
#else
               SpUiSptPCSteInd(&sap->pst, sap->suId, apc, (Sps)type);
#endif /* SPTV2 */
#else
#ifdef SPTV2
               SpUiSptPCSteInd(&sap->pst, sap->suId, apc, (Sps)type, sccpState,
                               ril);
#else
            SpUiSptPCSteInd(&sap->pst, sap->suId, apc, (Sps)type);
#endif /* SPTV2 */
#endif /* SP_CFGMG */
         }
         break;
      }
      case SS_UIS:
      case SS_UOS:
      {
         S16 cnt;
         U8 flag;
         
         if (from == FROM_UPPER)
            break;
         for (cnt = 0; cnt < (S16)spCb.spCfg.nmbSaps; cnt++)
         {
            sap = *(spCb.sapList + (PTR)cnt);
            if ((!sap) || (!(sap->status & SP_BND))
               )
               continue;

            flag = FALSE;
            if (swtch == sap->nwData->variant)
               flag = TRUE;
            if (!flag)
               continue;
                
            found = FALSE;
            for (i = 0; i < sap->nmbConPc; i++)
            {
               if (sap->conPc[i] == apc)
               {
                  found = TRUE;
                  break;
               }
            }
            /* only post indication if apc is in our concerned list */
            if (!found)
               continue;
#ifdef SP_CFGMG
            if (spCb.spCfg.mngmntOn)
               SpUiSptSteInd( &sap->pst, sap->suId, apc, ssn, (Sps)type, smi);
#else
            SpUiSptSteInd( &sap->pst, sap->suId, apc, ssn, (Sps)type, smi);
#endif /* SP_CFGMG */
         }
         
         break;
      }
#if (ERRCLASS & ERRCLS_INT_PAR)
      default:
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP223, (ErrVal) type,
                    "invalid type of broadcast"); 
      }
         break;
#endif    
   }
   RETVOID;
} /* spLocalBroadcast */

  
/*
*
*       Fun:   spSendMngtMsg
*
*       Desc:  Send an sccp management message
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spSendMngtMsg
(
SpMngtCb *mcb              /* management control block */
)
#else
PUBLIC Void spSendMngtMsg(mcb)
SpMngtCb *mcb;              /* management control block */
#endif
{
   SpRteCb* rCb;     /* route control block */
   SpRteKey rKey;    /* route key */
   Bool found;       /* sp047.302 - addition - flag */
   U8 i;             /* sp047.302 - addition - counter */
   Buffer *data;     /* message buffer */
   Priority prior;   /* priority */
   SpUdCb ucb;       /* unit data control block */
   SpUDatEvnt ud;    /* unit data event */
   S16 ret;
  
   TRC2(spSendMngtMsg)

#ifdef SP_CFGMG
   if (!spCb.spCfg.mngmntOn) /* don't send anything if management message */
   {                         /* is turned off */
      RETVOID; 
   } 
#endif /* SP_CFGMG */

   rKey.k1.dpc = mcb->dpc;
   rKey.k1.nwId = mcb->nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   /* make sure route is accessible */
   if (!rCb || !(rCb->status & SP_ONLINE))
      RETVOID;

   /* Check the nSap status */
   if (!(rCb->nSap->status & SP_BND))
   {
      RETVOID;
   }

   /*modified by wanglijun, check spc is local*/
   if(rCb->nSap->nwData->selfPc == mcb->dpc)
   {
      RETVOID;
   }

   /* sp047.302 - addition - find the correct subsystem for which the
    * counter is to be increased.
    */
   /* now find the correct subsystem */
   found = FALSE;
   for (i = 0; i < rCb->nmbSsns; i++)
   {
      if (rCb->ssnList[i].ssn == mcb->assn)
      {
         found = TRUE;
         break;
      }
   }

   switch (mcb->frmt)
   {
      case SCMG_SSP:
         rCb->nSap->sts.ssProhTx++;
         /* sp047.302 - addition - added ssProhTx per route and ssn */
         if (found)
            rCb->ssnList[i].ssProhTx++;
         prior = SN_PRI3;
         break;

      case SCMG_SSA:
         rCb->nSap->sts.ssAllTx++;
         prior = SN_PRI3;
         break;

      case SCMG_SOR:
         rCb->nSap->sts.ssOutRTx++;
         prior = SN_PRI1;
         break;

      case SCMG_SOG:
         rCb->nSap->sts.ssOutGTx++;
         prior = SN_PRI1;
         break;

      case SCMG_SST:
         rCb->nSap->sts.ssStatTx++;
         /* sp047.302 - addition - added ssStatTx per route and ssn */
         if (found)
            rCb->ssnList[i].ssStatTx++;
         prior = SN_PRI2;
         break;

      case SCMG_SSC:
         /* send SSC only if route is itu 96 */
         if (rCb->swtch == LSP_SW_ITU96)
         {
            /* reset counter for number of message received to zero */
            spCb.nmbMsgRx = 0;

            /* assign highest priority to SSC */
            prior = SN_PRI3;

            /* update statistics for number of SSC sent */
            rCb->nSap->sts.ssCongTx++;
         }
         else
            RETVOID;
         break;


      default:
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP224, (ErrVal) mcb->frmt,
                    "invalid management format identifier"); 
         RETVOID;
      }
   } /* switch (mcb->frmt) */

   /* before we encode the message, we need to build the data
    * section...
    */
  
   ret = SGetMsg(rCb->nSap->pst.region, rCb->nSap->pst.pool, &data);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP225, (ErrVal) ret,"SGetMsg failed");
      RETVOID;
   }

   /* if message type is SSC, pack congestion level */
   if (mcb->frmt == SCMG_SSC)
   {
      ret = SPkU8(mcb->cLvl, data);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP226, (ErrVal) ret,"Packing failure");
         SPutMsg(data);
         RETVOID;
      }
#endif /* ERRCLASS */
   } /* if (...frmt == SCMG_SSC) */

   /* if outgoing route is international ITU96 then 
    * code SMI as zero 
    */
   if ((rCb->swtch == LSP_SW_ITU96) && (rCb->nSap->nwData->niInd == INAT_IND))
      mcb->smi = 0;

   /* Pack the data */
   ret = SPkU8(mcb->smi, data);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP227, (ErrVal) ret,"Packing failure");
      SPutMsg(data);
      RETVOID;
   }
#endif /* ERRCLASS */

   if (spPkPc(rCb->nSap->nwData->pcLen, mcb->apc, data) == 0)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP228, (ErrVal) 0,"spPkPC failed");
      SPutMsg(data);
      RETVOID;
   }

   ret = SPkU8(mcb->assn, data);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP229, (ErrVal) ret,"Packing failure");
      SPutMsg(data);
      RETVOID;
   }
#endif /* ERRCLASS */

   ret = SPkU8(mcb->frmt, data);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP230, (ErrVal) ret,"Packing failure");
      SPutMsg(data);
      RETVOID;
   }
#endif /* ERRCLASS */
  
   ucb.ud = &ud;

   /* build the called and calling addresses */

   if (rCb->nSap->nwData->variant == LSP_SW_ITU)
   {
      ucb.ud->cdAddr.sw = SW_ITU;
   }
   if (rCb->nSap->nwData->variant == LSP_SW_CHINA)
   {
      ucb.ud->cdAddr.sw = SW_CHINA;
   }


#ifdef CMSS7_SPHDROPT
   ucb.ud->cdAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* CMSS7_SPHDROPT */
   ucb.ud->cdAddr.niInd = rCb->nSap->nwData->niInd;
   ucb.ud->cdAddr.ssfPres = FALSE;
   ucb.ud->cdAddr.rtgInd = RTE_SSN;
   ucb.ud->cdAddr.pcInd = TRUE;
   ucb.ud->cdAddr.pc = mcb->dpc;
   ucb.ud->cdAddr.ssnInd = TRUE;
   ucb.ud->cdAddr.ssn = SS_SCCPMNGT;
   ucb.ud->cdAddr.gt.format = GTFRMT_0;
   ucb.ud->cdAddr.pres = TRUE;
  

   if (rCb->nSap->nwData->variant == LSP_SW_ITU)
   {
      ucb.ud->cgAddr.sw = SW_ITU;
   }
   if (rCb->nSap->nwData->variant == LSP_SW_CHINA)
   {
      ucb.ud->cgAddr.sw = SW_CHINA;
   }


#ifdef CMSS7_SPHDROPT
   ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* CMSS7_SPHDROPT */
   ucb.ud->cgAddr.niInd = rCb->nSap->nwData->niInd;
   ucb.ud->cdAddr.ssfPres = FALSE;
   ucb.ud->cgAddr.rtgInd = RTE_SSN;
   ucb.ud->cgAddr.pcInd = TRUE;
   ucb.ud->cgAddr.pc = rCb->nSap->nwData->selfPc;
   ucb.ud->cgAddr.ssnInd = TRUE;
   ucb.ud->cgAddr.ssn = SS_SCCPMNGT;
   ucb.ud->cgAddr.gt.format = GTFRMT_0;
   ucb.ud->cgAddr.pres = TRUE;
  
   ucb.rCb = rCb;
   ucb.nSap = rCb->nSap;
   ucb.nwData = rCb->nSap->nwData;
   ucb.ud->qos.pClass = PCLASS0;
   ucb.ud->qos.retOpt = REC_NSO;
   ucb.opc = rCb->nSap->nwData->selfPc;
   ucb.dpc = mcb->dpc;

   data = spEncCLMsg(M_UNITDATA, &ucb, &data);
   if (data == (Buffer*)NULLP)
      RETVOID;

   spCb.sts.uDataTx++;
   ucb.ud->prior = prior;
   spDelvUDatDown(&ucb, FROM_UPPER, data);

   RETVOID;
} /* spSendMngtMsg */
  
/*
*
*       Fun:   spLiHndlMngt
*
*       Desc:  Handle incoming management messages
*
*       Ret:   None
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spLiHndlMngt
(
SpUdCb *ucb,             /* unit data control block */
Buffer *mBuf             /* management data */
)
#else
PUBLIC Void spLiHndlMngt(ucb, mBuf)
SpUdCb *ucb;             /* unit data control block */
Buffer *mBuf;            /* management buffer */
#endif
{
   SpMngtData mData;     /* management data */
   S16 ret;              /* return value */

   TRC2(spLiHndlMngt);


#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP232, (ErrVal) 0,
                 "spLiHndlMngt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */
   
   /* management messages are always routed on DPC+SSN. So
    * if sccp receives it then its for self sccp only. Decode
    * the management data
    */
   ret = spDecMngtData(ucb->nwData->pcLen, &mData, mBuf);

   /* we have decoded message, so message buffer is not needed further */
   spDropMsg(&mBuf);

   /* sp007.302 - addition - return if decoding of Mngt msg is failed */
   if (ret != SP_OK)
      RETVOID;
   
   /* handle management message based on type */
   switch (mData.format)
   {
      case SCMG_SSP:          /* Subsystem Prohibited */
         /* sp040.302 - addition - increment global cntr */
         spCb.sts.ssProhRx++;
         ucb->nSap->sts.ssProhRx++;
         spHndlSSP(ucb->nSap, ucb->opc, mData.aPc, mData.aSsn);
         break;

      case SCMG_SSA:          /* subsystem allowed */
         ucb->nSap->sts.ssAllRx++;
         spHndlSSA(ucb->nSap, ucb->opc, mData.aPc, mData.aSsn);
         break;

      case SCMG_SST:          /* subsystem test */
         ucb->nSap->sts.ssStatRx++;
         spHndlSST(ucb->nSap, ucb->opc, mData.aPc, mData.aSsn);
         break;

      case SCMG_SOR:          /* subsystem OOS request */
         ucb->nSap->sts.ssOutRRx++;
         spHndlSOR(ucb->nwData->nwId, ucb->opc, mData.aPc, mData.aSsn, 
                   mData.smi);
         break;

      case SCMG_SOG:          /* subsystem OOS granted */
         ucb->nSap->sts.ssOutGRx++;
         spHndlSOG(ucb->nSap, ucb->opc, mData.aPc, mData.aSsn, mData.smi);
         break;

      case SCMG_SSC:          /* sccp congested */
         /* sp040.302 - addition - increment global cntr */
         spCb.sts.ssCongRx++;
         ucb->nSap->sts.ssCongRx++;
         spHndlSSC(ucb->nSap, mData.aPc, mData.cLvl);
         break;

      default:
         /* invalid management message */
         SPLOGERROR(ERRCLS_DEBUG, ESP233, (ErrVal) mData.format,
                    "invalid management format identifier"); 
         break;
   } /* switch (mData.format) */

   RETVOID;
} /* spLiHndlMngt */

  
/*
*
*       Fun:   spHndlSSA
*
*       Desc:  Handle subsystem allowed message (MNGT).
*
*       Ret:   None
*
*       Notes: Rec Q.714
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSSA
(
SpNSapCb* nSap,      /* network sap */
Dpc opc,             /* calling point code */
Dpc apc,             /* affected point code */
Ssn ssn              /* subsystem number */
)
#else
PUBLIC Void spHndlSSA(nSap, opc, apc, ssn)
SpNSapCb* nSap;      /* network sap */
Dpc opc;             /* calling point code */
Dpc apc;             /* affected point code */
Ssn ssn;             /* subsystem number */
#endif
{
   REG1 U8 i;        /* loop counter */
   SpRteCb *rCb;     /* route control block */
   SpRteKey rKey;    /* route key */
   Bool found;       /* boolean for searching ssn */
   Smi smi;          /* subsystem multiplicity indicator */
   SpReport spRep;   /* sp035.302 -addition- sccp error perf/subsystem availability report */
  
   TRC2(spHndlSSA);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SSA pc %#lx, ssn %#lx\n", (U32) apc, (U32) ssn));

   if (apc == nSap->nwData->selfPc)
      RETVOID;
  
   rCb = (SpRteCb *) NULLP;
   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
      RETVOID;


   /* Now check if subsystem is SCCP */
   if ((ssn == SS_SCCPMNGT) && 
       ((nSap->nwData->variant == LSP_SW_ITU) ||
        (nSap->nwData->variant == LSP_SW_CHINA) ||
        (rCb->swtch == LSP_SW_ANS96)
       ))
   {
      /* stop the subsystem test on SCCP if one is in progress */
      if (rCb->rteStsFlag & TMR_SST)
      {
         spRmvRteCbTq(rCb, TMR_SST);
         /* unset the bit for SST timer in the flag */
         rCb->rteStsFlag &= (U8) (~TMR_SST);
      }

      /* Turn the status of the SCCP to on. */
      rCb->sccpSts = RMT_SCCP_AVAIL;

      /* do a subsystem test on each remote subsystem
       * to turn it back on
       */
      spResumeSS(rCb);
#ifdef ZP
      zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */
      RETVOID;
   }

   /* Okay, we have a valid route control block */
  
   /* now find the correct subsystem */
   found = FALSE;
   for (i = 0; i < rCb->nmbSsns; i++)
   {
      if (rCb->ssnList[i].ssn == ssn)
      {
         found = TRUE;
         break;
      }
   }

   if (!found)
      RETVOID; /* no subsystem found */
  
   /* i is the index... */
   if (rCb->ssnList[i].nmbBpc)
      smi = SMI_DUP;
   else
      smi = SMI_SOL;
  
   /* is subsystem already marked accessible */
   if (rCb->ssnList[i].status & SS_ACC)
   {
      if (rCb->ssnList[i].ssFlgs & TMR_SST)   /* sanity test */
      {
         spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
         rCb->ssnList[i].ssFlgs &= (U8)(~TMR_SST); /* unset SST flag */
      }
      RETVOID; /* no, return ok */
   }
  
   /* mark subsystem accessible */
   rCb->ssnList[i].status |= SS_ACC;
  
   /* stop SST */
   if (rCb->ssnList[i].ssFlgs & TMR_SST)
   {         
      spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
      rCb->ssnList[i].ssFlgs &= (U8)(~TMR_SST); /* unset SST flag */
   }


   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
          "SCCP -- Management SSA Broadcast pc %#lx, ssn %#lx\n", (U32) apc,
          (U32)ssn));

   /* update statistics for SSA received */
   rCb->ssnList[i].ssAllRx++;

   /* broadcast to adjacent dpcs */
   spBroadcast(nSap->nwData, opc, rCb->dpc, rCb->ssnList[i].ssn, smi,
               SCMG_SSA );
  
   /* broad cast to local subsystems */
   spLocalBroadcast(SS_UIS, nSap->nwData->variant, apc, ssn, (Smi) smi,
                    rCb->sccpSts, rCb->spRestrictComp.ril, (U8) FROM_LOWER); 
   
   /* sp035.302 - addition - sccp report generation on receiving SSA  */
   cmZero((U8 *) &spRep, sizeof(SpReport));  /* initialize spReport */

   /*fill spReport parameters */
   spRep.nwId = nSap->nwData->nwId;
   spRep.sw = nSap->nwData->variant;
   spRep.dpc = apc;
   spRep.ssn = ssn;

   /* send SCCP report */
   spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_SSA_RECVD, &spRep);

#ifdef ZP
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
     
   RETVOID;
} /* spHndlSSA */
  

/*
*
*       Fun:   spBroadcast
*
*       Desc:  Broadcast a message to all adjacent point codes (MNGT)
*
*       Ret:   None
*
*       Notes: Rec Q.714 
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spBroadcast
(
SpNwCb* nwData,    /* network sap */
Dpc opc,           /* originating point code (from mtp-3, or us) */
Dpc aPc,           /* affected point code */
Ssn aSsn,          /* affected subsystem number */
Smi smi,           /* subsystem multiplicity indicator */
U8 msg             /* SCMG_SSA, or SCMG_SSP */
)
#else
PUBLIC Void spBroadcast(nwData, opc, aPc, aSsn, smi, msg)
SpNwCb* nwData;    /* network control block */
Dpc opc;           /* originating point code (from mtp-3, or us) */
Dpc aPc;           /* affected point code */
Ssn aSsn;          /* affected subsystem number */
Smi smi;           /* subsystem multiplicity indicator */
U8 msg;            /* SCMG_SSA, or SCMG_SSP */
#endif
{
   REG1 U8 i;      /* counter */
   REG2 U8 j;      /* counter */
   Dpc dpc;        /* destination point code */
   SpRteCb *rCb;   /* route control block */
   SpRteKey rKey;  /* route Key */
   SpSapCb* sap;   /* sap */
   SpMngtCb mcb;   /* sp002.31 - moved this definition to the beginning of the function */
  
   TRC2(spBroadcast)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "SCCP -- Broadcast\n"));

   /* look up route cb if this is not us... */
   if (opc != nwData->selfPc)
   {
      /* is informer pc == to affected pc */
      if (opc == aPc)
      {
         /* find iformer pc's route control block */
         rKey.k1.dpc = aPc;
         rKey.k1.nwId = nwData->nwId;
         spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
         if (rCb == (SpRteCb*)NULLP)
            RETVOID;
     
         /*
          * Each subsystem in a route control block has a
          * list of concerned signalling points. This is 
          * kept at the subsystem level because we assume
          * that point codes will only be concerned if they
          * too have a user of this ssn. Therefore, we do
          * not look for all the subsystems on the affected
          * point code, merely the one that matches the assn
          *
          */
         /*
          * Find the affected subsystem in the route control block
          */
         for (i = 0; i < rCb->nmbSsns; i++)
         {
            if ( rCb->ssnList[i].ssn == aSsn)
            {
               /* loop through the aSsn's concerned point codes */
               for (j = 0; j < rCb->ssnList[i].nmbConPc; j++)
               {
                  /* sp002.31 moved SpMngtCb definition to the beginning of function */
 
                  /* don't send message to informer */
                  if (rCb->ssnList[i].conPc[j] == opc)
                  continue;

                  /* set the destination point code */
                  dpc = rCb->ssnList[i].conPc[j];

                  mcb.dpc = dpc;
                  mcb.apc = aPc;
                  mcb.assn = aSsn;
                  mcb.nwData = nwData;
                  mcb.smi = smi;
                  mcb.frmt = msg;
                  spSendMngtMsg (&mcb);
               }
            break;
            }
        
         }
      }
      else              /* do nothing */
         RETVOID;
   }
   else /* this is a local user */
   {
      /* is informer pc == to affected pc */
      if (opc == aPc)
      {
         sap = spFindUpperSap(nwData->nwId, aSsn);
         if ( sap == (SpSapCb*)NULLP)
            RETVOID;

         for (j = 0; j < sap->nmbConPc; j++)
         {
            rKey.k1.dpc = sap->conPc[j];
            rKey.k1.nwId = nwData->nwId;
            spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
            if (rCb == (SpRteCb*)NULLP)
               continue;

            /* sp002.31 - We now send messages to all concerned point codes
               not just those that have the same sub-system number. */ 
            /* set the destination point code */
            dpc = sap->conPc[j];
            mcb.dpc = dpc;
            mcb.assn = aSsn;
            mcb.apc = aPc;
            mcb.nwData = nwData;
            mcb.smi = smi;
            mcb.frmt = msg;
            spSendMngtMsg (&mcb);
         }
      }
   }
   RETVOID;
} /* spBroadCast */


/*
*
*       Fun:   spHndlSSP
*
*       Desc:  Handle subsystem prohibited message (MNGT).
*
*       Ret:   None
*
*       Notes: Rec Q.714
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSSP
(
SpNSapCb *nSap,    /* network sap */
Dpc opc,           /* calling point code */
Dpc aPc,           /* affected point code */
Ssn aSsn           /* affected subsystem number */
)
#else
PUBLIC Void spHndlSSP(nSap, opc, aPc, aSsn)
SpNSapCb *nSap;    /* network sap */
Dpc opc;           /* calling point code */
Dpc aPc;           /* affected point code */
Ssn aSsn;          /* affected subsystem number */
#endif
{
   REG1 U8 i;      /* counter */
   SpRteCb* rCb;   /* route control block */
   SpRteKey rKey;  /* route Key */
   Bool found;     /* flag */
   Smi smi;        /* subsystem multiplicity indicator */
   SpReport spRep; /* sccp error perf/subsyetem availability report */
  
   TRC2(spHndlSSP)
  
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SSP\n"));

   /* find the route */
   rKey.k1.dpc = aPc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
      RETVOID;
  
   found = FALSE;
   for (i = 0; i < rCb->nmbSsns; i++)
   {
      if (rCb->ssnList[i].ssn == aSsn)
      {
         found = TRUE;
         break;
      }
   }
   if (!found)
      RETVOID;   /* no subsystem found */
  
   if (!(rCb->ssnList[i].status & SS_ACC))
      RETVOID;   /* subsystem already prohibited */
  
   if (rCb->ssnList[i].ssFlgs & TMR_SST)   /* sanity test */
      RETVOID;

   /* Start Subsystem Status Test */
   rCb->ssnList[i].ssFlgs |= TMR_SST;
   rCb->ssnList[i].tmr.enb = rCb->nSap->nwData->defSstTmr.enb;
   rCb->ssnList[i].tmr.val = rCb->nSap->nwData->defSstTmr.val;
   spStartSsnCbTmr(&rCb->ssnList[i], TMR_SST);
  
   if (rCb->ssnList[i].nmbBpc)
      smi = SMI_DUP;
   else
      smi = SMI_SOL;

   /* mark subsystem inaccessible (prohibited)
    * We do not "Mark translate to backup", because
    * our CheckRoute routine will automatically look
    * to the backup if the primary is inaccessible
    */
   rCb->ssnList[i].status &= SS_INACC;


   /* sp047.302 - addition - added ssProhRx per route and ssn */
   rCb->ssnList[i].ssProhRx++;
  
   /* broadcast to adjacent dpcs */
   spBroadcast(nSap->nwData, opc, rCb->dpc, rCb->ssnList[i].ssn, smi, SCMG_SSP);

   /* broad cast to local subsystems */
   spLocalBroadcast(SS_UOS, nSap->nwData->variant, aPc, aSsn, (Smi) smi,
                    rCb->sccpSts, rCb->spRestrictComp.ril, (U8) FROM_LOWER);

   /* initialize spReport */
   cmZero((U8 *) &spRep, sizeof(SpReport));

   /* fill spReport parameters */
   spRep.nwId = nSap->nwData->nwId;
   spRep.sw = nSap->nwData->variant;
   spRep.dpc = aPc;
   spRep.ssn = aSsn;

   /* send SCCP report */
   spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_SSP_RECVD,
                    &spRep);
#ifdef ZP
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */
  
   RETVOID;
} /* spHndlSSP */

  
/*
*
*       Fun:   spHndlSST
*
*       Desc:  Handle subsystem status test (MNGT).
*
*       Ret:   None
*
*       Notes: Rec Q.714 
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSST
(
SpNSapCb *nSap,   /* network sap */
Dpc opc,          /* calling point code */
Dpc pc,           /* affected point code */
Ssn ssn           /* subsystem number */
)
#else
PUBLIC Void spHndlSST(nSap, opc, pc, ssn)
SpNSapCb *nSap;   /* network sap */
Dpc opc;         /* calling point code */
Dpc pc;           /* affected point code */
Ssn ssn;          /* subsystem number */
#endif
{
   SpSapCb* sap;
   SpMngtCb mcb;
  
   TRC2(spHndlSST)
  
   /* sp044.302 - deletion - pc is being used below, so removed UNUSED(pc) */

   SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
          "SCCP -- Management SST pc %#lx, ssn %#lx\n", (U32) pc, (U32) ssn));

   /* sp044.302 - addition - return if SST not for selfPc */
   if (pc != nSap->nwData->selfPc)
      RETVOID;

   /* subsystem is SCCP itself */
   if ((ssn == SS_SCCPMNGT) && 
       ((nSap->nwData->variant == LSP_SW_ITU)
        || (nSap->nwData->variant == LSP_SW_CHINA)
       ))
   {
      mcb.nwData = nSap->nwData;
      mcb.dpc = opc;
      mcb.apc = nSap->nwData->selfPc;
      mcb.assn = ssn;
      mcb.frmt = SCMG_SSA;
      mcb.smi = SMI_SOL;
      spSendMngtMsg(&mcb);
      RETVOID;
   }

   /* find the route */
   sap = spFindUpperSap(nSap->nwData->nwId, ssn);
   if (sap == (SpSapCb*)NULLP)
      RETVOID;
  
   /* check ignore */
   if (sap->status & SP_IGNR)
      RETVOID;

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SST sap not ignored\n"));
   
   /* if sap is prohibited, do nothing */
   if (sap->status & SP_PROH)
      RETVOID;

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SST sap not prohibited\n"));

   mcb.nwData = nSap->nwData;
   mcb.dpc = opc;
   mcb.apc = nSap->nwData->selfPc;
   mcb.assn = sap->ssn;
   mcb.frmt = SCMG_SSA;

   /* else send subsystem allowed */
   if (sap->nmbBpc)
      mcb.smi = SMI_DUP;
   else
      mcb.smi = SMI_SOL;
     
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
          "SCCP -- Management SST sending SSA on pc %#lx, ssn, %#lx\n",
          (U32) mcb.apc, (U32) mcb.assn));

   spSendMngtMsg(&mcb);
   RETVOID;
} /* spHndlSST */


/*
*
*       Fun:   spHndlSOG
*
*       Desc:  Handle subsystem out of service grant (MNGT).
*
*       Ret:   None
*
*       Notes: Rec Q.714 
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSOG
(
SpNSapCb *nSap,   /* network sap */
Dpc cgPc,         /* calling point code */
Dpc pc,           /* affected point code */
Ssn ssn,          /* subsystem number */
Smi smi           /* subsystem multiplicity indicator */
)
#else
PUBLIC Void spHndlSOG(nSap, cgPc, pc, ssn, smi)
SpNSapCb *nSap;   /* network sap */
Dpc cgPc;         /* calling point code */
Dpc pc;           /* affected point code */
Ssn ssn;          /* subsystem number */
Smi smi;          /* subsystem multiplicity indicator */
#endif
{
   SpSapCb *sap;  /* upper sap */
   SpRteCb *rCb;  /* route contrl block */
   SpRteKey rKey; /* route key */

   TRC2(spHndlSOG)
  
   UNUSED(cgPc);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SOG\n"));

   /* find sap */
   sap = spFindUpperSap(nSap->nwData->nwId, ssn);
   if  ( (sap == (SpSapCb*)NULLP) || (!(sap->status & SP_BND)) )
      RETVOID;
  
   if (!(sap->status & SP_GRNT))
      RETVOID;
  
   /* remove the sap from the timing que  (i.e. Stop T(Coord Chg) */
   spRmvSapCbTq(sap, TMR_GRT);
  
   /* cancel "waiting for grant" */
   sap->status ^= SP_GRNT;
  
   /* broadcast SSP */
   spBroadcast(nSap->nwData, nSap->nwData->selfPc, pc, ssn, smi, SCMG_SSP );
   sap->tmr.enb = TRUE;
   sap->tmr.val = sap->nwData->defIgnTmr.val;
   spStartSapCbTmr(sap, TMR_IGN);

   if (!(sap->status & SP_IGNR))
      sap->status ^= SP_IGNR;
   
   /* Send N_COORD confirmation */
#ifdef SP_CFGMG
   if (spCb.spCfg.mngmntOn)
      SpUiSptCordCfm (&sap->pst, sap->suId, ssn, smi);
#else
      SpUiSptCordCfm (&sap->pst, sap->suId, ssn, smi);
#endif /* SP_CFGMG */

#ifdef ZP
      zpRunTimeUpd(ZP_SP_SAPCB, sap, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */

   /* find route towards the pc from which SOG is
    * received to update statistics
    */
   rKey.k1.dpc = cgPc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb != (SpRteCb *) NULLP)
   {
      U8 i;   /* loop counter */

      /* find SSN on the route from which SOG is received */
      for (i = 0; i < MAXNUMSSN; i++)
      {
         if (rCb->ssnList[i].ssn == ssn)
            break;
      }
      if (i == MAXNUMSSN)  /* ssn not found, statistics can't be updated */
         RETVOID;

      /* update statistics for SOG received */
      rCb->ssnList[i].ssOGRx++;
   } /* if (rCb != (SpRteCb *) NULLP) */

   RETVOID;
} /* spHndlSOG */

  
/*
*
*       Fun:   spHndlSOR
*
*       Desc:  Handle subsystem out of service rquest (MNGT).
*
*       Ret:   SP_OK   - ok
*
*       Notes: Rec Q.714
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSOR
(
NwId id,          /* network identifier */
Dpc opc,          /* calling point code */
Dpc apc,          /* affected point code */
Ssn assn,         /* subsystem number */
Smi smi           /* subsystem multiplicity indicator */
)
#else
PUBLIC Void spHndlSOR(id, opc, apc, assn, smi)
NwId id;          /* network identifier */
Dpc opc;          /* calling point code */
Dpc apc;          /* affected point code */
Ssn assn;         /* affected subsystem number */
Smi smi;          /* subsystem multiplicity indicator */
#endif
{
   Status stat;
   SpSapCb *sap;
   S16 ret;

   UNUSED(opc);
   UNUSED(apc);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SOR\n"));

   /* I check my dynamic buffers against my configured threshold */
   ret = SChkRes(spCb.spInit.region, spCb.spInit.pool, &stat);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP234, (ErrVal) ret,  "SChkRes() failed");
      RETVOID;
   }

   sap = (SpSapCb *) NULLP;
   sap = spFindUpperSap(id, assn);
   if ((sap == (SpSapCb *) NULLP) || (!(sap->status & SP_BND)))
      RETVOID;

   
   if (stat <= spCb.spCfg.sogThresh)
   {
      SpRteCb *rCb;     /* route control block */
      SpRteKey rKey;    /* route key */
      U8 i;             /* loop counter */

      /* update sap statistics for ss out-of-service request denied */
      sap->sts.ssOOSReqDn++;

      rCb = (SpRteCb *) NULLP;
      rKey.k1.dpc = apc;
      rKey.k1.nwId = id;

      spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
      if (rCb == (SpRteCb *) NULLP)
         /* route not found, statistics can't be updated */
         RETVOID;

      /* find matching ssn on the route */
      for (i = 0; i < MAXNUMSSN; i++)
      {
         if (rCb->ssnList[i].ssn == assn)
            break;
      }
      if (i == MAXNUMSSN)  /* ssn not found, statistics can't be updated */
         RETVOID;

      /* update route-ssn statistics for ss OOS req denied */
      rCb->ssnList[i].ssORDenied++;
      RETVOID;
   } /* if (stat <= spCb.spCfg.sogThresh) */

   /* copy the affected PC in SapCb . Since there are more than one number
    * of backup of a SSN ,so there is a need to track the point code from where
    * SOR originates . In case SOR originates from more than one SSN ,then 
    * this field will be overwritten by the latest PC from where SOR 
    * originates and the response will be given to it 
    */

   /* copy the apc in SapCb from where SOR originates */
   sap->sorPc = apc;

   /* send N-COORD Indication */
#ifdef SP_CFGMG        
   if (spCb.spCfg.mngmntOn)
      SpUiSptCordInd(&sap->pst, sap->suId, assn, smi);
#else
   SpUiSptCordInd(&sap->pst, sap->suId, assn, smi);
#endif /* SP_CFGMG */

#ifdef ZP
   zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
#endif /* ZP */
   RETVOID;
} /* spHndlSOR */

  
/*
*
*       Fun:   spHndlSSC
*
*       Desc:  Handle SCCP congested message from remote sccp.
*
*       Ret:   None
*
*       Notes: None.
*
*       File:  cp_bdy3.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlSSC
(
SpNSapCb* nSap,        /* network sap */
Dpc apc,               /* affected point code */
U8 cLvl                /* congestion level */
)
#else
PUBLIC Void spHndlSSC(nSap, apc, cLvl)
SpNSapCb* nSap;        /* network sap */
Dpc apc;               /* affected point code */
U8 cLvl;               /* congestion level */
#endif
{
   SpRteCb *rCb;       /* route control block */
   SpRteKey rKey;      /* route key */
   SpReport spRep;     /* sccp error perf/subsyetem availability report */

   TRC2(spHndlSSC);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management SSC pc %#lx, cLvl %#x\n", (U32) apc, (U8) cLvl));

   if (apc == nSap->nwData->selfPc)
      RETVOID;
  
   /* initialize route control block to null */
   rCb = (SpRteCb *) NULLP;

   /* form route key to search route in hash list */
   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   /* find route from which SSC message is received */
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
   {
      /* route not found, return */
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP -- SSC received from unknown route, pc %#lx\n", (U32) apc));
      RETVOID;
   }

   /* if affected point code is marked as prohibited, no action
    * is taken, return
    */
   if (!(rCb->status & SP_ONLINE))
      RETVOID;

   /* handle SSC only if received from ITU 96 route and traffic
    * limitation procedure is turned ON
    */
   if ((rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* compare the value of cls with the congestion level reported in
       * SSC.
       */
      if (rCb->spRestrictLocal.cls <= cLvl)
      {
         /* stop congestion timer if running */
         spRmvRteCbTq(rCb, TMR_CON);

         /* re-start congestion timer */
         rCb->rteStsFlag |= TMR_CON;
         rCb->tmr.enb = rCb->nSap->nwData->defCongTmr.enb;
         rCb->tmr.val = rCb->nSap->nwData->defCongTmr.val;
         spStartRteCbTmr(rCb, TMR_CON);

         /* if cls is less than reported congestion level, update cls
          * compute traffic limitation data and broadcast ril to local
          * users.
          */
         if (rCb->spRestrictLocal.cls < cLvl)
         {
            /* update cls in rCb */
            rCb->spRestrictLocal.cls = cLvl;

            /* compute rl, rsl and ril */
            spTrfCompute(&rCb->spRestrictLocal, &rCb->spRestrictComp, rCb->dpc,
                         rCb->nSap->nwData->nwId);

            /* broad cast to local subsystems */
            spLocalBroadcast((U8) SP_CONG, nSap->nwData->variant, apc,
                             (Ssn) NOTUSED, (Smi) NOTUSED, rCb->sccpSts,
                             rCb->spRestrictComp.ril, (U8) FROM_LOWER);
#ifdef ZP
            /* update peer with congestion info */
            zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC,
                         CMPFTHA_ACTN_MOD);
#endif /* ZP */
         } /* if (rCb->spRestrictLocal.cls < cLvl) */
      } /* if (...cls <= cLvl) */
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */

   /* initialize spReport */
   cmZero((U8 *) &spRep, sizeof(SpReport));

   /* fill spReport parameters */
   spRep.nwId = nSap->nwData->nwId;
   spRep.sw = nSap->nwData->variant;
   spRep.dpc = apc;
   spRep.congLvl = cLvl;

   /* send SCCP report */
   spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_SSC_RECVD,
                    &spRep);
   RETVOID;
} /* spHndlSSC */
 
  

  
/*
 *
 *       Fun:   spMngtUnavail
 *
 *       Desc:  SCCP Management - pause
 *
 *       Ret:   None
 *
 *       Notes: Rec Q.714  (CCITT - 92 version) page 32
 *
         File:  cp_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void spMngtUnavail
(
SpNSapCb* nSap,          /* network sap */
Dpc apc,                 /* affected point code */
Priority prior           /* priority */
)
#else
PUBLIC Void spMngtUnavail(nSap, apc, prior)
SpNSapCb* nSap;          /* network sap */
Dpc apc;                 /* affected point code */
Priority prior;          /* priority */
#endif
{
   REG1 U8 i;            /* counter */
   SpRteCb *rCb;         /* route control block */
   SpRteKey rKey;        /* route key */
   Swtch variant;        /* variant */
   SpReport spRep;       /* sp049.302 - addition - sccp error perf report */
  
   TRC2(spMngtUnavail);
  
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Management Unavail\n"));

   rKey.k1.dpc = apc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *) NULLP)
      RETVOID;
   /* sp001.30 - Removed code to make route offline as per spec 
    * ITU92 Q.714 5.3.4.2 */ 

   /* simplifying the dereference */
   variant = rCb->nSap->nwData->variant;
   {
      if (prior & SNT_USR_UNEQUIPPED)
      {
         /* sp049.302 - deletion - sccp error perf report moved out of the
          * if condition 
          */  

         /* mark remote sccp as unequipped */
         rCb->sccpSts = RMT_SCCP_UNEQP;

         /* stop SST timer for remote sccp, if running */
         if(rCb->rteStsFlag & TMR_SST)
         {
           spRmvRteCbTq(rCb, TMR_SST);
           rCb->rteStsFlag &= (U8)(~TMR_SST);
         }

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP -- Management: remote SCCP unequipped.\n"));

         /* generate alarm for remote sccp unequipped */
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_RMT_SCCP_UNEQUIP, 
                     LSP_CAUSE_RMT_SCCP_UNEQUIP, EVTSNTSTAIND,
                     (U8) prior);

         /* sp049.302 - deletion - sccp error perf/subsystem availability 
          * report indicating remote SCCP unequipped, moved out of the
          * if condition 
          */  
      }
      else
      {
         /* sp049.302 - deletion - sccp error perf report moved out of the
          * if condition 
          */  
         /* mark remote sccp as unavailable */
         rCb->sccpSts = RMT_SCCP_UNAVAIL;

         if (rCb->rteStsFlag & TMR_SST)
            rCb->rteStsFlag |= TMR_CONTSST; 
         else
         {
            /* sp018.301 - modification - start timer before sending SST.
             * Start timer for remote SCCP in all cases even if we do not
             * send SST (depending on route swtch) to recover from remote
             * SSN unavailability state
             */
            /* Start SST timer */
            rCb->rteStsFlag |= TMR_SST;
            rCb->tmr.enb = rCb->nSap->nwData->defSstTmr.enb;
            rCb->tmr.val = rCb->nSap->nwData->defSstTmr.val;
            spStartRteCbTmr(rCb, TMR_SST);
         
            {
               SpMngtCb mcb;

               /* send SST with SSN = SS_SCCPMNGT */
               mcb.dpc = rCb->dpc;
               mcb.apc  = rCb->dpc;
               mcb.assn = SS_SCCPMNGT;
               mcb.frmt = SCMG_SST;
               mcb.smi = rCb->nmbBpc ? SMI_DUP : SMI_SOL;
               mcb.nwData = rCb->nSap->nwData;
               spSendMngtMsg(&mcb);
            }
         }
         /* sp049.302 - deletion - sccp error perf/subsystem availability 
          * report indicating remote SCCP unequipped, moved out of the
          * if condition 
          */  
      }

      /* stop congestion timer for remote sccp if running */
      if (rCb->rteStsFlag & TMR_CON)
      {
         spRmvRteCbTq(rCb, TMR_CON);
         rCb->rteStsFlag &= (U8)(~TMR_CON);
      }

      /* reset congestion level for remote sccp to zero */
      rCb->spRestrictLocal.cls = 0;

      /* compute traffic restriction data */
      spTrfCompute(&rCb->spRestrictLocal, &rCb->spRestrictComp, rCb->dpc,
                   rCb->nSap->nwData->nwId);

      for (i = 0; i < rCb->nmbSsns; i++)
      {
         if (rCb->ssnList[i].ssFlgs & TMR_SST)
         {
            spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
            rCb->ssnList[i].ssFlgs &= (U8) (~TMR_SST);
         }
      
         if (rCb->ssnList[i].status & SS_ACC)
         {
            rCb->ssnList[i].status &= SS_INACC;
            spLocalBroadcast((U8) SS_UOS, nSap->nwData->variant, apc,
                             rCb->ssnList[i].ssn,
                             (Smi) (rCb->ssnList[i].nmbBpc ? SMI_DUP : SMI_SOL),
                             rCb->sccpSts, rCb->spRestrictComp.ril,
                             (U8) FROM_LOWER);
         }
      } /* for (i = 0; i < rCb->nmbSsns; i++) */
      /* sp049.302 - addition - generate SCCP error perf/subsystem
       * availablity report indicating remote SCCP unequipped.
       */
      cmZero((U8 *) &spRep, sizeof(SpReport));

      /* fill spReport parameters and send SCCP report */
      spRep.nwId = nSap->nwData->nwId;
      spRep.sw = variant;
      spRep.dpc = apc;
      spRep.ssn = SS_SCCPMNGT;

      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, 
                       LSP_CAUSE_RMT_SCCP_UNEQUIP, &spRep);
#ifdef ZP
   zpRunTimeUpd(ZP_SP_RTECB, rCb, CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
   } /* end else not a japan variant */
   RETVOID;
} /* spMngtUnavail */

  
/*
 *
 *       Fun:   spResumeSS
 *
 *       Desc:  SCCP Management - resume
 *
 *       Ret:   None
 *
 *       Notes: 
 *
         File:  cp_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void spResumeSS
(
SpRteCb* rCb            /* route control block */
)
#else
PUBLIC Void spResumeSS(rCb)
SpRteCb* rCb;            /* route control block */
#endif
{
   REG1 S32 i;      /* counter */
   
   TRC2(spResumeSS);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP -- Subsystems Resume\n"));

   if (rCb == (SpRteCb *) NULLP)
      RETVOID;           /* route does not exist, ignore */
  
   rCb->status |= SP_ONLINE; /* mark sp allowed */

#ifdef SP_SSA_AVAILABLE
   for (i = 0; i < (S32) rCb->nmbSsns; i++)
   {
      Smi smi;         /* subsystem multiplicity indicator */

      /* find smi */
      if (rCb->ssnList[i].nmbBpc)
         smi = SMI_DUP;
      else
         smi = SMI_SOL;
  
      /* mark ssn accessible */
      rCb->ssnList[i].status |= SS_ACC;

      /* broadcast to local sccp user */
      spLocalBroadcast(SS_UIS, rCb->nSap->nwData->variant, rCb->dpc,
                       rCb->ssnList[i].ssn, smi, rCb->sccpSts,
                       rCb->spRestrictComp.ril, (U8) FROM_LOWER);
   }
#else
   /* sp047.302 - Addition - If management is turned off then mark all SSN'c
    * accessible.
    */
#ifdef SP_CFGMG
   if (spCb.spCfg.mngmntOn == FALSE)
   {
      for (i = 0; i < (S32) rCb->nmbSsns; i++)
      {
         /* mark ssn accessible */
         rCb->ssnList[i].status |= SS_ACC;
      }
   }
   else
#endif /* SP_CFGMG */
   {
      /* set all subsystems to testing... */
      for (i = 0; i < (S32)rCb->nmbSsns; i++)
      {
         if (rCb->ssnList[i].ssFlgs & TMR_SST)
            continue;
         rCb->ssnList[i].ssFlgs |= TMR_SST;
         /* Start control block timer */
         rCb->ssnList[i].tmr.enb = rCb->nSap->nwData->defSstTmr.enb;
         rCb->ssnList[i].tmr.val = rCb->nSap->nwData->defSstTmr.val;

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP -- spResume Starting SST on %lx %d\n", rCb->dpc,
                rCb->ssnList[i].ssn));

         spStartSsnCbTmr(&rCb->ssnList[i], TMR_SST);
      }
   }
#endif /* SP_SSA_AVAILABLE */

   RETVOID;
} /* spResumeSS */

  

/********************************************************************30**
  
         End of file:     cp_bdy3.c@@/main/18_1 - Tue Jan 22 15:15:39 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release. 

1.2          ---  fmg   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  fmg   1. added support for CCITT 1988 
                           connection-oriented control.

1.4          ---  fmg   1. change i to S16 in spHndlSPP

1.5          ---  fmg   1. updated to support new system service
                           interface

1.6          ---  fmg   1. change prototype spHndlSST

1.7          ---  scc   1. Add ability to configure management to
                           turn management messages on/off via flag
                           SP_CFGMG

1.8          ---  scc   1. make changes for ANSI 92 variant and CCITT 92
                           variant
             ---  scc   2. niInd no longer used, set to zero.

1.9          ---  fmg   1. chaged switch from SW_XXXX to  LSP_SW_XXXX
             ---  fmg   2. removed cm2.x include 
             ---  fmg   3. added cm_ss7.? include 

1.10         ---  fmg   1. change ifdef

1.11         ---  fmg   1. fixed bug in spLocalBroadcast
             ---  fmg   2. fixed sap loop

1.12         ---  fmg   1. added cast in spLocalBroadcast.

1.13         ---  mjp   1. check if user has bound before calling
                           primitives
             ---  mjp   2. replace old error function with SPLOGERROR
             ---  mjp   3. changed spaddr switch to SW_XXX from LSP_SW_XXX
                           to be consistent with SCCP users.

1.14         ---  mjp   1. added affected subsystem number to spBroadcast
             ---  mjp   2. added direction to spResolveAddr calls
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.15         sp001.27 mjp  1. removed EXTERN define of spRmvSapCbTq
             sp005.27 ash  2. Added Dpc parameter to SteInd primitive
                           3. Changes to support fault tolerance
                           4. support for common hash library
                           5. removed GCC warnings
             sp011.27      6. Management messages fills niInd bit of 
                              called and calling party address from
                              network sap
                      cp   7. Made changes as required by TCR0003 for 
                              Debug Msg generation.
                           8. Calling spBroadcast with the correct opc
                              when a SOG is received.

/main/16     ---      cp   1. Management messages sent out in spHndlSSA
                              and spHndlSSP now have the correct affected 
                              subsystem number.
             ---      cp   2. Changes for new GTT framework.
             ---      cp   3. We do a local broadcast of SP_ACC after a 
                              apc recovers from congestion.
             ---      cp   4. SP_PRESERVE_ADDR related changes for handling 
                              management msgs.
             ---      cp   5. Removed SP_PRESERVE_ADDR option from 
                              management messages. 
                           6. Initialize spHdrOption for mgmt msgs.
             ---      vb   7. Clean up of the patches.
                      cp   8. Added support for new Class 1 implementation.
             ---      vb   9. Updated code as per design spec 1010030.12

/main/18     ---      cp   1. DFTHA mods.
             sp001.30 sg   1. The route should not be made offline when
                              a UPU message is received.
             sp002.31 sg   2. Broadcast changed to send messages to all
                              concerned point codes, not just those
                              routes that have the same SSN.
             sp005.301 sg  3. Modified code to check for the ammount of times
                              we have recurssivly called spCheckRoute.    If we
                              exceed a defined maximum, we should return an
                              error.  Otherwise, we can cause a core dump,
                              by infinitly calling the function recursivly.
             sp008.301 sg  4. Remote subsystems become available after
                              receiving an MTP-RESUME.  Also, a congested
                              online SCCP should process the MTP-RESUME.
/main/18_1     ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
             sp001.302 rc   1. Sid correction
             sp007.302 rc   1. In spLiHndlMngt, checking value returned by the
                               function decoding Mngt message.
             sp010.302 sg   1. Removed the sending of an SSP message.
             sp014.302 rc   1. On resume from mtp3 if route is already online
                               and sccp is uncongested then stop STA and SST
                               timers if they are running.
             sp018.302 rc  1.  Starting timers before sending message to other
                               layer to handle tight coupling interfaces.
             sp024.302 rc  1.  Generate SCCP error report for remote SCCP
                               unequipped on getting MTP3 indication.
                           2.  On MTP3 congestion indication, changing the run
                               time upd to Normal to avoid blocking of thread
                               in sync update when the route remains congested
                               for a longer duration and MTP3 is indicating
                               congestion repeateldy.
             sp035.302 mc 1.   Generating sccp report on receiving SSA,  SP
                               inaccesible and accessible indication from MTP3.
             sp040.302 rc 1.   Incrementing global cntr on receipt of SSP, SSC.
             sp041.302 sm 1.   Moved SCCP report generation on receiving 
                               MTP-RESUME to before the nsap check.
             sp043.302 mc 1.   Moved SCCP report generation on receiving 
                               MTP-RESUME to after the nsap SP_SNRST check.
             sp044.302 sm 1.   return on receipt of SST if affected point code
                               is not same as self pc.
             sp046.302 mc 1.   generate SCCP error perf/subsystem unavailablity
                               report indicating remote SP INACC on receiving
                               UPU from MTP3.
             sp047.302 sm 1.   If management is turned off mark all SSN's
                               accessible.
                          2.   Counters for SST, SSC and SSP transmit and
                               receive statistics added. 
             sp049.302 mc 1.   sccp error perf/subsystem availability 
                               report indicating remote SCCP unequipped
                               in case of MTP-PAUSE indication user part
                               unavailable, moved out of the if condition
                               check of priority.
*********************************************************************91*/

