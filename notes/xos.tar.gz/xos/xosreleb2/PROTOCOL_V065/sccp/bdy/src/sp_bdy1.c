/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     sccp - body 1
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Primitives.
  
     File:     cp_bdy1.c
  
     Sid:      cp_bdy1.c@@/main/26 - Tue Jan 22 15:15:00 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/



/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */

#ifdef SSI_WITH_CLI_ENABLED
#include "clishell.h"
#include "sp_dbg.h"
#endif

/* local defines */
  
/* local externs */
  
/* forward references */

/* sp038.302 - addition - support for multiple instances */
/* public variable declarations */
#ifdef SS_MULTIPLE_PROCS 
PUBLIC SpCb spCbLst[SP_MAX_INSTANCES];
PUBLIC SpCb *spCbPtr;
#else
PUBLIC SpCb spCb;
#endif /* SS_MULTIPLE_PROCS */

EXTERN U32 g_spDbgMask;
 
/* This structure holds all the global structs we need. */

/* private variable declarations */
  
/*
 *     support functions
 */
  
/*
*
*       Fun:   SpMiLspCfgReq
*
*       Desc:  Configure this layer for operation.
*             Called by Layer Management for one of the following purposes:
*             o STGEN - General Configuration 
*             o STNW - Network Configuration 
*             o STTSAP - Upper SAP (TCAP/ISUP) Configuration.
*             o STNSAP - Lower SAP (MTP3) Configuration
*             o STADRMAP - Add GTT AddrMap.
*             o STROUT - Add Routing Table Entry.
*             o STASSO - configuring an association.
*             o STMSGIMP - Default msg configuration
*             o STTRFLIM -  Traffic Limitation (Congestion)
*             o STNIDPC - Configuration of NID to DPC mapping
*             o STNWSS7 - Configuration of 

*       Ret:   SP_OK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpMiLspCfgReq
(
Pst *pst,               /* pointer to post structure */
SpMngmt *cfg            /* pointer to GenCfg Struct */
)
#else
PUBLIC S16 SpMiLspCfgReq(pst, cfg)
Pst *pst;               /* pointer to post structure */
SpMngmt *cfg;           /* pointer to GenCfg Struct */
#endif
{
   S16 ret;             /* return value */
#ifdef LSPV2_4      
   SpNwCb *nwCb;        /* sp045.302 - addition - ptr to network CB */
   U8 nwIndx;           /* sp045.302 - addition - index */
   S8 k;                /* sp045.302 - addition - index */
   U16 reason;          /* sp045.302 - addition - failure reason */
#endif 

   TRC3(SpMiLspCfgReq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0,  "SpMiLspCfgReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif   
#ifdef ZP
      /* We do allow configuration request when we are doing peersync
         as of now */
#endif /* ZP */

   /* sp045.302 - addition - initialise the return value to ROK. */
   ret = ROK;

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf, "SpMiLspCfgReq(elmId (%d))\n",
          cfg->hdr.elmId.elmnt));

   if (spCb.spInit.cfgDone != TRUE)
   {
      /* if general config is not over then use pst structure
       * in primitive to communicate to stack manager 
       */
      spCb.spInit.lmPst.selector = pst->selector;
      spCb.spInit.lmPst.region = pst->region;
      spCb.spInit.lmPst.pool = pst->pool;
      spCb.spInit.lmPst.prior = pst->prior;
      spCb.spInit.lmPst.route = pst->route;         
      spCb.spInit.lmPst.dstProcId = pst->srcProcId;
      spCb.spInit.lmPst.dstEnt = pst->srcEnt;
      spCb.spInit.lmPst.dstInst = pst->srcInst;
#ifdef SP_RUG
      /* fill intfVer in lmPst, Layer manager is not required to provide
       * backward compatibility at LM interface. LM always fills self LM
       * interface version number in pst. Initialize interface version in
       * lmPst with the version number filled by LM in pst structure 
       */
      spCb.spInit.lmPst.intfVer = pst->intfVer;
#endif /* SP_RUG */
      
      /* we should not use spCb.spInit.procId here because for fault
       * tolernace if PSF is been configured first then this will
       * contain virtual procId
       */
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS      
      spCb.spInit.lmPst.srcProcId = spCb.spInit.procId;
#else      
      spCb.spInit.lmPst.srcProcId = SFndProcId();
#endif      
      spCb.spInit.lmPst.srcEnt = spCb.spInit.ent;
      spCb.spInit.lmPst.srcInst = spCb.spInit.inst;
      spCb.spInit.lmPst.event = EVTNONE;

      /* Intialie traffic and audit related  flags */
      spCb.spTrfLimFlag = FALSE;
      spCb.spTrfLimCfgDone = FALSE;
      spCb.spAudFlag = FALSE;
   } /* spCb..cfgDone != TRUE */
      
   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:       /* general */
         ret = spGenCfgReq(pst, cfg);
         break;
      case STNW:        /* A new network */
         ret = spNwCfgReq(pst, cfg);
         break;
      case STTSAP:      /* A New Sap */
         ret = spSapCfgReq(pst, cfg);
         break;
      case STNSAP:      /* network sap with bind */
         ret = spNSapCfgReq(pst, cfg);
         break;
      case STASSO :
         /* sp045.302 - addition - if network id is 0xFFFF then add association
          * in all the networks of the same variants.
          */
#ifdef LSPV2_4      
         if (cfg->t.cfg.s.spAsso.nwId == 0xFFFF)
         {
            nwCb = NULLP;
            for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
            {
               nwCb = *(spCb.nwList + (PTR) nwIndx);
               if (nwCb->variant == cfg->t.cfg.s.spAsso.rule.sw)
               {
                  cfg->t.cfg.s.spAsso.nwId = nwCb->nwId;
                  ret = spAssoCfgReq(pst, cfg);
                  /* if association was not successfully added then we need
                   * to delete this association from all the previous networks
                   * in which it was successfully added.
                   */
                  if (ret != ROK)
                  {
                     for (k = ((S8)nwIndx - 1); k >= 0; k--)
                     {
                        nwCb = *(spCb.nwList + (PTR) k);
                        if (nwCb->variant == cfg->t.cfg.s.spAsso.rule.sw)
                        {
                           cfg->t.cfg.s.spAsso.nwId = nwCb->nwId;
                           if ((reason = spDelAsso (&cfg->t.cfg.s.spAsso))
                               != LCM_REASON_NOT_APPL)
                           {
                              SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
                                     "SpMiLspCfgReq: Association deletion\
                                      failed during Associaiton config for\
                                      special case of network id == 0xFFFF for\
                                      network id : %ld\n", nwCb->nwId));
                           }
                        } /* (nwCb->variant == cfg->t.cfg.s.spAsso.rule.sw) */
                     } /* (k = ((S8)nwIndx - 1); k >= 0; k--) */
                     break;
                  } /* if (ret != ROK) */
               } /* if (nwCb->variant == cfg->t.cfg.s.spAsso.rule.sw) */
            } /* for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++) */
         } /* if (cfg->t.cfg.s.spAsso.nwId == 0xFFFF) */
         else
            ret = spAssoCfgReq(pst, cfg);
         if (ret != ROK)
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 0);
#else 
         ret = spAssoCfgReq(pst, cfg);
#endif 
         break;
      case STADRMAP :
         /* sp045.302 - addition - if network id is 0xFFFF then add addressMap
          * in all the networks of the same variants.
          */
#ifdef LSPV2_4      
         if (cfg->t.cfg.s.spAddrMap.nwId == 0xFFFF)
         {
            nwCb = NULLP;
            for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
            {
               nwCb = *(spCb.nwList + (PTR) nwIndx);
               if (nwCb->variant == cfg->t.cfg.s.spAddrMap.sw)
               {
                  cfg->t.cfg.s.spAddrMap.nwId = nwCb->nwId;
                  ret = spAddrMapCfgReq(pst, cfg);
                  /* if addressMap was not successfully added then we need
                   * to delete this AddressMap from all the previous networks
                   * in which it was successfully added.
                   */
                  if (ret != ROK)
                  {
                     for (k = ((S8)nwIndx - 1); k >= 0; k--)
                     {
                        nwCb = *(spCb.nwList + (PTR) k);
                        if (nwCb->variant == cfg->t.cfg.s.spAddrMap.sw)
                        {
                           cfg->t.cfg.s.spAddrMap.nwId = nwCb->nwId;
                           cfg->t.cfg.s.spAddrMap.outNwId = nwCb->nwId;
                           if ((reason = spDelAddrMap 
                               (&cfg->t.cfg.s.spAddrMap))
                               != LCM_REASON_NOT_APPL)
                           {
                              SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
                                     "SpMiLspCfgReq: Association deletion\
                                      failed during Associaiton config for\
                                      special case of network id == 0xFFFF for\
                                      network id : %ld\n", nwCb->nwId));
                           }
                        } /* (nwCb->variant == cfg->t.cfg.s.spAsso.rule.sw) */
                     } /* (k = ((S8)nwIndx - 1); k >= 0; k--) */
                     break;
                  } /* if (ret != ROK) */
               }
            }
         }
         else
            ret = spAddrMapCfgReq(pst, cfg);
         if (ret != ROK)
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 0);
#else 
         ret = spAddrMapCfgReq(pst, cfg);
#endif 
         break;
      case STROUT:
         ret = spRteCfgReq(pst, cfg);
         break;

      case STTRFLIM :
         ret = spTrfLimCfgReq(pst, cfg);
         break;   
      case STMSGIMP :
         ret = spMsgImpCfgReq(pst, cfg);
         break;
      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP001, (ErrVal) cfg->hdr.elmId.elmnt, 
                    "SpMiLspCfgReq() invalid elmnt");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_ELMNT);
         RETVALUE(RFAILED);
   } /* switch(cfg...elmnt) */
 
   if (ret !=ROK)
      RETVALUE(RFAILED);

#ifdef ZP
   zpUpdPeer ();
#endif /* ZP */

   spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_OK, 0);

   RETVALUE(ROK);

} /* SpMiLspCfgReq */

  
/*
*
*       Fun:   SpMiLspCntrlReq
*
*       Desc:  Controls for SCCP
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpMiLspCntrlReq
(
Pst *pst,                /* post structure */
SpMngmt *cntrl           /* Control Strucutre */
)
#else
PUBLIC S16 SpMiLspCntrlReq(pst, cntrl)
Pst *pst;                /* post structure */
SpMngmt *cntrl;          /* Control Structure */
#endif
{
   S16 i;                /* index */
   Elmnt elmnt;          /* header element */
   U8 action;            /* action parameter */
   U8 sAction;           /* subaction field */
   U16 reason;           /* failure reason */
   SpSapCb *sap;         /* sap control block pointer */
   SpNSapCb *nsap;       /* network sap control block pointer */
   S16 ret;              /* return val */
#ifdef LSPV2_4      
   SpNwCb *nwCb;        /* sp045.302 - addition - ptr to network CB */
   U8 nwIndx;           /* sp045.302 - addition - index */
#endif 

   TRC3(SpMiLspCntrlReq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpMiLspCntrlReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf, "SpMiLspCntrlReq(pst, elmId (%d)\n",
          cntrl->hdr.elmId.elmnt));

   elmnt = cntrl->hdr.elmId.elmnt;
   action = cntrl->t.cntrl.action;
   sAction = cntrl->t.cntrl.subAction;
   reason = FALSE;

#ifdef ZP
   /* Since we send out updates for alarms...we should check if we
      are in the middle of a peersync */
   /* sp001.302 - addition - check for deletion of nw, sap, nsap added */
   if (((elmnt == STGEN) &&
       (((action == AENA) && (sAction == SAUSTA)) ||
       ((action == ADISIMM) && (sAction == SAUSTA)) || (action == ACONG))) ||
       (elmnt == STDELROUT) || (elmnt == STDELADRMAP) || (elmnt == STDELASSO) ||
       (elmnt == STDELNW) || (elmnt == STDELTSAP) || (elmnt == STDELNSAP))
   {
      if (!zpCheckCritical())
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP002, (ErrVal) 0, 
                    "SpMiLspCntrlReq() received in invalid PSF state");
         spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_STATE);
         RETVALUE(RFAILED);         
      }
   }
#endif /* ZP */

   /* validate control request parameters */
   switch (elmnt)
   { 
      case STGEN:
         switch (action)
         {
            case AENA:
            case ADISIMM:
               if ((sAction != SAUSTA) 
#ifdef DEBUGP
                  && (sAction != SADBG)
#endif /* DEBUGP */
                  && (sAction != SAAUD)
                  && (sAction != SATRFLIM)
                  && (sAction != SAREPORT)
                 )
                  reason = LCM_REASON_INVALID_SUBACTION;
               if (sAction == SATRFLIM)
               {
                  if (spCb.spTrfLimCfgDone != TRUE)
                     reason = LCM_REASON_INVALID_STATE;
               }
               break;

            case ACONG:      /* SCCP congestion */   
               /* validate congestion level */
               if (cntrl->t.cntrl.ctlType.spCong.congLvl > MAXCL)
                  reason = LCM_REASON_INVALID_PAR_VAL;
               break;
            case ASHUTDOWN:  /* shutdown SCCP */
#ifdef SPCO
            case ARST:       /* SCCP reset - start the guard timer */
#endif /* SPCO */
               /* subaction - dont care */
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      case STTSAP:
         switch (action)
         {
            case AUBND_DIS:
               if ((cntrl->hdr.elmId.elmntInst1 < 0) ||
                   (cntrl->hdr.elmId.elmntInst1 >= spCb.spCfg.nmbSaps) ||
                   (spCb.sapList[cntrl->hdr.elmId.elmntInst1] == 
                    (SpSapCb *)NULLP))
                  reason = LCM_REASON_INVALID_SAP;
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      case STNSAP:
         switch (action)
         {
            case AUBND_DIS: 
            case ABND_ENA:
               if ((cntrl->hdr.elmId.elmntInst1 < 0) ||
                   (cntrl->hdr.elmId.elmntInst1 >= spCb.spCfg.nmbNSaps) ||
                   (spCb.nSapList[cntrl->hdr.elmId.elmntInst1] == 
                    (SpNSapCb *)NULLP))
                  reason = LCM_REASON_INVALID_SAP;
               break;

            case ADISIMM:
            case AENA:
               if (sAction != SATRC)
                  reason = LCM_REASON_INVALID_SUBACTION;
               /* sp011.302 - added check for invalid NSap */
               if ((cntrl->hdr.elmId.elmntInst1 < 0) ||
                   (cntrl->hdr.elmId.elmntInst1 >= spCb.spCfg.nmbNSaps) ||
                   (spCb.nSapList[cntrl->hdr.elmId.elmntInst1] ==
                    (SpNSapCb *)NULLP))
                  reason = LCM_REASON_INVALID_SAP;
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;            
         }
         break;

      case STGRTSAP:
         switch (action)
         {
            case AUBND_DIS:
               if (sAction != SAGR_DSTPROCID)
                  reason = LCM_REASON_INVALID_SUBACTION;
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      case STGRNSAP:
      case STALLSAP:
         switch (action)
         {
            case AUBND_DIS:
            case ABND_ENA:
               if (sAction != SAGR_DSTPROCID)
                  reason = LCM_REASON_INVALID_SUBACTION;
               break;

            default:
               reason = LCM_REASON_INVALID_ACTION;
               break;
         }
         break;

      /* sp001.302 - addition - deletion of network, sap and nSap */
      case STDELNW:
#if (ERRCLASS & ERRCLS_INT_PAR) 
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO, 
                       "general configuration needs to be done first");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */
         break;

      case STDELTSAP:
#if (ERRCLASS & ERRCLS_INT_PAR) 
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO, 
                       "general configuration needs to be done first");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }
         if (cntrl->hdr.elmId.elmntInst1 >= (S16) spCb.spCfg.nmbSaps)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                       (ErrVal) cntrl->hdr.elmId.elmntInst1,
                       "Sap index out of range");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */
         break;

      case STDELNSAP:
#if (ERRCLASS & ERRCLS_INT_PAR) 
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO, 
                       "general configuration needs to be done first");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }
         if (cntrl->hdr.elmId.elmntInst1 >= (S16) spCb.spCfg.nmbNSaps)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                       (ErrVal) cntrl->hdr.elmId.elmntInst1,
                       "NSap index out of range");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK,
                        LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */
         break;

      case STDELROUT:
#if (ERRCLASS & ERRCLS_INT_PAR) 
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP003, (ErrVal) ERRZERO, 
                       "general configuration needs to be done first");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }
         if (cntrl->t.cntrl.cfg.spDelRte.nSapId >= (S16)spCb.spCfg.nmbNSaps)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP004,
                       (ErrVal) cntrl->t.cntrl.cfg.spDelRte.nSapId, 
                       "NSap index out of range");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK,
                                             LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */
         break;

      case STDELADRMAP:
         /* General configuration has to be done */
#if  (ERRCLASS & ERRCLS_INT_PAR)
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP005, (ErrVal) 0,
                       "General Configuration to be done");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE(RFAILED);
         }
#endif /* ERRCLASS */
         break;

      case STDELASSO:
         /* General configuration has to be done */
         if (spCb.spInit.cfgDone == FALSE)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP006, (ErrVal) 0,
                       "General Configuration to be done");
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_GENCFG_NOT_DONE);
            RETVALUE (RFAILED);
         }
         break;

      default:
         reason = LCM_REASON_INVALID_ELMNT;
         break;
   } /* end switch */
   
   if (reason != FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP007, (ErrVal) reason, 
                 "SpMiLspCntrlReq() invalid action/subaction/elmId");
      spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
      RETVALUE(RFAILED);
   }

   switch (elmnt)
   {
      case STGEN: 
         switch(action)
         {
            case ASHUTDOWN:
               spShutdown();
               break;

            case AENA:
               if ((sAction == SAUSTA) || (sAction == SAREPORT))
               {
                  spCb.ustaMask |= cntrl->t.cntrl.ctlType.ustaMask;
               }
#ifdef DEBUGP
               if (sAction == SADBG)
               {
                  spCb.spInit.dbgMask |= cntrl->t.cntrl.ctlType.spDbg.dbgMask;
               }
#endif /* DEBUGP */
              
              if (sAction == SATRFLIM)
                 spCb.spTrfLimFlag = TRUE;
             
              if (sAction == SAAUD)
                 spCb.spAudFlag = TRUE;

#ifdef ZP
/* sp026.302 - addition - do not generate RT upd for debug enable. Debug
 * control request is sent to each copy of SCCP in both core 1 and core 2 arch.
 */
#ifdef DEBUGP
              if (sAction != SADBG)
#endif /* DEBUGP */
                  zpRunTimeUpd(ZP_SP_PCB, (Void *)&spCb, 
                               CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
              break;

            case ADISIMM:
               if ((sAction == SAUSTA) || (sAction == SAREPORT))
               {
                  spCb.ustaMask &= ~(cntrl->t.cntrl.ctlType.ustaMask);
               }
#ifdef DEBUGP
               if (sAction == SADBG)
               {
                 spCb.spInit.dbgMask &= ~(cntrl->t.cntrl.ctlType.spDbg.dbgMask);
               }
#endif /* DEBUGP */
               if (sAction == SATRFLIM)
               {
                  spCb.spTrfLimFlag = FALSE;
               }
             
               if (sAction == SAAUD)
               {
                  spCb.spAudFlag = FALSE;
               }
#ifdef ZP
/* sp026.302 - addition - do not generate RT upd for debug disable. Debug
 * control request is sent to each copy of SCCP in both core 1 and core 2 arch.
 */
#ifdef DEBUGP
              if (sAction != SADBG)
#endif /* DEBUGP */
                  zpRunTimeUpd(ZP_SP_PCB, (Void *)&spCb, 
                               CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
               break;
#ifdef SPCO
            case ARST :  
               /* 
                * Existing connections are retained. Ideally guard
                * timer should be startedafter the SCCP has just come
                * up and no traffic has been started as yet. 
                */
               if (! (spCb.status & SP_GUARD)) /* check for a crazy SM */
                  spCb.status ^= SP_GUARD;
              
               spCb.tmr.enb = TRUE;
               spCb.tmr.val = spCb.spCfg.defGuaTmr.val;
               spStartGlbTmr(&spCb, TMR_GRD);

               break;
#endif /* SPCO */
            case ACONG :
            { 
               spCb.sscThresh = cntrl->t.cntrl.ctlType.spCong.sscThresh;
               spCb.congLvl = cntrl->t.cntrl.ctlType.spCong.congLvl;
            }
#ifdef ZP
               zpRunTimeUpd(ZP_SP_PCB, (Void *)&spCb, 
                            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
               break;
         } 
         break;
        
      case STTSAP:
         spDisableUpperSap(spCb.sapList[cntrl->hdr.elmId.elmntInst1]);
#ifdef ZP
         zpRunTimeUpd(ZP_SP_SAPCB, 
                      (Void *)spCb.sapList[cntrl->hdr.elmId.elmntInst1],
                      CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
         break;

      case STNSAP:  /* network sap */
         switch (action)
         {
            case AUBND_DIS:
               spDisableLowerSap(spCb.nSapList[cntrl->hdr.elmId.elmntInst1]);
               spCb.nSapList[cntrl->hdr.elmId.elmntInst1]->contEnt = ENTSM;

/* sp026.302 - addition - update sby from this location */
#ifdef ZP
               zpRunTimeUpd(ZP_SP_NSAPCB,
                            (Void *) spCb.nSapList[cntrl->hdr.elmId.elmntInst1],
                            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
               break;

            case ABND_ENA:
               ret = 
                   spEnableLowerSap(spCb.nSapList[cntrl->hdr.elmId.elmntInst1],
                                    &reason);
               if(ret != ROK)
               {
                  spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
                  RETVALUE(RFAILED);
               }
               spCb.nSapList[cntrl->hdr.elmId.elmntInst1]->contEnt = ENTNC;

/* sp026.302 - addition - update sby from this location */
#ifdef ZP
               zpRunTimeUpd(ZP_SP_NSAPCB,
                            (Void *) spCb.nSapList[cntrl->hdr.elmId.elmntInst1],
                            CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
               break;

            case AENA:   /* trace enabling */
               if (sAction == SATRC)
               {
                  spCb.nSapList[cntrl->hdr.elmId.elmntInst1]->trc = TRUE;
               }
               break;

            case ADISIMM:   /* trace disabling */
               if (sAction == SATRC)
               {
                  spCb.nSapList[cntrl->hdr.elmId.elmntInst1]->trc = FALSE;
               }
               break;

            default:
               /* Somethign is clearly wrong if we come here */
               break;
         }
         /* sp026.302 - modification - call run time upd in appropriate
          * cases by moving function call above.
          */
         break;

     case STGRTSAP:
        for (i = 0; i < spCb.spCfg.nmbSaps; i++)
        {
           sap = spCb.sapList[i];
           if ((sap != (SpSapCb *)NULLP) &&
               (sap->pst.dstProcId == cntrl->t.cntrl.par.dstProcId))
           {
              if (action == AUBND_DIS)
              {
                 spDisableUpperSap(sap);
#ifdef ZP
                 zpRunTimeUpd(ZP_SP_SAPCB, (Void *)sap, 
                              CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */
              }
           }
        }
        break;

     case STGRNSAP:
        switch (action)
        {
           case AUBND_DIS:
              for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
              {
                 nsap = spCb.nSapList[i];
                 if ((nsap != (SpNSapCb *)NULLP) &&
                     (nsap->pst.dstProcId == cntrl->t.cntrl.par.dstProcId))
                 {
                    spDisableLowerSap(nsap);
                    nsap->contEnt = ENTSM;
#ifdef ZP
                    zpRunTimeUpd(ZP_SP_NSAPCB, (Void *)nsap, 
                                 CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                 }
              }
              break;
              
           case ABND_ENA:
              for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
              {
                 nsap = spCb.nSapList[i];
                 if ((nsap != (SpNSapCb *)NULLP) &&
                     (nsap->pst.dstProcId == cntrl->t.cntrl.par.dstProcId))
                 {
                    ret = spEnableLowerSap(nsap, &reason);              
                    if(ret != ROK)
                    {
                       spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                                   reason);
                       RETVALUE(RFAILED);
                    }
                    nsap->contEnt = ENTNC;
#ifdef ZP
                    zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nsap,
                                 CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                 }
              }
              break;
        }
        break;

     case STALLSAP:
        for (i = 0; i < spCb.nmbSaps; i++)
        {
           sap = spCb.sapList[i];
           if ((sap != (SpSapCb *)NULLP) &&
               (sap->pst.dstProcId == cntrl->t.cntrl.par.dstProcId))
           {
              if (action == AUBND_DIS)
              {
                 spDisableUpperSap(sap);
#ifdef ZP
                 zpRunTimeUpd(ZP_SP_SAPCB, (Void *)sap, 
                              CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_MOD);
#endif /* ZP */
              }
           }
        }
        for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
        {
           nsap = spCb.nSapList[i];
           if ((nsap != (SpNSapCb *)NULLP) &&
               (nsap->pst.dstProcId == cntrl->t.cntrl.par.dstProcId))
           {
              if (action == AUBND_DIS)
              {
                 spDisableLowerSap(nsap);
                 nsap->contEnt = ENTSM;
              }
              else
              {
                 ret = spEnableLowerSap(nsap, &reason);
                 if(ret != ROK)
                 {
                    spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                                reason);
                    RETVALUE(RFAILED);
                 }
                 nsap->contEnt = ENTNC;
              }
#ifdef ZP
              zpRunTimeUpd(ZP_SP_NSAPCB, (Void *)nsap, CMPFTHA_UPDTYPE_SYNC, 
                           CMPFTHA_ACTN_MOD);
#endif /* ZP */
           }
        }
        break;

      /* sp001.302 - addition - deletion of network, sap and nSap */
      case STDELNW:
         if ((reason = spDeleteNetwork(cntrl->hdr.elmId.elmntInst1)) != 
             LCM_REASON_NOT_APPL)
         {
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
            RETVALUE(RFAILED);
         }
         break;

      case STDELTSAP:
         if ((reason = spDeleteSap(cntrl->hdr.elmId.elmntInst1)) != 
             LCM_REASON_NOT_APPL)
         {
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
            RETVALUE(RFAILED);
         }
         break;

      case STDELNSAP:
         if ((reason = spDeleteNSap(cntrl->hdr.elmId.elmntInst1)) != 
             LCM_REASON_NOT_APPL)
         {
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, reason);
            RETVALUE(RFAILED);
         }
         break;

      case STDELROUT:
         if ((reason = spDeleteRoute (&cntrl->t.cntrl.cfg.spDelRte)) != 
             LCM_REASON_NOT_APPL)
         {
            spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                        reason);
            RETVALUE(RFAILED);
         }
         break;

      case STDELADRMAP :
         /* sp045.302 - addition - if network id is 0xFFFF then delete
          * addressMap in all the networks of the same variants.
          */
#ifdef LSPV2_4      
         if (cntrl->t.cntrl.cfg.spAddrMap.nwId == 0xFFFF)
         {
            nwCb = NULLP;
            for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
            {
               nwCb = *(spCb.nwList + (PTR) nwIndx);
               if (nwCb->variant == cntrl->t.cntrl.cfg.spAddrMap.sw)
               {
                  cntrl->t.cntrl.cfg.spAddrMap.nwId = nwCb->nwId;
                  cntrl->t.cntrl.cfg.spAddrMap.outNwId = nwCb->nwId;
                  if ((reason = spDeleteAddrMap (&cntrl->t.cntrl.cfg.spAddrMap))
                      != LCM_REASON_NOT_APPL)
                  {
                     spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                                 reason);
                     RETVALUE(RFAILED);
                  }
                  break;

               }
            }
         }
         else
#endif 
         {
            if ((reason = spDeleteAddrMap (&cntrl->t.cntrl.cfg.spAddrMap)) != 
                LCM_REASON_NOT_APPL)
            {
               spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                           reason);
               RETVALUE(RFAILED);
            }
         }
         break;

      case STDELASSO:
         /* sp045.302 - addition - if network id is 0xFFFF then delete
          * addressMap in all the networks of the same variants.
          */
#ifdef LSPV2_4      
         if (cntrl->t.cntrl.cfg.spAsso.nwId == 0xFFFF)
         {
            nwCb = NULLP;
            for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
            {
               nwCb = *(spCb.nwList + (PTR) nwIndx);
               if (nwCb->variant == cntrl->t.cntrl.cfg.spAsso.rule.sw)
               {
                  cntrl->t.cntrl.cfg.spAsso.nwId = nwCb->nwId;
                  if ((reason = spDeleteAsso (&cntrl->t.cntrl.cfg.spAsso)) 
                      != LCM_REASON_NOT_APPL)
                  {
                     spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                                 reason);
                     RETVALUE(RFAILED);
                  }
               }
            }
         }
         else
#endif 
         {
            if ((reason = spDeleteAsso (&cntrl->t.cntrl.cfg.spAsso)) != 
                LCM_REASON_NOT_APPL)
            {
               spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_NOK, 
                           reason);
               RETVALUE (RFAILED);
            }
         }
         break;

     default:
         break;
   } /* end switch */

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
          
   spSendLmCfm(pst, TCNTRL, &cntrl->hdr, LCM_PRIM_OK, 0);
   RETVALUE(ROK);

} /* SpMiLspCntrlReq */

  
/*
*
*       Fun:   SpMiLspStaReq
*
*       Desc:  Request Status from SCCP
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpMiLspStaReq
(
Pst *pst,
SpMngmt *sta                     /* Status Strucutre */
)
#else
PUBLIC S16 SpMiLspStaReq(pst, sta)
Pst *pst;
SpMngmt *sta;                    /* Status Structure */
#endif
{
   SpSapCb *sap;
   SpNSapCb *nSap;
#ifdef SP_LMINT3
   Pst rPst;               /* reply post */
#endif /* SP_LMINT3 */
   SpRteCb* rCb;
   SpRteKey rKey;
   S16 i;
   U8 j;
   SpMngmt rSta;

   TRC3(SpMiLspStaReq);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpMiLspStaReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf, "SpMiLspStaReq(pst, elmId (%d))\n",
          sta->hdr.elmId.elmnt));

   /* sp016.302 - addition - initialize rSta */
   cmZero((U8 *) &rSta, sizeof(SpMngmt));

   SGetDateTime(&rSta.t.ssta.dt);

   switch (sta->hdr.elmId.elmnt)
   {
      case STTSAP:
         if ((sap = *(spCb.sapList + sta->hdr.elmId.elmntInst1)) == NULLP)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP008, 
                       (ErrVal) ERRZERO, "sap not configured");
            spSendLmCfm(pst, TSSTA, &sta->hdr, 
                        LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         } 
         /* sp027.302 - modification - return status as bitMask to report
          * various states of sap, instead of just returning BND and UNBND
          * state. Values can be found in lsp.h file.
          */
         rSta.t.ssta.s.spSta.status = (S16) sap->status;
#ifdef SP_RUG
         /* fill self and remote interface version info in status struct */
         rSta.t.ssta.s.spSta.selfIntfVer = SPTIFVER;
         rSta.t.ssta.s.spSta.remIntfValid = sap->remIntfValid;
         rSta.t.ssta.s.spSta.remIntfVer = sap->pst.intfVer;
#endif /* SP_RUG */
         break;

      case STNSAP:
         if ((nSap = *(spCb.nSapList + sta->hdr.elmId.elmntInst1)) == NULLP)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP009, 
                       (ErrVal) ERRZERO, "nSap not configured");
            spSendLmCfm(pst, TSSTA, &sta->hdr, 
                        LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
            RETVALUE(RFAILED);
         } 
         /* sp027.302 - modification - return status as bitMask to report
          * various states of sap, instead of just returning BND and UNBND
          * state. Values can be found in lsp.h file.
          */
         rSta.t.ssta.s.spSta.status = (S16) nSap->status;
#ifdef SP_RUG
         /* return self and remote interface version info in status struct */
         rSta.t.ssta.s.spSta.selfIntfVer = SNTIFVER;
         rSta.t.ssta.s.spSta.remIntfValid = nSap->remIntfValid;
         rSta.t.ssta.s.spSta.remIntfVer = nSap->pst.intfVer;
#endif /* SP_RUG */
         break;
         
      case STROUT:
         /* 
          * Check if it is a enquiry for a local pointcode 
          */
         /* Find the NSAP corresponding to the pointcode */
         for (i = 0, j = 0, nSap = (SpNSapCb *)NULLP; 
              i < spCb.spCfg.nmbNSaps; i++)    
         {
            if ((spCb.nSapList[i] != (SpNSapCb*)NULLP) &&
               (spCb.nSapList[i]->nwData->selfPc ==
                      sta->t.ssta.s.spRteSta.pcSta.pc) &&
               (spCb.nSapList[i]->nwData->nwId == 
                      sta->t.ssta.s.spRteSta.pcSta.nwId))
            {
               nSap = spCb.nSapList[i];
               break; /* found the pc */
            }
         }
         if (i != spCb.spCfg.nmbNSaps)
         {
            /* pc found, return the status of the local subsystems */
            rSta.t.ssta.s.spRteSta.pcSta.nwId = nSap->nwData->nwId;
            rSta.t.ssta.s.spRteSta.pcSta.pc = nSap->nwData->selfPc;

            /* It will always be solitary. We wont know we have a backup */
            rSta.t.ssta.s.spRteSta.pcSta.smi = SMI_SOL;

            rSta.t.ssta.s.spRteSta.pcSta.status = SP_ACC;

            /* Get the status of all the subsystems */
            for (i = 0, sap = (SpSapCb *)NULLP; 
                 ((i < spCb.spCfg.nmbSaps) && (j < MAXNUMSSN)); i++)
            {
               sap = spCb.sapList[i];
               if ((sap != (SpSapCb *)NULLP) &&
                   (sap->nwData == nSap->nwData) &&
                   (sap->status & SP_BND)) 
               {
                  /* ok, sap exists and we have a SSN cuz it's bound */
                  sap = spCb.sapList[i];
                  rSta.t.ssta.s.spRteSta.ssnSta[j].ssn = sap->ssn;  
                  if (sap->status & SP_PROH)
                     rSta.t.ssta.s.spRteSta.ssnSta[j].status = SS_UOS;
                  else
                     rSta.t.ssta.s.spRteSta.ssnSta[j].status = SS_UIS;
                  rSta.t.ssta.s.spRteSta.ssnSta[j].smi =
                                                    sap->nmbBpc?SMI_DUP:SMI_SOL;
                  /* Increment the count */
                  j++;
               }
            }
            rSta.t.ssta.s.spRteSta.nmbSsns = j;
            break;
         } /* End of processing for local point code */
         else
         {
            /* 
             * It is not a local PC. Check for remote pc.
             * Find route Cb for the PC in psSta.pc 
             * We havent used elmntInst1 becoz it is a S16 and ANSI PC wont fit.
             */
            rKey.k1.dpc = sta->t.ssta.s.spRteSta.pcSta.pc;
            rKey.k1.nwId = sta->t.ssta.s.spRteSta.pcSta.nwId;

            spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
         
            /* error checks */
            if (rCb == (SpRteCb*)NULLP) 
            {
               spSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK, 
                           LCM_REASON_INVALID_PAR_VAL);
               RETVALUE (RFAILED);            
            }

            /* find status of point code */
            rSta.t.ssta.s.spRteSta.pcSta.nwId = rCb->nSap->nwData->nwId;
            rSta.t.ssta.s.spRteSta.pcSta.pc = rCb->dpc;
            rSta.t.ssta.s.spRteSta.pcSta.smi = rCb->nmbBpc?SMI_DUP:SMI_SOL;

            rSta.t.ssta.s.spRteSta.pcSta.status = 0;
            if (rCb->status & SP_ONLINE)
               rSta.t.ssta.s.spRteSta.pcSta.status |= SP_ACC;
            else
               rSta.t.ssta.s.spRteSta.pcSta.status |= SP_INACC;
            if (rCb->status & SP_CONG)
               rSta.t.ssta.s.spRteSta.pcSta.status |= SP_CONG;
            rSta.t.ssta.s.spRteSta.pcSta.sccpSts = rCb->sccpSts;
            rSta.t.ssta.s.spRteSta.pcSta.rl = rCb->spRestrictComp.rl;
            rSta.t.ssta.s.spRteSta.pcSta.rsl = rCb->spRestrictComp.rsl;
            rSta.t.ssta.s.spRteSta.pcSta.cl = (U8) (rCb->spRestrictLocal.cls);
            rSta.t.ssta.s.spRteSta.pcSta.ril = rCb->spRestrictComp.ril;

            /* find status of all the subsystems for this route */
            rSta.t.ssta.s.spRteSta.nmbSsns = rCb->nmbSsns;
            for (i = 0; i < rCb->nmbSsns; i++)
            {
               rSta.t.ssta.s.spRteSta.ssnSta[i].ssn = rCb->ssnList[i].ssn;
               if (rCb->ssnList[i].nmbBpc)
                  rSta.t.ssta.s.spRteSta.ssnSta[i].smi = SMI_DUP;
               else
                  rSta.t.ssta.s.spRteSta.ssnSta[i].smi = SMI_SOL;

               rSta.t.ssta.s.spRteSta.ssnSta[i].status = 0;
               if (rCb->ssnList[i].status & SS_ACC)
                  rSta.t.ssta.s.spRteSta.ssnSta[i].status |= SS_UIS;
               else
                  rSta.t.ssta.s.spRteSta.ssnSta[i].status |= SS_UOS;
            } /* for () */
         }
         break;

      case STSID:
         /* initialize self system Id */
         spGetSId(&rSta.t.ssta.s.sysId);  
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP010, (ErrVal) sta->hdr.elmId.elmnt, 
                    "invalid elmnt");
         spSendLmCfm(pst, TSSTA, &sta->hdr, LCM_PRIM_NOK,
                     LCM_REASON_INVALID_ELMNT);
         RETVALUE (RFAILED);
   } /* switch () */

   rSta.hdr.msgType = NOTUSED;
   rSta.hdr.msgLen = NOTUSED;
   rSta.hdr.seqNmb = NOTUSED;
   rSta.hdr.version = NOTUSED;
   rSta.hdr.elmId.elmnt = sta->hdr.elmId.elmnt;
   /* sp011.302 - StaCfm will contain the same elmntInst1 as the Req */
   rSta.hdr.elmId.elmntInst1 = sta->hdr.elmId.elmntInst1;
   rSta.hdr.elmId.elmntInst2 = NOTUSED;
   rSta.hdr.elmId.elmntInst3 = NOTUSED;
   rSta.hdr.entId.ent = spCb.spInit.ent;
   rSta.hdr.entId.inst = spCb.spInit.inst;

#ifdef SP_LMINT3
   rSta.hdr.transId = sta->hdr.transId;
   cmCopy ((U8 *)&sta->hdr.response, (U8 *)&rSta.hdr.response, sizeof(Resp));
   rSta.cfm.status = LCM_PRIM_OK;
   /* sp001.302 - addition - fill reason as not applicable for success case */
   rSta.cfm.reason = LCM_REASON_NOT_APPL;

   spFillReplyPst(&rPst, &sta->hdr, pst);
   SpMiLspStaCfm(&rPst, &rSta);
#else
   SpMiLspStaCfm(&spCb.spInit.lmPst, &rSta);
#endif /* SP_LMINT3 */

   RETVALUE (ROK);
} /* SpMiLspStaReq */

  
/*
*
*       Fun:   SpMiLspStsReq
*
*       Desc:  Request Statistics from SCCP
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpMiLspStsReq
(
Pst *pst,                       /* post */
Action action,                  /* Action */
SpMngmt *sts                    /* Statistics Structure */
)
#else
PUBLIC S16 SpMiLspStsReq(pst, action, sts)
Pst *pst;                       /* post */
Action action;                  /* action */
SpMngmt *sts;                   /* Statistics Strucutre */
#endif
{
#ifdef SP_LMINT3
   Pst rPst;           /* reply post */
#endif /* SP_LMINT3 */
   SpMngmt rSts;       /* reply statistics structure */
   
   TRC3(SpMiLspStsReq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpMiLspCfgReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
          "SpMiLspStsReq(pst, Action (%d), elmId (%d))\n", action,
          sts->hdr.elmId.elmnt));

   /* sp016.302 - addition - initialize rSts */
   cmZero((U8 *) &rSts, sizeof(SpMngmt));

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sts->hdr.elmId.elmnt != STGEN) &&      /* general statistics */
       (sts->hdr.elmId.elmnt != STTSAP) &&     /* sap (upper) statistics */
       (sts->hdr.elmId.elmnt != STNSAP) &&     /* nsap (lower) statistics */
       (sts->hdr.elmId.elmnt != STROUT))       /* route statistics */
   {
      /* sp027.302 - addition - add STROUT in error log */
      SPLOGERROR(ERRCLS_INT_PAR, ESP011, (ErrVal) sts->hdr.elmId.elmnt, 
                 "SpMiLspStsReq() element not STGEN, STTSAP, STNSAP or STROUT");
      spSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_ELMNT);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* validate action parameter */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (action > NOZEROSTS)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP012, (ErrVal) action, 
                 "qSpMiLspStsReq() invalid action");
      spSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_INVALID_ACTION);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
  
   (Void) SGetDateTime(&rSts.t.sts.dt);

   if (sts->hdr.elmId.elmnt == STGEN)
   {
      /* move statistic counters into statistic structure */
      cmCopy((U8 *)&spCb.sts, (U8 *)&rSts.t.sts.s.spGlbSts, 
             sizeof(SpGLBSts));
#ifdef ZP
/* sp028.302 - addition - in FTHA or DFT/HA sccp, numConn is stored in zpCb.
 * Fill numConn from zpCb. In case of conventional sccp, this counter within 
 * spCb.sts is incremented/decremented in respective function and so no need
 * to fill it here.
 */
#ifdef SPCO
#ifdef LSPV2_2
      rSts.t.sts.s.spGlbSts.numConn = zpCb.numLr;
#endif /* LSPV2_2 */
#endif /* SPCO */
#endif /* ZP */
      if (action == ZEROSTS)
      {
         cmZero ((U8 *)&spCb.sts, sizeof (spCb.sts));
      }
   }
   else if (sts->hdr.elmId.elmnt == STNSAP)
   {
      SpNSapCb *nSap;      /* Network Sap */
      
      nSap = *(spCb.nSapList + (PTR) sts->hdr.elmId.elmntInst1);

#if (ERRCLASS & ERRCLS_INT_PAR)
      if (nSap == NULLP)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP013, (ErrVal) ERRZERO,
                    "NSap does not exists");
         spSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_SAP);
         RETVALUE(RFAILED);
      }
#endif /* ERRCLASS */

      cmCopy((U8 *) &nSap->sts, (U8 *) &rSts.t.sts.s.spNSapSts, 
             sizeof(SpNSAPSts));

      if (action == ZEROSTS)
      {
         cmZero ((U8 *)&nSap->sts, sizeof (nSap->sts));
      }
   }
   else if (sts->hdr.elmId.elmnt == STTSAP)
   {
      /* sts->hdr.elmId.elmntInst1 must hold suId */
      SpSapCb *sap;      /* Sap */
      
      sap = *(spCb.sapList + (PTR)sts->hdr.elmId.elmntInst1);
#if (ERRCLASS & ERRCLS_INT_PAR)
      if (sap == (SpSapCb*)NULLP)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP014, (ErrVal) ERRZERO,
                    "Sap does not exists");
         spSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_INVALID_SAP);
         RETVALUE(RFAILED);
      }
#endif /* ERRCLASS */

      cmCopy((U8 *) &sap->sts, (U8 *) &rSts.t.sts.s.spSapSts, 
             sizeof(SpSAPSts));

      if (action == ZEROSTS)
      {
         cmZero ((U8 *)&sap->sts, sizeof (sap->sts));
      }
   }
   else if (sts->hdr.elmId.elmnt == STROUT)
   {
      SpRteCb *rteCb;
      SpRteKey rKey;
      U8 l;

      /* check if route exists for which statistics required */
      rKey.k1.dpc = sts->t.sts.s.spRteSts.pc;
      rKey.k1.nwId = sts->t.sts.s.spRteSts.nwId;

      spFindRte(&spCb.rteCp, &rteCb, &rKey, (U16) 0);
      if (rteCb == (SpRteCb *) NULLP)
      {
         /* Inform Layer manager in case route doesn't exist */
         SPLOGERROR(ERRCLS_INT_PAR, ESP015, (ErrVal) rSts.t.sts.s.spRteSts.pc,
                    "Route does not exists");
         spSendLmCfm(pst, TSTS, &sts->hdr, LCM_PRIM_NOK,
                     LCM_REASON_INVALID_PAR_VAL);
         RETVALUE(RFAILED);
      }

      rSts.t.sts.s.spRteSts.nwId = sts->t.sts.s.spRteSts.nwId;
      rSts.t.sts.s.spRteSts.pc = sts->t.sts.s.spRteSts.pc;
      rSts.t.sts.s.spRteSts.numOfSsn = rteCb->nmbSsns;
      for (l = 0; l < rteCb->nmbSsns; l++)
      {
         rSts.t.sts.s.spRteSts.ssnSts[l].ssn = rteCb->ssnList[l].ssn;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssOGRx = rteCb->ssnList[l].ssOGRx;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssORDenied = 
                                               rteCb->ssnList[l].ssORDenied;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssAllRx = rteCb->ssnList[l].ssAllRx;
         /* sp047.302 - addition - addition statistics for SSP,SST and SSC
          * per route and ssn.
          */
#ifdef LSPV2_5
         rSts.t.sts.s.spRteSts.ssnSts[l].ssProhRx = rteCb->ssnList[l].ssProhRx;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssProhTx = rteCb->ssnList[l].ssProhTx;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssStatRx = rteCb->ssnList[l].ssStatRx;
         rSts.t.sts.s.spRteSts.ssnSts[l].ssStatTx = rteCb->ssnList[l].ssStatTx;
#endif /* LSPV2_5 */

         if (action == ZEROSTS)
         {
            rteCb->ssnList[l].ssOGRx = 0;
            rteCb->ssnList[l].ssORDenied = 0;
            rteCb->ssnList[l].ssAllRx = 0;
            /* sp047.302 - addition - addition statistics for SSP,SST and SSC
             * per route and ssn.
             */
#ifdef LSPV2_5
            rSts.t.sts.s.spRteSts.ssnSts[l].ssProhRx = 0;
            rSts.t.sts.s.spRteSts.ssnSts[l].ssProhTx = 0;
            rSts.t.sts.s.spRteSts.ssnSts[l].ssStatRx = 0;
            rSts.t.sts.s.spRteSts.ssnSts[l].ssStatTx = 0;
#endif /* LSPV2_5 */
         }
      } 
   }

   rSts.hdr.msgType = NOTUSED;
   rSts.hdr.msgLen = NOTUSED;
   rSts.hdr.seqNmb = NOTUSED;
   rSts.hdr.version = NOTUSED;
   rSts.hdr.elmId.elmnt = sts->hdr.elmId.elmnt;
   /* sp027.302 - modification - fill elmntInst1 */
   rSts.hdr.elmId.elmntInst1 = sts->hdr.elmId.elmntInst1;
   rSts.hdr.elmId.elmntInst2 = NOTUSED;
   rSts.hdr.elmId.elmntInst3 = NOTUSED;
   rSts.hdr.entId.ent = spCb.spInit.ent;
   rSts.hdr.entId.inst = spCb.spInit.inst;

#ifdef SP_LMINT3
   rSts.hdr.transId = sts->hdr.transId;
   cmCopy ((U8 *)&sts->hdr.response, (U8 *)&rSts.hdr.response, sizeof(Resp));
   rSts.cfm.status = LCM_PRIM_OK;
   spFillReplyPst(&rPst, &sts->hdr, pst);
   SpMiLspStsCfm(&rPst, action, &rSts);
#else
   SpMiLspStsCfm(&spCb.spInit.lmPst, action, &rSts);
#endif /* SP_LMINT3 */

   RETVALUE (ROK);

} /* SpMiLspStsReq */

  
/*
*
*       Fun:   Bind Request
*
*       Desc:  This function binds the SCCP upper layer service user
*              with the SCCP network layer service provider. The SCCP
*              network layer software will register this new service
*              user and will allocate a Service Access Point (SAP) for
*              this bind. The service user will specify the reference
*              number that will be used for the duration of this bind.
*              The Control Block for service provider is the Network
*              Layer SAP, while the Control Block for the
*              service user is dependent on the protocol.
*
*       Ret:   ROK   - ok
*
*       Notes: For successful bind case, issue a bind confirm in SPT2.
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
Ssn ssn                         /* subsystem number  */
)
#else
PUBLIC S16 SpUiSptBndReq(pst, suId, spId, ssn )
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
Ssn ssn;                        /* subsystem number  */
#endif
{
   SpSapCb *cb;
   TRC3(SpUiSptBndReq);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptBndReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif  

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf,
          "SpUiSptBndReq(pst, suId (%d), spId (%d), ssn (%d)\n", suId, spId,
          ssn));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP016, (ErrVal) 0, 
                 "SpUiSptBndReq() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */
  
   /* get Sap control block */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spId >= (S16)spCb.spCfg.nmbSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP017, (ErrVal) spId,
                 "SpUiSptBndReq() invalid spId");
      /* inform layer manager of invalid event */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
  
   /* this sap should already of been configured */
   if ((cb = *(spCb.sapList + spId)) == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP018, (ErrVal) spId,
                 "SpUiSptBndReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }

   if (!(cb->status & SP_BND))
   {
#ifdef SP_RUG
      /* find interface version from stored info */

      U16 i;
      Bool found;
      found = FALSE;
      if (cb->remIntfValid == FALSE)
      {
         for (i = 0; i < spCb.numIntfInfo && found == FALSE; i++)
         {
            if (spCb.spVerInfoCb[i].intfInfo.intf.intfId == SPTIF)
            {
               switch (spCb.spVerInfoCb[i].intfInfo.grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if ((spCb.spVerInfoCb[i].intfInfo.dstProcId == 
                                                      pst->srcProcId) &&
                        (spCb.spVerInfoCb[i].intfInfo.dstEnt.ent == 
                                                      pst->srcEnt) &&
                        (spCb.spVerInfoCb[i].intfInfo.dstEnt.inst == 
                                                      pst->srcInst))
                        found = TRUE;
                     break;
                  case SHT_GRPTYPE_ENT:
                     if ((spCb.spVerInfoCb[i].intfInfo.dstEnt.ent == 
                                                      pst->srcEnt) &&
                        (spCb.spVerInfoCb[i].intfInfo.dstEnt.inst == 
                                                      pst->srcInst))
                        found = TRUE;
                     break;
                  default:
                     break;
               } /* end switch(.grpType) */
            } /* end if(.intfId == SPTIF) */
         } /* end for(i = 0; ...) */
         if (found == TRUE)
         {
            /* initialize interface version number in pst */
            cb->pst.intfVer = spCb.spVerInfoCb[i - 1].intfInfo.intf.intfVer;
            /* mark the validity of remote interface version no as TRUE */
            cb->remIntfValid = TRUE;
         }
         else
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP019, (ErrVal) spId,
                       "SpUiSptBndReq() remIntfver not available");
            spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                        LCM_CAUSE_SWVER_NAVAIL, EVTSPTBNDREQ, 0);
            RETVALUE(RFAILED);
         }
      } /* end if (cb->remIntfValid == FALSE) */
#endif /* SP_RUG */

      cb->status ^= SP_BND;
/* sp038.302 - addition - support for multiple instances */
      if (cb->pst.route == RTE_PROTO)
         cb->pst.dstProcId = CMFTHA_RES_RSETID;
      else
         cb->pst.dstProcId = pst->srcProcId;
      cb->pst.dstEnt = pst->srcEnt;
      cb->pst.dstInst = pst->srcInst;
      cb->suId = suId;
      cb->ssn = ssn;
#ifdef ZP
      zpRunTimeUpd(ZP_SP_SAPCB, (Void *) cb, 
                   CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
   }
   else
   {
      if (cb->pst.dstProcId != pst->srcProcId ||
          cb->pst.dstEnt != pst->srcEnt ||
          cb->pst.dstInst != pst->srcInst ||
          cb->suId != suId)
      {
#ifdef SPT2
          (Void) SpUiSptBndCfm(&cb->pst, cb->suId, CM_BND_NOK);
#endif /* SPT2 */
          RETVALUE(RFAILED);
      }
   }

   /* Send a StaInd to SM as we are inservice now. */
   if (spCb.ustaMask & LSP_USTAALARM)
      spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_USER_INS, 
                  LCM_CAUSE_USER_INITIATED, (U8) cb->nwData->variant,
                  (U8) cb->spId); 
#ifdef SPT2
   SpUiSptBndCfm(&cb->pst, cb->suId, CM_BND_OK);
#endif /* SPT2 */

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   RETVALUE(ROK);
} /* SpUiSptBndReq */

  
/*
*
*       Fun:   Unbind Request
*
*       Desc:  This function unbinds the SCCP network layer service
*              user from the SCCP network layer service provider.
*              The Network Layer Service Access Point (SAP) is deallocated.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptUbndReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Reason reason                   /* reason */
)
#else
PUBLIC S16 SpUiSptUbndReq(pst, spId, reason)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Reason reason;                  /* reason */
#endif
{
   SpSapCb *sap;

   TRC3(SpUiSptUbndReq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptUbndReq() failed, cannot derive spCb");
      /* sp039.302 - addition - return fail */
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

#ifndef DEBUGP
   UNUSED(pst);
   UNUSED(reason);
#else
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptUbndReq(pst, spId (%d), reason (%d)\n", spId, reason));
#endif /* DEBUGP */
  
#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP020, (ErrVal) 0, 
                 "SpUiSptUbndReq() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTUBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spId >= (SpId)spCb.spCfg.nmbSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP021, (ErrVal) spId,
                 "SpUiSptUbndReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTUBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
  
   /* get upper sap */
   if ((sap = *(spCb.sapList + spId)) == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP022, (ErrVal) spId,
                 "SpUiSptUbndReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTUBNDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
  
   spDisableUpperSap(sap);
#ifdef ZP
   zpRunTimeUpd(ZP_SP_SAPCB, (Void *)sap, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_DEL);
   zpDelMapping (ZP_SP_SAPCB, (Void *)sap); 
#endif /* ZP */

   SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *)sap,
            (Size)sizeof(SpSapCb));

   /* clear the sap pointer */
   *(spCb.sapList + spId) = NULLP;

   spCb.nmbSaps--;

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

   RETVALUE(ROK);
} /* end of SpUiSptUbndReq */

  
/*
*
*      Fun:   Activate Task - initialize
*
*      Desc:  Invoked by system services to initialize a task.
*
*      Ret:   ROK   - ok
*
*      Notes: None
*
*      File:  cp_bdy1.c
*
*/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 spActvInit
(
ProcId proc,           /* Proc Id * */
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason,         /* reason */
Void **xxCb            /* protocol control block */ 
)
#else
PUBLIC S16 spActvInit(proc, entity, inst, region, reason, xxCb)
ProcId proc;           /* Proc Id */
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
Void **xxCb;           /* protocol control block */ 
#endif
#else 
#ifdef ANSI
PUBLIC S16 spActvInit
(
Ent entity,            /* entity */
Inst inst,             /* instance */
Region region,         /* region */
Reason reason          /* reason */
)
#else
PUBLIC S16 spActvInit(entity, inst, region, reason)
Ent entity;            /* entity */
Inst inst;             /* instance */
Region region;         /* region */
Reason reason;         /* reason */
#endif
#endif /* SS_MULTIPLE_PROCSS */
{
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   /* sp049.302 - deletion - spNumCallsToInit removed */
   PRIVATE U16 spFirstCall = FALSE; /* sp49.202 - addition - to monitor
                                     * the first call to ActvInit
                                     */
   U16 i = 0;
   U16 j = 0;  /* sp049.302 - addition - counter */
   Void *tmpPsfCb = NULLP;  /* sp050.302 - addition - ptr to save psf CB */
   Bool flag = FALSE;  /* sp050.302 - addition - flag */
#endif

	S32 retSp = 0;
	S32 retPrtl = 0;

   TRC3(spActvInit);

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   /* sp49.202 - addition - support for NRM_TERM of TAPA task
    * added. ActvInit is called during DeRegTTsk with reason NRM_TRM
    */
   if(reason == SHUTDOWN )
   {
      /* sp050.302 - addition - save the psfCb ptr before calling cmZero
       * and restore it after cmZero call.
       */
#if ZP
      tmpPsfCb = spCb.psfCb;
#endif
      cmZero ((U8 *)&spCb, sizeof(SpCb));
      spCb.used = TRUE;
      spCb.spInit.procId = proc;
#if ZP
      spCb.psfCb = tmpPsfCb;
#endif
   }
   else if(reason == NRM_TERM)
   {
      cmZero ((U8 *)*xxCb, sizeof(spCb));
      ((SpCb *)(*xxCb))->used = FALSE;
      RETVALUE(ROK);
   }
   else
   {
      if(!spFirstCall)
      {
         spFirstCall = TRUE;
	      for (j = 0; j < SP_MAX_INSTANCES; j++)
	         cmZero ((U8 *)&spCbLst[j], sizeof(SpCb));
      }
      else
      {
	      for(i = 0; i < SP_MAX_INSTANCES; i++)
         {
            if(spCbLst[i].used == FALSE)
            {
               spCbPtr = &spCbLst[i];
               /* sp050.302 - addition - if flag is TRUE then psfCb will
                * be overwritten with zpCbLst array index. This is required
                * because in case of SHUTDOWN we are preserving the psfCb
                * ptr and we dont allocate from zpCbLst.
                */
                flag = TRUE;
               break;
            }
         }
      }

      if(i == SP_MAX_INSTANCES)
	      RETVALUE(FALSE);

      spCbLst[i].used = TRUE;
      spCbPtr = &spCbLst[i];
      *xxCb = (Void *)&spCbLst[i];
   }
#endif
/* sp038.302 - addition - support for multiple instances */
#ifndef SS_MULTIPLE_PROCS 
   cmZero ((U8 *)&spCb, sizeof (SpCb));
#endif

/* sp038.302 - addition - support for multiple instances */
#ifndef SS_MULTIPLE_PROCS 
   spCb.spInit.procId = SFndProcId();
#else
   spCb.spInit.procId = proc;
#endif
   spCb.spInit.ent = entity;
   spCb.spInit.inst = inst;
   spCb.spInit.region = region;
   spCb.spInit.reason = reason;
   spCb.spInit.cfgDone = FALSE;
   spCb.spInit.pool = 0;
   spCb.spInit.acnt = FALSE;
   spCb.spInit.trc = FALSE;  /* unused */
   
#ifdef DEBUGP
#ifdef SP_DEBUG
   spCb.spInit.dbgMask = g_spDbgMask;/*modified by wanglijun for set dbgmask from shell*/
#endif /* SP_DEBUG */   
#endif /* DEBUGP */

#ifdef SP_USTA
    spCb.ustaMask |= LSP_USTAALARM;  /* enable unsolicit alarm */
#endif
#ifdef ZP
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS    
    /* sp050.302 - addition - update psfCb only if flag is TRUE, in case
     * of SHUTDOWN flag will FALSE.
     */
    if (flag == TRUE)
       spCb.psfCb = (Void *)&(zpCbLst[i]);
#endif    
    spCb.conUpdFlg = FALSE;
    zpActvInit(entity, inst, region, reason);
#endif /* ZP */

   /* assign default message importance, in case message importance
    * date are configured, these values will be overwritten
    */
   spCb.spMsgImp.defUdtImp = DEFUDTIMP;
   spCb.spMsgImp.defUdtSrvImp = DEFUDTSIMP;
   spCb.spMsgImp.defXudtImp = DEFXUDTIMP;
   spCb.spMsgImp.defXudtSrvImp = DEFXUDTSIMP;
   spCb.spMsgImp.defLudtImp = DEFLUDTIMP;
   spCb.spMsgImp.defLudtSrvImp = DEFLUDTSIMP;
   spCb.spMsgImp.defCrImp = DEFCRIMP;
   spCb.spMsgImp.defCcImp = DEFCCIMP;
   spCb.spMsgImp.defCrefImp = DEFCREFIMP;
   spCb.spMsgImp.defDt1Imp = DEFDT1IMP;
   spCb.spMsgImp.defDt2Imp = DEFDT2IMP;
   spCb.spMsgImp.defAkImp = DEFAKIMP;
   spCb.spMsgImp.defItImp = DEFITIMP;
   spCb.spMsgImp.defEdImp = DEFEDIMP;
   spCb.spMsgImp.defEaImp = DEFEAIMP;
   spCb.spMsgImp.defRsrImp = DEFRSRIMP;
   spCb.spMsgImp.defRscImp = DEFRSCIMP;
   spCb.spMsgImp.defErrImp = DEFERRIMP;
   spCb.spMsgImp.defRlsdImp = DEFRLSDIMP;
   spCb.spMsgImp.defRlcImp = DEFRLCIMP;

#ifdef SSI_WITH_CLI_ENABLED
	retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl", "Э��ģʽ", "�޲���" );
	retSp = XOS_RegistCmdPrompt(retPrtl, "sccp", "SCCP Э��", "�޲���" );

	XOS_RegistCommand(retSp, spSetDbgMask, "setdbgmask", "SCCP set debug mask", 
"one parameter:dbgmask(Bitmask specification)\n\
SI:  0x01 system service interface\n\
MI:  0x02 layer management interface\n\
UI:  0x04 upper interface\n\
LI:  0x08 lower interface\n\
PI:  0x10 peer interface\n\
LYR: 0x100 layer specific interface\n\
DATA:0X200 data msg stream " );
	XOS_RegistCommand(retSp, spGetDbgMask, "showdbgmask", "SCCP show debug mask", "no parameter" );

	XOS_RegistCommand(retSp, spPrintSpCb, "showspcb", "SCCP print the sccp control block", "no parameter" );
	XOS_RegistCommand(retSp, spPrintGenCfg, "showgencfg", "SCCP print the general config", "no parameter" );
	XOS_RegistCommand(retSp, spPrintNwCb, "shownwcb", "SCCP print the network control block", 
    "one parameter:nwid or all\n\
nwid:1~nmbnwcb\n\
all:print all network control block" );
	XOS_RegistCommand(retSp, spPrintSapCb, "showsapcb", "SCCP print the sap control block", 
	"one parameter:spid or all\n\
spid:1~nmbsapcb\n\
all:print all sap control block" );
	XOS_RegistCommand(retSp, spPrintNSapCb, "shownsapcb", "SCCP print the nsap control block", 
	"one parameter:suid or all\n\
suid:1~nmbnsapcb\n\
all:print all nsap control block" );
	XOS_RegistCommand(retSp, spPrintGtAssoCb, "showgtrule", "SCCP print the gt rule information", 
	"one parameter:ruleid or all\n\
ruleid:1~nmbrule\n\
all:print all gt rule information" );
	XOS_RegistCommand(retSp, spPrintGtAddrMapCb, "showgtaddr", "SCCP print all gt address information", 
	"one parameter:all\n\
all:print all gt address information");
	XOS_RegistCommand(retSp, spPrintRteCb, "showroute", "SCCP print all route information", 
	"one parameter:all\n\
all:print all route information" );
	XOS_RegistCommand(retSp, spPrintGLBSts, "showglbsts", "SCCP print all global statistic information", "no parameter");
#ifdef CP_OAM_SUPPORT  
	XOS_RegistCommand(retSp, spAddGtRule, "addgtrule", "SCCP add gt rule test", "no parameter");
	XOS_RegistCommand(retSp, spDelGtRule, "delgtrule", "SCCP delete gt rule test", "no parameter");
	XOS_RegistCommand(retSp, spModGtRule, "modgtrule", "SCCP modify gt rule test", "no parameter");

	XOS_RegistCommand(retSp, spAddGtAddr, "addgtaddr", "SCCP add gt address test", "no parameter");
	XOS_RegistCommand(retSp, spDelGtAddr, "delgtaddr", "SCCP delete gt address test", "no parameter");
	XOS_RegistCommand(retSp, spModGtAddr, "modgtaddr", "SCCP modify gt address test", "no parameter");

	XOS_RegistCommand(retSp, spAddRoute, "addroute", "SCCP add route test", "no parameter");
	XOS_RegistCommand(retSp, spDelRoute, "delroute", "SCCP delete route test", "no parameter");
	XOS_RegistCommand(retSp, spModRoute, "modroute", "SCCP modify route test", "no parameter");
  
	XOS_RegistCommand(retSp, spAddRouteSsn, "addroutessn", "SCCP add route ssn test", "no parameter");
	XOS_RegistCommand(retSp, spDelRouteSsn, "delroutessn", "SCCP delete route ssn test", "no parameter");
	XOS_RegistCommand(retSp, spModRouteSsn, "modroutessn", "SCCP modify route ssn test", "no parameter");
#endif /* CP_OAM_SUPPORT */
#endif

   RETVALUE(ROK);
} /* end of spActvInit */

  
/*
*
*       Fun:   SpUiSptUDatReq
*
*       Desc:  Unit data request from upper user.
*
*       Ret:   ROK, RFAILED.
*
*       Notes: None.
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider sap id */
SpUDatEvnt *uData,              /* Unit Data Event */
Buffer *mBuf                    /* data buffer */
)
#else
PUBLIC S16 SpUiSptUDatReq(pst, spId, uData, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider sap id */
SpUDatEvnt *uData;              /* Unit Data Event */
Buffer *mBuf;                   /* data buffer */
#endif
{
   SpUdCb ucb;                  /* unit data control block */
   MsgLen mlen;                 /* sp047.302 - addition - message length */

   TRC3(SpUiSptUDatReq)

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Entered SpUiSptUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptUDatReq() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }        

   /*BEGIN:add by wanglijun.*/
   SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
            "********SCCP receive upper layer unitdata msg,spId(%d)*******\n",
            spId));
   SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
            "calling addr: opc(0x%x),ssn(%d),rtgInd(%d),gtaddr(-%32s)\n",
            uData->cgAddr.pc,uData->cgAddr.ssn,uData->cgAddr.rtgInd,uData->cgAddr.gt.addr.strg));
   SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
            "called addr: dpc(0x%x),ssn(%d),rtgInd(%d),gtaddr(-%32s)\n",
            uData->cdAddr.pc,uData->cdAddr.ssn,uData->cdAddr.rtgInd,uData->cdAddr.gt.addr.strg));
   /*END:add by wanglijun*/

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif 
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptUDatReq(pst, spId (%d)\n", spId));

   /* sp047.302 - Addition - Check for minimum data length, as per the spec
    * the minimum data length for UDT or XUDT is 2 and LUDT is 3 octets.
    */
   /* sp048.302 - Addition - Check for return value for SFndLenMsg() */
   if ((SFndLenMsg(mBuf, &mlen)) != ROK)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "SpUiSptUDatReq() failed, cannot derive message Length");
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
   if (mlen < 1)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "SpUiSptUDatReq() invalid Data Length, should be atleast 2 \
                 for narrowband and 3 for broadband");
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spid range */
   if ((spId >= (SpId)spCb.spCfg.nmbSaps) || (spId < 0))
   {
      /* invalid sap id. This should never happen.
       * drop message, return failure
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP023, (ErrVal) spId,
                 "SpUiSptUDatReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTUDATREQ, (U8) spId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* find upper sap */
   ucb.sap = *(spCb.sapList + (PTR) spId);  

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ucb.sap == (SpSapCb *) NULLP)
   {
      /* sap not found. This should never happen
       * drop message, return failure
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP024, (ErrVal) spId,
                 "SpUiSptUDatReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SAP, EVTSPTUDATREQ, (U8) spId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* initialize unit data control block fields */
   ucb.nSap = NULLP;                    /* lower sap initialized to null */
   ucb.rCb = NULLP;                     /* route cb initialized to null */
   ucb.nwData = ucb.sap->nwData;        /* network control block */
   /* sp045.302 - addition - initialise out network CB */
   ucb.outNwData = ucb.sap->nwData;        /* network control block */
   ucb.opc = ucb.sap->nwData->selfPc;   /* originating point code */
   ucb.ud = uData;                      /* unit data event struct */
   
   /* if interface version is SPTV2, assign importance in ucb from 
    * unitdata event struct else mark presence of importance in ucb
    * as not present
    */
#ifdef SPTV2
   /* assign importance in ucb from unit data event struct */
   ucb.imp.pres = uData->imp.pres;
   ucb.imp.val = uData->imp.val;
#else
   ucb.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* validate input */
   if (spValidateEvnt(&ucb) != SP_OK)
   {
      ucb.dpc = ucb.sap->nwData->selfPc;
      spHndlStatInd(&ucb, RTC_NTBADADDR, mBuf);
      RETVALUE (ROK);
   }

   /* sp047.302 - Addition - If message Interception is enabled retain
    * the original addresses.
    */
   if (ucb.sap->msgInterceptEnabled == TRUE)
   {
      cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr);
      cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr);
   }

#ifdef CMSS7_SPHDROPT
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if the flag is uninitialised in cgAddr */
   if ((ucb.ud->cgAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ucb.ud->cgAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP025, (ErrVal) ucb.ud->cgAddr.spHdrOpt,
                 "cgAddr spHdrOpt uninitialized");
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field is uninitialized */
   }

   /* Check if the flag is uninitialised in cdAddr */
   if ((ucb.ud->cdAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ucb.ud->cdAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP026, (ErrVal) ucb.ud->cdAddr.spHdrOpt,
                 "cdAddr spHdrOpt uninitialized");
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field is uninitialized */
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
#endif /* CMSS7_SPHDROPT */

   if (ucb.ud->cgAddr.pres != TRUE)
   {
#ifdef CMSS7_SPHDROPT
      /* sp024.302 - addition - initialize spHdrOpt. We are constructing
       * cgAddr and so in this case we always want to include PC in cgAddr
       * unless the flag SP_PRESERVE_ADDR is defined. If the flag is defined
       * then we will not include pc and the next node will have to construct
       * cgPc from opc of MTP routing label. If flag is not defined then we
       * will include the pc.
       */
#ifdef SP_PRESERVE_ADDR
      ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#else  /* SP_PRESERVE_ADDR */
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

      ucb.ud->cgAddr.pres = TRUE;
      ucb.ud->cgAddr.ssnInd = TRUE;
      ucb.ud->cgAddr.ssn = ucb.sap->ssn;
      ucb.ud->cgAddr.pcInd = TRUE;
      ucb.ud->cgAddr.pc = ucb.sap->nwData->selfPc;

      /* sp024.302 - addition - initialize remaining fields of cgAddr
       * from the appropriate values of cdAddr
       */
      ucb.ud->cgAddr.sw = ucb.ud->cdAddr.sw;
      ucb.ud->cgAddr.ssfPres = ucb.ud->cdAddr.ssfPres;
      ucb.ud->cgAddr.ssf = ucb.ud->cdAddr.ssf;
      ucb.ud->cgAddr.niInd = ucb.ud->cdAddr.niInd;
      ucb.ud->cgAddr.rtgInd = RTE_SSN;
      ucb.ud->cgAddr.gt.format = GTFRMT_0;
   }
   else
   {
      /* Fill in the cgAddr only if necessary */
      if (ucb.ud->cgAddr.rtgInd != RTE_GT)
      {
         if (!ucb.ud->cgAddr.ssnInd)
         {
            ucb.ud->cgAddr.ssnInd = TRUE;
            ucb.ud->cgAddr.ssn = ucb.sap->ssn;
         }
         ucb.ud->cgAddr.rtgInd = RTE_SSN;
      }

      /* Fill pc in cgAddr. The encoding of pc in cgAddr depends on the
       * value of spHdrOpt provided. If spHdrOpt indicates CMSS7_NO_SP_PC
       * then pc will not be encoded in cgAddr of outgoing msg. Otherwise
       * pc will be encoded in cgAddr.
       */
      if (ucb.ud->cgAddr.pcInd != TRUE)
      {
         ucb.ud->cgAddr.pcInd = TRUE;
         ucb.ud->cgAddr.pc = ucb.sap->nwData->selfPc;
      }
   }

   /* Handle unit data request */
   spUiHndlUDatReq(&ucb, mBuf);

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

#ifdef MEM_STS
   /* xingzhou.xu: added for memory debug print --07/12/2006 */
   printf("Leaving SpUiSptUDatReq, memory usage is:");
   SRegInfoShow(0);
   /**********************************************************/
#endif
   RETVALUE(ROK);
} /* SpUiSptUDatReq */

/* sp047.302 - Addition - Unit Data Service request from Service User */
#ifdef SPTV2_1
  
/*
*
*       Fun:   SpUiSptUDatSrvReq
*
*       Desc:  Unit data Service request from upper user.
*
*       Ret:   ROK, RFAILED.
*
*       Notes: None.
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptUDatSrvReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider sap id */
SpUDatEvnt *uData,              /* Unit Data Event */
Buffer *mBuf                    /* data buffer */
)
#else
PUBLIC S16 SpUiSptUDatSrvReq(pst, spId, uData, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider sap id */
SpUDatEvnt *uData;              /* Unit Data Event */
Buffer *mBuf;                   /* data buffer */
#endif
{
   SpUdCb ucb;                 /* unit data control block */
   MsgLen mlen;                /* sp047.302 - addition - message length */

   TRC3(SpUiSptUDatSrvReq)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptUDatSrvReq() failed, cannot derive spCb");
      /* sp048.302 - Addition - free buffer */
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif 
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptUDatSrvReq(pst, spId (%d)\n", spId));

   /* sp048.302 - Addition - Check for return value for SFndLenMsg() */
   if ((SFndLenMsg(mBuf, &mlen)) != ROK)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "SpUiSptUDatSrvReq() failed, cannot derive message Length");
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
   if (mlen < 1)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "SpUiSptUDatReq() invalid Data Length, should be atleast 2 \
                 for narrowband and 3 for broadband");
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spid range */
   if ((spId >= (SpId)spCb.spCfg.nmbSaps) || (spId < 0))
   {
      /* invalid sap id. This should never happen.
       * drop message, return failure
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP023, (ErrVal) spId,
                 "SpUiSptUDatSrvReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTUDATSRVREQ, (U8) spId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* find upper sap */
   ucb.sap = *(spCb.sapList + (PTR) spId);  

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ucb.sap == (SpSapCb *) NULLP)
   {
      /* sap not found. This should never happen
       * drop message, return failure
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP024, (ErrVal) spId,
                 "SpUiSptUDatSrvReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SAP, EVTSPTUDATSRVREQ, (U8) spId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* initialize unit data control block fields */
   ucb.nSap = NULLP;                    /* lower sap initialized to null */
   ucb.rCb = NULLP;                     /* route cb initialized to null */
   ucb.nwData = ucb.sap->nwData;        /* network control block */
   ucb.outNwData = ucb.sap->nwData;        /* network control block */
   ucb.opc = ucb.sap->nwData->selfPc;   /* originating point code */
   ucb.ud = uData;                      /* unit data event struct */
   
   /* if interface version is SPTV2, assign importance in ucb from 
    * unitdata event struct else mark presence of importance in ucb
    * as not present
    */
#ifdef SPTV2
   /* assign importance in ucb from unit data event struct */
   ucb.imp.pres = uData->imp.pres;
   ucb.imp.val = uData->imp.val;
#else
   ucb.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* validate input */
   if (spValidateEvnt(&ucb) != SP_OK)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "SpUiSptUDatSrvReq: spValidateEvnt() failed");
      /* sp048.302 - Addition - In case of validate fail release memory */
      spDropMsg(&mBuf);
      RETVALUE (ROK);
   }

   if (ucb.sap->msgInterceptEnabled == TRUE)
   {
      cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr);
      cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr);
   }

#ifdef CMSS7_SPHDROPT
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Check if the flag is uninitialised in cgAddr */
   if ((ucb.ud->cgAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ucb.ud->cgAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP025, (ErrVal) ucb.ud->cgAddr.spHdrOpt,
                 "cgAddr spHdrOpt uninitialized");
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field is uninitialized */
   }

   /* Check if the flag is uninitialised in cdAddr */
   if ((ucb.ud->cdAddr.spHdrOpt != CMSS7_NO_SP_PC) &&
       (ucb.ud->cdAddr.spHdrOpt != CMSS7_DEF_OPT))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP026, (ErrVal) ucb.ud->cdAddr.spHdrOpt,
                 "cdAddr spHdrOpt uninitialized");
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT; /* Field is uninitialized */
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
#endif /* CMSS7_SPHDROPT */

   if (ucb.ud->cgAddr.pres != TRUE)
   {
#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
      ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#else  /* SP_PRESERVE_ADDR */
      ucb.ud->cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

      ucb.ud->cgAddr.pres = TRUE;
      ucb.ud->cgAddr.ssnInd = TRUE;
      ucb.ud->cgAddr.ssn = ucb.sap->ssn;
      ucb.ud->cgAddr.pcInd = TRUE;
      ucb.ud->cgAddr.pc = ucb.sap->nwData->selfPc;
      ucb.ud->cgAddr.sw = ucb.ud->cdAddr.sw;
      ucb.ud->cgAddr.ssfPres = ucb.ud->cdAddr.ssfPres;
      ucb.ud->cgAddr.ssf = ucb.ud->cdAddr.ssf;
      ucb.ud->cgAddr.niInd = ucb.ud->cdAddr.niInd;
      ucb.ud->cgAddr.rtgInd = RTE_SSN;
      ucb.ud->cgAddr.gt.format = GTFRMT_0;
   }
   else
   {
      /* Fill in the cgAddr only if necessary */
      if (ucb.ud->cgAddr.rtgInd != RTE_GT)
      {
         if (!ucb.ud->cgAddr.ssnInd)
         {
            ucb.ud->cgAddr.ssnInd = TRUE;
            ucb.ud->cgAddr.ssn = ucb.sap->ssn;
         }
         ucb.ud->cgAddr.rtgInd = RTE_SSN;
      }

      /* Fill pc in cgAddr. The encoding of pc in cgAddr depends on the
       * value of spHdrOpt provided. If spHdrOpt indicates CMSS7_NO_SP_PC
       * then pc will not be encoded in cgAddr of outgoing msg. Otherwise
       * pc will be encoded in cgAddr.
       */
      if (ucb.ud->cgAddr.pcInd != TRUE)
      {
         ucb.ud->cgAddr.pcInd = TRUE;
         ucb.ud->cgAddr.pc = ucb.sap->nwData->selfPc;
      }
   }

   /* Handle unit data Service request */
   spUiHndlUDatSrvReq(&ucb, mBuf);

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

   RETVALUE(ROK);
} /* SpUiSptUDatSrvReq */
#endif /* SPTV2_1 */

  
/*
 *
 *       Fun:   SpLiSntUDatInd
 *
 *       Desc:  Data Indication from the lower layer.
 *
 *       Ret:   ROK   - ok
 *
 *       Notes : The link selector in this function is used in the ucb 
 *               for Class 0 and 1 messages. For class 0 messages if the
 *               messages are sent out after GTT we will overwrite the sls.
 *               For Class 1 messages if we are sending the message out 
 *               after GTT; in the new implementation we will retain the sls 
 *               while in hte old one we will overwrite the sls.
 *
 *       File:  cp_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpLiSntUDatInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Sevice user id */
Dpc opc,                        /* Originating point code*/
Dpc dpc,                        /* Destination point code */
SrvInfo srvInfo,                /* service information */
LnkSel lnkSel,                  /* link selector */
Buffer *mBuf                    /* data */
)
#else
PUBLIC S16 SpLiSntUDatInd(pst, suId, opc, dpc, srvInfo, lnkSel, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Sevice user id */
Dpc opc;                        /* Origination point code */
Dpc dpc;                        /* Destination point code */
SrvInfo srvInfo;                /* service information */
LnkSel lnkSel;                  /* link selector */ 
Buffer *mBuf;                   /* data */
#endif
{
   S16 ret;                     /* return flag */
   SpNSapCb* nSap;              /* network sap */
   Buffer *data;                /* data buffer */
#ifdef SPCO
   SpConCb* cb;                 /* connection control block */
   U32 lclRef;                  /* local reference */
#endif

   TRC3(SpLiSntUDatInd)

   UNUSED(pst);
#ifndef DEBUGP
   UNUSED(dpc);
#endif /* DEBUGP */
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpLiSntUDatInd() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   /*BEGIN:add by wanglijun.*/
   SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
            "********SCCP receive lower layer unitdata msg, suId(%d), opc(%ld), dpc(%ld)*******\n",
            suId, opc, dpc));
   /*END:add by wanglijun*/

   SPDBGP(DBGMASK_LI, (spCb.spInit.prntBuf, 
          "SpLiSntUDatInd(pst, suId (%d), opc (%ld), dpc (%ld), srvinfo (%d), lnksel (%d)\n", suId, opc, dpc, srvInfo, lnkSel));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate suId */
   if ((suId >= (SuId)spCb.spCfg.nmbNSaps) || (suId < 0))
   {
      /*
       * This should never happen
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP027, (ErrVal) suId,
                 "SpLiSptUDatInd() invalid suId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_INV_SUID, EVTSPTUDATIND, (U8)suId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* sp003.302 - added a nSap control block pointer as a parameter to
    * spFindLowerSapSid so we can check the different situation of nSap
    * via returned value 
    */
   ret = spFindLowerSapSid(suId, &nSap);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ret == RFAILED)
   {
      /* sp003.302 - NSap not configured, this should never happen,
       * drop message, raise alarm
       */
      SPLOGERROR(ERRCLS_INT_PAR, ESP028, (ErrVal) suId,
                 "SpLiSptUDatInd() nsap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_INV_SUID, EVTSPTUDATIND, (U8) suId);
      spDropMsg(&mBuf);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* sp003.302 - if lower sap is configured but not bound then return ok
    * instead of return failure
    */
   if (ret == ROKDNA)
   {
      spDropMsg(&mBuf);
      RETVALUE(ROK);
   }
   /* capture a trace before decoding */
   SP_GEN_TRC((SuId) suId, (U16) SP_MSG_RECVD, mBuf);

   /* before decoding message perform sccp congestion control procedure */
   if (nSap->nwData->variant == LSP_SW_ITU)
   {
      if (spCb.congLvl > 0)
      {
         /* increment number of messages received and if number of 
          * message received exceeds the sscThresh then send SSC to
          * the node from which message is received
          */
         spCb.nmbMsgRx++;
         if (spCb.nmbMsgRx >= spCb.sscThresh)
         {
            SpMngtCb mcb;

            mcb.frmt = SCMG_SSC;
            mcb.dpc = opc;
            mcb.apc = nSap->nwData->selfPc;

            /* sp022.302 - addition - fill affected ssn as SCMG(SCCP itself) */
            mcb.assn = SS_SCCPMNGT;
            mcb.nwData = nSap->nwData;
            mcb.cLvl = spCb.congLvl;
            spSendMngtMsg(&mcb);
         }
      } /* if (...congLvl > 0) */
   } /* if (...variant == LSP_SW_ITU) */

   SPDECPDUHDR(&nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, nSap->nwData->variant,
               (U32) MF_SCCP);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ret != MFROK)
   {
      /* discard unknown message types */
      SPLOGERROR(ERRCLS_INT_PAR, ESP029, (ErrVal) ret,
                 "SpLiSntUDatInd() SPDECPDUHDR failed");

      /* increment statistics counter for syntax error */
      spCb.sts.synError++;

      /* send alarm to LM */
      spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_SYN_ERROR,
                  LCM_CAUSE_INV_NETWORK_MSG, (U8) (nSap->nwData->variant),
                  (U8) (nSap->suId));

      spDropMsg(&mBuf);
      RETVALUE(ROK);
   }
#endif /* ERRCLASS */

   SPDECPDU(&nSap->mfMsgCtl, ret, (ElmtHdr *) &spCb.pdu);
   if (ret != MFROK)
   {
      /* Decode will only fail if some attribute of the mandatory elements are
       * bogus. Since they are mandatory, this is somewhat problematic, we 
       * take appropriate action here.
       */

      /* increment statistics counter for syntax error */
      spCb.sts.synError++;
      spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_SYN_ERROR, 
                  LCM_CAUSE_INV_NETWORK_MSG, (U8)(nSap->nwData->variant), 
                  (U8) (nSap->suId));
#ifdef SPCO
      spHandleBadDecode(nSap, opc);
#else
      spDropMsg(&mBuf);
      spDropMsg(&nSap->mfMsgCtl.sccpInfo.data);
#endif
      RETVALUE(ROK);
   }

   /* message buffer not needed anymore */
   SPutMsg(mBuf);
   data = nSap->mfMsgCtl.sccpInfo.data;   
   nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;

   switch (spCb.pduHdr.msgType.val)
   {
#ifdef SPCO
      case M_CONREQ:
      {
         /* update statistics for CR received from network */
         spCb.sts.crRx++;

         if (spCb.status & SP_GUARD)
         {
            if (data != (Buffer *) NULLP)
               spDropMsg(&data);
            RETVALUE(ROK);
         }
         (Void) spLiHndlCr(nSap, srvInfo, opc, data, lnkSel);
         break;
      }

      case M_CONCFM:
      {
         if (spCb.status & SP_GUARD)
         {
            if (data != (Buffer*) NULLP)
               spDropMsg(&data);
            RETVALUE(ROK);
         }

         lclRef = nSap->mfMsgCtl.sccpInfo.dstLclRef;
         if (!(cb = spLookUpConCbAndSetSide(nSap->nwData, lclRef)))
         {
            spHandleBadDLR(nSap, opc, (U8) ((srvInfo & 0xC0) >> 6), data);
            RETVALUE(RFAILED);
         }

         cb->cs[SIDE(cb)].nSap = nSap;
         /*
          * if originating point code is different than the 
          * previously stored called point codes, and
          * this is a request type 0 connection, replace
          * old point code with new one in connection hash list
          */
         if (cb->cType & SP_REQ0)
         {
            if (opc != cb->cs[SIDE(cb)].pc) 
            {
               /* sp026.302 - removal - remove function call spDelCon and
                * spAddCon. These functions were to maintain conn hash list
                * based on CG_KEY, CD_KEY and SU_KEY and are no longer used.
                */
               /* assign originating point code for called side */
               cb->cs[SIDE(cb)].pc = opc;
            }
         }
         else
         {
            cb->cs[SIDE(cb)].conId.suId = nSap->suId;
            cb->cs[SIDE(cb)].pc = opc;

            /* sp026.302 - removal - remove function call spAddCon. This
             * function was to maintain conn hash list based on CG_KEY,
             * CD_KEY and SU_KEY and is no longer used.
             */
         }
         
         /* get message importance, relevant statistics will also be
          * incremented within this fundtion
          */
         spLiGetCoMsgImp(cb, spCb.pduHdr.msgType.val, &spCb.pdu, nSap, srvInfo);

         cb->info = (PTR) &spCb.pdu;
         spLiConMt[spCb.pduHdr.msgType.val-1][cb->side][cb->state](cb, data);
         break;
      } /* case M_CONCFM */
#endif /* SPCO */

      case M_UNITDATA:
      {
         SpUdCb ucb;
         SpUDatEvnt ud;

         /* Set Up UnitData Event Structure */
         ucb.nSap = nSap;
         ucb.nwData = nSap->nwData;
         /* sp045.302 - addition - initialise the out network */
         ucb.outNwData = nSap->nwData;
         ucb.sap = (SpSapCb *) NULLP;
         ucb.rCb = (SpRteCb *) NULLP;
         ucb.opc = opc;
         ucb.dpc = (Dpc) 0;
         ucb.sls = lnkSel;    /* Incoming sls */
         ucb.ud = &ud;
         ucb.ud->prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);
         ucb.ud->qos.pClass = spCb.pdu.m.uData.pClass.pClass.val;
         ucb.ud->qos.retOpt = spCb.pdu.m.uData.pClass.retOpt.val;


         ucb.dataType = M_UNITDATA;  
         ucb.hopCntr = 0;

         /* UDT does not carry importance, mark it as not present
          * in unit data event struct
          */
         ucb.imp.pres = NOTPRSNT;

         spTknStrToSpAddr(&spCb.pdu.m.uData.cdAddr.spAddr, &ucb.ud->cdAddr,
                          ucb.nwData->variant, (U8)((srvInfo & 0xC0) >> 6));
         spTknStrToSpAddr(&spCb.pdu.m.uData.cgAddr.spAddr, &ucb.ud->cgAddr,
                          ucb.nwData->variant, (U8) ((srvInfo & 0xC0) >> 6));

#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
         /* 
          * This is the _only_ criteria for adding or removing pc from network
          * messages.
          */
         if (ucb.ud->cdAddr.pcInd == FALSE)
            ucb.ud->cdAddr.spHdrOpt = CMSS7_NO_SP_PC;
         if (ucb.ud->cgAddr.pcInd == FALSE)
            ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

         /* sp047.302 - Addition - Retain a copy of called and calling address
          * so that they can be restored if message interception is enabled.
          */
         cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr); 
         cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr); 

         /* sp024.302 - modification - calling party address treatment is 
          * done after determining the spHdrOpt
          */
         /* section 2.1 T1.112.4 and ITU '96 states
            that we fill in the pc in the calling address in 
            N-UNITDATAind from MTP3 opc if the routing
            is on DPC/SSN and no dpc was present. */
         if ((ucb.ud->cgAddr.rtgInd == RTE_SSN) &&
             (ucb.ud->cgAddr.pcInd == FALSE))
         {
            ucb.ud->cgAddr.pcInd = TRUE;
            ucb.ud->cgAddr.pc = ucb.opc;
         }

         /* increment statistics cntr for no. of Unit Data received */
         spCb.sts.uDataRx++;

         /* handle message class wise */
         switch (ucb.ud->qos.pClass)
         {
            case PCLASS0:
            {
               /* increment statistics cntr for class 0 msgs received */
               spCb.sts.msgRxC0++;
               if ((ucb.ud->cdAddr.ssn == SS_SCCPMNGT) && 
                   (ucb.ud->cgAddr.ssn == SS_SCCPMNGT))
                  spLiHndlMngt(&ucb, data);
               else
                  spLiHndlClss0(&ucb, data);
               break;
            }

            case PCLASS1:
            {
               /* increment statistics cntr for class 1 msgs received */
               spCb.sts.msgRxC1++;
               spLiHndlClss1(&ucb, data);
               break;
            }

            default:
            {
               /* invalid class; increment statistics counter for
                * syntax error, send alarm and drop message.
                */
               spCb.sts.synError++;
               SPLOGERROR(ERRCLS_INT_PAR, ESP030, (ErrVal) ucb.ud->qos.pClass,
                          "SpLiSntUDatInd() invalid class");
               spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_SYN_ERROR,
                           LSP_CAUSE_SYNTAX_ERROR, spCb.pduHdr.msgType.val,
                           ucb.ud->qos.pClass);
               spDropMsg(&data);
               break;
            }
         } /* switch (...pClass) */
         break;
      }  /* case M_UNITDATA */

      case M_UNITDATASRV:
      {
         SpUdCb ucb;
         SpUDatEvnt ud;

         ucb.nSap = nSap;
         ucb.nwData = nSap->nwData;
         /* sp045.302 - addition - initialise the out network */
         ucb.outNwData = nSap->nwData;
         ucb.sap = (SpSapCb *) NULLP;
         ucb.rCb = (SpRteCb *) NULLP;
         ucb.opc = opc;
         ucb.dpc = (Dpc) 0;
         ucb.sls = lnkSel;    /* Incoming sls */
         ucb.ud = &ud;
         ucb.ud->prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);
         ucb.ud->qos.pClass = PCLASS0;

         /* Use the retOpt for the return cause */
         ucb.ud->qos.retOpt = spCb.pdu.m.uDataSrv.retCause.retCause.val;



         ucb.dataType = M_UNITDATASRV; 
         ucb.hopCntr = 0;

         /* UDTS does not carry importance, mark it as not present
          * in unit data event struct
          */
         ucb.imp.pres = NOTPRSNT;

         spTknStrToSpAddr(&spCb.pdu.m.uDataSrv.cdAddr.spAddr, &ucb.ud->cdAddr,
                          ucb.nwData->variant, (U8) ((srvInfo & 0xC0) >> 6));
         spTknStrToSpAddr(&spCb.pdu.m.uDataSrv.cgAddr.spAddr, &ucb.ud->cgAddr,
                          ucb.nwData->variant, (U8) ((srvInfo & 0xC0) >> 6));

#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
         /* This is the criteria for adding or removing pc from 
          * network messages. 
          */
         if (ucb.ud->cdAddr.pcInd == FALSE)
            ucb.ud->cdAddr.spHdrOpt = CMSS7_NO_SP_PC;
         if (ucb.ud->cgAddr.pcInd == FALSE)
            ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

         /* sp047.302 - Addition - Retain a copy of called and calling address
          * so that they can be restored if message interception is enabled.
          */
         cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr); 
         cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr); 

         /* increment statistics cntr for UDTS received */
         spCb.sts.uDataSrvRx++;
         spLiHndlUDatSrv(&ucb, data);
         break;
      } /* case M_UNITDATASRV */

      case M_LUNITDATA: /* Fall Through */
      case M_XUNITDATA:
      {
         SpUdCb ucb;
         SpUDatEvnt ud;

         /* Set Up UnitData Event Structure */
         ucb.nSap = nSap;
         ucb.nwData = nSap->nwData;
         /* sp045.302 - addition - initialise the out network */
         ucb.outNwData = nSap->nwData;
         ucb.sap = (SpSapCb *) NULLP;
         ucb.rCb = (SpRteCb *) NULLP;
         ucb.opc = opc;
         ucb.dpc = (Dpc) 0;
         ucb.sls = lnkSel;   /* Incoming sls */
         ucb.ud = &ud;
         ucb.ud->prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);
         ucb.ud->qos.pClass = spCb.pdu.m.xuData.pClass.pClass.val;
         ucb.ud->qos.retOpt = spCb.pdu.m.xuData.pClass.retOpt.val;
         ucb.dataType = spCb.pduHdr.msgType.val;  
         ucb.hopCntr = spCb.pdu.m.xuData.hopCntr.cnt.val;

         /* fill message importance in unit data control block. 
          * Though importance is a part of ud struct, its being
          * filled in ucb, because the imp in ud is under SPTV2
          * and its possible that SCCP is itu 96 but with lower
          * spt interface version. In such case if sccp receives
          * importance in message from network then it should
          * accept and act upon it if traffic limitation is enabled.
          */
         if (spCb.pdu.m.xuData.imp.eh.pres == NOTPRSNT)
         {
            ucb.imp.pres = NOTPRSNT;
         }
         else
         {
            ucb.imp.pres = PRSNT_NODEF;
            /* if importance is greater than maximum allowable value
             * then assign the maximum alowable value only.
             */
            if (spCb.pdu.m.xuData.imp.importance.val > MAXUDATIMP)
               ucb.imp.val = MAXUDATIMP;
            else
               ucb.imp.val = spCb.pdu.m.xuData.imp.importance.val;
         }

         if (spCb.pdu.m.xuData.segment.eh.pres == NOTPRSNT)
            ucb.seg = FALSE;
         else
         {
            ucb.seg = TRUE; 
            if ((spCb.pdu.m.xuData.segment.remainSeg.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuData.segment.inSeq.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuData.segment.firstSeg.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuData.segment.lclRef.pres == PRSNT_NODEF))
            {
               ucb.segRemain  = spCb.pdu.m.xuData.segment.remainSeg.val;
               ucb.seq = spCb.pdu.m.xuData.segment.inSeq.val;
               ucb.firstSeg  = spCb.pdu.m.xuData.segment.firstSeg.val;
               ucb.ref  = spCb.pdu.m.xuData.segment.lclRef.val;
            }
            else
            {
               SPLOGERROR(ERRCLS_INT_PAR, ESP031, (ErrVal) ERRZERO,
                          "missing segmentation data ");
               spSendLmSta(LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_EVT, 
                           LCM_CAUSE_DECODE_ERR, NOTUSED, NOTUSED);
               spDropMsg(&data);
               RETVALUE(ROKDNA);
            }
         }

         spTknStrToSpAddr(&spCb.pdu.m.xuData.cdAddr.spAddr,
                          &ucb.ud->cdAddr, ucb.nwData->variant, 
                          (U8) ((srvInfo & 0xC0) >> 6));
         spTknStrToSpAddr(&spCb.pdu.m.xuData.cgAddr.spAddr,
                          &ucb.ud->cgAddr, ucb.nwData->variant, 
                          (U8) ((srvInfo & 0xC0) >> 6));

#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
         /* 
          * This is the _only_ criteria for adding or removing pc from network
          * messages.
          */
         if (ucb.ud->cdAddr.pcInd == FALSE)
            ucb.ud->cdAddr.spHdrOpt = CMSS7_NO_SP_PC;
         if (ucb.ud->cgAddr.pcInd == FALSE)
            ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

         /* sp047.302 - Addition - Retain a copy of called and calling address
          * so that they can be restored if message interception is enabled.
          */
         cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr); 
         cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr); 

         /* sp024.302 - addition - perform calling party address treatment as
          * per ITU Q.714, section 2.7.5.1 (b) and (c).
          */
         if ((ucb.ud->cgAddr.rtgInd == RTE_SSN) &&
             (ucb.ud->cgAddr.pcInd == FALSE))
         {
            ucb.ud->cgAddr.pcInd = TRUE;
            ucb.ud->cgAddr.pc = ucb.opc;
         }

         /* increment statistics counter for ludt/xudt received */
         if (spCb.pduHdr.msgType.val == M_LUNITDATA)
            spCb.sts.luDataRx++;
         else
            spCb.sts.xuDataRx++;

         /* save address string for segmentation identification */ 
         ucb.cgAddrStr = &spCb.pdu.m.xuData.cgAddr.spAddr;

         /* Check for Hop Counter violation */
         if (ucb.ud->cdAddr.rtgInd == RTE_GT) 
         {
            /* decrement hop counter */
            --ucb.hopCntr;
            if (ucb.hopCntr <= 0)
            {
               /* increment statistics for hop cntr violation */
               spCb.sts.rfHopViolate++;

                /* Handle Hop Counter Violation */
               if ((ucb.ud->qos.pClass == PCLASS0) ||
                   (ucb.ud->qos.pClass == PCLASS1))
               {
                  /* sp010.302 - Hop counter violation should be 12 for ANSI 96 */
                  spReturnMsg(&ucb, RTC_HOPVIOLATE2, data);

                  spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_HOP_VIOLATION,
                              LCM_CAUSE_OUT_OF_RANGE, NOTUSED, NOTUSED);

                  RETVALUE(ROK);
               }
               else /* drop management messages */
               {
                  spDropMsg(&data);
                  RETVALUE(ROK);
               }
            }
         }

 
            ucb.spMti.pres = FALSE;

         /* handle message class wise */
         switch (ucb.ud->qos.pClass)
         {
            case PCLASS0:
            {
               /* increment statistics counter for class 0 msgs received */
               spCb.sts.msgRxC0++;
               if ((ucb.ud->cdAddr.ssn == SS_SCCPMNGT) && 
                   (ucb.ud->cgAddr.ssn == SS_SCCPMNGT))
                  spLiHndlMngt(&ucb, data);
               else
                  spLiHndlClss0(&ucb, data);
               break;
            }
            case PCLASS1:
            {
               /* increment statistics counter for class 1 msgs received */
               spCb.sts.msgRxC1++;
               spLiHndlClss1(&ucb, data);
               break;
            }
            default:
            {
               /* invalid class; increment statistics counter for
                * syntax error, send alarm and drop message.
                */
               spCb.sts.synError++;
               SPLOGERROR(ERRCLS_INT_PAR, ESP032, (ErrVal) ucb.ud->qos.pClass,
                          "SpLiSntUDatInd() invalid class");
               spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_SYN_ERROR,
                           LSP_CAUSE_SYNTAX_ERROR, spCb.pduHdr.msgType.val,
                           ucb.ud->qos.pClass);
               spDropMsg(&data);
            break;
            }
         } /* switch (...pClass) */
         break;
      } /* case M_XUNITDATA */

      case M_LUNITDATASRV:  /* Fall Through */
      case M_XUNITDATASRV:
      {
         SpUdCb ucb;
         SpUDatEvnt ud;

         ucb.nSap = nSap;
         ucb.nwData = nSap->nwData;
         /* sp045.302 - addition - initialise the out network */
         ucb.outNwData = nSap->nwData;
         ucb.sap = (SpSapCb *) NULLP;
         ucb.rCb = (SpRteCb *) NULLP;
         ucb.opc = opc;
         ucb.dpc = (Dpc) 0;
         ucb.sls = lnkSel;   /* Incomign sls */
         ucb.ud = &ud;
         ucb.ud->prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);
         ucb.ud->qos.pClass = PCLASS0;

         /* Use the retOpt for the return cause */
         ucb.ud->qos.retOpt = spCb.pdu.m.xuDataSrv.retCause.retCause.val;

         ucb.hopCntr = spCb.pdu.m.xuDataSrv.hopCntr.cnt.val;

         /* fill message importance in unit data control block. 
          * Though importance is a part of ud struct, its being
          * filled in ucb, because the imp in ud is under SPTV2
          * and its possible that SCCP is itu 96 but with lower
          * spt interface version. In such case if sccp receives
          * importance in message from network then it should
          * accept and act upon it if traffic limitation is enabled.
          */
         if (spCb.pdu.m.xuDataSrv.imp.eh.pres != NOTPRSNT)
         {
            ucb.imp.pres = PRSNT_NODEF;
            /* if importance is greater than maximum allowable value
             * then assign the maximum alowable value only.
             */
            if (spCb.pdu.m.xuDataSrv.imp.importance.val > MAXUDATIMP)
               ucb.imp.val = MAXUDATIMP;
            else
               ucb.imp.val = spCb.pdu.m.xuDataSrv.imp.importance.val;
         }
         else
         {
            ucb.imp.pres = NOTPRSNT;
         }

         if (spCb.pduHdr.msgType.val == M_LUNITDATASRV)
         {
            ucb.dataType = M_LUNITDATASRV;  
         }
         else
         {
            ucb.dataType = M_XUNITDATASRV;  
         }

         spTknStrToSpAddr(&spCb.pdu.m.xuDataSrv.cdAddr.spAddr, &ucb.ud->cdAddr,
                          ucb.nwData->variant, (U8) ((srvInfo & 0xC0) >> 6));
         spTknStrToSpAddr(&spCb.pdu.m.xuDataSrv.cgAddr.spAddr, &ucb.ud->cgAddr,
                          ucb.nwData->variant, (U8) ((srvInfo & 0xC0) >> 6));

#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
         /* This is the criteria for adding or removing pc from 
          * network messages. 
          */
         if (ucb.ud->cdAddr.pcInd == FALSE)
            ucb.ud->cdAddr.spHdrOpt = CMSS7_NO_SP_PC;
         if (ucb.ud->cgAddr.pcInd == FALSE)
            ucb.ud->cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

         /* sp047.302 - Addition - Retain a copy of called and calling address
          * so that they can be restored if message interception is enabled.
          */
         cmCopySpAddr(&ucb.ud->cgAddr, &ucb.origCgAddr); 
         cmCopySpAddr(&ucb.ud->cdAddr, &ucb.origCdAddr); 

         if (spCb.pdu.m.xuDataSrv.segment.eh.pres == NOTPRSNT)
            ucb.seg = FALSE;
         else
         {
            ucb.seg = TRUE; 
            if ((spCb.pdu.m.xuDataSrv.segment.remainSeg.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuDataSrv.segment.inSeq.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuDataSrv.segment.firstSeg.pres == PRSNT_NODEF)
                &&(spCb.pdu.m.xuDataSrv.segment.lclRef.pres == PRSNT_NODEF))
            {
               ucb.segRemain  = spCb.pdu.m.xuDataSrv.segment.remainSeg.val;
               ucb.seq = spCb.pdu.m.xuDataSrv.segment.inSeq.val;
               ucb.firstSeg  = spCb.pdu.m.xuDataSrv.segment.firstSeg.val;
               ucb.ref  = spCb.pdu.m.xuDataSrv.segment.lclRef.val;
            }
            else
            {
               SPLOGERROR(ERRCLS_INT_PAR, ESP033, (ErrVal) ERRZERO,
                          "missing segmentation data ");
               spSendLmSta(LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_EVT, 
                           LCM_CAUSE_DECODE_ERR, NOTUSED, NOTUSED);
               spDropMsg(&data);
               RETVALUE(ROKDNA);
            }
         }

         /* Check for Hop Counter violation */
         if (ucb.ud->cdAddr.rtgInd == RTE_GT) 
         {
            /* decrement the Hop Counter */
            --ucb.hopCntr;
            if (ucb.hopCntr <= 0) /* Hop counter reaches 0 */ 
            {
               /* increment statistics for hop cntr violation */
               spCb.sts.rfHopViolate++;

               spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_HOP_VIOLATION,
                           LCM_CAUSE_OUT_OF_RANGE, NOTUSED, NOTUSED);

               spDropMsg(&data); 
               RETVALUE (ROK);
            }
         }

 
            ucb.spMti.pres = FALSE;

         /* increment statistics cntr for XUDTS/LUDTS received */
         if (spCb.pduHdr.msgType.val == M_LUNITDATASRV)
         {
            spCb.sts.luDataSrvRx++;
         }
         else
         {
            spCb.sts.xuDataSrvRx++;
         }

         spLiHndlUDatSrv(&ucb, data);
         break;
      } /* case M_XUNITDATASRV */

      default:
      {
         /* Check For Guard Timer */
#ifdef SPCO
         if (spCb.status & SP_GUARD)
         {
            /* if its a release message, send release complete */
            if (spCb.pduHdr.msgType.val == M_RELSD )
            {
               /* this will send relcmp... */
               spHandleBadDLR(nSap, opc, (U8) ((srvInfo & 0xC0) >> 6), data);
               RETVALUE(ROK);
            }
            else
               spDropMsg(&data);
            RETVALUE(ROK);
         }

         lclRef = nSap->mfMsgCtl.sccpInfo.dstLclRef;
         if (!(cb = spLookUpConCbAndSetSide(nSap->nwData, lclRef)))
         {
            /* handle unassigned local reference */
            spHandleBadDLR(nSap, opc, (U8) ((srvInfo & 0xC0) >> 6), data);
            RETVALUE(ROK);
         }

         cb->cs[SIDE(cb)].nSap = nSap;

         if (opc != cb->cs[SIDE(cb)].pc)
         {
            /* handle mismatched point code */
            spHandleBadOPC(cb, opc, data);
            RETVALUE(ROK);
         }
         if (nSap->mfMsgCtl.sccpInfo.slrPres)
         {
            if (cb->cs[SIDE(cb)].conId.suInstId != 
                nSap->mfMsgCtl.sccpInfo.srcLclRef)
            {
               spHandleBadSLR(cb, opc, data);
               RETVALUE(ROK);
            }
         }
  
         /* reset the counter nmbItTx to zero only if message type is other
          * than IT
          */
         if (spCb.pduHdr.msgType.val != M_INACTST )
            cb->nmbItTx = 0;

         /* pass pdu to lower interface routine */
         cb->info = (PTR) &spCb.pdu;
         
         /* get message importance */
         spLiGetCoMsgImp(cb, spCb.pduHdr.msgType.val, &spCb.pdu, nSap, srvInfo);

         /* jump into matrix */
         spLiConMt[spCb.pduHdr.msgType.val-1][cb->side][cb->state](cb, data);

#else  /* SPCO  */
         SPLOGERROR(ERRCLS_INT_PAR, ESP034, (ErrVal) spCb.pduHdr.msgType.val,
                    "invalid spCb.pduHdr.msgType.val");
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LCM_EVENT_INV_EVT, 
                     LCM_CAUSE_INV_NETWORK_MSG, NOTUSED, NOTUSED);
         spDropMsg(&data);
#endif /* SPCO  */
         break;
      }
   } /* switch (...msgType.val) */

   spCb.sts.msgHand++;        /* update statistics counter */

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

   RETVALUE(ROK);
} /* SpLiSntUDatInd */

  
/*
*       Fun:   SpLiSntStaInd
*
*       Desc:  Status Indicator...
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpLiSntStaInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
Dpc apc,                        /* affected point code */
Status status,                  /* mtp-3 status */
Priority prior                  /* priority */
)
#else
PUBLIC S16 SpLiSntStaInd(pst, suId, apc, status, prior)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
Dpc apc;                        /* affected point code */
Status status;                  /* mtp-3 status */
Priority prior;                 /* priority */
#endif
{
   SpNSapCb *nSap;
   S16 ret;                     /* return value - sp003.302 - addition */
  
   TRC3(SpLiSntStaInd)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpLiSntStaInd() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_LI, (spCb.spInit.prntBuf, 
      "SpLiSntStaInd(pst, suId (%d), apc (%ld), status (%d), priority (%d))\n",
      suId, apc, status, prior));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP035, (ErrVal) 0, 
                 "SpLiSntStaInd() recd in invalid PSF state");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSNTSTAIND, (U8)suId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */
   /* sp003.302 - added a nSap control block pointer as a parameter to
    * spFindLowerSapSid so we can check the different situation of nSap
    * via returned value 
    */
   ret = spFindLowerSapSid(suId, &nSap);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ret == RFAILED)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP036, (ErrVal) suId,
                 "SpLiSntStaInd() nsap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                                LCM_CAUSE_INV_SUID, EVTSNTSTAIND, (U8)suId);
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS */
   
   /* sp003.302 - if lower sap is configured but not bind then return ok
    * instead of return failure
    */
   if (ret == ROKDNA)
      RETVALUE(ROK);

   switch (status)
   {
      /* Pause and Remote User Unavailable are almost identical,
       * a paused route will be resumed. A RUU route will not be,
       * but may automagically reappear, so skip the pause logic.
       * (i.e. adjusting the routing table)
       */
      case SN_RMTUSRUNAV:
      case SN_PAUSE:
         if (status == SN_PAUSE)
            spMngtPause(nSap, apc);
         else 
            spMngtUnavail(nSap, apc, prior); /* status == SN_RMTUSRUNAV) */
         break;

      case SN_RESUME:
         spMngtResume(nSap, apc);
         break;

      case SN_STPCONG:
      case SN_CONG:
         spMngtCong(nSap, apc, prior);
         break;

      case SN_RSTBEG:
         spHndlRstBeg(nSap);
         break;

      case SN_RSTEND:
         /* just in case the timer has expired earlier */
         if (nSap->status & SP_SNRST) 
            spHndlRstEnd(nSap);
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP037, (ErrVal) status,
                    "SpLiSntStaInd() invalid  mtp-3 status");
         spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                     LCM_CAUSE_OUT_OF_RANGE, EVTSNTSTAIND, NOTUSED);
         break;
   }

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   
   RETVALUE (ROK);
} /* SpLiSntStaInd */

#ifdef SNT2

/*
*       Fun:   SpLiSntBndCfm
*
*       Desc:  Bind confirmation...
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpLiSntBndCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
U8 status                       /* mtp-3 status */
)
#else
PUBLIC S16 SpLiSntBndCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
U8 status;                      /* mtp-3 status */
#endif
{
   SpNSapCb *nSap;              /* network sap */
   S16 ret = ROK;

   TRC3(SpLiSntBndCfm)

   UNUSED(pst);

/* sp039.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpLiSntBndCfm() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   SPDBGP(DBGMASK_LI, (spCb.spInit.prntBuf, 
          "SpLiSntBndCfm(pst, suId (%d), status (%d)\n", suId, status));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP038, (ErrVal) 0, 
                 "SpLiSntBndCfm() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSNTBNDCFM, (U8)suId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */
   
   nSap = spCb.nSapList[suId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (nSap == (SpNSapCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP039, (ErrVal) suId,
                 "SpLiSntBndCfm() nsap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_INV_SUID, EVTSNTBNDCFM, (U8)suId);
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS */

   if (!(nSap->status & SP_WAIT_BNDCFM))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP040, (ErrVal) nSap->status,
                 "SpLiSntBndCfm() unexpected bind confirm");
      RETVALUE(RFAILED);
   }
   /* stop timer */
   spRmvNSapTq(nSap, TMR_INT);
   nSap->bndRetryCnt = 0;
   nSap->status ^= SP_WAIT_BNDCFM;
   if (status == CM_BND_NOK)
   {
      spSendLmSta(LCM_CATEGORY_PROTOCOL, LCM_EVENT_BND_FAIL, 
                  LCM_CAUSE_UNKNOWN, NOTUSED, (U8)suId);
      ret = RFAILED;
   }
   else
   {
      nSap->status ^= SP_BND;
      spRteExtSync(nSap);
   }
#ifdef ZP
   zpRunTimeUpd(ZP_SP_NSAPCB, (Void *)nSap, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
   zpUpdPeer();
#endif /* ZP */
   RETVALUE(ret);
} /* SpLiSntBndCfm */

  
/*
*       Fun:   SpLiSntStaCfm
*
*       Desc:  Status confirmation
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpLiSntStaCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
Dpc  dpc,                       /* destination point code */
Status status,                  /* mtp-3 status */
U8 congLevel                    /* congestion level */
)
#else
PUBLIC S16 SpLiSntStaCfm(pst, suId, dpc, status, congLevel)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
Dpc dpc;                        /* affected point code */
Status status;                  /* mtp-3 status */
U8 congLevel;                   /* congestion level */
#endif
{
   SpNSapCb *nSap; /* network SAP */
   SpRteCb *rCb;   /* route control block */
   SpRteKey rKey;  /* route key */

   /* sp006.302 - modification - correction in func name passed to macro */
   TRC3(SpLiSntStaCfm)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpLiSntStaCfm() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_LI, (spCb.spInit.prntBuf, 
          "SpLiSntStaCfm(pst, suId (%d), dpc (%ld), status (%d), congLevel (%d)\n", suId, dpc, status, congLevel));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP041, (ErrVal) 0, 
                 "SpLiSntStaCfm() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSNTSTACFM, (U8)suId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

   nSap = spCb.nSapList[suId];
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (nSap == (SpNSapCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP042, (ErrVal) suId,
                 "SpLiSntStaCfm() nsap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_LI_INV_EVT, 
                  LCM_CAUSE_INV_SUID, EVTSNTSTACFM, (U8)suId);
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS */

   if (!(nSap->status & SP_BND))
   {
      RETVALUE(RFAILED);
   }

   rKey.k1.dpc = dpc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb *)NULLP)
   {
       RETVALUE(RFAILED);
   }

   /* route came up or route came up and congested */
   switch (status)
   {
      case SN_RESUME:
         spMngtResume(rCb->nSap, dpc);
         break;

      case SN_CONG:
         if (!(rCb->status & SP_ONLINE))
            spMngtResume(rCb->nSap, dpc); 

         if ((rCb->status & SP_CONG) && (rCb->cLvl != congLevel))
            spMngtCong(rCb->nSap, dpc, congLevel);
         break;

      default:
         break;
   }
      
#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   RETVALUE(ROK);
} /* end of SpLiSntStaCfm */
#endif /* SNT2 */

  
/*
*       Fun:   SpUiSptCordReq
*
*       Desc:  N-COORD request
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptCordReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Ssn aSsn                        /* affected subsystem number */
)
#else
PUBLIC S16 SpUiSptCordReq(pst, spId, aSsn)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Ssn aSsn;                       /* affected subsystem number */
#endif
{
   SpSapCb *sap;                /* upper sap */
   SpMngtCb mcb;  
   U16 i;                       /* loop counter */
  
   TRC3(SpUiSptCordReq)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptCordReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptCordReq(pst, spId (%d), aSsn (%d)\n", spId, aSsn));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP043, (ErrVal) 0, 
                 "SpUiSptCordReq() recd in invalid PSF state");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTCRDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ( (spId > (SpId)spCb.spCfg.nmbSaps) || (spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP044, (ErrVal) spId,
                 "SpUiSptCordReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTCRDREQ, (U8)spId);
      RETVALUE(RFAILED);
   }   
#endif /* ERRCLASS */

   /* find upper sap */
   sap = *(spCb.sapList + (PTR)spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sap == (SpSapCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP045, (ErrVal) spId,
                 "SpUiSptCordReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTCRDREQ, (U8)spId);
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS */

   /* multiple backups have been added in rel 3.2 */
   if (!sap->nmbBpc)
      RETVALUE (ROK);         /* no backup available */
  
   /* send a management message to all sap's backup */
   for(i = 0; i < sap->nmbBpc; i++)
   {
      mcb.dpc = sap->bpcList[i].bpc;     /*  backup PC  */
      mcb.apc = sap->nwData->selfPc;     /* Self Point Code */
      mcb.assn = aSsn;
      mcb.nwData = sap->nwData;
      mcb.smi = SMI_DUP;
      mcb.frmt = SCMG_SOR;
      spSendMngtMsg(&mcb);
   }

   /* start sap timer for coordinated state change */
   sap->tmr.enb = TRUE;
   sap->tmr.val = sap->nwData->defCrdTmr.val;
   sap->aSsn = aSsn; 
   spStartSapCbTmr(sap, TMR_GRT);
  
   /* set "waiting for grant" */
   if (!(sap->status & SP_GRNT))
   {
      sap->status ^= SP_GRNT;
#ifdef ZP
      zpRunTimeUpd(ZP_SP_SAPCB, (Void *)sap, CMPFTHA_UPDTYPE_NORMAL, 
                   CMPFTHA_ACTN_MOD);
#endif /*ZP */
   }

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
  
   RETVALUE (ROK);
}  /* SpUiSptCordReq  */
  
/*
*       Fun:   SpUiSptCordRsp
*
*       Desc:  NCOORD response
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptCordRsp
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service user id */
Ssn aSsn                        /* affected subsystem number */
)
#else
PUBLIC S16 SpUiSptCordRsp(pst, spId, aSsn)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Ssn aSsn;                       /* affected subsystem number */
#endif
{
   SpSapCb *sap;
   SpMngtCb mcb;  
  
   TRC3(SpUiSptCordRsp)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptCordRsp() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptCordRsp(pst, spId (%d), aSsn (%d)\n", spId, aSsn));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP046, (ErrVal) 0, 
                 "SpUiSptCordRsp() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTCRDRSP, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ( (spId > (SpId)spCb.spCfg.nmbSaps) || (spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP047, (ErrVal) spId,
                 "SpUiSptCordRsp() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTCRDRSP, (U8)spId);
      RETVALUE (RFAILED); /* spid out of range */
   }
#endif /* ERRCLASS */
  
   /* find upper sap */
   sap = *(spCb.sapList + (PTR)spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sap == (SpSapCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP048, (ErrVal) spId,
                 "SpUiSptCordRsp() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTCRDRSP, (U8)spId);
      RETVALUE (RFAILED);
   }
#endif /* ERRCLASS */
  
   if (!sap->nmbBpc)
      RETVALUE (ROK); /* no backup available */
  
   sap->sts.ssOOSReqGr++;    /* sss out-of-service request granted */
   
   /* In case there is multiple backup of SS , to identify the point code 
    * to which co-ordinate response has to be sent a  new field apc in SapCb 
    * has been added which will indicate the backup point code to which SOG 
    * has to be  send 
    */ 
   /* send a management message to this sap's backup */
   mcb.dpc = sap->sorPc;
   /* The SP who sent the SOR has to be the apc */
   mcb.apc = sap->sorPc;
   mcb.assn = aSsn;
   mcb.nwData = sap->nwData;
   mcb.smi = SMI_DUP;
   mcb.frmt = SCMG_SOG;
   spSendMngtMsg(&mcb);

   RETVALUE (ROK);
} /* SpUiSptCordRsp */

  
/*
*       Fun:   SpUiSptSteReq
*
*       Desc:  N-STATE Request.
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptSteReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Ssn aSsn,                       /* affected Subsystem */
UStat uStat                     /* user Status */
)
#else
PUBLIC S16 SpUiSptSteReq(pst, spId, aSsn, uStat)
Pst *pst;                       /* post structure */
SpId spId;                      /* service user id */
Ssn aSsn;                       /* affected Subsystem */
UStat uStat;                    /* user Status */
#endif
{
   SpSapCb *sap;                /* sap pointer */
   Smi smi;                     /* subsystem multiplicity indicator */

   TRC3(SpUiSptSteReq)

   UNUSED(pst);
#ifndef DEBUGP
   UNUSED(aSsn);
#endif /* DEBUGP */
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptSteReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptSteReq(pst, spId (%d), aSsn (%d), uStat (%d)\n",
          spId, aSsn, uStat));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP049, (ErrVal) 0, 
                 "SpUiSptSteReq() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTEREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((spId > (SpId) spCb.spCfg.nmbSaps) || (spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP050, (ErrVal) spId,
                 "SpUiSptSteReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTSTEREQ, (U8)spId);
      RETVALUE (RFAILED);            
   }
#endif /* ERRCLASS */
  
   sap = *(spCb.sapList + (PTR) spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sap == (SpSapCb *) NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP051, (ErrVal) spId,
                 "SpUiSptSteReq() sap not configured");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTSTEREQ, (U8)spId);
      RETVALUE(RFAILED);            
   }
#endif /* ERRCLASS */

   if (sap->nmbBpc)
      smi = SMI_DUP;
   else
      smi = SMI_SOL;

   switch (uStat)
   {
      case SS_UOS:
      {
         if (sap->status & SP_PROH)
         {
#ifdef SPT2
            (Void) SpUiSptSteCfm(&sap->pst, sap->suId, ROK);
#endif /* SPT2 */
            RETVALUE(SP_OK);  /* do nothing */
         }

         /* Sematically spDisableUpperSap is an incorrect function to
          * be called here.  Restore the SP_BND state of the SAP and
          * remIntfValid flag as TRUE after calling this function
          */
         spDisableUpperSap(sap);
         sap->status ^= SP_PROH;
         sap->status ^= SP_BND;
#ifdef SP_RUG
         sap->remIntfValid = TRUE;
#endif /* SP_RUG */

         /* update statistics for start of local subsystem prohibited */
         sap->sts.ssProhStart++;
#ifdef ZP
         zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap, CMPFTHA_UPDTYPE_SYNC, 
                      CMPFTHA_ACTN_MOD);
#endif /* ZP */
         break;
      }

      case SS_UIS:
      {
         /* sp017.302 - deletion - remove check on sap prohibited and process
          * UIS request on each invokation of this primitive
          */

         /* sp019.302 - mark sap avilable, reset the bit only
          * if sap is prohibited to handle multiple UIS from user.
          */
         if (sap->status & SP_PROH)
         {
            sap->status ^= SP_PROH;

            /* update statistics for stop of local subsystem prohibited */
            sap->sts.ssProhStop++;
         }

#ifdef ZP
         zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap, CMPFTHA_UPDTYPE_SYNC, 
                      CMPFTHA_ACTN_MOD);
#endif /* ZP */
         spBroadcast(sap->nwData, sap->nwData->selfPc, sap->nwData->selfPc,
                     sap->ssn, smi, SCMG_SSA);
         spLocalBroadcast(SS_UIS, sap->nwData->variant, sap->nwData->selfPc,
                          sap->ssn, smi, (U8) NOTUSED, (U8) NOTUSED,
                          (U8) FROM_UPPER);
         if (spCb.ustaMask & LSP_USTAALARM)
            spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_USER_INS, 
                        LCM_CAUSE_USER_INITIATED, (U8) sap->nwData->variant,
                        (U8) sap->spId); 
         break;
      }

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP052, (ErrVal) uStat,
                    "SpLiSntStaInd() invalid user status");
         spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                     LCM_CAUSE_OUT_OF_RANGE, EVTSPTSTEREQ, NOTUSED);
#ifdef SPT2
         (Void) SpUiSptSteCfm(&sap->pst, sap->suId, RFAILED);
#endif /* SPT2 */
         RETVALUE(RFAILED);
   } /* switch (uStat) */

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

#ifdef SPT2
   (Void) SpUiSptSteCfm(&sap->pst, sap->suId, ROK);
#endif /* SPT2 */

   RETVALUE(ROK);
} /* SpUiSptSteReq */

#ifdef SPT2

/*
*       Fun:   SpUiSptStaReq
*
*       Desc:  status Request.
*
*       Ret:   ROK   - ok
*
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptStaReq
(
Pst *pst,                     /* post structure */
SpId spId,                    /* service provider id */
U8 status,                    /* status type */
Dpc dpc,                      /* destination pointcode */
Ssn ssn                       /* Subsystem */
)
#else
PUBLIC S16 SpUiSptStaReq(pst, spId, status, dpc, ssn)
Pst *pst;                     /* post structure */
SpId spId;                    /* service user id */
U8 status;                    /* status */
Dpc dpc;                      /* pointcode */
Ssn ssn;                      /* Subsystem */
#endif
{
   S16 i;                     /* index */
   SpRteCb* rCb;              /* route control block pointer */
   SpRteKey rKey;             /* route Key */
   SpSsnCb* ssnCb;            /* subsystem control block pointer */
   Smi smi;                   /* subsystem multiplicity indicator */
   UStat uStat;               /* status */
   SpSapCb *sap;              /* sap control block */
   /* sp006.302 - removal - removing local variables sccpState and ril */

   TRC3(SpUiSptStaReq)

   /* sp044.302 - addition - Initialization of Local Variables */   
   ssnCb = NULLP;   
   smi = SMI_UNK;

   UNUSED(pst);

/* sp039.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptStaReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptStaReq(pst, spId (%d), status (%d), dpc (%ld), ssn (%d)\n",
          spId, status, dpc, ssn));

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP053, (ErrVal) 0, 
                 "SpUiSptStaReq() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, EVTSPTSTAREQ, (U8)spId);
      RETVALUE(RFAILED);
   }
#endif /* ZP */

   uStat = 0;
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((spId > (SpId)spCb.spCfg.nmbSaps) || (spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP054, (ErrVal) spId,
                 "SpUiSptStaReq() invalid spId");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTSTAREQ, (U8)spId);
      RETVALUE (RFAILED);            
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sap == (SpSapCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP055, (ErrVal) spId,
                 "SpUiSptStaReq() Null sap pointer");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_INV_SPID, EVTSPTSTAREQ, (U8)spId);
      RETVALUE (RFAILED);            
   }
#endif /* ERRCLASS */

   rKey.k1.dpc = dpc;
   rKey.k1.nwId = sap->nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
   if (rCb == (SpRteCb*)NULLP)
   {
      /* this route is not configured in SCCP so just return */
      RETVALUE (RFAILED);            
   }

   switch(status)
   {
      case SPT_STATUS_PC:  /* pointcode status requested */
         if (rCb->nmbBpc)
            smi = SMI_DUP;
         else
            smi = SMI_SOL;
         /* determine uStat */
         if (rCb->status & SP_ONLINE)
            uStat |= SP_ACC;
         else
            uStat |= SP_INACC;
         if (rCb->status & SP_CONG)
            uStat |= SP_CONG;

         /* sp006.302 - removal - removing assignments to local variables
          * sccpState and ril and passing these values form rCb fields so
          * that proper values of these parameters are passed to upper user
          * irrespective of point code status request or ssn status request
          */
         break;

      case SPT_STATUS_SS:  /* subsystem status requested */
         for (i = 0; i < rCb->nmbSsns; i++)
         {
            ssnCb = &rCb->ssnList[i];
            if ((ssnCb != (SpSsnCb *)NULLP) && (ssnCb->ssn == ssn))
               break;
         }
         if (i < rCb->nmbSsns)
         {
            /* we found requested subsystem */
            if (ssnCb->nmbBpc)
               smi = SMI_DUP;
            else
               smi = SMI_SOL;
            if (ssnCb->status & SS_ACC)
               uStat |= SS_UIS;
            else
               uStat |= SS_UOS;
         }
         else
         {
             /* requested subsystem is not configured in SCCP */
            RETVALUE(RFAILED);
         }
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP056, (ErrVal) status,
                             "SpUiSptStaReq() invalid status");
         spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                     LCM_CAUSE_OUT_OF_RANGE, EVTSPTSTAREQ, NOTUSED);
         break;
   } /* end switch */

   /* send confirmation back */
#ifdef SPTV2
   /* sp006.302 - modification - removing local variables for sccp state and
    * ril and rather passing sccp state and ril from rCb fields
    */
   (Void) SpUiSptStaCfm(&sap->pst, sap->suId, status, dpc, ssn, uStat, smi,
                        rCb->sccpSts, rCb->spRestrictComp.ril);
#else
   (Void) SpUiSptStaCfm(&sap->pst, sap->suId, status, dpc, ssn, uStat, smi);
#endif /* SPTV2 */

   /* sp030.302 - modification - return value TRUE to ROK */
   RETVALUE(ROK);
} /* SpUiSptStaReq */
#endif /* SPT2 */


#ifdef SPCO
/*
*
*       Fun:   SpUiSptConReq
*
*       Desc:  Connection Request
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptConReq
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event */
Buffer *data                    /* buffer */
)
#else
PUBLIC S16 SpUiSptConReq(pst, conEvnt, data)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event */
Buffer *data;                   /* buffer */
#endif
{
   S16 thresh;                  /* threshold */
   SpSapCb *sap;                /* upper sap cb */
   SpConCb *cb;                 /* call */
   SpAddr *cdAddr;              /* called address */
   U8 evnt;                     /* connection event */
   S16 ret;                     /* return value */

   TRC3(SpUiSptConReq)
   
   /* sp044.302 - addition - Initialization of called Address */   
   cdAddr = NULLP;   

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptConReq() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf,
          "SpUiSptConReq(pst, conEvnt->type (%d)\n", conEvnt->type));

   /* validate connection event type */
   switch(conEvnt->type)
   {
      case CE_REQ0:
         cdAddr = &conEvnt->t.req0.cdAddr;
         evnt = SP_CONREQ0;
         break;
      case CE_REQ1:
         evnt = SP_CONREQ1;
         break;
      case CE_REQ2:
         evnt = SP_CONREQ2;
         break;
      default:
         spDropMsg(&data);
         RETVALUE(RFAILED);
   } /* switch (...type) */

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((conEvnt->conId.spId >= (SpId) spCb.spCfg.nmbSaps) || 
       (conEvnt->conId.spId < 0))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR) conEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate sap */
   if (sap == (SpSapCb *) NULLP)
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* check if the guard timer has started */
   if (spCb.status & SP_GUARD)
   {
      SpDisEvnt dis;
      cmCopy((U8 *) &conEvnt->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
      dis.rspAddr.pres = TRUE;
      dis.rspAddr.pc = sap->nwData->selfPc;
      dis.rsn =  RFC_NRQOST;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not relevant in indication to user */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
      (Void) SpUiSptDisInd(&sap->pst, &dis, data);
      RETVALUE(ROK);
   }

   /* Check Local Resources */
   ret = SChkRes(spCb.spInit.region, spCb.spInit.pool, &thresh);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP057, (ErrVal) ret,  "SChkRes() failed");
      /* sp011.302 - Should drop message if we reach this exception case */
      spDropMsg(&data);

      RETVALUE(RFAILED);
   }

   if (thresh <= spCb.spCfg.conThresh)
   {
      SpDisEvnt dis;
      /* sp030.302 - modification - moved alarm generation after check */
      /* sp028.302 - addition - generate alarm */
      spSendLmSta(LCM_CATEGORY_INTERNAL, LSP_EVENT_CONREQ_FAILURE,
                  LSP_CAUSE_CONN_THRESH_EXCEEDED, NOTUSED, NOTUSED);

      /* we've reached the connection threshold */
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "Out of Resources, Connection Refused\n"));
      cmCopy((U8 *) &conEvnt->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
      dis.rspAddr.pres = TRUE;
      dis.rspAddr.pc = sap->nwData->selfPc;
      dis.rsn =  RFC_NRQOST;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not relevant in indication to user */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
      (Void) SpUiSptDisInd(&sap->pst, &dis, data);
      RETVALUE(ROK);
   } /* if (thresh <= ...conThresh) */

   cb = spNewConCb(sap->nwData);
   if (cb == (SpConCb *) NULLP)
   {
      /* resources are unavailable */
      SpDisEvnt dis;
      cmCopy((U8 *) &conEvnt->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
      dis.rspAddr.pres = TRUE;
      dis.rspAddr.pc = sap->nwData->selfPc;
      dis.rsn =  RFC_NRQOST;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not relevant in indication to user */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
      (Void) SpUiSptDisInd(&sap->pst, &dis, data);
      if (evnt == SP_CONREQ2)
          spConRefFromConReq(sap, conEvnt);
      RETVALUE(ROK);
   } /* if (cb == NULLP) */

   if (cdAddr->ssfPres)
      cb->ssf = cdAddr->ssf;
   else
      cb->ssf = (U8) ((sap->nwData->sInfo & 0xC0) >> 6);

   /* assign importance to connection request, mark its
    * presence only if its present in conEvnt struct
    */
#ifdef SPTV2
   if (conEvnt->imp.pres == PRSNT_NODEF)
   {
      /* check if importance is greater than maximum allowable 
       * value then use the maximum allowable value only
       */
      if (conEvnt->imp.val > MAXCRIMP)
         cb->imp.val = MAXCRIMP;
      else
         cb->imp.val = conEvnt->imp.val;

      /* mark prsence of importance */
      cb->imp.pres = PRSNT_NODEF;
   }
   else
   {
      /* message importance is not present, use default value for
       * traffic limitation procedure but do not mark presence of
       * importance to avoid sending it in outgoing CR
       */
      cb->imp.val = spCb.spMsgImp.defCrImp;
   }
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* set up connection section */
   cb->cs[SIDE(cb)].conId.spId = sap->spId;   /* service provider id */
   cb->cs[SIDE(cb)].conId.suId = sap->suId;   /* service user id */
   /* sp045.302 - addition - save the network CB ptr of the network
    * from which CR was received in the SIDE(cb) 
    */
   cb->cs[SIDE(cb)].nwData = sap->nwData;     /* calling side network CB */
   /* initialise called side nwData */
   cb->cs[OPSIDE(cb)].nwData = sap->nwData;   /* called side network CB */
   cb->state = RDY_ST;                        /* connection state ready */
   cb->cType = 0;                             /* con type set to zero */
   cb->sap = sap;                             /* service access point */
   cb->cs[SIDE(cb)].nSap = NULLP;             /* service access point */
   cb->qos.pClass = conEvnt->qos.pClass;      /* protocol class */
   cb->qos.retOpt = conEvnt->qos.retOpt;      /* return options */
   cb->qos.credit = conEvnt->qos.credit;      /* credit */
   cb->info = (PTR) conEvnt;                  /* attach the event */

   cb->hopCntr.pres = FALSE;                  /* hop counter presence */
   cb->hopCntr.val = 0;                       /* hop counter value */

   /* sp020.302 - addition - assign priority. Priority can be in the range
    * 0 to 1. In our implementation we will always use priority 0 for CR, DT
    * and AK messages.
    */
   cb->prior = (Prior) 0;

#ifdef ZP
   {
      ZpAMSpConCb zpAMSpConCb;
      
      zpAMSpConCb.intfc = CMFTHA_IF_UPPER;
      zpAMSpConCb.conEvnt = conEvnt;
                  
      zpAddMapping(ZP_SP_CONCB, (Void *) cb, &zpAMSpConCb);
   }
#endif

   /* Insert the reference number in the connection control block */
   if (!spInsertConRef(cb))   
   {
      SpDisEvnt dis;   /* sp026.302 - addition - disInd to user */

      SPLOGERROR(ERRCLS_INT_PAR, ESP058, (ErrVal) ERRZERO,
                 "cannot allocate a reference number for the connection");

      /* sp026.302 - addition - generate disInd to user. */
      cmCopy((U8 *) &conEvnt->conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
      dis.rspAddr.pres = TRUE;
      dis.rspAddr.pc = sap->nwData->selfPc;
      dis.rsn =  RFC_NRQOST;
      dis.orig = ORIG_NET;
#ifdef SPTV2
      /* importance is not relevant in indication to user */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

#ifdef ZP
      /* sp028.302 - addition - delete mapping */
      zpDelMapping(ZP_SP_CONCB, (Void *) cb);
#endif /* ZP */

      SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) cb, 
               (Size)sizeof(SpConCb));
      (Void) SpUiSptDisInd(&sap->pst, &dis, data);
      /* sp011.302 - Should drop message if we reach this exception case */
      /* sp026.302 - removal - data returned in disInd above. */
      RETVALUE(RFAILED);
   }

   /* jump into upper interface state machine */
   spUiConMt[evnt][RDY_ST](cb, data);

   RETVALUE(ROK);
} /* SpUiSptConReq */


/*
*
*       Fun:   SpUiSptConRsp
*
*       Desc:  Connection Response
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptConRsp
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event */
Buffer *data                    /* buffer */
)
#else
PUBLIC S16 SpUiSptConRsp(pst, conEvnt, data)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event */
Buffer *data;                   /* buffer */
#endif
{
   SpConCb *cb;
   SpSapCb *sap;

   TRC3(SpUiSptConRsp)

   UNUSED(pst);

/* sp039.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptConRsp() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptConRsp(pst, conEvnt->type (%d)\n", conEvnt->type));

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((conEvnt->conId.spId >= (SpId)spCb.spCfg.nmbSaps) || 
       (conEvnt->conId.spId < 0) )
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)conEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb*)NULLP) || (spCb.status & SP_GUARD))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   cb = spLookUpConCbAndSetSide(sap->nwData, conEvnt->conId.spInstId);
   if ( cb == (SpConCb*)NULLP) 
   {                             /* NO CONTROL BLOCK, bummer... */
      spDisInd(&conEvnt->conId, RLC_INCONDT, ORIG_NET, data);
      RETVALUE(ROK);
   }

   /* stop connection timer */
   spRmvConCbTq(cb, CON_TMR);

   /* we must be the called side so update called info */

   cb->cType = SP_DEST;
   cb->cs[SIDE(cb)].conId.suInstId = conEvnt->conId.suInstId;

   if ((conEvnt->qos.pClass != cb->qos.pClass) &&
       ((conEvnt->qos.pClass == PCLASS2) || (conEvnt->qos.pClass == PCLASS3)))
      cb->qos.pClass = conEvnt->qos.pClass;

   if ( (cb->qos.pClass == PCLASS3))
   {
      /* reset credit... */
      cb->qos.credit = conEvnt->qos.credit;

      /* set up current window for opposite side */
      cb->cs[OPSIDE(cb)].txWin = cb->qos.credit;
      cb->cs[OPSIDE(cb)].rxWin = cb->qos.credit;
   }

   /* assign importance to connection response event */
#ifdef SPTV2
   if (conEvnt->imp.pres == PRSNT_NODEF)
   {
      /* check if importance is greater than maximum allowable 
       * value then use the maximum allowable value only
       */
      if (conEvnt->imp.val > MAXCCIMP)
         cb->imp.val = MAXCCIMP;
      else
         cb->imp.val = conEvnt->imp.val;

      /* mark presence of importance */
      cb->imp.pres = PRSNT_NODEF;
   }
   else
   {
      /* message importance is not present, use default value for
       * traffic limitation procedure but do not mark presence of
       * importance to avoid sending it within CC
       */
      cb->imp.val = spCb.spMsgImp.defCcImp;
   }
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* jump into upper interface state machine */
   /*        EVNT_IDX   STATE                 */
   spUiConMt[SP_CONRSP][cb->state](cb, data);
#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   RETVALUE(ROK);
} /* end of SpUiSptConRsp */

/*
*
*       Fun:   SpUiSptDatReq
*
*       Desc:  Data Request 
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDatReq
(
Pst *pst,                       /* post structure */
SpDatEvnt *datEvnt,             /* data event */
Buffer *data                    /* buffer */
)
#else
PUBLIC S16 SpUiSptDatReq(pst, datEvnt, data)
Pst *pst;                       /* post structure */
SpDatEvnt *datEvnt;             /* data event */
Buffer *data;                   /* buffer */
#endif
{
   SpConCb *cb;                 /* call control block */
   SpSapCb* sap;                /* sap */

   TRC3(SpUiSptDatReq)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptDatReq() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptDatReq(pst, suId (%d), spId (%d), suInstId (%ld), spInstId (%ld), cfmReq (%d)\n", datEvnt->conId.suId, datEvnt->conId.spId,
          datEvnt->conId.suInstId, datEvnt->conId.spInstId, datEvnt->cfmReq));

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((datEvnt->conId.spId >= (SpId)spCb.spCfg.nmbSaps) || 
       (datEvnt->conId.spId < 0) )
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR) datEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb *) NULLP) || (spCb.status & SP_GUARD))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   cb = spLookUpConCbAndSetSide(sap->nwData, datEvnt->conId.spInstId);
   if ( cb == (SpConCb *) NULLP) 
   {                             /* NO CONTROL BLOCK */
      spDisInd(&datEvnt->conId, RLC_INCONDT, ORIG_NET, data);
      RETVALUE(ROK);
   }

   /* assign importance to data request event */
#ifdef SPTV2
   if (datEvnt->imp.pres == PRSNT_NODEF)
   {
      /* check if importance is greater than maximum allowable 
       * value then use the maximum allowable value only
       */
      if (datEvnt->imp.val > MAXDT1IMP)
         cb->imp.val = MAXDT1IMP;
      else
         cb->imp.val = datEvnt->imp.val;

      /* mark presence of importance */
      cb->imp.pres = PRSNT_NODEF;
   }
   else
   {
      /* message importance is not present, use default value for
       * traffic limitation procedure but do not mark presence of
       * importance
       */
      cb->imp.val = spCb.spMsgImp.defDt1Imp;
   }
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* update statistics for DT1/DT2 messages sent from this sap */
   if (cb->qos.pClass == PCLASS2)
      sap->sts.dt1MsgTx++;
   else
      sap->sts.dt2MsgTx++;

   /* jump into upper interface state machine */
   spUiConMt[SP_DATREQ][cb->state](cb, data);
   RETVALUE(ROK);
} /* SpUiSptDatReq */


/*
*
*       Fun:   SpUiSptEDatReq
*
*       Desc:  Expedited Data Request 
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptEDatReq
(
Pst *pst,                       /* post structure */
SpConId *conId,                 /* connection id */
Buffer *data                    /* buffer */
)
#else
PUBLIC S16 SpUiSptEDatReq(pst, conId, data)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
Buffer *data;                   /* buffer */
#endif
{
   SpConCb *cb;                 /* call control block */
   SpSapCb* sap;                /* sap */

   TRC3(SpUiSptEDatReq)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptEDatReq() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptEDatReq(pst, suId (%d), spId (%d), suInstId (%ld), spInstId (%ld)\n", conId->suId, conId->spId, conId->suInstId, conId->spInstId));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((conId->spId >= (SpId)spCb.spCfg.nmbSaps) || (conId->spId < 0))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)conId->spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb *) NULLP) || (spCb.status & SP_GUARD))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   conId->suId = sap->suId;
   
   cb = spLookUpConCbAndSetSide(sap->nwData, conId->spInstId);
   if (cb == (SpConCb*)NULLP) 
   {                             /* NO CONTROL BLOCK, bummer... */
      spDisInd(conId, RLC_INCONDT, ORIG_NET, data);
      RETVALUE(ROK);
   }

   /* verify that this connection provides class 3 service */
   if (cb->qos.pClass != PCLASS3)
   {
      spDropMsg(&data);
      spRelease(cb, SIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
      spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);
    
      /* Update statistics */
      spCb.sts.prvInitRel++;

      RETVALUE(ROK);
   }

   /* assign default inportance value for message ED, as importance
    * is not passed within ED primitive event from user
    */
#ifdef SPTV2
   cb->imp.val = spCb.spMsgImp.defEdImp;
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* update statistics for ED messages sent from this sap */
   sap->sts.edMsgTx++;

   /* jump into upper interface state machine */
   spUiConMt[SP_EDATREQ][cb->state](cb, data);

   RETVALUE(ROK);
} /* SpUiSptEDatReq */


/*
*
*       Fun:   SpUiSptDatAckReq
*
*       Desc:  Data Acknowledgement Request 
*
*       Ret:   ROK   - ok
*
*       Notes: For further study...
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDatAckReq
(
Pst *pst,                       /* post structure */
SpConId *conId                  /* connection id */
)
#else
PUBLIC S16 SpUiSptDatAckReq(pst, conId)
Pst *pst;                       /* post structure */
SpConId *conId;                 /* connection id */
#endif
{
   TRC3(SpUiSptDatAckReq)

   UNUSED(pst);
#ifndef DEBUGP
  UNUSED(conId);
#endif /* DEBUGP */
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptDatAckReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, 
          "SpUiSptDatAckReq(pst, suId (%d), spId (%d), suInstId (%ld), spInstId (%ld)\n", conId->suId, conId->spId, conId->suInstId, conId->spInstId));

   RETVALUE(ROK);
} /* end of SpUiSptDatAckReq */


/*
*
*       Fun:   SpUiSptRstReq
*
*       Desc:  Reset Request
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptRstReq
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 SpUiSptRstReq(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   SpConCb *cb;                 /* call control block */
   SpSapCb* sap;                /* sap */

   TRC3(SpUiSptRstReq)

   UNUSED(pst);

/* sp039.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptRstReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));
#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf,
          "SpUiSptRstReq(pst, rsn (%d), orig(%d)\n", rstEvnt->rsn,
          rstEvnt->orig));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if (( rstEvnt->conId.spId >= (SpId)spCb.spCfg.nmbSaps) || 
       ( rstEvnt->conId.spId < 0) )
      RETVALUE(RFAILED);
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)rstEvnt->conId.spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb*)NULLP) || (spCb.status & SP_GUARD))
      RETVALUE(RFAILED);
#endif /* ERRCLASS */

   cb = spLookUpConCbAndSetSide(sap->nwData, (U32)(rstEvnt->conId.spInstId));
   if ( cb == (SpConCb*)NULLP) 
   {                             /* NO CONTROL BLOCK, bummer... */
      spDisInd(&rstEvnt->conId, RLC_INCONDT, ORIG_NET, NULLP);
      RETVALUE(ROK);
   }

   if (cb->qos.pClass != PCLASS3)
   {
      /* somebody blew it */
      spDisInd(&rstEvnt->conId, RFC_NRQOST, ORIG_NET, NULLP);
      RETVALUE(ROK);
   }

   /* assign default inportance value for message RSR, as importance
    * is not passed within RSR primitive event from user
    */
#ifdef SPTV2
   cb->imp.val = spCb.spMsgImp.defRsrImp;
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   cb->info = (PTR)rstEvnt;
   /* jump into upper interface state machine */
   spUiConMt[SP_RSTREQ][cb->state](cb, NULLP);

   RETVALUE(ROK);
} /* end of SpUiSptRstReq */


/*
*
*       Fun:   SpUiSptRstRsp
*
*       Desc:  Reset Response
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptRstRsp
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 SpUiSptRstRsp(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   SpConCb *cb;                 /* call control block */
   SpSapCb* sap;                /* sap */

   TRC3(SpUiSptRstRsp)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptRstRsp() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptRstRsp(pst)\n"));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((rstEvnt->conId.spId >= (SpId)spCb.spCfg.nmbSaps) || 
       (rstEvnt->conId.spId < 0))
      RETVALUE(RFAILED);
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)rstEvnt->conId.spId);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb*)NULLP) || (spCb.status & SP_GUARD))
      RETVALUE(RFAILED);
#endif /* ERRCLASS */

   cb = spLookUpConCbAndSetSide(sap->nwData, rstEvnt->conId.spInstId);
   if ( cb == (SpConCb*)NULLP) 
   {                             /* NO CONTROL BLOCK, bummer... */
      spDisInd(&rstEvnt->conId, RLC_INCONDT, ORIG_NET, NULLP);
      RETVALUE(ROK);
   }

   if (cb->qos.pClass != PCLASS3)
   {
      /* somebody blew it */
      spDisInd(&rstEvnt->conId, RFC_NRQOST, ORIG_NET, NULLP);
      RETVALUE(ROK);
   }

   /* assign default inportance value for message RSC, as importance
    * is not passed within RSC primitive event from user
    */
#ifdef SPTV2
   cb->imp.val = spCb.spMsgImp.defRscImp;
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   cb->info = (PTR)rstEvnt;
   /* jump into upper interface state machine */
   spUiConMt[SP_RSTRSP][cb->state](cb, NULLP);

   RETVALUE(ROK);
} /* end of SpUiSptRstRsp */

/*
*
*       Fun:   SpUiSptDisReq
*
*       Desc:  Disconnect Request.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptDisReq
(
Pst *pst,
SpDisEvnt *disEvnt,       /* disconnect event */
Buffer* data              /* data buffer */
)
#else
PUBLIC S16 SpUiSptDisReq(pst, disEvnt, data)
Pst *pst;
SpDisEvnt *disEvnt;       /* disconnect event */
Buffer* data;             /* data buffer */
#endif
{
   SpSapCb* sap;          /* upper sap control block */
   SpConCb *cb;           /* connection control block */

   TRC3(SpUiSptDisReq)

   UNUSED(pst);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptDisReq() failed, cannot derive spCb");
      /* sp048.302 - addition - free buffer */
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptDisReq(pst)\n"));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((disEvnt->conId.spId >= (SpId) spCb.spCfg.nmbSaps) || 
       (disEvnt->conId.spId < 0))
      RETVALUE(RFAILED);
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR) disEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb *) NULLP) || (spCb.status & SP_GUARD))
   {
      spDropMsg(&data);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   cb = spLookUpConCbAndSetSide(sap->nwData, disEvnt->conId.spInstId);
   if (cb == (SpConCb *) NULLP) 
   {                             /* NO CONTROL BLOCK */
      spDisInd(&disEvnt->conId, RLC_INCONDT, ORIG_NET, data);
      RETVALUE(ROK);
   }

   /* if I'm originating side, and I don't yet have
    * an opposite side instance id (i.e. no connection confirm yet),
    * set flag and RETVALUE
    */
   if (cb->cType & SP_ORIG && !cb->cs[OPSIDE(cb)].conId.spInstId)
   {
      cb->cbFlags |= CG_RCVD_DIS; /* set received disconnect flag */
      if (data)
         spDropMsg(&data);
      RETVALUE(ROK);
   }

#ifdef SPTV2
   /* assign importance to disconnection event based on whether
    * primitive is invoked to refuse connection establishment or
    * or relase of an established connection
    */
   switch (cb->state)
   {
      case RDY_ST:   /* fall through */
      case CON_ST:
         /* disconnect request is for refusal of conn establishment */
         if (disEvnt->imp.pres == PRSNT_NODEF)
         {
            /* check if importance is greater than maximum allowable 
             * value then use the maximum allowable value only
             */
            if (disEvnt->imp.val > MAXCREFIMP)
               cb->imp.val = MAXCREFIMP;
            else
               cb->imp.val = disEvnt->imp.val;

            /* mark presence of importance */
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* message importance is not present, use default value for
             * traffic limitation procedure but do not mark presence of
             * importance to avoid sending it within CREF
             */
            cb->imp.val = spCb.spMsgImp.defCrefImp;
         }
         break;

      default:
         /* discon request is for release of a connection */
         if (disEvnt->imp.pres == PRSNT_NODEF)
         {
            /* check if importance is greater than maximum allowable 
             * value then use the maximum allowable value only
             */
            if (disEvnt->imp.val > MAXRLSDIMP)
               cb->imp.val = MAXRLSDIMP;
            else
               cb->imp.val = disEvnt->imp.val;

            /* mark presence of importance */
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* message importance is not present, use default value for
             * traffic limitation procedure but do not mark presence of
             * importance to avoid sending it within RLSD
             */
            cb->imp.val = spCb.spMsgImp.defRlsdImp;
         }
         break;
   } /* switch (cb->state) */
#else
   cb->imp.pres = NOTPRSNT;
#endif /* SPTV2 */

   /* disconnect request can come from either side of a connection */

   /* pass along event to matrix function */
   cb->info = (PTR) disEvnt;

   /* jump into upper interface state machine */
   /*        EVNT_IDX   STATE                 */
   spUiConMt[SP_DISREQ][cb->state](cb, data);

   RETVALUE(ROK);
} /* SpUiSptDisReq */


/*
*
*       Fun:   SpUiSptInfReq
*
*       Desc:  Information Request
*
*       Ret:   ROK   - ok
*
*       Notes: For further study...
*
*       File:  cp_bdy1.c
*
*/
#ifdef ANSI
PUBLIC S16 SpUiSptInfReq
(
Pst *pst,                       /* post structure */
SpInfEvnt *infEvnt              /* inform event */
)
#else
PUBLIC S16 SpUiSptInfReq(pst, infEvnt)
Pst *pst;                       /* post structure */
SpInfEvnt *infEvnt;             /* inform event */
#endif
{
   TRC3(SpUiSptInfReq)

   UNUSED(pst);
   UNUSED(infEvnt);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptInfReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptRstReq(pst)\n"));

   RETVALUE(ROK);
} /* end of SpUiSptInfReq */
#endif /* SPCO */

#ifdef SP_FTHA

/*
 *
 *       Fun  :  System agent control Request 
 *
 *       Desc :  Processes system agent control request primitive
 *
 *       Ret  :  ROK  - ok
 *
 *       Notes:  None
 *
 *       File :  sp_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpMiShtCntrlReq
(
Pst *pst,                    /* post structure */
ShtCntrlReqEvnt *reqInfo     /* system agent control request event */
)
#else
PUBLIC S16 SpMiShtCntrlReq(pst, reqInfo)
Pst *pst;                    /* post structure */
ShtCntrlReqEvnt *reqInfo;    /* system agent control request event */
#endif
{
   Pst repPst;               /* reply post structure */
   ShtCntrlCfmEvnt cfmInfo;  /* system agent control confirm event */
   SpNSapCb *nsap;           /* NSAP control block */         
   SpSapCb *sap;             /* SAP control block */ 
   U8 i;                     /* loop counter */
   S16 ret;                  /* return value */
#ifdef SP_RUG
   U16 idx;                  /* index to find interface version info entry */
   S32 j;                    /* loop counter */
#endif /* SP_RUG */

   TRC3 (SpMiShtCntrlReq);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpMiShtCntrlReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
        pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

#ifdef ZP
   /* checking critical resource set is not required for getver
    * and setver, as these control requests can come before
    * critical resource set is made active
    */
#ifdef SP_RUG
   if ((reqInfo->reqType != SHT_REQTYPE_GETVER) &&
       (reqInfo->reqType != SHT_REQTYPE_SETVER))
#endif /* SP_RUG */
   {
      if (!zpCheckCritical())
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP059, (ErrVal) 0, 
                    "SpMiShtCntrlReq() recd in invalid PSF state ");
         spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                     LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
         RETVALUE(ROK);
      }
   }
#endif /* ZP */

   /* sp001.302 - addition - initialize cfmInfo */
   cmZero((U8 *) &cfmInfo, sizeof(ShtCntrlCfmEvnt));

   /* fill reply pst structure */
   repPst.dstProcId = pst->srcProcId;
   repPst.dstEnt    = pst->srcEnt;
   repPst.dstInst   = pst->srcInst;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.route     = reqInfo->hdr.response.route;
   repPst.selector  = reqInfo->hdr.response.selector;
   repPst.prior     = reqInfo->hdr.response.prior;
   repPst.region    = reqInfo->hdr.response.mem.region;
   repPst.pool      = reqInfo->hdr.response.mem.pool;
   repPst.event     = EVTSHTCNTRLCFM;
   repPst.srcProcId = pst->dstProcId;
   repPst.srcEnt    = ENTSP;
   repPst.srcInst   = pst->dstInst;

   /* fill reply transaction Id */
   cfmInfo.transId = reqInfo->hdr.transId;

   /* fill request type */
#ifdef SP_RUG
   cfmInfo.reqType = reqInfo->reqType;
#endif /* SP_RUG */

   /* check if general configuration done */
   if (spCb.spInit.cfgDone != TRUE)
   {
      cfmInfo.status.status = LCM_PRIM_NOK;
      cfmInfo.status.reason = LCM_REASON_GENCFG_NOT_DONE;
      
      SpMiShtCntrlCfm(&repPst, &cfmInfo);
      RETVALUE(ROK);
   }

   /* fill status value */
   cfmInfo.status.reason = LCM_REASON_NOT_APPL;
    
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         switch (reqInfo->s.bndEna.grpType)
         {
            case SHT_GRPTYPE_ALL: 
               /* always done only for Lower SAP */
               for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
               {
                  nsap = spCb.nSapList[i];
                  if ((nsap != (SpNSapCb *) NULLP) &&
                      (nsap->pst.dstProcId == reqInfo->s.bndEna.dstProcId) &&
                      (nsap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                      (nsap->pst.dstInst == reqInfo->s.bndEna.dstEnt.inst) &&
                      (nsap->contEnt != ENTSM))
                  {
                     ret = spEnableLowerSap(nsap, &cfmInfo.status.reason);
#ifdef ZP
                     /* check return val and generate RT update accordingly */
                     if (ret == ROK)
                        zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nsap, 
                                     CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                  }
               }
               break;
               
            case SHT_GRPTYPE_ENT:
               for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
               {
                  nsap = spCb.nSapList[i];
                  if ((nsap != (SpNSapCb *) NULLP) &&
                      (nsap->pst.dstEnt == reqInfo->s.bndEna.dstEnt.ent) &&
                      (nsap->pst.dstInst == reqInfo->s.bndEna.dstEnt.inst) &&
                      (nsap->contEnt != ENTSM))
                 {
                    ret = spEnableLowerSap(nsap, &cfmInfo.status.reason);
#ifdef ZP
                    /* check return val and generate RT update accordingly */
                    if (ret == ROK)
                       zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nsap, 
                                    CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                 }
               }
               break;
 
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
               break;
         }
         break;

      case SHT_REQTYPE_UBND_DIS:  /* system agent control unbind disable */
         switch (reqInfo->s.ubndDis.grpType)
         {
            case SHT_GRPTYPE_ALL:
               for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
               {
                  nsap = spCb.nSapList[i];
                  if ((nsap != (SpNSapCb *) NULLP) &&
                      (nsap->pst.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                      (nsap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (nsap->pst.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (nsap->contEnt != ENTSM))
                  {
                     spDisableLowerSap(nsap);
#ifdef ZP
                     zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nsap, 
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                  }
               }
               for (i = 0; i < spCb.spCfg.nmbSaps; i++)
               {
                  sap = spCb.sapList[i];
                  if ((sap != (SpSapCb *) NULLP) &&
                      (sap->pst.dstProcId == reqInfo->s.ubndDis.dstProcId) &&
                      (sap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (sap->pst.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     spDisableUpperSap(sap);
#ifdef ZP
                     zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap,
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                  }
               }
#ifdef SP_RUG
               /* delete stored version info */
               for (j = spCb.numIntfInfo - 1; j >= 0; j--)
               {
                  if ((spCb.spVerInfoCb[j].intfInfo.grpType == 
                                         reqInfo->s.ubndDis.grpType) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstProcId ==
                                         reqInfo->s.ubndDis.dstProcId) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.ent ==
                                         reqInfo->s.ubndDis.dstEnt.ent) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.inst ==
                                         reqInfo->s.ubndDis.dstEnt.inst))
                  {
#ifdef ZP
                     /* run time update peer - first we update peer, as in
                      * in deletion of verinfo we just copy last verinfo into
                      * current location and so current location if getting
                      * modified
                      */
                     zpRunTimeUpd(ZP_SP_VERINFOCB, (Void *)&spCb.spVerInfoCb[j],
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL);

#endif /* ZP */
                     /* delete verson info by copying the last version info
                        into current location */
                     cmCopy(
                        (U8 *)&spCb.spVerInfoCb[spCb.numIntfInfo - 1].intfInfo,
                        (U8 *)&spCb.spVerInfoCb[j].intfInfo, 
                         sizeof(ShtVerInfo));
#ifdef ZP
                     /* delete verinfo cb from DLL within rsetCb - as in
                        in deletion last verinfo is being copied to current
                        location, deletion of cb from DLL will always be for
                        the last verinfo */
                     zpDelMapping(ZP_SP_VERINFOCB,
                              (Void *) &spCb.spVerInfoCb[spCb.numIntfInfo - 1]);
#endif /* ZP */
                     /* decrement number of intInfo */
                     spCb.numIntfInfo--;
                  }
               }
#endif /* SP_RUG */
               break;

            case SHT_GRPTYPE_ENT:
               for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
               {
                  nsap = spCb.nSapList[i];
                  if ((nsap != (SpNSapCb *) NULLP) &&
                      (nsap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (nsap->pst.dstInst == reqInfo->s.ubndDis.dstEnt.inst) &&
                      (nsap->contEnt != ENTSM))
                  {
                     spDisableLowerSap(nsap);
#ifdef ZP
                     zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nsap, 
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                  }
               }
               for (i = 0; i < spCb.spCfg.nmbSaps; i++)
               {
                  sap = spCb.sapList[i];
                  if ((sap != (SpSapCb *) NULLP) &&
                      (sap->pst.dstEnt == reqInfo->s.ubndDis.dstEnt.ent) &&
                      (sap->pst.dstInst == reqInfo->s.ubndDis.dstEnt.inst))
                  {
                     spDisableUpperSap(sap);
#ifdef ZP
                     zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap,
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
                  }
               }
#ifdef SP_RUG
               /* delete of stored version info */
               for (j = spCb.numIntfInfo - 1; j >= 0; j--)
               {
                  if ((spCb.spVerInfoCb[j].intfInfo.grpType == 
                                         reqInfo->s.ubndDis.grpType) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.ent ==
                                         reqInfo->s.ubndDis.dstEnt.ent) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.inst ==
                                         reqInfo->s.ubndDis.dstEnt.inst))
                  {
#ifdef ZP
                     /* run time update peer - first we update peer, as in
                        in deletion of verinfo we just copy last verinfo into
                        current location and so current location if getting
                        modified */
                     zpRunTimeUpd(ZP_SP_VERINFOCB, (Void *)&spCb.spVerInfoCb[j],
                                  CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL);

#endif /* ZP */
                     /* delete verson info by copying the last version info
                        into current location */
                     cmCopy(
                        (U8 *) &spCb.spVerInfoCb[spCb.numIntfInfo - 1].intfInfo,
                        (U8 *) &spCb.spVerInfoCb[j].intfInfo, 
                        sizeof(ShtVerInfo));
#ifdef ZP
                     /* delete verinfo cb from DLL within rsetCb - as in
                        in deletion last verinfo is being copied to current
                        location, deletion of cb from DLL will always be for
                        the last verinfo */
                     zpDelMapping(ZP_SP_VERINFOCB,
                              (Void *) &spCb.spVerInfoCb[spCb.numIntfInfo - 1]);
#endif /* ZP */
                     /* decrement number of intInfo */
                     spCb.numIntfInfo--;
                  }
               }
#endif /* SP_RUG */
               break;
            default:
               cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
               break;
         }
         break;

#ifdef SP_RUG
      case SHT_REQTYPE_GETVER:  /* system agent control get interface version */
         spGetVer(&cfmInfo.t.gvCfm);
         break;
      case SHT_REQTYPE_SETVER:  /* system agent control set interface version */
         ret = spSetVer(&reqInfo->s.svReq, &cfmInfo.status, &idx);
#ifdef ZP
         /* check whether version info is valid and needs to be added and
            updated or only needs run time updation. if ret is SP_NOP, then
            either interface info validation is failed or version info is
            for peer interface. In case of peer interface, run time updation 
            will be done from within zpSetVer itself. In case of invalid 
            version info, reason is returned within status */
         if (ret != SP_NOP)
         {
            if (ret == SP_ADD)
            {
               /* add mapping of version info cb to DLL in resource set cb */
               zpAddMapping(ZP_SP_VERINFOCB, (Void *) &spCb.spVerInfoCb[idx], 
                            NULLP);
            }
            /* update interface version info */
            zpRunTimeUpd(ZP_SP_VERINFOCB, (Void *) &spCb.spVerInfoCb[idx],
                         CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
         }
#endif /* ZP */

         break;
#endif /* SP_RUG */
         
      default:
         cfmInfo.status.reason = LCM_REASON_INVALID_PAR_VAL;
         break;
   }

   /* response is sent without waiting for bind or unbind to complete */
   /* if we are not able to find any SAP to start bind enable or
      unbind disable, still a success response is returned by the
      protocol layer */

   if (cfmInfo.status.reason != LCM_REASON_NOT_APPL)
      cfmInfo.status.status = LCM_PRIM_NOK;
   else
      cfmInfo.status.status = LCM_PRIM_OK;
   
#ifdef ZP
   zpUpdPeer();
#endif /* ZP */

   /* send the response */
   SpMiShtCntrlCfm(&repPst, &cfmInfo);
       
   RETVALUE(ROK);
} /* end SpMiShtCntrlReq */
#endif /* FTHA */

#ifdef SPCO
#ifdef SPTV2

/*
 *
 *       Fun  :  Audit Request initiated by SCCP User
 *
 *       Desc :  Audit Request request primitive handling initiated by
 *               by SCCP user. Audit request will handle the monitoring
 *               of signalling connection.
 *
 *       Ret  :  ROK  - operation successful
 *               RFAILED - operation failed
 *
 *       Notes:  None
 *
 *       File :  sp_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpUiSptAudReq
(
Pst *pst,                        /* post structure */
SpAudEvnt *audEvnt               /* pointer to Audit Evnt struct */
)
#else
PUBLIC S16 SpUiSptAudReq(pst, audEvnt)
Pst *pst;                        /* post structure */
SpAudEvnt *audEvnt;              /* pointer to Audit Evnt struct */
#endif
{
   SpSapCb *sap;                 /* pointer to SAP control block */
   SpConCb *cb;                  /* pointer to connection control block */

   TRC3(SpUiSptAudReq)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptAudReq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
      pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif
   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptAudReq(pst)\n"));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((audEvnt->conId.spId >= (SpId) spCb.spCfg.nmbSaps) || 
       (audEvnt->conId.spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP060, (ErrVal) audEvnt->conId.spId,
                 "SpUiSptAudReq : Invalid spId in AudEvnt");           

      /* send alarm to LM  */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSPTAUDREQ, (U8) audEvnt->conId.spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR) audEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb*)NULLP) || (spCb.status & SP_GUARD))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP061, (ErrVal) audEvnt->conId.spId,
                 "SpUiSptAudReq : Invalid sap state");           
      /* send alarm to LM  */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSPTAUDREQ, (U8) audEvnt->conId.spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* Get the connection control Block */
   cb = spLookUpConCbAndSetSide(sap->nwData, audEvnt->conId.spInstId);
   if ( cb == (SpConCb *) NULLP)
   {
      /* return state as invalid */
      audEvnt->state = CON_STATE_INV;
   }
   else
   {
      switch (cb->state)
      {
         case RDY_ST: /* Signalling con. state is READY */
         case CON_ST: /* Signalling con. state is connecting */
            /* if the state of connection is ready or connecting, send state
             * as connecting
             */
            audEvnt->state = CON_STATE_CON;
            break;
         case DTX_ST: /* Signalling con. state is data transfer */
         case RCG_ST: /* Signalling con. state is reset calling side */
         case RCD_ST: /* Signalling con. state is reset called side */
         case RBT_ST: /* Signalling con. state is reset both side */
            /* if connection is in any of the above mentioned state then
             * send the state as data transfer state 
             */
            audEvnt->state = CON_STATE_DTX;
            break;
         case RLS_ST: /* Signalling con. state is releasing */
            /* send the state as releasing */
            audEvnt->state = CON_STATE_RLS;
            break;
      } /* swtch (cb->state) */
   }

   /* Return audit confirm to user */
   (Void) SpUiSptAudCfm(&sap->pst, audEvnt);
   RETVALUE(ROK);
} /* SpUiSptAudReq */


/*
 *
 *       Fun  :  Audit Response by SCCP User on audit indication
 *
 *       Desc :  Audit Response for audit indiaction. SCCP verifies the state
 *               consistency of connection with the self stored state .If
 *               connection states are inconsistent ,then the connection is 
 *               released.
 *
 *       Ret  :  ROK  - operation successful
 *               RFAILED - operation failed
 *
 *       Notes:  None
 *
 *       File :  sp_bdy1.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpUiSptAudRsp
(
Pst *pst,                        /* post structure */
SpAudEvnt *audEvnt               /* pointer to Audit Evnt sruct */
)
#else
PUBLIC S16 SpUiSptAudRsp(pst, audEvnt)
Pst *pst;                        /* post structure */ 
SpAudEvnt *audEvnt;              /* pointer to Audit Evnt sruct */
#endif
{
   SpSapCb *sap;                 /* pointer to SAP control block */
   SpConCb *cb;                  /* pointer to connection control block */

   TRC3(SpUiSptAudRsp)

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(pst->dstProcId,pst->dstEnt,pst->dstInst, (Void **)&spCbPtr)) != ROK)
   {
      /* sp049.302 - modification - using SPERROR instead of SPLOGERROR
       * to avoid using spCb as it can cause crash if spCb is NULLP.
       */
      SPERROR(pst, ERRCLS_DEBUG, ESPXXX, 0, "SpUiSptAudRsp() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
            "-----------SCCP--------(proc(%d),ent(%d),inst(%d))------\n",
            pst->dstProcId,pst->dstEnt,pst->dstInst));

#endif

   SPDBGP(DBGMASK_UI, (spCb.spInit.prntBuf, "SpUiSptAudReq(pst)\n"));

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate spId */
   if ((audEvnt->conId.spId >= (SpId)spCb.spCfg.nmbSaps) || 
       (audEvnt->conId.spId < 0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP062, (ErrVal) audEvnt->conId.spId,
                 "SpUiSptAudRsp : Invalid spId in AudEvnt");           

      /* send alarm to LM with cause LCM_CAUSE_INV_SPID */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSPTAUDRSP, (U8) audEvnt->conId.spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   sap = *(spCb.sapList + (PTR)audEvnt->conId.spId);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((sap == (SpSapCb*)NULLP) || (spCb.status & SP_GUARD))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP063, (ErrVal) audEvnt->conId.spId,
                 "SpUiSptAudRsp : Invalid sap state");           

      /* send alarm to LM with cause LCM_CAUSE_INV_SPID */
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT,
                  LCM_CAUSE_INV_SPID, EVTSPTAUDRSP, (U8) audEvnt->conId.spId);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* Get the connection control Block */
   cb = spLookUpConCbAndSetSide(sap->nwData, audEvnt->conId.spInstId);
   if (cb == (SpConCb*)NULLP)
   {
      /* return state as invalid */
      audEvnt->state = CON_STATE_INV;
   } /* end for null connection control block */
   else
   { 
      /* Inititate normal connection release in case state 
       * at user is invalid 
       */
      if (audEvnt->state == CON_STATE_INV)
      {
         spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));
         spRmvConCbTq(cb, IAR_TMR(OPSIDE(cb)));
         spFreezeSlr(cb, FRZ_SIDE(SIDE(cb))); /* freeze calling side */
         spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         RETVALUE(ROK);
      } /* conn state at user is invalid */
      else 
      {  /* conn state at user is valid */
         /* match the Connection state and inititate connection
          * release in case state at user is invalid 
          */
         switch(cb->state) /* state of connection at SCCP */
         {
            case DTX_ST:  /* at SCCP ,state is data transfer */
            case RCG_ST:  /* at SCCP ,state is reset calling side */
            case RCD_ST:  /* at SCCP ,state is reset called side */
            case RBT_ST:  /* at SCCP ,state is reset both side */ 
            
               /* at user state shud be data transfer only */
               if (audEvnt->state != CON_STATE_DTX)
               {
                  /* initiate conection release */ 
                  SpDisEvnt dis;                   /* Disconnect event struct */
  
                  /* Initialise DisEvnt structure */  
                  cmCopy((U8 *) &audEvnt->conId, (U8 *) &dis.conId, 
                         sizeof(SpConId));
                  cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
                  /* sp004.302 - addition - fill responding address */
                  dis.rspAddr.pres = TRUE;
                  dis.rspAddr.pc = cb->sap->nwData->selfPc;
                  dis.rsn = RLC_INCONDT; /* rel cause :Data Inconsistency */
                  dis.orig = ORIG_NET;
#ifdef SPTV2
                  /* importance is not relevant in disconnect indication */
                  dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
                  /* give Dinconnect indication to user */
                  if (cb->sap->status &SP_BND)
                     (Void) SpUiSptDisInd(&cb->sap->pst, &dis, NULLP);

                  spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));
                  spRmvConCbTq(cb, IAR_TMR(OPSIDE(cb)));
                  spFreezeSlr(cb, FRZ_SIDE(SIDE(cb))); /* freeze calling side */
                  spRelease(cb, OPSIDE(cb), RLC_INCONDT, ORIG_NET, NULLP);

                  /* sp034.302 - addition - free conCb if its in dead state */
                  if (cb->cType & SP_DEAD)
                     spFreeConCb(cb);

                  RETVALUE(ROK);
               } /* if (audEvnt->state != CON_STATE_DTX) */
               else
                  cb->nmbItTx = 0;
               break;

            case RLS_ST: /* at SCCP state is releasing */
               /* if at user state is not rel.,give user disconnect 
                * indication 
                */
               if (audEvnt->state !=CON_STATE_RLS)
               {
                  /* give Disconnect indication to user */
                  SpDisEvnt dis;

                  /* Initialise DisEvnt structure */  
                  cmCopy((U8 *) &audEvnt->conId, (U8*)&dis.conId, 
                         sizeof(SpConId));
                  cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
                  /* sp004.302 - addition - fill responding address */
                  dis.rspAddr.pres = TRUE;
                  dis.rspAddr.pc = cb->sap->nwData->selfPc;
                  dis.rsn = RLC_INCONDT; /* rel cause :Data Inconsistency */
                  dis.orig = ORIG_NET;
#ifdef SPTV2
                  /* importance is not relevant in indication primitive to
                   * user, mark it as not present
                   */
                  dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
                  /* give Dinconnect indication to user */
                  if (cb->sap->status & SP_BND)
                     (Void) SpUiSptDisInd(&cb->sap->pst, &dis, NULLP);
                  RETVALUE(ROK);
               } /* if (audEvnt->state !=CON_STATE_RLS) */
               break;

         } /* end of switch which validates the connection state */
      }
   } /* end of valid CB found */
   RETVALUE(ROK);
} /* SpUiSptAudRsp */
#endif /* SPTV2 */
#endif /* SPCO */  

  

/********************************************************************30**
  
         End of file:     cp_bdy1.c@@/main/26 - Tue Jan 22 15:15:00 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.

1.2          ---  fmg   1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  fmg   1. Added support for CCITT connection-oriented
                           control.

1.3          ---  fmg   1. Added support for CCITT connection-oriented
                           control.
 
1.4          ---  fmg   1. change sp_db.[xh] to cp_db.[xh]
 
1.5          ---  fmg   1. miscellaneous changes
 
1.6          ---  fmg   1. remove ifdef ERRCHK from around ret in
                           MSPCfgReq
             ---  fmg   2. miscellaneous changes

1.7          ---  fmg   1. Change SPutMsg to spDropMsg after
                           SPDECPDUHDR.
             ---  fmg   2. Change all SPutMsg to spDropMsg...
             ---  fmg   3. Removed SPrint statements from between
                           cases in SntStaInd.
             ---  fmg   4. updated to support new system services
             ---  fmg   5. miscellaneous changes

1.8          ---  scc   1. added changes to allow reconfiguration
                           in SpMiLspCfgReq

1.9          ---  scc   1. add ifdef SS7_ANS88 around defSrtTmr

1.10         ---  fmg   1. cleaned up some compile time warnings (Cast)

1.11         ---  fmg   1. fixed non-errchk compile time error.

1.12         ---  ak    1. config ADRMAP, removed check for pcInd

1.13         ---  scc   1. text change

1.14         ---  fmg   1. fixed SW_CCITT88 to nSap->swtch in UDatInd

1.15         ---  scc   1. change SpLiSntUdatInd to handle ANSI92
             ---  fmg   2. fixed bug in SpLiSntStaInd (PAUSE) to not
                           delete connections if we have SPCO enabled,
                           but the num of configured is zero.

1.16         ---  fmg   1. Added initialization of nmbSaps to nSapCb
                           config. (Change Log Id: SP2_1ID000)
1.17         ---  fmg   1. fixed syntax error for SPCO/NOERRCHK case
             ---  fmg   2. switched switch from SW_XXXX to  LSP_SW_xxxxx
             ---  fmg   3. removed cm2.x include. 
             ---  fmg   4. smoothed formatting
1.18         ---  fmg   1. removed redundant declaration of spFindCon
             ---  fmg   2. fixed ConCfm spId, suId logic

1.19         ---  mjp   1. added dpc parameter to SpLiSntUDatInd function
             ---  mjp   2. replaced previous error functions  with SPLOGERROR
             ---  mjp   3. add unsolicited status indications, CFG_NOK, CFG_OK,
                           CNTRL_NOK, CNTRL_NOK, STA_NOK, STA_OK, STS_NOK, 
                           STS_OK, SPT_INV, SNT_INV, INV_EVNT, BND_ON_BND
             ---  mjp   4. cleaned up spUiSptBndReq()
             ---  mjp   5. validate configured spaddr switch (LSP_SW_XXX)
             ---  mjp   6. change configured spaddr switch to SW_XXX
                           to be consistent with SCCP users.
                           
1.20         ---  mjp   1. change spSendMngtMsg parameter to SpMngtCb struct

1.21         ---  mjp   1. Moved some fields from SpUDatEvnt to SpUdCb
             ---  mjp   2. Updated to conform to TCO0000.01
             ---  mjp   3. initialize nmbLr = 0, when NSap is configured
             ---  mjp   4. fixed duplicate assignment of sapCb->bpc 
             ---  mjp   5. SpSC (Sequence Control) parameter added to
                           Unitdata event and passed from SCCP user. SpSC
                           added to up1 and up2 SCLI hashing key.
             ---  mjp   6. reduced nmbAdjDpc by one when an adjacent route 
                           is deleted
             ---  mjp   7. allow a route to be "re-configured"
             ---  mjp   8. changed spSapToNSapSw to return LSP_SW_ITU instead
                           of SW_CCITT
             ---  mjp   9. removed #ifdef SPCO in STADRMAP around check to
                           see if address in present 
             ---  mjp  10. check if global title is preset in STADRMAP
                           return RFAILED if not present
             ---  mjp  11. removed type parameter from SpUiSptBndReq.
             ---  mjp  12. nSapCb->sInfo is now configured with the 
                           subService field in spNSAPSCfg
             ---  mjp  13. upper sap configuration now fills in spid
             ---  mjp  14. update spMemSize calculations for 
                           SpXUdCb and SpXUdRefCb
             ---  mjp  15. initialized opc in new ucb in SpUiSptUDatReq.
             ---  mjp  16. changed SP_FLCOFF to SP_FLCON
             ---  mjp  17. in SpLiSntUDatInd case: M_UNITDATASRV - store 
                           the "return cause" in ud.qos.retOpt
             ---  mjp  18. initialize QOS in new unitdata control block when
                           unitdata service message is received.   
             ---  mjp  19. added sub-service field (ssf) to spTknStrToSpAddr
             ---  mjp  20. SpLiSntStaInd now uses status defines from snt.h
*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.22         sp000.27 mjp  1. add check for NULL sap in SpLiSntStaInd
             sp001.27 mjp  2. added timeFlg to spCb initialization (wrapper) 
             sp002.27 ash  3. Initialized lmPst structure to handle 
                              failure cases before/during general configuration
                           4. Fixed STROUT reconfiguration handling
                           5. Fixed STDELROUT handling
             ----     ash  6. Changes for fault tolerant SCCP
                           7. New control request added for enable/disable
                              upper/lower individual/group saps
                           8. Fixed statistics msgHand in function 
                              SpLiSntUDatInd by removing RETVALUE calls to
                              break statements 
                           9. ConRsp should stop connection timer
                          10. Both UbndReq and SteReq with UOS are cleaned
                              up. They use new function spDisableUpperSap.
                              this new function also cleans up the connection
                              for upper user.
                          11. Fixed UbndReq handling to free all rosources 
                              in case we are not already prohibited 
                          12. Changes for LMINT3
                          13. CfgReq cleanup
                          14. Changes for using new hash library
                          15. Changes for debug TCO
             sp007.27 ash 16. Changes already done
                          17. Removed all GCC warnings
             sp009.27     18. Changes for patch
             sp010.27     19. Changes for patch
             sp011.27     20. niInd bit copied in network sap 
                      cp  21. Made changes as required by TCR0003 for 
                              Debug Msg generation.
                      ash 22. defGuaTmr moved outside SPCO
                          23. For SP_OLD_BIND, Bind request should always
                              be sent after doing a state change, otherwise
                              tightly coupled interface may be a problem
                      cp  24. Added control reuest for trace generation.
                          25. Added calls to SP_GEN_TRC for trace capture.
                          26. Modified trace generation to work on per SAP.
                          27. rspAddr now contains the correct apc value when
                              SpUiSptDisInd is called.

/main/23        ---       cp  1.  Replaced ERRCLS_DEBUG by ERRCLS_INT_PAR.
                          2.  Fixed memory leak during NSAP config error 
                              checking.
            ---       cp  3.  Made changes to CfgReq for the new GTT framework.
                              Changes to StaReq for STROUT handling.
            ---       ash 4.  Changes for returning proper reason fields
                              value in config confirm when config request
                              for deleting a non existing address map entry
                              is received
            ---       cp  5.  When a node recovers from uncongestion we pass 
                              a SP_ACC to the users.
            ---       cp  6.  Added SP_PRESERVE_ADDR define to preserve the 
                              cgAddr and cdAddr in Class 0 and Class 1 msgs.
                          7.  Corrected zeroing of statistics structures.
            ---       cp  8.  Corrected check for presence of pc in cdAddr.
            ---       cp  9.  SCCP informs SM when a Bind is done by a user.
                          10. Correct comparison is done for MAXNUMSSNs during 
                              route configuration. 
            ---       cp  11. We pass the spId in StaInd when the user is 
                              inservice.
            ---       cp  12. SP_PRESERVE_ADR is to be used for only messages 
                              coming from the network.
                          13. Support added for spHdrOpt field in SpAddr
                          14. Corrected problems with old GTT implementation 
                              to work with changed SpAddr.
            ---       vb  15. Clean up of all the patches
                          16. Initialization of the dbgMask flag added.
            ---       cp  17. Added support for enquiring local pc,ssn status 
                              thru SpMiLspStaReq. 
                      cp  18. Removed FlcInd primitive. Prototype still remains
                              in snt.x
                      cp  19. Added CntrlReq for starting the guard timer.
                      cp  20. Handling of SN_RSTBEG and SN_RSTEND is now spec 
                              compliant. 
                      cp  21. Added support for new Class1 implementation
                      cp  22. Added support for calculating sls per route 
                              (instead of per NSAP).    
                      cp  23. Changed the local ref array to single dimension.
                      cp  24. Added new semantics for for STDELROUT. 
                      cp  25. Moved all delete requests (route, addrMap 
                              and asso) to CntrlReq.
                      cp  26. Incorporated changes from sp022.27.
           ---        vb  27. Updated code as per design spec 1010030.12
             /main/25                 cp   1. Implemented tcr0018.02
                           2. PSF hooks
                           3. CHINA support
             sp001.30 sg   1. As per ITU and ANSI specs we fill in the
                              pc in the calling address in N-UNITDATA
                              ind from MTP3 opc if the routing is on
                              DPC/SSN and no dpc was present.
             sp001.30 sg   2. Fix of the initialization of nmbAdjDpc, so
                              that we would not be writing to memory that
                              has not be allocated when nmbAdjDpc = 0.
             sp003.31 sg   3. Fixed the for statement for nmbConPc.
             sp004.301 sg  4. Fixed the for statement for nmbConPc.
             sp009.301 sg  5. Set the pcInd to TRUE before we set spHdrOpt
                              to FALSE.
             sp011.301 sg  6. Removed check for an offline node when we receive
                              a StaCfm.
             sp014.301 rc  7. Rolling upgrade changes, under the compile flag
                              SP_RUG, as per tcr0020.txt:
                           -  During general configuration, memory allocation
                              for storing interface version information and 
                              configuration and re-configuration of LM 
                              interface version number within lmPst. 
                           -  lmPst made reconfigurable.
                           -  Initializing upper interface version number 
                              in pst->intfVer within upper SAP during config.
                           -  Initializing lower interface version number in 
                              pst->intfVer within lower SAP during config.
                           -  Providing self and remote interface version number
                              to LM in upper SAP status. Adding element STNSAP
                              for lower SAP status in status request.
                           -  While handling bind request from upper user, 
                              remote interface version information for upper 
                              user is searched in the stored interface version 
                              informations and pst->intfVer within upper SAP is 
                              initialized accordingly, in case, version 
                              information for the upper user is not found from 
                              the stored version informations, a bind confirm 
                              with CM_BND_NOK is generated to user.
                           -  In the system agent control request, handling for 
                              request type SHT_REQTYPE_GETVER and
                              SHT_REQTYPE_SETVER.
                           -  Additional parameter to spEnableLowerSap and
                              check on return val of spEnableLowerSap.
                           -  calling zpUpdPeer in shtcntrlreq handling
/main/26     ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302 rc   1. Changes to implement TCR21 :
                              - deletion of nw, sap and nSap supported.
                              - conditional check for peersynce progress
                                extended for nw, sap and nsap deletion control
                                request.
             sp003.302 qz   1. Added a nSap control block pointer as a 
                               parameter to spFindLowerSapSid so we can check
                               the different situation of nSap via returned
                               vlaue.If lower sap was configured but not bind,
                               return ok instead of getting error.
             sp004.302 rc   1. Type of spMti changed to token U8 from token str
                               type and so subscript to spMti.val removed
                            2. Filling responding address in disCon indication
                               to sccp user in case of connection audit
                               inconsistency.
             sp006.302 rc   1. When sending confirm to SSN status request by
                               by upper user parameters sccpState and ril were
                               being passed uninitialized. To avoid this local
                               variables sccpState and ril are removed and
                               these parameters are passed from rCb fields.
                            2. In function SpLiSntStaCfm, correction in function
                               name passed trc macro.
             sp009.302 sg   1. Do not send an PSF update for a trace
                               control request.
             sp010.302 sg   1. Hop counter violation should be 12 for ANSI 96.
             sp011.302 sg   1. Added check for invalid NSap in trace
                               control request.
                            2. Need to release memory in an exception case.
             sp016.302 rc   1. Initialize mgmt cfm struct in LM Sta and Sts Req.
             sp017.302 rc   1. Process UIS request from user irrespective of the
                               sap status.
             sp019.302 rc   1. Handling multiple SS_UIS from user in SptSteReq.
             sp020.302 rc   1. Save priority of CR message in conCb.
             sp022.302 rc   1. When generating SSC message fill aSsn as SCMG 
                               i.e. SCCP itself. SSC is for SCCP itself only.
             sp024.302 rc   1. Performing calling party address treatment as
                               per ITU Q.714, section 2.7.5.1.
             sp026.302 rc   1. Do not generate RT update for debug control req.
                            2. Generate DisInd when conn can not be established
                               due to failure in local ref allocation.
                            3. Removed function call spDelCon and spAddCon.
                               These functions were to maintain conn hash list
                               based on CG_KEY, CD_KEY and SU_KEY and are no
                               longer used.
             sp027.302 rc   1. When returning upper SAP and lower SAP's status 
                               in LspStaCfm, return the bitMask value of status
                               to report various states of a SAP, instead of
                               just reporting Bind and Unbind state of SAP. The
                               bitMask values of SAP state can be found in lsp.h
                               file.
                            2. Fill elmntInst1 when generating LspStsCfm so that
                               LM can identify the sapId in the StsCfm.
             sp028.302 rc   1. Delete conCb from DLL when lclRef allocation is
                               failed.
                            2. Generate alarm when conn could not be established
                               due to exceeding the configured conThresh value.
                            3. Reporting numConn in global statistics.
             sp030.302 cg   1. Corrected SpUiSptStaReq return value to ROK 
                            2. Moved alarm generation for conThresh after check
             sp034.302 rc   1. Free conCb when connection becomes dead.
             sp038.302 mc   1. SS_MULTIPLE_PROCS flag added.
             sp039.302 mc   1. SS_MULTIPLE_PROCS flag added.
                            2. return RFAILED if SGetXxCb fails.
             sp044.302 sm   1. Initialized the local variables to avoid warnings.
             sp045.302 mc   1. If network id in Association and AddressMap
                               configuration is 0xffff, then address map and 
                               association is added in all the networks of
                               the same variant. In case addressMap/association
                               is being added in all the networks, if there
                               is error in adding in a particular network
                               then the addressMap/association is being
                               deleted from all the networks in which it
                               was sucessfully added.
                            2. If network id in Association and AddressMap
                               deletion is 0xffff, then address map and 
                               association is deleted in all the networks of
                               the same variant.
                            3. initialise the ucb's nwData and outNwData for
                               internetworking case for UDAtReq case. 
                            4. initialise the conCb's cs[]'s nwData and 
                               outNwData for ConReq case for 
                               internetworking case for CO case. 
             sp047.302 sm   1. If message Interception is enabled then retain a
                               copy of the original called and calling address 
                               so that we can copy them back into the message 
                               before pasing it on to user or provider.
                            2. Counters for SST, SSC and SSP transmit and
                               receive statistics added. 
             sp048.302 sm   1. Return value checked for SFndLenMsg and free
                               buffer in case of errors.
             sp049.302 mc   1. Changes for SS_MULTIPLE_PROCS. support for
                               NRM_TRM added in spActvInit and also changes
                               in SHUTDOWN handling.
                            2. Replaced SPLOGERROR with SLOGERROR to avoid using
                               spCb. This change is required because when
                               SGetXxCb returns null spCbPtr it can cause
                               crash.
             sp050.302 mc   1. Changes for SS_MULTIPLE_PROCS in spActvInit
                               for SHUTDOWN handling save the ptr of psfCb
                               before calling cmZero. This is required because
                               for SHUTDOWN case we set the spCb.used flag
                               TRUE and we should not allocate a new index
                               from zpCbLst array.
                            2. Renamed SLOGEEROR to SPERROR.
*********************************************************************91*/
