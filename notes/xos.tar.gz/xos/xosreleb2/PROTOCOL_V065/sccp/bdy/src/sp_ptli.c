/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     sccp - portable lower interface
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Lower Interface.
  
     File:     sp_ptli.c
  
     Sid:      sp_ptli.c@@/main/12_1 - Tue Jan 22 15:13:33 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common LDF-PSF */
#include "cmzpdplb.h"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common LDF-PSF */
#include "cmzpdplb.x"      /* common LDF-PSF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */
  

/*
  
The following functions are provided in this file:
  
     SpLiSntBndReq       lower interface - Bind Request
     SpLiSntUDatReq      lower interface - Data Request
     SpLiSntStaReq       lower interface - status Request
  
It should be noted that not all of these functions may be required
by a particular network layer service user.
  
It is assumed that the following functions are provided in SCCP:
  
     SpLiSntUDatInd   lower interface - Unit Data Indication
     SpLiSntStaInd    lower interface - Status Indication
  
*/
  

/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */
  
/* portable functions */

PRIVATE S16 PtLiSntBndReq ARGS((Pst*, SuId, SpId, SrvInfo));
PRIVATE S16 PtLiSntUDatReq ARGS((Pst*, SpId, Dpc, Dpc, SrvInfo, LnkSel, 
                                 Priority, Buffer *));
#ifdef SNT2
PRIVATE S16 PtLiSntStaReq ARGS((Pst*, SpId, Dpc)); 
#endif /* SNT2 */

/* functions in other modules */
  
/* public variable declarations */
  

/*
  
the following matrices define the mapping between the primitives
called by the lower interface of SCCP and the corresponding
primitives of the MTP level 3 service user(s).
  
The parameter MAXSPLI defines the maximum number of service users on
top of MTP level 3. There is an array of functions per primitive
invoked by MTP level 3. Every array is MAXSPLI long (i.e. there
are as many functions as the number of service users).
  
The dispatching is performed by the configurable variable: selector.
The selector is configured on a per SAP basis.
  
The selectors are:
  
   0 - loosely coupled (#define LCSPLISNT)
   1 - MTP Level 3 (#define SN)
   2 - M3UA (sigtran) (#define IT)  
*/
  

/* Bind Request primitive */
  
PRIVATE SntBndReq SpLiSntBndReqMt[MAXSPLI] =
{
#ifdef LCSPLISNT
   cmPkSntBndReq,          /* 0 - loosely coupled, portable */
#else
   PtLiSntBndReq,          /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntBndReq,          /* 1 - tightly coupled, Snt */
#else
   PtLiSntBndReq,          /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntBndReq,          /* 2 - tightly coupled, M3UA */
#else
   PtLiSntBndReq,          /* 2 - tightly coupled, portable */
#endif
};


/* Unit Data Request primitive */
  
PRIVATE SntUDatReq SpLiSntUDatReqMt[MAXSPLI] =
{
#ifdef LCSPLISNT
   cmPkSntUDatReq,         /* 0 - loosely coupled, portable */
#else
   PtLiSntUDatReq,         /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntUDatReq,         /* 1 - tightly coupled, SNT */
#else
   PtLiSntUDatReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntUDatReq,         /* 2 - tightly coupled, M3UA */
#else
   PtLiSntUDatReq,         /* 2 - tightly coupled, portable */
#endif
};


#ifdef SNT2

/* status Request primitive */
  
PRIVATE SntStaReq SpLiSntStaReqMt[MAXSPLI] =
{
#ifdef LCSPLISNT
   cmPkSntStaReq,         /* 0 - loosely coupled, portable */
#else
   PtLiSntStaReq,         /* 0 - loosely coupled, portable */
#endif
#ifdef SN
   SnUiSntStaReq,         /* 1 - tightly coupled, SNT */
#else
   PtLiSntStaReq,         /* 1 - tightly coupled, portable */
#endif
#ifdef IT
   ItUiSntStaReq,         /* 2 - tightly coupled, M3UA */
#else
   PtLiSntStaReq,         /* 2 - tightly coupled, portable */
#endif
};
#endif /* SNT2 */

/*
 *     lower interface functions
 */

  
/*
 *
 *       Fun:   lower interface - Network Bind Request
 *
 *       Desc:  This function binds an SCCP entity to an MTP 3 Entity.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpLiSntBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
SrvInfo sInfo                   /* service info */
)
#else
PUBLIC S16 SpLiSntBndReq(pst, suId, spId, sInfo)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
SrvInfo sInfo;                  /* service info */
#endif
{
   TRC3(SpLiSntBndReq);

   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            (*SpLiSntBndReqMt[pst->selector])(pst, suId, spId, sInfo);
         else
            DnUiSntBndReq(pst, suId, spId, sInfo);
         break;
#endif /* DN */

/* sp026.302 - addition - support for LDF-M3UA */
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
            (*SpLiSntBndReqMt[pst->selector])(pst, suId, spId, sInfo);
         else
            DvUiSntBndReq(pst, suId, spId, sInfo);
         break;
#endif /* DV */

      default:
         /* jump to specific primitive depending on configured selector */
         (*SpLiSntBndReqMt[pst->selector])(pst, suId, spId, sInfo);
         break;
   }
   RETVALUE(ROK);
} /* end of SpLiSntBndReq */

  
/*
 *
 *       Fun:   lower interface - Unit Data Request
 *
 *       Desc:  This function tells MTP 3 to transmit data;
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* service link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 SpLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating point code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* service link selector */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpNSapCb *nSap;

   TRC3(SpLiSntUDatReq);

   /* This is a safe function. No errorchecking needs to be done. */
   if (((nSap = spFndLSapSpidOpc(spId, opc)) != NULLP) && (nSap->trc == TRUE))
      SP_GEN_TRC(nSap->suId,SP_MSG_TXED,mBuf);

   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            (*SpLiSntUDatReqMt[pst->selector])(pst, spId, opc, dpc, sInfo, sls,
                                               prior, mBuf);
         else         
            DnUiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf);   
         break;
#endif /* DN */

/* sp026.302 - addition - support for LDF-M3UA */
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
            (*SpLiSntUDatReqMt[pst->selector])(pst, spId, opc, dpc, sInfo, sls,
                                               prior, mBuf);
         else         
            DvUiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf);   
         break;
#endif /* DV */

      default:
         /* jump to specific primitive depending on configured selector */
         (*SpLiSntUDatReqMt[pst->selector])(pst, spId, opc, dpc, sInfo, sls,
                                            prior, mBuf);
         break;
   }

   RETVALUE (ROK);
} /* end of SpLiSntUDatReq */

#ifdef SNT2 
  
/*
 *
 *       Fun:   lower interface - status Request
 *
 *       Desc:  This function sends status request to MTP3;
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PUBLIC S16 SpLiSntStaReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc dpc                         /* destination point code */
)
#else
PUBLIC S16 SpLiSntStaReq(pst, spId, dpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc dpc;                        /* destination point code */
#endif
{
   TRC3(SpLiSntStaReq);
   
   switch (pst->dstEnt)
   {
#ifdef DN
      case ENTSN:
         if (pst->route == RTE_PROTO)
            (*SpLiSntStaReqMt[pst->selector])(pst, spId, dpc);
         else
            DnUiSntStaReq(pst, spId, dpc);
         break;
#endif /* DN */         

/* sp026.302 - addition - support for LDF-M3UA */
#ifdef DV
      case ENTIT:
         if (pst->route == RTE_PROTO)
            (*SpLiSntStaReqMt[pst->selector])(pst, spId, dpc);
         else
            DvUiSntStaReq(pst, spId, dpc);
         break;
#endif /* DV */         

      default:
         /* jump to specific primitive depending on configured selector */
         (*SpLiSntStaReqMt[pst->selector])(pst, spId, dpc);
         break;
   }
   RETVALUE (ROK);
} /* end of SpLiSntStaReq */
#endif /* SNT2 */

  
/*
 *     portable functions
 */

  
/*
 *
 *       Fun:   portable - Network Bind Request
 *
 *       Desc:  This function binds an SCCP Entity to an MTP 3 Entity.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
SrvInfo sInfo                   /* service information */
)
#else
PRIVATE S16 PtLiSntBndReq(pst, suId, spId, sInfo)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
SrvInfo sInfo;                  /* service information */
#endif
{
   TRC3(PtLiSntBndReq)

   UNUSED(pst);
   UNUSED(suId);
   UNUSED(spId);
   UNUSED(sInfo);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP832, (ErrVal)ERRZERO, "PtLiSntStaBndReq");
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of PtLiSntBndReq */

  
/*
 *
 *       Fun:   portable - Network Unit Data Request
 *
 *       Desc:  This function tells the MTP Level 3 to transmit data.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selection */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PRIVATE S16 PtLiSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating pont code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* signalling link selection */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(PtLiSntUDatReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(opc);
   UNUSED(dpc);
   UNUSED(sInfo);
   UNUSED(sls);
   UNUSED(prior);
   UNUSED(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP833, (ErrVal)ERRZERO, "PtLiSntUDatReq");
#endif /* ERRCLASS */

   RETVALUE(ROK);
}  /* end of PtLiSntUDatReq */

#ifdef SNT2
  
/*
 *
 *       Fun:   portable - Network status Request
 *
 *       Desc:  This function sends status request to MTP3
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  sp_ptli.c
 *
 */
#ifdef ANSI
PRIVATE S16 PtLiSntStaReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc dpc                         /* destination point code */
)
#else
PRIVATE S16 PtLiSntStaReq(pst, spId, dpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc dpc;                        /* destination point code */
#endif
{
   TRC3(PtLiSntStaReq)

   UNUSED(pst);
   UNUSED(spId);
   UNUSED(dpc);
#if (ERRCLASS & ERRCLS_DEBUG)
   SPLOGERROR(ERRCLS_DEBUG, ESP834, (ErrVal)ERRZERO, "PtLiSntStaReq");
#endif /* ERRCLASS */

   RETVALUE(ROK);
}  /* end of PtLiSntStaReq */
#endif /* SNT2 */

  
/********************************************************************30**
  
         End of file:     sp_ptli.c@@/main/12_1 - Tue Jan 22 15:13:33 2002
  
*********************************************************************31*/

  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/

  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. text changes

1.3          ---  fmg   1. added support for CCITT 1988 
                           connection-oriented control

1.4          ---  fmg   1. added support for new system service interface

1.5          ---  scc   1. correct tokens at end of directive

1.6          ---  scc   1. reorder packing order for snPkLiSntBndReq
                           for old selector to be consistent with MTP3

1.7          ---  mjp   1. added opc parameter to UDatReq functions
             ---  mjp   2. replace old error function with SPLOGERROR
             ---  mjp   3. CMCHKPKLOG used with all pack functions 

1.8          ---  mjp   1. added cm_ss7.x and cm_ss7.h
             ---  mjp   2. removed all ref to SEL_LC_OLD and SPostTsk
             ---  mjp   3. removed old selector from interface matrices
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.9          ---      ash  1. Primitive added for SNT2
             ---      cp   2. Removed the packing functions.  
                           3. Trace generation done within SpLiSntUDatReq.
/main/10     ---      vb   1. Added support for M3UA

/main/12     ---      cp   1. Removed old BndReq functions.
/main/12_1   ---      rc   1. copyright header changed
           sp001.302  rc   1. Sid correction
           sp026.302  rc   1. Added support for LDF-M3UA.
*********************************************************************91*/
