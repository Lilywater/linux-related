/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     sccp - body 4
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Connection-oriented
               Utilities.
  
     File:     cp_bdy4.c
  
     Sid:      cp_bdy4.c@@/main/15_1 - Tue Jan 22 15:15:53 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


#ifdef SPCO
/* external functions */

/* forward references */
PRIVATE Void spSendInactTst ARGS((SpConCb*, S16));


/* 
 * support functions
 */


/*
 *
 *       Fun:   spNewConCb
 *
 *       Desc:  Allocate new Connection Control Block. By default 
 *              it puts that the side as calling side. Hence SIDE(cb) 
 *              will yield the calling side.
 *
 *       Ret:   Successful  - pointer to new control block
 *              Failure     - NULLP
 *
 *       Notes: SCCP Connection Oriented Control...
 *
 *       File:  cp_bdy4.c
 *
 */
#ifdef ANSI
PUBLIC SpConCb *spNewConCb
(
SpNwCb *nwData              /* network control block */
)
#else
PUBLIC SpConCb *spNewConCb(nwData)
SpNwCb *nwData;             /* network control block */
#endif
{
   SpConCb *cb;             /* connecion control block to be returned */
   S16 ret;                 /* return value */

   TRC2(spNewConCb);

   /* Get the buffer */
   ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, (Data **) &cb,
                  (Size) sizeof(SpConCb));
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP235, (ErrVal) ret, "SGetSBuf failed");
      RETVALUE((SpConCb *) NULLP);
   }

   /* zero out control block */
   cmZero((U8 *) cb, sizeof(SpConCb));

   /* We always start on the Calling side. The reason being that
    * the connect request calways comes from the calling side.
    */
   cb->side = CG_SIDE;

   /* sp045.302 - deletion - nwData is moved to cs[] */

   /* sp045.302 - addition - initializing the network data for calling/called 
    * side.
    */
   cb->cs[SIDE(cb)].nwData = nwData;
   cb->cs[OPSIDE(cb)].nwData = nwData;
   /* initialize queues */
   SInitQueue(&cb->cs[SIDE(cb)].datQ);
   SInitQueue(&cb->cs[SIDE(cb)].eDatQ);
   SInitQueue(&cb->cs[OPSIDE(cb)].datQ);
   SInitQueue(&cb->cs[OPSIDE(cb)].eDatQ);
   cmInitTimers(cb->timers, MAXCONTMR);
   cb->state = RDY_ST;

   RETVALUE(cb);
} /* spNewConCb */


/*
 *
 *       Fun:   spInsertConRef
 *
 *       Desc:  Inserts the connection reference number in the
 *              connection control block.
 *         
 *       Ret:   TRUE, FALSE
 *
 *       Notes: The reference number of the calling side is (i + 1), where
 *              i is the free index in the array) on the CG_SIDE and
 *              (i + 1 + nmbCon) on the CD_SIDE.
 *
 *       File:  cp_bdy4.c
 */
#ifdef ANSI
PUBLIC S16 spInsertConRef
(
SpConCb *cb            /* Connection control block */
)
#else
PUBLIC S16 spInsertConRef(cb)
SpConCb *cb;           /* Connection control block */
#endif
{

#ifndef ZP
   SpLclRef *slr;      /* source local reference */
   U8 found;           /* flag to indicate entry found or not */
   U32 i;              /* loop counter */
   U32 j;              /* sp004.302 - addition - loop counter */
   U32 nextLr;         /* sp004.302 - addition - next lclRef */
#endif /* ZP */
   
   TRC2(spInsertConRef);

#ifdef ZP
   RETVALUE(zpInsertConRef(cb));
#else /* ZP */

   /* sp044.302 - addition - Initialization of Local Variables */   
   slr = NULLP;   
   /* sp045.302 - modification - nwData is moved to cs[] */
   if (cb->cs[SIDE(cb)].nwData->nmbLr == spCb.spCfg.nmbCon)
   {
      /* sp028.302 - addition - print debug info and generate alarm */
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "spInsertConRef: Max number of connection exceeded\n"));
      spSendLmSta(LCM_CATEGORY_INTERNAL, LSP_EVENT_ADD_LCLREF_ERR,
                  LSP_CAUSE_MAXCON_EXCEEDED, NOTUSED, NOTUSED);
      RETVALUE(FALSE);
   }

   /* sp032.302 - addition - added field nmbConThresh to genrate alarm 
    * in case nmbLr reaches nmbConThresh percentage of nmbCon.
    */
#ifdef LSPV2_3
   /* sp045.302 - modification - nwData is moved to cs[] */
   if (cb->cs[SIDE(cb)].nwData->nmbLr >= 
       (spCb.spCfg.nmbConThresh*spCb.spCfg.nmbCon/10))
   {
      /* sp045.302 - modification - nwData is moved to cs[] */
      spSendLmSta(LCM_CATEGORY_INTERNAL, LSP_EVENT_ADD_LCLREF_ERR,
                  LSP_CAUSE_MAXCON_THRESH_REACHED, 
                  (U8)cb->cs[SIDE(cb)].nwData->nmbLr, NOTUSED);
   }
#endif /* LSPV2_3 */



   found = FALSE;

   /* sp004.302 - modification - start searching for local reference,
    * starting from nextLr
    */
   /* sp045.302 - modification - nwData is moved to cs[] */
   nextLr = cb->cs[SIDE(cb)].nwData->nextLr;

   for (i = nextLr, j = 0; j < spCb.spCfg.nmbCon; j++)
   {
      /* sp045.302 - modification - nwData is moved to cs[] */
      slr = &cb->cs[SIDE(cb)].nwData->lclRef[i];
      if (slr == (SpLclRef *) NULLP)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP236, (ErrVal) ERRZERO,
                    "local reference list not initialized");
         RETVALUE(FALSE);
      }
      if (!slr->cb && !slr->fflag)
      {
         found = TRUE;
         break;
      }
 
      i++;
      if (i == spCb.spCfg.nmbCon)
         i = 0;
   }
   if (!found) 
      RETVALUE(FALSE);

   /* CG_SIDE is actual index */
#ifndef SP_SLR_RANGE
   cb->cs[CG_SIDE].conId.spInstId = (i + 1);
#else
   cb->cs[CG_SIDE].conId.spInstId = (i + 1 + spCb.spCfg.slrLowRange);
#endif /* SP_SLR_RANGE */

   /* CD_SIDE is index + maximum number of connections */
#ifndef SP_SLR_RANGE
   cb->cs[CD_SIDE].conId.spInstId = (spCb.spCfg.nmbCon + i + 1); 
#else
   cb->cs[CD_SIDE].conId.spInstId = (spCb.spCfg.nmbCon + i + 1
                                     + spCb.spCfg.slrLowRange); 
#endif /* SP_SLR_RANGE */

   slr->cb = cb;
   slr->nwData->nmbLr++;  /* nwData and fflag fields are already initialized */
   cb->slr = slr;         /* Con Cb points back to the slr */

   /* sp004.302 - addition - update nextLr in nwCb */
   /* sp045.302 - modification - nwData is moved to cs[] */
   cb->cs[SIDE(cb)].nwData->nextLr = i + 1;
   if (cb->cs[SIDE(cb)].nwData->nextLr == spCb.spCfg.nmbCon)
      cb->cs[SIDE(cb)].nwData->nextLr = 0;

#ifdef LSPV2_2
   /* sp028.302 - addition - increment counter for numConn */
   spCb.sts.numConn++;
#endif /* LSPV2_2 */

   RETVALUE(TRUE);
#endif /* ZP */
} /* spInsertConRef */


/*
 *
 *       Fun:   spFreeConRef
 *
 *       Desc: This function frees the reference of the conCb from the
 *       slr. The actual slr will be deleted when the freezetimer has
 *       expired.
 *
 *       Ret:   ROK - Success.
 *              RNOK - failed.
 *
 *       Notes: SCCP Connection Oriented Control...
 *
 *       File:  cp_bdy4.c
 * */
#ifdef ANSI
PUBLIC Void spFreeConRef
(
SpConCb *cb   /* Con Cb */
)
#else
PUBLIC Void spFreeConRef(cb)
SpConCb *cb;  /* Con Cb */
#endif
{
#ifndef ZP
   SpLclRef *slr;
#endif

   TRC2(spFreeConRef);

#ifdef ZP
   zpFreeConRef(cb);
   RETVOID;
#else
   slr = cb->slr;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (slr == (SpLclRef *) NULLP)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP237, (ErrVal) cb->cs[CG_SIDE].conId.spInstId,
                 "invalid instance id in connection cb");
      RETVOID;
   }
   /* sp045.302 - modification - nwData is moved to cs[] */
   if (cb->cs[SIDE(cb)].nwData->defFrzTmr.val && 
       (slr->cb == (SpConCb *) NULLP) ) /* We've been here before */
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP238, (ErrVal) ERRZERO,
                 "Connection cb already freed");
      RETVOID;
   }
   /* sp045.302 - modification - nwData is moved to cs[] */
   if (cb->cs[SIDE(cb)].nwData->defFrzTmr.val && (slr->cb != cb))
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP239, (ErrVal) ERRZERO,
                 "connection cb structures not linked correctly");
      RETVOID;
   }
#endif /* ERRCLASS */

   slr->cb = NULLP;
   RETVOID;
#endif /* ZP */
} /* spFreeConRef */

#ifdef DEBUGP

/*
*
*       Fun:   spPrntTknStr
*
*       Desc:  Configure this layer for operation.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spPrntTknStr
(
TknStr *s         /* token string */
)
#else
PUBLIC Void spPrntTknStr(s)
TknStr *s;        /* token string */
#endif
{
   REG1 U8 i;
   Txt *ptr;

   TRC2(spPrntTknStr)

   sprintf(spCb.spInit.prntBuf,"Str: %d\n", s->len);   
   SPrint(spCb.spInit.prntBuf);

   ptr = spCb.spInit.prntBuf;
   for (i = 0; i < s->len; i++, ptr+=2)
   {
       U8 b1,b2;
       b1 = (s->val[i] >> 4 ) & 0x0f;
       b2 = s->val[i] & 0x0f;
       b1 = spHexToAscii(b1);
       b2 = spHexToAscii(b2);
       sprintf(ptr,"%c%c", b1, b2);
   }
   sprintf(ptr, "\n\n");
   SPrint(spCb.spInit.prntBuf);
   RETVOID;
} /* spPrntTknStr */


/*
*
*       Fun:   spHexToAscii
*
*       Desc:  Hex to Ascii conversions.
*
*       Ret:   ASCII value
*
*       Notes: None
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC U8 spHexToAscii
(
U8 hex
)
#else
PUBLIC U8 spHexToAscii(hex)
U8 hex;
#endif
{
   TRC3(spHexToAscii)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (hex > 0x0f)
      SPLOGERROR(ERRCLS_DEBUG, ESP240, (ErrVal) hex, "illegal hex value");
#endif /* ERRCLASS */

   if (hex <= 0x09)
      RETVALUE('0' + hex);
   else
      RETVALUE('a' + (hex - 10));

} /* spHexToAscii */
#endif /* DEBUGP */


/*
*
*       Fun:   spFreezeSlr
*
*       Desc:  Freeze Source Local Reference
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spFreezeSlr
(
SpConCb *cb,               /* connection */
U8 flg                     /* freeze flg */
)
#else
PUBLIC Void spFreezeSlr(cb, flg)
SpConCb *cb;              /* connection */
U8 flg;                   /* freeze flg */
#endif
{

#ifndef ZP
   SpLclRef *slr;
#endif /* ZP */

   TRC2(spFreezeSlr);

#ifdef ZP
   /* This function can serve the new (ZP) and old implementation
    * both. If for any reason this function is modified please
    * introduce a zpFreezeSlr function. 
    */
   zpFreezeSlr (cb, flg);
   RETVOID; 
#else /* ZP */

   /* find the slr */
   slr = cb->slr;

   /* freeze calling side */
   slr->fflag |= flg;

   /* if both sides are frozen, place it on the timing queue */
   /* sp045.302 - modification - nwData is moved to cs[] */
   if (((slr->fflag & SP_FRZ_BT) == SP_FRZ_BT) && 
         cb->cs[SIDE(cb)].nwData->defFrzTmr.val) 
   {
      /* set the freeze timer */
      slr->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData is moved to cs[] */
      slr->tmr.val = cb->cs[SIDE(cb)].nwData->defFrzTmr.val;
      spStartLclRefTmr(slr);

      /* sp034.302 - modificatiom - avoid dereference and mark conn as dead */
      cb->cType |= SP_DEAD;
   }
   else 
   {
      /* sp045.302 - modification - nwData is moved to cs[] */
      if (((slr->fflag & SP_FRZ_BT) == SP_FRZ_BT) && 
          !cb->cs[SIDE(cb)].nwData->defFrzTmr.val) 
      {
         /* sp034.302 - addition - mark conn as dead */
         cb->cType |= SP_DEAD;

         slr->cb = (SpConCb*)NULLP;
         slr->fflag = 0;
         slr->nwData->nmbLr--;
#ifdef LSPV2_2
         /* sp028.302 - addition - decrement counter for numConn */
         spCb.sts.numConn--;
#endif /* LSPV2_2 */
      }
   }
   RETVOID;
#endif /* ZP */
} /* spFreezeSlr */


/*
*
*       Fun:   spFreeConCb
*
*       Desc:  Free connection control block. Function spFreeConRef should 
*              be called before calling this function.
*
*       Ret:   Void
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spFreeConCb
(
SpConCb *cb                /* connection */
)
#else
PUBLIC Void spFreeConCb(cb)
SpConCb *cb;              /* connection */
#endif
{
   S16 tNum;

   TRC2(spFreeConnCb);
   
   /* free con ref */
   spFreeConRef(cb); 

   /* flush queues */
   spFlushQueue(&cb->cs[SIDE(cb)].datQ);
   spFlushQueue(&cb->cs[SIDE(cb)].eDatQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].datQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].eDatQ);

   /* stop timers */
   for (tNum = 0; tNum < MAXCONTMR; tNum++) 
       if (cb->timers[tNum].tmrEvnt != TMR_NONE)
          spRmvConCbTq(cb, (U8) cb->timers[tNum].tmrEvnt);

   /* sp026.302 - removal - remove function call spDelCon. This
    * function was to delete conn from conn hash list based on
    * CG_KEY, CD_KEY and SU_KEY and is no longer used.
    */

#ifdef ZP
   /* sp034.302 - modification - generate RT upd for deletion of ConCb only
    * when slr cb is still there, means freeze time is still running. If
    * defFrzTmr is disabled, then slr would be freed before conCb is freed
    * and that case will result in packing error of ConCb. When SBY sccp
    * receives RT upd for deletion of slr, then if conCb exists then it will
    * also free the conCb.
    */
   if (((cb->state == RLS_ST) ||
       (cb->state == RCG_ST) ||
       (cb->state == RCD_ST) ||
       (cb->state == RBT_ST) ||
       (cb->state == DTX_ST)) && (cb->slr != NULLP))
   {
      /* this means we have already created this control block on standby
       * so it must be deleted 
       */ 
      zpRunTimeUpd(ZP_SP_CONCB, (Void *)cb, CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_DEL);
   }
   zpDelMapping (ZP_SP_CONCB, (Void *) cb);
#endif /* ZP */
   /* free memory */
   (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) cb, 
                   (Size)sizeof(SpConCb));

   RETVOID;
} /* spFreeConCb */


/*
*
*       Fun:   spLookUpConCbAndSetSide
*
*       Desc:  Finds control bock based on network and instance id
*
*       Ret:   Pointer to control block
*
*       Notes: This function based on the received reference number
*       decides whether the message came from the called or the
*       calling side and then replaces the side in the conCb with the
*       CG_SIDE or CD_SIDE.
*
*       File:  cp_bdy4.c
* */
#ifdef ANSI
PUBLIC SpConCb *spLookUpConCbAndSetSide
(
SpNwCb *nwData,           /* network */
U32 id
)
#else
PUBLIC SpConCb *spLookUpConCbAndSetSide(nwData, id)
SpNwCb *nwData;           /* network */
U32 id;
#endif
{

#ifndef ZP
   SpLclRef* slr;
   InstId idx;
   U8 side;
#endif /* ZP */
   
   TRC2(spLookUpConCbAndSetSide);

#ifdef ZP
   RETVALUE(zpLookUpConCbAndSetSide (id, ZP_CONVERT_SWTCH(nwData->variant)));
#else
   if (id == 0)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP241, (ErrVal) ERRZERO,
                 "instance id set to 0");
      RETVALUE((SpConCb *) NULLP);
   }

#ifdef SP_SLR_RANGE
   /* added range on number of SLR */
   id = id - spCb.spCfg.slrLowRange;
#endif /* SP_SLR_RANGE */

   if (id > spCb.spCfg.nmbCon)
   {
       idx = id - spCb.spCfg.nmbCon;
       if (idx > spCb.spCfg.nmbCon)
       {
          RETVALUE((SpConCb *) NULLP);
       }
       side = CD_SIDE;
   }
   else
   {
       idx = id;
       side = CG_SIDE;
   }
   slr = &nwData->lclRef[idx - 1];

   if (!slr)
      RETVALUE((SpConCb *) NULLP);

   /* if there is no control block, return null */
   if (slr->cb == (SpConCb *) NULLP)
      RETVALUE((SpConCb *) NULLP);

   /* if control block is frozen return null */
   if ((slr->fflag & SP_FRZ_CG) && (side == CG_SIDE))
      RETVALUE((SpConCb *) NULLP);

   if ((slr->fflag & SP_FRZ_CD) && (side == CD_SIDE))
      RETVALUE((SpConCb *) NULLP);

   /* set the side */
   slr->cb->side = side;

   RETVALUE(slr->cb);
#endif /* ZP */
} /* spLookUpConCbAndSetSide */


/*
*
*       Fun:   spHndlIarTo
*
*       Desc:  Handle IAR timer timing out.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlIarTo
(
SpConCb *cb            /* connection control block */
)
#else
PUBLIC Void spHndlIarTo(cb)
SpConCb *cb;           /* connection control block */
#endif
{
   TRC2(spHndlIarTo)

   UNUSED(cb);
   RETVOID;
} /* spHndlIarTo */

  
/*
*
*       Fun:    spRmvLclRefTq
*
*       Desc:   Removes control block from Timing Queue
*
*       Ret:    None
*
*       Notes:  Timer handling is retained for ZP also.
*
*       File:   cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvLclRefTq
(
SpLclRef *cb       /* control block */
)
#else
PUBLIC Void spRmvLclRefTq(cb)
SpLclRef *cb;      /* control block */
#endif
{
   CmTmrArg arg;

   TRC2(spRmvLclRefTq)

   arg.tq = spCb.spLclRefTq;
   arg.tqCp = &spCb.spLclRefTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = TMR_DEF;
   arg.wait = NOTUSED;
   arg.tNum = TMR0;
   arg.max = TMR_DEF_MAX;
   cmRmvCbTq(&arg);
   RETVOID;
} /* spRmvLclRefTq */

  
/*
*
*       Fun:   spStartLclRefTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy4.c
*
*/
  
#ifdef ANSI
PUBLIC Void spStartLclRefTmr
(
SpLclRef *cb      /* control block */
)
#else
PUBLIC Void spStartLclRefTmr(cb)
SpLclRef *cb;     /* control block */
#endif
{
   CmTmrArg arg;

   TRC2(spStartLclRefTmr)
 
   arg.tq = spCb.spLclRefTq;
   arg.tqCp = &spCb.spLclRefTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR) cb;
   arg.evnt = TMR_DEF;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = TMR_DEF_MAX;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)          /* if wait, place on TQ */
      cmPlcCbTq(&arg);
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "spStartLclRefTmr\n"));
   RETVOID;
} /* spStartLclRefTmr */

  
/*
*
*       Fun:   spLclRefTmrEvnt
*
*       Desc:  SpLclRef Timer event handler
*
*       Ret:   ROK
*
*       Notes: 
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spLclRefTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spLclRefTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{

#ifndef ZP
   SpLclRef *slr;
#endif /* ZP */
   
   TRC2(spLclRefTmrEvnt)

   UNUSED(evnt);

   SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
          "spLclRefTmrEvnt : %d expired \n", evnt));

#ifdef ZP
   zpLclRefTmrEvnt(cbp, evnt);
   RETVOID;
#else
   slr = (SpLclRef *) cbp;

   /* unfreeze local reference number */
   slr->fflag = 0;
   slr->nwData->nmbLr--;

#ifdef LSPV2_2
   /* sp028.302 - addition - decrement counter for numConn */
   spCb.sts.numConn--;
#endif /* LSPV2_2 */

   /* clear the connection control block */
   slr->cb = (SpConCb *) NULLP;
   RETVOID;
#endif /* ZP */
} /* spLclRefTmrEvnt */

/* sp026.302 - removal - remove functions spInitConHl, spAddCon and
 * spDelCon. These functions were to maintain conn hash list based on
 * CG_KEY, CD_KEY and SU_KEY and are no longer used.
*/


/*
*
*       Fun:   spConRefused
*
*       Desc:  send connection refused on the calling side.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spConRefused
(
SpConCb *cb,           /* connection control block */
U8 cause,              /* refusal cause */
U8 orig,               /* originator */
Buffer *data           /* data buffer */
)
#else
PUBLIC Void spConRefused(cb, cause, orig, data )
SpConCb *cb;           /* connection control block */
U8 cause;              /* refusal cause */
U8 orig;               /* originator */
Buffer *data;          /* data buffer */
#endif
{
   S16 ret;
   TRC2(spConRefused)

   /* connection refused always goes to Calling side */

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[CG_SIDE].pc == cb->cs[CG_SIDE].nwData->selfPc) /* local */
   {
      SpDisEvnt dis;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (!cb->sap)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP243, (ErrVal) ERRZERO, 
                    "calling sap is NULL");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }
#endif /* (ERRCLASS) */

      cmCopy((U8 *) &cb->cs[CG_SIDE].conId, (U8 *) &dis.conId, sizeof(SpConId));
      cmCopySpAddr(&cb->t.req0.cdAddr, &dis.rspAddr);
      dis.rsn = cause;
      dis.orig = orig;

#ifdef SPTV2
      /* mark importance as not present, as importance is not
       * relevant in disconnect indication to upper user
       */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
         (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data);
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
   }
   else   /* called side */
   {
      SpConRef cr;
      Buffer *mBuf;

      cr.dLclRef.eh.pres = PRSNT_NODEF;
      cr.dLclRef.dLclRef.pres = PRSNT_NODEF;
      cr.dLclRef.dLclRef.val = cb->cs[CG_SIDE].conId.suInstId;

      cr.refCause.eh.pres = PRSNT_NODEF;
      cr.refCause.refCause.pres = PRSNT_NODEF;
      cr.refCause.refCause.val = cause;

      if (cb->cType & SP_REQ0)
      {
         if (cb->t.req0.cdAddr.pres)
         {
            cr.cdAddr.eh.pres = PRSNT_NODEF;
            spSpAddrToTknStr(&cb->t.req0.cdAddr, &cr.cdAddr.spAddr);
         }
         else
            cr.cdAddr.eh.pres = NOTPRSNT;
      }
      else
         cr.cdAddr.eh.pres = NOTPRSNT;

      if (data)
      {
         cr.data.eh.pres = PRSNT_NODEF;
         cr.data.data.pres = PRSNT_NODEF;
         cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data = data;
      }
      else
         cr.data.eh.pres = NOTPRSNT;

      if (cb->imp.pres == NOTPRSNT)
         cr.imp.eh.pres = NOTPRSNT;
      else
      {
         cr.imp.eh.pres = PRSNT_NODEF;
         cr.imp.importance.pres = PRSNT_NODEF;
         cr.imp.importance.val = cb->imp.val;
      }
 
      cr.endOp.eh.pres = PRSNT_NODEF;
      cr.endOp.endOp.pres = PRSNT_NODEF;
      cr.endOp.endOp.val = 0;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_CONREF;

      ret = SGetMsg(cb->cs[CG_SIDE].nSap->pst.region, 
                    cb->cs[CG_SIDE].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP244, (ErrVal) ret,"SGetMsg failed");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }

      /* Encode message */
      /* sp045.302 - modification - nwData is moved to cs[] */
      SPENCPDUHDR(&cb->cs[CG_SIDE].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
                  cb->cs[CG_SIDE].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP245, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
          cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         RETVOID;
      }

      SPENCPDU(&cb->cs[CG_SIDE].nSap->mfMsgCtl, ret, (ElmtHdr *) &cr);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP246, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
          cb->cs[CG_SIDE].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         RETVOID;

      }
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->cs[CG_SIDE].sls = spGetSls(cb->cs[CG_SIDE].nwData,
                                     cb->cs[CG_SIDE].pc);
      
      /* sp014.302 - priority of CREF should be 1 instead of 0 */
      ret = spSendCoMsg(cb, CG_SIDE, SN_PRI1, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
      else
         /* update statistics for CREF message sent */
         spCb.sts.crefTx++;
   } /* else called side */
   RETVOID;
} /* spConRefused */


/*
*
*       Fun:   spRelease
*
*       Desc:  release the connection of the appropriate side
*              send DisInd on local releases, and M_RELSD for
*              remote releases.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRelease
(
SpConCb *cb,           /* connection control block */
U8 side,               /* side */
U8 cause,              /* refusal cause */
U8 orig,               /* originator */
Buffer *data           /* data buffer */
)
#else
PUBLIC Void spRelease(cb, side, cause, orig, data )
SpConCb *cb;           /* connection control block */
U8 side;               /* side */
U8 cause;              /* refusal cause */
U8 orig;               /* originator */
Buffer *data;          /* data buffer */
#endif
{
   S16 ret;            /* return value */

   TRC2(spRelease)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[side].pc == cb->cs[side].nwData->selfPc) /* local */
   {
      SpDisEvnt dis;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (!cb->sap)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP247, (ErrVal) ERRZERO, 
                    "calling sap is NULL");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }
#endif

      cmCopy((U8*)&cb->cs[side].conId, (U8*)&dis.conId, sizeof(SpConId));
      cmZero((U8*)&dis.rspAddr, sizeof(SpAddr));
      dis.rsn = cause;
      dis.orig = orig;

#ifdef SPTV2
      /* importance is not relevant in disconnection indication to 
       * upper user. mark it as not present
       */
      dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
        (Void) SpUiSptDisInd(&cb->sap->pst, &dis, data);
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
      /* just in case we have missed , freeze slr here */
      spFreezeSlr(cb, FRZ_SIDE(side));
   }
   else                /* destination side is remote */
   {
      SpRelsd rel;     /* RLSD */
      Buffer *mBuf;    /* message buffer */
      U8 found;        /* flag */
      U8 tNum;         /* counter for timers */

      /* destination local reference is my remote lcl reference */
      rel.dLclRef.eh.pres = PRSNT_NODEF;
      rel.dLclRef.dLclRef.pres = PRSNT_NODEF;

      /* this will be zero when its unknown */
      rel.dLclRef.dLclRef.val = cb->cs[side].conId.suInstId;

      /* source local reference is my lcl reference */
      rel.sLclRef.eh.pres = PRSNT_NODEF;
      rel.sLclRef.sLclRef.pres = PRSNT_NODEF;
      rel.sLclRef.sLclRef.val = cb->cs[side].conId.spInstId;
      rel.relCause.eh.pres = PRSNT_NODEF;
      rel.relCause.relCause.pres = PRSNT_NODEF;
      rel.relCause.relCause.val = cause;
      rel.imp.eh.pres = NOTPRSNT;

      if (data)
      {
         rel.data.eh.pres = PRSNT_NODEF;
         rel.data.data.pres = PRSNT_NODEF;
         cb->cs[side].nSap->mfMsgCtl.sccpInfo.data = data;
      }
      else
         rel.data.eh.pres = NOTPRSNT;

      rel.endOp.eh.pres = PRSNT_NODEF;
      rel.endOp.endOp.pres = PRSNT_NODEF;
      rel.endOp.endOp.val = 0;
      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_RELSD;
      ret = SGetMsg(cb->cs[side].nSap->pst.region, cb->cs[side].nSap->pst.pool,
                    &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP248, (ErrVal) ret, "SGetMsg failed");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }

      /* Encode message */
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[side].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
                  cb->cs[side].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP249, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[side].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[side].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
          cb->cs[side].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         RETVOID;
      }

      SPENCPDU(&cb->cs[side].nSap->mfMsgCtl, ret, (ElmtHdr *) &rel);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP250, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[side].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[side].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
          cb->cs[side].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         RETVOID;
      }

      found = FALSE;
      for (tNum = 0; tNum < MAXCONTMR; tNum++)
      {
         if (cb->timers[tNum].tmrEvnt == INT_TMR(side))
         {
            found = TRUE;
            break; 
         }
      }

      if (found)
      {
         /* 
          * Restart/Start the Repeat Release timer for the called/calling side. 
          * This is done becoz we might send out two RLS in succession..eg on
          * receiving a IT with Bad SLR or OPC.
          */
         spRmvConCbTq(cb, REPREL_TMR(side));
         cb->tmr.enb = TRUE;

         /* use RepRelTmr value only for itu92 & 96, china, ansi96 and bell05 */
         if ((cb->cs[side].swtch == LSP_SW_ITU92)  
             || (cb->cs[side].swtch == LSP_SW_ITU96)
             || (cb->cs[side].swtch == LSP_SW_CHINA) 
            )
         {
            /* sanity check, make sure that we have RepRelTmr value */
            /* sp045.302 - modification - nwData moved to cs[] */
            if (cb->cs[side].nwData->defRepRelTmr.enb == TRUE) 
               cb->tmr.val = cb->cs[side].nwData->defRepRelTmr.val;
            else
               cb->tmr.val = cb->cs[side].nwData->defRelTmr.val;
         }
         else
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[side].nwData->defRelTmr.val;
         spStartConCbTmr(cb, REPREL_TMR(side));
      }
      else
      {
         /* Restart/Start the Release timer for the called/calling side .
          * This is done becoz we might send out two RLS in succession..eg on
          * receiving a IT with Bad SLR or OPC.
          */
         spRmvConCbTq(cb, REL_TMR(side));
         cb->tmr.enb = TRUE;
         /* sp045.302 - modification - nwData moved to cs[] */
         cb->tmr.val = cb->cs[side].nwData->defRelTmr.val;
         spStartConCbTmr(cb, REL_TMR(side));
      }   
      cb->state = RLS_ST;
      
      ret = spSendCoMsg(cb, side, SN_PRI2, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
   } /* else destination remote */
   RETVOID;
} /* spRelease */


/*
*
*       Fun:   spRelCmp
*
*       Desc:  release the connection of the appropriate side
*              send DisInd on local releases, and M_RELSD for
*              remote releases.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRelCmp
(
SpConCb *cb,           /* connection control block */
U8 side                /* side */
)
#else
PUBLIC Void spRelCmp(cb, side)
SpConCb *cb;           /* connection control block */
U8 side;               /* side */
#endif
{
   S16 ret;

   TRC2(spRelCmp)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[side].pc != cb->cs[side].nwData->selfPc) /* remote */
   {
      SpRelCmp rc;
      Buffer *mBuf;

      /* destination local reference is my remote lcl reference */
      rc.dLclRef.eh.pres = PRSNT_NODEF;
      rc.dLclRef.dLclRef.pres = PRSNT_NODEF;
      rc.dLclRef.dLclRef.val = cb->cs[side].conId.suInstId;

      /* source local reference is my lcl reference */
      rc.sLclRef.eh.pres = PRSNT_NODEF;
      rc.sLclRef.sLclRef.pres = PRSNT_NODEF;
      rc.sLclRef.sLclRef.val = cb->cs[side].conId.spInstId;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_RELCMP;

      ret = SGetMsg(cb->cs[side].nSap->pst.region, 
                    cb->cs[side].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP251, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }

      /* Encode message */
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[side].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
                  cb->cs[side].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP252, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         RETVOID;
      }

      SPENCPDU(&cb->cs[side].nSap->mfMsgCtl, ret, (ElmtHdr *) &rc);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP253, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         RETVOID;
      }
 
      ret = spSendCoMsg(cb, side, SN_PRI2, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
   } /* if (cb->cs[side].pc != cb->cs[side].nwData->selfPc) */
   RETVOID;
} /* spRelCmp */


/*
*
*       Fun:   spConRequest
*
*       Desc:  Send Connection Reuest on the called side.
*              if local, generate Connection Indication.
*              if remote, send Connection Request.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spConRequest
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* data buffer */
)
#else
PUBLIC Void spConRequest(cb, data )
SpConCb *cb;           /* connection control block */
Buffer *data;          /* data buffer */
#endif
{
   S16 ret;            /* return value */

   TRC2(spConRequest)

   /* connection request always comes from the calling side */

   if (cb->cType & SP_REQ1)    /* this is a request type 1 */
   {
      SpConEvnt ce;

      ce.type = CE_REP;        /* this is a reply */

      /* copy the calling side con id into the connection event */
      cmCopy((U8 *) &cb->cs[SIDE(cb)].conId, (U8 *) &ce.conId, sizeof(SpConId));

      /* return the same quality of service (we have no preference) */
      cmCopy((U8 *) &cb->qos, (U8 *) &ce.qos, sizeof(SpQosSet));
      ce.qos.retOpt = 0; /* unused */

      /* this is our called side reference */
      ce.t.reply.slr = cb->cs[OPSIDE(cb)].conId.spInstId;

#ifdef SPTV2
      /* importance is irrevelant in indication primitive to user */
      ce.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* start connection timer */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[SIDE(cb)].nwData->defConTmr.val;
      spStartConCbTmr(cb, CON_TMR);

      /* connecting state */
      cb->state = CON_ST;

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
      {
        /* We use the connection indication primitive to
         * pass the "reply" interface element.
         * We return any data that may have been passed down.
         */
         (Void) SpUiSptConInd(&cb->sap->pst, &ce, data);
      }
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
      RETVOID;
   } /* request type 1 */

   /* check if this is an intermediate request type 2 */
   if ((cb->cType & SP_REQ2) && (cb->cType & SP_INTR))
   {
      SpConEvnt ce;

      ce.type = CE_REP;     /* this is a reply */

      /* copy the user Id info into the ce connection id */
      cmCopy((U8 *) &cb->t.req2.usrId, (U8 *) &ce.conId, sizeof(SpConId));

      /* return the same quality of service (we have no preference) */
      cmCopy((U8 *) &cb->qos, (U8 *) &ce.qos, sizeof(SpQosSet));
      ce.qos.retOpt = 0; /* unused */

      /* this is our called side reference */
      ce.t.reply.slr = cb->cs[OPSIDE(cb)].conId.spInstId;

#ifdef SPTV2
      /* importance is irrevelant in indication primitive to user */
      ce.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* start connection timer */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[SIDE(cb)].nwData->defConTmr.val;
      spStartConCbTmr(cb, CON_TMR);

      /* connecting state */
      cb->state = CON_ST;

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
      {
        /* We use the connection indication primitive to
         * pass the "reply" interface element.
         * We return any data that may have been passed down.
         */
         (Void) SpUiSptConInd(&cb->sap->pst, &ce, data);
      }
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
      RETVOID;
   } /* intermediate request type 2 */

   /* If this is a destination node, and request 2 then
    * we proceed the same as a request 0
    */
   if (cb->cType & SP_DEST)    /* called side local */
   {
      SpConEvnt ce;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (!cb->sap)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP254, (ErrVal) ERRZERO, 
                    "called sap is NULL");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }
#endif
      
      cmCopy((U8 *) &cb->cs[OPSIDE(cb)].conId, (U8 *) &ce.conId,
             sizeof(SpConId));
      cmCopySpAddr(&cb->t.req0.cdAddr, &ce.t.ind.cdAddr);
      if (cb->t.req0.cgAddr.pres)
         cmCopySpAddr(&cb->t.req0.cgAddr, &ce.t.ind.cgAddr);
      else
         ce.t.ind.cgAddr.pres = FALSE;
      ce.t.ind.rcs = 0;
      ce.t.ind.eds = 0;
      ce.qos.pClass = spCb.pdu.m.conReq.pClass.pClass.val;
      ce.qos.retOpt = 0;    /* unused */
      if (ce.qos.pClass == PCLASS3)
         ce.qos.credit = spCb.pdu.m.conReq.pClass.pClass.val;
      ce.type = CE_IND;

#ifdef SPTV2
      /* importance is irrevelant in indication primitive to user */
      ce.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      /* start connection timer */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[SIDE(cb)].nwData->defConTmr.val;
      spStartConCbTmr(cb, CON_TMR);

      cb->state = CON_ST;

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
      {
         (Void) SpUiSptConInd(&cb->sap->pst, &ce, data);
      }
      else
      {
         if (data)
            (Void) SPutMsg(data);

         /* sp028.302 - addition - freeze slr and free conCb */ 
         spFreezeSlr(cb, SP_FRZ_BT);
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         /* sp034.302 - addition - return from here */
         RETVOID;
      }
   }
   else                 /* called side remote */
   {
      SpConReq cr;      /* connection request message */
      Buffer *mBuf;     /* message buffer */

      /* over here put in hop counter value as appropriate */
      /* from connection control block cb                  */
      if (cb->hopCntr.pres==TRUE)
      {
         cr.hopCntr.eh.pres = PRSNT_NODEF;
         cr.hopCntr.cnt.pres = PRSNT_NODEF;
         cr.hopCntr.cnt.val = cb->hopCntr.val;
      } 
      else
         cr.hopCntr.eh.pres = NOTPRSNT;

      cr.sLclRef.eh.pres = PRSNT_NODEF;
      cr.sLclRef.sLclRef.pres = PRSNT_NODEF;
      cr.sLclRef.sLclRef.val = cb->cs[OPSIDE(cb)].conId.spInstId;

      cr.pClass.eh.pres = PRSNT_NODEF;
      cr.pClass.pClass.pres = PRSNT_NODEF;
      cr.pClass.pClass.val = cb->qos.pClass;

      cr.cdAddr.eh.pres = PRSNT_NODEF;
      spSpAddrToTknStr(&cb->t.req0.cdAddr, &cr.cdAddr.spAddr);

      if (cb->qos.pClass == PCLASS3)
      {
         cr.credit.eh.pres = PRSNT_NODEF;
         cr.credit.credit.pres = PRSNT_NODEF;
         cr.credit.credit.val = cb->qos.credit;
      }
      else
         cr.credit.eh.pres = NOTPRSNT;

      if (cb->t.req0.cgAddr.pres)
      {
         cr.cgAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&cb->t.req0.cgAddr, &cr.cgAddr.spAddr);
      }
      else
         cr.cgAddr.eh.pres = NOTPRSNT;

      if (data)
      {
         cr.data.eh.pres = PRSNT_NODEF;
         cr.data.data.pres = PRSNT_NODEF;
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = data;
      }
      else
         cr.data.eh.pres = NOTPRSNT;

      if (cb->imp.pres == NOTPRSNT)
         cr.imp.eh.pres = NOTPRSNT;
      else
      {
         cr.imp.eh.pres = PRSNT_NODEF;
         cr.imp.importance.pres = PRSNT_NODEF;
         cr.imp.importance.val = cb->imp.val;
      }

      cr.endOp.eh.pres = PRSNT_NODEF;
      cr.endOp.endOp.pres = PRSNT_NODEF;
      cr.endOp.endOp.val = 0;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_CONREQ;

      ret = SGetMsg(cb->cs[OPSIDE(cb)].nSap->pst.region, 
                    cb->cs[OPSIDE(cb)].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP255, (ErrVal) ret, "SGetMsg failed");
         if (data)
            (Void) SPutMsg(data);

         /* sp028.302 - addition - freeze slr and free conCb */ 
         spFreezeSlr(cb, SP_FRZ_BT);
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         RETVOID;
      }

      /* Encode message */
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
                  cb->cs[OPSIDE(cb)].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP256, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         /* sp028.302 - addition - freeze slr and free conCb */ 
         spFreezeSlr(cb, SP_FRZ_BT);
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         RETVOID;
      }

      SPENCPDU(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &cr);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP257, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         /*
          * sp036.302 - modification - correcting the index of cs.
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         /* sp028.302 - addition - freeze slr and free conCb */ 
         spFreezeSlr(cb, SP_FRZ_BT);
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         RETVOID;

      }

      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[OPSIDE(cb)].nwData->defConTmr.val;
      spStartConCbTmr(cb, CON_TMR);
      
      /* sp045.302 - modifcation - nwData moved to cs[] */
      cb->cs[OPSIDE(cb)].sls = spGetSls(cb->cs[OPSIDE(cb)].nwData, 
                                        cb->cs[OPSIDE(cb)].pc);
      cb->state = CON_ST;

      /* sp020.302 - modification - use prior from conCb */
      ret = spSendCoMsg(cb, OPSIDE(cb), cb->prior, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * send back con refused. Message is already encoded, so
          * data can not be sent in the conn refused message.
          */
         if (mBuf)
            SPutMsg(mBuf);
         spFreezeSlr(cb, SP_FRZ_BT);
         spConRefused(cb, RFC_NRQOST, ORIG_NET, NULLP);
         spFreeConCb(cb);
         /* sp034.302 - addition - return from here */
         RETVOID;
      }
      else
         /* update statistics for CR messages sent */
         spCb.sts.crTx++;
   } /* else called side remote */
   RETVOID;
} /* spConRequest */


/*
*
*       Fun:   spConConfirm
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spConConfirm
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PUBLIC Void spConConfirm(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   S16 ret;
   TRC2(spConConfirm)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[OPSIDE(cb)].pc == cb->cs[OPSIDE(cb)].nwData->selfPc) /* local */
   {
      SpConEvnt con;

      con.type = CE_CFM;

      /* generate connection confirm indication */
      cmCopy((U8 *) &cb->cs[OPSIDE(cb)].conId, (U8 *) &con.conId,
             sizeof(SpConId));

      /* quality of service set */
      cmCopy((U8 *) &cb->qos, (U8 *) &con.qos, sizeof(SpQosSet));

      /* responding address */
      cmCopySpAddr(&cb->t.req0.cdAddr, &con.t.cfm.rspAddr);

      if (cb->cType & SP_REQ0)
      {
         con.t.cfm.eds = cb->t.req0.eds;
         con.t.cfm.rcs = cb->t.req0.rcs;
      }
      else 
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP258, (ErrVal) cb->cType, "invalid ctype");
      }

#ifdef SPTV2
      /* importance is not relevant in conection confirm to upper
       * user. Mark it as not present
       */
      con.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

      cb->state = DTX_ST;

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
         (Void) SpUiSptConCfm(&cb->sap->pst, &con, data);
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
   }
   else                                  /* remote */
   {
      SpConCfm cc;
      Buffer *mBuf;

      cc.dLclRef.eh.pres = PRSNT_NODEF;
      cc.dLclRef.dLclRef.pres = PRSNT_NODEF;
      cc.dLclRef.dLclRef.val = cb->cs[OPSIDE(cb)].conId.suInstId;
      
      cc.sLclRef.eh.pres = PRSNT_NODEF;
      cc.sLclRef.sLclRef.pres = PRSNT_NODEF;
      cc.sLclRef.sLclRef.val = cb->cs[OPSIDE(cb)].conId.spInstId;

      cc.pClass.eh.pres = PRSNT_NODEF;
      cc.pClass.pClass.pres = PRSNT_NODEF;
      cc.pClass.pClass.val = cb->qos.pClass;

      if (cb->qos.pClass == PCLASS3)
      {
         cc.credit.eh.pres = PRSNT_NODEF;
         cc.credit.credit.pres = PRSNT_NODEF;
         cc.credit.credit.val = cb->qos.credit;
      }
      else
         cc.credit.eh.pres = NOTPRSNT;

      /* 
       * this in being sent from the called side to the calling side,
       */
      /* sp024.302 - modification - As per Q.712, 2.3, unlike connectionless,
       * in case of connection-oriented SCCP, called and calling address is
       * related to the direction of connection set-up i.e. independent of the
       * direction the message is going. So in CC, fill the same called address
       * as received in incoming CR message earlier and not the calling address
       * of the incoming CR.
       */
      if (cb->t.req0.cdAddr.pres)
      {
         cc.cdAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&cb->t.req0.cdAddr, &cc.cdAddr.spAddr);
      }
      else
         cc.cdAddr.eh.pres = NOTPRSNT;

      if (data)
      {
         cc.data.eh.pres = PRSNT_NODEF;
         cc.data.data.pres = PRSNT_NODEF;
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = data;
      }
      else
         cc.data.eh.pres = NOTPRSNT;

      if (cb->imp.pres == NOTPRSNT)
         cc.imp.eh.pres = NOTPRSNT;
      else
      {
         cc.imp.eh.pres = PRSNT_NODEF;
         cc.imp.importance.pres = PRSNT_NODEF;
         cc.imp.importance.val = cb->imp.val;
      }

      cc.endOp.eh.pres = PRSNT_NODEF;
      cc.endOp.endOp.pres = PRSNT_NODEF;
      cc.endOp.endOp.val = 0;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_CONCFM;;


      ret = SGetMsg(cb->cs[OPSIDE(cb)].nSap->pst.region, 
                    cb->cs[OPSIDE(cb)].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP259, (ErrVal) ret, "SGetMsg failed");
         if (data)
            (Void) SPutMsg(data);
         RETVOID;
      }

      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE, 
                  cb->cs[OPSIDE(cb)].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP260, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         spFreezeSlr(cb, SP_FRZ_BT);

         /* refuse connection to calling side */
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);

         /* free & freeze the local reference */
         spFreeConCb(cb);
         RETVOID;
      }

      SPENCPDU(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &cc);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP261, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         /* freeze both */
         spFreezeSlr(cb, SP_FRZ_BT);

         /* refuse connection to calling side */
         spConRefused(cb, RFC_UNQUAL, ORIG_NET, NULLP);

         /* free the con cb */
         spFreeConCb(cb);
         RETVOID;
      }

      /* start inactivity timers (for remote only) */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[CG_SIDE].nwData->defIasTmr.val;
      spStartConCbTmr(cb, CG_IAS_TMR);
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[CG_SIDE].nwData->defIarTmr.val;
      spStartConCbTmr(cb, CG_IAR_TMR);

      cb->state = DTX_ST;

      /* sp045.302 - modification - nwData moved to cs[] */
      cb->cs[OPSIDE(cb)].sls = spGetSls(cb->cs[OPSIDE(cb)].nwData, 
                                        cb->cs[OPSIDE(cb)].pc);

      ret = spSendCoMsg(cb, OPSIDE(cb), SN_PRI1, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
   } /* else remote */
#ifdef ZP
   zpRunTimeUpd(ZP_SP_CONCB, (Void *)cb, 
                CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_ADD);
#endif /* ZP */
   RETVOID;
} /* spConConfirm */


/*
*
*       Fun:   spSendRelCmp
*
*       Desc:  Send a release complete when there is no control block
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spSendRelCmp
(
SpNSapCb *nSap,           /* network sap */
Dpc pc,                   /* point code */
InstId sRef,              /* source reference */
InstId dRef,              /* dest reference */
U8 ssf                   /* sub-service field */
)
#else
PUBLIC Void spSendRelCmp(nSap, pc, sRef, dRef, ssf)
SpNSapCb *nSap;          /* network sap */
Dpc pc;                  /* point code */
InstId sRef;             /* source reference */
InstId dRef;             /* dest reference */
U8 ssf;                  /* sub-service field */
#endif
{
   SpRelCmp rc;
   Buffer *mBuf;
   S16 ret;
   SrvInfo sInfo;
   SpRteKey rKey; /* sp011.302 - Added to find route */
   SpRteCb *rCb;  /* sp011.302 - Added to find route */

   TRC2(spSendRelCmp)

   /* reverse the references for the return trip */
   rc.dLclRef.eh.pres = PRSNT_NODEF;
   rc.dLclRef.dLclRef.pres = PRSNT_NODEF;
   rc.dLclRef.dLclRef.val = sRef;

   /* this is meaningless to us, but hopefully meaningful to caller */
   rc.sLclRef.eh.pres = PRSNT_NODEF;
   rc.sLclRef.sLclRef.pres = PRSNT_NODEF;
   rc.sLclRef.sLclRef.val = dRef;

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_RELCMP;

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   /* find route */
   rKey.k1.dpc = pc;
   rKey.k1.nwId = nSap->nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);


   /* before encoding message, check whether message can be
    * discarded due to traffic limitation mechanism
    */
   if ((nSap->nwData->variant == SW_ITU) && (spCb.spTrfLimFlag == TRUE))
   {
      U8 imp;

      if ((rCb != NULLP) && (rCb->swtch == LSP_SW_ITU96))
      {
         /* get default importance from database for message RLC */
         imp = spCb.spMsgImp.defRlcImp;
         ret = spFindRestriction(rCb, imp);
         if (ret == SP_DISCARD)
         {
            SpReport spRep;       /* sccp error perf report */

            /* fill sccp error report */
            cmZero((U8 *) &spRep, sizeof(SpReport));

            spRep.nwId = rCb->nSap->nwData->nwId;
            spRep.sw = rCb->nSap->nwData->variant;
            spRep.dpc = rCb->dpc;

            /* generate sccp error performance report */
            spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                             &spRep);
            RETVOID;
         }
      }
   } /* if ((...variant == SW_ITU) && (spTrfLimFlag == TURE)) */

   ret = SGetMsg(nSap->pst.region, nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP262, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* encode message header */
   SPENCPDUHDR(&nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, nSap->nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP263, (ErrVal) ret, "SPENCPDUHDR failed");
      SPutMsg(mBuf);
      RETVOID;
   }

   /* encode message */
   SPENCPDU(&nSap->mfMsgCtl, ret, (ElmtHdr *) &rc);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP264, (ErrVal) ret, "SPENCPDU failed");
      SPutMsg(mBuf);
      RETVOID;
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   if (rCb == (SpRteCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"No route");
      spDropMsg(&mBuf);
      RETVOID;
   }

   if (!(rCb->status & SP_ONLINE))
   {
       spDropMsg(&mBuf);
#if (ERRCLASS & ERRCLS_INT_PAR)
       SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"PC not available");
#endif /* ERRCLASS */
       RETVOID;
   }

   /* send it explicitly without spSendCoMsg()) */
   sInfo = ((ssf << 6) | SCCP_SI);

   if (!(nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* send it explicitly without spSendCoMsg()) */
   sInfo = ((ssf << 6) | SCCP_SI);

   if (!(nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   (Void) SpLiSntUDatReq(&nSap->pst, nSap->spId, nSap->nwData->selfPc, pc,
                         sInfo, spGetSls (nSap->nwData, pc), (Priority) SN_PRI2,
                         mBuf);
   RETVOID;
} /* spSendRelCmp */


/*
*
*       Fun:   spSendBackConRefused
*
*       Desc:  Send an error when there is no control block
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spSendBackConRefused
(
SpNSapCb *nSap,           /* network sap */
Dpc opc,                  /* originating point code */
TknStr *cdAddr,           /* called address (TknStr) */
U8 cause,                 /* cause */
U8 ssf,                   /* Sub-Service field */
Buffer *data              /* data buffer used to process CR */
)
#else
PUBLIC Void spSendBackConRefused(nSap, opc, cdAddr, cause, ssf, data)
SpNSapCb *nSap;           /* network sap */
Dpc opc;                  /* originating point code */
TknStr *cdAddr;           /* called address (TknStr) */
U8 cause;                 /* cause */
U8 ssf;                   /* Sub-Service field */
Buffer *data;             /* data buffer used to process CR */
#endif
{
   SpConRef cr;
   Buffer *mBuf;
   S16 ret;
   U16 i;
   SpRteKey rKey; /* sp011.302 - Added to find route */
   SpRteCb *rCb;  /* sp011.302 - Added to find route */

   TRC2(spSendBackConRefused)

   /* Drop the data buffer as there is no need for this buffer. This
    * buffer contain the information required to process the connection 
    * request from remote end
    */
   if (data != NULLP)
   {
      spDropMsg(&data);
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   rKey.k1.dpc = opc;
   rKey.k1.nwId = nSap->nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   /* before encoding message, check whether message should
    * be discarded due to traffic limitation mechanism
    */
   if ((nSap->nwData->variant == SW_ITU) && (spCb.spTrfLimFlag == TRUE))
   {
      U8 imp;                 /* message importance */

      if ((rCb != NULLP) && (rCb->swtch == LSP_SW_ITU96))
      {
         /* get default importance from database for message CREF */
         imp = spCb.spMsgImp.defCrefImp;
         ret = spFindRestriction(rCb, imp);
         if (ret == SP_DISCARD)
         {
            SpReport spRep;       /* sccp error perf report */

            /* fill sccp error report */
            cmZero((U8 *) &spRep, sizeof(SpReport));

            spRep.nwId = rCb->nSap->nwData->nwId;
            spRep.sw = rCb->nSap->nwData->variant;
            spRep.dpc = rCb->dpc;

            /* generate sccp error performance report */
            spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                             &spRep);
            RETVOID;
         }
      }
   } /* if ((...variant == SW_ITU) && (spTrfLimFlag == TURE)) */

   cr.dLclRef.eh.pres = PRSNT_NODEF;
   cr.dLclRef.dLclRef.pres = PRSNT_NODEF;
   cr.dLclRef.dLclRef.val = nSap->mfMsgCtl.sccpInfo.srcLclRef;

   cr.refCause.eh.pres = PRSNT_NODEF;
   cr.refCause.refCause.pres = PRSNT_NODEF;
   cr.refCause.refCause.val = cause;

   cr.cdAddr.eh.pres = PRSNT_NODEF;
   cr.cdAddr.spAddr.pres = PRSNT_NODEF;
   cr.cdAddr.spAddr.len = cdAddr->len;
   for (i = 0; i < cdAddr->len; i++)
      cr.cdAddr.spAddr.val[i] = cdAddr->val[i];

   if (nSap->mfMsgCtl.sccpInfo.data)
   {
      cr.data.eh.pres = PRSNT_NODEF;
      cr.data.data.pres = PRSNT_NODEF;
      cr.data.data.val = 0;
   }
   else
      cr.data.eh.pres = NOTPRSNT;

   cr.imp.eh.pres = NOTPRSNT;

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_CONREF;

   ret = SGetMsg(nSap->pst.region, nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP265, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* Encode message */
   SPENCPDUHDR(&nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, nSap->nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP266, (ErrVal) ret, "SPENCPDUHDR failed");
      SPutMsg(mBuf);
      RETVOID;
   }

   SPENCPDU(&nSap->mfMsgCtl, ret, (ElmtHdr *) &cr);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP267, (ErrVal) ret, "SPENCPDU failed");
      SPutMsg(mBuf);
      RETVOID;
   }

   /* send it explicitly without spSendCoMsg (No Cb)
    * invoke lower interface primitive
    */
   if (!(nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   if (rCb == (SpRteCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"No route");
      spDropMsg(&mBuf);
      RETVOID;
   }

   if (!(rCb->status & SP_ONLINE))
   {
       spDropMsg(&mBuf);
       SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"PC not available");
       RETVOID;
   }

   (Void) SpLiSntUDatReq(&nSap->pst, nSap->spId, nSap->nwData->selfPc, opc,
                         (U8) ((ssf << 6) | (U8) SCCP_SI), 
                         spGetSls(nSap->nwData, opc), (Priority) SN_PRI1, mBuf);

   /* update statistics for CREF message sent */
   spCb.sts.crefTx++;
   RETVOID;
} /* spSendBackConRefused */


/*
*
*       Fun:   spSendCoMsg
*
*       Desc:  Encapsulate the actual MTP3 transfer routine so that
*              we can add functionality as required.
*              Possible additions include: 
*              1) Better flow control mechanisms between SCCP & MTP3
*              2) Better congestion control mechanisms between SCCP & MTP3
*
*       Ret:   SP_OK      - message delivered successfully to lower layer.
*              SP_DISCARD - message is discarded due to traffic limitations.
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC S16 spSendCoMsg
(
SpConCb *cb,           /* connection control block */
U8 side,               /* side to send on */
Priority pri,          /* priority of message */
U8 imp,                /* message importance */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 spSendCoMsg(cb, side, pri, imp, mBuf)
SpConCb *cb;           /* connection control block */
U8 side;               /* side to send on */
Priority pri;          /* priority of message */
U8 imp;                /* message importance */
Buffer *mBuf;          /* message buffer */
#endif
{
   SrvInfo sInfo;      /* service info */
   S16 ret;            /* return value */
   SpRteKey rKey; /* sp011.302 - Added to find route */
   SpRteCb *rCb;  /* sp011.302 - Added to find route */

   TRC2(spSendCoMsg)
   
   /* There is no need to check the status of spAudFlag at this point 
    * as we r not taking any action based on its value. Besides this 
    * it will add overhead in this function to check the flag status */

   cb->nmbItTx = 0;
   sInfo = ((cb->ssf << 6) | SCCP_SI);
   if (!(cb->cs[side].nSap->status & SP_BND))
   {
      /* sp012.302 - Do not drop message as it is only a copy */ 
      RETVALUE(SP_DISCARD);
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   rKey.k1.dpc = cb->cs[side].pc;
   /* sp045.302 - modification - using nwId from nSap's nwData, this
    * is done to get network id of the outgoing network.
    */
   rKey.k1.nwId = cb->cs[side].nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   if ((cb->cs[side].nSap->nwData->variant == SW_ITU) &&
       (spCb.spTrfLimFlag == TRUE))
   {
      /* though rCb should not be null, but it is possible when
       * during the life of this connection, sccp route is deleted
       */
      if ((rCb != NULLP) && (rCb->swtch == LSP_SW_ITU96))
      {
         ret = spFindRestriction(rCb, imp);
         if (ret != SP_OK)
         {
            SpReport spRep;       /* sccp error perf report */

            /* fill sccp error report */
            cmZero((U8 *) &spRep, sizeof(SpReport));

            spRep.nwId = rCb->nSap->nwData->nwId;
            spRep.sw = rCb->nSap->nwData->variant;
            spRep.dpc = rCb->dpc;

            /* generate sccp error performance report */
            spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                             &spRep);
            RETVALUE(ret);
         }
      } /* if ((rCb != NULLP) && (rCb->swtch == LSP_SW_ITU96)) */
   } /* if (...variant == SW_ITU) && ...spTrfLimFlag == TRUE) */

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   if (rCb == (SpRteCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"No route");
      /* sp012.302 - Do not drop message as it is only a copy */ 
      RETVALUE(SP_DISCARD); 
   }

   if (!(rCb->status & SP_ONLINE))
   {
       /* sp012.302 - Do not drop message as it is only a copy */ 
       SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"PC not available");
       RETVALUE(SP_DISCARD);
   }
   /* invoke lower interface primitive */
   /* sp045.302 - modification - pass the correct opc from cs[]'s nwData */ 
   (Void) SpLiSntUDatReq(&cb->cs[side].nSap->pst, cb->cs[side].nSap->spId, 
                         cb->cs[side].nwData->selfPc, cb->cs[side].pc, sInfo,
                         cb->cs[side].sls, (Priority) pri, mBuf);
   RETVALUE(SP_OK);
} /* spSendCoMsg */


/*
*
*       Fun:   spConRefFromConReq
*
*       Desc:  Send back a connection refused based on a Request Type 2
*              Interface Primitive (ISUP end or intermediate node)
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spConRefFromConReq
(
SpSapCb *sap,          /* sap */
SpConEvnt *ce          /* connection event */
)
#else
PUBLIC Void spConRefFromConReq(sap, ce)
SpSapCb *sap;          /* sap */
SpConEvnt *ce;         /* connection event */
#endif
{
   S16 ret;
   Buffer *mBuf;
   SpConRef cr;
   SpRteKey rKey;
   SpRteCb *rCb;

   TRC2(spConRefFromConReq)

   /* Form the route key for searching */
   rKey.k1.dpc = ce->t.req2.opc;
   rKey.k1.nwId = sap->nwData->nwId;

   /* find route */
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   if (rCb == (SpRteCb *) NULLP)
   {
      /* sp011.302 - SPLOGERROR should be in ERRCLASS defines */
      SPLOGERROR(ERRCLS_INT_PAR, ESP268, (ErrVal) ERRZERO, "No route");
      RETVOID;
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   if (!(rCb->status & SP_ONLINE))
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
       SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"PC not available");
#endif /* ERRCLASS */
       RETVOID;
   }

   ret = SGetMsg(rCb->nSap->pst.region, rCb->nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP269, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   cr.dLclRef.eh.pres = PRSNT_NODEF;
   cr.dLclRef.dLclRef.pres = PRSNT_NODEF;
   cr.dLclRef.dLclRef.val = ce->t.req2.slr;

   cr.refCause.eh.pres = PRSNT_NODEF;
   cr.refCause.refCause.pres = PRSNT_NODEF;
   cr.refCause.refCause.val = RFC_NRQOST;

   cr.imp.eh.pres = NOTPRSNT;

   cr.cdAddr.eh.pres = NOTPRSNT;
   cr.data.eh.pres = NOTPRSNT;
   cr.endOp.eh.pres = PRSNT_NODEF;

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_CONREF;

   SPENCPDUHDR(&rCb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, sap->nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP270, (ErrVal) ret, "SPENCPDUHDR failed");
      if (mBuf)
          SPutMsg(mBuf);
      RETVOID;
   }

   SPENCPDU(&rCb->nSap->mfMsgCtl, ret, (ElmtHdr *) &cr);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP271, (ErrVal) ret, "SPENCPDU failed");
      if (mBuf)
         SPutMsg(mBuf);
      RETVOID;
   }

   if (!(rCb->nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   (Void) SpLiSntUDatReq(&rCb->nSap->pst, rCb->nSap->spId,
                         rCb->nSap->nwData->selfPc, ce->t.req2.opc,
                         rCb->nSap->nwData->sInfo,
                         spGetSls(sap->nwData, ce->t.req2.opc),
                         (Priority) SN_PRI1, mBuf);

   /* update statistics for CREF messages sent */
   spCb.sts.crefTx++;

   RETVOID;
} /* spConRefFromConReq */


/*
*
*       Fun:   spHandleBadDLR
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*              CCITT Blue Book Table B-2/Q.714 pp. 478
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spHandleBadDLR
(
SpNSapCb *nSap,         /* connection control block */
Dpc opc,                /* originating point code */
U8 ssf,                 /* sub-service field */
Buffer *data            /* message buffer */
)
#else
PUBLIC Void spHandleBadDLR(nSap, opc, ssf, data)
SpNSapCb *nSap;         /* connection control block */
Dpc opc;                /* originating point code */
U8 ssf;                 /* sub-service field */
Buffer *data;           /* message buffer */
#endif
{

   TRC2(spHandleBadDLR)

   switch (nSap->mfMsgCtl.msgType)
   {
      /* ERRORS */
      case M_CONCFM:
      case M_RSTREQ:
      case M_RSTCFM:
         /* sp005.302 - modification - pass dstLclRef in ERR msg, i.e
          * srcLclRef from the received bad DLR message
          */
         spSendPduErr(nSap, opc, nSap->mfMsgCtl.sccpInfo.srcLclRef, ERR_LRNUD,
                      ssf);
         break;

      /* LCM_REASONABLE */
      case M_RELSD:
         spSendRelCmp(nSap, opc, nSap->mfMsgCtl.sccpInfo.srcLclRef,
                      nSap->mfMsgCtl.sccpInfo.dstLclRef, ssf);
         break;

      /* DISCARD */
      case M_CONREF:
      case M_RELCMP:
      case M_DATA1:
      case M_DATA2:
      case M_DATAACK:
      case M_EXPDATA:
      case M_EXPDATAACK:
      case M_PDUERR:
      case M_INACTST:
         break;

      /* FATAL */
      case M_CONREQ:
      case M_UNITDATA:
      case M_UNITDATASRV:
      case M_XUNITDATA:
      case M_XUNITDATASRV:
      default:
         SPLOGERROR(ERRCLS_DEBUG, ESP272, (ErrVal) nSap->mfMsgCtl.msgType,
                    "invalid message type");
         break;
   } /* switch (...msgType) */

   /* discard the data/message buffer */
   spDropMsg(&data);
   RETVOID;
} /* spHandleBadDLR */


/*
*
*       Fun:   spHandleBadOPC
*
*       Desc:  originating point code does not match stored point code.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*              CCITT Blue Book Table B-2/Q.714 pp. 478
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spHandleBadOPC
(
SpConCb *cb,           /* connection control block */
Dpc opc,               /* originating point code */
Buffer *data           /* message buffer */
)
#else
PUBLIC Void spHandleBadOPC(cb, opc, data)
SpConCb *cb;        /* connection control block */
Dpc opc;               /* originating point code */
Buffer *data;          /* message buffer */
#endif
{
   TRC2(spHandleBadOPC)

   switch (cb->cs[SIDE(cb)].nSap->mfMsgCtl.msgType)
   {
      case M_RELSD:
      case M_RSTREQ:
      case M_RSTCFM:
         /* sp005.302 - modification - pass dstLclRef in ERR msg, i.e
          * srcLclRef from the received bad OPC message
          */
         spSendPduErr(cb->cs[SIDE(cb)].nSap, opc, 
                      cb->cs[SIDE(cb)].nSap->mfMsgCtl.sccpInfo.srcLclRef, 
                      ERR_PCMM, cb->ssf);
         break;
      /* when porting to different national variants, implementors
       * may wish to include cases here for other message types.  
       * These would be for other message type where this condition
       * is somehow meaningful.
       */
      default:
         break;
   } /* switch (...msgType) */

   /* discard the data/message buffer */
   if (data)
      (Void) SPutMsg(data);

   /* remain in current state, (i.e. continue) */
   RETVOID;
} /* spHandleBadOPC */


/*
*
*       Fun:   spHandleBadSLR
*
*       Desc:  source local reference does not match stored slr.
*
*       Ret:   void
*
*       Notes: Connection Oriented Control
*              CCITT Blue Book Table B-2/Q.714 pp. 478
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spHandleBadSLR
(
SpConCb *cb,           /* connection control block */
Dpc opc,               /* originating point code */
Buffer *data           /* message buffer */
)
#else
PUBLIC Void spHandleBadSLR(cb, opc, data)
SpConCb *cb;           /* connection control block */
Dpc opc;               /* originating point code */
Buffer *data;          /* message buffer */
#endif
{
   U32 suInstId;     /* remote SLR */

   TRC2(spHandleBadSLR)

   switch (cb->cs[SIDE(cb)].nSap->mfMsgCtl.msgType)
   {
      case M_RELSD:
      case M_RSTREQ:
      case M_RSTCFM:
         /* sp005.302 - modification - pass dstLclRef in ERR msg, i.e
          * srcLclRef from the received bad SLR message
          */
         spSendPduErr(cb->cs[SIDE(cb)].nSap, opc, 
                      cb->cs[SIDE(cb)].nSap->mfMsgCtl.sccpInfo.srcLclRef, 
                      ERR_LRNIS, cb->ssf);
         break;

      case M_INACTST:
      {
         /* sp016.302 - addition */
         S16 ret;
         Buffer *data1;
         Buffer *data2;

         /* sp016.302 - addition - copy buffers */
         if (data != (Buffer *) NULLP)
         {
            ret = SCpyMsgMsg(data, spCb.spInit.region, spCb.spInit.pool,
                             &data1);
            if (ret != ROK)
            {
               SPLOGERROR(ERRCLS_ADD_RES, ESPXXX, (ErrVal) ret,
                          "SCpyMsgMsg failed");
               RETVOID;
            }

            ret = SCpyMsgMsg(data, spCb.spInit.region, spCb.spInit.pool,
                             &data2);
            if (ret != ROK)
            {
               SPLOGERROR(ERRCLS_ADD_RES, ESPXXX, (ErrVal) ret,
                          "SCpyMsgMsg failed");
               RETVOID;
            }
         }
         else
         {
            data1 = (Buffer *) NULLP;
            data2 = (Buffer *) NULLP;
         }

         /* first stop any inactivity timers */
         if (cb->cType & SP_ORIG) /* I'm an originating node */
         {
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CD_IAR_TMR);
         }
         else if (cb->cType & SP_DEST) /* I'm an destination node */
         {
            spRmvConCbTq(cb, CG_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);
         }
         else if (cb->cType & SP_INTR) /* I'm an intermediate node */
         {
            spRmvConCbTq(cb, CD_IAR_TMR);
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);
            spRmvConCbTq(cb, CG_IAS_TMR);
         }

         /* send release with DLR as incoming SLR */
         suInstId = cb->cs[SIDE(cb)].conId.suInstId;
         cb->cs[SIDE(cb)].conId.suInstId = 
                     cb->cs[SIDE(cb)].nSap->mfMsgCtl.sccpInfo.srcLclRef;
         spRelease(cb, SIDE(cb), RLC_INCONDT, ORIG_NET, data);
         cb->cs[SIDE(cb)].conId.suInstId = suInstId;
         /* No need to stop teh timer as we will restart it in 
          * the following spRelease fn call */ 

         /* now start release with local stored SLR */
         /* release in both directions */
         /* sp016.302 - modification - pass new duplicated buffer */
         spRelease(cb, CG_SIDE, RLC_INCONDT, ORIG_NET, data1);
         spRelease(cb, CD_SIDE, RLC_INCONDT, ORIG_NET, data2);

         /* Update statistics */
         spCb.sts.prvInitRel++;
 
         RETVOID;
      }
      /* when porting to different national variants, implementors
       * may wish to include cases here for other message types.  
       * These would be for other message type where this condition
       * is somehow meaningful.
       */

      default:
         break;
   } /* switch (...msgType) */

   /* discard the data/message buffer */
   if (data)
      (Void) SPutMsg(data);

   /* remain in current state, (i.e. continue) */
   RETVOID;
} /* spHandleBadSLR */


/*
*
*       Fun:   spSendPduErr
*
*       Desc:  Send an error message to a remote SCCP
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spSendPduErr
(
SpNSapCb *nSap,     /* network sap */
Dpc dpc,            /* destination point code */
InstId dlr,         /* destination local reference */
U8 ec,              /* error cause */
U8 ssf              /* sub-service field */
)
#else
PUBLIC Void spSendPduErr(nSap, dpc, dlr, ec, ssf)
SpNSapCb *nSap;     /* network sap */
Dpc dpc;            /* destination point code */
InstId dlr;         /* destination local reference */
U8 ec;              /* error cause */
U8 ssf;             /* sub-service field */
#endif
{
   S16 ret;         /* return value */
   SpPduErr err;    /* pdu ERR */
   Buffer *mBuf;    /* message buffer */
   SrvInfo sInfo;   /* service information octet */
   SpRteKey rKey;   /* route key */
   SpRteCb *rCb;    /* route contrl block */

   TRC2(spSendPduErr)

   err.dLclRef.eh.pres = PRSNT_NODEF;
   err.dLclRef.dLclRef.pres = PRSNT_NODEF;
   err.dLclRef.dLclRef.val = dlr;
   err.errCause.eh.pres = PRSNT_NODEF;
   err.errCause.errCause.pres = PRSNT_NODEF;
   err.errCause.errCause.val = ec;

   /* sp008.302 - addition - initialize presence of endOp */
   err.endOp.eh.pres = PRSNT_NODEF;
   err.endOp.endOp.pres = PRSNT_NODEF;
   err.endOp.endOp.val = 0;

   spCb.pduHdr.eh.pres = TRUE;
   spCb.pduHdr.msgType.pres = TRUE;
   spCb.pduHdr.msgType.val = M_PDUERR;

   ret = SGetMsg(nSap->pst.region, nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP273, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* find route */
   rKey.k1.dpc = dpc;
   rKey.k1.nwId = nSap->nwData->nwId;
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   /* ERR message should not be sent on GSM route */
   if ((rCb != (SpRteCb *) NULLP) && (rCb->swtch == LSP_SW_GSM0806))
   {
      /* sp040.302 - addition - free buffer allocated for ERR msg */
      if (mBuf != (Buffer *) NULLP)
         SPutMsg(mBuf);
      RETVOID;
   }

   /* the case when rCb is null could occur when ERR messages is
    * to be sent in response to a connection oriented message with
    * bad opc is received and hence rCb null is valid case.
    */

   /* check whether message should be discarded due to
    * traffic limitation mechanism
    */
   if ((rCb != (SpRteCb *) NULLP) && (rCb->swtch == LSP_SW_ITU96))
   {
      U8 imp;

      /* get default importance from database */
      imp = spCb.spMsgImp.defErrImp;
      ret = spFindRestriction(rCb, imp);
      if (ret == SP_DISCARD)
      {
         SpReport spRep;       /* sccp error perf report */

         /* sp040.302 - addition - free buffer allocated for ERR msg */
         if (mBuf != (Buffer *) NULLP)
            SPutMsg(mBuf);

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = rCb->nSap->nwData->nwId;
         spRep.sw = rCb->nSap->nwData->variant;
         spRep.dpc = rCb->dpc;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                          &spRep);
         RETVOID;
      }
   } /* if (rCb->swtch == LSP_SW_ITU96) */

   SPENCPDUHDR(&nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, nSap->nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      SPutMsg(mBuf);       /* return message to buffer pool */
      SPLOGERROR(ERRCLS_DEBUG, ESP274, (ErrVal) ret, "SPENCPDUHDR failed");
      RETVOID;
   }

   SPENCPDU(&nSap->mfMsgCtl, ret, (ElmtHdr *) &err);

   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP275, (ErrVal) ret, "SPENCPDU failed");
      if (mBuf)
         SPutMsg(mBuf);
      RETVOID;
   }

   /* we send this directly (without spSendCoMsg())
    * invoke lower interface primitive
    */
   sInfo = ((ssf << 6) | SCCP_SI);

   if (!(nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* sp011.302 - Added check for route availability.  Do No send */
   /*             the message if route is no longer available */
   if (rCb == (SpRteCb*)NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"No route");
      spDropMsg(&mBuf);
      RETVOID;
   }

   if (!(rCb->status & SP_ONLINE))
   {
       spDropMsg(&mBuf);
       SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ERRZERO,"PC not available");
       RETVOID;
   }

   SpLiSntUDatReq(&nSap->pst, nSap->spId, nSap->nwData->selfPc, dpc, sInfo,
                  spGetSls (nSap->nwData, dpc), (Priority)SN_PRI1,  mBuf);

   /* update statistics for ERR messages sent */
   spCb.sts.errTx++;
   RETVOID;
} /* spSendPduErr */


/*
*
*       Fun:   spDat1Tx
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spDat1Tx
(
SpConCb *cb,           /* connection control block */
Buffer *data,          /* message buffer */
Bool more              /* more data? */
)
#else
PUBLIC Void spDat1Tx(cb, data, more)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
Bool more;               /* more data? */
#endif
{
   S16 ret;
   Buffer *mBuf;

   TRC2(spDat1Tx)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[OPSIDE(cb)].pc == cb->cs[OPSIDE(cb)].nwData->selfPc) /* local */
   {
      
      if (more) /* there is more data coming... */
      {
         if (cb->cs[OPSIDE(cb)].segBuf == (Buffer *) NULLP)
            cb->cs[OPSIDE(cb)].segBuf = data; /* no segmentation buffer, set */
         else
         {                       /* concatenate existing with new */
            (Void) SCatMsg(cb->cs[OPSIDE(cb)].segBuf, data, M1M2);
            (Void) SPutMsg(data);
         }
         /* thats, all, return */
         RETVOID;
      }
      else /* there is no more data, prepare for indication */
      {
         SpDatEvnt dat;

         if (cb->cs[OPSIDE(cb)].segBuf == (Buffer *) NULLP)
            cb->cs[OPSIDE(cb)].segBuf = data; /* no segmentation buffer, set */
         else
         {                       /* concatenate existing with new */
            (Void) SCatMsg(cb->cs[OPSIDE(cb)].segBuf, data, M1M2);
            (Void) SPutMsg(data);
         }

         /* set up data indication */
         cmCopy((U8 *) &cb->cs[OPSIDE(cb)].conId, (U8 *) &dat.conId, 
                sizeof(SpConId));

         dat.cfmReq = FALSE;    /* this is for further study */
         dat.conId.suId = cb->sap->suId; /* set suid */

#ifdef SPTV2
         /* importance is not relevant in data indication to upper
          * user. Mark it as not present
          */
         dat.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

         /* check if the user has bound */
         if (cb->sap->status & SP_BND)
         {
            Buffer *segBuf;   /* sp005.302 - addition - data buffer */

            /* sp005.302 - modification - reset segBuf to null before sending
             * data indication up to user, for, if user is tightly coupled and
             * on data indication, user again sends another data on the conn.
             * then conn side will change.
             */
            segBuf = cb->cs[OPSIDE(cb)].segBuf;

            /* reset segBuf to NULLP */
            cb->cs[OPSIDE(cb)].segBuf = (Buffer *) NULLP;
         
            /* update statistics for DT1 messages received */
            cb->sap->sts.dt1MsgRx++;

            (Void) SpUiSptDatInd(&cb->sap->pst, &dat, segBuf);
         }
         else
         {
            /* sp018.302 - addition - check segBuf not being null */
            if (cb->cs[OPSIDE(cb)].segBuf != (Buffer *) NULLP)
            {
               SPutMsg(cb->cs[OPSIDE(cb)].segBuf);
               cb->cs[OPSIDE(cb)].segBuf = (Buffer *) NULLP;
            }
         }

         RETVOID;
      } /* else - no more data */
   }
   else
   {                                          /* DESTINATION IS REMOTE */
      SpData1 dat;

      /* no worries about more data,
       * segmenting and reassembly occur
       * only at endpoints 
       */

      dat.dLclRef.eh.pres = PRSNT_NODEF;
      dat.dLclRef.dLclRef.pres = PRSNT_NODEF;
      dat.dLclRef.dLclRef.val = cb->cs[OPSIDE(cb)].conId.suInstId;

      dat.segReas.eh.pres = PRSNT_NODEF;
      dat.segReas.segReas.pres = PRSNT_NODEF;
      dat.segReas.segReas.val = more;

      dat.data.eh.pres = PRSNT_NODEF;
      dat.data.data.pres = PRSNT_NODEF;
      dat.data.data.val = TRUE;

      cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = data;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_DATA1;

      ret = SGetMsg(cb->cs[OPSIDE(cb)].nSap->pst.region, 
                    cb->cs[OPSIDE(cb)].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         (Void) SPutMsg(data);
         SPLOGERROR(ERRCLS_ADD_RES, ESP276, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE, 
                  cb->cs[OPSIDE(cb)].nwData->variant, MF_SCCP);
      if (ret != ROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
         /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         SPLOGERROR(ERRCLS_DEBUG, ESP277, (ErrVal) ret, "SPENCPDUHDR failed");
         RETVOID;
      }

      SPENCPDU(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &dat);
      if (ret != MFROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
           /* sp035.302 - addition - assigning explicit NULL to 
            * data pointer to avoid double deallocation. 
            */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         SPLOGERROR(ERRCLS_DEBUG, ESP278, (ErrVal) ret, "SPENCPDU failed");
         RETVOID;
      }

      /* check for timer's existence */
      spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));

      /* restart interval timer */
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[OPSIDE(cb)].nwData->defIasTmr.val;
      spStartConCbTmr(cb, IAS_TMR(OPSIDE(cb)));

      /* Prior should match Connection Request! */
      /* sp020.302 - modification - use prior from conCb to match it with
       * that in CR
       */
      ret = spSendCoMsg(cb, OPSIDE(cb), cb->prior, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
   } /* else destination remote */
   RETVOID;
} /* spDat1Tx */


/*
*
*       Fun:   spDat2Tx
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spDat2Tx
(
SpConCb *cb,           /* connection control block */
Buffer *data,          /* message buffer */
Bool more              /* more data ? */
)
#else
PUBLIC Void spDat2Tx(cb, data, more)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
Bool more;             /* more data? */
#endif
{
   S16 ret;       /* return value */
   Buffer *mBuf;  /* message buffer */
   Bool txOk;     /* okay to transmit */

   TRC2(spDat2Tx)

   txOk = TRUE; /* as far as we know we can transmit */

   /* all data transfers are sent to the opposite side */
   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[OPSIDE(cb)].pc == cb->cs[OPSIDE(cb)].nwData->selfPc) /* local */
   {
      if (more) /* there is more data coming... */
      {
         if (cb->cs[OPSIDE(cb)].segBuf == (Buffer *) NULLP)
         {
            /* no segmentation buffer, simply attach it */
            cb->cs[OPSIDE(cb)].segBuf = data; 
         }
         else
         {                       /* concatenate existing with new */
            (Void) SCatMsg(cb->cs[OPSIDE(cb)].segBuf, data, M1M2);
            (Void) SPutMsg(data);
         }
      }
      else /* there is no more data, prepare for indication */
      {
         SpDatEvnt dat;

         if (cb->cs[OPSIDE(cb)].segBuf == (Buffer *) NULLP)
         {
            /* no segmentation buffer, set */
            cb->cs[OPSIDE(cb)].segBuf = data; 
         }
         else
         {                       /* concatenate existing with new */
            (Void) SCatMsg(cb->cs[OPSIDE(cb)].segBuf, data, M1M2);
            (Void) SPutMsg(data);
         }

         /* set up data indication */
         cmCopy((U8*)&cb->cs[OPSIDE(cb)].conId, (U8*)&dat.conId, 
                sizeof(SpConId));
         dat.cfmReq = FALSE; /* this is for further study */
         dat.conId.suId = cb->sap->suId;

#ifdef SPTV2
         /* importance is not relevant in data indication to upper
          * user. Mark it as not present
          */
         dat.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

         /* check if the user has bound */
         if (cb->sap->status & SP_BND)
         {
            Buffer *segBuf;   /* sp005.302 - addition - data buffer */

            /* sp005.302 - modification - reset segBuf to null before sending
             * data indication up to user, for, if user is tightly coupled and
             * on data indication, user again sends another data on the conn.
             * then conn side will change.
             */
            segBuf = cb->cs[OPSIDE(cb)].segBuf;

            /* reset segBuf to NULLP */
            cb->cs[OPSIDE(cb)].segBuf = (Buffer *) NULLP;

            /* update statistics for DT2 messages received */
            cb->sap->sts.dt2MsgRx++;

            (Void) SpUiSptDatInd(&cb->sap->pst, &dat, segBuf);
         }
         else
         {
            /* sp018.302 - addition - check segBuf not being null */
            if (cb->cs[OPSIDE(cb)].segBuf != (Buffer *) NULLP)
            {
               SPutMsg(cb->cs[OPSIDE(cb)].segBuf);
               cb->cs[OPSIDE(cb)].segBuf = (Buffer *) NULLP;
            }
         }
      } /* else no more data */
   }                                          /* DESTINATION IS REMOTE */
   else
   {
      SpData2 dat;   /* data event */
      QLen qLen;

      SFndLenQueue(&cb->cs[OPSIDE(cb)].datQ, &qLen);

      /* Flow Control */
      dat.dLclRef.eh.pres = PRSNT_NODEF;
      dat.dLclRef.dLclRef.pres = PRSNT_NODEF;
      dat.dLclRef.dLclRef.val = 
         cb->cs[OPSIDE(cb)].conId.suInstId;

      dat.seqSeg.eh.pres = PRSNT_NODEF;
      dat.seqSeg.senSeqNum.pres = PRSNT_NODEF;
      dat.seqSeg.senSeqNum.val = 0;

      dat.seqSeg.moreData.pres = PRSNT_NODEF;
      dat.seqSeg.moreData.val = more;


      dat.seqSeg.recSeqNum.pres = PRSNT_NODEF;
      dat.seqSeg.recSeqNum.val = 0;

      /* Determine if we should send this message */
      if (!spChkTxWdw(&cb->cs[OPSIDE(cb)], cb->cs[OPSIDE(cb)].NPS))
         txOk = FALSE;
      else if (qLen)
         txOk = FALSE;
      else if (cb->state == RST_ST(OPSIDE(cb)))
         txOk = FALSE;

      if (txOk)
      {
         dat.seqSeg.recSeqNum.val = 
            cb->cs[OPSIDE(cb)].TPR = cb->cs[OPSIDE(cb)].EPS;
         dat.seqSeg.senSeqNum.val = cb->cs[OPSIDE(cb)].NPS;
         cb->cs[OPSIDE(cb)].NPS = 
            (cb->cs[OPSIDE(cb)].NPS + 1) % (U8) MODULO_128;
         cb->cs[OPSIDE(cb)].lstMoreTx = more;
      }

      dat.data.eh.pres = PRSNT_NODEF;
      dat.data.data.pres = PRSNT_NODEF;
      dat.data.data.val = TRUE;

      cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = data;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_DATA2;

      ret = SGetMsg(cb->cs[OPSIDE(cb)].nSap->pst.region, 
                    cb->cs[OPSIDE(cb)].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPutMsg(data);
         SPLOGERROR(ERRCLS_ADD_RES, ESP279, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE, 
                  cb->cs[OPSIDE(cb)].nwData->variant, MF_SCCP);
      if (ret != ROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
		   /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
         SPLOGERROR(ERRCLS_DEBUG, ESP280, (ErrVal) ret, "SPENCPDUHDR failed");
         RETVOID;
      }

      SPENCPDU(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &dat);
      if (ret != MFROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
		   /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
         SPLOGERROR(ERRCLS_DEBUG, ESP281, (ErrVal) ret, "SPENCPDU failed");
         RETVOID;
      }

      if (!txOk) /* que message */
      {
         if (!spCheckResources(cb->cs[OPSIDE(cb)].nSap))
         {
            /* sp028.302 - addition - print debug info and generate alarm */
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   "Failure in queing DT2 msg, queThresh exceed\n"));

            spSendLmSta(LCM_CATEGORY_INTERNAL, LSP_EVENT_DT2_QUE_FAILURE,
                        LSP_CAUSE_QUE_THRESH_EXCEEDED, NOTUSED, NOTUSED);

            spIntRst(cb, RSC_NETCONG);
            RETVOID;
         }
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP - SPCO: queuing message\n"));
         ret = SQueueLast(mBuf, &cb->cs[OPSIDE(cb)].datQ);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
         {
            if (data)
               SPutMsg(data);
            if (mBuf)
               SPutMsg(mBuf);
            SPLOGERROR(ERRCLS_ADD_RES, ESP282, (ErrVal) ret, 
                       "SQueueLast failed");
            RETVOID;
         }
#endif /* ERRCLASS */
         RETVOID;
      }
      else /* deliver message */
      {
         /* check for timer's existence */
         spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));

         /* restart interval timer */
         cb->tmr.enb = TRUE;
         /* sp045.302 - modification - nwData moved to cs[] */
         cb->tmr.val = cb->cs[OPSIDE(cb)].nwData->defIasTmr.val;
         spStartConCbTmr(cb, IAS_TMR(OPSIDE(cb)));

         /* Prior should match Connection Request! */
         /* sp020.302 - modification - use prior from conCb to match it with
          * that in CR
          */
         ret = spSendCoMsg(cb, OPSIDE(cb), cb->prior, cb->imp.val, mBuf);
         if (ret != SP_OK)
         {
            /* message discarded due to traffic limitation mechanism
             * drop message
             */
            if (mBuf)
               SPutMsg(mBuf);
         }
      }
   } /* else destination remote */
   RETVOID;
} /* spDat2Tx */


/*
*
*       Fun:   spEDatTx
*
*       Desc:  Handle Expedited Data Indication/Transfer
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spEDatTx
(
SpConCb *cb,           /* connection control block */
Buffer *data           /* message buffer */
)
#else
PUBLIC Void spEDatTx(cb, data)
SpConCb *cb;           /* connection control block */
Buffer *data;          /* message buffer */
#endif
{
   Buffer *mBuf;
   SpExpData ed;
   S16 ret;

   TRC2(spEDatTx)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[OPSIDE(cb)].pc == cb->cs[OPSIDE(cb)].nwData->selfPc) /* local */
   {
      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
      {
         /* Expedited Data Indication */
         (Void) SpUiSptEDatInd(&cb->sap->pst, &cb->cs[OPSIDE(cb)].conId, data);

         /* update statistics for ED messages received */
         cb->sap->sts.edMsgRx++;
      }
      else
      {
         if (data)
            (Void) SPutMsg(data);
      }
   }
   else
   {
      /* else build the outgoing message */
      ed.dLclRef.eh.pres = PRSNT_NODEF;
      ed.dLclRef.dLclRef.pres = PRSNT_NODEF;
      ed.dLclRef.dLclRef.val = cb->cs[OPSIDE(cb)].conId.suInstId;


      ed.data.eh.pres = PRSNT_NODEF;
      ed.data.data.pres = PRSNT_NODEF;
      ed.data.data.val = TRUE;
      cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = data;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_EXPDATA;

      ret = SGetMsg(cb->cs[OPSIDE(cb)].nSap->pst.region, 
                    cb->cs[OPSIDE(cb)].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPutMsg(data);
         SPLOGERROR(ERRCLS_ADD_RES, ESP283, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE, 
                  cb->cs[OPSIDE(cb)].nwData->variant, MF_SCCP);
      if (ret != ROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
		   /* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
         SPLOGERROR(ERRCLS_DEBUG, ESP284, (ErrVal) ret, "SPENCPDUHDR failed");
         spDropCall(cb, RLC_REMPROC);

         RETVOID;
      }

      SPENCPDU(&cb->cs[OPSIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &ed);
      if (ret != MFROK)
      {
         if (mBuf)
            SPutMsg(mBuf);
         if (cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data)
            SPutMsg(cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data);
 	   	/* sp035.302 - addition - assigning explicit NULL to 
          * data pointer to avoid double deallocation. 
          */
         cb->cs[OPSIDE(cb)].nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
         SPLOGERROR(ERRCLS_DEBUG, ESP285, (ErrVal) ret, "SPENCPDU failed");
         spDropCall(cb, RLC_REMPROC);
         RETVOID;
      }

      /* if we're waiting for an ack or
       * we're resetting the outgoing side,
       * queue it up 
       */
      if ( (cb->cs[OPSIDE(cb)].flags & EDA_PEN) ||
           (cb->state == RST_ST(OPSIDE(cb))) )
      {
         ret = SQueueLast(mBuf, &cb->cs[OPSIDE(cb)].eDatQ);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            SPLOGERROR(ERRCLS_ADD_RES, ESP286, (ErrVal) ret,
                       "SQueueLast failed");
#endif /* ERRCLASS */
         RETVOID;
      }

      /* restart send timer */
      spRmvConCbTq(cb, IAS_TMR(OPSIDE(cb)));

      cb->tmr.enb = TRUE;
       /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[OPSIDE(cb)].nwData->defIasTmr.val;
      spStartConCbTmr(cb, IAS_TMR(OPSIDE(cb)));

      /* waiting for ack... */
      cb->cs[OPSIDE(cb)].flags |= EDA_PEN;

      ret = spSendCoMsg(cb, OPSIDE(cb), SN_PRI1, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
   } /* else remote */
   RETVOID;
} /* spEDatTx */


/*
*
*       Fun:   spCheckResources
*
*       Desc:  Check our resources 
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Bool spCheckResources
(
SpNSapCb *nSap
)
#else
PUBLIC Bool spCheckResources(nSap)
SpNSapCb *nSap;
#endif
{
   S16 thresh;
   S16 ret;

   TRC2(spCheckResources)


   ret = SChkRes(nSap->pst.region, nSap->pst.pool, &thresh);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP287, (ErrVal) ret, "SChkRes failed");
      RETVALUE(FALSE);
   }
#endif /* ERRCLASS */
 
   /* sp028.302 - removal - debug print moved to parent func */

   if (thresh <= spCb.spCfg.queThresh)
      RETVALUE(FALSE);

   RETVALUE(TRUE);
} /* spCheckResources */


/*
*
*       Fun:   spChkRxWdw
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Bool spChkRxWdw
(
SpSide *side,             /* connection side */
U8 ps                     /* send sequence number */
)
#else
PUBLIC Bool spChkRxWdw(side, ps)
SpSide *side;             /* connection side */
U8 ps;                    /* send sequence number */
#endif
{
   U8 tmp;

   TRC2(spChkRxWdw)

   tmp = ps;
   if (tmp < side->TPR)
      tmp += MODULO_128;
   RETVALUE((Bool) (tmp < (U8)(side->TPR + side->rxWin)));
} /* spChkRxWdw */


/*
*
*       Fun:   spChkTxWdw
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Bool spChkTxWdw
(
SpSide *side,              /* connection side */
U8 ps                      /* send sequence number */
)
#else
PUBLIC Bool spChkTxWdw(side, ps)
SpSide *side;             /* connection side */
U8 ps;                    /* send sequence number */
#endif
{
   U8 tmp;

   TRC2(spChkTxWdw)
   tmp = ps;
   if (tmp < side->LPR)
      tmp += MODULO_128;
   RETVALUE((Bool) (tmp < (U8) (side->LPR + side->txWin)));
} /* spChkTxWdw */


/*
*
*       Fun:   spChkPr
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Bool spChkPr
(
SpSide *side,             /* side */
U8 pr                     /* receive sequence number */
)
#else
PUBLIC Bool spChkPr(side, pr)
SpSide *side;              /* side */
U8 pr;                     /* receive sequence number */
#endif
{
   TRC2(spChkPr)

   if (side->NPS < side->LPR)
      RETVALUE((Bool) (pr >= side->LPR || pr <= side->NPS));
   RETVALUE((Bool) (pr >= side->LPR && pr <= side->NPS));
} /* spChkPr */


/*
*
*       Fun:   spDataAck
*
*       Desc:  Generate Data Acknowledge
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spDataAck
(
SpConCb *cb           /* connection control block */
)
#else
PUBLIC Void spDataAck(cb)
SpConCb *cb;          /* connection control block */
#endif
{
   S16 ret;
   SpDataAck da;
   Buffer *mBuf;

   TRC2(spDataAck)

   da.dLclRef.eh.pres = PRSNT_NODEF;
   da.dLclRef.dLclRef.pres = PRSNT_NODEF;
   da.dLclRef.dLclRef.val = cb->cs[SIDE(cb)].conId.suInstId;

   da.recSeqNum.eh.pres = PRSNT_NODEF;
   da.recSeqNum.recSeqNum.pres = PRSNT_NODEF;
   da.recSeqNum.recSeqNum.val = 
      cb->cs[SIDE(cb)].TPR = cb->cs[SIDE(cb)].EPS;
   /* store last pr transmitted */

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP: spDataAck - rsn: %d\n", da.recSeqNum.recSeqNum.val));

   da.credit.eh.pres = PRSNT_NODEF;
   da.credit.credit.pres = PRSNT_NODEF;
   da.credit.credit.val = cb->qos.credit;

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_DATAACK;

   ret = SGetMsg(cb->cs[SIDE(cb)].nSap->pst.region, 
                 cb->cs[SIDE(cb)].nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP288, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* sp045.302 - modification - nwData moved to cs[] */
   /* Encode message */
   SPENCPDUHDR(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, mBuf,
               (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
               cb->cs[SIDE(cb)].nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
         SPLOGERROR(ERRCLS_DEBUG, ESP289, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         RETVOID;
   }

   SPENCPDU(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &da);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP290, (ErrVal) ret, "SPENCPDU failed");
      if (mBuf)
         SPutMsg(mBuf);
      RETVOID;

   }

   /* RESTART SEND TIMER */
   spRmvConCbTq(cb, IAS_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIasTmr.val;
   spStartConCbTmr(cb, IAS_TMR(SIDE(cb)));

   /* sp020.302 - modification - use prior from conCb to match it with
    * that in CR.
    */
   ret = spSendCoMsg(cb, SIDE(cb), cb->prior, cb->imp.val, mBuf);
   if (ret != SP_OK)
   {
      /* message discarded due to traffic limitation mechanism
       * drop message
       */
      if (mBuf)
         SPutMsg(mBuf);
   }
   RETVOID;
} /* spDataAck */


/*
*
*       Fun:   spEDatAck
*
*       Desc:  Generate Data Acknowledge
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spEDatAck
(
SpConCb *cb           /* connection control block */
)
#else
PUBLIC Void spEDatAck(cb)
SpConCb *cb;          /* connection control block */
#endif
{
   S16 ret;
   SpExpDataAck eda;
   Buffer *mBuf;

   TRC2(spEDatAck)

   /* Ack always on SIDE */

   eda.dLclRef.eh.pres = PRSNT_NODEF;
   eda.dLclRef.dLclRef.pres = PRSNT_NODEF;
   eda.dLclRef.dLclRef.val = cb->cs[SIDE(cb)].conId.suInstId;

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "SCCP: spEDatAck\n"));

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_EXPDATAACK;

   ret = SGetMsg(cb->cs[SIDE(cb)].nSap->pst.region, 
                 cb->cs[SIDE(cb)].nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP291, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* Encode message */
   /* sp045.302 - modification - nwData moved to cs[] */
   SPENCPDUHDR(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
               (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
               cb->cs[SIDE(cb)].nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      if (mBuf)
         SPutMsg(mBuf);
         SPLOGERROR(ERRCLS_DEBUG, ESP292, (ErrVal) ret, "SPENCPDUHDR failed");
         spDropCall(cb, RLC_REMPROC);
         RETVOID;
   }

   SPENCPDU(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &eda);
   if (ret != MFROK)
   {
      if (mBuf)
         SPutMsg(mBuf);
      SPLOGERROR(ERRCLS_DEBUG, ESP293, (ErrVal) ret, "SPENCPDU failed");
      spDropCall(cb, RLC_REMPROC);
      RETVOID;
   }

   /* RESTART SEND TIMER */
   spRmvConCbTq(cb, IAS_TMR(SIDE(cb)));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIasTmr.val;
   spStartConCbTmr(cb, IAS_TMR(SIDE(cb)));

   ret = spSendCoMsg(cb, SIDE(cb), SN_PRI1, cb->imp.val, mBuf);
   if (ret != SP_OK)
   {
      /* message discarded due to traffic limitation mechanism
       * drop message
       */
      if (mBuf)
         SPutMsg(mBuf);
   }
   RETVOID;
} /* spEDatAck */


/*
*
*       Fun:   spCheckDatQ
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spCheckDatQ
(
SpConCb *cb,                    /* connection control block */
U8 side
)
#else
PUBLIC Void spCheckDatQ(cb, side)
SpConCb *cb;                    /* connection control block */
U8 side;
#endif
{
   U8 mType;
   S16 ret;

   TRC2(spCheckDatQ)

   for (;;)
   {
      U8 tmpPs;
      U8 tmpPr;
      U8 pS;
      U8 pR;
      Buffer *msg;
      ret = SExamQueue(&msg, &cb->cs[side].datQ, 0);
      if (ret == ROKDNA)
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP294, (ErrVal) ret, "SExamQueue failed");
         RETVOID;
      }
#endif /* ERRCLASS */

      ret = SExamMsg(&mType, msg, 0);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP295, (ErrVal) ret, "SExamMsg failed");
         RETVOID;
      }
#endif /* ERRCLASS */

      switch (mType)
      {
         case M_DATA2:
         {
            /* we have DT2s in our queue, but we have to do some 
             * validation before we send it
             */

            ret = SExamMsg(&tmpPs, msg, 4);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            {
               SPLOGERROR(ERRCLS_DEBUG, ESP296, (ErrVal) ret,
                          "SExamMsg failed");
               RETVOID;
            }
#endif /* ERRCLASS */

            ret = SExamMsg(&tmpPr, msg, 5);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            {
               SPLOGERROR(ERRCLS_DEBUG, ESP297, (ErrVal) ret, 
                          "SExamMsg failed");
               RETVOID;
            }
#endif /* ERRCLASS */

#if (ERRCLASS & ERRCLS_DEBUG)
            if ( (tmpPs >> (U8) 1) != 0)
            {
               SPLOGERROR(ERRCLS_DEBUG, ESP298, (ErrVal) tmpPs, 
                          "Queued message contains a send seq num");
               RETVOID;
            }
            if ( (tmpPr >> (U8)1) != 0)
            {
               SPLOGERROR(ERRCLS_DEBUG, ESP299, (ErrVal) tmpPr, 
                          "Queued message contains a receive seq num");
               RETVOID;
            }
#endif /* ERRCLASS */

            /* are we within our sending window */
            if (!spChkTxWdw(&cb->cs[side], cb->cs[side].NPS))
               RETVOID;
            else
            {
              /* actually dequeue it */

               ret = SDequeueFirst(&msg, &cb->cs[side].datQ);
#if (ERRCLASS & ERRCLS_DEBUG)
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_DEBUG, ESP300, (ErrVal) ret, 
                             "SDequeueFirst failed");
                  RETVOID;
               }
#endif /* ERRCLASS */

               SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                      "SCCP: Dequeuing Message\n"));
            }
            pS = tmpPs | (cb->cs[side].NPS<<1);
            SRepMsg(pS, msg, 4);         /* replace ps */
            cb->cs[side].NPS = 
               (U8)(cb->cs[side].NPS +1) % (U8)MODULO_128;

            cb->cs[side].TPR = cb->cs[side].EPS;
            pR = tmpPr | (cb->cs[side].TPR << 1);
            SRepMsg(pR, msg, 5);         /* replace ps */

            /* store away last transmitted */
            cb->cs[side].lstMoreTx = tmpPr & 0x01;

            /* restart send timer */
            spRmvConCbTq(cb, IAS_TMR(side));
            cb->tmr.enb = TRUE;
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[side].nwData->defIasTmr.val;
            spStartConCbTmr(cb, IAS_TMR(side));

            ret = spSendCoMsg(cb, side, SN_PRI0, cb->imp.val, msg);
            if (ret != SP_OK)
            {
               /* message discarded due to traffic limitation mechanism
                * drop message
                */
               if (msg)
                  SPutMsg(msg);
            }
            break;
         }
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
             SPLOGERROR(ERRCLS_DEBUG, ESP301, (ErrVal) mType, 
                        "invalid message type queued");
#endif /* ERRCLASS */
      } /* switch (mType) */
   } /* for (;;) */
   RETVOID;
} /* spCheckDatQ */


/*
*
*       Fun:   spCheckEDatQ
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spCheckEDatQ
(
SpConCb *cb,                    /* connection control block */
U8 side                         /* side */
)
#else
PUBLIC Void spCheckEDatQ(cb, side)
SpConCb *cb;                    /* connection control block */
U8 side;                        /* side */
#endif
{
   S16 ret;
   Buffer *msg;

   TRC2(spCheckEDatQ)

   ret = SRemQueue(&msg, &cb->cs[side].eDatQ, 0);
   if (ret == ROKDNA)
      RETVOID;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP302, (ErrVal) ret, "SRemQueue failed");
      RETVOID;
   }
#endif /* ERRCLASS */

   /* reset send timer */
   spRmvConCbTq(cb, IAS_TMR(side));
   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[side].nwData->defIasTmr.val;
   spStartConCbTmr(cb, IAS_TMR(side));

   cb->cs[side].flags |= EDA_PEN; 
   ret = spSendCoMsg(cb, side, SN_PRI1, cb->imp.val, msg);
   if (ret != SP_OK)
   {
      /* message discarded due to traffic limitation mechanism
       * drop message
       */
      if (msg)
         SPutMsg(msg);
   }

   RETVOID;
} /* spCheckEDatQ */


/*
*
*       Fun:   spStartGlbTmr
*
*       Desc:  start global timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy4.c
*
*/
 
#ifdef ANSI
PUBLIC Void spStartGlbTmr
(
SpCb *cb,                       /* control block */
U8 event                        /* timer event */
)
#else
PUBLIC Void spStartGlbTmr(cb, event)
SpCb *cb;                       /* control block */
U8 event;                       /* timer event */
#endif
{
   CmTmrArg arg;
 
   TRC2(spStartGlbTmr);
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP303, (ErrVal) ERRZERO,
                 "spStartGlbTmr called with NULLP");
      RETVOID;
   }
#endif
   arg.tq = spCb.spGlbTq;
   arg.tqCp = &spCb.spGlbTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = event;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXSPTMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)
      cmPlcCbTq(&arg);
   RETVOID;
} /* spStartGlbTmr */


  
/*
*
*       Fun:   spGlbTmrEvnt
*
*       Desc:  Global Timer Event
*
*       Ret:   None
*
*       Notes: Handle timer events...
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spGlbTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spGlbTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{
   SpCb *cb;

   TRC2(spGlbTmrEvnt);

   cb = (SpCb *) cbp;

   switch (evnt)
   {
      case TMR_GRD:
         /* clear the GUARD status */
         if (spCb.status & SP_GUARD) /* check for a crazy SM */
         {
            spCb.status ^= SP_GUARD;
         }
         break;
      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP304, (ErrVal) evnt,
                    "spGlbTmrEvnt invalid event");
         break;
   }
   RETVOID;
} /* spGlbTmrEvnt */


/*
*
*       Fun:   spStartConCbTmr
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spStartConCbTmr
(
SpConCb *cb,           /* connection control block */
U8 ev                  /* event */
)
#else
PUBLIC Void spStartConCbTmr(cb, ev)
SpConCb *cb;           /* connection control block */
U8 ev;                 /* event */
#endif
{
   CmTmrArg arg;

   TRC2(spStartConCbTmr)

   arg.tq = spCb.spConTq;
   arg.tqCp = &spCb.spConTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = ev;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXCONTMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;

   if (arg.wait != 0)         /* if timer place on tq */
      cmPlcCbTq(&arg);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spStartConCbTmr : %d started \n", ev));

   RETVOID;
} /* spStartConCbTmr */


/*
*
*       Fun:   spRmvConCbTq
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvConCbTq
(
SpConCb *cb,           /* connection control block */
U8 ev                  /* message buffer */
)
#else
PUBLIC Void spRmvConCbTq(cb, ev)
SpConCb *cb;           /* connection control block */
U8 ev;                 /* message buffer */
#endif
{
   REG1 U8 tNum;
   CmTmrArg arg;
   Bool found;

   TRC2(spRmvConCbTq)

   found = FALSE;
   for(tNum = 0; tNum < MAXCONTMR; tNum++)
   {
      if (cb->timers[tNum].tmrEvnt == ev)
      {
         found = TRUE;
         break;
      }
   }
   if (!found)
      RETVOID;

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spRmvConCbTq : %d stopped\n", ev));

   arg.tq = spCb.spConTq;
   arg.tqCp = &spCb.spConTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tNum;
   arg.max = MAXCONTMR;
   cmRmvCbTq(&arg);
   RETVOID;
} /* spRmvConCbTq */


/*
*
*       Fun:   spPrcConCbTq
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 spPrcConCbTq
(
ProcId  proc,
Ent     ent,
Inst    inst
)
#else
PUBLIC S16 spPrcConCbTq(proc, ent, inst)
ProcId  proc;
Ent     ent;
Inst    inst;
#endif
#else
#ifdef ANSI
PUBLIC S16 spPrcConCbTq
(
void
)
#else
PUBLIC S16 spPrcConCbTq()
#endif
#endif /* SS_MULTIPLE_PROCS */
{
   TRC2(spPrcConCbTq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
   if((SGetXxCb(proc, ent, inst, (Void **)&spCbPtr)) != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spPrcConCbTq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }
#endif

#ifdef ZP
   if (!zpCb.freezeTmr)
#endif /* ZP */
   {
      cmPrcTmr(&spCb.spConTqCp, spCb.spConTq, spConCbTmrEvnt);
      cmPrcTmr(&spCb.spLclRefTqCp, spCb.spLclRefTq, spLclRefTmrEvnt);
      cmPrcTmr(&spCb.spGlbTqCp, spCb.spGlbTq, spGlbTmrEvnt);
   }
   RETVALUE(ROK);
} /* spPrcConCbTq */

  
/*
*
*       Fun:   spConCbTmrEvnt
*
*       Desc:  Connection Control Block Timer Event
*
*       Ret:   None
*
*       Notes: Handle timer events...
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spConCbTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spConCbTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{
   SpConCb* cb;

   TRC2(spConCbTmrEvnt)

   cb = (SpConCb *) cbp;

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spConCbTmrEvnt: id=%ld cType=%d\n", cb->cs[CG_SIDE].conId.spInstId,
          cb->cType));

   switch (evnt)
   {
      case CON_TMR:         /* connection timer expired */
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_CON TIMED OUT\n"));
         if ((cb->cType & SP_ORIG) || (cb->cType & SP_DEST))
         {
            /* freeze both sides */
            spFreezeSlr(cb, SP_FRZ_BT);

            if (!(cb->cbFlags & CG_RCVD_DIS))
            {
               /* send connection refused on the calling side */
               spConRefused(cb, RFC_EXCETMR, ORIG_NET, NULLP);
            }

            /* free resources... */
            spFreeConCb(cb);
         }
         else if (cb->cType & SP_INTR)
         {
            if (cb->cType & SP_REQ2)
            {
               SpDisEvnt dis;

               /* if we are an ISUP Request Type 2 (intermediate node)
                * send a disconnect to our user
                */
               cmCopy((U8 *) &cb->t.req2.usrId, (U8 *) &dis.conId, 
                      sizeof(SpConId));
               cmZero((U8 *) &dis.rspAddr, sizeof(SpAddr));
               dis.rsn = RLC_NOTOBTN;
               dis.orig = ORIG_NET;
               dis.conId.suId = cb->sap->suId;
#ifdef SPTV2
               /* importance is not relevant in disconnect indication
                * to upper user. Mark it as not present
                */
               dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */

               /* check if the user has bound */
               if (cb->sap->status & SP_BND)
                  (Void) SpUiSptDisInd(&cb->sap->pst, &dis, NULLP);
             }

            /* freeze calling side */
            spFreezeSlr(cb, SP_FRZ_CG);

            /* send connection refused to calling side */
            spConRefused(cb, RFC_EXCETMR, ORIG_NET, NULLP);

            /*
             * It doesn't make sense for an intermediate
             * node to send a release to the called side
             * because I do not yet have the correct
             * destination local reference 
             */  
            /* send release to called side - cause = access failure */
            spRelease(cb, CD_SIDE, RLC_ACCFAIL, ORIG_NET, NULLP);

            /* sp034.302 - addition - free conCb if its in dead state */
            if (cb->cType & SP_DEAD)
               spFreeConCb(cb);

            /* Update statistics */
            spCb.sts.prvInitRel++;

         }
         else  /* this should never happen */
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP305, (ErrVal) cb->cType,
                       "invalid connection type");
            RETVOID;
         }
         break;
      }

      case CG_IAS_TMR:    /* calling inactivity send timer expired */
      {
#ifdef ZP
         /* sp022.302 - addition - on sby, do not send IT just restart timer */
         /* sp029.302 - addition - if peersync is in progress then do not
          * process this timer and just restart it.
          */
         if (((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
              CMPFTHA_STATE_STANDBY) && (cb->state == DTX_ST))
             || ((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
                  CMPFTHA_STATE_ACTIVE) &&
              !(ZP_IS_RSET_REALLY_ACTIVE(zpCb.rsetCbList[cb->spZpCb.rsetId]))))
         {
            cb->tmr.enb = TRUE;
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[CG_SIDE].nwData->defIasTmr.val;
            spStartConCbTmr(cb, CG_IAS_TMR);
            break;
         }
#endif /* ZP */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_IAS TIMED OUT\n"));
         spSendInactTst(cb, evnt);
         break;
      }

      case CG_IAR_TMR:    /* calling inactivity receive timer expired */
      {
         SpReport spRep;     /* sccp error performance report struct */

#ifdef ZP
         /* sp023.302 - addition - on sby, do not release conn,
          * just restart timer
          */
         /* sp029.302 - addition - if peersync is in progress then do not
          * process this timer and just restart it.
          */
         if (((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
              CMPFTHA_STATE_STANDBY) && (cb->state == DTX_ST))
             || ((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
                  CMPFTHA_STATE_ACTIVE) &&
              !(ZP_IS_RSET_REALLY_ACTIVE(zpCb.rsetCbList[cb->spZpCb.rsetId]))))
         {
            cb->tmr.enb = TRUE;
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[CG_SIDE].nwData->defIarTmr.val;
            spStartConCbTmr(cb, CG_IAR_TMR);
            break;
         }
#endif /* ZP */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_IAR TIMED OUT\n"));

         /* we have a calling side no matter what */
         spRmvConCbTq(cb, CG_IAS_TMR);

         /* we also have a called side if we're an intermediate node */
         if (cb->cType & SP_INTR)
         {
            /* called side */
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CD_IAR_TMR);
         }

         /* Update Statistics */
         spCb.sts.TiarExpiry++;
         spCb.sts.prvInitRel++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CG_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CG_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CG_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_ITRECV_EXP,
                          &spRep);

         /* don't freeze either local reference */

         /* send release on called side */
         spRelease(cb, CD_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);

         /* send release on calling side */
         spRelease(cb, CG_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);

         break;
      }

      case CD_IAS_TMR:    /* called inactivity send timer expired */
      {
#ifdef ZP
         /* sp022.302 - addition - on sby, do not send IT just restart timer */
         /* sp029.302 - addition - if peersync is in progress then do not
          * process this timer and just restart it.
          */
         if (((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
              CMPFTHA_STATE_STANDBY) && (cb->state == DTX_ST))
             || ((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
                  CMPFTHA_STATE_ACTIVE) &&
              !(ZP_IS_RSET_REALLY_ACTIVE(zpCb.rsetCbList[cb->spZpCb.rsetId]))))
         {
            cb->tmr.enb = TRUE;
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[CD_SIDE].nwData->defIasTmr.val;
            spStartConCbTmr(cb, CD_IAS_TMR);
            break;
         }
#endif /* ZP */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_IAS TIMED OUT\n"));
         spSendInactTst(cb, evnt);
         break;
      }

      case CD_IAR_TMR:    /* called inactivity receive timer expired */
      {
         SpReport spRep;     /* sccp error performance report struct */

#ifdef ZP
         /* sp023.302 - addition - on sby, do not release conn,
          * just restart timer
          */
         /* sp029.302 - addition - if peersync is in progress then do not
          * process this timer and just restart it.
          */
         if (((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
              CMPFTHA_STATE_STANDBY) && (cb->state == DTX_ST))
             || ((zpCb.rsetCbList[cb->spZpCb.rsetId]->state ==
                  CMPFTHA_STATE_ACTIVE) &&
              !(ZP_IS_RSET_REALLY_ACTIVE(zpCb.rsetCbList[cb->spZpCb.rsetId]))))
         {
            cb->tmr.enb = TRUE;
            /* sp045.302 - modification - nwData moved to cs[] */
            cb->tmr.val = cb->cs[CD_SIDE].nwData->defIarTmr.val;
            spStartConCbTmr(cb, CD_IAR_TMR);
            break;
         }
#endif /* ZP */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_IAR TIMED OUT\n"));

         /* stop inactivity timers on both sides */

         /* we have a called side no matter what */

         /* called side */
         spRmvConCbTq(cb, CD_IAS_TMR);

         /* we only have a calling side if we're an intermediate node */
         if (cb->cType & SP_INTR)
         {
            spRmvConCbTq(cb, CG_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);
         }

         /* Update Statistics */
         spCb.sts.TiarExpiry++;
         spCb.sts.prvInitRel++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CD_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CD_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CD_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_ITRECV_EXP,
                          &spRep);

         /* don't freeze either local reference */

         /* send release on called side */
         spRelease(cb, CD_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);

         /* send release on calling side */
         spRelease(cb, CG_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);

         break;
      }

      case CG_RST_TMR:
      {
         SpReport spRep;     /* sccp error performance report struct */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_RST_TMR TIMED OUT\n"));
         if (cb->cType & SP_DEST)
         {
            spFreezeSlr(cb, SP_FRZ_CD);  /* freeze user */
            /* remove inactivity timers for opposite side */
            spRmvConCbTq(cb, CG_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);
         }
         else if (cb->cType & SP_INTR)  /* we are  an intermediate node */
         {
            /* remove inactivity timers for both sides */
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CD_IAR_TMR);
            spRmvConCbTq(cb, CG_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);

            /* remove reset timer for opposite side */
            spRmvConCbTq(cb, CD_RST_TMR);
         }

         /* update statistics for provider initiated reset of conn */
         spCb.sts.prvInitReset++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CG_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CG_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CG_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_NSP_RESET,
                          &spRep);

         /* send release on called side */
         spRelease(cb, CD_SIDE, RLC_EXRSTTMR, ORIG_NET, NULLP);

         /* send release on calling side */
         spRelease(cb, CG_SIDE, RLC_EXRSTTMR, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         break;
      }

      case CD_RST_TMR:
      {
         SpReport spRep;     /* sccp error performance report struct */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_RST_TMR TIMED OUT\n"));
         if (cb->cType & SP_ORIG)
         {
            spFreezeSlr(cb, SP_FRZ_CG);  /* freeze user */
            /* remove inactivity timers for opposite side */
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CD_IAR_TMR);
         }
         else if (cb->cType & SP_INTR)  /* we are  an intermediate node */
         {
            /* remove inactivity timers for both sides */
            spRmvConCbTq(cb, CG_IAS_TMR);
            spRmvConCbTq(cb, CG_IAR_TMR);
            spRmvConCbTq(cb, CD_IAS_TMR);
            spRmvConCbTq(cb, CD_IAR_TMR);

            /* remove reset timer for opposite side */
            spRmvConCbTq(cb, CG_RST_TMR);
         }

         /* update statistics for provider initiated reset of conn */
         spCb.sts.prvInitReset++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CD_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CD_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CD_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_NSP_RESET,
                          &spRep);

         /* send release on called side */
         spRelease(cb, CD_SIDE, RLC_EXRSTTMR, ORIG_NET, NULLP);

         /* send release on calling side */
         spRelease(cb, CG_SIDE, RLC_EXRSTTMR, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         break;
      }

      case CG_REL_TMR:
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_REL TIMED OUT\n"));

         /* Start teh INT  timer */
         cb->tmr.enb = TRUE;
         /* sp045.302 - modification - nwData moved to cs[] */
         cb->tmr.val = cb->cs[CG_SIDE].nwData->defIntTmr.val;
         spStartConCbTmr(cb, CG_INT_TMR);

         /* Dont send the Release before starting the INT timer */
         spRelease(cb, CG_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);
         break;

      case CD_REL_TMR:
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_REL TIMED OUT\n"));

         /* Start teh INT  timer */
         cb->tmr.enb = TRUE;
         /* sp045.302 - modification - nwData moved to cs[] */
         cb->tmr.val = cb->cs[CD_SIDE].nwData->defIntTmr.val;
         spStartConCbTmr(cb, CD_INT_TMR);

         /* Dont send the Release before starting the INT timer */
         spRelease(cb, CD_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);
         break;

      case CG_INT_TMR:
      {
         SpReport spRep;     /* sccp error performance report struct */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_INT TIMED OUT\n"));
         /* 
          * inform maintenance 
          * for further study...
          */
         /* freeze the source local references */
         spFreezeSlr(cb, SP_FRZ_CG);

         /* Stop the Release Timers */
         spRmvConCbTq(cb, CG_REPREL_TMR);

         /* update statistics for failure in release complete supervision */
         spCb.sts.rlsCmpFail++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CG_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CG_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CG_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RLSCOMP_FAIL,
                          &spRep);

         /* free memory associated */
         /* sp013.302 - Free memory if freeze timer disabled */
         /* sp034.302 - modification - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         break;
      }
      case CD_INT_TMR:
      {
         SpReport spRep;     /* sccp error performance report struct */

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_INT TIMED OUT\n"));
         /* 
          * inform maintenance 
          * for further study...
          */
         /* freeze the source local references */
         spFreezeSlr(cb, SP_FRZ_CD);

         /* Stop the Release Timers */
         spRmvConCbTq(cb, CD_REPREL_TMR);

         /* update statistics for failure in release complete supervision */
         spCb.sts.rlsCmpFail++;

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = cb->cs[CD_SIDE].nSap->nwData->nwId;
         spRep.sw = cb->cs[CD_SIDE].nSap->nwData->variant;
         spRep.dpc = cb->cs[CD_SIDE].pc;
         spRep.protClass = cb->qos.pClass;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RLSCOMP_FAIL,
                          &spRep);

         /* free memory associated with them too. */
         /* sp013.302 - Free memory if freeze timer disabled */
         /* sp034.302 - modification - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         break;
      }
      case CG_REPREL_TMR:
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CG_REPREL TIMED OUT\n"));
         spRelease(cb, CG_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);
         break;

      case CD_REPREL_TMR:
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "CD_REPREL TIMED OUT\n"));
         spRelease(cb, CD_SIDE, RLC_EXRIATMR, ORIG_NET, NULLP);
         break;

      case GUA_TMR:      /* waiting to resume normal operation timer expired */
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "GUA TIMED OUT\n"));
         break;

      default:            /* error, do nothing */
         SPLOGERROR(ERRCLS_DEBUG, ESP306, (ErrVal) evnt, "invalid timer event");
         break;
   } /* switch (evnt) */
#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   RETVOID;
} /* spConCbTmrEvnt */


/*
*
*       Fun:   spSendInactTst
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PRIVATE Void spSendInactTst
(
SpConCb *cb,           /* connection control block */
S16 ev                  /* timer event */
)
#else
PRIVATE Void spSendInactTst(cb, ev)
SpConCb *cb;           /* connection control block */
S16 ev;                 /* timer event */
#endif
{
   SpInactTst it;
   SpSide *side;
   Buffer *mBuf;
   S16 ret;

   TRC2(spSendInactTst)

   /* sp044.302 - addition - Initialization of Local Variables */   
   side = NULLP;   

   if (ev == CD_IAS_TMR)
   {
      side = &cb->cs[CD_SIDE];
      cb->side = CD_SIDE;
   }
   else
   {
      if (ev == CG_IAS_TMR)
      {
         side = &cb->cs[CG_SIDE];
         cb->side = CG_SIDE;
      }
      else
         SPLOGERROR(ERRCLS_DEBUG, ESP307, (ErrVal) ev, "invalid timer event");
   }

   it.dLclRef.eh.pres = PRSNT_NODEF;
   it.dLclRef.dLclRef.pres = PRSNT_NODEF;
   it.dLclRef.dLclRef.val = side->conId.suInstId;

   it.sLclRef.eh.pres = PRSNT_NODEF;
   it.sLclRef.sLclRef.pres = PRSNT_NODEF;
   it.sLclRef.sLclRef.val = side->conId.spInstId;

   it.pClass.eh.pres = PRSNT_NODEF;
   it.pClass.pClass.pres = PRSNT_NODEF;
   it.pClass.pClass.val = cb->qos.pClass;

   /* WARNING:
    * The protocol is wrong, sending the last transmitted P(S)
    * make no sense. If no data has been transmitted yet, we can't
    * send 0 because that is incorrect.
    * Instead we send next P(S)
    */
   it.seqSeg.eh.pres = PRSNT_NODEF;
   it.seqSeg.senSeqNum.pres = PRSNT_NODEF;
   it.seqSeg.senSeqNum.val = side->NPS;

   it.seqSeg.recSeqNum.pres = PRSNT_NODEF;
   it.seqSeg.recSeqNum.val = side->TPR;
   it.seqSeg.moreData.pres = PRSNT_NODEF;
   it.seqSeg.moreData.val = side->lstMoreTx;

   it.credit.eh.pres = PRSNT_NODEF;
   it.credit.credit.pres = PRSNT_NODEF;
   it.credit.credit.val = side->txWin;

   spCb.pduHdr.eh.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.pres = PRSNT_NODEF;
   spCb.pduHdr.msgType.val = M_INACTST;

   ret = SGetMsg(cb->cs[SIDE(cb)].nSap->pst.region, 
                 cb->cs[SIDE(cb)].nSap->pst.pool, &mBuf);
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP308, (ErrVal) ret, "SGetMsg failed");
      RETVOID;
   }

   /* Encode message */
   /* sp045.302 - modification - nwData moved to cs[] */
   SPENCPDUHDR(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, mBuf, 
               (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
               cb->cs[SIDE(cb)].nwData->variant, MF_SCCP);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP309, (ErrVal) ret, "SPENCPDUHDR failed");
      if (mBuf)
         SPutMsg(mBuf);
      RETVOID;
   }

   SPENCPDU(&cb->cs[SIDE(cb)].nSap->mfMsgCtl, ret, (ElmtHdr *) &it);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP310, (ErrVal) ret, "SPENCPDU failed");
      if (mBuf)
         SPutMsg(mBuf);
      RETVOID;

   }

   cb->tmr.enb = TRUE;
   /* sp045.302 - modification - nwData moved to cs[] */
   cb->tmr.val = cb->cs[SIDE(cb)].nwData->defIasTmr.val;
   /* restart send inactivity timer */
   spStartConCbTmr(cb, (U8) ev);

   /* Check if destination network SAP is bound */
   if (!(cb->cs[SIDE(cb)].nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* discard IT message due to traffic limitation mechanism */
   /* sp045.302 - modification - nwData moved to cs[] */
   if ((cb->cs[SIDE(cb)].nwData->variant == LSP_SW_ITU) && (spCb.spTrfLimFlag == TRUE))
   {
      SpRteCb *rCb;       /* route control block */
      SpRteKey rKey;      /* route key */
      U8 imp;             /* message importance */

      /* assign default importance to IT message */
      imp = spCb.spMsgImp.defItImp;

      /* find route */
      rKey.k1.dpc = cb->cs[SIDE(cb)].pc;
      /* sp045.302 - modification - use nwId from cs[SIDE(cb)].nwData */
      rKey.k1.nwId = cb->cs[SIDE(cb)].nwData->nwId;
      spFindRte(&spCb.rteCp, &rCb, &rKey, 0);
      if (rCb == (SpRteCb *) NULLP)
      {
         /* route not found, drop message */
         spDropMsg(&mBuf);
         RETVOID;
      }

      /* find restriction only if route is ITU 96 */
      if (rCb->swtch == LSP_SW_ITU96)
      {
         ret = spFindRestriction(rCb, imp);
         if (ret == SP_DISCARD)
         {
            SpReport spRep;       /* sccp error perf report */

            /* fill sccp error report */
            cmZero((U8 *) &spRep, sizeof(SpReport));

            spRep.nwId = rCb->nSap->nwData->nwId;
            spRep.sw = rCb->nSap->nwData->variant;
            spRep.dpc = rCb->dpc;

            /* generate sccp error performance report */
            spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                             &spRep);
            spDropMsg(&mBuf);
            RETVOID;
         } /* if (ret == SP_DISCARD) */
      } /* if (rCb->swtch == LSP_SW_ITU96) */
   } /* if (...variant == LSP_SW_ITU) && (...spTrfLimFlag == TRUE)) */

   /* sp014.302 - priority of IT should be 1 instead of 0 */
   /* sp045.302 - modification - use selfPc from cs[SIDE(cb)].nwData */
   /* deliver the message */
   (Void) SpLiSntUDatReq(&cb->cs[SIDE(cb)].nSap->pst,
                         cb->cs[SIDE(cb)].nSap->spId,
                         cb->cs[SIDE(cb)].nwData->selfPc,
                         cb->cs[SIDE(cb)].pc, 
                         (U8) ((cb->ssf << 6) | (U8) SCCP_SI),
                         cb->cs[SIDE(cb)].sls, SN_PRI1, mBuf);

   /* sp005.302 - modification - send audit indication after delivering
    * IT message to network
    */
#ifdef SPTV2
   if (spCb.spAudFlag == TRUE)
   {
      /* check whether we r relay node and if so then 
       * there is no need for auditing
       */
      if (!(cb->cType & SP_INTR))
      {
         if (cb->nmbItTx >= spCb.spCfg.itThresh)
         {
            SpAudEvnt audEvnt;    /* Audit event structure */

            audEvnt.conId.spId = cb->cs[OPSIDE(cb)].conId.spId;
            audEvnt.conId.suId = cb->cs[OPSIDE(cb)].conId.suId;
            audEvnt.conId.spInstId  = cb->cs[OPSIDE(cb)].conId.spInstId;
            audEvnt.conId.suInstId  = cb->cs[OPSIDE(cb)].conId.suInstId;
            (Void) SpUiSptAudInd(&cb->sap->pst, &audEvnt);
         }
         else
            cb->nmbItTx++;
      } /* if (!(cb->cType & SP_INTR)) */
   } /* if (spCb.spAudFlag == TRUE) */
#endif /* SPTV2 */

   RETVOID;
} /* spSendInactTst */


/*
*
*       Fun:   spDisInd
*
*       Desc:  Send a DisInd incase of error in self
*              We dont fill the rspAddr as this fn is not 
*              called to signal rejection of conn est.
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spDisInd
(
SpConId *conId,
U8 rsn,
U8 orig,
Buffer *data
)
#else
PUBLIC Void spDisInd(conId, rsn ,orig, data)
SpConId *conId;
U8 rsn;
U8 orig;
Buffer *data;
#endif
{
   SpSapCb *sap;
   SpDisEvnt dis;

   TRC2(spDisInd);
      
   sap = *(spCb.sapList + (PTR) conId->spId);
   if ((sap == (SpSapCb*)NULLP) || (!(sap->status & SP_BND)))
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP311, (ErrVal) ERRZERO,
                 "Null sap or sap not bound");
      if (data)
         (Void) SPutMsg(data);
      RETVOID;
   }

   cmCopy((U8 *) conId, (U8 *) &dis.conId, sizeof(SpConId));
   dis.rsn = rsn;
   dis.orig = orig;
   dis.conId.suId = sap->suId;
#ifdef CMSS7_SPHDROPT
   dis.rspAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* CMSS7_SPHDROPT */
   dis.rspAddr.pres = TRUE;
   dis.rspAddr.sw = sap->nwData->variant;
   dis.rspAddr.ssfPres = FALSE;
   dis.rspAddr.niInd = sap->nwData->niInd;
   dis.rspAddr.rtgInd = RTE_SSN;
   dis.rspAddr.ssnInd = TRUE;
   dis.rspAddr.ssn = sap->ssn;
   dis.rspAddr.pcInd = TRUE;
   dis.rspAddr.pc = sap->nwData->selfPc;
   dis.rspAddr.gt.format = GTFRMT_0;
#ifdef SPTV2
   /* importance is not relevant in disconnect indication
    * to upper user. Mark it as not present
    */
   dis.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
   
   (Void) SpUiSptDisInd(&sap->pst, &dis, data);
   RETVOID;
} /* spDisInd */


/*
*
*       Fun:   spRstReq
*
*       Desc:  Generate Reset Request/Indication
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRstReq
(
SpConCb *cb,           /* connection control block */
U8 side,               /* side */
U8 cause               /* cause */
)
#else
PUBLIC Void spRstReq(cb, side, cause)
SpConCb *cb;           /* connection control block */
U8 side;               /* side */
U8 cause;              /* message buffer */
#endif
{
   S16 ret;

   TRC2(spRstReq)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[side].pc == cb->cs[side].nwData->selfPc) /* local */
   {
      SpRstEvnt rr;
      rr.conId.suId = cb->sap->suId;
      rr.conId.spId = cb->sap->spId;
      rr.conId.suInstId = cb->cs[side].conId.suInstId;
      rr.conId.spInstId = cb->cs[side].conId.spInstId;
      rr.rsn = cause;
      rr.orig = ORIG_NET;

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
         (Void) SpUiSptRstInd(&cb->sap->pst, &rr);
   }
   else
   {
      SpResReq rr;
      Buffer *mBuf;

      rr.dLclRef.eh.pres = PRSNT_NODEF;
      rr.dLclRef.dLclRef.pres = PRSNT_NODEF;
      rr.dLclRef.dLclRef.val = cb->cs[side].conId.suInstId;

      rr.sLclRef.eh.pres = PRSNT_NODEF;
      rr.sLclRef.sLclRef.pres = PRSNT_NODEF;
      rr.sLclRef.sLclRef.val = cb->cs[side].conId.spInstId;

      rr.resCause.eh.pres = PRSNT_NODEF;
      rr.resCause.resCause.pres = PRSNT_NODEF;
      rr.resCause.resCause.val = cause;

      /* sp008.302 - addition - initialize presence of endOp */
      rr.endOp.eh.pres = PRSNT_NODEF;
      rr.endOp.endOp.pres = PRSNT_NODEF;
      rr.endOp.endOp.val = 0;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_RSTREQ;

      ret = SGetMsg(cb->cs[side].nSap->pst.region, 
                    cb->cs[side].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP312, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }

      /* Encode message */
      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[side].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE,
                  cb->cs[side].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP313, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);
         RETVOID;
      }

      SPENCPDU(&cb->cs[side].nSap->mfMsgCtl, ret, (ElmtHdr *) &rr);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP314, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);
         RETVOID;
      }

      /* restart reset timer */
      spRmvConCbTq(cb, RST_TMR(side));
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[side].nwData->defRstTmr.val;
      spStartConCbTmr(cb, RST_TMR(side));

      /* restart send timer */
      spRmvConCbTq(cb, IAS_TMR(side));
      cb->tmr.enb = TRUE;
      /* sp045.302 - modification - nwData moved to cs[] */
      cb->tmr.val = cb->cs[side].nwData->defIasTmr.val;
      spStartConCbTmr(cb, IAS_TMR(side));

      /* sp014.302 - priority of RSR should be 1 instead of 0 */
      /* deliver the message */
      ret = spSendCoMsg(cb, side, SN_PRI1, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }
      else
         /* update statistics for RSR messages sent */
         spCb.sts.rsrTx++;
   } /* else - called side remote */

   RETVOID;
} /* spRstReq */


/*
*
*       Fun:   spFlushQueue
*
*       Desc:  flush all messages in queue
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spFlushQueue
(
Queue *q            /* queue */
)
#else
PUBLIC Void spFlushQueue(q)
Queue *q;           /* queue */
#endif
{
   Buffer *mBuf;
   S16 ret;

   TRC2(spFlushQueue)

   for (;;)
   {
      ret = SRemQueue(&mBuf, q, 0);
      if (ret == ROKDNA)
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
         SPLOGERROR(ERRCLS_DEBUG, ESP315, (ErrVal) ret, "SRemQueue failed");
#endif /* ERRCLASS */
      (Void) SPutMsg(mBuf);
      mBuf = (Buffer*)NULLP;
   }
   RETVOID;
} /* spFlushQueue */



/*
*
*       Fun:   spRstCfm
*
*       Desc:  Generate reset confirm
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spRstCfm
(
SpConCb *cb,           /* connection control block */
U8 side                /* side to tx on */
)
#else
PUBLIC Void spRstCfm(cb, side)
SpConCb *cb;           /* connection control block */
U8 side;               /* side to tx on */
#endif
{
   S16 ret;
   TRC2(spRstCfm)

   /* sp045.302 - modification - check selfPc from cb->cs's nwData */
   if (cb->cs[side].pc == cb->cs[side].nwData->selfPc) /* local */
   {
      SpRstEvnt re;
      
      /* generate connection confirm indication */
      cmCopy((U8 *) &cb->cs[side].conId, (U8 *) &re.conId, sizeof(SpConId));
      re.conId.suId = cb->sap->suId;
      /* quality of service set */

      /* check if the user has bound */
      if (cb->sap->status & SP_BND)
         (Void) SpUiSptRstCfm(&cb->sap->pst, &re);
   }
   else                                  /* remote */
   {
      SpResCfm rc;
      Buffer *mBuf;

      rc.dLclRef.eh.pres = PRSNT_NODEF;
      rc.dLclRef.dLclRef.pres = PRSNT_NODEF;
      rc.dLclRef.dLclRef.val = cb->cs[side].conId.suInstId;
      
      rc.sLclRef.eh.pres = PRSNT_NODEF;
      rc.sLclRef.sLclRef.pres = PRSNT_NODEF;
      rc.sLclRef.sLclRef.val = cb->cs[side].conId.spInstId;

      spCb.pduHdr.eh.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.pres = PRSNT_NODEF;
      spCb.pduHdr.msgType.val = M_RSTCFM;;


      ret = SGetMsg(cb->cs[side].nSap->pst.region, 
                    cb->cs[side].nSap->pst.pool, &mBuf);
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP316, (ErrVal) ret, "SGetMsg failed");
         RETVOID;
      }

      /* sp045.302 - modification - nwData moved to cs[] */
      SPENCPDUHDR(&cb->cs[side].nSap->mfMsgCtl, ret, mBuf, 
                  (ElmtHdr *) &spCb.pduHdr, &pduHdrMsgDef[0], TRUE, TRUE, 
                  cb->cs[side].nwData->variant, MF_SCCP);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP317, (ErrVal) ret, "SPENCPDUHDR failed");
         if (mBuf)
            SPutMsg(mBuf);

         /* free & freeze the local reference */
         spFreezeSlr(cb, SP_FRZ_BT);
         spRelease(cb, SIDE(cb), RLC_UNQUAL, ORIG_NET, NULLP);
         spRelease(cb, OPSIDE(cb), RLC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         spCb.sts.prvInitRel++;
         RETVOID;
      }

      SPENCPDU(&cb->cs[side].nSap->mfMsgCtl, ret, (ElmtHdr *) &rc);
      if (ret != MFROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP318, (ErrVal) ret, "SPENCPDU failed");
         if (mBuf)
            SPutMsg(mBuf);

         /* free & freeze the local reference */
         spFreezeSlr(cb, SP_FRZ_BT);
         spRelease(cb, SIDE(cb), RLC_UNQUAL, ORIG_NET, NULLP);
         spRelease(cb, OPSIDE(cb), RLC_UNQUAL, ORIG_NET, NULLP);
         spFreeConCb(cb);
         spCb.sts.prvInitRel++;
         RETVOID;
      }

      ret = spSendCoMsg(cb, side, SN_PRI1, cb->imp.val, mBuf);
      if (ret != SP_OK)
      {
         /* message discarded due to traffic limitation mechanism
          * drop message
          */
         if (mBuf)
            SPutMsg(mBuf);
      }

      /* see if we have anything que'd up */
      spCheckEDatQ(cb, side);
      spCheckDatQ(cb, side);
   } /* else remote */
   RETVOID;
} /* spRstCfm */


/*
*
*       Fun:   spIntRst
*
*       Desc:  Internal Reset
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spIntRst
(
SpConCb *cb,           /* connection control block */
U8 cause               /* cause */
)
#else
PUBLIC Void spIntRst(cb, cause)
SpConCb *cb;           /* connection control block */
U8 cause;              /* cause */
#endif
{
   TRC2(spIntRst)

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP - Internal Reset\n"));

   /* flush both queues */
   spFlushQueue(&cb->cs[SIDE(cb)].datQ);
   spFlushQueue(&cb->cs[SIDE(cb)].eDatQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].datQ);
   spFlushQueue(&cb->cs[OPSIDE(cb)].eDatQ);

   cb->cs[SIDE(cb)].flags |= RST_INT;
   cb->cs[SIDE(cb)].flags &= (U8) (~EDA_PEN); /* turn off exp data pending */
   cb->cs[SIDE(cb)].NPS = 0;
   cb->cs[SIDE(cb)].EPS = 0;
   cb->cs[SIDE(cb)].LPR = 0;
   cb->cs[SIDE(cb)].TPR = 0;
   cb->cs[SIDE(cb)].txWin = cb->qos.credit;
   cb->cs[SIDE(cb)].rxWin = cb->qos.credit;

   cb->cs[OPSIDE(cb)].flags |= RST_INT;
   cb->cs[OPSIDE(cb)].flags &= (U8)(~EDA_PEN); /* turn off exp data pending */
   cb->cs[OPSIDE(cb)].NPS = 0;
   cb->cs[OPSIDE(cb)].EPS = 0;
   cb->cs[OPSIDE(cb)].LPR = 0;
   cb->cs[OPSIDE(cb)].TPR = 0;
   cb->cs[OPSIDE(cb)].txWin = cb->qos.credit;
   cb->cs[OPSIDE(cb)].rxWin = cb->qos.credit;

   cb->state = RBT_ST;
   spRstReq(cb, SIDE(cb), cause);
   spRstReq(cb, OPSIDE(cb), cause);

   /* Update statistics */
   spCb.sts.prvInitReset++;

   RETVOID;
} /* spIntRst */


/*
 *
 *       Fun:   spDropCall
 *
 *       Desc:  
 *
 *       Ret:   ROK   - ok
 *
 *       Notes: Connection Oriented Control
 *
 *       File:  cp_bdy4.c
 *
 */
#ifdef ANSI
PUBLIC Void spDropCall
(
SpConCb *cb,           /* connection control block */
U8 rsn                 /* release cause  */
)
#else
PUBLIC Void spDropCall(cb, rsn)
SpConCb *cb;           /* connection control block */
U8 rsn;                /* release cause  */
#endif
{
   TRC2(spDropCall);

   if (cb->cType != SP_INTR)
   {
      if (cb->cType == SP_ORIG)
         spFreezeSlr(cb, SP_FRZ_CG);
      else if (cb->cType == SP_DEST)
         spFreezeSlr(cb, SP_FRZ_CD);
   }

   switch (cb->state)
   {
      case RDY_ST:
         /* free everything up */
         spFreezeSlr(cb, SP_FRZ_BT);
         spFreeConCb(cb);
         break;
 
      case CON_ST:
         /* send back refusal */
         spFreezeSlr(cb, SP_FRZ_CG);
         spConRefused(cb, RFC_NOTOBTN, ORIG_NET, NULLP);
         if (cb->cType == SP_REQ0)
         {
            /* release forward */
            spRelease(cb, CD_SIDE, rsn, ORIG_NET, NULLP);

            /* sp034.302 - addition - free conCb if its in dead state */
            if (cb->cType & SP_DEAD)
               spFreeConCb(cb);
         }
         else
         {
            /* since we can't send release, freeze and free */
            spFreezeSlr(cb, SP_FRZ_CD);
            spFreeConCb(cb);
         }
         break;

      case DTX_ST:
      case RCG_ST:
      case RCD_ST:
      case RBT_ST:
         /* release both */
         spRelease(cb, CG_SIDE, rsn, ORIG_NET, NULLP);
         spRelease(cb, CD_SIDE, rsn, ORIG_NET, NULLP);

         /* sp034.302 - addition - free conCb if its in dead state */
         if (cb->cType & SP_DEAD)
            spFreeConCb(cb);

         break;

      case RLS_ST:
         break;

      default:
         SPLOGERROR(ERRCLS_DEBUG, ESP319, (ErrVal) cb->state,
                    "invalid call state");
         break;
   } /* switch (cb->state) */

   RETVOID;
} /* spDropCall */


/*
*
*       Fun:   spHandleBadDecode
*
*       Desc:  Try to do something meaningful with a partially
*              deciphered message
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy4.c
*
*/
#ifdef ANSI
PUBLIC Void spHandleBadDecode
(
SpNSapCb *nSap,           /* network sap */
Dpc opc                   /* originating point code */
)
#else
PUBLIC Void spHandleBadDecode(nSap, opc)
SpNSapCb *nSap;           /* network sap */
Dpc opc;                  /* originating point code */
#endif
{

   TRC2(spHandleBadDecode)

   UNUSED(opc);

   switch (nSap->mfMsgCtl.msgType)
   {
      case M_CONREQ:
      { 
         SpConReq *cr;
         cr = (SpConReq*)&spCb.pdu.m.conReq;
         break;
      }
      case M_CONCFM:
      {
         SpConCfm *cc;
         cc = (SpConCfm*)&spCb.pdu.m.conCfm;
         break;
      }
      case M_CONREF:
      {
         SpConRef *cr;
         cr = (SpConRef*)&spCb.pdu.m.conRef;
         break;
      }
      case M_RELSD:
      {
         SpRelsd *rel;
         rel = (SpRelsd*)&spCb.pdu.m.relsd;
         break;
      }
      case M_RELCMP:
      {
         SpRelCmp *rc;
         rc = (SpRelCmp*)&spCb.pdu.m.relCmp;
         break;
      }
      case M_DATA1:
      {
         SpData1 *data1;
         data1 = (SpData1*)&spCb.pdu.m.data1;
         break;
      }
      case M_DATA2:
      {
         SpData2 *data2;
         data2 = (SpData2*)&spCb.pdu.m.data2;
         break;
      }
      case M_DATAACK:
      {
         SpDataAck *da;
         da = (SpDataAck*)&spCb.pdu.m.dataAck;
         break;
      }
      case M_UNITDATA:
      {
         SpUnitData *ud;
         ud = (SpUnitData*)&spCb.pdu.m.uData;
         break;
      }
      case M_LUNITDATA:
      case M_XUNITDATA:
      {
         SpXUnitData *ud;
         ud = (SpXUnitData*)&spCb.pdu.m.xuData;
         break;
      }
      case M_UNITDATASRV:
      {
         SpUnitDataSrv *uds;
         uds = (SpUnitDataSrv*)&spCb.pdu.m.uDataSrv;
         break;
      }
      case M_LUNITDATASRV:
      case M_XUNITDATASRV:
      {
         SpXUnitDataSrv *uds;
         uds = (SpXUnitDataSrv*)&spCb.pdu.m.xuDataSrv;
         break;
      }
      case M_EXPDATA:
      {
         SpExpData *ed;
         ed = (SpExpData*)&spCb.pdu.m.expData;
         break;
      }
      case M_EXPDATAACK:
      {
         SpExpDataAck *eda;
         eda = (SpExpDataAck*)&spCb.pdu.m.expDataAck;
         break;
      }
      case M_RSTREQ:
      {
         SpResReq *rr;
         rr = (SpResReq*)&spCb.pdu.m.resReq;
         break;
      }
      case M_RSTCFM:
      {
         SpResCfm *rc;
         rc = (SpResCfm*)&spCb.pdu.m.resCfm;
         break;
      }
      case M_PDUERR:
      {
         SpPduErr *pe;
         pe = (SpPduErr*)&spCb.pdu.m.pduErr;
         break;
      }
      case M_INACTST:
      {
         SpInactTst *it;
         it = (SpInactTst*)&spCb.pdu.m.inactTst;
         break;
      }
      default:
      {
         break;
      }
   }

   spDropMsg(&nSap->mfMsgCtl.mp);
   nSap->mfMsgCtl.mp = (Buffer *) NULLP;

   RETVOID;
} /* spHandleBadDecode */


/*
 *      Fun:   spLiHndlCr
 *
 *      Desc:  This function handles connection request from remote end.
 *
 *      Ret:   VOID
 *             
 *      Notes: 
 *
 *      File:  cp_bdy4.c
 */
#ifdef ANSI
PUBLIC Void spLiHndlCr
(
SpNSapCb *nSap,            /* pointer to n/w sap Control block */
SrvInfo srvInfo,           /* sub-service field info */
Dpc opc,                   /* point code from where CR received */
Buffer *data,              /* data buffer */
LnkSel lnkSel              /* signalling link selector */
)
#else
PUBLIC Void spLiHndlCr(nSap, srvInfo, opc, data, lnkSel)
SpNSapCb *nSap;           /* pointer to n/w sap Control block */
SrvInfo srvInfo;          /* sub-service filed info */ 
Dpc opc;                  /* point code from where CR received */
Buffer *data;             /* data buffer */
LnkSel lnkSel;            /* signalling link selector */
#endif
{
   SpConReq *cReq;        /* connection request event */
   SpNwCb *nwData;        /* pointer to n/w control block */
   SpNwCb *outNwData;     /* sp045.302 - addition - pointer to n/w control
                           * block for outgoing network.
                           */
   U8 i;                  /* counter */
   U8 ssf;                /* sub-service field */
   U8 numEntity;          /* number of SCCP entity in outgoing entity set */
   U8 nextEntity;         /* next SCCP entity to be selected for load share */
   U8 mode;               /* mode of operation SCCP entity */
   U8 noCplng;            /* flag to indiacte coupling at relay node */
   S16 ret;               /* return value */
   S16 thresh;            /* resource threshold */
   SpConCb *cb;           /* connection control blcok */
   SpSapCb *sap;          /* upper sap cb */
   SpRteKey rKey;         /* Route Key */
   SpRteCb *cgrCb;        /* Route control block for calling side */
   SpRteCb *rCb;          /* Route control block  for called side */
   SpAddr oCdAddr;        /* original called address */
   SpAddr cgAddr;         /* calling address */
   U8 flag;               /* flag indicating backup routing is done */
   SpAddr outAddr[MAXENTITIES]; /* array of outgoing SCCP entities */
   U8 cause;              /* cause of failure */
   U16 repCause;          /* sccp error perf/subsys availablity report */
   Prior prior;           /* sp020.302 - addition - priority of recvd CR msg */

   TRC2(spLiHndlCr)

   /* sp044.302 - addition - Initialization of Local Variables */   
   cb = NULLP;   
   cause = 0;   
   repCause = 0;   
  
   nwData = nSap->nwData;
   /* sp045.302 - addition - initialise outgoing network CB with incoming
    * network CB.
    */
   outNwData = nSap->nwData;
   ssf = (srvInfo & 0xC0) >> 6;

   /* sp020.302 - addition - get priority of recvd CR message to
    * use for DT, AK messages on this connection
    */
   prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);

   /* Find the rCb for the message recieved */
   rKey.k1.dpc = opc;
   rKey.k1.nwId = nSap->nwData->nwId;
   spFindRte(&spCb.rteCp, &cgrCb, &rKey, 0);
   if (cgrCb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP320, (ErrVal) ERRZERO,
                 "cannot find the route");
      spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                           RFC_UNQUAL, ssf, data);
      RETVOID;
   }

   /* Check the local resources and if not available initiate
    * conection refusal
    */
   (Void) SChkRes(spCb.spInit.region, spCb.spInit.pool, &thresh);

   if (thresh <= spCb.spCfg.conThresh)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP321, (ErrVal) ERRZERO,
                 "no. of connection thresh reach its max value");
      /* sp028.302 - addition - generate alarm */
      spSendLmSta(LCM_CATEGORY_INTERNAL, LSP_EVENT_CONREQ_FAILURE,
                  LSP_CAUSE_CONN_THRESH_EXCEEDED, NOTUSED, NOTUSED);
      spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                           RFC_NRQOST, ssf, data);
      RETVOID;
   }

   /* simplify dereferencing */
   cReq = &spCb.pdu.m.conReq;

   /* called address */
   spTknStrToSpAddr(&cReq->cdAddr.spAddr, &oCdAddr, nwData->variant, ssf);
#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
   if (oCdAddr.pcInd == FALSE)
      oCdAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */

   /* calling address */
   if ((cReq->cgAddr.eh.pres != NOTPRSNT) &&
        (cReq->cgAddr.spAddr.pres != NOTPRSNT))
   {
      spTknStrToSpAddr(&cReq->cgAddr.spAddr, &cgAddr, nwData->variant, ssf);
#ifdef CMSS7_SPHDROPT
#ifdef SP_PRESERVE_ADDR
      if (cgAddr.pcInd == FALSE)
         cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */
   }
   /* sp004.302 - initialize presence of calling address as FALSE,
    * if calling party address is not present in incoming CR message
    */
   else
      cgAddr.pres = FALSE;

   /* Resolve outgoing address */
   /* sp045.302 - modification - pass ptr to nwCb instead of selfPc 
    * pass ptr to outgoing network CB
    */
   ret = spResolveAddr(&oCdAddr, PCLASS0, &numEntity, &nextEntity,
                       &mode, &outAddr[0], &noCplng, nwData, &outNwData);

   if (ret != SP_OK)
   {
      SpReport spRep;    /* sccp error perf report */

      /* Initiate connection refusal */
      if (cgrCb->swtch == LSP_SW_ITU96)
          spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                              RFC_NTBADADDR, ssf, data);
      else
         spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                              RFC_ACCFAIL, ssf, data);

      /* fill sccp error report */
      cmZero((U8 *) &spRep, sizeof(SpReport));

      spRep.nwId = nSap->nwData->nwId;
      spRep.sw = nSap->nwData->variant;
      cmCopySpAddr(&oCdAddr, &spRep.cdPa);

      /* generate sccp error performance report */
      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NTSPECADDR,
                       &spRep);

      /* increment statistics counter */
      spCb.sts.rfNTSA++;
   }
   else
   {
      U8 foundEntity;
      if (mode == DOMINANT)
         nextEntity = 0;
      foundEntity = FALSE;
      for(i = 0; i < numEntity && foundEntity == FALSE; i++)
      {
         /* sp045.302 - addition - check the variants of incoming and outgoing 
          * networks. if network id's are different then variant of
          * the two networks must be same. if not then send alarm to LM and 
          * generate error report.
          */
         if ((nwData->nwId != outNwData->nwId) && 
             (nwData->variant != outNwData->variant))
         {
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   "spUiHndlUDatReq: Varaints are not same for incoming and\
                    outgoing networks : incoming network id = %d,\
                    outgoing network id = %d\
                    and the variant of incoming network is %d and variant of\
                    outgoing network is %d\n", nwData->nwId,
                    outNwData->nwId, nwData->variant,
                    outNwData->variant));

            spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                        LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);

            RETVOID;
         }
         /* sp045.302 - modification - replace nwData with outNwData */
         ret = spCheckRoute(outNwData, &outAddr[nextEntity], lnkSel, PCLASS0,
                               &rCb, &flag, &sap, FROM_LOWER);
         switch(ret)
         {
            case SP_LOCAL : /* This is the destination node */
               cb = spNewConCb(nwData);
               if (cb == (SpConCb *) NULLP)
               {
                  SPLOGERROR(ERRCLS_ADD_RES, ESP322, (ErrVal) ERRZERO,
                             "cannot allocate a con CB");
                  spSendBackConRefused(nSap, opc, 
                                       &spCb.pdu.m.conReq.cdAddr.spAddr,
                                       RFC_NRQOST, ssf, data);
                  RETVOID;
               }
               cb->sap = sap;

               /* sp020.302 - addition - save priority of recvd CR message to
                * use for DT, AK messages on this connection
                */
               cb->prior = prior;

               /* copy calling and called address in ConCb */
               cmCopySpAddr(&oCdAddr, &cb->t.req0.oCdAddr);
               cmCopySpAddr(&outAddr[nextEntity], &cb->t.req0.cdAddr);

               /* sp024.302 - addition - perform calling party addr treatment
                * as per ITU-T Q.714, section 2.7.5.2, (d).
                */
               if (cgAddr.pres == TRUE)
               {
                  /* if there is no pc then insert opc into cg pc */ 
                  if (cgAddr.pcInd == FALSE)
                  {
                     cgAddr.pc = opc;
                     cgAddr.pcInd = TRUE;
                  }
               }
               else
               {
                  /* cgAddr absent, construct it from MTP routing label.
                   * Do not mark presence of cgAddr as TRUE, we will not
                   * indicate cgAddr to our user as we did not recv in CR
                   * message. Inclusion of pc is only to identify the
                   * originating node of incoming connection section.
                   */
                  cgAddr.pc = opc;
                  cgAddr.pcInd = TRUE;
               }

               cmCopySpAddr(&cgAddr, &cb->t.req0.cgAddr);

               /* credit */
               if ((cReq->credit.eh.pres != NOTPRSNT) &&
                   (cReq->credit.credit.pres != NOTPRSNT))
                  cb->qos.credit = cReq->credit.credit.val;

               /* assign importance */
               if (cReq->imp.eh.pres != NOTPRSNT)
               {
                  cb->imp.val = cReq->imp.importance.val;
                  cb->imp.pres = PRSNT_NODEF;
               }
               else
                  cb->imp.pres = NOTPRSNT;

               /* Fill the general param in ConCb */
               /* sp024.302 - modification - use cgAddr.pc */
               cb->key.k1.cgPc = cgAddr.pc;
               /* setup hash keys... */
               cb->key.k3.suId = cb->sap->suId;
               cb->key.k3.spInstId = cb->cs[OPSIDE(cb)].conId.spInstId;
               cb->cType |= SP_REQ0;            /* this must be the case */
               cb->cType |= SP_DEST;            /* this is the destination */
               cb->qos.pClass = cReq->pClass.pClass.val;
               cb->qos.retOpt = 0; /* unused */
               cb->ssf = ssf;
               /* sp045.302 - addition - save the network CB ptr of the network
                * from which CR was received in the SIDE(cb) 
                */
               cb->cs[SIDE(cb)].nwData = nwData;
#ifndef ZP
               /* Insert the ref. number in the connection control block */
               if (!spInsertConRef (cb))
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESP323, (ErrVal) ERRZERO,
                             "cannot allocate a ref nmb for the connection");
                  spSendBackConRefused(nSap, opc, 
                                       &spCb.pdu.m.conReq.cdAddr.spAddr,
                                       RFC_NRQOST, ssf, data);
                  SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *)cb,
                           (Size) sizeof(SpConCb));
                  RETVOID;
               }
#else
               {
                  ZpAMSpConCb zpAMSpConCb;
                  zpAMSpConCb.intfc = CMFTHA_IF_LOWER;
                  zpAMSpConCb.sls = lnkSel;
                  zpAMSpConCb.conReq = &spCb.pdu.m.conReq;
                  zpAddMapping (ZP_SP_CONCB, (Void *)cb, (Void *)&zpAMSpConCb);

                  /* Insert the ref. number in the connection control block */
                  if (!zpInsertConRef (cb))
                  {
                     /* sp026.302 - addition - send back CREF */
                     spSendBackConRefused(nSap, opc, 
                                          &spCb.pdu.m.conReq.cdAddr.spAddr,
                                          RFC_NRQOST, ssf, data);
                     zpDelMapping (ZP_SP_CONCB, cb);

                     /* sp026.302 - removal - dropping of data, data passed to
                      * above function returning CREF.
                      */
                     SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *)cb,
                              (Size)sizeof(SpConCb));
                     RETVOID;
                  }
               }
#endif /* ZP */

               /* setup the  calling side */
               cb->cs[SIDE(cb)].nSap = nSap;

               /* sp024.302 - modification - use cgAddr.pc */
               cb->cs[SIDE(cb)].pc = cgAddr.pc;
               cb->cs[SIDE(cb)].swtch = cgrCb->swtch;
               cb->cs[SIDE(cb)].conId.suId = cb->cs[SIDE(cb)].nSap->suId;
               cb->cs[SIDE(cb)].conId.suInstId = cReq->sLclRef.sLclRef.val;

               /* setup called side */
               cb->cs[OPSIDE(cb)].nSap = NULLP;
               /* sp045.302 - modification - use selfPc from outNwData */
               cb->cs[OPSIDE(cb)].pc = outNwData->selfPc;
               /* sp045.302 - addition - initialise the nwData of OPSIDE 
                * with outNwData. 
                */
               cb->cs[OPSIDE(cb)].nwData = outNwData;
               cb->cs[OPSIDE(cb)].conId.suId = cb->sap->suId;
               cb->cs[OPSIDE(cb)].conId.spId = cb->sap->spId;

               /* sp026.302 - removal - remove function call spAddCon. This
                * function was to maintain conn hash list based on CG_KEY,
                * CD_KEY and SU_KEY and is no longer used.
                */
               foundEntity = TRUE;
               break;

            case SP_OK:      /* destination is remote */
               /* check if hop voilation occurs */

               if (cReq->hopCntr.eh.pres)
               {
                  /* check to see if hop counter need to be decremented */
                  if (oCdAddr.rtgInd == RTE_GT)
                  {
                     if (cReq->hopCntr.cnt.val <= 0)
                     {  /* we have a hop counter violation */
                        /* initiate connection refusal   */
                        if (rCb->swtch == LSP_SW_ITU96 || 
                            rCb->swtch == LSP_SW_ANS96 ||
                            rCb->swtch == LSP_SW_BELL05)
                           spSendBackConRefused(nSap, opc, 
                                               &spCb.pdu.m.conReq.cdAddr.spAddr,
                                               RFC_HOPVIOLATE, ssf, data);
                        else
                           spSendBackConRefused(nSap, opc, 
                                               &spCb.pdu.m.conReq.cdAddr.spAddr,
                                               RFC_DSTADRIN, ssf, data);
                        spCb.sts.rfHopViolate++;
                        spSendLmSta(LCM_CATEGORY_PROTOCOL, 
                                    LSP_EVENT_HOP_VIOLATION,
                                    LCM_CAUSE_OUT_OF_RANGE, NOTUSED, NOTUSED);
                        RETVOID;
                     } /* if(cReq->hopCntr.cnt.val <= 0) */
                     else
                        /* decrement te hop counter value by 1 */
                        --cReq->hopCntr.cnt.val;
                  }
               }

               if (noCplng == TRUE) /* no coupling case */
               {
                  SrvInfo sInfo;

                  sInfo = (ssf << 6) | SCCP_SI;

                  /* sp020.302 - addition - insert priority of incomg CR */
                  sInfo = sInfo | ((prior << 4) & 0x30);

                  if (cgAddr.pres == TRUE)
                  {
                     /* modify the calling address as there is no coupling */ 
                     if (cgAddr.pcInd == FALSE)
                     {
                        cgAddr.pc = opc;
                        cgAddr.pcInd = TRUE;
                     }
                     /* if no SSN present ,fill it as UNKNOWN */
                     if (cgAddr.ssnInd == FALSE)
                     {
                        cgAddr.ssn = SS_UNKNOWN;
                        cgAddr.ssnInd = TRUE;
                     }
                  }
                  else /* cgAddr absent, construct it from MTP routing label */
                  {
                     cgAddr.pc = opc;
                     cgAddr.pcInd = TRUE;
                     /* SSN is coded as unknown and rtgInd is set to SSN */
                     cgAddr.ssn = SS_UNKNOWN;
                     cgAddr.ssnInd = TRUE;
                     cgAddr.rtgInd = RTE_SSN;
                     cgAddr.pres = TRUE;

                     /* sp024.302 - addition - initialize remaining fields of
                      * cgAddr with appropriate values from oCdAddr
                      */
                     cgAddr.sw = oCdAddr.sw;
                     cgAddr.ssfPres = oCdAddr.ssfPres;
                     cgAddr.ssf = oCdAddr.ssf;
                     cgAddr.niInd = oCdAddr.niInd;
                     cgAddr.gt.format = GTFRMT_0;
                  }

#ifdef CMSS7_SPHDROPT
                  /* assign sp hdr option as default so as pc is included
                   * in calling address for no coupling case
                   */
                  cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* CMSS7_SPHDROPT */

                  ret = spNoCplngCr(rCb, &cgAddr, &outAddr[nextEntity], sInfo, 
                                    lnkSel, data);
                            
                  if (ret == RFAILED)
                     spSendBackConRefused(nSap, opc, 
                                          &spCb.pdu.m.conReq.cdAddr.spAddr,
                                          RFC_NRQOST, ssf, NULLP);

                  RETVOID;
               } /* if (noCplng == TRUE) */
               else /* coupling required */
               {
                  cb = spNewConCb(nwData);
                  if (cb == (SpConCb*)NULLP)
                  {
                     SPLOGERROR(ERRCLS_ADD_RES, ESP324, (ErrVal) ERRZERO,
                                "cannot allocate a con CB");
                     spSendBackConRefused(nSap, opc, 
                                          &spCb.pdu.m.conReq.cdAddr.spAddr,
                                          RFC_NRQOST, ssf, data);
                     RETVOID;
                  }
                  /* sp045.302 - addition - save the network CB ptr of the network
                   * from which CR was received in the SIDE(cb) 
                   */
                  cb->cs[SIDE(cb)].nwData = nwData;
                  cb->cs[OPSIDE(cb)].nwData = outNwData;
    
                  /* copy calling and called address in ConCb */
                  cmCopySpAddr(&oCdAddr, &cb->t.req0.oCdAddr);

                  /* sp024.302 - addition - perform calling party addr treatment
                   * as per ITU-T Q.714, section 2.7.5.2, (c).
                   */
                  if (cgAddr.pres == TRUE)
                  {
                     /* if there is no pc then insert opc into cg pc. We
                      * have already initialized the spHdrOpt after conversion
                      * of TknStr to SpAddr. So inclusion of pc depends on
                      * whether the flag SP_PRESERVE_ADDR is defined or not.
                      * If flag is defined then pc will not be encoded in 
                      * cgAddr in outgoing CR and the next node will have to 
                      * construct it from opc of MTP routing label. Otherwise
                      * pc will be endoced in cgAddr.
                      */
                     if (cgAddr.pcInd == FALSE)
                     {
                        cgAddr.pc = opc;
                        cgAddr.pcInd = TRUE;
                     }
                  }
                  else /* cgAddr absent, construct it from MTP routing label */
                  {
#ifdef CMSS7_SPHDROPT
                     /* we are constructing cgAddr and so in this case we
                      * always want to include PC in cgAddr unless the flag
                      * SP_PRESERVE_ADDR is defined. If the flag is defined
                      * then we will not include pc and the next node will
                      * have to construct cgPc from opc of MTP routing label.
                      * If flag is not defined then we will include the pc.
                      */
#ifdef SP_PRESERVE_ADDR
                     cgAddr.spHdrOpt = CMSS7_NO_SP_PC;
#else  /* SP_PRESERVE_ADDR */
                     cgAddr.spHdrOpt = CMSS7_DEF_OPT;
#endif /* SP_PRESERVE_ADDR */
#endif /* CMSS7_SPHDROPT */
                     cgAddr.pres = TRUE;
                     cgAddr.sw = oCdAddr.sw;
                     cgAddr.ssfPres = oCdAddr.ssfPres;
                     cgAddr.ssf = oCdAddr.ssf;
                     cgAddr.niInd = oCdAddr.niInd;
                     cgAddr.rtgInd = RTE_SSN;
                     cgAddr.ssnInd = TRUE;
                     cgAddr.pcInd = TRUE;
                     cgAddr.ssn = SS_UNKNOWN;
                     cgAddr.pc = opc;
                     cgAddr.gt.format = GTFRMT_0;
                  }

                  cmCopySpAddr(&outAddr[nextEntity], &cb->t.req0.cdAddr);

                  /* sp024.302 - modification - use cg pc */
                  cb->key.k1.cgPc = cgAddr.pc;
                  cb->key.k2.cdPc = cb->t.req0.cdAddr.pc;
                  cb->cType |= SP_REQ0;         /* this must be the case */
                  cb->cType |= SP_INTR;         /* coupling case,so we r INTR */
                  cb->sap = NULLP;               
                  cb->ssf = ssf;
                  cb->qos.pClass = cReq->pClass.pClass.val;
                  cb->qos.retOpt = 0; /* unused */

                  /* sp020.302 - addition - save priority of recvd CR message to
                   * use for DT, AK messages on this connection
                   */
                  cb->prior = prior;
     
                  if (cReq->hopCntr.eh.pres)
                  {
                     cb->hopCntr.pres = TRUE;
                     cb->hopCntr.val = cReq->hopCntr.cnt.val;
                  }
                  else
                  {
                     cb->hopCntr.pres = FALSE;
                     cb->hopCntr.val = 0;
                  }

                  /* This is required in case the CREQ was received from
                   * an ITU96 node and routed to an ITU88 or ITU92 node
                   */
                  if ((rCb->swtch == LSP_SW_ITU92) || 
                      (rCb->swtch == LSP_SW_ITU88) ||
                      (rCb->swtch == LSP_SW_CHINA))
                  {
                     cb->hopCntr.pres = FALSE;
                  }

                  /* credit */
                  if ((cReq->credit.eh.pres != NOTPRSNT) &&
                      (cReq->credit.credit.pres != NOTPRSNT))
                     cb->qos.credit = cReq->credit.credit.val;

#ifndef ZP
                  /* Insert the ref. number in the connection control block */
                  if (!spInsertConRef (cb))
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESP325, (ErrVal) ERRZERO,
                                "cannot allocate a reference number for the connection");
                     spSendBackConRefused(nSap, opc, 
                                          &spCb.pdu.m.conReq.cdAddr.spAddr,
                                          RFC_NRQOST, ssf, data);
                     SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *)cb,
                              (Size)sizeof(SpConCb));
                     RETVOID;
                  }
#else
                  {
                     ZpAMSpConCb zpAMSpConCb;
                     zpAMSpConCb.intfc = CMFTHA_IF_LOWER;
                     zpAMSpConCb.sls = lnkSel;
                     zpAMSpConCb.conReq = &spCb.pdu.m.conReq;
                     zpAddMapping(ZP_SP_CONCB, (Void *) cb,
                                  (Void *) &zpAMSpConCb);

                     /* Insert the ref. number in the connection cntrl block */
                     if (!zpInsertConRef(cb))
                     {
                        zpDelMapping(ZP_SP_CONCB, cb);
                        if (!data)
                           spDropMsg(&data);
                        SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                                 (Data *) cb, (Size) sizeof(SpConCb));
                        RETVOID;
                     }
                  }
#endif /* ZP */
                  cb->cs[SIDE(cb)].nSap = nSap;

                  /* sp024.302 - modification - use cg pc */
                  cb->cs[SIDE(cb)].pc = cgAddr.pc;
                  cb->cs[SIDE(cb)].swtch = cgrCb->swtch;
                  cb->cs[SIDE(cb)].conId.suId = cb->cs[SIDE(cb)].nSap->suId;
                  cb->cs[SIDE(cb)].conId.suInstId = cReq->sLclRef.sLclRef.val;
                  cb->cs[OPSIDE(cb)].pc = cb->t.req0.cdAddr.pc;
                  cb->cs[OPSIDE(cb)].swtch = rCb->swtch;
                  cb->cs[OPSIDE(cb)].nSap = rCb->nSap;

                  /* sp026.302 - removal - remove function call spAddCon. This
                   * function was to delete conn from hash list based on CG_KEY,
                   * CD_KEY and SU_KEY and is no longer used.
                   */

                  /* sp024.302 - addition - modify cg pc with own pc before
                   * sending out the CR to next node as per ITU Q.714,
                   * section 2.7.5.2, (c). We can not determine whether
                   * coupling will be done at next node or not so we will
                   * always include our own pc in cg pc.
                   */
                  /* sp045.302 - modification - replacing nwData with 
                   * outNwData.
                   */
                  cgAddr.pc = outNwData->selfPc;

                  /* sp024.302 - modification - copy cgAddr into ConCb at this
                   * place after modifying cg pc.
                   */
                  cmCopySpAddr(&cgAddr, &cb->t.req0.cgAddr);

                  /* get message importance */
                  spLiGetCoMsgImp(cb, spCb.pduHdr.msgType.val, &spCb.pdu, nSap,
                                  srvInfo);
                  foundEntity = TRUE;
                  break;
              } /* coupling required case */

            case SP_UNEQUIP: /* upper user unequipped */
               /* increment statistics */
               spCb.sts.rfUnequip++;

               /* refuse connection request */
               if (cgrCb->swtch == LSP_SW_ITU96)
                  spSendBackConRefused(nSap, opc, 
                                       &spCb.pdu.m.conReq.cdAddr.spAddr,
                                       RFC_UNEQUIP, ssf, data);
               else
                  spSendBackConRefused(nSap, opc, 
                                       &spCb.pdu.m.conReq.cdAddr.spAddr,
                                       RFC_UNQUAL, ssf, data);
               RETVOID;

            case SP_SSFAIL:      
               /* increment statistics */
               spCb.sts.rfSsnFail++;
               cause = RFC_SSFAIL;
               repCause = LSP_CAUSE_RTF_SSFAIL;
               foundEntity = FALSE;
               break;

            case SP_SPFAIL:
               /* increment statistics */
               spCb.sts.rfNetFail++;
               cause = RFC_DSTADRIN;
               repCause = LSP_CAUSE_RTF_NETFAIL;
               foundEntity = FALSE;
               break;

            default: /* SP_ERROR */
               /* increment statistics */
               spCb.sts.rfUnknown++;
               SPLOGERROR (ERRCLS_INT_PAR, ESP326, (ErrVal) ret,
                           "unexpected return code");
               /* refusal cause: Unqualified */
               spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                                    RFC_UNQUAL, ssf, data);
               RETVOID;
         } /* swtch (ret) */
         nextEntity++;
         if (nextEntity > numEntity)
            nextEntity = 0;
      } /* for(i = 0; i < numEntity && foundEntity == FALSE; i++) */

      if (foundEntity == FALSE)
      {
         SpReport spRep;    /* sccp error perf/subsys availability report */

         cmZero((U8 *) &spRep, sizeof(SpReport));
         
         spRep.nwId = nSap->nwData->nwId;
         spRep.sw = nSap->nwData->variant;
         cmCopySpAddr(&outAddr[nextEntity - 1], &spRep.cdPa);

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, repCause, &spRep);

         /* send back con refused */
         spSendBackConRefused(nSap, opc, &spCb.pdu.m.conReq.cdAddr.spAddr,
                              cause, ssf, data);
         RETVOID;
      }         
      else
         /* send connection request */
         spConRequest(cb, data);
   }
   RETVOID;
} /* spLiHndlCr */


/*
 *      Fun:   spNoCplngCr
 *
 *      Desc:  This function sends the connection request to
 *             remote end without having any coupling at local
 *             node.
 *
 *      Ret:   RFAILED
 *             ROK
 *             
 *      Notes: 
 *
 *      File:  cp_bdy4.c
 */
#ifdef ANSI
PUBLIC S16 spNoCplngCr
(
SpRteCb *rCb,            /* pointer to called side route control block */
SpAddr *cgAddr,          /* calling  side */
SpAddr *cdAddr,          /* called side */
SrvInfo sInfo,           /* sub-service field */
LnkSel lnkSel,           /* signalling link selection */
Buffer *data             /* pointer to data buffer */
)
#else
PUBLIC S16 spNoCplngCr(rCb, cgAddr, cdAddr, sInfo, lnkSel, data)
SpRteCb *rCb;            /* pointer to called side route control block */
SpAddr *cgAddr;          /* calling  side */
SpAddr *cdAddr;          /* called side */
SrvInfo sInfo;           /* sub-service field */
LnkSel lnkSel;           /* signalling link selection */
Buffer *data;            /* pointer to data buffer */
#endif
{
   S16 ret;              /* return value */
   SpConReq *cReq;       /* Connection request */
   Buffer *mBuf;         /* message buffer */
   Prior prior;          /* sp020.302 - addition - priority of recvd CR */
   
   TRC2(spNoCplngCr)

   /* simplify dereferencing */
   cReq = &spCb.pdu.m.conReq;

   /* sp020.302 - addition - retrieve priority from sInfo */
   prior = (Prior) ((Prior) (sInfo & 0x30) >> (Prior) 4);

   /* Fill the appropriate CgAddr and CdAddr in cReq and rest of
    * the elements can be placed as it is 
    */
   cReq->cdAddr.eh.pres = PRSNT_NODEF;
   spSpAddrToTknStr(cdAddr, &cReq->cdAddr.spAddr);
   cReq->cgAddr.eh.pres = PRSNT_NODEF;
   spSpAddrToTknStr(cgAddr, &cReq->cgAddr.spAddr);

   /* Decrement the hop counter value */
   if (cReq->hopCntr.eh.pres)
   {
      cReq->hopCntr.cnt.val--;
   }

   /* get the message buffer from OPSIDE nSap */
   ret = SGetMsg(rCb->nSap->pst.region, rCb->nSap->pst.pool, &mBuf);
   if(ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP327, (ErrVal) ret, "SGetMsg failed");
      if (data)
         SPutMsg(data);
      RETVALUE(RFAILED);
   }

   /* Set up incoming data buffer into outgoing SAP for encoding */
   rCb->nSap->mfMsgCtl.sccpInfo.data = data;

   /* Encode the CR message */
   SPENCPDUHDR(&rCb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
               &pduHdrMsgDef[0], TRUE, TRUE, rCb->nSap->nwData->variant,
               MF_SCCP);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP328, (ErrVal) ret, "SPENCPDUHDR failed");
      if (mBuf)
         SPutMsg(mBuf);
      if (rCb->nSap->mfMsgCtl.sccpInfo.data)
         SPutMsg(rCb->nSap->mfMsgCtl.sccpInfo.data);
		/* sp035.302 - addition - assigning explicit NULL to 
       * data pointer to avoid double deallocation. 
       */
      rCb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
      RETVALUE(RFAILED);
   }

   SPENCPDU(&rCb->nSap->mfMsgCtl, ret, (ElmtHdr *) cReq);
   if (ret != MFROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP329, (ErrVal) ret, "SPENCPDU failed");
      if (mBuf)
         SPutMsg(mBuf);
      if (rCb->nSap->mfMsgCtl.sccpInfo.data)
         SPutMsg(rCb->nSap->mfMsgCtl.sccpInfo.data);
		/* sp035.302 - addition - assigning explicit NULL to 
       * data pointer to avoid double deallocation. 
       */
      rCb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;	
      RETVALUE(RFAILED);
   }

   /* before delivering data down, check if message to be discarded
    * due to traffic limitation mechanism if the route is itu 96 and
    * traffic limitation mechsnism is turned on
    */
   if ((spCb.spTrfLimFlag == TRUE) && (rCb->swtch == LSP_SW_ITU96))
   {
      U8 imp;     /* message importance */
      U8 ssf;     /* sub-service field */

      /* find ssf from sInfo */
      ssf = (rCb->nSap->nwData->sInfo & 0xC0) >> 6;

      /* derive message importance from incoming CR if present
       * or derive imp from sio priority in case of national
       * network or assume default value of importance
       */
      if (cReq->imp.eh.pres == PRSNT_NODEF)
         imp = cReq->imp.importance.val;
      else
      {

         if (ssf != SSF_NAT)   /* not a national network */
            imp = spCb.spMsgImp.defCrImp;
         else                  /* national network */
         {
            if (rCb->nSap->nwData->sioPrioImpPres == TRUE)
               imp = rCb->nSap->nwData->sioPrioImp[prior];
            else
               imp = spCb.spMsgImp.defCrImp;
         }
      }

      /* find restriction */
      ret = spFindRestriction(rCb, imp);
      if (ret == SP_DISCARD)
      {
         SpReport spRep;       /* sccp error perf report */

         /* message discarded due to traffic limitation mechanism */
         SPLOGERROR(ERRCLS_DEBUG, ESP330, (ErrVal) 0, "Message discarded");
         if (mBuf)
            SPutMsg(mBuf);

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = rCb->nSap->nwData->nwId;
         spRep.sw = rCb->nSap->nwData->variant;
         spRep.dpc = rCb->dpc;

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                          &spRep);
         RETVALUE(RFAILED);
      }
   } /* if ((...spTrfLimFlag == TRUE) && (..swtch == LSP_SW_ITU96)) */

   /* deliver the message down to called side */
   /* sp020.302 - modification - pass same priority as recvd in incoming CR */
   (Void) SpLiSntUDatReq(&rCb->nSap->pst, rCb->nSap->spId,
                         rCb->nSap->nwData->selfPc, cdAddr->pc, sInfo, lnkSel,
                         prior, mBuf);

   /* update statistics for CR messages sent */
   spCb.sts.crTx++;

   RETVALUE(ROK);
} /* spNoCplngCr */


/*
 *      Fun:   spLiGetCoMsgImp
 *
 *      Desc:  This function calculates the importance for a connection
 *             oriented messages received from network. This function
 *             also updates relevant statistics counters for messages
 *             received from network.
 *
 *      Ret:   RETVOID
 *             
 *      Notes: 
 *
 *      File:  cp_bdy4.c
 */
#ifdef ANSI
PUBLIC Void spLiGetCoMsgImp
(
SpConCb *cb,            /* connection control block */
U8 msgType,             /* message type */
SpAllPdus *pdu,          /* pdu received from network */
SpNSapCb *nSap,         /* NSAP control block */
SrvInfo srvInfo         /* service information octet */
)
#else
PUBLIC Void spLiGetCoMsgImp(cb, msgType, pdu, nSap, srvInfo)
SpConCb *cb;            /* connection control block */
U8 msgType;             /* message type */
SpAllPdus *pdu;         /* pdu received from network */
SpNSapCb *nSap;         /* NSAP control block */
SrvInfo srvInfo;        /* service information octet */
#endif
{
   U8 prior;            /* priority */
   U8 subSrv;           /* subservice field */

   TRC2(spLiGetCoMsgImp)

   /* get priority from srvInfo */
   prior = (Prior) ((Prior) (srvInfo & 0x30) >> (Prior) 4);

   /* get subservice field from srvInfo octet */
   subSrv = (srvInfo & 0xC0) >> 6;

   /* assign imporance based on message type. Mark presence of imp
    * as present only if it is present in the incoming message else
    * only assign the default value and presence will be marked as
    * not present so as not to encode imp in the outgoing message and
    * to be used only for traffic limitation mechanism at self node.
    */
   cb->imp.pres = NOTPRSNT;

   switch (msgType)
   {
      case M_CONREQ:
         if (pdu->m.conReq.imp.eh.pres == PRSNT_NODEF)
         {
            cb->imp.val = pdu->m.conReq.imp.importance.val;
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* assign importance only if traffic limitation mechanism is ON */
            if (spCb.spTrfLimFlag == TRUE)
            {
               if (subSrv == SSF_NAT)  /* national network */
               {
                  if (nSap->nwData->sioPrioImpPres == TRUE)
                     cb->imp.val = nSap->nwData->sioPrioImp[prior];
                  else
                     cb->imp.val = spCb.spMsgImp.defCrImp;
               }
               else
                  cb->imp.val = spCb.spMsgImp.defCrImp;
            }
         }
         break;

      case M_CONCFM:
         if (pdu->m.conCfm.imp.eh.pres == PRSNT_NODEF)
         {
            cb->imp.val = pdu->m.conCfm.imp.importance.val;
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* assign importance only if traffic limitation mechanism is ON */
            if (spCb.spTrfLimFlag == TRUE)
            {
               if (subSrv == SSF_NAT)  /* national network */
               {
                  if (nSap->nwData->sioPrioImpPres == TRUE)
                     cb->imp.val = nSap->nwData->sioPrioImp[prior];
                  else
                     cb->imp.val = spCb.spMsgImp.defCcImp;
               }
               else
                  cb->imp.val = spCb.spMsgImp.defCcImp;
            }
         }  
         break;

      case M_CONREF:
         if (pdu->m.conRef.imp.eh.pres == PRSNT_NODEF)
         {
            cb->imp.val = pdu->m.conRef.imp.importance.val;
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* assign importance only if traffic limitation mechanism is ON */
            if (spCb.spTrfLimFlag == TRUE)
            {
               if (subSrv == SSF_NAT)  /* national network */
               {
                  if (nSap->nwData->sioPrioImpPres == TRUE)
                     cb->imp.val = nSap->nwData->sioPrioImp[prior];
                  else
                     cb->imp.val = spCb.spMsgImp.defCrefImp;
               }
               else
                  cb->imp.val = spCb.spMsgImp.defCrefImp;
            }
         }
         /* update statistics for cref received from network */
         spCb.sts.crefRx++;
         break;

      case M_RELSD:
         if (pdu->m.relsd.imp.eh.pres == PRSNT_NODEF)
         {
            cb->imp.val = pdu->m.relsd.imp.importance.val;
            cb->imp.pres = PRSNT_NODEF;
         }
         else
         {
            /* assign importance only if traffic limitation mechanism is ON */
            if (spCb.spTrfLimFlag == TRUE)
            {
               if (subSrv == SSF_NAT)  /* national network */
               {
                  if (nSap->nwData->sioPrioImpPres == TRUE)
                     cb->imp.val = nSap->nwData->sioPrioImp[prior];
                  else
                     cb->imp.val = spCb.spMsgImp.defRlsdImp;
               }
               else
                  cb->imp.val = spCb.spMsgImp.defRlsdImp;
            }
         }
         break;

      case M_RELCMP:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defRlcImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defRlcImp;
         }
         break;

      case M_DATA1:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defDt1Imp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defDt1Imp;
         }
         break;

      case M_DATA2:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defDt2Imp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defDt2Imp;
         }
         break;

      case M_DATAACK:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defAkImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defAkImp;
         }
         break;

      case M_EXPDATA:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defEdImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defEdImp;
         }
         break;

      case M_EXPDATAACK:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defEaImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defEaImp;
         }
         break;

      case M_RSTREQ:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defRsrImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defRsrImp;
            /* update statistics for rsr received from network */
            spCb.sts.rsrRx++;
         }
         break;

      case M_RSTCFM:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defRscImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defRscImp;
         }
         break;

      case M_PDUERR:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defErrImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defErrImp;
            /* update statistics for err received from network */
            spCb.sts.errRx++;
         }
         break;

      case M_INACTST:
         /* assign importance only if traffic limitation mechanism is ON */
         if (spCb.spTrfLimFlag == TRUE)
         {
            if (subSrv == SSF_NAT)  /* national network */
            {
               if (nSap->nwData->sioPrioImpPres == TRUE)
                  cb->imp.val = nSap->nwData->sioPrioImp[prior];
               else
                  cb->imp.val = spCb.spMsgImp.defItImp;
            }
            else
               cb->imp.val = spCb.spMsgImp.defItImp;
         }
         break;

      default:
         /* mark imp as not present, error will not be returned here */
         cb->imp.pres = NOTPRSNT;
         break;
   } /* switch (msgType) */
} /* spLiGetCoMsgImp */

#endif /* SPCO */
      

/********************************************************************30**
  
         End of file:     cp_bdy4.c@@/main/15_1 - Tue Jan 22 15:15:53 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. change region and pool in SGetMsg

1.3          ---  fmg   1. miscellaneous changes

1.4          ---  fmg   1. updated to support new system services

1.5          ---  scc   1. add missing initialization line 
                           rr.conId.spId = cb->sap->spId;
                           in spRstReq. 
             ---  scc   2. add missing initialization lines
                           con.t.cfm.eds = cb->t.req0.eds;
                           con.t.cfm.rcs = cb->t.req0.rcs;
                           in spConConfirm 

1.6          ---  scc   1. add modifications for ANSI92
             ---  fmg   2. added errchks to spFindCon
1.7          ---  fmg   1. closed open comment
             ---  fmg   2. fixed syntax errors in spFindCon

1.8          ---  fmg   1. fixed syntax error in SPCO/NOERRCHK case
             ---  fmg   2. switched switch from SW_XXXX to LSP_SW_XXXX
             ---  fmg   3. removed cm2.x include

1.9          ---  fmg   1. cleaned up SPCO logic

1.10         ---  mjp   1. added opc parameter to all SpLiSntUDatReq calls
             ---  mjp   2. check if user has bound before calling
                           primitives
             ---  mjp   3. update error codes
             ---  mjp   4. changed ce.type now set to CE_IND when
                           spUiSptConInd is called  

1.11         ---  mjp   1. replace previous error function  with SPLOGERROR
             ---  mjp   2. removed second call to cmInitTimers in spNewConCb
             ---  mjp   3. in spDat1Tx and spDat2Tx return buffer if upper
                           SAP is not bound.
             ---  mjp   4. remove reference to cb->cType after cb is set to
                           NULLP in spFreezeSlr
             ---  mjp   5. added ssf to spSendBackConRefused
             ---  mjp   6. sInfo in all calls to SpLiSntUDatReq is set 
                           base on ssf control block. 
*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.12         sp001.27 mjp  1.set connection control block to null in spFreeConCb
             sp001.27 mjp  2. Check spCb.timeFlg when processing timing queue
             sp003.27 ash  3. spSendInactTst function cb->tmr must be initialized
                              before restarting the timer.
                           4. Changes to support SCCP fault tolerance
                           5. Connection timer is started for a case where 
                              we are waiting for ConRsp from our user. On
                              expiry we should send conRefused to the calling
                              side. At present connection will be hanging if
                              out user doesn't send a ConRsp.    
                           6. spDropCall modified for fault tolerance 
             sp006.27 ash  7. Fix for connection refused
                           8. Changes for new hash library 
             sp007.27 ash  9. Fix for freezing slr while releasing a 
                              connection on SP_ORIG/SP_DEST type of node
                          10. Fixed GCC warnings
             sp012.27 ash 11. Update patch in main release
                      cp  12. Made changes as required by TCR0003 for 
                              Debug Msg generation. 
                          13. Added  SP_GEN_TRC to capture the trace.    
                          14. Added Interval, Release, Repeat Release timers 
                              for CDS and CGS.
                          15. Removed Call to SP_GEN_TRC before SpLiSntUDatReq.
                          16. Removed extra call to spRelease when the CON timer
                              expires.
                      ash 17. spLookUpConCbAndSetSide should check for spMyId 
                              not to exceeds SP_MAX_INST in the system
/main/13                  cp   1. spDisInd was not filling in rspAddr..which 
                              waz causing probs in cmPkSpAddr in LC envs.
                      cp   2. Added support for sls per route (rather 
                              then per nSap).
                      cp   3. Changed lclRef to single dimension and added 
                              clarity to the function names.
                      vb   4. Updated code as per design spec 1010030.12

             /main/15                 cp   1. DFTHA support
                           2. Patches merged in                      
             sp007.301 rc  1. Initialisation of cgAddr.pres in ConRequest
             sp010.301 sg  2. Added a configurable value to set the low
                              range on the source local refrence.
/main/15_1   ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
             sp001.302  rc   1. Sid correction
                             2. Check for japan route switch removed, as
                                japan SCCP does not support connections.
             sp004.302  rc   1. Optimizing algo to search free local reference
                             2. In func spLiHndlCr, initializing presence of
                                calling address as FALSE, if calling party
                                address is not present in incoming CR message
             sp005.302  rc   1. Sending dstLclRef in ERR msg, i.e srcLclRef
                                from the received bad message
                             2. resetting segBuf to null before sending data
                                indication up to user, for, if user is tightly
                                coupled and on data indication, user again
                                sends another data on the conn. then the conn
                                side will change.
                             3. sending audit indication to user only after
                                delivering IT message to network
             sp008.302  rc   1. Initialize param endOp in ERR and RSR message.
             sp011.302  sg 1. Check that MTP3 route is available before
                              sending connection message.
             sp012.302  sg 1. Do not drop messages as they are only
                              copies.
             sp013.302 sg  2. Free connection block when freeze timer disabled.
             sp014.302 rc  1. Prior of CREF,IT and RSR is changed to 1 from 0
             sp016.302 rc  1. Passing diff data buffer to spRelease when sending
                              release to both local user and remote at the same
                              time.
             sp018.302 rc  1. Before releasing buffer check its not null.
             sp020.302 rc  1. Using same priority in DT1/DT2/AK messages as
                              received in CR messages. In case CR is originated
                              from our node we will use the priority 0.
             sp022.302 rc  1. On expiry of IAS timer if rset state is sby
                              then do not send IT message and just restart the
                              the IAS timer. This timer will always be running
                              on sby to avoid restarting it from beginning when
                              sby becomes active.
             sp023.302 rc  1. On expiry of IAR timer if rset state is sby
                              then do not release connection, just restart the
                              the IAS timer. This timer will always be running
                              on sby to avoid restarting it from beginning when
                              sby becomes active.
             sp024.302 rc  1. When generating CC, in the called address fill
                              the same called address as received in incoming
                              CR message earlier and not the calling address of
                              the incoming CR message. This is as per Q.712,
                              2.3, which states, unlike connectionless SCCP,
                              in case of connection-oriented SCCP, called and
                              calling address is related to the direction of
                              connection set-up i.e. independent of the
                              direction the message is going.
                           2. Performing calling party address treatment as per
                              ITU Q.714, section 2.7.5.2
             sp026.302 rc  1. Generate CREF when conn can not be established
                              due to failure in local ref allocation.
                           2. Removed functions spInitConHl, spDelCon and
                              spAddCon. These functions were to maintain conn
                              hash list based on CG_KEY, CD_KEY and SU_KEY and
                              are no longer used.
             sp028.302 rc  1. Generating alarm when LclRef could not be added
                              due to exceeding limit of max connections.
                           2. Generate alarm when conn could not be established
                              due to exceeding the configured conThresh value.
                           3. Freeze slr and free conCb when CR could not
                              be processed.
                           4. Increment/decrement counter for numConn in case
                              of conventional sccp. For FT/HA or DFT/HA zpCb
                              counter is used for numConn.
             sp029.302 rc  1. If peersync is in progress then do not process
                              the expiry of IAS or IAR timers and just restart
                              these timers again.
             sp031.302 cg  1.  check to make sure the slr->cb is not NULL 
             sp032.302 cg  1.  Added field nmbConThresh to genrate alarm 
             sp034.302 rc  1. Free conCb when connection becomes dead.
                           2. Mark connection as dead when lclRef is frozen or
                              when lclRef is freed immediately due to defFrzTmr
                              being disabled.
                           3. Generate RT upd for deletion of ConCb only when
                              slr cb is still there, means freeze time is still
                              running. If defFrzTmr is disabled, then slr would
                              be freed before conCb is freed and that case will
                              result in packing error of ConCb. When SBY sccp
                              receives RT upd for deletion of slr,then if conCb
                              exists then it will also free the conCb.
				 sp035.302 mc  1.  In case of failure in ENCPDU, checking for 
                              data pointer stored ucb to avoid double
                              deallocation of same pointer.						
             sp036.302 mc  1. Correcting the index of cs.
             sp038.302 mc   1. SS_MULTIPLE_PROCS flag added.
             sp040.302 rc  1. In spSendPduErr, free buffer if msg could not be
                              sent.
             sp044.302 sm  1. Initialized the local variables to avoid warnings.
             sp045.302 mc  1. In spResolveAddr replacing selfPc with ptr to 
                              nwCb of incoming network. 
                           2. Passing ptr to outgoing network CB in
                              spResolveAddr.
                           3. replacing nwData with outNwData in spCheckRoute
                              call to find route status in outgoing network.
                           4. initializing the ConCb's cs[]->nwData with
                              incoming and outgoing network CB.
                           5. since we are storing the ptr to network CB
                              for calling/called side in conCb->cs[], 
                              replacing the cb->nwData->selfPc with respective
                              side's network's selfPc.
                           6. Passing correct opc in SntUDatReq.
                           7. nwData moved from conCb to to conCb's cs[].
*********************************************************************91*/
