/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:     sccp - body 2
 
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP Utilities.
  
     File:     cp_bdy2.c
  
     Sid:      cp_bdy2.c@@/main/18_1 - Tue Jan 22 15:15:20 2002
  
     Prg:      fmg
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"       /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


/* local defines */

/*
 * Macro to return the length of a LngAddr
 */
#ifndef SIZEOFLNGADDR
#define SIZEOFLNGADDR(addr) (sizeof(addr->length) + addr->length)
#endif /* SIZEOFLNGADDR */

/* external functions */

/* forward references */
PRIVATE S16 spRemPc ARGS((U8, Dpc *, Buffer *));
PRIVATE Void spSegData ARGS((SpUdCb *, Buffer *, MsgLen, MsgLen, U8));
PRIVATE Void spUiHndlSegData ARGS((SpUdCb *, Buffer *));
PRIVATE Void spLiSegAndSendData ARGS((SpUdCb *, Buffer *));
#ifndef ZP
PRIVATE Bool spGetXUdRef ARGS((SpXUdRef *, SpNwCb *)); 
#endif /* ZP */
PRIVATE Void spLiHndlSegData ARGS((SpUdCb *, Buffer *));
PRIVATE SpXUdCb* spFindXUdCb ARGS((SpUdCb *, Buffer *));
PRIVATE S16 spGetAddrLen ARGS((SpAddr *, Swtch));
PRIVATE S16 spTruncateMsg ARGS((Buffer *, MsgLen));



#ifdef SP_GNP
/* sp045.302 - addition - pass ptr to network Cb */
/* function for calling party address treatment for
 * Generic numbering plan support
 */
PRIVATE S16 spCgAddrTreatment ARGS((SpAddr *, U8, U8, SpNwCb *, SpNwCb **));
#endif /* SP_GNP */

  
/*
 *     support functions
 */

  
/*
*
*       Fun:   spInitRteHl
*
*       Desc:  Initialize Routing Table Hash List
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spInitRteHl
(
SpRteCp *rteCp        /* control point */
)
#else
PUBLIC S16 spInitRteHl(rteCp)
SpRteCp *rteCp;       /* control point */
#endif
{
   TRC2(spInitRteHl)
   rteCp->rCp = &spCb.rteHlCp;

   /* sp026.302 - modification - Default hash function to search RteCb is 
    * replaced with U32Mod function. With the new hash function, hashing will
    * be done on first field Dpc only which is U32 to find the index (bin)
    * and then complete key (dpc and nwId) will be used for matching. This will
    * make hash search very fast and the number of bins can also be increased to
    * support large number of routes. With this approach of using only dpc for
    * hashing, the number of entries per bin will be multiplied by the number of
    * networks besides the normal collasion in hashing. For example if there are
    * two networks configured and same point code exists in both network then
    * the corresponding bin will have at least two entries for each combination
    * of dpc+nwId.
    *
    * Care must be taken when modifying the route Key. As we will be using only
    * the first U32 field of the key to find the bin, the placement of dpc
    * and nwId within this key is very important and so before modifying the key
    * the impact on hashing should be analysed. Also if hash function U32Mod is 
    * modified then its impact should be evaluated.
    */
   RETVALUE(cmHashListInit(rteCp->rCp, RTE_HL_SIZE, 0, TRUE, 
                                        CM_HASH_KEYTYPE_U32MOD,
                                        spCb.spInit.region, 
                                        spCb.spInit.pool));
} /* end of spInitRteHl */

  
/*
*
*       Fun:   spFindRte
*
*       Desc:  Finds a route control block entry
*
*       Ret:   None
*
*       Notes: Hopefully, a good compiler will inline this...
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spFindRte
(
SpRteCp *rteCp,    /* route control point */
SpRteCb **rtep,    /* route control block */
SpRteKey *key,     /* hash key */
U16 idx            /* index, (always zero) */
)
#else
PUBLIC Void spFindRte(rteCp, rtep, key, idx)
SpRteCp *rteCp;    /* route control point */
SpRteCb **rtep;    /* route control block */
SpRteKey *key;     /* hash key */
U16 idx;           /* index, (always zero) */
#endif
{
  
   TRC2(spFindRte);
  
   *rtep = (SpRteCb *)NULLP;
   cmHashListFind(rteCp->rCp, (U8 *)key, (U16)sizeof(key->k1), 
                  (U16)idx, (PTR *)rtep); 
   RETVOID;
} /* end of spFindRte */

  
/*
*
*       Fun:   spAddRte
*
*       Desc:  Adds a route control block entry
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spAddRte
(
SpRteCp *rteCp,    /* route control point */
SpRteCb *rtep      /* route control block */
)
#else
PUBLIC Void spAddRte(rteCp, rtep)
SpRteCp *rteCp;    /* route control point */
SpRteCb *rtep;     /* route control block */
#endif
{
   TRC2(spAddRte);
   cmHashListInsert(rteCp->rCp, (PTR)rtep, (U8 *)&rtep->key.k1,
                                   (U16)sizeof(rtep->key.k1));
   RETVOID;
} /* end of spAddRte */

/* sp045.302 - addition - pass ptr to network CB also */

/*
 *
 * Fun: spMatchAssoCb
 *
 * Desc: This function matches the GT with one of the association in the
 *       association list. Association list is separate for each network.
 *
 *       If none is found NULL is returned.
 *
 * Ret: Pointer to Association Control Block.
 *
 * Notes: none
 *
 * File: cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC SpAssoCb * spMatchAssoCb
(
GlbTi *gt,     /* Global Title */
Swtch sw,       /* Switch - identifies the variant */
SpNwCb *nwCb   /* sp045.302 - addition - ptr to network CB */
)
#else 
PUBLIC SpAssoCb * spMatchAssoCb (gt, sw, nwCb)
GlbTi *gt;     /* Global Title */
Swtch sw;       /* Switch - identifies the variant */
SpNwCb *nwCb;   /* sp045.302 - addition - ptr to network CB */
#endif
{
   S16 i, j;
   U8 adjFrmt;
   
   TRC2 (spMatchAssoCb);

/* sp045.302 - addition - the feature GTT per netnowk is availabe under
 * LSPV2_4 interface version flag.
 */
#ifdef LSPV2_4      

   /* sp045.302 - addition - check if nwCb is null */
   if (!nwCb)
      RETVALUE (NULLP);

   /* sp045.302 - modification - if no association is configured then return */
   if (!nwCb->nmbAsso)
      RETVALUE (NULLP);

   /* sp045.302 - modification - using nmbAsso and curAsso from network CB
   * instead of spCb.
   */
   /* Go thru the nwCb.AssoCb */
   for (j = nwCb->curAsso; 
        i = j % nwCb->nmbAsso, (j - nwCb->curAsso) < nwCb->nmbAsso; j++)
   {
      if (nwCb->assoList[i]->rule.formatPres)
      {
         if (nwCb->assoList[i]->rule.format == gt->format)
         {
               adjFrmt = gt->format;
            switch (adjFrmt)
            {
               case GTFRMT_1:
                  /* sp045.302 - modification - assoList is moved to nwCb */
                  if (nwCb->assoList[i]->rule.gt.f1.oddEvenPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f1.oddEven != 
                          gt->gt.f1.oddEven)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f1.natAddrPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f1.natAddr != 
                          gt->gt.f1.natAddr)
                        break;
                  }
                  nwCb->curAsso = i;
                  RETVALUE (nwCb->assoList[i]); 

               case GTFRMT_2:
                  /* sp045.302 - modification - assoList is moved to nwCb */
                  if (nwCb->assoList[i]->rule.gt.f2.tTypePres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f2.tType !=  
                          gt->gt.f2.tType)
                        break;
                  }
                  nwCb->curAsso = i;
                  RETVALUE (nwCb->assoList[i]); 

               case GTFRMT_3:
                  /* sp045.302 - modification - assoList is moved to nwCb */
                  if (nwCb->assoList[i]->rule.gt.f3.tTypePres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f3.tType !=  
                          gt->gt.f3.tType)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f3.numPlanPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f3.numPlan != 
                          gt->gt.f3.numPlan)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f3.encSchPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f3.encSch != 
                          gt->gt.f3.encSch)
                        break;
                  }
                  nwCb->curAsso = i;
                  RETVALUE (nwCb->assoList[i]); 
          
               case GTFRMT_4:
                  /* sp045.302 - modification - assoList is moved to nwCb */
                  if (nwCb->assoList[i]->rule.gt.f4.tTypePres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f4.tType !=  
                          gt->gt.f4.tType)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f4.numPlanPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f4.numPlan != 
                          gt->gt.f4.numPlan)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f4.encSchPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f4.encSch != 
                          gt->gt.f4.encSch)
                        break;
                  }
                  if (nwCb->assoList[i]->rule.gt.f4.natAddrPres)
                  {
                     if (nwCb->assoList[i]->rule.gt.f4.natAddr != 
                          gt->gt.f4.natAddr)
                        break;
                  }
                  nwCb->curAsso = i;
                  RETVALUE (nwCb->assoList[i]); 

               default :
                  RETVALUE (NULLP);
            }/* switch () */
         } /* (nwCb->assoList[i]->rule.format == gt->format) */
      } /* ( nwCb->assoList[i]->rule.formatPres ) */
      else
      {
         nwCb->curAsso = i;
         /* format is not used. All GTs match to this rule */
         RETVALUE (nwCb->assoList[i]); 
      }
   } /* for () */
#else 
   /* handling if GTT per network is not enabled */
   if (!spCb.nmbAsso)
      RETVALUE (NULLP);
   /* Go thru the spCb.AssoCb */
   for (j = spCb.curAsso; 
        i = j % spCb.nmbAsso, (j - spCb.curAsso) < spCb.nmbAsso; j++)
   {
      if (spCb.assoList[i]->rule.sw != sw)
         continue;
      if (spCb.assoList[i]->rule.formatPres)
      {
         if (spCb.assoList[i]->rule.format == gt->format)
         {
               adjFrmt = gt->format;
            switch (adjFrmt)
            {
               case GTFRMT_1:
                  if (spCb.assoList[i]->rule.gt.f1.oddEvenPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f1.oddEven != 
                         gt->gt.f1.oddEven)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f1.natAddrPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f1.natAddr != 
                         gt->gt.f1.natAddr)
                        break;
                  }
                  spCb.curAsso = i;
                  RETVALUE (spCb.assoList[i]); 

               case GTFRMT_2:
                  if (spCb.assoList[i]->rule.gt.f2.tTypePres)
                  {
                     if (spCb.assoList[i]->rule.gt.f2.tType !=  
                         gt->gt.f2.tType)
                        break;
                  }
                  spCb.curAsso = i;
                  RETVALUE (spCb.assoList[i]); 

               case GTFRMT_3:
                  if (spCb.assoList[i]->rule.gt.f3.tTypePres)
                  {
                     if (spCb.assoList[i]->rule.gt.f3.tType !=  
                         gt->gt.f3.tType)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f3.numPlanPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f3.numPlan != 
                         gt->gt.f3.numPlan)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f3.encSchPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f3.encSch != 
                         gt->gt.f3.encSch)
                        break;
                  }
                  spCb.curAsso = i;
                  RETVALUE (spCb.assoList[i]); 
          
               case GTFRMT_4:
                  if (spCb.assoList[i]->rule.gt.f4.tTypePres)
                  {
                     if (spCb.assoList[i]->rule.gt.f4.tType !=  
                         gt->gt.f4.tType)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f4.numPlanPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f4.numPlan != 
                         gt->gt.f4.numPlan)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f4.encSchPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f4.encSch != 
                         gt->gt.f4.encSch)
                        break;
                  }
                  if (spCb.assoList[i]->rule.gt.f4.natAddrPres)
                  {
                     if (spCb.assoList[i]->rule.gt.f4.natAddr != 
                         gt->gt.f4.natAddr)
                        break;
                  }
                  spCb.curAsso = i;
                  RETVALUE (spCb.assoList[i]); 
               
               default :
                  RETVALUE (NULLP);
            }/* switch () */
         } /* if () */
      } /* if () */
      else
      {
         spCb.curAsso = i;
         /* format is not used. All GTs match to this rule */
         RETVALUE (spCb.assoList[i]); 
      }
   } /* for () */

#endif 
   /* No matching association found */
   RETVALUE (NULLP);
}

/* sp045.302 - addition - passing ptr to network CB so that search can be
 * per network.
 */

/*
 *
 * Fun: spAssoForRule
 *
 * Desc: This function checks if the rule has already been
 *       configured.
 *
 * Ret: ROK - if there is a exact matchign entry.
 *      RFAILED - if there is no matching entry
 *      ROKDUP - the incoming rule overlaps with a configured entry.
 * Notes: none.
 *
 * File: cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spAssoForRule
(
SpRule *rule,  /* GT Rule */
U16 *indx,     /* index to assoList */
SpNwCb *nwCb   /* sp045.302 - addition - ptr to network Cb */
)
#else 
PUBLIC S16 spAssoForRule (rule, indx, nwCb)
SpRule *rule; /* GT Rule */
U16 *indx;    /* index to assoList */
SpNwCb *nwCb; /* sp045.302 - addition - ptr to network Cb */
#endif
{
   S16 i;
   S16 oFlag; /* Overlap Flag - rules overlap */
   S16 dFlag; /* different flag */
   U8 adjFrmt;
   
   TRC2 (spAssoForRule);

/* sp045.302 - addition - the feature GTT per netnowk is availabe under
 * LSPV2_4 interface version flag.
 */
#ifdef LSPV2_4      
   /* sp045.302 - addition - check for NULL nwCb */
   if (nwCb == NULLP)
      RETVALUE (NULLP);

   /*sp045.302 - modification - nmbAsso is moved to nwCb */
   /* Go thru the nwCb.AssoCb */
   for (i = 0; i < nwCb->nmbAsso; i++)
   {
      /* sp045.302 - deletion - check for variant is deleted */

      /* 
       * The FIELDS_CMP macro makes the dFlag as TRUE if both the present 
       * flags are TRUE and the values are different.
       * This macro makes the oFlag as TRUE if one present flag does not 
       * match the other one. This basically means that the entries are 
       * overlapping.
       * If both the flags are FALSE it means that it is an exact match
       * (either both flags are FALSE or both flags are TRUE and the values
       * are also equal.
       * The way to go about checking the fields for a particular type of GT
       * is that you call this macro for all teh fields and than check the 
       * value of the flags at the end. If dFlag is TRUE it means that 
       * there is one diff field and thus the  rules are unique. If oFlag is
       * TRUE than the rules overlap (and config shouldnt be allowed). If both
       * are FLASE than the rules are equal (and config shouldnt be allowed)
       */
      dFlag = FALSE;
      oFlag = FALSE;
      /*sp045.302 - modificaiton - assoList is moved to nwCb */
      FIELDS_CMP (nwCb->assoList[i]->rule.formatPres,
                  nwCb->assoList[i]->rule.format,
                  rule->formatPres,
                  rule->format,
                  oFlag, dFlag);

      if (dFlag == TRUE)
         continue;
      else
         if (oFlag == TRUE)
         {
            RETVALUE (ROKDUP);
         }

      /* If we come here the formats are same */
      if (rule->formatPres == FALSE)
      {
         *indx = i;
         RETVALUE (ROK);
      }
     
      /* Keep looking */
         adjFrmt = rule->format;
      switch (adjFrmt)
      {
         case GTFRMT_1:
            oFlag = FALSE;
            dFlag = FALSE;
            /*sp045.302 - modificaiton - assoList is moved to nwCb */
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f1.oddEvenPres,
                       nwCb->assoList[i]->rule.gt.f1.oddEven,
                       rule->gt.f1.oddEvenPres,
                       rule->gt.f1.oddEven,
                       oFlag, dFlag);
            /*sp045.302 - modificaiton - assoList is moved to nwCb */
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f1.natAddrPres,
                       nwCb->assoList[i]->rule.gt.f1.natAddr,
                       rule->gt.f1.natAddrPres,
                       rule->gt.f1.natAddr,
                       oFlag, dFlag);
            
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_2:
            oFlag = FALSE;
            dFlag = FALSE;
            /*sp045.302 - modificaiton - assoList is moved to nwCb */
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f2.tTypePres,
                       nwCb->assoList[i]->rule.gt.f2.tType,
                       rule->gt.f2.tTypePres,
                       rule->gt.f2.tType,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_3:
            oFlag = FALSE;
            dFlag = FALSE;
            /*sp045.302 - modificaiton - assoList is moved to nwCb */
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f3.tTypePres,
                       nwCb->assoList[i]->rule.gt.f3.tType,
                       rule->gt.f3.tTypePres,
                       rule->gt.f3.tType,
                       oFlag, dFlag);
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f3.numPlanPres,
                       nwCb->assoList[i]->rule.gt.f3.numPlan,
                       rule->gt.f3.numPlanPres,
                       rule->gt.f3.numPlan,
                       oFlag, dFlag);
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f3.encSchPres,
                       nwCb->assoList[i]->rule.gt.f3.encSch,
                       rule->gt.f3.encSchPres,
                       rule->gt.f3.encSch,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_4:
            oFlag = FALSE;
            dFlag = FALSE;
            /*sp045.302 - modificaiton - assoList is moved to nwCb */
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f4.tTypePres,
                       nwCb->assoList[i]->rule.gt.f4.tType,
                       rule->gt.f4.tTypePres,
                       rule->gt.f4.tType,
                       oFlag, dFlag);
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f4.numPlanPres,
                       nwCb->assoList[i]->rule.gt.f4.numPlan,
                       rule->gt.f4.numPlanPres,
                       rule->gt.f4.numPlan,
                       oFlag, dFlag);
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f4.encSchPres,
                       nwCb->assoList[i]->rule.gt.f4.encSch,
                       rule->gt.f4.encSchPres,
                       rule->gt.f4.encSch,
                       oFlag, dFlag);
            FIELDS_CMP(nwCb->assoList[i]->rule.gt.f4.natAddrPres,
                       nwCb->assoList[i]->rule.gt.f4.natAddr,
                       rule->gt.f4.natAddrPres,
                       rule->gt.f4.natAddr,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         default :
            RETVALUE (RFAILED);
      }/* switch () */
   } /* for () */
#else /* LSPV2_4 */
   /* sp045.302 - handling, if GTT per network is not enabled */
   /* Go thru the spCb.AssoCb */
   for (i = 0; i < spCb.nmbAsso; i++)
   {
      if (spCb.assoList[i]->rule.sw != rule->sw)
         continue;
      /* Since format is 0 we cannot configure any other rule */

      /* 
       * The FIELDS_CMP macro makes the dFlag as TRUE if both the present 
       * flags are TRUE and the values are different.
       * This macro makes the oFlag as TRUE if one present flag does not 
       * match the other one. This basically means that the entries are 
       * overlapping.
       * If both the flags are FALSE it means that it is an exact match
       * (either both flags are FALSE or both flags are TRUE and the values
       * are also equal.
       * The way to go about checking the fields for a particular type of GT
       * is that you call this macro for all teh fields and than check the 
       * value of the flags at the end. If dFlag is TRUE it means that 
       * there is one diff field and thus the  rules are unique. If oFlag is
       * TRUE than the rules overlap (and config shouldnt be allowed). If both
       * are FLASE than the rules are equal (and config shouldnt be allowed)
       */
      dFlag = FALSE;
      oFlag = FALSE;
      FIELDS_CMP (spCb.assoList[i]->rule.formatPres,
                  spCb.assoList[i]->rule.format,
                  rule->formatPres,
                  rule->format,
                  oFlag, dFlag);

      if (dFlag == TRUE)
         continue;
      else
         if (oFlag == TRUE)
         {
            RETVALUE (ROKDUP);
         }

      /* If we come here the formats are same */
      if (rule->formatPres == FALSE)
      {
         *indx = i;
         RETVALUE (ROK);
      }
     
      /* Keep looking */
         adjFrmt = rule->format;
      switch (adjFrmt)
      {
         case GTFRMT_1:
            oFlag = FALSE;
            dFlag = FALSE;
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f1.oddEvenPres,
                       spCb.assoList[i]->rule.gt.f1.oddEven,
                       rule->gt.f1.oddEvenPres,
                       rule->gt.f1.oddEven,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f1.natAddrPres,
                       spCb.assoList[i]->rule.gt.f1.natAddr,
                       rule->gt.f1.natAddrPres,
                       rule->gt.f1.natAddr,
                       oFlag, dFlag);
            
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_2:
            oFlag = FALSE;
            dFlag = FALSE;
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f2.tTypePres,
                       spCb.assoList[i]->rule.gt.f2.tType,
                       rule->gt.f2.tTypePres,
                       rule->gt.f2.tType,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_3:
            oFlag = FALSE;
            dFlag = FALSE;
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f3.tTypePres,
                       spCb.assoList[i]->rule.gt.f3.tType,
                       rule->gt.f3.tTypePres,
                       rule->gt.f3.tType,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f3.numPlanPres,
                       spCb.assoList[i]->rule.gt.f3.numPlan,
                       rule->gt.f3.numPlanPres,
                       rule->gt.f3.numPlan,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f3.encSchPres,
                       spCb.assoList[i]->rule.gt.f3.encSch,
                       rule->gt.f3.encSchPres,
                       rule->gt.f3.encSch,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                        RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         case GTFRMT_4:
            oFlag = FALSE;
            dFlag = FALSE;
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f4.tTypePres,
                       spCb.assoList[i]->rule.gt.f4.tType,
                       rule->gt.f4.tTypePres,
                       rule->gt.f4.tType,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f4.numPlanPres,
                       spCb.assoList[i]->rule.gt.f4.numPlan,
                       rule->gt.f4.numPlanPres,
                       rule->gt.f4.numPlan,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f4.encSchPres,
                       spCb.assoList[i]->rule.gt.f4.encSch,
                       rule->gt.f4.encSchPres,
                       rule->gt.f4.encSch,
                       oFlag, dFlag);
            FIELDS_CMP(spCb.assoList[i]->rule.gt.f4.natAddrPres,
                       spCb.assoList[i]->rule.gt.f4.natAddr,
                       rule->gt.f4.natAddrPres,
                       rule->gt.f4.natAddr,
                       oFlag, dFlag);
            if (dFlag == TRUE)
               continue;    /* The entries are different */
            else
               if (oFlag == TRUE) /* The entries overlap */
               {
                  RETVALUE (ROKDUP);
               }
               else /* both flags are FALSE - we got an exact match */
               {
                  *indx = i;
                  RETVALUE (ROK);
               }
            break;
            
         default :
            RETVALUE (RFAILED);
      }/* switch () */
   } /* for () */
#endif  
   /* No matching rule found */
   RETVALUE (RFAILED);
} /* AssoForRule */

/* sp045.302 - modification - replacing selfPc with ptr to  nwCb of incoming
 * network and ptr of outgoing network CB to retrun correct network CB.
 */

/* 
 *
 *       Fun:   spResolveAddr
 *
 *       Desc:  Resolve Incoming Addresse.
 *
 *       Ret:   SP_OK    -   Operation successful. Address resolved.
 *              SP_ERROR -   Error in resolvoing address.
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spResolveAddr
(
SpAddr *inAddr,          /* incoming address */
U8 pClass,               /* sccp class */
U8 *numEntity,           /* buffer to return number of outgoing sccp entity */
U8 *nextEntity,          /* buffer to return next sccp entity to be selected */
U8 *mode,                /* buffer to return mode of operation of entities */
SpAddr *outAddr,         /* outgoing sccp entities */
U8 *noCplng,             /* buffer to return flag for coupling of connection */
SpNwCb *nwCb,            /* sp045.302 - modification - ptr to network Cb of
                          * incoming network
                          */
SpNwCb **outNwCb         /* sp045.302 - addition - ptr to network Cb of
                          * outgoing network.
                          */
)
#else
PUBLIC S16 spResolveAddr(inAddr, pClass, numEntity, nextEntity, mode, outAddr,
                         noCplng, nwCb, outNwCb)
SpAddr *inAddr;          /* incoming address */
U8 pClass;               /* sccp class */
U8 *numEntity;           /* buffer to return number of outgoing sccp entity */
U8 *nextEntity;          /* buffer to return next sccp entity to be selected */
U8 *mode;                /* buffer to return mode of operation of entities */
SpAddr *outAddr;         /* outgoing sccp entities */
U8 *noCplng;             /* buffer to return flag for coupling of connection */
SpNwCb *nwCb;            /* sp045.302 - modification - ptr to network Cb of
                          * incoming network
                          */
SpNwCb **outNwCb         /* sp045.302 - addition - ptr to network Cb of
                          * outgoing network.
                          */
#endif
{
   U8 i;                 /* loop counter */

   TRC2(spResolveAddr);

   /* if pc in the inAddr is not self pc then do not resolve address.
    * Retrun ok. Message will be passed to the pc present in inAddr
    */
   /* sp045.302 - modification - get selfPc  from nwCb */
   if (inAddr->pcInd && (inAddr->pc != nwCb->selfPc))
   {
      cmCopySpAddr(inAddr, &outAddr[0]);
      *numEntity = 1;
      *nextEntity = 0;
      *mode = DOMINANT;
      *noCplng = FALSE;
      RETVALUE(SP_OK);
   }

   /* Validate the incoming address */
   if (inAddr->rtgInd == RTE_GT &&
       ((inAddr->gt.format == GTFRMT_0) || (inAddr->gt.format > GTFRMT_4)))
      RETVALUE(SP_ERROR);

   if ((inAddr->rtgInd == RTE_SSN) && (!inAddr->ssnInd))
      RETVALUE(SP_ERROR);

   /* Find out if GTT is required */
   if (inAddr->rtgInd == RTE_GT)
   {
      SpAssoCb *assoCb;
      U16 ret;

      /* update statistics counter for GT translations */
      spCb.sts.gttReq++;

      /* sp045.302 - addition - pass ptr to network CB */
      assoCb = spMatchAssoCb(&inAddr->gt, inAddr->sw, nwCb);
      if (assoCb == NULLP)
         RETVALUE(SP_ERROR);
            
      /* sp045.302 - modification - replacing selfPc with nwCb 
       * and pass ptr to outgoing network 
       */
      /* Call the relevant translation function of the Rule */
      ret = assoCb->funcs->gttTrans(assoCb, inAddr, pClass, mode, numEntity,
                                    nextEntity, outAddr, noCplng, nwCb, 
                                    outNwCb);
      if (ret != ROK)
         RETVALUE(SP_ERROR);

#ifdef CMSS7_SPHDROPT
      /* spResolveAddr is always called when a GT is part of the cdAddr
       * Thus it is the best place to set the spPcPreserve flag.
       * We will check the flag value wherever we are encoding the pdu with
       * cdAddr. The messages whose encoding will get affected are : 
       * CR, CC, CREF, UDT, UDTS, XUDT, XUDTS, 
       * The translation function destroys the pres flag so we have to
       * initialise it after it.
       */
      for (i = 0; i < *numEntity; i++)
         outAddr[i].spHdrOpt = inAddr->spHdrOpt;
#endif /* CMSS7_SPHDROPT */
   }
   else 
   {
      if (inAddr->rtgInd == RTE_SSN)
      {
         cmCopySpAddr(inAddr, &outAddr[0]);
         *numEntity = 1;
         *nextEntity = 0;
         *mode = DOMINANT;
         *noCplng = FALSE;
      }
      else
         RETVALUE(SP_ERROR);
   }
   
   RETVALUE(SP_OK);        
} /* spResolveAddr */

/* sp033.302 - modification - function modified so as to return correct rCb */
  
/*
*
*       Fun:   spCheckDpc
*
*       Desc:  Check accessibility of destination point code. 
*
*       Ret:   SP_OK - Operation successful. Destination is remote pc and
*                      is accessible.
*              SP_ERROR - Operation failed. Destination is not accessible.
*
*       Notes: None.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spCheckDpc
(
SpRteCb **rCb,        /* sp033.302 -modification - return route cb */
SpAddr *rAddr,        /* return address */
LnkSel sls,           /* signalling link selection */
Bool sequence         /* flag to indicate sequencing required */
)
#else
PUBLIC S16 spCheckDpc(rCb, rAddr, sls, sequence)
SpRteCb **rCb;        /* sp033.302 -modification - return route cb */
SpAddr *rAddr;        /* return address */
LnkSel sls;           /* signalling link selection */
Bool sequence;        /* flag to indicate sequencing required */
#endif
{
   SpRteCb *firstAccRte;        /* first accessible route */
   SpRteCb *bkupRcb;            /* backup route */
   SpRteKey rKey;               /* route key */
   U16 i;                       /* loop counter */


   TRC2(spCheckDpc);

#ifndef SS7_BELL05
   UNUSED(sls);
#endif
   /* initialize first accessible route and selected route */
   firstAccRte = NULLP;

   /* check accessibility of point code specified in the route */
   if ((*rCb)->status & SP_ONLINE)
   {
      /* if mode is dominant or no any backup then return ok. In 
       * this case the pc specified in route will be used as 
       * destination. Otherwise in case mode is other than dominant or
       * there are backups then assign primary route as firstaccessible
       * route and then pc will be checked for congested status.
       */
      if (((*rCb)->replicatedMode == DOMINANT) || ((*rCb)->nmbBpc == 0))
         RETVALUE(SP_OK);
      else
      {
            firstAccRte = *rCb;  /* first accessible route */
      }
   }
   else
   {
      if ((*rCb)->nmbBpc == 0)
         RETVALUE(SP_ERROR);
   }
   
   if (((*rCb)->replicatedMode == DOMINANT) || 
       (((*rCb)->replicatedMode == DOMINANT_ALTERNATE) &&
        (sequence == TRUE)))
   {
      /* return first accessible route if available else find
       * accessible route from among backups
       */
      if (firstAccRte != (SpRteCb *) NULLP)
      {
         rAddr->pc = firstAccRte->dpc;
         *rCb = firstAccRte;
         RETVALUE(SP_OK);
      }
      else
      {
         for (i = 0; i < (*rCb)->nmbBpc; i++)
         {
            /* form route key to search route in list */
            rKey.k1.dpc = (*rCb)->bpcList[i].bpc;
            rKey.k1.nwId = (*rCb)->nSap->nwData->nwId;
 
            /* find route towards backup at index i */
            spFindRte(&spCb.rteCp, &bkupRcb, &rKey, 0);
 
            if (bkupRcb == (SpRteCb *) NULLP)
            {
               /* route not found, check next backup */
               SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                      "spCheckDpc: backup rte not found, checking next backup\n"));
               continue;
            }
            if (bkupRcb->status & SP_ONLINE)
            {
               /* backup is returned */
               rAddr->pc = bkupRcb->dpc;
               *rCb = bkupRcb;
               RETVALUE(SP_OK);
            }
         } /* for (i = 0; i < (*rCb)->nmbBpc; i++) */
      } /* else - if (firstAccRte != NULLP) */
   } /* mode is dominant OR dominant alternate with sequencing */

   RETVALUE(SP_ERROR);
} /* spCheckDpc */

/* sp033.302 - modification - function modified so as to return correct rCb */
  
/*
*
*       Fun:   spCheckSsn
*
*       Desc:  Check accessibility of destination point code. 
*
*       Ret:   SP_OK     - Operation successful. Destination is remote SSN and
*                          is accessible.
*              SP_LOCAL  - Operation successful and SSN is local sccp user.
*              SP_SSFAIL - Operation failed. Destination SSN is not
*                          accessible.
*              SP_ERROR  - Operation failed. Destination is not accessible.
*
*       Notes: None.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spCheckSsn
(
SpRteCb **rCb,        /* sp033.302 - modification - return route cb */
SpAddr *rAddr,        /* return address */
LnkSel sls,           /* signalling link selection */
Bool sequence,        /* flag to indicate sequencing required */
Dpc spc,              /* self point code */
SpSapCb **cdSap       /* called sap */
)
#else
PUBLIC S16 spCheckSsn(rCb, rAddr, sls, sequence, spc, cdSap)
SpRteCb **rCb;        /* sp033.302 - modification - return route cb */
SpAddr *rAddr;        /* return address */
LnkSel sls;           /* signalling link selection */
Bool sequence;        /* flag to indicate sequencing required */
Dpc spc;              /* self point code */
SpSapCb **cdSap;      /* called sap */
#endif
{
   SpRteCb *firstAccRte;        /* first accessible route */
   SpRteCb *bkupRcb;            /* backup route */
   SpRteKey rKey;               /* route key */
   SpSapCb *sap;                /* upper sap */
   U16 i;                       /* loop counter */
   U16 j;                       /* loop counter */
   U16 k;                       /* loop counter */

   TRC2(spCheckSsn);
   
#ifndef SS7_BELL05
   UNUSED(sls);
#endif

   /* initialize first accessible route and selected route
    * as null and foiundRoute as false
    */
   firstAccRte = NULLP;

   /* find matching ssn on route */
   for (i = 0; i < (*rCb)->nmbSsns; i++)
   {
      if ((*rCb)->ssnList[i].ssn == rAddr->ssn)
         break;
   }
   if (i == (*rCb)->nmbSsns)  /* no matching ssn found */
      RETVALUE(SP_ERROR);
   
   /* if ssn is accessible and either mode of operation of backups
    * of ssn is dominant or number of backups of ssn is zero, then
    * return ok. In this case ssn and dpc in the primary route will
    * be used as destination, else mark primary route as first
    * accessible route to further check congestion status of dpc
    */
   if ((*rCb)->ssnList[i].status & SS_ACC)
   {
      if (((*rCb)->ssnList[i].replicatedMode == DOMINANT) ||
          ((*rCb)->ssnList[i].nmbBpc == 0))
         RETVALUE(SP_OK);
      else
      {
            firstAccRte = *rCb;
      }
   }
   else
   {
      if ((*rCb)->ssnList[i].nmbBpc == 0)
      {
         /* sp027.302 - addition - determine proper cause of failure.
          * if ssn is inaccessible due to route being down, then return
          * point code failed otherwise return ssn failed.
          */
         if (!((*rCb)->status & SP_ONLINE))
            RETVALUE(SP_SPFAIL);
         else
            RETVALUE(SP_SSFAIL);
      }
   }
            if (((*rCb)->ssnList[i].replicatedMode == DOMINANT) ||
                (((*rCb)->ssnList[i].replicatedMode == DOMINANT_ALTERNATE) &&
                 (sequence == TRUE)))
            {
               if (firstAccRte != (SpRteCb *) NULLP)
               {
                  rAddr->pc = firstAccRte->dpc;
                  *rCb = firstAccRte;
                  RETVALUE(SP_OK);
               }
               else
               {
                  for (j = 0; j < (*rCb)->ssnList[i].nmbBpc; j++)
                  {
                     /* check if backup pc is self */
                     if ((*rCb)->ssnList[i].bpcList[j].bpc == spc)
                     {
                        /* find upper sap and check availability */
                        sap = spFindUpperSap((*rCb)->nSap->nwData->nwId,
                                             (*rCb)->ssnList[i].ssn);
                        if ((sap != (SpSapCb *) NULLP) &&
                            (!(sap->status & SP_PROH)))
                        {
                           rAddr->pc = spc;
                           *cdSap = sap;
                           RETVALUE(SP_LOCAL);
                        }
                        else
                        {
                           /* check next backup of ssn */
                           /* sp045.302 - modification - network id also printed */
                           SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                                  "spCheckSsn: ssn(%x),nw(%x) sap inaccessible,\
                                  checking backup\n", 
                                  (*rCb)->ssnList[i].ssn,
                                  (*rCb)->nSap->nwData->nwId));
                           continue;
                        }
                     }
                     else
                     {
                        /* form the route key to search route in hash list */
                        rKey.k1.dpc = (*rCb)->ssnList[i].bpcList[j].bpc;
                        rKey.k1.nwId = (*rCb)->nSap->nwData->nwId;

                        /* find route towards backup at index j */
                        spFindRte(&spCb.rteCp, &bkupRcb, &rKey, 0);

                        if (bkupRcb == (SpRteCb *) NULLP)
                        {
                           /* sp045.302 - modification - network id also printed */
                           /* route not found, check next backup */
                           SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                                  "spCheckSsn: ssn(%x), nw(%x) route not found,\
                                  checking next backup\n",
                                  (*rCb)->ssnList[i].ssn,
                                  (*rCb)->nSap->nwData->nwId));
                           continue;
                        }

                        /* check whether ssn is present on bkupRcb */
                        for (k = 0; k < bkupRcb->nmbSsns; k++)
                        {
                           if (bkupRcb->ssnList[k].ssn == (*rCb)->ssnList[i].ssn)
                              break;
                        }

                        if (k == bkupRcb->nmbSsns)
                        {
                           /* sp045.302 - modification - network id also printed */
                           /* ssn not found, check next backup */
                           SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                                  "spCheckSsn: ssn(%x), nw(%x)not found on\
                                  backup, checking next backup\n",
                                  (*rCb)->ssnList[i].ssn,
                                  (*rCb)->nSap->nwData->nwId));
                           continue;
                        }

                        /* check accessibility of backup ssn */
                        /* sp010.302 - Changed the SSN list index */
                        if (bkupRcb->ssnList[k].status & SS_ACC)
                        {
                           /* return backup */
                           rAddr->pc = bkupRcb->dpc;
                           *rCb = bkupRcb;
                           RETVALUE(SP_OK);
                        }
                     } /* else - backup of ssn is not self pc */
                  } /* for (j = 0; j < (*rCb)->ssnList[i].nmbBpc; j++) */
               } /* else - if (firstAccRte != NULLP) */
            } /* end mode is dominant OR dominant alternate with sequence */

   /* ssn is not accessible */
   /* sp027.302 - addition - determine proper cause of failure.
    * if ssn is inaccessible due to route being down, then return
    * point code failed otherwise return ssn failed.
    */
   if (!((*rCb)->status & SP_ONLINE))
      RETVALUE(SP_SPFAIL);
   else
      RETVALUE(SP_SSFAIL);
} /* spCheckSsn */


/*
*
*       Fun:   spCheckRoute
*
*       Desc:  Check routing validity on a called address.
*
*       Ret:   SP_OK - accessible
*              SP_LOCAL - accessible local subsystem
*              SP_SSFAIL - subsystem inaccessible
*              SP_SPFAIL - signalling point inaccessible
*              SP_ERROR - error
*              SP_UNEQUIP - upper user is unequipped
*
*       Notes: None.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spCheckRoute
(
SpNwCb   *nwData,      /* network data */ 
SpAddr   *rAddr,       /* return address */
LnkSel   sls,          /* signalling link selection */
U8       pClass,        /* sccp class of service */
SpRteCb  **rCb,        /* return route control block */
U8 *flag,              /* flag indicating backup routing is being done */
SpSapCb  **cdSap,      /* called sap */
U8 direction           /* direction of data flow from upper/lower */
)
#else
PUBLIC S16 spCheckRoute(nwData, rAddr, sls, pClass, rCb, flag, cdSap, direction)
SpNwCb   *nwData;      /* network data */ 
SpAddr   *rAddr;       /* return address */
LnkSel   sls;          /* signalling link selection */
U8       pClass;        /* sccp class of service */
SpRteCb  **rCb;        /* return route control block */
U8 *flag;              /* flag indicating backup routing is being done */
SpSapCb  **cdSap;      /* called sap */
U8 direction;          /* direction of data flow from upper/lower */
#endif
{
   REG1 U8 i;         /* counter  */
   REG1 U8 j;         /* counter  */
   SpRteKey rKey;     /* route key */
   S16 ret;           /* return value */
   Bool sequence;     /* flag to indicate sequencing */
  
   TRC2(spCheckRoute);
  
   /* sp045.302 - modification - network id also printed */
   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spCheckRoute : pc (%lx) : nw (%lx)\n", rAddr->pc, nwData->nwId));

   /* initialize route control block and flag */
   *rCb = NULLP;
   *flag = 0;

   if (pClass == PCLASS0)
      sequence = FALSE;    /* no sequencing of message is required */
   else
      sequence = TRUE;     /* sequencing of message is required */
      
   /* handle local routes */
   if ((rAddr->pc == nwData->selfPc) || !rAddr->pcInd)
   {
      /* update global statistics for messages received for local ssn */
      spCb.sts.msgLoc++;

      /* find upper sap */
      *cdSap = spFindUpperSap(nwData->nwId, rAddr->ssn);
      if (*cdSap == (SpSapCb *) NULLP)
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                "SCCP - Route: Sap not found (nw %d) (ssn %d)\n", nwData->nwId,
                rAddr->ssn));
         RETVALUE(SP_UNEQUIP);
      }

      /* check upper sap is not prohibited */
      if (!((*cdSap)->status & SP_PROH))
      {
         /* upper sap is accessible, return local */
         *flag = 0;
         RETVALUE(SP_LOCAL);
      }
      else
      {
         /* upper sap prohibited. If data request is from upper user,
          * then return ssfail else if data is received from lower
          * layer then search backups of upper sap for availability
          */
         if (direction == FROM_UPPER)
            RETVALUE(SP_SSFAIL);
         else
         {
            /* find backup of upper sap */
            for (i = 0; i < (*cdSap)->nmbBpc; i++)
            {
               if ((*cdSap)->bpcList[i].bpc == nwData->selfPc)
               {
                  /* sp030.302 - addition  - debug print */
                  /* sp045.302 - modification - network id also printed */
                  /* its an error case */
                  SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                            "SCCP - Backup PC is same as Self PC %#lx\
                            (nw %#lx) \n" , rAddr->pc, nwData->nwId));
                  RETVALUE(SP_ERROR);
               }
               else
               {
                  /* form the route key for searching in list */
                  rKey.k1.dpc = (*cdSap)->bpcList[i].bpc; 
                  rKey.k1.nwId = nwData->nwId; 

                  /* find route */
                  spFindRte(&spCb.rteCp, rCb, &rKey, 0);

                  if (*rCb == (SpRteCb *) NULLP)
                  {
                     /* route not found */
                     /* sp045.302 - modification - network id also printed */
                     SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                            "SCCP - Routing CB not found %#lx (nw %#lx) \n", 
                            rAddr->pc, nwData->nwId));
                     RETVALUE(SP_ERROR);
                  }

                  /* check ssn status on bpc */
                  for (j = 0; j < (*rCb)->nmbSsns; j++)
                  {
                     if ((*rCb)->ssnList[j].ssn == rAddr->ssn)
                        if ((*rCb)->ssnList[i].status & SS_ACC)
                        {
                           rAddr->pc = (*rCb)->dpc;
                           /* set flag to indicate backup routing */
                           *flag |= SP_BRT;
                           RETVALUE(SP_OK);
                        }
                  } /* for (j = 0; j < rCb->nmbSsns; j++) */
               } /* else-if (...bpc == nwData->selfPc) */
            } /* for (i = 0; i < sap->nmbBpc; i++) */
            if (i == (*cdSap)->nmbBpc)
            {  
               /* backup of upper sap not found, return failure */
               RETVALUE(SP_SSFAIL);
            }
            RETVALUE(SP_OK);
         } /* direction is from lower layer */
      } /* else upper sap is prohibited */
   } /* if ((rAddr->pc == nwData->selfPc) || !rAddr->pcInd) */
   else  /* dpc is not self */
   {
      /* form the route key for searching in list */
      rKey.k1.dpc = rAddr->pc; 
      rKey.k1.nwId = nwData->nwId; 

      /* find route */
      spFindRte(&spCb.rteCp, rCb, &rKey, 0);

      if (*rCb == (SpRteCb *) NULLP)
      {
         /* sp045.302 - modification - network id also printed */
         /* route not found */
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                "SCCP - Routing CB not found %#lx (nw %#lx)\n",
                rAddr->pc, nwData->nwId));
         RETVALUE(SP_ERROR);
      }

      /* check whether route on GT OR ssn is sccp mngt */
      if (!rAddr->ssnInd || (rAddr->rtgInd == RTE_GT) ||
          (rAddr->ssnInd && (rAddr->ssn == SS_SCCPMNGT)))
      {
         /* sp033.302 - modification - ptr to route Cb returned */
         ret = spCheckDpc(rCb, rAddr, sls, sequence);
         if (ret == SP_ERROR)
            RETVALUE(SP_SPFAIL);

         /* check if spCheckDpc has selected self-dpc among backups
          * this should never happen, though
          */
         if (rAddr->pc == nwData->selfPc)
         {
            /* sp045.302 - modification - network id also printed */
            /* sp030.302 - addition  - debug print */
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, 
                "SCCP - selected backup is same as self-dpc %#lx (nw %#lx) \n", 
                rAddr->pc, nwData->nwId));
            RETVALUE(SP_ERROR);
         }
         else
            RETVALUE(ret);
      } /* if route on GT */
      else
      {
         /* route on dpc + ssn */
         /* sp033.302 - modification - ptr to route Cb returned */
         ret = spCheckSsn(rCb, rAddr, sls, sequence, nwData->selfPc, cdSap);
         RETVALUE(ret);
      } /* else route on dpc+ssn */
   } /* else - dpc is not self */
} /* spCheckRoute */

  
/*
*
*       Fun:   spTruncateMsg
*
*       Desc:  Truncates the message to the required length
*
*       Ret:   Buffer
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 spTruncateMsg
(
Buffer *mBuf,        /* the actual data */
MsgLen len           /* length */
)
#else
PRIVATE S16 spTruncateMsg(mBuf, len)
Buffer *mBuf;        /* the actual data */
MsgLen len;          /* length */
#endif
{
   S16 ret;
   MsgLen mlen;
   Data dump[MAXUDATSIZE * MAXNUMSEG];

   /* Find the current length */
   ret = SFndLenMsg(mBuf, &mlen);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP064, (ErrVal) ret,
                 "SFndLenMsg failed - Buffer = NULLP");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   
   /* Check if remove required */
   if (mlen <= len)
      RETVALUE(ROK);
 
   /* Remove the extra bytes */
   SRemPstMsgMult (dump, (MsgLen) (mlen - len), mBuf);
   
   RETVALUE(ROK);
}


  
/*
*
*       Fun:   spEncCLMsg
*
*       Desc:  Encode a connectionless message
*
*       Ret:   Buffer
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Buffer *spEncCLMsg
(
U8 mType,            /* message type */
SpUdCb *ucb,         /* unit data control block */
Buffer **data        /* the actual data */
)
#else
PUBLIC Buffer *spEncCLMsg(mType, ucb, data)
U8 mType;            /* message type */
SpUdCb *ucb;         /* unit data control block */
Buffer **data;       /* the actual data */
#endif
{
   Buffer *mBuf;     /* message buffer */
   S16 ret;          /* return */

   TRC2(spEncCLMsg)

   /* encode message based on type */
   switch (mType)
   {
      case M_UNITDATA:
      {
         SpUnitData ud;

         /* we build our sccp message here...
          *
          * mos packs everything backwards, so we will too.
          *
          * we pass the address of the mbuf pointer because we
          * will be replacing it with our newly constructed message.
          */
      
         ud.pClass.eh.pres = PRSNT_NODEF;
         ud.pClass.pClass.pres = PRSNT_NODEF;
         ud.pClass.pClass.val = ucb->ud->qos.pClass;
         ud.pClass.retOpt.pres = PRSNT_NODEF;
         ud.pClass.retOpt.val = ucb->ud->qos.retOpt;
      
         ud.cdAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cdAddr, &ud.cdAddr.spAddr);
         ud.cgAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cgAddr, &ud.cgAddr.spAddr);
      
         ud.data.eh.pres = PRSNT_NODEF;
         ud.data.data.pres = PRSNT_NODEF;
         ud.data.data.val = 1;
         ucb->nSap->mfMsgCtl.sccpInfo.data = *data;
      
         spCb.pduHdr.eh.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.val = M_UNITDATA;
      
         ret = SGetMsg(ucb->nSap->pst.region, ucb->nSap->pst.pool, &mBuf);
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP065, (ErrVal) ret, "SGetMsg failed");
            SPutMsg(*data);
            RETVALUE((Buffer *) NULLP);
         }
      
         /* Encode pdu header */
         SPENCPDUHDR(&ucb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
                     &pduHdrMsgDef[0], TRUE, TRUE, ucb->nSap->nwData->variant,
                     MF_SCCP);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP066, (ErrVal) ret,
                       "SPENCPDUHDR failed");
            if (mBuf)
               SPutMsg(mBuf);
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation. 
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);

               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }

         /* Encode pdu */
         SPENCPDU(&ucb->nSap->mfMsgCtl, ret, (ElmtHdr *) &ud);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP067, (ErrVal) ret, "SPENCPDU failed");
            if (mBuf)
               SPutMsg(mBuf);
               
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation. 
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);
               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }
         ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         *data = (Buffer *) NULLP;   
         break;
      }

      case M_LUNITDATA:      /* fall through */
      case M_XUNITDATA: 
      {
         SpXUnitData ud;

         ud.pClass.eh.pres = PRSNT_NODEF;
         ud.pClass.pClass.pres = PRSNT_NODEF;
         ud.pClass.pClass.val = ucb->ud->qos.pClass;
         ud.pClass.retOpt.pres = PRSNT_NODEF;
         ud.pClass.retOpt.val = ucb->ud->qos.retOpt;

         /* let's deal with Hop Counter */
         ud.hopCntr.eh.pres = PRSNT_NODEF;
         ud.hopCntr.cnt.pres = PRSNT_NODEF;
         ud.hopCntr.cnt.val = ucb->hopCntr;

         ud.cdAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cdAddr, &ud.cdAddr.spAddr);

         ud.cgAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cgAddr, &ud.cgAddr.spAddr);
      
         ud.data.eh.pres = PRSNT_NODEF;
         ud.data.data.pres = PRSNT_NODEF;
         ud.data.data.val = 1;
         ucb->nSap->mfMsgCtl.sccpInfo.data = *data;

         /* put in the segmentation parameters */
         if (ucb->seg)
         {
            ud.segment.eh.pres = PRSNT_NODEF; 
            ud.segment.remainSeg.pres = PRSNT_NODEF;
            ud.segment.remainSeg.val = ucb->segRemain;
            ud.segment.inSeq.pres = PRSNT_NODEF;
            ud.segment.inSeq.val = ucb->seq;
            ud.segment.firstSeg.pres = PRSNT_NODEF;
            ud.segment.firstSeg.val = ucb->firstSeg;
            ud.segment.lclRef.pres = PRSNT_NODEF;
            ud.segment.lclRef.val = ucb->ref;
         }
         else
            ud.segment.eh.pres = NOTPRSNT;

         /* put in importance parameter */
         if (ucb->imp.pres == NOTPRSNT)
         {
            ud.imp.eh.pres = NOTPRSNT;
         }
         else
         {
            ud.imp.eh.pres = PRSNT_NODEF;
            ud.imp.importance.pres = PRSNT_NODEF;
            ud.imp.importance.val = ucb->imp.val;
         }
      


         /* stick in end of optional parameter indicator */
         ud.endOp.eh.pres = PRSNT_NODEF;
         ud.endOp.endOp.pres = PRSNT_NODEF;
         ud.endOp.endOp.val = 0;
      
         spCb.pduHdr.eh.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.val = mType;

         ret = SGetMsg(ucb->nSap->pst.region, ucb->nSap->pst.pool, &mBuf);
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP068, (ErrVal) ret, "SGetMsg failed");
            SPutMsg(*data);
            RETVALUE((Buffer *) NULLP);
         }
      
         /* Encode pdu header */
         SPENCPDUHDR(&ucb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
                     &pduHdrMsgDef[0], TRUE, TRUE, ucb->nSap->nwData->variant,
                     MF_SCCP);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP069, (ErrVal) ret,
                       "SPENCPDUHDR failed");
            if (mBuf)
               SPutMsg(mBuf);
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation. 
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);

               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }

         /* Encode pdu */
         SPENCPDU(&ucb->nSap->mfMsgCtl, ret, (ElmtHdr *) &ud);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP070, (ErrVal) ret, "SPENCPDU failed");
            if (mBuf)
               SPutMsg(mBuf);
                /* sp035.302 - modification - replacing *data with ucb..data
                 * to avoid double deallocation. 
                 */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);
               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }
         ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         *data = (Buffer *) NULLP;   
         break;
      }

      case M_UNITDATASRV:                         /* M_UNITDATASRV */
      {
         SpUnitDataSrv uds;
      
         uds.retCause.eh.pres = PRSNT_NODEF;
         uds.retCause.retCause.pres = PRSNT_NODEF;
         uds.retCause.retCause.val = ucb->ud->qos.retOpt;
      
         uds.cdAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cdAddr, &uds.cdAddr.spAddr);
         uds.cgAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cgAddr, &uds.cgAddr.spAddr);
      
         uds.data.eh.pres = PRSNT_NODEF;
         uds.data.data.pres = PRSNT_NODEF;
         uds.data.data.val = 1;
         ucb->nSap->mfMsgCtl.sccpInfo.data = *data;
      
         spCb.pduHdr.eh.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.val = M_UNITDATASRV; 
      
         ret = SGetMsg(ucb->nSap->pst.region, ucb->nSap->pst.pool, &mBuf);
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP071, (ErrVal) ret,"SGetMsg failed");
            SPutMsg(*data);
            RETVALUE((Buffer *) NULLP);
         }
      
         /* Encode pdu header */
         SPENCPDUHDR(&ucb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
                     &pduHdrMsgDef[0], TRUE, TRUE, ucb->nSap->nwData->variant,
                     MF_SCCP);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP072, (ErrVal) ret,
                       "SPENCPDUHDR failed");
            if (mBuf)
               SPutMsg(mBuf);
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation. 
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);

               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }

         /* Encode pdu */
         SPENCPDU(&ucb->nSap->mfMsgCtl, ret, (ElmtHdr *) &uds);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP073, (ErrVal) ret, "SPENCPDU failed");
            if (mBuf)
               SPutMsg(mBuf);
                /* sp035.302 - modification - replacing *data with ucb..data
                 * to avoid double deallocation. 
                 */ 

            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);
               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }
         ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         *data = (Buffer *) NULLP;
         break;
      }

      case M_LUNITDATASRV:      /* fall through */
      case M_XUNITDATASRV:
      {
         SpXUnitDataSrv uds;
      
         /* fill return cause */
         uds.retCause.eh.pres = PRSNT_NODEF;
         uds.retCause.retCause.pres = PRSNT_NODEF;
         uds.retCause.retCause.val = ucb->ud->qos.retOpt;

         /* fill hop counter */
         uds.hopCntr.eh.pres = PRSNT_NODEF;
         uds.hopCntr.cnt.pres = PRSNT_NODEF;
         uds.hopCntr.cnt.val = ucb->hopCntr;

         uds.cdAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cdAddr, &uds.cdAddr.spAddr);

         uds.cgAddr.eh.pres = PRSNT_NODEF;
         spSpAddrToTknStr(&ucb->ud->cgAddr, &uds.cgAddr.spAddr);
      
         uds.data.eh.pres = PRSNT_NODEF;
         uds.data.data.pres = PRSNT_NODEF;
         uds.data.data.val = 1;
         ucb->nSap->mfMsgCtl.sccpInfo.data = *data;
      
         /* put in segmentation parameter */
         if (ucb->seg == TRUE)
         {
            uds.segment.eh.pres = PRSNT_NODEF;
            uds.segment.remainSeg.pres = PRSNT_NODEF;
            uds.segment.remainSeg.val = ucb->segRemain;
            uds.segment.inSeq.pres = PRSNT_NODEF;
            uds.segment.inSeq.val = (U8) ucb->seq;
            uds.segment.firstSeg.pres = PRSNT_NODEF;
            uds.segment.firstSeg.val = (U8) ucb->firstSeg;
            uds.segment.lclRef.pres = PRSNT_NODEF;
            uds.segment.lclRef.val = (U32) ucb->ref;
         }
         else
            uds.segment.eh.pres = NOTPRSNT;

         /* put in importance parameter */
         if (ucb->imp.pres == NOTPRSNT)
         {
            uds.imp.eh.pres = NOTPRSNT;
         }
         else
         {
            uds.imp.eh.pres = PRSNT_NODEF;
            uds.imp.importance.pres = PRSNT_NODEF;
            uds.imp.importance.val = ucb->imp.val;
         }
      


         /* add in end of optional parameters indicator */
         uds.endOp.eh.pres = PRSNT_NODEF;
         uds.endOp.endOp.pres = PRSNT_NODEF;
         uds.endOp.endOp.val = 0;
      
         spCb.pduHdr.eh.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.pres = PRSNT_NODEF;
         spCb.pduHdr.msgType.val = mType;
      
         ret = SGetMsg(ucb->nSap->pst.region, ucb->nSap->pst.pool, &mBuf);
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP074, (ErrVal) ret,"SGetMsg failed");
            SPutMsg(*data);
            RETVALUE((Buffer *) NULLP);
         }
      
         /* Encode pdu header */
         SPENCPDUHDR(&ucb->nSap->mfMsgCtl, ret, mBuf, (ElmtHdr *) &spCb.pduHdr,
                     &pduHdrMsgDef[0], TRUE, TRUE, ucb->nSap->nwData->variant,
                     MF_SCCP);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP075, (ErrVal) ret,
                       "SPENCPDUHDR failed");
            if (mBuf)
               SPutMsg(mBuf);
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation. 
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);

               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }

         /* Encode pdu */
         SPENCPDU(&ucb->nSap->mfMsgCtl, ret, (ElmtHdr *) &uds);
         if (ret != MFROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP076, (ErrVal) ret, "SPENCPDU failed");
            if (mBuf)
               SPutMsg(mBuf);
               /* sp035.302 - modification - replacing *data with ucb..data
                * to avoid double deallocation.
                */
            if (ucb->nSap->mfMsgCtl.sccpInfo.data)
               SPutMsg(ucb->nSap->mfMsgCtl.sccpInfo.data);
               /* sp035.302 - addition - assigning explicit NULL to 
                * data pointers to avoid double deallocation. 
                */
            ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
            *data = (Buffer *) NULLP;   
            RETVALUE((Buffer *) NULLP);
         }
         ucb->nSap->mfMsgCtl.sccpInfo.data = (Buffer *) NULLP;
         *data = (Buffer *) NULLP;
         break;
      }

      default:
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP077, (ErrVal) mType,
                    "spEncCLMsg() - invalid mType");
         SPutMsg(*data);
         RETVALUE((Buffer *) NULLP);
      }
   } /* switch (mType) */
   
   RETVALUE(mBuf);
} /* spEncCLMsg */

/* sp047.302 - Addition - Function spUiHndlUDatSrvReq added to handle the 
 * Unit Data Service request.
 */
  
/*
 *
 *       Fun:   spUiHndlUDatSrvReq
 *
 *       Desc:  Handle a unit data service request from an Upper Interface.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spUiHndlUDatSrvReq
(
SpUdCb *ucb,                   /* unit data control block */
Buffer *mBuf                   /* the actual data */
)
#else
PUBLIC Void spUiHndlUDatSrvReq(ucb, mBuf)
SpUdCb *ucb;                   /* unit data control block */
Buffer *mBuf;                  /* the actual data */
#endif
{
   S16 ret;                    /* return value */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing SCCP entities */
   U8 nextEntity;              /* next SCCP entity to be selected */
   Bool foundRoute;            /* flag to indicate route found or not */
   U8 cause;                   /* cause of failure in routing/return on error */
   U8 mode;                    /* mode of operation of SCCP entities */
   Bool noCplng;               /* coupling flag, though not valid in Con'less */
   U8 i;                       /* loop counter */
   SpSapCb *cdSap;             /* called sap */
   U8 flag;                    /* flag for backup routing */
   MsgLen udtsSize;            /* sp048.302 - addition - size to fit in one 
                                * UDTS
                                */
   MsgLen xudtsSize;           /* sp047.302 - addition - size to fit in one
                                * XUDTS
                                */
   MsgLen cdLen;                /* sp047.302 - addition - called address length */
   MsgLen cgLen;                /* sp047.302 - addition - calling address length */
#ifdef SP_GNP
   U8 inSsf;                   /* subservice field of incoming network */
   U8 outSsf;                  /* subservice field of outgoing network */
#endif /* SP_GNP */

   TRC2(spUiHndlUDatSrvReq);

   cause = 0;
#ifdef SP_GNP
   inSsf = 0;   
   outSsf = 0;   
#endif /* SP_GNP */

   /* update sap statistics for UDatSrvReq received */
#ifdef LSPV2_5
   ucb->sap->sts.msgUDatSrvReqRx++;
#endif /* LSPV2_5 */
   

   {
      ret = spResolveAddr(&ucb->ud->cdAddr, ucb->ud->qos.pClass, &numEntity,
                          &nextEntity, &mode, &cdAddr[0], &noCplng, 
                          ucb->nwData, &ucb->outNwData);
      if (ret == SP_ERROR)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) 0,
                    "spUiHndlUDatSrvReq: spResolveAddr() failed");
         /* sp048.302 - Addition - Drop the message and free the buffer */
         spDropMsg(&mBuf);
         RETVOID;
      }
      else
      {
         /* if mode of operation of sccp entities is dominant then first
          * the availability of sccp entity at an index 0 is being checked.
          * Hence set nextEntity as zero. If the mode is loadshare and
          * message is class 1 then the entity is selected based on sls.
          * If mode is loadshare and message is class 0 then first sccp
          * entity to be checked for availability is the entity at an
          * index nextEntity returned by function spResolveAddr.
          */
         if (mode == DOMINANT)
            nextEntity = 0;
         else
            if ((mode == LOADSHARE) && (ucb->ud->qos.pClass == PCLASS1))
               /* select entity based on sls */
               nextEntity = ucb->sls % numEntity;
      }
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;
      /* check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * status indiation up.
       */
      if ((ucb->nwData->nwId != ucb->outNwData->nwId) && 
          (ucb->nwData->variant != ucb->outNwData->variant))
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spUiHndlUDatSrvReq: Varaints are not same for incoming and\
                 outgoing networks : incoming network id = %d,\
                 outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", ucb->nwData->nwId,
                 ucb->outNwData->nwId, ucb->nwData->variant,
                 ucb->outNwData->variant));
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
         /* sp048.302 - Addition - Drop the message and free the buffer */
         spDropMsg(&mBuf);
         RETVOID;
      }

      ret = spCheckRoute(ucb->outNwData, &cdAddr[nextEntity], ucb->sls,
                         ucb->ud->qos.pClass, &ucb->rCb, &flag, &cdSap,
                         FROM_UPPER);
      switch (ret)
      {
         case SP_OK:
            /* route is up; destination accessible */
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
#ifdef SP_GNP
            /* assign originating and outgoing network subservice fields */
            inSsf = (ucb->sap->nwData->sInfo & 0xC0) >> 6;
            outSsf = cdAddr[nextEntity].ssf;
#endif /* SP_GNP */

            ucb->nSap = ucb->rCb->nSap;
            ucb->dpc = ucb->ud->cdAddr.pc;
            ucb->opc = ucb->outNwData->selfPc;
            if (ucb->sap->msgInterceptEnabled == TRUE)
            {
               cmCopySpAddr(&ucb->origCdAddr, &ucb->ud->cdAddr);
               cmCopySpAddr(&ucb->origCgAddr, &ucb->ud->cgAddr);
            }
            foundRoute = TRUE;
            break;

         case SP_SSFAIL:
            /* subsystem is prohibited */
            cause = (U8) RTC_SSFAIL;
            break;

         case SP_SPFAIL:
            /* signalling point is prohibited */
            cause = (U8) RTC_NETFAIL;
            break;

         default:
            /* route doesn't exist, or other logical error */
            cause = (U8) RTC_UNQUAL;
            break;
      } /* switch (ret) */

      /* increment nextEntity in modulo fashion with numEntity */
      nextEntity = nextEntity + 1;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)
   {
      if ((cause == RTC_UNQUAL) || (cause == RTC_NETFAIL) || 
          (cause == RTC_SSFAIL))
      {
         for (i = 0; i < numEntity; i++)
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   " Routing failure for dpc %x and ssn %x\n",
                   cdAddr[i].pc, cdAddr[i].ssn));
      }
      /* route not found, send alarm to LM */
      if (cause == RTC_UNQUAL)
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
      /* sp048.302 - Addition - Drop the message and free the buffer */
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* assign importance to the message */
   if (ucb->imp.pres == PRSNT_NODEF)
   {
      /* check if importance is greater than default 
       * allowed value, then use the default allowed
       * value. The specifications does not define
       * max imp for UDTS, so using the default
       * value.
       */
      if (ucb->imp.val > DEFUDTSIMP)
         ucb->imp.val = DEFUDTSIMP;
   }
   else
   {
      /* message importance is not present, use default
       * value but do not mark its presence so as not 
       * to encode in outgoing message
       */
      ucb->imp.val = spCb.spMsgImp.defUdtImp;
   }

   /* check if message to be discarded due to traffic limitation.
    * Discard message due to traffic restriction only if the route
    * is ITU96 and traffic limitation mechansim is enabled
    */
   if ((ucb->rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* find restriction */
      ret = spFindRestriction(ucb->rCb, ucb->imp.val);
      if (ret == SP_DISCARD)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) 0,
                    "spUiHndlUDatSrvReq: spFindRestriction() failed");
         /* sp048.302 - Addition - Drop the message and free the buffer */
         spDropMsg(&mBuf);
         RETVOID;
      }
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */
 
#ifdef SP_GNP
   if ( ucb->sap->msgInterceptEnabled == FALSE)
   {
      /* perform calling party address treatment for generic numbering plan */
      ret = spCgAddrTreatment(&ucb->ud->cgAddr, inSsf, outSsf, ucb->nwData,
                              &ucb->outNwData);
      if (ret != SP_OK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP078, (ErrVal) ERRZERO,
                    "Failure in calling party address treament");
         /* sp048.302 - Addition - Drop the message and free the buffer */
         spDropMsg(&mBuf);
         RETVOID;
      }
   }
#endif /* SP_GNP */

   cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                        ucb->rCb->nSap->nwData->variant);
   cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                        ucb->rCb->nSap->nwData->variant);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (cgLen == 0 || cdLen == 0)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP090, (ErrVal) 0,
                 "error calculating called/calling address length");
      /* sp048.302 - Addition - Drop the message and free the buffer */
      spDropMsg(&mBuf);
      RETVOID;
   }
#endif /* ERRCLASS */

   /* sp048.302 - modification - fill param and handle message based
    * on route switch
    */

   /* set return cause to be filled in retCause param of message */
   ucb->ud->qos.retOpt = RTC_UNQUAL;

   /* set def hop cntr, in case we send XUDTS becuase of compile flag */
   ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;

   /* message will not be sent as segmented XUDTS, set fields */
   ucb->seg = FALSE;
   ucb->segRemain = 0;
   ucb->ref = 0;

   /* message originated locally, mark message type interworking as false */
   ucb->spMti.pres = FALSE;

   switch (ucb->rCb->swtch)
   {
      case LSP_SW_ITU88:
      {
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
            udtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
         else
            udtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;

         /* truncate message if required */
         spTruncateMsg(mBuf, udtsSize);

         ucb->dataType = M_UNITDATASRV;
      }
      break;


      case LSP_SW_CHINA:   /* fall through : same as itu92 */
      case LSP_SW_GSM0806: /* fall through */
      case LSP_SW_ITU92:
      {
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
         {
            /* either china route or gsm route in ansi network */
            if ((ucb->rCb->swtch == LSP_SW_CHINA) ||
                (ucb->rCb->nSap->nwData->variant == LSP_SW_ANS))
            {
               udtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN_ANSI;
               xudtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN_ANSI;
            }
            else
            {
               udtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
               xudtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN;
            }
         }
         else
         {
            /* either china route or gsm route in ansi network */
            if ((ucb->rCb->swtch == LSP_SW_CHINA) ||
                (ucb->rCb->nSap->nwData->variant == LSP_SW_ANS))
            {
               udtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN_ANSI;
               xudtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN_ANSI;
            }
            else
            {
               udtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;
               xudtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN;
            }
         }

         /* china, japan, gsm, itu92 does not support importance */
         ucb->imp.pres = NOTPRSNT;

#ifdef SPTV2

#endif /* SPTV2 */

#ifdef SP_TX_XUDT
         /* truncate message if required */
         spTruncateMsg(mBuf, xudtsSize);

         ucb->dataType = M_XUNITDATASRV;
#else
         /* truncate message if required */
         spTruncateMsg(mBuf, udtsSize);

         ucb->dataType = M_UNITDATASRV;
#endif /* SP_TX_XUDT */
      }
      break;


      case LSP_SW_ITU96:
      {
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
         {
            udtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
            xudtsSize = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN;
         }
         else
         {
            udtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;
            xudtsSize = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN;
         }

#ifdef SPTV2

#endif /* SPTV2 */

#ifdef SP_TX_XUDT
         /* truncate message if required */
         spTruncateMsg(mBuf, xudtsSize);

         ucb->dataType = M_XUNITDATASRV;
#else
         /* if imp is not present send message as UDTS, else XUDTS */
         if (ucb->imp.pres == NOTPRSNT)
         {
            /* truncate message if required */
            spTruncateMsg(mBuf, udtsSize);

            ucb->dataType = M_UNITDATASRV;
         }
         else
         {
            /* truncate message if required */
            spTruncateMsg(mBuf, xudtsSize);

            ucb->dataType = M_XUNITDATASRV;
         }
#endif /* SP_TX_XUDT */
      } /* LSP_SW_ITU96 */
      break;


      default:
         /* invalid route, drop message */
         SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) ucb->rCb->swtch,
                    "spUiHndlUDatSrvReq: invalid route.");
         spDropMsg(&mBuf);
         RETVOID;
         break;
   } /* switch (ucb->rCb->swtch) */

   if ((mBuf = spEncCLMsg(ucb->dataType, ucb, &mBuf)) == NULLP)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) ERRZERO,
                 "spUiHndlUDatSrvReq: Failure in Encode UDTS message.");
      spDropMsg(&mBuf);
      RETVOID;
   }

   spCb.sts.uDataSrvTx++;
#ifdef LSPV2_5
   ucb->sap->sts.uDataSrvTx++;
#endif /* LSPV2_5 */
   /* deliver message to lower layer */
   spDelvUDatDown(ucb, FROM_UPPER, mBuf);

   RETVOID;
} /* spUiHndlUDatSrvReq */


  
/*
 *
 *       Fun:   spUiHndlUDatReq
 *
 *       Desc:  Handle a unit data request from an Upper Interface.
 *
 *       Ret:   None
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spUiHndlUDatReq
(
SpUdCb *ucb,                   /* unit data control block */
Buffer *mBuf                   /* the actual data */
)
#else
PUBLIC Void spUiHndlUDatReq(ucb, mBuf)
SpUdCb *ucb;                   /* unit data control block */
Buffer *mBuf;                  /* the actual data */
#endif
{
   S16 ret;                    /* return value */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing SCCP entities */
   U8 nextEntity;              /* next SCCP entity to be selected */
   Bool foundRoute;            /* flag to indicate route found or not */
   U8 cause;                   /* cause of failure in routing/return on error */
   U8 mode;                    /* mode of operation of SCCP entities */
   Bool noCplng;               /* coupling flag, though not valid in Con'less */
   U8 i;                       /* loop counter */
   SpSapCb *cdSap;             /* called sap */
   U8 flag;                    /* flag for backup routing */
#ifdef SP_GNP
   U8 inSsf;                   /* subservice field of incoming network */
   U8 outSsf;                  /* subservice field of outgoing network */
#endif /* SP_GNP */

   TRC2(spUiHndlUDatReq);

   /* sp044.302 - addition - Initialization of Local Variables */   
   cause = 0;
#ifdef SP_GNP
   inSsf = 0;   
   outSsf = 0;   
#endif /* SP_GNP */

   /* update sap statistics per class for msgs sent from the upper
    * sap and get Sls if message is for class 1, for class 0 sls
    * will be found while delivering data down to lower layer
    */
   if (ucb->ud->qos.pClass == PCLASS1)
   {
      ucb->sap->sts.msgTxC1++;
      /* sp047.302 - Addition - Statistics added for message Interception */
#ifdef LSPV2_5
      ucb->sap->sts.msgInterceptTxC1++;
#endif /* LSPV2_5 */
      ucb->sls = ucb->ud->sc & ucb->nwData->slsMask;
   }
   else
   {
      ucb->sap->sts.msgTxC0++;
      /* sp047.302 - Addition - Statistics added for message Interception */
#ifdef LSPV2_5
      ucb->sap->sts.msgInterceptTxC0++;
#endif /* LSPV2_5 */
   }


   {
      /* sp045.302 - modification - replacing selfPc with ptr to nwCb 
       * of incoming network  and ptr to outgoing network CB.
       */
      ret = spResolveAddr(&ucb->ud->cdAddr, ucb->ud->qos.pClass, &numEntity,
                          &nextEntity, &mode, &cdAddr[0], &noCplng, 
                          ucb->nwData, &ucb->outNwData);
      if (ret == SP_ERROR)
      {
         /* translation error, send status indication to user */
         spHndlStatInd(ucb, (U8) RTC_NTSPECADDR, mBuf);
         RETVOID;
      }
      else
      {
         /* if mode of operation of sccp entities is dominant then first
          * the availability of sccp entity at an index 0 is being checked.
          * Hence set nextEntity as zero. If the mode is loadshare and
          * message is class 1 then the entity is selected based on sls.
          * If mode is loadshare and message is class 0 then first sccp
          * entity to be checked for availability is the entity at an
          * index nextEntity returned by function spResolveAddr.
          */
         if (mode == DOMINANT)
            nextEntity = 0;
         else
            if ((mode == LOADSHARE) && (ucb->ud->qos.pClass == PCLASS1))
               /* select entity based on sls */
               nextEntity = ucb->sls % numEntity;
      }
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;
      /* sp045.302 - addition - check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * status indiation up.
       */
      if ((ucb->nwData->nwId != ucb->outNwData->nwId) && 
          (ucb->nwData->variant != ucb->outNwData->variant))
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spUiHndlUDatReq: Varaints are not same for incoming and\
                 outgoing networks : incoming network id = %d,\
                 outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", ucb->nwData->nwId,
                 ucb->outNwData->nwId, ucb->nwData->variant,
                 ucb->outNwData->variant));
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
         /* copy new called address into unit data event */
         cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
         cause = (U8) RTC_NETFAIL;
         /* send status indication up */
         spHndlStatInd(ucb, (U8) cause, mBuf);
         RETVOID;
      }

      /* sp045.302 - modification - using network CB of the outgoing network */
      ret = spCheckRoute(ucb->outNwData, &cdAddr[nextEntity], ucb->sls,
                         ucb->ud->qos.pClass, &ucb->rCb, &flag, &cdSap,
                         FROM_UPPER);
      switch (ret)
      {
         case SP_LOCAL:            /* (Loop back ) */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            /* update upper sap statistics per class for msgs received */
            if (ucb->ud->qos.pClass == PCLASS0)
            {
               ucb->sap->sts.msgRxC0++;
               /* sp047.302 - Addition - Statistics added for message 
                * Interception 
                */
#ifdef LSPV2_5
               ucb->sap->sts.msgInterceptRxC0++;
#endif /* LSPV2_5 */
            }
            else
            {
               ucb->sap->sts.msgRxC1++;
               /* sp047.302 - Addition - Statistics added for message 
                * Interception 
                */
#ifdef LSPV2_5
               ucb->sap->sts.msgInterceptRxC1++;
#endif /* LSPV2_5 */
            }

            /*BEGIN:add by wanglijun.*/
            SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
                    "********SCCP send unitdata msg to upper layer ,suId(%d),opc(0x%d),dpc(0x%d)*******\n",
                    ucb->sap->suId, ucb->opc, ucb->dpc));
            /*END:add by wanglijun*/

            /* send unit data indication up */
            (Void) SpUiSptUDatInd(&cdSap->pst, cdSap->suId, 
                                  ucb->nwData->selfPc, ucb->ud, mBuf);
            RETVOID;

         case SP_OK:
            /* route is up; destination accessible */
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
#ifdef SP_GNP
            /* assign originating and outgoing network subservice fields */
            inSsf = (ucb->sap->nwData->sInfo & 0xC0) >> 6;
            outSsf = cdAddr[nextEntity].ssf;
#endif /* SP_GNP */

            ucb->nSap = ucb->rCb->nSap;
            ucb->dpc = ucb->ud->cdAddr.pc;
            /* sp045.302 - modification - replace nwCb with outNwCb to take
             * care of internetworking case.
             */
            ucb->opc = ucb->outNwData->selfPc;
            /* sp047.302 - Addition - If the message intercept is enabled
             * restore the original called and calling address into the unit 
             * data Cb.
             */
            if (ucb->sap->msgInterceptEnabled == TRUE)
            {
               cmCopySpAddr(&ucb->origCdAddr, &ucb->ud->cdAddr);
               cmCopySpAddr(&ucb->origCgAddr, &ucb->ud->cgAddr);
            }
            foundRoute = TRUE;
            break;

         case SP_UNEQUIP:
            /* upper user is unequipped, send status indication to
             * originating sap
             */
            /* sp045.302 - modification - replace nwCb with outNwCb to take
             * care of internetworking case.
             */
            ucb->dpc = ucb->outNwData->selfPc;
            spHndlStatInd(ucb, (U8) RTC_UNEQUIP, mBuf);
            RETVOID;

         case SP_SSFAIL:
            /* subsystem is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_SSFAIL;
            break;

         case SP_SPFAIL:
            /* signalling point is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_NETFAIL;
            break;

         default:
            /* route doesn't exist, or other logical error */
            cause = (U8) RTC_UNQUAL;
            break;
      } /* switch (ret) */

      /* increment nextEntity in modulo fashion with numEntity */
      nextEntity = nextEntity + 1;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)
   {
      /* sp046.302 - addition - debug prints to indicate routing error */
      if ((cause == RTC_UNQUAL) || (cause == RTC_NETFAIL) || 
          (cause == RTC_SSFAIL))
      {
         for (i = 0; i < numEntity; i++)
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   " Routing failure for dpc %x and ssn %x\n",
                   cdAddr[i].pc, cdAddr[i].ssn));
      }
      /* route not found, send alarm to LM */
      if (cause == RTC_UNQUAL)
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
      /* send status indication up */
      spHndlStatInd(ucb, (U8) cause, mBuf);
      RETVOID;
   }

   /* sp024.302 - removal - calling party address treatment is done
    * in parent function.
    */

   /* assign importance to the message */
   if (ucb->imp.pres == PRSNT_NODEF)
   {
      /* check if importance is greater than maximum
       * allowed value, then use the maximum allowed
       * value
       */
      if (ucb->imp.val > MAXUDATIMP)
         ucb->imp.val = MAXUDATIMP;
   }
   else
   {
      /* message importance is not present, use default
       * value but do not mark its presence so as not 
       * to encode in outgoing message
       */
      ucb->imp.val = spCb.spMsgImp.defUdtImp;
   }

   /* check if message to be discarded due to traffic limitation.
    * Discard message due to traffic restriction only if the route
    * is ITU96 and traffic limitation mechansim is enabled
    */
   if ((ucb->rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* find restriction */
      ret = spFindRestriction(ucb->rCb, ucb->imp.val);
      if (ret == SP_DISCARD)
      {
         /* message can not be sent due to traffic limitation,
          * send status indication up
          */
         spHndlStatInd(ucb, (U8) RTC_NETCONG, mBuf);
         RETVOID;
      } /* if (ret == SP_DISCARD) */
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */
 
#ifdef SP_GNP
   /* sp047.302 - Addition - Calling address treatment is done only if message
    * interception is disabled.
    */
   if ( ucb->sap->msgInterceptEnabled == FALSE)
   {
      /* perform calling party address treatment for generic numbering plan */
      /* sp045.302 - addition - pass ptr to network CB , and out network CB */
      ret = spCgAddrTreatment(&ucb->ud->cgAddr, inSsf, outSsf, ucb->nwData,
                              &ucb->outNwData);
      if (ret != SP_OK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP078, (ErrVal) ERRZERO,
                    "Failure in calling party address treament");
         /* send status indication up */
         spHndlStatInd(ucb, (U8) RTC_UNQUAL, mBuf);
         RETVOID;
      }
   }
#endif /* SP_GNP */

   /* Send UDT/XUDT/LUDT based on the route and nSap characteristics */
   spUiHndlSegData(ucb, mBuf);

   RETVOID;
} /* spUiHndlUDatReq */


/*
*
*       Fun:   spDecMngtData
*
*       Desc:  Decode management data
*
*       Ret:   SP_OK   - ok
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spDecMngtData
(
U8 dlen,             /* dpc length */
SpMngtData *mData,
Buffer *mBuf
)
#else
PUBLIC S16 spDecMngtData(dlen, mData, mBuf)
U8 dlen;             /* dpc length */
SpMngtData *mData;
Buffer *mBuf;
#endif
{
   U8 octet;
   S16 ret;
  
   TRC2(spDecMngtData)

   /* remove the data length */

   /*
    * SCMG Format Identifier
    */
   ret = SRemPreMsg(&octet, mBuf);
   if (ret != ROK)
      RETVALUE(SP_ERROR);
   switch(octet)                 /* validate format */
   {
      case SCMG_SSA:
      case SCMG_SSP:
      case SCMG_SST:
      case SCMG_SOR:
      case SCMG_SOG:
      case SCMG_SSC:
         mData->format = octet;
         break;
      default:
         RETVALUE(SP_ERROR);
   }
   /*
    * SCMG Affected Ssn
    */
   ret = SRemPreMsg(&octet, mBuf);
   if (ret != ROK)
      RETVALUE(SP_ERROR);
   mData->aSsn = octet;
  
   /*
    * SCMG Affected Point Code
    */
   ret = spRemPc(dlen, &mData->aPc, mBuf);
   if (ret != ROK)
      RETVALUE(SP_ERROR);

   ret = SRemPreMsg(&octet, mBuf);
   if (ret != ROK)
      RETVALUE(SP_ERROR);
   switch(octet)                      /* validate subsystem multiplicity */
   {
      case SMI_UNK:
      case SMI_SOL:
      case SMI_DUP:
         mData->smi = octet;
         break;
      default:
         RETVALUE(SP_ERROR);
   }

   /* decode congestion level if message is SSC */
   if (mData->format == SCMG_SSC)
   {
       ret = SRemPreMsg(&octet, mBuf);
       if (ret != ROK)
          RETVALUE(SP_ERROR);
       mData->cLvl = octet;
   }
   else
   {
       mData->cLvl = 0;
   }

   RETVALUE(SP_OK);
} /* end of spDecMngtData */

  
/*
*
*       Fun:   spLiHndlClss0
*
*       Desc:  Handle a Class 0 Message from a Lower Interface.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spLiHndlClss0
(
SpUdCb *ucb,            /* unit data control block */
Buffer *mBuf            /* data buffer */
)
#else
PUBLIC Void spLiHndlClss0(ucb, mBuf)
SpUdCb *ucb;            /* unit data control block */
Buffer *mBuf;           /* data buffer */
#endif
{
   S16 ret;                    /* return value */
   U8 flag;                    /* flag */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing SCCP entities */
   U8 nextEntity;              /* next SCCP entity to be selected */
   Bool foundRoute;            /* flag to indicate route found or not */
   U8 cause;                   /* cause of failure in routing/return on error */
   U8 mode;                    /* mode of operation of SCCP entities */
   Bool noCplng;               /* coupling flag, though not valid in Con'less */
   U8 i;                       /* loop counter */
   U8 oRtgInd;                 /* routing indicator in the called addr */
#ifdef SP_GNP
   U8 inSsf;                   /* subservice field of incoming network */
   U8 outSsf;                  /* subservice field of outgoing network */
#endif /* SP_GNP */

   TRC2(spLiHndlClss0);

   /* sp044.302 - addition - Initialization of Local Variables */   
   cause = 0;
   ret = 0;   
   oRtgInd = RTE_GT;
#ifdef SP_GNP
   inSsf = 0;   
   outSsf = 0;   
#endif /* SP_GNP */



   {
      /* before resolving addr, store routing indicator to be able to
       * decide to send back SSP
       */
      oRtgInd = ucb->ud->cdAddr.rtgInd;

      /* before GT translations, set incoming pc as self pc */
      ucb->ud->cdAddr.pc = ucb->nwData->selfPc;
      ucb->ud->cdAddr.pcInd = TRUE;

      /* sp045.302 - modification - replacing selfPc with ptr to nwCb 
       * of incoming network and ptr to outgoing network CB. 
       */
      ret = spResolveAddr(&ucb->ud->cdAddr, PCLASS0, &numEntity, &nextEntity,
                          &mode, &cdAddr[0], &noCplng, ucb->nwData,
                          &ucb->outNwData);
      if (ret == SP_ERROR)
      {
         /* translation error, return message */
         spReturnMsg(ucb, (U8) RTC_NTSPECADDR, mBuf);
         RETVOID;
      }
      else
      {
         /* for class 0 traffic, if mode of operation of sccp entities
          * is dominant then first the availability of sccp entity at
          * an index 0 is being checked. Hence set nextEntity as zero.
          * In case of loadshare mode the first entity to be checked for
          * availability is the entity at an index nextEntity, returned
          * by spResolveAddr.
          */
         if (mode == DOMINANT)
            nextEntity = 0;
      }
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;
      /* sp045.302 - addition - check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * status indiation up.
       */
      if ((ucb->nwData->nwId != ucb->outNwData->nwId) && 
         (ucb->nwData->variant != ucb->outNwData->variant))
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spLiHndlClss0: Varaints are not same for incoming and\
                 outgoing networks : incoming network id = %d,\
                 outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", ucb->nwData->nwId,
                 ucb->outNwData->nwId, ucb->nwData->variant,
                 ucb->outNwData->variant));
         /* copy new called address into unit data event */
         cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
         cause = (U8) RTC_NETFAIL;
         /* send status indication up */
         spHndlStatInd(ucb, (U8) cause, mBuf);
         RETVOID;
      }

      /* sp045.302 - modification - using network CB of the outgoing network */
      ret = spCheckRoute(ucb->outNwData, &cdAddr[nextEntity], 0, PCLASS0,
                            &ucb->rCb, &flag, &ucb->sap, FROM_LOWER);
      switch (ret)
      {
         case SP_LOCAL:     /* destination is local user */
            /* sp047.302 - Addition - If the Sap has the msgInterceptEnabled
             * flag set then copy the origCdAddr and origCgAddr into ucb.
             */
            if (ucb->sap->msgInterceptEnabled == TRUE)
            {
               cmCopySpAddr(&ucb->origCdAddr, &ucb->ud->cdAddr);
               cmCopySpAddr(&ucb->origCgAddr, &ucb->ud->cgAddr);
            }
            else
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            /* update upper sap statistics for class 0 msgs received */
            ucb->sap->sts.msgRxC0++;
            /* sp047.302 - Addition - Statistics added for message Interception
             */
#ifdef LSPV2_5
            ucb->sap->sts.msgInterceptRxC0++;
#endif /* LSPV2_5 */

            /*BEGIN:add by wanglijun.*/
            SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
                    "********SCCP send unitdata msg to upper layer ,suId(%d),opc(0x%d),dpc(0x%d)*******\n",
                    ucb->sap->suId, ucb->opc, ucb->dpc));
            /*END:add by wanglijun*/

            /* send unit data indication up */
            (Void) SpUiSptUDatInd(&ucb->sap->pst, ucb->sap->suId, ucb->opc,
                                  ucb->ud, mBuf);
            RETVOID;

         case SP_OK:        /* route is up; destination accessible */
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

#ifdef SP_GNP
            /* assign incoming and outgoing subservice fields */
            inSsf = (ucb->nSap->nwData->sInfo & 0xC0) >> 6;
            outSsf = cdAddr[nextEntity].ssf;
#endif /* SP_GNP */

            ucb->nSap = ucb->rCb->nSap;
            ucb->dpc = ucb->ud->cdAddr.pc;
            foundRoute = TRUE;
            break;

         case SP_UNEQUIP:
            /* upper user unequipped, return message */
            spReturnMsg(ucb, (U8) RTC_UNEQUIP, mBuf);
            RETVOID;

         case SP_SSFAIL:    /* subsystem is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_SSFAIL;
            break;

         case SP_SPFAIL:    /* signalling point is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_NETFAIL;
            break;

         default:           /* route doesn't exist, or other logical error */

            /* sp030.302 - modification - cause RTC_NETFAIL to RTC_UNQUAL */
            cause = (U8) RTC_UNQUAL;
            break;
      } /* switch (ret) */
      
      /* increment nextEntity in modulo operation with numEntity */
      nextEntity++;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)
   {
      /* sp046.302 - addition - debug prints to indicate routing error */
      if ((cause == RTC_UNQUAL) || (cause == RTC_NETFAIL) || 
          (cause == RTC_SSFAIL))
      {
         for (i = 0; i < numEntity; i++)
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   " Routing failure for dpc %x and ssn %x\n",
                   cdAddr[i].pc, cdAddr[i].ssn));
      }
      /* route not found, send alarm to LM */
      if (cause == RTC_UNQUAL)
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
      /* return message */
      spReturnMsg(ucb, (U8) cause, mBuf);
            
      /* send management message SSP if the message is received 
       * with routing on SSN and check route has returned SSFAIL
       */
      if ((ret == SP_SSFAIL) && (oRtgInd == RTE_SSN))
      {
         SpMngtCb mcb;

         mcb.dpc = ucb->opc;
         mcb.apc = ucb->nwData->selfPc;
         mcb.assn = ucb->ud->cdAddr.ssn;
         mcb.nwData = ucb->nwData;
         mcb.smi = SMI_UNK;
         mcb.frmt = SCMG_SSP;
         spSendMngtMsg(&mcb);
      }
      RETVOID;
   } /* if (foundRoute == FALSE) */
 
   /* check if message to be discarded due to traffic limitation.
    * Discard message due to traffic restriction only if the route
    * is ITU96 and traffic limitation mechansim is enabled
    */
   if ((ucb->rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* if importance is not present in the received message,
       * then in case of national network find importance from
       * sio priority else assume default importance for the
       * the message but in any case do not mark presence of
       * importance so as not to encode importance in outgoing
       * message if its not present in incoming message.
       */
      if (ucb->imp.pres == NOTPRSNT)
      {
         U8 ssf;               /* sub-service field */

         if (ucb->ud->cdAddr.ssfPres)
            ssf = ucb->ud->cdAddr.ssf;
         else
            ssf = (ucb->nwData->sInfo & 0xC0) >> 6;

         if (ssf != SSF_NAT)   /* not a national network */
            ucb->imp.val = spCb.spMsgImp.defUdtImp;
         else                  /* national network */
         {
            if (ucb->nwData->sioPrioImpPres == TRUE)
               ucb->imp.val = ucb->nwData->sioPrioImp[(U8) ucb->ud->prior];
            else
               ucb->imp.val = spCb.spMsgImp.defUdtImp;
         }
      } /* if (ucb->imp.pres == NOTPRSNT) */

      /* find restriction */
      ret = spFindRestriction(ucb->rCb, ucb->imp.val);
      if (ret == SP_DISCARD)
      {
         /* message can not be forwarded due to traffic limitation,
          * return message
          */
         spReturnMsg(ucb, (U8) RTC_NETCONG, mBuf);
         RETVOID;
      } /* if (ret == SP_DISCARD) */
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */
 
#ifdef SP_GNP
   /* perform calling party address treatment for generic numbering plan */
   /* sp045.302 - addition - pass ptr to network CB , and out network CB */
   ret = spCgAddrTreatment(&ucb->ud->cgAddr, inSsf, outSsf, ucb->nwData,
                           &ucb->outNwData);
   if (ret != SP_OK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP079, (ErrVal) ERRZERO,
                 "Failure in calling party address treament");
      /* return message */
      spReturnMsg(ucb, (U8) RTC_UNQUAL, mBuf);
   }
#endif /* SP_GNP */

   /* now that there is no chance of the message being
    * returned set opc
    */
   /* sp045.302 - modification - replace nwCb with outNwCb to take
    * care of internetworking case.
    */
   ucb->opc = ucb->outNwData->selfPc;

   /* increment appropriate statistics */
   if (flag & SP_BRT)
      ucb->sap->sts.msgTxBSS++;

   spLiSegAndSendData(ucb, mBuf);

   RETVOID;
} /* spLiHndlClss0 */

  
/*
*
*       Fun:   spFindUpperSap
*
*       Desc:  find an upper sap
*
*       Ret:   SP_OK   - ok
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC SpSapCb* spFindUpperSap
(
NwId nwId,     /* network identifier */
Ssn ssn        /* subsystem number */
)
#else
PUBLIC SpSapCb* spFindUpperSap(nwId, ssn)
NwId nwId;     /* network identifier */
Ssn ssn;       /* subsystem number */
#endif
{
   REG1 U8 i;
  
   for (i = 0; i < spCb.spCfg.nmbSaps; i++)
   {
      if (spCb.sapList[i] != (SpSapCb*)NULLP)
      {
         if ( (spCb.sapList[i]->nwData->nwId == nwId) &&   /* match network */
            (spCb.sapList[i]->ssn == ssn) &&      /* match subsystem */
            (spCb.sapList[i]->status & SP_BND) )  /* state is bound */
            RETVALUE(spCb.sapList[i]);
      }
   }
   RETVALUE((SpSapCb*)NULLP);
} /* end of spFindUpperSap */


/*
 *
 *       Fun:   spLiHndlClss1
 *
 *       Desc:  Handle a Class 1 Message from the Lower Interface.
 *              If the message is to be sent out to the network after 
 *              GTT, then instead of allocating a new a SCLICb we use 
 *              the incoming sls as the outgoing sls.
 *
 *       Ret:   Void
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void spLiHndlClss1
(
SpUdCb *ucb,                   /* unit data control block */
Buffer *mBuf                   /* the actual data */
)
#else
PUBLIC Void spLiHndlClss1(ucb, mBuf)
SpUdCb *ucb;                   /* unit data control block */
Buffer *mBuf;                  /* the actual data */
#endif
{
   S16 ret;                    /* return value */
   U8 flag;                    /* flag */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing SCCP entities */
   U8 nextEntity;              /* next SCCP entity to be selected */
   Bool foundRoute;            /* flag to indicate route found or not */
   U8 cause;                   /* cause of failure in routing */
   U8 mode;                    /* mode of operation of SCCP entities */
   Bool noCplng;               /* coupling flag, though not valid in Con'less */
   U8 i;                       /* loop counter */
   U8 oRtgInd;                 /* routing indicator in called addr */
#ifdef SP_GNP
   U8 inSsf;                   /* subservice field of incoming network */
   U8 outSsf;                  /* subservice field of outgoing network */
#endif /* SP_GNP */

   TRC2(spLiHndlClss1);

   /* sp044.302 - addition - Initialization of Local Variables */   
   cause = 0;
   ret = 0;   
   oRtgInd = RTE_GT;
#ifdef SP_GNP
   inSsf = 0;   
   outSsf = 0;   
#endif /* SP_GNP */



   {
      /* before resolving addr, store routing indicator to be able to
       * decide to send back SSP
       */
      oRtgInd = ucb->ud->cdAddr.rtgInd;

      /* before GT Translations, set incoming pc as self pc */
      ucb->ud->cdAddr.pc = ucb->nwData->selfPc;
      ucb->ud->cdAddr.pcInd = TRUE;

      /* sp045.302 - modification - replacing selfPc with ptr to nwCb 
       * of incoming network and ptr to outgoing network CB.
       */
      ret = spResolveAddr(&ucb->ud->cdAddr, PCLASS1, &numEntity, &nextEntity,
                          &mode, &cdAddr[0], &noCplng, ucb->nwData,
                          &ucb->outNwData);
      if (ret == SP_ERROR)
      {
         /* translation error, return message */
         spReturnMsg(ucb, (U8) RTC_NTSPECADDR, mBuf);
         RETVOID;
      }
      else
      {
         /* for class 1 traffic, if mode of operation of sccp entities
          * is dominant then first the availability of sccp entity at 
          * an index 0 is being checked. Hence set nextEntity as zero.
          * If the mode is loadshare then the entity is selected based
          * on sls.
          */
         if (mode == DOMINANT)
            nextEntity = 0;
         else
            if (mode == LOADSHARE)
               /* select entity based on sls */
               nextEntity = ucb->sls % numEntity;
      }
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;
      /* sp045.302 - addition - check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * status indiation up.
       */
      if ((ucb->nwData->nwId != ucb->outNwData->nwId) && 
          (ucb->nwData->variant != ucb->outNwData->variant))
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spLiHndlClss1: Varaints are not same for incoming and outgoing\
                 networks : incoming network id = %d, outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", ucb->nwData->nwId,
                 ucb->outNwData->nwId, ucb->nwData->variant,
                 ucb->outNwData->variant));
         /* copy new called address into unit data event */
         cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
         cause = (U8) RTC_NETFAIL;
         /* send status indication up */
         spHndlStatInd(ucb, (U8) cause, mBuf);
         RETVOID;
      }
      /* sp045.302 - modification - using network CB of the outgoing network */
      ret = spCheckRoute(ucb->outNwData, &cdAddr[nextEntity], ucb->sls,
                            PCLASS1, &ucb->rCb, &flag, &ucb->sap, FROM_LOWER);
      switch (ret)
      {
         case SP_LOCAL:     /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            /* reassemble segmented data if necessary */
            if ((ucb->dataType == M_XUNITDATA) && (ucb->seg == TRUE))
               spLiHndlSegData(ucb, mBuf);
            else
            {
               /* sp045.302 - modification - update the counter before calling
                * the data indication primitive as updating after calling
                * the indication primitive could be an issue in tightly
                * coupled case.
                */
               /* increment statistics counter for class 1 msgs recvd */
               ucb->sap->sts.msgRxC1++;
               /* sp047.302 - Addition - Statistics added for message 
                * Interception
                */
#ifdef LSPV2_5
               ucb->sap->sts.msgInterceptRxC1++;
#endif /* LSPV2_5 */
               /* sp047.302 - Addition - If the Sap has the msgInterceptEnabled
                * flag set then copy the origCdAddr and origCgAddr into ucb.
                */
               if (ucb->sap->msgInterceptEnabled == TRUE)
               {
                  cmCopySpAddr(&ucb->origCdAddr, &ucb->ud->cdAddr);
                  cmCopySpAddr(&ucb->origCgAddr, &ucb->ud->cgAddr);
               }

               /*BEGIN:add by wanglijun.*/
               SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
                       "********SCCP send unitdata msg to upper layer ,suId(%d),opc(0x%d),dpc(0x%d)*******\n",
                       ucb->sap->suId, ucb->opc, ucb->dpc));
               /*END:add by wanglijun*/
               
               /* send unit data indication up */
               (Void) SpUiSptUDatInd(&ucb->sap->pst, ucb->sap->suId, ucb->opc,
                                     ucb->ud, mBuf);
            }
            RETVOID;

         case SP_OK:        /* route is up; destination accessible */
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

#ifdef SP_GNP
            /* assign incoming and outgoing subservice fields */
            inSsf = (ucb->nSap->nwData->sInfo & 0xC0) >> 6;
            outSsf = cdAddr[nextEntity].ssf;
#endif /* SP_GNP */

            ucb->nSap = ucb->rCb->nSap;
            ucb->dpc = ucb->ud->cdAddr.pc;
            foundRoute = TRUE;
            break;

         case SP_UNEQUIP:
            /* upper user unequipped, return message */
            spReturnMsg(ucb, (U8) RTC_UNEQUIP, mBuf);
            RETVOID;

         case SP_SSFAIL:    /* subsystem is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_SSFAIL;
            break;

         case SP_SPFAIL:    /* signalling point is prohibited */
            /* copy new called address into unit data event */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);
            cause = (U8) RTC_NETFAIL;
            break;

         default:           /* route doesn't exist, or other logical error */
            /* sp030.302 - modification - cause RTC_NETFAIL to RTC_UNQUAL */
            cause = (U8) RTC_UNQUAL;
            break;
      } /* switch (ret) */

      /* increment nextEntity in modulo operation with numEntity */
      nextEntity = nextEntity + 1;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)
   {
      /* sp046.302 - addition - debug prints to indicate routing error */
      if ((cause == RTC_UNQUAL) || (cause == RTC_NETFAIL) || 
          (cause == RTC_SSFAIL))
      {
         for (i = 0; i < numEntity; i++)
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   " Routing failure for dpc %x and ssn %x\n",
                   cdAddr[i].pc, cdAddr[i].ssn));
      }
      /* route not found, send alarm to LM */
      if (cause == RTC_UNQUAL)
         spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_ROUTING_ERR,
                     LSP_CAUSE_INV_ROUTE, NOTUSED, NOTUSED);
      /* return message */
      spReturnMsg(ucb, (U8) cause, mBuf);

      /* send management message SSP if the message is received 
       * with routing on SSN ans check route has returned SSFAIL
       */
      if ((ret == SP_SSFAIL) && (oRtgInd == RTE_SSN))
      {
         SpMngtCb mcb;

         mcb.dpc = ucb->opc;
         mcb.apc = ucb->nwData->selfPc;
         mcb.assn = ucb->ud->cdAddr.ssn;
         mcb.nwData = ucb->nwData;
         mcb.smi = SMI_UNK;
         mcb.frmt = SCMG_SSP;
         spSendMngtMsg(&mcb);
      }
      RETVOID;
   } /* if (foundRoute == FALSE) */

   /* check if message to be discarded due to traffic limitation.
    * Discard message due to traffic restriction only if the route
    * is ITU96 and traffic limitation mechansim is enabled
    */
   if ((ucb->rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* if importance is not present in the received message,
       * then in case of national network find importance from
       * sio priority else assume default importance for the
       * the message but in any case do not mark presence of
       * importance so as not to encode importance in outgoing
       * message if its not present in incoming message.
       */
      if (ucb->imp.pres == NOTPRSNT)
      {
         U8 ssf;              /* sub-service field */

         if (ucb->ud->cdAddr.ssfPres)
            ssf = ucb->ud->cdAddr.ssf;
         else
            ssf = (ucb->nwData->sInfo & 0xC0) >> 6;

         if (ssf != SSF_NAT)  /* not a national network */
            ucb->imp.val = spCb.spMsgImp.defUdtImp;
         else                 /* national network */
         {
            if (ucb->nwData->sioPrioImpPres == TRUE)
               ucb->imp.val = ucb->nwData->sioPrioImp[(U8) ucb->ud->prior];
            else
               ucb->imp.val = spCb.spMsgImp.defUdtImp;
         }
      } /* if (ucb->imp.pres == NOTPRSNT) */

      /* find restriction */
      ret = spFindRestriction(ucb->rCb, ucb->imp.val);
      if (ret == SP_DISCARD)
      {
         /* message can not be forwarded due to traffic limitation,
          * return message
          */
         spReturnMsg(ucb, (U8) RTC_NETCONG, mBuf);
         RETVOID;
      } /* if (ret == SP_DISCARD) */
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */
 
#ifdef SP_GNP
   /* perform calling party address treatment for generic numbering plan */
   /* sp045.302 - addition - pass ptr to network CB */
   ret = spCgAddrTreatment(&ucb->ud->cgAddr, inSsf, outSsf, ucb->nwData,
                           &ucb->outNwData);
   if (ret != SP_OK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP080, (ErrVal) ERRZERO,
                 "Failure in calling party address treament");
      /* return message */
      spReturnMsg(ucb, (U8) RTC_UNQUAL, mBuf);
   }
#endif /* SP_GNP */

   /* sp045.302 - modification - replacing nwData with outNwData */
   /* now that there is no chance of the message being returned set opc */
   ucb->opc = ucb->outNwData->selfPc;

   /* increment appropriate statistics */
   if (flag & SP_BRT)
      ucb->sap->sts.msgTxBSS++;

   spLiSegAndSendData(ucb, mBuf);

   RETVOID;   
} /* spLiHndlClss1 */

  
/*
*
*       Fun:   spHndlStatInd
*
*       Desc:  Handle Errors and Unit Data Service messages destined for
*              upper interface.
*
*       Ret:   None
*
*       Notes: If the message originated from upper layer, the
*              user address must be the calling address. If it
*              came from the lower layer (UDatSrv), it must be
*              the called address.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spHndlStatInd
(
SpUdCb *ucb,         /* unit data control block */
RCause rc,           /* return cause */
Buffer *mBuf         /* the message buffer */
)
#else
PUBLIC Void spHndlStatInd(ucb, rc, mBuf)
SpUdCb *ucb;         /* unit data control block */
RCause  rc;          /* return cause */
Buffer *mBuf;        /* the message buffer */
#endif
{
   U16 repCause;     /* cause for sccp report */

   TRC2(spHndlStatInd)

   /* initialize cause with unknown, for sccp report
    * is not generated in ecah of the return causes.
    */
   repCause = LCM_CAUSE_UNKNOWN;

   /* update statistics and send sccp error report to LM based on
    * return cause, only if the message is originated locally.
    */
   if (ucb->opc == ucb->nwData->selfPc)
   {
      switch (rc)
      {
         case RTC_NTBADADDR:
            spCb.sts.rfNTASN++;
            repCause = LSP_CAUSE_RTF_NTBADADDR;
            break;
         case RTC_NTSPECADDR:
            spCb.sts.rfNTSA++;
            repCause = LSP_CAUSE_RTF_NTSPECADDR;
            break;
         case RTC_SSCONG:
            spCb.sts.rfSsnCong++;
            repCause = LSP_CAUSE_RTF_SSCONG;
            break;
         case RTC_SSFAIL:
            spCb.sts.rfSsnFail++;
            repCause = LSP_CAUSE_RTF_SSFAIL;
            break;
         case RTC_UNEQUIP:
            spCb.sts.rfUnequip++;
            repCause = LSP_CAUSE_RTF_UNEQUIP;
            break;
         case RTC_NETFAIL:
            spCb.sts.rfNetFail++;
            repCause = LSP_CAUSE_RTF_NETFAIL;
            break;
         case RTC_NETCONG:
            repCause = LSP_CAUSE_RTF_NETCONG;
            break;
         case RTC_UNQUAL:
            spCb.sts.rfUnknown++;
            break;
         case RTC_HOPVIOLATE:   /* fall through */
         case RTC_HOPVIOLATE2:
            spCb.sts.rfHopViolate++;
            repCause = LSP_CAUSE_HOP_VIOLATE;
            break;
         case RTC_NOREASSEMB:
            spCb.sts.reassemErr++;
            repCause = LSP_CAUSE_REASM_OUTSEQ;
            break;
         case RTC_SEGFAILURE:
            repCause = LSP_CAUSE_SEGFAIL_LARGE;
            break;
         case RTC_INVINSRTREQ:
            spCb.sts.rfInvInsRtReq++;
            break;
         case RTC_INVISNIRTREQ:
            spCb.sts.rfInvIsniRtReq++;
            break;
         case RTC_ISNICONRTFL:
            spCb.sts.rfIsniConRtFl++;
            break;
         case RTC_REDISNICONRT:
            spCb.sts.rfRedIsniRtReq++;
            break;
         case RTC_UNISNIID:
            spCb.sts.rfUnIsniId++;
            break;
         default:
            break;
      } /* switch (rc) */
   } /* if (ucb->opc == ...selfPc) */

   /* generate sccp error performance report if repCause is not unknown */
   if (repCause != LCM_CAUSE_UNKNOWN)
   {
      SpReport spRep;   /* sccp error perf/subsyetem availability report */

      cmZero((U8 *) &spRep, sizeof(SpReport));

      /* fill spReport parameters */
      /* sp045.302 - modification - if the return cause is  RTC_NTBADADDR, 
       * RTC_RTC_NTSPECADDR or RTC_NOREASSEMB use incoming network(nwData) CB
       * else use the outgoing network CB (outNwData).
       */
      /* fill spReport parameters */
      if ((rc == RTC_NTBADADDR) || (rc == RTC_NTSPECADDR)
           || (rc == RTC_NOREASSEMB))
         spRep.nwId = ucb->nwData->nwId;
      else
         spRep.nwId = ucb->outNwData->nwId;
      spRep.sw = ucb->nwData->variant;
      cmCopySpAddr(&ucb->ud->cdAddr, &spRep.cdPa);
      cmCopySpAddr(&ucb->ud->cgAddr, &spRep.cgPa);

      /* fill segmentation local reference, if report
       * is for reassembly failure
       */
      if (repCause == LSP_CAUSE_REASM_OUTSEQ)
         spRep.segLr = (U32) ucb->ref;

      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, repCause, &spRep);
   }

   /* check return on error flag */
   if (ucb->ud->qos.retOpt != REC_ROE)
   {
      /* Drop the message, no return on error flag */
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP: Dropping Message (return cause = %d)\n", rc));
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* check the user is bound and is not prohibited - required
    * for incoming network msgs
    */
   if ((ucb->sap->status & SP_BND) && !(ucb->sap->status & SP_PROH))
   {
      /* invoke status indication primitive to upper user */
      /* 
       * ucb->opc will always be filled as we pass it in teh SpUiSptStaInd
       * primitive.
       */
      if (ucb->opc == ucb->nwData->selfPc)
      {
         SpAddr tmpAddr;

         /* Switch cgAddr and cdAddr if message is local */
         cmCopySpAddr(&ucb->ud->cdAddr, &tmpAddr);
         cmCopySpAddr(&ucb->ud->cgAddr, &ucb->ud->cdAddr);
         cmCopySpAddr(&tmpAddr, &ucb->ud->cgAddr);
      }
      (Void) SpUiSptStaInd(&ucb->sap->pst, ucb->sap->suId, ucb->opc, 
                           ucb->ud, rc, mBuf);
   }
   RETVOID;  
} /* end of spHndlStatInd */


/*
 *
 *       Fun:   spDelvUDatDown
 *
 *       Desc:  Deliver UDT and XUDT messages to MTP3. This includes the 
 *              data messages as well as as management messages.
 *              This function also calculate the sls for Class 0 messages. 
 *              Sls for Class 0 messages ONLY shouldnt be caculated outside 
 *              this function.
 *
 *       Ret:   None.
 *
 *       Notes: If this function is used to transmit user data, then the global 
 *              statistics (for that class) has to be incremented. If this 
 *              function is used to transmit the management messages (we just 
 *              update the glb statistics for UDT messages before this fn is 
 *              called.. CLass sts couners are left untouched.
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void spDelvUDatDown
(
SpUdCb *ucb,         /* unit data control block */
U8 from,             /* FROM_UPPER | FROM_LOWER, */
Buffer *mBuf         /* message buffer */
)
#else
PUBLIC Void spDelvUDatDown(ucb, from, mBuf)
SpUdCb *ucb;         /* unit data control block */
U8 from;             /* FROM_UPPER | FROM_LOWER, */
Buffer *mBuf;        /* message buffer */
#endif
{
   SrvInfo sInfo;    /* service info octet */

   TRC2(spDelvUDatDown)

#ifndef SP_CFGMG
   UNUSED(from);
#else
   /* check to see management message should appear */
   if ((!spCb.spCfg.mngmntOn) && (from == FROM_UPPER) 
       && (ucb->ud->cgAddr.ssn == SS_SCCPMNGT))
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP081, (ErrVal) ERRZERO,
                 "management message received");
      spDropMsg(&mBuf);  /* Drop message */
      RETVOID;
   }
#endif /* SP_CFGMG */

   /* find service info octet */
   if (ucb->ud->cdAddr.ssfPres)
      sInfo = ((ucb->ud->cdAddr.ssf << 6) | SCCP_SI);
   else
      sInfo = ucb->nSap->nwData->sInfo;

   if (ucb->ud->qos.pClass == PCLASS0)
      ucb->sls = spGetSls(ucb->nwData, ucb->dpc);
   else
   {
      /* sp020.302 - addition - if message is from upper user and class 1
       * then derive SLS again so that slsMask can be used from rCb to use
       * 5 or 8 bits sls in case of ANSI and BELLCORE networks. For message
       * of class 1 and incoming from network, same sls is being used as in
       * incoming message to maintain sequencing
       */
      if (from == FROM_UPPER)
      {
         ucb->sls = ucb->ud->sc & ucb->rCb->slsMask;
      }
   }

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "SCCP - delivering message on sls %d pc = %#lx\n", ucb->sls,
          ucb->dpc));

   if (!(ucb->nSap->status & SP_BND))
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP082, (ErrVal) ERRZERO,
                 "NSAP unbound");
      spDropMsg(&mBuf);
      RETVOID;
   }

   /*BEGIN:add by wanglijun.*/
   SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
            "********SCCP send unitdata msg to lower layer, spId(%d), opc(%ld), dpc(%ld)*******\n",
            ucb->nSap->spId, ucb->nwData->selfPc, ucb->dpc));
   /*END:add by wanglijun*/

   SpLiSntUDatReq(&ucb->nSap->pst, ucb->nSap->spId, ucb->nwData->selfPc,
                  ucb->dpc, sInfo, ucb->sls, (Priority) ucb->ud->prior, mBuf);
   RETVOID;
} /* spDelvUDatDown */

  
/*
*
*       Fun:   spReturnMsg
*
*       Desc:  return a message to a user or the net.
*
*       Ret:   ROK   - ok
*
*       Notes: Return an undeliverable Unit Data Message to
*              the called address in the mBuf in the form of
*              an Unit Data Service Message.
*              Decode, reorder and send...
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spReturnMsg
(
SpUdCb *ucb,           /* unit data control block */
U8 reason,             /* reason */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC Void spReturnMsg(ucb, reason, mBuf)
SpUdCb *ucb;           /* unit data control block */
U8 reason;             /* reason */
Buffer *mBuf;          /* message buffer */
#endif
{
   SpAddr origCgAddr;  /* original calling address */
   SpAddr origCdAddr;  /* original callled address */
   SrvInfo sInfo;      /* sub-service info */
   SpRteCb *rCb;       /* Pointer to route control Block */
   SpRteKey rKey;      /* route key */
   U16 repCause;       /* cause of sccp report */

   TRC2(spReturnMsg)

   /* initialize cause with unknown, for sccp report
    * is not generated for each of the return causes.
    */
   repCause = LCM_CAUSE_UNKNOWN;

   /* update statistics */
   switch (reason)
   {
      case RTC_NTBADADDR:
         spCb.sts.rfNTASN++;
         repCause = LSP_CAUSE_RTF_NTBADADDR;
         break;
      case RTC_NTSPECADDR:
         spCb.sts.rfNTSA++;
         repCause = LSP_CAUSE_RTF_NTSPECADDR;
         break;
      case RTC_SSCONG:
         spCb.sts.rfSsnCong++;
         repCause = LSP_CAUSE_RTF_SSCONG;
         break;
      case RTC_SSFAIL:
         spCb.sts.rfSsnFail++;
         repCause = LSP_CAUSE_RTF_SSFAIL;
         break;
      case RTC_UNEQUIP:
         spCb.sts.rfUnequip++;
         repCause = LSP_CAUSE_RTF_UNEQUIP;
         break;
      case RTC_NETFAIL:
         spCb.sts.rfNetFail++;
         repCause = LSP_CAUSE_RTF_NETFAIL;
         break;
      case RTC_NETCONG:
         repCause = LSP_CAUSE_RTF_NETCONG;
         break;
      case RTC_UNQUAL:
         spCb.sts.rfUnknown++;
         break;
      case RTC_HOPVIOLATE:
      case RTC_HOPVIOLATE2:
         spCb.sts.rfHopViolate++;
         repCause = LSP_CAUSE_HOP_VIOLATE;
         break;
      case RTC_NOREASSEMB:
         spCb.sts.reassemErr++;
         repCause = LSP_CAUSE_REASM_OUTSEQ;
         break;
      case RTC_SEGFAILURE:
         repCause = LSP_CAUSE_SEGFAIL_LARGE;
         break;
      case RTC_INVINSRTREQ:
         spCb.sts.rfInvInsRtReq++;
         break;
      case RTC_INVISNIRTREQ:
         spCb.sts.rfInvIsniRtReq++;
         break;
      case RTC_ISNICONRTFL:
         spCb.sts.rfIsniConRtFl++;
         break;
      case RTC_REDISNICONRT:
         spCb.sts.rfRedIsniRtReq++;
         break;
      case RTC_UNISNIID:
         spCb.sts.rfUnIsniId++;
         break;
      default:
         break;
   } /* switch (reason) */

   /* generate sccp error perf/subsystem availability report if
    * report cause is not unknown
    */
   if (repCause != LCM_CAUSE_UNKNOWN)
   {
      SpReport spRep;     /* sccp error perf/subsystem availability report */

      cmZero((U8 *) &spRep, sizeof(SpReport));

     /* sp045.302 - modification - if the reason is  RTC_NTBADADDR, 
      * RTC_RTC_NTSPECADDR or RTC_NOREASSEMB use incoming network(nwData) CB
      * else use the outgoing network CB (outNwData).
      */
      /* fill spReport parameters */
      if ((reason == RTC_NTBADADDR) || (reason == RTC_NTSPECADDR)
           || (reason == RTC_NOREASSEMB))
         spRep.nwId = ucb->nwData->nwId;
      else
         spRep.nwId = ucb->outNwData->nwId;
      spRep.sw = ucb->nwData->variant;
      cmCopySpAddr(&ucb->ud->cdAddr, &spRep.cdPa);
      cmCopySpAddr(&ucb->ud->cgAddr, &spRep.cgPa);

      /* fill segmentation local reference, if report
       * is for reassembly failure
       */
      if (repCause == LSP_CAUSE_REASM_OUTSEQ)
         spRep.segLr = (U32) ucb->ref;

      spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, repCause, &spRep);
   }

   /* The idea here is to decode
    * the packaged message, switch the called and calling address,
    * set the message type to M_UNITDATASRV, and the return cause
    * to "reason", and finally to deliver it back to the sender.
    */
  
   if (ucb->ud->qos.retOpt == REC_NSO)
   {
      /* Drop Message */
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* store the calling address which would be used as return address */
   cmCopySpAddr(&ucb->ud->cgAddr, &origCgAddr);
   cmCopySpAddr(&ucb->ud->cdAddr, &origCdAddr);
   
   /* switch the calling address */
   ucb->ud->cgAddr.sw = ucb->nSap->nwData->variant;

   /* replace called address with orignial calling address */
   cmCopySpAddr(&origCgAddr, &ucb->ud->cdAddr);

   /* replace calling address with orignial called address */
   cmCopySpAddr(&origCdAddr, &ucb->ud->cgAddr);


   /* form the route key and search the route type */
   rKey.k1.dpc = ucb->opc;
   rKey.k1.nwId = ucb->nwData->nwId;

   /* find route */
   spFindRte(&spCb.rteCp, &rCb, &rKey, 0);

   /* on GSM route, UDTS is not sent */
   if((rCb == (SpRteCb *) NULLP) || (rCb->swtch == LSP_SW_GSM0806))
   {
      /* drop message */
      spDropMsg(&mBuf);
      RETVOID;
   }

   ucb->ud->qos.retOpt = reason; 

   /* niInd unused */
   ucb->ud->cgAddr.niInd = origCdAddr.niInd; 
   ucb->ud->cgAddr.pcInd = TRUE;
   ucb->ud->cgAddr.pc = ucb->nwData->selfPc;
   switch (ucb->dataType)
   {
      case M_LUNITDATA:
         ucb->hopCntr = ucb->nSap->nwData->defHopCnt;
         mBuf = spEncCLMsg(M_LUNITDATASRV, ucb, &mBuf);
         spCb.sts.luDataSrvTx++;
         break;
      case M_XUNITDATA:
         ucb->hopCntr = ucb->nSap->nwData->defHopCnt;
         /* initialize message type interworking as false */
         ucb->spMti.pres = FALSE;
         mBuf = spEncCLMsg(M_XUNITDATASRV, ucb, &mBuf);
         spCb.sts.xuDataSrvTx++;
         break;
      case M_UNITDATA:
         mBuf = spEncCLMsg(M_UNITDATASRV, ucb, &mBuf);
         spCb.sts.uDataSrvTx++;
         break;
      default:
         break;
   }

   if (mBuf == (Buffer*)NULLP)
   {
      /* return calling and called addresses back to the original values */
      /* May be required to send SSP to original calling party           */
      cmCopySpAddr(&origCgAddr, &ucb->ud->cgAddr);
      cmCopySpAddr(&origCdAddr, &ucb->ud->cdAddr);
      RETVOID;
   }

   /* If we're here, everything is ok, we need to send this
    * message on its merry way...
    */
#ifdef DEBUGP 
   if (ucb->dataType == M_XUNITDATA)
   {
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP Returning bad message to %lx [XUNITDATASRV]\n", ucb->opc)); 
   } 
   else
   {
      if (ucb->dataType == M_LUNITDATA)
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP Returning bad message to %lx [LUNITDATASRV]\n", 
                 ucb->opc)); 
      }
      else
      {
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP Returning bad message to %lx [UNITDATASRV]\n", ucb->opc)); 
      }
   }
#endif /* DEBUGP */

   if (ucb->ud->cdAddr.ssfPres)
      sInfo = ((ucb->ud->cdAddr.ssf << 6) | SCCP_SI);
   else
      sInfo = ucb->nSap->nwData->sInfo;

   if (!(ucb->nSap->status & SP_BND))
   {
      spDropMsg(&mBuf);
      RETVOID;
   }

   ucb->sls = spGetSls(ucb->nwData, ucb->opc);

   SpLiSntUDatReq(&ucb->nSap->pst, ucb->nSap->spId, ucb->nwData->selfPc,
                  ucb->opc, sInfo, ucb->sls, (Priority)0, mBuf);

  /* 
   * return calling and called addresses back to the original values
   * May be required to send SSP to original calling party
   */
   cmCopySpAddr(&origCgAddr, &ucb->ud->cgAddr);
   cmCopySpAddr(&origCdAddr, &ucb->ud->cdAddr);

   RETVOID;
} /* spReturnMsg */

  
/*
*
*       Fun:   spStartSsnCbTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spStartSsnCbTmr
(
SpSsnCb *cb,
S16 evnt
)
#else
PUBLIC Void spStartSsnCbTmr(cb, evnt)
SpSsnCb *cb;
S16 evnt;
#endif
{
   CmTmrArg arg;
  
   TRC2(spStartSsnCbTmr)
  
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP083, (ErrVal) cb,
                 "spStartSsnCbTmr() - invalid mType");
   }
#endif /* ERRCLASS */

   arg.tq = spCb.spSsnTq;
   arg.tqCp = &spCb.spSsnTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = evnt;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXSSNTMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)
      cmPlcCbTq(&arg);
   RETVOID;
} /* spStartSsnCbTmr */


/*
*
*       Fun:   spRmvSsnCbTq
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvSsnCbTq
(
SpSsnCb *cb,           /* connection control block */
U8 ev                  /* event */
)
#else
PUBLIC Void spRmvSsnCbTq(cb, ev)
SpSsnCb *cb;           /* connection control block */
U8 ev;                 /* event */
#endif
{
   U8 tNum;
   CmTmrArg arg;
   Bool found;

   TRC2(spRmvSsnCbTq)

   found = FALSE;

   for (tNum = 0; tNum < MAXSSNTMR; tNum++)
   {
      if (cb->timers[tNum].tmrEvnt == ev)
      {
         found = TRUE;
         break;
      }
   }
   if (found == FALSE)
      RETVOID;

   arg.tq = spCb.spSsnTq;
   arg.tqCp = &spCb.spSsnTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tNum;
   arg.max = MAXSSNTMR;
   cmRmvCbTq(&arg);
   RETVOID;
} /* end of spRmvSsnCbTq */


/*
*
*       Fun:   spPrcSsnCbTq
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy2.c
*
*/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 spPrcSsnCbTq
(
ProcId  proc,
Ent     ent,
Inst    inst
)
#else
PUBLIC S16 spPrcSsnCbTq(proc, ent, inst)
ProcId  proc;
Ent     ent;
Inst    inst;
#endif
#else /* SS_MULTIPLE_PROCS */
#ifdef ANSI
PUBLIC S16 spPrcSsnCbTq
(
Void
)
#else
PUBLIC S16 spPrcSsnCbTq()
#endif
#endif /* SS_MULTIPLE_PROCS */
{
   TRC2(spPrcSsnCbTq);
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(proc, ent, inst, (Void **)&spCbPtr)) != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spPrcSsnCbTq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        
#endif

#ifdef ZP
   if (!zpCb.freezeTmr)
#endif /* ZP */
   {
      cmPrcTmr(&spCb.spSsnTqCp, spCb.spSsnTq, spSsnCbTmrEvnt);
      cmPrcTmr(&spCb.spSapTqCp, spCb.spSapTq, spSapCbTmrEvnt);
   }
   RETVALUE(ROK);
} /* end of spPrcSsnCbTq */

  
/*
*
*       Fun:   spSsnCbTmrEvnt
*
*       Desc:  Subsystem control block timer event
*
*       Ret:   None
*
*       Notes: Whenever a timer expires, send a mangement message
*              and reset the timer...
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spSsnCbTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spSsnCbTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{
   SpSsnCb *cb;
   SpMngtCb mcb;

   TRC2(spSsnCbTmrEvnt)

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP084, (ErrVal) 0, 
                 "spSsnCbTmrEvnt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */

   cb = (SpSsnCb *) cbp;

#ifdef DEBUGP
   if (evnt == TMR_SST)
   {
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP -- SST FIRED: pc = %lx, ssn = %d\n", cb->rCb->dpc, cb->ssn));
   }
   else
   {
      SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
             "SCCP -- SRT FIRED: pc = %lx, ssn = %d\n", cb->rCb->dpc, cb->ssn));
   }
#endif /* DEBUGP */

   /* send a subsystem status test message */
   if (cb->nmbBpc)
      mcb.smi = SMI_DUP;
   else
      mcb.smi = SMI_SOL;
   
   mcb.nwData = cb->rCb->nSap->nwData;

   switch (evnt)
   {
      case TMR_SST:
         /* sp042.302 - addition - if we are sby then restart the timer */
#ifdef ZP
         if (zpCb.rsetCbList[cb->rCb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = cb->rCb->nSap->nwData->defSstTmr.enb;
            cb->tmr.val = cb->rCb->nSap->nwData->defSstTmr.val;
            spStartSsnCbTmr(cb, TMR_SST);
            RETVOID;
         }
#endif /* ZP */
      
         /* sp018.302 - modification - start timer before sending message */
         cb->tmr.enb = TRUE;
         spStartSsnCbTmr(cb, evnt); /* restart timer */

         mcb.dpc = cb->rCb->dpc;
         mcb.apc = cb->rCb->dpc;
         mcb.assn = cb->ssn;
         mcb.frmt = SCMG_SST;
         spSendMngtMsg(&mcb);
         break;


      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP085, (ErrVal) evnt,
                     "spSsnCbTmrEvnt invalid event");
         RETVOID;
   }
   
   RETVOID;
} /* spSsnCbTmrEvnt */

  
/*
*
*       Fun:   spStartSapCbTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spStartSapCbTmr
(
SpSapCb *cb,
U8 event
)
#else
PUBLIC Void spStartSapCbTmr(cb, event)
SpSapCb *cb;
U8 event;
#endif
{
   CmTmrArg arg;
  
   TRC2(spStartSapCbTmr)
  
   arg.tq = spCb.spSapTq;
   arg.tqCp = &spCb.spSapTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = event;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXSAPTMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)
      cmPlcCbTq(&arg);
   RETVOID;

} /* end of spStartSapCbTmr */


/*
*
*       Fun:   spRmvSapCbTq
*
*       Desc:  
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented Control
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvSapCbTq
(
SpSapCb *cb,           /* connection control block */
U8 event              /* event */
)
#else
PUBLIC Void spRmvSapCbTq(cb, event)
SpSapCb *cb;           /* connection control block */
U8 event;              /* event */
#endif
{
   U8 tNum;
   CmTmrArg arg;
   Bool found;

   TRC2(spRmvSapCbTq);

   found = FALSE;

   for (tNum = 0; tNum < MAXSAPTMR; tNum++)
   {
      if (cb->timers[tNum].tmrEvnt == event)
      {
         found = TRUE;
         break;
      }
   }
   if (found == FALSE)
      RETVOID;
   arg.tq = spCb.spSapTq;
   arg.tqCp = &spCb.spSapTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tNum;
   arg.max = MAXSAPTMR;
   cmRmvCbTq(&arg);
   RETVOID;
} /* end of spRmvSapCbTq */

  
/*
*
*       Fun:   spSapCbTmrEvnt
*
*       Desc:  Check control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spSapCbTmrEvnt
(
PTR cbp,           /* control block pointer */
S16 evnt           /* event */
)
#else
PUBLIC Void spSapCbTmrEvnt(cbp, evnt)
PTR cbp;          /* control block pointer */
S16 evnt;          /* event */
#endif
{
   SpSapCb *cb;
   TRC2(spSapCbTmrEvnt)

   UNUSED(evnt);

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP086, (ErrVal) 0, 
                 "spSapCbTmrEvnt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */
  
   cb = (SpSapCb*)cbp;

   switch (evnt)
   {
      case TMR_GRT:
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = TRUE;
            cb->tmr.val = cb->nwData->defCrdTmr.val;
            spStartSapCbTmr(cb, TMR_GRT);
            RETVOID;
         }
#endif /* ZP */
         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "SCCP -- GRANT EXPIRED\n"));
         if (cb->status & SP_GRNT)
         {
            cb->status ^= SP_GRNT;
#ifdef ZP
            zpRunTimeUpd(ZP_SP_SAPCB, (Void *)cb, CMPFTHA_UPDTYPE_NORMAL, 
                         CMPFTHA_ACTN_MOD);
#endif /* ZP */

         }
#if (ERRCLASS & ERRCLS_INT_PAR)
         else
            SPLOGERROR(ERRCLS_INT_PAR, ESP087, (ErrVal) cb->status,
                       "spSapCbTmrEvnt invalid sap status");
#endif /* ERRCLASS */
         break;

      case TMR_IGN:
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = TRUE;
            cb->tmr.val = cb->nwData->defIgnTmr.val;
            spStartSapCbTmr(cb, TMR_IGN);
            RETVOID;
         }
#endif /* ZP */
         
         if (cb->status & SP_IGNR)
         {
            SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                   "SCCP -- IGNORE EXPIRED\n"));
            cb->status ^= SP_IGNR;
#ifdef ZP
            zpRunTimeUpd(ZP_SP_SAPCB, (Void *)cb, CMPFTHA_UPDTYPE_NORMAL,
                         CMPFTHA_ACTN_MOD);
#endif /* ZP */
         }
#if (ERRCLASS & ERRCLS_INT_PAR)
         else
            SPLOGERROR(ERRCLS_INT_PAR, ESP088, (ErrVal) cb->status,
                       "spSapCbTmrEvnt invalid sap status");
#endif /* ERRCLASS */
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP089, (ErrVal) evnt,
                    "spSapCbTmrEvnt invalid event");
         break;
   }
#ifdef ZP
      zpUpdPeer();
#endif /* ZP */
      RETVOID;
} /* end of spSapCbTmrEvnt */

  
/*
*
*       Fun:   spFndLSapSpidOpc
*
*       Desc:  Find lower sap based on SpId and Opc
*
*       Ret:   SpNSapCb*   - ok
*              NULLP       - failed
*           
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC SpNSapCb* spFndLSapSpidOpc
(
SpId spId,
Dpc opc
)
#else
PUBLIC SpNSapCb* spFndLSapSpidOpc (spId, opc)
SpId spId;
Dpc opc;
#endif
{
   REG1 U8 i;
   SpNSapCb *nSap;
  
   TRC2(spFndLSapSpidOpc)
  
   nSap = (SpNSapCb*)NULLP;
   for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
   {
      if (spCb.nSapList[i] != (SpNSapCb*)NULLP)      /* validate config */
      {
         if ((spCb.nSapList[i]->spId == spId) &&
             (spCb.nSapList[i]->nwData->selfPc == opc))
         {
            nSap = spCb.nSapList[i];
            break;
         }
      }
   }
   /*
    * validate network sap
    */
   /* sp003.302 - if there is no valid nSap we should return null
    * pointer at this time 
    */
   if ((nSap == (SpNSapCb *) NULLP) || (!(nSap->status & SP_BND)))
      RETVALUE((SpNSapCb *) NULLP);
   else
      RETVALUE(nSap);
} /* end of spFindLowerSapSpidOpc */


/* sp003.302 - added a nSap control block pointer as a parameter to 
 * spFindLowerSapSid so we can check the different situation of nSap
 * via returned value 
 */
/*
*
*       Fun:   spFindLowerSapSid
*
*       Desc:  Find Lower sap with suid
*
*       Ret:   ROK       - ok
*              ROKDNA    - ok but not available
*              NULLP     - failed
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spFindLowerSapSid
(
SuId suId,
SpNSapCb **nSap
)
#else
PUBLIC S16 spFindLowerSapSid(suId, nSap)
SuId suId;
SpNSapCb **nSap;
#endif
{
   TRC2(spFindLowerSapSid)

   /* sp011.302 check for NULL sap */ 
   if (spCb.nSapList == (SpNSapCb **)NULLP)
      RETVALUE (RFAILED);
 
   *nSap = *(spCb.nSapList + suId);
   /*
    * validate network sap
    */
   /* sp003.302 - if lower sap is configured but not bind then return
    * nSap not available instead of failure
    */
   if (*nSap == NULLP)
      RETVALUE (RFAILED);
   if (!((*nSap)->status & SP_BND))
      RETVALUE (ROKDNA);
   else
      RETVALUE (ROK);
} /* end of spFindLowerSapSid */

  
/*
*
*       Fun:   spLiHndlUDatSrv
*
*       Desc:  Handle a Unit Data Service Message from lower interface.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spLiHndlUDatSrv
(
SpUdCb *ucb,      /* unit data control block */
Buffer *mBuf      /* data buffer */
)
#else
PUBLIC Void spLiHndlUDatSrv(ucb, mBuf)
SpUdCb *ucb;      /* unit data control block */
Buffer *mBuf;     /* data buffer */
#endif
{
   S16 ret;                    /* return value */
   SpAddr cdAddr[MAXENTITIES]; /* called address - outgoing sccp entities */
   U8 numEntity;               /* number of outgoing SCCP entities */
   U8 nextEntity;              /* next SCCP entity to be selected */
   Bool foundRoute;            /* flag to indicate route found or not */
   U8 mode;                    /* mode of operation of SCCP entities */
   Bool noCplng;               /* coupling flag, though not valid in Con'less */
   U8 i;                       /* loop counter */
   U8 flag;                    /* flag for backup routing */
   U8 retOpt;                  /* return option */
   U16 repCause;               /* sccp error performance report cause */

   TRC2(spLiHndlUDatSrv)

   /* sp044.302 - addition - Initialization of Local Variables */   
   repCause = LCM_CAUSE_UNKNOWN;   
  


   {
      /* sp047.302 - Addition - copy selfPc into usb and set pcInd as TRUE */
      /* before GT translations, set incoming pc as self pc.
       */
      ucb->ud->cdAddr.pc = ucb->nwData->selfPc;
      ucb->ud->cdAddr.pcInd = TRUE;

      /* sp045.302 - modification - replacing selfPc with ptr to nwCb 
       * of incoming network and ptr to outgoing network CB. 
       */
      ret = spResolveAddr(&ucb->ud->cdAddr, PCLASS0, &numEntity, &nextEntity,
                          &mode, &cdAddr[0], &noCplng, ucb->nwData,
                          &ucb->outNwData);
      if (ret == SP_ERROR)
      {
         SpReport spRep;    /* sccp error perf report */

         /* translation error, drop mesage */
         spDropMsg(&mBuf);

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         spRep.nwId = ucb->nwData->nwId;
         spRep.sw = ucb->nwData->variant;
         cmCopySpAddr(&ucb->ud->cdAddr, &spRep.cdPa);
         cmCopySpAddr(&ucb->ud->cgAddr, &spRep.cgPa);

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NTSPECADDR,
                          &spRep);

         RETVOID;
      }
      else
      {
         /* Unit data service message will be handled same as class 0
          * message regarding selection of outgoing sccp entities. Hence
          * if mode of operation of sccp entities is dominant then first
          * the availability of sccp entity at index 0 is being checked.
          * Hence set nextEntity as zero. In case of loadshare mode the
          * first sccp entity to be checked for availability is the entity
          * at an index nextEntity, returned by spResolveAddr.
          */
         if (mode == DOMINANT)
            nextEntity = 0;
      }
   }

   /* initialize foundRoute to FALSE */
   foundRoute = FALSE;

   /* select outgoing SCCP entity */
   for (i = 0; i < numEntity && foundRoute == FALSE; i++)
   {
      ret = ROK;
      /* sp045.302 - addition - check the variants of incoming and outgoing 
       * networks. if network id's are different then variant of
       * the two networks must be same. if not then send alarm to LM and 
       * status indiation up.
       */
      if ((ucb->nwData->nwId != ucb->outNwData->nwId) && 
         (ucb->nwData->variant != ucb->outNwData->variant))
      {
         /* translation error, drop mesage */
         spDropMsg(&mBuf);

         SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
                "spLiHndlClss1: Varaints are not same for incoming and outgoing\
                 networks : incoming network id = %d, outgoing network id = %d\
                 and the variant of incoming network is %d and variant of\
                 outgoing network is %d\n", ucb->nwData->nwId,
                 ucb->outNwData->nwId, ucb->nwData->variant,
                 ucb->outNwData->variant));

         RETVOID;
      }
      /* sp045.302 - modification - using network CB of the outgoing network */
      ret = spCheckRoute(ucb->outNwData, &cdAddr[nextEntity], 0, PCLASS0,
                            &ucb->rCb, &flag, &ucb->sap, FROM_LOWER);
      switch (ret)
      {
         case SP_LOCAL:
            /* sp047.302 - Addition - If the Sap has the msgInterceptEnabled
             * flag set then copy the origCdAddr into ucb else copy it from 
             * cdAddr.
             */
            if (ucb->sap->msgInterceptEnabled == TRUE)
            {
               cmCopySpAddr(&ucb->origCdAddr, &ucb->ud->cdAddr);
               cmCopySpAddr(&ucb->origCgAddr, &ucb->ud->cgAddr);
            }
            else
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            retOpt = ucb->ud->qos.retOpt;
            ucb->ud->qos.retOpt = REC_ROE;
            spHndlStatInd(ucb, retOpt, mBuf);
            RETVOID;

         case SP_OK:
            /* route up; destination accessible */
               /* copy new called address into unit data event */
               cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            ucb->nSap = ucb->rCb->nSap;
            ucb->dpc = ucb->ud->cdAddr.pc;
            foundRoute = TRUE;
            break;

         case SP_UNEQUIP:  /* subsystem unequipped */
            /* increment statistics */
            spCb.sts.rfUnequip++;
            repCause = LSP_CAUSE_RTF_UNEQUIP;
            break;

         case SP_SSFAIL:   /* subsystem prohibited */
            /* increment statistics */
            spCb.sts.rfSsnFail++;
            repCause = LSP_CAUSE_RTF_SSFAIL;
            break;

         case SP_SPFAIL:   /* signalling point prohibited */
            /* increment statistics */
            spCb.sts.rfNetFail++;
            /* sp040.302 - addition - copy new called address into unit
             * data event.
             */
            cmCopySpAddr(&cdAddr[nextEntity], &ucb->ud->cdAddr);

            repCause = LSP_CAUSE_RTF_NETFAIL;
            break;

         default:
            repCause = LCM_CAUSE_UNKNOWN;
            break;
      } /* switch (ret) */

      /* increment nextEntity in modulo fashion with numEntity */
      nextEntity++;
      if (nextEntity >= numEntity)
         nextEntity = 0;
   } /* for (i = 0; i < numEntity && foundRoute == FALSE; i++) */

   if (foundRoute == FALSE)  /* route not found */
   {
      if (repCause != LCM_CAUSE_UNKNOWN)
      {
         SpReport spRep;        /* sccp error perf/subsys availability report */

         cmZero((U8 *) &spRep, sizeof(SpReport));
         /* sp045.302 - modification - replace nwData with outNwData to indicate
          * failure in reaching destination pc in the outgoing network.
          */
         spRep.nwId = ucb->outNwData->nwId;
         spRep.sw = ucb->outNwData->variant;
         cmCopySpAddr(&ucb->ud->cdAddr, &spRep.cdPa);
         cmCopySpAddr(&ucb->ud->cgAddr, &spRep.cgPa);

         /* generate report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, repCause, &spRep);
      }

      /* drop message */
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* check if message to be discarded due to traffic limitation.
    * Discard message due to traffic restriction only if the route
    * is ITU96 and traffic limitation mechansim is enabled
    */
   if ((ucb->rCb->swtch == LSP_SW_ITU96) && (spCb.spTrfLimFlag == TRUE))
   {
      /* if importance is not present in the received message,
       * then in case of national network find importance from
       * sio priority else assume default importance for the
       * the message but in any case do not mark presence of
       * importance so as not to encode importance in outgoing
       * message if its not present in incoming message.
       */
      if (ucb->imp.pres == NOTPRSNT)
      {
         U8 ssf;              /* sub-service field */

         if (ucb->ud->cdAddr.ssfPres)
            ssf = ucb->ud->cdAddr.ssf;
         else
            ssf = (ucb->nwData->sInfo & 0xC0) >> 6;

         if (ssf != SSF_NAT)  /* not a national network */
            ucb->imp.val = spCb.spMsgImp.defUdtSrvImp;
         else                 /* national network */
         {
            if (ucb->nwData->sioPrioImpPres == TRUE)
               ucb->imp.val = ucb->nwData->sioPrioImp[(U8) ucb->ud->prior];
            else
               ucb->imp.val = spCb.spMsgImp.defUdtSrvImp;
         }
      } /* if (ucb->imp.pres == NOTPRSNT) */

      /* find restriction */
      ret = spFindRestriction(ucb->rCb, ucb->imp.val);
      if (ret == SP_DISCARD)
      {
         SpReport spRep;       /* sccp error perf report */

         /* message can not be forwarded due to traffic limitation,
          * drop message
          */
         spDropMsg(&mBuf);

         /* fill sccp error report */
         cmZero((U8 *) &spRep, sizeof(SpReport));

         /* sp045.302 - modification - replace nwData with outNwData to indicate
          * failure in reaching destination pc in the outgoing network.
          */
         spRep.nwId = ucb->outNwData->nwId;
         spRep.sw = ucb->outNwData->variant;
         spRep.dpc = ucb->rCb->dpc;
         cmCopySpAddr(&ucb->ud->cgAddr, &spRep.cgPa);

         /* generate sccp error performance report */
         spSendLmSpReport(LSP_EVENT_ERROR_PERFORMANCE, LSP_CAUSE_RTF_NETCONG,
                          &spRep);

         RETVOID;
      } /* if (ret == SP_DISCARD) */
   } /* if ((...swtch == LSP_SW_ITU96) && (...spTrfLimFlag == TRUE)) */
 
   /* Destination node is remote and route is up */
   if (ucb->dataType == M_UNITDATASRV)
   {       
      /* encode UDTS */
      mBuf = spEncCLMsg(M_UNITDATASRV, ucb, &mBuf);

      /* increment statistics counter for UDTS sent */
      spCb.sts.uDataSrvTx++;
   }
   else
   {
      if (ucb->dataType == M_LUNITDATASRV)
      {
         if (((ucb->rCb->swtch == LSP_SW_ITU96)
             ) && (ucb->rCb->flag & LSP_NW_BROADBAND))
         {
            /* encode LUDTS */
            mBuf = spEncCLMsg(M_LUNITDATASRV, ucb, &mBuf);

            /* increment statistics counter for LUDTS sent */
            spCb.sts.luDataSrvTx++;
         }
         else
         {
            MsgLen cdLen;           /* called address length */
            MsgLen cgLen;           /* calling address length */
            MsgLen xudtsSize;       /* size to fit in one XUDTS */

            /* if route is not itu96, mark importance as not present */
            if (ucb->rCb->swtch != LSP_SW_ITU96)
               ucb->imp.pres = NOTPRSNT;

            cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                                 ucb->rCb->nSap->nwData->variant);
            cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                                 ucb->rCb->nSap->nwData->variant);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (cgLen == 0 || cdLen == 0)
            {
               SPLOGERROR(ERRCLS_DEBUG, ESP090, (ErrVal) 0,
                          "error calculating called/calling address length");
               RETVOID;
            }
#endif /* ERRCLASS */

#ifdef SS7_BELL05
#else
            xudtsSize = MAXNSAPMSGSIZE - XUDHDRLEN - cgLen - cdLen;

            /* mark presence of mti as not present */
            ucb->spMti.pres = NOTPRSNT;
#endif /* SS7_BELL05 */

            /* truncate message to fit into an XUDTS */
            spTruncateMsg(mBuf, xudtsSize);

            /* encode XUDTS */
            mBuf = spEncCLMsg(M_XUNITDATASRV, ucb, &mBuf);

            /* increment statistics counter for XUDTS sent */
            spCb.sts.xuDataSrvTx++;
         }
      } /* if (ucb->dataType == M_LUNITDATASRV) */
      else
      {
         /* if route is not itu96, mark importance as not present */
         if (ucb->rCb->swtch != LSP_SW_ITU96)
            ucb->imp.pres = NOTPRSNT;

         /* encode XUDTS */
         mBuf = spEncCLMsg(M_XUNITDATASRV, ucb, &mBuf);

         /* increment statistics counter for XUDTS sent */
         spCb.sts.xuDataSrvTx++;
      }
   } /* else-if (ucb->dataType == M_UNITDATASRV) */

   if (mBuf == (Buffer *) NULLP)
      RETVOID;
   /* sp045.302 - modification - replace the opc with the selfPc of the 
    * outgoing network.
    */
   ucb->opc = ucb->outNwData->selfPc;
   /* deliver unit data service message to lower layer */
   spDelvUDatDown(ucb, FROM_LOWER, mBuf);

   RETVOID;
} /* spLiHndlUDatSrv */

#ifdef SPTV2

#endif /* SPTV2 */
 

/*
*
*       Fun:   spValidateEvnt
*
*       Desc:  validate unit data event structure passed from upper interface.
*
*       Ret:   SP_OK   - ok
*              SP_ERROR - not ok
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC S16 spValidateEvnt
(
SpUdCb *ucb           /* unit data control block */
)
#else
PUBLIC S16 spValidateEvnt(ucb)
SpUdCb *ucb;            /* unit data control block */
#endif
{
   U8 adjFrmt;          /* adjusted gt format */

   TRC2(spValidateEvnt);
   
   /* validate protocol class */
   switch (ucb->ud->qos.pClass)
   {
      case PCLASS0:   /* protocol class 0; fall through */
      case PCLASS1:   /* protocl class 1 */
         break;
         
      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP098, (ErrVal) ucb->ud->qos.pClass,
                    "spValidateEvnt: invalid class");
         RETVALUE(SP_ERROR);
   } /* switch (...pClass) */

   /* validate return on error flag */
   switch (ucb->ud->qos.retOpt)
   {
      case REC_NSO:   /* no special option; fall through */
      case REC_ROE:   /* message return on error */
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP099, (ErrVal) ucb->ud->qos.retOpt,
                    "spValidateEvnt: invalid retOpt");
         RETVALUE(SP_ERROR);
   } /* switch (...retOpt) */

   /* validate mtp priority */
   if (ucb->ud->prior > SN_PRI3)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP100, (ErrVal) ucb->ud->qos.pClass,
                 "spValidateEvnt: invalid mtp prior");
      RETVALUE(SP_ERROR);
   }

   /* check presence of called address */
   if (!ucb->ud->cdAddr.pres)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP101, (ErrVal) 0,
                 "spValidateEvnt: Called address absent");
      RETVALUE(SP_ERROR);
   }

   /* validate called address switch */
   switch (ucb->ud->cdAddr.sw)
   {
      case SW_ITU:          /* fall through */
      case SW_CHINA:        /* fall through */
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP102, (ErrVal) ucb->ud->cdAddr.sw,
                    "spValidateEvnt: invalid cdAddr sw");
         RETVALUE(SP_ERROR);
   } /* switch (...sw) */

   /* We may want to verify the ssf, niInd in the cdAddr
      with the values stored in the network control block */

   /* validate routing indicator */
   switch (ucb->ud->cdAddr.rtgInd)
   {
      case RTE_SSN:   /* route on ssn */
      case RTE_GT:    /* route on GT */
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP103, (ErrVal) ucb->ud->cdAddr.rtgInd,
                    "spValidateEvnt: invalid rtgInd in called address");
         RETVALUE(SP_ERROR);
   } /* switch (...rtgInd) */
   
   /* insure that a global title exists when routing on gt, gt
    * format 0 means no GT is present in address
    */
   if ((ucb->ud->cdAddr.rtgInd == RTE_GT) && 
       (ucb->ud->cdAddr.gt.format == GTFRMT_0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP104, (ErrVal) 0,
                 "spValidateEvnt: inconsistent rtgInd and gt in cdAddr");
      RETVALUE(SP_ERROR);
   }
   
   /* insure proper info is available if routing on ssn */
   if (ucb->ud->cdAddr.rtgInd == RTE_SSN)
   {
      /* There must be a point code */
      if (ucb->ud->cdAddr.pcInd == FALSE)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP105, (ErrVal) 0,
                    "spValidateEvnt: inconsistent rtgInd and pcInd");
         RETVALUE(SP_ERROR);
      }

      /* There must be a subsystem number */
      if (ucb->ud->cdAddr.ssnInd == FALSE)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP106, (ErrVal) 0,
                    "spValidateEvnt: inconsistent rtgInd and ssnInd");
         RETVALUE(SP_ERROR);
      }
   } /* if (...rtgInd == RTE_SSN) */

   /* insure GT_FRMT is in the correct range */
      if (ucb->ud->cdAddr.gt.format > GTFRMT_4)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP108, (ErrVal) 0,
                    "spValidateEvnt: invalid gt format");
         RETVALUE(SP_ERROR);
      }

      adjFrmt = ucb->ud->cdAddr.gt.format;

   if (adjFrmt != GTFRMT_0)
   {
      /* if there is a GT it must have a length */
      if (!ucb->ud->cdAddr.gt.addr.length)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP109, (ErrVal) 0,
                    "spValidateEvnt: invalid gt len");
         RETVALUE(SP_ERROR);
      }
   }

   /* validate the global title in called address */
   switch (adjFrmt)
   {
      case GTFRMT_0:
         break;

      case GTFRMT_1:
      {
         if ((ucb->ud->cdAddr.gt.gt.f1.oddEven != TRUE) &&
             (ucb->ud->cdAddr.gt.gt.f1.oddEven != FALSE))
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP110, (ErrVal) 0,
                       "spValidateEvnt: invalid oddEven in gt format 1");
            RETVALUE(SP_ERROR);
         }

         /* validate nature of address indicator */
         switch (ucb->ud->cdAddr.gt.gt.f1.natAddr)
         {
            case NA_SUBNUM:      /* subscriber number */ 
            case NA_NATSIGNUM:   /* national significant number */
            case NA_INTNUM:      /* international number */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP111, (ErrVal) 0,
                          "spValidateEvnt: invalid natAddr in gt format 1");
               RETVALUE(SP_ERROR);
         } /* switch (...natAddr) */
         break;
      } /* case GTFRMT_1 */

      case GTFRMT_2:
         /* GT format 2 contains translation type and GTAI only
          * and tType can not be validated
          */
         break;         

      case GTFRMT_3:
      {
         /* validate numbering plan for gt format 3 */
         switch (ucb->ud->cdAddr.gt.gt.f3.numPlan)
         {
            case NP_UNKN:     /* unknown */ 
            case NP_ISDN:     /* ISDN/telephony numbering plan */
            case NP_TEL:      /* telephony numbering plan */
            case NP_DATA:     /* data numbering plan */ 
            case NP_TELEX:    /* telex numbering plan */
            case NP_MARMOB:   /* maritime mobile numbering plan */
            case NP_LANMOB:   /* land mobil numbering plan */
            case NP_ISDNMOB:  /* ISDN/mobile numbering plan */
            case NP_UID:      /* UID numbering plan */
            case NP_GROUP:    /* Group numbering plan */
            case NP_NWSPEC:   /* private network or network specific numplan */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP112, (ErrVal) 0,
                          "spValidateEvnt: invalid numPlan ");
               RETVALUE(SP_ERROR);
         } /* switch (...numPlan) */

         /* validate encoding scheme for gt format 3 */
         switch (ucb->ud->cdAddr.gt.gt.f3.encSch)
         {
            case ES_UNKN:     /* unknown */
            case ES_BCDODD:   /* BCD, odd number of digits */
            case ES_BCDEVEN:  /* BCD, even number of digits */
               break;

            case ES_NWSPEC:   /* national specific encoding scheme */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP114, (ErrVal) 0,
                          "spValidateEvnt: invalid encSch gt");
               RETVALUE(SP_ERROR);
         } /* switch (...encSch) */
         break;
      } /* case GTFRMT_3 */

      case GTFRMT_4:
      {
         /* validate numbering plan for gt format 4 */
         switch (ucb->ud->cdAddr.gt.gt.f4.numPlan)
         {
            case NP_UNKN:      /* unknown */ 
            case NP_ISDN:      /* ISDN/telephony numbering plan */ 
            case NP_TEL:       /* telephony numbering plan */
            case NP_DATA:      /* data numbering plan */
            case NP_TELEX:     /* telex numbering plan */
            case NP_MARMOB:    /* maritime mobile numbering plan */
            case NP_LANMOB:    /* land mobile numbering plan */
            case NP_ISDNMOB:   /* ISDN/mobile numbering plan */
            case NP_UID:       /* UID numbering plan */
            case NP_GROUP:     /* Group numbering plan */
            case NP_NWSPEC:    /* private network or network specific numplan */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP115, (ErrVal) 0,
                          "spValidateEvnt: invalid numPlan gt format 4");
               RETVALUE(SP_ERROR);
         } /* switch (...numPlan) */

         /* validate encoding scheme for gt format 4 */
         switch(ucb->ud->cdAddr.gt.gt.f4.encSch)
         {
            case ES_UNKN:      /* unknown */
            case ES_BCDODD:    /* BCD, odd number of digits */
            case ES_BCDEVEN:   /* BCD, even number of digits */
            case ES_NWSPEC:    /* national specific encoding scheme */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP116, (ErrVal) 0,
                          "spValidateEvnt: invalid encSch gt format 4");
               RETVALUE(SP_ERROR);
         } /* switch (...encSch) */

         /* validate nature of Addr indicator for gt format 4 */
         switch (ucb->ud->cdAddr.gt.gt.f4.natAddr)
         {
            case NA_SUBNUM:    /* subscriber number */
            case NA_NATSIGNUM: /* national significant number */
            case NA_INTNUM:    /* international number */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESP117, (ErrVal) 0,
                          "spValidateEvnt: invalid natAddr ");
               RETVALUE(SP_ERROR);
         } /* switch (...natAddr) */
         break;
      } /* case GTFRMT_4 */

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP118, (ErrVal) 0,
                    "spValidateEvnt: invalid GT format ");
         RETVALUE(SP_ERROR);
   } /* switch (adjFrmt) */

   /* Note: message importance will not be validated in this function
    * importance will be validated against maximum allowable value in
    * the function delivering data down to lower layer
    */

#ifdef SPTV2

#endif /* SPTV2 */

   RETVALUE(SP_OK);
} /* spValidateEvnt */


/*
*
*       Fun:   spPkPc
*
*       Desc:  Pack a Point Code
*
*       Ret:   length of point code
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC U8 spPkPc
(
U8 dlen,            /* point code length */
Dpc dpc,            /* point code */
Buffer *buf         /* buffer to pack pc */
)
#else
PUBLIC U8 spPkPc(dlen, dpc, buf)
U8 dlen;            /* point code length */
Dpc dpc;            /* point code */
Buffer *buf;        /* buffer to pack pc */
#endif
{
   U8 len;          /* byte length packed in buffer */
   S16 ret;         /* return value */

   TRC2(spPkPc)

   /* pack pc based on point code length */
   switch (dlen)
   {
      case DPC14:       /* 14 bits pc - ITU network */
      {
         Data pc[2];
         U16 word1;
         word1 = (U16) GetLoWord(dpc);
         word1 &= DPC14MSK;
         pc[0] = (U8) GetHiByte(word1);
         pc[1] = (U8) GetLoByte(word1);

         ret = SAddPreMsgMult(pc, (MsgLen) 2, buf);
#if (ERRCLASS & ERRCLS_ADD_RES)      
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP119, (ErrVal) ret,
                       "SAddpreMsgMult failed");
            RETVALUE(0);
         }
#endif /* ERRCLASS */
         len = 2;
      }
      break;
 

      case DPC24:       /* 24 bits pc - ANSI, Bellcore and china network */
      {
         Data pc[3];
         U16 word1;
         U16 word2;
         word1 = (U16) GetLoWord(dpc);
         word2 = (U16) GetHiWord(dpc);
         pc[0] = (U8) GetLoByte(word2);
         pc[1] = (U8) GetHiByte(word1);
         pc[2] = (U8) GetLoByte(word1);

         ret = SAddPreMsgMult(pc, (MsgLen) 3, buf);
#if (ERRCLASS & ERRCLS_ADD_RES)      
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP121, (ErrVal) ret,
                       "SAddpreMsgMult failed");
            RETVALUE(0);
         }
#endif /* ERRCLASS */
         len = 3;
      }
      break;
 
      default:
         /* error case */
         SPLOGERROR(ERRCLS_ADD_RES, ESP122, (ErrVal) dlen,
                    "SAddpreMsgMult: Invalid point code length");
         RETVALUE(0);
   } /* switch (dlen) */

   RETVALUE(len);
} /* spPkPc */


/*
*
*       Fun:   spRemPc
*
*       Desc:  Remove a Point Code
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 spRemPc
(
U8 dlen,           /* point code length */
Dpc *dpc,          /* buffer to unpack point code */
Buffer *mBuf       /* message buffer */
)
#else
PRIVATE S16 spRemPc(dlen, dpc, mBuf)
U8 dlen;           /* point code length */
Dpc *dpc;          /* buffer to unpack point code */
Buffer *mBuf;      /* message buffer */
#endif
{
   S16 ret;        /* return value */

   TRC2(spRemPc)

   switch (dlen)
   {
      case DPC14:         /* 14 bits pc - ITU network */
      {
         Data pc[2];
         U16 word1;

         ret = SRemPreMsgMult(pc, 2, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP123, (ErrVal) ret,
                       "spRemPc() SRemPreMsgMult failed");
            RETVALUE(ret);
         }
#endif /* ERRCLASS */

         *dpc = 0;
         word1 = 0;
         word1 = PutLoByte(word1, pc[0]);
         word1 = PutHiByte(word1, pc[1]);
         *dpc = PutLoWord(*dpc, word1);
         *dpc &= DPC14MSK;
      }
      break;


      case DPC24:         /* 24 bits pc - ANSI, Bellcore and China network */
      {
         Data pc[3];
         U16 word1;
         U16 word2;

         ret = SRemPreMsgMult(pc, 3, mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP125, (ErrVal) ret,
                       "spRemPc() SRemPreMsgMult failed");
            RETVALUE(ret);
         }
#endif /* ERRCLASS */

         *dpc = 0;
         word1 = 0;
         word2 = 0;
         word1 = PutLoByte(word1, pc[0]);
         word1 = PutHiByte(word1, pc[1]);
         word2 = PutLoByte(word2, pc[2]);
         *dpc = PutLoWord(*dpc, word1);
         *dpc = PutHiWord(*dpc, word2);
      }
      break;

      default:
         /* error case */
         SPLOGERROR(ERRCLS_DEBUG, ESP126, (ErrVal) dlen,
                    "spRemPc: Invalid point code length");
         RETVALUE(RFAILED);
   } /* switch (dlen) */

   RETVALUE(ROK);
} /* spRemPc */


/*
*
*       Fun:   spSendLmSta
*
*       Desc:  Send Unsolicited Status to Layer Management
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spSendLmSta
(
U16 category,           /* category */
U16 event,              /* event generated */
U16 cause,              /* cause */
U8 par1,                /* parameter 1 */
U8 par2                 /* parameter 2 */
)
#else
PUBLIC Void spSendLmSta(category, event, cause, par1, par2)
U16 category;           /* category */
U16 event;              /* event generated */
U16 cause;              /* cause */
U8 par1;                /* parameter 1 */
U8 par2;                /* parameter 2 */
#endif
{
   SpMngmt usta;

   TRC2(spSendLmSta);

   /* if gencfg not done, return */
   if (spCb.spInit.cfgDone != TRUE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP127, (ErrVal) 0, 
                 "spSendLmSta(): General Config not done");
      RETVOID;
   }

   /* sp001.302 - addition - initialize usta */
   cmZero((U8 *) &usta, sizeof(SpMngmt));

   if (spCb.ustaMask & LSP_USTAALARM)
   {
      usta.hdr.msgType = TUSTA;
      usta.hdr.entId.ent = spCb.spInit.ent;
   
#ifdef SP_LMINT3
      (Void) SGetDateTime(&usta.t.usta.alarm.dt);
      usta.t.usta.alarm.category = category;
      usta.t.usta.alarm.event = event;
      usta.t.usta.alarm.cause = cause;
      usta.t.usta.evtRep.evntParm[0] = par1;
      usta.t.usta.evtRep.evntParm[1] = par2;
#else
      (Void) SGetDateTime(&usta.t.usta.dt);
      usta.hdr.elmId.elmntInst1 = par1;
      usta.hdr.elmId.elmntInst2 = par2;
      usta.t.usta.evnt = event;    
#endif /* SP_LMINT3 */
      
      /* generate Status Confirmation to Layer Manager */
      
      (Void)SpMiLspStaInd(&spCb.spInit.lmPst, &usta);
   }
   RETVOID;
} /* spSendLmSta */


/*
*
*       Fun:   spSendLmSpReport
*
*       Desc:  Send SCCP error performance and subsystem availability report.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spSendLmSpReport
(
U16 event,              /* event generated */
U16 cause,              /* cause */
SpReport *spRep         /* sccp error perf/subsystem availability report */
)
#else
PUBLIC Void spSendLmSpReport(event, cause, spRep)
U16 event;              /* event generated */
U16 cause;              /* cause */
SpReport *spRep;        /* sccp error perf/subsystem availability report */
#endif
{
   SpMngmt usta;        /* management struct for usta */

   TRC2(spSendLmSpReport);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spCb.spInit.cfgDone != TRUE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP128, (ErrVal) 0, 
                 "spSendLmSta(): General Config not done");
      RETVOID;
   }
#endif /* ERRCLASS */

   if (spCb.ustaMask & LSP_USTAREPORT)
   {
      /* fill message type and entity */
      usta.hdr.msgType = TUSTA;
      usta.hdr.entId.ent = spCb.spInit.ent;
   
#ifdef SP_LMINT3
      (Void) SGetDateTime(&usta.t.usta.alarm.dt);
      usta.t.usta.alarm.category = LCM_CATEGORY_PERF_MONIT;
      usta.t.usta.alarm.event = event;
      usta.t.usta.alarm.cause = cause;
#else
      (Void) SGetDateTime(&usta.t.usta.dt);
      usta.t.usta.evnt = event;
#endif /* SP_LMINT3 */

      /* copy sccp report */
      cmCopy((U8 *) spRep, (U8 *) &usta.t.usta.evtRep.spRep, sizeof(SpReport));
      
      /* send sccp report to Layer Manager */
      (Void) SpMiLspStaInd(&spCb.spInit.lmPst, &usta);
   }
   RETVOID;
} /* spSendLmSpReport */

  
/*
*
*       Fun:    spRmvNSapTq
*
*       Desc:   Removes control block from Timing Queue
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvNSapTq
(
SpNSapCb *cb,     /* control block */
S16      event    /* timer event */
)
#else
PUBLIC Void spRmvNSapTq(cb, event)
SpNSapCb *cb;      /* control block */
S16      event;    /* timer event */
#endif
{
   CmTmrArg arg;
   U8 tNum;

   TRC2(spRmvNSapTq);

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf, "spRmvNSapTq : tmr %d\n",
          event));

   for (tNum = 0; tNum < MAXNSAPTMR; tNum++)
   {
      if (cb->timers[tNum].tmrEvnt == event)
      {
         break;
      }
   }
   if (tNum >= MAXNSAPTMR)
   {
      RETVOID;
   }

   arg.tq = spCb.spNSapTq;
   arg.tqCp = &spCb.spNSapTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = event;
   arg.wait = NOTUSED;
   arg.tNum = tNum;
   arg.max = MAXNSAPTMR;
   cmRmvCbTq(&arg);
   RETVOID;
} /* end of spRmvNSapTq */

  
/*
*
*       Fun:   spStartNSapCbTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void spStartNSapCbTmr
(
SpNSapCb *cb,                   /* control block */
U8 event                        /* timer event */
)
#else
PUBLIC Void spStartNSapCbTmr(cb, event)
SpNSapCb *cb;                   /* control block */
U8 event;                       /* timer event */
#endif
{
   CmTmrArg arg;
  
   TRC2(spStartNSapCbTmr)
 
#if (ERRCLASS & ERRCLS_INT_PAR)  
   if (cb == NULLP)

   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP129, (ErrVal) ERRZERO,
                 "spStartNSapCbTmr called with NULLP");
      RETVOID;
   }
#endif

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spStartNSapCbTmr : tmr %d\n", event));
   
   arg.tq = spCb.spNSapTq;
   arg.tqCp = &spCb.spNSapTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = event;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXNSAPTMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)
      cmPlcCbTq(&arg);
   RETVOID;
} /* end of spStartNSapCbTmr */

  
/*
*
*       Fun:   spNSapCbTmrEvnt
*
*       Desc:  NSap Control Block Timer Event.
*
*       Ret:   ROK
*
*       Notes: Called whenever an NSap timer expires.
*              We Simply delete the NSap (which frees up the memory).
*              This too should be inlined....
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spNSapCbTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spNSapCbTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{
   SpNSapCb *cb; 

   TRC2(spNSapCbTmrEvnt)

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP130, (ErrVal) 0, 
                 "spNSapCbTmrEvnt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */

   SPDBGP(SP_DBGMASK_INTERNAL, (spCb.spInit.prntBuf,
          "spNSapCbTmrEvnt : tmr %d\n", evnt));

   cb = (SpNSapCb *) cbp;
  
   switch (evnt)
   {
      case TMR_RSTEND:  /* Enquiry timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = TRUE;
            cb->tmr.val = spCb.spCfg.defRstEndTmr.val;
            spStartNSapCbTmr(cb, TMR_RSTEND);
            RETVOID;
         }
#endif /* ZP */      

         /* 
          * Either a StaInd from MTP3 is lost or a 
          * wrong timer value is configured. I hope it is the former.
          */
         spHndlRstEnd (cb);
         break;

#ifdef SNT2
      case TMR_INT:      /* bind interval timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = TRUE;
            cb->tmr.val = spCb.spCfg.tIntTmr.val;
            spStartNSapCbTmr(cb, TMR_INT);
            RETVOID;
         }
#endif /* ZP */

         if (cb->bndRetryCnt < SP_MAX_INTRETRY)
         {
            /* sp018.302 - modification - restart the timer */
            cb->bndRetryCnt++;
            cb->tmr.enb = TRUE;
            cb->tmr.val = spCb.spCfg.tIntTmr.val;
            spStartNSapCbTmr(cb, TMR_INT);

            /* reissue a bind request */
            (Void)SpLiSntBndReq(&cb->pst, cb->suId, cb->spId,
                                cb->nwData->sInfo);
         }
         else
         {
            spSendLmSta(LCM_CATEGORY_PROTOCOL, LCM_EVENT_BND_FAIL,
                            LCM_CAUSE_UNKNOWN, NOTUSED, (U8) cb->suId);
            cb->bndRetryCnt = 0;
            cb->status ^= SP_WAIT_BNDCFM;
#ifdef ZP
            zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) cb, CMPFTHA_UPDTYPE_NORMAL, 
                         CMPFTHA_ACTN_MOD);
#endif /* ZP */
         }
         break;
#endif /* SNT2 */
         
      default:
      SPLOGERROR(ERRCLS_INT_PAR, ESP131, (ErrVal) evnt,
                  "spNSapCbTmrEvnt invalid event");
        break;
   } /* switch (evnt) */

#ifdef ZP
   zpUpdPeer();
#endif /* ZP */
   RETVOID;
} /* spNSapCbTmrEvnt */


/*
*
*       Fun:   spDropMsg
*
*       Desc:  Encapsulate the dropping of a message...
*              This could/should be common to all protocol stacks!
*              Better yet, this should be a macro... so that it could
*              be inlined.
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Utility
*              A SMART optimizer will inline this (I hope)...
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spDropMsg
(
Buffer **mBuf           /* message buffer */
)
#else
PUBLIC Void spDropMsg(mBuf)
Buffer **mBuf;          /* message buffer */
#endif
{
   S16 ret;

   TRC2(spDropMsg)

   if (*mBuf)
   {
      ret = SPutMsg(*mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP132, (ErrVal) ret, "SPutMsg failed");
      }
#endif /* ERRCLASS */

   }
   *mBuf = (Buffer *) NULLP;
   RETVOID;
} /* spDropMsg */


/*           
*
*       Fun:   spTknStrToSpAddr
*
*       Desc:  convert TknStr structure to an SpAddr structure
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spTknStrToSpAddr
(
TknStr *str,        /* token string */
SpAddr *addr,       /* address */
Swtch sw,           /* switch */
U8 ssf              /* sub-service field */
)
#else
PUBLIC Void spTknStrToSpAddr(str, addr, sw, ssf)
TknStr *str;         /* token string */
SpAddr *addr;        /* address */
Swtch sw;            /* switch from sap*/
U8 ssf;              /* sub-service field */
#endif
{
   REG1 U8 i;        /* loop counter */
   U8 octet;         /* octet to decode address */
   U8 *ptr;          /* pointer to address string */
   S16 len;          /* address length - sp007.302 - type changed to S16 */
   U8 adjFrmt;       /* adjusted format */
  
   TRC2(spTknStrToSpAddr)

   if (str->pres == NOTPRSNT)
   {
      addr->pres = FALSE;
      RETVOID;
   }

   /* mark presence of address as true */
   addr->pres = TRUE;

#ifdef CMSS7_SPHDROPT
   addr->spHdrOpt = CMSS7_DEF_OPT;
#endif /* CMSS7_SPHDROPT */

   /* add ssf to address */
   addr->ssf = ssf;
   addr->ssfPres = TRUE;
  
   switch (sw)
   {
      case LSP_SW_ITU:
         addr->sw = SW_ITU;
         break;

      case LSP_SW_CHINA:
         addr->sw = SW_CHINA;
         break;



      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP133, (ErrVal) sw, "invalid switch");
         RETVOID;
   } /* switch (sw) */

   ptr = str->val;
   len = str->len;

   /* get address indicator */
   octet = *ptr++;
   
   {
      addr->pcInd = (U8) (octet & 0x01);
      addr->ssnInd = (U8) ((octet >> 1) & 0x01);
   }

   addr->gt.format = (U8) ((octet >> 2) & 0x0f);
   addr->rtgInd = (U8) ((octet >> 6) & 0x01);
   addr->niInd = (U8) ((octet >> 7) & 0x01);
   len--;
  
   /* sp007.302 - addition - check if routing on GT, then GT should
    * be present. For route on SSN, validation shall not be done, for
    * calling party address treatment might be done down the flow.
    */
   if ((addr->rtgInd == RTE_GT) && (addr->gt.format == GTFRMT_0))
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "spTknStrToSpAddr: inconsistent rtgInd and gt");
      RETVOID;
   }

   /* unpack point code and ssn based on address switch */
   switch (addr->sw)
   {
      case SW_ITU:
      {
         U16 word1 = 0;
         if (addr->pcInd)
         {
            addr->pc = 0;
            word1 = PutLoByte(word1, *ptr++);
            word1 = PutHiByte(word1, *ptr++);
            word1 &= DPC14MSK;
            addr->pc = word1;
            len -= 2;
         }

         if (addr->ssnInd)
         {
            addr->ssn = *ptr++;
            len--;
         }
         break;
      }


      /* sp006.301 - changed the china variant, as the format for the cdAddr
         should be point code then SSN, as apposed to ANSI, where the format
         is SSN followed by PC */

      case SW_CHINA:
      {
         U16 word1 = 0;
         U16 word2 = 0;

         if (addr->pcInd)
         {
            addr->pc = 0;
            word1 = PutLoByte(word1, *ptr++);
            word1 = PutHiByte(word1, *ptr++);
            word2 = PutLoByte(word2, *ptr++);
            addr->pc = PutLoWord(addr->pc, word1);
            addr->pc = PutHiWord(addr->pc, word2);
            addr->pc &= DPC24MSK;
            len -= 3;
         }

         if (addr->ssnInd)
         {
            addr->ssn = *ptr++;
            len--;
         }
         break;
      }
   } /* switch (addr->sw) */
  
   /* 
    * if available, unpack the address....
    */
   if (addr->gt.format == GTFRMT_0)
      RETVOID;
   else
   {
      /* sp007.302 - addition - check presence of GT address */
      if (len <= 0)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                    "spTknStrToSpAddr: inconsistent gt");
         RETVOID;
      }
   }

/* sp007.302 - addition - validate GT format */
      if (addr->gt.format > GTFRMT_4)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) addr->gt.format,
                    "spTknStrToSpAddr: invalid gt format");
         RETVOID;
      }

       adjFrmt = addr->gt.format;

   /* unpack gt based on format type */
   switch (adjFrmt)
   {
      case GTFRMT_1:
      {
         octet = 0;
         octet = *ptr++;

         /* decode Odd/Even indicator */
         addr->gt.gt.f1.oddEven = (U8) ((octet >> 0x07) & 0x01);
        
         /* decode nature of address indicator */
         addr->gt.gt.f1.natAddr = (U8) (octet & 0x7f);

         /* sp007.302 - addition - validate nature of address indicator */
         switch (addr->gt.gt.f1.natAddr)
         {
            case NA_SUBNUM:      /* subscriber number */
            case NA_NATSIGNUM:   /* national significant number */
            case NA_INTNUM:      /* international number */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f1.natAddr,
                          "spTknStrToSpAddr: invalid natAddr in gt format 1");
               RETVOID;
         } /* switch (...natAddr) */

         len--;
         break;
      } /*  case GTFRMT_1 */

      case GTFRMT_2:
      {
         octet = 0;
         octet = *ptr++;

         /* decode Translation type */
         addr->gt.gt.f2.tType = octet;
         len--;
         break;
      }

      case GTFRMT_3:
      {
         octet = 0;
         octet = *ptr++;

         /* decode Translation type. No validation of TT is done */
         addr->gt.gt.f3.tType = octet;
         len--;

         /* decode Encoding Scheme */
         octet = *ptr++;
         addr->gt.gt.f3.encSch = (U8) (octet & 0x0f);

         /* sp007.302 - addition - validate encoding scheme for gt format 3 */
         switch (addr->gt.gt.f3.encSch)
         {
            case ES_UNKN:     /* unknown */
            case ES_BCDODD:   /* BCD, odd number of digits */
            case ES_BCDEVEN:  /* BCD, even number of digits */
               break;

            case ES_NWSPEC:   /* national specific encoding scheme */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f3.encSch,
                          "spTknStrToSpAddr: invalid encSch in gt format 3");
               RETVOID;
         } /* switch (...encSch) */

         /* decode Numbering Plan */
         addr->gt.gt.f3.numPlan = (U8) ((octet >> 0x04) & 0x0f);

         /* sp007.302 - addition - validate numbering plan for gt format 3 */
         switch (addr->gt.gt.f3.numPlan)
         {
            case NP_UNKN:     /* unknown */ 
            case NP_ISDN:     /* ISDN/telephony numbering plan */
            case NP_TEL:      /* telephony numbering plan */
            case NP_DATA:     /* data numbering plan */ 
            case NP_TELEX:    /* telex numbering plan */
            case NP_MARMOB:   /* maritime mobile numbering plan */
            case NP_LANMOB:   /* land mobil numbering plan */
            case NP_ISDNMOB:  /* ISDN/mobile numbering plan */
            case NP_UID:      /* UID numbering plan */
            case NP_GROUP:    /* Group numbering plan */
            case NP_NWSPEC:   /* private network or network specific numplan */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f3.numPlan,
                          "spTknStrToSpAddr: invalid numPlan in gt format 3");
               RETVOID;
         } /* switch (...numPlan) */

         len--;
         break;
      } /*  case GTFRMT_3 */

      case GTFRMT_4:
      {
         octet = 0;
         octet = *ptr++;

         /* decode Translation Type */
         addr->gt.gt.f4.tType = octet;
         len--;
  
         /* decode Encoding Scheme */
         octet = *ptr++;
         addr->gt.gt.f4.encSch = (U8) (octet & 0x0f);

         /* sp007.302 - addition - validate encoding scheme for gt format 4 */
         switch (addr->gt.gt.f4.encSch)
         {
            case ES_UNKN:     /* unknown */
            case ES_BCDODD:   /* BCD, odd number of digits */
            case ES_BCDEVEN:  /* BCD, even number of digits */
               break;

            case ES_NWSPEC:   /* national specific encoding scheme */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f4.encSch,
                          "spTknStrToSpAddr: invalid encSch gt");
               RETVOID;
         } /* switch (...encSch) */

         /* decode Numbering Plan */
         addr->gt.gt.f4.numPlan = (U8) ((octet >> 0x04) & 0x0f);

         /* sp007.302 - addition - validate numbering plan for gt format 4 */
         switch (addr->gt.gt.f4.numPlan)
         {
            case NP_UNKN:     /* unknown */ 
            case NP_ISDN:     /* ISDN/telephony numbering plan */
            case NP_TEL:      /* telephony numbering plan */
            case NP_DATA:     /* data numbering plan */ 
            case NP_TELEX:    /* telex numbering plan */
            case NP_MARMOB:   /* maritime mobile numbering plan */
            case NP_LANMOB:   /* land mobil numbering plan */
            case NP_ISDNMOB:  /* ISDN/mobile numbering plan */
            case NP_UID:      /* UID numbering plan */
            case NP_GROUP:    /* Group numbering plan */
            case NP_NWSPEC:   /* private network or network specific numplan */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f4.numPlan,
                          "spTknStrToSpAddr: invalid numPlan ");
               RETVOID;
         } /* switch (...numPlan) */

         len--;
  
         /* decode Nature of address indicator */
         octet = *ptr++;
         addr->gt.gt.f4.natAddr = (U8) (octet & 0x7f);

         /* sp007.302 - addition - validate nature of address indicator */
         switch (addr->gt.gt.f4.natAddr)
         {
            case NA_SUBNUM:      /* subscriber number */
            case NA_NATSIGNUM:   /* national significant number */
            case NA_INTNUM:      /* international number */
               break;

            default:
               SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                          (ErrVal) addr->gt.gt.f4.natAddr,
                          "spTknStrToSpAddr: invalid natAddr in gt format 4");
               RETVOID;
         } /* switch (...natAddr) */

         len--;
         break;
      } /*  case GTFRMT_4 */
   } /* switch (adjFrmt) */

   /* sp007.302 - addition - check for presence of GT address nibbles */
   if (len <= 0)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) 0,
                 "spTknStrToSpAddr: Addr nibbles not present in GT");
      RETVOID;
   }

   /* Address nibbles */
   addr->gt.addr.length = len;
   for (i = 0; i < len; i++)
       addr->gt.addr.strg[i] = *ptr++;
   RETVOID;
} /* spTknStrToSpAddr */


/*
*
*       Fun:   spSpAddrToTknStr
*
*       Desc:  Pack an sccp address structure into a TknStr structure
*
*       Ret:   None
*
*       Notes: None.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spSpAddrToTknStr
(
SpAddr *addr,           /* sccp address */
TknStr *str             /* address token string */
)
#else
PUBLIC Void spSpAddrToTknStr(addr, str)
SpAddr *addr;           /* sccp address */
TknStr *str;            /* address token string */
#endif
{
   REG1 U8 len;         /* length of address */
   REG2 U8 *ptr;        /* pointer to address string */
   REG3 U8 i;           /* loop counter */
   U8 adjFrmt;          /* adjusted format */
   U8 octet;            /* address octet to encode into string */
  
   TRC2(spSpAddrToTknStr)

   /* Initialize len, octet and ptr */
   len = 0;
   octet = 0;
   ptr = str->val;

#ifdef CMSS7_SPHDROPT
   if (addr->spHdrOpt == CMSS7_NO_SP_PC)
      addr->pcInd = FALSE;
#endif /* CMSS7_SPHDROPT*/    

   /* encode the address indicators into a single octet */
   octet = 0;
   octet |= ((addr->niInd & 0x01) << 7);
   octet |= ((addr->rtgInd & 0x01) << 6);
   octet |= ((addr->gt.format & 0x0f) << 2);

   switch (addr->sw)
   {
      case SW_ITU:         /* fall through */
      case SW_CHINA:       /* fall through */
         octet |= ((addr->pcInd & 0x01) << 0);
         octet |= ((addr->ssnInd & 0x01) << 1);
         break;


      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP134, (ErrVal) addr->sw,
                    "invalid switch");
         RETVOID;
   } /* switch (addr->sw) */

   *ptr++ = octet;
   len++;

   /* encode the point code and subsystem number */
   switch (addr->sw)
   {
      case SW_ITU:
      {
         if (addr->pcInd)
         {
            U16 word1;
            word1 = (U16) GetLoWord(addr->pc);
            word1 &= DPC14MSK;
            *ptr++ = (U8) GetLoByte(word1);
            *ptr++ = (U8) GetHiByte(word1);
            len += 2;
         }
         if (addr->ssnInd)
         {
            *ptr++ = addr->ssn;
            len++;
         }
         break;
      }


      /* sp006.301 - changed the china variant, as the format for the cdAddr
         should be point code then SSN, as apposed to ANSI, where the format
         is SSN followed by PC */

      case SW_CHINA:
      {
         if (addr->pcInd)
         {
            U16 word1;
            U16 word2;
            word1 = (U16) GetLoWord(addr->pc);
            word2 = (U16) GetHiWord(addr->pc);
            *ptr++ = (U8) GetLoByte(word1);
            *ptr++ = (U8) GetHiByte(word1);
            *ptr++ = (U8) GetLoByte(word2);
            len += 3;
         }
         if (addr->ssnInd)
         {
            *ptr++ = addr->ssn;
            len++;
         }
         break;
      }

      default:
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP135, (ErrVal) addr->sw,
                    "invalid switch");
         RETVOID;
      }
   } /* switch (addr->sw) */

   /* We do this backwards because
    * the mos pack routines prepend
    */
  
       adjFrmt = addr->gt.format;
  
   switch (adjFrmt)
   {
      case GTFRMT_0:
      {
         /* gt not present */
         break;
      }

      case GTFRMT_1:
      {
         octet = 0;
         octet |= ((addr->gt.gt.f1.oddEven & 0x01) << 7);
         octet |= (addr->gt.gt.f1.natAddr & 0x7f);
         *ptr++ = octet;
         len++;

         /* encode the address bits */
         for (i = 0; i < addr->gt.addr.length; i++)
         {
            *ptr++ = addr->gt.addr.strg[i];
         }
         len += addr->gt.addr.length;
         break;
      }

      case GTFRMT_2:
      {
         /* encode translation type */
         *ptr++ = addr->gt.gt.f2.tType;
         len++;

         /* encode the address bits */
         for (i = 0; i < addr->gt.addr.length; i++)
         {
            *ptr++ = addr->gt.addr.strg[i];
         }
         len += addr->gt.addr.length;
         break;
      }

      case GTFRMT_3:
      {
         /* encode translation type */
         *ptr++ = addr->gt.gt.f3.tType;
         len++;

         octet = 0;

         /* encode numbering plan */
         octet |= ((addr->gt.gt.f3.numPlan & 0x0f) << 4);

         /* encode encoding scheme */
         octet |= (addr->gt.gt.f3.encSch & 0x0f);
         *ptr++ = octet;
         len++;

         /* encode the address bits */
         for (i = 0; i < addr->gt.addr.length; i++)
         {
            *ptr++ = addr->gt.addr.strg[i];
         }
         len += addr->gt.addr.length;
         break;
      } /* case GTFRMT_3 */

      case GTFRMT_4:
      {
         *ptr++ = addr->gt.gt.f4.tType;
         len++;

         octet = 0;

         /* encode numbering plan and encoding scheme */
         octet |= ((addr->gt.gt.f4.numPlan & 0x0f) << 4);
         octet |= (addr->gt.gt.f4.encSch & 0x0f);
         *ptr++ = octet;
         len++;
  
         octet = 0;

         /* encode nature of address indicator */
         octet = (addr->gt.gt.f4.natAddr & 0x7f);
         *ptr++ = octet;
         len++;

         /* encode the address bits */
         for (i = 0; i < addr->gt.addr.length; i++)
         {
            *ptr++ = addr->gt.addr.strg[i];
         }
         len += addr->gt.addr.length;
         break;
      } /* case GTFRMT_4 */
   } /* switch (adjFrmt) */
  
   /* set the address length */
   str->len = len;
   str->pres = PRSNT_NODEF;

   RETVOID;
} /* spSpAddrToTknStr */



  
/*
*
*       Fun:   spLiSegAndSendData
*
*       Desc:  Handle the Unit Data. Based on the message length and
*              route characteristics send the appropriate format
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void spLiSegAndSendData
(
SpUdCb *ucb,              /* unit data control block */
Buffer *mBuf              /* message buffer */
)
#else
PRIVATE Void spLiSegAndSendData(ucb, mBuf)
SpUdCb *ucb;              /* unit data control block */
Buffer *mBuf;             /* message buffer */
#endif
{
   S16 ret;               /* return value */
   MsgLen mLen;           /* message length */
   MsgLen cgLen;          /* calling addres length */
   MsgLen cdLen;          /* called addres length */
   MsgLen xudt_hdrLen;    /* xudt header length */
   MsgLen xudt_maxdlen;   /* maximum data length in xudt */
   MsgLen ludt_hdrLen;    /* ludt header length */
   MsgLen ludt_maxdlen;   /* maximum data length in ludt */
 
   TRC2(spLiSegAndSendData);
   
   switch (ucb->dataType)
   {
      case M_UNITDATA:
      {
         /* Encode Unit Data message */
         mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
         break;
      }

      case M_XUNITDATA:
      {
         /* sp045.302 - addition - if route is ITU88/ANS88 XUDT is not
          * supported.
          */
         if ( 
              (ucb->rCb->swtch == LSP_SW_ITU88))  
         {
             /* data is too long for transmission */
             SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) 0,
                "Segmentation not supported(ITU/ANSI 88 route) ");
             /* return message */
             spReturnMsg(ucb, (U8) RTC_UNQUAL, mBuf);
             RETVOID;
         }
         /* Encode Extended Unit Data message */
         mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
         break;
      }

      case M_LUNITDATA:
      {
         ret = SFndLenMsg(mBuf, &mLen);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP136, (ErrVal) ret,
                       "SFndLenMsg failed - Buffer = NULLP");
            RETVOID;
         }
#endif /* ERRCLASS */

         cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                              ucb->rCb->nSap->nwData->variant);
         cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                              ucb->rCb->nSap->nwData->variant);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (cgLen == 0 || cdLen == 0)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP137, (ErrVal) 0,
                 "error calculating calling/called party address length");
            RETVOID;
         }
#endif /* ERRCLASS */

         /* determine xudt/ludt hdrLen based on presence of isni and ins */
#ifdef SS7_BELL05
#else
         xudt_hdrLen = XUDHDRLEN;
         ludt_hdrLen = LUDHDRLEN;
#endif /* SS7_BELL05 */

         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
         {
            xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - xudt_hdrLen;
         }
         else
         {
            xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - xudt_hdrLen;
         }

         ludt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - ludt_hdrLen;

         if (((ucb->rCb->swtch == LSP_SW_ITU96)
             ) && (ucb->rCb->flag & LSP_NW_BROADBAND)
             && (mLen <= ludt_maxdlen))
         {
            /* Encode Long Unit Data message */
            mBuf = spEncCLMsg(M_LUNITDATA, ucb, &mBuf);
            break;
         }

         if (mLen <= xudt_maxdlen)
         {
            mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
            break;
         }
         else
         {
            if (mLen > MAXNUMSEG * xudt_maxdlen)
            {
               /* data is too long for segmentation */
               spCb.sts.segErrFail++;

               spDropMsg(&mBuf);
               RETVOID;
            }
            else
            {
               /* sp045.302 - addition - if route is ANS92 segmented XUDT is not
                * supported.
                */
               /* Send as segmented XUDT */


               spSegData(ucb, mBuf, mLen, xudt_maxdlen, FROM_LOWER);
               RETVOID;
            }
         }
         break;
      }

      default:
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP138, (ErrVal) ucb->dataType,
                    "Unknown Data Type");
         spDropMsg(&mBuf);
         RETVOID;
      }
   } /* switch (ucb->dataType) */

   /* Deliver Data - no segementation was required */

   if (mBuf == (Buffer *) NULLP)
      RETVOID;

   ret = SFndLenMsg(mBuf, &mLen);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP139, (ErrVal) ret,
                 "SFndLenMsg failed - Buffer = NULLP");
      RETVOID;
   }
#endif /* ERRCLASS */

   if (mLen > ucb->rCb->nSap->msgLen)    /* Message is too long */
   {
      /* We drop the message, because we have already
       * encoded it so it will be meaningless to a user
       */
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* deliver message to lower layer */
   spDelvUDatDown(ucb, FROM_LOWER, mBuf);
   
   /* Update Statistics */
   if (ucb->dataType == M_UNITDATA)
      spCb.sts.uDataTx++;
   else
      if (ucb->dataType == M_LUNITDATA)
         spCb.sts.luDataTx++;
      else
         spCb.sts.xuDataTx++;

   (ucb->ud->qos.pClass == PCLASS0)?spCb.sts.msgTxC0++:spCb.sts.msgTxC1++;

   RETVOID;
} /* spLiSegAndSendData */

  
/*
*
*       Fun:   spUiHndlSegData
*
*       Desc:  Handle the Unit Data. Based on the message length and
*              route characteristics send the appropriate format UDT/XUDT/LUDT
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void spUiHndlSegData
(
SpUdCb *ucb,               /* unit data control block */
Buffer *mBuf               /* message buffer */
)
#else
PRIVATE Void spUiHndlSegData(ucb, mBuf)
SpUdCb *ucb;               /* unit data control block */
Buffer *mBuf;              /* message buffer */
#endif
{
   S16 ret;                /* return value */
   MsgLen cgLen;           /* length of calling address */
   MsgLen cdLen;           /* length of called address */
   MsgLen udt_maxdlen;     /* maximum data length for UDT */
   MsgLen xudt_maxdlen;    /* maximum data length for XUDT */
   MsgLen ludt_maxdlen;    /* maximum data length for LUDT */
   MsgLen mLen;            /* length of message buffer passed */
 
   TRC2(spUiHndlSegData);
 
   /* find length of message buffer passed */
   ret = SFndLenMsg(mBuf, &mLen);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP140, (ErrVal) ret,
                 "SFndLenMsg failed - Buffer = NULLP");
      RETVOID;
   }
#endif /* ERRCLASS */

   /* handle message based on route switch */
   switch (ucb->rCb->swtch)
   {
      case LSP_SW_ITU88:  
      {
         /* sp015.302 - correcting the calculation of max data length which
          * can be sent in UDT
          */
         /* calculate length of cgAddr and cdAddr */
         cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                              ucb->rCb->nSap->nwData->variant);
         cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                              ucb->rCb->nSap->nwData->variant);

#if (ERRCLASS & ERRCLS_DEBUG)
         if (cgLen == 0 || cdLen == 0)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) 0,
                       "error calculating calling/called address length");
            RETVOID;
         }
#endif /* ERRCLASS */

         /* calculate max data length to be accomodated in one msg,
          * hdrlen for UDT is same in ansi ans itu
          */
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
            udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
         else
            udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;

         /* validate data length for UDT */
         if (mLen > udt_maxdlen)
         {
             /* data is too long for transmission */
             SPLOGERROR(ERRCLS_DEBUG, ESP141, (ErrVal) mLen,
                "Segmentation not supported(ITU/ANSI 88 route): Data too long");
             spDropMsg(&mBuf);
             spHndlStatInd(ucb, (U8) RTC_UNQUAL, NULLP);
             RETVOID;
         }

         ucb->dataType = M_UNITDATA;

         /* Encode Unit Data message */
         mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
         break;
      }


      case LSP_SW_CHINA:     /* fall through : same as itu92 */
      /* sp040.302 - removal - gsm routes handling separated from itu 92 */
      case LSP_SW_ITU92:
      {
         /* calculate calling/called address length */
         cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                              ucb->rCb->nSap->nwData->variant);
         cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                              ucb->rCb->nSap->nwData->variant);
 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (cgLen == 0 || cdLen == 0)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP143, (ErrVal) 0,
                       "error calculating calling/called address length");
            RETVOID;
         }
#endif /* ERRCLASS */
 
         /* china, japan and itu92 routes do not support importance,
          * mark it as not present
          */
         ucb->imp.pres = NOTPRSNT;

         /* ITU does not support message type interworking,
          * mark presence of message type interworking as FALSE
          */
         ucb->spMti.pres = FALSE;

#ifdef SPTV2

#endif /* SPTV2 */

         /* on GSM route no return on error option will be set */
         /* sp040.302 - removal - gsm routes handling separated
          * if (ucb->rCb->swtch == LSP_SW_GSM0806)
          *  ucb->ud->qos.retOpt = REC_NSO;
          */

         /* calculate max data length to be accomodated in one msg */
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
         {
/* sp043.302 - modification - for China variant using ANSI header define */
            if (ucb->rCb->swtch == LSP_SW_CHINA)
            {
               udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN_ANSI;
               xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN_ANSI;
            }
            else
            {
               udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
               xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN;
            }
         }
         else
         {
/* sp043.302 - modification - for China variant using ANSI header define */
            if (ucb->rCb->swtch == LSP_SW_CHINA)
            {
               udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN_ANSI;
               xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN_ANSI;
            }
            else
            {
               udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;
               xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN;
            }
         }

         /* check if segmentation required */
         if (mLen <= xudt_maxdlen)
         {
            /* no segmentation is needed, just send data out */
#ifdef SP_TX_XUDT
            ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
            ucb->seg = FALSE;
            ucb->segRemain = 0;
            ucb->ref = 0;
            ucb->dataType = M_XUNITDATA;
            mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
#else
            ucb->dataType = M_UNITDATA;
            mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
#endif /* SP_TX_XUDT */
         }
         else
         {
#ifndef SP_TX_XUDT
            if (mLen <= udt_maxdlen)
            {
               ucb->dataType = M_UNITDATA;
               mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
            }
            else
#endif /* SP_TX_XUDT */
               if (mLen > MAXNUMSEG * xudt_maxdlen)
               {
                  /* data is too long for segmentation */
                  spCb.sts.segErr++;

                  SPLOGERROR(ERRCLS_DEBUG, ESP144, (ErrVal) mLen,
                             "Segmentation failed - Data too large");
                  spDropMsg(&mBuf);
                  spHndlStatInd(ucb, (U8) RTC_UNQUAL, NULLP);
                  RETVOID;
               }
               else
               {
                  /* Send as segmented XUDT */
                  spSegData(ucb, mBuf, mLen, xudt_maxdlen, FROM_UPPER);
                  RETVOID;
               }
         }
         break;
      } /* case LSP_SW_ITU92 */

      /* sp040.302 - modification - handling for gsm routes separated from
       * itu92 because route swtch GSM is applicable for both ANSI and ITU
       * network and so based on network variant, handling will be done.
       */
      case LSP_SW_GSM0806:
      {
         /* calculate calling/called address length */
         cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                              ucb->rCb->nSap->nwData->variant);
         cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                              ucb->rCb->nSap->nwData->variant);
 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (cgLen == 0 || cdLen == 0)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) ucb->rCb->swtch,
                       "error calculating calling/called address length");
            RETVOID;
         }
#endif /* ERRCLASS */
 
         /* GSM routes does not support importance, mark it no present */
         ucb->imp.pres = NOTPRSNT;

         /* GSM routes do not support message type interworking,
          * mark presence of message type interworking as FALSE
          */
         ucb->spMti.pres = FALSE;

#ifdef SPTV2

#endif /* SPTV2 */

         /* on GSM route no return on error option will be set */
         ucb->ud->qos.retOpt = REC_NSO;

         /* calculate message length based on network variant. GSM route is
          * applicable in both ansi and itu netrowks.
          */
         if (ucb->rCb->nSap->nwData->variant == LSP_SW_ITU)
         {
            /* calculate max data length to be accomodated in one msg */
            if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
            {
               udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
               xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN;
            }
            else
            {
               udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;
               xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN;
            }
         }
         else
         {
            if (ucb->rCb->nSap->nwData->variant == LSP_SW_ANS)
            {
               /* calculate max data length to be accomodated in one msg */
               if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
               {
                  udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN_ANSI;
                  xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen
                                 - XUDHDRLEN_ANSI;
               }
               else
               {
                  udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen
                                - UDHDRLEN_ANSI;
                  xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen
                                 - XUDHDRLEN_ANSI;
               }
            }
            else
            {
               /* error invalid variant */
               SPLOGERROR(ERRCLS_DEBUG, ESPXXX,
                  (ErrVal) ucb->rCb->nSap->nwData->variant,
                  "Error, LSP_SW_GSM0806 route is valid only in itu or ansi");
               spDropMsg(&mBuf);
               spHndlStatInd(ucb, (U8) RTC_UNQUAL, NULLP);
               RETVOID;
            }
         }

         /* check if segmentation required */
         if (mLen <= xudt_maxdlen)
         {
            /* no segmentation is needed, just send data out */
#ifdef SP_TX_XUDT
            ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
            ucb->seg = FALSE;
            ucb->segRemain = 0;
            ucb->ref = 0;
            ucb->dataType = M_XUNITDATA;
            mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
#else
            ucb->dataType = M_UNITDATA;
            mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
#endif /* SP_TX_XUDT */
         }
         else
         {
#ifndef SP_TX_XUDT
            if (mLen <= udt_maxdlen)
            {
               ucb->dataType = M_UNITDATA;
               mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
            }
            else
#endif /* SP_TX_XUDT */
               if (mLen > MAXNUMSEG * xudt_maxdlen)
               {
                  /* data is too long for segmentation */
                  spCb.sts.segErr++;

                  SPLOGERROR(ERRCLS_DEBUG, ESPXXX, (ErrVal) mLen,
                             "Segmentation failed - Data too large");
                  spDropMsg(&mBuf);
                  spHndlStatInd(ucb, (U8) RTC_UNQUAL, NULLP);
                  RETVOID;
               }
               else
               {
                  /* Send as segmented XUDT */
                  spSegData(ucb, mBuf, mLen, xudt_maxdlen, FROM_UPPER);
                  RETVOID;
               }
         }
         break;
      } /* case LSP_SW_GSM0806 */


      case LSP_SW_ITU96:
      {
         /* calculate length of cgAddr and cdAddr */
         cgLen = spGetAddrLen(&ucb->ud->cgAddr,
                              ucb->rCb->nSap->nwData->variant);
         cdLen = spGetAddrLen(&ucb->ud->cdAddr,
                              ucb->rCb->nSap->nwData->variant);
 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (cgLen == 0 || cdLen == 0)
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP147, (ErrVal) 0,
                       "error calculating calling/called address length");
            RETVOID;
         }
#endif /* ERRCLASS */
 
         /* ITU does not support message type interworking,
          * mark presence of message type interworking as FALSE
          */
         ucb->spMti.pres = FALSE;

#ifdef SPTV2

#endif /* SPTV2 */

         /* calculate max data length to be accomodated in one msg */
         if (ucb->rCb->nSap->msgLen > MAXNSAPMSGSIZE)
         {
            udt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - UDHDRLEN;
            xudt_maxdlen = MAXNSAPMSGSIZE - cgLen - cdLen - XUDHDRLEN;
         }
         else
         {
            udt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - UDHDRLEN;
            xudt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - XUDHDRLEN;
         }

         ludt_maxdlen = ucb->rCb->nSap->msgLen - cgLen - cdLen - LUDHDRLEN;

         if (mLen <= xudt_maxdlen)
         {
            /* no segmentation is needed, just send data out */
#ifdef SP_TX_XUDT
            ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
            ucb->dataType = M_XUNITDATA;
            ucb->seg = FALSE;
            ucb->segRemain = 0;
            ucb->ref = 0;
            mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
#else
            /* if importance is not present send message as UDT
             * else if importance send message as XUDT
             */
            if (ucb->imp.pres == NOTPRSNT)
            {
               ucb->dataType = M_UNITDATA;
               mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
            }
            else
            {
               ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
               ucb->dataType = M_XUNITDATA;
               ucb->seg = FALSE;
               ucb->segRemain = 0;
               ucb->ref = 0;
               mBuf = spEncCLMsg(M_XUNITDATA, ucb, &mBuf);
            }
#endif /* SP_TX_XUDT */
         }
         else
         {
#ifndef SP_TX_XUDT
            /* if message can be sent in one udt and if importance
             * is not present send message as UDT
             */
            if ((mLen <= udt_maxdlen) && (ucb->imp.pres == NOTPRSNT))
            {
               ucb->dataType = M_UNITDATA;
               mBuf = spEncCLMsg(M_UNITDATA, ucb, &mBuf);
            }
            else
#endif /* SP_TX_XUDT */
               if ((mLen <= ludt_maxdlen) &&
                   (ucb->rCb->flag & LSP_NW_BROADBAND))
               {
                  /* Send LUDT */
                  ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
                  ucb->dataType = M_LUNITDATA;

                  ucb->seg = FALSE;
                  ucb->segRemain = 0;
                  ucb->ref = 0;
                  mBuf = spEncCLMsg(M_LUNITDATA, ucb, &mBuf);
               }
               else
               {
                  if (mLen > MAXNUMSEG * xudt_maxdlen)
                  {
                     /* data is too long for segmentation */
                     spCb.sts.segErr++;

                     SPLOGERROR(ERRCLS_DEBUG, ESP148, (ErrVal) mLen,
                                "Segmentation failed - Data too large");
                     spDropMsg(&mBuf);
                     spHndlStatInd(ucb, (U8) RTC_SEGFAILURE, NULLP);
                     RETVOID;
                  }
                  else
                  {
                     /* Send as segmented XUDT */
                     spSegData(ucb, mBuf, mLen, xudt_maxdlen, FROM_UPPER);
                     RETVOID;
                  }
               }
         }
         break;
      } /* end of ITU96 */


      default:
      {
         /* invalid route switch, should never happen
          * give state indication up, log error and return
          */
         spHndlStatInd(ucb, (U8) RTC_UNQUAL, mBuf);
         SPLOGERROR(ERRCLS_INT_PAR, ESP151, (ErrVal) ucb->rCb->swtch,
                    "invalid route switch value");
         RETVOID;
      }
   } /* switch (ucb->rCb->swtch) */

   /* Deliver Data - no segementation was required */

   if (mBuf == (Buffer *) NULLP)
      RETVOID;

   /* find length of encoded message (UDT) */
   ret = SFndLenMsg(mBuf,&mLen);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP152, (ErrVal) ret,
                 "SFndLenMsg failed - Buffer = NULLP");
      RETVOID;
   }
#endif /* ERRCLASS */

   /* check if encoded message exceeds nSap message len */
   if (mLen > ucb->rCb->nSap->msgLen)
   {
      /* Message is too long. Drop the message, we have
       * already encoded it so it is meaningless to our user
       */
      spDropMsg(&mBuf);
      spHndlStatInd(ucb, (U8) RTC_UNQUAL, NULLP);
      RETVOID;
   }

   /* deliver message to lower layer */
   spDelvUDatDown(ucb, FROM_UPPER, mBuf);

   /* Update Statistics */
   if (ucb->dataType == M_UNITDATA)
      spCb.sts.uDataTx++;
   else
      if (ucb->dataType == M_XUNITDATA)
         spCb.sts.xuDataTx++;
      else
         if (ucb->dataType == M_LUNITDATA)
            spCb.sts.luDataTx++;

   (ucb->ud->qos.pClass == PCLASS0)?spCb.sts.msgTxC0++:spCb.sts.msgTxC1++;

   RETVOID;
} /* spUiHndlSegData */

  
/*
*
*       Fun:   spSegData
*
*       Desc:  segment connection less message and send each segment
*              as an XUDT.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void spSegData
(
SpUdCb *ucb,         /* unit data control block */
Buffer *mBuf,        /* message buffer */
MsgLen mLen,         /* message length */
MsgLen maxdlen,      /* maximum message data length */
U8 from              /* Direction */
)
#else
PRIVATE Void spSegData(ucb, mBuf, mLen, maxdlen, from)
SpUdCb *ucb;         /* unit data control block */
Buffer *mBuf;        /* message buffer */
MsgLen mLen;         /* message length */
MsgLen maxdlen;      /* maximum message data length */
U8 from;             /* Direction */
#endif
{
   SpXUdRef  ref;    /* segmentation reference */

   TRC2(spSegData);

   /* 
    * if data is class 0, we need to handle it as a class 1 message
    * also we need to put the same SLS in all the segments. The SLS 
    * cannot be decided in the spDelvUDatDown function. It will be too 
    * late.
    * For Class 1 mesages requiring segmentation, the sls has been 
    * decided before this function is called.
    */
   if (ucb->ud->qos.pClass == PCLASS0)
   {
      ucb->ud->qos.pClass = PCLASS1;
      ucb->seq = FALSE;
      /* 
       * The dpc will be present as this function is only called 
       * after doing GTT and checking the route value.
       */
      ucb->sls = spGetSls(ucb->rCb->nSap->nwData, ucb->dpc);
   }
   else
      ucb->seq = TRUE;    /* sls already assigned for class 1 */

#ifndef ZP         
   spGetXUdRef(&ref, ucb->rCb->nSap->nwData);
#else
   if (zpGetXUdRef(&ref, ucb))
#endif
   {
      Buffer *txData; 
      Buffer *rmData;
      S16 segRemain;
   
      txData = mBuf;
      rmData = (Buffer *) NULLP;
      segRemain = (S8) ((mLen - 1) / maxdlen);
      ucb->seg = TRUE; /* initialize segmentation info */
      ucb->dataType = M_XUNITDATA;
      if (from == FROM_UPPER)
      {
         ucb->hopCntr = ucb->rCb->nSap->nwData->defHopCnt;
      }
      ucb->firstSeg = TRUE;
      ucb->ref = ref;
      ucb->ud->cdAddr.sw = ucb->rCb->nSap->nwData->variant;
      ucb->ud->cgAddr.sw = ucb->rCb->nSap->nwData->variant;
      do 
      {
         SSegMsg(txData, maxdlen, &rmData);  /* segment data */
         ucb->segRemain = (U8) segRemain; 
         txData = spEncCLMsg(M_XUNITDATA, ucb, &txData);

         /* deliver message to lower layer */
         spDelvUDatDown(ucb, from, txData);

         /* update statistics counters */
         spCb.sts.xuDataTx++;  
         spCb.sts.msgTxC1++;

         segRemain--;
         txData = rmData;
         ucb->firstSeg = FALSE;

#ifdef SP_SEG_RETOPT
         /* if SP_SEG_RETOPT flag is enabled, then only for the
          * BELL05 route, set no return on error for subsequent
          * segmented XUDTs. If the flag is not enabled, then by
          * default, no return on error option will be sent in
          * non-first XUDT segments.
          */
#else
         ucb->ud->qos.retOpt = REC_NSO;
#endif /* SP_SEG_RETOPT */
      } 
      while (segRemain >= 0);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (rmData != (Buffer*) NULLP)
      { 
         /* Something is wrong, there should be no more data left */ 
         SPLOGERROR(ERRCLS_DEBUG, ESP153, (ErrVal) ERRZERO,
                    "data not segmented properly");
         RETVOID;
      }
#endif /* ERRCLASS */
   }

   RETVOID;
} /* spSegData */

#ifndef ZP
  

/*
*
*       Fun:   spGetXUdRef
*
*       Desc:  Get extended unit data messages reference number for 
*              segmentation of unit data (for CCITT92 only).
*
*       Ret:   TRUE (if this is changed. chk the full implemenation 
*              for usage of spGetXUdRef.
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Bool spGetXUdRef
(
SpXUdRef *ref,         /* reference number */
SpNwCb *nwData         /* network control block */
)
#else
PRIVATE Bool spGetXUdRef(ref, nwData)
SpXUdRef *ref;          /* reference number */
SpNwCb *nwData;         /* network control block */
#endif
{
   TRC2(spGetXUdRef);

   /* sp003.302 - Corrected the calculation of reference number */
   *ref = ((nwData->xUdRefCount++) & SP_MAXXUDREF);

   RETVALUE(TRUE);

} /* end of spGetXUdRef */
#endif /* ZP */

  
/*
*
*       Fun:   spLiHndlSegData
*
*       Desc:  Handle a segmented message from a Lower Interface.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE Void spLiHndlSegData
(
SpUdCb *ucb,            /* unit data control block */
Buffer *mBuf            /* data buffer */
)
#else
PRIVATE Void spLiHndlSegData(ucb, mBuf)
SpUdCb *ucb;            /* unit data control block */
Buffer *mBuf;           /* data buffer */
#endif
{
   S16  ret;
   SpXUdCb *xUdCb;

   TRC2(spLiHndlSegData)

   /* find extended unit data control block (build one if necessary) */
   xUdCb = spFindXUdCb(ucb,mBuf);

   if (xUdCb == (SpXUdCb *) NULLP)
   {
      /* No control block match or no more resource left for connections */
      /* Discard message. */
      spDropMsg(&mBuf);
      RETVOID;
   }

   /* check to see if segment number is okay */
   if (ucb->segRemain != xUdCb->segRemain)
   {
      /* reassembly error, initiate procedure to return message to user */
      /* I am only returning the first segment.  */

      /* First dump the current message */

      ret = SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP154, (ErrVal) ret, "SPutMsg failed");
      }
#endif /* ERRCLASS */

      /* reconfigure ucb to return the first segment */
      /* return address already in ucb */
      ucb->segRemain = xUdCb->initNumSeg;
      ucb->firstSeg = TRUE;
      ucb->seg = TRUE;
      ucb->ref = xUdCb->ref;

      /* split off first segment */
#if (ERRCLASS & ERRCLS_DEBUG)
      if (xUdCb->firstSegLen > ucb->nSap->msgLen)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP155, (ErrVal) ret, "SPutMsg failed");
         RETVOID;
      }
#endif /* ERRCLASS */

      SSegMsg(xUdCb->segBuf, xUdCb->firstSegLen, &mBuf);

      if (mBuf!= (Buffer*)NULLP)
      {
         ret = SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret != ROK)
         { 
            SPLOGERROR(ERRCLS_DEBUG, ESP156, (ErrVal) ret, "SPutMsg failed");
            RETVOID;
         }
#endif /* ERRCLASS */
      }

      spReturnMsg(ucb, RTC_NOREASSEMB, xUdCb->segBuf);

      /* free control block */
      xUdCb->used = FALSE;

#ifdef ZP
      zpDelMapping (ZP_SP_XUDCB, xUdCb);
#endif /* ZP */

      /* Stop reassembly time out clock */
      spRmvXUdTq(xUdCb);

      RETVOID;
   }

   /* do reassembly */
   if (ucb->firstSeg)
   {
      xUdCb->segBuf = mBuf;

      ret = SFndLenMsg(mBuf, &xUdCb->firstSegLen);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP157, (ErrVal) ret,
                    "SFndLenMsg failed - Buffer = NULLP");
         RETVOID;
      }
#endif /* ERRCLASS */

      /* Start timer for reassembly of segmented data */
      xUdCb->tmr.enb = TRUE;
      xUdCb->tmr.val = ucb->nwData->defAsmbTmr.val;
      spStartXUdTmr(xUdCb);
   }
   else
   {
      ret = SCatMsg(xUdCb->segBuf, mBuf, M1M2);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP158, (ErrVal) ret,
                    "SFndLenMsg failed - Buffer = NULLP");
         RETVOID;
      }
#endif /* ERRCLASS */

      ret = SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP159, (ErrVal) ret, "SPutMsg failed");
         RETVOID;
      }
#endif /* ERRCLASS */
   }

   /* check to see if this is the last segment  */
   /* send data upstair if this is the last seg */
   if (ucb->segRemain == 0)
   {
      /* Stop reassembly time out clock */
      spRmvXUdTq(xUdCb);

      /* release the control block */
      xUdCb->used = FALSE;

#ifdef ZP
      zpDelMapping (ZP_SP_XUDCB, xUdCb);
#endif /* ZP */

      /* check if the user has bound */
      if (ucb->sap->status & SP_BND)
      {
         ucb->sap->sts.msgRxC1++;
         /* sp047.302 - Addition - Statistics added for message Interception */
#ifdef LSPV2_5
         ucb->sap->sts.msgInterceptRxC1++;
#endif /* LSPV2_5 */

         /*BEGIN:add by wanglijun.*/
         SPDBGP(SP_DBGMASK_DATA_MSG, (spCb.spInit.prntBuf,
                 "********SCCP send unitdata msg to upper layer ,suId(%d),opc(0x%d),dpc(0x%d)*******\n",
                 ucb->sap->suId, ucb->opc, ucb->dpc));
         /*END:add by wanglijun*/

         /* call indication primitive */
         (Void) SpUiSptUDatInd(&ucb->sap->pst, ucb->sap->suId, ucb->opc, 
                               ucb->ud, xUdCb->segBuf);
      }
      RETVOID;
   }

   /* decrement segRemain counter */
   --xUdCb->segRemain;
   RETVOID;
} /* spLiHndlSegData */

  
/*
*
*       Fun:   spMatchAddr
*
*       Desc:  Check to see if 2 addresses match 
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Bool spMatchAddr
(
TknStr* adr1,           /* address1 */
TknStr* adr2            /* address2 */
)
#else
PUBLIC Bool spMatchAddr(adr1, adr2)
TknStr* adr1;           /* address1 */
TknStr* adr2;           /* address2 */
#endif
{
   S16 i;

   TRC2(spMatchAddr)

   if ((!adr1->pres) || (!adr2->pres))
      RETVALUE(FALSE);

   /* check to see if address length match */
   if (adr1->len != adr2->len)
      RETVALUE(FALSE);

   if (adr1->len <= MF_SIZE_TKNSTR)
   {
      /* check to see if address string match */
      for (i=0; i<(S16)adr1->len; ++i)
      {
         if (adr1->val[i] != adr2->val[i])
            RETVALUE(FALSE); 
      }
      RETVALUE(TRUE);
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   else
   {
      SPLOGERROR(ERRCLS_DEBUG, ESP160, (ErrVal) adr1->len,
                 "invalid address length");
   }
#endif /* ERRCLASS */
   RETVALUE(FALSE);

} /* spMatchAddr */

  
/*
*
*       Fun:   spFindXUdCb
*
*       Desc:  Find extended unit data control block for reassembly 
*
*       Ret:   Extended unid data control block
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE SpXUdCb* spFindXUdCb
(
SpUdCb *ucb,            /* unit data control block */
Buffer *mBuf            /* data buffer */
)
#else
PRIVATE SpXUdCb* spFindXUdCb(ucb, mBuf)
SpUdCb *ucb;            /* unit data control block */
Buffer *mBuf;           /* data buffer */
#endif
{
   U16 i;
   SpXUdCb *xUdCb,*newCb;
   S16  ret;
#ifdef ZP
   ZpAMSpXUdCb zpAMSpXUdCb; /* sp011.302 - added semi-colon */
#endif /* ZP */

   TRC2(spFindXUdCb)

   UNUSED(mBuf);

   /* loop through all the control blocks of this sap
    * to find a match
    */ 
   newCb = (SpXUdCb *) NULLP;
   xUdCb = (SpXUdCb *) NULLP;

   for (i = 0; i < spCb.spCfg.nmbXUdCb; ++i)
   {
      if (ucb->nSap->xUdCb == (SpXUdCb **) NULLP)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP161, (ErrVal) 0,
                    "extended unit data control blocks not configured");
         RETVALUE((SpXUdCb *) NULLP);
      }
      xUdCb = ucb->nSap->xUdCb[i];
      if (xUdCb == (SpXUdCb *) NULLP)
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP162, (ErrVal) 0,
                    "extended unit data control blocks not configured");
         RETVALUE((SpXUdCb *) NULLP);
      }
      if (xUdCb->used)
      {
         if ((ucb->ref == xUdCb->ref) 
             && (spMatchAddr(&xUdCb->cgAddrStr, ucb->cgAddrStr)))
            break;
      }
      else    /* take note of unused control block */
         if (newCb == (SpXUdCb *) NULLP)
         {
            newCb = xUdCb;
         }
   } /* for (i = 0; i < spCb.spCfg.nmbXUdCb; ++i) */

   if (i >= spCb.spCfg.nmbXUdCb) 
   {  
      /* no matching control block found */
      if (ucb->firstSeg)
      {
         if (newCb == (SpXUdCb *) NULLP)
         {
            /* all the Xudt reassembly control blocks are exhausted
             * update statistics for reassembly failure
             */
            spCb.sts.reassemErrNoSpc++;
            RETVALUE((SpXUdCb *) NULLP);
         }
         /* put in addresses, reference number, and other information */
         newCb->used = TRUE;
         newCb->ref = ucb->ref;
         newCb->segRemain = ucb->segRemain;
         newCb->initNumSeg = ucb->segRemain;

         /* fill in address string */
         newCb->cgAddrStr.pres = ucb->cgAddrStr->pres;
         newCb->cgAddrStr.len = ucb->cgAddrStr->len;
         if (ucb->cgAddrStr->len <= MF_SIZE_TKNSTR)
            for (i=0; i<ucb->cgAddrStr->len; ++i)
               newCb->cgAddrStr.val[i] = ucb->cgAddrStr->val[i]; 
#ifdef ZP
         zpAMSpXUdCb.sls = ucb->sls;
         zpAMSpXUdCb.cdPc = ucb->dpc;
         zpAMSpXUdCb.cdSsn = ucb->sap->ssn;         
         zpAMSpXUdCb.nSap = ucb->nSap;
         zpAddMapping(ZP_SP_XUDCB, (Void *)newCb, (Void *)&zpAMSpXUdCb);
#endif /* ZP */
         RETVALUE(newCb);
      }
      else /* no control block found for non first segment data */  
         RETVALUE((SpXUdCb *) NULLP);
   }
   else /* matching control block found */
   {
      if (ucb->firstSeg)
      {
         /* we have duplicated first seg data.        */
         /* we shouldn't find any control block here  */

         /* junk the current reassembly control block */ 
         xUdCb->used = FALSE;

#ifdef ZP
         zpDelMapping(ZP_SP_XUDCB, xUdCb);
#endif /* ZP */

         /* Stop reassembly time out clock */
         spRmvXUdTq(xUdCb);

         if (xUdCb->segBuf != (Buffer *) NULLP)
         {
            ret = SPutMsg(xUdCb->segBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
            if (ret != ROK)
            { 
               SPLOGERROR(ERRCLS_DEBUG, ESP163, (ErrVal) ret,"SPutMsg failed");
            }
#endif /* ERRCLASS */
            /* sp028.302 - addition - initialise segBuf */
            xUdCb->segBuf = (Buffer *) NULLP;
         }

         /* increment statistics counter for reassembly failure due
          * to duplicated segments
          */
         spCb.sts.reassemErr++;

         RETVALUE((SpXUdCb *) NULLP);
      }
      else
         /* return control block found */
         RETVALUE(xUdCb);
   }
} /* spFindXUdCb */

  
/*
*
*       Fun:    spPrcXUdTq
*
*       Desc:   Processes extended unit data control block Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   cp_bdy2.c
*
*/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 spPrcXUdTq
(
ProcId  proc,
Ent     ent,
Inst    inst
)
#else
PUBLIC S16 spPrcXUdTq(proc, ent, inst)
ProcId  proc;
Ent     ent;
Inst    inst;
#endif
#else /* SS_MULTIPLE_PROCS */  
#ifdef ANSI
PUBLIC S16 spPrcXUdTq
(
void
)
#else
PUBLIC S16 spPrcXUdTq()
#endif
#endif /* SS_MULTIPLE_PROCS */
{
   TRC2(spPrcXUdTq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(proc, ent, inst, (Void **)&spCbPtr)) != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spPrcXudTq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        
#endif 

#ifdef ZP
   if (!zpCb.freezeTmr)
#endif /* ZP */
      cmPrcTmr(&spCb.spXUdTqCp, spCb.spXUdTq, spXUdTmrEvnt);
   RETVALUE(ROK);
} /* end of spPrcXUdTq */
 
  
/*
*
*       Fun:    spRmvXUdTq
*
*       Desc:   Removes control block from Timing Queue
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvXUdTq
(
SpXUdCb *cb       /* control block */
)
#else
PUBLIC Void spRmvXUdTq(cb)
SpXUdCb *cb;      /* control block */
#endif
{
   CmTmrArg arg;
 
   TRC2(spRmvXUdTq)
 
   arg.tq = spCb.spXUdTq;
   arg.tqCp = &spCb.spXUdTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = TMR_DEF;
   arg.wait = NOTUSED;
   arg.tNum = TMR0;
   arg.max = TMR_DEF_MAX;
   cmRmvCbTq(&arg);
   RETVOID;
} /* end of spRmvXUdTq */
 
  
/*
*
*       Fun:   spStartXUdTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void spStartXUdTmr
(
SpXUdCb *cb      /* control block */
)
#else
PUBLIC Void spStartXUdTmr(cb)
SpXUdCb *cb;     /* control block */
#endif
{
   CmTmrArg arg;
 
   TRC2(spStartXUdTmr)
 
   arg.tq = spCb.spXUdTq;
   arg.tqCp = &spCb.spXUdTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = TMR_DEF;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = TMR_DEF_MAX;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)          /* if wait, place on TQ */
      cmPlcCbTq(&arg);
   RETVOID;
} /* end of spStartXUdTmr */
 
  
/*
*
*       Fun:   spXUdTmrEvnt
*
*       Desc:  Extended Unit Data Timer Event 
*
*       Ret:   None
*
*       Notes: Called whenever time to assemble segmented extended unit
*              data expires.  Return the extended unit data. 
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spXUdTmrEvnt
(
PTR cbp,
S16 evnt
)
#else
PUBLIC Void spXUdTmrEvnt(cbp, evnt)
PTR cbp;
S16 evnt;
#endif
{
   SpXUdCb *xUdCb;        /* XUDT control block */
 
   TRC2(spXUdTmrEvnt)

   UNUSED(evnt);
#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP164, (ErrVal) 0, 
                 "spXUdTmrEvnt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */

   xUdCb = (SpXUdCb *)cbp;

   /* Discard the message when reassembly time expires. */
   /* Release the control block and free up memory. */
   xUdCb->used = FALSE;

#ifdef ZP
   zpDelMapping (ZP_SP_XUDCB, xUdCb);
#endif /* ZP */

   spDropMsg(&xUdCb->segBuf);

   /* increment statistics for reassembly failure due to timer expiry */
   spCb.sts.reassemErrTimExp++;

   RETVOID;
} /* spXUdTmrEvnt */
 
  
/*
*
*       Fun:   spGetAddrLen
*
*       Desc:  get length of global title in octet 
*
*       Ret:   Global title length 
*
*       Notes: Used to determine the size of data portion in extended
*              unit data. 
*              Global title assumed in CCITT format.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 spGetAddrLen
(
SpAddr *addr,
Swtch swtch
)
#else
PRIVATE S16 spGetAddrLen(addr, swtch)
SpAddr *addr;
Swtch swtch;
#endif
{
   S16 retLen;
   U8 adjFrmt;

   TRC2(spGetAddrLen)

   retLen = 0;

   retLen += ADDRINDLEN;

   /* sp001.30 - LSP_SW_CHINA being removed from the below if statement as it
      should use an ANSI point code length */
   /* for japan variant also, use dpc len as in itu, for in itu dpc
    * length is 2 octets though the pc is 14 bits and in japan dpc is
    * 16 bits and will be accomodated in 2 octets
    */
   if (addr->pcInd)
      retLen += ((swtch == LSP_SW_ITU)
                ) ?  CCITT_DPCLEN : ANSI_DPCLEN;

   if (addr->ssnInd)
      retLen += SSNLEN;

      adjFrmt = addr->gt.format;

   switch (adjFrmt)
   {
      case GTFRMT_0:
         break;
      case GTFRMT_1:
      {
         retLen += addr->gt.addr.length;
         if ((swtch == LSP_SW_ITU) ||
             (swtch == LSP_SW_CHINA)) 
            retLen += CCITT_FM1HDLEN;
#if (ERRCLASS & ERRCLS_DEBUG)
         else
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP165, (ErrVal) swtch, "invalid switch");
            RETVALUE((S16) 0);
         }
#endif /* ERRCLASS */
         break;
      }
      case GTFRMT_2:
      {
         retLen += addr->gt.addr.length; 
         if ((swtch == LSP_SW_ITU) ||
             (swtch == LSP_SW_CHINA))
            retLen += CCITT_FM2HDLEN;
         else
            retLen += ANSI_FM2HDLEN;
         break;
      }
      case GTFRMT_3:
      {
         retLen += addr->gt.addr.length;
         if ((swtch == LSP_SW_ITU) ||
             (swtch == LSP_SW_CHINA))
            retLen += (S16)CCITT_FM3HDLEN;
         else
            retLen += ANSI_FM1HDLEN;
         break;
      }
      case GTFRMT_4:
      {
         retLen += addr->gt.addr.length;
         if ((swtch == LSP_SW_ITU) ||
             (swtch == LSP_SW_CHINA))
            retLen += (S16)CCITT_FM4HDLEN;
#if (ERRCLASS & ERRCLS_DEBUG)
         else
         {
            SPLOGERROR(ERRCLS_DEBUG, ESP166, (ErrVal) swtch,
                       "invalid switch and global title format combination");
            RETVALUE((S16) 0);
         }
#endif /* ERRCLASS */
         break;
      }
      default:
      {
         SPLOGERROR(ERRCLS_DEBUG, ESP167, (ErrVal) adjFrmt,
                    "invalid switch and global title format");
         break;
      }
   }
 
   RETVALUE(retLen);
} /* spGetAddrLen */

  
/*
*
*
*       Fun:   spDisableUpperSap
*
*       Desc:  This function unbinds and disables specified STTSAP.
*              It will cleanup all resources related to this SAP and
*              change the sap status
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  cp_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 spDisableUpperSap
(
SpSapCb *sap       /* transport sap */
)
#else
PUBLIC S16 spDisableUpperSap(sap)
SpSapCb *sap;      /* transport sap */
#endif
{
   Smi smi;          /* subsystem multiplicity indicator */
   
   TRC2(spDisableUpperSap)

#ifdef SP_RUG
   /* sp014.301 - addition - mark validity of remote interface version
    * number in pst as FALSE _only_ if version controlling entity is not
    * layer manager
    */
   if (sap->verContEnt != ENTSM)
      sap->remIntfValid = FALSE;
#endif /* SP_RUG */

   if (!(sap->status & SP_BND))
   {
      RETVALUE(ROK);
   }

   if (sap->status & SP_PROH)
   {
      /* disable sap */
      sap->status ^= SP_BND;
      RETVALUE(ROK);
   }

   if (sap->nmbBpc)
      smi = SMI_DUP;
   else
      smi = SMI_SOL;

   if (sap->status & SP_IGNR)
   {
      spRmvSapCbTq(sap, TMR_IGN);
      sap->status ^= SP_IGNR;
   }
   else if ((sap->status & SP_GRNT))
   {
      spRmvSapCbTq(sap, TMR_GRT);
      sap->status ^= SP_GRNT;
   }


   spBroadcast(sap->nwData, sap->nwData->selfPc, sap->nwData->selfPc, sap->ssn,
               smi, SCMG_SSP);
   spLocalBroadcast(SS_UOS, sap->nwData->variant, sap->nwData->selfPc, sap->ssn,
                    smi, (U8) NOTUSED, (U8) NOTUSED, (U8) FROM_UPPER);
   /* disable sap */
   sap->status ^= SP_BND;
   if (spCb.ustaMask & LSP_USTAALARM) /* unsolicited status */
      spSendLmSta(LCM_CATEGORY_PROTOCOL, LSP_EVENT_USER_OOS, 
                  LCM_CAUSE_USER_INITIATED, (U8) sap->nwData->variant,
                  (U8) sap->spId); 
   RETVALUE(ROK);
} /* spDisableUpperSap */

  
/*
*       Fun:   spDisableLowerSap
*
*       Desc:  This function unbinds and disables specified STNSAP.
*              It will cleanup all resources related to this SAP and
*              change the sap status
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  cp_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 spDisableLowerSap
(
SpNSapCb *nSap       /* network sap */
)
#else
PUBLIC S16 spDisableLowerSap(nSap)
SpNSapCb *nSap;      /* network sap */
#endif
{
    S16 i;             /* counter */
    PTR hl;            /* list entry */
    SpRteCb *rCb;      /* route control block */
    Smi smi;           /* subsystem multiplicity indicator */
    S16 ret;           /* return value */
    U8 tNum;           /* timer number */

    TRC2(spDisableLowerSap)

    if (nSap == (SpNSapCb *)NULLP)
    {
       SPLOGERROR(ERRCLS_DEBUG, ESP168, (ErrVal) 0, 
                           "spDisableLowerSap(). Null NSAP pointer");
       RETVALUE(RFAILED);
    }

    /* sp001.302 - addition - check if nSap is unbound, could be a 
     * repeated ubnd-disable request, return ok
     */
    if (!((nSap->status & SP_BND) || (nSap->status & SP_WAIT_BNDCFM)))
    {
       RETVALUE(ROK);
    }

    /* clear sap status */
    nSap->status &= ~(SP_WAIT_BNDCFM | SP_BND | SP_GUARD | SP_SNRST);

    /* clear any timer started for this NSAP */
    for (tNum = 0; tNum < MAXNSAPTMR; tNum++)
    {
       if (nSap->timers[tNum].tmrEvnt != TMR_NONE)
       {
          spRmvNSapTq(nSap, nSap->timers[tNum].tmrEvnt);
       }
    }

    /* 
     * go through the rte hash list and for all the rte's which 
     * have a switch match with NSAP, take proper actions
     */
    hl = (PTR)NULLP;
    for(;;)
    {
       if ((ret = cmHashListGetNext(&spCb.rteHlCp, hl, (PTR *)&rCb)) == ROK)
       {
          if (nSap == rCb->nSap) 
          {
             if (rCb->status & SP_ONLINE)
             {
                /* mark it offline */
                rCb->status &= SP_OFFLINE;

                /* check all subsystems */
                for (i = 0; i < rCb->nmbSsns; i++)
                {
                   /* disable subsystem status test */
                   if (rCb->ssnList[i].ssFlgs & TMR_SST)
                   {
                      spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
                      rCb->ssnList[i].ssFlgs &= (U8)(~TMR_SST); 
                   }
      
                   /* set smi */
                   if (rCb->ssnList[i].nmbBpc)
                      smi = SMI_DUP;
                   else
                      smi = SMI_SOL;
      
                   /* mark subsystem prohibited */
                   rCb->ssnList[i].status &= SS_INACC;

                   /* local broadcast of UOS */
                   spLocalBroadcast((U8) SS_UOS, nSap->nwData->variant,
                                    rCb->dpc, rCb->ssnList[i].ssn, smi,
                                    rCb->sccpSts, rCb->spRestrictComp.ril,
                                    (U8) FROM_LOWER);
                }

                if (rCb->nmbBpc)
                   smi = SMI_DUP;
                else
                   smi= SMI_SOL;
                spLocalBroadcast((U8) SP_INACC, nSap->nwData->variant, rCb->dpc,
                                 (Ssn) NOTUSED, smi, rCb->sccpSts,
                                 rCb->spRestrictComp.ril, (U8) FROM_LOWER);
             }
             else
             {
                /* nothing is required */
#ifdef SNT2
                /* stop status enquiry timer */
                spRmvRteCbTq(rCb, TMR_STA);
                rCb->rteStsFlag &= (U8) (~TMR_STA);
#endif /* SNT2 */
             }
          }
          hl = (PTR)rCb;
       } /* end if */
       else
       {
          /* no more entries */
          break;
       }
    } /* end for */

    /* 
     * Delete all associated SCLI's. The cleaup of SCLI's is done when
     * the route is marked down.
     */

/* sp028.302 - removal - remove not defined flag ZP, this is applicable
 * in all cases: conv, ftha and dftha
 */
    /* Delete all associated SpXudCb */
    /* sp001.302 - removal - check on variant removed as XudCb applicable
     * in all the variants
     */
    if (spCb.spCfg.nmbXUdCb)
    {
       for (i = 0; i < spCb.spCfg.nmbXUdCb; i++)
       {
          if ((nSap->xUdCb[i] != (SpXUdCb *)NULLP) &&
              (nSap->xUdCb[i]->used == TRUE))
          {
             /* sp028.302 - addition - stop reassem timer */
             spRmvXUdTq((SpXUdCb *) (nSap->xUdCb[i]));

             /* sp028.302 - modification - check segBuf before freeing */
             if (nSap->xUdCb[i]->segBuf != (Buffer *) NULLP)
             {
                SPutMsg(nSap->xUdCb[i]->segBuf);
                nSap->xUdCb[i]->segBuf = (Buffer *) NULLP;
             }

             /* sp028.302 - addition - mark used flag FALSE, delete mapping */
             nSap->xUdCb[i]->used = FALSE;
#ifdef ZP
             zpDelMapping(ZP_SP_XUDCB, (Void *) (nSap->xUdCb[i]));
#endif /* ZP */
          }
          /* 
           * We do not free extended unit data control block over
           * here. The reason being that teh stack manager is not
           * going to reconfigure the SAP after a Disable Lower SAP.
           */
       }
    }

    RETVALUE(ROK);
} /* end of spDisableLowerSap */

  
/*
*
*
*       Fun:   spEnableLowerSap
*
*       Desc:  This function enable and bind specified STNSAP.
*
*       Ret:   ROK/RFAILED
*
*       Notes:
*
*       File:  cp_bdy2.c
*
*/      
#ifdef ANSI
PUBLIC S16 spEnableLowerSap
(
SpNSapCb *nSapCb,      /* network sap */
U16 *reason            /* sp014.301 - addition - failure reason */
)
#else
PUBLIC S16 spEnableLowerSap(nSapCb, reason)
SpNSapCb *nSapCb;      /* network sap */
U16 *reason;           /* sp014.301 - addition - failure reason */
#endif
{
   TRC2(spEnableLowerSap)

#ifndef SP_RUG
   UNUSED(reason);
#endif /* SP_RUG */

    if (nSapCb->status & SP_BND)
    {
       RETVALUE(ROK);
    }
#ifdef SNT2
    if (nSapCb->status & SP_WAIT_BNDCFM)
    {
       RETVALUE(ROK);
    }
#endif /* SNT2 */

#ifdef SP_RUG
   /* sp014.301 - addition - binding can not be performed if sap does not 
      have a valid remote interface version number. Bind has to be performed 
      only after version synchronization has been done */
   if(nSapCb->remIntfValid == FALSE)
   {
      *reason = LCM_REASON_SWVER_NAVAIL;  /* interface version not available */
      RETVALUE(RFAILED);
   }
#endif /* SP_RUG */

#ifdef SNT2
    nSapCb->status ^= SP_WAIT_BNDCFM;    /* wait for bind confirmation */
    nSapCb->bndRetryCnt = 0;
    /* start a timer */
    nSapCb->tmr.enb = TRUE;
    nSapCb->tmr.val = spCb.spCfg.tIntTmr.val;
    spStartNSapCbTmr(nSapCb, TMR_INT);
#else
    nSapCb->status ^= SP_BND;            /* set bind flag */
#endif /* SNT2 */
      
    /* bind Service provider */
    (Void) SpLiSntBndReq(&nSapCb->pst, nSapCb->suId, nSapCb->spId,
                         nSapCb->nwData->sInfo);

    RETVALUE(ROK);
} /* end of spEnableLowerSap */

  
/*
*
*
*       Fun:   spHndlRstBeg
*
*       Desc:  Handle Restart begin.
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void spHndlRstBeg
(
SpNSapCb *nSap       /* network sap */
)
#else
PUBLIC Void spHndlRstBeg(nSap)
SpNSapCb *nSap;       /* network sap */
#endif
{
   Void *pCb;
   Void *nCb;
   S16 ret;
   S16 i;

   TRC2(spHndlRstBeg);

   /* 
    * 1. Mark all the routes associated with nSap to be inaccessible and
    * 2. do a local broadcast of PCSteInd of pc which were up.
    * 3. Take all teh actions which are taken when the pc goes 
    *    down (SN_PAUSE)- SCCP control blocks will die when their 
    *    timer (keep alive) expires.
    * 4. Mark all the rouets as down because of restart. When we get 
    *    a resume from MTP3 we wil not inform the local users. Local 
    *    users will be informed about the staus of the PC and their 
    *    subsystems only when we get the SN_RSTEND.
    */

   if ((Size)spCb.spCfg.nmbRtes > (Size)0)
   {
      pCb = (PTR)NULLP;
      nCb = (PTR)NULLP;
      
      ret = cmHashListGetNext(&spCb.rteHlCp, (PTR) pCb, (PTR *) &nCb); 
      while (ret == ROK)
      {
         SpRteCb *rCb;
         rCb = (SpRteCb *)nCb;
         if (nSap == rCb->nSap)
         {
            rCb->status &= SP_OFFLINE;
            rCb->sccpSts = RMT_SCCP_INACC;    /* remote sccp inaccessible */

            /* disable SST for remote SCCP, if in progress */
            if (rCb->rteStsFlag & TMR_SST)
            {
               spRmvRteCbTq(rCb, TMR_SST);
               rCb->rteStsFlag &= (U8) (~TMR_SST);
            }

            /* reset RLM and RSLM to zero. No need to compute traffic
             * limitation data, as remote SP and SCCP both will be
             * broadcasted (local) as inaccessible
             */
            rCb->spRestrictLocal.rlm = 0;
            rCb->spRestrictLocal.rslm = 0;
            
            /* loop through the subsystems */
            for (i = 0; i < rCb->nmbSsns; i++)
            {
               /* disable subsystem status test */
               if (rCb->ssnList[i].ssFlgs & TMR_SST)
               {
                  spRmvSsnCbTq(&rCb->ssnList[i], TMR_SST);
                  rCb->ssnList[i].ssFlgs &= (U8)(~TMR_SST); 
               }
               /* mark subsystem prohibited && translate to backup */
               rCb->ssnList[i].status &= SS_INACC;
               
               /* local broadcast of UOS */
               spLocalBroadcast((U8) SS_UOS, nSap->nwData->variant, rCb->dpc, 
                                rCb->ssnList[i].ssn, 
                                (Smi) (rCb->ssnList[i].nmbBpc?SMI_DUP:SMI_SOL), 
                                rCb->sccpSts, rCb->spRestrictComp.ril,
                                (U8) FROM_LOWER);
            }
            spLocalBroadcast((U8) SP_INACC, nSap->nwData->variant, rCb->dpc,
                             (Ssn) NOTUSED,
                             (Smi) (rCb->nmbBpc ? SMI_DUP : SMI_SOL),
                             rCb->sccpSts, rCb->spRestrictComp.ril,
                             (U8) FROM_LOWER);
#ifdef ZP            
/* sp040.302 - addition - generate RT upd for rteCb only in case of earlier
 * psf peer interface versions ZPPV1, ZPPV2 and ZPPV2_1. In case of interface
 * version ZPPV2_2 and higher, sby sccp will mark all the associated routes
 * as offline on nSap status updation of RstBeg to avoid large number of RT
 * update for each associated route Cbs.
 */
#if ((defined(ZPPV1)) || (defined(ZPPV2)) || (defined(ZPPV2_1)))
            zpRunTimeUpd(ZP_SP_RTECB, (Void *)rCb, 
                         CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ((defined(ZPPV1)) || (defined(ZPPV2)) || (defined(ZPPV2_1))) */
#endif /* ZP */
         } 
         
         pCb = nCb;
         ret = cmHashListGetNext(&spCb.rteHlCp, (PTR) pCb, (PTR *) &nCb); 
      }
   }
         
   /* Change the status */
   nSap->status |= SP_SNRST;

   /* Start the MTP3 restart status end timer */
   nSap->tmr.enb = TRUE;
   nSap->tmr.val = spCb.spCfg.defRstEndTmr.val;         
   spStartNSapCbTmr(nSap, TMR_RSTEND); 

#ifdef ZP
   zpRunTimeUpd(ZP_SP_NSAPCB, (Void *)nSap, CMPFTHA_UPDTYPE_SYNC, 
                CMPFTHA_ACTN_MOD);
#endif /* ZP */

   RETVOID;
} /* spHndlRstBeg */

  
/*
*
*
*       Fun:   spHndlRstEnd
*
*       Desc:  Handle Restart end.
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void spHndlRstEnd
(
SpNSapCb *nSap       /* network sap */
)
#else
PUBLIC Void spHndlRstEnd(nSap)
SpNSapCb *nSap;       /* network sap */
#endif
{
   Void *pCb;
   Void *nCb;
   S16 ret;

   TRC2(spHndlRstEnd);

   /* Stop the reset end timer, if running */
   spRmvNSapTq (nSap, TMR_RSTEND);

   /* 
    * For each route belonging to the nSap ......
    * 1. Do a broadcast of PC status and subsystem status 
    *    for all the PC's which are up. 
    *    Note: We dont do a broadcast to conPc's
    */
   if ((Size)spCb.spCfg.nmbRtes > (Size)0)
   {
      pCb = (PTR)NULLP;
      nCb = (PTR)NULLP;
      ret = cmHashListGetNext(&spCb.rteHlCp, (PTR)pCb, (PTR *)&nCb); 
      for (;;)
      {
         if (ret != ROK)
         {
            break;
         }
         else
         {
            SpRteCb *rCb;
            S32 i;

            rCb = (SpRteCb *)nCb;
            if ((rCb->nSap == nSap) && (rCb->status & SP_ONLINE))
            {
               /* mark remote sccp as accessible and compute traffic
                * limitation data
                */
               rCb->sccpSts = RMT_SCCP_AVAIL;

               spLocalBroadcast((U8) SP_ACC, nSap->nwData->variant, 
                                rCb->dpc, (Ssn) NOTUSED, (Smi) NOTUSED,
                                rCb->sccpSts, rCb->spRestrictComp.ril,
                                (U8) NOTUSED);
               /* All the subsystems are maked as up */ 
               for (i = 0; i < (S32) rCb->nmbSsns; i++)
                  spLocalBroadcast(SS_UIS, nSap->nwData->variant, rCb->dpc, 
                                   rCb->ssnList[i].ssn, 
                                 (Smi) (rCb->ssnList[i].nmbBpc?SMI_DUP:SMI_SOL),
                                   rCb->sccpSts, rCb->spRestrictComp.ril,
                                   (U8) FROM_LOWER);
            }
            pCb = nCb;
            ret = cmHashListGetNext(&spCb.rteHlCp, (PTR)pCb, (PTR *)&nCb); 
         }
      } /* end for */
   }

#ifdef SNT2
   spRteExtSync(nSap);         
#endif /* SNT2 */
   nSap->status &= ~SP_SNRST;
#ifdef ZP
   zpRunTimeUpd(ZP_SP_NSAPCB, (Void *)nSap, CMPFTHA_UPDTYPE_NORMAL, 
                CMPFTHA_ACTN_MOD);
#endif /* ZP */
   RETVOID;
} /* spHndlRstEnd */

#ifdef SNT2

/*
*
*
*       Fun:   spRteExtSync
*
*       Desc:  This function checks the status of all routes in the system
*              and starts status enquiry timer for sending Status request
*              to MTP3 for all routes with status SP_CONG/SPOFFLINE
*
*       Ret:   RETVOID
*
*/      
#ifdef ANSI
PUBLIC Void spRteExtSync
(
SpNSapCb *nSap       /* network sap */
)
#else
PUBLIC Void spRteExtSync(nSap)
SpNSapCb *nSap;       /* network sap */
#endif
{
   PTR hl;            /* list entry */
   SpRteCb *rCb;      /* route control block */
   S16 ret;           /* return value */

   TRC2(spRteExtSync)

   /* 
    * go through the rte hash list and for all the rte's which are
    * SP_OFFLINE/SP_CONG and have a switch match with NSAP, start 
    * status enquiry timers 
    */

   hl = (PTR)NULLP;

   for (;;)
   {
      if ((ret = cmHashListGetNext(spCb.rteCp.rCp, hl, (PTR *)&rCb)) == ROK)
      {
         if ((nSap == rCb->nSap) &&
             ((rCb->status & SP_CONG) || !(rCb->status & SP_ONLINE)))
         {
            /* start status enquiry timer */
            rCb->rteStsFlag |= TMR_STA;
            rCb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
            rCb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
            spStartRteCbTmr(rCb, TMR_STA);
         }
         hl = (PTR)rCb;
      }
      else
      {
         break;
      }
   }          
   RETVOID;
} /* spRteExtSync */
#endif /* SNT2 */

  
/*
*
*       Fun:    spPrcRteCbTq
*
*       Desc:   Processes Route control block Timing Queue
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   cp_bdy2.c
*
*/
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 spPrcRteCbTq
(
ProcId  proc,
Ent     ent,
Inst    inst
)
#else
PUBLIC S16 spPrcRteCbTq(proc, ent, inst)
ProcId  proc;
Ent     ent;
Inst    inst;
#endif
#else /* SS_MULTIPLE_PROCS */  
#ifdef ANSI
PUBLIC S16 spPrcRteCbTq
(
void
)
#else
PUBLIC S16 spPrcRteCbTq()
#endif
#endif /* SS_MULTIPLE_PROCS */
{
   TRC2(spPrcRteCbTq)
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   if((SGetXxCb(proc, ent, inst, (Void **)&spCbPtr)) != ROK)
   {
      SPLOGERROR(ERRCLS_DEBUG, ESPXXX, 0, "spPrcRteCbTq() failed, cannot derive spCb");
      RETVALUE(RFAILED);
   }        
#endif

#ifdef ZP
   if (!zpCb.freezeTmr)
#endif /* ZP */
   {
#ifdef SNT2
      cmPrcTmr(&spCb.spRteTqCp, spCb.spRteTq, spRteCbTmrEvnt);
#endif /* SNT2 */
      cmPrcTmr(&spCb.spNSapTqCp, spCb.spNSapTq, spNSapCbTmrEvnt);
   }
   RETVALUE(ROK);
} /* end of spPrcRteCbTq */


/*
*
*       Fun:    spRmvRteCbTq
*
*       Desc:   Removes control block from Timing Queue
*
*       Ret:    None
*
*       Notes:  None
*
*       File:   cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRmvRteCbTq
(
SpRteCb *cb,      /* control block */
U8 ev             /* timer event */
)
#else
PUBLIC Void spRmvRteCbTq(cb, ev)
SpRteCb *cb;      /* control block */
U8 ev;            /* timer event */
#endif
{
   U8 tNum;
   CmTmrArg arg;
   Bool found;

   TRC2(spRmvRteCbTq)

   found = FALSE;

   for (tNum = 0; tNum < MAXRTETMR; tNum++)
   {
      if (cb->timers[tNum].tmrEvnt == ev)
      {
         found = TRUE;
         break;
      }
   }

   if (found == FALSE)
      RETVOID;

   arg.tq = spCb.spRteTq;
   arg.tqCp = &spCb.spRteTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = NOTUSED;
   arg.wait = NOTUSED;
   arg.tNum = tNum;
   arg.max = MAXRTETMR;
   cmRmvCbTq(&arg);
   RETVOID;
} /* end of spRmvRteCbTq */

  
/*
*
*       Fun:   spStartRteCbTmr
*
*       Desc:  start control block timer
*
*       Ret:   None
*
*       Notes: None
*
*       File:  cp_bdy2.c
*
*/
  
#ifdef ANSI
PUBLIC Void spStartRteCbTmr
(
SpRteCb *cb,                   /* control block */
U8 event                       /* timer event */
)
#else
PUBLIC Void spStartRteCbTmr(cb, event)
SpRteCb *cb;                   /* control block */
U8 event;                      /* timer event */
#endif
{
   CmTmrArg arg;
  
   TRC2(spStartRteCbTmr)
 
#if (ERRCLASS & ERRCLS_INT_PAR)  
   if (cb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP169, (ErrVal) ERRZERO,
                 "spStartRteCbTmr called with NULLP");
      RETVOID;
   }
#endif
   arg.tq = spCb.spRteTq;
   arg.tqCp = &spCb.spRteTqCp;
   arg.timers = cb->timers;
   arg.cb = (PTR)cb;
   arg.evnt = event;
   arg.wait = 0;
   arg.tNum = NOTUSED;
   arg.max = MAXRTETMR;
   if (cb->tmr.enb == TRUE)
      arg.wait = cb->tmr.val;
   if (arg.wait != 0)
      cmPlcCbTq(&arg);
   RETVOID;
} /* end of spStartRteCbTmr */

  
/*
*
*       Fun:   spRteCbTmrEvnt
*
*       Desc:  Route Control Block Timer Event.
*
*       Ret:   ROK
*
*       Notes: Called whenever an Route timer expires.
*
*       File:  cp_bdy2.c
*
*/
#ifdef ANSI
PUBLIC Void spRteCbTmrEvnt
(
PTR cbp,         /* control block pointer */
S16 evnt         /* event */
)
#else
PUBLIC Void spRteCbTmrEvnt(cbp, evnt)
PTR cbp;         /* control block timer */
S16 evnt;        /* event */
#endif
{
   S16 i;           /* counter */
   SpRteCb *cb;     /* route control block */ 
   SpNSapCb *nsap;  /* network SAP control block */

   TRC2(spRteCbTmrEvnt)

   /* sp044.302 - addition - Initialization of Local Variables */   
   nsap = NULLP;   

#ifdef ZP
   if (!zpCheckCritical())
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP170, (ErrVal) 0, 
                 "spRteCbTmrEvnt() recd in invalid PSF state ");
      spSendLmSta(LCM_CATEGORY_INTERFACE, LCM_EVENT_UI_INV_EVT, 
                  LCM_CAUSE_PROT_NOT_ACTIVE, 0, 0);
      RETVOID;
   }
#endif /* ZP */

   cb = (SpRteCb *) cbp;
  
   switch (evnt)
   {
      case TMR_STA:   /* status enquiry timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
            cb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
            spStartRteCbTmr(cb, (U8) TMR_STA);
            RETVOID;
         }
#endif /* ZP */      

         /* restart the timer */
         cb->rteStsFlag |= TMR_STA;
         cb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
         cb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
         spStartRteCbTmr(cb, (U8) TMR_STA);

         /* find the matching network SAP */
         for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
         {
            nsap = spCb.nSapList[i];
            if  ((nsap != NULLP) && (nsap == cb->nSap))  
            {
               break;
            }
         }
         if ((i < spCb.spCfg.nmbNSaps) && (nsap->status & SP_BND))
         {
             /* we found a matching NSAP and we are bound */
            SpLiSntStaReq(&nsap->pst, nsap->spId, cb->dpc);
         }
         break;

      case TMR_ATTACK:   /* attack timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = cb->nSap->nwData->defAttackTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defAttackTmr.val;
            spStartRteCbTmr(cb, TMR_ATTACK);
            RETVOID;
         }
#endif /* ZP */

         /* reset attack timer bit in the flag */
         cb->rteStsFlag &= (U8) (~TMR_ATTACK);
         break;

      case TMR_DECAY:    /* decay timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = cb->nSap->nwData->defDecayTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defDecayTmr.val;
            spStartRteCbTmr(cb, TMR_DECAY);
            RETVOID;
         }
#endif /* ZP */
         
         /* update rlm, rslm */
         cb->spRestrictLocal.rslm--;
         if ((cb->spRestrictLocal.rslm < 0) &&
             (cb->spRestrictLocal.rlm != 0))
         {
            cb->spRestrictLocal.rslm = spCb.spCfg.maxRstSubLvl - 1;
            cb->spRestrictLocal.rlm--;
         }

         /* if either rlm or rslm is non-zero, restart the decay timer */
         if ((cb->spRestrictLocal.rslm != 0) ||
             (cb->spRestrictLocal.rlm != 0))
         {
            cb->rteStsFlag |= TMR_DECAY;
            cb->tmr.enb = cb->nSap->nwData->defDecayTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defDecayTmr.val;
            spStartRteCbTmr(cb, TMR_DECAY);
         }
         else
            cb->rteStsFlag &= (U8) (~TMR_DECAY);

         /* compute traffic limitation data and broadcaste ril
          * to local user
          */
         spTrfCompute(&cb->spRestrictLocal, &cb->spRestrictComp, cb->dpc,
                      cb->nSap->nwData->nwId);

         SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
                "TMR_DECAY: spRestrictLocal(RLm: %d\t, RSLm: %d\t, CLs: %d)\n",
                cb->spRestrictLocal.rlm, cb->spRestrictLocal.rslm,
                cb->spRestrictLocal.cls));

         SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf,
                "TMR_DECAY: spRestrictComp(RL: %d\t, RSL: %d\t, RIL: %d)\n",
                cb->spRestrictComp.rl, cb->spRestrictComp.rsl,
                cb->spRestrictComp.ril));

         spLocalBroadcast(SP_CONG, cb->nSap->nwData->variant, cb->dpc,
                          (Ssn) SS_SCCPMNGT, (Smi) SMI_SOL, cb->sccpSts,
                          cb->spRestrictComp.ril, (U8) FROM_LOWER);
#ifdef ZP
         zpRunTimeUpd(ZP_SP_RTECB, cb, CMPFTHA_UPDTYPE_SYNC,
                      CMPFTHA_ACTN_MOD);
#endif /* ZP */
         break;

      case TMR_SST:          /* remote sccp status timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = cb->nSap->nwData->defSstTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defSstTmr.val;
            spStartRteCbTmr(cb, TMR_SST);
            RETVOID;
         }
#endif /* ZP */
         
         if (cb->rteStsFlag & TMR_CONTSST)
         {
            SpMngtCb mcb;    /* management message cb */

            /* remove continue flag and send another SST */
            cb->rteStsFlag ^= TMR_CONTSST;

            /* sp018.302 - modification - start tmr before sending SST */
            /* restart SST timer */
            cb->rteStsFlag |= TMR_SST;
            cb->tmr.enb = cb->nSap->nwData->defSstTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defSstTmr.val;
            spStartRteCbTmr(cb, TMR_SST);

            {
               /* build data for SST message */
               mcb.nwData = cb->nSap->nwData;
               mcb.dpc = cb->dpc;
               mcb.apc = cb->dpc;
               mcb.assn = SS_SCCPMNGT;
               mcb.frmt = SCMG_SST;
               mcb.smi = SMI_SOL;
               spSendMngtMsg(&mcb);
            }
         }
         else
         {
            /* unset the bit for SST timer in the flag */
            cb->rteStsFlag &= (U8) (~TMR_SST);

            /* recover all the subsystems attached to the SCCP */
            spResumeSS(cb);
            RETVOID;
         }
         break;

      case TMR_CON:   /* remote sccp congestion timer */
         /* sp040.302 - addition - if we are sby then just start timer again */
#ifdef ZP
         if (zpCb.rsetCbList[cb->spZpCb.rsetId]->state == CMPFTHA_STATE_STANDBY)
         {
            cb->tmr.enb = cb->nSap->nwData->defCongTmr.enb;
            cb->tmr.val = cb->nSap->nwData->defCongTmr.val;
            spStartRteCbTmr(cb, TMR_CON);
            RETVOID;
         }
#endif /* ZP */
         
         /* decrement cls and if cls has not reduced to zero,
          * restart congestion timer
          */
         if (cb->spRestrictLocal.cls > 0)
         {
            cb->spRestrictLocal.cls--;
            if (cb->spRestrictLocal.cls != 0)
            {
               /* stop congestion timer */
               spRmvRteCbTq(cb, TMR_CON);

               /* restart congestion timer */
               cb->rteStsFlag |= TMR_CON;
               cb->tmr.enb = cb->nSap->nwData->defCongTmr.enb;
               cb->tmr.val = cb->nSap->nwData->defCongTmr.val;
               spStartRteCbTmr(cb, TMR_CON);
            }
            else
               cb->rteStsFlag &= (U8) (~TMR_CON);   /* unset TMR_CON bit */

            /* compute traffic limitation data and broadcaste ril
             * to local user
             */
            spTrfCompute(&cb->spRestrictLocal, &cb->spRestrictComp, cb->dpc,
                         cb->nSap->nwData->nwId);

            spLocalBroadcast(SP_CONG, cb->nSap->nwData->variant, cb->dpc,
                             (Ssn) SS_SCCPMNGT, (Smi) SMI_SOL, cb->sccpSts,
                             cb->spRestrictComp.ril, (U8) FROM_LOWER);
#ifdef ZP
            zpRunTimeUpd(ZP_SP_RTECB, cb, CMPFTHA_UPDTYPE_SYNC,
                         CMPFTHA_ACTN_MOD);
#endif /* ZP */
         } /* if (...cls > 0) */
         break;

      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP171, (ErrVal) evnt,
                    "spRteCbTmrEvnt invalid event");
         break;
   } /* switch (evnt) */

#ifdef ZP
      zpUpdPeer();
#endif /* ZP */

   RETVOID;
} /* end of spRteCbTmrEvnt */

#ifdef SP_LMINT3

/*
 *
 *      Fun:   spFillReplyPst
 *
 *      Desc:  This function prepares the post structure required for sending
 *             management confirm
 *
 *      Ret:   RETVOID
 *
 *      Notes: None.
 *
        File:  cp_bdy2.c
 *
 */

#ifdef ANSI
PUBLIC Void spFillReplyPst
(
Pst    *rPst,                    /* reply post */
Header *hdr,                     /* mgmt header */
Pst    *iPst                     /* incoming post */
)
#else
PUBLIC Void spFillReplyPst(rPst, hdr, iPst)
Pst    *rPst;                    /* reply post */
Header *hdr;                     /* mgmt header */
Pst    *iPst;                    /* incoming post */
#endif
{
   TRC2(spFillReplyPst)

   rPst->srcEnt = spCb.spInit.ent;
   rPst->srcInst = spCb.spInit.inst;
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS   
   rPst->srcProcId = spCb.spInit.procId;
#else   
   rPst->srcProcId = SFndProcId();
#endif   
   rPst->dstEnt = iPst->srcEnt;
   rPst->dstInst = iPst->srcInst;
   rPst->dstProcId = iPst->srcProcId;
#ifdef SP_RUG
   /* sp014.301 - addition - fill remote interface version */
   rPst->intfVer = iPst->intfVer;
#endif /* SP_RUG */
   rPst->selector = hdr->response.selector;
   rPst->prior = hdr->response.prior;
   rPst->route = hdr->response.route;
   rPst->region = hdr->response.mem.region;
   rPst->pool= hdr->response.mem.pool;

   RETVOID;
} /* end of spFillReplyPst */
#endif /* SP_LMINT3 */


/*
 *
 *      Fun:   spSendLmCfm
 *
 *      Desc:  This function sends control and configuration confirms to
 *             layer management
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spSendLmCfm
(
Pst    *pst,                    /* post */
U8     cfmType,                 /* confirm type */
Header *hdr,                    /* header */
U16    status,                  /* confirm status */
U16    reason                   /* failure reason */
)
#else
PUBLIC S16 spSendLmCfm(pst, cfmType, hdr, status, reason)
Pst    *pst;                    /* post */
U8     cfmType;                 /* confirm type */
Header *hdr;                    /* header */
U16    status;                  /* confirm status */
U16    reason;                  /* failure reason */
#endif
{
#ifdef SP_LMINT3
   SpMngmt cfm;                 /* management structure */
   Pst rPst;                    /* reply post */
#else
   U16 event;                   /* alarm event */
#endif /* SP_LMINT3 */

   TRC2(spSendLmCfm)

#ifdef SP_LMINT3
   /* sp024.302 - modification - fill msgType */
   cfm.hdr.msgType = cfmType;
   cfm.hdr.msgLen = NOTUSED;
   cfm.hdr.seqNmb = NOTUSED;
   cfm.hdr.version = NOTUSED;

   /* sp024.302 - modification - use the same elmnt and elmntInst1 as
    * received in request primitive from LM
    */
   cfm.hdr.elmId.elmnt = hdr->elmId.elmnt;
   cfm.hdr.elmId.elmntInst1 = hdr->elmId.elmntInst1;
   cfm.hdr.elmId.elmntInst2 = NOTUSED;
   cfm.hdr.elmId.elmntInst3 = NOTUSED;
   cfm.hdr.response.selector = NOTUSED;
   cfm.hdr.response.mem.region = NOTUSED;
   cfm.hdr.response.mem.pool = NOTUSED;
   cfm.hdr.response.route = NOTUSED;
   cfm.hdr.response.prior = NOTUSED;
   cfm.hdr.entId.ent = spCb.spInit.ent;
   cfm.hdr.entId.inst = spCb.spInit.inst;
   cfm.hdr.transId = hdr->transId;
   cfm.cfm.status = status;
   cfm.cfm.reason = reason;

   /* prepare reply post structure */
   spFillReplyPst(&rPst, hdr, pst);

   switch(cfmType)
   {
      case TCFG:
         /* send configuration confirm */
         (Void)SpMiLspCfgCfm(&rPst, &cfm);
         break;
      case TCNTRL:
         /* send configuration confirm */
         (Void)SpMiLspCntrlCfm(&rPst, &cfm);
         break;
      case TSSTA:
        /* send status confirm */
         (Void)SpMiLspStaCfm(&rPst, &cfm);
         break;
      case TSTS:
        /* send status confirm */
         (Void)SpMiLspStsCfm(&rPst, 0, &cfm);
      default:
         RETVALUE(RFAILED);
   }
#else
    /* provide backward compatibility here */
   switch (cfmType)
   {
      case TCNTRL:
         if (status == LCM_PRIM_NOK)
         {
            event = LSP_USTA_CNTRL_NOK;
         }
         else
         {
            event = LSP_USTA_CNTRL_OK;
         }
         break;

      case TCFG:
         if (status == LCM_PRIM_NOK)
         {
            event = LSP_USTA_CFG_NOK;
         }
         else
         {
            event = LSP_USTA_CFG_OK;
         }
         break;

      case TSSTA:
         if (status == LCM_PRIM_NOK)
         {
            event = LSP_USTA_STA_NOK;
         }
         else
         {
            event = LSP_USTA_STA_OK;
         }
         break;

      case TSTS:
         if (status == LCM_PRIM_NOK)
         {
            event = LSP_USTA_STS_NOK;
         }
         else
         {
            event = LSP_USTA_STS_OK;
         }
         break;

      default:
         RETVALUE(RFAILED);
    } /* end switch */

    /* send usta */
    spSendLmSta(0, event, 0, 0, 0);
#endif 

   RETVALUE(ROK);
} /* end of spSendLmCfm */


/*
 *
 *      Fun:   spShutdown
 *
 *      Desc:  This function takes care of shutting down SCCP. This function
 *             release all the resources occupied by SCCP and leaves it 
 *             in a state when SCCP task was created with no configuration.
 *             While cleaning up it does not generate any indication to any
 *             of the upper/lower layers.
 *
 *      Ret:   RETVOID
 *
 *      Notes: 1. The remove timers is not required since we deregister the
 *                timers at the end.
 *
 *             2. The order of shutdown is reverse of the order of config
 *
 *      File:  cp_bdy2.c
 *
 */

#ifdef ANSI
PUBLIC Void spShutdown
(
Void
)
#else
PUBLIC Void spShutdown()
#endif
{
   U16 i;                       /* counter */
#ifdef LSPV2_4   
   U16 x;                       /* sp045.302 - addition - counter */
#endif /* LSPV2_4 */   
   U16 j;                       /* counter */
   SpNwCb *nwData;              /* network control block */
   SpNSapCb *nSap;              /* network sap */
   SpSapCb  *sap;               /* transport sap */
   SpXUdCb  *xUdCb;             /* extended unit data control block */
   PTR pCb;                     /* previous control block */
   PTR nCb;                     /* next control block */
   S16 ret;                     /* return value */
#ifdef SP_RUG
   /* sp014.301 - addition - fields for intf ver info */
   U16 spMaxNumIntfInfo;        /* max num of intf ver info */
   Size spMaxIntfInfoSize;      /* max size to store intf ver info */
#endif /* SP_RUG */
   /* sp044.302 - deletion - xxCb unused */
   TRC2(spShutdown)

   /* if general config not done then don't do anything */
   if (spCb.spInit.cfgDone == FALSE)
   {
      RETVOID;  
   }
   /* sp045.302 - modification - deallocating memory for association list for
    * each network.
    */
#ifdef LSPV2_4   
   for (i = 0; i < spCb.nmbNws; i++)
   {
      for (x = 0; x < spCb.nwList[i]->nmbAsso; x++)
      {
         /* Call the Deinit function for each association */
         spCb.nwList[i]->assoList[x]->funcs->gttDeInit
                                                 (spCb.nwList[i]->assoList[x]);
         /* Deallocate teh memory for the associations */
         SPutSBuf (spCb.spInit.region, spCb.spInit.pool, 
                   (Data *)spCb.nwList[i]->assoList[x], 
                   (Size) sizeof(SpAssoCb));
      } 
      if (spCb.nwList[i]->assoList != NULLP)
      {
         SPutSBuf (spCb.spInit.region, spCb.spInit.pool,
                   (Data*)spCb.nwList[i]->assoList, 
                   spCb.spCfg.nmbAsso * 
                   SBUFSIZE (sizeof (SpAssoCb*)));
      }
   }
#else  /* LSPV2_4 */ 
   for (i = 0; i < spCb.nmbAsso; i++)
   {
      /* Call the Deinit function for each association */
      spCb.assoList[i]->funcs->gttDeInit (spCb.assoList[i]);
      /* Deallocate teh memory for the associations */
      SPutSBuf (spCb.assoList[i]->region, spCb.assoList[i]->pool, 
                (Data *)spCb.assoList[i], (Size) sizeof(SpAssoCb));
   }

   /* Release memory fro association list */
   if (spCb.assoList != NULLP)
   {
      SPutSBuf (spCb.spInit.region, spCb.spInit.pool,
                (Data*)spCb.assoList, 
                spCb.spCfg.nmbAsso * 
                SBUFSIZE (sizeof (SpAssoCb*)));
   }
#endif  /* LSPV2_4 */ 

   /* release all route control block entries and hash tables */
   if ((Size)spCb.spCfg.nmbRtes > (Size)0)
   {
      pCb = (PTR)NULLP;
      /* go through rte hash list */
      ret = cmHashListGetNext(&spCb.rteHlCp, pCb, &nCb); 
      for (;;)
      {
         if (ret != ROK)
         {
            break;
         }
         else
         {
            pCb = nCb;
            ret = cmHashListGetNext(&spCb.rteHlCp, pCb, &nCb); 
            /* release memory */
            (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                            (Data *)pCb, (Size)sizeof(SpRteCb));
         }
      } /* end for */
      cmHashListDeinit(&spCb.rteHlCp);
   }

   /* clean up upper saps */
   for (i = 0; i < spCb.spCfg.nmbSaps; i++)
   {
      if ((sap = spCb.sapList[i]) != (SpSapCb *)NULLP)
      {
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                         (Data *) sap, (Size) sizeof(SpSapCb));
      }
   }

   /* release memory for sap list */
   if (spCb.sapList != (SpSapCb **)NULLP)
   {
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                      (Data*) spCb.sapList, 
                      (Size)(spCb.spCfg.nmbSaps * sizeof(SpSapCb*)));
   }

   /* clean up network saps */
   for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
   {
      if ((nSap = spCb.nSapList[i]) != (SpNSapCb *)NULLP)
      {
         /* network sap existing */
         /* remove all extended unit data control blocks */
         if (spCb.spCfg.nmbXUdCb)
         {
            for (j = 0; j < spCb.spCfg.nmbXUdCb; j++)
            {
               xUdCb = nSap->xUdCb[j];
               if ((xUdCb != (SpXUdCb *)NULLP) &&
                   (xUdCb->used == TRUE))
               {
                  SPutMsg(xUdCb->segBuf);
               }
               /* free control block */
               (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                               (Data *)nSap->xUdCb[j], (Size)sizeof(SpXUdCb));
            }
            /* free extended unit data control block list */
            (Void)SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                           (Data *) nSap->xUdCb,
                           (Size)((Size)spCb.spCfg.nmbXUdCb * sizeof(SpXUdCb*)));
         }
         /* sp004.302 - addition - free nSap Cb */
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                         (Data *) nSap, (Size) sizeof(SpNSapCb));
      } /* if nSap != NULLP */ 
   } /* end for */

   /* release memory for network sap list */
   if (spCb.nSapList != (SpNSapCb **)NULLP)
   {
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                         (Data*)spCb.nSapList, 
                         (Size)(spCb.spCfg.nmbNSaps * sizeof(SpNSapCb*)));
   }

   /* clean up network control block */
   for (i = 0; i < spCb.spCfg.nmbNws; i++)
   {
      if ((nwData = spCb.nwList[i]) != (SpNwCb *) NULLP)
      {
#ifndef ZP
         /* If ZP is defined all the con cb's will removed as part of
          * ZP shutdown
          */         
#ifdef SPCO
         /* remove all connection control blocks and local references */
         if (spCb.spCfg.nmbCon != 0)
         {
            U32 k;         /* sp001.302 - modification - type changed to U32 */
            SpConCb *conCb;
            SpLclRef *slr; 
            for (k = 0; k < spCb.spCfg.nmbCon; k++)
            {
               /* grab slr */
               slr = &nwData->lclRef[k];
               if ((conCb = slr->cb) != (SpConCb *)NULLP)
               {
                  /* release connection control block here */
                  if (conCb->cs[SIDE(conCb)].segBuf != (Buffer *)NULLP)
                  {
                     SPutMsg(conCb->cs[SIDE(conCb)].segBuf);
                  }
                  if (conCb->cs[OPSIDE(conCb)].segBuf != (Buffer *)NULLP)
                  {
                     SPutMsg(conCb->cs[OPSIDE(conCb)].segBuf);
                  }
                  spFlushQueue(&conCb->cs[SIDE(conCb)].datQ);
                  spFlushQueue(&conCb->cs[SIDE(conCb)].eDatQ);
                  spFlushQueue(&conCb->cs[OPSIDE(conCb)].datQ);
                  spFlushQueue(&conCb->cs[OPSIDE(conCb)].eDatQ);
                  SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                           (Data*)conCb, (Size)sizeof(SpConCb));
               }
            }
            SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data *) nwData->lclRef,
                     (Size)((Size)spCb.spCfg.nmbCon * sizeof(SpLclRef)));
         } /* end if nmbCon != 0 */
#endif /* SPCO */
#endif /* ZP */
         /* release network control block */
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                          (Data *) nwData, (Size) sizeof(SpNwCb));
      } /* end of nwData != NULLP */
   } /* end for */

   /* release memory for network list */
   if (spCb.nwList != (SpNwCb **)NULLP)
   {
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                         (Data*)spCb.nwList, 
                         (Size)(spCb.spCfg.nmbNws * sizeof(SpNwCb*)));
   }

   /* sp026.302 - removal - remove freeing of mem for conn hash list
    * based on CG_KEY, CD_KEY and SU_KEY. These conn hash lists are
    * no longer used.
    */

#ifdef SP_RUG
   /* sp014.301 - addition - release memory for interface version info */
   if (spCb.spVerInfoCb != NULLP)
   {
      /* calculate maximum number of interface informations */
      spMaxNumIntfInfo = (Size)spCb.spCfg.nmbSaps +
                         (Size)spCb.spCfg.nmbNSaps;
      /* calculate memory allocated to store interface version info */
      spMaxIntfInfoSize = (Size)spMaxNumIntfInfo *
                          (Size)sizeof(SpVerInfoCb);

      SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *)spCb.spVerInfoCb,
               spMaxIntfInfoSize);
   }
#endif /* SP_RUG */

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
   /* Deregister all the timers */
   SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
             (S16)spCb.spCfg.ssnTimeRes, (PAIFTMRS16)spPrcSsnCbTq);
#else
   SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
             (S16)spCb.spCfg.ssnTimeRes, (PFS16)spPrcSsnCbTq);
#endif /* SS_MULTIPLE_PROCS */
#ifdef SPCO
   if (spCb.spCfg.nmbCon != (Size)0)
   {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
      SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                (S16)spCb.spCfg.conTimeRes, (PAIFTMRS16)spPrcConCbTq);
#else
      SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                (S16)spCb.spCfg.conTimeRes, (PFS16)spPrcConCbTq);
#endif /* SS_MULTIPLE_PROCS */
   }
#endif /* SPCO */

   if (spCb.spCfg.nmbXUdCb > 0)
   {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
      SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                (S16)spCb.spCfg.AsmbTimeRes, (PAIFTMRS16)spPrcXUdTq);
#else
      SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                (S16)spCb.spCfg.AsmbTimeRes, (PFS16)spPrcXUdTq);
#endif /* SS_MULTIPLE_PROCS */
   }

/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS 
   SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
             (S16)spCb.spCfg.recTimeRes, (PAIFTMRS16)spPrcRteCbTq);
#else
   SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
             (S16)spCb.spCfg.recTimeRes, (PFS16)spPrcRteCbTq);
#endif /* SS_MULTIPLE_PROCS */

   /* return static memory pool */
   (Void) SPutSMem(spCb.spInit.region, spCb.spInit.pool);

   /* Reinit everything..... */
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
   /* sp044.302 - modification - replacing xxCb with NULLP, since its unused in 
    * spActvInit function.
    */
   spActvInit (spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
               spCb.spInit.region, SHUTDOWN, NULLP);
#else
   spActvInit (spCb.spInit.ent, spCb.spInit.inst,
               spCb.spInit.region, spCb.spInit.reason);
#endif /* SS_MULTIPLE_PROCS */
   RETVOID;
} /* end of spShutdown */

 
/*
 *
 *       Fun:   spGenTrc
 *
 *       Desc:  Send a trace indication to the Layer Manager
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void spGenTrc
(
SuId suId,      /* Lower SAP Id */
U16 evnt,       /* event */
Buffer *mBuf    /* buffer for tracing */
)
#else
PUBLIC Void spGenTrc(suId, evnt, mBuf)
SuId suId;      /* Lower SAP Id */
U16  evnt;      /* event */
Buffer *mBuf;   /* buffer for tracing */
#endif
{
   SpMngmt    trc;                      
   MsgLen     msgLen;
  
   TRC2(spGenTrc);

   /* sp001.302 - addition - initialize trc */
   cmZero((U8 *) &trc, sizeof(SpMngmt));

   trc.hdr.msgLen = 0;                   /* optional - message length */
   trc.hdr.version = 0;                  /* optional - version */
   trc.hdr.seqNmb = 0;                   /* optional - sequence number */
   trc.hdr.msgType = TTRC;               /* message type */
   trc.hdr.entId.ent = spCb.spInit.ent;  /* entity id */
   trc.hdr.entId.inst = spCb.spInit.inst;/* instance id */
 
   /* SAP where event occured */
   trc.hdr.elmId.elmnt = STNSAP;         /* network SAP */
   trc.hdr.elmId.elmntInst1 = suId;      /* SAP number */
   trc.hdr.elmId.elmntInst2 = 0;         /* optional - element instance */
   trc.hdr.elmId.elmntInst3 = 0;         /* optional - element instance */
 
   /* event */
   trc.t.trc.evnt = evnt;                /* event to be traced */

   /* find length of message buffer */
   (Void)SFndLenMsg(mBuf, &msgLen);
 
   /* trace upto LST_MAX_TRC_LEN bytes of message buffer */
   if(msgLen > SP_TRACE_LEN)
      msgLen = SP_TRACE_LEN;

   {
      MsgLen tmp;
      (void)SCpyMsgFix (mBuf, 0, msgLen, &trc.t.trc.evntParm[0], &tmp);
   }

   /* store length of trace */
   trc.t.trc.len = msgLen;

    /* initialize date and time in trace structure */
   SGetDateTime(&trc.t.trc.dt);
 
   /* call management trace indication primitive */
   SpMiLspTrcInd(&spCb.spInit.lmPst, &trc);
 
   RETVOID;
} /* stGenTrc */


/*
 *
 *       Fun:   spGetSls
 *
 *       Desc:  Returns the signalling link selector, and increments it.
 *              The Sls is kept per route in the network.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC LnkSel spGetSls
(
SpNwCb *nwData, /* network control block */
Dpc pc          /* Point code */
)
#else
PUBLIC LnkSel spGetSls(nwData, pc)
SpNwCb *nwData; /* network control block */
Dpc pc;         /* Point code */
#endif
{
   SpRteCb *rCb; 
   SpRteKey rKey;

   TRC2(spGetSls);

   rCb = (SpRteCb *)NULLP; 

   rKey.k1.dpc = pc;
   rKey.k1.nwId = nwData->nwId;

   spFindRte(&spCb.rteCp, &rCb, &rKey, 0); 

   if (rCb == (SpRteCb *)NULLP)
   {
      /* PDU Err functions willrequire this as we do not store incoming sls */
      RETVALUE (nwData->sls++ & nwData->slsMask); 
   }
   
   /* sp020.302 - modification - use slsMask from rCb instead of nwCb */
   RETVALUE (rCb->sls++ & rCb->slsMask);    
}


/*
 *
 *       Fun:   spDeleteRoute
 *
 *       Desc:  Do the function of route deleteion
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteRoute
(
SpDelRteCfg *spDelRte    /* Delete route structure passed by SM */
)
#else
PUBLIC S16 spDeleteRoute (spDelRte)
SpDelRteCfg *spDelRte;   /* Delete route structure passed by SM */
#endif
{
   SpRteCb *rteCb; 
   SpNSapCb *nSap; 
   SpRteKey rKey;
   S16 i;
   S16 k;
   
   TRC2(spDeleteRoute);

   SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf, 
          "spDeleteRoute (nSap (%ld), dpc (%ld), ssnPres (%ld), ssn (%ld))\n",
          (U32) spDelRte->nSapId, (U32) spDelRte->dpc, (U32) spDelRte->ssnPres, 
          (U32) spDelRte->ssn));

   nSap = (SpNSapCb *) (*(spCb.nSapList + (PTR) spDelRte->nSapId));

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (nSap == (SpNSapCb *) NULLP)
      RETVALUE(LCM_REASON_INVALID_PAR_VAL);
#endif /* ERRCLASS */         

   rKey.k1.dpc = spDelRte->dpc;
   rKey.k1.nwId = nSap->nwData->nwId;

   spFindRte(&spCb.rteCp, &rteCb, &rKey, 0);

   /* sp001.302 - removal - compile flag ERRCLASS removed and check on
    * rteCb is made unconditional to handle repeated route deletion request
    */
   if (rteCb == (SpRteCb *) NULLP)
   {
      /* route not found, could be deleted in previous deletion
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* Check if ssn is present */
   if (spDelRte->ssnPres)
   {
      /* just delete the ssn in the route and leave the route intact */
      for (i = 0; i < rteCb->nmbSsns; i++)
      {
         /* find the ssn */
         if (rteCb->ssnList[i].ssn == spDelRte->ssn)
         {
            /* Stop the timer */
            spRmvSsnCbTq(&rteCb->ssnList[i], TMR_SST);
            /* shift the ssn array */
            for (k = i; k < rteCb->nmbSsns - 1; k++)
            {
               /* Stop the timers */
               spRmvSsnCbTq(&rteCb->ssnList[k], TMR_SST);


               spRmvSsnCbTq(&rteCb->ssnList[k+1], TMR_SST);


               /* copy teh ssn control block */
               cmCopy ((U8 *)&rteCb->ssnList[k+1], (U8 *)&rteCb->ssnList[k], 
                       sizeof (SpSsnCb));
               /* Restart the timers */
               if (rteCb->ssnList[k].ssFlgs & TMR_SST)
               {
                   rteCb->ssnList[k].tmr.enb = 
                                             rteCb->nSap->nwData->defSstTmr.enb;
                  rteCb->ssnList[k].tmr.val = 
                                             rteCb->nSap->nwData->defSstTmr.val;
                  spStartSsnCbTmr(&rteCb->ssnList[k], TMR_SST);
               }
            }
            /* sp004.301 - removed code to decrease the number of SSNs, 
             * as we will do this after we verify that an SSN was deleted, 
             * also removed the FT/HA update */ 
            break;
         }
      }
      /* sp004.301 - Added code to remove the SSN.   We will either return an error since
         no SSN was deleted, or an SSN was deleted and we need to update the number of SSNs.
         Also, moved the FT/HA update to here */ 
      if (i == rteCb->nmbSsns)
         RETVALUE (LCM_REASON_INVALID_PAR_VAL);
      else
      {
         rteCb->nmbSsns--;
#ifdef ZP
         zpRunTimeUpd(ZP_SP_RTECB, (Void *)rteCb,
                      CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_MOD);
#endif /* ZP */
      }
   }
   else  /* Delete the full route */
   {
      for (i = 0; i < rteCb->nmbSsns; i++)
      {
         /* cancel all outstanding timers */
         spRmvSsnCbTq(&rteCb->ssnList[i], TMR_SST);
      }
      rteCb->nmbSsns = 0;  /* necessary for PSF */

      /* stop all timers on route */
#ifdef SNT2
      /* stop status enquiry timer */
      if (rteCb->rteStsFlag & TMR_STA)
      {
         spRmvRteCbTq(rteCb, TMR_STA);
         rteCb->rteStsFlag &= (U8) (~TMR_STA);
      }
#endif /* SNT2 */
      /* stop sst timer for remote sccp */
      if (rteCb->rteStsFlag & TMR_SST)
      {
         spRmvRteCbTq(rteCb, TMR_SST);
         rteCb->rteStsFlag &= (U8) (~TMR_SST);
      }
      /* stop remote sccp congestion timer */
      if (rteCb->rteStsFlag & TMR_CON)
      {
         spRmvRteCbTq(rteCb, TMR_CON);
         rteCb->rteStsFlag &= (U8) (~TMR_CON);
      }
      /* stop attack timer */
      if (rteCb->rteStsFlag & TMR_ATTACK)
      {
         spRmvRteCbTq(rteCb, TMR_ATTACK);
         rteCb->rteStsFlag &= (U8) (~TMR_ATTACK);
      }
      /* stop decay timer */
      if (rteCb->rteStsFlag & TMR_DECAY)
      {
         spRmvRteCbTq(rteCb, TMR_DECAY);
         rteCb->rteStsFlag &= (U8) (~TMR_DECAY);
      }

      cmHashListDelete(spCb.rteCp.rCp, (PTR)rteCb);
#ifdef ZP
      zpRunTimeUpd(ZP_SP_RTECB, (Void *)rteCb, 
                   CMPFTHA_UPDTYPE_SYNC, CMPFTHA_ACTN_DEL);
      zpDelMapping (ZP_SP_RTECB, (Void *)rteCb);
#endif /* ZP */
      SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
               (Data*)rteCb, (Size)sizeof(SpRteCb));
      spCb.nmbRtes--;
   }
   RETVALUE (LCM_REASON_NOT_APPL);
} /* spDeleteRoute */


/*
 *
 *       Fun:   spDeleteAsso
 *
 *       Desc:  Delete an association
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteAsso
(
SpAssoCfg *spAsso    /* Delet association. */
)
#else
PUBLIC S16 spDeleteAsso (spAsso)
SpAssoCfg *spAsso;   /* Delet association. */
#endif
{
   S16 ret;          /* return value */
   U16 indx;         /* index of the assoCb in the list */
   SpAssoCb *assoCb; /* association control block */
   SpNwCb *nwCb;       /* sp045.302 - addition - network control block */
#ifdef LSPV2_4      
   Bool found;         /* sp045.302 - addition - boolean */
   U16 nwIndx;       /* sp045.302 - addition - network index */
#endif
   
   TRC2(spDeleteAsso);

   /* sp045.302 - addtion - get the network id and check if its configured */
   nwCb = NULLP;
#ifdef LSPV2_4      
   found = FALSE;

   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == spAsso->nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, spAsso->nwId,
                "spDeleteAsso: network id not configured");
      RETVALUE(LSP_REASON_NW_NOTCFG);
   }

   /* sp001.302 - addition - delete association only if an exact match
    * is found, if overlapping match is founnd, return failure
    */
   /* sp045.302 - addition - pass network CB */
   ret = spAssoForRule(&spAsso->rule, &indx, nwCb);
   if (ret == RFAILED)
   {
      /* no matching rule found in the configured list. May be rule 
       * deleted in previous control request. Return success.
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }
   else
   {
      if (ret == ROKDUP)
      {
         /* overlapping match is found, log error and return failure */
         SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ret, "Overlapping rule");
         RETVALUE(LSP_REASON_ASSO_NOT_CFG);
      }
      else
      {
         /* delete association */
         assoCb = nwCb->assoList[indx];
         /* copy last association in the list at the current indx and 
          * initialize the last entry with null
          */
         nwCb->assoList[indx] = nwCb->assoList[nwCb->nmbAsso - 1];
         nwCb->assoList[nwCb->nmbAsso - 1] = NULLP;

         --nwCb->nmbAsso;
         nwCb->nmbActns -= assoCb->nmbActns;

         /* Release all the memory allocated */
         assoCb->funcs->gttDeInit(assoCb);
         SPutSBuf(assoCb->region, assoCb->pool, 
                  (Data *)assoCb, (Size) sizeof(SpAssoCb));
#ifdef ZP
   zpRunTimeUpd(ZP_SP_ASSOCFG, (Void *)spAsso, CMPFTHA_UPDTYPE_NORMAL,
                CMPFTHA_ACTN_DEL);

#endif /* ZP */         
   RETVALUE (LCM_REASON_NOT_APPL);
      }
   }
#else /* LSPV2_4 */   
   /* sp001.302 - addition - delete association only if an exact match
    * is found, if overlapping match is founnd, return failure
    */
   /* sp045.302 - addition - pass network CB */
   ret = spAssoForRule(&spAsso->rule, &indx, nwCb);
   if (ret == RFAILED)
   {
      /* no matching rule found in the configured list. May be rule 
       * deleted in previous control request. Return success.
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }
   else
   {
      if (ret == ROKDUP)
      {
         /* overlapping match is found, log error and return failure */
         SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ret, "Overlapping rule");
         RETVALUE(LSP_REASON_ASSO_NOT_CFG);
      }
      else
      {
         /* delete association */
         assoCb = spCb.assoList[indx];

         /* copy last association in the list at the current indx and 
          * initialize the last entry with null
          */
         spCb.assoList[indx] = spCb.assoList[spCb.nmbAsso - 1];
         spCb.assoList[spCb.nmbAsso - 1] = NULLP;

         --spCb.nmbAsso;
         spCb.nmbActns -= assoCb->nmbActns;

         /* Release all the memory allocated */
         assoCb->funcs->gttDeInit(assoCb);
         SPutSBuf(assoCb->region, assoCb->pool, 
                  (Data *)assoCb, (Size) sizeof(SpAssoCb));
#ifdef ZP
         zpRunTimeUpd(ZP_SP_ASSOCFG, (Void *)spAsso, CMPFTHA_UPDTYPE_NORMAL,
                      CMPFTHA_ACTN_DEL);

#endif /* ZP */         
         RETVALUE (LCM_REASON_NOT_APPL);
      }
   }
#endif /* LSPV2_4 */   
} /* SpDeleteAsso */

#ifdef LSPV2_4
/* sp045.302 - addition -new function to rollback association addition 
 * in networks. roll back will be required in case of association config
 * request with network id 0xffff, then association is added in all  networks.
 * and if for a particular network we encounter any problem then we need to
 * delete from all the previously added networks.
 */

/*
 *
 *       Fun:   spDelAsso
 *
 *       Desc:  Delete an association during association config request for
 *       special case of network id == 0xFFFF, when the association is being
 *       added in all the networks of the same variant.
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDelAsso
(
SpAssoCfg *spAsso    /* Delet association. */
)
#else
PUBLIC S16 spDelAsso (spAsso)
SpAssoCfg *spAsso;   /* Delet association. */
#endif
{
   S16 ret;          /* return value */
   U16 indx;         /* index of the assoCb in the list */
   SpAssoCb *assoCb; /* association control block */
   Bool found;         /* sp045.302 - addition - boolean */
   SpNwCb *nwCb;       /* sp045.302 - addition - network control block */
   U16 nwIndx;       /* sp045.302 - addition - network index */
   
   TRC2(spDelAsso);

   /* sp045.302 - addtion - get the network id and check if its configured */
   found = FALSE;
   nwCb = NULLP;

   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == spAsso->nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, spAsso->nwId,
                "spDeleteAsso: network id not configured");
      RETVALUE(LSP_REASON_NW_NOTCFG);
   }

   /* sp001.302 - addition - delete association only if an exact match
    * is found, if overlapping match is founnd, return failure
    */
   /* sp045.302 - addition - pass network CB */
   ret = spAssoForRule(&spAsso->rule, &indx, nwCb);
   if (ret == RFAILED)
   {
      /* no matching rule found in the configured list. May be rule 
       * deleted in previous control request. Return success.
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }
   else
   {
      if (ret == ROKDUP)
      {
         /* overlapping match is found, log error and return failure */
         SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, (ErrVal) ret, "Overlapping rule");
         RETVALUE(LSP_REASON_ASSO_NOT_CFG);
      }
      else
      {
         /* delete association */
         assoCb = nwCb->assoList[indx];
         /* copy last association in the list at the current indx and 
          * initialize the last entry with null
          */
         nwCb->assoList[indx] = nwCb->assoList[nwCb->nmbAsso - 1];
         nwCb->assoList[nwCb->nmbAsso - 1] = NULLP;

         --nwCb->nmbAsso;
         nwCb->nmbActns -= assoCb->nmbActns;

         /* Release all the memory allocated */
         assoCb->funcs->gttDeInit(assoCb);
         SPutSBuf(assoCb->region, assoCb->pool, 
                  (Data *)assoCb, (Size) sizeof(SpAssoCb));
      }
   }
   RETVALUE (LCM_REASON_NOT_APPL);
} /* SpDelAsso */

#endif /* LSPV2_4 */

/*
 *
 *       Fun:   spDeleteAddrMap
 *
 *       Desc:  Delete an addressmap
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteAddrMap
(
SpAddrMapCfg *spAddrMap          /* address map to be deleted */
)
#else
PUBLIC S16 spDeleteAddrMap (spAddrMap)
SpAddrMapCfg *spAddrMap;         /* address map to be deleted */
#endif
{
   S16 ret;
   SpAssoCb *assoCb;
   SpNwCb *nwCb;       /* sp045.302 - addition - network control block */
#ifdef LSPV2_4
   Bool found;         /* sp045.302 - addition - boolean */
   U16 nwIndx;         /* sp045.302 - addition - network id */
#endif /* LSPV2_4 */
   
   TRC2(spDeleteAdrMap);

   /* sp045.302 - addition - check if network is configured */
   nwCb = NULLP;
#ifdef LSPV2_4   
   found = FALSE;

   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == spAddrMap->nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, spAddrMap->nwId,
                "spDeleteAddrMap: network id not configured");
      RETVALUE(LSP_REASON_NW_NOTCFG);
   }

   /* sp045.302 - modification - nmbAsso moved to network Cb */
   /* Association configuration not done */
   if (nwCb->nmbAsso == 0)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteAddrMap(): Association is not configured for i\
             Network(id %d) ", nwCb->nwId));
      /* sp045.302 - modification - return type changed. */
      /* association not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* 
    * Find the matching association. 
    * It also detects if no configuration has been done.
    */
   /* sp045.302 - modification - pass network CB instead of switch */
   assoCb = spMatchAssoCb (&spAddrMap->gt, spAddrMap->sw, nwCb);
   if (assoCb == NULLP)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteAddrMap(): no matching Association found for i\
             Network(id %d) ", nwCb->nwId));
      /* sp045.302 - modification - return type changed. */
      /* association not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* sp001.302 - addition - check exitence of address map */
   ret = spMatchAddrMap(assoCb, spAddrMap);
   if (ret == RFAILED)
   {
      /* address map not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* Call the delete function for the association */
   ret = assoCb->funcs->gttDelete(assoCb, spAddrMap);
   if (ret != ROK)
      RETVALUE (ret);

   /* Success */
   /* sp045.302 - modification - nmbAsso moved to network Cb */
   nwCb->nmbAddrs--;
   /* sp045.302 - addition - decrement the counter. */
   nwCb->numAddrMapOutNwId--;
#else /* LSPV2_4 */   
   /* Association configuration not done */
   if (spCb.nmbAsso == 0)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP174, (ErrVal) 0,
                 "Configure Associations first");
      RETVALUE(LSP_REASON_RULE_NOTPRSNT);
   }

   /* 
    * Find the matching association. 
    * It also detects if no configuration has been done.
    */
   /* sp045.302 - modification - pass network CB instead of switch */
   assoCb = spMatchAssoCb (&spAddrMap->gt, spAddrMap->sw, nwCb);
   if (assoCb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP175, (ErrVal) 0,
                 "No matching associations");
      RETVALUE(LSP_REASON_RULE_NOTPRSNT);
   }

   /* sp001.302 - addition - check exitence of address map */
   ret = spMatchAddrMap(assoCb, spAddrMap);
   if (ret == RFAILED)
   {
      /* address map not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* Call the delete function for the association */
   ret = assoCb->funcs->gttDelete(assoCb, spAddrMap);
   if (ret != ROK)
      RETVALUE (ret);

   /* Success */
   spCb.nmbAddrs--;
#endif /* LSPV2_4 */   
#ifdef ZP
   zpRunTimeUpd(ZP_SP_ADDRMAPCFG, (Void *)spAddrMap, 
             CMPFTHA_UPDTYPE_NORMAL, CMPFTHA_ACTN_DEL);
#endif /* ZP */

   RETVALUE (LCM_REASON_NOT_APPL);
} /* spDeleteAdrMap */

#ifdef LSPV2_4   
/* sp045.302 - addition -new function to rollback addrMap addition in networks.
 * roll back will be required in case of addrMap config request with network id
 * 0xffff, then addrMap is added in all the networks. and if for a particular
 * network we encounter any problem then we need to delete from all the
 * previously added networks.
 */

/*
 *
 *       Fun:   spDelAddrMap
 *
 *       Desc:  Delete an addressmap during addressMap config request for
 *       special case of network id == 0xFFFF, when the addressmap is being
 *       added in all the networks of the same variant.
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDelAddrMap
(
SpAddrMapCfg *spAddrMap          /* address map to be deleted */
)
#else
PUBLIC S16 spDelAddrMap (spAddrMap)
SpAddrMapCfg *spAddrMap;         /* address map to be deleted */
#endif
{
   S16 ret;
   SpAssoCb *assoCb;
   Bool found;
   SpNwCb *nwCb;
   U16 nwIndx;
   
   TRC2(spDelAddrMap);

   found = FALSE;
   nwCb = NULLP;

   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == spAddrMap->nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, spAddrMap->nwId,
                "spDelAddrMap: network id not configured");
      RETVALUE(LSP_REASON_NW_NOTCFG);
   }

   /* sp045.302 - modification - nmbAsso moved to network Cb */
   /* Association configuration not done */
   if (nwCb->nmbAsso == 0)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDelAddrMap(): Association is not configured for i\
             Network(id %d) ", nwCb->nwId));
      /* sp045.302 - modification - return type changed. */
      /* association not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* 
    * Find the matching association. 
    * It also detects if no configuration has been done.
    */
   /* sp045.302 - modification - pass network CB instead of switch */
   assoCb = spMatchAssoCb (&spAddrMap->gt, spAddrMap->sw, nwCb);
   if (assoCb == NULLP)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDelAddrMap(): No matching associations found for\
             Network(id %d) ", nwCb->nwId));
      /* sp045.302 - modification - return type changed. */
      /* association not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* sp001.302 - addition - check exitence of address map */
   ret = spMatchAddrMap(assoCb, spAddrMap);
   if (ret == RFAILED)
   {
      /* address map not found, may be deleted in previous control
       * request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* Call the delete function for the association */
   ret = assoCb->funcs->gttDelete(assoCb, spAddrMap);
   if (ret != ROK)
      RETVALUE (ret);

   /* Success */
   /* sp045.302 - modification - nmbAsso moved to network Cb */
   nwCb->nmbAddrs--;
   /* sp045.302 - addition - decrement the counter. */
   nwCb->numAddrMapOutNwId--;

   RETVALUE (LCM_REASON_NOT_APPL);
} /* spDelAddrMap */

#endif /* LSPV2_4 */  
/* sp001.302 - addition - function to delete network, upper sap and lower sap */

/*
 *
 *       Fun:   spDeleteNetwork
 *
 *       Desc:  Delete a network
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteNetwork
(
NwId nwId           /* network Id */
)
#else
PUBLIC S16 spDeleteNetwork(nwId)
NwId nwId;          /* network Id */
#endif
{
   SpNwCb *spNwCb;    /* network contrl block to be deleted */
   U16 nwIndx;        /* index of nwCb in the nwList */
   U32 j;             /* loop counter */
   Bool found;        /* boolean */
   SpSapCb *sap;      /* upper sap control block */
   SpNSapCb *nSap;    /* lower sap control block */

   TRC2(spDeleteNetwork)

   /* sp044.302 - addition - Initialization of Local Variables */   
   spNwCb = NULLP;   

   /* find network control block to be deleted */
   found = FALSE;
   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      spNwCb = *(spCb.nwList + (PTR) nwIndx);
      if ((spNwCb != (SpNwCb *) NULLP) && (spNwCb->nwId == nwId))
      {
         found = TRUE;
         break;
      }
   }

   if (found == FALSE)
   {
      /* network not found, could be deleted in previous
       * deletion request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }
   
   /* sp045.302 - addition - if there are any associations configured the
    * dont allow for network deletion.
    */
   if (spNwCb->nmbAsso > 0)
   {
      /* network can not be deleted */
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNetwork(): Network(id %d) can't be deleted, associations\
             exists", nwId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

   /* sp045.302 - addition - if there are any associations configured the
    * dont allow for network deletion.
    */
   if (spNwCb->numAddrMapOutNwId > 0)
   {
      /* network can not be deleted */
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNetwork(): Network(id %d) can't be deleted,\
             as there exist AddressMaps configured where this network id\
             is being used as outNwId (for inter network transfer of message\
             after GTT) exists", nwId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

   
   /* check is there any upper sap configured in the network */
   found = FALSE;
   for (j = 0; j < spCb.spCfg.nmbSaps; j++)
   {
      sap = spCb.sapList[j];
      if ((sap != (SpSapCb *) NULLP) &&
          (sap->nwData == spNwCb))
      {
         found = TRUE;
         break;
      }
   }

   if (found == TRUE)
   {
      /* network can not be deleted */
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNetwork(): Network(id %d) can't be deleted, SAP exists",
             nwId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

   /* check is there any lower sap configured in the network */
   for (j = 0; j < spCb.spCfg.nmbNSaps; j++)
   {
      nSap = spCb.nSapList[j];
      if ((nSap != (SpNSapCb *) NULLP) &&
          (nSap->nwData == spNwCb))
      {
         found = TRUE;
         break;
      }
   }

   if (found == TRUE)
   {
      /* network can not be deleted */
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNetwork(): Network(id %d) can't be deleted, NSAP exists",
             nwId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

   /* validation successful, network control block can be deleted */

#ifndef ZP
#ifdef SPCO
   /* remove all connection control blocks and local references */
   if (spCb.spCfg.nmbCon != 0)
   {
      SpConCb *conCb;
      SpLclRef *slr; 
      for (j = 0; j < spCb.spCfg.nmbCon; j++)
      {
         slr = &spNwCb->lclRef[j];
         if ((conCb = slr->cb) != (SpConCb *) NULLP)
         {
            /* release connection control block here */
            if (conCb->cs[SIDE(conCb)].segBuf != (Buffer *) NULLP)
            {
               SPutMsg(conCb->cs[SIDE(conCb)].segBuf);
            }
            if (conCb->cs[OPSIDE(conCb)].segBuf != (Buffer *) NULLP)
            {
               SPutMsg(conCb->cs[OPSIDE(conCb)].segBuf);
            }
            spFlushQueue(&conCb->cs[SIDE(conCb)].datQ);
            spFlushQueue(&conCb->cs[SIDE(conCb)].eDatQ);
            spFlushQueue(&conCb->cs[OPSIDE(conCb)].datQ);
            spFlushQueue(&conCb->cs[OPSIDE(conCb)].eDatQ);
            SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                     (Data *) conCb, (Size) sizeof(SpConCb));
         }
      }
      SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
               (Data *) spNwCb->lclRef,
               (Size) ((Size) spCb.spCfg.nmbCon * sizeof(SpLclRef)));
   } /* if (...nmbCon != 0) */
#endif /* SPCO */
#endif /* ZP */

#ifdef ZP
   zpRunTimeUpd(ZP_SP_NWCB, (Void *) spNwCb, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
   zpDelMapping(ZP_SP_NWCB, (Void *) spNwCb);
#endif /* ZP */

   /* release network control block */
   (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                   (Data *) spNwCb, (Size) sizeof(SpNwCb));

   /* copy last nwCb in the list at the current index and initialize
    * last entry with NULLP; decrement number of networks
    */
   *(spCb.nwList + (PTR) nwIndx) = *(spCb.nwList + (PTR) (spCb.nmbNws - 1));
   *(spCb.nwList + (PTR) (spCb.nmbNws - 1)) = NULLP;
   spCb.nmbNws--;
   RETVALUE(LCM_REASON_NOT_APPL);
} /* spDeleteNetwork */


/*
 *
 *       Fun:   spDeleteSap
 *
 *       Desc:  Delete an upper sap
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteSap
(
SpId spId             /* sap Id */
)
#else
PUBLIC S16 spDeleteSap(spId)
SpId spId;            /* sap Id */
#endif
{
   SpSapCb *sap;      /* upper sap control block */

   TRC2(spDeleteSap)

   sap = spCb.sapList[spId];
   if (sap == (SpSapCb *) NULLP)
   {
      /* sap not found, could be deleted in previous
       * deletion request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* check if sap is bound, bound sap can not be deleted */
   if (sap->status & SP_BND)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteSap(): SAP (id: %d) is bound, can not be deleted", spId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

#ifdef ZP
   zpRunTimeUpd(ZP_SP_SAPCB, (Void *) sap, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
   zpDelMapping(ZP_SP_SAPCB, (Void *) sap);
#endif /* ZP */

   /* release upper sap control block */
   (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) sap,
                   (Size) sizeof(SpSapCb));

   /* decrement number of upper saps configured and initialize saplist entry */
   spCb.nmbSaps--;
   spCb.sapList[spId] = NULLP;
   RETVALUE(LCM_REASON_NOT_APPL);
} /* spDeleteSap */


/*
 *
 *       Fun:   spDeleteNSap
 *
 *       Desc:  Delete a Lower sap
 *
 *       Ret:   error code to be passed to SM
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spDeleteNSap
(
SuId suId             /* sap Id */
)
#else
PUBLIC S16 spDeleteNSap(suId)
SuId suId;            /* sap Id */
#endif
{
   SpNSapCb *nSap;    /* network sap control block */
   PTR hl;            /* hash list entry */
   SpRteCb *rCb;      /* route control block */
   Bool found;        /* boolean to find nSap in rCb */
   U16 i;             /* loop variable */
   S16 ret;           /* return value */

   TRC2(spDeleteNSap)

   nSap = spCb.nSapList[suId];
   if (nSap == (SpNSapCb *) NULLP)
   {
      /* nSap not found, could be deleted in previous
       * deletion request, return success
       */
      RETVALUE(LCM_REASON_NOT_APPL);
   }

   /* check if sap is bound, bound sap can not be deleted */
   if (nSap->status & SP_BND)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNSap(): NSAP(id %d) is bound, can not be deleted", suId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }

   /* check is there any route using this nSap, if nSap is being
    * used by any route, then nSap can not be deleted
    */
   hl = (PTR) NULLP;
   found = FALSE;
   for (;;)
   {
      if ((ret = cmHashListGetNext(&spCb.rteHlCp, hl, (PTR *) &rCb)) == ROK)
      {
         if (rCb->nSap == nSap) 
         {
            found = TRUE;
            break;
         }
         hl = (PTR) rCb;
      }
      else
      {
         /* no more entries */
         break;
      }
   } /* for (;;) */

   if (found == TRUE)
   {
      SPDBGP(DBGMASK_MI, (spCb.spInit.prntBuf,
             "spDeleteNSap(): NSAP(id %d) being used by route,can't be deleted",
             suId));
      RETVALUE(LCM_REASON_INVALID_STATE);
   }
   
   /* all validation done, nSap can be deleted */

   /* remove all extened unit data control blocks */
   for (i = 0; i < spCb.spCfg.nmbXUdCb; i++)
   {
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                      (Data *) (*(nSap->xUdCb + (PTR) i)),
                      (Size) sizeof(SpXUdCb));
   }
   /* free xudCb list */
   (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                   (Data *) nSap->xUdCb,
                   (Size) ((Size) spCb.spCfg.nmbXUdCb * sizeof(SpXUdCb *)));

#ifdef ZP
   zpRunTimeUpd(ZP_SP_NSAPCB, (Void *) nSap, CMPFTHA_UPDTYPE_SYNC,
                CMPFTHA_ACTN_DEL);
   zpDelMapping(ZP_SP_NSAPCB, (Void *) nSap);
#endif /* ZP */

   /* release upper sap control block */
   (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                   (Data *) nSap, (Size) sizeof(SpNSapCb));

   /* decrement number of upper saps configured and initialize saplist entry */
   spCb.nmbNSaps--;
   spCb.nSapList[suId] = NULLP;
   RETVALUE(LCM_REASON_NOT_APPL);
} /* spDeleteNSap */

  
#ifdef SP_RUG
/*
 *
 *       Fun:   spGetVer
 *
 *       Desc:  Get interface version request handling, processes system agent
 *              control request primitive to get interface version number
 *
 *       Ret: ROK - operation successful
 *
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spGetVer
(
ShtGetVerCfm *getVerCfmInfo     /* get interface version information */
)
#else
PUBLIC S16 spGetVer (getVerCfmInfo)
ShtGetVerCfm *getVerCfmInfo;    /* get interface version information */
#endif
{
   TRC2(spGetVer);

   /* fill upper interface version informations */
   getVerCfmInfo->numUif = 1;
   getVerCfmInfo->uifList[0].intfId = SPTIF;
   getVerCfmInfo->uifList[0].intfVer = SPTIFVER;

   /* fill lower interface version informations */
   getVerCfmInfo->numLif = 1;
   getVerCfmInfo->lifList[0].intfId = SNTIF;
   getVerCfmInfo->lifList[0].intfVer = SNTIFVER;

#ifdef ZP   /* if SCCP is FT-HA / DFT-HA */
   /* fill peer interface version informations */
   zpGetVer(&getVerCfmInfo->pif);
#endif /* ZP */

   RETVALUE(ROK);
} /* spGetVer */


/*
 *
 *       Fun:   spSetVer
 *
 *       Desc:  Set interface version request handling, processes system agent 
 *              control request primitive to set interface version number
 *
 *       Ret: SP_NOP - No further operation needed. This value is returned
 *                     when either validation of interface info is failed
 *                     or interface info is for peer interface.
 *            SP_ADD - This value is returned when interface info is added 
 *                     into the list of version information control block list.
 *            SP_UPD - This value is returned when version information control 
 *                     block is updated.
 *       
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spSetVer
(
ShtVerInfo *shtVerInfo,     /* interface version information */
CmStatus *status,           /* status */
U16 *indx                   /* index of ver info control block in the list */
)
#else
PUBLIC S16 spSetVer(shtVerInfo, status, indx)
ShtVerInfo *shtVerInfo;     /* interface version information */
CmStatus *status;           /* status */
U16 *indx;                  /* index of ver info control block in the list */
#endif
{
   U16 i;
   S16 ret;
   Bool found;
   ShtVerInfo *intfInfo;
   SpSapCb *sapCb;
   SpNSapCb *nSapCb;

   TRC2(spSetVer);

   found = FALSE;

   status->reason = LCM_REASON_NOT_APPL;

#ifdef ZP
   /* check if this is applicable to PSF, if version info is for peer
      interface, then return SP_NOP. For peer interface, runtime update will 
      be done from within zpSetVer itself */
   if(zpSetVer(&shtVerInfo->intf, status) != RNA)
      RETVALUE(SP_NOP);
#endif /* ZP */

   /* validate interface version information, if interface version number in
      set request is greater than self interface version then return reason 
      as version mismatch */
   switch(shtVerInfo->intf.intfId)
   {
      case SPTIF:
         if(shtVerInfo->intf.intfVer > SPTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
      case SNTIF:
         if(shtVerInfo->intf.intfVer > SNTIFVER)
            status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
      default:
         status->reason = LCM_REASON_VERSION_MISMATCH;
         break;
   } /* end switch(shtVerInfo->intf.intfId) */
   
   if(status->reason != LCM_REASON_NOT_APPL)
      RETVALUE(SP_NOP);

   /* check if stored information already exists */
   for(i = 0; i < spCb.numIntfInfo && found == FALSE; i++)
   {
      intfInfo = &spCb.spVerInfoCb[i].intfInfo;
      if(intfInfo->intf.intfId == shtVerInfo->intf.intfId)
      {
         if(intfInfo->grpType == shtVerInfo->grpType)
         {
            /* if stored information found, replace version info with new info
               specified in set version request */
            switch(shtVerInfo->grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if((intfInfo->dstProcId == shtVerInfo->dstProcId) &&
                     (intfInfo->dstEnt.ent == shtVerInfo->dstEnt.ent) &&
                     (intfInfo->dstEnt.inst == shtVerInfo->dstEnt.inst))
                  {
                     intfInfo->intf.intfVer = shtVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
               case SHT_GRPTYPE_ENT:
                  if((intfInfo->dstEnt.ent == shtVerInfo->dstEnt.ent) &&
                     (intfInfo->dstEnt.inst == shtVerInfo->dstEnt.inst))
                  {
                     intfInfo->intf.intfVer = shtVerInfo->intf.intfVer;
                     found = TRUE;
                  }
                  break;
            } /* end switch(shtVerInfo->grpType) */
         } /* end if(intfInfo->grpType == shtVerInfo->grpType) */
      } /* end if(intfInfo->intf.intfId == shtVerInfo->intf.intfId) */
   } /* end for(i = 0; ...) */

   /* in worst case we need to store one intf version info for each SAP */
   if(found == FALSE)
   {
      /* check if version info can be appended to the list */
      if(spCb.numIntfInfo < ((Size)spCb.spCfg.nmbSaps + 
                            (Size)spCb.spCfg.nmbNSaps))
      {
         /* store version info at the end of the list */
         cmCopy((U8 *)shtVerInfo,
                (U8 *)&spCb.spVerInfoCb[spCb.numIntfInfo].intfInfo,  
                sizeof(ShtVerInfo));

         /* fill index to be returned, to add and update version info to
            peer in run time updation */
         *indx = spCb.numIntfInfo;

         /* increase number of interface information stored */
         spCb.numIntfInfo++;

         /* mark ret as SP_ADD, to add the ver info cb in the DLL in rsetCb */
         ret = SP_ADD;

      } /* end if(numIntfInfo < total number of SAPs) */
      else
      {
         status->reason = LCM_REASON_EXCEED_CONF_VAL;
         RETVALUE(SP_NOP);
      } /* end else */
   } /* end (found == FALSE) */
   else
   {        
      /* fill index to be returned, to add and update version info cb to
         peer in run time updation */
      *indx = i - 1;

      /* mark ret as SP_UPD, as version info already exists and needs peer 
         run time updation only */
      ret = SP_UPD;
   }

   /* update interface version info in pst within SAPs */
   switch(shtVerInfo->intf.intfId)
   {
      case SPTIF:
         for(i = 0; i < spCb.spCfg.nmbSaps; i++)
         {
            /* find sap cb */
            if((sapCb = *(spCb.sapList + (PTR)i)) != NULLP)
            {
               /* update interface version in pst only if SAP is bound */
               if(sapCb->status & SP_BND)
               {
                  switch(shtVerInfo->grpType)
                  {
                     case SHT_GRPTYPE_ALL:
                        if((shtVerInfo->dstProcId == sapCb->pst.dstProcId) &&
                           (shtVerInfo->dstEnt.ent == sapCb->pst.dstEnt) &&
                           (shtVerInfo->dstEnt.inst == sapCb->pst.dstInst))
                        {
                           sapCb->pst.intfVer = shtVerInfo->intf.intfVer;
                           sapCb->remIntfValid = TRUE;
                        }
                        break;
                     case SHT_GRPTYPE_ENT:
                        if((shtVerInfo->dstEnt.ent == sapCb->pst.dstEnt) &&
                           (shtVerInfo->dstEnt.inst == sapCb->pst.dstInst))
                        {
                           sapCb->pst.intfVer = shtVerInfo->intf.intfVer;
                           sapCb->remIntfValid = TRUE;
                        }
                        break;
                  } /* end switch(shtVerInfo->grpType) */
               } /* end if(sapCb->status & SP_BND) */
            } /* end if(sapCb != NULLP) */
         } /* end for(i = 0; ...) */
         break;

      case SNTIF:
         for(i = 0; i < spCb.spCfg.nmbNSaps; i++)
         {
            /* find nSap cb */
            if((nSapCb = *(spCb.nSapList + (PTR)i)) != NULLP)
            {
               switch(shtVerInfo->grpType)
               {
                  case SHT_GRPTYPE_ALL:
                     if((shtVerInfo->dstProcId == nSapCb->pst.dstProcId) &&
                        (shtVerInfo->dstEnt.ent == nSapCb->pst.dstEnt) &&
                        (shtVerInfo->dstEnt.inst == nSapCb->pst.dstInst))
                     {
                        nSapCb->pst.intfVer = shtVerInfo->intf.intfVer;
                        nSapCb->remIntfValid = TRUE;
                     }
                     break;
                  case SHT_GRPTYPE_ENT:
                     if((shtVerInfo->dstEnt.ent == nSapCb->pst.dstEnt) &&
                        (shtVerInfo->dstEnt.inst == nSapCb->pst.dstInst))
                     {
                        nSapCb->pst.intfVer = shtVerInfo->intf.intfVer;
                        nSapCb->remIntfValid = TRUE;
                     }
                     break;
               } /* end switch(shtVerInfo->grpType) */
            } /* end if(nSapCb != NULLP) */
         } /* end for(i = 0; ...) */
   } /* end switch(.intfId) */
   
   RETVALUE(ret);
} /* spSetVer */
#endif /* SP_RUG */


/*
 *
 *       Fun:   spSortBpc
 *
 *       Desc:  Sort the backup point code in order of their priority 
 *
 *       Ret:  none
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void spSortBpc
(
SpBpcCb *bpcList,
U16 nmbBpc
)
#else
PUBLIC Void spSortBpc(bpcList,nmbBpc)
SpBpcCb *bpcList;
U16 nmbBpc;
#endif
{

   SpBpcCb tmp;        /* temp var used to swap array element */
   U16 i;              /* loop counter */
   U16 j;              /* loop counter */
   for (i = 0; i < nmbBpc; i++)
   {
      for(j = i+1; j < nmbBpc; j++)
      {
         if (bpcList[j].prior > bpcList[i].prior)
         {
            tmp.bpc = bpcList[j].bpc;
            tmp.prior = bpcList[j].prior;
            bpcList[j].bpc = bpcList[i].bpc;
            bpcList[j].prior = bpcList[i].prior;
            bpcList[i].bpc = tmp.bpc;
            bpcList[i].prior = tmp.prior;
         }
      }
   }
   RETVOID;
} /* spSortBpc */
    

/*
 *
 *       Fun:   spGenCfgReq
 *
 *       Desc:  General Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spGenCfgReq
(
Pst *pst,              /* pointer to post structure */
SpMngmt *cfg           /* pointer to config structure */
)
#else
PUBLIC S16 spGenCfgReq(pst, cfg)
Pst *pst;              /* pointer to post structure */
SpMngmt *cfg;          /* pointer to config structure */
#endif
{
   U16 i;              /* variable for counter */ 
   Size spMemSize;     /* Memory size required */
   S16 ret;            /* return Value */
   U16 reason;         /* failure reason */
   Size spSapSize;     /* memeory for sap CB */    
   Size spNSapSize;    /* memory for nsap CB */
   Size spNwSize;      /* memeory for n/w CB */
   U8  tmrCnt;         /* timer counter */
   /* sp045.302 - modification - spAssoListSize is used if LSPV2_4 is not
    * defined
    */
#ifndef LSPV2_4   
   Size spAssoListSize;
#endif /* LSPV2_4 */   
#ifdef SP_RUG
   /* sp014.301 - addition - fields for intf ver info */
   U16 spMaxNumIntfInfo;     /* max number of interface version informations */
   Size spMaxIntfInfoSize;   /* max size for storing interface version
                                informations */
#endif

   TRC2(spGenCfgReq)

   /* sp044.302 - addition - Initialization of Local Variables */   
   spSapSize = 0;   
   spNSapSize = 0;   

/* validation of interface version number in smPst */
#ifdef SP_RUG
   if (cfg->t.cfg.s.spGen.sm.intfVer > LSPIFVER)
   {
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_VERSION_MISMATCH);
      RETVALUE(RFAILED);
   }
#endif /* SP_RUG */

   if (spCb.spInit.cfgDone != TRUE) /* first time around */
   {
      U32 tmpOffset;   /* sp038.302 - addition - offset of spCfg in spCb */
                       /* sp040.302 - modification - type of tmpOffset changed 
                        */

      /* sp040.302 - modification - type of tmpOffset changed */
      tmpOffset = (U32) SP_OFFSET(SpCb, spCfg);

      /* sp038.302 - modification - zero out spCb starting from spCfg addr */
      /* sp040.302 - modification - type casting sizeof with Size */
      cmZero((U8 *) &spCb.spCfg, (Size)(((Size)sizeof(SpCb)) - (Size)tmpOffset)); 

/* sp038.302 - modification - addmapping moved down after zeroing out
 * relevant portion of spCb
 */
#ifdef ZP
      zpAddMapping (ZP_SP_PCB, (Void *)&spCb, NULLP);
#endif /* ZP */
        
/* sp031.302 - addition - ustaMask is initialized if SP_USTA is defined */
#ifdef SP_USTA
    spCb.ustaMask |= LSP_USTAALARM;  /* enable unsolicit alarm */
#endif

      /* copy general configuration */
      cmCopy((U8 *)&cfg->t.cfg.s.spGen, (U8 *)&spCb.spCfg, 
             sizeof(SpGenCfg));

      spCb.spGlbTqCp.tmrLen = TQNUMENT;
      spCb.spSapTqCp.tmrLen = TQNUMENT;
      spCb.spNSapTqCp.tmrLen = TQNUMENT;
      spCb.spSsnTqCp.tmrLen = TQNUMENT;
#ifdef SPCO
      spCb.spConTqCp.tmrLen = TQNUMENT;
      spCb.spLclRefTqCp.tmrLen = TQNUMENT;
#endif /* SPCO */
      spCb.spRteTqCp.tmrLen = TQNUMENT;
      spCb.spXUdTqCp.tmrLen = TQNUMENT;
      for (i = 0; i < TQNUMENT; i++)
      {
         spCb.spGlbTq[i].first = NULLP;
         spCb.spSapTq[i].first = NULLP;
         spCb.spSsnTq[i].first = NULLP;
         spCb.spNSapTq[i].first = NULLP;
#ifdef SPCO
         spCb.spConTq[i].first = NULLP;
         spCb.spLclRefTq[i].first = NULLP;
#endif /* SPCO */
         spCb.spRteTq[i].first = NULLP;
         spCb.spXUdTq[i].first = NULLP;
      }
            
      /* Calculate how much memory we'll need */
      spMemSize =
         (
         /* control blocks */
         ((Size) spCb.spCfg.nmbNws * 
          (Size) SBUFSIZE((Size)sizeof(SpNwCb))) + 
         ((Size) spCb.spCfg.nmbSaps * 
          (Size) SBUFSIZE((Size)sizeof(SpSapCb))) +
         ((Size) spCb.spCfg.nmbNSaps * 
          (Size) SBUFSIZE((Size)sizeof(SpNSapCb))) + 
         (Size) SBUFSIZE(((Size)spCb.spCfg.nmbNws * 
          (Size) sizeof(SpNwCb *))) +
         (Size) SBUFSIZE(((Size) spCb.spCfg.nmbSaps * 
          (Size)sizeof(SpSapCb *))) +
         (Size) SBUFSIZE(((Size) spCb.spCfg.nmbNSaps * 
          (Size)sizeof(SpNSapCb *))) +
         ((Size)spCb.spCfg.nmbRtes * 
          (Size)SBUFSIZE((Size)sizeof(SpRteCb))));
            
      /* sp045.302 - modification - nmbAsso and nmbAddrs are per network
       * so allocating memory for all the networks.
       */
      /* table pointer list entries */
      {
         Size tmp, tmp1;
         tmp = cmFuncs.gttMemSize(spCb.spCfg.nmbAsso * spCb.spCfg.nmbNws,
                                  spCb.spCfg.nmbActns, spCb.spCfg.nmbAddrs * 
                                  spCb.spCfg.nmbNws);
         tmp1 = ptFuncs.gttMemSize(spCb.spCfg.nmbAsso * spCb.spCfg.nmbNws, 
                                   spCb.spCfg.nmbActns, spCb.spCfg.nmbAddrs *
                                   spCb.spCfg.nmbNws);
         spMemSize += (tmp > tmp1 ? tmp : tmp1);
         spMemSize += (spCb.spCfg.nmbAsso * spCb.spCfg.nmbNws) * 
                       (SBUFSIZE (sizeof (SpAssoCb) + 
                        SBUFSIZE (sizeof (SpAssoCb*))));
      }

      /* The following defines determine the size of our hash tables
       * will we be doing routing */
      if ((Size)spCb.spCfg.nmbRtes > (Size)0)
         spMemSize += (Size)SBUFSIZE(RTE_HL_SIZE * sizeof(CmListEnt));
            
#ifdef SPCO
#ifndef ZP
            /* Local References */
      spMemSize += (Size)(spCb.spCfg.nmbNws * 
                          spCb.spCfg.nmbCon * sizeof(SpLclRef));
#endif /* ZP */
      /* connection control blocks */
      spMemSize += (Size) (spCb.spCfg.nmbNws * 
                           spCb.spCfg.nmbCon * sizeof(SpConCb));
            
      /* sp026.302 - removal - remove memory calc for conn hash list
       * based on CG_KEY, CD_KEY and SU_KEY. These conn hash lists are
       * no longer used.
       */
#endif /* SPCO */
            
      /* extended unit data reassembly control blocks */
      spMemSize += (Size)(spCb.spCfg.nmbNSaps *
                          (Size) spCb.spCfg.nmbXUdCb * 
                          (Size)SBUFSIZE(sizeof(SpXUdCb*)));
      spMemSize += (Size)(spCb.spCfg.nmbNSaps *
                          (Size) spCb.spCfg.nmbXUdCb *
                          (Size) SBUFSIZE(sizeof(SpXUdCb)));
#ifdef SP_RUG
      /* sp014.301 */
      /* initialize number of interface info */
      spCb.numIntfInfo = 0;

      /* calculate maximum number of interface informations */
      spMaxNumIntfInfo = (Size)spCb.spCfg.nmbSaps + (Size)spCb.spCfg.nmbNSaps;

      /* calculate memory to store interface version info */
      spMaxIntfInfoSize = (Size)spMaxNumIntfInfo * (Size)sizeof(SpVerInfoCb);

      spMemSize += spMaxIntfInfoSize;
#endif /* SP_RUG */
            
      SPDBGP(SP_DBGMASK_INTERNAL,(spCb.spInit.prntBuf, "MEM: %ld\n",
             spMemSize));

      /* Allocate Memory */
      ret = SGetSMem(spCb.spInit.region, spMemSize, &spCb.spInit.pool);
      if (ret != ROK)
      {
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_MEM_NOAVAIL);
         SPLOGERROR(ERRCLS_ADD_RES, ESP176,(ErrVal)ret,"SGetSMem failed");
         RETVALUE(RFAILED);
      }  

      reason = LCM_REASON_MEM_NOAVAIL;

      /* Assign Memory to the Network Control Block List */
      spNwSize = (Size)((Size)spCb.spCfg.nmbNws * (Size)sizeof(SpNwCb*));
      ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data**)&spCb.nwList, spNwSize);

      if (ret == ROK)
      {
         cmZero ((U8 *) spCb.nwList, spNwSize);

         /* Assign Memory to the Sap list (UPPER) */
         spSapSize = (Size)((Size)spCb.spCfg.nmbSaps * 
                            (Size)sizeof(SpSapCb*));
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                        (Data**)&spCb.sapList, spSapSize);
      }
      if (ret == ROK)
      {
         cmZero ((U8 *) spCb.sapList, spSapSize);

         /* Assign Memory to the Network Sap list (LOWER) */
         spNSapSize = (Size)((Size)spCb.spCfg.nmbNSaps * 
                             (Size)sizeof(SpNSapCb*));
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                        (Data**)&spCb.nSapList, spNSapSize);
      }
            
      if (ret == ROK)
      {
         cmZero ((U8 *) spCb.nSapList, spNSapSize);
         /* sp045.302 - modification - memory allocation for association
          * list for LSPV2_4 interface version is being done
          * under network configuration
          */
#ifndef LSPV2_4
         /* Allocate memory for the assoCb list, only if
          * number of association is configured as non zero.
          */
         if (spCb.spCfg.nmbAsso > 0)
         {
            spAssoListSize = spCb.spCfg.nmbAsso * SBUFSIZE(sizeof(SpAssoCb *));
            ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                           (Data**) &spCb.assoList, spAssoListSize);
            if (ret == ROK)
            {
               cmZero((U8 *) spCb.assoList, spAssoListSize);
            }
         }
#endif /* LSPV2_4 */         
      }

#ifdef SP_RUG
      /* sp014.301 - addition - Assign Memory to Interface version info 
         control blocks list */
      ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data**)&spCb.spVerInfoCb, spMaxIntfInfoSize);
      if (ret == ROK)
      {
         cmZero ((U8 *)spCb.spVerInfoCb, spMaxIntfInfoSize);
      }
#endif /* SP_RUG */

      /* Assign memory to the hash lists */
      if ((Size)spCb.spCfg.nmbRtes > (Size)0)
      {
         if (ret == ROK)
         {
            ret = spInitRteHl(&spCb.rteCp);
         }
      }
      else
      {
         /* No routes, we can't operate */
         ret = RFAILED;
         SPLOGERROR(ERRCLS_INT_PAR, ESP177, (ErrVal) 0, 
                          "No routes, we can't operate");
      }

      /* sp026.302 - removal - remove function call spInitConHl. This
       * function was to maintain conn hash list based on CG_KEY,
       * CD_KEY and SU_KEY and is no longer used.
       */

      reason = LCM_REASON_REGTMR_FAIL;
      tmrCnt = 0;

      /* Register Our Timers */
      if (ret == ROK)
      {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
         ret = SRegTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.ssnTimeRes, (PAIFTMRS16)spPrcSsnCbTq);
#else
         ret = SRegTmr(spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.ssnTimeRes, (PFS16)spPrcSsnCbTq);
#endif /* SS_MULTIPLE_PROCS */          
      }
            
#ifdef SPCO
      if ((Size)spCb.spCfg.nmbCon != (Size)0)
      {
         if (ret == ROK)
         {
            tmrCnt++;
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS    
            ret = SRegTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                          (S16)spCb.spCfg.conTimeRes, (PAIFTMRS16)spPrcConCbTq);
#else
            ret = SRegTmr(spCb.spInit.ent, spCb.spInit.inst,
                          (S16)spCb.spCfg.conTimeRes, (PFS16)spPrcConCbTq);
#endif /* SS_MULTIPLE_PROCS */
         }
      } 
#endif /* SPCO */
      /* set up timer for ex. unit data assembly (CCITT 92) */
      if ((ret == ROK) && ((Size)spCb.spCfg.nmbXUdCb > (Size) 0))
      {
         tmrCnt++;
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS    
         ret = SRegTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.AsmbTimeRes, (PAIFTMRS16)spPrcXUdTq);
#else
         ret = SRegTmr(spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.AsmbTimeRes, (PFS16)spPrcXUdTq);
#endif /* SS_MULTIPLE_PROCS */
      }

      if (ret == ROK)
      {
         tmrCnt++;
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS    
         ret = SRegTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.recTimeRes, (PAIFTMRS16)spPrcRteCbTq);
#else
         ret = SRegTmr(spCb.spInit.ent, spCb.spInit.inst,
                       (S16)spCb.spCfg.recTimeRes, (PFS16)spPrcRteCbTq);
#endif /* SS_MULTIPLE_PROCS */
      }

      if (ret != ROK)
      {
         /* do all cleanup as gencfg has failed */
         /* return static buffer for Network */
         if (spCb.nwList != (SpNwCb **)NULLP)
         {
            (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                            (Data*)spCb.nwList, spNwSize);
         }
         /* return static buffer for Sap list (LOWER) */
         if (spCb.nSapList != (SpNSapCb **)NULLP)
         {
            (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                            (Data*)spCb.nSapList, spNSapSize);
         }
         /* return static buffer for Sap list (UPPER) */
         if (spCb.sapList != (SpSapCb **)NULLP)
         {
            (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                            (Data*) spCb.sapList, spSapSize);
         }

         /* sp045.302 - deletion - deallocation of memory for association list
          * deleted from here since it gets allocated in network conf. .This
          * is being done part of GTT per network changes.
          */
#ifdef SP_RUG
         /* sp014.301 - addition - Deallocate static buffer for 
         interface ver info CBs */
         if (spCb.spVerInfoCb != NULLP)
         {
            SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data*)spCb.spVerInfoCb, spMaxIntfInfoSize);
         }
#endif /* SP_RUG */

         if ((Size)spCb.spCfg.nmbRtes > (Size)0)
         {
            cmHashListDeinit(&spCb.rteHlCp);
         }

         /* sp026.302 - removal - remove freeing of mem for conn hash list
          * based on CG_KEY, CD_KEY and SU_KEY. These conn hash lists are
          * no longer used.
          */
      
         /* return static memory pool */
         (Void) SPutSMem(spCb.spInit.region, spCb.spInit.pool);

         /* deregister Our Timers  - in same order*/
     
         if (tmrCnt > 0)
         {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS   
            (Void) SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.ssnTimeRes, (PAIFTMRS16)spPrcSsnCbTq);
#else
            (Void) SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.ssnTimeRes, (PFS16)spPrcSsnCbTq);
#endif /* SS_MULTIPLE_PROCS */
            tmrCnt--;
         }
#ifdef SPCO
         if (tmrCnt > 0)
         {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
            (Void) SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.conTimeRes, (PAIFTMRS16)spPrcConCbTq);
#else
            (Void) SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.conTimeRes, (PFS16)spPrcConCbTq);
#endif /* SS_MULTIPLE_PROCS */
            tmrCnt--;
         }
#endif /* SPCO */
         if ((tmrCnt > 0) && ((Size)spCb.spCfg.nmbXUdCb > (Size) 0))
         {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
            (Void) SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.AsmbTimeRes, (PAIFTMRS16)spPrcXUdTq);
#else
            (Void) SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.AsmbTimeRes, (PFS16)spPrcXUdTq);
#endif /* SS_MULTIPLE_PROCS */
         }

         if (tmrCnt > 0)
         {
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS
            (Void) SDeregTmr(spCb.spInit.procId, spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.recTimeRes, (PAIFTMRS16)spPrcRteCbTq);
#else
            (Void) SDeregTmr(spCb.spInit.ent, spCb.spInit.inst,
                             (S16)spCb.spCfg.recTimeRes, (PFS16)spPrcRteCbTq);
#endif /* SS_MULTIPLE_PROCS */
         }

         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, reason);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (reason == LCM_REASON_REGTMR_FAIL)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP178, (ErrVal)ret, "SRegTmr failed");
         }
         else
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP179, (ErrVal)ret, 
                       "Mem allocation failed");
         }
#endif /* ERRCLASS */
         RETVALUE(RFAILED);
      }

      /* Initialize the Network pointers */
      for (i = 0; i < spCb.spCfg.nmbNws; i++)
         *(spCb.nwList + (PTR)i) = NULLP;
  
      /* Initialize the Sap pointers */
      for (i = 0; i < spCb.spCfg.nmbSaps; i++)
         *(spCb.sapList + (PTR)i) = NULLP;
 
      /* Initialize the Network Sap pointers */
      for (i = 0; i < spCb.spCfg.nmbNSaps; i++)
         *(spCb.nSapList + (PTR)i) = NULLP;

      /* sp045.302 - deletion - initialisation of GT related data moved to
       * network configuration.
       */
      /* Initialize the timers */
      cmInitTimers(spCb.timers, MAXSPTMR);
      spCb.spInit.cfgDone = TRUE;
   }
   else /* second time around */
   {
      spCb.spCfg.mngmntOn = cfg->t.cfg.s.spGen.mngmntOn;
      spCb.spCfg.sogThresh = cfg->t.cfg.s.spGen.sogThresh;
      spCb.spCfg.maxRstLvl =  cfg->t.cfg.s.spGen.maxRstLvl;
      spCb.spCfg.maxRstSubLvl =  cfg->t.cfg.s.spGen.maxRstSubLvl;
      spCb.spCfg.conThresh = cfg->t.cfg.s.spGen.conThresh;
      spCb.spCfg.queThresh = cfg->t.cfg.s.spGen.queThresh;
      spCb.spCfg.itThresh = cfg->t.cfg.s.spGen.itThresh;
      spCb.spCfg.defGuaTmr.enb = cfg->t.cfg.s.spGen.defGuaTmr.enb;
      spCb.spCfg.defGuaTmr.val = cfg->t.cfg.s.spGen.defGuaTmr.val;
      spCb.spCfg.defRstEndTmr.enb = cfg->t.cfg.s.spGen.defRstEndTmr.enb;
      spCb.spCfg.defRstEndTmr.val = cfg->t.cfg.s.spGen.defRstEndTmr.val;
      spCb.spCfg.tIntTmr.enb = cfg->t.cfg.s.spGen.tIntTmr.enb;
      spCb.spCfg.tIntTmr.val = cfg->t.cfg.s.spGen.tIntTmr.val;
      spCb.spCfg.defStatusEnqTmr.enb = 
                                cfg->t.cfg.s.spGen.defStatusEnqTmr.enb;
      spCb.spCfg.defStatusEnqTmr.val = 
                                cfg->t.cfg.s.spGen.defStatusEnqTmr.val;
      /* sp045.302 - addition - making numConnThresh reconfigurable */
#ifdef LSPV2_3
      spCb.spCfg.nmbConThresh = cfg->t.cfg.s.spGen.nmbConThresh;
#endif /* LSPV2_3 */
   }

   /* sp014.301 - modification - lmPst is made reconfigurable */
   /* Initialize the layer management bind info */

   spCb.spInit.lmPst.dstProcId = cfg->t.cfg.s.spGen.sm.dstProcId;
/* sp038.302 - addition - support for multiple instances */
#ifdef SS_MULTIPLE_PROCS   
   spCb.spInit.lmPst.srcProcId = spCb.spInit.procId;
#else   
   spCb.spInit.lmPst.srcProcId = SFndProcId();
#endif   
   spCb.spInit.lmPst.dstEnt = cfg->t.cfg.s.spGen.sm.dstEnt;
   spCb.spInit.lmPst.dstInst = cfg->t.cfg.s.spGen.sm.dstInst;
   spCb.spInit.lmPst.srcEnt = spCb.spInit.ent;
   spCb.spInit.lmPst.srcInst = spCb.spInit.inst;
   spCb.spInit.lmPst.prior = cfg->t.cfg.s.spGen.sm.prior;
   spCb.spInit.lmPst.route = cfg->t.cfg.s.spGen.sm.route;         
   spCb.spInit.lmPst.event = EVTNONE;
   spCb.spInit.lmPst.region = cfg->t.cfg.s.spGen.sm.region;
   spCb.spInit.lmPst.pool = cfg->t.cfg.s.spGen.sm.pool;
   spCb.spInit.lmPst.selector = cfg->t.cfg.s.spGen.sm.selector;
#ifdef SP_RUG
   /* sp014.301 - addition - initialize LM interface version number in lmPst */
   spCb.spInit.lmPst.intfVer = cfg->t.cfg.s.spGen.sm.intfVer;
#endif /* SP_RUG */
   RETVALUE(ROK);
} /* spGenCfgReq */


/*
 *
 *       Fun:   spNwCfgReq
 *
 *       Desc:  Network Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */

#ifdef ANSI
PUBLIC S16 spNwCfgReq
(
Pst *pst,             /* post structure */
SpMngmt *cfg          /* config struct */
)
#else
PUBLIC S16 spNwCfgReq(pst, cfg)
Pst *pst;             /* post structure */
SpMngmt *cfg;         /* config struct */
#endif
{
   U32 i;             /* loop variable */
   U8 nwIndx;         /* sp001.302 - addition - index of nwCb in nwList */
   SpNwCb *nwCb;      /* network control block */
   S16 ret;           /* return value */
   Size spAssoListSize; /* sp045.302 - addition - size of asso. list */

   TRC2(spNwCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Need general configuration done first */
   if (spCb.spInit.cfgDone == FALSE)
   {
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* Validation check before going for n/w config */
   /* check switch */
   switch (cfg->t.cfg.s.spNw.variant)
   {
      case LSP_SW_ITU:
         break;
      case LSP_SW_CHINA:
         break;
      default:
         SPLOGERROR(ERRCLS_INT_PAR, ESP180, 
                    (ErrVal) cfg->t.cfg.s.spNw.variant,
                    "unknown switch value");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LSP_REASON_INVALID_SWTCH);
         RETVALUE(RFAILED);
   }

   /* Check if the network is already configured */
   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == cfg->t.cfg.s.spNw.nwId)
      {
         /* Network Control Block Found */

         /* Reconfiguration */
         nwCb->defHopCnt = cfg->t.cfg.s.spNw.defHopCnt;
       
         /* sp037.302 - addition - sInfo made reconfigurable 
          * after reconfiguration of ssf, nsap should be disabled
          * and then enabled for sinfo to be passed to MTP3.
          */
         nwCb->sInfo = ((cfg->t.cfg.s.spNw.subService << 6) | SCCP_SI);

         nwCb->sioPrioImpPres =  cfg->t.cfg.s.spNw.sioPrioImpPres;
         if (nwCb->sioPrioImpPres == TRUE)
         {
            for(i = 0; i < MAXSIOPRIO; i++)
            {
               nwCb->sioPrioImp[i]= cfg->t.cfg.s.spNw.sioPrioImp[i];
            }
         }
         nwCb->defSstTmr.enb = cfg->t.cfg.s.spNw.defSstTmr.enb;
         nwCb->defSstTmr.val = cfg->t.cfg.s.spNw.defSstTmr.val;
         nwCb->defIgnTmr.enb = cfg->t.cfg.s.spNw.defIgnTmr.enb;
         nwCb->defIgnTmr.val = cfg->t.cfg.s.spNw.defIgnTmr.val;
         nwCb->defCrdTmr.enb = cfg->t.cfg.s.spNw.defCrdTmr.enb;
         nwCb->defCrdTmr.val = cfg->t.cfg.s.spNw.defCrdTmr.val;
         nwCb->defAsmbTmr.enb = cfg->t.cfg.s.spNw.defAsmbTmr.enb;
         nwCb->defAsmbTmr.val = cfg->t.cfg.s.spNw.defAsmbTmr.val;
         /* The following timres have been added for congestion handling 
          * in ITU-96 network : ds */
         nwCb->defAttackTmr.enb = cfg->t.cfg.s.spNw.defAttackTmr.enb;
         nwCb->defAttackTmr.val = cfg->t.cfg.s.spNw.defAttackTmr.val;
         nwCb->defDecayTmr.enb = cfg->t.cfg.s.spNw.defDecayTmr.enb;
         nwCb->defDecayTmr.val = cfg->t.cfg.s.spNw.defDecayTmr.val;
         nwCb->defCongTmr.enb = cfg->t.cfg.s.spNw.defCongTmr.enb;
         nwCb->defCongTmr.val = cfg->t.cfg.s.spNw.defCongTmr.val;
#ifdef SPCO
         nwCb->defFrzTmr.enb = cfg->t.cfg.s.spNw.defFrzTmr.enb;
         nwCb->defFrzTmr.val = cfg->t.cfg.s.spNw.defFrzTmr.val;
         nwCb->defConTmr.enb = cfg->t.cfg.s.spNw.defConTmr.enb;
         nwCb->defConTmr.val = cfg->t.cfg.s.spNw.defConTmr.val;
         nwCb->defIasTmr.enb = cfg->t.cfg.s.spNw.defIasTmr.enb;
         nwCb->defIasTmr.val = cfg->t.cfg.s.spNw.defIasTmr.val;
         nwCb->defIarTmr.enb = cfg->t.cfg.s.spNw.defIarTmr.enb;
         nwCb->defIarTmr.val = cfg->t.cfg.s.spNw.defIarTmr.val;
         nwCb->defRelTmr.enb = cfg->t.cfg.s.spNw.defRelTmr.enb;
         nwCb->defRelTmr.val = cfg->t.cfg.s.spNw.defRelTmr.val;
         nwCb->defRepRelTmr.enb = cfg->t.cfg.s.spNw.defRepRelTmr.enb;
         nwCb->defRepRelTmr.val = cfg->t.cfg.s.spNw.defRepRelTmr.val;
         nwCb->defIntTmr.enb = cfg->t.cfg.s.spNw.defIntTmr.enb;
         nwCb->defIntTmr.val = cfg->t.cfg.s.spNw.defIntTmr.val;
         nwCb->defRstTmr.enb = cfg->t.cfg.s.spNw.defRstTmr.enb;
         nwCb->defRstTmr.val = cfg->t.cfg.s.spNw.defRstTmr.val;
#endif /* SPCO */
       
         RETVALUE(ROK);
      }
   }

   /* New network config reqiuest. Check if the number of networks
    * has reached the max possible value. 
    */
   if (spCb.nmbNws >= (S16)spCb.spCfg.nmbNws)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP181, (ErrVal) spCb.spCfg.nmbNws,
                 "Maximum number of Network already configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_MAXNW_CFG);
      RETVALUE(RFAILED);
   }

   /* get memory for the network control block */
   ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                  (Data **) &nwCb, (Size) sizeof(SpNwCb));
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP182, (ErrVal)ret, "SGetSBuf failed");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL);
      RETVALUE(RFAILED);
   }
   cmZero ((U8 *)nwCb, sizeof(SpNwCb));

   if (spCb.spCfg.nmbAsso > 0)
   {
        /* sp045.302 - modification - calculating size for assolist */
         spAssoListSize = spCb.spCfg.nmbAsso * SBUFSIZE(sizeof(SpAssoCb *));
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                        (Data**) &nwCb->assoList, spAssoListSize);
         if (ret == ROK)
            cmZero((U8 *) nwCb->assoList, spAssoListSize);
         else
         {
            (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) nwCb,
                            (Size) sizeof(SpNwCb));

            SPLOGERROR(ERRCLS_ADD_RES, ESPXXX, (ErrVal)ret, "spNwCfgReq :\
                       SGetSBuf failed for assoList");
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL);
            RETVALUE(RFAILED);
         }

   }

   nwCb->nwId = cfg->t.cfg.s.spNw.nwId;
   nwCb->variant = cfg->t.cfg.s.spNw.variant;
   nwCb->pcLen = cfg->t.cfg.s.spNw.pcLen;
   nwCb->selfPc = cfg->t.cfg.s.spNw.selfPc;
   nwCb->sInfo = ((cfg->t.cfg.s.spNw.subService << 6) | SCCP_SI);
   nwCb->defHopCnt = cfg->t.cfg.s.spNw.defHopCnt;
   nwCb->niInd = cfg->t.cfg.s.spNw.niInd;
   nwCb->sioPrioImpPres =  cfg->t.cfg.s.spNw.sioPrioImpPres;
   if(nwCb->sioPrioImpPres)
   {
      for(i = 0; i < MAXSIOPRIO; i++)
      {
         nwCb->sioPrioImp[i]= cfg->t.cfg.s.spNw.sioPrioImp[i];
      }
   }
   nwCb->defSstTmr.enb = cfg->t.cfg.s.spNw.defSstTmr.enb;
   nwCb->defSstTmr.val = cfg->t.cfg.s.spNw.defSstTmr.val;
   nwCb->defIgnTmr.enb = cfg->t.cfg.s.spNw.defIgnTmr.enb;
   nwCb->defIgnTmr.val = cfg->t.cfg.s.spNw.defIgnTmr.val;
   nwCb->defCrdTmr.enb = cfg->t.cfg.s.spNw.defCrdTmr.enb;
   nwCb->defCrdTmr.val = cfg->t.cfg.s.spNw.defCrdTmr.val;
   nwCb->defAsmbTmr.enb = cfg->t.cfg.s.spNw.defAsmbTmr.enb;
   nwCb->defAsmbTmr.val = cfg->t.cfg.s.spNw.defAsmbTmr.val;

   /* The following timres have been added for congestion 
    * handling in ITU-96 network 
    */
   nwCb->defAttackTmr.enb = cfg->t.cfg.s.spNw.defAttackTmr.enb;
   nwCb->defAttackTmr.val = cfg->t.cfg.s.spNw.defAttackTmr.val;
   nwCb->defDecayTmr.enb = cfg->t.cfg.s.spNw.defDecayTmr.enb;
   nwCb->defDecayTmr.val = cfg->t.cfg.s.spNw.defDecayTmr.val;
   nwCb->defCongTmr.enb = cfg->t.cfg.s.spNw.defCongTmr.enb;
   nwCb->defCongTmr.val = cfg->t.cfg.s.spNw.defCongTmr.val;
#ifdef SPCO
   nwCb->defFrzTmr.enb = cfg->t.cfg.s.spNw.defFrzTmr.enb;
   nwCb->defFrzTmr.val = cfg->t.cfg.s.spNw.defFrzTmr.val;
   nwCb->defConTmr.enb = cfg->t.cfg.s.spNw.defConTmr.enb;
   nwCb->defConTmr.val = cfg->t.cfg.s.spNw.defConTmr.val;
   nwCb->defIasTmr.enb = cfg->t.cfg.s.spNw.defIasTmr.enb;
   nwCb->defIasTmr.val = cfg->t.cfg.s.spNw.defIasTmr.val;
   nwCb->defIarTmr.enb = cfg->t.cfg.s.spNw.defIarTmr.enb;
   nwCb->defIarTmr.val = cfg->t.cfg.s.spNw.defIarTmr.val;
   nwCb->defRelTmr.enb = cfg->t.cfg.s.spNw.defRelTmr.enb;
   nwCb->defRelTmr.val = cfg->t.cfg.s.spNw.defRelTmr.val;
   nwCb->defRepRelTmr.enb = cfg->t.cfg.s.spNw.defRepRelTmr.enb;
   nwCb->defRepRelTmr.val = cfg->t.cfg.s.spNw.defRepRelTmr.val;
   nwCb->defIntTmr.enb = cfg->t.cfg.s.spNw.defIntTmr.enb;
   nwCb->defIntTmr.val = cfg->t.cfg.s.spNw.defIntTmr.val;
   nwCb->defRstTmr.enb = cfg->t.cfg.s.spNw.defRstTmr.enb;
   nwCb->defRstTmr.val = cfg->t.cfg.s.spNw.defRstTmr.val;
#endif /* SPCO */
       
   nwCb->sls = 0;
       
   /* The sls Mask is stored in the here because it is associated
    * with the variant value.
    */

      nwCb->slsMask = SLSMASK_CCITT;

#ifndef ZP 
#ifdef SPCO
   if ((Size)spCb.spCfg.nmbCon > (Size)0)
   {
      /* get memory for the local reference list  */
      ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, 
                     (Data **) &nwCb->lclRef,
                     (Size)((Size)spCb.spCfg.nmbCon * sizeof(SpLclRef)));

      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP183, (ErrVal) ret,
                    "SGetSBuf failed");
         /* sp001.302 - addition - free buffer for network control block */
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) nwCb,
                         (Size) sizeof(SpNwCb));
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_MEM_NOAVAIL);
         RETVALUE(RFAILED);
      }
      else
      {
         cmZero((U8 *)nwCb->lclRef, spCb.spCfg.nmbCon * sizeof(SpLclRef));
         nwCb->nmbLr = 0;              
         /* sp004.302 - addition - initialize nextLr to zero */
         nwCb->nextLr = 0;
         for (i = 0; i < spCb.spCfg.nmbCon; i++)
         {
            nwCb->lclRef[i].fflag = FALSE;
            nwCb->lclRef[i].cb = NULLP;
            nwCb->lclRef[i].nwData = nwCb;
            cmInitTimers(nwCb->lclRef[i].timers, TMR_DEF_MAX);
         }
      }
   }
#endif /* SPCO */
#endif /* ZP */
   nwCb->xUdRefCount = 0;   /* extended unit data reference counter */
   *(spCb.nwList + (PTR) nwIndx) = nwCb;
   spCb.nmbNws++;

#ifdef ZP
   zpAddMapping (ZP_SP_NWCB, (Void *)nwCb, NULLP);
#endif /* ZP */
   RETVALUE(ROK);
}/* spNwCfgReq */


/*
 *
 *       Fun:   spSapCfgReq
 *
 *       Desc:  Transport (upper) Sap Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spSapCfgReq
(
Pst *pst,
SpMngmt *cfg
)
#else
PUBLIC S16 spSapCfgReq(pst, cfg)
Pst *pst;
SpMngmt *cfg;
#endif
{
   SpSapCb *sapCb;
   U16 i;
   U16 j;
   S16 ret;

   TRC2(spSapCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Need general configuration done first */
   if (spCb.spInit.cfgDone == FALSE)
   {
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

#if (ERRCLASS & ERRCLS_INT_PAR) 
   /* Validate index */
   if (cfg->hdr.elmId.elmntInst1 >= (S16)spCb.spCfg.nmbSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP184, 
                 (ErrVal) cfg->hdr.elmId.elmntInst1,
                 "Sap index out of range");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_INVALID_SAP);
      RETVALUE(RFAILED);
    }
#endif /* ERRCLASS */
    /* Find the Network Control Block */
   for (i = 0; i < spCb.nmbNws; i++)
   {
      if (cfg->t.cfg.s.spSap.nwId == (*(spCb.nwList + (PTR)i))->nwId) 
      {
         break;
      }
   }

   if (i == spCb.nmbNws)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP185, (ErrVal) 0, "network not configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_NW_NOTCFG);
      RETVALUE(RFAILED);
   }

   /* Check if Sap has already been configured */
   if ((sapCb = *(spCb.sapList + (PTR)cfg->hdr.elmId.elmntInst1))!=NULLP)
   {
    /* 
     *  Parameters that can be reconfigured are 
     *  nmbBpc,mem,  nmbConPc, conPc and Interface version num.
     */
#ifdef SP_RUG

      /* sp014.301 - addition - reconfigure interface version info */ 
      if (cfg->t.cfg.s.spSap.remIntfValid == TRUE)
      {
         /* validate interface version number */
         if (cfg->t.cfg.s.spSap.remIntfVer > SPTIFVER)
         {
            /* send nok confirmation with reason version mismatch */
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                        LCM_REASON_VERSION_MISMATCH);
            RETVALUE(RFAILED);
          }
          else
          {
             /* reconfigure interface version number in pst of SAP */
             sapCb->pst.intfVer = cfg->t.cfg.s.spSap.remIntfVer;

             /* mark the validity of remote interface version number */
             sapCb->remIntfValid = TRUE;

             /* mark version controlling entity as layer manager */
             sapCb->verContEnt = ENTSM;
          }
      }
#endif /* SP_RUG */

      sapCb->pst.region = cfg->t.cfg.s.spSap.mem.region;
      sapCb->pst.pool = cfg->t.cfg.s.spSap.mem.pool;
      sapCb->nmbBpc = cfg->t.cfg.s.spSap.nmbBpc;
      for (i=0; i < sapCb->nmbBpc; i++)
      {
         sapCb->bpcList[i].bpc = cfg->t.cfg.s.spSap.bpcList[i].bpc;
         sapCb->bpcList[i].prior = cfg->t.cfg.s.spSap.bpcList[i].prior;
      }

      /* sp047.302 - Addition - Configure the msgInterceptEnabled flag */
#ifdef LSPV2_5
      sapCb->msgInterceptEnabled = cfg->t.cfg.s.spSap.msgInterceptEnabled;
#else
      sapCb->msgInterceptEnabled = FALSE;
#endif

      /* sort the backup point code as per their priority */
      spSortBpc(sapCb->bpcList, sapCb->nmbBpc);
      sapCb->nmbConPc = cfg->t.cfg.s.spSap.nmbConPc;
      for (j = 0; j < sapCb->nmbConPc; j++)
         sapCb->conPc[j] = cfg->t.cfg.s.spSap.conPc[j];

      RETVALUE(ROK);
   }

#if  (ERRCLASS & ERRCLS_INT_PAR)
   if (spCb.nmbSaps == spCb.spCfg.nmbSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP186, (ErrVal) spCb.nmbSaps,
                 "Max number of saps already configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_MAXSAP_CFG);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
         
   /* get memory for the sap */
   ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, (Data **) &sapCb,
                  (Size) sizeof(SpSapCb));
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP187, (ErrVal) ret, "SGetSBuf failed");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL);
      RETVALUE(RFAILED);
   }
   cmZero ((U8 *)sapCb, sizeof(SpSapCb));

#ifdef SP_RUG
   /* sp014.301 - addition - if valid interface version number is 
      present in config param, initialize interface version number 
      in SAP pst */
   if (cfg->t.cfg.s.spSap.remIntfValid == TRUE)
   {
      /* validate interface version number */
      if (cfg->t.cfg.s.spSap.remIntfVer > SPTIFVER)
      {
         /* send nok confirmation with reason version mismatch */
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                           LCM_REASON_VERSION_MISMATCH);

        /* deallocate buffer for SAP */
        (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                        (Data *) sapCb, (Size) sizeof(SpSapCb));

         RETVALUE(RFAILED);
      }
      else
      {
         /* initialize interface version number in pst of SAP */
         sapCb->pst.intfVer = cfg->t.cfg.s.spSap.remIntfVer;

         /* mark the validity of remote interface version number */
         sapCb->remIntfValid = TRUE;

         /* mark version controlling entity as layer manager */
         sapCb->verContEnt = ENTSM;  /* version controller is SM */
      }
   }
   else
   {
      /* mark the validity of remote interface version as FALSE */
      sapCb->remIntfValid = FALSE;

      /* mark version controlling entity as unknown */
      sapCb->verContEnt = ENTNC;  /* version controller unknown */
   }
#endif /* SP_RUG */

      *(spCb.sapList + (PTR)cfg->hdr.elmId.elmntInst1) = sapCb;
      sapCb->pst.selector = cfg->t.cfg.s.spSap.selector;
      sapCb->pst.region = cfg->t.cfg.s.spSap.mem.region;
      sapCb->pst.pool = cfg->t.cfg.s.spSap.mem.pool;
      sapCb->pst.prior = cfg->t.cfg.s.spSap.prior;
      sapCb->pst.route = cfg->t.cfg.s.spSap.route;
      /* sp047.302 - Addition - Configure the msgInterceptEnabled flag */
#ifdef LSPV2_5
      sapCb->msgInterceptEnabled = cfg->t.cfg.s.spSap.msgInterceptEnabled;
#else
      sapCb->msgInterceptEnabled = FALSE;
#endif

      /* destination is filled in at bind, set to "NOT CONFIGURED" */
      sapCb->pst.dstProcId = PROCIDNC;
      sapCb->pst.dstEnt = ENTNC;
      sapCb->pst.dstInst = INSTNC;
      sapCb->pst.srcProcId = spCb.spInit.procId;
      sapCb->pst.srcEnt = spCb.spInit.ent;
      sapCb->pst.srcInst = spCb.spInit.inst;
      sapCb->pst.event = EVTNONE;
      sapCb->spId = (SpId)cfg->hdr.elmId.elmntInst1;
      sapCb->nwData = *(spCb.nwList + i);
      sapCb->status = 0;
      sapCb->ssn = 0;
      sapCb->aSsn = 0;
      sapCb->nmbBpc = cfg->t.cfg.s.spSap.nmbBpc;
      for (i=0; i < sapCb->nmbBpc; i++)
      {
         sapCb->bpcList[i].bpc = cfg->t.cfg.s.spSap.bpcList[i].bpc;
         sapCb->bpcList[i].prior = cfg->t.cfg.s.spSap.bpcList[i].prior;
      }

      /* sort the backup point code as per their priority rel 3.2 */
      spSortBpc(sapCb->bpcList, sapCb->nmbBpc);
      sapCb->nmbConPc = cfg->t.cfg.s.spSap.nmbConPc;
      for (j = 0; j < sapCb->nmbConPc; j++)
         sapCb->conPc[j] = cfg->t.cfg.s.spSap.conPc[j];
      cmInitTimers(sapCb->timers, MAXSAPTMR);
      spCb.nmbSaps++;

#ifdef ZP
      zpAddMapping (ZP_SP_SAPCB, (Void *)sapCb, NULLP);
#endif /* ZP */
   RETVALUE(ROK);
}/* spSapCfgReq */


/*
 *
 *       Fun:   spNSapCfgReq
 *
 *       Desc:  Network Sap Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spNSapCfgReq
(
Pst *pst,                 /* pointer to pst structure */
SpMngmt *cfg              /* pointer to GenCfg struct */ 
)
#else
PUBLIC S16 spNSapCfgReq(pst, cfg)
Pst *pst;                 /* pointer to pst structure */
SpMngmt *cfg;             /* pointer to GenCfg struct */
#endif
{
   SpXUdCb*  xUdPtr;      /* pointer to XUD Control Block */
   U16 i;                 /* counter variable */
   U16 j;                 /* counter variable */
   U16 indx;              /* index in an array of SapCb's*/
   SpNSapCb *nSapCb;      /* pointer to SapCb */
   S16 ret;               /* return value */

   TRC2(spNSapCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Need general configuration done first */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP188, (ErrVal) ERRZERO,
                 "general configuration needs to be done first");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
         
#if (ERRCLASS & ERRCLS_INT_PAR) 
         /* Validate index */
   if (cfg->hdr.elmId.elmntInst1 >= (S16)spCb.spCfg.nmbNSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP189, 
                 (ErrVal) cfg->hdr.elmId.elmntInst1,
                 "NSap index out of range");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
   /* Check id nwId is valid */
   for (i = 0; i < spCb.nmbNws; i++)
   {
      if (cfg->t.cfg.s.spNSap.nwId == (*(spCb.nwList + (PTR)i))->nwId) 
      {
         break;
      }
   }

   if (i == spCb.nmbNws)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP190, (ErrVal) 0, "network not configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_NW_NOTCFG);
      RETVALUE(RFAILED);
   }

   /* check to see if Sap is already configured */
   if ((nSapCb= *(spCb.nSapList + (PTR)cfg->hdr.elmId.elmntInst1))!=NULLP)
   {
#ifdef SP_RUG
      /* sp014.301 - addition - reconfigure interface version */
      if (cfg->t.cfg.s.spNSap.remIntfValid == TRUE)
      {
          /* validate interface version number */
         if (cfg->t.cfg.s.spNSap.remIntfVer > SNTIFVER)
         {
            /* send nok confirmation with reason version mismatch */
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                           LCM_REASON_VERSION_MISMATCH);
            RETVALUE(RFAILED);
         }
         else
         {
            /* reconfigure interface version number in pst within NSAP */
            nSapCb->pst.intfVer = cfg->t.cfg.s.spNSap.remIntfVer;

            /* mark the validity of remote interface version number */
            nSapCb->remIntfValid = TRUE;
         }
      }
#endif /* SP_RUG */

      nSapCb->msgLen = cfg->t.cfg.s.spNSap.msgLen;
      RETVALUE(ROK);
   }

#if  (EERRCLASS & ERRCLS_INT_PAR)         
   if (spCb.nmbNSaps == spCb.spCfg.nmbNSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP191, (ErrVal) spCb.nmbNSaps,
                 "Maximum number of Nsaps already configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_MAXSAP_CFG);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
         
   /* get memory for the sap */
   ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data **) &nSapCb, (Size) sizeof(SpNSapCb));
   if (ret != ROK)
   {
      SPLOGERROR(ERRCLS_ADD_RES, ESP192, (ErrVal)ret, "SGetSBuf failed");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_MEM_NOAVAIL);
      RETVALUE(RFAILED);
   }
   cmZero ((U8 *)nSapCb, sizeof(SpNSapCb));

#ifdef SP_DIS_SAP
   nSapCb->contEnt = ENTSM;    /* SM is the controlloing entity */
#else
   nSapCb->contEnt = ENTNC;    /* unknown controlling entity */
#endif /* SP_DIS_SAP */

   nSapCb->nwData = *(spCb.nwList + i);
   nSapCb->suId = (SuId)cfg->hdr.elmId.elmntInst1;
   nSapCb->spId = cfg->t.cfg.s.spNSap.spId;
   nSapCb->pst.selector = cfg->t.cfg.s.spNSap.selector;
   nSapCb->pst.region = cfg->t.cfg.s.spNSap.mem.region;
   nSapCb->pst.pool = cfg->t.cfg.s.spNSap.mem.pool;
   nSapCb->pst.prior = cfg->t.cfg.s.spNSap.prior;
   nSapCb->pst.route = cfg->t.cfg.s.spNSap.route;
   nSapCb->pst.dstProcId = cfg->t.cfg.s.spNSap.dstProcId;
   nSapCb->pst.dstEnt = cfg->t.cfg.s.spNSap.dstEnt;
   nSapCb->pst.dstInst = cfg->t.cfg.s.spNSap.dstInst;
/* sp038.302 - addition - support for multiple instances */
/* sp039.302 - modification - copy dstProcId in srcProcId for multiple 
 * instances.
 */
#ifndef SS_MULTIPLE_PROCS   
#ifndef ZP
   nSapCb->pst.srcProcId = spCb.spInit.procId;
#else
   /* We don't care if we are pure FTHA or DFTHA at this point */
   nSapCb->pst.srcProcId = CMFTHA_RES_RSETID;
#endif /* ZP */
#else
   nSapCb->pst.srcProcId = pst->dstProcId;
#endif /* SS_MULTIPLE_PROCS */   

   nSapCb->pst.srcEnt = spCb.spInit.ent;
   nSapCb->pst.srcInst = spCb.spInit.inst;
   nSapCb->pst.event = EVTNONE;

#ifdef SP_RUG
   /* sp014.301 - addition - if valid interface version number is 
      present in config param */
   if (cfg->t.cfg.s.spNSap.remIntfValid == TRUE)
   {
      /* validate interface version number */
      if (cfg->t.cfg.s.spNSap.remIntfVer > SNTIFVER)
      {
         /* send nok confirmation with reason version mismatch */
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                       LCM_REASON_VERSION_MISMATCH);

         /* defallocate buffer for NSAP */
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                          (Data *) nSapCb, (Size) sizeof(SpNSapCb));
         RETVALUE(RFAILED);
      }
      else
      {
         /* initialize interface version number in pst within NSAP */
         nSapCb->pst.intfVer = cfg->t.cfg.s.spNSap.remIntfVer;

         /* mark the validity of remote interface version number */
         nSapCb->remIntfValid = TRUE;
      }
   }
   else
   {
      Bool found;
      found = FALSE;
      for (j = 0; j < spCb.numIntfInfo && found == FALSE; j++)
      {
         if (spCb.spVerInfoCb[j].intfInfo.intf.intfId == SNTIF)
         {
            switch (spCb.spVerInfoCb[j].intfInfo.grpType)
            {
               case SHT_GRPTYPE_ALL:
                  if ((spCb.spVerInfoCb[j].intfInfo.dstProcId == 
                      nSapCb->pst.dstProcId) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.ent == 
                       nSapCb->pst.dstEnt) &&
                      (spCb.spVerInfoCb[j].intfInfo.dstEnt.inst ==
                       nSapCb->pst.dstInst))
                     found = TRUE;
                  break;
               case SHT_GRPTYPE_ENT:
                  if ((spCb.spVerInfoCb[j].intfInfo.dstEnt.ent ==
                       nSapCb->pst.dstEnt) &&
                       (spCb.spVerInfoCb[j].intfInfo.dstEnt.inst ==
                        nSapCb->pst.dstInst))
                  found = TRUE;
                  break;
               default:
                  break;
            } /* end switch(.grpType) */
         } /* end if(.intfId == SNTIF) */
      } /* end  for(j = 0; ...) */
      if (found == TRUE)
      {
         /* initialize interface version number in pst */
         nSapCb->pst.intfVer = 
                     spCb.spVerInfoCb[j - 1].intfInfo.intf.intfVer;

         /* mark the validity of remote interface version number */
         nSapCb->remIntfValid = TRUE;
      }
      else
         nSapCb->remIntfValid = FALSE;
   } /* end else-if(cfg...remIntfValid == TRUE) */
#endif /* SP_RUG */

   /* get memory for extended unit data control blocks */
   if ((Size)spCb.spCfg.nmbXUdCb > (Size)0)
   {
      ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, 
                     (Data **) &nSapCb->xUdCb,
                      (Size)((Size)spCb.spCfg.nmbXUdCb * 
                                    sizeof(SpXUdCb*)));
      if (ret != ROK)
      {
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                            (Data *) nSapCb, (Size) sizeof(SpNSapCb));

         SPLOGERROR(ERRCLS_ADD_RES, ESP193, (ErrVal) ret, "SGetSBuf failed");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                     LCM_REASON_MEM_NOAVAIL);
         RETVALUE(RFAILED);
      }

      cmZero((U8 *)nSapCb->xUdCb, 
              spCb.spCfg.nmbXUdCb * sizeof(SpXUdCb*));

      for ( j = 0; j < spCb.spCfg.nmbXUdCb; j++)
      {
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, 
                        (Data **) &xUdPtr, (Size)sizeof(SpXUdCb));
         if (ret != ROK)
         {
            for ( indx = 0; indx < j; indx++)
            {
               (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                                 (Data *) *(nSapCb->xUdCb + 
                                 (PTR)indx), (Size)sizeof(SpXUdCb));
            }

           (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                           (Data *) nSapCb->xUdCb,
                           (Size)((Size)spCb.spCfg.nmbXUdCb * 
                            sizeof(SpXUdCb*)));
           (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                           (Data *) nSapCb, (Size) sizeof(SpNSapCb));

           SPLOGERROR(ERRCLS_ADD_RES, ESP194, (ErrVal) ret, "SGetSBuf failed");
           spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                       LCM_REASON_MEM_NOAVAIL);
           RETVALUE(RFAILED);
         }
         cmZero ((U8 *)xUdPtr, sizeof(SpXUdCb));
              
         /* initialize SpXUdCb structure */
         xUdPtr->used = FALSE;
         cmInitTimers(xUdPtr->timers, TMR_DEF_MAX);

         /* insert in list */
         *(nSapCb->xUdCb + (PTR)j) = xUdPtr;
#ifdef ZP
         xUdPtr->nSap = nSapCb;
#endif /* ZP */
      } /* for (j = 0; ...) */
   } /* .inmbXUdCb > (Size)0 */

   *(spCb.nSapList + (PTR)cfg->hdr.elmId.elmntInst1) = nSapCb;
         
   nSapCb->status = 0;
   nSapCb->trc = FALSE;   /* default value */
   nSapCb->msgLen = cfg->t.cfg.s.spNSap.msgLen;
         
   cmInitTimers(nSapCb->timers, MAXNSAPTMR);
        
   /*
    * Initialize message config/control structures 
    */
   MFINITPROF(&nSapCb->mfCfgProf, ret, NMB_MID, 0, cpAllPduDefs, NULLP, 0,
              (MF_IGNORE | MF_SCCP), NULLP);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ret != MFROK)
   {
      if ((Size)spCb.spCfg.nmbXUdCb > (Size)0)
      {
         for ( j = 0; j < spCb.spCfg.nmbXUdCb; j++)
         {
            (Void)SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                           (Data *) *(nSapCb->xUdCb + (PTR)j),
                           (Size)sizeof(SpXUdCb));
         }
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                         (Data *) nSapCb->xUdCb,
                         (Size)((Size)spCb.spCfg.nmbXUdCb * sizeof(SpXUdCb*)));
      }
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                      (Data *) nSapCb, (Size) sizeof(SpNSapCb));
      SPLOGERROR(ERRCLS_INT_PAR, ESP195, (ErrVal) ret, "MFINITPROF failed");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_MFINIT_FAIL);
      *(spCb.nSapList + (PTR) cfg->hdr.elmId.elmntInst1) = NULLP;
      RETVALUE(RFAILED);
   } /* ret != MFROK */
#endif /* ERRCLASS & ERRCLS_INT_PAR */
         
   MFINITMSGCTL(&nSapCb->mfMsgCtl, ret, &nSapCb->mfCfgProf, 0);
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (ret != MFROK)
   {
      if ((Size)spCb.spCfg.nmbXUdCb > (Size)0)
      {
         for ( j = 0; j < spCb.spCfg.nmbXUdCb; j++)
         {
            (Void)SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                           (Data *) *(nSapCb->xUdCb + (PTR)j),
                           (Size)sizeof(SpXUdCb));
         }
         (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool, 
                         (Data *) nSapCb->xUdCb,
                         (Size)((Size)spCb.spCfg.nmbXUdCb * sizeof(SpXUdCb*)));
      }
      (Void) SPutSBuf(spCb.spInit.region, spCb.spInit.pool,
                      (Data *) nSapCb, (Size) sizeof(SpNSapCb));
      SPLOGERROR(ERRCLS_INT_PAR, ESP196, (ErrVal) ret, "MFINITMSGCTL failed");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_MFINIT_FAIL);
      *(spCb.nSapList + (PTR) cfg->hdr.elmId.elmntInst1) = NULLP;
      RETVALUE(RFAILED);
   } /* ret != MFROK */
#endif /* ERRCLASS & ERRCLS_INT_PAR */
                  
   spCb.nmbNSaps++;                   /* Number of network saps */
        
#ifdef ZP
   zpAddMapping(ZP_SP_NSAPCB, (Void *)nSapCb, NULLP);
#endif /* ZP */

   RETVALUE(ROK);
} /* NSapCfgReq */


/*
 *
 *       Fun:   spAssoCfgReq
 *
 *       Desc:  Association Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spAssoCfgReq
(
Pst *pst,              /* pointer to pst struct */
SpMngmt *cfg           /* pointer to GenCfg struct */
)
#else
PUBLIC S16 spAssoCfgReq(pst, cfg)
Pst *pst;              /* pointer to pst struct */
SpMngmt *cfg;          /* pointer to GenCfg struct */
#endif
{
   SpAssoCb *assoCb;   /* pointer to assoCb */
   S16 ret;            /* return value */
   U16 i;              /* counter variable */
   U16 indx;           /* index in an array */
#ifdef LSPV2_4
   U8 nwIndx;          /* sp045.302 - addition - index of nwCb in nwList */
   Bool found;         /* sp045.302 - addition - boolean */
#endif /* LSPV2_4 */
   SpNwCb *nwCb;       /* sp045.302 - addition - network control block */

   
   TRC2(spAssoCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* General configuration has to be done */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP197, (ErrVal) 0,
                 "General Configuration to be done");
      /* sp045.302 - deletion - to avoid multiple negative cfm to LM 
       * we are checking the return status in the parent function.
       */
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

/* sp045.302 - addition - checking for LSP interface version flags prior to
 * LSPV2_4. if LSPV2_4 flag is not enabled then global GT database will be
 * used.
 */
   nwCb = NULLP;
#ifdef LSPV2_4
   found = FALSE;

   /* sp045.302 - addtion - check if network id in config req. is configured */
   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == cfg->t.cfg.s.spAsso.nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, cfg->t.cfg.s.spAsso.nwId,
                "spAssoCfgReq :network id not configured");
      /* sp045.302 - deletion - spSendLmCfm removed to avoid multiple 
       * negative cfm to LM 
       * we are checking the return status in the parent function.
       */
      RETVALUE(RFAILED);
   }

   /* sp001.302 - addition - check for exact match or overlapping match of
    * the rule. If exact match found, return ok, if overlapping match is
    * found, return failure else its a new association config request
    */

   /* sp045.302 - addition - pass network CB */
   ret = spAssoForRule(&cfg->t.cfg.s.spAsso.rule, &indx, nwCb);
   if (ret == ROK)
   {
     /* an exact match of the rule is found in already configured
      * associations list. Case of repeated config request, return OK
      */
     RETVALUE(ROK);
   }
   else
   {
      if (ret == ROKDUP)
      {
         /* overlapping match was found, log error and return failure */
         SPLOGERROR(ERRCLS_INT_PAR, ESP198, (ErrVal) ret, "Overlapping rule");
         /* sp045.302 - deletion - to avoid multiple negative cfm to LM 
          * we are checking the return status in the parent function.
          */
         RETVALUE(RFAILED);
      }
      else
      {
         /* sp045.302 - modification - nmbAsso moved to netwrok Cb */
         /* check if the configuration within limits */
         if (nwCb->nmbAsso == spCb.spCfg.nmbAsso) 
         {
            /* sp045.302 - modification - nmbAsso moved to netwrok Cb */
            SPLOGERROR(ERRCLS_INT_PAR, ESP199, (ErrVal) nwCb->nmbAsso,
                       "Max number of associations already\
                       configured for network id ");
            /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
             * multiple negative cfm to LM. 
             * we are checking the return status in the parent function.
             */
            RETVALUE(RFAILED);
         }
         if (cfg->t.cfg.s.spAsso.nmbActns > SP_MAX_ACTNS)
         {
            /* sp045.302 - modification - nmbAsso moved to netwrok Cb */
            SPLOGERROR(ERRCLS_INT_PAR, ESP200, (ErrVal) nwCb->nmbAsso,
                       "Change the SP_MAX_ACTNS if you want so many actions.");
            /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
             * multiple negative cfm to LM. 
             * we are checking the return status in the parent function.
             */
            RETVALUE(RFAILED);
         }
         /* sp045.302 - modification - nmbActns moved to netwrok Cb */
         if ((nwCb->nmbActns + cfg->t.cfg.s.spAsso.nmbActns) >
              spCb.spCfg.nmbActns)
         {
            /* sp045.302 - modification - nmbAsso moved to netwrok Cb */
            SPLOGERROR(ERRCLS_INT_PAR, ESP201, (ErrVal) nwCb->nmbAsso,
                       "Max number of actions already configured");
            /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
             * multiple negative cfm to LM. 
             * we are checking the return status in the parent function.
             */
            RETVALUE(RFAILED);
         }

         /* Allocate memory for a Assocation Control Block */
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, (Data **) &assoCb,
                        (Size) sizeof(SpAssoCb));
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP202, (ErrVal) ret, "SGetSBuf failed");
            /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
             * multiple negative cfm to LM. 
             * we are checking the return status in the parent function.
             */
            RETVALUE(RFAILED);
         }
         cmZero ((U8 *)assoCb, sizeof(SpAssoCb));

         /* Initialize assoCb */
         assoCb->region = spCb.spInit.region;
         assoCb->pool = spCb.spInit.pool;
         cmCopy ((U8 *)&cfg->t.cfg.s.spAsso.rule, 
                 (U8 *)&assoCb->rule, sizeof (SpRule));
         assoCb->nmbActns = cfg->t.cfg.s.spAsso.nmbActns;
         assoCb->nmbEntries = 0;
         /* sp046.302 - modification - initializing the dataFix, dataAsc
          * and dataDes pointers. these are moved from spActnCb to
          * spAssoCb
          */
         assoCb->dataFix = NULLP;
         assoCb->dataAsc = NULLP;
         assoCb->dataDes = NULLP;
         for (i = 0; i < assoCb->nmbActns; i++)
         {
            cmCopy ((U8 *)&cfg->t.cfg.s.spAsso.actn[i], 
                    (U8 *)&assoCb->actnCb[i].actn, sizeof (SpActn));
            /* sp045.302 - addition - initialising the DB pointer for 
             * fix, ascending and decending database pointer.
             */
            /* sp046.302 - deletion - dataFix, dataAsc and dataDes deleted
             * from spActnCb 
             */
            assoCb->actnCb[i].data = NULLP;
         }
         if (cfg->t.cfg.s.spAsso.fSetType == SP_T_FUNC)
            assoCb->funcs = &cmFuncs;
         else 
            assoCb->funcs = &ptFuncs;

         /* 
          * Call the Init function which will initalize action related fields
          * and allocate memory for the database.
          * The Init function will be called for each and every association.
          */
         ret = assoCb->funcs->gttInit (assoCb);
         if (ret != ROK)
         {
            SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) assoCb,
                     (Size) sizeof(SpAssoCb));
            /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
             * multiple negative cfm to LM. 
             * we are checking the return status in the parent function.
             */
            RETVALUE(RFAILED);
         }

         /* Success */
         /* sp045.302 - modification - nmbActns, nmbAsso and assoList 
          * moved to netwrok Cb
          */
         *(nwCb->assoList + (PTR) nwCb->nmbAsso) = assoCb;
         nwCb->nmbAsso++;
         nwCb->nmbActns += assoCb->nmbActns;
         RETVALUE(ROK);
      } /* else - new assoc config request */
   } /* else - exact match of rule not found */
#else /* LSPV2_4 */ 
   /* sp001.302 - addition - check for exact match or overlapping match of
    * the rule. If exact match found, return ok, if overlapping match is
    * found, return failure else its a new association config request
    */
   /* sp045.302 - addition - pass network CB */
   ret = spAssoForRule(&cfg->t.cfg.s.spAsso.rule, &indx, nwCb);
   if (ret == ROK)
   {
     /* an exact match of the rule is found in already configured
      * associations list. Case of repeated config request, return OK
      */
     RETVALUE(ROK);
   }
   else
   {
      if (ret == ROKDUP)
      {
         /* overlapping match was found, log error and return failure */
         SPLOGERROR(ERRCLS_INT_PAR, ESP198, (ErrVal) ret, "Overlapping rule");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                     LSP_REASON_OVERLAPPING_RULE);
         RETVALUE(RFAILED);
      }
      else
      {
         /* configuration request for new association */

         /* check if the configuration within limits */
         if (spCb.nmbAsso == spCb.spCfg.nmbAsso) 
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP199, (ErrVal) spCb.nmbAsso,
                       "Max number of associations already configured");
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LSP_REASON_MAXASSO_CFG);
            RETVALUE(RFAILED);
         }
         if (cfg->t.cfg.s.spAsso.nmbActns > SP_MAX_ACTNS)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP200, (ErrVal) spCb.nmbAsso,
                       "Change the SP_MAX_ACTNS if you want so many actions.");
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LSP_REASON_MAXACTNS_CFG);
            RETVALUE(RFAILED);
         }
         if ((spCb.nmbActns + cfg->t.cfg.s.spAsso.nmbActns) >
              spCb.spCfg.nmbActns)
         {
            SPLOGERROR(ERRCLS_INT_PAR, ESP201, (ErrVal) spCb.nmbAsso,
                       "Max number of actions already configured");
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LSP_REASON_MAXACTNS_CFG);
            RETVALUE(RFAILED);
         }

         /* Allocate memory for a Assocation Control Block */
         ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool, (Data **) &assoCb,
                        (Size) sizeof(SpAssoCb));
         if (ret != ROK)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP202, (ErrVal) ret, "SGetSBuf failed");
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LCM_REASON_MEM_NOAVAIL);
            RETVALUE(RFAILED);
         }
         cmZero ((U8 *)assoCb, sizeof(SpAssoCb));

         /* Put the assoCb in the association list */
         *(spCb.assoList + (PTR)spCb.nmbAsso) = assoCb;

         /* Initialize assoCb */
         assoCb->region = spCb.spInit.region;
         assoCb->pool = spCb.spInit.pool;
         cmCopy ((U8 *)&cfg->t.cfg.s.spAsso.rule, 
                 (U8 *)&assoCb->rule, sizeof (SpRule));
         assoCb->nmbActns = cfg->t.cfg.s.spAsso.nmbActns;
         assoCb->nmbEntries = 0;
         /* sp046.302 - modification - initializing the dataFix, dataAsc
          * and dataDes pointers. these are moved from spActnCb to
          * spAssoCb
          */
         assoCb->dataFix = NULLP;
         assoCb->dataAsc = NULLP;
         assoCb->dataDes = NULLP;
         for (i = 0; i < assoCb->nmbActns; i++)
         {
            cmCopy ((U8 *)&cfg->t.cfg.s.spAsso.actn[i], 
                    (U8 *)&assoCb->actnCb[i].actn, sizeof (SpActn));
            assoCb->actnCb[i].data = NULLP;
            /* sp046.302 - deletion - nmbEntries deleted from SpActnCb */
         }
         if (cfg->t.cfg.s.spAsso.fSetType == SP_T_FUNC)
            assoCb->funcs = &cmFuncs;
         else 
            assoCb->funcs = &ptFuncs;

         /* 
          * Call the Init function which will initalize action related fields
          * and allocate memory for the database.
          * The Init function will be called for each and every association.
          */
         ret = assoCb->funcs->gttInit (assoCb);
         if (ret != ROK)
         {
            *(spCb.assoList + (PTR)spCb.nmbAsso) = NULLP;
            SPutSBuf(spCb.spInit.region, spCb.spInit.pool, (Data *) assoCb,
                     (Size) sizeof(SpAssoCb));
            spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                        LSP_REASON_INIT_FAIL);
            RETVALUE(RFAILED);
         }

         /* Success */
         ++spCb.nmbAsso;
         spCb.nmbActns += assoCb->nmbActns;
         RETVALUE(ROK);
      } /* else - new assoc config request */
   } /* else - exact match of rule not found */
#endif /* LSPV2_4 */ 
} /* spAssoCfgReq */


/*
 *
 *       Fun:   spAddrMapCfgReq
 *
 *       Desc:  Address Map Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spAddrMapCfgReq
(
Pst *pst,
SpMngmt *cfg
)
#else
PUBLIC S16 spAddrMapCfgReq(pst, cfg)
Pst *pst;
SpMngmt *cfg;
#endif
{
   SpAssoCb *assoCb;
   S16 ret;
#ifdef LSPV2_4   
   U8 nwIndx;          /* sp045.302 - addition - index of nwCb in nwList */
   Bool found;         /* sp045.302 - addition - boolean */
#endif /* LSPV2_4 */   
   SpNwCb *nwCb;       /* sp045.302 - addition - network control block */

   TRC2(spAddrMapCfgReq)

/* sp045.302 - addition - the feature GTT per netnowk is availabe under
 * LSPV2_4 interface version flag.
 */
   nwCb = NULLP;
#ifdef LSPV2_4

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* General configuration has to be done */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP203, (ErrVal) 0,
                 "General Configuration to be done");
      /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
       * multiple negative cfm to LM 
       * we are checking the return status in the parent function.
       */
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* sp045.302 - addition - check if network in config req is is configured */
   found = FALSE;
   for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
   {
      nwCb = *(spCb.nwList + (PTR) nwIndx);
      if (nwCb->nwId == cfg->t.cfg.s.spAddrMap.nwId)
      {
         found = TRUE;
         break;
      }
   }

   if(found == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,  cfg->t.cfg.s.spAddrMap.nwId,
                "spAddrMapCfgReq: network id not configured");
      /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
       * multiple negative cfm to LM 
       * we are checking the return status in the parent function.
       */
      RETVALUE(RFAILED);
   }

   /* Find the matching association. */
   /* sp045.302 - modification - pass network CB instead of switch */
   assoCb = spMatchAssoCb(&cfg->t.cfg.s.spAddrMap.gt, 
                           cfg->t.cfg.s.spAddrMap.sw, nwCb);
   if (assoCb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP205, (ErrVal) 0,
                 "No matching associations");
      /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
       * multiple negative cfm to LM 
       * we are checking the return status in the parent function.
       */
      RETVALUE(RFAILED);
   }

   /* sp001.302 - addition - verify if address map is already configured */
   ret = spMatchAddrMap(assoCb, &cfg->t.cfg.s.spAddrMap);
   if (ret == ROK)
   {
      /* address map already configured, i.e. its a repeated config
       * request. return OK. Re-configuration of already configured
       * address map is not allowed
       */
      RETVALUE(ROK);
   }
   else
   {
      /* new address map configuration request
       * Check if the number of entries exceed the configured entries
       */
      /* sp045.302 - modification - nmbAddrs moved to netwrok Cb */
      if (nwCb->nmbAddrs == spCb.spCfg.nmbAddrs)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP204, (ErrVal) 0,
                    "Maximum address configuration exceeded.");
         /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
          * multiple negative cfm to LM 
          * we are checking the return status in the parent function.
          */
         RETVALUE(RFAILED);
      }

      /* Call the add function for the association */
      ret = assoCb->funcs->gttAdd(assoCb, &cfg->t.cfg.s.spAddrMap);
      if (ret != ROK)
      {
         /* sp045.302 - deletion - spSendLmCfm deleted from here to avoid
          * multiple negative cfm to LM 
          * we are checking the return status in the parent function.
          */
         RETVALUE(RFAILED);
      }

      /* Success */
      /* sp045.302 - modification - nmbAddrs moved to netwrok Cb */
      nwCb->nmbAddrs++;
      /* sp045.302 - addition - increment the counter. */
      nwCb->numAddrMapOutNwId++;
      RETVALUE(ROK);
   } /* else - new config request */
#else /* LSPV2_4 */
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* General configuration has to be done */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP203, (ErrVal) 0,
                 "General Configuration to be done");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* Find the matching association. */
   assoCb = spMatchAssoCb(&cfg->t.cfg.s.spAddrMap.gt,
                          cfg->t.cfg.s.spAddrMap.sw, nwCb);
   if (assoCb == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP205, (ErrVal) 0,
                 "No matching associations");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_RULE_NOTPRSNT);
      RETVALUE(RFAILED);
   }

   /* sp001.302 - addition - verify if address map is already configured */
   ret = spMatchAddrMap(assoCb, &cfg->t.cfg.s.spAddrMap);
   if (ret == ROK)
   {
      /* address map already configured, i.e. its a repeated config
       * request. return OK. Re-configuration of already configured
       * address map is not allowed
       */
      RETVALUE(ROK);
   }
   else
   {
      /* new address map configuration request
       * Check if the number of entries exceed the configured entries
       */
      if (spCb.nmbAddrs == spCb.spCfg.nmbAddrs)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP204, (ErrVal) 0,
                    "Maximum address configuration exceeded.");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                     LSP_REASON_MAXADDR_CFG);
         RETVALUE(RFAILED);
      }

      /* Call the add function for the association */
      ret = assoCb->funcs->gttAdd(assoCb, &cfg->t.cfg.s.spAddrMap);
      if (ret != ROK)
      {
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, ret);
         RETVALUE(RFAILED);
      }

      /* Success */
      spCb.nmbAddrs++;
      RETVALUE(ROK);
   } /* else - new config request */
#endif /* LSPV2_4 */
} /* spAddrMapCfgReq */


/*
 *
 *       Fun:   spRteCfgReq
 *
 *       Desc:  Route Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spRteCfgReq
(
Pst *pst,          /* pointer to pst struct */
SpMngmt *cfg       /* pointer to GenCfg strut */
)
#else
PUBLIC S16 spRteCfgReq(pst, cfg)
Pst *pst;          /* pointer to pst struct */
SpMngmt *cfg;      /* pointer to GenCfg strut */
#endif
{
   S16 ret;             /* return value */
   SpRteCb *rteCb;      /* pointer to rteCb */
   SpRteKey rKey;       /* route key */
   SpNSapCb *nSapCb;    /* pointer to NSapCb */
   Bool match;          /* flag */
   Swtch swtch;         /* switch */
   U16 i;               /* counter variable */
   U16 j;               /* counter variable */
   U16 k;               /* counter variable */
   U16 l;               /* counter variable */

   TRC2(spRteCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP206, (ErrVal) ERRZERO, 
                 "general configuration needs to be done first");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cfg->t.cfg.s.spRte.nmbSsns > MAXNUMSSN)
   {
      SPLOGERROR(ERRCLS_INT_PAR,ESP207,(ErrVal)cfg->t.cfg.s.spRte.nmbSsns,
                  "Configured number of subsystems exceeds maximum");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_INVALID_PAR_VAL);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   /* check the nSapId */
   if (cfg->t.cfg.s.spRte.nSapId >= spCb.spCfg.nmbNSaps)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP208, (ErrVal) cfg->t.cfg.s.spRte.nSapId,
                 "NSap index out of range");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LCM_REASON_INVALID_SAP);
      RETVALUE(RFAILED);
   }
   if ((nSapCb = *(spCb.nSapList + cfg->t.cfg.s.spRte.nSapId)) == NULLP)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP209, (ErrVal) 0,
                 "network sap not configured");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, LSP_REASON_NSAP_NOTCFG);
      RETVALUE(RFAILED);
   }


   /* check if route already exists */
   rKey.k1.dpc = cfg->t.cfg.s.spRte.dpc;
   rKey.k1.nwId = nSapCb->nwData->nwId;

   spFindRte(&spCb.rteCp, &rteCb, &rKey, (U16)0);
   if (rteCb != (SpRteCb *)NULLP)
   {
      /* use the same key - DPC has not changed */
      /*
       * We allow reconfiguration of the subsystem list. This
       * means that we allow only addition of more entries in
       * the list. 
       */
            
      /* Add the new subsystems */
      for (i = 0; i < cfg->t.cfg.s.spRte.nmbSsns; i++)
      {
         for (j = 0; j < rteCb->nmbSsns; j++)
         {
            if (rteCb->ssnList[j].ssn == cfg->t.cfg.s.spRte.ssnList[i].ssn)
               break;
         }
         if (j == rteCb->nmbSsns)
         {
            /* check if maximum ssn already configured */
            if (rteCb->nmbSsns == MAXNUMSSN)
            {
               SPLOGERROR(ERRCLS_INT_PAR, ESP211, (ErrVal) rteCb->nmbSsns,
                          "maximum number of subsystems already configured");
               spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                           LSP_REASON_MAXSSN_CFG);
               RETVALUE(RFAILED);
            }

            /* Add the subsystem */
            rteCb->ssnList[j].ssn = cfg->t.cfg.s.spRte.ssnList[i].ssn;
            /*modified by wanglijun, we always think local ssn is SS_ACC*/
            if(rteCb->dpc == nSapCb->nwData->selfPc)
            {
               rteCb->ssnList[j].status = SS_ACC;
            }
            else
            {
               rteCb->ssnList[j].status = cfg->t.cfg.s.spRte.ssnList[i].status;
            }
            rteCb->ssnList[j].replicatedMode = DOMINANT;
            rteCb->ssnList[j].nmbBpc = 
                                     cfg->t.cfg.s.spRte.ssnList[i].nmbBpc;
            for (l=0; l < rteCb->ssnList[j].nmbBpc; l++)
            {
               rteCb->ssnList[j].bpcList[l].bpc = 
                               cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].bpc;
               rteCb->ssnList[j].bpcList[l].prior = 
                                 cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].prior;
            }

            /* sort the backup point code as per their priority rel 3.2 */
            spSortBpc(rteCb->ssnList[j].bpcList, rteCb->ssnList[j].nmbBpc);
            rteCb->ssnList[j].nmbConPc = cfg->t.cfg.s.spRte.ssnList[i].nmbConPc;

            /* sp003.31 - Changed the below for statement to *
             * increment k instead of j                      */
            for (k = 0; k < rteCb->ssnList[i].nmbConPc; k++)
               rteCb->ssnList[j].conPc[k] = 
                                         cfg->t.cfg.s.spRte.ssnList[i].conPc[k];
            rteCb->ssnList[j].rCb = rteCb;
            rteCb->ssnList[j].ssFlgs = 0;
            rteCb->ssnList[j].tmr.val = 0;
            cmInitTimers(rteCb->ssnList[j].timers, MAXSSNTMR);
#ifndef ZP
            /* If PSF-SCCP is being used, the timers will be
               started when the crit rset is made active */
            /*
             * if subsystem is not accessible but pointcode is 
             * accessible then start SST timers 
             */
            if ((!(rteCb->ssnList[j].status & SS_ACC)) &&
                (rteCb->status & SP_ONLINE))
            {
               rteCb->ssnList[j].ssFlgs |= TMR_SST;
               rteCb->ssnList[j].tmr.enb = 
                                      rteCb->nSap->nwData->defSstTmr.enb;
               rteCb->ssnList[j].tmr.val = 
                                      rteCb->nSap->nwData->defSstTmr.val;
               spStartSsnCbTmr(&rteCb->ssnList[j], TMR_SST);
            }
#else /* ZP */
/* sp014.302 - start SST timer if resource set already active */
#ifdef ZP_DFTHA
            if ((zpCb.init.cfgDone == TRUE)
                && (ZP_IS_VALID_RSET(zpCb.critRsetId))
                && (zpCb.rsetCbList[zpCb.critRsetId]->state ==
                    CMPFTHA_STATE_ACTIVE))
#else /* ZP_DFTHA */
            if ((zpCb.init.cfgDone == TRUE)
                && (zpCb.rsetCbList[CMFTHA_RES_RSETID]->state ==
                    CMPFTHA_STATE_ACTIVE))
#endif /* ZP_DFTHA */
               if ((!(rteCb->ssnList[j].status & SS_ACC)) &&
                   (rteCb->status & SP_ONLINE))
               {
                  rteCb->ssnList[j].ssFlgs |= TMR_SST;
                  rteCb->ssnList[j].tmr.enb = 
                                         rteCb->nSap->nwData->defSstTmr.enb;
                  rteCb->ssnList[j].tmr.val = 
                                         rteCb->nSap->nwData->defSstTmr.val;
                  spStartSsnCbTmr(&rteCb->ssnList[j], TMR_SST);
               }
#endif
            /* sp008.302 - if route is offline, mark ssn status as inacc */
            /* sp025.302 - modification - change SP_INACC to SS_INACC */
            if (!(rteCb->status & SP_ONLINE))
               rteCb->ssnList[j].status &= SS_INACC;
            rteCb->nmbSsns++;
         }
         else
         {
            /* reconfigure the ssn parameters */
            /*modified by wanglijun, we always think local ssn is SS_ACC*/
            if(rteCb->dpc == nSapCb->nwData->selfPc)
            {
               rteCb->ssnList[j].status = SS_ACC;
            }
            else
            {
               rteCb->ssnList[j].status = cfg->t.cfg.s.spRte.ssnList[i].status;
            }

            rteCb->ssnList[j].replicatedMode  = DOMINANT;

            rteCb->ssnList[j].nmbBpc = cfg->t.cfg.s.spRte.ssnList[i].nmbBpc;
            for (l=0; l < rteCb->ssnList[i].nmbBpc; l++)
            {
               rteCb->ssnList[j].bpcList[l].bpc = 
                             cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].bpc;
               rteCb->ssnList[j].bpcList[l].prior = 
                                 cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].prior;
            }
     
            /*  sort the backup point code as per their priority  */
            spSortBpc(rteCb->ssnList[j].bpcList, rteCb->ssnList[j].nmbBpc);
            rteCb->ssnList[j].nmbConPc = 
                                        cfg->t.cfg.s.spRte.ssnList[i].nmbConPc;
     
            /* sp004.301 - Changed the below for statement 
             * to increment k instead of j
             */
            for (k = 0; k < rteCb->ssnList[i].nmbConPc; k++)
               rteCb->ssnList[j].conPc[k] = 
                                        cfg->t.cfg.s.spRte.ssnList[i].conPc[k];

/* sp026.302 - addition - when reconfiguring existing ssn,
 * if ssn status is not accessible but route is accessible
 * then start sst timer.
 */
#ifndef ZP
            /* If PSF-SCCP is being used, the timers will be
               started when the crit rset is made active */
            /*
             * if subsystem is not accessible but pointcode is 
             * accessible then start SST timers 
             */
            if ((!(rteCb->ssnList[j].status & SS_ACC)) &&
                (rteCb->status & SP_ONLINE))
            {
               /* first stop timer if its already running */
               if (rteCb->ssnList[j].ssFlgs & TMR_SST)
                  spRmvSsnCbTq(&rteCb->ssnList[j], TMR_SST);

               /* restart sst timer */
               rteCb->ssnList[j].ssFlgs |= TMR_SST;
               rteCb->ssnList[j].tmr.enb = 
                                      rteCb->nSap->nwData->defSstTmr.enb;
               rteCb->ssnList[j].tmr.val = 
                                      rteCb->nSap->nwData->defSstTmr.val;
               spStartSsnCbTmr(&rteCb->ssnList[j], TMR_SST);
            }
#else /* ZP */
/* start SST timer if resource set already active */
#ifdef ZP_DFTHA
            if ((zpCb.init.cfgDone == TRUE)
                && (ZP_IS_VALID_RSET(zpCb.critRsetId))
                && (zpCb.rsetCbList[zpCb.critRsetId]->state ==
                    CMPFTHA_STATE_ACTIVE))
#else /* ZP_DFTHA */
            if ((zpCb.init.cfgDone == TRUE)
                && (zpCb.rsetCbList[CMFTHA_RES_RSETID]->state ==
                    CMPFTHA_STATE_ACTIVE))
#endif /* ZP_DFTHA */
               if ((!(rteCb->ssnList[j].status & SS_ACC)) &&
                   (rteCb->status & SP_ONLINE))
               {
                  /* first stop timer if its already running */
                  if (rteCb->ssnList[j].ssFlgs & TMR_SST)
                     spRmvSsnCbTq(&rteCb->ssnList[j], TMR_SST);

                  /* restart sst timer */
                  rteCb->ssnList[j].ssFlgs |= TMR_SST;
                  rteCb->ssnList[j].tmr.enb = 
                                         rteCb->nSap->nwData->defSstTmr.enb;
                  rteCb->ssnList[j].tmr.val = 
                                         rteCb->nSap->nwData->defSstTmr.val;
                  spStartSsnCbTmr(&rteCb->ssnList[j], TMR_SST);
               }
#endif
            /* If route is offline, mark ssn status as inacc. In reconfig,
             * route status is not reconfigured. So on offline route timer
             * must be running and once route comes up, sst for ssn will be
             * started.
             */
            if (!(rteCb->status & SP_ONLINE))
               rteCb->ssnList[j].status &= SS_INACC;
         }
      }

      rteCb->replicatedMode  = DOMINANT;
      rteCb->nmbBpc = cfg->t.cfg.s.spRte.nmbBpc;
      for (l=0; l < rteCb->nmbBpc; l++)
      {
         rteCb->bpcList[l].bpc = cfg->t.cfg.s.spRte.bpcList[l].bpc;
         rteCb->bpcList[l].prior = cfg->t.cfg.s.spRte.bpcList[l].prior;
      }
      /*  sort the backup point code as per their priority rel 3.2 */
      spSortBpc(rteCb->bpcList, rteCb->nmbBpc);
      rteCb->flag = cfg->t.cfg.s.spRte.flag;
   }
   else /* route does not exist */
   {
      /* simplifying the dereference */
      swtch = cfg->t.cfg.s.spRte.swtch;

#if (ERRCLASS & ERRCLS_INT_PAR)
      if (spCb.nmbRtes == spCb.spCfg.nmbRtes)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP212, (ErrVal) spCb.nmbRtes,
                    "maximum number of routes already configured");
         /* sp001.302 - modification - reason of failure is changed to maximum
          * routes already configured
          */
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LSP_REASON_MAXROUTE_CFG);
         RETVALUE(RFAILED);
      }
#endif /* ERRCLASS */

     /* initialize match to TRUE */
     match = TRUE;

     /* check if there is mismatch in the variant  present in
      * the network CB and that of swtch in Rte cfg. In case of 
      * error generate alarm to layer manager. 
      */
      switch (nSapCb->nwData->variant)
      {
         case LSP_SW_ANS:
            /* sp040.302 - modification - gsm route is also valid in ansi nw */
            if (!((swtch == LSP_SW_ANS88) || (swtch == LSP_SW_ANS92) ||
                (swtch == LSP_SW_ANS96) || (swtch == LSP_SW_BELL05) ||
                (swtch == LSP_SW_GSM0806)))
               match = FALSE;
            break;
         case LSP_SW_ITU:
            /* sp040.302 - modification - gsm route is also valid in itu nw */
            if (!((swtch == LSP_SW_ITU88) || (swtch == LSP_SW_ITU92) ||
                (swtch == LSP_SW_ITU96) || (swtch == LSP_SW_GSM0806)))
               match = FALSE;
            break;
         case LSP_SW_CHINA:
            if (swtch != LSP_SW_CHINA)
               match = FALSE;
            break;
      } /* swtch (...variant) */
      
      if (match == FALSE)
      {
         SPLOGERROR(ERRCLS_INT_PAR, ESP213, (ErrVal) swtch,
                    "mismatch in nwCb->variant and swtch ");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK,
                     LCM_REASON_INVALID_PAR_VAL);
         RETVALUE(RFAILED);
      }

      /* added new route */
      ret = SGetSBuf(spCb.spInit.region, spCb.spInit.pool,
                     (Data **) &rteCb, (Size) sizeof(SpRteCb));
      if (ret != ROK)
      {
         SPLOGERROR(ERRCLS_ADD_RES, ESP214, (ErrVal) ret, "SGetSBuf failed");
         spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                     LCM_REASON_MEM_NOAVAIL);
         RETVALUE(RFAILED);
      }
      cmZero ((U8 *) rteCb, sizeof(SpRteCb));
            
      /* Fill the structure */
      rteCb->key.k1.dpc = rKey.k1.dpc;
      rteCb->key.k1.nwId = rKey.k1.nwId;

      rteCb->swtch = cfg->t.cfg.s.spRte.swtch;
      rteCb->dpc = cfg->t.cfg.s.spRte.dpc;
      /*modified by wanglijun, we always think local spc is SP_ONLINE*/
      if(rteCb->dpc == nSapCb->nwData->selfPc)
      {
         rteCb->status = SP_ONLINE;
      }
      else
      {
         rteCb->status = cfg->t.cfg.s.spRte.status;
      }

      rteCb->flag = cfg->t.cfg.s.spRte.flag;
      rteCb->cLvl = SN_PRI0; /* initial congestion is 0 */

      rteCb->replicatedMode  = DOMINANT;
      rteCb->nmbBpc = cfg->t.cfg.s.spRte.nmbBpc;
      for (l=0; l < rteCb->nmbBpc; l++)
      {
         rteCb->bpcList[l].bpc = cfg->t.cfg.s.spRte.bpcList[l].bpc;
         rteCb->bpcList[l].prior = cfg->t.cfg.s.spRte.bpcList[l].prior;
      }

      /*  sort the backup point code as per their priority rel 3.2 */
      spSortBpc(rteCb->bpcList, rteCb->nmbBpc);
      rteCb->nmbSsns = cfg->t.cfg.s.spRte.nmbSsns;

      /* configure each subsystem on route */
      for (i = 0; i < rteCb->nmbSsns; i++)
      {
         rteCb->ssnList[i].ssn = cfg->t.cfg.s.spRte.ssnList[i].ssn;
         /*modified by wanglijun, we always think local ssn is SS_ACC*/
         if(rteCb->dpc == nSapCb->nwData->selfPc)
         {
            rteCb->ssnList[i].status = SS_ACC;
         }
         else
         {
            rteCb->ssnList[i].status = cfg->t.cfg.s.spRte.ssnList[i].status;
         }

         rteCb->ssnList[i].replicatedMode  = DOMINANT;
         rteCb->ssnList[i].nmbBpc = cfg->t.cfg.s.spRte.ssnList[i].nmbBpc;
         for (l = 0; l < rteCb->ssnList[i].nmbBpc; l++)
         {
            rteCb->ssnList[i].bpcList[l].bpc = 
                                 cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].bpc;
            rteCb->ssnList[i].bpcList[l].prior = 
                              cfg->t.cfg.s.spRte.ssnList[i].bpcList[l].prior;
         }

         /*  sort the backup point code as per their priority rel 3.2 */
         spSortBpc(rteCb->ssnList[i].bpcList, rteCb->ssnList[i].nmbBpc);
         rteCb->ssnList[i].ssFlgs = 0;
         rteCb->ssnList[i].rCb = rteCb;
         rteCb->ssnList[i].tmr.val = 0;
         cmInitTimers(rteCb->ssnList[i].timers, MAXSSNTMR);
         rteCb->ssnList[i].nmbConPc =
                       cfg->t.cfg.s.spRte.ssnList[i].nmbConPc;
         for (j = 0; j < rteCb->ssnList[i].nmbConPc; j++)
            rteCb->ssnList[i].conPc[j] = cfg->t.cfg.s.spRte.ssnList[i].conPc[j];
#ifndef ZP
         /* if subsystem is not accessible but point code is accessible
          * then start SST timers for subsystem. If used with PSF, timer
          * will be started when critical resource set is made active
          */
         if ((!(rteCb->ssnList[i].status & SS_ACC)) &&
             (rteCb->status & SP_ONLINE))
         {
            rteCb->ssnList[i].ssFlgs |= TMR_SST;
            rteCb->ssnList[i].tmr.enb = nSapCb->nwData->defSstTmr.enb;
            rteCb->ssnList[i].tmr.val = nSapCb->nwData->defSstTmr.val;
            spStartSsnCbTmr(&rteCb->ssnList[i], TMR_SST);
         }
#else /* ZP */
/* sp014.302 - start SST timer if resource set already active */
#ifdef ZP_DFTHA
         if ((zpCb.init.cfgDone == TRUE)
             && (ZP_IS_VALID_RSET(zpCb.critRsetId))
             && (zpCb.rsetCbList[zpCb.critRsetId]->state ==
                 CMPFTHA_STATE_ACTIVE))
#else /* ZP_DFTHA */
         if ((zpCb.init.cfgDone == TRUE)
             && (zpCb.rsetCbList[CMFTHA_RES_RSETID]->state ==
                 CMPFTHA_STATE_ACTIVE))
#endif /* ZP_DFTHA */
            if ((!(rteCb->ssnList[i].status & SS_ACC)) &&
                (rteCb->status & SP_ONLINE))
            {
               rteCb->ssnList[i].ssFlgs |= TMR_SST;
               rteCb->ssnList[i].tmr.enb = nSapCb->nwData->defSstTmr.enb;
               rteCb->ssnList[i].tmr.val = nSapCb->nwData->defSstTmr.val;
               spStartSsnCbTmr(&rteCb->ssnList[i], TMR_SST);
            }
#endif /* ZP */

         /* sp008.302 - if route is offline, mark ssn status as inacc */
         /* sp025.302 - modification - change SP_INACC to SS_INACC */
         if (!(rteCb->status & SP_ONLINE))
            rteCb->ssnList[i].status &= SS_INACC;
      } /* for (i = 0; i < rteCb->nmbSsns; i++) */

#ifdef SNT2
      cmInitTimers(rteCb->timers, MAXRTETMR);
#endif /* SNT2 */
      rteCb->sls = 0;

      /* sp020.302 - addition - configure slsMask if provided. In case of ITU
       * slsMask can not be configured and will be 4 bits only.
       */
      rteCb->slsMask = SLSMASK_CCITT;

#ifndef ZP
      /* If used with PSF, we start the timer when the crit rset
       * is made active
       */
      if (!(rteCb->status & SP_ONLINE) || (rteCb->status & SP_CONG))
      {
#ifdef SNT2
          if (nSapCb->status & SP_BND)
          {
             /* sp025.302 - addition - initialize tmr fileds to start tmr */
             rteCb->rteStsFlag |= TMR_STA;
             rteCb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
             rteCb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
             spStartRteCbTmr(rteCb, TMR_STA);
          }
#endif /* SNT2 */
      }
#else /* ZP */
/* sp014.302 - start STA timer if resource set already active */
#ifdef ZP_DFTHA
      if ((zpCb.init.cfgDone == TRUE)
          && (ZP_IS_VALID_RSET(zpCb.critRsetId))
          && (zpCb.rsetCbList[zpCb.critRsetId]->state ==
              CMPFTHA_STATE_ACTIVE))
#else /* ZP_DFTHA */
      if ((zpCb.init.cfgDone == TRUE)
          && (zpCb.rsetCbList[CMFTHA_RES_RSETID]->state ==
              CMPFTHA_STATE_ACTIVE))
#endif /* ZP_DFTHA */
         if (!(rteCb->status & SP_ONLINE) || (rteCb->status & SP_CONG))
         {
#ifdef SNT2
             if (nSapCb->status & SP_BND)
             {
                /* sp025.302 - addition - initialize tmr fileds to start tmr */
                rteCb->rteStsFlag |= TMR_STA;
                rteCb->tmr.enb = spCb.spCfg.defStatusEnqTmr.enb;
                rteCb->tmr.val = spCb.spCfg.defStatusEnqTmr.val;
                spStartRteCbTmr(rteCb, TMR_STA);
             }
#endif /* SNT2 */
         }
#endif
      rteCb->nSap = nSapCb;

      /* insert into hash list */
      spAddRte(&spCb.rteCp, rteCb);
      spCb.nmbRtes++;
#ifdef ZP
      zpAddMapping (ZP_SP_RTECB, (Void *)rteCb, NULLP);
#endif /* ZP */
   }
   /* if route is configured ONLINE, initialize remote sccp status
    * as available else initialize remote sccp status as unavailable.
    */
   if (rteCb->status & SP_ONLINE)
      rteCb->sccpSts = RMT_SCCP_AVAIL;
   else
      rteCb->sccpSts = RMT_SCCP_UNAVAIL;

   RETVALUE(ROK);
} /* spRteCfgReq */





/*
 *
 *       Fun:   spTrfLimCfgReq
 *
 *       Desc:  Traffic Limitation Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spTrfLimCfgReq
(
Pst *pst,     /* pointer to pst struct */
SpMngmt *cfg  /* pointer to GenCfg struct */
)
#else
PUBLIC S16 spTrfLimCfgReq(pst, cfg)
Pst *pst;     /* pointer to pst struct */
SpMngmt *cfg; /* pointer to GenCfg struct */
#endif
{
   TRC2(spTrfLimCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Need general configuration done first */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP219, (ErrVal) 0,
                 "General Configuration to be done");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   cmCopy((U8 *) &cfg->t.cfg.s.spTrfLim, (U8 *) &spCb.spTrfLim,
          sizeof(SpTrfLimCfg));  
   spCb.spTrfLimCfgDone = TRUE;
   RETVALUE(ROK);
} /* spTrfLimCfgReq */


/*
 *
 *       Fun:   spMsgImpCfgReq
 *
 *       Desc:  Msg Importance Configuration Request from Layer Manager
 *
 *       Ret:   ROK
 *              RFAILED
 *            
 *       Notes: None
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spMsgImpCfgReq
(
Pst *pst,          /* pointer to pst struct */
SpMngmt *cfg       /* pointer to GenCfg struct */
)
#else
PUBLIC S16 spMsgImpCfgReq(pst, cfg)
Pst *pst;          /* pointer to pst struct */
SpMngmt *cfg;      /* pointer to GenCfg struct */
#endif
{

   TRC2(spMsgImpCfgReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* Need general configuration done first */
   if (spCb.spInit.cfgDone == FALSE)
   {
      SPLOGERROR(ERRCLS_INT_PAR, ESP220, (ErrVal) 0,
                 "General Configuration to be done");
      spSendLmCfm(pst, TCFG, &cfg->hdr, LCM_PRIM_NOK, 
                  LCM_REASON_GENCFG_NOT_DONE);
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
         
   cmCopy((U8 *) &cfg->t.cfg.s.spMsgImp, (U8 *) &spCb.spMsgImp,
          sizeof(SpMsgImpCfg));
   RETVALUE(ROK);
} /* spMsgImpCfgReq */


#ifdef SPTV2
#endif /* SPTV2 */

#ifdef SPTV2
#endif /* SPTV2 */


/*
 *
 *       Fun:   spFindRestriction
 *
 *       Desc: This function determines whether messge should be sent on a 
 *             given route or to be discarded as part of traffic limitation
 *             procedure. 
 *
 *       Ret: SP_OK      - Message can be sent on outgoing route.
 *            SP_DISCARD - Message should be discarded from being sent on
 *                         outgoing route.
 *       
 *       Notes: 1) if message importance > RL, message forwarded.
 *              2) if message importance < RL, message discarded.
 *              3) if message importance == RL, message discarded
 *                 proportionately. Where,
 *                    % traffic discarded = (RSL * 100) / MaxRstSubLvl.
 *
 *              This function also updates statistics counter for message
 *              routing failures due to network congestion (rfNetCong)
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC S16 spFindRestriction
(
SpRteCb *rCb,              /* Route control block */
U8 imp                     /* importance */
)
#else
PUBLIC S16 spFindRestriction(rCb, imp)
SpRteCb *rCb;              /* Route control block */
U8 imp;                    /* importance */
#endif
{
   S16 ret;                /* return value */

   TRC2(spFindRestriction);

   /* sp044.302 - addition - Initialization of Local Variables */   
   ret = SP_OK;   

   /* Traffic limitation mechanism is valid only in ITU96.
    * Hence if route switch is other than itu96, message will
    * not be discarded and so return ok.
    */
   if (rCb->swtch != LSP_SW_ITU96)
      RETVALUE(SP_OK);

   /* if message importance is greater than restriction level(RL)
    * message will be forwarded
    */
   if (imp > rCb->spRestrictComp.rl)
      RETVALUE(SP_OK);
   else
   {
      /* if message importance is less than restriction level(RL)
       * message will be discarded
       */
      if (imp < rCb->spRestrictComp.rl)
      {
         /* update statistics for message routing failure due to
          * traffic limitation mechanism and return discard
          */
         spCb.sts.rfNetCong++;
         RETVALUE(SP_DISCARD);
      }
      else
      {
         /* if message importance is equal to restriction level(RL)
          * messages will be discarded proportionately based on 
          * restriction sub-level(RSL)
          */
         if (imp == rCb->spRestrictComp.rl)
         {
            if (rCb->window >= rCb->spRestrictComp.rsl)
               ret = SP_OK;
            else
            {
               /* discard message and update statistics for message
                * routing failure due to traffic limitation mechanism
                */
               spCb.sts.rfNetCong++;
               ret = SP_DISCARD;
            }

            /* increment message window */
            rCb->window++;

            /* if message window has reached to maximum restriction
             * sub-level configured, then  reset window to zero
             */
            if (rCb->window == spCb.spCfg.maxRstSubLvl)
               rCb->window = 0;
         }
      } /* else-if (imp < ...rl) */
   } /* else-if (imp > ...rl) */

   RETVALUE(ret);
} /* spFindRestriction */


/*
 *
 *       Fun:   spTrfCompute
 *
 *       Desc: This function computes traffic limitation data from the
 *             configured traffic limitation database.
 *
 *       Ret: None.
 *       
 *       Notes: None.
 *
 *       File:  cp_bdy2.c
 *
 */
#ifdef ANSI
PUBLIC Void spTrfCompute
(
SpRestrictLocal *rstLocal,  /* input restriction data */
SpRestrictComp *rstComp,    /* computed restriction data */
Dpc aDpc,                   /* dpc for which traffic limitation is computed */
NwId nwId                   /* network id */
)
#else
PUBLIC Void spTrfCompute(rstLocal, rstComp, aDpc, nwId)
SpRestrictLocal *rstLocal;  /* input restriction data */
SpRestrictComp *rstComp;    /* computed restriction data */
Dpc aDpc;                   /* dpc for which traffic limitation is computed */
NwId nwId;                  /* network id */
#endif
{
   S16 rlm;                  /* restriction level (RLM) */
   S16 rslm;                 /* restriction Sub-level (RSLM) */
   S16 cls;                  /* remote sccp congestion level (CLS) */

   TRC2(spTrfCompute);

#ifdef SP_PTTRFCOMP
   /* compute traffic restriction data through customer provided function */
   ptTrfCompute(rstLocal, rstComp, aDpc, nwId);
#else
   /* affected dpc and nwId are not used. These param may be used
    * by customer provided function for computation of traffic
    * limitation data
    */
   UNUSED(aDpc);
   UNUSED(nwId);

   rlm = rstLocal->rlm;
   rslm = rstLocal->rslm;
   cls = rstLocal->cls;

   rstComp->rl = spCb.spTrfLim[rlm][rslm][cls].rl;
   rstComp->rsl = spCb.spTrfLim[rlm][rslm][cls].rsl;
   rstComp->ril = spCb.spTrfLim[rlm][rslm][cls].ril;
#endif /* SP_PTTRFCOMP */

   RETVOID;
} /* spTrfCompute */

#ifdef SP_GNP
/* sp045.302 - addition - pass ptr to network Cb */

/*
 *
 * Fun : spCgAddrTreatment
 *
 * Desc : Calling party address treatment to cater Generic number Plan
 *        requirements . When a message is leaving national network and is
 *        entering into the international n/w and if Calling party address
 *        contains GNP then point code of international gateway must be 
 *        inserted in the cgAddr.
 *
 * Ret:  SP_OK
 *       SP_ERROR
 *
 * Notes: None
 *
 * File: cp_bdy2.c
 *
 */
#ifdef ANSI 
PRIVATE S16 spCgAddrTreatment
(
SpAddr *inAddr,                  /* Short Address */
U8 inSsf,                        /* subservice field of incoming network */
U8 outSsf,                       /* subservice field of outgoing network */
SpNwCb *nwCb,                    /* sp045.302 - addition - ptr to netwok Cb */
SpNwCb **outNwCb                  /* sp045.302 - addition - ptr to netwok Cb */
)
#else
PRIVATE S16 spCgAddrTreatment(inAddr, inSsf, outSsf, nwCb, outNwCb)
SpAddr *inAddr;                  /* Short Address */
U8 inSsf;                        /* subservice field of incoming network */
U8 outSsf;                       /* subservice field of outgoing network */
SpNwCb *nwCb;                    /* sp045.302 - addition - ptr to netwok Cb */
SpNwCb **outNwCb;                    /* sp045.302 - addition - ptr to netwok Cb */
#endif
{
   U8 mode;                      /* mode of oper. of SCCP entity */
   U8 numEntity;                 /* num. of SCCP entity towards that dest. */ 
   U8 nextEntity;                /* index in array of outgoing sccp entity */
   Bool noCplng;                 /* flag to indicate whether cplng is there */
   SpAddr outAddr[MAXENTITIES];  /* array of outgoing sccp entity */
   SpAssoCb *assoCb;             /* association control block */
   S16 ret;                      /* return value */

   TRC2(spCgAddrTreatment);

   if (inAddr->gt.format == GTFRMT_4)
   {
      if ((inAddr->gt.gt.f4.numPlan == NP_GENERIC) &&
          (inAddr->gt.gt.f4.natAddr == NA_NATSIGNUM))
      {
         if ((inSsf == SSF_NAT) && (outSsf == SSF_INTL))
         {
            /* find the matching control block */
            /* sp045.302 - addition - pass network CB instead of switch */
            assoCb = spMatchAssoCb (&inAddr->gt, inAddr->sw, nwCb);
            if (assoCb == NULLP)
               RETVALUE (SP_ERROR);

            /* do GT translation */
            /* sp045.302 - modification - replacing selfPc with nwCb */
            ret = assoCb->funcs->gttTrans(assoCb, inAddr, PCLASS0, &mode,
                                          &numEntity, &nextEntity, &outAddr[0],
                                          &noCplng, nwCb, outNwCb);
            if (ret != SP_OK)
               RETVALUE(SP_ERROR);
            else
               cmCopySpAddr(&outAddr[0], inAddr);
         } /* if ((inSsf == SSF_NAT) && (outSsf == SSF_INTL)) */
      } /* if ((...numPlan == NP_GENERIC) && (...natAddr == NA_NATSIGNUM)) */
   } /* if (inAddr->gt.format == GTFRMT_4) */
   RETVALUE(SP_OK);
} /* spCgAddrTreatment */
#endif /* SP_GNP */

#ifdef SP_RUG

/*
 *
 * Fun : spRetroCfgReq
 *
 * Desc : Function to retrofit general configuration paramaters
 *
 * Ret:  None.
 *
 * Notes: None
 *
 * File: cp_bdy2.c
 *
 */
#ifdef ANSI 
PUBLIC Void spRetroCfgReq
(
Elmnt elmnt,                     /* element id */
CmIntfVer intfVer,               /* received interface version number */
PTR buf                          /* pointer to retrofit or config struct */
)
#else
PUBLIC Void spRetroCfgReq(elmnt, intfVer, buf)
Elmnt elmnt;                     /* element id */
CmIntfVer intfVer;               /* received interface version number */
PTR buf;                         /* pointer to retrofit or config struct */
#endif
{
   TRC2(spRetroCfgReq)
   
   /* currently, received interface version is not being used */
   UNUSED(intfVer);

   switch (elmnt)
   {
      case STGEN:
      {
         SpRetroGenCfg *spRetroGenCfg;

         spRetroGenCfg = (SpRetroGenCfg *) buf;

         /* copy general config param from retrofit buffer into spCb */
         cmCopy((U8 *)spRetroGenCfg, (U8 *) &spCb.spRetroGenCfg,
                sizeof(SpRetroGenCfg));
         break;
      }

      case STNW:
      {
         SpNwCfg *spNwCfg;

         spNwCfg = (SpNwCfg *) buf;

         /* copy timers config values from retrofit buffer into network
          * config struct
          */
         spNwCfg->defSstTmr.enb = spCb.spRetroGenCfg.defSstTmr.enb;
         spNwCfg->defSstTmr.val = spCb.spRetroGenCfg.defSstTmr.val;
         spNwCfg->defIgnTmr.enb = spCb.spRetroGenCfg.defIgnTmr.enb;
         spNwCfg->defIgnTmr.val = spCb.spRetroGenCfg.defIgnTmr.val;
         spNwCfg->defCrdTmr.enb = spCb.spRetroGenCfg.defCrdTmr.enb;
         spNwCfg->defCrdTmr.val = spCb.spRetroGenCfg.defCrdTmr.val;
         spNwCfg->defAsmbTmr.enb = spCb.spRetroGenCfg.defAsmbTmr.enb;
         spNwCfg->defAsmbTmr.val = spCb.spRetroGenCfg.defAsmbTmr.val;
         spNwCfg->defFrzTmr.enb = spCb.spRetroGenCfg.defFrzTmr.enb;
         spNwCfg->defFrzTmr.val = spCb.spRetroGenCfg.defFrzTmr.val;
         spNwCfg->defConTmr.enb = spCb.spRetroGenCfg.defConTmr.enb;
         spNwCfg->defConTmr.val = spCb.spRetroGenCfg.defConTmr.val;
         spNwCfg->defIasTmr.enb = spCb.spRetroGenCfg.defIasTmr.enb;
         spNwCfg->defIasTmr.val = spCb.spRetroGenCfg.defIasTmr.val;
         spNwCfg->defIarTmr.enb = spCb.spRetroGenCfg.defIarTmr.enb;
         spNwCfg->defIarTmr.val = spCb.spRetroGenCfg.defIarTmr.val;
         spNwCfg->defRelTmr.enb = spCb.spRetroGenCfg.defRelTmr.enb;
         spNwCfg->defRelTmr.val = spCb.spRetroGenCfg.defRelTmr.val;
         spNwCfg->defRepRelTmr.enb = spCb.spRetroGenCfg.defRepRelTmr.enb;
         spNwCfg->defRepRelTmr.val = spCb.spRetroGenCfg.defRepRelTmr.val;
         spNwCfg->defIntTmr.enb = spCb.spRetroGenCfg.defIntTmr.enb;
         spNwCfg->defIntTmr.val = spCb.spRetroGenCfg.defIntTmr.val;
         spNwCfg->defRstTmr.enb = spCb.spRetroGenCfg.defRstTmr.enb;
         spNwCfg->defRstTmr.val = spCb.spRetroGenCfg.defRstTmr.val;
         break;
      }

      default:
         /* error case, return */
         break;
   } /* switch (elmnt) */

   RETVOID;
} /* spRetroCfgReq */
#endif /* SP_RUG */


/*
 *
 * Fun : spRetroErr
 *
 * Desc : Dummy function to handle erroneous call to retrofit buffer function.
 *
 * Ret:  None.
 *
 * Notes: None
 *
 * File: cp_bdy2.c
 *
 */
#ifdef ANSI 
PUBLIC Void spRetroErr
(
Elmnt elmnt,                     /* element id */
CmIntfVer intfVer,               /* received interface version number */
PTR buf                          /* pointer to retrofit or config struct */
)
#else
PUBLIC Void spRetroErr(elmnt, intfVer, buf)
Elmnt elmnt;                     /* element id */
CmIntfVer intfVer;               /* received interface version number */
PTR buf;                         /* pointer to retrofit or config struct */
#endif
{
   TRC2(spRetroErr)
   
   UNUSED(elmnt);
   UNUSED(intfVer);
   UNUSED(buf);

   SPLOGERROR(ERRCLS_DEBUG, ESP222, (ErrVal) 0,
              "Invalid call to retrofit function");
   RETVOID;
} /* spRetroErr */


/********************************************************************30**
  
         End of file:     cp_bdy2.c@@/main/18_1 - Tue Jan 22 15:15:20 2002
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.3          ---  fmg   1. added support for CCITT 1988 
                           connection-oriented control

1.4          ---  fmg   1. change sp_db.[hx] to cp_db.[hx]

1.5          ---  fmg   1. change region and pool in SGetMsg

1.6          ---  fmg   1. change SGetMsg call in spEncCLMsg for non
                           ERRCHK
             ---  fmg   2. remove ifdef ERRCHK from around ret in
                           spEncCLMsg

1.7          ---  fmg   1. updated to support new system services
             ---  scc   2. add dpc to calling address for local connection.
                           affect connectionless part only.

1.8          ---  fmg   1. fixed non-errchk compile time error

1.9          ---  scc   1. add checking for illegal management messages

1.10         ---  scc   1. make changes for ANSI 92 and CCITT 92 variants 
                        2. correct suId to spId for call to  SpLiSntUDatReq 
                           in  spDelvUDatDown
                        3. correct spReturnMsg where called and calling
                           addresses have not been switched.
                        4. SpUiSptCordCfm for ANSI 92 has been changed.
                           Now if (smi==UOR_DENIED), upper user should
                           assume that their request is denied, not
                           confirmed.
                        5. NAT_IND and INAT_IND no longer passed
                           down to MTP3.

1.11         ---  fmg   1. switched switch from SW_XXXX to  LSP_SW_XXXX
             ---  fmg   2. removed cm2.x include
             ---  fmg   3. added cm_ss7.? includes
1.12         ---  fmg   1. fixed ucb->dpc omission in spLiHndlClssX

1.13    sp000.25  fmg   1. change msgType from M_UNITDATA to 
                           M_UNITDATASRV in spEncCLMsg
        sp000.25  fmg   2. set retOpt with return cause in spReturnMsg
        sp000.25  fmg   3. use the return nat/int indicator we got in
                           spReturnMsg
        sp000.25  fmg   4. fixed return cause in spLiHndlClss0
        sp000.25  fmg   5. removed code to overwrite niInd in
                           calling address for spUiHndlClss[01]
        sp001.25  fmg   6. fixed spGetAddrLen for new switches
        sp002.25  fmg   7. fixed address switch
        sp003.25  fmg   8. fixed spGetAddrLen to calculate addr
                           length correctly.
             ---  mjp   9. added opc parameter to all SpLiSntUDatReq() calls
             ---  mjp  10. check if user has bound before calling
                           primitives
             ---  mjp  11. change spSendLmSta to accept new events
             ---  mjp  12. replace previous error functions  with SPLOGERROR
             ---  mjp  13. added spSendGenLmStaInd()
             ---  mjp  14. added spRetMsgUppe()
             ---  mjp  15. moved error check in spGetAddrLen
             ---  mjp  16. spaddr switch to SW_XXX from LSP_SW_XXX
                           to be consistent with SCCP users.

1.14         ---  mjp   1. moved some fields from SpUDatEvnt to SpUdCb
             ---  mjp   2. spCheckRoute() check bpcInd in sap 
                           before overwriting pc.             
             ---  mjp   3. cpResolveAddr - If message is from upper interface
                           check pc before checking any other fields in
                           address. If pc is not local return SP_REMOTE
                           immediately.
             ---  mjp   4. moved assignment of ucb->opc in spLiHndlClss1
             ---  mjp   5. added apc var to spLiHndlBckupSS ucp->opc was
                           being used to store affected point code
             ---  mjp   6. SpSC (Sequence Control) parameter added to up1
                           and up2 SCLI hashing keys. Added SpSC parameter
                           to spFindSCLI and spCheckSCLI
             ---  mjp   7. SCLI hash list key f2 (key 6) length now calculated
                           with size of structure.
             ---  mjp   8. add validate priority in spValidateEvnt
             ---  mjp   9. changed SP_FLCOFF to SP_FLCON
             ---  mjp   10. preserve called and calling address in the
                            in spReturnMsg functions. 
             ---  mjp   11. Allow a local subsystem to send a Unitdata msg
                            to another local subsystem. Changed spValidateEvnt,
                            spUiHndlClss0, and spUiHndlClss1
             ---  mjp   12  changed logic to decided when to send SSP
                            in spLiHndlClss0 and spLiHndlClss1.
             ---  mjp   13  When a message from the network resolves to a
                            remote node, ucb->opc is not set to the local pc
                            until all error checking is done.
             ---  mjp   14  Changed spReturnMsg to copy all fields from the
                            original called address to the new calling address
             ---  mjp   15  spLiHndlUDatSrv - read "return cause" from
                            ud.qos.retopt not pClass. 
             ---  mjp   16  spHndlStatInd - check the state of the user
                            before calling spUiSptStaInd
             ---  mjp   17  removed SPLOGERROR when spResolveAddr in 
                            spCheckSCLI (case: GT) fails.
             ---  mjp   18  spLiHndlBckupSS - fill bpc into unitdata control
                            block dpc before sending message to spDelvUDatDown
             ---  mjp   19  Added direction to spResolveAddr calls
             ---  mjp   20  sInfo in all calls to SpLiSntUDatReq is set 
                            base on cdAddr in ucb. 
             ---  mjp   21  added sub-service field (ssf) to spTknStrToSpAddr
             ---  mjp   22  spLiHndlBckupSS - added check of isXudata when
                            encoding message
*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.15         sp001.27 mjp  1.  removed spStartSCLICbTmr from SpAddSCLI to allow
                               wrapper to reuse function.
             sp001.27 mjp  2.  Check spCb.timeFlg when processing timing queue
                      ash  3.  compilation error because of missing (;) after
                               enabling TRACE2.
                      ash  4.  Changes for fault tolerant SCCP
                           5.  New functions added to enable/disable Saps
                           6.  Changes for LMINT3
                           7   Removed function spSendGenLmStaInd
                           8.  Chnages for using new hash library
                           9.  CfgReq cleanup
                           10. Removing bug reported by insight 
                           11. Removed GCC warnings
             sp009.27      12. Changes for patch from previous release
             sp010.27      13. Changes for patch in previous release
                           14. Implemented spShutdown function 
                           15. In function spFindXUdCb , i should be U16
                      cp   16. Made changes as required by TCR0003 for 
                               Debug Msg generation.
                           17. Added function stGenTrc to generate TrcInd. 
                               Also added SP_GEN_TRC to capture the trace.
                           18. spFndLSapSpidOpc function added.
                           19. Call to SP_GEN_TRC before SpLiSntUDatReq is
                               removed.

/main/16         ---      cp   1.  Added flag SP_TX_UDT to support UDT transmission
                               for ANSI'92 and ITU'92.
             ---      cp   2.  Changes for the new GTT framework. 
             ---      cp   3.  Cleaning of SCLI's is done only if 
                               nmbSCLI is > 0 in genCfg.
                           4.  Statistics counters seem to be updated properly.
                           5.  SP_PRESERVE_ADDR flag added for preserving user 
                               supplied cdAddr and cgAddr.
             ---      cp   6.  SP_PRESERVE_ADDR related changes for handling 
                               msgs from L3.
             ---      cp   7.  rte_gtt counter is updated for all Class 1 
                               messages.
             ---      cp   8.  We pass spId in StaInd when user goes out of 
                               service.
             ---      cp   9.  Changes made for the spHdrOpt field in SpAddr.
             ---      vb   10. Clean up of all the patches
                      cp   11. Removed functions related to message drain 
                               flow control is removed.
                      cp   12. Added code for restart begin and end handling.
                      cp   13. Added support for new class 1 implementation.
                      cp   14. Added support for sls per route instead of per 
                               nSap.
                      cp   15. Changed LclRef array to single dimension.
                      cp   16. Corrected spShutdown for stopping SCLI timers.
                      cp   17. Added hooks for the new DFTHA ZP.
                      cp   18. Added functions for the deletion of asso, 
                               route and addrmap.
                      cp   19. Incorporated changes for sp020.27, sp021.27, 
                               sp022.27.
             ---      vb   20. Updated code as per design spec 1010030.12
/main/18     ---      cp    1. Merging of SCCP patches.
                            2. DFTHA related hooks
             sp001.31 sg    1. CHINA variant changed to use ANSI pc insted of ITU.
             sp004.301 sg   4. Added a check to verify that when deleting a
                               SSN we don't return an error when that SSN is the
                               last in a route.
             sp005.301 sg   5. Modified code to check for the ammount of times
                               we have recurssivly called spCheckRoute.    If we
                               exceed a defined maximum, we should return an
                               error.  Otherwise, we can cause a core dump,
                               by infinitly calling the function recursivly.
             sp006.301 sg   6. changed the china variant, as the format for the 
                               cdAddr should be point code then SSN, as apposed 
                               to ANSI, where the format is SSN followed by PC. 
             sp008.301 sg   7. Changed newAddr to a global variable. Previously 
                               newAddr was locally defined within a function,but
                               upon exiting the function the memory would be 
                               lost.
             sp012.301 zq   8. Do not allocate memory for association control
                               block when number of associations is configured
                               zero.
             sp013.301 zq   9. Added subsystem check when we do route
                               configuration for the first time.
                           10. Added default case to catch invalid switch value.
             sp014.301 rc  11. Rolling upgrade changes, under compile flag 
                               SP_RUG as per tcr0020.txt:
                            -  While disabling upper SAP, validity of remote
                               interface version number within sap is marked 
                               FALSE.
                            -  If validity of remote interface version number 
                               within NSAP is FALSE, then NSAP is not enabled.
                            -  Filling remote interface version number in
                               reply post structure.
                            -  Functions added:
                               spGetVer - to provide interface versions to SG
                               spSetVer - to set interface version info.
                            -  Additional parameter to spEnableLowerSap
                            -  Releasing memory for intfver info cb on shutdown
                            -  If genCfg not done, do not generate alarm.
             sp015.301 zq  12. Added validation for fields of the address. 
             sp017.301 zq  12. Stop timers on route when deleting the route.
/main/18_1   ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
             sp001.302  rc   1. Sid correction
                             2. Changes to implement TCR21 :
                              - handling repeated association config request.
                              - new function added:
                                   spMatchAddrMap()
                                   spDeleteNetwork()
                                   spDeleteSap()
                                   spDeleteNSap()
                              - releasing buffer for nwCb in case failure in
                                memory allocation to local reference list
                              - in re-configuration of nid-dpc/nwNid-Ss7Nid
                                mappings, if number of nids is 0, then the
                                corresponding flag for cfgdone is marked as
                                false
             sp003.302 qz    1. Corrected the calculation of reference number 
                                for segmentation of the unit data.
                             2. Added a check in function spFndLSapSpidOpc,if
                                no valid nSap is found we should return null 
                                pointer before do any further checking.
                             3. Added a nSap control block pointer as a 
                                parameter to spFindLowerSapSid so we can check 
                                the different situation of nSap via returned 
                                vlaue.
             sp004.302  rc   1. Initializing the field nextLr when configuring
                                the network.
                             2. type of spMti changed to token U8 from token str
                                ing type and so subscript to spMti.val removed
                             3. De-allocating nSap Cb buffer in spShutdown
             sp007.302  rc   1. Validation check added for fields of spAddr.
             sp008.302  rc   1. When configuration of route, if route status is
                                offline, then ssn status is also marked as
                                inaccessible.
             sp010.302  sg  1.  Check status of SSN in backup route.  Previously
                                we were assuming the backup route's SSN list
                                was intendical to the primary route.
              sp011.302 sg  1.  Added semi-colon for ZP
                            2.  Added check for NULL sap
              sp014.302 rc  1.  When adding a new route or ssn in DFT/HA if
                                crit rset is already active then start SST 
                                and/or STA timers.
              sp015.302 rc  1.  Correcting the calculation of max data length
                                which can be sent in UDT or XUDT
              sp018.302 rc  1.  Starting timers before sending message to other
                                layer to handle tight coupling interfaces.
              sp020.302 rc  1.  Configure slsMask in route if provided.
                            2.  For rCb->sls, using slsMask from rCb instead of
                                nwCb.
              sp024.302 rc  1.  When sending Cfm back to LM, fill the same
                                elmnt and elmntInst1 as received in request
                                primitive from LM.
              sp025.302 rc  1.  Initializing tmr values to start status timer
                                on a route when route is added run time and
                                route is offline.
              sp026.302 rc  1.  Removed function call spInitConHl. This func
                                was to maintain conn hash lists based on CG_KEY,
                                CD_KEY and SU_KEY and is no longer used. Also,
                                allocation/deallocation of mem for these conn
                                hash list is removed.
                            2.  Default hash function for RteCb hash list is
                                replaced with U32Mod.
                            3.  When reconfiguring ssn if ssn status is
                                reconfigured as not acessible then start sst
                                timer for that ssn.
              sp027.302 rc  1.  If ssn is not accessible due to route being
                                down, then return failure in accessibility of
                                point code otherwise return failure in 
                                accessibility of ssn.
              sp028.302 rc  1.  When disabling lower sap, stop reassem timer
                                and free the segBuf for all unformed message.
              sp030.302 cg  1.  Modified default cause to RTC_UNQUAL from 
                                RTC_NETFAIL in function spLiHndlClss0 
                                and spLiHndlClss1.
                            2.  Added debug print in spCheckRoute function in 
                                case of return value SP_ERROR
              sp031.302 cg  1.  ustaMask is initialized if SP_USTA is defined 
              sp033.302 rc  1.  First arg of functions spCheckDpc and spCheckSsn
                                is modified to return ptr to route cb.
              sp035.302 mc  1.  In case of failure in ENCPDU, checking for 
                                data pointer stored ucb to avoid double
                                deallocation of same pointer.
              sp037.302 mc  1.  sInfo made reconfigurable.
              sp038.302 mc  1.  SS_MULTIPLE_PROCS flag added.
              sp039.302 mc  1.  copy dstProcId in srcProcId for multiple 
                                procs case.
              sp040.302 rc  1.  On expiry of timers, if we are standby then just
                                restart the timers.             
                            2.  Handling for GSM routes is separated from itu92
                                routes handling because route swtch gsm is
                                is valid in both itu and ansi networks.
                            3.  In RstBeg handling, generate RT upd for rteCb
                                only in case of earlier psf peer interface ver
                                ZPPV1, ZPPV2 and ZPPV2_1. In the interface ver
                                ZPPV2_2 and higher, sby sccp will mark all the
                                associated routes as offline on nSap status
                                updation of RstBeg to avoid large number of RT
                                update for each associated route Cbs.
                            4.  Copying the called address into ucb.
              sp042.302 mc  1.  On expiry of SST and SRT timers, if we are standby 
                                then just restart the timers.
              sp043.302 mc  1.  Using ANSI header hash defines for China variant
                                because DPC length is 24 bits.
              sp044.302 sm  1.  Initialized the local variables to avoid warnings.
              sp045.302 mc  1.  In spResolveAddr replacing selfPc with ptr to 
                                nwCb of incoming network and ptr to outgoing
                                network CB.
                            2.  In spMatchAssoCb passing new argument, switch
                                with ptr to nwCb of incoming network.
                            3.  In spAssoForRule passing with ptr to 
                                nwCb of incoming network to make search per
                                network.
                            4.  In spCbAddrTreatment passing ptr to network Cb
                                of incoming network.
                            5.  In network deletion, deletion not allowed if
                                if there are any configured associations for
                                for the network.
                            6.  Changes for moving GT related data from global
                                spCb to network cb is to make GTT per network.
                            7.  spDeleteAddrMap to return ROK if no matching
                                association is found.
                            8.  numAddrMapOutNwId initialised to 0 in network
                                configuration and decremented in addressMap
                                deletion request.
                                Network deletion is not allowed if
                                numAddrMapOutNwId is greater than zero.
                            9.  If route is ITU88/ANS88 then xudt is not 
                                supported. message retrun procedure is initiated
                                and error performance report is generated.
                            10. if route is ANS92 segmented XUDT is not 
                                supported. message retrun procedure is initiated
                                and error performance report is generated.
                            11. numAddrMapOutNwId counter incremented.
                            12. new function spDelAsso() to delete associations
                                during association configuration.
                            13. new function spDelAddrMap() to delete
                                addressMap during addressMap configuration.
                            14. numConThresh made reconfigurable.
              sp046.302 mc  1.  Added debug prints in case of spCheckRoute
                                return indicates SP/SSN routing failure. This is
                                added because the present USTA indication doesnt
                                indicate the PC or SSN.
                            2.  Changes due to new hashlist pointers, dataFix,
                                dataAsc and dataDes being moved from SpActnCb
                                to SpAssoCb.
              sp047.302 sm  1.  If message Interception is enabled then retain a
                                copy of the original called and calling address 
                                and copy them back into the message before
                                passing it on to user or provider.
                            2.  Statistics added for intercepted messages at the
                                upper SAP.
              sp048.302 sm  1.  In case of error in handling spUiHndlUDatSrvReq
                                drop the message and release the buffer.
                            2.  Check for xudtsSize corrected to perform the 
                                respective checks for xudts and udts and 
                                truncate the message to that size.
*********************************************************************91*/
