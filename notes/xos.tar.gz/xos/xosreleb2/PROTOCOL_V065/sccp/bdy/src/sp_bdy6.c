/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     sccp - body 6
  
     Type:     C source file
  
     Desc:     C source code for SS7/SCCP GTT
  
     File:     cp_bdy6.c
  
     Sid:      cp_bdy6.c@@/main/3_1 - Tue Jan 22 15:17:30 2002
  
     Prg:      cp
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option             Description
     ------    ------------------------------
#ifndef SPCO
#else
      -02      Connectionless and Connection
#endif
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
#ifdef CCITT96
               CCITT 96
#endif
#ifdef ANS96
      -12      ANSI 96
#endif
 
************************************************************************/


/* header include files -- defines (.h) */
  
#include "envopt.h"  /* environment options */
#include "envdep.h"  /* environment dependent */
#include "envind.h"  /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* layer manager */
#include "cm_hash.h"           /* common header 1 */
#include "cm5.h"           /* common header 3 */
#include "cm_err.h"        /* common error */
#include "mf.h"            /* message functions */
#include "spt.h"           /* sccp layer */
#include "snt.h"           /* mtp3 layer */
#ifdef SP_FTHA
#include "sht.h"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.h"         /* sccp database */
#ifdef ZP
#include "cm_ftha.h"       /* common PSF */   
#include "mrs.h"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.h"      /* common PSF */       
#endif
#include "cm_psfft.h"      /* common PSF */
#endif /* ZP */
#include "sp.h"            /* sccp */
#ifdef ZP
#ifdef ZP_DFTHA
#include "cmzpdp.h"        /* common betn PSF and LDF */
#include "cmzpdplb.h"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.h"
#include "zp.h"
#endif /* ZP */
#include "sp_err.h"        /* sccp - error */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */  
#include "lsp.x"           /* layer manager */
#include "cm_hash.x"       /* common structs 1 */
#include "cm5.x"           /* common structs 3 */
#include "mf.x"            /* message functions */
#include "spt.x"           /* sccp layer */
#include "snt.x"           /* mtp 3 layer */
#ifdef SP_FTHA
#include "sht.x"           /* SHT */
#endif /* SP_FTHA */
#include "cp_db.x"         /* sccp database */
#ifdef ZP
#include "cm_ftha.x"       /* common PSF */       
#include "mrs.x"           /* Message router interface */    
#ifndef TDS_CORE2
#include "cm_pftha.x"      /* common PSF */    
#endif
#include "cm_psfft.x"      /* common PSF */
#endif /* ZP */
#include "sp.x"            /* sccp */
#ifdef ZP 
#ifdef ZP_DFTHA
#include "cmzpdp.x"        /* common betn PSF and LDF */
#include "cmzpdplb.x"      /* common betn PSF and LDF */
#endif /* ZP_DFTHA */
#include "lzp.x"
#include "zp.x"
#endif /* ZP */


/* external functions */

/* forward references */

PRIVATE S16 spGttInit ARGS((SpAssoCb *assoCb)); 
PRIVATE Size spGttMemSize ARGS((U16 maxRules, U16 maxActns, U16 maxEntries));
/* sp045.302 - modification - replacing selfPc with ptr to network Cb */
PRIVATE S16 spGttTrans ARGS((SpAssoCb *assoCb, SpAddr *inAddr, U8 pClass,
                             U8 *mode, U8 *numEntity, U8 *nextEntity,
                             SpAddr *outAddr, U8 *noCplng, SpNwCb *nwCb,
                             SpNwCb **outNwCb));
PRIVATE S16 spGttAdd ARGS((SpAssoCb *assoCb, SpAddrMapCfg *addrMap));
PRIVATE S16 spGttDelete ARGS((SpAssoCb *assoCb, SpAddrMapCfg *addrMap));
PRIVATE S16 spGttDeInit ARGS((SpAssoCb *assoCb));

PRIVATE U16 makeKey ARGS((ShrtAddrs *addr, SpKey *key, U8 startDigit, U8 endDigit));
PRIVATE U16 getEndDigit ARGS((SpAddr *));

/* 
 * support functions
 */


/* 
 * Mapping Tables for Trillium functions and Portable functions 
 */

GtFuncs cmFuncs =
{
   &spGttInit, &spGttMemSize, &spGttTrans, &spGttAdd, &spGttDelete, &spGttDeInit
};


/*
 * 
 * Fun : spGttInit
 *
 * Desc : This function initialises all the module controlled 
 *        fields in the Association Control Block. Like..
 *        - Database Pointer for each Action.
 *        It will also have to allocate all the memory required for the 
 *        databases. The actionCfg structure contains info about the 
 *        maxnumber of entries that will be configured for the database.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE S16 spGttInit 
(
SpAssoCb *assoCb  /* Association Control Block */
)
#else
PRIVATE S16 spGttInit (assoCb)
SpAssoCb *assoCb;  /* Association Control Block */
#endif 
{
   S16 ret;
   S16 i;
   U8 flagFix; /* sp045.302 - addition - flag for fix action */
   U8 flagAsc; /* sp045.302 - addition - flag for ascending action */
   U8 flagDes; /* sp045.302 - addition - flag for descending action */
   /* sp045.302 - deletion - listCp not used */
   CmHashListCp *listCpFix; /* sp045.302 - addition - hashlist for FIX action */
   CmHashListCp *listCpAsc; /* sp045.302 - addition - hashlist for ASC action */
   CmHashListCp *listCpDes; /* sp045.302 - addition - hashlist for DES action */

   TRC2(spGttInit);

   flagFix = FALSE; /* sp045.302 - addition - initialising */
   flagAsc = FALSE; /* sp045.302 - addition - initialising */
   flagDes = FALSE; /* sp045.302 - addition - initialising */

   /* sp045.302 - addition - allocate memory for hash list for FIX,ASC,DES 
    * actions.
    */

   /* Allocate memory for the cmHashListCp */
   if (SGetSBuf(assoCb->region, assoCb->pool, (Data **)&listCpFix, 
                sizeof (CmHashListCp)) != ROK)
      RETVALUE (RFAILED);
   if (SGetSBuf(assoCb->region, assoCb->pool, (Data **)&listCpAsc, 
                sizeof (CmHashListCp)) != ROK)
   {
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
                  sizeof(CmHashListCp));
      RETVALUE (RFAILED);
   }
   if (SGetSBuf(assoCb->region, assoCb->pool, (Data **)&listCpDes, 
                sizeof (CmHashListCp)) != ROK)
   {
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
                  sizeof(CmHashListCp));
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpAsc, 
                  sizeof(CmHashListCp));
      RETVALUE (RFAILED);
   }
   
   for (i = 0; i < assoCb->nmbActns; i++)
   {
      switch (assoCb->actnCb[i].actn.type)
      {
         /* sp045.302 - addition - initialize actnCb for FIX type */
         case SP_ACTN_FIX :
            /* sp046.302 - deletion - dataFix is moved from SpActnCb to
             * SpAssoCb.
             */
            flagFix = TRUE;
            break;
         /* sp045.302 - addition - initialize actnCb for ASC type */
         case SP_ACTN_VAR_ASC :
            /* sp046.302 - deletion - dataFix is moved from SpActnCb to
             * SpAssoCb.
             */
            flagAsc = TRUE;
            break;
         /* sp045.302 - addition - initialize actnCb for DES type */
         case SP_ACTN_VAR_DES :
            /* sp046.302 - deletion - dataFix is moved from SpActnCb to
             * SpAssoCb.
             */
            flagDes = TRUE;
            break;
            
         case SP_ACTN_CONST:
         case SP_ACTN_INSERT_PC:
         case SP_ACTN_STRIP_PC:
            /* sp046.302 - deletion - nmbEntries is not relevant in this case
             * as will be only one entry here.
             */
            assoCb->actnCb[i].data = (Void *)NULLP;
            break;
         case SP_ACTN_GT_TO_PC:
            /* sp046.302 - deletion - nmbEntries is not relevant in this case
             * as will be only one entry here.
             */
            assoCb->actnCb[i].data = (Void *)NULLP;
            break;
         default:
            break;
      } /* switch() */
   } /* for() */
   
   assoCb->nmbEntries = 0; 
   if (flagFix == TRUE)
   {
      /* sp046.302 - addition - dataFix moved to SpAssoCb */
      assoCb->dataFix = (Void *)listCpFix;
      /* sp045.302 - addtion - Initialise the hashlist for the FIX, ASC, 
       * DES action types
       */
      ret = cmHashListInit(listCpFix, GTT_HL_SIZE, 0, FALSE,
                           CM_HASH_KEYTYPE_DEF, assoCb->region, assoCb->pool);
      if (ret != ROK)
      {
         /* Free the buffer */
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
                  sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpDes, 
                     sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpAsc, 
                     sizeof(CmHashListCp));
         SPLOGERROR(ERRCLS_INT_PAR, ESP345, (ErrVal) ret,
                    "cmHashListInit failed for SP_ACTN_FIX action");
         RETVALUE(RFAILED);      
      }
   }
   else
      /* Free the buffer */
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
               sizeof(CmHashListCp));
   if (flagAsc == TRUE)
   {
      /* sp046.302 - addition - dataFix moved to SpAssoCb */
      assoCb->dataAsc = (Void *)listCpAsc;

      ret = cmHashListInit(listCpAsc, GTT_HL_SIZE, 0, FALSE,
                           CM_HASH_KEYTYPE_DEF, assoCb->region, assoCb->pool);
      if (ret != ROK)
      {
         /* Free the buffer */
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
                  sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpDes, 
                     sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpAsc, 
                  sizeof(CmHashListCp));
         SPLOGERROR(ERRCLS_INT_PAR, ESP345, (ErrVal) ret,
                    "spGttInit: cmHashListInit failed for SP_ACTN_VAR_ASC\
                    action");
         RETVALUE(RFAILED);      
      }
   }
   else
      /* Free the buffer */
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpAsc, 
               sizeof(CmHashListCp));
   if (flagDes == TRUE)
   {
      /* sp046.302 - addition - dataFix moved to SpAssoCb */
      assoCb->dataDes = (Void *)listCpDes;

      ret = cmHashListInit(listCpDes, GTT_HL_SIZE, 0, FALSE,
                           CM_HASH_KEYTYPE_DEF, assoCb->region, assoCb->pool);
      if (ret != ROK)
      {
         /* Free the buffer */
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpDes, 
                  sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpAsc, 
                  sizeof(CmHashListCp));
         SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpFix, 
                  sizeof(CmHashListCp));
         SPLOGERROR(ERRCLS_INT_PAR, ESP345, (ErrVal) ret,
                    "spGttInit: cmHashListInit failed for SP_ACTN_VAR_DES\
                    action");
         RETVALUE(RFAILED);      
      }
   }
   else
      /* Free the buffer */
      SPutSBuf(assoCb->region, assoCb->pool, (Data *) listCpDes, 
               sizeof(CmHashListCp));
   /* sp046.302 - addition - initialise the count of fix, ascending and
    * descending types of action.
    */ 
   assoCb->nmbEntriesFix = 0; /* Initialize */
   assoCb->nmbEntriesAsc = 0; /* Initialize */
   assoCb->nmbEntriesDes = 0; /* Initialize */

   RETVALUE(ROK);
} /* spGttInit */


/*
 * 
 * Fun : spGttMemSize
 *
 * Desc : The purpose of this function is to calculate the maximum memory 
 *        required for handling maxRules, maxActns and maxEntries. Our module 
 *        will have a database per rule (and not action). Memory requirements 
 *        arise for the following data structures.
 *        - maxRules number of CmHashListCp for SP_ACTN_FIX, SP_ACTN_VAR_ASC
 *            and SP_ACTN_VAR_DES actions.
 *        - maxEntries number of CmListEnt
 *
 * Returns: Memory required for maximal configuration.
 *
 * Notes: None
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI 
PRIVATE Size spGttMemSize 
(
U16 maxRules,  /* max number of Rules that will be handled */
U16 maxActns,  /* max number of actions in the system */
U16 maxEntries /* max number of Database entries in the system */
)
#else
PRIVATE Size spGttMemSize (maxRules, maxActns, maxEntries)
U16 maxRules;  /* max number of Rules that will be handled */
U16 maxActns;  /* max number of actions in the system  */
U16 maxEntries;/* max number of database entries in the system */
#endif
{
   Size memSize;

   TRC2(spGttMemSize);

   memSize = 0;
   /* sp045.302 - modification - allocating memory for three hashlists
    * instead of earlier only one hashlist.
    */
   memSize = 3 * maxRules * SBUFSIZE (sizeof (CmHashListCp));

   /* 
    * We ignore maxActns.
    * We are also ignoring the memory required fro action type SP_ACTN_CONST 
    * as it it much much lessser than the mem calculated in the following 
    * statements.
    */

   /* memory required for the total database */
   memSize += maxEntries * 
      (SBUFSIZE(sizeof (CmListEnt)) + SBUFSIZE (sizeof (DEntry)));
   RETVALUE (memSize);
} /* spGttMemSize */

/* sp045.302 - modification - pass network CB instead of self pc */

/*
 * 
 * Fun : spGttTrans
 *
 * Desc : This function is suppossed to look at the actions described 
 *        in the association control block in a _sequential_ manner. This is
 *        done till no more actions are left or a databsae entry is found.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE S16 spGttTrans 
(
SpAssoCb *assoCb,       /* Association Control Block */
SpAddr *inAddr,         /* Incoming Address */
U8 pClass,              /* SCCP class of operation */
U8 *mode,               /* Loadshare or Dominant mode */
U8 *numEntity,          /* number of outgoing SCCP entities */
U8 *nextEntity,         /* Next entity to be selected from set */
SpAddr *outAddr,        /* outgoing SCCP entities */
Bool *noCplng,          /* flag to indicate whether coupling required */
SpNwCb *nwCb,           /* sp045.302 - modification - ptr to network Cb 
                         * instead of selfpc
                         */
SpNwCb **outNwCb         /* sp045.302 - addition - ptr to network Cb of
                          * outgoing network.
                          */
)
#else
PRIVATE S16 spGttTrans (assoCb, inAddr, pClass, mode, numEntity, nextEntity,
                        outAddr, noCplng, nwCb, outNwCb)
SpAssoCb *assoCb;        /* Association Control Block */
SpAddr *inAddr;          /* Incoming Address */
U8 pClass;                /* SCCP class of operation */
U8 *mode;                /* Loadshare or Dominant mode */
U8 *numEntity;           /* number of outgoing SCCP entities */
U8 *nextEntity;          /* Next entity to be selected from set */
SpAddr *outAddr;         /* outgoing SCCP entities */
Bool *noCplng;           /* flag to indicate whether coupling required */
SpNwCb *nwCb;            /* sp045.302 - modification - ptr to network Cb 
                          * instead of selfpc
                          */
SpNwCb **outNwCb;        /* sp045.302 - addition - ptr to network Cb of
                          * outgoing network.
                          */
#endif
{
   S16 i;                /* loop counter */
   S16 j;                /* loop counter */
   U16 len;              /* length of data entry key */
   SpKey key;            /* key to find data entry */
   DEntry *dEntry;       /* pointer to data entry */
   U16 endDigitActn;     /* endDigit in Gt action cb */
   U16 startDigitActn;   /* startDigit in Gt action cb */
   U16 endDigit;         /* endDigit of key to search dEntry */
   S16 ret;              /* return value */
#ifdef LSPV2_4   
   SpNwCb *tmpNwCb;      /* sp045.302 - addition - ptr to network CB */
   U8 nwIndx;            /* sp045.302 - addition - counter */
   Bool found;           /* sp045.302 - addition - flag */
#endif /* LSPV2_4 */   

   TRC2(spGttTrans);

   endDigit = getEndDigit(inAddr);

   for (j = 0; j < assoCb->nmbActns; j++)
   {
      dEntry = NULLP;
      switch (assoCb->actnCb[j].actn.type)
      {
         case SP_ACTN_FIX :
            /* get startDigit and endDigit from the action control block */
            startDigitActn = assoCb->actnCb[j].actn.param.range.startDigit;
            endDigitActn = assoCb->actnCb[j].actn.param.range.endDigit;

            /* Validate the length of inAddr */
            if (endDigit < endDigitActn)
               continue;

            /* Make key */
            len = makeKey(&inAddr->gt.addr, &key, (U8) startDigitActn,
                          (U8) endDigitActn);

            /* sp045.302 - addition - separate hashlist for FIX action */
            /* sp046.302 - modification - dataFix is moved from SpActn to
             * SpAssoCb.
             */
            /* make entry from database */
            cmHashListFind((CmHashListCp *) assoCb->dataFix, 
                           (U8 *) &key, len, 0, (PTR *) &dEntry);

            /* Do the processing */
            if (dEntry != NULLP)
            {
               /* fill the required information to be returned */
               
               /* mode of operation of SCCP entities */
               *mode = dEntry->mode;

#ifdef LSPV2_4      
               if ( dEntry->outNwId != nwCb->nwId)
               {
                  /* sp045.302 - addition - check if outgoing network 
                   * is configured or not.
                   */
                  found = FALSE;
                  tmpNwCb = NULLP;
                  for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
                  {
                     tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                     if (tmpNwCb->nwId == dEntry->outNwId )
                     {
                        found = TRUE;
                        break;
                     }
                  }

                  if(found == FALSE)
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, dEntry->outNwId, 
                               "spGttTrans: out going network id not\
                               configured for FIX action");
                     RETVALUE(RFAILED);
                  }
                  *outNwCb = tmpNwCb;
               }
#endif /* LSPV2_4 */      

               /* number of entities in an entity set */
               *numEntity = dEntry->numEntity;
            
               /* flag to indicate coupling of connection section required */
               *noCplng = dEntry->noCplng;

               /* next outgoing SCCP entity selected */
               *nextEntity = dEntry->nextEntity;
              
               if (*mode == LOADSHARE && pClass == PCLASS0)
               {
                  /* increment nextEntity in mod operation with numEntity */
                  dEntry->nextEntity++;
                  if (dEntry->nextEntity >= dEntry->numEntity)
                     dEntry->nextEntity = 0;
               }

               /* copy outgoing SCCP entities */
               /* sp018.302 - addition - if ssn is missing in outAddr then
                * take ssn from inAddr
                */
               for(i = 0; i < (S16) dEntry->numEntity; i++)
               {
                  cmCopySpAddr(&dEntry->outAddr[i], &outAddr[i]);
                  if (outAddr[i].ssnInd == FALSE)
                  {
                     outAddr[i].ssn = inAddr->ssn;
                     outAddr[i].ssnInd = inAddr->ssnInd;
                  }
               }

               if (dEntry->replGt == TRUE)
                  for(i = 0; i < (S16) dEntry->numEntity; i++)
                     cmCopyGt(inAddr->sw, &inAddr->gt, &outAddr[i].gt);
               RETVALUE (ROK);
            }
            break;

         case SP_ACTN_VAR_ASC :
            /* get startDigit and endDigit from the action control block */
            startDigitActn = assoCb->actnCb[j].actn.param.range.startDigit;
            endDigitActn = assoCb->actnCb[j].actn.param.range.endDigit;

            /* Validate the length of inAddr */
            if (endDigit < startDigitActn)
               continue;
            if (endDigit > endDigitActn)
               endDigit = endDigitActn;

            len = makeKey(&inAddr->gt.addr, &key, (U8) startDigitActn,
                          (U8) startDigitActn);

            /* sp045.302 - addition - separate hashlist for ASC action */
            /* sp046.302 - modification - dataAsc is moved from SpActn to
             * SpAssoCb.
             */
            /* Get entry from database */
            cmHashListFind((CmHashListCp *) assoCb->dataAsc, 
                           (U8 *) &key, len, 0, (PTR *) &dEntry);

            /* if entry not found, modify key by adding next digit
             * till the endDigit to search dEntry.
             */
            if (dEntry == NULLP)
            {
               for (i = (S16) (startDigitActn + 1); i <= (S16) endDigit; i++)
               {
                  if (i & 0x01)
                  {
                     key.addr.strg[key.addr.length] =
                           inAddr->gt.addr.strg[((i + 1) >> 1) - 1];
                     key.addr.length++;
                     len++;
                  }
                  else
                  {
                     key.addr.strg[key.addr.length - 1] =
                           inAddr->gt.addr.strg[((i + 1) >> 1) - 1];
                  }

                  key.endDigit = (U8) i;
                  key.addr.strg[key.addr.length - 1] &=
                       ((i & 0x01) ? 0x0f : 0xff);

                  /* sp045.302 - addition - separate hashlist for ASC action */
                  /* sp046.302 - modification - dataAsc is moved from SpActn to
                   * SpAssoCb.
                   */
                  /* Get entry from database */
                  cmHashListFind((CmHashListCp *) assoCb->dataAsc, 
                                 (U8 *) &key, len, 0, (PTR *) &dEntry);

                  if (dEntry == NULLP)
                     continue;
                  else 
                     break;
               } /* for () */
            } /* if (dEntry == NULLP) */

            /* Do the processing */
            if (dEntry != NULLP)
            {
               /* fill the required information to be returned */
               
               /* mode of operation of SCCP entities */
               *mode = dEntry->mode;
               /* sp045.302 - addition - out going network id */
#ifdef LSPV2_4      
               if ( dEntry->outNwId != nwCb->nwId)
               {
                  /* sp045.302 - addition - check if outgoing network 
                   * is configured or not.
                   */
                  found = FALSE;
                  tmpNwCb = NULLP;
                  for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
                  {
                     tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                     if (tmpNwCb->nwId == dEntry->outNwId )
                     {
                        found = TRUE;
                        break;
                     }
                  }

                  if(found == FALSE)
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, dEntry->outNwId, 
                               "spGttTrans: out going network id not\
                               configured for VAR_ASC action");
                     RETVALUE(RFAILED);
                  }
                  *outNwCb = tmpNwCb;
               }
#endif /* LSPV2_4 */      
               /* number of entities in an entity set */
               *numEntity = dEntry->numEntity;
            
               /* flag to indicate couling of connection ection required */
               *noCplng = dEntry->noCplng;

               /* next outgoing SCCP entity selected */
               *nextEntity = dEntry->nextEntity;

               if (*mode == LOADSHARE && pClass == PCLASS0)
               {
                  /* increment nextEntity in mod operation with numEntity */
                  dEntry->nextEntity++;
                  if (dEntry->nextEntity >= dEntry->numEntity)
                     dEntry->nextEntity = 0;
               }

               /* copy outgoing SCCP entities */
               /* sp018.302 - addition - if ssn is missing in outAddr then
                * take ssn from inAddr
                */
               for(i = 0; i < (S16) dEntry->numEntity; i++)
               {
                  cmCopySpAddr(&dEntry->outAddr[i], &outAddr[i]);
                  if (outAddr[i].ssnInd == FALSE)
                  {
                     outAddr[i].ssn = inAddr->ssn;
                     outAddr[i].ssnInd = inAddr->ssnInd;
                  }
               }

               if (dEntry->replGt == TRUE)
                  for(i = 0; i < (S16) dEntry->numEntity; i++)
                     cmCopyGt(inAddr->sw, &inAddr->gt, &outAddr[i].gt);

               RETVALUE (ROK);
            }
            break;
               
         case SP_ACTN_VAR_DES :
            /* get startDigit and endDigit from the action control block */
            startDigitActn = assoCb->actnCb[j].actn.param.range.startDigit;
            endDigitActn = assoCb->actnCb[j].actn.param.range.endDigit;

            /* Validate the length of inAddr */
            if (endDigit < startDigitActn)
               continue;
            if (endDigit > endDigitActn)
               endDigit = endDigitActn;

            /* Make Key */
            len = makeKey(&inAddr->gt.addr, &key, (U8) endDigit, (U8) endDigit);

            /* Get entry from database */
            /* sp045.302 - addition - separate hashlist for DES action */
            /* sp046.302 - modification - dataDes is moved from SpActn to
             * SpAssoCb.
             */
            cmHashListFind((CmHashListCp *) assoCb->dataDes, 
                           (U8 *) &key, len, 0, (PTR *) &dEntry);

            if (dEntry == NULLP)
            {
               U8 count;

               for (i = (S16) (endDigit - 1); i >= (S16) startDigitActn; i--)
               {
                  if (i & 0x01)
                  {
                     key.addr.strg[0] =
                             inAddr->gt.addr.strg[((i + 1) >> 1) - 1];
                  }
                  else
                  {
                     for (count = key.addr.length; count > 0; count--)
                        key.addr.strg[count] = key.addr.strg[count - 1];

                     key.addr.strg[0] =
                        inAddr->gt.addr.strg[((i + 1) >> 1) - 1];
                     key.addr.length++;
                     len++;
                  }

                  key.startDigit = (U8) i;
                  key.addr.strg[0] &= ((i & 0x01) ? 0xff : 0xf0);

                  /* sp045.302 - addition - separate hashlist for DES action */
                  /* sp046.302 - modification - dataDes is moved from SpActn to
                   * SpAssoCb.
                   */
                  cmHashListFind((CmHashListCp *) assoCb->dataDes, 
                                 (U8 *) &key, len, 0, (PTR *) &dEntry);

                  if (dEntry == NULLP)
                     continue;
                  else 
                     break;
               } /* for () */
            } /* if (dEntry == NULLP) */
            
            /* Do the processing */
            if (dEntry != NULLP)
            {
               /* fill the required information to be returned */
               
               /* mode of operation of SCCP entities */
               *mode = dEntry->mode;

               /* sp045.302 - addition - out going network id */
#ifdef LSPV2_4      
               if ( dEntry->outNwId != nwCb->nwId)
               {
                  /* sp045.302 - addition - check if outgoing network 
                   * is configured or not.
                   */
                  found = FALSE;
                  tmpNwCb = NULLP;
                  for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
                  {
                     tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                     if (tmpNwCb->nwId == dEntry->outNwId )
                     {
                        found = TRUE;
                        break;
                     }
                  }

                  if(found == FALSE)
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, dEntry->outNwId, 
                               "spGttTrans: out going network id not\
                               configured VAR_ASC action");
                     RETVALUE(RFAILED);
                  }
                  *outNwCb = tmpNwCb;
               }
#endif /* LSPV2_4 */      
               /* number of entities in an entity set */
               *numEntity = dEntry->numEntity;
            
               /* flag to indicate couling of connection ection required */
               *noCplng = dEntry->noCplng;

               /* next outgoing SCCP entity selected */
               *nextEntity = dEntry->nextEntity;

               if (*mode == LOADSHARE && pClass == PCLASS0)
               {
                  /* increment nextEntity in mod operation with numEntity */
                  dEntry->nextEntity++;
                  if (dEntry->nextEntity >= dEntry->numEntity)
                     dEntry->nextEntity = 0;
               }

               /* copy outgoing SCCP entities */
               /* sp018.302 - addition - if ssn is missing in outAddr then
                * take ssn from inAddr
                */
               for(i = 0; i < (S16) dEntry->numEntity; i++)
               {
                  cmCopySpAddr(&dEntry->outAddr[i], &outAddr[i]);
                  if (outAddr[i].ssnInd == FALSE)
                  {
                     outAddr[i].ssn = inAddr->ssn;
                     outAddr[i].ssnInd = inAddr->ssnInd;
                  }
               }

               if (dEntry->replGt == TRUE)
                  for(i = 0; i < (S16) dEntry->numEntity; i++)
                     cmCopyGt(inAddr->sw, &inAddr->gt, &outAddr[i].gt);
               RETVALUE (ROK);
            }
            break;

         case SP_ACTN_CONST:
            /* check if entry is configured */
            if (assoCb->actnCb[j].data == NULLP)
               break;

            /* assign data to dEntry */
            dEntry = (DEntry *) (assoCb->actnCb[j].data);

            for (i = 0; i < (S16) dEntry->numEntity; i++)
            {
               cmCopySpAddr(&dEntry->outAddr[i], &outAddr[i]);

               /* sp018.302 - addition - if ssn is missing in outAddr then
                * take ssn from inAddr
                */
               if (outAddr[i].ssnInd == FALSE)
               {
                  outAddr[i].ssn = inAddr->ssn;
                  outAddr[i].ssnInd = inAddr->ssnInd;
               }
            }

            /* fill the required information to be returned */
             
            /* mode of operation of SCCP entities */
            *mode = dEntry->mode;

            /* sp045.302 - addition - out going network id */
#ifdef LSPV2_4      
            if ( dEntry->outNwId != nwCb->nwId)
            {
               /* sp045.302 - addition - check if outgoing network 
                * is configured or not.
                */
               found = FALSE;
               tmpNwCb = NULLP;
               for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
               {
                  tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                  if (tmpNwCb->nwId == dEntry->outNwId )
                  {
                     found = TRUE;
                     break;
                  }
               }

               if(found == FALSE)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, dEntry->outNwId, 
                            "spGttTrans: out going network id not\
                            configured for CONST action");
                  RETVALUE(RFAILED);
               }
               *outNwCb = tmpNwCb;
            }
#endif /* LSPV2_4 */      
            /* number of entities in an entity set */
            *numEntity = dEntry->numEntity;
          
            /* flag to indicate couling of connection ection required */
            *noCplng = dEntry->noCplng;

            /* next outgoing SCCP entity selected */
            *nextEntity = dEntry->nextEntity;

            if (*mode == LOADSHARE && pClass == PCLASS0)
            {
               /* increment nextEntity in mod operation with numEntity */
               dEntry->nextEntity++;
               if (dEntry->nextEntity >= dEntry->numEntity)
                  dEntry->nextEntity = 0;
            }

            if (((DEntry *)assoCb->actnCb[j].data)->replGt == TRUE)
               for(i = 0; i < (S16) dEntry->numEntity; i++)
                  cmCopyGt(inAddr->sw, &inAddr->gt, &outAddr[i].gt);
            RETVALUE (ROK);

         case SP_ACTN_GT_TO_PC:
            /* 
             * Copy 1st four GT into the PC (U32).
             * We dont have to worry about the switch as only the relevant 
             * portion of the PC will be used depending on teh variant.
             * replGt is ignored for this action as we _have_ to do route on GT.
             */

            cmCopySpAddr(inAddr, &outAddr[0]);
            /* 
             * The specs say that the GT is is in the form of a point code.
             * Hopefully we wont have to manipulate the digits to go into the 
             * PC. For now this seems o be right......
             */
            {
               U16 tmp16;
               U32 tmp32;
               U8 *tmp;
               
               tmp16 = 0;
               tmp32 = 0;
               tmp = &inAddr->gt.addr.strg[0];

               tmp16 = (U16) PutLoByte (tmp16, (U8) tmp[0]);
               tmp16 = (U16) PutHiByte (tmp16, (U8) tmp[1]);
               tmp32 = (U32) PutLoWord (tmp32, (U16) tmp16);
               tmp16 = 0;
               tmp16 = (U16) PutLoByte (tmp16, (U8) tmp[2]);
               outAddr[0].pc = (U32) PutHiWord (tmp32, (U16)tmp16);
            }

            /* fill the required information to be returned */
             
            /* mode of operation of SCCP entities */
            *mode = DOMINANT;

            /* number of entities in an entity set */
            *numEntity = 1;
          
            /* flag to indicate couling of connection ection required */
            *noCplng = FALSE;

            /* next outgoing SCCP entity selected */
            *nextEntity = 0;

            RETVALUE (ROK);
            
         case SP_ACTN_INSERT_PC:
            /* check if database entry is configured in actnCb */
            if (assoCb->actnCb[j].data == NULLP)
               break;
            else
            {
               U8 len1;              /* GT length */
               SpAddr *tmpAddr;      /* temporary address ptr */
               ShrtAddrs pcAddr;     /* point code in bcd format */

               tmpAddr = ((DEntry *) assoCb->actnCb[j].data)->outAddr;

               /* convert pc into BCD format */
               spPcToBcdAddr(tmpAddr->pc, DPC14, &pcAddr);

               len1 = inAddr->gt.addr.length;

               /* shift the GT array elemnts by the INAT_PC length value */
               for (i = (S16) (len1 - 1); i >= 0; i--)
               {
                  inAddr->gt.addr.strg[i +  INTLBCDPCLENGTH] =
                                             inAddr->gt.addr.strg[i];
               }

               /* insert point code in the beginning of GTAI */
               for (i = 0; i < INTLBCDPCLENGTH; i++)
                  inAddr->gt.addr.strg[i] = pcAddr.strg[i];

               /* modify the GT length */
               inAddr->gt.addr.length += INTLBCDPCLENGTH;

               /* replace TT, ES and NAI of inAddr */
               inAddr->gt.gt.f4.tType = tmpAddr->gt.gt.f4.tType;
               inAddr->gt.gt.f4.encSch = tmpAddr->gt.gt.f4.encSch;
               inAddr->gt.gt.f4.natAddr = tmpAddr->gt.gt.f4.natAddr;

               
               /* copy inAddr to outAddr: only one entry is allowed 
                * so copy it at first index
                */
               cmCopySpAddr(inAddr, &outAddr[0]);

               /* fill the required information to be returned */
             
               /* mode of operation of SCCP entities */
               *mode = ((DEntry *) assoCb->actnCb[j].data)->mode;

               /* sp045.302 - addition - out going network id */
#ifdef LSPV2_4      
               if ( ((DEntry *) assoCb->actnCb[j].data)->outNwId
                     != nwCb->nwId)
               {
                  /* sp045.302 - addition - check if outgoing network 
                   * is configured or not.
                   */
                  found = FALSE;
                  tmpNwCb = NULLP;
                  for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
                  {
                     tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                     if (tmpNwCb->nwId ==  
                              ((DEntry *) assoCb->actnCb[j].data)->outNwId)
                     {
                        found = TRUE;
                        break;
                     }
                  }

                  if(found == FALSE)
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESPXXX,
                     ((DEntry *) assoCb->actnCb[j].data)->outNwId, 
                               "spGttTrans: out going network id not\
                               configured INSERT_PC action");
                     RETVALUE(RFAILED);
                  }
                  *outNwCb = tmpNwCb;
               }
#endif /* LSPV2_4 */      

               /* copy number of entities in an entity set as 1 as this is
                * the only value which is allowed during Gtt addition
                */
               *numEntity = 1;
        
               /* next outgoing SCCP entity selected */
               *nextEntity = 0;

               /* flag to indicate couling of connection ection required */
               *noCplng = ((DEntry *) assoCb->actnCb[j].data)->noCplng;
               RETVALUE (ROK);
            }
            break;
    
         case SP_ACTN_STRIP_PC:
         {
            /* check if database entry is configured in actnCb */
            if(assoCb->actnCb[j].data == NULLP)
               break;
            else
            {
               Dpc dpc;            /* Point code in the beginning of GTAI */
               SpAddr *tmpAddr;    /* temp variable to store the address */
 
               /* convert first 3 octets (i.e. first 6 bcd digits) in
                * the beginning of GTAI into point code (dpc).
                */
               spBcdAddrToPc(&inAddr->gt.addr, DPC14, &dpc);

               /* sp045.302 - modification - selfPc from network Cb */
               /* check if resulted dpc matches the self point code */
               if(dpc == nwCb->selfPc)
               {
                  U8 k;

                  /* strip off first three octets from beginning of GTAI */
                  for (k = 0; k < (inAddr->gt.addr.length-INTLBCDPCLENGTH); k++)
                  {
                     inAddr->gt.addr.strg[k] = 
                                      inAddr->gt.addr.strg[k + INTLBCDPCLENGTH];
                  }

                  /* modify the GT length */
                  inAddr->gt.addr.length -= INTLBCDPCLENGTH;

                  /* get the database entry for this action */
                  tmpAddr = ((DEntry *) assoCb->actnCb[j].data)->outAddr;

                  /* replace TT,ES and NAI of inAddr from that in outAddr */
                  inAddr->gt.gt.f4.tType = tmpAddr->gt.gt.f4.tType;
                  inAddr->gt.gt.f4.encSch = tmpAddr->gt.gt.f4.encSch;
                  inAddr->gt.gt.f4.natAddr = tmpAddr->gt.gt.f4.natAddr;
                  inAddr->pc = tmpAddr->pc;

                  /* check if the pc of the database entry matches self point
                   * code. If so, translate the modified inAddr else copy
                   * the modified inAddr to outAddr and route the message to
                   * the point code which is resulted from database entry.
                   */
                  /* sp045.302 - modification - selfPc from network Cb */
                  if (tmpAddr->pc == nwCb->selfPc)
                  {
                     /* Find the matching control block */
                     /* sp045.302 - addition - ptr to network CB passed */
                     assoCb = spMatchAssoCb(&inAddr->gt, inAddr->sw, nwCb);
                     if (assoCb == NULLP)
                        RETVALUE (RFAILED);

                     /* sp045.302 - modification - replacing spc with network 
                      * Cb and passing ptr to ptr to outgoing network Cb.
                      */
                     /* translate modified inAddr */
                     ret = assoCb->funcs->gttTrans(assoCb, inAddr, pClass, mode,
                                                   numEntity, nextEntity, 
                                                   outAddr, noCplng, nwCb, 
                                                   outNwCb);
                     if (ret != SP_OK)
                        RETVALUE(RFAILED);
                     else   /* sp004.302 - addition - return success */
                        RETVALUE(ROK);
                  }
                  else
                     /* copy inAddr to outAddr */
                     cmCopySpAddr(inAddr, &outAddr[0]);
               } /* if (dpc == spc) */
               else
               {
                  /* first 3 octets (first 6 bcd digits) of the GTAI does
                   * not match the self point code, means, GT translation
                   * will be done at the node having the point code same as
                   * encoded in GTAI. Leave inAddr unchanged and route the
                   * message to the pc, resulted from first 3 octets of GTAI.
                   */

                  /* copy inAddr to outAddr */
                  cmCopySpAddr(inAddr, &outAddr[0]);

                  /* route message to dpc */
                  outAddr[0].pc = dpc;
               }

               /* fill the required information to be returned */

               /* mode of operation of SCCP entities */
               *mode = ((DEntry *) assoCb->actnCb[j].data)->mode;

               /* sp045.302 - addition - out going network id */
#ifdef LSPV2_4      
               if ( ((DEntry *) assoCb->actnCb[j].data)->outNwId 
                                  != nwCb->nwId)
               {
                  /* sp045.302 - addition - check if outgoing network 
                   * is configured or not.
                   */
                  found = FALSE;
                  tmpNwCb = NULLP;
                  for (nwIndx = 0; nwIndx < spCb.nmbNws; nwIndx++)
                  {
                     tmpNwCb = *(spCb.nwList + (PTR) nwIndx);
                     if (tmpNwCb->nwId == 
                        ((DEntry *) assoCb->actnCb[j].data)->outNwId )
                     {
                        found = TRUE;
                        break;
                     }
                  }

                  if(found == FALSE)
                  {
                     SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                     ((DEntry *) assoCb->actnCb[j].data)->outNwId, 
                               "spGttTrans: out going network id not\
                               configured for STRIP_PC action");
                     RETVALUE(RFAILED);
                  }
                  *outNwCb = tmpNwCb;
               }
#endif /* LSPV2_4 */      

               /* set number of entities in an entity set as 1 , as this
                *  the only possible value which is allowed during Gtt
                * addition 
                */
               *numEntity = 1;
          
               /* flag to indicate couling of connection ection required */
               *noCplng = ((DEntry *) assoCb->actnCb[j].data)->noCplng;

               /* next outgoing SCCP entity selected */
               *nextEntity = 0;

               RETVALUE(ROK);

            } /* valid data entry present */
         } /* end of case  ACN_STRIP_PC */
            break;

         default : 
            RETVALUE (RFAILED);
      } /* switch () */
   } /* for () */
   /* Translation is not possible */
   RETVALUE (RFAILED);
} /* spGttTrans */


/*
 * 
 * Fun : spGttAdd
 *
 * Desc : This function adds database entry. Before adding the database entry
 *        it will have to check if the action(in the addr map) exists
 *        for the the rule.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None.
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE S16 spGttAdd 
(
SpAssoCb *assoCb,         /* Association Control Block */
SpAddrMapCfg *addrMap     /* Address */
)
#else
PRIVATE S16 spGttAdd(assoCb, addrMap)
SpAssoCb *assoCb;         /* Association Control Block */
SpAddrMapCfg *addrMap;    /* Address */
#endif
{
   U8 i;                  /* loop counter */
   U8 j;                  /* loop counter */
   U16 len;               /* length of the key for hash list */
   U16 ret;               /* return value */
   DEntry *dEntry;        /* data base entry to store */

   TRC2(spGttAdd);

   /* Validation check for Generic numbering plan */
   if (addrMap->gt.format == GTFRMT_4)
   {
      if ((addrMap->gt.gt.f4.numPlan == NP_GENERIC) &&
          (addrMap->gt.gt.f4.natAddr == NA_INTNUM))
      {
         if (addrMap->numEntity > 1)
         {
            SPLOGERROR(ERRCLS_ADD_RES, ESP346, (ErrVal) 0, 
                       "Number of Entities in GNP should not be more than 1");
            RETVALUE(LSP_REASON_INVALID_NUMENTITIES);
         }
      }
   }
   
   /* sp045.302 - addition - inserting GT info for FIX, ASC and DSC type actions
    * in separate hash list.
    */
   for (i = 0; i < assoCb->nmbActns; i++)
   {
      if (assoCb->actnCb[i].actn.type == addrMap->actn.type)
      {
         switch (addrMap->actn.type)
         {
            case SP_ACTN_FIX :
               if ((addrMap->actn.param.range.startDigit == 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit == 
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else 
                  break;

               /* 
                * All validity checks have passed.
                * Allocate DEntry and add into the database .
                * No checks are dont to see if the entry is already
                * present in the database. 
                */
               ret = SGetSBuf(assoCb->region, assoCb->pool, (Data **) &dEntry,
                              sizeof(DEntry));
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_ADD_RES, ESP347, (ErrVal) ret, 
                             "spGttAdd :SGetSBuf failed for SP_ACTN_FIX");
                  RETVALUE(LCM_REASON_MEM_NOAVAIL);
               }
               
               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &dEntry->gtKey, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);

               /* copy the required fields of dEntry */

               /* Copy replGt */
               dEntry->replGt = addrMap->replGt;

               dEntry->noCplng = addrMap->noCplng;
               dEntry->mode = addrMap->mode; 
               /* sp045.302 - addition - outgoing network id */
#ifdef LSPV2_4      
               dEntry->outNwId = addrMap->outNwId; 
#endif /* LSPV2_4 */      
               dEntry->numEntity = addrMap->numEntity;
                
               /* Initialize next entity in dEntry to zero */
               dEntry->nextEntity = 0;

               /* Copy the outgoing Address */
               for(j = 0; j < addrMap->numEntity; j++)
                  cmCopySpAddr (&addrMap->outAddr[j], &dEntry->outAddr[j]);
               
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               /* Insert the dEntry into the hash table */
               ret = cmHashListInsert ((CmHashListCp *)assoCb->dataFix
                                       , (PTR)dEntry, (U8 *)&dEntry->gtKey, 
                                       len); 
               if (ret != ROK)
               {
                  /* release buffer allocated for dEntry */
                  SPutSBuf(assoCb->region, assoCb->pool, (Data *) dEntry,
                           sizeof(DEntry));
                  SPLOGERROR(ERRCLS_INT_PAR, ESP348, (ErrVal) ret, \
                             "cmHashListInsert failed for SP_ACTN_FIX action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }
               
               /* Entry Added */
               /* sp046.302 - modification - increment the counter of FIX */
               assoCb->nmbEntriesFix++;
               assoCb->nmbEntries++;
               RETVALUE (ROK);
         
            case SP_ACTN_VAR_ASC :
               if ((addrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* 
                * All validity checks have passed.
                * Allocate DEntry and add into the database .
                * No checks are dont to see if the entry is already
                * present in the database. 
                */
               ret = SGetSBuf(assoCb->region, assoCb->pool, (Data **) &dEntry,
                              sizeof(DEntry));
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_ADD_RES, ESP347, (ErrVal) ret, 
                             "spGttAdd: SGetSBuf failed for SP_ACTN_VAR_ASC");
                  RETVALUE(LCM_REASON_MEM_NOAVAIL);
               }
               
               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &dEntry->gtKey, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);

               /* copy the required fields of dEntry */

               /* Copy replGt */
               dEntry->replGt = addrMap->replGt;

               dEntry->noCplng = addrMap->noCplng;
               dEntry->mode = addrMap->mode; 
               /* sp045.302 - addition - outgoing network id */
#ifdef LSPV2_4      
               dEntry->outNwId = addrMap->outNwId; 
#endif /* LSPV2_4 */      
               dEntry->numEntity = addrMap->numEntity;
                
               /* Initialize next entity in dEntry to zero */
               dEntry->nextEntity = 0;

               /* Copy the outgoing Address */
               for(j = 0; j < addrMap->numEntity; j++)
                  cmCopySpAddr (&addrMap->outAddr[j], &dEntry->outAddr[j]);
               
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               /* Insert the dEntry into the hash table */
               ret = cmHashListInsert ((CmHashListCp *)assoCb->dataAsc
                                       , (PTR)dEntry, (U8 *)&dEntry->gtKey,
                                       len); 
               if (ret != ROK)
               {
                  /* release buffer allocated for dEntry */
                  SPutSBuf(assoCb->region, assoCb->pool, (Data *) dEntry,
                           sizeof(DEntry));
                  SPLOGERROR(ERRCLS_INT_PAR, ESP348, (ErrVal) ret, \
                             "spGttAdd: cmHashListInsert failed for\
                              SP_ACTNVAR_ASC action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }
               
               /* Entry Added */
               /* sp046.302 - modification - increment the counter of ASC */
               assoCb->nmbEntriesAsc++;
               assoCb->nmbEntries++;
               RETVALUE (ROK);
         
            case SP_ACTN_VAR_DES :
               if ((addrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* 
                * All validity checks have passed.
                * Allocate DEntry and add into the database .
                * No checks are dont to see if the entry is already
                * present in the database. 
                */
               ret = SGetSBuf(assoCb->region, assoCb->pool, (Data **) &dEntry,
                              sizeof(DEntry));
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_ADD_RES, ESP347, (ErrVal) ret, 
                             "spGttAdd: SGetSBuf failed for SP_ACTN_VAR_DES");
                  RETVALUE(LCM_REASON_MEM_NOAVAIL);
               }
               
               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &dEntry->gtKey, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);

               /* copy the required fields of dEntry */

               /* Copy replGt */
               dEntry->replGt = addrMap->replGt;

               dEntry->noCplng = addrMap->noCplng;
               dEntry->mode = addrMap->mode; 
               /* sp045.302 - addition - outgoing network id */
#ifdef LSPV2_4      
               dEntry->outNwId = addrMap->outNwId; 
#endif /* LSPV2_4 */      
               dEntry->numEntity = addrMap->numEntity;
                
               /* Initialize next entity in dEntry to zero */
               dEntry->nextEntity = 0;

               /* Copy the outgoing Address */
               for(j = 0; j < addrMap->numEntity; j++)
                  cmCopySpAddr (&addrMap->outAddr[j], &dEntry->outAddr[j]);
               
               /* sp046.302 - modification - dataDes is moved from SpActn to
                * SpAssoCb.
                */
               /* Insert the dEntry into the hash table */
               ret = cmHashListInsert ((CmHashListCp *)assoCb->dataDes
                                       , (PTR)dEntry, (U8 *)&dEntry->gtKey, 
                                       len); 
               if (ret != ROK)
               {
                  /* release buffer allocated for dEntry */
                  SPutSBuf(assoCb->region, assoCb->pool, (Data *) dEntry,
                           sizeof(DEntry));
                  SPLOGERROR(ERRCLS_INT_PAR, ESP348, (ErrVal) ret, \
                             "spGttAdd: cmHashListInsert failed for \
                             SP_ACTN_VAR_DES action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }
               
               /* Entry Added */
               /* sp046.302 - modification - increment the counter of DES */
               assoCb->nmbEntriesDes++;
               assoCb->nmbEntries++;
               RETVALUE (ROK);
         
            case SP_ACTN_CONST:
            case SP_ACTN_INSERT_PC:
            case SP_ACTN_STRIP_PC:
               /* reconfiguration is _not_ allowed */
               if (assoCb->actnCb[i].data == NULLP)
               {
                  ret = SGetSBuf (assoCb->region, assoCb->pool, 
                                  (Data **)&assoCb->actnCb[i].data, 
                                  sizeof (DEntry));
                  if (ret != ROK)
                  {
                     SPLOGERROR(ERRCLS_ADD_RES, ESP349, (ErrVal) ret, 
                                "SGetSBuf failed");
                     RETVALUE(LCM_REASON_MEM_NOAVAIL);
                  }
                  ((DEntry *) assoCb->actnCb[i].data)->noCplng =
                                                       addrMap->noCplng;
                  ((DEntry *)assoCb->actnCb[i].data)->mode =
                                                       addrMap->mode; 
                  /* sp045.302 - addition - outgoing network id */
#ifdef LSPV2_4      
                  ((DEntry *)assoCb->actnCb[i].data)->outNwId = 
                                                       addrMap->outNwId; 
#endif /* LSPV2_4 */      
                  ((DEntry *)assoCb->actnCb[i].data)->numEntity =
                                                       addrMap->numEntity;
                  /* Initialize next entity in dEntry to zero */
                  ((DEntry *)assoCb->actnCb[i].data)->nextEntity = 0;

                  /* sp046.302 - deletion - nmbEntries deleted from SpActnCb */
                  /* assoCb->actnCb[i].nmbEntries++; */
                  assoCb->nmbEntries ++;
                  ((DEntry *)assoCb->actnCb[i].data)->replGt = addrMap->replGt;

                  /* sp027.302 - modification - use variable j instead of i */
                  for(j = 0; j < addrMap->numEntity; j++)
                     cmCopySpAddr (&addrMap->outAddr[j], 
                               &((DEntry *)assoCb->actnCb[i].data)->outAddr[j]);
                  RETVALUE (ROK);
               }
               else
                  RETVALUE (LSP_REASON_ALREADY_CFG);
               break;

            case SP_ACTN_GT_TO_PC:
               SPLOGERROR(ERRCLS_INT_PAR, ESP350, (ErrVal)addrMap->actn.type, \
                          "invalid action");
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);

            default :
               SPLOGERROR(ERRCLS_INT_PAR, ESP351, (ErrVal)addrMap->actn.type, \
                          "invalid action");
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);
         } /* switch () */
      } /* if */
   } /* for () */
   /* No matching action found */
   SPLOGERROR(ERRCLS_INT_PAR, ESP352, (ErrVal) 0, "no action found");
   RETVALUE(LCM_REASON_INVALID_PAR_VAL);
} /* spGttAdd */


/*
 * 
 * Fun : spGttDelete
 *
 * Desc : This function deletes a database entry. Before deleting the 
 *        database entry it will have to check if the 
 *        action(in the addr map) exists for the the rule.
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None.
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE S16 spGttDelete
(
SpAssoCb *assoCb,        /* Association Control Block */
SpAddrMapCfg *addrMap    /* Address */
)
#else
PRIVATE S16 spGttDelete (assoCb, addrMap)
SpAssoCb *assoCb;         /* Association Control Block */
SpAddrMapCfg *addrMap;    /* Address */
#endif
{
   U8 i;
   S16 ret;
   U16 len;
   DEntry *dEntry;
   SpKey key;

   TRC2(spGttDelete);

   for (i = 0; i < assoCb->nmbActns; i++)
   {
      if (assoCb->actnCb[i].actn.type == addrMap->actn.type)
      {
         /* sp045.302 - addition - since there are separate hash list for FIX
          * ASC and DES type actions, deleting it separately for each of these
          * action types.
          */
         switch (addrMap->actn.type)
         {
            case SP_ACTN_FIX :
               dEntry = NULLP;
               if ((addrMap->actn.param.range.startDigit == 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit == 
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else 
                  break;

               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &key, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);
               
               /* Get the DEntry from hash list */
               /* sp045.302 - addition - separate hashlist for FIX action */
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataFix,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal) addrMap->actn.type,
                             "spGttDelete: cmhashListFind failed for\
                             SP_ACTN_FIX action ");
                  RETVALUE(LSP_REASON_GTT_NOTPRSNT);
               }
               
               /* Delete this entry from the hash list */
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete((CmHashListCp *)assoCb->dataFix,
                                      (PTR) dEntry);

               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal)addrMap->actn.type, 
                             "spGttDelete: cmhashListDelete failed for\
                             SP_ACTN_FIX action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }

               /* Free the entry */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)dEntry, (Size)sizeof(DEntry));
               
               /* Delete successful */
               /* sp046.302 - addition - decrement the counter of FIX */
               assoCb->nmbEntriesFix--;
               assoCb->nmbEntries--;
               RETVALUE (ROK);
            break;
            
            case SP_ACTN_VAR_ASC :
               dEntry = NULLP;
               if ((addrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &key, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);
               
               /* Get the DEntry from hash list */
               /* sp045.302 - addition - separate hashlist for ASC action */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataAsc,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal) addrMap->actn.type,
                             "spGttDelete: cmhashListFind failed for\
                             SP_ACTN_VAR_ASC action ");
                  RETVALUE(LSP_REASON_GTT_NOTPRSNT);
               }
               
               /* Delete this entry from the hash list */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete((CmHashListCp *)assoCb->dataAsc, (PTR) dEntry);

               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal)addrMap->actn.type, 
                             "spGttDelete: cmhashListDelete failed for\
                             SP_ACTN_VAR_ASC action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }

               /* Free the entry */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)dEntry, (Size)sizeof(DEntry));
               
               /* Delete successful */
               /* sp046.302 - addition - decrement the counter of ASC */
               assoCb->nmbEntriesAsc--;
               assoCb->nmbEntries--;
               RETVALUE (ROK);
            break;
            
            case SP_ACTN_VAR_DES :
               dEntry = NULLP;
               if ((addrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (addrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* Make the key */
               len = makeKey(&addrMap->gt.addr, &key, 
                             addrMap->actn.param.range.startDigit,
                             addrMap->actn.param.range.endDigit);
               
               /* Get the DEntry from hash list */
               /* sp045.302 - addition - separate hashlist for ASC action */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataDes,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal) addrMap->actn.type,
                             "spGttDelete: cmhashListFind failed for\
                             SP_ACTN_VAR_DES action ");
                  RETVALUE(LSP_REASON_GTT_NOTPRSNT);
               }
               
               /* Delete this entry from the hash list */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete((CmHashListCp *)assoCb->dataDes,
                                      (PTR) dEntry);

               if (ret != ROK)
               {
                  SPLOGERROR(ERRCLS_INT_PAR, ESPXXX, 
                             (ErrVal)addrMap->actn.type, 
                             "spGttDelete: cmhashListDelete failed for\
                             SP_ACTN_VAR_DES action");
                  RETVALUE(LCM_REASON_HASHING_FAILED);
               }

               /* Free the entry */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)dEntry, (Size)sizeof(DEntry));
               
               /* Delete successful */
               /* sp046.302 - addition - decrement the counter of DES */
               assoCb->nmbEntriesDes--;
               assoCb->nmbEntries--;
               RETVALUE (ROK);
            break;
            
            case SP_ACTN_CONST:
            case SP_ACTN_INSERT_PC:
            case SP_ACTN_STRIP_PC:
               if (assoCb->actnCb[i].data == NULLP)
                  RETVALUE (LSP_REASON_GTT_NOTPRSNT);
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)assoCb->actnCb[i].data,
                        (Size)sizeof(DEntry));
               assoCb->actnCb[i].data = NULLP;
               /* sp046.302 - deletion - nmbEntries deleted from actnCb */
               assoCb->nmbEntries--;
               RETVALUE (ROK);
               
            case SP_ACTN_GT_TO_PC:
               SPLOGERROR(ERRCLS_INT_PAR, ESP355, (ErrVal)addrMap->actn.type, \
                          "cannot delete for this action");
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);
            default :
               SPLOGERROR(ERRCLS_INT_PAR, ESP356, (ErrVal)addrMap->actn.type, \
                          "wrong action configured");
               RETVALUE(LCM_REASON_INVALID_PAR_VAL);
         } /* switch () */
      } /* if */
   } /* for () */
   SPLOGERROR(ERRCLS_INT_PAR, ESP357, (ErrVal)addrMap->actn.type, \
              "no matching action found");
   RETVALUE(LCM_REASON_INVALID_PAR_VAL);
} /* spGttDelete */


/*
 * 
 * Fun : spGttDeInit
 *
 * Desc : The purpose of this function is to deallocate all teh memory 
 *        allocated for this Asociation control block. 
 *
 * Returns: ROK, RFAILED
 *
 * Notes: None
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE S16 spGttDeInit
(
SpAssoCb *assoCb /* Association Control Block */
)
#else
PRIVATE S16 spGttDeInit (assoCb)
SpAssoCb *assoCb;  /* Association Control Block */
#endif
{
   S16 i;
   S16 ret;
   DEntry *pDEntry; /* previous */
   DEntry *nDEntry; /* next */

   TRC2(spGttDeInit);
   
   /* sp004.302 - removal - conditional check on nmbEntries is removed, so
    * that buffer for hash list Cp can be de-allocated in case when only
    * associations have been configured and no any address map have been added
    */

   /* 
    * Find the data pointer if there is one for this asso 
    * We go through each action and free all the associated data 
    * After that we free the Hash List Cp
    */
   for (i = 0; i < assoCb->nmbActns; i++)
   {
      switch (assoCb->actnCb[i].actn.type)
      {
         case SP_ACTN_FIX :
            /* sp045.302 - modification - loop on actnCb's nmbEntries */
            while (assoCb->nmbEntriesFix)
            {
               pDEntry = NULLP;
               /* sp045.302 - addition - separate hash list for FIX action */
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListGetNext((CmHashListCp *)assoCb->dataFix
                                        , (PTR) pDEntry, (PTR *)&nDEntry); 
               if (ret != ROK)
                  break;
               
               /* Delete previous entry from the hash list */
               /* sp045.302 - addition - separate hash list for FIX action */
               /* sp046.302 - modification - dataFix is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete ((CmHashListCp *)assoCb->dataFix
                                       , (PTR)nDEntry);                     
               if (ret != ROK)
               {
                  /* sp046.302 - modification - dataFix is moved from SpActn to
                   * SpAssoCb.
                   */
                  SPLOGERROR(ERRCLS_INT_PAR, ESP358, \
                             (ErrVal)assoCb->dataFix, \
                             "spGttDeInit: cmhashListDelete failed for FIX\
                             action");
                  RETVALUE(RFAILED);
               }

               /* Release the memory */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)nDEntry, (Size)sizeof(DEntry));
               
               assoCb->nmbEntries--;
               /* sp046.302 - addition - decrement the counter of FIX */
               assoCb->nmbEntriesFix--;
            } /* while () */
            if (assoCb->nmbEntriesFix)
            {
               /* Something has gone wrong */
               SPLOGERROR(ERRCLS_INT_PAR, ESP359, (ErrVal) 0, \
                          "spGttDeInit: assoCb nmbEntries for the FIX action\
                          type FIX is not zero");
               RETVALUE(RFAILED);
            }
            break; 

         case SP_ACTN_VAR_ASC :
            while (assoCb->nmbEntriesAsc)
            {
               pDEntry = NULLP;
               /* sp045.302 - addition - separate hash list for ASC action */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListGetNext((CmHashListCp *)assoCb->dataAsc
                                        , (PTR) pDEntry, (PTR *)&nDEntry); 
               if (ret != ROK)
                  break;
               
               /* Delete previous entry from the hash list */
               /* sp045.302 - addition - separate hash list for ASC action */
               /* sp046.302 - modification - dataAsc is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete 
                         ((CmHashListCp *)assoCb->dataAsc , (PTR)nDEntry);                     
               if (ret != ROK)
               {
                  /* sp046.302 - modification - dataAsc is moved from SpActn to
                   * SpAssoCb.
                   */
                  SPLOGERROR(ERRCLS_INT_PAR, ESP358, \
                             (ErrVal)assoCb->dataAsc, \
                             "spGttDeInit: cmhashListDelete failed");
                  RETVALUE(RFAILED);
               }

               /* Release the memory */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)nDEntry, (Size)sizeof(DEntry));
               
               assoCb->nmbEntries--;
               /* sp046.302 - addition - decrement the count */
               assoCb->nmbEntriesAsc--;
            } /* while () */
            /* sp046.302 - modification - check if all the entries of ASC are 
             * deleted
             */
            if (assoCb->nmbEntriesAsc)
            {
               /* Something has gone wrong */
               SPLOGERROR(ERRCLS_INT_PAR, ESP359, (ErrVal) 0, \
                          "spGttDeInit: assoCb nmeEntries for VAR_ASC is not\
                          zero");
               RETVALUE(RFAILED);
            }
            break; 
            
         case SP_ACTN_VAR_DES :
            /* 
             * Since we have a single database we just delete the whole thing 
             * Basically we dont do the freeing per action.
             */
            /* sp004.302 - modification - forever while loop is modified
             * to execute only upto number of entries configured.
             */
            while (assoCb->nmbEntriesDes) 
            {
               pDEntry = NULLP;
               /* sp045.302 - addition - separate hash list for DES action */
               /* sp046.302 - modification - dataDes is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListGetNext((CmHashListCp *)assoCb->dataDes
                                        , (PTR) pDEntry, (PTR *)&nDEntry); 
               if (ret != ROK)
                  break;
               
               /* Delete previous entry from the hash list */
               /* sp045.302 - addition - separate hash list for DES action */
               /* sp046.302 - modification - dataDes is moved from SpActn to
                * SpAssoCb.
                */
               ret = cmHashListDelete ((CmHashListCp *)assoCb->dataDes
                                        , (PTR)nDEntry);                     
               if (ret != ROK)
               {
                  /* sp046.302 - modification - dataAsc is moved from SpActn to
                   * SpAssoCb.
                   */
                  SPLOGERROR(ERRCLS_INT_PAR, ESP358, \
                             (ErrVal)assoCb->dataDes, \
                             "spGttDeInit: cmhashListDelete failed for DES\
                             action");
                  RETVALUE(RFAILED);
               }

               /* Release the memory */
               SPutSBuf(assoCb->region, assoCb->pool, 
                        (Data *)nDEntry, (Size)sizeof(DEntry));
               
               assoCb->nmbEntries--;
               /* sp046.302 - addition - decrement the counter */
               assoCb->nmbEntriesDes--;
            } /* while () */

            /* sp046.302 - modification - check if all the entries of DES are 
             * deleted
             */
            if (assoCb->nmbEntriesDes)
            {
               /* Something has gone wrong */
               SPLOGERROR(ERRCLS_INT_PAR, ESP359, (ErrVal) 0, \
                          "spGttDeInit: assoCb nmbEntries for action type\
                          VAR_DES is not zero");
               RETVALUE(RFAILED);
            }
            break; 

         case SP_ACTN_CONST:
         case SP_ACTN_INSERT_PC:
         case SP_ACTN_STRIP_PC:
            if (assoCb->actnCb[i].data == NULLP)
               break;
            SPutSBuf(assoCb->region, assoCb->pool, 
                     (Data *)assoCb->actnCb[i].data,
                     (Size)sizeof(DEntry));
            assoCb->actnCb[i].data = NULLP;
            /* sp046.302 - deletion - nmbEntries deleted from SpActnCb */
            /* sp004.302 - addition - decrement nmbEntries if it is > zero */
            if (assoCb->nmbEntries)
               assoCb->nmbEntries--;
            break;

         case SP_ACTN_GT_TO_PC:
            break;

         default :
            RETVALUE (ROK);
      } /* switch () */
   }

   /* sp046.302 - modify - deinitializing the hash list after all the entries
    * in the hash list has been deleted
    */
   if ((CmHashListCp *)assoCb->dataFix != (CmHashListCp *)NULLP)
   {
      cmHashListDeinit ((CmHashListCp *)assoCb->dataFix);
      SPutSBuf (assoCb->region, assoCb->pool, 
                (Data *)assoCb->dataFix, sizeof(CmHashListCp));
      assoCb->dataFix = NULLP;
   }
   if ((CmHashListCp *)assoCb->dataAsc != (CmHashListCp *)NULLP)
   {
      cmHashListDeinit ((CmHashListCp *)assoCb->dataAsc);
      SPutSBuf (assoCb->region, assoCb->pool, 
                (Data *)assoCb->dataAsc, sizeof(CmHashListCp));
      assoCb->dataAsc = NULLP;
   }
   if ((CmHashListCp *)assoCb->dataDes != (CmHashListCp *)NULLP)
   {
      cmHashListDeinit ((CmHashListCp *)assoCb->dataDes);
      SPutSBuf (assoCb->region, assoCb->pool, 
                (Data *)assoCb->dataDes, sizeof(CmHashListCp));
      assoCb->dataDes = NULLP;
   }
   if (assoCb->nmbEntries)
   {
      /* Something has gone wrong */
      SPLOGERROR(ERRCLS_INT_PAR, ESP359, (ErrVal) 0, \
                 "assoCb nmbEntries is not zero");
      RETVALUE(RFAILED);
   }
   RETVALUE (ROK);
} /* spGttDeInit */

/*
 *  Utility functions
 */


/* 
 * Fun : getEndDigit
 *
 * Desc : Returns the end digit of the GT as correctly as possible.
 *
 * Ret: ROK, RFAILED
 *
 * Notes: None.
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PRIVATE U16 getEndDigit
(
SpAddr *inAddr       /* Incoming Address */
)
#else
PRIVATE U16 getEndDigit (inAddr)
SpAddr *inAddr;       /* Incoming Address */
#endif
{
   U16 endDigit;
   U8 adjFrmt;

   endDigit = 2*inAddr->gt.addr.length;
   
      adjFrmt = inAddr->gt.format;
   switch (adjFrmt)
   {
      case GTFRMT_1:
         if (inAddr->gt.gt.f1.oddEven == OE_EVEN)
            RETVALUE (endDigit); /* even */
         else
            RETVALUE (endDigit-1);
         break;
         
      case GTFRMT_2:
         /* Hope for the best */
         RETVALUE (endDigit);
         
      case GTFRMT_3:
         if(inAddr->gt.gt.f3.encSch == ES_BCDEVEN)
            RETVALUE (endDigit);
         if(inAddr->gt.gt.f3.encSch == ES_BCDODD)
            RETVALUE (endDigit-1);
         break;
               
      case GTFRMT_4:
         if(inAddr->gt.gt.f4.encSch == ES_BCDEVEN)
            RETVALUE (endDigit);
         if(inAddr->gt.gt.f4.encSch == ES_BCDODD)
            RETVALUE (endDigit-1);
         break;
   } /* switch () */
   RETVALUE (endDigit);
} /* getEndDigit */


/*
 *
 * Fun : makeKey
 *
 * Desc : Make a key for hash lookup. 
 *
 * Return : Void
 *
 * Notes: Very intelligent algo is used. :-)
 *
 * File: cp_bdy6.c
 *
 */

#ifdef ANSI
PRIVATE U16 makeKey
(
ShrtAddrs *addr,     /* incoming GT digits */
SpKey *key,          /* Key to be formed */
U8 startDigit,       /* Start Digit */
U8 endDigit          /* End Digit */
)
#else
PRIVATE U16 makeKey(addr, key, startDigit, endDigit)
ShrtAddrs *addr;     /* incoming GT digits */
SpKey *key;          /* Key to be formed */
U8 startDigit;       /* Start Digit */
U8 endDigit;         /* End Digit */
#endif
{
   U16 len;

   TRC2(makeKey);
   
   /* Make key zero just in case there is padding */
   cmZero ((U8 *)key, sizeof (SpKey));

   /* Assign start and end digits */
   key->startDigit = startDigit;
   key->endDigit = endDigit;
   
   /* 
    * To make things more clear
    * ((startDigit + 1)/2 - 1) = offset of startDigit in the array.
    * ((endDigit + 1)/2 - 1) = offset of endDigit in the array.
    */

   /* Copy the Address in the Key */
   key->addr.length = (endDigit + 1)/2 - (startDigit + 1)/2 + 1;
   cmCopy ((U8 *)&addr->strg[(startDigit + 1)/2 - 1], (U8 *)&key->addr.strg,
           key->addr.length);

   /* Mask the irrelevant nibble */
   key->addr.strg[0] &= ((startDigit & 0x01) ? 0xff : 0xf0);
   key->addr.strg[key->addr.length - 1] &= ((endDigit & 0x01) ? 0x0f : 0xff);

   /*
    * In case someone finds a problem in the intelligent keys 
    * this simple algo can be reverted to.
    * Hope fully this will never be the case.
    *
    * cmCopy ((U8 *)addr, (U8 *)&key->addr, sizeof (ShrtAddrs));
    * RETVALUE (sizeof(SpKey));
    */
   
   /* Return length of the key */
   len = (U16) (((U32)(Void *)&((struct spKey *)(NULLP))->addr.strg +
                             key->addr.length) - (U32)(Void *)(NULLP));
   RETVALUE(len);
} /* makeKey */


/*
*
*       Fun:    spPcToBcdAddr
*
*       Desc:   Converts Point code to BCD format address
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   cp_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 spPcToBcdAddr
(
Dpc pc,                  /* point code */
U8 pcLen,                /* length of point code */
ShrtAddrs *bcdBuf        /* buffer to return pc coded in bcd format */
)
#else
PUBLIC S16 spPcToBcdAddr(pc, pcLen, bcdBuf)
Dpc pc;                  /* point code */
U8 pcLen;                /* length of point code, DPC14, DPC16, DPC24 */
ShrtAddrs *bcdBuf;       /* buffer to return pc coded in bcd format */
#endif
{
   U16 i;                /* counter */
   U8 *dst;              /* ptr to output buffer */
   U8 strg[ADRLEN];      /* string to contain ascii stream of pc */
  
   TRC2(spPcToBcdAddr)

   /* initialize string */
   for (i = 0; i < ADRLEN; i++)
      strg[i] = 0;

   /* initialize dst ptr */
   dst = bcdBuf->strg;

   if ((pcLen == DPC14) || (pcLen == DPC16))
   {
      /* for two byte point code, there would be 5
       * ascii digits, convert pc digits into ascii stream
       */
      for (i = 0; i < 5; i++)
      {
         strg[4 - i] = pc % 10;
         pc = (pc - strg[4 - i]) / 10;
      }

      /* convert ascii stream PC into BCD format */
      *dst = strg[0];
      *dst++ |= (U8) (strg[1] << 4);
      *dst = strg[2];
      *dst++ |= (U8) (strg[3] << 4);
      *dst = strg[4];

      bcdBuf->length = 3;
   }
   else
   {
      /* for three byte point code, there would be 8
       * ascii digits. Convert pc digits into ascii stream
       */
      for (i = 0; i < 8; i++)
      {
         strg[7 - i] = pc % 10;
         pc = (pc - strg[7 - i]) / 10;
      }

      /* convert ascii stream PC into BCD format */
      dst = bcdBuf->strg;
      *dst = strg[0];
      *dst++ |= (U8) (strg[1] << 4);
      *dst = strg[2];
      *dst++ |= (U8) (strg[3] << 4);
      *dst = strg[4];
      *dst++ |= (U8) (strg[5] << 4);
      *dst = strg[6];
      *dst++ |= (U8) (strg[7] << 4);

      bcdBuf->length = 4;
   }
     
   RETVALUE(ROK);
} /* spPcToBcdAddr */


/*
*
*       Fun:    spBcdAddrToPc
*
*       Desc:   This function converts a fixed number of octets from the 
*               beginning of the bcd stream into point code. Number of octets
*               converted depends on the length of pc passed. If the length of
*               pc passed is DPC14 or DPC16, then first three bcd octets are
*               converted into point code else if DPC24 is passed then first
*               four bcd octets are converted into point code. The bcd stream
*               is left unchanged.
*
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   cp_bdy6.c
*
*/
#ifdef ANSI
PUBLIC S16 spBcdAddrToPc
(
ShrtAddrs *bcdBuf,        /* bcd digits */
U8 pcLen,                 /* length of point code: DPC14, DPC16, DPC24 */
Dpc *pc                   /* point code to be returned */
)
#else
PUBLIC S16 spBcdAddrToPc(bcdBuf, pcLen, pc)
ShrtAddrs *bcdBuf;        /* bcd digits */
U8 pcLen;                 /* length of point code: DPC14, DPC16, DPC24 */
Dpc *pc;                  /* point code to be returned */
#endif
{
   U16 i;                /* counter */
   U16 j;                /* counter */
   U8 tmp;               /* tmp buffer to unpack bcd octet */
   U8 strg[ADRLEN];      /* string to contain ascii stream of pc */
  
   TRC2(spBcdAddrToPc)

   /* initialize string */
   for (i = 0; i < ADRLEN; i++)
      strg[i] = 0;

   j = 0;
   *pc = 0;
   tmp = 0;

   if ((pcLen == DPC14) || (pcLen == DPC16))
   {
      /* first three octets are the point code */
      for (i = 0; i < 3; i++)
      {
         tmp = bcdBuf->strg[i];
         strg[j++] = tmp & 0x0f;
         strg[j++] = (tmp & 0xf0) >> 4;
      }

      /* convert ascii string to point code */
      *pc = strg[0] * 10000 + strg[1] * 1000 + strg[2] * 100 + strg[3] * 10 +
           strg[4];
   }
   else
   {
      /* first four octets are the point code */
      for (i = 0; i < 4; i++)
      {
         tmp = bcdBuf->strg[i];
         strg[j++] = tmp & 0x0f;
         strg[j++] = (tmp & 0xf0) >> 4;
      }

      /* convert ascii string to point code */
      *pc = strg[0] * 10000000 + strg[1] * 1000000 + strg[2] * 100000 +
           strg[3] * 10000 + strg[4] * 1000 + strg[5] * 100 + strg[6] * 10 +
           strg[7];
   }
     
   RETVALUE(ROK);
} /* spBcdAddrToPc */

/* sp001.302 - addition - new function to find address map in
 * configured list 
 */

/*
 * Fun: spMatchAddrMap
 *
 * Desc: This function finds if the exact match of the address map in the
 *       already configured list of address maps.
 *
 * Ret: ROK     - exact matching address map found in the  configured list.
 *      RFAILED - no matching address map found in the configured list.
 * Notes: none
 *
 * File: cp_bdy6.c
 *
 */
#ifdef ANSI
PUBLIC S16 spMatchAddrMap
(
SpAssoCb *assoCb,         /* matching association control block */
SpAddrMapCfg *spAddrMap   /* address map to be matched in configured list */
)
#else 
PUBLIC S16 spMatchAddrMap(assoCb, spAddrMap)
SpAssoCb *assoCb;         /* matching association control block */
SpAddrMapCfg *spAddrMap;  /* address map to be matched in configured list */
#endif
{
   U8 i;                  /* loop counter */
   U16 len;               /* key length */
   S16 ret;               /* return value */
   SpKey key;             /* key to find data entry */
   DEntry *dEntry;        /* data base entry */

   TRC2(spMatchAddrMap)

   for (i = 0; i < assoCb->nmbActns; i++)
   {
      if (assoCb->actnCb[i].actn.type == spAddrMap->actn.type)
      {
         /* sp045.302 - addition - search the hash list, depending on the action
          * type the corresponding hash list is used.
          */
         switch (spAddrMap->actn.type)
         {
            case SP_ACTN_FIX :
               dEntry = NULLP;
               if ((spAddrMap->actn.param.range.startDigit == 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (spAddrMap->actn.param.range.endDigit == 
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else 
                  break;

               /* Make the key */ 
               len = makeKey(&spAddrMap->gt.addr, &key, 
                             spAddrMap->actn.param.range.startDigit,
                             spAddrMap->actn.param.range.endDigit);
                  
               /* sp046.302 - modification - dataFix, pointer to hashlist is
                * moved from SpActnCb to SpAssoCb.
                */
               /* Get the DEntry from hash list */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataFix,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               RETVALUE(ret);

            /* sp045.302 - addition - search the hash list */
            case SP_ACTN_VAR_ASC :
               dEntry = NULLP;
               if ((spAddrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                     (spAddrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* Make the key */
               len = makeKey(&spAddrMap->gt.addr, &key, 
                             spAddrMap->actn.param.range.startDigit,
                             spAddrMap->actn.param.range.endDigit);
                  
               /* sp046.302 - modification - dataAsc, pointer to hashlist is
                * moved from SpActnCb to SpAssoCb.
                */
               /* Get the DEntry from hash list */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataAsc,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               RETVALUE(ret);

            /* sp045.302 - addition - search the hash list */
            case SP_ACTN_VAR_DES :
               dEntry = NULLP;
               if ((spAddrMap->actn.param.range.startDigit >= 
                    assoCb->actnCb[i].actn.param.range.startDigit) &&
                   (spAddrMap->actn.param.range.endDigit <=
                    assoCb->actnCb[i].actn.param.range.endDigit))
                  /* Do Nothing */;
               else
                  break;

               /* Make the key */
               len = makeKey(&spAddrMap->gt.addr, &key, 
                             spAddrMap->actn.param.range.startDigit,
                             spAddrMap->actn.param.range.endDigit);
                  
               /* sp046.302 - modification - dataDes, pointer to hashlist is
                * moved from SpActnCb to SpAssoCb.
                */
               /* Get the DEntry from hash list */
               ret = cmHashListFind((CmHashListCp *)assoCb->dataDes,
                                    (U8 *)&key, len, 0, (PTR *)&dEntry);
               RETVALUE(ret);
            
            case SP_ACTN_CONST:
            case SP_ACTN_INSERT_PC:
            case SP_ACTN_STRIP_PC:
               if (assoCb->actnCb[i].data != NULLP)
               {
                  /* address map is configured, return ok */
                  RETVALUE(ROK);
               }
               else
               {
                  /* address map not configured, return failure */
                  RETVALUE(RFAILED);
               }
               
            case SP_ACTN_GT_TO_PC:
               /* addres map is not configured for this action, so
                * return address map not found
                */
               RETVALUE(RFAILED);

            default:
               RETVALUE(RFAILED);
         } /* switch (spAddrMap->actn.type) */
      } /* if (assoCb->actnCb[i].actn.type == addrMap->actn.type) */
   } /* for (i = 0; i < assoCb->nmbActns; i++) */
   RETVALUE(RFAILED);
} /* spMatchAddrMap */


/********************************************************************30**
  
         End of file:     cp_bdy6.c@@/main/3_1 - Tue Jan 22 15:17:30 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      cp   1. Initial Release

             ---      ash  1. Proper reason fields retruned in failure 
                              cases for spGttAdd and spGttDelete functions
             ---      cp   2. Changed the behaviour of SP_ACTN_VAR_ASC and 
                              SP_ACTN_VAR_DES.
                           3. Fixed the spGttDelete function.
             ---      cp   4. Moved the portable functions to another 
                              file to allow ease of patching.
             ---      cp   5. Corrected spGttDelete for handling of 
                              SP_ACTN_CONST.
                           6. Corrected pointer subtraction in makeKey because 
                              mcc68k wasnt able to understand it.
             ---      vb   7. Clean up of the patches
             ---      cp   8. Typecasted assoCb->actnCb[i].data, because 
                              some c++ compilers are dumb.

/main/3      ---      cp   1. Mods for DFTHA
/main/3_1    ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
             sp001.302  rc   1. Sid correction
                             2. new function added: spMatchAddrMap()
             sp004.302  rc 1. Function spGttDeInit() is modified such that
                              buffer for hash list Cp can be de-allocated in
                              case when only associations have been configured
                              and no any address map have been added.
             sp018.302  rc 1. If ssn is missing in outAddr from GTT then take
                              ssn from inAddr to GTT.
             sp027.302  rc 1. Correcting loop counter variable.
             sp045.302  mc 1. Changing the prototype of spGttTrans, replacing
                              self pc with ptr to network Cb.
                              function return ptr to outgoing network CB is
                              network id of incoming and outgoing
                              network is different.
                           2. Instead of earlier one hash list, now three new
                              hash lists are introduced for FIX, ASC and DES
                              type action.
                           3. If outNwId is different from self network id
                              first check if its configured and then
                              return the ptr to netwrok CB of that network.
             sp046.302  mc 1. moved dataFix, dataAsc and dataDes from SpActnCb
                              to SpAssoCb since its a common pointer which
                              was being stored in different ActnCb. so related
                              changes in spGttDeInit, spGttInit, spGttTrans
                              spGttAdd and spGttDelete
*********************************************************************91*/
