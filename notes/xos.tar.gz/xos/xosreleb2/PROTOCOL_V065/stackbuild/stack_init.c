#ifdef __cplusplus
extern "C"{
#endif

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "ssi.h"
#include "gen.h"
#include "cm5.h"           /* Common timer */
#include "cm_ss7.h"        /* SS7 Specific */
#include "cm_llist.h"
#include "cm_hash.h"       /* common hash */
#include "cm_tpt.h"
#include "cm_err.h"        /* common error */
#include "cm_dns.h"        /* Common DNS library */
#include "cm_inet.h"
#include "mf.h"


/* header/extern include files (.x) */
#include "gen.x"
#include "ssi.x"
#include "cm_hash.x"
#include "cm_llist.x"
#include "cm_lib.x"
#include "cm5.x"
#include "cm_ss7.x"
#include "cm_tpt.x"
#include "cm_dns.x"        /* Common DNS library */
#include "cm_inet.x"
#include "mf.x"

#include "stack_init.h"

#ifdef HI
#include "hi_init.h"
#endif

#ifdef SB
#include "sb_init.h"
#endif

#if (defined(SP) || defined(IT))
#include "snt.x"           /* SCT interface */
#endif

#ifdef IT
#include "it_init.h"
#endif


#ifdef SP
#include "sp_init.h"
#endif

#ifdef ST
#include "st_init.h"
#endif


#ifdef MA
/*#include "lma.x"
#include "ma.x"*/
#include "ma_init.h"
#endif

/*#include "snt.x"*/

#ifdef SSI_WITH_CLI_ENABLED
#include "xosshell.h"
#include "clishell.h"
#endif /*SSI_WITH_CLI_ENABLED*/

#ifdef SO
#include "so_init.h"
#endif


PUBLIC U16 g_LayerCount = 0;
PUBLIC S32 g_slot_control = 0;

U8 g_ProtocolVersion[] = "Protocol_v0.65";

EXTERN S16 ssiInit(void);

EXTERN S16 sb_init_own(SSTskId sbTskId1);
EXTERN S16 mg_init_fun(SSTskId mgTskId);
EXTERN S16 si_init_fun(SSTskId siTskId);


#ifdef SSI_WITH_CLI_ENABLED
#ifndef SS_MT
EXTERN XS16 SRegInfoShow(Region region);
#else
EXTERN XS16 SRegInfoShow(Region region, U32 *availmem);
#endif
EXTERN XVOID CLI_locConsoleEntry();
EXTERN void PrintPrlVersion(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv);
EXTERN XVOID PrintRegionInfo(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv);
#endif



#ifdef ANSI
PUBLIC S16 sm_init_fun
(
SSTskId tskId
)
#else
PUBLIC S16 sm_init_fun(tskId)
SSTskId tskId;
#endif
{
	
	if (ROK != SRegTTsk(ENTSM, SM_INST_0, TTNORM, PRIOR0, smActvInit, smActvTsk))
	{
		RETVALUE(RFAILED);
	}

	if(tskId == 0)
	{
	    if (SCreateSTsk(PRIOR0, &tskId) != ROK)
	    {
	         RETVALUE(RFAILED);
	    }
	}

	if (ROK != SAttachTTsk(ENTSM, SM_INST_0, tskId))
	{
		RETVALUE(RFAILED);
	}

	RETVALUE(ROK);
}




#ifdef ANSI
PUBLIC S16 tri_init_fun
(
Void
)
#else
PUBLIC S16 tri_init_fun(Void)
#endif
{
	PTR *func=NULLP;
	int params = 0;

	#ifdef CP_OAM_SUPPORT
	HANDLE hRet;
	#endif CP_OAM_SUPPORT

	SSTskId sysThreadId = 0;
	
    if (ROK != ssiInit())			/* start SSI */
    {
		printf("Start SSI FAILED!\n");

		RETVALUE(RFAILED);
    }

#ifdef SP
	if (SCreateSTsk((SSTskPrior)PRIOR0, &(sysThreadId)) != ROK)
    {
       RETVALUE(RFAILED);
    }
#endif
	
#ifdef SM    
    if (ROK != sm_init_fun(0))			/* start SM */
    {
		printf("Start SM FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
    
#ifdef HI
    if (ROK != hi_init_fun(0))			/* start TUCL */
    {
		printf("Start TUCL&SCTP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
	
#ifdef SB
    if (ROK != sb_init_own(0))			/* start SCTP */
    {
		printf("Start TUCL&SCTP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif	
    
#ifdef IT
    if (ROK != it_init_fun(0))			/* start M3UA */
    {
		printf("Start M3UA FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif	
    
#ifdef SP	
    if (ROK != sp_init_fun(sysThreadId))			/* start SCCP */
    {
		printf("Start SCCP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
   
#ifdef ST
    if (ROK != st_init_fun(sysThreadId))			/* start TCAP */
    {
		printf("Start TCAP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
    
#ifdef MA	
    if (ROK != ma_init_fun(sysThreadId))		/* start MAP */
    {
		printf("Start MAP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
    
#ifdef SO	
    if (ROK != sip_init_fun(0))		/* start SIP */
    {
		printf("Start SIP FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
    
#ifdef MG	
    if (ROK != mg_init_fun(0))		/* start SIP */
    {
		printf("Start H248 FAILED!\n");

		RETVALUE(RFAILED);
    }
#endif
    
#ifdef SI
	if (ROK != si_init_fun(0))		/* start SIP */
    {
		printf("Start ISUP FAILED!\n");

		RETVALUE(RFAILED);
    }

#endif

#ifdef SSI_WITH_CLI_ENABLED
{
	S32 retPrtl = 0;
	retPrtl = XOS_RegistCmdPrompt( SYSTEM_MODE, "prtl", "Э��ģʽ", "�޲���" );
	
	XOS_RegistCommand(retPrtl, PrintPrlVersion, "showversion", "print the protocol version", "no parameter" );
	XOS_RegistCommand(retPrtl,
		              PrintRegionInfo,
					  "showmemory",
					  "��ӡ�ڴ�������Ϣ����һ������������������������'?'",
					  "par1: ��Ҫ��ӡ��Region ID\r\n");
	
}  
#endif /*SSI_WITH_CLI_ENABLED*/
  
	RETVALUE(ROK);
}

#ifdef SSI_WITH_CLI_ENABLED
void PrintPrlVersion(CLI_ENV *pCliEnv, XS32 argc, XCHAR **ppArgv)
{
	if ( NULLP == pCliEnv )
   {
        XOS_CliExtPrintf(pCliEnv, "��ָ��Ϊ��ָ��!!!����λ��%s �ļ���%d ��\r\n",__FILE__, __LINE__ );
        RETVOID;
   }

    XOS_CliExtPrintf(pCliEnv, "protocol version is %s\r\n", g_ProtocolVersion);
	RETVOID;
}

XVOID PrintRegionInfo(CLI_ENV *pCliEnv, XS32 siArgc, XCHAR **ppArgv)
{
#ifdef SS_MT
    XU32    val;
#endif
	if (siArgc > 2)
	{
		printf("������������!\n");
		RETVOID;
	}
	
	if (atol(ppArgv[1]) < 0)
	{
		printf("��������!\n");
		RETVOID;
	}

#ifndef SS_MT
	SRegInfoShow(atol(ppArgv[1]));
#else
	SRegInfoShow(atol(ppArgv[1]), &val);
#endif
	RETVOID;
}

#endif /*SSI_WITH_CLI_ENABLED*/


#ifdef BUILD_TRI_EXE
#ifndef CP_OAM_SUPPORT
#ifdef SSI_WITH_CLI_ENABLED
XPUBLIC XS8 XOS_InfoReg(XVOID)
{
	return 0;
}
#endif
#endif /*CP_OAM_SUPPORT*/

#endif

PUBLIC S16 tst
(
Void
)
{
	RETVALUE(ROK);
}


PUBLIC S16 rdConQ
(
Data data
) 
{
   TRC2(rdConQ)

   RETVALUE(OK);

} /* end of rdConQ */


#ifdef BUILD_TRI_EXE
U32 g_isupUaModId;
void main(void)
{

    
	
#ifdef SSI_WITH_CLI_ENABLED
	if(XSUCC != XOS_Root())
	{
		return;
	}
#endif /*SSI_WITH_CLI_ENABLED*/

	if (ROK != tri_init_fun())			/* start STACK */
    {
		printf("Start STACK FAILED!\n");

		RETVOID;
    }	

	{
		#if 0
		/*test sip for SAG*/
		SuUserIntf userIntf;
		char localIp[] = "168.0.2.91";
		int i = sizeof(localIp);
		memset(&userIntf,0,sizeof(SuUserIntf));

		userIntf.listenPort = 5060;
		memcpy(userIntf.LocalIP,localIp,sizeof(localIp));
		suConfigureUa(&userIntf);
		#endif /* SO */
	}

#ifdef SSI_WITH_CLI_ENABLED
    CLI_locConsoleEntry();
#endif /*SSI_WITH_CLI_ENABLED*/

	return ;
	
}

void XosToFrameCallBack(U32 mid, Pst *pPst, void * pvBuf)
{
	return ;
}
#endif





#ifdef __cplusplus
}
#endif


