/***********************************

***********************************/
#ifndef _AMS_INIT_H_
#define _AMS_INIT_H_
#ifdef __cplusplus
extern "C"{
#endif

#define SM_INST_0			0
#define MA_INST_0			0

#ifdef __cplusplus
}
#endif
#endif /* _AMS_INIT_H_ */
