/********************************************************************16**

        (c) COPYRIGHT 1989-1999 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_queue.h"      /* queues */
#include "ss_msg.h"        /* messaging */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_strm.x"       /* streams */
#include "ss_msg.x"        /* messaging */
#include "vw_ss.x"         /* VxWorks SSI */

#if defined(SS_VW) && defined(SS_ZEROCOPY) 

PUBLIC  S16 tstZeroCopyTrans ARGS((Void));
#undef SS_DISPLAY /* enable/disable console display */

/* forward references */

PRIVATE S16 tstVWPoolInit ARGS((NET_POOL **pool));
PRIVATE U16 tstSSMsgCreate ARGS((Region region, Pool pool, Buffer **mBuf));
PRIVATE U16 tstVWMsgCreate ARGS((NET_POOL_ID pNetPool, M_BLK **ppMblk));
PRIVATE S16 tstGetMblkNum ARGS((M_BLK_ID pCur, register M_BLK_ID *ppPrv));
PRIVATE S16 tstAddMblkCl ARGS((NET_POOL_ID pNetPool, M_BLK_ID pMblk));
PRIVATE S16 tstSSMsgAdd ARGS((Buffer *mBuf));
PRIVATE S16 tstExhaustSSPool ARGS((Region region, Pool pool, Queue *mq, S32 mCnt));

#if defined(SS_DISPLAY)

EXTERN void netPoolShow ARGS((NET_POOL_ID pNetPool));
PRIVATE Void tstMsgShow ARGS((M_BLK_ID pMblk));

#else   /* SS_DISPLAY */

#define tstMsgShow(pMblk)
#define netPoolShow(pool)

#endif  /* SS_DISPLAY */

/* private variable declarations */

PRIVATE M_CL_CONFIG blkCfg;    /* network mBlk-clBlk pool configuration data */
PRIVATE CL_DESC     clCfg[] =  /* network cluster pool configuration table */
{
   /* 
   clSize         clNum   memArea   memSize
   ------         -----   -------  -------
   */
   {CL_SIZE_64,   13,     NULL,      0},
   {CL_SIZE_128,  14,     NULL,      0},
   {CL_SIZE_256,  15,     NULL,      0},
   {CL_SIZE_512,  16,     NULL,      0}
};


/*
 *
 *      Fun:   tstVWPoolInit  
 *
 *      Desc:  This function initializes the network pool
 *
 *      Ret:   ROK     - ok
 *             RFAILED - out of resources
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstVWPoolInit
(
NET_POOL **pool   /* location of pointer to network pool */
)
#else
PRIVATE S16 tstVWPoolInit(pool)
NET_POOL **pool;  /* location of pointer to network pool */
#endif
{
   int         i;         /* index into configuration table */
   int         num;       /* number of cluster description elements */

   TRC2(tstVWPoolInit)

   /* Allocate network pool control block */
   if ((*pool = (NET_POOL *) malloc(sizeof(NET_POOL))) == NULL)
      RETVALUE(RFAILED);

   /* initial values */
   blkCfg.clBlkNum = 0;
   blkCfg.memArea = NULL;
   num = NELEMENTS(clCfg);

   /* Calculate the memory size of all the clusters   */
   /* and allocate the memory for those clusters      */
   for (i = 0; i < num; i++)
   {
      clCfg[i].memSize = clCfg[i].clNum * (clCfg[i].clSize + sizeof(long));

      if (!clCfg[i].memSize) continue; /* skip zero allocation */

      clCfg[i].memArea = (char *) memalign(sizeof(long), clCfg[i].memSize);

      if (!clCfg[i].memArea)
         goto clean;      
#if 0
      printf("cluster pool=%d: size=%d mem_area=%p\n", i, clCfg[i].memSize, clCfg[i].memArea);
#endif
      /* as many clBlks as clusters */
      blkCfg.clBlkNum += clCfg[i].clNum;
   }

   blkCfg.mBlkNum = blkCfg.clBlkNum << 1; /* twice mBlks than clBlks */

   /* Calculate total memory for all mBlks and clBlks */
   blkCfg.memSize = (blkCfg.mBlkNum * (M_BLK_SZ + sizeof(long))) +
                      (blkCfg.clBlkNum * (CL_BLK_SZ + sizeof(long)));

   blkCfg.memArea = (char *) memalign(sizeof(long), blkCfg.memSize);
#if 0
   printf("mBlk-clBlk pool: size=%d mem_area=%p\n", blkCfg.memSize,blkCfg.memArea);
#endif
   if (!blkCfg.memArea)
      goto clean;

   /* Initialize network pool */
   if (netPoolInit(*pool, &blkCfg, clCfg, num, NULL) == ERROR)
   {
      free(blkCfg.memArea);
      goto clean;
   }

   RETVALUE(ROK);

clean:

   /* Free previously allocated memory */

   free(*pool);
   *pool = NULL;

   /* Check whether all subpools */
   if (i == num) i--;

   /* Free subpools */
   for (; i >= 0; i--)
      free(clCfg[i].memArea);

   RETVALUE(RFAILED);
} /* end of tstVWPoolInit */


/*
 *
 *      Fun:   tstSSMsgCreate 
 *
 *      Desc:  This function creates a STREAMS test message
 *             and filles in dummy payload
 *
 *      Ret:   ROK     - ok
 *             RFAILED - can not create test messsage 
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE U16 tstSSMsgCreate
(
Region   region,  /* region id */
Pool     pool,    /* pool id */
Buffer   **mBuf   /* location of pointer to message */
)
#else
PRIVATE U16 tstSSMsgCreate(region, pool, mBuf)
Region   region;  /* region id */
Pool     pool;    /* pool id */
Buffer   **mBuf;  /* location of pointer to message */
#endif
{
   PRIVATE Data data[] = { /* arbitrary payload */
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9,
                          0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9
                         };
   TRC2(tstSSMsgCreate)

   if (SGetMsg(region, pool, mBuf) != ROK)
   {
      *mBuf = NULLP;
      RETVALUE(RFAILED);
   }

   /* set some dummy payload */
   if (SAddPstMsgMult(data, (MsgLen) sizeof(data), *mBuf) != ROK)
   {
      SPutMsg(*mBuf);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of tstSSMsgCreate */


/*
 *
 *      Fun:   tstVWMsgCreate
 *
 *      Desc:  This function creates netBufLib test message  
 *             and filles in dummy payload
 *
 *      Ret:   ROK     - ok
 *             RFAILED - can not create test messsage 
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE U16 tstVWMsgCreate
(
NET_POOL_ID   pNetPool,   /* pointer to network pool */
M_BLK         **ppMblk    /* location of pointer to mBlk */
)
#else
PRIVATE U16 tstVWMsgCreate(pNetPool, ppMblk)
NET_POOL_ID   pNetPool;   /* pointer to network pool */
M_BLK         **ppMblk;   /* location of pointer to mBlk */
#endif
{
   register M_BLK_ID pMblk; /* pointer to mBlk */

   TRC2(tstVWMsgCreate)

   /* get mBlk */
   if ((pMblk = netMblkGet(pNetPool, M_DONTWAIT, MT_DATA)) == NULL)
   {
      *ppMblk = NULL;
      RETVALUE(RFAILED);
   }

   /* add clBlk-cluster construct to mBlk */
   if (netMblkClGet(pNetPool, pMblk, CL_SIZE_256, M_DONTWAIT, FALSE) != OK)
   {
      netMblkFree(pNetPool, pMblk);
      *ppMblk = NULL;
      RETVALUE(ROUTRES);
   }

   /* set message header */
   pMblk->mBlkHdr.mFlags |= M_PKTHDR;
   pMblk->mBlkHdr.mData = pMblk->pClBlk->clNode.pClBuf;
   /* and some dummy payload */
   pMblk->mBlkHdr.mLen = 200;
   pMblk->mBlkPktHdr.len = 200;
   memset(pMblk->mBlkHdr.mData, 5, 200);

#if 0
   printf("netBufLib message: mBlk=%p, clBlk=%p\n", pMblk, pMblk->pClBlk);   
#endif

   *ppMblk = pMblk;

   RETVALUE(ROK);
}  /* end of tstVWMsgCreate */


/*
 *
 *      Fun:   tstMsgShow  
 *
 *      Desc:  This function displays data content of netBufLib message
 *
 *      Ret:   None
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#if defined(SS_DISPLAY)

#ifdef ANSI
PRIVATE Void tstMsgShow
(
M_BLK_ID    pMblk  /* pointer to mBlk */
)
#else
PRIVATE Void tstMsgShow(pMblk) 
M_BLK_ID    pMblk; /* pointer to mBlk */
#endif
{
   #define LINE 20      /* consequtive octets per line */
   register char *data; /* pointer to payload octet */
   register int i;      /* loop counter */

   /* for all mBlks in the chain */
   while (pMblk) 
   {
      data = pMblk->mBlkHdr.mData;

      printf("\nmData:");

      /* dump the payload */
      for (i = 0; i < pMblk->mBlkHdr.mLen; i++, data++)
      {
         if (i % LINE == 0)
            printf("\n");

         printf("%02x ", *data);
      }

      printf("\n");
      pMblk = pMblk->mBlkHdr.mNext;
   }
}  /* end of tstMsgShow */

#endif /* SS_DISPLAY */

/*
 *
 *      Fun:   tstGetMblkNum
 *
 *      Desc:  This function gets number of mBlks and
 *             reference to the last mBlk in chain
 *
 *      Ret:   number of mBlks
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstGetMblkNum
(
M_BLK_ID          pCur,
register M_BLK_ID *ppPrv
)
#else
PRIVATE S16 tstGetMblkNum(pCur, ppPrv)
M_BLK_ID          pCur;
register M_BLK_ID *ppPrv;
#endif
{
   S16 cnt;      /* number of elements in chain */

   TRC2(tstGetMblkNum)

   cnt = 0;

   while (pCur)
   {
      cnt++;
      *ppPrv = pCur;
      pCur = pCur->mBlkHdr.mNext;
   }

   RETVALUE(cnt);
} /* end of tstGetMblkNum */


/*
 *
 *      Fun:   tstAddMblkCl
 *
 *      Desc:  This function adds more dummy data to existing 
 *             netBufLib message
 *
 *      Ret:   ROK     - ok
 *             RFAILED - out of mBlks 
 *             ROUTRES - out of clBlk-clusters 
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstAddMblkCl
(
NET_POOL_ID   pNetPool,   /* pointer to network pool */
M_BLK_ID      pMblk       /* pointer to mBlk */
)
#else
PRIVATE S16 tstAddMblkCl(pNetPool, pMblk)
NET_POOL_ID   pNetPool;   /* pointer to network pool */
M_BLK_ID      pMblk;      /* pointer to mBlk */
#endif
{
   M_BLK_ID mBlk;   /* temporary pointer to mBlk */

   TRC2(tstAddMblkCl)

   /* get mBlk */
   if ((mBlk = netMblkGet(pNetPool, M_DONTWAIT, MT_DATA)) == NULL)
      RETVALUE(RFAILED);

   /* add clBlk-cluster construct to mBlk */
   if (netMblkClGet(pNetPool, mBlk, CL_SIZE_256, M_DONTWAIT, FALSE) != OK)
   {
      netMblkFree(pNetPool, mBlk);
      RETVALUE(ROUTRES);
   }

   /* set message header */
   mBlk->mBlkHdr.mFlags |= M_PKTHDR;
   mBlk->mBlkHdr.mData = mBlk->pClBlk->clNode.pClBuf;
   /* and some dummy payload */
   mBlk->mBlkHdr.mLen = 200;
   mBlk->mBlkPktHdr.len = 200;
   memset(mBlk->mBlkHdr.mData, 7, 200);

   /* append triplet to chain */
   pMblk->mBlkHdr.mNext = mBlk;

   RETVALUE(ROK);
} /* end of tstAddMblkCl */


#if 0 /* for the moment this is not needed */


/*
 *
 *      Fun:   tstExhaustMblkPool  
 *
 *      Desc:  This function exhaust network pool but specified
 *             mBlk elements in a queue
 *
 *      Ret:   
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstExhaustMblkPool
(
NET_POOL_ID pNetPool, /* pointer to network pool */
M_BLK_ID    pMblk,    /* pointer to mBlk queue */
S32         mCnt      /* count of free mBlks */
)
#else
PRIVATE S16 tstExhaustMblkPool(pNetPool, pMblk, mCnt) 
NET_POOL_ID pNetPool; /* pointer to network pool */
M_BLK_ID    pMblk;    /* pointer to mBlk queue head */
S32         mCnt;     /* count of free mBlks */
#endif
{
   M_BLK_ID curMblk;  /* pointer to current mBlk */
   M_BLK_ID nxtMblk;  /* pointer to next mBlk */

   TRC2(tstExhaustMblkPool)

   /* enqueue all mBlks in pool */
   while ((curMblk = netMblkGet(pNetPool, M_DONTWAIT, MT_DATA)) != NULL)
   {
      curMblk->mBlkHdr.mNext = pMblk->mBlkHdr.mNext;
      pMblk->mBlkHdr.mNext = curMblk;
   }

   /* free specified number of mBlks */
   curMblk = pMblk->mBlkHdr.mNext;

   while (mCnt > 0 && curMblk) 
   {
      nxtMblk = curMblk->mBlkHdr.mNext;
      netMblkFree(pNetPool, curMblk);
      curMblk = nxtMblk;
      mCnt--;
   }

   if (mCnt > 0)
      RETVALUE(RFAILED);

   RETVALUE(ROK);
} /* end of tstExhaustMblkPool */


/*
 *
 *      Fun:   tstExhaustClblkPool  
 *
 *      Desc:  This function exhaust network pool but specified
 *             number of clBlks in a queue
 *
 *      Ret:   
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstExhaustClblkPool
(
NET_POOL_ID pNetPool, /* pointer to network pool */
CL_BLK_ID   pClBlk,   /* pointer to clBlk queue */
S32         clCnt     /* count of free clBlks */
)
#else
PRIVATE S16 tstExhaustClblkPool(pNetPool, pClBlk, clCnt) 
NET_POOL_ID pNetPool; /* pointer to network pool */
CL_BLK_ID   pClBlk;   /* pointer to clBlk queue head */
S32         clCnt;    /* count of free clBlks */
#endif
{
   CL_BLK_ID curClBlk; /* pointer to current tclBlk */
   CL_BLK_ID nxtClBlk; /* pointer to next clBlk */

   TRC2(tstExhaustClblkPool)

   /* enqueue all clBlks in pool */
   while ((curClBlk = netClBlkGet(pNetPool, M_DONTWAIT)) != NULL)
   {
      curClBlk->clNode.pClBlkNext = pClBlk->clNode.pClBlkNext;
      pClBlk->clNode.pClBlkNext = curClBlk;
   }

   /* free specified number of clBlks */
   curClBlk = pClBlk->clNode.pClBlkNext;

   while (clCnt > 0 && curClBlk) 
   {
      nxtClBlk = curClBlk->clNode.pClBlkNext;
      netClBlkFree(pNetPool, curClBlk);
      curClBlk = nxtClBlk;
      clCnt--;
   }

   if (clCnt > 0)
      RETVALUE(RFAILED);

   RETVALUE(ROK);
} /* end of tstExhaustClblkPool */

#endif /* for the moment this is not needed */

/*
 *
 *      Fun:   tstExhaustSSPool  
 *
 *      Desc:  This function exhaust SSI pool/heap but specified
 *             number of message headers and dynamic buffers
 *
 *      Ret:   
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstExhaustSSPool
(
Region region, /* region id */
Pool   pool,   /* pool id */
Queue  *mq,    /* pointer to message header queue */
S32    mCnt    /* count of free mblk-dblk pairs */
)
#else
PRIVATE S16 tstExhaustSSPool(region, pool, mq, mCnt) 
Region region; /* region id */
Pool   pool;   /* pool id */
Queue  *mq;    /* pointer to message queue */
S32    mCnt;   /* count of free mblk-dblk pairs */
#endif
{
   Buffer * dBuf;  /* pointer to dynamic buffer */
   Buffer * mBuf;  /* pointer to message header */
   S32      n;     /* counter */

   TRC2(tstExhaustSSPool)

   if (mCnt <= 0)
      RETVALUE(ROK);

   /* reserve N messages */
   for (n = 0; n < mCnt; n++)
   {
      if (SGetMsg(region, pool, &mBuf) != ROK)
      {
         (Void) SFlushQueue(mq);
         RETVALUE(RFAILED);
      }

      if (SGetDBuf(region, pool, &dBuf) != ROK)
      {
         (Void) SPutMsg(mBuf);
         (Void) SFlushQueue(mq);
         RETVALUE(RFAILED);
      }

      if (SUpdMsg(mBuf, dBuf, 0) != ROK)
      {
         (Void) SFlushQueue(mq);
         RETVALUE(RFAILED);
      }

      (Void) SQueueLast(mBuf, mq);
   }

   /* get message header */
   if (SGetMsg(region, pool, &mBuf) != ROK)
   {
      (Void) SFlushQueue(mq);
      RETVALUE(RFAILED);
   }

   /* enqueue message header */
   (Void) SQueueLast(mBuf, mq);
   n = 0;

   /* exhaust SSI pools */
   while (SGetDBuf(region, pool, &dBuf) == ROK)
   {
      /* add dynamic buffer to message */
      if (SUpdMsg(mBuf, dBuf, 0) != ROK)
      {
         (Void) SPutDBuf(region, pool, dBuf);
         (Void) SFlushQueue(mq);
         RETVALUE(RFAILED);
      }
      n++;
   }
#if 0
   printf("exhausted dynamic buffers num=%ld\n", n);
#endif
   /* free reserved messages */
   for (n = 0; n < mCnt; n++)
   {
      (Void) SDequeueFirst(&mBuf, mq);
      (Void) SPutMsg(mBuf);
   }

   RETVALUE(ROK);
} /* end of tstExhaustSSPool */


/*
 *
 *      Fun:   tstSSMsgAdd
 *
 *      Desc:  This function adds more dummy data to existing  
 *             STREAMS message
 *
 *      Ret:   ROK     - ok
 *             RFAILED - can not add data 
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#ifdef ANSI
PRIVATE S16 tstSSMsgAdd
(
Buffer *mBuf  /* location of pointer to message buffer */
)
#else
PRIVATE S16 tstSSMsgAdd(mBuf)
Buffer *mBuf; /* location of pointer to message buffer */
#endif
{
   PRIVATE Data data[] = { /* arbitrary payload */
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0,
                          0x9, 0x8, 0x7, 0x6, 0x5, 0x4, 0x3, 0x2, 0x1, 0x0
                         };
   TRC2(tstSSMsgAdd)

   if (!mBuf)
      RETVALUE(RFAILED);

   /* set some dummy payload */
   if (SAddPstMsgMult(data, (MsgLen) sizeof(data), mBuf) != ROK)
      RETVALUE(ROUTRES);

   RETVALUE(ROK);
} /* end of tstSSMsgAdd */


/*
 *
 *      Fun:   tstZeroCopyTrans
 *
 *      Desc:  This is an entry point to acceptance test
 *             for zero-copy transmission on VxWorks OS.
 *
 *      Ret:   test status
 *             ROK      - test passed
 *             RFAILED  - test failed
 *
 *      Notes: None
 *
 *      File:  ss_acc.c
 *
 */
#define POOLMAX 3      /* maximum number of network pools */
#define NUM_MBLK 3     /* number of mBlks per pool */
#define NUM_CLBLK 2    /* number of clBlks per */
#define NUM_MBUF 3     /* number of messages in SSI pool */

#ifdef ANSI
PUBLIC S16 tstZeroCopyTrans
(
Void
)
#else
PUBLIC S16 tstZeroCopyTrans()
#endif
{
#if 0 /* create pool only once */
   PRIVATE
   NET_POOL * pool[POOLMAX];      /* network pool table */
#else /* create pool on each reoccurrence */
   NET_POOL * pool[POOLMAX] = {}; /* network pool table */
#endif
   Buffer *   mBuf;   /* pointer to 1st message buffer */
   Buffer *   mBuf_;  /* pointer to 2nd message buffer */
   CL_BLK_ID  pClblk; /* pointer to clBlk */
   M_BLK_ID   pMblk;  /* pointer to 1st mBlk */
   M_BLK_ID   pMblk_; /* pointer to 2nd mBlk */
   Queue      mq;     /* message queue */
   U16        ret;    /* test return status */
   int        i;      /* test block counter */
   int        j;      /* test section counter */
   int        k;      /* loop counter */
   Data       data[] = "Dummy test data:" /* arbitrary payload */
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789"
                       "012345678901234567890123456789";
   TRC2(tstZeroCopyTrans)

   /* initial values  */
   i = 0;
   ret = RFAILED;
   /* initialize message queue */
   (Void) SInitQueue(&mq);

   /*
    * We use goto to skip the test sections as needed. We found this useful
    * during inclusion/exclusion of the acceptance test cases on rebuilds.
    */
   goto No_1;

No_1:

   /* setting A */

   /* create converting pool of N elements, N = { num mBlks + num clBlks } */
   if (pool[0] == NULL)
   {
      if (ssConvPoolInit(NUM_MBLK, NUM_CLBLK , &pool[0]) != ROK)
      {
         printf("error: ssConvPoolInit\n");
         goto clean1;
      }
#if 0
      printf("created pool=%p\n", pool[0]);
#endif

   }

   /* 1. Converting pool tests */

   i = 1;
#if defined(SS_DISPLAY)
   printf("%d. Converting pool tests\n", i); 
#endif

   /* 1.1. Basic tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Basic tests\n", j);
#endif

   /* N times */
   for (k = 0; k < 10; k++)
   {
      /* grab clBlk */
      if ((pClblk = netClBlkGet(pool[0], M_DONTWAIT)) == NULL)
      {
         printf("error: netClBlkGet: loop %d\n", k);
         goto clean1;
      }

      /* free clBlk */
      netClBlkFree(pool[0], pClblk);

      /* grab mBlk */
      if ((pMblk = netMblkGet(pool[0], M_DONTWAIT, MT_DATA)) == NULL)
      {
         printf("error: netMblkGet: loop %d\n", k);
         goto clean1;
      }

      /* free mBlk */
      netMblkFree(pool[0], pMblk);
   }

   /* 1.2. Invalid tests */

#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Invalid tests\n", ++j);
#endif

   goto No_1_3; /* this test raise exception */

   if (tstVWMsgCreate(pool[0], &pMblk) != ROUTRES)
   {
      printf("error: tstVWMsgCreate\n");
      goto clean1;
   }

No_1_3:

   /* 1.3. Dump converting pool */

#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Converting pool dump\n", ++j); 
#endif

   netPoolShow(pool[0]);

   goto No_2;

No_2:

   /* setting B */

   if (pool[1] == NULL)
   {
      /* create network pool */
      if (tstVWPoolInit(&pool[1]) != ROK)
      {
         printf("error: tstVWPoolInit\n");
         goto clean1;
      }
#if 0
      printf("created pool=%p\n", pool[1]);
#endif
   }

   /* 2. Network pool tests */

#if defined(SS_DISPLAY)
   printf("%d. Network pool tests\n", ++i); 
#endif

   /* 2.1. Basic tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Basic tests\n", j); 
#endif

   if (tstVWMsgCreate(pool[1], &pMblk) != ROK)
   {
      printf("error: tstVWMsgCreate\n");
      goto clean1;
   }

   netMblkClChainFree(pMblk);
   pMblk = NULL;

   goto No_3;

No_3:

   /* setting C */

   /* exhaust SSI pools but N elements */
   /* N = { num message headers (mBufs) + dynamic buffers (dBufs) } */
   if (tstExhaustSSPool(SS_DFLT_REGION, 0, &mq, NUM_MBUF) != ROK)
   {
      printf("error: tstExhaustSSPool\n");
      goto clean1;
   }

   mBuf_ = NULLP;
   pMblk_ = NULL;

   /* 3. ssMsgConv2vw tests */

#if defined(SS_DISPLAY)
   printf("%d. ssMsgConv2vw tests\n", ++i); 
#endif
   
   /* 3.1. Input tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Input tests\n", j);
#endif

   /* create message header */
   if (SGetMsg(SS_DFLT_REGION, 0, &mBuf) != ROK)
   {
      printf("error: SGetMsg\n");
      goto clean1;
   }  

   /* this call shall fail - this is OK */
   if (ssMsgConv2vw(mBuf, &pMblk, pool[0]) == ROK)
   {
      printf("error: ssMsgConv2vw\n");
      netMblkClChainFree(pMblk);
      goto clean1;
   }

   /* free message header */
   (Void) SPutMsg(mBuf);

   /* 3.2. Functional tests */

#if defined(SS_DISPLAY)
   printf("%d.%d. Functional tests\n", i, ++j); 
#endif

   /* N times */
   for (k = 0; k < 10; k++)
   {
      /* create 1st STREAMS message */
      if (tstSSMsgCreate(SS_DFLT_REGION, 0, &mBuf) != ROK)
      {
         printf("error: tstSSMsgCreate: loop %d\n", k);
         goto clean2;
      }

      /* on odd loops duplicate (create 2nd) STREAMS message */
      /* for the reference count test */
      if (k % 2 == 1)
      {
         if (SAddMsgRef(mBuf, SS_DFLT_REGION, 0, &mBuf_) != ROK)
         {
            printf("error: SAddMsgRef: loop %d\n", k);

            (Void) SPutMsg(mBuf);
            goto clean2;
         }

         /* convert 2nd STREAMS message to netBufLib message */ 
         if (ssMsgConv2vw(mBuf_, &pMblk_, pool[0]) != ROK)
         {
            printf("error: ssMsgConv2vw: loop %d\n", k);

            (Void) SPutMsg(mBuf);
            (Void) SPutMsg(mBuf_);

            goto clean2;
         }

         /* free 2nd netBufLib message */
         if (pMblk_)
         {
            tstMsgShow(pMblk_); /* dump the message */

            netMblkClChainFree(pMblk_);
            pMblk_ = NULL;
            mBuf_ = NULLP;
         }
      }

      /* convert 1st STREAMS message to netBufLib message */ 
      if (ssMsgConv2vw(mBuf, &pMblk, pool[0]) != ROK)
      {
         printf("error: ssMsgConv2vw: loop %d\n", k);
         (Void) SPutMsg(mBuf);
         goto clean2;
      }

      /* free 1st netBufLib message */
      if (pMblk)
      {
         netMblkClChainFree(pMblk);
         pMblk = NULL;
         mBuf = NULLP;
      }
   }

   /* checking the pools n/a */

   goto No_4;

No_4:

   /* 4. ssMsgConv2ss tests */

#if defined(SS_DISPLAY)
   printf("%d. ssMsgConv2ss tests\n", ++i); 
#endif

   /* 4.1. Input tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Input tests\n", j); 
#endif

   /* 4.2. Functional tests */

#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. Functional tests\n", ++j); 
#endif

   /* N times */
   for (k = 0; k < 10; k++)
   {
      /* create 1st netBufLib message */ 
      if (tstVWMsgCreate(pool[1], &pMblk) != ROK)
      {
         printf("error: tstSSMsgCreate: loop %d\n", k);
         goto clean2;
      }

      /* on odd loops duplicate (create 2nd) netBufLib message */
      /* for the reference count test */
      if (k % 2 == 1)
      {
         if ((pMblk_ = netMblkChainDup(pool[1], pMblk, 0,
                                       M_COPYALL, M_DONTWAIT)) == NULL)
         {
            printf("error: netMblkChainDup: loop %d\n", k);
            netMblkClChainFree(pMblk);
            goto clean2;
         }

         /* convert 2nd netBufLib message to STREAMS message */ 
         if (ssMsgConv2ss(pMblk_, &mBuf_, SS_DFLT_REGION, 0) != ROK)
         {
            printf("error: ssMsgConv2ss: loop %d\n", k);

            netMblkClChainFree(pMblk);
            netMblkClChainFree(pMblk_);

            goto clean2;
         }

         /* manipulate STREAMS message and check for message validity */
         if (SAddPstMsgMult(data, (MsgLen) sizeof(data), mBuf_) != ROK)
         {
            printf("error: SAddPstMsgMult: loop %d\n", k);

            (Void) SPutMsg(mBuf_);
            goto clean2;
         }
#if defined(SS_DISPLAY)
#if 0
         /* dump the message */
         SPrntMsg(mBuf_, 0, 0);
#endif
#endif
         /* free 2nd STREAMS message */
         if (mBuf_)
         {
            (Void) SPutMsg(mBuf_);
            mBuf_ = NULLP;
            pMblk_ = NULL;
         }
      }

      /* convert 1st netBufLib message to STREAMS message */ 
      if (ssMsgConv2ss(pMblk, &mBuf, SS_DFLT_REGION, 0) != ROK)
      {
         printf("error: ssMsgConv2ss: loop %d\n", k);
         netMblkClChainFree(pMblk);
         goto clean2;
      }

      /* free 1st STREAMS message */
      if (mBuf)
      {
         (Void) SPutMsg(mBuf);
         mBuf = NULLP;
         pMblk = NULL;
      }
   }

   /* checking the pools n/a */

   goto No_5;

No_5:

   /* 5. Resource exhausted tests */

#if defined(SS_DISPLAY)
   printf("%d. Resource exhausted tests\n", ++i);
#endif

   /* This test shall indicate that conversion routines are capable of       */
   /* handling unsuccessful conversion due to the lack of mapping elements.  */
   /* This is  when either SSI or converting pools are without enough        */
   /* elements to complete the conversion sucessfuly.                        */
   /* The conversion routine shall release all taken elements (unwind the    */
   /* chain) and leave the original message intact.                          */

   /* 5.1. ssMsgConv2vw tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. ssMsgConv2vw tests\n", j);
#endif

   /* create STREAMS message composed of N mblk-dblk-data_buffer constructs  */
   /* where N = 2 + number of mBlk-clBlk constructs of converting pool (two  */
   /* more because the first mblk-dblk-data_buffer construct is dropped when */
   /* conversion succeed).                                                   */

   if (tstSSMsgCreate(SS_DFLT_REGION, 0, &mBuf) != ROK)
   {
      printf("error: tstSSMsgCreate\n");
      goto clean2;
   }

   /* N times */
   for (k = 0; k < (NUM_MBUF + 1); k++)
   {
      /* add some dummy payload */
      if (tstSSMsgAdd(mBuf) == ROUTRES)
      {
#if 0
         printf("tstSSMsgAdd: loop %d\n", k);
#endif
         break;
      }
   }

   /* convert STREAMS message to netBufLib message - shall fail. This is OK. */
   if (ssMsgConv2vw(mBuf, &pMblk, pool[0]) == ROK)
   {
      printf("error: ssMsgConv2vw\n");
      netMblkClChainFree(pMblk);
      goto clean2;
   }

#if defined(SS_DISPLAY)
   /* dump original message */
   SPrntMsg(mBuf, 0, 0);
#endif

   /* free STREAMS message */
   (Void) SPutMsg(mBuf);

   /* 5.2. ssMsgConv2ss tests */

   j = 1;
#if defined(SS_DISPLAY)
   printf("%d.", i);
   printf("%d. ssMsgConv2ss tests\n", j); 
#endif

   /* create netBufLib message composed of N mBlk-clBlk-cluster constructs   */
   /* where N = 1 + number of mblk-dblk-data_buffer constructs of SSI pool   */
   if (tstVWMsgCreate(pool[1], &pMblk) != ROK)
   {
      printf("error: tstVWMsgCreate\n");
      goto clean2;
   }

   /* N-1 times */
   for (k = 0; k < NUM_MBUF; k++)
   {
      (Void) tstGetMblkNum(pMblk, &pMblk_);

      if (tstAddMblkCl(pool[1], pMblk_) != ROK)
      {
         printf("error: tstAddMblkCl: loop %d\n", k);
         goto clean2;
      }
   }

   /* convert netBufLib message to STREAMS message - shall fail. This is OK. */
   if (ssMsgConv2ss(pMblk, &mBuf, SS_DFLT_REGION, 0) == ROK)
   {
      printf("error: ssMsgConv2ss\n");
      (Void) SPutMsg(mBuf);
      goto clean2;
   }

   /* dump original message */
   tstMsgShow(pMblk);

   /* free netBufLib message */
   netMblkClChainFree(pMblk);

   goto No_6;

No_6:

   /* toggle test status */
   ret = ROK;

clean2:   /* free queues */

   (Void) SFlushQueue(&mq);

clean1:

   /* Dump and free all pools */
#if defined(SS_DISPLAY)
   printf("%d. All pools dump\n", i + 1); 
#endif

   for (k = 0; k < POOLMAX; k++)
      if (pool[k])
         netPoolShow(pool[k]);

   /* free converting pool */
   if (pool[0] && (ssConvPoolFree(pool[0]) != ROK))
      printf("error: ssConvPoolFree\n");
   
   pool[0] = NULL;

   /* free network pool */
   if (pool[1])
   {
      (Void) netPoolDelete(pool[1]);

      free(pool[1]);

      free(blkCfg.memArea);

      for (k = 0; k < ((int)NELEMENTS(clCfg)) ; k++)
         free(clCfg[k].memArea);
   }

   pool[1] = NULL;

#if defined(SS_DISPLAY)
   printf("tstZeroCopyTrans: status=%s\n", ret == ROK ? "PASS" : "FAIL");
#else
   UNUSED(i);
   UNUSED(j);
#endif

   RETVALUE(ret);
} /* end of tstZeroCopyTrans */

#endif /* SS_VW && SS_ZEROCOPY */
