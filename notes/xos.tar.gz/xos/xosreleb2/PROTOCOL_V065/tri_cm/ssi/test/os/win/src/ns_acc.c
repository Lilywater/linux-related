/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services 
  
     Type:     C Source Code.
  
     Desc:     Positive Acceptance Tests
 
     File:     ns_acc.c

     Sid:      ns_acc.c 1.2  -  08/11/98 12:02:17
  
     Prg:      ag
  
*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lns.h"           /* NTSS layer mgmt */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "ns_acc.h"        /* acceptance test */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "lns.x"           /* NTSS layer mgmt */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "ns_acc.x"        /* acceptance test */


/* local defines */

/* local typedefs */
typedef struct tstCp
{
   S32 tskCnt[SS_MAX_TTSKS];    /* individual tsk count */
   SMtxId mtx;                  /* mutex */
   SCondId cond;                /* condition */
   S32 tstCnt;                  /* tst count */
}TstCp;

/* local externs */
EXTERN Bool perm2Completed;

  
/* forward references */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */
PRIVATE S32    tCnt;
PRIVATE TstCp  tCp;              /* test control point */
PRIVATE Region region;
PRIVATE Pool   pool;
PRIVATE Ticks  sTicks;           /* start ticks */
PRIVATE MsgLen mLen = 1;
PRIVATE Pool   sPool0;
PRIVATE S16 nsTstState;            /* test state */
PRIVATE U32 nsTstCnt;              /* test count */
PRIVATE Ticks sysTime1;            /* system time 1 */
PRIVATE S16 sysTimeCnt;            /* system time count */
PRIVATE Random value1;             /* random number */
PRIVATE S16 valueCnt;              /* random number count */
PRIVATE Pool sPool;                /* pool id */
PRIVATE S16  tmrTimeCnt[NMBTSKS];  /* timer time count */
PRIVATE Txt  prntBuf[PRNTSZE];     /* print buffer */

PRIVATE MsgLen rcvCount0[] = {0, 0, 0, 0};
PRIVATE MsgLen rcvCount1[] = {0, 0, 0, 0};
PRIVATE MsgLen rcvCount2[] = {0, 0, 0, 0};

PRIVATE U32 tsk0TmrCnt;            /* count of timer activations for task 0 */
PRIVATE U32 tsk1TmrCnt;            /* count of timer activations for task 1 */
PRIVATE U32 tsk2TmrCnt;            /* count of timer activations for task 2 */

PRIVATE U32 act0Cnt;
PRIVATE U32 act1Cnt;
PRIVATE U32 act2Cnt;

PRIVATE MsgLen msgLen[NMBPRIOR];

/* ns013.102 - Addition to call SRegInit */
EXTERN  S16 tstActvInit ARGS((Ent ent, Inst inst, Region region, Reason reason));

#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT
Route rte[5]; 
#endif
#endif /* end ns003.12 addition */

  
/*
 * support functions
 */


  
/*
*
*       Fun:   rdConQ
*
*       Desc:  Reads the console queue.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
  
#ifdef ANSI
PUBLIC S16 rdConQ
(
Data data
) 
#else
PUBLIC S16 rdConQ(data)
Data data;
#endif
{
   TRC2(rdConQ)

   /* check if control-c */
   if (data == 0x03)
#ifdef NU
      ExitProcess(1);
#endif

   RETVALUE(OK);

} /* end of rdConQ */

/*
*
*       Fun:   tst
*
*       Desc:  entry point for task registration
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
#ifdef ANSI
PUBLIC S16 tst
(
void
)
#else
PUBLIC S16 tst()
#endif
{
   S16  i;
   S16  j;
   S16  ret;
   Bool pass;

   TRC1(tst)

   SGetSysTime(&sTicks);
   SGetMutex(&tCp.mtx);         /* get control mutex */
   SGetCond(&tCp.cond);         /* get control condition */
   for(i = 0; i < SS_MAX_TTSKS;  i++)
      tCp.tskCnt[i] = 0;
   tCp.tstCnt = 0;
   region = SS_DFLT_REGION;
   pool   = SS_DFLT_POOL;


   nsTstState = 0;
   nsTstCnt = 0;
   sysTimeCnt = 0;
   valueCnt = 0;
   SGetSysTime(&sysTime1);
   SRandom(&value1);
   mLen = 0;
   for (i = 0; i < NMBTSKS; i++)
   {
      tmrTimeCnt[i] = 0;
   }

   /* This section manipulates the static memory */

   SGetSMem(DFLT_REGION, (Size) ((TSTTIMES + 1) * MAXSMEMLEN), &sPool0);   

   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TSTPERMENT, TSTINST0, tstActvInit);
   /* Register the activation address of the first test permanent task */
   SRegActvTsk(TSTPERMENT, TSTINST0, TTPERM, PRIOR3, tst0PermActvTsk);
 
   /* This section manipulates the static memory */
   SGetSMem(DFLT_REGION, (Size) ((TSTTIMES + 1) * MAXSMEMLEN), &sPool); 

#ifdef SM
   /* ns013.102 - Modification to use SRegInit */
   SRegInit(ENTSM, TSTINST0, tstActvInit);
   /* Register the activation address for the stack manager */
   SRegActvTsk(ENTSM, TSTINST0, TTNORM, PRIOR0, smActvTsk);
#endif /* SM */

   /* run negative tests */
   negativetst();

   for (j=0; j < NMBPRIOR; j++)
   {
      msgLen[j] = 0;
   }
   act0Cnt = 0;
   act1Cnt = 0;
   act2Cnt = 0;
   tsk0TmrCnt = 0;
   tsk1TmrCnt = 0;
   tsk2TmrCnt = 0;

   pass = TRUE;
   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TST0ENT, TSTINST0, tstActvInit);
   /* Register the activation address of the test task 0, instance 0 */
   ret = SRegActvTsk(TST0ENT, TSTINST0, TTNORM, PRIOR0, tst0ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }

   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TST1ENT, TSTINST0, tstActvInit);
   /* Register the activation address of the test task 1, instance 0 */
   ret = SRegActvTsk(TST1ENT, TSTINST0, TTNORM, PRIOR0, tst1ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }

   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TST2ENT, TSTINST0, tstActvInit);
   /* Register the activation address of the test task 2, instance 0 */
   ret = SRegActvTsk(TST2ENT, TSTINST0, TTNORM, PRIOR0, tst2ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT		 
   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TST6ENT, TSTINST0, tstActvInit);
   /* Register the activation address of the test task 3, instance 0 */
   ret = SRegActvTsk(TST6ENT, TSTINST0, TTNORM, PRIOR0, tst6ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
#endif 
#endif /* end ns003.12 addition */   

   ret = SRegTmr(TST0ENT, TSTINST0, TIMERES, tst0ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   
   ret = SRegTmr(TST1ENT, TSTINST0, TIMERES, tst1ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }

   ret = SRegTmr(TST2ENT, TSTINST0, TIMERES, tst2ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }

   nsPrintResult("tst()", pass);

   /* ns013.102 - Modification to use SRegInit */
   SRegInit(TSTPERMENT, TSTINST1, tstActvInit);
   /* Register the activation address of the second test permanent task */
   SRegActvTsk(TSTPERMENT, TSTINST1, TTPERM, PRIOR3, tst1PermActvTsk);

   RETVALUE(ROK);

} /* end of tst */

/* ns013.102 - Modification to use SRegInit */
/*                                     
*
*       Fun:   tstActvInit
*
*       Desc:  Sample function for test task  initialization.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tstActvInit
(
Ent ent,                    /* entity */
Inst inst,                  /* instance */
Region reg,                 /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 tstActvInit(ent, inst, reg, reason)
Ent ent;                    /* entity */
Inst inst;                  /* instance */
Region reg;                 /* region */
Reason reason;              /* reason */
#endif
{
   TRC2(tstActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(reg);
   UNUSED(reason);

   RETVALUE(ROK);

}


/*
*
*       Fun:   tst0PermActvTsk
*
*       Desc:  Sample function for test permanent task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst0PermActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst0PermActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   Queue q;
   Queue q1;
   MsgLen mlng;
   MsgLen mlng1;
   QLen qlng;
   QLen qlng1;
   QLen idx;
   QLen size;
   S16 ret1;
   S16 ret2;
   S16 i;
   S16 j;
   Buffer *bufPtr;
   Buffer *m[TSTTIMES];
   Buffer *n[TSTTIMES];
   Data uData;
   Data sData;
   S8 s8;
   S16 s16;
   S32 s32;
   U8 u8;
   U16 u16;
   U32 u32;
#ifndef WIN32
#ifndef UNIX
   VectNmb vectNmb;
   PIF vectFnct,vectFnct1;
#endif /* UNIX */
#endif /* WIN32 */
   DateTime dt;
   Ticks sysTime2;
   Status status;
   Random value2;
   Data *sBuf[TSTTIMES];
   Data *s;
   Region region;
   Pool pool;
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT
   Pst ourPst;
#endif
#endif /* end ns003.12 addition */
   TRC2(tst0PermActvTsk)

   if (mBuf != NULLP)
   {
      /* return message */
      SPutMsg(mBuf);
   }

   region = OWNREGION;
   pool = SP_POOL;

   sprintf(prntBuf, "ns_acc: NTSS tst count %lu \r", nsTstCnt);
   if (nsTstState == 0)
   {
      SDisplay(0,prntBuf);
   }

   /* perform test case */
   switch(nsTstState)
   {
      case 0:               /* test statistics */
      {
         ++nsTstCnt;

         mLen++;
         if (mLen > MAXMSGLEN)
            mLen = 1;

         nsTstState = 5;
         break;
      }
      case 5:
      {
         Data buf[200];
         MsgLen cnt;
         
         SGetMsg(region,pool,&m[0]);
         for (i = 0; i < 150; i++)
         {
            SAddPstMsg((Data)i, m[0]);
         }

         SCpyMsgFix(m[0], 0, 150, buf, &cnt);
         if (cnt != 150)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX,ERRZERO, "" );
         
         for (i = 0; i < 150; i++)
         {
            if (buf[i] != (Data)i)
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
            else
               buf[i] = 0;
         }
         
         SCpyMsgFix(m[0], 75, 75, buf, &cnt);

         if (cnt != 75)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );

         for (i = 0; i < 75; i++)
         {
            if (buf[i] != (Data)i + 75)
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
         }

         SCpyMsgFix(m[0], 149, 1, buf, &cnt);
         if (cnt != 1)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );

         for (i = 0; i < 1; i++)
         {
            if (buf[i] != (Data)i+149)
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
         }
         SPutMsg(m[0]);
         nsTstState = 10;
         break;
      }
      case 10:              /* queue initialization */
      {
         SInitQueue(&q);

         SFndLenQueue(&q, &qlng);
         if ( qlng != 0 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX,5, "" );
         if (((ret1 = SDequeueFirst(&bufPtr, &q)) != ROKDNA) || 
            ((ret2 = SDequeueLast(&bufPtr, &q)) != ROKDNA))    
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX,6, "" );
         idx = 0;
         if (((ret1 = SExamQueue(&bufPtr, &q, idx)) != ROKDNA) ||
            ((ret2 = SRemQueue(&bufPtr, &q, idx)) != ROKDNA))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX,7, "" );

         nsTstState = 11;
         break;
      }
      case 11:          /* queue and dequeue from front, find queue length */
      {
         SInitQueue(&q);

         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueFirst(m[i],&q);
            SFndLenQueue(&q, &qlng);
            if ( qlng != (QLen)(i+1) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX,8, "" );
         }
         for (i = (TSTTIMES-1); i >= 0; i--)
         {
            SDequeueFirst(&m[i], &q);
            SFndLenQueue(&q, &qlng);
            if ( qlng != (QLen)i )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX,9, "" );
            SPutMsg(m[i]);
         }
   
         nsTstState =12;
         break;
      }
      case 12:           /* queue and dequeue from back, find queue length */
      {
         SInitQueue(&q);

         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueLast(m[i],&q);
            SFndLenQueue(&q, &qlng);
            if ( qlng != (QLen)(i+1) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 10, "" );
         }
         for (i = (TSTTIMES-1); i >= 0; i--)
         {
            SDequeueLast(&m[i], &q);
            SFndLenQueue(&q, &qlng);
            if ( qlng != (QLen)i )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 11, "" );
            SPutMsg(m[i]);
         }

         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueFirst(m[i],&q);
         }
         for (i = 0; i < TSTTIMES; i++)
         {
            SDequeueLast(&n[i], &q);
            SFndLenQueue(&q,&qlng);
            if ( qlng != (QLen)(TSTTIMES-i-1) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 12, "" );
            SPutMsg(n[i]);
         }   

         nsTstState = 13;
         break;
      }
      case 13:              /* flush queue */
         SInitQueue(&q);

         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueLast(m[i],&q);
         }
         SFlushQueue(&q);
         SFndLenQueue(&q,&qlng);
         if ( qlng != 0 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 13, "" );

         if (((ret1 = SDequeueFirst(&bufPtr, &q)) != ROKDNA) || 
            ((ret2 = SDequeueLast(&bufPtr, &q)) != ROKDNA))    
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 14, "" );
         nsTstState = 14;
         break;

      case 14:              /* concatenate queue */
         SInitQueue(&q);
         SInitQueue(&q1);

         for ( i = 1;i <= 2;i++ )
         {
            SGetMsg(region,pool,&m[0]);
            SQueueLast(m[0],&q);
            SFndLenQueue(&q,&qlng);
           
            SGetMsg(region,pool,&n[0]);
            SQueueFirst(n[0],&q1);
            SFndLenQueue(&q1,&qlng1);
         
            size = qlng+qlng1;
            if ( i == Q1Q2 )
            {
               SCatQueue(&q,&q1,Q1Q2);
               if ( size != q.crntSize )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 15, "" );
               SDequeueFirst(&m[1],&q);
               if ( m[1] != m[0] )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 16, "" );
               SDequeueLast(&n[1],&q);
               if ( n[1] != n[0] )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 17, "" );
               SDequeueFirst(&n[2],&q1);
               if ( n[2] != NULLP )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 18, "" );
               SPutMsg(m[0]);
               SPutMsg(n[0]);
            }
            else
            {
               SCatQueue(&q,&q1,Q2Q1);
               if ( size != q.crntSize )
                 NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 19, "" );
               SDequeueFirst(&n[1],&q);
               if ( n[1] != n[0] )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 20, "" );
               SDequeueLast(&m[1],&q);
               if ( m[1] != m[0] )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 21, "" );
               SDequeueFirst(&n[2],&q1);
               if ( n[2] != NULLP )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 22, "" );
               SPutMsg(m[0]);
               SPutMsg(n[0]);
            }               
         }

         nsTstState = 15;
         break;

      case 15:              /* examine queue */
         SInitQueue(&q);

         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueLast(m[i],&q);
         }

         idx = 0;
         SExamQueue(&bufPtr, &q, idx);
         if ( bufPtr != m[idx] )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 23, "" );
         idx = TSTTIMES-1;
         SExamQueue(&bufPtr, &q, idx);
         if ( bufPtr != m[idx] )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 24, "" );

         for (i = 0; i < TSTTIMES; i++)
            SPutMsg(m[i]);            

         nsTstState = 16;
         break;
            
      case 16:              /* add/remove to/from queue */
         SInitQueue(&q);
         SGetMsg(region,pool,&n[0]);

         idx = 0;
         SAddQueue(n[0],&q,idx);
         SExamQueue(&n[1],&q,idx);
         SFndLenQueue(&q,&qlng);
         if ( (n[1] != n[0]) || (qlng != 1) )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 25, "" );
         SRemQueue(&n[2],&q,idx);
         SFndLenQueue(&q,&qlng);
         if ( (n[2] != n[0]) || (qlng != 0) )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 26, "" );
 
         for (i = 0; i < TSTTIMES; i++)
         {
            SGetMsg(region,pool,&m[i]);
            SQueueLast(m[i],&q);
         }

         idx = (QLen) TSTTIMES / 2;
         SAddQueue(n[0],&q,idx);
         SExamQueue(&n[1],&q,idx);
         SRemQueue(&n[2],&q,idx);
         if ( (n[1] != n[0]) || (n[2] != n[0]) )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 27, "" );
         
         idx = TSTTIMES;
         SAddQueue(n[0],&q,idx);
         SExamQueue(&n[1],&q,idx);
         SRemQueue(&n[2],&q,idx);
         if ( (n[1] != n[0]) || (n[2] != n[0]) )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 28, "" );
   
         for (i = 0; i < TSTTIMES; i++)
            SPutMsg(m[i]);            
         SPutMsg(n[0]);

         nsTstState = 20;
         break;

      case 20:              /* get message */
         SGetMsg(region,pool,&m[0]);

         SFndLenMsg(m[0],&mlng);
         if ( mlng != 0 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 29, "" );
         if (((ret1 = SRemPreMsg(&uData,m[0])) != ROKDNA) ||
            ((ret2 = SRemPstMsg(&uData,m[0])) != ROKDNA))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 30, "" );
         idx = 0;
         if (((ret1 = SExamMsg(&uData,m[0],(MsgLen)idx)) != ROKDNA) ||
            ((ret2 = SRepMsg(uData,m[0],(MsgLen)idx)) != ROKDNA))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 31, "" );
   
         SPutMsg(m[0]);   

         nsTstState = 21;
         break;

      case 21:              /* packing and unpacking */
         SGetMsg(region,pool,&m[0]);

         SPkS8((S8) 0x01,m[0]);
         SPkU8((U8) 0x02,m[0]);
         SPkS16((S16) 0x0304,m[0]);
         SPkU16((U16) 0x0506,m[0]);
         SPkS32((S32) 0x0708090aL,m[0]);
         SPkU32((U32) 0x0b0c0d0eL,m[0]);

         SUnpkU32(&u32,m[0]);
         if ( u32 != (U32) 0x0b0c0d0eL )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 32, "" );
         SUnpkS32(&s32,m[0]);
         if ( s32 != (S32) 0x0708090aL )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 33, "" );
         SUnpkU16(&u16,m[0]);
         if ( u16 != (U16) 0x0506 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 34, "" );
         SUnpkS16(&s16,m[0]);
         if ( s16 != (S16) 0x0304 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 35, "" );
         SUnpkU8(&u8,m[0]);
         if ( u8 != (U8) 0x02 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 36, "" );
         SUnpkS8(&s8,m[0]);
         if ( s8 != (S8) 0x01 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 37, "" );

         SPutMsg(m[0]);

         nsTstState = 22;
         break;

      case 22:              /* add pre message */
         SGetMsg(region,pool,&m[0]);
      
         for ( j = 0; j < mLen; j++ )
            SAddPreMsg((Data) j,m[0]);
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 38, "" );
         }

         for ( j = 0; j < mLen; j++ )
            SRepMsg((Data) j,m[0],(MsgLen) j);
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) j )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 39, "" );
         }

         SFndLenMsg(m[0],&mlng);
         if ( mlng != mLen )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 40, "" );

         for ( j = 0; j < mLen; j++ )
         {
            SRemPreMsg(&uData,m[0]); 
            SFndLenMsg(m[0],&mlng);
            if ( (uData != (Data) j) || (mlng != ((mLen - 1)-j)) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 41, "" );
         }
    
         SPutMsg(m[0]);

         nsTstState = 23;
         break;

      case 23:              /* add post message */
         SGetMsg(region,pool,&m[0]);
      
         for ( j = 0; j < mLen; j++ )
            SAddPstMsg((Data) j,m[0]);
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) j )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 42, "" );
         }
         for ( j = 0; j < mLen; j++ )
            SRepMsg((Data) j,m[0],(MsgLen) ((mLen - 1)-j));
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 43, "" );
         }

         SFndLenMsg(m[0],&mlng);
         if ( mlng != mLen )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 44, "" );
         for ( j = 0; j < mLen; j++ )
         {
            SRemPstMsg(&uData,m[0]); 
            SFndLenMsg(m[0],&mlng);
            if ( (uData != (Data) j) || (mlng != ((mLen - 1)-j)) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 45, "" );
         }
    
         SPutMsg(m[0]);

         nsTstState = 24;
         break;

      case 24:              /* initialize message */
         SGetMsg(region,pool,&m[0]);
      
         for ( j = 0; j < mLen; j++ )
            SAddPstMsg((Data) j,m[0]);
         SInitMsg(m[0]);
         SFndLenMsg(m[0],&mlng);
         if( mlng != 0 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 46, "" );
         
         if (((ret1 = SRemPreMsg(&uData,m[0])) != ROKDNA) ||
            ((ret2 = SRemPstMsg(&uData,m[0])) != ROKDNA))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 47, "" );
         idx = 0;
         if (((ret1 = SExamMsg(&uData,m[0],(MsgLen)idx)) != ROKDNA) ||
            ((ret2 = SRepMsg(uData,m[0],(MsgLen)idx)) != ROKDNA))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 48, "" );
   
         SPutMsg(m[0]);
               
         nsTstState = 25;
         break;
      
      case 25:              /* concatenate message */
         SGetMsg(region,pool,&m[0]);
         SGetMsg(region,pool,&m[1]);
         
         for ( j = 0; j < 2*TSTTIMES; j++ )
         {
            SAddPstMsg((Data) j,m[0]);
            SAddPreMsg((Data) j,m[1]);
         }
         
         for ( i = 0; i <= 1; i++ )
         {
            if ( i == M1M2 )
            {
               SCatMsg(m[0],m[1],i);
               SFndLenMsg(m[0],&mlng);
               SFndLenMsg(m[1],&mlng1);
               if ((mlng != 4*TSTTIMES) || (mlng1 != 0))
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 49, "" );
               SRemPstMsg(&uData,m[0]);
               if ( uData != (Data) 0 )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 50, "" );
               SAddPstMsg(uData,m[0]);
               if (((ret1 = SRemPreMsg(&uData,m[1])) != ROKDNA) ||
                  ((ret2 = SRemPstMsg(&uData,m[1])) != ROKDNA) || (uData != (Data) 0))                  
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 51, "" );
            }
            else
            {
               SCatMsg(m[1],m[0],i);
               SFndLenMsg(m[0],&mlng);
               SFndLenMsg(m[1],&mlng1);
               if ((mlng1 != 4*TSTTIMES) || (mlng != 0))
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 52, "" );
               SRemPstMsg(&uData,m[1]);
               if ( uData != (Data) 0 )
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 53, "" );
               SAddPstMsg(uData,m[1]);
               if (((ret1 = SRemPreMsg(&uData,m[0])) != ROKDNA) ||
                  ((ret2 = SRemPstMsg(&uData,m[0])) != ROKDNA) ||
                  (uData != (Data) 0))                  
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 54, "" );
            }
         }

         SPutMsg(m[0]);
         SPutMsg(m[1]);
                     
         nsTstState = 26;
         break;

      case 26:              /* segment message */
         SGetMsg(region,pool,&m[0]);

         for ( j = 0; j < 128; j++ )
            SAddPstMsg((Data) j,m[0]);

         idx = 0;
         SSegMsg(m[0],(MsgLen)idx,&m[1]); 
         for ( j = 0; j < 128; j++ )
         {
            SExamMsg(&uData,m[1],(MsgLen)j);
            if ( uData != (Data) j )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 55, "" );
         }
         if ((ret1 = SRepMsg(uData,m[0],(MsgLen)idx)) != ROKDNA)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 56, "" );

         SPutMsg(m[0]);
                    
         idx = 128;
         SSegMsg(m[1],(MsgLen)idx,&m[0]);
         SFndLenMsg(m[1],&mlng1);
         if ((m[0] != NULLP) || (mlng1 != (MsgLen)idx))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 57, "" );

         idx = 64;
         SSegMsg(m[1],(MsgLen)idx,&m[0]);
         SFndLenMsg(m[0],&mlng);
         SFndLenMsg(m[1],&mlng1);
         if ((mlng != (MsgLen)idx) || (mlng1 != (MsgLen)idx))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 58, "" );
         for ( j = 0; j < (S16)(128-idx); j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) (idx+j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 59, "" );
         }
         SCatMsg(m[1],m[0],M1M2);

         SPutMsg(m[0]);

         idx = 63;
         SSegMsg(m[1],(MsgLen)idx,&m[0]);
         SFndLenMsg(m[0],&mlng);
         SFndLenMsg(m[1],&mlng1);
         if ((mlng != (MsgLen)idx+2) || (mlng1 != (MsgLen)idx))
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 60, "" );
         for ( j = 0; j < (S16)(128-idx); j++)
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) (idx+j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 61, "" );
         }

         SPutMsg(m[0]);
         SPutMsg(m[1]);

         nsTstState = 27;
         break;
         
      case 27:              /* pack and unpack message */
         SGetMsg(region,pool,&m[0]);
         
         for ( j = 0, sData = 0; j < mLen; j++, sData++ )
            SPkS8((S8) sData,m[0]);
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&sData,m[0],(MsgLen) j);
            if ( sData != (Data) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 62, "" );
         }
         for ( j = 0; j < mLen; j++ )
         {
            SUnpkS8(&s8,m[0]);
            if ( s8 != (S8) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 63, "" );
         }

         SPutMsg(m[0]);

         nsTstState = 28;
         break;

      case 28:              /* pack and unpack message */
         SGetMsg(region,pool,&m[0]);
         
         for ( j = 0, uData = (Data) 0; j < mLen; j++, uData++ )
            SPkU8((U8) uData,m[0]);
         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data)((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 64, "" );
         }
         for ( j = 0; j < mLen; j++ )
         {        
            SUnpkU8(&uData,m[0]);
            if ( uData != (Data)((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 65, "" );
         }

         SPutMsg(m[0]);

         nsTstState = 29;
         break;

      case 29:              /* compress message */
         SGetMsg(region,pool,&m[0]);

         for ( j = 0; j < mLen; j++ )
            SAddPreMsg((Data) j,m[0]);

         SCompressMsg(m[0]);

         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[0],(MsgLen) j);
            if ( uData != (Data) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 66, "" );
         }

         SPutMsg(m[0]);

         nsTstState = 30;
         break;
        
      case 30:              /* copy message to message */
         SGetMsg(region,pool,&m[0]);
      
         for ( j = 0; j < mLen; j++ )
            SAddPreMsg((Data) j,m[0]);

         SCpyMsgMsg(m[0],region,pool,&m[1]);

         for ( j = 0; j < mLen; j++ )
         {
            SExamMsg(&uData,m[1],(MsgLen) j);
            if ( uData != (Data) ((mLen - 1)-j) )
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 67, "" );
         }

         SPutMsg(m[0]);
         SPutMsg(m[1]);

         nsTstState = 40;
         break;

      case 40:
#ifndef SS_NIC
         SDisInt();
         SHoldInt();
         SRelInt();
         SEnbInt();
#endif /* SS_NIC */
         nsTstState = 41;
         break;

      case 41:
#ifndef SS_NIC
         SDisInt();
         SDisInt();
         SDisInt();
         SEnbInt();
         SEnbInt();
         SEnbInt();
#endif /* SS_NIC */
         nsTstState = 42;
         break;

      case 42:
#ifndef WIN32
#ifndef UNIX
         vectNmb = 0;
         SGetVect(vectNmb, &vectFnct);
         SPutVect(vectNmb, vectFnct);
         SGetVect(vectNmb, &vectFnct1);
         if ( vectFnct1 != vectFnct )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 68, "" );
#endif /* UNIX */
#endif /* WIN32 */

         nsTstState = 50;
         break;
            
      case 50:    /* get system time */
         SGetSysTime(&sysTime2);
         if ( sysTime2 == sysTime1 )
         {
            /* ns013.102 - Modification fix test */
            if (sysTimeCnt >= 1000)
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 69, "" );
            else
               sysTimeCnt++;
         }
         else
         {
            SGetSysTime(&sysTime1);
            sysTimeCnt = 0;
         }

         nsTstState = 51;
         break;

      case 51:    /* check resources */
         SGetMsg(region,pool,&m[0]);

         SChkRes(region, pool, &status);
         if ( status == 0 )
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 70, "" );

         SPutMsg(m[0]);

         nsTstState = 52;
         break;

      case 52:     /* test random number generator */
         SRandom(&value2);
         if ( value2 == value1 )
         {
             if (valueCnt >= 100)
                NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 71, "" );
             else
                valueCnt++;
         }
         else
         {
            SRandom(&value1);
            valueCnt = 0;
         }

         nsTstState = 63;
         break;

      case 53:    /* set date time and get date time */

         if ((ret1 = SGetDateTime(&dt)) != ROK)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 72, "" );

         nsTstState = 60;
         break;

      case 60:     /* get even size static memory, alternating */

         for ( j = 0; j < TSTTIMES; j++ )
         {
            /* Get static buffer from static memory */
            SGetSBuf(region, sPool, &sBuf[j], (Size) MAXSMEMLEN);

            s = sBuf[j];
            for (i = 0; i < MAXSMEMLEN; i++)
            {
               *s = (Data) j;
               s++;
            }

            s = sBuf[j];
            for (i = 0; i < MAXSMEMLEN; i++)
            {
               if (*s != (Data) j)
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 73, "" );
               s++;
            }

            /* Put static buffer to static memory */
            SPutSBuf(region, sPool, sBuf[j], (Size) MAXSMEMLEN);
         }

         nsTstState = 61;
         break;

      case 61:     /* get even size static memory, consecutive */

         for ( j = 0; j < TSTTIMES; j++ )
         {
            /* Get static buffer from static memory */
            SGetSBuf(region, sPool, &sBuf[j], (Size) MAXSMEMLEN);

            s = sBuf[j];
            for (i = 0; i < MAXSMEMLEN; i++)
            {
               *s = (Data) j;
               s++;
            }
         }

         for ( j = 0; j < TSTTIMES; j++ )
         {
            s = sBuf[j];
            for (i = 0; i < MAXSMEMLEN; i++)
            {
               if (*s != (Data) j)
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 74, "" );
               s++;
            }

            /* Put static buffer to static memory */
            SPutSBuf(region, sPool, sBuf[j], (Size) MAXSMEMLEN);
         }

         nsTstState = 62;
         break;

      case 62:     /* get odd size static memory, alternating */

         for ( j = 0; j < TSTTIMES; j++ )
         {
            /* Get static buffer from static memory */
            SGetSBuf(region, sPool, &sBuf[j], (Size) (MAXSMEMLEN - 1));

            s = sBuf[j];
            for (i = 0; i < (MAXSMEMLEN - 1); i++)
            {
               *s = (Data) j;
               s++;
            }

            s = sBuf[j];
            for (i = 0; i < (MAXSMEMLEN - 1); i++)
            {
               if (*s != (Data) j)
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 75, "" );
               s++;
            }

            /* Put static buffer to static memory */
            SPutSBuf(region, sPool, sBuf[j], (Size) (MAXSMEMLEN - 1));
         }

         nsTstState = 63;
         break;

      case 63:     /* get odd size static memory, consecutive */

         for ( j = 0; j < TSTTIMES; j++ )
         {
            /* Get static buffer from static memory */
            SGetSBuf(region, sPool, &sBuf[j], (Size) (MAXSMEMLEN - 1));

            s = sBuf[j];
            for (i = 0; i < (MAXSMEMLEN - 1); i++)
            {
               *s = (Data) j;
               s++;
            }
         }

         for ( j = 0; j < TSTTIMES; j++ )
         {
            s = sBuf[j];
            for (i = 0; i < (MAXSMEMLEN - 1); i++)
            {
               if (*s != (Data) j)
                  NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 76, "" );
               s++;
            }

            /* Put static buffer to static memory */
            SPutSBuf(region, sPool, sBuf[j], (Size) (MAXSMEMLEN - 1));
         }

         nsTstState = 70;
         break;

      case 70:

         nsTstState = 71;
         break;

      case 71:
         nsTstState = 72;
         break;

      case 72:
         nsTstState = 73;
         break;

      case 73:
         if(osCp.procId != SFndProcId())
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 79, "" );

         nsTstState = 84;
         break;

      case 84:
         SInitQueue(&q);
         SGetMsg(region,pool,&m[0]);
         SGetMsg(region,pool,&m[1]);
         SQueueLast(m[0],&q);
         SQueueLast(m[1],&q);
         idx = 0;
         ret1 = SRemQueue(&bufPtr, &q, 0);
         if (ret1 != ROK)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 79, "" );
         if (bufPtr != m[0])
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 80, "" );
         SPutMsg(bufPtr);
         ret1 = SRemQueue(&bufPtr, &q, 0);
         if (ret1 != ROK)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 81, "" );
         if (bufPtr != m[1])
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 82, "" );
         SPutMsg(bufPtr);

         nsTstState = 85;
         break;

      case 85:
         SInitQueue(&q);
         SGetMsg(region,pool,&m[0]);
         SGetMsg(region,pool,&m[1]);
         SQueueLast(m[0],&q);
         SQueueLast(m[1],&q);
         idx = 0;
         ret1 = SRemQueue(&bufPtr, &q, 1);
         if (ret1 != ROK)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 83, "" );
         if (bufPtr != m[1])
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 84, "" );
         SPutMsg(bufPtr);
         ret1 = SRemQueue(&bufPtr, &q, 0);
         if (ret1 != ROK)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 85, "" );
         if (bufPtr != m[0])
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 86, "" );
         SPutMsg(bufPtr);

         nsTstState = 86;
         break;

      case 86:
         SGetMsg(region,pool,&m[0]);
         for ( j = 0; j < 6; j++ )
            SAddPstMsg((Data) j,m[0]);
         for ( j = 0; j < 3; j++ )
            SAddPreMsg((Data) j,m[0]);
         SSegMsg(m[0],8,&m[1]); 
         if(SFndLenMsg(m[0],&mlng) != ROK || mlng != 8)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 94, "" );
         if(SExamMsg(&uData,m[0],(MsgLen) 0) != ROK || uData != (Data) 2 ||
            SExamMsg(&uData,m[0],(MsgLen) 1) != ROK || uData != (Data) 1 ||
            SExamMsg(&uData,m[0],(MsgLen) 2) != ROK || uData != (Data) 0 ||
            SExamMsg(&uData,m[0],(MsgLen) 3) != ROK || uData != (Data) 0 ||
            SExamMsg(&uData,m[0],(MsgLen) 4) != ROK || uData != (Data) 1 ||
            SExamMsg(&uData,m[0],(MsgLen) 5) != ROK || uData != (Data) 2 ||
            SExamMsg(&uData,m[0],(MsgLen) 6) != ROK || uData != (Data) 3 ||
            SExamMsg(&uData,m[0],(MsgLen) 7) != ROK || uData != (Data) 4)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 95, "" );
         if(m[1] == NULLP)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 96, "" );
         SPutMsg(m[0]);
         SPutMsg(m[1]);

         nsTstState = 87;
         break;

      case 87:
         SGetMsg(region,pool,&m[0]);
         for ( j = 0; j < 15; j++ )
            SAddPreMsg((Data) j,m[0]);
         for ( j = 0; j < 23; j++ )
            SAddPstMsg((Data) j,m[0]);
         SSegMsg(m[0],28,&m[1]); 
         if(SFndLenMsg(m[0],&mlng) != ROK || mlng != 28)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 97, "" );
         if(SExamMsg(&uData,m[0],(MsgLen)  0) != ROK || uData != (Data) 14 ||
            SExamMsg(&uData,m[0],(MsgLen)  1) != ROK || uData != (Data) 13 ||
            SExamMsg(&uData,m[0],(MsgLen)  2) != ROK || uData != (Data) 12 ||
            SExamMsg(&uData,m[0],(MsgLen)  3) != ROK || uData != (Data) 11 ||
            SExamMsg(&uData,m[0],(MsgLen)  4) != ROK || uData != (Data) 10 ||
            SExamMsg(&uData,m[0],(MsgLen)  5) != ROK || uData != (Data)  9 ||
            SExamMsg(&uData,m[0],(MsgLen)  6) != ROK || uData != (Data)  8 ||
            SExamMsg(&uData,m[0],(MsgLen)  7) != ROK || uData != (Data)  7 ||
            SExamMsg(&uData,m[0],(MsgLen)  8) != ROK || uData != (Data)  6 ||
            SExamMsg(&uData,m[0],(MsgLen)  9) != ROK || uData != (Data)  5 ||
            SExamMsg(&uData,m[0],(MsgLen) 10) != ROK || uData != (Data)  4 ||
            SExamMsg(&uData,m[0],(MsgLen) 11) != ROK || uData != (Data)  3 ||
            SExamMsg(&uData,m[0],(MsgLen) 12) != ROK || uData != (Data)  2 ||
            SExamMsg(&uData,m[0],(MsgLen) 13) != ROK || uData != (Data)  1 ||
            SExamMsg(&uData,m[0],(MsgLen) 14) != ROK || uData != (Data)  0 ||
            SExamMsg(&uData,m[0],(MsgLen) 15) != ROK || uData != (Data)  0 ||
            SExamMsg(&uData,m[0],(MsgLen) 16) != ROK || uData != (Data)  1 ||
            SExamMsg(&uData,m[0],(MsgLen) 17) != ROK || uData != (Data)  2 ||
            SExamMsg(&uData,m[0],(MsgLen) 18) != ROK || uData != (Data)  3 ||
            SExamMsg(&uData,m[0],(MsgLen) 19) != ROK || uData != (Data)  4 ||
            SExamMsg(&uData,m[0],(MsgLen) 20) != ROK || uData != (Data)  5 ||
            SExamMsg(&uData,m[0],(MsgLen) 21) != ROK || uData != (Data)  6 ||
            SExamMsg(&uData,m[0],(MsgLen) 22) != ROK || uData != (Data)  7 ||
            SExamMsg(&uData,m[0],(MsgLen) 23) != ROK || uData != (Data)  8 ||
            SExamMsg(&uData,m[0],(MsgLen) 24) != ROK || uData != (Data)  9 ||
            SExamMsg(&uData,m[0],(MsgLen) 25) != ROK || uData != (Data) 10 ||
            SExamMsg(&uData,m[0],(MsgLen) 26) != ROK || uData != (Data) 11 ||
            SExamMsg(&uData,m[0],(MsgLen) 27) != ROK || uData != (Data) 12)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 98, "" );
         if(SFndLenMsg(m[1],&mlng) != ROK || mlng != 10)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 99, "" );
         if(SExamMsg(&uData,m[1],(MsgLen)  0) != ROK || uData != (Data) 13 ||
            SExamMsg(&uData,m[1],(MsgLen)  1) != ROK || uData != (Data) 14 ||
            SExamMsg(&uData,m[1],(MsgLen)  2) != ROK || uData != (Data) 15 ||
            SExamMsg(&uData,m[1],(MsgLen)  3) != ROK || uData != (Data) 16 ||
            SExamMsg(&uData,m[1],(MsgLen)  4) != ROK || uData != (Data) 17 ||
            SExamMsg(&uData,m[1],(MsgLen)  5) != ROK || uData != (Data) 18 ||
            SExamMsg(&uData,m[1],(MsgLen)  6) != ROK || uData != (Data) 19 ||
            SExamMsg(&uData,m[1],(MsgLen)  7) != ROK || uData != (Data) 20 ||
            SExamMsg(&uData,m[1],(MsgLen)  8) != ROK || uData != (Data) 21 ||
            SExamMsg(&uData,m[1],(MsgLen)  9) != ROK || uData != (Data) 22)
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 100, "" );
         SPutMsg(m[0]);
         SPutMsg(m[1]);

         nsTstState = 90;
         break;

      case 90:
      {
         PRIVATE U32 smState = SMSTASID;
         PRIVATE Bool zero   = NOZEROSTS;
         Pst smPst;
         NsMngmt mngmt;
         
         if (!(nsTstCnt % 25))
         {
            smPst.dstProcId = SFndProcId();
            smPst.srcProcId = SFndProcId();
            smPst.dstEnt = ENTNS;
            smPst.dstInst = 0;
            smPst.srcEnt = ENTSM;
            smPst.srcInst = 0;
            smPst.prior = PRIOR0;
            smPst.route = RTESPEC;
            smPst.region = DFLT_REGION;
            smPst.pool = DFLT_POOL;
            
#ifdef LCSMNSMILNS
            smPst.selector = 0;
#else
            smPst.selector = 1;    /* tightly coupled to SM */
#endif /* LCSMNSMILNS */
            
            nsZeroHdr(&mngmt.hdr);
            mngmt.hdr.entId.ent = ENTNS;
            mngmt.hdr.entId.inst = 0;
#ifdef NS_ENB_MGMT
            switch (smState)
            {
               case SMSTASID:
               {
                  mngmt.hdr.msgType = TSSTA;
                  mngmt.hdr.elmId.elmnt = STSID;
                  SmMiLnsStaReq(&smPst, &mngmt);
                  smState = SMSTASPOOL;
                  break;
               }
               case SMSTASPOOL:
               {
                  mngmt.hdr.elmId.elmnt = STSPOOL;
                  mngmt.hdr.msgType = TSSTA;
                  SmMiLnsStaReq(&smPst, &mngmt);
                  smState = SMSTADPOOL;
                  break;
               }
               case SMSTADPOOL:
               {
                  mngmt.hdr.elmId.elmnt = STDPOOL;
                  mngmt.hdr.msgType = TSSTA;
                  SmMiLnsStaReq(&smPst, &mngmt);
                  smState = SMSTADQ;               
                  break;
               }
               case SMSTADQ:
               {
                  PRIVATE prior = PRIOR0;
                  
                  mngmt.hdr.msgType = TSSTA;
                  mngmt.hdr.elmId.elmnt = STDQ;
                  mngmt.hdr.elmId.elmntInst1 = prior;
                  SmMiLnsStaReq(&smPst, &mngmt);

                  prior++;
                  if (prior == NMBPRIOR)
                  {
                     prior = PRIOR0;
                     smState = SMSTAENT;
                  }
                  break;
               }
               case SMSTAENT:
               {
                  PRIVATE U8 num = 0;

                  mngmt.hdr.msgType = TSSTA;
                  switch(num)
                  {
                     case 0:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST0ENT;
                        SmMiLnsStaReq(&smPst, &mngmt);
                        num++;
                        break;

                     case 1:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST1ENT;
                        SmMiLnsStaReq(&smPst, &mngmt);
                        num++;
                        break;
                     
                     case 2:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST2ENT;
                        SmMiLnsStaReq(&smPst, &mngmt);
                        num++;
                        break;
                     case 3:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = ENTSM;
                        SmMiLnsStaReq(&smPst, &mngmt);
                        num = 0;
                        smState = SMSTSLOOP;
                        break;
                  }

                  break;
               }
               case SMSTSLOOP:
               {
                  mngmt.hdr.msgType = TSTS;
                  mngmt.hdr.elmId.elmnt = STLOOP;
                  SmMiLnsStsReq(&smPst, zero, &mngmt);
                  smState = SMSTSENT;
                  break;
               }
               case SMSTSENT:
               {
                  PRIVATE U8 num = 0;

                  mngmt.hdr.msgType = TSTS;
                  switch(num)
                  {
                     case 0:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST0ENT;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST0;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num++;
                        break;
                     case 1:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST1ENT;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST0;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num++;
                        break;
                     case 2:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TST2ENT;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST0;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num++;
                        break;
                     case 3:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TSTPERMENT;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST0;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num++;
                        break;
                     case 4:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = TSTPERMENT;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST1;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num++;
                        break;
                     case 5:
                        mngmt.hdr.elmId.elmnt = STENT;
                        mngmt.hdr.elmId.elmntInst1 = ENTSM;
                        mngmt.hdr.elmId.elmntInst2 = TSTINST0;
                        SmMiLnsStsReq(&smPst, zero, &mngmt);
                        num = 0;
                        zero = (zero == ZEROSTS) ? NOZEROSTS : ZEROSTS;
                        smState = SMSTASID;
                        break;
                  }
                  break;
               }   
            }
#endif
         }
         
         nsTstState = 91;
         break;
      }
      case 91:
      {
         PRIVATE S16 cnt = 5;
         SRegTmr(TST1ENT, TSTINST0, cnt, tst1fnc);
         if( SDeregTmr(TST1ENT, TSTINST0, cnt, tst1fnc) != ROK )
         {
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
         }
         cnt = (cnt == 5)?20:5;
         nsTstState = 92;
         break;
      }

      case 92:
      {
#ifdef NS_ENB_MGMT
         PRIVATE U32 enable = FALSE;
         Pst lPst, smPst;
         NsMngmt cntrl;
         
         if (enable == FALSE)
         {
            lPst.dstProcId = SFndProcId();
            lPst.srcProcId = SFndProcId();
            lPst.dstEnt = ENTNS;
            lPst.dstInst = 0;
            lPst.srcEnt = ENTSM;
            lPst.srcInst = 0;
            lPst.prior = PRIOR0;
            lPst.route = RTESPEC;
            lPst.region = DFLT_REGION;
            lPst.pool = DFLT_POOL;
            
#ifdef LCSMNSMILNS
            lPst.selector = 0;
#else
            lPst.selector = 1;    /* tightly coupled to SM */
#endif /* LCSMNSMILNS */
            
            /* Fill smPst */
            smPst.dstProcId = SFndProcId();
            smPst.srcProcId = SFndProcId();
            smPst.dstEnt = ENTSM;
            smPst.dstInst = 0;
            smPst.srcEnt = ENTNS;
            smPst.srcInst = 0;
            smPst.prior = PRIOR0;
            smPst.route = RTESPEC;
            smPst.region = DFLT_REGION;
            smPst.pool = DFLT_POOL;
            
#ifdef LCSMNSMILNS
            smPst.selector = 0;
#else
            smPst.selector = 1;    /* tightly coupled to SM */
#endif /* LCSMNPMILNS */
            
            nsZeroHdr(&cntrl.hdr);
            cntrl.hdr.elmId.elmnt = STGEN;
            cntrl.hdr.msgType = TCNTRL;
            cntrl.t.cntrl.action = AENA;
            cntrl.t.cntrl.subAction = SAUSTA;
            cntrl.t.cntrl.smPst = smPst;
            SmMiLnsCntrlReq(&lPst, &cntrl);
            enable = TRUE;
         }
#endif /* NS_ENB_MGMT */         
#if 0 /* ns003.12 deletion */
			nsTstState = 0;
#endif /* end ns003.12 deletion */
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT		 
			nsTstState = 96;
#else
			nsTstState = 0;
#endif		 
#endif /* end ns003.12 addition */
         break;
      }
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT		 
   case 96:
        {
           /* Register the router function */
           /* ns013.102 - Modification to fix router task test cases */
           rte[0] = RTESHM;
           rte[1] = RTEFRST;
           SRegRtrTsk(rte, 2, tstRtrTsk);

           /* Get message */
           SGetMsg(region, pool, &m[0]);
  
           /* Add Data to end of message */
           for (i = 0; i < 10; i++)
              SAddPstMsg((Data) i, m[0]);

           /* Post the message to the first test task */
           /* ns013.102 - Modification to fix router task test cases */
           ourPst.event     = 0;               /* event */
           ourPst.prior     = 0;               /* priority */
           ourPst.route     = RTESHM;          /* route */
           ourPst.dstProcId = SFndProcId();    /* destination processor id */
           ourPst.dstEnt    = TST6ENT + 1;     /* destination entity */
           ourPst.dstInst   = TSTINST0 + 1;    /* destination instance */
           ourPst.srcProcId = SFndProcId();    /* source processor id */
           ourPst.srcEnt    = TSTPERMENT;      /* source entity */
           ourPst.srcInst   = TSTINST0;        /* source instance */
           if (SPstTsk(&ourPst, m[0]) != ROK)
           {
              SSLOGERROR( ERRCLS_DEBUG, ESSXXX, ERRZERO, "" );
           }
           /* ns013.102 - Modification to fix router task test cases */
           nsTstState = 97;
           break;
         }
         /* ns013.102 - Modification to fix router task test cases */
   case 97:
         /* Wait for test task 6 (tst6ActvTsk) to modify "nsTstState" */
         break;
   case 98:
        {
           /* De-Register a router function */
           SDeregRtrTsk(rte, 2);

           /* Get message */
           SGetMsg(region, pool, &m[0]);
  
           /* Add Data to end of message */
           for (i = 0; i < 10; i++)
              SAddPstMsg((Data) i, m[0]);

           /* Post the message to the first test task */
           /* ns013.102 - Modification to fix router task test cases */
           ourPst.event     = 0;               /* event */
           ourPst.prior     = 0;               /* priority */
           ourPst.route     = RTESPEC;         /* route */
           ourPst.dstProcId = SFndProcId();    /* destination processor id */
           ourPst.dstEnt    = TST6ENT;         /* destination entity */
           ourPst.dstInst   = TSTINST0;        /* destination instance */
           ourPst.srcProcId = SFndProcId();    /* source processor id */
           ourPst.srcEnt    = TSTPERMENT;      /* source entity */
           ourPst.srcInst   = TSTINST0;        /* source instance */
           if (SPstTsk(&ourPst, m[0]) != ROK)
           {
              SSLOGERROR( ERRCLS_DEBUG, ESSXXX, ERRZERO, "" );
           }
           nsTstState = 99;
         break;
        }
        /* ns013.102 - Modification to fix router task test cases */
   case 99:
        /* Wait for test task 6 (tst6ActvTsk) to modify "nsTstState" */
        break;
#endif
#endif /* end ns003.12 addition */
   }
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst0PermActvTsk */

#ifdef ANSI
PUBLIC S16 tst1fnc
(
void
)
#else
PUBLIC S16 tst1fnc()
#endif
{
   TRC2(tst1fnc)
   RETVALUE(ROK);
}

#ifdef ANSI
PUBLIC S16 tst2fnc
(
void
)
#else
PUBLIC S16 tst2fnc()
#endif
{
   TRC2(tst2fnc)
   RETVALUE(ROK);
}


/*
*
*       Fun:   nsZeroHdr
*
*       Desc: 
*
*       Ret:  
*
*       Notes: 
*
*       File:  ns_acc.c
*
*/
#ifdef ANSI
PRIVATE Void nsZeroHdr
(
Header *hdr
)
#else
PRIVATE Void nsZeroHdr(hdr)
Header *hdr;
#endif
{
   REG1 S32 i;
   REG2 Data *p;
   TRC2(nsZeroHdr)
   
   for (i =0, p = (Data*)hdr; i < sizeof(Header); i++ )
      *p++ = 0;
   RETVOID;
} /* end of nsZeroHdr */


/*                                     
*
*       Fun:   tst0ActvTsk
*
*       Desc:  Sample function for test task 0 activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst0ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst0ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 j;
   Data uData;
   MsgLen mlng;
   U32  count;
   Prior pr;
   
 
   TRC2(tst0ActvTsk)

   act0Cnt++;

   SUnpkU8(&pr, mBuf);
   rcvCount0[pr]++;
   if (rcvCount0[pr] > MAXMSGLEN)
      rcvCount0[pr] = 1;
   SUnpkU32(&count, mBuf);
   if (count != (U32)rcvCount0[pr])
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,0,"Missing messages (?)" );
      nsPrintResult("Testcase Unnumbered", FALSE);
   }
 
   SFndLenMsg(mBuf,&mlng);
   if ( mlng != rcvCount0[pr] )
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,1,"" );
  
   for ( j = 0; j < rcvCount0[pr]; j++ )
   {
      SExamMsg(&uData,mBuf,(MsgLen) j);
      if ( uData != (Data) j )
         NSLOGERROR( ERRCLS_DEBUG, ENSXXX,2, "" );
   }
   /* ns013.12 - Modification to fix router task test cases */
   if(pst->event != 0)
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,3, "" );

   SPkU32(count, mBuf);
   SPkU8(pr, mBuf);
 
   /* Post the message to the test task 1 */
   pst->event     = 1;               /* event */
   pst->prior     = pr;              /* priority */
   /* ns013.12 - Modification to fix router task test cases */
   pst->route     = RTESPEC;         /* route */
   pst->dstProcId = SFndProcId();    /* destination processor id */
   pst->dstEnt    = TST1ENT;         /* destination entity */
   pst->dstInst   = TSTINST0;        /* destination instance */
   pst->srcProcId = SFndProcId();    /* source processor id */
   pst->srcEnt    = TST0ENT;         /* source entity */
   pst->srcInst   = TSTINST0;        /* source instance */
   if (SPstTsk(pst, mBuf) != ROK)
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,ERRZERO, "" );
   }
         
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst0ActvTsk */



/*                                     
*
*       Fun:   tst1ActvTsk
*
*       Desc:  Sample function for test task 1 activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst1ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst1ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 j;
   Data uData;
   MsgLen mlng;
   U32  count;
   Prior pr;
 
   TRC2(tst1ActvTsk)
 
   act1Cnt++;

   SUnpkU8(&pr, mBuf);
   rcvCount1[pr]++;
   if (rcvCount1[pr] > MAXMSGLEN)
      rcvCount1[pr] = 1;
   SUnpkU32(&count, mBuf);
   if (count != (U32)rcvCount1[pr])
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,0,"Missing messages (?)" );
      nsPrintResult("Testcase Unnumbered", FALSE);
   }

   SFndLenMsg(mBuf,&mlng);
   if ( mlng != rcvCount1[pr] )
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,90, "" );
  
   for ( j = 0; j < rcvCount1[pr]; j++ )
   {
      SExamMsg(&uData,mBuf,(MsgLen) j);
      if ( uData != (Data) j )
         NSLOGERROR( ERRCLS_DEBUG, ENSXXX,91, "" );
   }
   /* ns013.12 - Modification to fix router task test cases */
   if(pst->event != 1)
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,92, "" );

   SPkU32(count, mBuf);
   SPkU8(pr, mBuf);
 
   /* Post the message to the test task 2 */
   pst->event     = 2;               /* event */
   pst->prior     = pr;               /* priority */
   /* ns013.12 - Modification to fix router task test cases */
   pst->route     = RTESPEC;         /* route */
   pst->dstProcId = SFndProcId();    /* destination processor id */
   pst->dstEnt    = TST2ENT;         /* destination entity */
   pst->dstInst   = TSTINST0;        /* destination instance */
   pst->srcProcId = SFndProcId();    /* source processor id */
   pst->srcEnt    = TST1ENT;         /* source entity */
   pst->srcInst   = TSTINST0;        /* source instance */
   if (SPstTsk(pst, mBuf) != ROK)
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
   }
         
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst1ActvTsk */


/*                                     
*
*       Fun:   tst2ActvTsk
*
*       Desc:  Sample function for first test task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst2ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst2ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   U32   count;
   Prior pr;
   S16   ret;
   TRC2(tst2ActvTsk)

   act2Cnt++;

#ifdef NU
   printf ("tst2ActvTsk: act0 = %u, act1 = %u, act2 = %u \n", act0Cnt, act1Cnt, 
            act2Cnt);
#endif /* NU */
#ifdef NK
   KdPrint (("tst2ActvTsk: act0 = %u, act1 = %u, act2 = %u \n", act0Cnt, 
              act1Cnt, act2Cnt));
#endif /* NK */
   SUnpkU8(&pr, mBuf);
   rcvCount2[pr]++;
   if (rcvCount2[pr] > MAXMSGLEN)
      rcvCount2[pr] = 1;
   SUnpkU32(&count, mBuf);
   if (count != (U32)rcvCount2[pr])
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,0,"Missing messages (?)" );
      nsPrintResult("Testcase Unnumbered", FALSE);
   }
 
   /* ns013.12 - Modification to fix router task test cases */
   if(pst->event != 2)
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, 93, "" );

   /* return received message to pool */
   ret = SPutMsg(mBuf);
   if (ret != ROK)
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX,0,"SPutMsg Failed");
   }

   /* Deregister the permanent tasks if all the test cases are executed */
   if (perm2Completed == TRUE)
   {
      SDeregInitTskTmr(TSTPERMENT, TSTINST2);
      perm2Completed = FALSE;
   }
 
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst2ActvTsk */
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT
/*                                     
*
*       Fun:   tst6ActvTsk
*
*       Desc:  Sample function for test route task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst6ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst6ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 j;
   Data uData;
   MsgLen mlng;

   TRC2(tst6ActvTsk)

   SFndLenMsg(mBuf,&mlng);
   /* ns013.102 - Modification to fix route task test cases */
   if ( (pst->route == RTESHM) || (pst->route == RTEFRST))
   {
  
     for ( j = 0; j < mlng; j++ )
     {
       SExamMsg(&uData,mBuf,(MsgLen) j);
       if ( uData != (Data) (mlng-j ))
          SSLOGERROR( ERRCLS_DEBUG, ESSXXX, ERRZERO, "" );
     }
     nsTstState = 98;
   }
   else
   {

     for ( j = 0; j < mlng; j++ )
     {
       SExamMsg(&uData,mBuf,(MsgLen) j);
       if ( uData != (Data) j )
          SSLOGERROR( ERRCLS_DEBUG, ESSXXX, ERRZERO, "" );
     }
     nsTstState = 0;
   }

   /* return received message to pool */
   SPutMsg(mBuf);
 
   /* pass test */
 
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst6ActvTsk */
#endif
#endif /* end ns003.12 */

/*                                     
*
*       Fun:   tst0ActvTmr
*
*       Desc:  Sample function for task 0 timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst0ActvTmr
(
void
)
#else
PUBLIC S16 tst0ActvTmr()
#endif
{
   TRC2(tst0ActvTmr)

   tsk0TmrCnt++;
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst0ActvTmr */

/*                                     
*
*       Fun:   tst1ActvTmr
*
*       Desc:  Sample function for task 1 timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst1ActvTmr
(
void
)
#else
PUBLIC S16 tst1ActvTmr()
#endif
{
   TRC2(tst1ActvTmr)

   tsk1TmrCnt++;

   SExitTsk();
   RETVALUE(ROK);

} /* end of tst1ActvTmr */


/*                                     
*
*       Fun:   tst2ActvTmr
*
*       Desc:  Sample function for first test timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst2ActvTmr
(
void
)
#else
PUBLIC S16 tst2ActvTmr()
#endif
{
   TRC2(tst2ActvTmr)

   tsk2TmrCnt++;

#ifdef NU
   printf("tst2ActvTmr:");
   printf("tmr1 = %d, tmr2 = %d, tmr3 = %d \n", tsk0TmrCnt, tsk1TmrCnt, tsk2TmrCnt);
#endif /* NU */
#ifdef NK
   KdPrint(("tst2ActvTmr:"));
   KdPrint(("tmr1 = %d, tmr2 = %d, tmr3 = %d \n", tsk0TmrCnt, tsk1TmrCnt, tsk2TmrCnt));
#endif /* NU */

   SExitTsk();
   RETVALUE(ROK);

} /* end of tst2ActvTmr */


/*
*
*       Fun:   tst1PermActvTsk
*
*       Desc:  Sample function for test permanent task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst1PermActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst1PermActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   PRIVATE Prior pr = 0;
   S16 ret;
   S16 i;
   static U16 cycles = 0;

   TRC2(tst1PermActvTsk)

   if (mBuf)
      SPutMsg(mBuf);

   /* Post a message for every 1000 cycles */
   cycles++;
   if (cycles > 1000)
   {
      cycles = 0;
   }
   else
   {
      RETVALUE(ROK);
   }
   
   ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
   if (ret != ROK)
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "Failed in SGetMsg" );
      SExitTsk();
      RETVALUE(RFAILED);
   }

   msgLen[pr]++;
   if (msgLen[pr] > MAXMSGLEN)
      msgLen[pr] = 1;

   /* Add Data to end of message */
   for (i = 0; i < msgLen[pr]; i++)
      SAddPstMsg((Data) i, mBuf);

   if (SPkU32(msgLen[pr], mBuf) != ROK)
   {
      nsPrintResult("tst1PermActvTsk: Failed in SPkU32", FALSE);
   }
   if (SPkU8(pr, mBuf) != ROK)
   {
      nsPrintResult("tst1PermActvTsk: Failed in SPkU8", FALSE);
   }


   /* Post the message to the first test task */
   pst->event     = 0;               /* event */
   pst->prior     = pr;              /* priority */
   /* ns013.102 - Modification to fix router task test cases */
   pst->route     = RTESPEC;         /* route */
   pst->dstProcId = SFndProcId();    /* destination processor id */
   pst->dstEnt    = TST0ENT;         /* destination entity */
   pst->dstInst   = TSTINST0;        /* destination instance */
   pst->srcProcId = SFndProcId();    /* source processor id */
   pst->srcEnt    = TSTPERMENT;      /* source entity */
   pst->srcInst   = TSTINST1;        /* source instance */
   if (SPstTsk(pst, mBuf) != ROK)
   {
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "" );
   }

   /* Upon receipt of the message the first test task will post the
      message to the second test task which will then put the message
      back to memory */

   pr++;
   if (pr == NMBPRIOR)
      pr = 0;
 
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst1PermActvTsk */
#if 1 /* ns003.12 addition */
#ifdef SS_RTR_SUPPORT
/*                                     
*
*       Fun:   tstRtrTsk
*
*       Desc:  Sample function for router task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tstRtrTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tstRtrTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   MsgLen mlng;
   /* ns013.102 - Modification to fix router task test cases */
   S16 j;
   Data uData, src[10];

   
   TRC2(tstRtrTsk)
 

   SFndLenMsg(mBuf,&mlng);

   /* ns013.102 - Modification to fix router task test cases */
   for ( j = 0; j < mlng; j++ )
   {
      SExamMsg(&uData,mBuf,(MsgLen) j);
      if ( uData != (Data) j )
         SSLOGERROR( ERRCLS_DEBUG, ESSXXX,0, "" );
   }
   SRemPstMsgMult(src, mlng, mBuf);
   /* Add Data to end of message */
   for (j = 0; j < 10; j++)
      SAddPstMsg( (Data)(10 - j), mBuf);
  
   pst->dstInst   = TSTINST0;        /* destination instance */
   pst->dstEnt    = TST6ENT;         /* destination entity */

   /* pass test */
 
   SExitTsk();
   RETVALUE(ROK);

} /* end of tstRtrTsk */  
#endif /* _SUPPORT */
#endif /* end ns003.12 addition */
  
/********************************************************************30**
  
         End of file: ns_acc.c 1.2  -  08/11/98 12:02:17

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release.
1.2          ---      bsr  2. reorginisation
1.2+        ns013.102 bjp  1. Modification to fix router task test cases  
*********************************************************************91*/
