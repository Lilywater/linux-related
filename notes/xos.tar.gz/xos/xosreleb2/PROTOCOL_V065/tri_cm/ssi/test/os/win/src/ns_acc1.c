/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services 
  
     Type:     C Source Code.
  
     Desc:     Negative Acceptance Tests
 
     File:     ns_acc1.c

     Sid:      ns_acc1.c 1.2  -  08/11/98 12:02:23
  
     Prg:      bsr
  
*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "ns_acc.h"        /* acceptance test */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */


#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "ns_acc.x"        /* acceptance test */

  
/* local defines */

/* local typedefs */
  
/* local externs */
PRIVATE U32 tsk3TmrCnt;            /* count of timer activations for task 0 */
PRIVATE U32 tsk4TmrCnt;            /* count of timer activations for task 1 */
PRIVATE U32 tsk5TmrCnt;            /* count of timer activations for task 2 */

/* forward references */

/* functions in other modules */

/* public variable declarations */
PUBLIC Bool perm2Completed = FALSE;

/* private variable declarations */

PRIVATE Bool tskInitCnt[NMBTSKS];  /* task initialization flag */
PRIVATE S16 nsTstState;            /* test state */
PRIVATE U32 nsTstCnt;              /* test count */
PRIVATE Ticks sysTime1;            /* system time 1 */
PRIVATE S16 sysTimeCnt;            /* system time count */
PRIVATE Random value1;             /* random number */
PRIVATE S16 valueCnt;              /* random number count */
PRIVATE Pool sPool;                /* pool id */
PRIVATE Txt  prntBuf[PRNTSZE];     /* print buffer */

  
/*
*     support functions
*/


/*
*
*       Fun:   nsPrintResult
*
*       Desc:  Prints test result
*
*       Ret:   VOID
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC VOID nsPrintResult
(
S8   *prntBuf,          /* Message */
Bool pass               /* result */
)
#else
PUBLIC VOID nsPrintResult(prntBuf, pass)
S8   *prntBuf;          /* Message */
Bool pass;              /* result */
#endif
{
   SPrint(prntBuf);
   if (pass)
      SPrint(" -- PASSED \n");
   else
   {
#ifdef NU
      DebugBreak();
#endif /* NU */
#ifdef NK
      KdBreakPoint();
#endif /* NK */
      SPrint(" -- FAILED \n");
   }

} /* End of nsPrintResult */


/*
*
*       Fun:   tst2PermActvTsk
*
*       Desc:  Sample function for test permanent task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst2PermActvTsk
(
Pst *pst,                   /* post */
Buffer *mB                  /* message buffer */
)
#else
PUBLIC S16 tst2PermActvTsk(pst, mB)
Pst *pst;                   /* post */
Buffer *mB;               /* message buffer */
#endif
{
   Queue q;
   Queue q1;
   Queue q2;
   QLen qLen;
   MsgLen idx;
   MsgLen cnt;
   MsgLen cCnt;
   S16 i;
   Pool pool;
   U8 pass;
   S16 ret;
   Data data;
   Data *bufPtr;
   Data   dBuf[DBUF_SIZE];
   Buffer *mBuf;
   Buffer *mBuf1;
   Buffer *mBuf2;
   Buffer *m[NUM_MBUFS];
   MsgLen length;

   TRC2(tst2PermActvTsk)

   if (mB != NULLP)
   {
      /* return message */
      SPutMsg(mB);
   }

   pool = SP_POOL;

   /* perform test case */
   switch(nsTstState)
   {
      case 0:               /* test statistics */
         ++nsTstCnt;
         pass = TRUE;
         nsTstState = 1;
         break;

      /* Begin testing SGetSMem */
      /* Begin testcase 2.1.1 */
      /* Call SGetSMem with zero size */
      case 1:
      {
         sprintf(prntBuf, "Testcase 2.1.1");
         pass = TRUE;
         ret = SGetSMem(OWNREGION, (Size) 0, &sPool);
         if (ret != ROK)
         {
            pass = FALSE;
         }
         break;
      }
      /* End testcase 2.1.1 */

      /* Begin testcase 2.1.2 */
      /* Call SGetSMem with invalid region */
      case 2:
      {
         sprintf(prntBuf, "Testcase 2.1.2");
         pass = TRUE;
         ret = SGetSMem(REGIONNC, (Size) MAXSMEMLEN, &sPool);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSMem failed" );
         }
         break;
      }
      /* End testcase 2.1.2 */

      /* Begin testcase 2.1.3 */
      /* Call SGetSMem with NULL pool pointer */
      case 3:
      {
         sprintf(prntBuf, "Testcase 2.1.2");
         pass = TRUE;
         ret = SGetSMem(OWNREGION, (Size) MAXSMEMLEN, NULLP);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSMem failed" );
         }
         break;
      }
      /* End testcase 2.1.3 */
      /* End testing SGetSMem */

      /* Begin testing SPutSMem */
      /* Begin testcase 2.2.1 */
      /* Call SPutSMem with zero size */
      case 4:
      {
         sprintf(prntBuf, "Testcase 2.2.1");
         pass = TRUE;
         break;
      }
      /* End testcase 2.2.1 */

      /* Begin testcase 2.2.2 */
      /* Call SPutSMem with invalid region */
      case 5:
      {
         sprintf(prntBuf, "Testcase 2.2.2");
         pass = TRUE;
         ret = SPutSMem(REGIONNC, sPool);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSMem failed" );
         }
         break;
      }
      /* End testcase 2.2.2 */

      /* Begin testcase 2.2.3 */
      /* Call SPutSMem with invalid pool */
      case 6:
      {
         sprintf(prntBuf, "Testcase 2.2.3");
         pass = TRUE;
         ret = SPutSMem((Region)OWNREGION, (Pool) -1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSMem failed" );
         }
         break;
      }
      /* End testcase 2.2.3 */

      /* Begin testcase 2.2.4 */
      /* Call SPutSMem with a size not equal to size used for SGetSMem */
      case 7:
      {
         sprintf(prntBuf, "Testcase 2.2.3");
         pass = TRUE;
         break;
      }
      /* End testcase 2.2.4 */
      /* End testing SPutSMem */

      /* Begin testing SGetSBuf */
      /* Begin testcase 2.3.1 */
      /* Call SGetSBuf with zero size */
      case 8:
      {
         sprintf(prntBuf, "Testcase 2.3.1");
         pass = TRUE;
         ret = SGetSBuf((Region)OWNREGION, sPool, &bufPtr, (Size) 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
         }
         break;
      }
      /* End testcase 2.3.1 */

      /* Begin testcase 2.3.2 */
      /* Call SGetSBuf after SPutSMem */
      case 9:
      {
         Pool pool;

         sprintf(prntBuf, "Testcase 2.3.2");
         pass = TRUE;
         ret = SGetSMem(OWNREGION, (Size) MAXSMEMLEN, &pool);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSMem failed" );
         }
         ret = SPutSMem(OWNREGION, pool);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSMem failed" );
         }
         break;
      }
      /* End testcase 2.3.2 */

      /* Begin testcase 2.3.3 */
      /* Call SGetSBuf NULL data pointer */
      case 10:
      {
         sprintf(prntBuf, "Testcase 2.3.3");
         pass = TRUE;
         ret = SGetSBuf(OWNREGION, sPool, NULLP, (Size) MAXSMEMLEN/2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
         }
         break;
      }
      /* End testcase 2.3.3 */

      /* Begin testcase 2.3.4 */
      /* Call SGetSBuf with invalid region */
      case 11:
      {
         sprintf(prntBuf, "Testcase 2.3.4");
         pass = TRUE;
         ret = SGetSBuf(REGIONNC, sPool, &bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
         }
         break;
      }
      /* End testcase 2.3.4 */
      /* End testing SGetSBuf */

      /* Begin testing SPutSBuf */
      /* Begin testcase 2.4.1 */
      /* Call SPutSBuf with zero size */
      case 12:
      {
         sprintf(prntBuf, "Testcase 2.4.1");
         pass = TRUE;
         ret = SGetSBuf(OWNREGION, sPool, &bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, bufPtr, (Size) 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
         }
         break;
      }

      /* End testcase 2.4.1 */

      /* Begin testcase 2.4.2 */
      /* Call SPutSBuf with size different from the size used in SGetSBuf */
      case 13:
      {
         sprintf(prntBuf, "Testcase 2.4.2");
         pass = TRUE;
         ret = SGetSBuf(OWNREGION, sPool, &bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
         }
         break;
      }

      /* End testcase 2.4.2 */

      /* Begin testcase 2.4.3 */
      /* Call SPutSBuf with NULL data buffer pointer */
      case 14:
      {
         sprintf(prntBuf, "Testcase 2.4.3");
         pass = TRUE;
         ret = SGetSBuf(OWNREGION, sPool, &bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, NULLP, (Size) MAXSMEMLEN/2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
         }
         break;
      }

      /* End testcase 2.4.3 */

      /* Begin testcase 2.4.4 */
      /* Call SPutSBuf with invalid region */
      case 15:
      {
         sprintf(prntBuf, "Testcase 2.4.4");
         pass = TRUE;
         ret = SGetSBuf(OWNREGION, sPool, &bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(REGIONNC, sPool, bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
            goto end;
         }

         ret = SPutSBuf(OWNREGION, sPool, bufPtr, (Size) MAXSMEMLEN/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutSBuf failed" );
         }
         break;
      }

      /* End testcase 2.4.4 */
      /* End testing SPutSBuf */

      /* Begin testing SGetMsg */
      /* Begin testcase 5.1.1 */
      /* Call SGetMsg with invalid region */
      case 16:
      {
         sprintf(prntBuf, "Testcase 5.1.1");
         pass = TRUE;
         ret = SGetMsg(REGIONNC, DFLT_POOL, &mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
         }
         break;
      }
      /* End testcase 5.1.1 */

      /* Begin testcase 5.1.2 */
      /* Call SGetMsg with invalid pool */
      case 17:
      {
         sprintf(prntBuf, "Testcase 5.1.2");
         pass = TRUE;
         ret = SGetMsg((Region)OWNREGION, (Pool)-1, &mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
         }
         break;
      }
      /* End testcase 5.1.2 */

      /* Begin testcase 5.1.3 */
      /* Call SGetMsg with NULL mBuf pointer */
      case 18:
      {
         sprintf(prntBuf, "Testcase 5.1.3");
         pass = TRUE;
         ret = SGetMsg((Region)OWNREGION, (Pool)DFLT_POOL, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
         }
         break;
      }
      /* End testcase 5.1.3 */
      /* End testing SGetMsg */



      /* Begin testing SPutMsg */
      /* Begin testcase 5.2.1 */
      /* Call SPutMsg with NULL mBuf pointer */
      case 19:
      {
         sprintf(prntBuf, "Testcase 5.2.1");
         pass = TRUE;
         ret = SPutMsg(NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testcase 5.2.1 */

      /* Begin testcase 5.2.2 */
      case 20:
      {
         sprintf(prntBuf, "Testcase 5.2.2");
         pass = TRUE;
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testcase 5.2.2 */
      /* End testing SPutMsg */

      /* Begin testing SInitMsg */
      /* Begin testcase 5.3.1 */
      /* Call SInitMsg with NULL mBuf */
      case 21:
      {
         sprintf(prntBuf, "Testcase 5.3.1");
         pass = TRUE;
         ret = SInitMsg(NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
         }
         break;
      }
      /* End testcase 5.3.1 */

      /* Begin testing SFndLenMsg */
      /* Begin testcase 5.4.1 */
      /* Call SFndLenMsg with NULL mBuf */
      case 22:
      {
         sprintf(prntBuf, "Testcase 5.4.1");
         pass = TRUE;
         ret = SFndLenMsg(NULLP, &length);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
         }
         break;
      }
      /* End testcase 5.4.1 */

      /* Begin testcase 5.4.2 */
      /* Call SFndLenMsg with NULL length pointer */
      case 23:
      {
         sprintf(prntBuf, "Testcase 5.4.2");
         pass = TRUE;
         /* ns013.102 - Modification to fix warn */
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
         }
         ret = SFndLenMsg(mBuf, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
         }
         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testcase 5.4.2 */
      /* End testing SFndLenMsg */

      /* Begin testing SExamMsg */
      /* Begin testcase 5.5.1 */
      /* Call SFndLenMsg with NULL length pointer */
      case 24:
      {
         sprintf(prntBuf, "Testcase 5.5.1");
         pass = TRUE;
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         idx = 1;
         ret = SExamMsg(NULLP, mBuf, idx);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.5.1 */

         /* Begin testcase 5.5.2 */
         /* Call SExamMsg with NULL mBuf */
         sprintf(prntBuf, "Testcase 5.5.2");
         pass = TRUE;
         ret = SExamMsg(&data, NULLP, idx);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.5.2 */

         /* Begin testcase 5.5.3 */
         /* Call SExamMsg with very large index value */
         sprintf(prntBuf, "Testcase 5.5.3");
         pass = TRUE;
         idx = 100;
         ret = SExamMsg(&data, mBuf, idx);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.5.3 */

         /* Begin testcase 5.5.4 */
         /* Call SExamMsg with negative index */
         sprintf(prntBuf, "Testcase 5.5.4");
         pass = TRUE;
         ret = SExamMsg(&data, mBuf, -1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.5.4 */

         /* Begin testcase 5.5.5 */
         /* Add few bytes and  call SExamMsg with all allowable indices */
         sprintf(prntBuf, "Testcase 5.5.5");
         pass = TRUE;
         ret = SExamMsg(&data, mBuf, 0);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if ( data != 'A')
            pass = FALSE;
         ret = SExamMsg(&data, mBuf, 1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if ( data != 'B')
            pass = FALSE;
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.5.5 */

         /* End testcase 5.5.6 */
         sprintf(prntBuf, "Testcase 5.5.6");
         pass = TRUE;
         ret = SExamMsg(&data, mBuf, 2);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         nsPrintResult("Testcase 5.5.6", pass);
         /* End testcase 5.5.6 */

         /* Begin testcase 5.5.7 */
         sprintf(prntBuf, "Testcase 5.5.7");
         pass = TRUE;
         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if (length != 2)
            pass = FALSE;

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.5.7 */
         break;
      }
      /* End testing SExamMsg */

      /* Begin testing SRepMsg */
      case 25:
      {
         sprintf(prntBuf, "Testcase 5.6.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         /* Begin testcase 5.6.1 */
         /* Call SRepMsg with NULL mBuf */
         pass = TRUE;
         idx = 1;
         /* ns013.102 - Modification to fix warning */
         ret = SExamMsg(&data, mBuf, 0);
         ret = SRepMsg(data, NULLP, idx);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.6.1 */

         /* Begin testcase 5.6.2 */
         /* Call SRepMsg with negative index */
         sprintf(prntBuf, "Testcase 5.6.2");
         pass = TRUE;
         ret = SRepMsg(data, mBuf, -1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.2 */

         /* Begin testcase 5.6.3 */
         /* Call SRepMsg with index greater than length */
         sprintf(prntBuf, "Testcase 5.6.3");
         pass = TRUE;
         idx = 100;
         ret = SRepMsg(data, mBuf, idx);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.3 */

         /* Begin testcase 5.6.4 */
         /*
          * Call SRepMsg with valid index, and use SExamMsg to check 
          *  the result 
          */
         sprintf(prntBuf, "Testcase 5.6.4");
         pass = TRUE;
         data = 'C';
         ret = SRepMsg(data, mBuf, 1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }
         data = 0;
         ret = SExamMsg(&data, mBuf, 1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if (data != 'C')
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.4 */

         /* Begin testcase 5.6.5 */
         /* Call SRepMsg with index = length */
         sprintf(prntBuf, "Testcase 5.6.5");
         pass = TRUE;
         ret = SRepMsg(data, mBuf, 2);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.5 */

         /* End testcase 5.6.6 */
         sprintf(prntBuf, "Testcase 5.6.6");
         pass = TRUE;
         data = 'D';
         ret = SRepMsg(data, mBuf, 0);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
            goto end;
         }
         data = 0;
         ret = SExamMsg(&data, mBuf, 0);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if (data != 'D')
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.6 */

         /* Begin testcase 5.6.7 */
         /* Check length of the message after a call to SRepMsg */
         sprintf(prntBuf, "Testcase 5.6.7");
         pass = TRUE;
         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if (length != 2)
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.6.7 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         nsTstState = 26;
         break;
      }
      /* End testing SRepMsg */

      /* Begin testing SAddPre */
      case 26:
      {
         sprintf(prntBuf, "Testcase 5.7.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         /* Begin testcase 5.7.1 */
         /* Call SAddPreMsg with NULL mBuf */
         pass = TRUE;
         ret = SAddPreMsg('A', NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.7.1 */

         /* Begin testcase 5.7.2 */
         /* Add a byte with SAddPreMsg and check the result with SExamMsg */
         sprintf(prntBuf, "Testcase 5.7.2");
         pass = TRUE;
         data = 0;
         ret = SExamMsg(&data, mBuf, 0);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if ( data != 'A')
            pass = FALSE;

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.7.2 */
         break;
      }
      /* End testing SAddPreMsg */

      /* Begin testing SAddPstMsg */
      case 27:
      {
         sprintf(prntBuf, "Testcase 5.8.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         /* Begin testcase 5.8.1 */
         /* Call SAddPstMsg with NULL mBuf */
         pass = TRUE;
         ret = SAddPstMsg('A', NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.8.1 */

         /* Begin testcase 5.8.2 */
         /* Add a byte with SAddPreMsg and check the result with SExamMsg */
         sprintf(prntBuf, "Testcase 5.8.2");
         pass = TRUE;
         data = 0;
         ret = SExamMsg(&data, mBuf, 1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
            goto end;
         }
         if ( data != 'B')
            pass = FALSE;

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.8.2 */
         break;
      }
      /* End testing SAddPstMsg */


      /* Begin testing SRemPreMsg */
      case 28:
      {
         sprintf(prntBuf, "Testcase 5.9.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         /* Begin testcase 5.9.1 */
         /* Call SRemPreMsg with NULL mBuf */
         pass = TRUE;
         ret = SRemPreMsg(&data, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.9.1 */

         /* Begin testcase 5.9.2 */
         /* Call SRemPreMsg with NULL dataBuf */
         sprintf(prntBuf, "Testcase 5.9.2");
         pass = TRUE;
         ret = SRemPreMsg(NULLP, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.9.2 */

         /* Begin testcase 5.9.3 */
         /* Add a byte with SAddPreMsg and check the result with SRemPreMsg */
         sprintf(prntBuf, "Testcase 5.9.3");
         pass = TRUE;
         ret = SRemPreMsg(&data, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         if (data != 'A')
            pass = FALSE;

         ret = SRemPreMsg(&data, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         if (data != 'B')
            pass = FALSE;

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         if (length != 0)
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.9.3 */

         /* Begin testcase 5.9.4 */
         /* Call SRemPreMsg on a empty mBuf */
         sprintf(prntBuf, "Testcase 5.9.4");
         pass = TRUE;
         ret = SRemPreMsg(&data, mBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
            goto end;
         }
         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.9.4 */
         break;
      }
      /* End testing SRemPreMsg */

      /* Begin testing SRemPstMsg */
      case 29:
      {
         sprintf(prntBuf, "Testcase 5.10.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('B', mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         /* Begin testcase 5.10.1 */
         /* Call SRemPstMsg with NULL mBuf */
         pass = TRUE;
         ret = SRemPstMsg(&data, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.10.1 */

         /* Begin testcase 5.10.2 */
         /* Call SRemPstMsg with NULL dataBuf */
         sprintf(prntBuf, "Testcase 5.10.2");
         pass = TRUE;
         ret = SRemPstMsg(NULLP, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.10.2 */

         /* Begin testcase 5.10.3 */
         /* Add a byte with SAddPstMsg and check the result with SRemPstMsg */
         sprintf(prntBuf, "Testcase 5.10.3");
         pass = TRUE;
         ret = SRemPstMsg(&data, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         if (data != 'B')
            pass = FALSE;

         ret = SRemPstMsg(&data, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         if (data != 'A')
            pass = FALSE;

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         if (length != 0)
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.10.3 */

         /* Begin testcase 5.10.4 */
         /* Call SRemPstMsg on a empty mBuf */
         sprintf(prntBuf, "Testcase 5.10.4");
         pass = TRUE;
         ret = SRemPstMsg(&data, mBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
            goto end;
         }
         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.10.4 */
         break;
      }
      /* End testing SRemPstMsg */

      /* Begin testing SAddPreMsgMult */
      case 30:
      {
         sprintf(prntBuf, "Testcase 5.11.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         /* Begin testcase 5.11.1 */
         /* Call SAddPreMsgMult with NULL mBuf */
         pass = TRUE;
         ret = SAddPreMsgMult(dBuf, DBUF_SIZE, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.11.1 */

         /* Begin testcase 5.11.2 */
         /* Call SAddPreMsgMult with NULL dataBuf */
         sprintf(prntBuf, "Testcase 5.11.2");
         pass = TRUE;
         ret = SAddPreMsgMult(NULLP, DBUF_SIZE, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.11.2 */

         /* Begin testcase 5.11.3 */
         /* Call SAddPreMsgMult with zero count */
         sprintf(prntBuf, "Testcase 5.11.3");
         pass = TRUE;
         ret = SAddPreMsgMult(dBuf, 0, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.11.3 */

         /* Begin testcase 5.11.4 */
         /* Call SAddPreMsgMult with -ve count */
         sprintf(prntBuf, "Testcase 5.11.4");
         pass = TRUE;
         ret = SAddPreMsgMult(&data, -1, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.11.4 */

         /* Begin testcase 5.11.5 */
         sprintf(prntBuf, "Testcase 5.11.5");
         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         ret = SAddPreMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }
         /* End testcase 5.11.5 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testing SAddPreMsgMult */

      /* Begin testing SAddPstMsgMult */
      case 31:
      {
         sprintf(prntBuf, "Testcase 5.12.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         /* Begin testcase 5.12.1 */
         /* Call SAddPstMsgMult with NULL mBuf */
         pass = TRUE;
         ret = SAddPstMsgMult(dBuf, DBUF_SIZE, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.12.1 */

         /* Begin testcase 5.12.2 */
         /* Call SAddPstMsgMult with NULL dataBuf */
         sprintf(prntBuf, "Testcase 5.12.2");
         pass = TRUE;
         ret = SAddPstMsgMult(NULLP, DBUF_SIZE, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.12.2 */

         /* Begin testcase 5.12.3 */
         /* Call SAddPstMsgMult with zero count */
         sprintf(prntBuf, "Testcase 5.12.3");
         pass = TRUE;
         ret = SAddPstMsgMult(dBuf, 0, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.12.3 */

         /* Begin testcase 5.12.4 */
         /* Call SAddPstMsgMult with -ve count */
         sprintf(prntBuf, "Testcase 5.12.4");
         pass = TRUE;
         ret = SAddPstMsgMult(&data, -1, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.12.4 */

         /* Begin testcase 5.12.5 */
         sprintf(prntBuf, "Testcase 5.12.5");
         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         ret = SAddPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPreMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }
         /* End testcase 5.12.5 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         break;
      }
      /* End testing SAddPreMsgMult */

      /* Begin testing SRemPreMsgMult */
      case 32:
      {
         sprintf(prntBuf, "Testcase 5.13.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         /* Begin testcase 5.13.1 */
         /* Call SRemPreMsgMult with NULL mBuf */
         pass = TRUE;
         ret = SRemPreMsgMult(dBuf, DBUF_SIZE, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.13.1 */

         /* Begin testcase 5.13.3 */
         /* Call SRemPreMsgMult with zero count */
         sprintf(prntBuf, "Testcase 5.13.3");
         pass = TRUE;
         ret = SRemPreMsgMult(dBuf, 0, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.13.3 */

         /* Begin testcase 5.13.4 */
         /* Call SRemPreMsgMult with -ve count */
         sprintf(prntBuf, "Testcase 5.13.4");
         pass = TRUE;
         ret = SRemPreMsgMult(&data, -1, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.13.4 */

         /* Begin testcase 5.13.5 */
         /* Call SRemPstMsgMult with count > length */
         sprintf(prntBuf, "Testcase 5.13.5");
         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         ret = SAddPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPreMsgMult(dBuf, DBUF_SIZE + 100, mBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsgMult failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         /* End testcase 5.13.5 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testing SRemPreMsgMult */

      /* Begin testing SRemPstMsgMult */
      case 33:
      {
         sprintf(prntBuf, "Testcase 5.14.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         /* Begin testcase 5.14.1 */
         /* Call SRemPstMsgMult with NULL mBuf */
         pass = TRUE;
         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.14.1 */

         /* Begin testcase 5.14.3 */
         /* Call SRemPstMsgMult with zero count */
         sprintf(prntBuf, "Testcase 5.14.3");
         pass = TRUE;
         ret = SRemPstMsgMult(dBuf, 0, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.14.3 */

         /* Begin testcase 5.14.4 */
         /* Call SRemPstMsgMult with -ve count */
         sprintf(prntBuf, "Testcase 5.14.4");
         pass = TRUE;
         ret = SRemPstMsgMult(&data, -1, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.14.4 */

         /* Begin testcase 5.14.5 */
         /* Call SRemPstMsgMult with count > length */
         sprintf(prntBuf, "Testcase 5.14.5");
         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         ret = SAddPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsgMult failed" );
            goto end;
         }

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE + 100, mBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         /* End testcase 5.14.5 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         break;
      }
      /* End testing SRemPstMsgMult */

      /* Begin testing SGetPstMsgMult */
      case 34:
      {
         sprintf(prntBuf, "Testcase 5.15.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         /* Begin testcase 5.15.1 */
         /* Call SGetPstMsgMult with NULL mBuf */
         pass = TRUE;
         cnt = 10;
         ret = SGetPstMsgMult(cnt, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.15.1 */

         /* Begin testcase 5.15.2 */
         /* Call SGetPstMsgMult with zero count */
         sprintf(prntBuf, "Testcase 5.15.2");
         pass = TRUE;
         ret = SGetPstMsgMult(0, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.15.2 */

         /* Begin testcase 5.15.3 */
         /* Call SGetPstMsgMult with -ve count */
         sprintf(prntBuf, "Testcase 5.15.3");
         pass = TRUE;
         ret = SGetPstMsgMult(-1, mBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetPstMsgMult failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.15.3 */

         /* Begin testcase 5.15.4 */
         /* Call SGetPstMsgMult with count > length */
         sprintf(prntBuf, "Testcase 5.15.4");

         ret = SGetPstMsgMult(DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetPstMsgMult failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != 0)
            {
               pass = FALSE;
               break;
            }
         }

         /* End testcase 5.15.4 */

         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         break;
      }
      /* End testing SGetPstMsgMult */

      /* Begin testing SCpyFixMsg */
      case 35:
      {
         sprintf(prntBuf, "Testcase 5.16.4");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         /* Begin testcase 5.16.1 */
         /* Call SCpyFixMsg with NULL srcBuf */
         pass = TRUE;
         ret = SCpyFixMsg(NULLP, mBuf, 0, 10, &cCnt);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.16.1 */

         /* Begin testcase 5.16.2 */
         /* Call SCpyFixMsg with NULL dstMbuf */
         sprintf(prntBuf, "Testcase 5.16.2");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, NULLP, 0, 10, &cCnt);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.2 */

         /* Begin testcase 5.16.3 */
         /* Call SCpyFixMsg with NULL cCnt */
         sprintf(prntBuf, "Testcase 5.16.3");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, 0, 10, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.3 */

         /* Begin testcase 5.16.4 */
         /* Call SCpyFixMsg with -ve dstIdx */
         sprintf(prntBuf, "Testcase 5.16.4");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, -1, 10, &cCnt);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.4 */

         /* Begin testcase 5.16.5 */
         /* Call SCpyFixMsg with -ve cnt */
         sprintf(prntBuf, "Testcase 5.16.5");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, 0, -1, &cCnt);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.5 */

         /* Begin testcase 5.16.6 */
         /* Call SCpyFixMsg with dstIdx > length of the message */

         sprintf(prntBuf, "Testcase 5.16.6");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, 10, DBUF_SIZE, &cCnt);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }

         ret = SCpyFixMsg(dBuf, mBuf, length, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }

         if ( length != DBUF_SIZE)
            pass = FALSE;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.6 */

         /* Begin testcase 5.16.7 */
         /* Call SCpyFixMsg with dstIdx = length of the message */
         sprintf(prntBuf, "Testcase 5.16.7");

         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, 0, DBUF_SIZE/2, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyFixMsg(&dBuf[DBUF_SIZE/2], mBuf, DBUF_SIZE/2, DBUF_SIZE/2, 
                          &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE/2; i++)
         {
            if (dBuf[(DBUF_SIZE/2 -1) - i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }
         for (i = DBUF_SIZE/2; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.16.7 */

         /* Begin testcase 5.16.8 */
         /* 
          * Add few bytes at the middle of the message and verify 
          * using SExamMsg
          */
         sprintf(prntBuf, "Testcase 5.16.8");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, mBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         for (i = 0; i < 10; i++)
         {
            dBuf[i] = (i + 10) % 256;
         }

         ret = SCpyFixMsg(dBuf, mBuf, DBUF_SIZE/2, 10, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE+10)
            pass = FALSE;

         for (i = 0; i < 10; i++)
         {
            ret = SExamMsg(dBuf, mBuf, (MsgLen)(DBUF_SIZE/2 + i));
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamMsg failed" );
               goto end;
            }

            if (dBuf[0] != (i + 10) % 256)
            {
               pass = FALSE;
               break;
            }
         }

         /* End testcase 5.16.8 */
         ret = SPutMsg(mBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         break;
      }
      /* End testing SCpyFixMsg */

      /* Begin testing SCpyMsgMsg */
      case 36:
      {
         Buffer *srcBuf;
         Buffer *dstBuf;

         sprintf(prntBuf, "Testcase 5.17.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         /* Begin testcase 5.17.1 */
         /* Call SCpyMsgMsg with NULL srcBuf */
         pass = TRUE;
         ret = SCpyMsgMsg(NULLP, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.17.1 */

         /* Begin testcase 5.17.2 */
         /* Call SCpyMsgMsg with NULL dstMbuf */
         sprintf(prntBuf, "Testcase 5.17.2");
         pass = TRUE;
         ret = SCpyMsgMsg(srcBuf, (Region)OWNREGION, (Pool)DFLT_POOL, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.2 */

         /* Begin testcase 5.17.3 */
         /* Call SCpyMsgMsg with invalid region */
         sprintf(prntBuf, "Testcase 5.17.3");
         pass = TRUE;
         ret = SCpyMsgMsg(srcBuf, (Region)-1, (Pool)DFLT_POOL, &dstBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.3 */


         /* Begin testcase 5.17.4 */
         /* Call SCpyMsgMsg with valid params, and call SInitMsg on source 
          * buffer.  Check the data in the second buffer.
          */
         sprintf(prntBuf, "Testcase 5.17.4");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.4 */

         /* Begin testcase 5.17.5 */
         /* Call SCpyMsgMsg with valid params, and replace all the data in 
          * source buffer using SRepMsg.  Check the data in the second buffer */
         sprintf(prntBuf, "Testcase 5.17.5");

         pass = TRUE;
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            ret = SRepMsg('A', srcBuf, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
               goto end;
            }
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.5 */

         /* Begin testcase 5.17.6 */
         /* Call SCpyMsgMsg with valid params, and add few bytes to the in 
          * source buffer. Check the data in the second buffer */
         sprintf(prntBuf, "Testcase 5.17.6");

         pass = TRUE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i % 256;

         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         for (i = 0; i < 10; i++)
         {
            ret = SAddPstMsg('A', srcBuf);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
               goto end;
            }
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         ret = SFndLenMsg(srcBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != (DBUF_SIZE + 10))
            pass = FALSE;

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.6 */

         /* Begin testcase 5.17.7 */
         /* Call SCpyMsgMsg with valid params, and remove few bytes from the 
          * source buffer.  Check the data in the second buffer */ 
         sprintf(prntBuf, "Testcase 5.17.7");

         pass = TRUE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i % 256;

         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         for (i = 0; i < 10; i++)
         {
            ret = SRemPstMsg(&dBuf[0], srcBuf);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsg failed" );
               goto end;
            }
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         ret = SFndLenMsg(srcBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != (DBUF_SIZE - 10))
            pass = FALSE;

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.17.7 */

         /* Begin testcase 5.17.8 */
         /* Call SCpyMsgMsg with valid params, and remove few bytes from the 
          * source buffer.  Check the data in the second buffer */ 
         sprintf(prntBuf, "Testcase 5.17.8");

         pass = TRUE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i % 256;

         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         ret = SPutMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }
         /* End testcase 5.17.8 */
         break;
      }
      /* End testing SCpyMsgMsg */

      /* Begin testing SCatMsg */
      case 37:
      {
         Buffer *srcBuf;
         Buffer *dstBuf;

         sprintf(prntBuf, "Testcase 5.18.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         ret = SGetMsg(OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         /* Begin testcase 5.18.1 */
         /* Call SCatMsg with NULL srcBuf */
         pass = TRUE;
         ret = SCatMsg(NULLP, dstBuf, M1M2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.18.1 */

         /* Begin testcase 5.18.2 */
         /* Call SCatMsg with NULL dstMbuf */
         sprintf(prntBuf, "Testcase 5.18.2");
         pass = TRUE;
         ret = SCatMsg(srcBuf, NULLP, M1M2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.18.2 */

         /* Begin testcase 5.18.3 */
         /* Call SCatMsg with invalid order */
         sprintf(prntBuf, "Testcase 5.18.3");
         pass = TRUE;
         ret = SCatMsg(srcBuf, dstBuf, -1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.18.3 */


         /* Begin testcase 5.18.4 */
         /* Call SCatMsg two empty messages */
         sprintf(prntBuf, "Testcase 5.18.4");

         pass = TRUE;
         ret = SCatMsg(srcBuf, dstBuf, M1M2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.18.4 */

         /* Begin testcase 5.18.5 */
         /* Call SCatMsg with valid messages and check the contents of both 
          * the messages */
         sprintf(prntBuf, "Testcase 5.18.5");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE/2, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         
         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         ret = SCatMsg(srcBuf, dstBuf, M1M2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != 0)
            pass = FALSE;

         ret = SFndLenMsg(srcBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.18.5 */

         /* Begin testcase 5.18.6 */
         /* Call SCatMsg with valid messages and check the contents of both 
          * the messages */
         sprintf(prntBuf, "Testcase 5.18.6");
         pass = TRUE;
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE/2, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(srcBuf, OWNREGION, DFLT_POOL, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         ret = SInitMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitMsg failed" );
            goto end;
         }

         ret = SCatMsg(srcBuf, dstBuf, M1M2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != 0)
            pass = FALSE;

         ret = SFndLenMsg(srcBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE/2)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE/2; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE/2, srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE/2; i++)
         {
            if (dBuf[i] != i%256)
            {
               pass = FALSE;
               break;
            }
         }

         /* End testcase 5.18.6 */

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         ret = SPutMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         break;
      }
      /* End testing SCatMsg */

      /* Begin testing SSegMsg */
      case 38:
      {
         Buffer *srcBuf;
         Buffer *dstBuf;
         sprintf(prntBuf, "Testcase 5.19.1");

         ret = SGetMsg(OWNREGION, DFLT_POOL, &srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         /* Begin testcase 5.19.1 */
         /* Call SSegMsg with NULL srcBuf */
         pass = TRUE;
         ret = SSegMsg(NULLP, 0, &dstBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.19.1 */

         /* Begin testcase 5.19.2 */
         /* Call SSegMsg with NULL dstMbuf */
         sprintf(prntBuf, "Testcase 5.19.2");
         pass = TRUE;
         ret = SSegMsg(srcBuf, 0, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.19.2 */

         /* Begin testcase 5.19.3 */
         /* Call SSegMsg with -ve index */
         sprintf(prntBuf, "Testcase 5.19.3");
         pass = TRUE;
         ret = SSegMsg(srcBuf, -1, &dstBuf);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.19.3 */


         /* Begin testcase 5.19.4 */
         /* Call SSegMsg with index > length */
         sprintf(prntBuf, "Testcase 5.19.4");

         pass = TRUE;
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }
         ret = SSegMsg(srcBuf, (DBUF_SIZE + 10), &dstBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.19.4 */

         /* Begin testcase 5.19.5 */
         /* Call SSegMsg with valid messages and check the contents of both 
          * the messages */
         sprintf(prntBuf, "Testcase 5.19.5");
         pass = TRUE;
         
         ret = SSegMsg(srcBuf, DBUF_SIZE, &dstBuf);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 5.19.5 */

         /* Begin testcase 5.19.6 */
         /* Call SSegMsg with index = 0 */

         sprintf(prntBuf, "Testcase 5.19.6");
         pass = TRUE;
         ret = SSegMsg(srcBuf, 0, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(srcBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != 0)
            pass = FALSE;

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
         {
              if (dBuf[i] != i%256)
              {
               pass = FALSE;
               break;
            }
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.19.6 */

         /* Begin testcase 5.19.7 */
         /* Call SSegMsg with a valid index, replace the contents of srcBuf
          * and check the contents of dstBuf */

         sprintf(prntBuf, "Testcase 5.19.7");
         pass = TRUE;
         SInitMsg(srcBuf);
         ret = SCpyFixMsg(dBuf, srcBuf, 0, DBUF_SIZE, &cCnt);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyFixMsg failed" );
            goto end;
         }

         ret = SSegMsg(srcBuf, DBUF_SIZE/2, &dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SSegMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE/2; i++)
         {
            ret = SRepMsg('A', srcBuf, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRepMsg failed" );
               goto end;
            }
         }

         for (i = 0; i < 10; i++)
         {
            ret = SAddPstMsg('A', srcBuf);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
               goto end;
            }
         }

         ret = SFndLenMsg(dstBuf, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != DBUF_SIZE/2)
            pass = FALSE;

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = 0;

         ret = SRemPstMsgMult(dBuf, DBUF_SIZE/2, dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPstMsgMult failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE/2; i++)
         {
              if (dBuf[i] != i%256)
              {
               pass = FALSE;
               break;
            }
         }

         ret = SPutMsg(dstBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         /* End testcase 5.19.7 */

         ret = SPutMsg(srcBuf);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
         }

         break;
      }
      /* End testing SSegMsg */

      /* Begin testing SCompressMsg */
      case 39:
      {

         sprintf(prntBuf, "Testcase 5.20.1");
         ret = SGetMsg(OWNREGION, DFLT_POOL, &mBuf1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
            goto end;
         }

         for (i = 0; i < DBUF_SIZE; i++)
            dBuf[i] = i%256;

         /* Begin testcase 5.20.1 */
         /* Call SCompressMsg with NULL mBuf */
         pass = TRUE;
         ret = SCompressMsg(NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCompressMsg failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         /* End testcase 5.20.1 */

         /* Begin testcase 5.20.2 */
         /* Call SAddPreMsg and SAddPstMsg. Call SCpyMsgMsg. Now call 
          * SAddPreMsg and SAddPstMsg on mBuf2. (This might have allocated 
          * 4 data buffers for mBuf2). Call SCompressMsg on mBuf2, 
          * check it's contents and check contents of mBuf1. */
         sprintf(prntBuf, "Testcase 5.20.2");
         pass = TRUE;

         ret = SAddPreMsg('B', mBuf1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('C', mBuf1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         ret = SCpyMsgMsg(mBuf1, OWNREGION, DFLT_POOL, &mBuf2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCpyMsgMsg failed" );
            goto end;
         }

         ret = SAddPreMsg('A', mBuf2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPreMsg failed" );
            goto end;
         }

         ret = SAddPstMsg('D', mBuf2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddPstMsg failed" );
            goto end;
         }

         ret = SCompressMsg(mBuf2);
         if (ret != OK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCompressMsg failed" );
            goto end;
         }

         ret = SFndLenMsg(mBuf2, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != 4)
            pass = FALSE;

         ret = SFndLenMsg(mBuf1, &length);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenMsg failed" );
            goto end;
         }
         if ( length != 2)
            pass = FALSE;

         for (i = 0; i < 4; i++)
         {
            ret = SRemPreMsg(&data, mBuf2);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
               goto end;
            }
            if (data != ('A' + i))
               pass = FALSE;
         }

         for (i = 0; i < 2; i++)
         {
            ret = SRemPreMsg(&data, mBuf1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemPreMsg failed" );
               goto end;
            }
            if (data != ('B' + i))
               pass = FALSE;
         }

         ret = SPutMsg(mBuf2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }

         ret = SPutMsg(mBuf1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            goto end;
         }

         /* End testcase 5.20.2 */
         break;
      }
/* End testing SCompressMsg */


/* Begin testing SIniTQueue */
      case 40:
      {

         sprintf(prntBuf, "Testcase 3.1.1");
         /* Begin testcase 3.1.1 */
         /* Call SInitQueue with NULL q */
         pass = TRUE;
         ret = SInitQueue(NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
         }
         /* End testcase 3.1.1 */

         break;
      }
      /* Begin testing SQueueFirst */
      case 41:
      {

         sprintf(prntBuf, "Testcase 3.2.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }
         ret = SInitQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.2.1 */
         /* Call SQueueFirst with NULL buf pointer */
         pass = TRUE;
         ret = SQueueFirst(NULLP, &q);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueFirst failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.2.1 */

         /* Begin testcase 3.2.2 */
         /* Call SQueueFirst with NULL q pointer */
         pass = TRUE;
         ret = SQueueFirst(m[0], NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueFirst failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.2.2 */

         /* Begin testcase 3.2.3 */
         /* Call SQueueFirst twice with valid messages check the contents 
          * with SExamQueue. */
         pass = TRUE;
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueFirst(m[i], &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueFirst failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SExamQueue(&mBuf, &q, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueFirst failed" );
               goto end;
            }
            if (mBuf != m[NUM_MBUFS - (i +1)])
            {
               pass = FALSE;
               break;
            }
         }

         ret = SFlushQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFlushQueue failed" );
         }

         /* End testcase 3.2.3 */

         break;
      }
      /* End testing SQueueFirst */

      /* Begin testing SQueueLast */
      case 42:
      {

         sprintf(prntBuf, "Testcase 3.3.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }
         ret = SInitQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.3.1 */
         /* Call SQueueLast with NULL buf pointer */
         pass = TRUE;
         ret = SQueueLast(NULLP, &q);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.3.1 */

         /* Begin testcase 3.3.2 */
         /* Call SQueueLast with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.3.2");
         pass = TRUE;
         ret = SQueueLast(m[0], NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.3.2 */

         /* Begin testcase 3.3.3 */
         /* Call SQueueLast twice with valid messages check the contents 
          * with SExamQueue. */
         sprintf(prntBuf, "Testcase 3.3.3");
         pass = TRUE;
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueLast(m[i], &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SExamQueue(&mBuf, &q, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         ret = SFlushQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFlushQueue failed" );
         }

         /* End testcase 3.3.3 */

         break;
      }
      /* End testing SQueueLast */

      /* Begin testing SDequeueFirst */
      case 43:
      {

         sprintf(prntBuf, "Testcase 3.4.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }
         ret = SInitQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.4.1 */
         /* Call SDequeueFirst with NULL buf pointer */
         pass = TRUE;
         ret = SDequeueFirst(NULLP, &q);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.4.1 */

         /* Begin testcase 3.4.2 */
         /* Call SDequeueFirst with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.4.2");
         pass = TRUE;
         ret = SDequeueFirst(&mBuf, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.4.2 */

         /* Begin testcase 3.4.3 */
         /* Call SQueueLast with valid messages check the contents 
          * with SDequeueFirst */
         sprintf(prntBuf, "Testcase 3.4.3");

         pass = TRUE;
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueLast(m[i], &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueLast(&mBuf, &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueLast failed" );
               goto end;
            }
            if (mBuf != m[NUM_MBUFS -(i +1)])
            {
               pass = FALSE;
               break;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SPutMsg(m[i]);
            if (ret != ROK)
            {
                 pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            }
         }

         /* End testcase 3.4.3 */
         break;
      }
      /* End testing SDeqeueFirst */

      /* Begin testing SDequeueLast */
      case 44:
      {

         sprintf(prntBuf, "Testcase 3.5.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }
         ret = SInitQueue(&q);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.5.1 */
         /* Call SDequeueLast with NULL buf pointer */
         pass = TRUE;
         ret = SDequeueLast(NULLP, &q);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueLast failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.5.1 */

         /* Begin testcase 3.5.2 */
         /* Call SDequeueLast with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.5.2");
         pass = TRUE;
         ret = SDequeueLast(&mBuf, NULL);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueLast failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.5.2 */

         /* Begin testcase 3.5.3 */
         /* Call SQueueFirst with valid messages check the contents 
          * with SDequeueLast */
         sprintf(prntBuf, "Testcase 3.5.3");

         pass = TRUE;
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueFirst(m[i], &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueLast(&mBuf, &q);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueLast failed" );
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SPutMsg(m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            }
         }

         /* End testcase 3.5.3 */

         break;
      }
      /* End testing SDeqeueLast */

      /* Begin testing SCatQueue */
      case 45:
      {

         sprintf(prntBuf, "Testcase 3.6.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }

         ret = SInitQueue(&q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }
         ret = SInitQueue(&q2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.6.1 */
         /* Call SCatQueue with NULL q1 pointer */
         pass = TRUE;
         ret = SCatQueue(NULLP, &q2, Q1Q2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.1 */

         /* Begin testcase 3.6.2 */
         /* Call SCatQueue with NULL q2 pointer */
         sprintf(prntBuf, "Testcase 3.6.2");
         pass = TRUE;
         ret = SCatQueue(&q1, NULLP, Q1Q2);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.2 */

         /* Begin testcase 3.6.3 */
         /* Call SCatQueue with invalid order */
         sprintf(prntBuf, "Testcase 3.6.3");
         pass = TRUE;
         ret = SCatQueue(&q1, &q2, -1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.3 */

         /* Begin testcase 3.6.4 */
         /* Call SCatQueue with empty q1 and q2 */
         sprintf(prntBuf, "Testcase 3.6.4");
         pass = TRUE;
         ret = SCatQueue(&q1, &q2, Q1Q2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.4 */

         /* Begin testcase 3.6.5 */
         /* SCatQueue with empty q1 */
         sprintf(prntBuf, "Testcase 3.6.5");
         pass = TRUE;
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueFirst(m[i], &q2);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         ret = SCatQueue(&q1, &q2, Q2Q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
            goto end;
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueFirst(&mBuf, &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed");
               goto end;
            }
            if (mBuf != m[NUM_MBUFS - (i+1)])
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.5 */

         /* Begin testcase 3.6.6 */
         /* SCatQueue with empty q2 */
         sprintf(prntBuf, "Testcase 3.6.6");
         pass = TRUE;
         SInitQueue(&q1);
         SInitQueue(&q2);
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SQueueLast(m[i], &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         ret = SCatQueue(&q1, &q2, Q2Q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
            goto end;
         }

         ret = SFndLenQueue(&q1, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
            goto end;
         }
         if (qLen != NUM_MBUFS)
            pass = FALSE;

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueFirst(&mBuf, &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed");
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.6 */

         /* Begin testcase 3.6.7 */
         /* Call SCatQueue with valid q1 and q2 with order Q1Q2. */
         sprintf(prntBuf, "Testcase 3.6.7");

         pass = TRUE;
         SInitQueue(&q1);
         SInitQueue(&q2);
         for (i = 0; i < NUM_MBUFS/2; i++)
         {
            ret = SQueueLast(m[i], &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         for (i = NUM_MBUFS/2; i < NUM_MBUFS; i++)
         {
            ret = SQueueLast(m[i], &q2);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         ret = SCatQueue(&q1, &q2, Q1Q2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
            goto end;
         }

         ret = SFndLenQueue(&q1, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
            goto end;
         }
         if (qLen != NUM_MBUFS)
            pass = FALSE;

         ret = SFndLenQueue(&q2, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
            goto end;
         }
         if (qLen != 0)
            pass = FALSE;

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueFirst(&mBuf, &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed");
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.7 */

         /* Begin testcase 3.6.8 */
         /* Call SCatQueue with valid q1 and q2 with order Q2Q1. */
         sprintf(prntBuf, "Testcase 3.6.8");

         pass = TRUE;
         SInitQueue(&q1);
         SInitQueue(&q2);
         for (i = 0; i < NUM_MBUFS/2; i++)
         {
            ret = SQueueFirst(m[i], &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueLast failed" );
               goto end;
            }
         }

         for (i = NUM_MBUFS/2; i < NUM_MBUFS; i++)
         {
            ret = SQueueFirst(m[i], &q2);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SQueueFirst failed" );
               goto end;
            }
         }

         ret = SCatQueue(&q1, &q2, Q2Q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCatQueue failed" );
            goto end;
         }

         ret = SFndLenQueue(&q1, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
            goto end;
         }
         if (qLen != NUM_MBUFS)
            pass = FALSE;

         ret = SFndLenQueue(&q2, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
            goto end;
         }
         if (qLen != 0)
            pass = FALSE;

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueFirst(&mBuf, &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed");
               goto end;
            }
            if (mBuf != m[NUM_MBUFS - (i+1)])
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.6.8 */

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SPutMsg(m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            }
         }
         break;
      }
      /* End testing SCatQueue */


      /* Begin testing SFndLenQueue */
      case 46:
      {

         sprintf(prntBuf, "Testcase 3.7.1");
         ret = SInitQueue(&q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.7.1 */
         /* Call SFndLenQueue with NULL q pointer */
         pass = TRUE;
         ret = SFndLenQueue(NULLP, &qLen);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.7.1 */

         /* Begin testcase 3.7.2 */
         /* Call SFndLenQueue with NULL length pointer */
         sprintf(prntBuf, "Testcase 3.7.2");
         pass = TRUE;
         ret = SFndLenQueue(&q1, NULLP);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed" );
         }
         /* End testcase 3.7.2 */

         break;
      }
      /* End testing SFndLenQueue */

      /* Begin testing SAddQueue */
      case 47:
      {

         sprintf(prntBuf, "Testcase 3.8.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }

         ret = SInitQueue(&q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.8.1 */
         /* Call SAddQueue with NULL buf pointer */
         pass = TRUE;
         ret = SAddQueue(NULLP, &q1, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.8.1 */

         /* Begin testcase 3.8.2 */
         /* Call SAddQueue with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.8.2");
         pass = TRUE;
         ret = SAddQueue(m[0], NULLP, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
            goto end;
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.8.2 */

         /* Begin testcase 3.8.3 */
         /* Call SAddQueue with -ve index */
         sprintf(prntBuf, "Testcase 3.8.3");
         pass = TRUE;
         ret = SAddQueue(m[0], &q1, (QLen)-1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.8.3 */

         /* Begin testcase 3.8.4 */
         /* Call SAddQueue with index > length */
         sprintf(prntBuf, "Testcase 3.8.4");
         pass = TRUE;
         ret = SAddQueue(m[0], &q1, 10);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
            goto end;
         }
         SFndLenQueue(&q1, &qLen);
         if (qLen != 0)
            pass = FALSE;

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.8.4 */

         /* Begin testcase 3.8.5 */
         /* Call SAddQueue with index = 0 */
         sprintf(prntBuf, "Testcase 3.8.5");
         pass = TRUE;
         SInitQueue(&q1);
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SAddQueue(m[i], &q1, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SDequeueFirst(&mBuf, &q1);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDequeueFirst failed");
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         nsPrintResult(prntBuf, pass);
         /* End testcase 3.8.5 */

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SPutMsg(m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            }
         }

         break;
      }
      /* End testing SAddQueue */

      /* Begin testing SRemQueue */
      case 48:
      {

         sprintf(prntBuf, "Testcase 3.9.1");
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SGetMsg(OWNREGION, DFLT_POOL, &m[i]);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
               goto end;
            }
         }

         ret = SInitQueue(&q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.9.1 */
         /* Call SRemQueue with NULL buf pointer */
         pass = TRUE;
         ret = SRemQueue(NULLP, &q1, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.9.1 */

         /* Begin testcase 3.9.2 */
         /* Call SRemQueue with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.9.2");
         pass = TRUE;
         ret = SRemQueue(&mBuf, NULLP, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.9.2 */

         /* Begin testcase 3.9.3 */
         /* Call SRemQueue with -ve index */
         sprintf(prntBuf, "Testcase 3.9.3");
         pass = TRUE;
         ret = SRemQueue(&mBuf, &q1, (QLen)-1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.9.3 */

         /* Begin testcase 3.9.4 */
         /* Call SRemQueue with index > length */
         sprintf(prntBuf, "Testcase 3.9.4");
         pass = TRUE;
         ret = SRemQueue(&mBuf, &q1, 10);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.9.4 */

         /* Begin testcase 3.9.5 */
         /* Add a message at index 0 and call SRemQueue with index = 0 */
         sprintf(prntBuf, "Testcase 3.9.5");
         pass = TRUE;
         SInitQueue(&q1);
         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SAddQueue(m[i], &q1, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
               goto end;
            }
         }

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SRemQueue(&mBuf, &q1, 0);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed");
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         SFndLenQueue(&q1, &qLen);
         if (qLen != 0)
            pass = FALSE;

         nsPrintResult("Testcase 3.9.5", pass);
         /* End testcase 3.9.5 */

         /* Begin testcase 3.9.6  and 3.9.7 */
         /* 3.9.6: Call SRemQueue with index = length */
         /* 3.9.7: Add a message at middle of the queue call SRemQueue with 
          * the same index */
         sprintf(prntBuf, "Testcase 3.9.6");
         pass = TRUE;
         SInitQueue(&q1);
         for (i = 0; i < NUM_MBUFS - 1; i++)
         {
            ret = SAddQueue(m[i], &q1, i);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed" );
               goto end;
            }
         }

         ret = SRemQueue(&mBuf, &q1, NUM_MBUFS);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed");
            goto end;
         }
         nsPrintResult(prntBuf, pass);

         sprintf(prntBuf, "Testcase 3.9.7");
         ret = SFndLenQueue(&q1, &qLen);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SFndLenQueue failed");
            goto end;
         }

         ret = SAddQueue(m[NUM_MBUFS - 1], &q1, qLen/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAddQueue failed");
            goto end;
         }

         ret = SRemQueue(&mBuf, &q1, qLen/2);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed");
            goto end;
         }
         if (mBuf != m[NUM_MBUFS - 1])
            pass = FALSE;

         pass = TRUE;
         for (i = 0; i < NUM_MBUFS - 1; i++)
         {
            ret = SRemQueue(&mBuf, &q1, 0);
            if (ret != ROK)
            {
               pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRemQueue failed");
               goto end;
            }
            if (mBuf != m[i])
            {
               pass = FALSE;
               break;
            }
         }

         SFndLenQueue(&q1, &qLen);
         if (qLen != 0)
            pass = FALSE;

         /* End testcase 3.9.7 */

         for (i = 0; i < NUM_MBUFS; i++)
         {
            ret = SPutMsg(m[i]);
            if (ret != ROK)
            {
                 pass = FALSE;
               NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPutMsg failed" );
            }
         }

         break;
      }
      /* End testing SRemQueue */

      /* Begin testing SExamQueue */
      case 49:
      {

         sprintf(prntBuf, "Testcase 3.10.1");
         ret = SInitQueue(&q1);
         if (ret != ROK)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SInitQueue failed" );
            goto end;
         }

         /* Begin testcase 3.10.1 */
         /* Call SExamQueue with NULL buf pointer */
         pass = TRUE;
         ret = SExamQueue(NULLP, &q1, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.10.1 */

         /* Begin testcase 3.10.2 */
         /* Call SExamQueue with NULL q pointer */
         sprintf(prntBuf, "Testcase 3.10.2");
         pass = TRUE;
         ret = SExamQueue(&mBuf, NULLP, 0);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.10.2 */

         /* Begin testcase 3.10.3 */
         /* Call SExamQueue with -ve index */
         sprintf(prntBuf, "Testcase 3.10.3");
         pass = TRUE;
         ret = SExamQueue(&mBuf, &q1, (QLen)-1);
         if (ret != RFAILED)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.10.3 */

         /* Begin testcase 3.10.4 */
         /* Call SExamQueue with index > length */
         sprintf(prntBuf, "Testcase 3.10.4");
         pass = TRUE;
         ret = SExamQueue(&mBuf, &q1, 10);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
         }
         nsPrintResult(prntBuf, pass);
         /* End testcase 3.10.4 */

         /* Begin testcase 3.10.5 */
         /* Call SExamQueue with index = length */
         sprintf(prntBuf, "Testcase 3.10.5");
         pass = TRUE;
         ret = SExamQueue(&mBuf, &q1, 0);
         if (ret != ROKDNA)
         {
            pass = FALSE;
            NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SExamQueue failed" );
         }
         /* End testcase 3.10.5 */
         /* Deregister this task */
         perm2Completed = TRUE;
         nsTstState = 0xff;
         RETVALUE(ROK);
      }

      case 0xff:
      {
         /* testing completed; so just return */
         RETVALUE(ROK);
      }

      /* End testing SRemQueue */

   }
end:
   nsPrintResult(prntBuf, pass);
   nsTstState++;

   SExitTsk();
   RETVALUE(ROK);

} /* end of tst2PermActvTsk */


/*                                     
*
*       Fun:   negativetst
*
*       Desc:  main test program.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
  
#ifdef ANSI
PUBLIC S16 negativetst
(
void
)
#else
PUBLIC S16 negativetst()
#endif
{
   S16 i;
   S16 ret;
   /* ns013.102 - Modification to fix warning */
#ifndef SS_SINGLE_THREADED
   SsIdx sTskId;
#endif
   Pst pst;
   Buffer *mBuf;
   Bool pass;

   TRC1(tst)

   sprintf(prntBuf, "In negativetst() now \n");
   SPrint(prntBuf);

   nsTstState = 0;
   nsTstCnt = 0;
   sysTimeCnt = 0;
   valueCnt = 0;
   SGetSysTime(&sysTime1);
   SRandom(&value1);
   for (i = 0; i < NMBTSKS; i++)
   {
      tskInitCnt[i] = 0;
   }

   /* Begin Testcase ID: 1.1.1 */
   pass = TRUE;
   /* Register the initialization address of the test task 0 */
   SRegInit(TST3ENT, TSTINST0, tst3ActvInit); 

   if (tskInitCnt[0] != 1)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "SRegInit failed" );
   }

   /* Register the initialization address of the test task 1 */
   SRegInit(TST4ENT, TSTINST0, tst4ActvInit); 

   if (tskInitCnt[1] != 1)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "SRegInit failed" );
   }

   /* Register the initialization address of the test task 2 */
   SRegInit(TST5ENT, TSTINST0, tst5ActvInit); 

   if (tskInitCnt[2] != 1)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "SRegInit failed" );
   }

   nsPrintResult("Testcase 1.1.1", pass);
   /* End Testcase ID: 1.1.1 */

   /* Begin Testcase ID: 1.1.2 */
   pass = TRUE;
   /* Call SRegInit with invalid entity ID */
   ret = SRegInit(ENTNC, TSTINST0, tst5ActvInit); 
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegInit failed" );
   }
   nsPrintResult("Testcase 1.1.2", pass);
   /* End Testcase ID: 1.1.2 */

   /* Begin Testcase ID: 1.1.3 */
   pass = TRUE;
   /* Call SRegInit with invalid inst ID */
   ret = SRegInit(TST5ENT, INSTNC, tst5ActvInit); 
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegInit failed" );
   }
   nsPrintResult("Testcase 1.1.3", pass);
   /* End Testcase ID: 1.1.3 */

   /* Begin Testcase ID: 1.1.4 */
   pass = TRUE;
   /* Call SRegInit with NULL init function */
   ret = SRegInit(TST5ENT, TSTINST0, NULL); 
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegInit failed" );
   }
   /* ns011.102 - Addition to deregister task */
   ret = SDeregInitTskTmr(TST5ENT, TSTINST0); 
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDeregInitTskTmr failed" );
   }
   nsPrintResult("Testcase 1.1.4", pass);
   /* End Testcase ID: 1.1.4 */

   /* Begin Testcase ID: 1.1.5 */
   pass = TRUE;

   nsPrintResult("Testcase 1.1.5", pass);
   /* End Testcase ID: 1.1.5 */

   /* Begin Testcase ID: 1.1.6 */
   pass = TRUE;

   /* Call SRegInit with already registered entity and inst ID, but with a
    * different init function  */

   nsPrintResult("Testcase 1.1.6", pass);
   /* End Testcase ID: 1.1.6 */

   /* Begin Testcase ID: 1.1.7 */
   pass = TRUE;
   /* Call SDeregInitTskTmr for TSK 2 */

   /* Reregister TSK 2 init function */
   SRegInit(TST5ENT, TSTINST0, tst5ActvInit); 

   if (tskInitCnt[2] != 2)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "SRegInit failed" );
   }
   nsPrintResult("Testcase 1.1.7", pass);
   /* End Testcase ID: 1.1.7 */

   /* Begin Testcase Id: 1.2.1 */
   pass = TRUE;
   /* Register with invalid entity ID */
   ret = SRegActvTsk(ENTNC, TSTINST0, TTNORM, PRIOR0, tst3ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   nsPrintResult("Testcase 1.2.1", pass);
   /* End Testcase Id: 1.2.1 */

   /* Begin Testcase Id: 1.2.2 */
   /* Register with invalid inst ID */
   pass = TRUE;
   ret = SRegActvTsk(TST3ENT, INSTNC, TTNORM, PRIOR0, tst3ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   nsPrintResult("Testcase 1.2.2", pass);
   /* End Testcase Id: 1.2.2 */

   /* Begin Testcase Id: 1.2.3 */
   pass = TRUE;

   nsPrintResult("Testcase 1.2.3", pass);
   /* End Testcase Id: 1.2.3 */

   /* Begin Testcase ID: 1.2.4 */
   /* Register the activation address of the test task 0, instance 0 */
   pass = TRUE;
   ret = SRegActvTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0, tst3ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }

   /* Reregister the activation function */
   ret = SRegActvTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0, tst3ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   nsPrintResult("Testcase 1.2.4", pass);
   /* End Testcase ID: 1.2.4 */

   /* Begin Testcase ID: 1.2.5 */
   /* Reregister with different activation function */
   pass = TRUE;
   ret = SRegActvTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0, tst4ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   nsPrintResult("Testcase 1.2.5", pass);
   /* End Testcase ID: 1.2.5 */

   /* Begin Testcase ID: 1.2.6 */
   /* Call SDeregInitTskTmr for TSK 0 */
   pass = TRUE;
   ret = SDeregInitTskTmr(TST3ENT, TSTINST0); 
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDeregInitTskTmr failed" );
   }
   nsPrintResult("Testcase 1.2.6", pass);
   /* End Testcase ID: 1.2.6 */

   /* Begin testing SRegTTsk */
   /* Deregister Task 1 */
   SDeregInitTskTmr(TST4ENT, TSTINST0);

   /* Begin Testcase ID: 1.3.1 */
   /* Call SRegTTsk with invalid Entity ID */
   pass = TRUE;
   ret = SRegTTsk(ENTNC, TSTINST0, TTNORM, PRIOR0, tst4ActvInit, tst4ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }
   nsPrintResult("Testcase 1.3.1", pass);
   /* End Testcase Id: 1.3.1 */

   /* Begin Testcase Id: 1.3.2 */
   /* Call SRegTTsk with invalid inst ID */
   pass = TRUE;
   ret = SRegTTsk(TST4ENT, INSTNC, TTNORM, PRIOR0, tst4ActvInit, tst4ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }
   nsPrintResult("Testcase 1.3.2", pass);
   /* End Testcase Id: 1.3.2 */

   /* Begin Testcase ID: 1.3.3 */
   /* Call SRegTTsk with invalid task type */
   pass = TRUE;
   ret = SRegTTsk(TST4ENT, INSTNC, TTUND, PRIOR0, tst4ActvInit, tst4ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }
   nsPrintResult("Testcase 1.3.3", pass);
   /* End Testcase ID: 1.3.3 */

   /* Begin Testcase Id: 1.3.4 */
   pass = TRUE;

   nsPrintResult("Testcase 1.3.4", pass);
   /* End Testcase Id: 1.3.4 */

   /* Begin Testcase Id: 1.3.5 */
   pass = TRUE;

   nsPrintResult("Testcase 1.3.5", pass);
   /* End Testcase Id: 1.3.5 */

   /* Begin Testcase ID: 1.3.6 */
   /* Register the activation address of the test task 1, instance 0 */
   pass = TRUE;
   ret = SRegTTsk(TST4ENT, TSTINST0, TTNORM, PRIOR0, tst4ActvInit, tst4ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }

   /* Reregister the activation function */
   ret = SRegTTsk(TST4ENT, TSTINST0, TTNORM, PRIOR0, tst4ActvInit, tst4ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }
   nsPrintResult("Testcase 1.3.6", pass);
   /* End Testcase ID: 1.3.6 */

   /* Begin Testcase ID: 1.3.7 */
   /* Reregister with different activation function */
   pass = TRUE;
   ret = SRegTTsk(TST4ENT, TSTINST0, TTNORM, PRIOR0, tst4ActvInit, tst3ActvTsk);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTTsk failed" );
   }
   nsPrintResult("Testcase 1.3.7", pass);
   /* End Testcase ID: 1.3.7 */

   /* Begin Testcase ID: 1.3.8 */
   /* Call SDeregInitTskTmr for TSK 0 */
   pass = TRUE;
   ret = SDeregInitTskTmr(TST4ENT, TSTINST0); 
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDeregInitTskTmr failed" );
   }
   nsPrintResult("Testcase 1.3.8", pass);
   /* End Testcase ID: 1.3.8 */
   /* End testing SRegTTsk */

#ifndef SS_SINGLE_THREADED
   /* Begin testing SCreateSTsk */
   /* Begin Testcase ID: 1.4.1 */
   /* Call SCreateSTsk with invalid priority */
   pass = TRUE;
   ret = SCreateSTsk(PRIORNC, &sTskId);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCreateSTsk failed" );
   }
   nsPrintResult("Testcase 1.4.1", pass);
   /* End Testcase ID: 1.4.1 */

   /* Begin Testcase ID: 1.4.2 */
   /* Call SCreateSTsk with NULL STskId pointer */
   pass = TRUE;
   ret = SCreateSTsk(PRIORNC, NULL);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCreateSTsk failed" );
   }
   nsPrintResult("Testcase 1.4.2", pass);
   /* End Testcase ID: 1.4.2 */
   /* End testing SCreateSTsk */

   /* Begin Testing SDestroySTsk */
   /* Begin testcase ID: 1.5.1 */
   /* Call SDestroySTsk with a invalid STskId */
   pass = TRUE;
   ret = SDestroySTsk((SSTskId)-1);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDestroySTsk failed" );
   }
   nsPrintResult("Testcase 1.5.1", pass);
   /* End testcase ID: 1.5.1 */

   /* Begin testcase ID: 1.5.2 */
   /* Call SDestroySTsk twice with a valid STskId */
   pass = TRUE;
   ret = SCreateSTsk(SS_NORM_TSK_PRI, &sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCreateSTsk failed" );
   }

   ret = SDestroySTsk(sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDestroySTsk failed" );
   }

   ret = SDestroySTsk(sTskId);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDestroySTsk failed" );
   }
   nsPrintResult("Testcase 1.5.2", pass);
   /* End testcase ID: 1.5.2 */
   /* End Testing SDestroySTsk */

   /* Begin testing SAttachTTsk */
   /* Create a system task */
   pass = TRUE;
   ret = SCreateSTsk(SS_NORM_TSK_PRI, &sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCreateSTsk failed" );
   }
   
   /* Begin testcase ID: 1.6.1 */
   /* First register the Tapa Task before calling SAttachTTsk */
   pass = TRUE;
   if (SRegTTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0,
                               tst3ActvInit, tst3ActvTsk) != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ERRZERO, "SRegTTsk failed" );
   }

   /* Call SAttachTTsk with invalid Entity Id */
   ret = SAttachTTsk(ENTNC, TSTINST0, sTskId);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }
   nsPrintResult("Testcase 1.6.1", pass);
   /* End testcase ID: 1.6.1 */

   /* Begin testcase ID: 1.6.2 */
   /* Call SAttachTTsk with invalid Inst Id */
   pass = TRUE;
   ret = SAttachTTsk(TST3ENT, INSTNC, sTskId);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }
   nsPrintResult("Testcase 1.6.2", pass);
   /* End testcase ID: 1.6.2 */

   /* Begin testcase ID: 1.6.3 */
   /* Call SAttachTTsk with invalid system task Id */
   pass = TRUE;
   ret = SAttachTTsk(TST3ENT, TSTINST0,(SSTskId) -1);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }
   nsPrintResult("Testcase 1.6.3", pass);
   /* End testcase ID: 1.6.3 */

   /* Begin testcase ID: 1.6.4 */
   /* Call SAttachTTsk twice with valid parameters */
   pass = TRUE;
   ret = SAttachTTsk(TST3ENT, TSTINST0, sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }

   /* Reattach the same task */
   ret = SAttachTTsk(TST3ENT, TSTINST0, sTskId);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }
   nsPrintResult("Testcase 1.6.4", pass);
   /* End testcase ID: 1.6.4 */

   /* Begin testcase ID: 1.6.5 */
   /* Call SCreateSTsk, SAttachTTsk, SDestroySTsk and 
    * SAttachTTsk(with a new valid STskId) */

   pass = TRUE;
   ret = SDestroySTsk(sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDestroySTsk failed" );
   }

   ret = SCreateSTsk(SS_NORM_TSK_PRI, &sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SCreateSTsk failed" );
   }

   ret = SAttachTTsk(TST3ENT, TSTINST0, sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }
   nsPrintResult("Testcase 1.6.5", pass);
   /* End testcase ID: 1.6.5 */
   /* End testing SAttachTTsk */

   /* Begin testing SDetachTTsk */
   /* Begin testcase ID: 1.7.1 */
   /* Call SDetachTTsk with invalid Entity Id */
   pass = TRUE;
   ret = SDetachTTsk(ENTNC, TSTINST0);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDetachTTsk failed" );
   }
   nsPrintResult("Testcase 1.7.1", pass);
   /* End testcase ID: 1.7.1 */

   /* Begin testcase ID: 1.7.2 */
   /* Call SDetachTTsk with invalid Inst Id */
   pass = TRUE;
   ret = SDetachTTsk(TST3ENT, INSTNC);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDetachTTsk failed" );
   }
   nsPrintResult("Testcase 1.7.2", pass);
   /* End testcase ID: 1.7.2 */

   /* Begin testcase ID: 1.7.3 */
   /* Call SDetachTTsk twice with valid params */
   pass = TRUE;
   ret = SDetachTTsk(TST3ENT, TSTINST0);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDetachTTsk failed" );
   }

   ret = SDetachTTsk(TST3ENT, TSTINST0);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDetachTTsk failed" );
   }
   nsPrintResult("Testcase 1.7.3", pass);
   /* End testcase ID: 1.7.3 */


   /* Begin testcase ID: 1.7.4 */
   /* Call SAttachTTsk, SDetachTTsk, SAttachTTsk and SDetachTTsk 
    * (use same STskId) */
   pass = TRUE;
   ret = SAttachTTsk(TST3ENT, TSTINST0, sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }

   ret = SDetachTTsk(TST3ENT, TSTINST0);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDetachTTsk failed" );
   }

   ret = SAttachTTsk(TST3ENT, TSTINST0, sTskId);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SAttachTTsk failed" );
   }

   nsPrintResult("Testcase 1.7.4", pass);
   /* End testcase ID: 1.7.4 */
   /* End testing SDetachTTsk */
#else /* SS_SINGLE_THREADED */
   SRegActvTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0, tst3ActvTsk);
#endif /* SS_SINGLE_THREADED */

   /* Begin testing SRegTmr */
   /* Begin testcase 4.1.1 */
   /* Call SRegTmr with invalid Entity Id */
   pass = TRUE;
   ret = SRegTmr(ENTNC, TSTINST0, TSK0TMR, tst3ActvTmr);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.1.1", pass);
   /* End testcase 4.1.1 */

   /* Begin testcase 4.1.2 */
   /* Call SRegTmr with invalid inst Id */
   pass = TRUE;
   ret = SRegTmr(TST3ENT, INSTNC, TSK0TMR, tst3ActvTmr);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.1.2", pass);
   /* End testcase 4.1.2 */

   /* Begin testcase 4.1.3 */
   /* Call SRegTmr with NULL timer activation function */
   pass = TRUE;
   ret = SRegTmr(TST3ENT, TSTINST0, TSK0TMR, NULL);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.1.3", pass);
   /* End testcase 4.1.3 */

   /* Begin testcase 4.1.4 */
   /* Call SRegTmr for a unregistered task */
   pass = TRUE;
   ret = SRegTmr(TST5ENT + 20, TSTINST0, TSK2TMR, tst5ActvTmr);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.1.4", pass);
   /* End testcase 4.1.4 */

   /* Begin testcase 4.1.5 */
   /* Call SRegTmr twice for a same task */
   pass = TRUE;
   ret = SRegTmr(TST3ENT, TSTINST0, TSK0TMR, tst3ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }

   ret = SRegTmr(TST3ENT, TSTINST0, TSK0TMR, tst3ActvTmr);
   /* ns011.102 - Modification to fix bug */
   if (ret == ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.1.5", pass);
   /* End testcase 4.1.5 */

   /* Begin testcase 4.2.1 */
   /* Call DeregInitTskTmr */
   pass = TRUE;
   ret = SDeregInitTskTmr(TST3ENT, TSTINST0);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDeregInitTskTmr failed" );
   }
   nsPrintResult("Testcase 4.2.1", pass);
   /* End testcase 4.2.1 */

   /* Begin testcase 4.2.2 */
   /* Register 3 timers for 3 different tasks and check if they are called */
   pass = TRUE;

   SDeregInitTskTmr(TST3ENT, TSTINST0);
   SDeregInitTskTmr(TST4ENT, TSTINST0);
   SDeregInitTskTmr(TST5ENT, TSTINST0);

   /* Register the activation address of the test task 0, instance 0 */
   SRegActvTsk(TST3ENT, TSTINST0, TTNORM, PRIOR0, tst3ActvTsk);

   /* Register the activation address of the test task 1, instance 0 */
   SRegActvTsk(TST4ENT, TSTINST0, TTNORM, PRIOR0, tst4ActvTsk);

   /* Register the activation address of the test task 2, instance 0 */
   SRegActvTsk(TST5ENT, TSTINST0, TTNORM, PRIOR0, tst5ActvTsk);
   
   ret = SRegTmr(TST3ENT, TSTINST0, TIMERES, tst3ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   
   ret = SRegTmr(TST4ENT, TSTINST0, TIMERES, tst4ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }

   ret = SRegTmr(TST5ENT, TSTINST0, TIMERES, tst5ActvTmr);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegTmr failed" );
   }
   nsPrintResult("Testcase 4.2.2", pass);
   /* End testcase 4.2.2 */
   /* End testing SRegTmr */


   /* Begin testing SPstTsk */
   pass = TRUE;
   pst.event     = 0;               /* event */
   pst.prior     = PRIOR0;          /* priority */
   /* ns013.102 - Modification to fix warning */
   pst.route     = RTESPEC;         /* route */
   pst.dstProcId = SFndProcId();    /* destination processor id */
   pst.dstEnt    = TST4ENT;         /* destination entity */
   pst.dstInst   = TSTINST0;        /* destination instance */
   pst.srcProcId = SFndProcId();    /* source processor id */
   pst.srcEnt    = TST3ENT;         /* source entity */
   pst.srcInst   = TSTINST0;        /* source instance */

   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }

   /* Begin testcase 1.9.1 */
   /* Call SPstTsk with invalid Ent Id */
   pst.dstEnt = ENTNC;
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.1", pass);
   /* End testcase 1.9.1 */

   /* Begin testcase 1.9.2 */
   /* Call SPstTsk with invalid inst Id */
   pass = TRUE;
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.dstEnt = TST4ENT;
   pst.dstInst = INSTNC;
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.2", pass);
   /* End testcase 1.9.2 */

   /* Begin testcase 1.9.3 */
   /* Call SPstTsk with unregistered source task */
   pass = TRUE;
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.dstInst = TSTINST0;
   pst.srcEnt = TST3ENT + 20;
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.3", pass);
   /* End testcase 1.9.3 */

   /* Begin testcase 1.9.4 */
   /* Call SPstTsk with unregistered destination task */
   pass = TRUE;
#ifndef SS_DRVR_SUPPORT
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.srcEnt = TST3ENT;
   pst.dstEnt = TST4ENT + 20;
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
#endif /*SS_DRVR_SUPPORT */
   nsPrintResult("Testcase 1.9.4", pass);
   /* End testcase 1.9.4 */

   /* Begin testcase 1.9.5 */
   /* Call SPstTsk with NULL pst pointer */
   pass = TRUE;
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   ret = SPstTsk(NULLP, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.5", pass);
   /* End testcase 1.9.5 */

   /* Begin testcase 1.9.6 */
   /* Call SPstTsk with NULL mBuf pointer */
   pass = TRUE;
   ret = SPstTsk(&pst, NULL);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.6", pass);
   /* End testcase 1.9.6 */

   /* Begin testcase 1.9.7 */
   /* Call SPstTsk with previously deregistered task as source task */
   /* First register and deregister a task */
   pass = TRUE;
   ret = SRegActvTsk(TST5ENT + 20, TSTINST0, TTNORM, PRIOR0, tst5ActvTsk);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SRegActvTsk failed" );
   }
   ret = SDeregInitTskTmr(TST5ENT + 20, TSTINST0);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SDeregInitTskTmr failed" );
   }
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.srcEnt = TST5ENT + 20; 
   pst.dstEnt = TST5ENT; 
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.7", pass);
   /* End testcase 1.9.7 */

   /* Begin testcase 1.9.8 */
   /* Call SPstTsk with previously deregistered task as dst task */
   pass = TRUE;
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.srcEnt = TST5ENT; 
   pst.dstEnt = TST5ENT + 20; 
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
   nsPrintResult("Testcase 1.9.8", pass);
#ifndef SS_DRVR_SUPPORT
   ret = SGetMsg(OWNREGION, SP_POOL, &mBuf);
   if (ret != ROK)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SGetMsg failed" );
   }
   pst.srcEnt = TST5ENT; 
   pst.dstEnt = TST5ENT + 20; 
   ret = SPstTsk(&pst, mBuf);
   if (ret != RFAILED)
   {
      pass = FALSE;
      NSLOGERROR( ERRCLS_DEBUG, ENSXXX, ret, "SPstTsk failed" );
   }
#endif
   nsPrintResult("Testcase 1.9.8", pass);
   /* End testcase 1.9.7 */
   /* End testing SPstTsk */

   /* Register the activation address of the first test permanent task */
   SRegActvTsk(TSTPERMENT, TSTINST2, TTPERM, PRIOR3, tst2PermActvTsk);
 
   /* This section manipulates the static memory */

   /* Get static memory */
   SGetSMem(OWNREGION, (Size) ((TSTTIMES + 1) * MAXSMEMLEN), &sPool);

   SDeregInitTskTmr(TST3ENT, TSTINST0);
   SDeregInitTskTmr(TST4ENT, TSTINST0);
   SDeregInitTskTmr(TST5ENT, TSTINST0);

   RETVALUE(ROK);

} /* end of tst */


/*                                     
*
*       Fun:   tst3ActvInit
*
*       Desc:  Sample function for test task 0 initialization.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst3ActvInit
(
Ent ent,                    /* entity */
Inst inst,                  /* instance */
Region region,              /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 tst3ActvInit(ent, inst, region, reason)
Ent ent;                    /* entity */
Inst inst;                  /* instance */
Region region;              /* region */
Reason reason;              /* reason */
#endif
{
   TRC2(tst3ActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   tskInitCnt[0]++;
   RETVALUE(ROK);

} /* end of tst3ActvInit */


/*                                     
*
*       Fun:   tst4ActvInit
*
*       Desc:  Sample function for test task 1 initialization.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst4ActvInit
(
Ent ent,                    /* entity */
Inst inst,                  /* instance */
Region region,              /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 tst4ActvInit(ent,inst,region,reason)
Ent ent;                    /* entity */
Inst inst;                  /* instance */
Region region;              /* region */
Reason reason;              /* reason */
#endif
{
   TRC2(tst4ActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   tskInitCnt[1]++;
   RETVALUE(ROK);

} /* end of tst4ActvInit */


/*                                     
*
*       Fun:   tst5ActvInit
*
*       Desc:  Sample function for test task 2 initialization.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst5ActvInit
(
Ent ent,                    /* entity */
Inst inst,                  /* instance */
Region region,              /* region */
Reason reason               /* reason */
)
#else
PUBLIC S16 tst5ActvInit(ent,inst,region,reason)
Ent ent;                    /* entity */
Inst inst;                  /* instance */
Region region;              /* region */
Reason reason;              /* reason */
#endif
{
   TRC2(tst5ActvInit)

   UNUSED(ent);
   UNUSED(inst);
   UNUSED(region);
   UNUSED(reason);

   tskInitCnt[2]++;
   RETVALUE(ROK);

} /* end of tst5ActvInit */


/*                                     
*
*       Fun:   tst3ActvTsk
*
*       Desc:  Sample function for test task 0 activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst3ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst3ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(tst3ActvTsk)

   SPutMsg(mBuf);
   RETVALUE(ROK);

} /* end of tst3ActvTsk */



/*                                     
*
*       Fun:   tst4ActvTsk
*
*       Desc:  Sample function for test task 1 activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst4ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst4ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(tst4ActvTsk)
 
   SPutMsg(mBuf);
   RETVALUE(ROK);

} /* end of tst4ActvTsk */


/*                                     
*
*       Fun:   tst5ActvTsk
*
*       Desc:  Sample function for first test task activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst5ActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 tst5ActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(tst5ActvTsk)

   SPutMsg(mBuf);
   RETVALUE(ROK);

} /* end of tst5ActvTsk */


/*                                     
*
*       Fun:   tst3ActvTmr
*
*       Desc:  Sample function for task 0 timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst3ActvTmr
(
void
)
#else
PUBLIC S16 tst3ActvTmr()
#endif
{
   TRC2(tst3ActvTmr)

   tsk3TmrCnt++;
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst3ActvTmr */

/*                                     
*
*       Fun:   tst4ActvTmr
*
*       Desc:  Sample function for task 1 timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst4ActvTmr
(
void
)
#else
PUBLIC S16 tst4ActvTmr()
#endif
{
   TRC2(tst4ActvTmr)

   tsk4TmrCnt++;
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst4ActvTmr */


/*                                     
*
*       Fun:   tst5ActvTmr
*
*       Desc:  Sample function for first test timer activation.
*
*       Ret:   ROK       - ok
*
*       Notes: None
*
*       File:  ns_acc1.c
*
*/
 
#ifdef ANSI
PUBLIC S16 tst5ActvTmr
(
void
)
#else
PUBLIC S16 tst5ActvTmr()
#endif
{
   TRC2(tst5ActvTmr)

   tsk5TmrCnt++;
   SExitTsk();
   RETVALUE(ROK);

} /* end of tst5ActvTmr */

  
/********************************************************************30**
  
         End of file: ns_acc1.c 1.2  -  08/11/98 12:02:23
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bsr  1. initial release.
1.2          ---      bsr  2. reorganization
           ns011.102  bjp  3. Modification of test cases
1.2+       ns013.102  bjp  1. Modification to fix warnings
*********************************************************************91*/
