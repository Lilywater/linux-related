/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     Include file
  
     Desc:     Acceptance test suit
 
     File:     ns_acc.h

     Sid:      ns_acc.h 1.1  -  08/11/98 12:00:53
  
     Prg:      bsr
  
*********************************************************************21*/



#ifndef __NSACCH__
#define __NSACCH__

#define TST0ENT    (ENTNS+1) /* test 0 entity */
#define TST1ENT    (ENTNS+2) /* test 1 entity */
#define TST2ENT    (ENTNS+3) /* test 2 entity */
#define TST3ENT    (ENTNS+4) /* test 0 entity */
#define TST4ENT    (ENTNS+5) /* test 1 entity */
#define TST5ENT    (ENTNS+6) /* test 2 entity */
#define TSTPERMENT (ENTNS+7) /* test permanent entity */
#if 1 /* ns003.12 addition */
#define TST6ENT    (ENTNS+8) /* test 2 entity */
#endif /* end ns003.12 addition */
#define TSTINST0     0       /* test instance 0 */
#define TSTINST1     1       /* test instance 1 */
#define TSTINST2     2       /* test instance 2 */
#define TSTINST3     3       /* test instance 3 */

#define TSK0TMR      10
#define TSK1TMR      10
#define TSK2TMR      100

#define TIMERES      10

#define NMBTSKS      3       /* number of tasks */
#define MAXMSGLEN    256     /* maximum message length */

#define TSTTIMES     10      /* number of test for certain function */
#define MAXSMEMLEN   0x20    /* maximum static memory length */

#define SMSTASID     0
#define SMSTASPOOL   1
#define SMSTADPOOL   2
#define SMSTADQ      3
#define SMSTAENT     4
#define SMSTSLOOP    5
#define SMSTSDQ      6
#define SMSTSENT     7

#define NMBPRIOR     4

#define DBUF_SIZE    1024   /* keep this as even number */
#define NUM_MBUFS    10     /* Keep this as even number */


/* local defines */
#define PERMENT1     5
#define PERMENT2     6
#define MAXTSTCNT    0
#define BSIZE        100
#define NMBTMRTSKS   2
#define TSKCNT       1000

#define SMSTASID     0
#define SMSTASPOOL   1
#define SMSTADPOOL   2
#define SMSTADQ      3
#define SMSTAENT     4
#define SMSTSLOOP    5
#define SMSTSDQ      6
#define SMSTSENT     7

#endif /* __NSACCH__ */


/********************************************************************30**
  
         End of file: ns_acc.h 1.1  -  08/11/98 12:00:53
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bsr  1. initial release

*********************************************************************91*/
