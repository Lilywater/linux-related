/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     System Services -- identification file

     Type:     C source file

     Desc:     Version information

     File:     ss_id.c

     Sid:      ss_id.c 1.2  -  10/14/98 14:12:23

     Prg:      kp

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */

#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */


/* header/extern include files (.x) */

#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */


/* defines */

#define SSSWMV 1              /* main version */
#define SSSWMR 3              /* main revision */
#define SSSWBV 0              /* branch version */
/* ss035.103 */
#define SSSWBR 35            /* branch revision */
#define SSSWPN "1078001"      /* part number */


/* public variable declarations */


/* copyright banner */

CONSTANT PUBLIC Txt ssBan1[] ={"(c) COPYRIGHT 1989-1998, Trillium Digital Systems, Inc."};
CONSTANT PUBLIC Txt ssBan2[] ={"                 All rights reserved."};

/* system id */
  
CONSTANT PUBLIC SystemId ssSId =
{
   SSSWMV,                    /* main version */
   SSSWMR,                    /* main revision */
   SSSWBV,                    /* branch version */
   SSSWBR,                    /* branch revision */
   SSSWPN,                    /* part number */
};



/********************************************************************30**

         End of file: ss_id.c 1.2  -  10/14/98 14:12:23

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. initial release

1.2          ---      kp   1. Changed version number for release 1.3
                     bdu   1. branch revision for ss015.13
                     zo    1. branch revision for ss016.13
                     jn    1. branch revision for ss017.13
                     bp    1. branch revision for ss018.13
                     bp    1. branch revision for ss019.103
                     bjp   1. branch revision for ss020.103
                     bjp   1. branch revision for ss021.103
                     bjp   1. branch revision for ss022.103
                     bjp   1. branch revision for ss023.103
                     bjp   1. branch revision for ss024.103
                     bjp   1. branch revision for ss025.103
                     bjp   1. branch revision for ss026.103
                     bjp   1. branch revision for ss027.103
                     bjp   1. branch revision for ss028.103
                     kkj   1. branch revision for ss029.103
                     kkj   1. branch revision for ss030.103
                     kkj   1. branch revision for ss031.103
1.3+ ss032.103       kkj   1. branch revision for ss032.103
1.3+ ss033.103       pdb   1. branch revision for ss033.103
1.3+ ss034.103       pdb   1. branch revision for ss034.103
1.3+ ss035.103       pdb   1. branch revision for ss035.103
*********************************************************************91*/
