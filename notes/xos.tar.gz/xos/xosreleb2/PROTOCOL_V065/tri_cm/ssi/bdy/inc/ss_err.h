/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     System Services - errors
  
     Type:     C include file
  
     Desc:     Error defines required by System Services.
  
     File:     ss_err.h
  
     Sid:      ss_err.h 1.3  -  10/14/98 14:10:51
   
     Prg:      kp
  
*********************************************************************21*/

#ifndef __SSERRH__
#define __SSERRH__

#ifdef __cplusplus
extern "C" {
#endif



/* log error macro */
/* ss029.103: modification: SFndProcId is not supported with multiple procs */
#ifndef SS_MULTIPLE_PROCS
#define SSLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError((Ent)ENTSS, (Inst)0 , SFndProcId(), \
             (Txt *)__FILE__, __LINE__, \
             (ErrCls)errCls, (ErrVal)errCode, \
             (ErrVal)errVal, (Txt *)errDesc)
#else /* SS_MULTIPLE_PROCS */
#define SSLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError((Ent)ENTSS, (Inst)0 , PROCNC, \
             (Txt *)__FILE__, __LINE__, \
             (ErrCls)errCls, (ErrVal)errCode, \
             (ErrVal)errVal, (Txt *)errDesc)
#endif /* SS_MULTIPLE_PROCS */

/* defines */
#define   ERRSS       0
#define   ESSBASE     (ERRSS + 0)    /* reserved */
#define   ESSXXX      (ESSBASE)      /* reserved */


#define   ESS001      (ERRSS +    1)    /*     ss_acc.c:  19 */
#define   ESS002      (ERRSS +    2)    /*     ss_acc.c:  20 */
#define   ESS003      (ERRSS +    3)    /*     ss_acc.c: 529 */
#define   ESS004      (ERRSS +    4)    /*     ss_acc.c: 579 */
#define   ESS005      (ERRSS +    5)    /*     ss_acc.c: 587 */
#define   ESS006      (ERRSS +    6)    /*     ss_acc.c: 595 */
#define   ESS007      (ERRSS +    7)    /*     ss_acc.c: 603 */
#define   ESS008      (ERRSS +    8)    /*     ss_acc.c: 642 */
#define   ESS009      (ERRSS +    9)    /*     ss_acc.c: 653 */
#define   ESS010      (ERRSS +   10)    /*     ss_acc.c: 662 */
#define   ESS011      (ERRSS +   11)    /*     ss_acc.c: 671 */
#define   ESS012      (ERRSS +   12)    /*     ss_acc.c: 680 */
#define   ESS013      (ERRSS +   13)    /*     ss_acc.c: 741 */
#define   ESS014      (ERRSS +   14)    /*     ss_acc.c: 751 */
#define   ESS015      (ERRSS +   15)    /*     ss_acc.c: 762 */
#define   ESS016      (ERRSS +   16)    /*     ss_acc.c: 783 */
#define   ESS017      (ERRSS +   17)    /*     ss_acc.c: 826 */
#define   ESS018      (ERRSS +   18)    /*     ss_acc.c: 836 */
#define   ESS019      (ERRSS +   19)    /*     ss_acc.c: 847 */
#define   ESS020      (ERRSS +   20)    /*     ss_acc.c: 868 */
#define   ESS021      (ERRSS +   21)    /*     ss_acc.c:1227 */
#define   ESS022      (ERRSS +   22)    /*     ss_acc.c:1233 */
#define   ESS023      (ERRSS +   23)    /*     ss_acc.c:1236 */
#define   ESS024      (ERRSS +   24)    /*     ss_acc.c:1250 */
#define   ESS025      (ERRSS +   25)    /*     ss_acc.c:1301 */
#define   ESS026      (ERRSS +   26)    /*     ss_acc.c:1307 */
#define   ESS027      (ERRSS +   27)    /*     ss_acc.c:1310 */
#define   ESS028      (ERRSS +   28)    /*     ss_acc.c:1324 */
#define   ESS029      (ERRSS +   29)    /*     ss_acc.c:1365 */
#define   ESS030      (ERRSS +   30)    /*     ss_acc.c:1420 */
#define   ESS031      (ERRSS +   31)    /*     ss_acc.c:1431 */
#define   ESS032      (ERRSS +   32)    /*     ss_acc.c:1485 */
#define   ESS033      (ERRSS +   33)    /*     ss_acc.c:1640 */
#define   ESS034      (ERRSS +   34)    /*     ss_acc.c:1645 */
#define   ESS035      (ERRSS +   35)    /*     ss_acc.c:1653 */
#define   ESS036      (ERRSS +   36)    /*     ss_acc.c:1658 */
#define   ESS037      (ERRSS +   37)    /*     ss_acc.c:1663 */
#define   ESS038      (ERRSS +   38)    /*     ss_acc.c:1668 */
#define   ESS039      (ERRSS +   39)    /*     ss_acc.c:1680 */
#define   ESS040      (ERRSS +   40)    /*     ss_acc.c:1683 */
#define   ESS041      (ERRSS +   41)    /*     ss_acc.c:1687 */
#define   ESS042      (ERRSS +   42)    /*     ss_acc.c:1702 */
#define   ESS043      (ERRSS +   43)    /*     ss_acc.c:1709 */
#define   ESS044      (ERRSS +   44)    /*     ss_acc.c:1726 */
#define   ESS045      (ERRSS +   45)    /*     ss_acc.c:1733 */
#define   ESS046      (ERRSS +   46)    /*     ss_acc.c:1747 */
#define   ESS047      (ERRSS +   47)    /*     ss_acc.c:1765 */
#define   ESS048      (ERRSS +   48)    /*     ss_acc.c:1769 */
#define   ESS049      (ERRSS +   49)    /*     ss_acc.c:1792 */
#define   ESS050      (ERRSS +   50)    /*     ss_acc.c:1795 */
#define   ESS051      (ERRSS +   51)    /*     ss_acc.c:1798 */
#define   ESS052      (ERRSS +   52)    /*     ss_acc.c:1801 */
#define   ESS053      (ERRSS +   53)    /*     ss_acc.c:1809 */
#define   ESS054      (ERRSS +   54)    /*     ss_acc.c:1812 */
#define   ESS055      (ERRSS +   55)    /*     ss_acc.c:1815 */
#define   ESS056      (ERRSS +   56)    /*     ss_acc.c:1818 */
#define   ESS057      (ERRSS +   57)    /*     ss_acc.c:1839 */
#define   ESS058      (ERRSS +   58)    /*     ss_acc.c:1843 */
#define   ESS059      (ERRSS +   59)    /*     ss_acc.c:1860 */
#define   ESS060      (ERRSS +   60)    /*     ss_acc.c:1864 */
#define   ESS061      (ERRSS +   61)    /*     ss_acc.c:1877 */
#define   ESS062      (ERRSS +   62)    /*     ss_acc.c:1884 */
#define   ESS063      (ERRSS +   63)    /*     ss_acc.c:1898 */
#define   ESS064      (ERRSS +   64)    /*     ss_acc.c:1901 */
#define   ESS065      (ERRSS +   65)    /*     ss_acc.c:1905 */
#define   ESS066      (ERRSS +   66)    /*     ss_acc.c:1924 */
#define   ESS067      (ERRSS +   67)    /*     ss_acc.c:1927 */
#define   ESS068      (ERRSS +   68)    /*     ss_acc.c:1930 */
#define   ESS069      (ERRSS +   69)    /*     ss_acc.c:1933 */
#define   ESS070      (ERRSS +   70)    /*     ss_acc.c:1936 */
#define   ESS071      (ERRSS +   71)    /*     ss_acc.c:1939 */
#define   ESS072      (ERRSS +   72)    /*     ss_acc.c:1955 */
#define   ESS073      (ERRSS +   73)    /*     ss_acc.c:1964 */
#define   ESS074      (ERRSS +   74)    /*     ss_acc.c:1969 */
#define   ESS075      (ERRSS +   75)    /*     ss_acc.c:1976 */
#define   ESS076      (ERRSS +   76)    /*     ss_acc.c:1993 */
#define   ESS077      (ERRSS +   77)    /*     ss_acc.c:2001 */
#define   ESS078      (ERRSS +   78)    /*     ss_acc.c:2006 */
#define   ESS079      (ERRSS +   79)    /*     ss_acc.c:2012 */
#define   ESS080      (ERRSS +   80)    /*     ss_acc.c:2028 */
#define   ESS081      (ERRSS +   81)    /*     ss_acc.c:2032 */
#define   ESS082      (ERRSS +   82)    /*     ss_acc.c:2036 */
#define   ESS083      (ERRSS +   83)    /*     ss_acc.c:2061 */
#define   ESS084      (ERRSS +   84)    /*     ss_acc.c:2064 */
#define   ESS085      (ERRSS +   85)    /*     ss_acc.c:2068 */
#define   ESS086      (ERRSS +   86)    /*     ss_acc.c:2076 */
#define   ESS087      (ERRSS +   87)    /*     ss_acc.c:2079 */
#define   ESS088      (ERRSS +   88)    /*     ss_acc.c:2084 */
#define   ESS089      (ERRSS +   89)    /*     ss_acc.c:2109 */
#define   ESS090      (ERRSS +   90)    /*     ss_acc.c:2112 */
#define   ESS091      (ERRSS +   91)    /*     ss_acc.c:2120 */
#define   ESS092      (ERRSS +   92)    /*     ss_acc.c:2127 */
#define   ESS093      (ERRSS +   93)    /*     ss_acc.c:2132 */
#define   ESS094      (ERRSS +   94)    /*     ss_acc.c:2143 */
#define   ESS095      (ERRSS +   95)    /*     ss_acc.c:2148 */
#define   ESS096      (ERRSS +   96)    /*     ss_acc.c:2166 */
#define   ESS097      (ERRSS +   97)    /*     ss_acc.c:2172 */
#define   ESS098      (ERRSS +   98)    /*     ss_acc.c:2189 */
#define   ESS099      (ERRSS +   99)    /*     ss_acc.c:2195 */
#define   ESS100      (ERRSS +  100)    /*     ss_acc.c:2215 */
#define   ESS101      (ERRSS +  101)    /*     ss_acc.c:2235 */
#define   ESS102      (ERRSS +  102)    /*     ss_acc.c:2274 */
#define   ESS103      (ERRSS +  103)    /*     ss_acc.c:2287 */
#define   ESS104      (ERRSS +  104)    /*     ss_acc.c:2305 */
#define   ESS105      (ERRSS +  105)    /*     ss_acc.c:2317 */
#define   ESS106      (ERRSS +  106)    /*     ss_acc.c:2333 */
#define   ESS107      (ERRSS +  107)    /*     ss_acc.c:2356 */
#define   ESS108      (ERRSS +  108)    /*     ss_acc.c:2388 */
#define   ESS109      (ERRSS +  109)    /*     ss_acc.c:2417 */
#define   ESS110      (ERRSS +  110)    /*     ss_acc.c:2449 */
#define   ESS111      (ERRSS +  111)    /*     ss_acc.c:2465 */
#define   ESS112      (ERRSS +  112)    /*     ss_acc.c:2477 */
#define   ESS113      (ERRSS +  113)    /*     ss_acc.c:2491 */
#define   ESS114      (ERRSS +  114)    /*     ss_acc.c:2504 */
#define   ESS115      (ERRSS +  115)    /*     ss_acc.c:2533 */
#define   ESS116      (ERRSS +  116)    /*     ss_acc.c:2567 */
#define   ESS117      (ERRSS +  117)    /*     ss_acc.c:2569 */
#define   ESS118      (ERRSS +  118)    /*     ss_acc.c:2573 */
#define   ESS119      (ERRSS +  119)    /*     ss_acc.c:2575 */
#define   ESS120      (ERRSS +  120)    /*     ss_acc.c:2590 */
#define   ESS121      (ERRSS +  121)    /*     ss_acc.c:2592 */
#define   ESS122      (ERRSS +  122)    /*     ss_acc.c:2596 */
#define   ESS123      (ERRSS +  123)    /*     ss_acc.c:2598 */
#define   ESS124      (ERRSS +  124)    /*     ss_acc.c:2612 */
#define   ESS125      (ERRSS +  125)    /*     ss_acc.c:2621 */
#define   ESS126      (ERRSS +  126)    /*     ss_acc.c:2623 */
#define   ESS127      (ERRSS +  127)    /*     ss_acc.c:2638 */
#define   ESS128      (ERRSS +  128)    /*     ss_acc.c:2667 */
#define   ESS129      (ERRSS +  129)    /*     ss_acc.c:2669 */
#define   ESS130      (ERRSS +  130)    /*     ss_acc.c:2680 */
#define   ESS131      (ERRSS +  131)    /*     ss_acc.c:2698 */
#define   ESS132      (ERRSS +  132)    /*     ss_acc.c:2723 */
#define   ESS133      (ERRSS +  133)    /*     ss_acc.c:2735 */
#define   ESS134      (ERRSS +  134)    /*     ss_acc.c:2740 */
#define   ESS135      (ERRSS +  135)    /*     ss_acc.c:2747 */
#define   ESS136      (ERRSS +  136)    /*     ss_acc.c:2753 */
#define   ESS137      (ERRSS +  137)    /*     ss_acc.c:2773 */
#define   ESS138      (ERRSS +  138)    /*     ss_acc.c:2782 */
#define   ESS139      (ERRSS +  139)    /*     ss_acc.c:2787 */
#define   ESS140      (ERRSS +  140)    /*     ss_acc.c:2794 */
#define   ESS141      (ERRSS +  141)    /*     ss_acc.c:2817 */
#define   ESS142      (ERRSS +  142)    /*     ss_acc.c:2822 */
#define   ESS143      (ERRSS +  143)    /*     ss_acc.c:2828 */
#define   ESS144      (ERRSS +  144)    /*     ss_acc.c:2833 */
#define   ESS145      (ERRSS +  145)    /*     ss_acc.c:2881 */
#define   ESS146      (ERRSS +  146)    /*     ss_acc.c:2935 */
#define   ESS147      (ERRSS +  147)    /*     ss_acc.c:2968 */
#define   ESS148      (ERRSS +  148)    /*     ss_acc.c:3243 */
#define   ESS149      (ERRSS +  149)    /*     ss_acc.c:3246 */
#define   ESS150      (ERRSS +  150)    /*     ss_acc.c:3250 */
#define   ESS151      (ERRSS +  151)    /*     ss_acc.c:3260 */
#define   ESS152      (ERRSS +  152)    /*     ss_acc.c:3267 */
#define   ESS153      (ERRSS +  153)    /*     ss_acc.c:3279 */
#define   ESS154      (ERRSS +  154)    /*     ss_acc.c:3286 */
#define   ESS155      (ERRSS +  155)    /*     ss_acc.c:3300 */
#define   ESS156      (ERRSS +  156)    /*     ss_acc.c:3314 */
#define   ESS157      (ERRSS +  157)    /*     ss_acc.c:3318 */
#define   ESS158      (ERRSS +  158)    /*     ss_acc.c:3338 */
#define   ESS159      (ERRSS +  159)    /*     ss_acc.c:3341 */
#define   ESS160      (ERRSS +  160)    /*     ss_acc.c:3344 */
#define   ESS161      (ERRSS +  161)    /*     ss_acc.c:3347 */
#define   ESS162      (ERRSS +  162)    /*     ss_acc.c:3355 */
#define   ESS163      (ERRSS +  163)    /*     ss_acc.c:3358 */
#define   ESS164      (ERRSS +  164)    /*     ss_acc.c:3361 */
#define   ESS165      (ERRSS +  165)    /*     ss_acc.c:3364 */
#define   ESS166      (ERRSS +  166)    /*     ss_acc.c:3381 */
#define   ESS167      (ERRSS +  167)    /*     ss_acc.c:3385 */
#define   ESS168      (ERRSS +  168)    /*     ss_acc.c:3398 */
#define   ESS169      (ERRSS +  169)    /*     ss_acc.c:3402 */
#define   ESS170      (ERRSS +  170)    /*     ss_acc.c:3415 */
#define   ESS171      (ERRSS +  171)    /*     ss_acc.c:3422 */
#define   ESS172      (ERRSS +  172)    /*     ss_acc.c:3486 */
#define   ESS173      (ERRSS +  173)    /*     ss_acc.c:3489 */
#define   ESS174      (ERRSS +  174)    /*     ss_acc.c:3493 */
#define   ESS175      (ERRSS +  175)    /*     ss_acc.c:3508 */
#define   ESS176      (ERRSS +  176)    /*     ss_acc.c:3511 */
#define   ESS177      (ERRSS +  177)    /*     ss_acc.c:3514 */
#define   ESS178      (ERRSS +  178)    /*     ss_acc.c:3517 */
#define   ESS179      (ERRSS +  179)    /*     ss_acc.c:3520 */
#define   ESS180      (ERRSS +  180)    /*     ss_acc.c:3523 */
#define   ESS181      (ERRSS +  181)    /*     ss_acc.c:3535 */
#define   ESS182      (ERRSS +  182)    /*     ss_acc.c:3544 */
#define   ESS183      (ERRSS +  183)    /*     ss_acc.c:3549 */
#define   ESS184      (ERRSS +  184)    /*     ss_acc.c:3556 */
#define   ESS185      (ERRSS +  185)    /*     ss_acc.c:3569 */
#define   ESS186      (ERRSS +  186)    /*     ss_acc.c:3577 */
#define   ESS187      (ERRSS +  187)    /*     ss_acc.c:3582 */
#define   ESS188      (ERRSS +  188)    /*     ss_acc.c:3588 */
#define   ESS189      (ERRSS +  189)    /*     ss_acc.c:3600 */
#define   ESS190      (ERRSS +  190)    /*     ss_acc.c:3604 */
#define   ESS191      (ERRSS +  191)    /*     ss_acc.c:3608 */
#define   ESS192      (ERRSS +  192)    /*     ss_acc.c:3629 */
#define   ESS193      (ERRSS +  193)    /*     ss_acc.c:3632 */
#define   ESS194      (ERRSS +  194)    /*     ss_acc.c:3637 */
#define   ESS195      (ERRSS +  195)    /*     ss_acc.c:3645 */
#define   ESS196      (ERRSS +  196)    /*     ss_acc.c:3648 */
#define   ESS197      (ERRSS +  197)    /*     ss_acc.c:3653 */
#define   ESS198      (ERRSS +  198)    /*     ss_acc.c:3671 */
#define   ESS199      (ERRSS +  199)    /*     ss_acc.c:3674 */
#define   ESS200      (ERRSS +  200)    /*     ss_acc.c:3682 */
#define   ESS201      (ERRSS +  201)    /*     ss_acc.c:3689 */
#define   ESS202      (ERRSS +  202)    /*     ss_acc.c:3694 */
#define   ESS203      (ERRSS +  203)    /*     ss_acc.c:3708 */
#define   ESS204      (ERRSS +  204)    /*     ss_acc.c:3713 */
#define   ESS205      (ERRSS +  205)    /*     ss_acc.c:3727 */
#define   ESS206      (ERRSS +  206)    /*     ss_acc.c:3733 */
#define   ESS207      (ERRSS +  207)    /*     ss_acc.c:3746 */
#define   ESS208      (ERRSS +  208)    /*     ss_acc.c:3752 */
#define   ESS209      (ERRSS +  209)    /*     ss_acc.c:3768 */
#define   ESS210      (ERRSS +  210)    /*     ss_acc.c:3829 */
#define   ESS211      (ERRSS +  211)    /*     ss_acc.c:3843 */
#define   ESS212      (ERRSS +  212)    /*     ss_acc.c:3850 */
#define   ESS213      (ERRSS +  213)    /*     ss_acc.c:3861 */
#define   ESS214      (ERRSS +  214)    /*     ss_acc.c:3922 */
#define   ESS215      (ERRSS +  215)    /*     ss_acc.c:3950 */
#define   ESS216      (ERRSS +  216)    /*     ss_acc.c:3975 */
#define   ESS217      (ERRSS +  217)    /*     ss_acc.c:4003 */
#define   ESS218      (ERRSS +  218)    /*     ss_acc.c:4056 */
#define   ESS219      (ERRSS +  219)    /*     ss_acc.c:4067 */
#define   ESS220      (ERRSS +  220)    /*     ss_acc.c:4139 */
#define   ESS221      (ERRSS +  221)    /*     ss_acc.c:4142 */
#define   ESS222      (ERRSS +  222)    /*     ss_acc.c:4145 */
#define   ESS223      (ERRSS +  223)    /*     ss_acc.c:4148 */
#define   ESS224      (ERRSS +  224)    /*     ss_acc.c:4156 */
#define   ESS225      (ERRSS +  225)    /*     ss_acc.c:4159 */
#define   ESS226      (ERRSS +  226)    /*     ss_acc.c:4162 */
#define   ESS227      (ERRSS +  227)    /*     ss_acc.c:4165 */
#define   ESS228      (ERRSS +  228)    /*     ss_acc.c:4225 */
#define   ESS229      (ERRSS +  229)    /*     ss_acc.c:4229 */
#define   ESS230      (ERRSS +  230)    /*     ss_acc.c:4288 */
#define   ESS231      (ERRSS +  231)    /*     ss_acc.c:4292 */
#define   ESS232      (ERRSS +  232)    /*     ss_acc.c:4305 */
#define   ESS233      (ERRSS +  233)    /*     ss_acc.c:4312 */
#define   ESS234      (ERRSS +  234)    /*     ss_acc.c:4424 */
#define   ESS235      (ERRSS +  235)    /*     ss_acc.c:4433 */
#define   ESS236      (ERRSS +  236)    /*     ss_acc.c:4451 */
#define   ESS237      (ERRSS +  237)    /*     ss_acc.c:4470 */
#define   ESS238      (ERRSS +  238)    /*     ss_acc.c:4480 */
#define   ESS239      (ERRSS +  239)    /*     ss_acc.c:4499 */
#define   ESS240      (ERRSS +  240)    /*     ss_acc.c:4518 */
#define   ESS241      (ERRSS +  241)    /*     ss_acc.c:4527 */
#define   ESS242      (ERRSS +  242)    /*     ss_acc.c:4545 */
#define   ESS243      (ERRSS +  243)    /*     ss_acc.c:4564 */
#define   ESS244      (ERRSS +  244)    /*     ss_acc.c:4573 */
#define   ESS245      (ERRSS +  245)    /*     ss_acc.c:4591 */
#define   ESS246      (ERRSS +  246)    /*     ss_acc.c:4610 */
#define   ESS247      (ERRSS +  247)    /*     ss_acc.c:4619 */
#define   ESS248      (ERRSS +  248)    /*     ss_acc.c:4637 */
#define   ESS249      (ERRSS +  249)    /*     ss_acc.c:4661 */
#define   ESS250      (ERRSS +  250)    /*     ss_acc.c:4677 */
#define   ESS251      (ERRSS +  251)    /*     ss_acc.c:4693 */
#define   ESS252      (ERRSS +  252)    /*     ss_acc.c:4709 */
#define   ESS253      (ERRSS +  253)    /*     ss_acc.c:4724 */
#define   ESS254      (ERRSS +  254)    /*     ss_acc.c:4774 */
#define   ESS255      (ERRSS +  255)    /*     ss_acc.c:4822 */
#define   ESS256      (ERRSS +  256)    /*     ss_acc.c:4870 */
#define   ESS257      (ERRSS +  257)    /*     ss_acc.c:4918 */
#define   ESS258      (ERRSS +  258)    /*     ss_acc.c:4966 */
#define   ESS259      (ERRSS +  259)    /*     ss_acc.c:5232 */

#define   ESS260      (ERRSS +  260)    /*    ss_drvr.c:  19 */
#define   ESS261      (ERRSS +  261)    /*    ss_drvr.c:  20 */
#define   ESS262      (ERRSS +  262)    /*    ss_drvr.c: 182 */
#define   ESS263      (ERRSS +  263)    /*    ss_drvr.c: 190 */
#define   ESS264      (ERRSS +  264)    /*    ss_drvr.c: 198 */
#define   ESS265      (ERRSS +  265)    /*    ss_drvr.c: 205 */
#define   ESS266      (ERRSS +  266)    /*    ss_drvr.c: 212 */
#define   ESS267      (ERRSS +  267)    /*    ss_drvr.c: 219 */
#define   ESS268      (ERRSS +  268)    /*    ss_drvr.c: 230 */
#define   ESS269      (ERRSS +  269)    /*    ss_drvr.c: 240 */

#define   ESS270      (ERRSS +  270)    /*     ss_msg.c:  19 */
#define   ESS271      (ERRSS +  271)    /*     ss_msg.c:  20 */
#define   ESS272      (ERRSS +  272)    /*     ss_msg.c: 203 */
#define   ESS273      (ERRSS +  273)    /*     ss_msg.c: 209 */
#define   ESS274      (ERRSS +  274)    /*     ss_msg.c: 216 */
#define   ESS275      (ERRSS +  275)    /*     ss_msg.c: 335 */
#define   ESS276      (ERRSS +  276)    /*     ss_msg.c: 340 */
#define   ESS277      (ERRSS +  277)    /*     ss_msg.c: 347 */
#define   ESS278      (ERRSS +  278)    /*     ss_msg.c: 358 */
#define   ESS279      (ERRSS +  279)    /*     ss_msg.c: 373 */
#define   ESS280      (ERRSS +  280)    /*     ss_msg.c: 379 */
#define   ESS281      (ERRSS +  281)    /*     ss_msg.c: 387 */
#define   ESS282      (ERRSS +  282)    /*     ss_msg.c: 398 */
#define   ESS283      (ERRSS +  283)    /*     ss_msg.c: 406 */
#define   ESS284      (ERRSS +  284)    /*     ss_msg.c: 412 */
#define   ESS285      (ERRSS +  285)    /*     ss_msg.c: 479 */
#define   ESS286      (ERRSS +  286)    /*     ss_msg.c: 484 */
#define   ESS287      (ERRSS +  287)    /*     ss_msg.c: 554 */
#define   ESS288      (ERRSS +  288)    /*     ss_msg.c: 559 */
#define   ESS289      (ERRSS +  289)    /*     ss_msg.c: 628 */
#define   ESS290      (ERRSS +  290)    /*     ss_msg.c: 633 */
#define   ESS291      (ERRSS +  291)    /*     ss_msg.c: 662 */
#define   ESS292      (ERRSS +  292)    /*     ss_msg.c: 732 */
#define   ESS293      (ERRSS +  293)    /*     ss_msg.c: 737 */
#define   ESS294      (ERRSS +  294)    /*     ss_msg.c: 751 */
#define   ESS295      (ERRSS +  295)    /*     ss_msg.c: 832 */
#define   ESS296      (ERRSS +  296)    /*     ss_msg.c: 838 */
#define   ESS297      (ERRSS +  297)    /*     ss_msg.c: 844 */
#define   ESS298      (ERRSS +  298)    /*     ss_msg.c: 850 */
#define   ESS299      (ERRSS +  299)    /*     ss_msg.c:1001 */
#define   ESS300      (ERRSS +  300)    /*     ss_msg.c:1007 */
#define   ESS301      (ERRSS +  301)    /*     ss_msg.c:1013 */
#define   ESS302      (ERRSS +  302)    /*     ss_msg.c:1019 */
#define   ESS303      (ERRSS +  303)    /*     ss_msg.c:1182 */
#define   ESS304      (ERRSS +  304)    /*     ss_msg.c:1188 */
#define   ESS305      (ERRSS +  305)    /*     ss_msg.c:1193 */
#define   ESS306      (ERRSS +  306)    /*     ss_msg.c:1267 */
#define   ESS307      (ERRSS +  307)    /*     ss_msg.c:1273 */
#define   ESS308      (ERRSS +  308)    /*     ss_msg.c:1278 */
#define   ESS309      (ERRSS +  309)    /*     ss_msg.c:1369 */
#define   ESS310      (ERRSS +  310)    /*     ss_msg.c:1376 */
#define   ESS311      (ERRSS +  311)    /*     ss_msg.c:1384 */
#define   ESS312      (ERRSS +  312)    /*     ss_msg.c:1489 */
#define   ESS313      (ERRSS +  313)    /*     ss_msg.c:1496 */
#define   ESS314      (ERRSS +  314)    /*     ss_msg.c:1501 */
#define   ESS315      (ERRSS +  315)    /*     ss_msg.c:1616 */
#define   ESS316      (ERRSS +  316)    /*     ss_msg.c:1622 */
#define   ESS317      (ERRSS +  317)    /*     ss_msg.c:1628 */
#define   ESS318      (ERRSS +  318)    /*     ss_msg.c:1633 */
#define   ESS319      (ERRSS +  319)    /*     ss_msg.c:1696 */
#define   ESS320      (ERRSS +  320)    /*     ss_msg.c:1702 */
#define   ESS321      (ERRSS +  321)    /*     ss_msg.c:1707 */
#define   ESS322      (ERRSS +  322)    /*     ss_msg.c:1786 */
#define   ESS323      (ERRSS +  323)    /*     ss_msg.c:1792 */
#define   ESS324      (ERRSS +  324)    /*     ss_msg.c:1797 */
#define   ESS325      (ERRSS +  325)    /*     ss_msg.c:1802 */
#define   ESS326      (ERRSS +  326)    /*     ss_msg.c:1820 */
#define   ESS327      (ERRSS +  327)    /*     ss_msg.c:1954 */
#define   ESS328      (ERRSS +  328)    /*     ss_msg.c:1960 */
#define   ESS329      (ERRSS +  329)    /*     ss_msg.c:1966 */
#define   ESS330      (ERRSS +  330)    /*     ss_msg.c:1972 */
#define   ESS331      (ERRSS +  331)    /*     ss_msg.c:1977 */
#define   ESS332      (ERRSS +  332)    /*     ss_msg.c:1988 */
#define   ESS333      (ERRSS +  333)    /*     ss_msg.c:2003 */
#define   ESS334      (ERRSS +  334)    /*     ss_msg.c:2014 */
#define   ESS335      (ERRSS +  335)    /*     ss_msg.c:2110 */
#define   ESS336      (ERRSS +  336)    /*     ss_msg.c:2116 */
#define   ESS337      (ERRSS +  337)    /*     ss_msg.c:2121 */
#define   ESS338      (ERRSS +  338)    /*     ss_msg.c:2127 */
#define   ESS339      (ERRSS +  339)    /*     ss_msg.c:2132 */
#define   ESS340      (ERRSS +  340)    /*     ss_msg.c:2137 */
#define   ESS341      (ERRSS +  341)    /*     ss_msg.c:2252 */
#define   ESS342      (ERRSS +  342)    /*     ss_msg.c:2257 */
#define   ESS343      (ERRSS +  343)    /*     ss_msg.c:2264 */
#define   ESS344      (ERRSS +  344)    /*     ss_msg.c:2271 */
#define   ESS345      (ERRSS +  345)    /*     ss_msg.c:2283 */
#define   ESS346      (ERRSS +  346)    /*     ss_msg.c:2298 */
#define   ESS347      (ERRSS +  347)    /*     ss_msg.c:2304 */
#define   ESS348      (ERRSS +  348)    /*     ss_msg.c:2312 */
#define   ESS349      (ERRSS +  349)    /*     ss_msg.c:2323 */
#define   ESS350      (ERRSS +  350)    /*     ss_msg.c:2391 */
#define   ESS351      (ERRSS +  351)    /*     ss_msg.c:2476 */
#define   ESS352      (ERRSS +  352)    /*     ss_msg.c:2481 */
#define   ESS353      (ERRSS +  353)    /*     ss_msg.c:2491 */
#define   ESS354      (ERRSS +  354)    /*     ss_msg.c:2559 */
#define   ESS355      (ERRSS +  355)    /*     ss_msg.c:2621 */
#define   ESS356      (ERRSS +  356)    /*     ss_msg.c:2627 */
#define   ESS357      (ERRSS +  357)    /*     ss_msg.c:2639 */
#define   ESS358      (ERRSS +  358)    /*     ss_msg.c:2715 */
#define   ESS359      (ERRSS +  359)    /*     ss_msg.c:2720 */
#define   ESS360      (ERRSS +  360)    /*     ss_msg.c:2727 */
#define   ESS361      (ERRSS +  361)    /*     ss_msg.c:2738 */
#define   ESS362      (ERRSS +  362)    /*     ss_msg.c:2753 */
#define   ESS363      (ERRSS +  363)    /*     ss_msg.c:2759 */
#define   ESS364      (ERRSS +  364)    /*     ss_msg.c:2767 */
#define   ESS365      (ERRSS +  365)    /*     ss_msg.c:2779 */
#define   ESS366      (ERRSS +  366)    /*     ss_msg.c:2912 */
#define   ESS367      (ERRSS +  367)    /*     ss_msg.c:2918 */
#define   ESS368      (ERRSS +  368)    /*     ss_msg.c:2924 */
#define   ESS369      (ERRSS +  369)    /*     ss_msg.c:2930 */
#define   ESS370      (ERRSS +  370)    /*     ss_msg.c:2943 */
#define   ESS371      (ERRSS +  371)    /*     ss_msg.c:3033 */
#define   ESS372      (ERRSS +  372)    /*     ss_msg.c:3153 */
#define   ESS373      (ERRSS +  373)    /*     ss_msg.c:3215 */
#define   ESS374      (ERRSS +  374)    /*     ss_msg.c:3221 */
#define   ESS375      (ERRSS +  375)    /*     ss_msg.c:3228 */
#define   ESS376      (ERRSS +  376)    /*     ss_msg.c:3233 */
#define   ESS377      (ERRSS +  377)    /*     ss_msg.c:3239 */
#define   ESS378      (ERRSS +  378)    /*     ss_msg.c:3260 */
#define   ESS379      (ERRSS +  379)    /*     ss_msg.c:3305 */
#define   ESS380      (ERRSS +  380)    /*     ss_msg.c:3381 */
#define   ESS381      (ERRSS +  381)    /*     ss_msg.c:3386 */
#define   ESS382      (ERRSS +  382)    /*     ss_msg.c:3391 */
#define   ESS383      (ERRSS +  383)    /*     ss_msg.c:3417 */
#define   ESS384      (ERRSS +  384)    /*     ss_msg.c:3474 */
#define   ESS385      (ERRSS +  385)    /*     ss_msg.c:3479 */
#define   ESS386      (ERRSS +  386)    /*     ss_msg.c:3484 */
#define   ESS387      (ERRSS +  387)    /*     ss_msg.c:3490 */
#define   ESS388      (ERRSS +  388)    /*     ss_msg.c:3513 */
#define   ESS389      (ERRSS +  389)    /*     ss_msg.c:3575 */
#define   ESS390      (ERRSS +  390)    /*     ss_msg.c:3581 */
#define   ESS391      (ERRSS +  391)    /*     ss_msg.c:3649 */
#define   ESS392      (ERRSS +  392)    /*     ss_msg.c:3655 */
#define   ESS393      (ERRSS +  393)    /*     ss_msg.c:3724 */
#define   ESS394      (ERRSS +  394)    /*     ss_msg.c:3730 */
#define   ESS395      (ERRSS +  395)    /*     ss_msg.c:3735 */
#define   ESS396      (ERRSS +  396)    /*     ss_msg.c:3802 */
#define   ESS397      (ERRSS +  397)    /*     ss_msg.c:3808 */
#define   ESS398      (ERRSS +  398)    /*     ss_msg.c:3813 */
#define   ESS399      (ERRSS +  399)    /*     ss_msg.c:3872 */
#define   ESS400      (ERRSS +  400)    /*     ss_msg.c:3877 */
#define   ESS401      (ERRSS +  401)    /*     ss_msg.c:3925 */
#define   ESS402      (ERRSS +  402)    /*     ss_msg.c:3930 */
#define   ESS403      (ERRSS +  403)    /*     ss_msg.c:3935 */
#define   ESS404      (ERRSS +  404)    /*     ss_msg.c:3984 */
#define   ESS405      (ERRSS +  405)    /*     ss_msg.c:3989 */
#define   ESS406      (ERRSS +  406)    /*     ss_msg.c:4043 */
#define   ESS407      (ERRSS +  407)    /*     ss_msg.c:4048 */
#define   ESS408      (ERRSS +  408)    /*     ss_msg.c:4053 */
#define   ESS409      (ERRSS +  409)    /*     ss_msg.c:4058 */
#define   ESS410      (ERRSS +  410)    /*     ss_msg.c:4067 */
#define   ESS411      (ERRSS +  411)    /*     ss_msg.c:4080 */
#define   ESS412      (ERRSS +  412)    /*     ss_msg.c:4126 */
#define   ESS413      (ERRSS +  413)    /*     ss_msg.c:4131 */
#define   ESS414      (ERRSS +  414)    /*     ss_msg.c:4137 */
#define   ESS415      (ERRSS +  415)    /*     ss_msg.c:4142 */
#define   ESS416      (ERRSS +  416)    /*     ss_msg.c:4156 */
#define   ESS417      (ERRSS +  417)    /*     ss_msg.c:4202 */
#define   ESS418      (ERRSS +  418)    /*     ss_msg.c:4208 */
#define   ESS419      (ERRSS +  419)    /*     ss_msg.c:4214 */
#define   ESS420      (ERRSS +  420)    /*     ss_msg.c:4224 */
#define   ESS421      (ERRSS +  421)    /*     ss_msg.c:4280 */
#define   ESS422      (ERRSS +  422)    /*     ss_msg.c:4285 */
#define   ESS423      (ERRSS +  423)    /*     ss_msg.c:4301 */
#define   ESS424      (ERRSS +  424)    /*     ss_msg.c:4687 */
#define   ESS425      (ERRSS +  425)    /*     ss_msg.c:4693 */
#define   ESS426      (ERRSS +  426)    /*     ss_msg.c:4771 */
#define   ESS427      (ERRSS +  427)    /*     ss_msg.c:4777 */
#define   ESS428      (ERRSS +  428)    /*     ss_msg.c:4872 */
#define   ESS429      (ERRSS +  429)    /*     ss_msg.c:4879 */
#define   ESS430      (ERRSS +  430)    /*     ss_msg.c:4933 */
#define   ESS431      (ERRSS +  431)    /*     ss_msg.c:4940 */
#define   ESS432      (ERRSS +  432)    /*     ss_msg.c:4951 */
#define   ESS433      (ERRSS +  433)    /*     ss_msg.c:4966 */
#define   ESS434      (ERRSS +  434)    /*     ss_msg.c:4972 */
#define   ESS435      (ERRSS +  435)    /*     ss_msg.c:4980 */
#define   ESS436      (ERRSS +  436)    /*     ss_msg.c:5035 */
#define   ESS437      (ERRSS +  437)    /*     ss_msg.c:5042 */
#define   ESS438      (ERRSS +  438)    /*     ss_msg.c:5049 */
#define   ESS439      (ERRSS +  439)    /*     ss_msg.c:5057 */
#define   ESS440      (ERRSS +  440)    /*     ss_msg.c:5065 */
#define   ESS441      (ERRSS +  441)    /*     ss_msg.c:5077 */
#define   ESS442      (ERRSS +  442)    /*     ss_msg.c:5097 */
#define   ESS443      (ERRSS +  443)    /*     ss_msg.c:5104 */
#define   ESS444      (ERRSS +  444)    /*     ss_msg.c:5132 */
#define   ESS445      (ERRSS +  445)    /*     ss_msg.c:5185 */
#define   ESS446      (ERRSS +  446)    /*     ss_msg.c:5192 */
#define   ESS447      (ERRSS +  447)    /*     ss_msg.c:5199 */
#define   ESS448      (ERRSS +  448)    /*     ss_msg.c:5207 */
#define   ESS449      (ERRSS +  449)    /*     ss_msg.c:5215 */
#define   ESS450      (ERRSS +  450)    /*     ss_msg.c:5227 */
#define   ESS451      (ERRSS +  451)    /*     ss_msg.c:5247 */
#define   ESS452      (ERRSS +  452)    /*     ss_msg.c:5254 */
#define   ESS453      (ERRSS +  453)    /*     ss_msg.c:5273 */
#define   ESS454      (ERRSS +  454)    /*     ss_msg.c:5324 */
#define   ESS455      (ERRSS +  455)    /*     ss_msg.c:5331 */
#define   ESS456      (ERRSS +  456)    /*     ss_msg.c:5338 */
#define   ESS457      (ERRSS +  457)    /*     ss_msg.c:5350 */
#define   ESS458      (ERRSS +  458)    /*     ss_msg.c:5370 */
#define   ESS459      (ERRSS +  459)    /*     ss_msg.c:5377 */
#define   ESS460      (ERRSS +  460)    /*     ss_msg.c:5384 */
#define   ESS461      (ERRSS +  461)    /*     ss_msg.c:5406 */
#define   ESS462      (ERRSS +  462)    /*     ss_msg.c:5461 */
#define   ESS463      (ERRSS +  463)    /*     ss_msg.c:5467 */
#define   ESS464      (ERRSS +  464)    /*     ss_msg.c:5472 */
#define   ESS465      (ERRSS +  465)    /*     ss_msg.c:5478 */
#define   ESS466      (ERRSS +  466)    /*     ss_msg.c:5486 */

#define   ESS467      (ERRSS +  467)    /*    ss_ptsp.c:  19 */
#define   ESS468      (ERRSS +  468)    /*    ss_ptsp.c:  20 */

#define   ESS469      (ERRSS +  469)    /*     ss_rtr.c:  19 */
#define   ESS470      (ERRSS +  470)    /*     ss_rtr.c:  20 */
#define   ESS471      (ERRSS +  471)    /*     ss_rtr.c: 167 */
#define   ESS472      (ERRSS +  472)    /*     ss_rtr.c: 174 */
#define   ESS473      (ERRSS +  473)    /*     ss_rtr.c: 183 */
#define   ESS474      (ERRSS +  474)    /*     ss_rtr.c: 196 */
#define   ESS475      (ERRSS +  475)    /*     ss_rtr.c: 262 */
#define   ESS476      (ERRSS +  476)    /*     ss_rtr.c: 269 */
#define   ESS477      (ERRSS +  477)    /*     ss_rtr.c: 284 */
#define   ESS478      (ERRSS +  478)    /*     ss_rtr.c: 297 */
#define   ESS479      (ERRSS +  479)    /*     ss_rtr.c: 307 */

#define   ESS480      (ERRSS +  480)    /*    ss_task.c:  19 */
#define   ESS481      (ERRSS +  481)    /*    ss_task.c:  20 */
#define   ESS482      (ERRSS +  482)    /*    ss_task.c: 165 */
#define   ESS483      (ERRSS +  483)    /*    ss_task.c: 172 */
#define   ESS484      (ERRSS +  484)    /*    ss_task.c: 190 */
#define   ESS485      (ERRSS +  485)    /*    ss_task.c: 200 */
#define   ESS486      (ERRSS +  486)    /*    ss_task.c: 213 */
#define   ESS487      (ERRSS +  487)    /*    ss_task.c: 219 */
#define   ESS488      (ERRSS +  488)    /*    ss_task.c: 232 */
#define   ESS489      (ERRSS +  489)    /*    ss_task.c: 239 */
#define   ESS490      (ERRSS +  490)    /*    ss_task.c: 285 */
#define   ESS491      (ERRSS +  491)    /*    ss_task.c: 350 */
#define   ESS492      (ERRSS +  492)    /*    ss_task.c: 357 */
#define   ESS493      (ERRSS +  493)    /*    ss_task.c: 364 */
#define   ESS494      (ERRSS +  494)    /*    ss_task.c: 372 */
#define   ESS495      (ERRSS +  495)    /*    ss_task.c: 381 */
#define   ESS496      (ERRSS +  496)    /*    ss_task.c: 393 */
#define   ESS497      (ERRSS +  497)    /*    ss_task.c: 399 */
#define   ESS498      (ERRSS +  498)    /*    ss_task.c: 418 */
#define   ESS499      (ERRSS +  499)    /*    ss_task.c: 423 */
#define   ESS500      (ERRSS +  500)    /*    ss_task.c: 464 */
#define   ESS501      (ERRSS +  501)    /*    ss_task.c: 470 */
#define   ESS502      (ERRSS +  502)    /*    ss_task.c: 486 */
#define   ESS503      (ERRSS +  503)    /*    ss_task.c: 505 */
#define   ESS504      (ERRSS +  504)    /*    ss_task.c: 522 */
#define   ESS505      (ERRSS +  505)    /*    ss_task.c: 576 */
#define   ESS506      (ERRSS +  506)    /*    ss_task.c: 586 */
#define   ESS507      (ERRSS +  507)    /*    ss_task.c: 597 */
#define   ESS508      (ERRSS +  508)    /*    ss_task.c: 610 */
#define   ESS509      (ERRSS +  509)    /*    ss_task.c: 616 */
#define   ESS510      (ERRSS +  510)    /*    ss_task.c: 648 */
#define   ESS511      (ERRSS +  511)    /*    ss_task.c: 675 */
#define   ESS512      (ERRSS +  512)    /*    ss_task.c: 696 */
#define   ESS513      (ERRSS +  513)    /*    ss_task.c: 717 */
#define   ESS514      (ERRSS +  514)    /*    ss_task.c: 746 */
#define   ESS515      (ERRSS +  515)    /*    ss_task.c: 764 */
#define   ESS516      (ERRSS +  516)    /*    ss_task.c: 860 */
#define   ESS517      (ERRSS +  517)    /*    ss_task.c: 866 */
#define   ESS518      (ERRSS +  518)    /*    ss_task.c: 874 */
#define   ESS519      (ERRSS +  519)    /*    ss_task.c: 881 */
#define   ESS520      (ERRSS +  520)    /*    ss_task.c: 889 */
#define   ESS521      (ERRSS +  521)    /*    ss_task.c: 902 */
#define   ESS522      (ERRSS +  522)    /*    ss_task.c: 924 */
#define   ESS523      (ERRSS +  523)    /*    ss_task.c: 934 */
#define   ESS524      (ERRSS +  524)    /*    ss_task.c: 942 */
#define   ESS525      (ERRSS +  525)    /*    ss_task.c: 957 */
#define   ESS526      (ERRSS +  526)    /*    ss_task.c: 963 */
#define   ESS527      (ERRSS +  527)    /*    ss_task.c: 980 */
#define   ESS528      (ERRSS +  528)    /*    ss_task.c: 987 */
#define   ESS529      (ERRSS +  529)    /*    ss_task.c:1057 */
#define   ESS530      (ERRSS +  530)    /*    ss_task.c:1066 */
#define   ESS531      (ERRSS +  531)    /*    ss_task.c:1080 */
#define   ESS532      (ERRSS +  532)    /*    ss_task.c:1089 */
#define   ESS533      (ERRSS +  533)    /*    ss_task.c:1109 */
#define   ESS534      (ERRSS +  534)    /*    ss_task.c:1187 */
#define   ESS535      (ERRSS +  535)    /*    ss_task.c:1193 */
#define   ESS536      (ERRSS +  536)    /*    ss_task.c:1207 */
#define   ESS537      (ERRSS +  537)    /*    ss_task.c:1221 */
#define   ESS538      (ERRSS +  538)    /*    ss_task.c:1266 */
#define   ESS539      (ERRSS +  539)    /*    ss_task.c:1274 */
#define   ESS540      (ERRSS +  540)    /*    ss_task.c:1291 */
#define   ESS541      (ERRSS +  541)    /*    ss_task.c:1312 */
#define   ESS542      (ERRSS +  542)    /*    ss_task.c:1329 */
#define   ESS543      (ERRSS +  543)    /*    ss_task.c:1348 */
#define   ESS544      (ERRSS +  544)    /*    ss_task.c:1365 */
#define   ESS545      (ERRSS +  545)    /*    ss_task.c:1401 */
#define   ESS546      (ERRSS +  546)    /*    ss_task.c:1420 */
#define   ESS547      (ERRSS +  547)    /*    ss_task.c:1428 */
#define   ESS548      (ERRSS +  548)    /*    ss_task.c:1464 */
#define   ESS549      (ERRSS +  549)    /*    ss_task.c:1483 */
#define   ESS550      (ERRSS +  550)    /*    ss_task.c:1490 */
#define   ESS551      (ERRSS +  551)    /*    ss_task.c:1569 */
#define   ESS552      (ERRSS +  552)    /*    ss_task.c:1588 */
#define   ESS553      (ERRSS +  553)    /*    ss_task.c:1639 */
#define   ESS554      (ERRSS +  554)    /*    ss_task.c:1646 */
#define   ESS555      (ERRSS +  555)    /*    ss_task.c:1659 */
#define   ESS556      (ERRSS +  556)    /*    ss_task.c:1681 */
#define   ESS557      (ERRSS +  557)    /*    ss_task.c:1704 */
#define   ESS558      (ERRSS +  558)    /*    ss_task.c:1712 */
#define   ESS559      (ERRSS +  559)    /*    ss_task.c:1736 */
#define   ESS560      (ERRSS +  560)    /*    ss_task.c:1744 */
#define   ESS561      (ERRSS +  561)    /*    ss_task.c:1763 */
#define   ESS562      (ERRSS +  562)    /*    ss_task.c:1771 */
#define   ESS563      (ERRSS +  563)    /*    ss_task.c:1796 */
#define   ESS564      (ERRSS +  564)    /*    ss_task.c:1804 */
#define   ESS565      (ERRSS +  565)    /*    ss_task.c:1828 */
#define   ESS566      (ERRSS +  566)    /*    ss_task.c:1881 */
#define   ESS567      (ERRSS +  567)    /*    ss_task.c:1893 */
#define   ESS568      (ERRSS +  568)    /*    ss_task.c:1920 */
#define   ESS569      (ERRSS +  569)    /*    ss_task.c:1927 */
#define   ESS570      (ERRSS +  570)    /*    ss_task.c:1941 */
#define   ESS571      (ERRSS +  571)    /*    ss_task.c:1948 */
#define   ESS572      (ERRSS +  572)    /*    ss_task.c:1969 */
#define   ESS573      (ERRSS +  573)    /*    ss_task.c:1977 */
#define   ESS574      (ERRSS +  574)    /*    ss_task.c:1999 */
#define   ESS575      (ERRSS +  575)    /*    ss_task.c:2014 */
#define   ESS576      (ERRSS +  576)    /*    ss_task.c:2022 */
#define   ESS577      (ERRSS +  577)    /*    ss_task.c:2065 */
#define   ESS578      (ERRSS +  578)    /*    ss_task.c:2081 */
#define   ESS579      (ERRSS +  579)    /*    ss_task.c:2103 */
#define   ESS580      (ERRSS +  580)    /*    ss_task.c:2114 */
#define   ESS581      (ERRSS +  581)    /*    ss_task.c:2196 */
#define   ESS582      (ERRSS +  582)    /*    ss_task.c:2203 */
#define   ESS583      (ERRSS +  583)    /*    ss_task.c:2211 */
#define   ESS584      (ERRSS +  584)    /*    ss_task.c:2224 */
#define   ESS585      (ERRSS +  585)    /*    ss_task.c:2237 */
#define   ESS586      (ERRSS +  586)    /*    ss_task.c:2260 */
#define   ESS587      (ERRSS +  587)    /*    ss_task.c:2267 */
#define   ESS588      (ERRSS +  588)    /*    ss_task.c:2288 */
#define   ESS589      (ERRSS +  589)    /*    ss_task.c:2296 */
#define   ESS590      (ERRSS +  590)    /*    ss_task.c:2318 */
#define   ESS591      (ERRSS +  591)    /*    ss_task.c:2333 */
#define   ESS592      (ERRSS +  592)    /*    ss_task.c:2358 */
#define   ESS593      (ERRSS +  593)    /*    ss_task.c:2374 */
#define   ESS594      (ERRSS +  594)    /*    ss_task.c:2382 */
#define   ESS595      (ERRSS +  595)    /*    ss_task.c:2412 */
#define   ESS596      (ERRSS +  596)    /*    ss_task.c:2427 */
#define   ESS597      (ERRSS +  597)    /*    ss_task.c:2434 */
#define   ESS598      (ERRSS +  598)    /*    ss_task.c:2454 */
#define   ESS599      (ERRSS +  599)    /*    ss_task.c:2469 */
#define   ESS600      (ERRSS +  600)    /*    ss_task.c:2494 */
#define   ESS601      (ERRSS +  601)    /*    ss_task.c:2509 */
#define   ESS602      (ERRSS +  602)    /*    ss_task.c:2556 */
#define   ESS603      (ERRSS +  603)    /*    ss_task.c:2571 */
#define   ESS604      (ERRSS +  604)    /*    ss_task.c:2664 */
#define   ESS605      (ERRSS +  605)    /*    ss_task.c:2671 */
#define   ESS606      (ERRSS +  606)    /*    ss_task.c:2684 */
#define   ESS607      (ERRSS +  607)    /*    ss_task.c:2701 */
#define   ESS608      (ERRSS +  608)    /*    ss_task.c:2721 */
#define   ESS609      (ERRSS +  609)    /*    ss_task.c:2729 */
#define   ESS610      (ERRSS +  610)    /*    ss_task.c:2757 */
#define   ESS611      (ERRSS +  611)    /*    ss_task.c:2764 */
#define   ESS612      (ERRSS +  612)    /*    ss_task.c:2789 */
#define   ESS613      (ERRSS +  613)    /*    ss_task.c:2826 */
#define   ESS614      (ERRSS +  614)    /*    ss_task.c:2834 */
#define   ESS615      (ERRSS +  615)    /*    ss_task.c:2856 */
#define   ESS616      (ERRSS +  616)    /*    ss_task.c:2864 */
#define   ESS617      (ERRSS +  617)    /*    ss_task.c:2872 */
#define   ESS618      (ERRSS +  618)    /*    ss_task.c:2919 */
#define   ESS619      (ERRSS +  619)    /*    ss_task.c:2936 */
#define   ESS620      (ERRSS +  620)    /*    ss_task.c:3020 */
#define   ESS621      (ERRSS +  621)    /*    ss_task.c:3028 */
#define   ESS622      (ERRSS +  622)    /*    ss_task.c:3037 */
#define   ESS623      (ERRSS +  623)    /*    ss_task.c:3050 */
#define   ESS624      (ERRSS +  624)    /*    ss_task.c:3075 */
#define   ESS625      (ERRSS +  625)    /*    ss_task.c:3084 */
#define   ESS626      (ERRSS +  626)    /*    ss_task.c:3119 */
#define   ESS627      (ERRSS +  627)    /*    ss_task.c:3128 */
#define   ESS628      (ERRSS +  628)    /*    ss_task.c:3147 */
#define   ESS629      (ERRSS +  629)    /*    ss_task.c:3163 */
#define   ESS630      (ERRSS +  630)    /*    ss_task.c:3192 */
#define   ESS631      (ERRSS +  631)    /*    ss_task.c:3201 */
#define   ESS632      (ERRSS +  632)    /*    ss_task.c:3229 */
#define   ESS633      (ERRSS +  633)    /*    ss_task.c:3238 */
#define   ESS634      (ERRSS +  634)    /*    ss_task.c:3290 */
#define   ESS635      (ERRSS +  635)    /*    ss_task.c:3299 */
#define   ESS636      (ERRSS +  636)    /*    ss_task.c:3306 */
#define   ESS637      (ERRSS +  637)    /*    ss_task.c:3319 */
#define   ESS638      (ERRSS +  638)    /*    ss_task.c:3332 */
#define   ESS639      (ERRSS +  639)    /*    ss_task.c:3349 */
#define   ESS640      (ERRSS +  640)    /*    ss_task.c:3358 */
#define   ESS641      (ERRSS +  641)    /*    ss_task.c:3388 */
#define   ESS642      (ERRSS +  642)    /*    ss_task.c:3397 */
#define   ESS643      (ERRSS +  643)    /*    ss_task.c:3415 */
#define   ESS644      (ERRSS +  644)    /*    ss_task.c:3424 */
#define   ESS645      (ERRSS +  645)    /*    ss_task.c:3440 */

#define   ESS646      (ERRSS +  646)    /*     ss_gen.c:  19 */
#define   ESS647      (ERRSS +  647)    /*     ss_gen.c:  20 */
#define   ESS648      (ERRSS +  648)    /*     ss_gen.c: 261 */
#define   ESS649      (ERRSS +  649)    /*     ss_gen.c: 339 */
#define   ESS650      (ERRSS +  650)    /*     ss_gen.c: 364 */
#define   ESS651      (ERRSS +  651)    /*     ss_gen.c: 501 */
#define   ESS652      (ERRSS +  652)    /*     ss_gen.c: 518 */
#define   ESS653      (ERRSS +  653)    /*     ss_gen.c: 922 */
#define   ESS654      (ERRSS +  654)    /*     ss_gen.c: 932 */
#define   ESS655      (ERRSS +  655)    /*     ss_gen.c: 939 */
#define   ESS656      (ERRSS +  656)    /*     ss_gen.c: 983 */
#define   ESS657      (ERRSS +  657)    /*     ss_gen.c:1029 */
#define   ESS658      (ERRSS +  658)    /*     ss_gen.c:1039 */
#define   ESS659      (ERRSS +  659)    /*     ss_gen.c:1053 */
#define   ESS660      (ERRSS +  660)    /*     ss_gen.c:1060 */
#define   ESS661      (ERRSS +  661)    /*     ss_gen.c:1075 */
#define   ESS662      (ERRSS +  662)    /*     ss_gen.c:1189 */
#define   ESS663      (ERRSS +  663)    /*     ss_gen.c:1253 */
#define   ESS664      (ERRSS +  664)    /*     ss_gen.c:1266 */

#define   ESS665      (ERRSS +  665)    /*     ss_mem.c:  19 */
#define   ESS666      (ERRSS +  666)    /*     ss_mem.c:  20 */
#define   ESS667      (ERRSS +  667)    /*     ss_mem.c: 162 */
#define   ESS668      (ERRSS +  668)    /*     ss_mem.c: 169 */
#define   ESS669      (ERRSS +  669)    /*     ss_mem.c: 181 */
#define   ESS670      (ERRSS +  670)    /*     ss_mem.c: 195 */
#define   ESS671      (ERRSS +  671)    /*     ss_mem.c: 256 */
#define   ESS672      (ERRSS +  672)    /*     ss_mem.c: 268 */
#define   ESS673      (ERRSS +  673)    /*     ss_mem.c: 281 */
#define   ESS674      (ERRSS +  674)    /*     ss_mem.c: 349 */
#define   ESS675      (ERRSS +  675)    /*     ss_mem.c: 361 */
#define   ESS676      (ERRSS +  676)    /*     ss_mem.c: 380 */
#define   ESS677      (ERRSS +  677)    /*     ss_mem.c: 387 */
#define   ESS678      (ERRSS +  678)    /*     ss_mem.c: 406 */
#define   ESS679      (ERRSS +  679)    /*     ss_mem.c: 456 */
#define   ESS680      (ERRSS +  680)    /*     ss_mem.c: 463 */
#define   ESS681      (ERRSS +  681)    /*     ss_mem.c: 470 */
#define   ESS682      (ERRSS +  682)    /*     ss_mem.c: 483 */
#define   ESS683      (ERRSS +  683)    /*     ss_mem.c: 502 */
#define   ESS684      (ERRSS +  684)    /*     ss_mem.c: 509 */
#define   ESS685      (ERRSS +  685)    /*     ss_mem.c: 527 */

#define   ESS686      (ERRSS +  686)    /*    ss_pack.c:  19 */
#define   ESS687      (ERRSS +  687)    /*    ss_pack.c:  20 */
#define   ESS688      (ERRSS +  688)    /*    ss_pack.c: 154 */
#define   ESS689      (ERRSS +  689)    /*    ss_pack.c: 194 */
#define   ESS690      (ERRSS +  690)    /*    ss_pack.c: 241 */
#define   ESS691      (ERRSS +  691)    /*    ss_pack.c: 289 */
#define   ESS692      (ERRSS +  692)    /*    ss_pack.c: 346 */
#define   ESS693      (ERRSS +  693)    /*    ss_pack.c: 403 */
#define   ESS694      (ERRSS +  694)    /*    ss_pack.c: 444 */
#define   ESS695      (ERRSS +  695)    /*    ss_pack.c: 452 */
#define   ESS696      (ERRSS +  696)    /*    ss_pack.c: 494 */
#define   ESS697      (ERRSS +  697)    /*    ss_pack.c: 502 */
#define   ESS698      (ERRSS +  698)    /*    ss_pack.c: 544 */
#define   ESS699      (ERRSS +  699)    /*    ss_pack.c: 552 */
#define   ESS700      (ERRSS +  700)    /*    ss_pack.c: 603 */
#define   ESS701      (ERRSS +  701)    /*    ss_pack.c: 611 */
#define   ESS702      (ERRSS +  702)    /*    ss_pack.c: 663 */
#define   ESS703      (ERRSS +  703)    /*    ss_pack.c: 671 */
#define   ESS704      (ERRSS +  704)    /*    ss_pack.c: 734 */
#define   ESS705      (ERRSS +  705)    /*    ss_pack.c: 742 */

#define   ESS706      (ERRSS +  706)    /*   ss_queue.c:  19 */
#define   ESS707      (ERRSS +  707)    /*   ss_queue.c:  20 */
#define   ESS708      (ERRSS +  708)    /*   ss_queue.c: 157 */
#define   ESS709      (ERRSS +  709)    /*   ss_queue.c: 211 */
#define   ESS710      (ERRSS +  710)    /*   ss_queue.c: 280 */
#define   ESS711      (ERRSS +  711)    /*   ss_queue.c: 286 */
#define   ESS712      (ERRSS +  712)    /*   ss_queue.c: 292 */
#define   ESS713      (ERRSS +  713)    /*   ss_queue.c: 299 */
#define   ESS714      (ERRSS +  714)    /*   ss_queue.c: 391 */
#define   ESS715      (ERRSS +  715)    /*   ss_queue.c: 397 */
#define   ESS716      (ERRSS +  716)    /*   ss_queue.c: 453 */
#define   ESS717      (ERRSS +  717)    /*   ss_queue.c: 460 */
#define   ESS718      (ERRSS +  718)    /*   ss_queue.c: 467 */
#define   ESS719      (ERRSS +  719)    /*   ss_queue.c: 548 */
#define   ESS720      (ERRSS +  720)    /*   ss_queue.c: 554 */
#define   ESS721      (ERRSS +  721)    /*   ss_queue.c: 560 */
#define   ESS722      (ERRSS +  722)    /*   ss_queue.c: 566 */
#define   ESS723      (ERRSS +  723)    /*   ss_queue.c: 575 */
#define   ESS724      (ERRSS +  724)    /*   ss_queue.c: 584 */
#define   ESS725      (ERRSS +  725)    /*   ss_queue.c: 673 */
#define   ESS726      (ERRSS +  726)    /*   ss_queue.c: 680 */
#define   ESS727      (ERRSS +  727)    /*   ss_queue.c: 686 */
#define   ESS728      (ERRSS +  728)    /*   ss_queue.c: 852 */
#define   ESS729      (ERRSS +  729)    /*   ss_queue.c: 858 */
#define   ESS730      (ERRSS +  730)    /*   ss_queue.c: 908 */
#define   ESS731      (ERRSS +  731)    /*   ss_queue.c: 914 */
#define   ESS732      (ERRSS +  732)    /*   ss_queue.c: 961 */
#define   ESS733      (ERRSS +  733)    /*   ss_queue.c: 980 */
#define   ESS734      (ERRSS +  734)    /*   ss_queue.c: 996 */
#define   ESS735      (ERRSS +  735)    /*   ss_queue.c:1040 */
#define   ESS736      (ERRSS +  736)    /*   ss_queue.c:1051 */
#define   ESS737      (ERRSS +  737)    /*   ss_queue.c:1072 */
#define   ESS738      (ERRSS +  738)    /*   ss_queue.c:1126 */
#define   ESS739      (ERRSS +  739)    /*   ss_queue.c:1132 */
#define   ESS740      (ERRSS +  740)    /*   ss_queue.c:1138 */
#define   ESS741      (ERRSS +  741)    /*   ss_queue.c:1144 */
#define   ESS742      (ERRSS +  742)    /*   ss_queue.c:1157 */
#define   ESS743      (ERRSS +  743)    /*   ss_queue.c:1195 */
#define   ESS744      (ERRSS +  744)    /*   ss_queue.c:1208 */
#define   ESS745      (ERRSS +  745)    /*   ss_queue.c:1260 */
#define   ESS746      (ERRSS +  746)    /*   ss_queue.c:1266 */
#define   ESS747      (ERRSS +  747)    /*   ss_queue.c:1272 */
#define   ESS748      (ERRSS +  748)    /*   ss_queue.c:1281 */
#define   ESS749      (ERRSS +  749)    /*   ss_queue.c:1292 */
#define   ESS750      (ERRSS +  750)    /*   ss_queue.c:1305 */
#define   ESS751      (ERRSS +  751)    /*   ss_queue.c:1351 */
#define   ESS752      (ERRSS +  752)    /*   ss_queue.c:1400 */
#define   ESS753      (ERRSS +  753)    /*   ss_queue.c:1413 */
#define   ESS754      (ERRSS +  754)    /*   ss_queue.c:1424 */
#define   ESS755      (ERRSS +  755)    /*   ss_queue.c:1438 */
#define   ESS756      (ERRSS +  756)    /*   ss_queue.c:1451 */
#define   ESS757      (ERRSS +  757)    /*   ss_queue.c:1474 */

#define   ESS758      (ERRSS +  758)    /*    ss_strm.c:  19 */
#define   ESS759      (ERRSS +  759)    /*    ss_strm.c:  20 */
#define   ESS760      (ERRSS +  760)    /*    ss_strm.c: 226 */
#define   ESS761      (ERRSS +  761)    /*    ss_strm.c: 395 */
#define   ESS762      (ERRSS +  762)    /*    ss_strm.c: 410 */
#define   ESS763      (ERRSS +  763)    /*    ss_strm.c: 468 */
#define   ESS764      (ERRSS +  764)    /*    ss_strm.c: 479 */
#define   ESS765      (ERRSS +  765)    /*    ss_strm.c: 538 */
#define   ESS766      (ERRSS +  766)    /*    ss_strm.c: 549 */
#define   ESS767      (ERRSS +  767)    /*    ss_strm.c: 567 */
#define   ESS768      (ERRSS +  768)    /*    ss_strm.c: 622 */
#define   ESS769      (ERRSS +  769)    /*    ss_strm.c: 633 */
#define   ESS770      (ERRSS +  770)    /*    ss_strm.c: 669 */
#define   ESS771      (ERRSS +  771)    /*    ss_strm.c: 680 */
#define   ESS772      (ERRSS +  772)    /*    ss_strm.c: 728 */
#define   ESS773      (ERRSS +  773)    /*    ss_strm.c: 746 */
#define   ESS774      (ERRSS +  774)    /*    ss_strm.c: 806 */
#define   ESS775      (ERRSS +  775)    /*    ss_strm.c: 818 */
#define   ESS776      (ERRSS +  776)    /*    ss_strm.c: 872 */
#define   ESS777      (ERRSS +  777)    /*    ss_strm.c: 896 */
#define   ESS778      (ERRSS +  778)    /*    ss_strm.c: 908 */
#define   ESS779      (ERRSS +  779)    /*    ss_strm.c: 919 */
#define   ESS780      (ERRSS +  780)    /*    ss_strm.c:1056 */
#define   ESS781      (ERRSS +  781)    /*    ss_strm.c:1176 */
#define   ESS782      (ERRSS +  782)    /*    ss_strm.c:1182 */
#define   ESS783      (ERRSS +  783)    /*    ss_strm.c:1356 */
#define   ESS784      (ERRSS +  784)    /*    ss_strm.c:1483 */

#define   ESS785      (ERRSS +  785)    /*   ss_timer.c:  19 */
#define   ESS786      (ERRSS +  786)    /*   ss_timer.c:  20 */
#define   ESS787      (ERRSS +  787)    /*   ss_timer.c: 200 */
#define   ESS788      (ERRSS +  788)    /*   ss_timer.c: 206 */
#define   ESS789      (ERRSS +  789)    /*   ss_timer.c: 214 */
#define   ESS790      (ERRSS +  790)    /*   ss_timer.c: 221 */
#define   ESS791      (ERRSS +  791)    /*   ss_timer.c: 228 */
#define   ESS792      (ERRSS +  792)    /*   ss_timer.c: 238 */
#define   ESS793      (ERRSS +  793)    /*   ss_timer.c: 250 */
#define   ESS794      (ERRSS +  794)    /*   ss_timer.c: 268 */
#define   ESS795      (ERRSS +  795)    /*   ss_timer.c: 274 */
#define   ESS796      (ERRSS +  796)    /*   ss_timer.c: 284 */
#define   ESS797      (ERRSS +  797)    /*   ss_timer.c: 299 */
#define   ESS798      (ERRSS +  798)    /*   ss_timer.c: 316 */
#define   ESS799      (ERRSS +  799)    /*   ss_timer.c: 324 */
#define   ESS800      (ERRSS +  800)    /*   ss_timer.c: 351 */
#define   ESS801      (ERRSS +  801)    /*   ss_timer.c: 402 */
#define   ESS802      (ERRSS +  802)    /*   ss_timer.c: 488 */
#define   ESS803      (ERRSS +  803)    /*   ss_timer.c: 495 */
#define   ESS804      (ERRSS +  804)    /*   ss_timer.c: 502 */
#define   ESS805      (ERRSS +  805)    /*   ss_timer.c: 509 */
#define   ESS806      (ERRSS +  806)    /*   ss_timer.c: 516 */
#define   ESS807      (ERRSS +  807)    /*   ss_timer.c: 526 */
#define   ESS808      (ERRSS +  808)    /*   ss_timer.c: 537 */
#define   ESS809      (ERRSS +  809)    /*   ss_timer.c: 555 */
#define   ESS810      (ERRSS +  810)    /*   ss_timer.c: 561 */
#define   ESS811      (ERRSS +  811)    /*   ss_timer.c: 571 */
#define   ESS812      (ERRSS +  812)    /*   ss_timer.c: 586 */
#define   ESS813      (ERRSS +  813)    /*   ss_timer.c: 622 */
#define   ESS814      (ERRSS +  814)    /*   ss_timer.c: 630 */
#define   ESS815      (ERRSS +  815)    /*   ss_timer.c: 666 */

#ifdef __cplusplus
}
#endif

#endif  /* __SSERRH__ */


  
/********************************************************************30**
  
         End of file: ss_err.h 1.3  -  10/14/98 14:10:51
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. initial release

1.2          ---      bsr  1. Updated error codes
  
1.3          ---      ada  1. Added typecast in SLogError to remove
                              diab compile errors 
                      kp   1. Regenerated error codes
1.3+        ss029.103 kkj  1. Multiple proc ids support added
*********************************************************************91*/
