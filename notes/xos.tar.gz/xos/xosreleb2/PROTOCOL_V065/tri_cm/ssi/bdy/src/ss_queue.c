/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
 
     Name:     System Services -- Queueing
 
     Type:     C source file
 
     Desc:     Source code for System Services queuing functions.
 
     File:     ss_queue.c
 
     Sid:      ss_queue.c 1.3  -  10/14/98 14:17:28
 
     Prg:      bsr
  
*********************************************************************21*/



/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_strm.h"       /* STREAMS */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */


  
/*
*
*       Fun:   SInitQueue
*
*       Desc:  This function initializes a queue.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: no assumptions are made about the previous state
*              of the queue.
*
*              queue size is set to zero.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SInitQueue
(
Queue *q               /* queue */
)
#else
PUBLIC S16 SInitQueue(q)
Queue *q;              /* queue */
#endif
{
   TRC1(SInitQueue)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check queue pointer */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS708, ERRZERO, "Null Ptr");
      RETVALUE(RFAILED);
   }
#endif
   q->head     = NULLP;
   q->tail     = NULLP;
   q->crntSize = 0;

   RETVALUE(ROK);

} /* end of SInitQueue */

  
/*
*
*       Fun:   SFlushQueue
*
*       Desc:  This function will release all of the data or message
*              buffers on the specified queue.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: if queue is empty: no action is taken.
*
*              if queue is not empty: all buffers in queue are returned
*              to memory. queue length is set to zero.
*
*              if dequeud buffer is a message buffer, all data buffers
*              associated with the message buffer are returned to memory
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SFlushQueue
(
Queue *q                    /* queue */
)
#else
PUBLIC S16 SFlushQueue(q)
Queue *q;                   /* queue */
#endif
{
   Buffer *tBuf;
   Buffer *mBuf;
   SsMsgInfo *minfo;
  
   TRC1(SFlushQueue)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS709, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
#endif

   tBuf = q->head;
   while (tBuf != NULLP)
   {
      mBuf = tBuf->b_next;
      if (tBuf->b_datap->db_type == SS_M_PROTO)
         SPutMsg(tBuf);
      else
      {
         minfo = (SsMsgInfo *) tBuf->b_rptr;
         SPutDBuf(minfo->region, minfo->pool, tBuf);
      }
      tBuf = mBuf;
   }
   q->crntSize = 0;
   q->head     = NULLP;
   q->tail     = NULLP;

   RETVALUE(ROK);

} /* end of SFlushQueue */

  
/*
*
*       Fun:   SCatQueue
*
*       Desc:  This function will concatenate the two specified queues
*              into one queue.
*
*       Ret:   ROK     - ok
*              RFAILED - failed, general (optional)
*
*       Notes: if order equals Q1Q2: all buffers attached to queue 2 are
*              moved to the end of queue 1. queue 2 is set to empty.
*              queue 1 length is increased by length of queue 2. queue
*              2 length is set to zero. return is ok.
*
*              if order equals Q2Q1: all buffers attached to queue 2 are
*              moved to the front of queue 1. queue 2 is set to empty.
*              queue 1 length is increased by length of queue 2. queue
*              2 length is set to zero. return is ok.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SCatQueue
(
Queue *q1,                  /* queue 1 */
Queue *q2,                  /* queue 2 */
Order order                 /* order */
)
#else
PUBLIC S16 SCatQueue(q1, q2, order)
Queue *q1;                  /* queue 1 */
Queue *q2;                  /* queue 2 */
Order order;                /* order */
#endif
{
   TRC1(SCatQueue)
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (q1 == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS710, ERRZERO, "Null Q1 Ptr");
      RETVALUE(RFAILED);
   }
 
   if (q2 == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS711, ERRZERO, "Null Q2 Ptr");
      RETVALUE(RFAILED);
   }
   
   if ((order != Q1Q2) && (order != Q2Q1))
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS712, ERRZERO, "Invalid queue order");
      RETVALUE(RFAILED);
   }

   /* ss021.103 - Addition if Q1 is Q2 */
   if (q2 == q1)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS713, ERRZERO, "Q1 == Q2");
      RETVALUE(RFAILED);
   }
   
#endif /* ERRCLASS */
   
   if (q1->crntSize == 0)
   {
      q1->head       = q2->head;
      q1->tail       = q2->tail;
      q1->crntSize   = q2->crntSize;

      q2->head       = NULLP;
      q2->tail       = NULLP;
      q2->crntSize   = 0;
      
      RETVALUE(ROK);
   }

   if (q2->crntSize == 0)
   {
      RETVALUE(ROK);
   }
   
   switch (order)
   {
      case Q1Q2:
      {
         q1->tail->b_next = q2->head;
         q2->head->b_prev = q1->tail;
         q1->tail         = q2->tail;

         break;
      }

      case Q2Q1:
      {
         q2->tail->b_next = q1->head;
         q1->head->b_prev = q2->tail;
         q1->head         = q2->head;

         break;
      }
      default:
         RETVALUE(RFAILED);
   }

   q1->crntSize  += q2->crntSize;

   q2->head       = NULLP;
   q2->tail       = NULLP;
   q2->crntSize   = 0;

   RETVALUE(ROK);

} /* end of SCatQueue */


  
/*
*
*       Fun:   SFndLenQueue
*
*       Desc:  This function determines the length of a queue.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: length of queue is determined, queue is unchanged
*              and length is returned via pointer to length.
*              
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SFndLenQueue
(
Queue *q,                   /* queue */
QLen  *lngPtr               /* pointer to length */
)
#else
PUBLIC S16 SFndLenQueue(q, lngPtr)
Queue *q;                   /* queue */
QLen  *lngPtr;              /* pointer to length */
#endif
{
   TRC1(SFndLenQueue)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS714, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
   /* check length */
   if (lngPtr == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS715, ERRZERO, "Null Q Len Ptr");
      RETVALUE(RFAILED);
   }
#endif

   *lngPtr = q->crntSize;

   RETVALUE(ROK);

} /* end of SFndLenQueue */


/*
*
*       Fun:   SExamQueue
*
*       Desc:  This function examines the queue at the desired index.
*
*       Ret:   ROK      - ok
*              ROKDNA   - ok, data not available
*              RFAILED  - failed 
*
*       Notes: index is 0 based and indicates location in queue.
*
*              if queue is empty: pointer to buffer is set to null and
*              return is ok, data not available. queue length is unchanged.
*
*              if queue is not empty: pointer to buffer is set to indexed
*              buffer in queue. return is ok. queue length is unchanged.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SExamQueue
(
Buffer **bufPtr,            /* pointer to buffer */
Queue  *q,                  /* queue */
QLen   idx                  /* index */
)
#else
PUBLIC S16 SExamQueue(bufPtr, q, idx)
Buffer **bufPtr;            /* pointer to buffer */
Queue  *q;                  /* queue */
QLen   idx;                 /* index */
#endif
{
   Buffer *tmpBuf;
   QLen   i;

   TRC1(SExamQueue)
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check buffer pointer */
   if (bufPtr == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS716, ERRZERO, "Null Buf Ptr");
      RETVALUE(RFAILED);
   }
 
   /* check index */
   if ((S32)idx < 0)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS717, ERRZERO, "-ve index ");
      RETVALUE(RFAILED);
   }
 
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS718, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */
 
   if (idx >= q->crntSize)
   {
      *bufPtr = NULLP;
      RETVALUE(ROKDNA);
   }

   if (idx == 0)
   {
      *bufPtr = q->head;
   }
   else  if (idx == q->crntSize -1)
   {
      *bufPtr = q->tail;
   }
   else 
   {
      tmpBuf = q->head;
      for (i = 0; i < idx; i++)
      {
         tmpBuf = tmpBuf->b_next;
      }
      *bufPtr = tmpBuf;
   }

   RETVALUE(ROK);

} /* end of SExamQueue */


/*
*
*       Fun:   SAddQueue
*
*       Desc:  This function inserts a bufer into the queue before 
*              the desired index.
*
*       Ret:   ROK     - ok
*              RFAILED - failed
*              ROKDNA  - failed - specified index not available
*
*       Notes: index is 0 based and indicates location in queue.
*
*              if queue is empty: buffer is placed in the queue.
*              queue length is incremented.
*
*              if queue is not empty: if index is less than the queue length, 
*              buffer is inserted before the desired index;
*              otherwise, buffer is placed behind all other buffers in queue.
*              queue length is incremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SAddQueue
(
Buffer *mBuf,                /* buffer */
Queue  *q,                   /* queue */
QLen   idx                   /* index */
)
#else
PUBLIC S16 SAddQueue(mBuf, q, idx)
Buffer *mBuf;                /* buffer */
Queue  *q;                   /* queue */
QLen   idx;                  /* index */
#endif
{
   Buffer *tBuf;
   QLen   i;

   TRC1(SAddQueue)
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS719, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
 
   if (mBuf == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS720, ERRZERO, "Null Buf Ptr");
      RETVALUE(RFAILED);
   }
 
   if ((S32)idx < 0)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS721, ERRZERO, "-ve index");
      RETVALUE(RFAILED);
   }
   /* ss021.103 - Addition to check buffer type and if duplicate message */
   if (mBuf->b_datap->db_type != SS_M_PROTO)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS722, ERRZERO, 
                 "Incorrect buffer type");
      RETVALUE(RFAILED);
   }
   tBuf = q->head;
   while (tBuf != (Buffer *)NULLP)
   {
      if (tBuf == mBuf)
      {
         SSLOGERROR(ERRCLS_INT_PAR, ESS723, ERRZERO, "Duplicate queued mBuf");
         RETVALUE(RFAILED);
      }
      tBuf = tBuf->b_next;
   }
#endif /* ERRCLASS */

   if (idx > q->crntSize)
   {
      SSLOGERROR(ERRCLS_DEBUG, ESS724, ERRZERO, "Invalid index");
      RETVALUE(ROKDNA);
   }
   else if (q->crntSize == 0)
   {
      q->head = mBuf;
      q->tail = mBuf;

      mBuf->b_next = NULLP;
      mBuf->b_prev = NULLP;
   }
   else if (idx == 0)
   {
      mBuf->b_next     = q->head;
      mBuf->b_prev     = NULLP;
      q->head->b_prev  = mBuf;
      q->head          = mBuf;
   }
   else if (idx == q->crntSize)
   {
      mBuf->b_prev    = q->tail;
      mBuf->b_next    = NULLP;
      q->tail->b_next = mBuf;
      q->tail         = mBuf;
   }
   else
   {
      tBuf = q->head;
      for (i = 0; i < idx; i++)
      {
         tBuf = tBuf->b_next;
      }
    
      tBuf->b_prev->b_next = mBuf;
      mBuf->b_prev         = tBuf->b_prev;
      mBuf->b_next         = tBuf;
      tBuf->b_prev         = mBuf;
   }
   q->crntSize++;
   RETVALUE(ROK);

} /* end of SAddQueue */


/*
*
*       Fun:   SRemQueue
*
*       Desc:  This function removes a buffer from the queue at 
*              the desired index.
*
*       Ret:   ROK      - ok
*              ROKDNA   - ok, data not available
*              RFAILED  - failed
*
*       Notes: index is 0 based and indicates location in queue.
*
*              if queue is empty: pointer to buffer is set to null and
*              return is ok, data not available. queue length is unchanged.
*
*              if queue is not empty: pointer to buffer is set to indexed
*              buffer in queue. return is ok. queue length is decremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SRemQueue
(
Buffer **bufPtr,            /* pointer to buffer */
Queue  *q,                  /* queue */
QLen   idx                  /* index */
)
#else
PUBLIC S16 SRemQueue(bufPtr, q, idx)
Buffer **bufPtr;            /* pointer to buffer */
Queue  *q;                  /* queue */
QLen   idx;                 /* index */
#endif
{
   Buffer *tBuf;
   QLen   i;

   TRC1(SRemQueue)
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check buffer pointer */
   if (bufPtr == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS725, ERRZERO, "Null Buf Ptr");
      RETVALUE(RFAILED);
   }
 
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS726, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
 
   if ((S32)idx < 0)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS727, ERRZERO, "-ve Index");
      RETVALUE(RFAILED);
   }      
#endif /* ERRCLASS */   
 
   if (idx >= q->crntSize)
   {
      *bufPtr = NULLP;
      RETVALUE(ROKDNA);
   }
   if (idx == 0)
   {
      *bufPtr = q->head;
      if (q->crntSize == 1)
      {
         q->head = NULLP;
         q->tail = NULLP;
      }
      else
      {
         q->head         = q->head->b_next;
         q->head->b_prev = NULLP;
      }
   }
   else if (idx == q->crntSize -1)
   {
      *bufPtr = q->tail;
      q->tail = q->tail->b_prev;
      q->tail->b_next = NULLP;
   }
   else 
   {
      tBuf = q->head;

      for (i = 0; i < idx; i++)
      {
         tBuf = tBuf->b_next;
      }
      *bufPtr = tBuf;
      
      tBuf->b_prev->b_next = tBuf->b_next;
      tBuf->b_next->b_prev = tBuf->b_prev;
   }
   q->crntSize--;

   RETVALUE(ROK);

} /* end of SRemQueue */


#ifndef SS_ENABLE_MACROS


/*
*
*       Fun:   SQueueFirst
*
*       Desc:  This function queues a data or message buffer to the
*              front of the specified queue.
*
*       Ret:   ROK     - ok
*              RFAILED - failed, general (optional)
*
*       Notes: if queue is empty: buffer is placed in the queue. queue
*              length is incremented.
*              
*              if queue is not empty: buffer is placed in front of all
*              other buffers in queue. queue length is incremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SQueueFirst
(
Buffer *buf,                /* buffer */
Queue *q                    /* queue */
)
#else
PUBLIC INLINE S16 SQueueFirst(buf, q)
Buffer *buf;                /* buffer */
Queue *q;                   /* queue */
#endif
{
   TRC1(SQueueFirst)

   RETVALUE(SAddQueue(buf, q, 0));
} /* end of SQueueFirst */

  
/*
*
*       Fun:   SDequeueFirst
*
*       Desc:  This function dequeues a data or message buffer from
*              the front of the specified queue.
*
*       Ret:   ROK      - ok
*              ROKDNA   - ok, data not available
*              RFAILED  - failed, general (optional)
*
*       Notes: if queue is empty: pointer to buffer is set to null and
*              return is ok, data not available. queue length is unchanged.
*              
*              if queue is not empty: pointer to buffer is set to first
*              buffer in queue, first buffer in queue is removed and
*              return is ok. queue length is decremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SDequeueFirst
(
Buffer **bufPtr,            /* pointer to buffer */
Queue *q                    /* queue */
)
#else
PUBLIC INLINE S16 SDequeueFirst(bufPtr, q)
Buffer **bufPtr;            /* pointer to buffer */
Queue *q;                   /* queue */
#endif
{
   TRC2(SDequeueFirst)

   RETVALUE(SRemQueue(bufPtr, q, 0));
} /* end of SDequeueFirst */

  
/*
*
*       Fun:   SQueueLast
*
*       Desc:  This function queues a data or message buffer to the
*              back of the specified queue.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: if queue is empty: buffer is placed in the queue.
*              queue length is incremented.
*              
*              if queue is not empty: buffer is placed behind all
*              other buffers in queue. queue length is incremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SQueueLast
(
Buffer *buf,                /* buffer */
Queue *q                    /* queue */
)
#else
PUBLIC S16 SQueueLast(buf, q)
Buffer *buf;                /* buffer */
Queue *q;                   /* queue */
#endif
{
   TRC1(SQueueLast)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check queue */
   if (q == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS728, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
   /* check queue */
   if (buf == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS729, ERRZERO, "Null Buf Ptr");
      RETVALUE(RFAILED);
   }
#endif
   RETVALUE(SAddQueue(buf, (q), ((q)->crntSize)));
}


  
/*
*
*       Fun:   SDequeueLast
*
*       Desc:  This function dequeues a data or message buffer from the
*              back of the specified queue.
*
*       Ret:   ROK     - ok
*              ROKDNA  - ok, data not available
*              RFAILED - failed, general (optional)
*
*       Notes: if queue is empty: pointer to buffer is set to null and
*              return is ok, data not available. queue length is unchanged.
*              
*              if queue is not empty: pointer to buffer is set to last
*              buffer in queue, last buffer in queue is removed and
*              return is ok. queue length is decremented.
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 SDequeueLast
(
Buffer **bufPtr,            /* pointer to buffer */
Queue *q                    /* queue */
)
#else
PUBLIC S16 SDequeueLast(bufPtr, q)
Buffer **bufPtr;            /* pointer to buffer */
Queue *q;                   /* queue */
#endif
{
   S16   ret;

   TRC1(SDequeueLast)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check buffer pointer */
   if (!bufPtr)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS730, ERRZERO, "Null Buf Ptr");
      RETVALUE(RFAILED);
   }
   /* check queue */
   if (!q)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS731, ERRZERO, "Null Q Ptr");
      RETVALUE(RFAILED);
   }
#endif
   if(q->crntSize > 0)
      ret = SRemQueue(bufPtr, q, q->crntSize-1);
   else
      ret = SRemQueue(bufPtr, q, q->crntSize);

   RETVALUE(ret);
}

#endif /* SS_ENABLE_MACROS */


/*
*
*       Fun:   ssInitDmndQ
*
*       Desc:  This function initializes a Demand Queue
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 ssInitDmndQ
(
SsDmndQ *dQueue                 /* Demand Queue */
)
#else
PUBLIC S16 ssInitDmndQ(dQueue)
SsDmndQ *dQueue;                /* Demand Queue */
#endif
{
   U8  i;
   S16 ret;

   TRC0(ssInitDmnddQ)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dQueue == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS732, ERRZERO, "NULL DQ Pointer");
      RETVALUE(RFAILED);
   }
#endif

   for (i = 0; i < SS_MAX_NUM_DQ; i++)
   {
      dQueue->queue[i].head     = NULLP;
      dQueue->queue[i].tail     = NULLP;
      dQueue->queue[i].crntSize = 0;
   }

   for (i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
   {
      dQueue->bitMask[i] =  0;
      ret = SInitLock(&dQueue->dmndQLock[i], SS_DMNDQ_LOCK);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS733, (ErrVal)ret,
                                   "Failed to initialize lock");
#endif
         RETVALUE(RFAILED);
      }
   }

   /* initialize the semaphore */
   ret = ssInitSema(&dQueue->dmndQSema, 0);
   if (ret != ROK)
   {
      for (i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
      {
         SDestroyLock(&dQueue->dmndQLock[i]);
      }
#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS734, (ErrVal)ret, 
                                   "Failed to init semaphore");
#endif
      RETVALUE(RFAILED);
   }
   RETVALUE (ROK);

} /* End of ssInitDmndQ */


/*
*
*       Fun:   ssDestroyDmndQ
*
*       Desc:  This function destroys a Demand Queue by releasing all the
*              queued messages and detroying all the associated locks
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: 
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 ssDestroyDmndQ
(
SsDmndQ *dQueue                        /* demand Queue */
)
#else
PUBLIC S16 ssDestroyDmndQ(dQueue)
SsDmndQ *dQueue;                       /* demand Queue */
#endif
{
   U8     i;
   Buffer *tBuf;
   S16    ret;

   TRC0(ssDestroyDmndQ)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dQueue == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS735, ERRZERO, "NULL DQ Pointer");
      RETVALUE(RFAILED);
   }
#endif

   for (i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
   {
      ret = SDestroyLock(&dQueue->dmndQLock[i]);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS736, (ErrVal)ret, "Failed to destroy lock");
#endif
         RETVALUE(RFAILED);
      }
   }
   for (i = 0; i < SS_MAX_NUM_DQ; i++)
   {
      while (dQueue->queue[i].head != NULLP)
      {
         tBuf = dQueue->queue[i].head;
         dQueue->queue[i].head = dQueue->queue[i].head->b_next;
         SPutMsg(tBuf);
      }
   }
#if 0    /* ss06.13:deletion */
   ssDestroySema(&dQueue->dmndQSema);
#endif   /* ss06.13:deletion */

#if 1    /* ss06.13:addition */
   if( ssDestroySema(&dQueue->dmndQSema) != ROK)
   {
      SSLOGERROR(ERRCLS_DEBUG, ESS737, ERRZERO,
                         "Could not delete the Semaphore");
      RETVALUE(RFAILED);

   }
#endif   /* ss06.13:addition */
   RETVALUE (ROK);

} /* end of ssDestroyDmndQ */


/*
*
*       Fun:   ssDmndQPut
*
*       Desc:  This function adds a message to the head or tail of the 
*              priority queue specified. The priority specified is the 
*              destination Q index i.e 
*              ((dst_Tsk_pri * SS_MAX_MSG_PRI) + msg_pri)
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 ssDmndQPut
(
SsDmndQ *dQueue,                       /* demand Queue */
Buffer  *mBuf,                         /* message buffer */
Prior   priority,                      /* priority */
Order   order                          /* position */
)
#else
PUBLIC S16 ssDmndQPut(dQueue, mBuf, priority, order)
SsDmndQ *dQueue;                       /* demand Queue */
Buffer  *mBuf;                         /* message buffer */
Prior   priority;                      /* priority */
Order   order;                         /* position */
#endif
{
   U8     maskIndex;                   /* mask Index */
   U8     bitPosition;                 /* bit position in index */
   Queue *queue;                       /* queue in demand queue */
   S16    ret;                         /* return value */

   TRC0(ssDmndQPut)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dQueue == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS738, ERRZERO, "NULL DQ Pointer");
      RETVALUE(RFAILED);
   }

   if (mBuf == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS739, ERRZERO, "NULL mBuf Pointer");
      RETVALUE(RFAILED);
   }

   if ((priority == PRIORNC) || (priority > SS_MAX_DQ_PRIOR))
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS740, ERRZERO, "invalid priority ");
      RETVALUE(RFAILED);
   }

   if ((order != SS_DQ_FIRST) && (order != SS_DQ_LAST))
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS741, ERRZERO, "invalid order ");
      RETVALUE(RFAILED);
   }
#endif
   
   maskIndex   = priority >> 3;
   bitPosition = 7 - (priority % 8);
   queue       = &dQueue->queue[priority];

   ret = SLock(&dQueue->dmndQLock[maskIndex]);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS742, (ErrVal)ret, "Failed to get lock");
#endif
      RETVALUE (RFAILED);
   }

   if (queue->crntSize == 0)
   {
      queue->head   = mBuf;
      queue->tail   = mBuf;
      mBuf->b_next  = NULLP;
      mBuf->b_prev  = NULLP;

      /* Set the corresponding bit in bit mask */
      dQueue->bitMask[maskIndex] |= (1 << bitPosition);
   }
   else
   {
      if (order == SS_DQ_LAST)
      {
         mBuf->b_prev        = queue->tail;
         mBuf->b_next        = NULLP;
         queue->tail->b_next = mBuf;
         queue->tail         = mBuf;
      }
      else
      {
         mBuf->b_next        = queue->head;
         mBuf->b_prev        = NULLP;
         queue->head->b_prev = mBuf;
         queue->head         = mBuf;
      }
   }
   queue->crntSize++;

   ret = SUnlock(&dQueue->dmndQLock[maskIndex]);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS743, (ErrVal)ret, "Failed to release lock");
#endif
      /* ss035.103 */
      if (order == SS_DQ_LAST)
      {
         SDequeueLast(&mBuf, queue);
      }
      else
      {
         SDequeueFirst(&mBuf, queue);
      }
      RETVALUE (RFAILED);
   }

   /* increment the counting semaphore */
#if 0  /* ss006.13: deletion */
   ssPostSema(&dQueue->dmndQSema);
#endif /* ss006.13: deletion */
#if 1  /* ss006.13: addition */
   if (ssPostSema(&dQueue->dmndQSema) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
       SSLOGERROR(ERRCLS_DEBUG, ESS744, ERRZERO,
                         "Could not unlock the Semaphore");
       /* ss035.103 */
       if (order == SS_DQ_LAST)
       {
          SDequeueLast(&mBuf, queue);
       }
       else
       {
          SDequeueFirst(&mBuf, queue);
       } 
       RETVALUE(RFAILED);
#endif
   }
#endif /* ss006.13: addition */
   RETVALUE(ROK);

} /* End of ssDmndQPut */


/*
*
*       Fun:   ssDmndQGet
*
*       Desc:  This function removes a message from head or tail of the 
*              highest non-empty priority queue message. 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ROKDNA   - ok, no data available in queue
*
*       Notes:  This is a blocking call
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 ssDmndQGet
(
SsDmndQ *dQueue,                          /* demand queue */
Buffer  **mBuf,                           /* message buffer */
Order   order                             /* position */ 
)
#else
PUBLIC S16 ssDmndQGet(dQueue, mBuf, order)
SsDmndQ *dQueue;                          /* demand queue */
Buffer  **mBuf;                           /* message buffer */
Order   order;                            /* position */
#endif
{
   Queue *queue;
   S16   ret;
   S16   i;
   U8    bitPosition;
   U8    qIndex;

   TRC0(ssDmndQGet)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dQueue == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS745, ERRZERO, "NULL DQ Pointer");
      RETVALUE(RFAILED);
   }

   if (mBuf == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS746, ERRZERO, "NULL mBuf Pointer");
      RETVALUE(RFAILED);
   }

   if ((order != SS_DQ_FIRST) && (order != SS_DQ_LAST))
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS747, ERRZERO, "invalid order ");
      RETVALUE(RFAILED);
   }
#endif

   ret = ssWaitSema(&dQueue->dmndQSema);
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS748, (ErrVal)ret, "Failed to get semaphore");
#endif
      RETVALUE (RFAILED);
   }

   for (i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
   {
      ret = SLock(&dQueue->dmndQLock[i]);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS749, (ErrVal)ret, "Failed to get lock");
#endif
         RETVALUE (RFAILED);
      }

      bitPosition = osCp.dmndQLookupTbl[dQueue->bitMask[i]];
      if (bitPosition != 255)
         break;

      ret = SUnlock(&dQueue->dmndQLock[i]);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS750, ret, "Failed to release lock");
#endif
         RETVALUE (RFAILED);
      }
   }

   if (i >= SS_DQ_BIT_MASK_LEN)
   {
      /* Demand Queue is empty */
      *mBuf = NULLP;
      RETVALUE (ROKDNA);
   }
   
   qIndex = (i * 8) +  (7 - bitPosition);
   queue = &dQueue->queue[qIndex];

   if (queue->crntSize == 1)
   {
      *mBuf = queue->head;
      queue->head = NULLP;
      queue->tail = NULLP;

      /* Reset the corresponding bit in bit mask */
      dQueue->bitMask[i] &= (~( 1 << (bitPosition)));
   }
   else
   {
      if (order == SS_DQ_FIRST)
      {
         *mBuf = queue->head;
         queue->head = queue->head->b_next;
         queue->head->b_prev = NULLP;
      }
      else
      {
         *mBuf = queue->tail;
         queue->tail = queue->tail->b_prev;
         queue->tail->b_next = NULLP;
      }
   }
   queue->crntSize--;

   ret = SUnlock(&dQueue->dmndQLock[i]); 
   if (ret != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS751, (ErrVal)ret, "Failed to release lock");
#endif
      RETVALUE (RFAILED);
   }

   RETVALUE (ROK);

} /* End of ssDmndQGet */


/*
*
*       Fun:   ssFndLenDmndQ 
*
*       Desc:  This function returns the number of messages in a queue
*              If priority is specified, length of the associated Q is 
*              returned otherwise total length of all Qs is returned.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  ss_queue.c
*
*/
#ifdef ANSI
PUBLIC S16 ssFndLenDmndQ
(
SsDmndQ *dQueue,                               /* demand queue */
Prior   priority,                              /* priority */
QLen    *len                                   /* queue length */
)
#else
PUBLIC S16 ssFndLenDmndQ(dQueue, priority, len)
SsDmndQ *dQueue;                               /* demand queue */
Prior   priority;                              /* priority */
QLen    *len;                                  /* queue length */
#endif
{
   
   S16  ret;                                   /* return value */
   U8   i;

   TRC0(ssFndLenDmndQ)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((dQueue == NULLP) || (len == NULLP))
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS752, ERRZERO, "NULL Pointer");
      RETVALUE(RFAILED);
   }
#endif

   *len = 0;
   if (priority != PRIORNC)
   {
      i = priority >> 3; 
      ret = SLock(&dQueue->dmndQLock[i]);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS753, (ErrVal)ret, "Failed to get lock");
#endif
         RETVALUE (RFAILED);
      }

      *len = dQueue->queue[priority].crntSize;

      ret = SUnlock(&dQueue->dmndQLock[i]);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         SSLOGERROR(ERRCLS_DEBUG, ESS754, (ErrVal)ret,  \
                                         "Failed to release lock");
#endif
         RETVALUE (RFAILED);
      }
   }
   else
   {
      for (i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
      {
         ret = SLock(&dQueue->dmndQLock[i]);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SSLOGERROR(ERRCLS_DEBUG, ESS755, (ErrVal)ret, "Failed to get lock");
#endif
            /* Release all the locks aquired */
            while (i > 0)
            {
#if 0   /* ss006.13: deletion */
                SUnlock(&dQueue->dmndQLock[i-1]);
#endif  /* ss006.13: deletion */

#if 1   /* ss006.13: addition */
                if( SUnlock(&dQueue->dmndQLock[i-1]) != ROK)
                {
#if (ERRCLASS & ERRCLS_DEBUG)
                   SSLOGERROR(ERRCLS_DEBUG, ESS756, ERRZERO,
                         "Could not give the Semaphore");
                   RETVALUE(RFAILED);
#endif
                }
#endif  /* ss006.13: addition */

               i--;
            }

            RETVALUE (RFAILED);
         }
      }

      for (i = 0; i  < SS_MAX_NUM_DQ; i++)
         *len  += dQueue->queue[i].crntSize;

      for ( i = 0; i < SS_DQ_BIT_MASK_LEN; i++)
      {
         ret = SUnlock(&dQueue->dmndQLock[i]);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            SSLOGERROR(ERRCLS_DEBUG, ESS757, (ErrVal)ret, "Failed to get lock");
#endif
            RETVALUE (RFAILED);
         }
      }
   }
   RETVALUE(ROK);

} /* End of ssFndLenDmndQ */



/********************************************************************30**
  
         End of file:     ss_queue.c@@/main/starent_rel_1.1_dev/1 - Fri Jun 24 12:02:50 2005
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bsr  1. initial release.
  
1.2          ---      kr   1. defined functions SQueueFirst, 
                              SDequeueFirst, SQueueLast and SDequeueLast
                              under SS_ENABLE_MACROS
             ---      kp   2. Cosmetic changes

1.3          ---      kp   1. Bug fix in ssDmndQGet()
1.3+        ss006.13  jn   2. Compile Warning - "Value computed is not
                              used" removed for ssPostSema and SUnlock.
1.3+       ss021.103 bjp   3. test if q1 == q2 for SCatQueue
                              add test for correct buffer type and
			         if duplicate buffer in SAddQueue
1.3+       ss029.103  kkj  1. Errcodes modifies
1.3+       ss035.103  pdb  1. Add code in ssDmndQPut to remove the mBuf from
                              the demandQueue in case of error.
*********************************************************************91*/
