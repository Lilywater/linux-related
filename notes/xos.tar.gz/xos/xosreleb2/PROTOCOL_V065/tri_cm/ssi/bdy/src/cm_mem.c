/********************************************************************16**

        (c) COPYRIGHT 1989-1999 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
 
     Name:     Common Memory Manager 
 
     Type:     C source file
 
     Desc:     C source code for the Commom Memory Manager module. 
 
     File:     cm_mem.c
 
     Sid:      cm_mem.c@@/main/10 - Thu Dec  6 14:11:30 2001
 
     Prg:      rm
 
*********************************************************************21*/


/************************************************************************

The following functions are provided in this file.
 
    cmMmRegInit     Memory Region Initialization.
    cmMmRegDeInit   Memory Region Deinitialization.

************************************************************************/


/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_mem.h"        /* Common memory manager */ 


/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_mem.x"        /* Common memory manager */ 

#ifdef USE_PURE
#include <stdlib.h>
#endif /* USE_PURE */


/* local defines */

/* local typedefs */
 
/* local externs */
 
/* forward references */
 
PRIVATE S16 cmAlloc ARGS((Void *regionCb, Size *size, U32 flags, Data **ptr));
PRIVATE S16 cmFree  ARGS((Void *regionCb, Data *ptr, Size size));
PRIVATE S16 cmCtl   ARGS((Void *regionCb, Event event, SMemCtl *memCtl));

PRIVATE S16 cmHeapAlloc ARGS((CmMmHeapCb *heapCb, Data **ptr, Size *size));
PRIVATE S16 cmHeapFree  ARGS((CmMmHeapCb *heapCb, Data *ptr, Size size));

PRIVATE Void cmMmHeapInit ARGS((Data *memAddr, CmMmHeapCb *heapCb, Size size));
PRIVATE Void cmMmBktInit ARGS((Data **memAddr, CmMmRegCb *regCb, 
                              CmMmRegCfg *cfg, U16 bktIdx, U16 *lstMapIdx));

/* public variable declarations */
#ifdef USE_PURE
Size avail_size;
#endif /* USE_PURE */

/* private variable declarations */


/*
*
*       Fun:   cmMmRegInit
*
*       Desc:  Configure the memory region for allocation. The function 
*              registers the memory region with System Service by calling
*              SRegRegion.
*
*
*       Ret:   ROK     - successful, 
*              RFAILED - unsuccessful.
*
*       Notes: The memory owner calls this function to initialize the memory 
*              manager with the information of the memory region. Before 
*              calling this function, the memory owner should allocate memory 
*              for the memory region. The memory owner should also provide the 
*              memory for the control block needed by the memory manager. The 
*              memory owner should allocate the memory for the region control 
*              block as cachable memory. This may increase the average 
*              throughput in allocation and deallocation as the region control
*              block is mostly accessed by the CMM.
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PUBLIC S16 cmMmRegInit
(
Region       region,
CmMmRegCb   *regCb,
CmMmRegCfg  *cfg
)
#else
PUBLIC S16 cmMmRegInit(region, regCb, cfg)
Region       region;
CmMmRegCb   *regCb;
CmMmRegCfg  *cfg;
#endif
{
   Data *memAddr;
   U16   bktIdx;
   U16   lstMapIdx;

#if (ERRCLASS & ERRCLS_INT_PAR)
   Size  lstQnSize;
   Size  bktBlkSize;
#endif

   TRC2(cmMmRegInit);

#if (ERRCLASS & ERRCLS_INT_PAR)

   /* error check on parameters */
   if ((regCb == NULLP) || (cfg == NULLP)) 
   {
      RETVALUE(RFAILED);
   }
   
   /* Error check on the configuration fields */
   if ((!cfg->size) || (cfg->vAddr == NULLP) || 
        (cfg->numBkts > CMM_MAX_BKT_ENT)) 
   {
      RETVALUE(RFAILED);
   }

   /* Error check whether the size of the mapping table is sufficient */
   if ((cfg->numBkts) && 
      ((cfg->bktCfg[cfg->numBkts - 1].size) /          \
        cfg->bktQnSize) > CMM_MAX_MAP_ENT)
   {
      RETVALUE(RFAILED);
   }

   /* Check if the quantum size is power of 2 */
   if ((cfg->numBkts) &&
       ((cfg->bktQnSize - 1) & (cfg->bktQnSize)))
   {
      RETVALUE(RFAILED);
   }

   /* 
    * Check if the size of the memory region is enough, whether bucket sizes
    * are multiples of quantumn size, and also whether two consecutive buckets
    *  falls within same quanta.
    */
   lstQnSize      = cfg->bktQnSize;
   regCb->bktSize = 0;

   for ( bktIdx =0; bktIdx < cfg->numBkts; bktIdx++)
   {
      /* check if bucket size is mutiple of quantumn size */
      if (cfg->bktCfg[bktIdx].size % cfg->bktQnSize)
      {
          RETVALUE(RFAILED);
      }

      if ((bktBlkSize = cfg->bktCfg[bktIdx].size) < lstQnSize)
      {
         /* 
          * Two consecutive buckets are not separated by quantum size.
          */
          RETVALUE(RFAILED);
      }

      regCb->bktSize += (cfg->bktCfg[bktIdx].size * 
                         cfg->bktCfg[bktIdx].numBlks); 
    
      if (regCb->bktSize > cfg->size)
      {
         /* Size of the memory region is less than the required size */
         RETVALUE(RFAILED);
      }

      lstQnSize = ((bktBlkSize / cfg->bktQnSize) + 1) * cfg->bktQnSize;
   }

#endif

   /* Initialize the region control block */
   regCb->region = region;
   regCb->regInfo.regCb = regCb;
   regCb->regInfo.start = cfg->vAddr;
   regCb->regInfo.size  = cfg->size;

#ifdef USE_PURE
   avail_size = cfg->size;
#endif /* USE_PURE */

   if ( cfg->chFlag & CMM_REG_OUTBOARD)
   {
      /* Out_of_board memory */
      regCb->regInfo.flags = CMM_REG_OUTBOARD;
   } 
  else
   {
      regCb->regInfo.flags = 0;
   }


   /* Initialize the memory manager function handlers */
   regCb->regInfo.alloc = cmAlloc; 
   regCb->regInfo.free  = cmFree; 
   regCb->regInfo.ctl   = cmCtl;

   /* Initialize the physical address */
   if ((regCb->chFlag = cfg->chFlag) & CMM_REG_PHY_VALID)
   {
      regCb->pAddr = cfg->pAddr;
   }

   /* Initial address of the memory region block */
   memAddr    = cfg->vAddr;

   /* Initialize the fields related to the bucket pool */
   regCb->bktMaxBlkSize = 0;
   regCb->bktSize       = 0; 

   if (cfg->numBkts)
   {
      /* Last bucket has the maximum size */
      regCb->bktMaxBlkSize = cfg->bktCfg[cfg->numBkts - 1].size;
   
      /* Get the power of the bktQnSize */
      regCb->bktQnPwr = 0; 
      while( !((cfg->bktQnSize >> regCb->bktQnPwr) & 0x01))
      {
         regCb->bktQnPwr++;
      }
    
      /* Initilaize the bktIndex of the map entries to FF */
      for ( lstMapIdx = 0; lstMapIdx < CMM_MAX_MAP_ENT; lstMapIdx++)
      {
         regCb->mapTbl[lstMapIdx].bktIdx = 0xFF;
      }
  
      lstMapIdx = 0;
      for ( bktIdx = 0; bktIdx < cfg->numBkts; bktIdx++)
      {
         /* Allocate the lock for the bucket pool */
         if (SInitLock (&(regCb->bktTbl[bktIdx].bktLock), cfg->lType) != ROK)
         {
            /* Free the initialzed lock for the earlier buckets. */
            for ( ;bktIdx > 0;)
            {
               SDestroyLock(&(regCb->bktTbl[--bktIdx].bktLock));
            }

            RETVALUE(RFAILED);
         }

         cmMmBktInit( &memAddr, regCb, cfg, bktIdx, &lstMapIdx); 
      }

      /* Used while freeing the bktLock in cmMmRegDeInit */
      regCb->numBkts = cfg->numBkts;
   }

   /* 
    * Initialize the heap pool if size the memory region region is more
    * than the size of the bucket pool 
    */
    regCb->heapSize = 0;
    regCb->heapFlag = FALSE;

    /* Align the memory address */
    memAddr = (Data *)(PTRALIGN(memAddr));

    regCb->heapSize = cfg->vAddr + cfg->size - memAddr;  

    /* 
     * Round the heap size so that the heap size is multiple 
     * of CMM_MINBUFSIZE 
     */
    regCb->heapSize -= (regCb->heapSize %  CMM_MINBUFSIZE);

    if (regCb->heapSize)
    {
       /* Allocate the lock for the heap pool */
       if (SInitLock (&regCb->heapCb.heapLock, cfg->lType) != ROK)
       {
          if ((bktIdx = cfg->numBkts))
          {
             /* Free the initialzed locks of the buckets */
             for (; bktIdx > 0;)
             {
                SDestroyLock(&(regCb->bktTbl[--bktIdx].bktLock));
             }
          }

          RETVALUE(RFAILED);
       }
        
       regCb->heapFlag = TRUE;
       cmMmHeapInit(memAddr, &(regCb->heapCb), regCb->heapSize); 
    }

    /* Call SRegRegion to register the memory region with SSI */
    if (SRegRegion(region, &regCb->regInfo) != ROK)
    {
       RETVALUE(RFAILED);
    }

    RETVALUE(ROK);
} /* end of cmMmRegInit*/



/*
*
*       Fun:   cmMmRegDeInit
*
*       Desc:  Deinitialize the memory region. The function call SDeregRegion
*              to deregister the memory region with System Service.
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: The memory owner calls this function to deinitialize the region.
*              The memory manager does not return the memory to the system. 
*              Before calling this function, the memory owner must be sure that 
*              no layer is using any memory block from this region. On 
*              successful return from the function, any request to the memory 
*              manager to allocate/deallocate memory will fail. The memory owner
*              can reuse the memory for other region or return the memory to the
*              system memory pool.
*
*
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PUBLIC S16 cmMmRegDeInit
(
CmMmRegCb   *regCb
)
#else
PUBLIC S16 cmMmRegDeInit(regCb)
CmMmRegCb   *regCb;
#endif
{
   U16  bktIdx; 

   TRC2(cmMmRegDeInit);

#if (ERRCLASS & ERRCLS_INT_PAR)
  
   /* error check on parameters */
   if (regCb == NULLP)
   {
      RETVALUE(RFAILED);
   }

#endif

   /* Call SDeregRegion first to deregister the memory region with SSI */
   (Void) SDeregRegion (regCb->region);

   if (regCb->bktSize)
   {
      /* Bucket pool is configured */

      /* Free the initialzed locks of the buckets */
      for ( bktIdx = regCb->numBkts; bktIdx > 0;)
      {
         SDestroyLock(&(regCb->bktTbl[--bktIdx].bktLock));
      }
   }

   if (regCb->heapFlag)
   {
      /* Heap pool is configured */

      /* Destroy the bucket lock */
      SDestroyLock(&regCb->heapCb.heapLock);
   }

   RETVALUE(ROK);

} /* end of cmMmRegDeInit */


/*
*
*       Fun:   cmAlloc
*
*       Desc:  Allocate a memory block for the memory region.
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: 
*              The function allocates a memory block of size atleast equal to 
*              the requested size. The size parameter will be updated with the 
*              actual size of the memory block allocated for the request. The 
*              CMM tries to allocate the memory block form the bucket pool. If
*              there is no memory in the bucket the CMM allocates the memory 
*              block form the heap pool. This function is always called by the
*              System Service module.
*    
*              The caller of the function should try to use the out value of 
*              the size while returning the memory block to the region. However 
*              the current design of the memory manager does not enforce to pass
*              the actual size of the memory block.  (Due to the SGetSBuf 
*              semantics the layer will not able to pass the correct size of the
*              memory block while calling SPutSBuf).
*
*
*       File:  cm_mem.c
*
*/

#ifdef ANSI
PRIVATE S16  cmAlloc
(
Void   *regionCb,
Size   *size,
U32     flags,
Data  **ptr 
)
#else
PRIVATE S16  cmAlloc(regionCb, size, flags, ptr)
Void   *regionCb;
Size   *size;
U32     flags;
Data  **ptr;
#endif
{
   U16        idx;
   CmMmBkt   *bkt;
   CmMmRegCb *regCb;

   TRC2(cmAlloc);

   UNUSED(flags);

   regCb = (CmMmRegCb *)regionCb;

#if (ERRCLASS & ERRCLS_INT_PAR)

   /* error check on parameters */
   if ((regCb == NULLP) || (size == NULLP) || !(*size) || (ptr == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif
  
#if(!defined( USE_PURE)&&!defined(XOS_SSI_MEM))

   /* 
    * Check if the requested size is less than or equal to the maximum block 
    * size in the bucket. 
    */
   if ( *size <= regCb->bktMaxBlkSize)
   {
      /* Get the map to the mapping table */
      idx = ((*size - 1) >> regCb->bktQnPwr);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (regCb->mapTbl[idx].bktIdx == 0xFF)
      { 
         /* Some fatal error in the map table initialization. */
         RETVALUE(RFAILED);
      }
#endif

      /* Dequeue the memory block and return it to the user */
      bkt = &(regCb->bktTbl[regCb->mapTbl[idx].bktIdx]); 

      /* While loop is introduced to use the "break statement inside */
      while (1)
      {
         /*
          * Check if the size request is not greater than the size available
          * in the bucket
          */
         if (*size > bkt->size)
         {
            /* Try to go to the next bucket if available */
            if((idx < (CMM_MAX_MAP_ENT - 1)) &&
               (regCb->mapTbl[++idx].bktIdx != 0xFF))
            {
               bkt = &(regCb->bktTbl[regCb->mapTbl[idx].bktIdx]);
            }
            else
            {
               /* This is the last bucket, try to allocate from heap */
               break;
            }
         }

         /* Acquire the bucket lock */
         (Void) SLock(&(bkt->bktLock));

#if (ERRCLASS & ERRCLS_DEBUG)
         regCb->mapTbl[idx].numReq++;
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         if ((*ptr = bkt->next))
         {
            bkt->next = *((CmMmEntry **)(bkt->next));

            /* 
             * Increment the statistics variable of number of memory block 
             * allocated 
             */
            bkt->numAlloc++;
#ifdef SSI_MEM_DEBUG	/* xingzhou.xu: added for debug statistics --07/10/2006 */
            (bkt->maxAlloc < bkt->numAlloc) ? bkt->maxAlloc = bkt->numAlloc : 
				                              bkt->maxAlloc;
#endif

            /* Update the size parameter */
            *size = bkt->size;

            /* Release the lock */
            (Void) SUnlock(&(bkt->bktLock));

            RETVALUE(ROK);
         }

#if (ERRCLASS & ERRCLS_DEBUG)
         regCb->mapTbl[idx].numFailure++;
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         /* Release the lock */
         (Void) SUnlock(&(bkt->bktLock));
         break;
      }
   }

   /* Memory not available in the bucket pool */
   if (regCb->heapFlag &&  (*size < regCb->heapSize))
   {
      /* 
       * The heap memory block is available. Allocate the memory block from
       * heap pool.
       */ 
       RETVALUE(cmHeapAlloc(&(regCb->heapCb), ptr, size));
   }

   /* No memory available */
   RETVALUE(RFAILED);
#endif

#ifdef SSI_XOS_MEM 

    *ptr = XOS_MemMalloc(FID_PROTOCL, (XU32)(*size));
    if(*ptr) 
    RETVALUE(ROK);
    else
    RETVALUE(RFAILED);

else/* use pure is on */
   *ptr = (Data*) malloc(*size);
   if ( (*ptr) == NULLP)
       RETVALUE(RFAILED);
   avail_size -= *size;
   RETVALUE(ROK);
#endif /* USE_PURE */

} /* end of cmAlloc */


/*
*
*       Fun:   cmFree
*
*       Desc:  Return the memory block for the memory region.
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: The user calls this function to return the previously allocated 
*              memory block to the memory region. The memory manager does not 
*              check the validity of the state of the memory block(like whether 
*              it was allocated earlier). The caller must be sure that, the 
*              address specified in the parameter 'ptr' is valid and was 
*              allocated previously from same region.
*
*
*       File:  cm_mem.c
*
*/

#ifdef ANSI
PRIVATE S16  cmFree
(
Void   *regionCb,
Data   *ptr, 
Size    size
)
#else
PRIVATE S16  cmFree(regionCb, ptr, size)
Void   *regionCb;
Data   *ptr;
Size    size;
#endif
{
   U16        idx;
   CmMmBkt   *bkt;
   CmMmRegCb *regCb;

   TRC2(cmFree);

   regCb = (CmMmRegCb *)regionCb;

#if(!defined( USE_PURE)&&!defined(XOS_SSI_MEM))
#if (ERRCLASS & ERRCLS_INT_PAR)

   /* error check on parameters */
   if ((regCb == NULLP) || (!size) || (ptr == NULLP))
   {
      RETVALUE(RFAILED);
   }

   /* Check if the memory block is from the memory region */
   if (ptr >= ((CmMmRegCb *)regCb)->regInfo.start +
               ((CmMmRegCb *)regCb)->regInfo.size) 
   {
      RETVALUE(RFAILED);
   }

#endif

   /* 
    * Check if the memory block was allocated from the bucket pool. 
    */

   if (ptr < (regCb->regInfo.start + regCb->bktSize))
   {
      /* The memory block was allocated from the bucket pool */

      /* Get the map to the mapping table */
      idx = ((size - 1) >> regCb->bktQnPwr);

#if (ERRCLASS & ERRCLS_DEBUG)
      if (regCb->mapTbl[idx].bktIdx == 0xFF)
      { 
         /* Some fatal error in the map table initialization. */
         RETVALUE(RFAILED);
      }
#endif

      /* Enqueue the memory block and return it to the user */
      bkt = &(regCb->bktTbl[regCb->mapTbl[idx].bktIdx]); 

      /*
       * Check if the size is not greater than the size available
       * in the bucket. If so, then the buffer must have been allocated
       * from next bucket.  We don't need to check the validity of the
       * next bucket, otherwise buffer must have been allocated from heap
       * pool.
       */
       if (size > bkt->size)
       {
          bkt = &(regCb->bktTbl[regCb->mapTbl[++idx].bktIdx]);
       }

      /* Acquire the bucket lock */
      (Void) SLock(&(bkt->bktLock));

      *((CmMmEntry **)ptr) =  bkt->next; 
      bkt->next = (CmMmEntry *)ptr;

      /* 
      * Decrement the statistics variable of number of memory block 
      * allocated 
      */
      bkt->numAlloc--;

      /* Release the lock */
      (Void) SUnlock(&(bkt->bktLock));

      RETVALUE(ROK);
   }

   /* The memory block was allocated from the heap pool */ 
   RETVALUE(cmHeapFree (&(regCb->heapCb), ptr, size));
#endif

#ifdef SSI_XOS_MEM


#else /* use pure is on */
   TRC2(cmFree);
   (Void)free(ptr);
   avail_size += size;
   RETVALUE(ROK);
#endif /* USE_PURE */


} /* end of cmFree */



/*
*
*       Fun:   cmCtl
*
*       Desc:  Control request function. 
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: The current semantics of the control function is defined for two 
*              types of events: virtual address to physical address translation 
*              and memory resource check. 
*
*              The physical address translation is valid only for the memory 
*              region physically contiguous and non pagable.
*
*
*
*       File:  cm_mem.c
*
*/

#ifdef ANSI
PRIVATE S16  cmCtl
(
Void    *regionCb,
Event    event, 
SMemCtl *memCtl
)
#else
PRIVATE S16  cmCtl(regionCb, event, memCtl)
Void    *regionCb;
Event    event;
SMemCtl *memCtl;
#endif
{
   CmMmRegCb *regCb;

   TRC2(cmCtl);

   regCb = (CmMmRegCb *)regionCb;

#if (ERRCLASS & ERRCLS_INT_PAR)

   /* error check on parameters */
   if ((regCb == NULLP) || (memCtl == NULLP))
   {
      RETVALUE(RFAILED);
   }

#endif

   switch (event)
   {
      case SS_MEM_V_TO_P:
      {
         Size       offset;
  
#if (ERRCLASS & ERRCLS_INT_PAR)
         if ((memCtl->u.vtop.vaddr == NULLP) || 
             (memCtl->u.vtop.paddr == NULLP))
         {
            RETVALUE(RFAILED);
         }
#endif
   
         /* Check if the virtual to physical address translation is valid */
         if (regCb->chFlag & CMM_REG_PHY_VALID) 
         {
            offset = memCtl->u.vtop.vaddr - regCb->regInfo.start;
            *(memCtl->u.vtop.paddr) = regCb->pAddr + offset;
   
            RETVALUE(ROK);
         }
         break;
      }

      case SS_MEM_CHK_RES:
      {

#if (ERRCLASS & ERRCLS_INT_PAR)
         if (!(memCtl->u.chkres.size) || 
            (memCtl->u.chkres.status == NULLP))
         {
            RETVALUE(RFAILED);
         }
#endif
#if(!defined( USE_PURE)&&!defined(XOS_SSI_MEM))
         /* Check if the Bucket pool is configured */
         if (regCb->bktSize)
         {
            U16        idx;
            CmMmBkt   *bkt;
            U32        avlSize, totSize;
            /* 
             * The bucket pool is configured. The status value returned
             * does reflect on the memory availabilty in the bucket pool. 
             * The value does not consider the available memory in the
             * heap pool. 
             */
             idx = ((memCtl->u.chkres.size - 1) >> regCb->bktQnPwr);
             bkt = &(regCb->bktTbl[regCb->mapTbl[idx].bktIdx]); 
             avlSize = (bkt->numBlks - bkt->numAlloc) * bkt->size;
             avlSize += regCb->heapCb.avlSize;
             totSize = (bkt->numBlks * bkt->size) + regCb->heapSize;
             *(memCtl->u.chkres.status) = (avlSize/(totSize/10)); 
         }
         else
         {
            /* Bucket pool not configured */

            /* 
             * Find the percentage memory available in the heap pool. The value
             * does not consider the fragmentation of the heap pool.
             */
            *(memCtl->u.chkres.status) = ((regCb->heapCb.avlSize) /
                                          (regCb->heapSize/10)); 
         }

         RETVALUE(ROK);
#endif		 

#ifdef SSI_XOS_MEM


		 
#else /* use pure is on */
            *(memCtl->u.chkres.status) = ((avail_size) /
                                          (regCb->regInfo.size/10));
         RETVALUE(ROK);
#endif /* USE_PURE */

      }

      default:
      {
         /* No other event is supported currently */
         RETVALUE(RFAILED);
      }
   }

   /* shouldn't reach here */
   RETVALUE(RFAILED);
} /* end of cmCtl */


/*
*
*       Fun:   cmMmBktInit
*
*       Desc:  Initialize the bucket and the map table.
*
*
*       Ret:   ROK     - successful, 
*              RFAILED - unsuccessful.
*
*       Notes: This function is called by the cmMmRegInit. 
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PRIVATE Void cmMmBktInit
(
Data      **memAddr,
CmMmRegCb  *regCb,
CmMmRegCfg *cfg,
U16         bktIdx,
U16        *lstMapIdx
)
#else
PRIVATE Void cmMmBktInit (memAddr, regCb, cfg, bktIdx, lstMapIdx)
Data      **memAddr;
CmMmRegCb  *regCb;
CmMmRegCfg *cfg;
U16         bktIdx;
U16        *lstMapIdx;
#endif
{
   U32   cnt;
   U16   idx;
   U32   numBlks;
   Size  size;
   Data **next;

   TRC2(cmMmBktInit);


   size = cfg->bktCfg[bktIdx].size; 
   numBlks = cfg->bktCfg[bktIdx].numBlks; 

   /* Reset the next pointer */
   regCb->bktTbl[bktIdx].next = NULLP; 

   /* Initialize the link list of the memory block */
   next = &(regCb->bktTbl[bktIdx].next); 
   for (cnt = 0; cnt < numBlks; cnt++)
   {
      *next     = *memAddr;
      next      = (CmMmEntry **)(*memAddr);
      *memAddr  = (*memAddr) + size;
   }
   *next = NULLP;

   /* Initialize the Map entry */
   idx = size / cfg->bktQnSize;

   /* 
    * Check if the size is multiple of quantum size. If not we need to initialize
    * one more map table entry.
    */ 
   if(size % cfg->bktQnSize)
   {
      idx++;
   }
   
   while ( *lstMapIdx < idx)
   {
      regCb->mapTbl[*lstMapIdx].bktIdx = bktIdx;

#if (ERRCLASS & ERRCLS_DEBUG)
      regCb->mapTbl[*lstMapIdx].numReq     = 0;
      regCb->mapTbl[*lstMapIdx].numFailure = 0;
#endif

      (*lstMapIdx)++;
   } 

   /* Initialize the bucket structure */
   regCb->bktTbl[bktIdx].size     = size; 
   regCb->bktTbl[bktIdx].numBlks  = numBlks; 
   regCb->bktTbl[bktIdx].numAlloc = 0;

   /* Update the total bucket size */
   regCb->bktSize += (size * numBlks); 

   RETVOID;
} /* end of cmMmBktInit */


/*
*
*       Fun:   cmMmHeapInit
*
*       Desc:  Initialize the heap pool. 
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: This function is called by the cmMmRegInit. 
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PRIVATE Void  cmMmHeapInit 
(
Data        *memAddr,
CmMmHeapCb  *heapCb,
Size         size 
)
#else
PRIVATE Void  cmMmHeapInit (memAddr, heapCb, size)
Data        *memAddr;
CmMmHeapCb  *heapCb;
Size         size;
#endif
{
   TRC2(cmMmHeapInit);

   /* Initialize the heap control block */
   heapCb->vStart      = memAddr;
   heapCb->vEnd        = memAddr + size;
   heapCb->avlSize    = size; 
   heapCb->minSize    = CMM_MINBUFSIZE; 

   heapCb->next       = (CmHEntry *)memAddr;
   heapCb->next->next = NULLP;
   heapCb->next->size = size; 

#if (ERRCLASS & ERRCLS_DEBUG)
   heapCb->numFragBlk  = 0;
   heapCb->numReq      = 0;
   heapCb->numFailure  = 0;
#endif


   RETVOID;

} /* end of cmMmHeapInit */


/*
*
*       Fun:   cmHeapAlloc
*
*       Desc:  Allocates the memory block from the heap pool. 
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: This function is called by the cmAlloc. cmAlloc calls this
*              function when there is no memory block available in the bucket 
*              and the  heap pool is configured.
*
*
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PRIVATE S16  cmHeapAlloc 
(
CmMmHeapCb  *heapCb,
Data       **ptr,
Size        *size 
)
#else
PRIVATE S16  cmHeapAlloc (heapCb, ptr, size)
CmMmHeapCb  *heapCb;
Data       **ptr;
Size        *size;
#endif
{
   CmHEntry  *prvHBlk;    /* Previous heap block */
   CmHEntry  *curHBlk;    /* Current heap block */ 
   Size       tmpSize;

   TRC2(cmHeapAlloc);

   /* Roundup the requested size */
   *size = CMM_DATALIGN(*size, (heapCb->minSize));
   
   /* Check if the available total size is adequate. */
   if ((*size) >= heapCb->avlSize)
   {
      RETVALUE(ROUTRES);
   }

   /* Acquire the heap lock */
   (Void) SLock (&(heapCb->heapLock));

   /* 
    * Search through the heap block list in the heap pool of size 
    * greater than or equal to the requested size.
    *
    */ 
   prvHBlk = (CmHEntry *)&(heapCb->next);
   for (curHBlk = prvHBlk->next; curHBlk; curHBlk = curHBlk->next,
                                                   prvHBlk = prvHBlk->next)
   {
      /*
       * Since the size of the block is always multiple of CMM_MINBUFSIZE 
       * and the requested size is rounded to the size multiple of
       * CMM_MINBUFSIZE, the difference between the size of the heap block
       * and the size to allocate will be either zero or multiple of
       * CMM_MINBUFSIZE. 
       */
      if ((*size) <= curHBlk->size) 
      {
         if ((tmpSize = (curHBlk->size - (*size))))
         {
            /* Heap block of bigger size */
            *ptr = (Data *)curHBlk + tmpSize;             
             curHBlk->size = tmpSize;
         } 
         else
         {
            /* Heap block is same size of the requested size */
            *ptr = (Data *)curHBlk;
             prvHBlk->next = curHBlk->next;
         }
         heapCb->avlSize -= (*size); 

         /* Release the lock */
         (Void) SUnlock (&(heapCb->heapLock));

         RETVALUE(ROK);
      }
   }

   /* Release the lock */
   (Void) SUnlock (&(heapCb->heapLock));

   RETVALUE(ROUTRES);

} /* end of cmHeapAlloc */


/*
*
*       Fun:   cmHeapFree
*
*       Desc:  Return the memory block from the heap pool. 
*
*
*       Ret:   ROK     - successful
*              RFAILED - unsuccessful.
*
*       Notes: This function returns the memory block to the heap  pool. This 
*              function is called by cmFree. The function does not check the 
*              validity of the memory block. The caller must be sure that the 
*              block was previously allocated and belongs to the heap pool. The 
*              function maintain the sorting order of the memory block on the
*              starting address of the block. This function also do compaction 
*              if the neighbouring blocks are already in the heap. 
*
*
*
*       File:  cm_mem.c
*
*/
#ifdef ANSI
PRIVATE S16  cmHeapFree 
(
CmMmHeapCb  *heapCb,
Data        *ptr,
Size         size 
)
#else
PRIVATE S16  cmHeapFree (heapCb, ptr, size)
CmMmHeapCb  *heapCb;
Data        *ptr;
Size         size;
#endif
{
   CmHEntry  *p;    
   CmHEntry  *curHBlk;    /* Current heap block */ 

   TRC2(cmHeapFree);

   /* Roundup the requested size */
   size = CMM_DATALIGN(size, (heapCb->minSize));

   /* increase the avlSize */
   heapCb->avlSize += size;
   
   p = (CmHEntry *)ptr; 

   /* Acquire the heap lock */
   (Void) SLock (&(heapCb->heapLock));

   for ( curHBlk = heapCb->next; curHBlk; curHBlk = curHBlk->next)
   {
      /* 
       * The block will be inserted to maintain the sorted order on the
       * starting address of the block.
       */
      if (p > curHBlk)
      {
         if (!(curHBlk->next) || 
             (p < (curHBlk->next)))
         {
            /* Heap block should be inserted here */

            /* 
             * Check if the block to be returned can be merged with the
             * current block.
             */
             if (((Data *)curHBlk + curHBlk->size) == (Data *)p)
             {
                 /* Merge the block */
                  size = (curHBlk->size += size);
                  p = curHBlk;
             }
             else
             {
                /* insert the block */
                p->next = curHBlk->next;
                p->size = size; 
                curHBlk->next = p;
             }

            /* Try to merge with the next block in the chain */
            if (((Data *)p + size) == (Data *)(p->next))
            {
               /* p->next can not be NULL */
               p->size += p->next->size; 
               p->next  = p->next->next;
            }

            /* Release the lock */
            (Void) SUnlock (&(heapCb->heapLock));
             
            RETVALUE(ROK);
         }
      }
      else if (p < curHBlk)
      {
         /*
         * Check if the block to be returned can be merged with the
         * current block.
         */
         if (((Data *)p + size) == (Data *)curHBlk)
         {
            /* Merge the block */
            p->size = size + curHBlk->size;
            p->next = curHBlk->next;
         }
         else
         {
            /* insert the block */
            p->next = curHBlk;
            p->size = size;
         }

         heapCb->next = p;

         /* Release the lock */
         (Void) SUnlock (&(heapCb->heapLock));

         RETVALUE(ROK);
      }

   }

   if (heapCb->next == NULLP)
   {
      /* Heap block is empty. Insert the block in the head. */
      heapCb->next = p;
      p->next = NULLP;
      p->size = size;

      /* Release the heap lock */
      (Void) SUnlock (&(heapCb->heapLock));

      RETVALUE(ROK);
   }

   /* Release the lock */
   (Void) SUnlock (&(heapCb->heapLock));

   RETVALUE(RFAILED);
} /* end of cmHeapFree */


/********************************************************************30**
 
         End of file:     cm_mem.c@@/main/10 - Thu Dec  6 14:11:30 2001
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/

/********************************************************************90**
 
    ver       pat    init                  description
------------ -------- ---- -----------------------------------------------
1.1          ---      rm   1. initial release

1.2          ---      kr   1. Fixed a bug in function cmMmRegInit
             ---      kp   2. Fixed miscellaneous GCC compile warnings
             ---      kp   3. Bug fix in cmHeapFree

1.3          ---      rm   1. Implement separate locks for each configured
                              bucket.

1.4          ---      ada  1. Removed chksrc generated error

1.5          ---      ada  1. Bug fix in cmAlloc

             ---      ada  2. In cmCtl, corrected resource check in heap
                              to return available memory
             ---      ada  3. In cmMmRegInit, only allow bucket size to
                              be a multiple of quantumn size
1.6          ---      dvs  1. updated copyright
1.7          ---      bbk  1. Fixed bug in for loop in cmHeapAlloc
/main/9      ---      jjn  1. Initialize regInfo->flag in cmMmRegInit
                           2. cmCtl has been modified for the memory
                              resource status to indicate the available
                              bucket memory of the requested size plus the
                              heap.
                           3. The cmHeapFree was not freeing memory
                              for the case after all memory is allocated
                           4. cmAlloc, cmFree and cmCtl have been mapped
                              to use malloc and free if USE_PURE is defined.
                              This is to run memory leak detection tool.
/main/10     ---      bdu  1. Changes have been made in order to support
                              huge memory allocation.
                           2. Modify the cmHeapFree to merge the memory
                              block correctly.
*********************************************************************91*/

 
