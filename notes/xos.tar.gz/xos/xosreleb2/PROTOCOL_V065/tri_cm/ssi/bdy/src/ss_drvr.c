/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
 
     Name:     System Services -- Driver
 
     Type:     C source file
 
     Desc:     Source code for those functions in System Services
               that exist for driver support.
 
     File:     ss_drvr.c
 
     Sid:      ss_drvr.c 1.2  -  08/11/98 10:46:54
 
     Prg:      kp
  
*********************************************************************21*/



/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */


#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */


#ifdef SS_DRVR_SUPPORT



/*
*
*       Fun:   SRegDrvrTsk
*
*       Desc:  This function is used to register a driver task.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*              ROUTRES  - failed, out of resources (optional)
*
*       Notes:
*
*       File:  ss_drvr.c
*
*/
#ifdef ANSI
PUBLIC S16 SRegDrvrTsk
(
Inst channel,                   /* channel instance */
ProcId low,                     /* processor ID -- low */
ProcId high,                    /* processor ID -- high */
ActvTsk actvTsk,                /* activation function */
ISTsk isTsk                     /* interrupt service function */
)
#else
PUBLIC S16 SRegDrvrTsk(channel, low, high, actvTsk, isTsk)
Inst channel;                   /* channel instance */
ProcId low;                     /* processor ID -- low */
ProcId high;                    /* processor ID -- high */
ActvTsk actvTsk;                /* activation function */
ISTsk isTsk;                    /* interrupt service function */
#endif
{
   S16 ret;
#if (ERRCLASS & ERRCLS_INT_PAR)

/* ss029.103: modification: multiple procId related changes */ 
#ifndef SS_MULTIPLE_PROCS
   ProcId thisProcId;
#endif

/* ss029.103: modification: multiple procId related changes */ 
#ifdef SS_MULTIPLE_PROCS
   U16 count;
   U16 i;
   ProcId procIdLst[SS_MAX_PROCS];
#endif /* SS_MULTIPLE_PROCS */

#endif

   TRC1(SRegDrvrTsk);

#if (ERRCLASS & ERRCLS_INT_PAR)

/* ss029.103: modification: multiple procId related changes */ 
#ifdef SS_MULTIPLE_PROCS
   if (SGetProcIdLst(&count, procIdLst) != ROK)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS262, ERRZERO, "Null procId list");
      RETVALUE(RFAILED);
   }

   for (i = 0; i < count; i++)
   {
      if (procIdLst[i] >= low  &&  procIdLst[i] <= high)
      {
       SSLOGERROR(ERRCLS_INT_PAR, ESS263, ERRZERO, "Invalid procId range");
       RETVALUE(RFAILED);
      }
   }
#else /* SS_MULTIPLE_PROCS */
   thisProcId = SFndProcId();
   if (thisProcId >= low  &&  thisProcId <= high)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS264, ERRZERO, "Invalid procId range");
      RETVALUE(RFAILED);
   }
#endif /* SS_MULTIPLE_PROCS */

   if (channel >= SS_MAX_DRVRTSKS)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS265, channel, "Invalid channel");
      RETVALUE(RFAILED);
   }

   /* check activation functions */
   if (actvTsk == NULLP  ||  isTsk == NULLP)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS266, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }

   /* check if already registered */
   if (osCp.drvrTskTbl[channel].used == TRUE)
   {
      SSLOGERROR(ERRCLS_INT_PAR, ESS267, ERRZERO,
                  "Driver task already registered");
      RETVALUE(RFAILED);
   }
#endif


#if (ERRCLASS & ERRCLS_DEBUG)
   /* check count of tasks */
   if (osCp.numDrvrTsks == SS_MAX_DRVRTSKS)
   {
      SSLOGERROR(ERRCLS_DEBUG, ESS268, ERRZERO, "Too many tasks");
      RETVALUE(ROUTRES);
   }
#endif


   if (SInitLock(&osCp.drvrTskTbl[channel].lock, SS_DRVRENTRY_LOCK) != ROK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS269, ERRZERO, "Could not initialize lock");
#endif

      RETVALUE(RFAILED);
   }

   osCp.drvrTskTbl[channel].channel = channel;
   osCp.drvrTskTbl[channel].actvTsk = actvTsk;
   osCp.drvrTskTbl[channel].isTsk = isTsk;
   osCp.drvrTskTbl[channel].low = low;
   osCp.drvrTskTbl[channel].high = high;

   ret = ssdRegDrvrTsk(&osCp.drvrTskTbl[channel]);
   if (ret != ROK)
   {
      osCp.drvrTskTbl[channel].channel = 0;
      osCp.drvrTskTbl[channel].actvTsk = NULLP;
      osCp.drvrTskTbl[channel].isTsk = NULLP;
      osCp.drvrTskTbl[channel].low = 0;
      osCp.drvrTskTbl[channel].high = 0;
      SDestroyLock(&osCp.drvrTskTbl[channel].lock);
   }
   else
   {
      osCp.drvrTskTbl[channel].used = TRUE;
      osCp.numDrvrTsks++;
   }


   RETVALUE(ret);
}


#endif /* SS_DRVR_SUPPORT */
 


/********************************************************************30**
  
         End of file: ss_drvr.c 1.2  -  08/11/98 10:46:54
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. initial release

1.2          ---      kp   1. cosmetic changes, error codes regenerated
1.2+        ss029.103 kkj  1. Multiple proc ids support added
*********************************************************************91*/
