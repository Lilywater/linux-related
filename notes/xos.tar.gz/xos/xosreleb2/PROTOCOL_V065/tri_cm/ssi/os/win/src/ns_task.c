/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     Windows NT - System Services 

     Type:     C Source Code 

     Desc:     Task Management

     File:     np_task.c

     Sid:      np_task.c 1.2  -  08/17/98 11:56:40

     Prg:      ag

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */


#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */


/* Extern variables */

/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

/* public variable declarations */

/* private variable declarations */


/*
*
*       Fun : sspthreadAttrInit
*
*       Desc: Initialize thread attribute object
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ENOMEM   - no memory available
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrInit
(
SspthreadAttr *attr                    /* thread attribute obejct */
)
#else
PUBLIC S32   sspthreadAttrInit(attr)
SspthreadAttr *attr;                   /* thread attribute obejct */
#endif
{
   S32           ret;
   SchedParam    param;
   Size          size;

   TRC0(sspthreadAttrInit)

   if (attr->sspthreadAttrp == NULLP)
   {
      size = sizeof(ThreadAttr);
      if (SAlloc(SS_DFLT_REGION, &size,0,  \
                          (Data **)&attr->sspthreadAttrp) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS072, ERRZERO,
                                    "Could not thread attr object memory");
#endif
         RETVALUE(ENOMEM);
      }
   }

   ret = sspthreadAttrSetScope(attr, PTHREAD_SCOPE_SYSTEM);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS073, (ErrVal)ret ,
                                "Could not set scope for thread attr object");
#endif
      RETVALUE(ret);
   }

   ret = sspthreadAttrSetDetachState(attr, PTHREAD_CREATE_JOINABLE);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS074, (ErrVal)ret, 
                      "Could not set Detach State for thread attr object");
#endif
      RETVALUE(ret);
   }

#ifdef _POSIX_THREAD_ATTR_STACKADDR
   ret = sspthreadAttrSetStackAddr(attr, NULL);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS075, (ErrVal)ret, 
                     "Could not set stack address for thread attr object");
#endif
      RETVALUE(ret);
   }
#endif

#ifdef _POSIX_THREAD_ATTR_STACKSIZE
   ret = sspthreadAttrSetStackSize(attr, NULL);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS076, (ErrVal)ret, 
                      "Could not set stack size for thread attr object");
#endif
      RETVALUE(ret);
   }
#endif

   ret = sspthreadAttrSetSchedPolicy(attr, SCHED_OTHER);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS077, (ErrVal)ret, 
                            "Could not set sched policy for thread attr object");
#endif
      RETVALUE(ret);
   }

   param.schedPrior = NS_DFLT_PRIOR;

   ret = sspthreadAttrSetSchedParam(attr, &param);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS078, (ErrVal)ret, 
                            "Could not set sched param for thread attr object");
#endif
      RETVALUE(ret);
   }

   ret =  sspthreadAttrSetInheritSched(attr, PTHREAD_EXPLICIT_SCHED); 
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS079, (ErrVal)ret, 
                        "Could not set inherit sched for thread attr object");
#endif
      RETVALUE(ret);
   }

   RETVALUE(ROK);

} /* end of sspthreadAttrInit */


/*
*
*       Fun : sspthreadAttrDestroy
*
*       Desc: Destroy the thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrDestroy
(
SspthreadAttr *attr             /* thread attribute obejct */
)
#else
PUBLIC S32   sspthreadAttrDestroy(attr)
SspthreadAttr *attr;            /* thread attribute obejct */
#endif
{
   TRC0(sspthreadAttrDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS080, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   
   SFree(SS_DFLT_REGION, (U8*) attr->sspthreadAttrp, sizeof(ThreadAttr));

   attr->sspthreadAttrp = NULLP;

   RETVALUE(ROK);
} /* end of sspthreadAttrDestroy */



#ifdef _POSIX_THREAD_ATTR_STACKSIZE
/*
*
*       Fun : sspthreadAttrSetStackSize
*
*       Desc: set stack size in thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetStackSize
(
SspthreadAttr *attr,                   /* thread attribute object */
Size          stacksize                /* stack size */
)
#else
PUBLIC S32   sspthreadAttrSetStackSize(attr, stacksize)
SspthreadAttr *attr;                   /* thread attribute object */
Size          stacksize;               /* stack size */
#endif
{
   TRC0(sspthreadAttrSetStackSize)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || stacksize < PTHREAD_STACK_MIN)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS081, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   
   attr->sspthreadAttrp->stackSize = stacksize;

   RETVALUE(ROK);
} /* end of sspthreadAttrSetStackSize */


/*
*
*       Fun : sspthreadAttrGetStackSize
*
*       Desc: Get the stacksize from thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetStackSize
(
SspthreadAttr *attr,                  /* thread attribute object */
Size          *stacksize              /* stacksize */
)
#else
PUBLIC S32   sspthreadAttrGetStackSize(attr, stacksize)
SspthreadAttr *attr;                  /* thread attribute object */
Size          *stacksize;             /* stacksize */
#endif
{
   TRC0(sspthreadAttrGetStackSize)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || attr->stacksize < PTHREAD_STACK_MIN)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS082, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   
   /* ns013.102 - Modification to fix bug */
   *stacksize = attr->sspthreadAttrp->stackSize;

   RETVALUE(ROK);
} /* end of sspthreadAttrGetStackSize */
#endif /* _POSIX_THREAD_ATTR_STACKSIZE */



#ifdef  _POSIX_THREAD_ATTR_STACKADDR 
/*
*
*       Fun : sspthreadAttrSetStackAddr
*
*       Desc: Set stackaddress in thread attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetStackAddr
(
SspthreadAttr *attr,                  /* thread attribute object */
VOID          *stackaddr              /* stack address */
)
#else
PUBLIC S32   sspthreadAttrSetStackAddr(attr, stackaddr)
SspthreadAttr *attr;                  /* thread attribute object */
VOID          *stackaddr;             /* stack address */
#endif
{
   TRC0(sspthreadAttrSetStackAddr)

   RETVALUE(ENOTSUP);

} /* end of spthreadAttrSetStackAddr */


/*
*
*       Fun : sspthreadAttrGetStackAddr
*
*       Desc: Get the stack addresss from thread attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetStackAddr
(
SspthreadAttr *attr;                  /* thread attribute object */
VOID          **stackaddr;            /* stack address */
)
#else
PUBLIC S32   sspthreadAttrGetStackAddr(attr, stackaddr)
SspthreadAttr *attr;                  /* thread attribute object */
VOID          **stackaddr;            /* stack address */
#endif
{
   TRC0(sspthreadAttrGetStackAddr)

   RETVAL(ENOTSUP)

} /* end of sspthreadAttrGetStackAddr */
#endif /* _POSIX_THREAD_ATTR_STACKADDR */


/*
*
*       Fun : sspthreadAttrSetDetachState
*
*       Desc: Set the detach state in attribute object of thread
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetDetachState
(
SspthreadAttr *attr,                    /* thread attribute object */
S32           detachstate               /* detach state */
)
#else
PUBLIC S32   sspthreadAttrSetDetachState(attr, detachstate)
SspthreadAttr *attr;                    /* thread attribute object */
S32           detachstate;              /* detach state */
#endif
{
   TRC0(sspthreadAttrSetDetachState)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP  ||
       ( detachstate != PTHREAD_CREATE_DETACHED
      && detachstate != PTHREAD_CREATE_JOINABLE))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS083, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   ((ThreadAttr *)(attr->sspthreadAttrp))->detachState = detachstate;
 
   RETVALUE(ROK);
} /* end of sspthreadAttrSetDetachState */


/*
*
*       Fun : sspthreadAttrGetDetachState
*
*       Desc: Get the detach state from attribute object of thread
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32    sspthreadAttrGetDetachState
(
SspthreadAttr *attr,                    /* thread attribute object */
S32           *detachstate              /* detach state */
)
#else
PUBLIC S32    sspthreadAttrGetDetachState(attr, detachstate)
SspthreadAttr *attr;                    /* thread attribute object */
S32           *detachstate;             /* detach state */
#endif
{
   TRC0(sspthreadAttrGetDetachState)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS084, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   *detachstate = ((ThreadAttr *)(attr->sspthreadAttrp))->detachState;
 
   if ((*detachstate != PTHREAD_CREATE_DETACHED)
       || (*detachstate != PTHREAD_CREATE_JOINABLE))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS085, ERRZERO,
                            "Invalid Detach State");
#endif
      RETVALUE(EINVAL);
   }
  
   RETVALUE(ROK);
} /* end of sspthreadAttrGetDetachState */


/*
*
*       Fun : sspthreadAttrSetScope
*
*       Desc: Set the scope value in thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetScope
(
SspthreadAttr *attr,              /* thread attribute object */
S32           scope               /* scope */
)
#else
PUBLIC S32   sspthreadAttrSetScope(attr, scope)
SspthreadAttr *attr;              /* thread attribute object */
S32           scope;              /* scope */
#endif
{
   TRC0(sspthreadAttrSetScope)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || scope != PTHREAD_SCOPE_SYSTEM)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS086, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   ((ThreadAttr *)(attr->sspthreadAttrp))->contentionScope = scope;

   RETVALUE(ROK);
} /* end of sspthreadAttrSetScope */



/*
*
*       Fun : sspthreadAttrGetScope
*
*       Desc: Get the scope value from thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetScope
(
SspthreadAttr *attr,              /* thread attribute object */
S32           *scope              /* scope */
)
#else
PUBLIC S32   sspthreadAttrGetScope(attr, scope)
SspthreadAttr *attr;              /* thread attribute object */
S32           *scope;             /* scope */
#endif
{
   TRC0(sspthreadAttrGetScope)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || scope == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS087, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   *scope = ((ThreadAttr *)(attr->sspthreadAttrp))->contentionScope;
  
   RETVALUE(ROK);
} /* end of sspthreadAttrGetScope */


/*
*
*       Fun : sspthreadAttrSetInheritSched
*
*       Desc: Set Inherit Scheduling value in thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetInheritSched
(
SspthreadAttr *attr,                     /* thread attribute object */
S32           inheritsched               /* inherit scheduling param */
)
#else
PUBLIC S32   sspthreadAttrSetInheritSched(attr, inheritsched)
SspthreadAttr *attr;                     /* thread attribute object */
S32           inheritsched;              /* inherit scheduling param */
#endif
{
   TRC0(sspthreadAttrSetInheritSched)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS088, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
   if (inheritsched != PTHREAD_EXPLICIT_SCHED)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS089, ERRZERO, "Null pointer");
      RETVALUE(ENOTSUP);
   }
#endif
  
   ((ThreadAttr *)(attr->sspthreadAttrp))->inheritSched = inheritsched;
    
   RETVALUE(ROK);
} /* end of sspthreadAttrSetInheritSched */



/*
*
*       Fun : sspthreadAttrGetInheritSched
*
*       Desc: Get Inherit Scheduling value from thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetInheritSched
(
SspthreadAttr *attr,                     /* thread attribute object */
S32           *inheritsched              /* inherit scheduling param */
)
#else
PUBLIC S32   sspthreadAttrGetInheritSched(attr, inheritsched)
SspthreadAttr *attr;                     /* thread attribute object */
S32           *inheritsched;             /* inherit scheduling param */
#endif
{
   TRC0(sspthreadAttrGetInheritSched)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || inheritsched == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS090, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   *inheritsched = ((ThreadAttr *)(attr->sspthreadAttrp))->inheritSched;

   RETVALUE(ROK);
} /* end of sspthreadAttrGetInheritSched */


/*
*
*       Fun : sspthreadAttrSetSchedPolicy
*
*       Desc: Set the scheduling policy in the thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetSchedPolicy
(
SspthreadAttr *attr,                    /* thread attribute object */
S32           policy                    /* scheduling policy */
)
#else
PUBLIC S32   sspthreadAttrSetSchedPolicy(attr, policy)
SspthreadAttr *attr;                    /* thread attribute object */
S32           policy;                   /* scheduling policy */
#endif
{
   TRC0(sspthreadAttrSetSchedPolicy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS091, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
   if (policy != SCHED_OTHER)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS092, ERRZERO, "Null pointer");
      RETVALUE(ENOTSUP);
   }
#endif

   ((ThreadAttr *)(attr->sspthreadAttrp))->policy = policy;

   RETVALUE(ROK);
} /* end of sspthreadAttrSetSchedPolicy */



/*
*
*       Fun : sspthreadAttrGetSchedPolicy
*
*       Desc: Get the scheduling policy from the thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetSchedPolicy
(
SspthreadAttr *attr,                    /* thread attribute object */
S32           *policy                   /* scheduling policy */
)
#else
PUBLIC S32   sspthreadAttrGetSchedPolicy(attr, policy)
SspthreadAttr *attr;                    /* thread attribute object */
S32           *policy;                  /* scheduling policy */
#endif
{
   ThreadAttr *a;

   TRC0(sspthreadAttrGetSchedPolicy)

   a = (ThreadAttr *)attr->sspthreadAttrp;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((a == NULLP) || (policy == NULLP) || (a->policy != SCHED_OTHER))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS093, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   *policy = a->policy;

   RETVALUE(ROK);
} /* end of sspthreadAttrGetSchedPolicy */


/*
*
*       Fun : sspthreadAttrSetSchedParam
*
*       Desc: Set Scheduling parameter in thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrSetSchedParam
(
SspthreadAttr *attr,                   /* thread attribute object */
SchedParam    *param                   /* scheduling parameter */
)
#else
PUBLIC S32   sspthreadAttrSetSchedParam(attr, param)
SspthreadAttr *attr;                   /* thread attribute object */
SchedParam    *param;                  /* scheduling parameter */
#endif
{
   TRC0(sspthreadAttrSetSchedParam)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || param == NULLP || param->schedPrior < 0)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS094, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   ((ThreadAttr *)(attr->sspthreadAttrp))->param.schedPrior = param->schedPrior;

   RETVALUE(ROK);
} /* end of sspthreadAttrSetSchedParam */


/*
*
*       Fun : sspthreadAttrGetSchedParam
*
*       Desc: Get Scheduling parameter from thread attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S32   sspthreadAttrGetSchedParam
(
SspthreadAttr *attr,                   /* thread attribute object */
SchedParam    *param                   /* scheduling parameter */
)
#else
PUBLIC S32   sspthreadAttrGetSchedParam(attr, param)
SspthreadAttr *attr;                   /* thread attribute object */
SchedParam    *param;                  /* scheduling parameter */
#endif
{
   ThreadAttr *a;

   TRC0(sspthreadAttrGetSchedParam)

   a = (ThreadAttr *)attr->sspthreadAttrp;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP || param== NULLP || (a->param.schedPrior <0))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS095, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif
   param->schedPrior = a->param.schedPrior;

   RETVALUE(ROK);
} /* end of sspthreadAttrGetSchedParam */



/* semantics of startRoutine are void *startRoutine(VOID *) */

/*
*
*       Fun : sspthreadCreate
*
*       Desc: Create a new thread of execution
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EAGAIN   - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCreate
(
Sspthread     *thread,                 /* thread */
SspthreadAttr *attr,                   /* thread attributes */
VOID*         (*startRoutine) (Void*), /* start routinee */
VOID          *arg                     /* start routine argument */
)
#else
PUBLIC  S32  sspthreadCreate(thread, attr, startRoutine, arg)
Sspthread     *thread;                 /* thread */
SspthreadAttr *attr;                   /* thread attributes */
VOID*         (*startRoutine) (Void*); /* start routinee */
VOID          *arg;                    /* start routine argument */
#endif
{
   U32   stacksize;
   U32   tId;
   U32   size;

   TRC0(sspthreadCreate)
      
   if (attr == NULLP)
   {
      size = sizeof(SspthreadAttr);
      if (SAlloc(SS_DFLT_REGION, &size, 0, (Data **)&attr) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS096, ERRZERO,
                                         "SAlloc Failed in sspthreadCreate");
#endif
         RETVALUE(RFAILED);
      }
      attr->sspthreadAttrp = NULLP;
      if (sspthreadAttrInit(attr) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
    
#ifdef _POSIX_THREAD_ATTR_STACKSIZE
   stacksize = ((ThreadAttr*)attr->sspthreadAttrp)->stackSize;
#else
   stacksize = NS_DFLT_STACK_SIZE;
#endif

   tId = 0;
   if ((nsCreateThread(&thread->thrdHandle,startRoutine, 
                                             arg,stacksize,tId) != ROK)
       || (thread->thrdHandle == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS097, (ErrVal)thread, 
                                         "Could not create system task");
#endif
      RETVALUE(EAGAIN);
   }

   thread->attr = attr;

   RETVALUE(ROK);
} /* end of sspthreadCreate */



/*
*
*       Fun : sspthreadEqual
*
*       Desc: compare the two threads if they are same
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadEqual
(
Sspthread     *thread1,                   /* 1st thread */
Sspthread     *thread2                    /* 2nd thread */
)
#else
PUBLIC  S32  sspthreadEqual(thread1, thread2)
Sspthread     *thread1;                   /* 1st thread */
Sspthread     *thread2;                   /* 2nd thread */
#endif
{
   TRC0(sspthreadEqual)

   if (thread1 == thread2
      && thread1->thrdHandle == thread2->thrdHandle)
   {
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of sspthreadEqual */



/*
*
*       Fun : sspthreadExit
*
*       Desc: Exit the thread
*
*       Ret : None
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  VOID  sspthreadExit
(
VOID         *valuePtr              /* thread exit status */
)
#else
PUBLIC  VOID  sspthreadExit(valuePtr)
VOID         *valuePtr;             /* thread exit status */
#endif
{
   TRC0(sspthreadExit)

   nsExitThread(*(U32 *)valuePtr);

} /* end of sspthreadExit */



/*
*
*       Fun : sspthreadJoin
*
*       Desc: Join other thread (wait for other thread to be terminated)
*
*       Ret:   ROK      - ok
*              ESRCH    - search failed
*              EDEADLK  - deadlock condition
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadJoin
(
Sspthread     *thread,           /* thread */
VOID         **valuePtr          /* return value */
)
#else
PUBLIC  S32  sspthreadJoin(thread, valuePtr)
Sspthread     *thread;           /* thread */
VOID         **valuePtr;         /* return value */
#endif
{
   TRC0(sspthreadJoin)

   if (thread == NULLP)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      NSLOGERROR(ERRCLS_INT_PAR, ENS098, ERRZERO, "Null pointer");
#endif
      RETVALUE(ESRCH);
   }

   if (thread->thrdHandle == nsGetCurrentThread())
   {   
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS099, ERRZERO, "Deadlock Detected");
#endif
      RETVALUE(EDEADLK);
   }
 
   nsThreadJoin(thread->thrdHandle, valuePtr); 

   RETVALUE(ROK);
} /* end of sspthreadJoin */


/*
*
*       Fun : sspthreadSelf
*
*       Desc: Return a pointer to thread itself
*
*       Ret : Pointer to thread
*             Null pointer - if the thread is not present
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC Sspthread *sspthreadSelf
(
VOID
)
#else
PUBLIC Sspthread *sspthreadSelf(VOID)
#endif
{
   TRC0(spthreadSelf)

   RETVALUE((Sspthread *)nsGetCurrentThread());

} /* end of sspthreadSelf */


/*
*
*       Fun : sspthreadGetSchedParam
*
*       Desc: Get the scheduling policy paramter
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ESRCH    - search failed
*              EINVAL   - invalid parameter 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32   sspthreadGetSchedParam
(
Sspthread     *thread,                /* thread */
S32           *policy,                /* sched policy */
SchedParam    *param                  /* sched policy param */
)
#else
PUBLIC  S32   sspthreadGetSchedParam(thread, policy, param)
Sspthread     *thread;                /* thread */
S32           *policy;                /* sched policy */
SchedParam    *param;                 /* sched policy param */
#endif
{
   TRC0(sspthreadGetSchedParam)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thread == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS100, ERRZERO, "Null pointer");
      RETVALUE(ESRCH);
   }

   if ((param == NULLP) || (*policy == INVALID_POLICY))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS101, ERRZERO, "INVALID");
      RETVALUE(EINVAL);
   }
#endif
   
   param->schedPrior = 
         ((ThreadAttr *)((SspthreadAttr *)(thread->attr))->
                                      sspthreadAttrp)->param.schedPrior;

   RETVALUE(ROK);
} /* end of sspthreadGetSchedParam */


/*
*
*       Fun : sspthreadSetSchedParam
*
*       Desc: Set Scheduling Parameter 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ESRCH    - search failed
*              EINVAL   - invalid parameter 
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32   sspthreadSetSchedParam
(
Sspthread      *thread,          /* thread */
S32            policy,           /* sched policy */
SchedParam     *param            /* sched policy parameter */
)
#else
PUBLIC  S32   sspthreadSetSchedParam(thread, policy, param)
Sspthread      *thread;          /* thread */
S32            policy;           /* sched policy */
SchedParam     *param;           /* sched policy parameter */
#endif
{
   /* ns016 - Modification for Windows CE Support */
#ifndef SS_WINCE
   S8    wPrior;
#else /* SS_WINCE */
   S16    wPrior;
#endif /* SS_WINCE */

   TRC0(sspthreadSetSchedParam)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thread == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS102, ERRZERO, "Null pointer");
      RETVALUE(ESRCH);
   }

   if (param == NULLP || policy == INVALID_POLICY)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS103, ERRZERO, "Invalid Policy");
      RETVALUE(EINVAL);
   }
   if (policy == SCHED_RR || policy == SCHED_FIFO)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS104, ERRZERO, "INVALID");
      RETVALUE(ENOTSUP);
   }
#endif

   ((ThreadAttr *)((SspthreadAttr *)(thread->attr))->sspthreadAttrp)
              ->param.schedPrior = param->schedPrior;

   /* Do a priority mapping for windows NT */
   wPrior = osCp.dep.wPriorLookup[param->schedPrior];

   if (nsSetThreadPriority(&thread->thrdHandle, wPrior) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS105, (ErrVal)wPrior, 
                                 "Could not set thread priority");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of sspthreadSetSchedParam */


/*
*
*       Fun : sspthreadSchedYield
*
*       Desc: Yield to some other ready-to-run thread
*
*       Ret :  none
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC VOID  sspthreadSchedYield
(
)
#else
PUBLIC VOID  sspthreadSchedYield(VOID)
#endif
{
   TRC0(sspthreadSchedYield)

   nsThreadYield();

} /* end of sspthreadSchedYield */



/*
*
*       Fun : sspthreadMutexAttrInit
*
*       Desc: Create a mutex attribute object
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ENOMEM   - no memory available
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrInit
(
SspthreadMutexAttr *attr                  /* mutex attribute */
)
#else
PUBLIC  S32  sspthreadMutexAttrInit(attr)
SspthreadMutexAttr *attr;                 /* mutex attribute */
#endif
{
#if (defined (_POSIX_THREAD_PRIO_PROTECT)||defined(_POSIX_THREAD_PROCESS_SHARED))
   S32     ret;
#endif

   Size    size;

   TRC0(sspthreadMutexAttrInit)

   if (attr->sspthreadMutexAttrp == NULLP)
   {
      size = sizeof(MutexAttr);
      if (SAlloc(SS_DFLT_REGION, &size,0,  \
                     (Data **)&attr->sspthreadMutexAttrp) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS106, ERRZERO, 
                         "Could not allocate memory for mutex attr object");
#endif
          RETVALUE(ENOMEM);
      }
   }

#ifdef _POSIX_THREAD_PROCESS_SHARED
   ret = sspthreadMutexAttrSetPshared(attr, SS_LOCK_MUTEX_PSHARED);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadMutexAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS107, (ErrVal)ret, 
                             "Could not set pshared for mutex attr object");
#endif
      RETVALUE(ret);
   }
#endif

#if ((defined _POSIX_THREAD_PRIO_PROTECT) && (defined _POSIX_THREAD_PRIOR_INHERIT))

   ret =  sspthreadMutexAttrSetPriorceiling(attr, priorceiling);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadMutexAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS108, (ErrVal)ret, 
                          "Could not set priorceiling for mutex attr object");
#endif
      RETVALUE(ret);
   }
   ret =  sspthreadMutexAttrSetProtocol(attr, protocol);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadMutexAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS109, (ErrVal)ret, 
                             "Could not set protocol for mutex attr object");
#endif
      RETVALUE(ret);
   }
#endif

   RETVALUE(ROK);

} /* end of sspthreadMutexAttrInit */



#ifdef _POSIX_THREAD_PROCESS_SHARED
/*
*
*       Fun : sspthreadMutexAttrSetPshared
*
*       Desc: Set the process shared value in mutex attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrSetPshared
(
SspthreadMutexAttr *attr,                 /* mutex attribute */
S32                pshared                /* process shared value */
)
#else
PUBLIC  S32  sspthreadMutexAttrSetPshared(attr, pshared)
SspthreadMutexAttr *attr;                 /* mutex attribute */
S32                pshared;               /* process shared value */
#endif
{
   TRC0(sspthreadMutexAttrSetPshared)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrSetPshared */


/*
*
*       Fun : sspthreadMutexAttrGetPshared
*
*       Desc: Get the process shared value from mutex attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrGetPshared
(
SspthreadMutexAttr *attr,                 /* mutex attribute */
S32                *pshared               /* process shared value */
)
#else
PUBLIC  S32  sspthreadMutexAttrGetPshared(attr, pshared)
SspthreadMutexAttr *attr;                 /* mutex attribute */
S32                *pshared;              /* process shared value */
#endif
{
   TRC0(sspthreadMutexAttrGetPshared)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrGetPshared */
#endif /* _POSIX_THREAD_PROCESS_SHARED */





#if defined (_POSIX_THREAD_PRIO_PROTECT) && defined (_POSIX_THREAD_PRIOR_INHERIT)
/*
*
*       Fun : sspthreadMutexAttrSetPriorceiling
*
*       Desc: Set the priority ceiling value in mutex attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrSetPriorceiling
(
SspthreadMutexAttr *attr,                 /* mutex attribute */
S32                 priorceiling          /* priority ceiling */
)
#else
PUBLIC  S32  sspthreadMutexAttrSetPriorceiling(attr, priorceiling)
SspthreadMutexAttr *attr;                 /* mutex attribute */
S32                 priorceiling;         /* priority ceiling */
#endif
{
   TRC0(sspthreadMutexAttrSetPriorceiling)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrSetPriorceiling */


/*
*
*       Fun : sspthreadMutexAttrGetPriorceiling
*
*       Desc: Get the priority ceiling value from mutex attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrGetPriorceiling
(
SspthreadMutexAttr *attr,                 /* mutex attribute */
S32                *priorceiling          /* priority ceiling */
)
#else
PUBLIC  S32  sspthreadMutexAttrGetPriorceiling(attr, priorceiling)
SspthreadMutexAttr *attr;                 /* mutex attribute */
S32                *priorceiling;         /* priority ceiling */
#endif
{
   TRC0(sspthreadMutexAttrGetPriorceiling)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrGetPriorceiling */


/*
*
*       Fun : sspthreadMutexAttrSetProtocol
*
*       Desc: Set the protocol value of mutex attribute object
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrSetProtocol
(
SspthreadMutexAttr *attr,                 /* mutex attribute */
S32                protocol               /* protocol */
)
#else
PUBLIC  S32  sspthreadMutexAttrSetProtocol(attr, protocol)
SspthreadMutexAttr *attr;                 /* mutex attribute */
S32                protocol;              /* protocol */
#endif
{
   TRC0(sspthreadMutexAttrSetProtocol)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrSetProtocol */


/*
*
*       Fun : sspthreadMutexAttrGetProtocol
*
*       Desc: Get the protocol value from mutex attributes
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrGetProtocol
(
SspthreadMutexAttr *attr,          /* mutex attributes */
S32                *protocol       /* protocol */
)
#else
PUBLIC  S32  sspthreadMutexAttrGetProtocol(attr, protocol)
SspthreadMutexAttr *attr;          /* mutex attributes */
S32                *protocol;      /* protocol */
#endif
{
   TRC0(sspthreadMutexAttrGetProtocol)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexAttrGetProtocol */
#endif



/*
*
*       Fun : sspthreadMutexAttrDestroy
*
*       Desc: Destroy the mutex attribute object
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexAttrDestroy
(
SspthreadMutexAttr *attr              /* mutex attribute */
)
#else
PUBLIC  S32  sspthreadMutexAttrDestroy(attr)
SspthreadMutexAttr *attr;             /* mutex attribute */
#endif
{
   TRC0(sspthreadMutexAttrDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS110, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   SFree(SS_DFLT_REGION, (U8*) attr->sspthreadMutexAttrp, sizeof(MutexAttr));

   attr->sspthreadMutexAttrp = NULLP;

   RETVALUE(ROK);

} /* end of sspthreadMutexAttrDestroy */



/* Mutex Manipulation functions */

#ifdef _POSIX_THREAD_PRIO_PROTECT
/*
*
*       Fun : sspthreadMutexGetpriorceiling
*
*       Desc: Get priority ceiling for the mutex
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes:  Not possible to support for Windows NT
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexGetpriorceiling
(
SspthreadMutex  *mutex,                    /* mutex */
S32             *priorceiling              /* priority ceiling */
)
#else
PUBLIC  S32  sspthreadMutexGetpriorceiling(mutex, priorceiling)
SspthreadMutex  *mutex;                    /* mutex */
S32             *priorceiling;             /* priority ceiling */
#endif
{
   TRC0(sspthreadMutexGetpriorceiling)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexGetpriorceiling */



/*
*
*       Fun : sspthreadMutexSetpriorceiling
*
*       Desc: Set the priorceiling for the mutex
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexSetpriorceiling
(
SspthreadMutex  *mutex,                    /* mutex */
S32             priorceiling               /* priority ceiling */
)
#else
PUBLIC  S32  sspthreadMutexSetpriorceiling(mutex, priorceiling)
SspthreadMutex  *mutex;                    /* mutex */
S32             priorceiling;              /* priority ceiling */
#endif
{
   TRC0(sspthreadMutexSetpriorceiling)

   RETVALUE(ENOTSUP);

} /* end of sspthreadMutexSetpriorceiling */
#endif /*  _POSIX_THREAD_PRIO_PROTECT */



/*
*
*       Fun : sspthreadMutexInit
*
*       Desc: Initialize the mutex
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EINVAL   - invalid paramter
*              EFAULT   - fault
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexInit
(
SspthreadMutex     *mutex,      /* mutex to be inited */
SspthreadMutexAttr *attr        /* mutex attributes */
)
#else
PUBLIC  S32  sspthreadMutexInit(mutex, attr)
SspthreadMutex     *mutex;      /* mutex to be inited */
SspthreadMutexAttr *attr;       /* mutex attributes */
#endif
{

   TRC0(sspthreadMutexInit)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mutex == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS111, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

#ifdef _POSIX_COMPLIANCE
   if (attr != NULLP)
   {
      /* check if attr values are invalid: TBD */
      RETVALUE(EINVAL);
   }
   else
      sspthreadMutexAttrInit(attr);
#endif

    if (nsCreateMutex(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS112, (ErrVal)mutex, "Could not init mutex");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);
} /* end of sspthreadMutexInit */


/*
*
*       Fun : sspthreadMutexLock
*
*       Desc: Acquires the mutex
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EFAULT   - fault
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexLock
(
SspthreadMutex  *mutex                /* mutex */
)
#else
PUBLIC  S32  sspthreadMutexLock(mutex)
SspthreadMutex  *mutex;               /* mutex */
#endif
{
   TRC0(sspthreadMutexLock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mutex == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS113, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif
   if (nsLockMutex(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS114, (ErrVal)mutex, 
                             "Could not lock mutex");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);
} /* end of sspthreadMutexLock */


/*
*
*       Fun : sspthreadMutexUnlock
*
*       Desc: Release the mutex
*
*       Ret:   ROK      - ok
*              EFAULT   - fault 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexUnlock
(
SspthreadMutex  *mutex      /* mutex to be released */
)
#else
PUBLIC  S32  sspthreadMutexUnlock(mutex)
SspthreadMutex  *mutex;     /* mutex to be released */
#endif
{
   TRC0(sspthreadMutexUnlock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mutex == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS115, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif

   nsUnlockMutex(mutex);

   RETVALUE(ROK);
} /* end of sspthreadMutexUnlock */


/*
*
*       Fun : sspthreadMutexDestroy
*
*       Desc: Destroy the mutex 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EFAULT   - fault
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadMutexDestroy
(
SspthreadMutex  *mutex             /* mutex to be destroyed */
)
#else
PUBLIC  S32  sspthreadMutexDestroy(mutex)
SspthreadMutex  *mutex;            /* mutex to be destroyed */
#endif
{
   TRC0(sspthreadMutexDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mutex == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS116, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif

   if (nsDestroyMutex(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS117, (ErrVal)mutex, 
                                       "Could not destroy mutex");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);
} /* end of sspthreadMutexDestroy */


/* Condition attribute related functions */

/*
*
*       Fun : sspthreadCondAttrInit
*
*       Desc: Initialize a condition attribute object
*
*       Ret:   ROK      - ok
*              ENOMEM   - no memory available
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondAttrInit
(
SspthreadCondAttr *attr        /* attribute object returned */
)
#else
PUBLIC  S32  sspthreadCondAttrInit(attr)
SspthreadCondAttr *attr;       /* attribute object returned */
#endif
{

#ifdef _POSIX_THREAD_PROCESS_SHARED
   S32   ret;
#endif

   Size  size;

   TRC0(sspthreadCondAttrInit)

   if (attr->sspthreadCondAttrp == NULLP)
   {
      size = sizeof(CondAttr);
      if (SAlloc(SS_DFLT_REGION, &size, 0,(Data **)&attr->sspthreadCondAttrp) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS118, ERRZERO, 
                             "Could not allocate memory for cond attr object");
#endif
          RETVALUE(ENOMEM);
      }
   }

#ifdef _POSIX_THREAD_PROCESS_SHARED
   ret =  sspthreadCondAttrSetPshared(attr, PTHREAD_COND_PSHARED);
   if (ret != ROK)
   {
      SFree(SS_DFLT_REGION, (U8*) attr->sspthreadCondAttrp, size);
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS119, (ErrVal)ret, 
                             "Could not set pshared for condition attr object");
#endif
      RETVALUE(ret);
   }
#endif

   RETVALUE(ROK);

} /* end of sspthreadCondAttrInit */

#ifdef _POSIX_THREAD_PROCESS_SHARED


/*
*
*       Fun : sspthreadCondAttrSetPshared
*
*       Desc: Set the pshared field from attribute 
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondAttrSetPshared
(
SspthreadCondAttr  *attr,        /* condition attributes */
S32                pshared 
)
#else
PUBLIC  S32  sspthreadCondAttrSetPshared(attr, pshared)
SspthreadCondAttr  *attr;        /* condition attributes */
S32                pshared;
#endif
{
   TRC0(sspthreadCondAttrSetPshared)

   RETVALUE(ENOTSUP);

} /* end of sspthreadCondAttrSetPshared */

/*
*
*       Fun : sspthreadCondAttrGetPshared
*
*       Desc: Get the pshared field from attribute 
*
*       Ret:   ROK      - ok
*              ENOTSUP  - not supported
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondAttrGetPshared
(
SspthreadCondAttr  *attr,             /* condition attributes */
S32                *pshared 
)
#else
PUBLIC  S32  sspthreadCondAttrGetPshared(attr, pshared)
SspthreadCondAttr  *attr;             /* condition attributes */
S32                *pshared;
#endif
{
   TRC0(sspthreadCondAttrGetPshared)

   RETVALUE(ENOTSUP);

} /* end of sspthreadCondAttrGetPshared */
#endif


/*
*
*       Fun : sspthreadCondAttrDestroy
*
*       Desc: destroy the condition attribute
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid parameter
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondAttrDestroy
(
SspthreadCondAttr *attr           /* attributes */
)
#else
PUBLIC  S32  sspthreadCondAttrDestroy(attr)
SspthreadCondAttr *attr;          /* attributes */
#endif
{
   TRC0(sspthreadCondAttrDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (attr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS120, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   SFree(SS_DFLT_REGION, (U8*) attr->sspthreadCondAttrp, sizeof(CondAttr));

   RETVALUE(ROK);
} /* end of sspthreadCondAttrDestroy */


/*
*
*       Fun : sspthreadCondBroadcast
*
*       Desc: Broadcast the condition 
*
*       Ret:   ROK      - ok
*              EFAULT   - fault
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondBroadcast
(
SspthreadCond *cond             /* condition to broadcast */
)
#else
PUBLIC  S32  sspthreadCondBroadcast(cond)
SspthreadCond *cond;            /* condition to broadcast */
#endif
{
   TRC0(sspthreadCondBroadcast)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS121, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif

   nsCondBroadcast(cond);

   RETVALUE(ROK);

} /* end of sspthreadCondBroadcast */


/*
*
*       Fun : sspthreadCondDestroy
*
*       Desc: Destroy the condition identified by cond
*
*       Ret:   ROK      - ok
*              EFAULT   - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondDestroy
(
SspthreadCond *cond            /* condition to delete */
)
#else
PUBLIC  S32  sspthreadCondDestroy(cond)
SspthreadCond *cond;           /* condition to delete */
#endif
{
   TRC0(sspthreadCondDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS122, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif
   if (nsDestroyCond(cond) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS123, (ErrVal)cond, 
                                  "Could not destroy condition");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);

} /* end of sspthreadCondDestroy */


/*
*
*       Fun : sspthreadCondInit
*
*       Desc: Initialize the condition
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EFAULT   - fault 
*              EINVAL   - invalid parameter
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondInit
(
SspthreadCond     *cond,               /* condition */
SspthreadCondAttr *attr                /* condition attributes */
)
#else
PUBLIC  S32  sspthreadCondInit(cond, attr)
SspthreadCond     *cond;               /* condition */
SspthreadCondAttr *attr;               /* condition attributes */
#endif
{

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS124, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

#ifdef _POSIX_COMPLIANCE
   if (attr != NULL)
   {
      /* check if attr values are invalid */
         RETVALUE(EINVAL);
   }
   else
       sspthreadCondAttrInit(attr);
#endif

   if (nsCreateCond(cond) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS125, (ErrVal)cond, 
                                     "Could not create condition");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);
} /* end of sspthreadCondInit */


/*
*
*       Fun : sspthreadCondSignal
*
*       Desc: Signal the condition
*
*       Ret:   ROK      - ok
*              EFAULT   - fault 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondSignal
(
SspthreadCond *cond                     /* condition to be signaled */
)
#else
PUBLIC  S32  sspthreadCondSignal(cond)
SspthreadCond *cond;                    /* condition to be signaled */
#endif
{
   TRC0(sspthreadCondSignal)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS126, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif

   nsSignalCond(cond);

   RETVALUE(ROK);

} /* end of sspthreadCondSignal */


/*
*
*       Fun : sspthreadCondWait
*
*       Desc: Wait for a codition
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EFAULT   - fault 
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondWait
(
SspthreadCond  *cond,          /* condition to wait on */
SspthreadMutex *mutex          /* associated mutex */
)
#else
PUBLIC  S32  sspthreadCondWait(cond, mutex)
SspthreadCond  *cond;          /* condition to wait on */
SspthreadMutex *mutex;         /* associated mutex */
#endif
{
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP || mutex == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS127, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif
   cond->condVal++;
   if (sspthreadMutexUnlock(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS128, (ErrVal)mutex, 
                                  "Could not unlock the mutex");
#endif
      RETVALUE(RFAILED);
   }

   nsCondWait(cond);

   if (sspthreadMutexLock(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS129, (ErrVal)mutex, 
                                  "Could not lock the mutex");
#endif
      RETVALUE(RFAILED);
   }

   cond->condVal--;

   RETVALUE(ROK);
} /* end of sspthreadCondWait */


/*
*
*       Fun : sspthreadCondTimedWait
*
*       Desc: Wait on a condition for a given time
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              ETIME    - time out
*              EFAULT   - fault
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadCondTimedWait
(
SspthreadCond  *cond,            /* condition to wait on */
SspthreadMutex *mutex,           /* associated mutex */
SsTime         *abstime          /* wait time */
)
#else
PUBLIC  S32  sspthreadCondTimedWait(cond, mutex, abstime)
SspthreadCond  *cond;            /* condition to wait on */
SspthreadMutex *mutex;           /* associated mutex */
SsTime         *abstime;         /* wait time */
#endif
{
   TRC0(sspthreadCondTimedWait)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((cond == NULLP) ||(mutex == NULLP) || (abstime == NULLP))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS130, ERRZERO, "Null pointer");
      RETVALUE(EFAULT);
   }
#endif

   cond->condVal++;
   if (sspthreadMutexUnlock(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS131, (ErrVal)mutex, 
                                  "Could not unlock the mutex");
#endif
      RETVALUE(RFAILED);
   }
   
   if (nsCondTimeWait(cond, abstime) == WAIT_TIMEOUT)
   {
      cond->condVal--;
      RETVALUE(ETIME);
   }

   if (sspthreadMutexLock(mutex) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS132, (ErrVal)mutex, 
                                  "Could not lock the mutex");
#endif
      RETVALUE(RFAILED);
   }

   cond->condVal--;

   RETVALUE(ROK);

} /* end of sspthreadCondTimedWait */



/* Semaphore related functions */

/*
*
*       Fun : sspthreadSemDestroy
*
*       Desc: Delete the semaphore indetified by sem
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid semaphore
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadSemDestroy
(
SspthreadSem  *sem        /* semaphore to be deleted */
)
#else
PUBLIC  S32  sspthreadSemDestroy(sem)
SspthreadSem  *sem;       /* semaphore to be deleted */
#endif
{
   TRC0(sspthreadSemDestroy)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sem == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS133, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   if (nsDestroySema(sem) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS134, (ErrVal)sem, 
                             "Could not destroy semaphore");
#endif
      RETVALUE(-1);
   }

   RETVALUE(ROK);
} /* end of sspthreadSemDestroy */


/*
*
*       Fun : sspthreadSemInit
*
*       Desc: Initialized a semaphore with given value
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*              EINVAL   - invalid value
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadSemInit
(
SspthreadSem *sem,      /* pointer to semaphore object */
S32          pshared,
U32          value      /* semaphore initial count */
)
#else
PUBLIC  S32  sspthreadSemInit(sem, pshared, value)
SspthreadSem *sem;      /* pointer to semaphore object */
S32          pshared;
U32          value;     /* semaphore initial count */
#endif
{
   TRC0(sspthreadSemInit)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sem == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS135, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
   if (value > NS_SEM_VALUE_MAX)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS136, ERRZERO, "Max Init count exceeded");
      RETVALUE(EINVAL);
   }
#endif

   if (nsCreateSema(sem, value, NS_SEM_VALUE_MAX) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS137, (ErrVal)sem, 
                             "Could not create the semaohore ");
#endif
      RETVALUE(-1);
   }

   RETVALUE(ROK);
} /* end of sspthreadSemInit */


/*
*
*       Fun : sspthreadSemPost
*
*       Desc: Increments the count of semaphore by one
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid value
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadSemPost
(
SspthreadSem  *sem             /* sempahore to be incremented */
)
#else
PUBLIC  S32  sspthreadSemPost(sem)
SspthreadSem  *sem;            /* sempahore to be incremented */
#endif
{
   TRC0(sspthreadSemPost)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sem == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS138, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   if (nsPostSema(sem) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS139, (ErrVal)sem, 
                             "Could not post the semaohore ");
#endif
      RETVALUE(-1);
   }

   RETVALUE(ROK);
} /* end of sspthreadSemPost */


/*
*
*       Fun : sspthreadSemTrywait
*
*       Desc: Try to acquire the semaphore if it can be acquired
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid value
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadSemTrywait
(
SspthreadSem  *sem               /* semaphore to be acquired */
)
#else
PUBLIC  S32  sspthreadSemTrywait(sem)
SspthreadSem  *sem;              /* semaphore to be acquired */
#endif
{
   TRC0(sspthreadSemTrywait)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sem == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS140, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   if (nsWaitForSingleObject(sem,0) == WAIT_TIMEOUT)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS141, (ErrVal)sem, 
                             "Could not decrement the semaohore ");
#endif
      RETVALUE(-1);
   }

   RETVALUE(ROK);
} /* end of sspthreadSemTrywait */


/*
*
*       Fun : sspthreadSemWait
*
*       Desc: Wait for the semaphore object 
*
*       Ret:   ROK      - ok
*              EINVAL   - invalid value
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC  S32  sspthreadSemWait
(
SspthreadSem  *sem                 /* semaphore to wait on */
)
#else
PUBLIC  S32  sspthreadSemWait(sem)
SspthreadSem  *sem;                /* semaphore to wait on */
#endif
{
   TRC0(sspthreadSemWait)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sem == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS142, ERRZERO, "Null pointer");
      RETVALUE(EINVAL);
   }
#endif

   if (nsWaitForSingleObject(sem, NS_INFINITE) != WAIT_OK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS143, (ErrVal)sem, 
                             "Could not decrement the semaohore ");
#endif
      RETVALUE(-1);
   }

   RETVALUE(ROK);
} /* end of sspthreadSemWait */



#ifndef SS_SINGLE_THREADED
/*
*
*       Fun :  SInitLock
*
*       Desc: Initialize a lock of the given type 
*
*       Ret :   ROK      - ok
*               RFAILED  - failed
*
*       Notes: Caller must prove the storage for the lock id to be stored.
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SInitLock
(
SLockId *lockId,           /* lock Id to be returned */
U8       lType             /* type of the lock */
)
#else
PUBLIC S16 SInitLock(lockId, lType)
SLockId *lockId;           /* lock Id to be returned */
U8       lType;            /* type of the lock */
#endif
{
   TRC1(SInitLock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check lockId pointer */
   if (lockId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS144, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   lockId->lType = lType;

#ifdef NK  /* Kernel space lock implementation */
   if (lType == SS_LOCK_MUTEX)
   {
      ASSERT(KeGetCurrentIrql() <= DISPATCH_LEVEL);  /* Check the IRQL */
      ExInitializeFastMutex(&lockId->osLock.mtx);
      RETVALUE(ROK);
   }
   if (lType == SS_LOCK_SPIN)
   {
      KeInitializeSpinLock(&lockId->osLock.sLock);
      RETVALUE(ROK);
   }
#endif

#ifdef NU  /* User space lock implementation */
   if (lType == SS_LOCK_MUTEX)
   {
      lockId->osLock.mtx = CreateMutex(NULL, FALSE, NULL);
      if (lockId->osLock.mtx == NULL)
      {
         RETVALUE(RFAILED);
      }
      RETVALUE(ROK);
   }

   if (lType == SS_LOCK_CRITSEC)
   {
      InitializeCriticalSection(&lockId->osLock.cSec);
      RETVALUE(ROK);
   }
#endif  /* NU */

   RETVALUE(RFAILED);

} /* end of SInitLock */



/*
*
*       Fun : SLock   
*
*       Desc: Acquires the lock identified by lockId
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SLock
(
SLockId *lockId                  /* lock Id of the lock to be acquired */
)
#else
PUBLIC S16 SLock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be acquired */
#endif
{
   TRC1(SLock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check lockId */
   if (lockId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS145, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


#ifdef NU
   if (lockId->lType == SS_LOCK_MUTEX)
   {
      if (WaitForSingleObject(lockId->osLock.mtx, INFINITE) == WAIT_OBJECT_0)
         RETVALUE(ROK);
      else
         RETVALUE(RFAILED);
   }

   if (lockId->lType == SS_LOCK_CRITSEC)
   {
      EnterCriticalSection(&lockId->osLock.cSec);
      RETVALUE(ROK);
   }
#endif

   RETVALUE(RFAILED);

} /* end of SLock */



/*
*
*       Fun :  SUnlock  
*
*       Desc: Release the lock identified by lockId
*
*       Ret :   ROK      - ok
*               RFAILED  - failed
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SUnlock
(
SLockId *lockId                  /* lock Id of the lock to be released */
)
#else
PUBLIC S16 SUnlock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be released */
#endif
{
   TRC1(SUnlock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check lockId */
   if (lockId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS146, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


#ifdef NU
   if (lockId->lType == SS_LOCK_MUTEX)
   {
      ReleaseMutex(lockId->osLock.mtx);
      RETVALUE(ROK);
   }
   if (lockId->lType == SS_LOCK_CRITSEC)
   {
      LeaveCriticalSection(&lockId->osLock.cSec);
      RETVALUE(ROK);
   }
#endif

   RETVALUE(RFAILED);

} /* end of SUnlock */


/*
*
*       Fun : SDestroyLock
*
*       Desc: Acquires the lock identified by lockId
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SDestroyLock
(
SLockId *lockId                  /* lock Id of the lock to be deleted */
)
#else
PUBLIC S16 SDestroyLock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be deleted */
#endif
{
   TRC1(SDestroyLock)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check lockId */
   if (lockId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS147, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


#ifdef NU
   if (lockId->lType == SS_LOCK_MUTEX)
   {
      CloseHandle(lockId->osLock.mtx);
      RETVALUE(ROK);
   }
   if (lockId->lType == SS_LOCK_CRITSEC)
   {
      DeleteCriticalSection(&lockId->osLock.cSec);
      RETVALUE(ROK);
   }
#endif

   RETVALUE(RFAILED);

} /* end of SDestroyLock */



/*
*
*       Fun : ssInitSema
*
*       Desc: Initialize a sempahore and put the initial count as
*             given
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssInitSema
(
SsSemaId   *sema,                        /* semaphore */
U8          count                        /* initial value */
)
#else
PUBLIC S16 ssInitSema(sema, count)
SsSemaId   *sema;                        /* semaphore */
U8          count;                       /* initial value */
#endif
{
   TRC0(ssInitSema)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS148, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsCreateSema(sema, count, NS_SEM_VALUE_MAX) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS149, (ErrVal)sema, 
                             "Could not create the semaohore ");
#endif
      RETVALUE(RFAILED);
   }
 
   RETVALUE(ROK);
} /* end of ssInitSema */


/*
*
*       Fun : ssDestroySema
*
*       Desc: Destroy a given sempahore 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssDestroySema
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 ssDestroySema(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(ssDestroySema)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS150, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsDestroySema(sema) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS151, (ErrVal)sema, 
                             "Could not destroy semaphore");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ssDestroySema */


/*
*
*       Fun : ssPostSema
*
*       Desc: Increment the count semaphore by one 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssPostSema
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 ssPostSema(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(ssPostSema)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS152, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsPostSema(sema) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS153, (ErrVal)sema, 
                             "Could not post the semaohore ");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ssPostSema */


/*
*
*       Fun : ssWaitSema
*
*       Desc: Decrement the count of the semahore by one on exiting
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: This is a blocking call
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssWaitSema
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 ssWaitSema(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(ssWaitSema)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS154, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsWaitForSingleObject(sema, NS_INFINITE) != WAIT_OK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS155, (ErrVal)sema, 
                             "Could not decrement the semaphore ");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ssWaitSema */

#if 1 /* ns004.12: addition */

/*
*
*       Fun : SInitSemaphore
*
*       Desc: Initialize a sempahore and put the initial count as
*             given
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SInitSemaphore
(
SsSemaId   *sema,                        /* semaphore */
U8          count                        /* initial value */
)
#else
PUBLIC S16 SInitSemaphore(sema, count)
SsSemaId   *sema;                        /* semaphore */
U8          count;                       /* initial value */
#endif
{
   TRC0(SInitSemaphore)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsCreateSema(sema, count, NS_SEM_VALUE_MAX) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENSXXX, (ErrVal)sema, 
                             "Could not create the semaohore ");
#endif
      RETVALUE(RFAILED);
   }
 
   RETVALUE(ROK);
} /* end of SInitSemaphore */


/*
*
*       Fun : SDestroySemaphore
*
*       Desc: Destroy a given sempahore 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SDestroySemaphore
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 SDestroySemaphore(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(SDestroySemaphore)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsDestroySema(sema) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENSXXX, (ErrVal)sema, 
                             "Could not destroy semaphore");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of SDestroySemaphore */


/*
*
*       Fun : SPostSemaphore
*
*       Desc: Increment the count semaphore by one 
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SPostSemaphore
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 SPostSemaphore(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(SPostSemaphore)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsPostSema(sema) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENSXXX, (ErrVal)sema, 
                             "Could not post the semaohore ");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ssPostSema */


/*
*
*       Fun : SWaitSemaphore
*
*       Desc: Decrement the count of the semahore by one on exiting
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: This is a blocking call
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SWaitSemaphore
(
SsSemaId   *sema                         /* semaphore */
)
#else
PUBLIC S16 SWaitSemaphore(sema)
SsSemaId   *sema;                        /* semaphore */
#endif
{
   TRC0(SWaitSemaphore)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check sema */
   if (sema == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   if (nsWaitForSingleObject(sema, NS_INFINITE) != WAIT_OK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENSXXX, (ErrVal)sema, 
                             "Could not decrement the semaphore ");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of ssWaitSema */

#endif /* ns004.12: addition */
#else /* SS_SINGLE_THREADED */


/*
*
*       Fun :  SInitLock
*
*       Desc: Initialize a lock of the given type 
*
*       Ret :   ROK      - ok
*               RFAILED  - failed
*               ROUTRES  - failed due to lack of resources
*
*       Notes: Caller must prove the storage for the lock id to be stored.
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SInitLock
(
SLockId *lockId,           /* lock Id to be returned */
U8       lType             /* type of the lock */
)
#else
PUBLIC S16 SInitLock(lockId, lType)
SLockId *lockId;           /* lock Id to be returned */
U8       lType;            /* type of the lock */
#endif
{

   TRC1(SInitLock)

   RETVALUE(ROK);

} /* end of SInitLock */



/*
*
*       Fun : SLock   
*
*       Desc: Acquires the lock identified by lockId
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SLock
(
SLockId *lockId                  /* lock Id of the lock to be acquired */
)
#else
PUBLIC S16 SLock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be acquired */
#endif
{
   TRC1(SLock)

   RETVALUE(ROK);

} /* end of SLock */



/*
*
*       Fun :  SUnlock  
*
*       Desc: Release the lock identified by lockId
*
*       Ret :   ROK      - ok
*               RFAILED  - failed
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SUnlock
(
SLockId *lockId                  /* lock Id of the lock to be released */
)
#else
PUBLIC S16 SUnlock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be released */
#endif
{
   TRC1(SUnlock)

   RETVALUE(ROK);

} /* end of SUnlock */


/*
*
*       Fun : SDestroyLock
*
*       Desc: Acquires the lock identified by lockId
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SDestroyLock
(
SLockId *lockId                  /* lock Id of the lock to be deleted */
)
#else
PUBLIC S16 SDestroyLock(lockId)
SLockId *lockId;                 /* lock Id of the lock to be deleted */
#endif
{
   TRC1(SDestroyLock)

   RETVALUE(ROK);

} /* end of SDestroyLock */

#endif /* SS_SINGLE_THREADED */



/*
*
*       Fun : nsProcessMsg
*
*       Desc: Process a message 
*
*       Ret:  none
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC VOID  nsProcessMsg
(
SsSTskEntry *sTsk  
)
#else
PUBLIC VOID  nsProcessMsg(sTsk)
SsSTskEntry *sTsk;
#endif
{
   S16         ret;
   Buffer     *mBuf;
   Ent         dEnt;
   Inst        dInst;
   SsTTskEntry *tTsk;
   SsTmrId     tIdx;  
   Pst         pst;
   Pst         *pPst;
   U8          i;

/* ns006.12 - ThreadYield Logic should be only applied to User Space */
#ifdef NU
#if 1 /* ns005.12: addition */
   S16         IsPermTsk = 0;
#endif /* ns005.12: addition */
#endif /* NU */
   
   TRC0(nsProcessMsg)

     /*
      * This is a blocking call so thread will sleep on this till a
      * message is available in demand queue in multi-threaded case
      * otherwise this calls retuns with ROKDNA
      */
      ret = ssDmndQGet(&sTsk->dQ, &mBuf, SS_DQ_FIRST);
      if (ret != ROK)
      {
         if (ret == ROKDNA)
         {
            NS_MGMT(SLock(&sTsk->lock));
            NS_MGMT(sTsk->dep.loopIdleCnt++);
            NS_MGMT(sTsk->dep.emptyCnt++);
            NS_MGMT(SUnlock(&sTsk->lock));
            RETVOID;
         }
         NS_MGMT(SLock(&sTsk->lock));
         NS_MGMT(sTsk->dep.loopActvCnt++);
         NS_MGMT(SUnlock(&sTsk->lock));
         RETVOID;
      }

      /* lock this system task entry */
      if (SLock(&sTsk->lock) != ROK)
      {
         SPutMsg(mBuf);
         RETVOID;
      }

      NS_MGMT(sTsk->dep.loopActvCnt++);
      NS_MGMT(sTsk->dep.notEmptyCnt++);

      /* got a message from the demand queue */
      /* check message type and process it accordingly */
      switch(SS_GET_MSGTYPE_FROM_MBUF(mBuf))
      {
         case SS_EVNT_DATA:
         {
            dEnt  = SS_GET_DENT_FROM_MBUF(mBuf);
            dInst = SS_GET_DINST_FROM_MBUF(mBuf);

            NS_MGMT(SLock(&sTsk->dep.stsLock));
            NS_MGMT(sTsk->dep.crntEnt = dEnt);
            NS_MGMT(sTsk->dep.crntInst= dInst);
            NS_MGMT(SUnlock(&sTsk->dep.stsLock));
      
            tIdx = osCp.tTskIds[dEnt][dInst];
            if (tIdx != SS_TSKNC)
            {
               tTsk  = &osCp.tTskTbl[osCp.tTskIds[dEnt][dInst]];
               /* ns007.102 -- verify system task is still running it */
	       if (tTsk->sTsk != sTsk)
	       {
                  SPutMsg(mBuf);
		  break;
	       }
               NS_MGMT(tTsk->dep.actvCnt++);
               NS_MGMT(sTsk->dep.loopNormCnt++);
#if 0 /* ns002.12: deletion */
               if (tTsk->actvTsk != NULLP)
                  (Void)(tTsk->actvTsk)(SS_GET_PST_FROM_MBUF(mBuf), mBuf);
#endif /* ns002.12: deletion */
#if 1 /* ns002.12: addition */
                  pPst = SS_GET_PST_FROM_MBUF(mBuf);
                  for (i = 0;  i < sizeof(Pst);  i++)
                     *(((U8 *) &pst) +i)  = * (((U8 *)pPst)+ i);
               if (tTsk->actvTsk != NULLP)
                  (Void)(tTsk->actvTsk)(&pst, mBuf);
#endif /* ns002.12: addition */
            }
            else
            {
               /* drop the message */
               SPutMsg(mBuf);
            }
            break;
         }
         case SS_EVNT_TIMER:
         {
            tIdx = SS_GET_TMRIDX_FROM_MBUF(mBuf);
            if (SLock(&osCp.tmrTblLock) == ROK)
            {
               if (osCp.tmrTbl[tIdx].tmrActvFn != NULLP)
               {
                  NS_MGMT(sTsk->dep.loopTmrCnt++);
                  (S16)((osCp.tmrTbl[tIdx].tmrActvFn)());
               }
            }
            /* 
             * check that if the assocaited buFfer in timer is 
             * to be deallocated here or not 
             */
            if (SS_GET_DYNBUF_FROM_MBUF(mBuf) == TRUE)
            {
               SPutMsg(mBuf);
            }
            else
            {
               /* Simply reset inUse field to FALSE */
               SS_RESET_INUSE_IN_MBUF(mBuf);
            }
            SUnlock(&osCp.tmrTblLock);
            break;
         }
         case SS_EVNT_PERMTICK:
         {
            /* 
             * This is a message from permanent task so handle 
             * it accordingly 
             */

            dEnt  = SS_GET_DENT_FROM_MBUF(mBuf);
            dInst = SS_GET_DINST_FROM_MBUF(mBuf);

            NS_MGMT(SLock(&sTsk->dep.stsLock));
            NS_MGMT(sTsk->dep.crntEnt = dEnt);
            NS_MGMT(sTsk->dep.crntInst= dInst);
            NS_MGMT(SUnlock(&sTsk->dep.stsLock));

            tIdx = osCp.tTskIds[dEnt][dInst];
            if (tIdx != SS_TSKNC) 
            {
               tTsk  = &osCp.tTskTbl[osCp.tTskIds[dEnt][dInst]];
               /* ns007.102 - verify the system task is still running it */
               if (tTsk->sTsk != sTsk)
	       {
                  SPutMsg(mBuf);
		  break;
	       }

               if (tTsk->tskType == SS_TSK_PERMANENT)
               {
                  pPst = SS_GET_PST_FROM_MBUF(mBuf);
                  for (i = 0;  i < sizeof(Pst);  i++)
                     *(((U8 *) &pst) +i)  = * (((U8 *)pPst)+ i);

                  if (tTsk->actvTsk != NULLP)
                  {
                     NS_MGMT(tTsk->dep.actvCnt++);
                     NS_MGMT(sTsk->dep.loopPermCnt++);
                        (Void)(tTsk->actvTsk)(&pst, NULLP);
                  }
                  
                  /* We need to re-send this message back to the same 
                   * task so the permanent task continues to run.
                   */
                  if (ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf, ((tTsk->tskPrior
                                 * SS_MAX_MSG_PRI) + pPst->prior)) != ROK)
                     SPutMsg(mBuf);
/* ns015.102 - Modification of nsProcessMsg for perm tasks with signals with ST mode */ 
#ifdef SS_SINGLE_THREADED
                  SetEvent(osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX]);
#endif /* SS_SINGLE_THREADED */
#ifdef NU
#if 1 /* ns005.12: addition */
		  IsPermTsk = 1;
#endif /* ns005.12: addition */
#endif /* NU */
               }
               else
               {
                  /* Logical error */
                  SPutMsg(mBuf);
               }
            }
            else
            {
               /* drop the message */
               SPutMsg(mBuf);
            }
            break;    
         }
         case SS_EVNT_TERM:
         {
            i              = sTsk->tskId;
            sTsk->termPend = FALSE;
            sTsk->used     = FALSE;
            sTsk->tskPrior = 0;
            sTsk->numTTsks = 0;
	    /* ns011.102 - Modification to protect nxtSTskEntry */
            ssDestroyDmndQ(&sTsk->dQ);
            SUnlock(&sTsk->lock);
            SDestroyLock(&sTsk->lock);

            SLock(&osCp.sTskTblLock);
            sTsk->nxt      = osCp.nxtSTskEntry;
            osCp.nxtSTskEntry = i;
            osCp.numSTsks--;
            SUnlock(&osCp.sTskTblLock);

            nsExitThread(ret);
         }
         default:
         {
            break;
         }
      } /* end of switch */

      SUnlock(&sTsk->lock);
      
#ifdef NU
#if 1 /* ns005.12: addition */
      if (IsPermTsk)
	nsThreadYield();
#endif /* ns005.12: addition */
#endif /* NU */

   RETVOID;
} /* end of nsProcessMsg */
      
#ifndef SS_STSK_HANDLER

/*
*
*       Fun : sTskHandler
*
*       Desc: system task scheuling loop
*
*       Ret:  none
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC VOID  *sTskHandler
(
VOID   *context
)
#else
PUBLIC VOID  *sTskHandler(context)
VOID   *context;
#endif
{
   SsSTskEntry *sTsk; 
#ifdef SS_SINGLE_THREADED
   U32          waitTime;
   /* ns015.102 - Addition of data type */ 
   U32          QSize;
   U32          i;
#endif /* SS_SINGLE_THREADED */

   sTsk = (SsSTskEntry *)context;


   for (;;)
   {
      /* continue the loop till the system task is terminated */

#ifndef SS_SINGLE_THREADED

      nsProcessMsg(sTsk); 

#else
      /*
       * wait for interrupt event, any timer event or message delivery
       *  event
       */

      /* ns015.102 - Removal of perm task processing in sTskHandler */ 
      waitTime = INFINITE;

      osCp.dep.eventIdx = (U8)WaitForMultipleObjects(osCp.dep.eventCount,
                                   osCp.dep.eventWaitArray, FALSE, waitTime);

      if ((osCp.dep.eventIdx >= WAIT_OBJECT_0) && 
          (osCp.dep.eventIdx <= (WAIT_OBJECT_0 + osCp.dep.eventCount - 1)))
      {
         osCp.dep.eventIdx -= WAIT_OBJECT_0;
      }
      else
      {

         /* ns015.102 - Removal of perm task processing in sTskHandler */ 
         /* ns015.102 - Addition of thread yield if no signal occured */ 
	      nsThreadYield();

      }

      /* 
       * The priority of events is as follows:
       * Interrupt, timier, message and console
       *
       * WaitForMultipleObjects returns the index of
       * first signalled event.
       */
#ifdef SS_DRVR_SUPPORT
      if (osCp.dep.eventIdx == NS_INTR_EVNT_IDX)
      {
         /* check for any interrupts */
         nsScanInt(NULLP);
      }
#endif /* SS_DRVR_SUPPORT */

      /* check if any timer has expired */
      nsTimerHandler(NULLP);

      /* ns015.102 - Modification of sTskHandler for perm tasks to be
       * handled through signals and to process the number of messages
       * in the demand queue for a message event signal */
      if (osCp.dep.eventIdx <= NS_MSD_EVNT_IDX)
      {
         /* process all messages */
         QSize = 0;
         for(i=0; i < SS_MAX_NUM_DQ; i++)
            QSize = QSize + sTsk->dQ.queue[i].crntSize;
         for(i=1; i<=QSize; i++)
            nsProcessMsg(sTsk);
      }
#ifdef CONAVL
/* ns010.102 - Addition to disable console reading with CONRD enabled */
#ifndef CONRD
/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
/*chendh disable it*/
#if 0
      if (osCp.dep.eventIdx <= NS_CON_EVNT_IDX)
      {
         /* check for console input */
         nsScanCon(NULLP);
      }
#endif
#endif /* SS_WINCE */
#endif /* CONRD */
#endif /* CONAVL */

#endif /* SS_SINGLE_THREADED */

   } /* loop */

   RETVALUE((Void *)NULLP);

} /* end of sTskHandler */
#endif /* SS_STSK_HANDLER */


/*
*
*       Fun:   Initialize task table
*
*       Desc:  This function initializes Windows-specific information
*              in the task table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:   np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitTsk
(
void
)
#else
PUBLIC S16 ssdInitTsk()
#endif
{
   S16  i;
   SsdSTskEntry *sdSTskE;
   NS_MGMT(SsdTTskEntry *sdTTskE);

   TRC0(ssdInitTsk)

#ifdef NS_ENB_MGMT
   /* initialize the dependent portion of TAPA task entry */
   for (i = 0;  i < SS_MAX_TTSKS;  i++)
   {
      sdTTskE = &osCp.tTskTbl[i].dep;
      sdTTskE->actvCnt = 0;
   }
#endif /* NS_ENB_MGMT */

   /* initialize the dependent portion of system task entry */
   for (i = 0;  i < SS_MAX_STSKS;  i++)
   {
      sdSTskE = &osCp.sTskTbl[i].dep;
      sdSTskE->sTskHandle = NULLP;

      /* initialize system task related statistics*/
      NS_MGMT(sdSTskE->loopActvCnt = 0);
      NS_MGMT(sdSTskE->loopIdleCnt = 0);
      NS_MGMT(sdSTskE->loopPermCnt = 0);
      NS_MGMT(sdSTskE->loopNormCnt = 0);
      NS_MGMT(sdSTskE->loopTmrCnt  = 0);

      /* initialize system task demand queue related statistics*/
      NS_MGMT(sdSTskE->emptyCnt    = 0);
      NS_MGMT(sdSTskE->notEmptyCnt = 0);

      NS_MGMT(sdSTskE->crntEnt     = ENTNC);
      NS_MGMT(sdSTskE->crntInst    = INSTNC);

#ifdef NS_ENB_MGMT
      if (SInitLock(&sdSTskE->stsLock, NS_STS_LOCK) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS156, ERRZERO, 
                               "SInitLock failed for NS_STS_LOCK");
#endif
         RETVALUE(RFAILED);
      } 
#endif /* NS_ENB_MGMT */
   }


   RETVALUE(ROK);
} /* end of ssdInitTsk */


#ifdef SS_DRVR_SUPPORT

/*
*
*       Func:  ssdInitDrvr
*
*       Desc:  This function initializes Windows-specific information
*              in the driver task table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitDrvr
(
void
)
#else
PUBLIC S16 ssdInitDrvr()
#endif
{
   MTHRD_PARAM(SchedParam sParam)
   NU_PARAM(U32 error)
   U8         i;


   TRC0(ssdInitDrvr)

   for (i=0; i < SS_MAX_DRVRTSKS; i++)
   {
      osCp.drvrTskTbl[i].dep.isFlag = FALSE;
   }

#ifdef NU
   /* create an event on which the interruprt handling thread will block */
   if ((osCp.dep.eventWaitArray[NS_INTR_EVNT_IDX] 
                   = CreateEvent(NULL, TRUE, FALSE, NULL)) == NULLP)
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS157, (ErrVal)error, 
                            "Could not create interrupt event");
#endif
      RETVALUE(RFAILED);
   }
#endif /* NU */


   /* increment number of events */
   osCp.dep.eventCount++;

#ifndef SS_SINGLE_THREADED
   /* Create a thread which will scan the interrputs */
   if (sspthreadCreate(&osCp.dep.intThrd, NULLP, nsScanInt, NULLP) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS159, ERRZERO, 
                            "Could not create Interrupt Scan Thread");
#endif
      RETVALUE(RFAILED);
   }

   sParam.schedPrior = NS_INT_THRD_PRIOR;

   if (sspthreadSetSchedParam(&osCp.dep.intThrd, SCHED_OTHER, &sParam) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS160, ERRZERO, 
                            "Could not set Interrupt Thread priority");
#endif
      RETVALUE(RFAILED);
   }

#endif /* SS_SINGLE_THREADED */

   RETVALUE(ROK);

} /* end of ssdInitDrvr */
#endif /* SS_DRVR_SUPPORT */

/*
*
*       Fun:   ssdAttachTTsk
*
*       Desc:  This function sends the initial tick message to a TAPA
*              task if the task is a permanent task.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdAttachTTsk
(
SsTTskEntry *tTsk           /* pointer to TAPA task entry */
)
#else
PUBLIC S16 ssdAttachTTsk(tTsk)
SsTTskEntry *tTsk;          /* pointer to TAPA task entry */
#endif
{
   Buffer     *mBuf;
   SsMsgInfo  *mInfo;

   TRC0(ssdAttachTTsk)

   /* 
    * For the permanent tasks post a message to them so they can
    * keep themself alive 
    */
   if (tTsk->tskType == SS_TSK_PERMANENT)
   {
      /* increment permanent task count */
      osCp.dep.permTskCount++;

      if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS161, ERRZERO, "SGetMsg() failed");
#endif
         RETVALUE(RFAILED); 
      }

      mInfo = (SsMsgInfo *)mBuf->b_rptr;
      mInfo->eventInfo.event = SS_EVNT_PERMTICK;

      /* setup post structure */
      mInfo->pst.dstProcId = SFndProcId();
      mInfo->pst.srcProcId = SFndProcId();
      mInfo->pst.selector  = SEL_LC_NEW;
      mInfo->pst.region    = SS_DFLT_REGION;
      mInfo->pst.pool      = SS_DFLT_POOL;
      mInfo->pst.prior     = PRIOR3;
      mInfo->pst.route     = RTESPEC;
      mInfo->pst.event     = 0;
      mInfo->pst.dstEnt    = tTsk->ent;
      mInfo->pst.dstInst   = tTsk->inst;
      mInfo->pst.srcEnt    = tTsk->ent;
      mInfo->pst.srcInst   = tTsk->inst;

      if (ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf,
            ((tTsk->tskPrior * SS_MAX_MSG_PRI) + mInfo->pst.prior)) != ROK)
      {
         SPutMsg(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS162, ERRZERO,
                           "Could not write to demand queue");
#endif
         RETVALUE(RFAILED); 
      }
/* ns015.102 - Modification to ssdAttachTTsk to process message via signal */
#ifdef SS_SINGLE_THREADED
      SetEvent(osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX]);
#endif /* SS_SINGLE_THREADED */

      /* store the buffer pointer to be used fro freeing the buffer later */
      tTsk->dep.permBuf = mBuf;
   }

   RETVALUE(ROK);
} /* end of ssdAttachTTsk */


/*
*
*       Fun:   ssdDetachTTsk
*
*       Desc:  This function marks the permanent tick message for
*              a permanent task to be dropped.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdDetachTTsk
(
SsTTskEntry *tTsk           /* pointer to TAPA task entry */
)
#else
PUBLIC S16 ssdDetachTTsk(tTsk)
SsTTskEntry *tTsk;          /* pointer to TAPA task entry */
#endif
{
   TRC0(ssdDetachTTsk)

   RETVALUE(ROK);

} /* end of ssdDetachTTsk */



/*
*
*       Fun:   ssdCreateSTsk
*
*       Desc:  Create  an OS thread in Windows NT
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: 
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdCreateSTsk
(
SsSTskEntry   *sTsk                              /* system task */
)
#else
PUBLIC S16 ssdCreateSTsk(sTsk)
SsSTskEntry   *sTsk;                             /* system task */
#endif
{
   U32 sSize;
   /* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   S8  wPrior;
#else /* SS_WINCE */
   S16  wPrior;
#endif /* SS_WINCE */
   U32 tId;

   TRC0(ssdCreateStsk)

#ifdef SS_SINGLE_THREADED
   sTsk->dep.sTskHandle = nsGetCurrentThread();
   RETVALUE(ROK);
#endif /* SS_SINGLE_THREADED */

   sSize = NS_DFLT_STACK_SIZE;

   tId = 0;
   if ((nsCreateThread(&sTsk->dep.sTskHandle,sTskHandler, sTsk,sSize,tId)!= ROK)
       || (sTsk->dep.sTskHandle == NULLP))
   {
      RETVALUE(RFAILED);
   }

   /* Do a priority mapping for windows NT */
   wPrior = osCp.dep.wPriorLookup[sTsk->tskPrior];

#ifdef NU
   if (nsSetThreadPriority(&sTsk->dep.sTskHandle, wPrior) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS163, (ErrVal)wPrior, 
                                      "Could not set thread priority");
#endif
      RETVALUE(RFAILED);
   }
#endif /* NU */
   RETVALUE(ROK);

} /*ssdCreateSTsk */




/*
*
*       Fun:   ssdDestroySTsk
*
*       Desc:  Destroy the system task
*
*       Ret: ROK       - ok
*            RFAILED   - failed
*
*       Notes: System task table, system task and TAPA task table
*              locks are held before making this call.
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdDestroySTsk
(
SsSTskEntry *sTsk                      /* system task to be destroyed */
)
#else
PUBLIC S16 ssdDestroySTsk(sTsk)
SsSTskEntry *sTsk;                     /* system task to be destroyed */
#endif
{
   Buffer *mBuf;

   TRC0(ssdDestroySTsk)

#ifdef SS_SINGLE_THREADED
   RETVALUE(ROK);
#endif /* SS_SINGLE_THREADED */

   if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   ((SsMsgInfo *)(mBuf->b_rptr))->eventInfo.event = SS_EVNT_TERM;

   if (ssDmndQPutLast(&sTsk->dQ, mBuf, NS_TERM_EVNT_PRIOR) != ROK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS164, ERRZERO,
                                         "Could not Enqueue Term Event");
#endif
      RETVALUE(RFAILED);
   }
/* ns015.102 - Modification to ssdDestroySTsk to process message via signal */
#ifdef SS_SINGLE_THREADED
   SetEvent(osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX]);
#endif /* SS_SINGLE_THREADED */
   RETVALUE(ROK);

} /* ssdDestroySTsk */

#ifdef SS_DRVR_SUPPORT

/*
*
*       Func:  ssdRegDrvrTsk
*
*       Desc:  This function initializes Windows-specific information
*              in the driver task table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdRegDrvrTsk
(
SsDrvrTskEntry *tEntry
)
#else
PUBLIC S16 ssdRegDrvrTsk( tEntry)
SsDrvrTskEntry *tEntry;
#endif
{
   TRC0(ssdRegDrvrTsk)

   RETVALUE(ROK);

} /* end of ssdRegDrvrTsk */
#endif /* SS_DRVR_SUPPORT */

#ifdef SS_OLD_THREAD

/*
*
*       Fun:   SGetMutex
*
*       Desc:  Create and initialize a mutex
*
*       Ret:   ROK     -  success
*              RFAILED -  failed 
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetMutex
(
SMtxId *mId                    /* mutex (returned) */
)
#else
PUBLIC S16 SGetMutex(mId)
SMtxId *mId;                   /* mutex (returned) */
#endif
{
   TRC1(SGetMutex)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS165, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


   if (nsCreateMutex((SsMutexEntry *)mId) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS167, (ErrVal)(*mId), "Could not init mutex");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of SGetMutex */


/*
*
*       Fun:   SPutMutex
*
*       Desc:  Destroy a mutex
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SPutMutex
(
SMtxId mId                     /* mutex id */
)
#else
PUBLIC S16 SPutMutex(mId)
SMtxId mId;                    /* mutex id */
#endif
{
   SsMutexEntry *mtx;

   TRC1(SPutMutex)

   mtx = (SsMutexEntry *)mId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mtx == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS168, ERRZERO, "Invalid mutex ID");
      RETVALUE(RFAILED);
   }
#endif

   if (nsDestroyMutex(mtx) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS169, (ErrVal)mtx,
                                       "Could not destroy mutex");
#endif
      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);

} /* end of SPutMutex */


/*
*
*       Fun:   SLockMutex
*
*       Desc:  Lock a mutex
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SLockMutex
(
SMtxId mId                     /* mutex id */
)
#else
PUBLIC S16 SLockMutex(mId)
SMtxId mId;
#endif
{
   SsMutexEntry *mtx;

   TRC1(SLockMutex)

   mtx = (SsMutexEntry *)mId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mtx == NULLP  )
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS170, mId, "Invalid mutex ID");
      RETVALUE(RFAILED);
   }
#endif

    if (nsLockMutex(mtx) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS171, (ErrVal)mtx,
                                     "Could not lock mutex");
#endif
      RETVALUE(EFAULT);
   }

   RETVALUE(ROK);

} /* end of SLockMutex */


/*
*
*       Fun:   SUnlockMutex
*
*       Desc:  Unlock a mutex
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SUnlockMutex
(
SMtxId mId                     /* mutex id */
)
#else
PUBLIC S16 SUnlockMutex(mId)
SMtxId mId;                    /* mutex id */
#endif
{
   SsMutexEntry *mtx;

   TRC1(SUnlockMutex)

   mtx = (SsMutexEntry *)mId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (mtx == NULLP )
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS172, mId, "Invalid mutex ID");
      RETVALUE(RFAILED);
   }
#endif

   nsUnlockMutex(mtx);

   RETVALUE(ROK);

} /* end of SUnlockMutex */


/*
*
*       Fun:   SGetCond
*
*       Desc:  Create and initialize a condition variable
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetCond
(
SCondId *cId                    /* condition id (returned) */
)
#else
PUBLIC S16 SGetCond(cId)
SCondId *cId;                   /* condition id (returned) */
#endif
{
   SsCondEntry *cond;

   TRC1(SGetCond)

   cond = (SsCondEntry *)cId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS173, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


   if (nsCreateCond(cond) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS175, (ErrVal)cId, 
                                     "Could not create condition");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of SGetCond */


/*
*
*       Fun:   SPutCond
*
*       Desc:  Destroy a condition variable
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SPutCond
(
SCondId cId                     /* condition id */
)
#else
PUBLIC S16 SPutCond(cId)
SCondId cId;                    /* condition id */
#endif
{
   SsCondEntry *cond;

   TRC1(SPutCond)

   cond = (SsCondEntry *)cId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* the second check is not thread-safe */
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS176, ERRZERO, "Invalid condition ID");
      RETVALUE(RFAILED);
   }
#endif

   if (nsDestroyCond(cond) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS177, (ErrVal)cond, 
                                  "Could not destroy condition");
#endif
      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);

} /* end of SPutCond */


/*
*
*       Fun:   SCondWait
*
*       Desc:  Wait on a condition variable
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SCondWait
(
SMtxId mId,
SCondId cId
)
#else
PUBLIC S16 SCondWait(mId, cId)
SMtxId mId;
SCondId cId;
#endif
{
   SsCondEntry  *cond;

   TRC1(SCondWait)

   cond = (SsCondEntry *)cId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS178, cond, "Invalid condition ID");
      RETVALUE(RFAILED);
   }
#endif

   cond->condVal++;

   if (SUnlockMutex(mId) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS179, (ErrVal)mId, 
                                  "Could not unlock the mutex");
#endif
      RETVALUE(RFAILED);
   }

   nsCondWait(cond);

   if (SLockMutex(mId) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS180, (ErrVal)mId, 
                                  "Could not lock the mutex");
#endif
      RETVALUE(RFAILED);
   }
   cond->condVal--;

   RETVALUE(ROK);

} /* end of SCondWait */


/*
*
*       Fun:   SCondSignal
*
*       Desc:  Signal a condition variable
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SCondSignal
(
SCondId cId
)
#else
PUBLIC S16 SCondSignal(cId)
SCondId cId;
#endif
{
   SsCondEntry *cond;

   TRC1(SCondSignal)

   cond = (SsCondEntry *)cId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS181, cond, "Invalid condition ID");
      RETVALUE(RFAILED);
   }
#endif

   nsSignalCond(cond);

   RETVALUE(ROK);

} /* end of SCondSignal */


/*
*
*       Fun:   SCondBroadcast
*
*       Desc:  Send a signal to all threads waiting on this condition
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SCondBroadcast
(
SCondId cId
)
#else
PUBLIC S16 SCondBroadcast(cId)
SCondId cId;
#endif
{
   SsCondEntry *cond;

   TRC1(SCondBroadcast)

   cond = (SsCondEntry *)cId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (cond == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS182, cond, "Invalid condition ID");
      RETVALUE(RFAILED);
   }
#endif

   nsCondBroadcast(cond);

   RETVALUE(ROK);

} /* end of SCondBroadcast */


/*
*
*       Fun:   SGetThread
*
*       Desc:  Create a thread of execution
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetThread
(
SThrd thrd,                     /* thread function */
S32 thr_flgs,                   /* thread flags */
Ptr arg,                        /* thread function argument */
SThrdId *thrdId                 /* thread function id */
)
#else
PUBLIC S16 SGetThread(thrd, thr_flgs, arg, thrdId, type)
SThrd thrd;                     /* thread function */
S32 thr_flgs;                   /* thread flags */
Ptr arg;                        /* thread function argument */
SThrdId *thrdId;                /* thread function id */
#endif
{
   U32         stacksize;
   SsThrdEntry *thread;
   U32         tId;

   TRC1(SGetThread)

   UNUSED(thr_flgs);

   thread = (SsThrdEntry *)thrdId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thread == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS183, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   stacksize = NS_DFLT_STACK_SIZE;

   tId = 0;
   if ((nsCreateThread(&thread->thrdHandle,thrd, arg,stacksize,tId)!= ROK)
      || (thread->thrdHandle == NULLP))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS184, (ErrVal)thread, 
                                         "Could not create thread");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of SGetThread */


/*
*
*       Fun:   SPutThread
*
*       Desc:  Destroy a thread of execution
*
*       Ret:   Does not return
*
*       Notes: SPutThread must be called by the same thread which 
*              is being freed. It is assumed that all shared resources
*              (i.e. mutexes, etc) have been freed prior to this call.
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SPutThread
(
SThrdId tId                /* thread function id */
)
#else
PUBLIC S16 SPutThread(tId)
SThrdId tId;               /* thread function id */
#endif
{
   SsThrdEntry *thrd;

   TRC1(SPutThread)

   thrd = (SsThrdEntry *)tId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thrd == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS185, ERRZERO, "Invalid thread ID");
      RETVALUE(RFAILED);
   }
#endif

   nsExitThread(0);

   RETVALUE(ROK);

} /* end of SPutThread */


/*
*
*       Fun:   SThreadYield
*
*       Desc:  Yield to another thread of equal or higher priority
*
*       Ret:   Void
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC INLINE Void SThreadYield
(
void
)
#else
PUBLIC INLINE Void SThreadYield()
#endif
{
   TRC1(SThreadYield)
   
   nsThreadYield();

   RETVOID;

} /* end of SThreadYield */


/*
*
*       Fun:   SThreadExit
*
*       Desc:  Let a thread exit
*
*       Ret:   Does not return
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC Void SThreadExit
(
Ptr *status                     /* exit status */
)
#else
PUBLIC Void SThreadExit(status)
Ptr *status;                   /* exit status */
#endif
{
   TRC1(SThreadExit)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (status == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS186, ERRZERO, "Null status pointer");
      RETVOID;
   }
#endif

   nsExitThread(*(U32 *)status);

   RETVOID;

} /* end of SThreadExit */


/*
*
*       Fun:   SSetThrdPrior
*
*       Desc:  Set a thread's priority
*
*       Ret:   Void
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC Void SSetThrdPrior
(
SThrdId tId,                   /* thread id */
S32 tPr                        /* new priority  */
)
#else
PUBLIC Void SSetThrdPrior(tId, tPr)
SThrdId tId;                   /* thread id */
S32 tPr;                       /* new priority */
#endif
{
   SsThrdEntry *thrd;
   /* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   U8          wPrior;
#else /* SS_WINCE */
   U16          wPrior;
#endif /* SS_WINCE */

   TRC1(SSetThrdPrior)

   thrd = (SsThrdEntry *)tId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thrd == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS187, ERRZERO, "Invalid thread ID");
      RETVOID;
   }
#endif

   /* Do a priority mapping for windows NT */
   wPrior = osCp.dep.wPriorLookup[tPr];

   nsSetThreadPriority(&thrd->thrdHandle, wPrior);
   thrd->prior = tPr;

   RETVOID;

} /* end of SSetThrdPrior */


/*
*
*       Fun:   SGetThrdPrior
*
*       Desc:  Get a thread's priority
*
*       Ret:   Void
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC Void SGetThrdPrior
(
SThrdId tId,                    /* thread id */
S32 *tPr                        /* priority (returned) */
)
#else
PUBLIC Void SGetThrdPrior(tId, tPr)
SThrdId tId;                    /* thread id */
S32 *tPr;                       /* priority (returned) */
#endif
{
   SsThrdEntry *thrd;

   TRC1(SGetThrdPrior)

   thrd = (SsThrdEntry *)tId;

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (thrd == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS188, tId, "Invalid thread ID");
      RETVOID;
   }

   if (tPr == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS189, tPr, "Null pointer");
      RETVOID;
   }
#endif

   *tPr = thrd->prior;

   RETVOID;

} /* end of SGetThrdPrior */



/*
*
*       Fun:   SThrdSelf
*
*       Desc:  Get the current thread ID.
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC S16 SThrdSelf
(
SThrdId *tId                   /* thead ID (returned) */
)
#else
PUBLIC S16 SThrdSelf(tId)
SThrdId *tId;                  /* thead ID (returned) */
#endif
{
   TRC1(SThrdSelf)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (tId == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS190, ERRZERO, "Invalid thread Id");
      RETVALUE(RFAILED);
   }
#endif

   *tId = (SThrdId)nsGetCurrentThread();

   RETVALUE(ROK);

} /* end of SThrdSelf */

#endif /* SS_OLD_THREAD */




/*
*
*       Fun:   Deinitialize task table
*
*       Desc:  This function deinitializes Windows-specific information
*              in the task table
*
*       Ret:   void
*
*       Notes:
*
*       File:   np_task.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitTsk
(
void
)
#else
PUBLIC Void ssdDeinitTsk()
#endif
{
   TRC0(ssdDeinitTsk)

   RETVOID;
} /* end of ssdDeinitTsk */


#ifdef SS_DRVR_SUPPORT

/*
*
*       Func:  ssdDeinitDrvr
*
*       Desc:  This function deinitializes Windows-specific information
*              in the driver task table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  np_task.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitDrvr
(
void
)
#else
PUBLIC Void ssdDeinitDrvr()
#endif
{
   TRC0(ssdDeinitDrvr)


   RETVOID;

} /* end of ssdDeinitDrvr */
#endif /* SS_DRVR_SUPPORT */


/********************************************************************30**
  
         End of file: np_task.c 1.2  -  08/17/98 11:56:40
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release
  
1.2          ---      ag   1. Fixed a bug for nsScanInt for multi-
                              threaded case
             ---      ag   2. Added function nsProcessMsg and 
                              modified function sTskHandler to wait
                              on event(s) in single-threaded case
             ---      ag   3. Moved function ssdInitDrvr from 
                              np_gen.c to this file
             ---      ag   4. Fixed function SThrdSelf
             ---      bsr  5. Initializing tId to 0 in the functions
                              sspthreadCreate, ssdCreateSTsk, and
                              SGetThread
             ---      bsr  6. Allocating and freeing memory for mutexes and
                              conds for kernel space in the functions
                              SGetMutex, SGetCond, SPutMutex and SPutCond.
             ---      bsr  7. Added ssdDeinitTsk and ssdDeinitDrvr
             ---      kr   8. Changed sTskHandler to handle the 
                              events in correct priority for single 
                              threaded case
             ---      bsr  9. Deleted ssdDeregInitTskTmr
             ---      sn  10. Modifications to C++ compile
1.2+         ns002.12 jn  11. In the 'nsProcessMsg' for message type of
                              SS_EVNT_DTATA, the Post Structure passed 
                              as a parameter in
                              the activation function is not allocated on 
                              the stack. Instead it directly points to 
                              the 'SsMsgInfo' structure in the message 
                              (which contains the post structure ). This
                              causes a problem in the protocol layers - 
                              the contents of the message are unpacked
                              into stack variables, the message is released
                              and then the function is called with the 
                              Post structure as one of the paramters. The
                              post structure is no longer valid as the
                              message in which it is contained has been
                              freed. 
                              The post structure is now allocated on stack
                              and copied from the SsMsgInfo structure in the
                              message before invoking the activation 
                              function.
             ns004.12 bdu 12. Added SInitSemaphore, SWaitSemaphore,
                              SPostSemaphore, SDestroySemaphore.
             ns005.12 bdu 13. Added Thread Yield Logic for Permanent Task
             ns006.12 jjn 14. Thread Yield Logic should be only applied to
                              User Space.
            ns007.102 bdu 15. Fix a bug in nsProcessMsg.
	    ns010.102 bjp 16. Create CONRD macro, define to disable
	                      console reading
            ns011.102 bjp 17. Modification to protect nxtSTskEntry in
	                        nsProcessMsg
1.2+        ns013.102 bjp  1. Modification to fix bug in 
                              sspthreadAttrGetStackSize
1.2+        ns015.102 bjp  1. Modification to handle all message passing
                              via signals in single threaded mode
                           2. Modification of sTskHandler to process total
                              demand queue size when message event signaled
1.2+        ns016.102 bjp  1. Modification for Windows CE Support
*********************************************************************91*/
