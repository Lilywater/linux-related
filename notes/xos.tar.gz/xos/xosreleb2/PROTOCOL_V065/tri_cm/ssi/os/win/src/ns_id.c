/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services 
  
     Type:     C Source Code.
  
     Desc:     Product Id file
 
     File:     ns_id.c

     Sid:      ns_id.c 1.2  -  08/11/98 12:02:45
  
     Prg:      ag
  
*********************************************************************21*/


  
/* header include files (.h) */
  
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
  
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
  
/* header/extern include files (.x) */
  
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */
  
/* defines */
  
#define NSSWMV 1              /* NTSS - main version */
#define NSSWMR 2              /* NTSS - main revision */
#define NSSWBV 0              /* NTSS - branch version */
#define NSSWBR 18             /* NTSS - branch revision */
#define NSSWPN "1078002"      /* NTSS - part number */
  
/* public variable declarations */
  
/* copyright banner */
  
PUBLIC CONSTANT Txt nsBan1[] ={"(c) COPYRIGHT 1989-1998, Trillium Digital Systems, Inc."};
PUBLIC CONSTANT Txt nsBan2[] ={"                 All rights reserved."};
  
/* system id */
  
PRIVATE CONSTANT SystemId nsSId ={
   NSSWMV,                    /* main version */
   NSSWMR,                    /* main revision */
   NSSWBV,                    /* branch version */
   NSSWBR,                    /* branch revision */
   NSSWPN,                    /* part number */
};

  
/*
*     support functions
*/

/*
*
*       Fun:   nsGetSId
*
*       Desc:  Get system id consisting of part number, main version and
*              revision and branch version and branch.
*
*       Ret:   ROK - ok
*
*       Notes: None
*
*       File:  ns_id.c
*
*/
#ifdef ANSI
PUBLIC S16 nsGetSId
(
SystemId *s                 /* system id */
)
#else
PUBLIC S16 nsGetSId(s)
SystemId *s;                /* system id */
#endif
{
   TRC2(nsGetSId)
   s->mVer = nsSId.mVer;
   s->mRev = nsSId.mRev;
   s->bVer = nsSId.bVer;
   s->bRev = nsSId.bRev;
   s->ptNmb = nsSId.ptNmb;

   RETVALUE(ROK);

} /* end of nsGetSId */
  

/********************************************************************30**

         End of file: ns_id.c 1.2  -  08/11/98 12:02:45

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**
 
    ver       pat    init                  description
------------ -------- ---- -----------------------------------------------
1.1          ---      ag   1. initial release.

1.2          ---      bsr  1. Updated minor version number
                      bdu  1. branch revision for ns007.102
		      bdu  1. branch revision for ns008.102
                      bp   1. branch revision for ns009.102
		      bjp  1. branch revision for ns010.102
		      bjp  1. branch revision for ns011.102
		      bjp  1. branch revision for ns012.102
                      bjp  1. branch revision for ns013.102
                      bjp  1. branch revision for ns014.102
                      bjp  1. branch revision for ns015.102
                      bjp  1. branch revision for ns016.102
                      bjp  1. branch revision for ns017.102
                      bn   1. branch revision for ns018.102
 *********************************************************************91*/
