/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     VxWorks -- implementation specific definitions

     Type:     C include file

     Desc:     Various macro definitions demanded by systems services.
               The contents of these are for the VxWorks implementation.

     File:     vw_ss.h

     Sid:      vw_ss.h 1.1  -  12/28/98 12:38:33

     Prg:      kp

*********************************************************************21*/


#ifndef __VWSSH__
#define __VWSSH__


/* --- interface to SS --- */

/* general */
#define SS_PROC_ID                      0 /*chendh 1*/

/* task related */
#define SS_MAX_ENT                      255
#define SS_MAX_INST                     8

#define SS_MAX_TTSKS                    30
#define SS_MAX_STSKS                    30

#ifdef SS_DRVR_SUPPORT
#define SS_MAX_DRVRTSKS                 70
#endif

#define SS_MAX_RTRTSKS                  255

/* vw022.201 - Addition of vxworks priority range */
#define VW_LOWEST_STSK_PRIOR            255
#define VW_HIGHEST_STSK_PRIOR           0

/* timer related */
#define SS_MAX_TMRS                     45


/* memory pools */
/* vw024.201 - Modification for REGION2 support */
#define SS_MAX_REGS			3

#define SS_MAX_POOLS_PER_REG            5
#define SS_DATA_CACHE                   0
#define SS_INSTRUCTION_CACHE            1
#define SS_B_CACHE                      2

/* locks */
#define SS_STSKTBL_LOCK                 SS_LOCK_MUTEX
#define SS_STSKENTRY_LOCK               SS_LOCK_MUTEX
#define SS_TMRTBL_LOCK                  SS_LOCK_MUTEX
#define SS_DMNDQ_LOCK                   SS_LOCK_MUTEX
#define SS_DRVRENTRY_LOCK               SS_LOCK_MUTEX
#define SS_RTRENTRY_LOCK                SS_LOCK_MUTEX


/* types needed by common SSI code */
#define SsSemaId                        SEM_ID
#define SLockId                         SEM_ID


/* calls needed by common SSI code */

/* vw028.201 - Addition of SThreadYield() to yield the CPU */
#ifndef VW_YIELD_TICKS
#define VW_YIELD_TICKS 1
#endif  /* VW_YIELD_TICKS */
#define SThreadYield() taskDelay(VW_YIELD_TICKS)

/* vw027.201 - Addition of optional priority inversion */
#ifdef SS_PRIORITY_INVERSION
#define SInitLock(l, t) \
   ((*l = semMCreate(SEM_Q_PRIORITY)) == NULL ? \
      RFAILED : ROK)
#else /* protected from priority inversion */
#define SInitLock(l, t) \
   ((*l = semMCreate(SEM_Q_PRIORITY | SEM_INVERSION_SAFE)) == NULL ? \
      RFAILED : ROK)
#endif /* SS_PRIORITY_INVERSION */
#define SLock(l) \
   ((semTake(*l, (intContext() ? NO_WAIT : WAIT_FOREVER)))== OK ? ROK : RFAILED)
#define SUnlock(l) \
   ((semGive(*l)) == OK ? ROK : RFAILED)
#define SDestroyLock(l) \
   ((semTake(*l, (intContext() ? NO_WAIT : WAIT_FOREVER))) != OK ? \
      RFAILED : ((semDelete(*l)) == OK ? ROK : RFAILED))

#define ssInitSema(s, c) \
   ((*s = semCCreate(SEM_Q_PRIORITY, c)) == NULL ? RFAILED : ROK)
#define ssWaitSema(s) \
   ((semTake(*s, (intContext() ? NO_WAIT : WAIT_FOREVER)))== OK ? ROK : RFAILED)
#define ssPostSema(s) \
   ((semGive(*s)) == OK ? ROK : RFAILED)
#define ssDestroySema(s) \
   ((semDelete(*s)) == OK ? ROK : RFAILED)

#if 1 /* vw019.21: Addition */
#define SInitSemaphore(s, c) \
   ((*s = semCCreate(SEM_Q_PRIORITY, c)) == NULL ? RFAILED : ROK)
#define SWaitSemaphore(s) \
   ((semTake(*s, (intContext() ? NO_WAIT : WAIT_FOREVER)))== OK ? ROK : RFAILED)
#define SPostSemaphore(s) \
   ((semGive(*s)) == OK ? ROK : RFAILED)
#define SDestroySemaphore(s) \
   ((semDelete(*s)) == OK ? ROK : RFAILED)
#endif /* vw019.21: Addition */

#define SS_CHECK_CUR_STSK(t)            (taskIdSelf() == (t)->dep.tId)


#define ssdPstTsk(p, m, t)
/* calls needed by message functions */
#define SMemCpy(d,s,c)  memcpy(d,s,c)
#define SMemSet(s,c,n)  memset(s,c,n)


/* --- internal to VxWorks-SSI --- */


/* interrupt service action flags */
#define VW_IS_SET               0
#define VW_IS_UNSET             1
#define VW_IS_RESET             2


/* Timeslice for round-robin scheduling. This is zero by
 *  default to support tight coupling with current
 *  Trillium software (which doesn't use the new tasking
 *  calls yet). If you're running loosely coupled on all
 *  layers, or you're using the new tasking calls to set
 *  up your stack (_not_ SRegActvTsk()), then you can set
 *  this to something like:
 *      osCp.dep.tmrMultipler
 *  Turning on round-robin scheduling seems to increase
 *  performance quite a bit. Everything still works fine
 *  with this at zero though. Probably safer to test with
 *  zero first and increase later...
 */
#define VW_TIMESLICE            0


/* System task priorities--low and high. Used by permanent
 *  tasks (low) and normal tasks (high).
 */
#define VW_TASK_PRIORITY_LOW    150
#define VW_TASK_PRIORITY_HIGH   160


/* Interrupt service task priority */
#define VW_ISTASK_PRIORITY      150

/* Timer task priority */
#define VW_TMRTASK_PRIORITY     VW_TASK_PRIORITY_LOW

/* vw023.201 - Addition of macro for system ticks per second */
/* default ticks per second for system clock */
/* limited by SYS_CLK_RATE_MIN and SYS_CLK_RATE_MAX in config.h */
#define VW_CLK_SYS_RATE		1000	/* 1 millisecond resolution */
	
/* stack size of the VxWorks task handler */
#if 0  /* vw019.21: Deletion */
#define VW_TASK_STACK           20000
#else  /* vw019.21: Addition */
#define VW_TASK_STACK           90000
#endif /* vw019.21: Addition */

/* stack size of the VxWorks IS task handler */
#define VW_ISTASK_STACK         5000

/* stack size of the VxWorks timer handler */
#if 0  /* vw019.21: Deletion */
#define VW_TMRTASK_STACK        5000
#else  /* vw019.21: Addition */
#define VW_TMRTASK_STACK        20000
#endif /* vw019.21: Addition */


/* # of messages in the IS task handler queue */
#define VW_MAX_ISTSK_MSGS       100

/* # of messages in the timer handler queue */
#define VW_MAX_TMRTSK_MSGS      100



/* memory block sizes and counts for memory manager configuration */
#define VW_MBUF_NMB_BUFS        3500            /* (SsMblk + SsDblk +   */
#define VW_MBUF_DSIZE           80              /*  SsMsgInfo)          */

#define VW_DBUF_NMB_BUFS        3500            /* data buffers for the */
#define VW_DBUF_DSIZE           256             /* message              */


/* memory pool data size definitions for pool-to-size mapping table */
#define VW_POOL_3_DSIZE         (VW_DBUF_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_2_DSIZE         (VW_DBUF_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_1_DSIZE         (VW_DBUF_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_0_DSIZE         (VW_DBUF_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))


/* memory size used for heap by the memory manager (512KB) */
#define VW_HEAP_SIZE            524288U


/* memory region size, allocated and passed to memory manager */
#define VW_MEM_REG_SIZE         (VW_HEAP_SIZE + \
                                 (VW_MBUF_NMB_BUFS * VW_MBUF_DSIZE) + \
                                 (VW_DBUF_NMB_BUFS * VW_DBUF_DSIZE))

/* vw024.201 - Modification for configuring REGION1 */
/* Memory configuration for REGION1 support */
/* memory block sizes and counts for memory manager configuration */
#define VW_MBUF_NMB_BUFS_REG1   3500            /* (SsMblk + SsDblk +   */
#define VW_MBUF_DSIZE_REG1      80              /*  SsMsgInfo)          */

#define VW_DBUF_NMB_BUFS_REG1   3500            /* data buffers for the */
#define VW_DBUF_DSIZE_REG1      256             /* message              */


/* memory pool data size definitions for pool-to-size mapping table */
#define VW_POOL_3_DSIZE_REG1     (VW_DBUF_DSIZE_REG1-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_2_DSIZE_REG1     (VW_DBUF_DSIZE_REG1-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_1_DSIZE_REG1     (VW_DBUF_DSIZE_REG1-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_0_DSIZE_REG1     (VW_DBUF_DSIZE_REG1-(sizeof(SsMblk)+sizeof(SsDblk)))


/* memory size used for heap by the memory manager (512KB) */
#define VW_HEAP_REG1_SIZE            921152U


/* memory region size, allocated and passed to memory manager */
/* Default local bus size is 921152 + 3500*80 + 3500*256 = 0x200000 Bytes */
#define VW_MEM_REG1_SIZE         (VW_HEAP_REG1_SIZE + \
                                 (VW_MBUF_NMB_BUFS_REG1 * VW_MBUF_DSIZE_REG1) + \
                                 (VW_DBUF_NMB_BUFS_REG1 * VW_DBUF_DSIZE_REG1))

/* vw024.201 - Addition for REGION2 support */
/* Memory configuration for REGION2 support */
/* memory block sizes and counts for memory manager configuration */
#define VW_MBUF_NMB_BUFS_REG2   3500            /* (SsMblk + SsDblk +   */
#define VW_MBUF_DSIZE_REG2      80              /*  SsMsgInfo)          */

#define VW_DBUF_NMB_BUFS_REG2   3500            /* data buffers for the */
#define VW_DBUF_DSIZE_REG2      256             /* message              */


/* memory pool data size definitions for pool-to-size mapping table */
#define VW_POOL_3_DSIZE_REG2     (VW_DBUF_DSIZE_REG2-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_2_DSIZE_REG2     (VW_DBUF_DSIZE_REG2-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_1_DSIZE_REG2     (VW_DBUF_DSIZE_REG2-(sizeof(SsMblk)+sizeof(SsDblk)))
#define VW_POOL_0_DSIZE_REG2     (VW_DBUF_DSIZE_REG2-(sizeof(SsMblk)+sizeof(SsDblk)))


/* memory size used for heap by the memory manager (512KB) */
#define VW_HEAP_REG2_SIZE            921152U


/* memory region size, allocated and passed to memory manager */
/* Default local bus size is 921152 + 3500*80 + 3500*256 = 0x200000 Bytes */
#define VW_MEM_REG2_SIZE         (VW_HEAP_REG2_SIZE + \
                                 (VW_MBUF_NMB_BUFS_REG2 * VW_MBUF_DSIZE_REG2) + \
                                 (VW_DBUF_NMB_BUFS_REG2 * VW_DBUF_DSIZE_REG2))

#define VW_MEM_REG2_ADDR         0x4000000 /* Local bus addr on 8260 board */

	
#ifdef SS_AEHDPR_SUPPORT

/* isr-dpr related */
#define MAX_VECT_NUM             128

#define MAX_DPR_PRIORITY         32

#define MAX_RING_BUF_LEN         2000

#ifdef PQ_PPC860
/* bits in CIMR register */
#define CIMR_REG                 0x948

/* Interrupt vector numbers */
#ifndef IV_SCC1
#define IV_SCC1                  0x3E
#endif

#ifndef IV_SCC2
#define IV_SCC2                  0x3D
#endif

#ifndef IV_SCC3
#define IV_SCC3                  0x3C
#endif

#ifndef IV_SCC4
#define IV_SCC4                  0x3B
#endif


#ifndef IV_IDMA1
#define IV_IDMA1                 0x35
#endif

/* calls needed by common SSI code */
#define VECT_TO_PRIORITY(pr) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC2: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC3: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC4: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_IDMA1: \
         { \
            pr = 150; \
            break; \
         } \
         default: \
         { \
            pr = 0xFF; \
         } \
      } \
   }

/* create the DPR table which has its index mapped to priority and
 * starts from zeroth position.Thus it avoids the hole in array,had array's
 * index exactly replicated priority value.So there is no need to have
 * length of the array equal to maximum priority supported for VxWorks(255).
 * And since only 5 interrupts(CPM interrupts like SCC1,SCC2,SCC3,SCC4 and/or
 * IDMA1 ) are likely to occur at any time ,then this would have meant wastage
 * of memory as well to have priority equals to the array index.Instead
 * priority has to be mapped in a way that there is no wastage of memory and
 * also reflects direct proportionality to the priority.This VECT_TO_INDEX can
 * be made even more intelligent which is upto every user's discreetion
 * NOTE:- You can have one DPR thread/task to handle all the sources of
 *        interrups or can have number of DPR threads equal to number of
 *        sources of interrupts or any combination of above.It depends on
 *        dpr_idx.By default all are kept as 0,so that only DPR thread/task
 *        is spawned to handle all the sources of interrupts.You can change
 *        dpr_idx accordingly
*/
#define VECT_TO_INDEX(dpr_idx) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC2: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC3: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC4: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_IDMA1: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         default: \
         { \
            dpr_idx = 0xFF; \
            break; \
         } \
      } \
   }
/* vw016.21: Addition */
#define VECT_TO_IDX(vect_idx) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            vect_idx = 0; \
            break; \
         } \
         case IV_SCC2: \
         { \
            vect_idx = 1; \
            break; \
         } \
         case IV_SCC3: \
         { \
            vect_idx = 2; \
            break; \
         } \
         case IV_SCC4: \
         { \
            vect_idx = 3; \
            break; \
         } \
         case IV_IDMA1: \
         { \
            vect_idx = 4; \
            break; \
         } \
         default: \
         { \
            vect_idx = 0xFF; \
            break; \
         } \
      } \
   }
/* vw016.21: Addition */

#endif /* end of PQ_PPC860 */

#ifdef SS_PROC_68360
#define CIMR_REG                 0x1548

/* Interrupt vector numbers */
#ifndef IV_SCC1
#define IV_SCC1                  0x5E
#endif

#ifndef IV_SCC2
#define IV_SCC2                  0x5D
#endif

#ifndef IV_SCC3
#define IV_SCC3                  0x5C
#endif

#ifndef IV_SCC4
#define IV_SCC4                  0x5B
#endif

/* calls needed by common SSI code */
#define VECT_TO_PRIORITY(pr) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC2: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC3: \
         { \
            pr = 150; \
            break; \
         } \
         case IV_SCC4: \
         { \
            pr = 150; \
            break; \
         } \
         default: \
         { \
            pr = 0xFF; \
         } \
      } \
   }

/* create the DPR table which has its index mapped to priority and
 * starts from zeroth position.Thus it avoids the hole in array,had array's
 * index exactly replicated priority value.So there is no need to have
 * length of the array equal to maximum priority supported for VxWorks(255).
 * And since only 4 interrupts(CPM interrupts like SCC1,SCC2,SCC3 and SCC4)
 * are likely to occur at any time ,then this would have meant wastage of
 * memory as well to have priority equals to the array index.Instead priority
 * has to mapped in a way that there is no wastage of memory and also reflects
 * direct proportionality to the priority.This VECT_TO_INDEX can be made even
 * more intelligent which is upto every user's discreetion
 * NOTE:- You can have one DPR thread/task to handle all the sources of
 *        interrups or can have number of DPR threads equal to number of
 *        sources of interrupts or any combination of above.It depends on
 *        dpr_idx.By default all are kept as 0,so that only DPR thread/task
 *        is spawned to handle all the sources of interrupts.You can change
 *        dpr_idx accordingly
*/
#define VECT_TO_INDEX(dpr_idx) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC2: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC3: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case IV_SCC4: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         default: \
         { \
            dpr_idx = 0xFF; \
            break; \
         } \
      } \
   }

/* vw017.21: Addition */
#define VECT_TO_IDX(vect_idx) \
   { \
      switch (vectNmb) \
      { \
         case IV_SCC1: \
         { \
            vect_idx = 0; \
            break; \
         } \
         case IV_SCC2: \
         { \
            vect_idx = 1; \
            break; \
         } \
         case IV_SCC3: \
         { \
            vect_idx = 2; \
            break; \
         } \
         case IV_SCC4: \
         { \
            vect_idx = 3; \
            break; \
         } \
         default: \
         { \
            vect_idx = 0xFF; \
            break; \
         } \
      } \
   }

#endif /* end of SS_PROC_68360 */


/* vw012.21 - added support for the 8260 driver */
#ifdef SS_PROC_8260

#define MAX_DPR_QUEUE            256

#define ssdPutDprQueue(qid, vectNmb, err) \
   { \
      Dpr *q; \
      q = &sDprTbl[qid]; \
      q->qbody[q->qtail] = vectNmb; \
      q->qtail = (q->qtail + 1) % MAX_DPR_QUEUE; \
      if (q->qhead == q->qtail) \
      { \
         q->qhead = (q->qhead + 1) % MAX_DPR_QUEUE; \
         err = TRUE; \
      } \
      else \
      { \
         err = FALSE; \
      } \
   }

#define ssdGetDprQueue(qid, vectNmb) \
   { \
      Dpr *q; \
      q = &sDprTbl[qid]; \
      if (q->qhead != q->qtail) \
      { \
         vectNmb = q->qbody[q->qhead]; \
         q->qhead = (q->qhead + 1) % MAX_DPR_QUEUE; \
      } \
      else \
      { \
         vectNmb = 0xFF; \
      } \
   }

#define ISR_ENB_INT_8260 \
   ASM(" mfmsr r9"); \
   ASM(" ori r9,r9,0x8000"); \
   ASM(" mtmsr r9");

#define ISR_DIS_INT_8260 \
   ASM(" mfmsr r9"); \
   ASM(" andi. r9,r9,0x7FFF"); \
   ASM(" mtmsr r9");

/* 8260 Interrupt vector numbers */
#define SSIV_FCC1                0x20
#define SSIV_FCC2                0x21
#define SSIV_FCC3                0x22
#define SSIV_MCC1                0x24
#define SSIV_MCC2                0x25
#define SSIV_SCC1                0x28
#define SSIV_SCC2                0x29
#define SSIV_SCC3                0x2a
#define SSIV_SCC4                0x2b
/* vw029.201 - Addition of 8264 support */
#ifdef SS_8264_SUPPORT
#define SSIV_TC                  0x2c
#endif /* SS_8264_SUPPORT */

/* Port C interrupts used for NMSI xCCs */
#define SSIV_PC(n)               (0x3f-n)
#define SSIV_IS_PC(v)            ((v >= 0x30) && (v <= 0x3f))

/* vw029.201 - Addition of 8264 support */
#ifndef SS_8264_SUPPORT
/* calls needed by common SSI code */
#define VECT_TO_PRIORITY(pr) \
   { \
      switch (vectNmb) \
      { \
         case SSIV_FCC1: case SSIV_FCC2: \
         { \
            pr = 50; \
            break; \
         } \
         case SSIV_FCC3: \
         { \
            pr = 60; \
            break; \
         } \
         case SSIV_MCC1: case SSIV_MCC2: \
         { \
            pr = 70; \
            break; \
         } \
         case SSIV_SCC1: case SSIV_SCC2: case SSIV_SCC3: case SSIV_SCC4: \
         { \
            pr = 80; \
            break; \
         } \
         default: \
         { \
            if (SSIV_IS_PC(vectNmb)) \
            { \
               pr = 90; \
            } \
            else \
            { \
               pr = 0xFF; \
            } \
         } \
      } \
   }

/* Create the DPR table which has its index mapped to priority
 * NOTE:- You can have one DPR thread/task to handle all the sources of
 *        interrupts or can have number of DPR threads equal to number of
 *        sources of interrupts or any combination of above. It depends on
 *        dpr_idx. The default mapping here is specified for optimum
 *        performance.
 */
#define VECT_TO_INDEX(dpr_idx) \
   { \
      switch (vectNmb) \
      { \
         case SSIV_FCC1: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case SSIV_FCC2: \
         { \
            dpr_idx = 1; \
            break; \
         } \
         case SSIV_FCC3: \
         { \
            dpr_idx = 2; \
            break; \
         } \
         case SSIV_MCC1: \
         { \
            dpr_idx = 3; \
            break; \
         } \
         case SSIV_MCC2: \
         { \
            dpr_idx = 4; \
            break; \
         } \
         case SSIV_SCC1: case SSIV_SCC2: case SSIV_SCC3: case SSIV_SCC4: \
         { \
            dpr_idx = 5; \
            break; \
         } \
         default: \
         { \
            if (SSIV_IS_PC(vectNmb)) \
            { \
               dpr_idx = 6; \
            } \
            else \
            { \
               dpr_idx = 0xFF; \
            } \
         } \
      } \
   }

#else /* SS_8264_SUPPORT */

/* calls needed by common SSI code */
#define VECT_TO_PRIORITY(pr) \
   { \
      switch (vectNmb) \
      { \
         case SSIV_FCC1: case SSIV_FCC2: \
         { \
            pr = 50; \
            break; \
         } \
         case SSIV_FCC3: \
         { \
            pr = 60; \
            break; \
         } \
         case SSIV_MCC1: case SSIV_MCC2: \
         { \
            pr = 70; \
            break; \
         } \
         case SSIV_SCC1: case SSIV_SCC2: case SSIV_SCC3: case SSIV_SCC4: \
         { \
            pr = 80; \
            break; \
         } \
         case SSIV_TC: \
         { \
            pr = 80; \
            break; \
         } \
         default: \
         { \
            if (SSIV_IS_PC(vectNmb)) \
            { \
               pr = 90; \
            } \
            else \
            { \
               pr = 0xFF; \
            } \
         } \
      } \
   }

/* Create the DPR table which has its index mapped to priority
 * NOTE:- You can have one DPR thread/task to handle all the sources of
 *        interrupts or can have number of DPR threads equal to number of
 *        sources of interrupts or any combination of above. It depends on
 *        dpr_idx. The default mapping here is specified for optimum
 *        performance.
 */
#define VECT_TO_INDEX(dpr_idx) \
   { \
      switch (vectNmb) \
      { \
         case SSIV_FCC1: \
         { \
            dpr_idx = 0; \
            break; \
         } \
         case SSIV_FCC2: \
         { \
            dpr_idx = 1; \
            break; \
         } \
         case SSIV_FCC3: \
         { \
            dpr_idx = 2; \
            break; \
         } \
         case SSIV_MCC1: \
         { \
            dpr_idx = 3; \
            break; \
         } \
         case SSIV_MCC2: \
         { \
            dpr_idx = 4; \
            break; \
         } \
         case SSIV_SCC1: case SSIV_SCC2: case SSIV_SCC3: case SSIV_SCC4: \
         { \
            dpr_idx = 5; \
            break; \
         } \
         case SSIV_TC: \
         { \
            dpr_idx = 7; \
            break; \
         } \
         default: \
         { \
            if (SSIV_IS_PC(vectNmb)) \
            { \
               dpr_idx = 6; \
            } \
            else \
            { \
               dpr_idx = 0xFF; \
            } \
         } \
      } \
   }
#endif /* SS_8264_SUPPORT */

/* vw017.21: Addition */
#define VECT_TO_IDX(vect_idx) \
   { \
      switch (vectNmb) \
      { \
         case SSIV_FCC1: \
         { \
            vect_idx = 0; \
            break; \
         } \
         case SSIV_FCC2: \
         { \
            vect_idx = 1; \
            break; \
         } \
         case SSIV_FCC3: \
         { \
            vect_idx = 2; \
            break; \
         } \
         case SSIV_MCC1: \
         { \
            vect_idx = 3; \
            break; \
         } \
         case SSIV_MCC2: \
         { \
            vect_idx = 4; \
            break; \
         } \
         case SSIV_SCC1: \
         { \
            vect_idx = 5; \
            break; \
         } \
         case SSIV_SCC2: \
         { \
            vect_idx = 6; \
            break; \
         } \
         case SSIV_SCC3: \
         { \
            vect_idx = 7; \
            break; \
         } \
         case SSIV_SCC4: \
         { \
            vect_idx = 8; \
            break; \
         } \
         default: \
         { \
            vect_idx = 0xFF; \
            break; \
         } \
      } \
   }

#endif /* end of SS_PROC_8260 */

/* types needed by common SSI code */
#define SsRingId            RING_ID
#define INVALID             FALSE

#endif /* SS_AEHDPR_SUPPORT */

#endif  /*  __VWSSH__  */



/********************************************************************30**

         End of file: vw_ss.h 1.1  -  12/28/98 12:38:33

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. initial release

1.1+         vw003.21 ada  1. Changed timer task priority from 160 (low)
                              to the normal task priority. In case of
                              single threaded option, the timer task
                              was getting starved.
             vw005.21 jn   2. Defined Macros SMemCpy & SMemSet for
                              multiple byte copy
             vw007.21 vrp  3. Added support for 68360 (SSetAehDpr)
             vw010.21 vrp  4. Reshuffled the code under SS_AEHDPR_SUPPORT
                              in order to give more portability so that
                              there are different ifdef flags for
                              PQ_PPC860,SS_PROC_68360
             vw011.21 jn   5. Added the macro SS_MAX_RTRTSTS to 255
             vw012.21 ada  6. Cleaned up patches for new code base
                      ada  7. Added MPC8260 driver support in SS_PROC_8260
                              section
                      ada  8. Changed SS_MAX_TMRS to 45
             vw014.21 jn   9. Changed SS_MAX_REGS to 2
                              Added the following macros:
                              SS_REGION1, SS_DATA_CACHE, SS_INSTRUCTION_CACHE,
                              SS_B_CACHE, VW_MEM_REG1_SIZE.
             vw016.21 jn  10. Added the VECT_TO_IDX to map the vector number
                              to zero based array.
             vw017.21 jn  10. Added the VECT_TO_IDX to map the vector number
                              to zero based array for SS_PROC_68360 and 
                              SS_PROC_8260.
             vw019.21 bdu 11. Added the following functions:
                              SInitSemaphore, SWaitSemaphore, SPostSemaphore,
                              SDestroySemaphore.
                              Increased the stack sizes.
            vw022.201 bjp 12. Added macros for VW_LOWEST_STSK_PRIOR and 
	                      VW_HIGHEST_STSK_PRIOR
            vw023.201 bjp 13. Add macro for VW_CLK_SYS_RATE
	                      Bug fix for region 1 support
            vw024.201 bjp 14. Add support for REGION2
	                      Modify memory configuration for REGION1
            vw027.201 zo  15. Added optional priority inversion protection
            vw028.201 zo  16. Added SThreadYield() for manual task rescheduling
            vw029.201 bjp  1. Addition of SS_8264_SUPPORT
*********************************************************************91*/
