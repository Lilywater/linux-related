/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     C Source Code.
  
     Desc:     Timer Management Functions
 
     File:     np_timer.c

     Sid:      np_timer.c 1.2  -  08/17/98 11:56:46
  
     Prg:      bsr
  
*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_strm.h"       /* STREAMS */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */




/* private variables */

PRIVATE SsTmrEntry   *tmr[NS_MAX_TMRS]; /* timer entry pointers */
PRIVATE U8           cancelledTmrList[NS_MAX_TMRS];


/* ns016.102 - Addition for Windows CE Support */
#ifdef SS_WINCE

/* Extern variables */

/* local defines */


PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayHeader   ARGS((Void));

PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayTail   ARGS((Void));

PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayHeader   ARGS((LPMAP_NODE_INFO header));

PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayTail   ARGS((LPMAP_NODE_INFO tail));

PRIVATE Bool isWaitAbleTimerArrayEmpty   ARGS((Void));

PRIVATE Bool isHeader   ARGS((LPMAP_NODE_INFO pNode));

PRIVATE Bool isTail   ARGS((LPMAP_NODE_INFO pNode));

PRIVATE LPMAP_NODE_INFO allocNode   ARGS((Void));

PRIVATE LPMAP_NODE_INFO addNode   ARGS((LPMapItemINFO pItem));

PRIVATE LPMAP_NODE_INFO findNode   ARGS((HANDLE hTimerEvent));

PRIVATE Void deleteNode   ARGS((LPMAP_NODE_INFO pNode));

PRIVATE Void clearArray   ARGS((Void));

PRIVATE MMRESULT getTimerId   ARGS((HANDLE hWaitableTimerEvent));

PRIVATE HANDLE ceCreateWaitableTimer   ARGS((LPSECURITY_ATTRIBUTES lpTimerAttributes, Bool bManualReset, LPCTSTR lpTimerName));

PRIVATE MMRESULT  ceSetWaitableTimer    ARGS(( 
							HANDLE hTimer,
							const LARGE_INTEGER *pDueTime,          
							LONG lPeriod,
							Void * pfnCompletionRoutine,
							LPVOID lpArgToCompletionRoutine,
							Bool fResume ));

PRIVATE Bool ceCancelWaitableTimer    ARGS((HANDLE hTimer));


/* local typedefs */

/* private variables */
PRIVATE CRITICAL_SECTION gTimerCriticalSec;
PRIVATE Bool bInitilized = FALSE;
PRIVATE LPMAP_NODE_INFO gWaitAbleTimerArrayHeader = NULL;
PRIVATE LPMAP_NODE_INFO gWaitAbleTimerArrayTail = NULL;
PRIVATE TIMECAPS g_tc;


/*
	gWaitAbleTimerArrayHeader/gWaitAbleTimerArrayTail
	These two pointers maintain a data struct like map<Handle of Event,timerId> 
	All the WaitAbleTimerArray subroutines are the helper functions
*/




/*
 *
 *       Fun:   getWaitAbleTimerArrayHeader
 *
 *       Desc:  get the header pointer to the WaitableTimer array
 *              
 *
 *       Ret:   Indicates the header pointer to the WaitableTimer array
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayHeader
(
Void
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayHeader()
#endif  /* ANSI */
{
	RETVALUE( gWaitAbleTimerArrayHeader );

}

/*
 *
 *       Fun:  getWaitAbleTimerArrayTail 
 *
 *       Desc:  get the tail pointer to the WaitableTimer array
 *              
 *
 *       Ret:   Indicates the tail pointer to the WaitableTimer array
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayTail
(
void
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO getWaitAbleTimerArrayTail()
#endif  /* ANSI */
{
	RETVALUE( gWaitAbleTimerArrayTail );
}

/*
 *
 *       Fun:   setWaitAbleTimerArrayHeader
 *
 *       Desc:  Set the header pointer to the WaitableTimer array
 *              
 *
 *       Ret:   the new header pointer to the WaitableTimer array
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayHeader
(
LPMAP_NODE_INFO header
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayHeader(header)
LPMAP_NODE_INFO header;
#endif  /* ANSI */
{
	if(header!=NULLP)
		header->previous = NULLP;
	RETVALUE( (gWaitAbleTimerArrayHeader = header) );
}

/*
 *
 *       Fun:   setWaitAbleTimerArrayTail
 *
 *       Desc:  Set the tail pointer to the WaitableTimer array
 *              
 *
 *       Ret:   the new tail pointer to the WaitableTimer array
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayTail
(
LPMAP_NODE_INFO tail
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO setWaitAbleTimerArrayTail(tail)
LPMAP_NODE_INFO tail;
#endif  /* ANSI */
{

	if(tail!=NULLP)
		tail->next = NULLP;
	RETVALUE( (gWaitAbleTimerArrayTail = tail) );
}

/*
 *
 *       Fun:  isWaitAbleTimerArrayEmpty 
 *
 *       Desc:  Determinte whether the WaitableTimer array is empty
 *              
 *
 *       Ret:   TRUE indicates empty, FALSE indicates not empty
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Bool isWaitAbleTimerArrayEmpty
(
void
)
#else  /* ANSI */
PRIVATE Bool isWaitAbleTimerArrayEmpty()
#endif  /* ANSI */
{
	
	RETVALUE( (getWaitAbleTimerArrayHeader()==NULLP) && (getWaitAbleTimerArrayTail()==NULLP) );
	
}

/*
 *
 *       Fun:   isHeader
 *
 *       Desc:  Determinte whether the input pNode points the header of the WaitableTimer array
 *              
 *
 *       Ret:   TRUE indicates yes, FALSE no
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Bool isHeader
(
LPMAP_NODE_INFO pNode
)
#else  /* ANSI */
PRIVATE Bool isHeader(pNode)
LPMAP_NODE_INFO pNode;
#endif  /* ANSI */
{
	if(pNode)
		RETVALUE( !pNode->previous );
	else
		RETVALUE( TRUE );
}

/*
 *
 *       Fun:   isTail
 *
 *       Desc:  Determinte whether the input pNode points the tail of the WaitableTimer array
 *              
 *
 *       Ret:   TRUE indicates yes, FALSE no
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Bool isTail
(
LPMAP_NODE_INFO pNode
)
#else  /* ANSI */
PRIVATE Bool isTail(pNode)
LPMAP_NODE_INFO pNode;
#endif  /* ANSI */
{
	if(pNode)
		RETVALUE( !pNode->next );
	else
		RETVALUE( TRUE );
}

/*
 *
 *       Fun: allocNode  
 *
 *       Desc:  Allocate a new node object which can be added to the WaitableTimer array
 *              
 *
 *       Ret:   NULLP indicates  failure. A non NULLP value indicates the 
 		pointer to the new allocated MAP_NODE object.
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO allocNode
(
void
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO allocNode()
#endif  /* ANSI */
{
	HLOCAL hAllocated;
	hAllocated = LocalAlloc(LPTR,sizeof(TagMapNode));
	if (hAllocated == NULLP)
		RETVALUE (NULLP);
	else
		RETVALUE( (LPMAP_NODE_INFO)hAllocated );
}

/*
 *
 *       Fun:   addNode
 *
 *       Desc:  Append the input *pItem to the WaitableTimer array
 *              
 *
 *       Ret:   NULLP indicates failure.
 		Non-NULLP value indicates pointer to the new added node object
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO addNode
(
LPMapItemINFO pItem
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO addNode(pItem)
LPMapItemINFO pItem;
#endif  /* ANSI */
{
	LPMAP_NODE_INFO newNode = allocNode();
	
	if( newNode == NULLP)	/*allocNode Failure*/
		RETVALUE( NULLP );
		
	if( pItem == NULLP )	/*Illegal parameter*/
		RETVALUE( NULLP );		
	
	newNode->pItem = pItem;


	if(isWaitAbleTimerArrayEmpty()) /*first time*/
	{
		setWaitAbleTimerArrayHeader(newNode);
		setWaitAbleTimerArrayTail(newNode);
	}
	else
	{
		getWaitAbleTimerArrayTail()->next = newNode;
		newNode->previous = getWaitAbleTimerArrayTail();
		setWaitAbleTimerArrayTail(newNode);
	}

	RETVALUE( newNode );
	
	
}

/*
 *
 *       Fun:   findNode
 *
 *       Desc:  Find the node with input handle of TimerEvent
 *              
 *
 *       Ret:   NULLP indicates no node matches the expected hTimerEvent.
 		A non-NULLP value indicates the pointer to the found node object.
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE LPMAP_NODE_INFO findNode
(
HANDLE hTimerEvent
)
#else  /* ANSI */
PRIVATE LPMAP_NODE_INFO findNode(hTimerEvent)
HANDLE hTimerEvent;
#endif  /* ANSI */
{
	LPMAP_NODE_INFO pNode = NULLP;
	if(isWaitAbleTimerArrayEmpty())
		RETVALUE( NULLP );
	pNode = getWaitAbleTimerArrayHeader();
	while(pNode) {
		if( pNode->pItem->first == hTimerEvent )
		{
			break;
		}
		else
		{
			pNode = pNode->next;
		}

	} ;

	RETVALUE( pNode );
}

/*
 *
 *       Fun:   deleteNode
 *
 *       Desc: Delete the indicated node object from WaitabletimerArray  
 *              
 *
 *       Ret:   No return value
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Void deleteNode
(
LPMAP_NODE_INFO pNode
)
#else  /* ANSI */
PRIVATE Void deleteNode(pNode)
LPMAP_NODE_INFO pNode;
#endif  /* ANSI */
{
	if(!pNode)
		RETVOID;	/*Empty*/

	if(isHeader(pNode) && isTail(pNode))	/*only One Node*/
	{
		setWaitAbleTimerArrayHeader(NULLP);
		setWaitAbleTimerArrayTail(NULLP);
	}
	else if(isHeader(pNode))
	{
		setWaitAbleTimerArrayHeader(pNode->next);
	}
	else if(isTail(pNode))
	{
		setWaitAbleTimerArrayTail(pNode->previous);
	}
	else
	{
		pNode->previous->next = pNode->next;
		pNode->next->previous = pNode->previous;
	}
		
/*
	CloseHandle(pNode->pItem->first);
	timeKillEvent(pNode->pItem->second);
*/


	LocalFree(pNode->pItem);
	pNode->pItem = NULLP;
	LocalFree(pNode);
	pNode = NULLP;
		
}

/*
 *
 *       Fun:   clearArray
 *
 *       Desc:  clear the WaitableTimer Array 
 *              
 *
 *       Ret:  No return value
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Void clearArray
(
void
)
#else  /* ANSI */
PRIVATE Void clearArray()
#endif  /* ANSI */
{
	while(!isWaitAbleTimerArrayEmpty())
	{
		deleteNode(getWaitAbleTimerArrayHeader());
	}
}

/*
 *
 *       Fun:   getTimerId
 *
 *       Desc:  Retrive the timerId with Handle of  the WaitableTimerEvent object
 *              
 *
 *       Ret:   0 indicates no matched timerId
 		A non-zero value indicates the matched timerId
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE MMRESULT getTimerId
(
HANDLE hWaitableTimerEvent
)
#else  /* ANSI */
PRIVATE MMRESULT getTimerId( hWaitableTimerEvent)
HANDLE hWaitableTimerEvent;
#endif  /* ANSI */
{
	LPMAP_NODE_INFO pNode = findNode(hWaitableTimerEvent);
	if(pNode)
	{
		RETVALUE( pNode->pItem->second );
	}
	else
		RETVALUE( 0 );
}





/*
 *
 *       Fun:   ceCreateWaitableTimer
 *
 *       Desc:  An alternative API of CreateWaitableTimer which existed in Win32API
 *              
 *
 *       Ret: NULLP indicates failure,otherwise indicates the HANDLE of created WaitableTimer object  
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE HANDLE ceCreateWaitableTimer
(
LPSECURITY_ATTRIBUTES lpTimerAttributes, 
Bool bManualReset, 
LPCTSTR lpTimerName
)
#else  /* ANSI */
HANDLE ceCreateWaitableTimer(lpTimerAttributes, bManualReset, lpTimerName)
LPSECURITY_ATTRIBUTES lpTimerAttributes;
Bool bManualReset; 
LPCTSTR lpTimerName;
#endif  /* ANSI */
{
	LPMapItemINFO pMapItem;
	HANDLE hWaitableTimerEvent;
	LPMAP_NODE_INFO  lpRet;

	if( !bInitilized )
	{
		InitializeCriticalSection( &gTimerCriticalSec);
		bInitilized  = TRUE;
	}


	hWaitableTimerEvent =  CreateEvent(lpTimerAttributes,bManualReset,FALSE,lpTimerName);
	if(!hWaitableTimerEvent)	/*the Timer has already existed*/
		RETVALUE( NULLP );
	
	pMapItem = NULLP;

	pMapItem = (LPMapItemINFO)LocalAlloc(LPTR,sizeof(TagMapItem));
	if( pMapItem == NULLP)		/*the Item alloced failure*/
		RETVALUE (NULLP);	
	
	pMapItem->first = hWaitableTimerEvent;
	pMapItem->second = 0;

	EnterCriticalSection( &gTimerCriticalSec);
	lpRet = addNode(pMapItem);
	LeaveCriticalSection( &gTimerCriticalSec);
	if( lpRet == NULLP )
		RETVALUE( NULLP );	


	/*Query Max Period*/
	timeGetDevCaps(&g_tc, sizeof(TIMECAPS));
	
	
	RETVALUE( hWaitableTimerEvent );
	
}





/*
 *
 *       Fun:   ceSetWaitableTimer
 *
 *       Desc:  An alternative API of SetWaitableTimer which existed in Win32API
 *              
 *
 *       Ret:  If the function succeeds, the return value is nonzero.

	       If the function fails, the return value is zero. 
	       To get extended error information, call GetLastError.

 
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE MMRESULT  ceSetWaitableTimer    
( 
HANDLE hTimer,
const LARGE_INTEGER *pDueTime,          
LONG lPeriod,
void * pfnCompletionRoutine,
LPVOID lpArgToCompletionRoutine,
Bool fResume
)
#else  /* ANSI */
MMRESULT  ceSetWaitableTimer (hTimer, *pDueTime, lPeriod, pfnCompletionRoutine, lpArgToCompletionRoutine, fResume)
HANDLE hTimer;
const LARGE_INTEGER *pDueTime;          
LONG lPeriod;
void * pfnCompletionRoutine;
LPVOID lpArgToCompletionRoutine;
Bool fResume;
#endif  /* ANSI */
{
	/*assert(abs(*lpDueTime) == (10000*lPeriod));	Assert this function was invoked by NSS applications!*/

	MMRESULT timerId;
	DWORD dwErr;
	LPMAP_NODE_INFO lpMapNode;

	if( !bInitilized )
	{
		InitializeCriticalSection( &gTimerCriticalSec);
		bInitilized  = TRUE;
	}

	if(!hTimer)
		RETVALUE( 0 );
	
	#define DEFAULT_DELAY 100

	/*If Input lPeriod is is not in the range of the minimum and maximum event delays supported by the timer,
	  we use DEFAULT_DELAY instead	*/

	if(lPeriod >= (LONG)g_tc.wPeriodMax || lPeriod <= (LONG)g_tc.wPeriodMin)
		timerId = timeSetEvent(DEFAULT_DELAY,0,(LPTIMECALLBACK)hTimer,0,TIME_PERIODIC|TIME_CALLBACK_EVENT_SET);
	else
		timerId = timeSetEvent(lPeriod,0,(LPTIMECALLBACK)hTimer,0,TIME_PERIODIC|TIME_CALLBACK_EVENT_SET);
	
	if( !timerId ){
		dwErr = GetLastError();
		RETVALUE( 0 );
	}

	EnterCriticalSection( &gTimerCriticalSec);
	lpMapNode = findNode(hTimer);
	if(lpMapNode)
		lpMapNode->pItem->second = timerId;
	LeaveCriticalSection( &gTimerCriticalSec);

	RETVALUE( timerId );

}

/*
 *
 *       Fun:   ceCancelWaitableTimer
 *
 *       Desc:  An alternative API of CancelWaitableTimer which existed in Win32API
 *              
 *
 *       Ret:  If the function succeeds, the return value is nonzero.

	       If the function fails, the return value is zero. 
	       To get extended error information, call GetLastError.
 *
 *       Notes:
 *
         File:  ns_timer.c
 *
 */
#ifdef ANSI
PRIVATE Bool ceCancelWaitableTimer
(
HANDLE hTimer
)
#else  /* ANSI */
Bool ceCancelWaitableTimer(hTimer)
HANDLE hTimer;
#endif  /* ANSI */
{
	MMRESULT timerId;

	if( !bInitilized )
	{
		InitializeCriticalSection( &gTimerCriticalSec);
		bInitilized  = TRUE;
	}

	if(!hTimer)
		RETVALUE( FALSE );

	EnterCriticalSection( &gTimerCriticalSec);
	timerId = getTimerId(hTimer);
	LeaveCriticalSection( &gTimerCriticalSec);


	if(timerId == 0)
		RETVALUE( FALSE );
	if( timeKillEvent(timerId)==TIMERR_NOERROR )
		RETVALUE( TRUE );
	else
		RETVALUE( FALSE );
}
#endif /*SS_WINCE*/


/*
 *
 *       Fun:   nsTimerHandler
 *
 *       Desc:  This function is invoked periodically by the system and it
 *              posts a timer message to the layer.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes:
 *
         File:  np_timer.c
 *
 */
#ifdef ANSI
PUBLIC S16 nsTimerHandler
(
Void *param
)
#else  /* ANSI */
PUBLIC S16 nsTimerHandler(param)
Void *param;
#endif /* ANSI */
{
   SsTmrEntry   *pTmrEntry;
   Buffer       *mBuf;
   SsMsgInfo    *mInfo1;
   SsMsgInfo    *mInfo2;
   SsEventInfo  *eInfo;
   /* ns013.102 - Addition for direct timer message queuing */
   SsIdx        idx;
   SsTTskEntry  *tTsk;
   U32          ret;
   S32          tmrIndex;
   U32          count;
   U8           i;
   U8           j;
   U8           k;
#ifdef NU
   DWORD        error;
#endif /* NU */

   TRC0(nsTimerHandler)

#ifndef SS_SINGLE_THREADED
   UNUSED(param);
#endif /* SS_SINGLE_THREADED */



#ifdef SS_SINGLE_THREADED
   count = osCp.dep.eventCount - NS_TMR_EVNT_IDX;

   if (osCp.dep.eventIdx >= NS_TMR_EVNT_IDX)
      ret = osCp.dep.eventIdx - NS_TMR_EVNT_IDX;
   else
   {
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
      if ((ret = WaitForMultipleObjects(count,
                             &osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX], 
                             FALSE, 0)) == WAIT_TIMEOUT)
#else /* SS_WINCE */
      if ((ret = WaitForMultipleObjectsEx(count,
                             &osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX], 
                             FALSE, 0, FALSE)) == WAIT_TIMEOUT)
#endif /* SS_WINCE */
      {
         /* No timer is expired  so just return */
         RETVALUE(ROK);
      }
   } 
#endif /* SS_SINGLE_THREADED */

#ifndef SS_SINGLE_THREADED
   for (;;) 
   {
      count = osCp.dep.eventCount - NS_TMR_EVNT_IDX;

#ifdef NU
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
      ret = WaitForMultipleObjects(count,
            &osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX], FALSE, INFINITE); 
#else /* SS_WINCE */
      ret = WaitForMultipleObjectsEx(count,
            &osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX], FALSE, INFINITE, FALSE); 
#endif /* SS_WINCE */
#endif /* NU */

#endif /* SS_SINGLE_THREADED */

#ifdef NU
      error = 0;
      if (ret == 0xffffffff)
      {
         error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS191, error,
                    "WaitForMultipleObjectsEx failed in nsTimerHandler");
#endif
      }
      else
      {
         if ((ret >= WAIT_OBJECT_0) 
               && (ret <= (WAIT_OBJECT_0 + count)))
         {
            /* bump return value to get the correct index */
            ret +=  NS_TMR_EVNT_IDX;  
            tmrIndex = ret - WAIT_OBJECT_0;
         }
         else
         {
            error = TRUE;
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS192, ret,
                  "Unknown return value from WaitForMultipleObjectsEx()");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         }
      }

      if (error)
      {
#ifdef SS_SINGLE_THREADED
         RETVALUE(RFAILED);
#else /* SS_SINGLE_THREADED */
         continue;
#endif /* SS_SINGLE_THREADED */
      }
#endif /* NU */


      if (tmrIndex == NS_TMR_EVNT_IDX)
      {

         /* This is either a timer cancellation event or a new timer added */
         if (SLock(&osCp.dep.waitArrayLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS194, ERRZERO, "SLock failed");
#endif
         RETVALUE(RFAILED);
         }

         count = osCp.dep.eventCount;
     
         /* Check for cancellation of timer(s) */
         for (i = NS_TMR_EVNT_IDX + 1; i < count; i++)
         {
            if (cancelledTmrList[i] == TRUE)
            {
#ifdef NU
               /* Cancel this timer */
/* ns016.102 - Modification for Windows CE Support */               
#ifdef SS_WINCE
               if (!ceCancelWaitableTimer(osCp.dep.eventWaitArray[i]))
#else /* SS_WINCE */
               if (!CancelWaitableTimer(osCp.dep.eventWaitArray[i]))
#endif /* SS_WINCE */
               {
                  error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
                 	NSLOGERROR(ERRCLS_DEBUG, ENS195, error, 
                                     " ceCancelWaitableTimer failed");
#else /* SS_WINCE */
                  NSLOGERROR(ERRCLS_DEBUG, ENS195, error,
                                     " CancelWaitableTimer failed");
#endif /* SS_WINCE */
#endif
                  RETVALUE(RFAILED);
               }

               /* Close this timer */
               if (!CloseHandle(osCp.dep.eventWaitArray[i]))
               {
                  error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS196, error,"CloseHandle failed");
#endif
                  RETVALUE(RFAILED);
               }
#endif /* NU */

               cancelledTmrList[i] = FALSE;
               osCp.dep.eventWaitArray[i] = NULLP;
               osCp.dep.eventCount--;
            } /* end of if */
         } /* end of for loop */

         /* Adjust the timer handle array */
         for ( j = NS_TMR_EVNT_IDX + 1; j < osCp.dep.eventCount; j++)
         {
            if (osCp.dep.eventWaitArray[j] == NULLP)
            {
               k = j + 1;
               while((osCp.dep.eventWaitArray[k] == NULLP) && (k < count))
               {
                  k++;
               }
               if (k >= count)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS197, count, "Something fishy!!");
#endif
                  break;
               }
               osCp.dep.eventWaitArray[j] = osCp.dep.eventWaitArray[k];
               osCp.dep.eventWaitArray[k] = NULLP;
               tmr[j] = tmr[k];
               tmr[k] = NULLP;
            }
         }
         if (SUnlock(&osCp.dep.waitArrayLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS198, ERRZERO, "SUnlock failed");
#endif
            RETVALUE(RFAILED);
         }

#ifdef SS_SINGLE_THREADED
        if (error) 
           RETVALUE(RFAILED);
        else
           RETVALUE(ROK);
#else /* SS_SINGLE_THREADED */
        continue;
#endif /* SS_SINGLE_THREADED */
      }

      /* This is a normal timer signal */
      pTmrEntry  = tmr[tmrIndex];
      /* ns016.102 - Modification for Windows CE Support */
      if (pTmrEntry == NULLP)
      {
#ifdef SS_SINGLE_THREADED
         RETVALUE(RFAILED);
#else
         continue;
#endif /* SS_SINGLE_THREADED */
      }
      mInfo1 = (SsMsgInfo *)pTmrEntry->mBuf->b_rptr;

      if (mInfo1->eventInfo.u.tmr.inUse != TRUE)
      {
         mInfo1->eventInfo.u.tmr.inUse = TRUE;

         /* ns013.102 - Modification to directly queue timer message */
         /* get a semaphore for the TAPA task table */
         SS_ACQUIRE_SEMA(&osCp.tTskTblSem, ret);
         if (ret != ROK)
         {
            SPutMsg(pTmrEntry->mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENSXXX , ret, "Could not lock TAPA task table");
#endif

            RETVALUE(RFAILED);
         }

         /* find the owner TAPA task */
         idx = osCp.tTskIds[pTmrEntry->ownerEnt][pTmrEntry->ownerInst];
         if (idx == SS_TSKNC)
         {
            SS_RELEASE_SEMA(&osCp.tTskTblSem);
            SPutMsg(pTmrEntry->mBuf);
            RETVALUE(RFAILED);
         }

         /* ensure that the TAPA task is hale and hearty */
         tTsk = &osCp.tTskTbl[idx];
         if (!tTsk->used)
         {
            SS_RELEASE_SEMA(&osCp.tTskTblSem);
            SPutMsg(pTmrEntry->mBuf);
            RETVALUE(RFAILED);
         }
         /* add by tenglijun on 2006-3-21 */
         if(!tTsk->sTsk)
         {
            SS_RELEASE_SEMA(&osCp.tTskTblSem);
            SPutMsg(pTmrEntry->mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENSXXX, pTmrEntry->ownerEnt,
                              "sTsk is not created ");
#endif

            RETVALUE(RFAILED);
         }
         /* write the timer message to the queue of the destination task */
         if (ssDmndQPutLast(&tTsk->sTsk->dQ, pTmrEntry->mBuf,
                     (Prior)((tTsk->tskPrior * SS_MAX_MSG_PRI) + PRIOR0)) != ROK)
         {
            SS_RELEASE_SEMA(&osCp.tTskTblSem);
            SPutMsg(pTmrEntry->mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENSXXX, ERRZERO,
                              "Could not write to demand queue");
#endif

            RETVALUE(RFAILED);
         }
/* ns015.102 - Addition to handle message passing with signals for ST mode */
#ifdef SS_SINGLE_THREADED
         SetEvent(osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX]);
#endif /* SS_SINGLE_THREADED */

         /* release the semaphore for the TAPA task table */
         SS_RELEASE_SEMA(&osCp.tTskTblSem);

      }
      else
      {
         /* Pre-allocated mBuf is in use, so allocate a new mBuf and set dynBuf,
          * and it will be freed in system task activation function */
         if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) !=ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS200, ERRZERO, " SGetMsg failed");
#endif
            RETVALUE(RFAILED);
         }
         else
         {
            mBuf->b_datap->db_type = SS_M_PROTO;
            mInfo2 = (SsMsgInfo *)mBuf->b_rptr;
   
            eInfo = &mInfo2->eventInfo;

            eInfo->event          = SS_EVNT_TIMER;
            eInfo->u.tmr.tmrIdx   = pTmrEntry->tmrId;
            eInfo->u.tmr.dynBuf   = TRUE;

            /* ns013.102 - Modification to directly queue timer message */

            /* get a semaphore for the TAPA task table */
            SS_ACQUIRE_SEMA(&osCp.tTskTblSem, ret);
            if (ret != ROK)
            {
               SPutMsg(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
               NSLOGERROR(ERRCLS_DEBUG, ENSXXX , ret, "Could not lock TAPA task table");
#endif

               RETVALUE(RFAILED);
            }

            /* find the owner TAPA task */
            idx = osCp.tTskIds[pTmrEntry->ownerEnt][pTmrEntry->ownerInst];
            if (idx == SS_TSKNC)
            {
               SS_RELEASE_SEMA(&osCp.tTskTblSem);
               SPutMsg(mBuf);
               RETVALUE(RFAILED);
            }

            /* ensure that the TAPA task is hale and hearty */
            tTsk = &osCp.tTskTbl[idx];
            if (!tTsk->used)
            {
               SS_RELEASE_SEMA(&osCp.tTskTblSem);
               SPutMsg(mBuf);
               RETVALUE(RFAILED);
            }

            /* write the timer message to the queue of the destination task */
            if (ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf,
               (Prior)((tTsk->tskPrior * SS_MAX_MSG_PRI) + PRIOR0)) != ROK)
            {
               SS_RELEASE_SEMA(&osCp.tTskTblSem);
               SPutMsg(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
               NSLOGERROR(ERRCLS_DEBUG, ENSXXX, ERRZERO,
                                 "Could not write to demand queue");
#endif

               RETVALUE(RFAILED);
            }
/* ns015.102 - Addition to handle message passing with signals for ST mode */
#ifdef SS_SINGLE_THREADED
            SetEvent(osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX]);
#endif /* SS_SINGLE_THREADED */

            /* release the semaphore for the TAPA task table */
            SS_RELEASE_SEMA(&osCp.tTskTblSem);
            
         }
      } /* end of else */

#ifndef SS_SINGLE_THREADED
   } /* end of while loop for multi-threaded operation */
#endif /* SS_SINGLE_THREADED */

   RETVALUE(ROK);

} /* end of nsTimerHandler */


/*
 *
 *       Fun:   ssdRegTmr
 *
 *       Desc:  This function is used to register a timer function for the
 *              layer. The system services will periodically invoke the
 *              function passed to it. The timer function will be used by the
 *              layer to manage the layers internal protocol timers.
 *
 *       Ret:   ROK      - ok
 *              RFAILED  - failed
 *
 *       Notes: A Message buffer and a post structure are preallocated and these
 *              objects are used when posting a timer message to the layer. This
 *              is to avoid allocation and deallocation of mBuf's every time 
 *              a timer messge is posted to the layer. Pst stucture's "spare1"
 *              field is used is hold the index into the timer table.
 *
         File:  np_timer.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssdRegTmr
(
SsTmrEntry *pTmrEntry              /* Pointer to timer Entry */
)
#else
PUBLIC S16 ssdRegTmr(pTmrEntry)
SsTmrEntry *pTmrEntry;             /* Pointer to timer Entry */
#endif
{
   Buffer        *mBuf;
   SsMsgInfo     *mInfo;
   SsEventInfo   *eInfo;             /* Timer Event info */
   U32           error;
   S32           period;
   LARGE_INTEGER dueTime;

   TRC0(ssdRegTmr)

   if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) !=ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS202, ERRZERO, " SGetMsg failed");
#endif
      RETVALUE(RFAILED);
   }

   pTmrEntry->mBuf = mBuf;

   mBuf->b_datap->db_type = SS_M_PROTO;
   mInfo = (SsMsgInfo *)mBuf->b_rptr;
   mInfo->pst.dstProcId = SFndProcId();
   mInfo->pst.srcProcId = SFndProcId();
   mInfo->pst.srcEnt   = pTmrEntry->ownerEnt;
   mInfo->pst.srcInst  = pTmrEntry->ownerInst;
   mInfo->pst.dstEnt   = pTmrEntry->ownerEnt;
   mInfo->pst.dstInst  = pTmrEntry->ownerInst;
   mInfo->pst.prior    = PRIOR0;                     /* Highest priority */
   mInfo->pst.route    = 0;
   mInfo->pst.event    = 0;
   mInfo->pst.region   = SS_DFLT_REGION;
   mInfo->pst.pool     = SS_DFLT_POOL;

   eInfo = &mInfo->eventInfo;

   eInfo->event          = SS_EVNT_TIMER;
   eInfo->u.tmr.tmrIdx   = pTmrEntry->tmrId;
   eInfo->u.tmr.inUse    = FALSE;
   eInfo->u.tmr.dynBuf   = FALSE;
   
   period = pTmrEntry->interval;    /* in units of 100 millisecs */

   /* Aquire lock to protect timer variables */
   if (SLock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS203, ERRZERO, "SLock failed");
#endif
      RETVALUE(RFAILED);
   }

   if (osCp.dep.eventCount == NS_MAX_TMRS)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS204, osCp.dep.eventCount, 
                    "No.of active timers exceeds MAXIMU_WAIT_OBJECTS");
#endif
      SUnlock(&osCp.dep.waitArrayLock);
      RETVALUE(RFAILED);
   }


#ifdef NU
   if ((osCp.dep.eventWaitArray[osCp.dep.eventCount] =
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
   	ceCreateWaitableTimer(NULLP, FALSE, NULLP)) == NULLP)
#else /* SS_WINCE */
      CreateWaitableTimer(NULLP, FALSE, NULLP)) == NULLP)
#endif /* SS_WINCE */
   {
      error = (U32)GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
     	NSLOGERROR(ERRCLS_DEBUG, ENS206, (ErrVal)error,
         " ceCreateWaitableTimer failed");
#else /* SS_WINCE */
      NSLOGERROR(ERRCLS_DEBUG, ENS206, (ErrVal)error,
         " CreateWaitableTimer failed");
#endif /* SS_WINCE */
#endif
      SUnlock(&osCp.dep.waitArrayLock);
      RETVALUE(RFAILED);
   }
 
   ZeroMemory((PVOID) &dueTime, (DWORD)sizeof(LARGE_INTEGER));
   /* ns011.102 - Modification to make dueTime negative (relative) */
   /* ns017.102 - Modification for SRegCfgTmr support */
   dueTime.QuadPart = -period * (10000000/SS_TICKS_SEC);

/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
   if (!ceSetWaitableTimer(osCp.dep.eventWaitArray[osCp.dep.eventCount],
#else /* SS_WINCE */
   if (!SetWaitableTimer(osCp.dep.eventWaitArray[osCp.dep.eventCount],
#endif /* SS_WINCE */
                         /* ns017.102 - Modification for SRegCfgTmr support */
                         &dueTime, (LONG)((period * SS_1MS)/SS_TICKS_SEC),
                         NULLP, 
                         (LPVOID) pTmrEntry, FALSE))
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
      NSLOGERROR(ERRCLS_DEBUG, ENS207, (ErrVal)error,
                                      " ceSetWaitableTimer failed");
#else /* SS_WINCE */
      NSLOGERROR(ERRCLS_DEBUG, ENS207, (ErrVal)error,
                                      " SetWaitableTimer failed");
#endif /* SS_WINCE */
#endif
      SUnlock(&osCp.dep.waitArrayLock);
      RETVALUE(RFAILED);
   }
#endif /* NU */

   tmr[osCp.dep.eventCount] = pTmrEntry;
   osCp.dep.eventCount++;

   /* Signal the timer thread, so that now it will start waiting on this
    * new timer object */
#ifdef NU
   if (!SetEvent(osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX]))
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS208, error, " SetEvent failed");
#endif
      SUnlock(&osCp.dep.waitArrayLock);
      RETVALUE(RFAILED);
   }
#endif /* NU */


   if (SUnlock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS209, ERRZERO, "SUnlock failed");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of ssdRegTmr */


/*
 *
 *       Fun:  ssdDeregTmr
 *
 *       Desc:  This function is used to deregister a timer function from 
 *              the system services.
 *
 *       Ret:   ROK      - ok
 *              RFAILED  - failed
 *
 *       Notes:
 *
         File:  np_timer.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssdDeregTmr
(
SsTmrEntry  *pTmrEntry              /* timer entry  */
)
#else
PUBLIC S16 ssdDeregTmr(pTmrEntry)
SsTmrEntry  *pTmrEntry;             /* timer entry  */
#endif
{
   U8          i;
#ifdef NU
   U32         error;              /* error value */
#endif

   TRC0(ssdDeregTmr)

   /* Aquire lock to protect timer variables */
   if (SLock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS210, ERRZERO, "SLock failed");
#endif
      RETVALUE(RFAILED);
   }

   /* 
    * Set cancellation event here. Actual cancellation will occur in
    * nsTimerHandler function 
    */
   for (i = NS_TMR_EVNT_IDX+1; i < osCp.dep.eventCount; i++)
   {
      /* store the index of the timer to be cancelled in cancelled tmr array */
      if (tmr[i] == pTmrEntry)
      {
         /* ns016.102 - Modification for Windows CE Support */
         tmr[i] = NULLP;
         cancelledTmrList[i] = TRUE;
         break;
      }
   }

   if (i == osCp.dep.eventCount)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS211, i, "No timer Found ");
#endif
      RETVALUE(RFAILED);
   }

#ifdef NU
   if (!SetEvent(osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX]))
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS212, error, " SetEvent failed");
#endif
      SUnlock(&osCp.dep.waitArrayLock);
      RETVALUE(RFAILED);
   }
#endif /* NU */


   /* 
    * Return the buffer allocated for the timer if it not in the Demand Q
    * otherwise set dynBuf bit, so that it will freed in sTskHandler 
    */
   if (((SsMsgInfo *)(pTmrEntry->mBuf->b_rptr))->eventInfo.u.tmr.inUse != TRUE)
      SPutMsg(pTmrEntry->mBuf);
   else
      ((SsMsgInfo *)(pTmrEntry->mBuf->b_rptr))->eventInfo.u.tmr.dynBuf = TRUE;

   pTmrEntry->mBuf = NULLP;

   /* release lock */
   if (SUnlock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS213, ERRZERO, "SUnlock failed");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* End of ssdDeregTmr */


/*
 *
 *       Fun:   ssdInitTmr
 *
 *       Desc:  This function initialize timer specific events 
 *
 *       Ret:   ROK      - ok
 *              RFAILED  - failed
 *
 *       Notes:
 *
         File:  np_timer.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssdInitTmr
(
VOID
)
#else
PUBLIC S16 ssdInitTmr(VOID)
#endif
{
   U16    i;
#ifdef NU
   DWORD  error;
#endif /* NU */

#ifndef SS_SINGLE_THREADED
   SchedParam sParam;
#endif

   /* ns017.102 - Modification for SRegCfgTmr support */
   if (SS_TICKS_SEC > SS_1MS)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS214, ERRZERO, "Minimum SS_TICKS_SEC is 1ms");
#endif
      RETVALUE(RFAILED);
   }


   /* Aquire lock to protect timer variables */
   if (SLock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS214, ERRZERO, "SLock failed");
#endif
      RETVALUE(RFAILED);
   }

   /* Initialize array to be used to cancel a timer */
   for (i = NS_TMR_EVNT_IDX; i < NS_MAX_TMRS; i++)
      cancelledTmrList[i] = FALSE;

#ifdef NU 
   /* create an event to be used for cancellation of timers */
   /* ns016.102 - Modification for Windows CE Support */
   if ((osCp.dep.eventWaitArray[NS_TMR_EVNT_IDX] 
           = CreateEvent(NULLP, FALSE, FALSE, NULLP)) == NULLP)
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS215, error, " CreateEvent failed");
#endif
      RETVALUE(RFAILED);
   }
#endif /* NU */

 
   /* increment number of events */
   osCp.dep.eventCount++;

#ifndef SS_SINGLE_THREADED
   /* Create a timer thread here */
   if (sspthreadCreate(&osCp.dep.tmrThrd, NULLP, (void* (*) (void*))nsTimerHandler, NULLP) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS218, ERRZERO, 
                            "could not crerate timer handler thread");
#endif
      RETVALUE(RFAILED);
   }

   sParam.schedPrior = NS_TMR_THRD_PRIOR;

   if (sspthreadSetSchedParam(&osCp.dep.tmrThrd, SCHED_OTHER, &sParam) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS219, ERRZERO, 
                            "Could not set Timer Thread priority");
#endif
      RETVALUE(RFAILED);
   }
#endif /* SS_SINGLE_THREADED */

   /* release lock */
   if (SUnlock(&osCp.dep.waitArrayLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS220, ERRZERO, "SUnlock failed");
#endif
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);

} /* end of ssdInitTmr */


/*
 *
 *       Fun:   ssdDeinitTmr
 *
 *       Desc:  This function Deinitialize timer specific events 
 *
 *       Ret:   ROK      - ok
 *              RFAILED  - failed
 *
 *       Notes:
 *
         File:  np_timer.c
 *
 */
#ifdef ANSI
PUBLIC Void ssdDeinitTmr
(
VOID
)
#else
PUBLIC Void ssdDeinitTmr(VOID)
#endif
{
   TRC0(ssdDeinitTmr)


   RETVOID;

} /* end of ssdDeinitTmr */


/********************************************************************30**
  
         End of file: np_timer.c 1.2  -  08/17/98 11:56:46
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bsr  1. initial release
  
1.2          ---      ag   1. Moved timer module data strs to ssOs.dep
             ---      ag   2. Changed nsLayerTimerHandler to 
                              nsTimerHandler 
             ---      ag   3. Fixed a bug in ssdDeregTmr
             ---      bsr  4. Fixed a warning in ssdDeinitTmr
             ---      sn   5. Modifications to C++ compile
             ns001.12 bsr  1. Fixed C++ compile errors
	    ns011.102 bjp  2. Modification to made dueTime negative in
	                      ssdRegTmr
       ns013.102 bjp  1. Modification to TimerHandler to directly queue
                         timer messages
1.2+   ns015.102 bjp  1.  Addition to handle message passing with 
                          signals for single threaded mode in
                          nsTimerHandler
1.2+   ns016.102 bjp  2.  Addition of Windows CE Support
1.2+   ns017.102 bjp  1. Addition of SRegCfgTmr support
*********************************************************************91*/
