/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     NTSS - error
  
     Type:     C include file
  
     Desc:     Error defines required by NTSS.
  
     File:     ns_err.h
  
     Sid:      ns_err.h 1.2  -  08/11/98 12:02:30
   
     Prg:      ag 
  
*********************************************************************21*/
  
#ifndef __NSERRH__
#define __NSERRH__
  
  

/* log error macro */
#define NSLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError( ENTNS, INSTNC, 0, __FILE__, __LINE__, \
             (ErrCls)errCls, (ErrVal)errCode, (ErrVal)errVal, errDesc )


/* defines */

#define   ERRNS       0
#define   ENSBASE     (ERRSS + 1000) /* reserved */
#define   ENSXXX      (ENSBASE)      /* reserved */

#define   ENS001      (ERRNS +    1)    /*     np_gen.c: 392 */
#define   ENS002      (ERRNS +    2)    /*     np_gen.c: 939 */
#define   ENS003      (ERRNS +    3)    /*     np_gen.c: 952 */
#define   ENS004      (ERRNS +    4)    /*     np_gen.c:1041 */
#define   ENS005      (ERRNS +    5)    /*     np_gen.c:1057 */
#define   ENS006      (ERRNS +    6)    /*     np_gen.c:1243 */
#define   ENS007      (ERRNS +    7)    /*     np_gen.c:1255 */
#define   ENS008      (ERRNS +    8)    /*     np_gen.c:1274 */
#define   ENS009      (ERRNS +    9)    /*     np_gen.c:1287 */
#define   ENS010      (ERRNS +   10)    /*     np_gen.c:1300 */
#define   ENS011      (ERRNS +   11)    /*     np_gen.c:1342 */
#define   ENS012      (ERRNS +   12)    /*     np_gen.c:1378 */
#define   ENS013      (ERRNS +   13)    /*     np_gen.c:1438 */
#define   ENS014      (ERRNS +   14)    /*     np_gen.c:1602 */
#define   ENS015      (ERRNS +   15)    /*     np_gen.c:1615 */
#define   ENS016      (ERRNS +   16)    /*     np_gen.c:1626 */
#define   ENS017      (ERRNS +   17)    /*     np_gen.c:1645 */
#define   ENS018      (ERRNS +   18)    /*     np_gen.c:1946 */
#define   ENS019      (ERRNS +   19)    /*     np_gen.c:2017 */
#define   ENS020      (ERRNS +   20)    /*     np_gen.c:2079 */
#define   ENS021      (ERRNS +   21)    /*     np_gen.c:2173 */
#define   ENS022      (ERRNS +   22)    /*     np_gen.c:2423 */
#define   ENS023      (ERRNS +   23)    /*     np_gen.c:2439 */
#define   ENS024      (ERRNS +   24)    /*     np_gen.c:2456 */
#define   ENS025      (ERRNS +   25)    /*     np_gen.c:2471 */
#define   ENS026      (ERRNS +   26)    /*     np_gen.c:2526 */
#define   ENS027      (ERRNS +   27)    /*     np_gen.c:2532 */
#define   ENS028      (ERRNS +   28)    /*     np_gen.c:2541 */
#define   ENS029      (ERRNS +   29)    /*     np_gen.c:2553 */
#define   ENS030      (ERRNS +   30)    /*     np_gen.c:2610 */
#define   ENS031      (ERRNS +   31)    /*     np_gen.c:2619 */
#define   ENS032      (ERRNS +   32)    /*     np_gen.c:2631 */
#define   ENS033      (ERRNS +   33)    /*     np_gen.c:2687 */
#define   ENS034      (ERRNS +   34)    /*     np_gen.c:2709 */
#define   ENS035      (ERRNS +   35)    /*     np_gen.c:2753 */
#define   ENS036      (ERRNS +   36)    /*     np_gen.c:2791 */
#define   ENS037      (ERRNS +   37)    /*     np_gen.c:2823 */
#define   ENS038      (ERRNS +   38)    /*     np_gen.c:2853 */
#define   ENS039      (ERRNS +   39)    /*     np_gen.c:2873 */
#define   ENS040      (ERRNS +   40)    /*     np_gen.c:2941 */
#define   ENS041      (ERRNS +   41)    /*     np_gen.c:2950 */
#define   ENS042      (ERRNS +   42)    /*     np_gen.c:2966 */
#define   ENS043      (ERRNS +   43)    /*     np_gen.c:2983 */
#define   ENS044      (ERRNS +   44)    /*     np_gen.c:3010 */
#define   ENS045      (ERRNS +   45)    /*     np_gen.c:3033 */
#define   ENS046      (ERRNS +   46)    /*     np_gen.c:3050 */
#define   ENS047      (ERRNS +   47)    /*     np_gen.c:3071 */
#define   ENS048      (ERRNS +   48)    /*     np_gen.c:3098 */
#define   ENS049      (ERRNS +   49)    /*     np_gen.c:3123 */
#define   ENS050      (ERRNS +   50)    /*     np_gen.c:3137 */
#define   ENS051      (ERRNS +   51)    /*     np_gen.c:3202 */
#define   ENS052      (ERRNS +   52)    /*     np_gen.c:3232 */
#define   ENS053      (ERRNS +   53)    /*     np_gen.c:3245 */
#define   ENS054      (ERRNS +   54)    /*     np_gen.c:3255 */
#define   ENS055      (ERRNS +   55)    /*     np_gen.c:3310 */
#define   ENS056      (ERRNS +   56)    /*     np_gen.c:3398 */
#define   ENS057      (ERRNS +   57)    /*     np_gen.c:3417 */
#define   ENS058      (ERRNS +   58)    /*     np_gen.c:3429 */
#define   ENS059      (ERRNS +   59)    /*     np_gen.c:3440 */
#define   ENS060      (ERRNS +   60)    /*     np_gen.c:3453 */
#define   ENS061      (ERRNS +   61)    /*     np_gen.c:3463 */
#define   ENS062      (ERRNS +   62)    /*     np_gen.c:3474 */
#define   ENS063      (ERRNS +   63)    /*     np_gen.c:3485 */
#define   ENS064      (ERRNS +   64)    /*     np_gen.c:3539 */
#define   ENS065      (ERRNS +   65)    /*     np_gen.c:3550 */
#define   ENS066      (ERRNS +   66)    /*     np_gen.c:3610 */
#define   ENS067      (ERRNS +   67)    /*     np_gen.c:3621 */
#define   ENS068      (ERRNS +   68)    /*     np_gen.c:3644 */
#define   ENS069      (ERRNS +   69)    /*     np_gen.c:3673 */
#define   ENS070      (ERRNS +   70)    /*     np_gen.c:3720 */
#define   ENS071      (ERRNS +   71)    /*     np_gen.c:3750 */

#define   ENS072      (ERRNS +   72)    /*    np_task.c: 176 */
#define   ENS073      (ERRNS +   73)    /*    np_task.c: 188 */
#define   ENS074      (ERRNS +   74)    /*    np_task.c: 199 */
#define   ENS075      (ERRNS +   75)    /*    np_task.c: 211 */
#define   ENS076      (ERRNS +   76)    /*    np_task.c: 224 */
#define   ENS077      (ERRNS +   77)    /*    np_task.c: 236 */
#define   ENS078      (ERRNS +   78)    /*    np_task.c: 249 */
#define   ENS079      (ERRNS +   79)    /*    np_task.c: 260 */
#define   ENS080      (ERRNS +   80)    /*    np_task.c: 300 */
#define   ENS081      (ERRNS +   81)    /*    np_task.c: 346 */
#define   ENS082      (ERRNS +   82)    /*    np_task.c: 388 */
#define   ENS083      (ERRNS +   83)    /*    np_task.c: 502 */
#define   ENS084      (ERRNS +   84)    /*    np_task.c: 544 */
#define   ENS085      (ERRNS +   85)    /*    np_task.c: 554 */
#define   ENS086      (ERRNS +   86)    /*    np_task.c: 595 */
#define   ENS087      (ERRNS +   87)    /*    np_task.c: 637 */
#define   ENS088      (ERRNS +   88)    /*    np_task.c: 679 */
#define   ENS089      (ERRNS +   89)    /*    np_task.c: 684 */
#define   ENS090      (ERRNS +   90)    /*    np_task.c: 728 */
#define   ENS091      (ERRNS +   91)    /*    np_task.c: 770 */
#define   ENS092      (ERRNS +   92)    /*    np_task.c: 775 */
#define   ENS093      (ERRNS +   93)    /*    np_task.c: 822 */
#define   ENS094      (ERRNS +   94)    /*    np_task.c: 863 */
#define   ENS095      (ERRNS +   95)    /*    np_task.c: 908 */
#define   ENS096      (ERRNS +   96)    /*    np_task.c: 964 */
#define   ENS097      (ERRNS +   97)    /*    np_task.c: 988 */
#define   ENS098      (ERRNS +   98)    /*    np_task.c:1103 */
#define   ENS099      (ERRNS +   99)    /*    np_task.c:1111 */
#define   ENS100      (ERRNS +  100)    /*    np_task.c:1187 */
#define   ENS101      (ERRNS +  101)    /*    np_task.c:1193 */
#define   ENS102      (ERRNS +  102)    /*    np_task.c:1244 */
#define   ENS103      (ERRNS +  103)    /*    np_task.c:1250 */
#define   ENS104      (ERRNS +  104)    /*    np_task.c:1255 */
#define   ENS105      (ERRNS +  105)    /*    np_task.c:1269 */
#define   ENS106      (ERRNS +  106)    /*    np_task.c:1348 */
#define   ENS107      (ERRNS +  107)    /*    np_task.c:1361 */
#define   ENS108      (ERRNS +  108)    /*    np_task.c:1375 */
#define   ENS109      (ERRNS +  109)    /*    np_task.c:1385 */
#define   ENS110      (ERRNS +  110)    /*    np_task.c:1633 */
#define   ENS111      (ERRNS +  111)    /*    np_task.c:1754 */
#define   ENS112      (ERRNS +  112)    /*    np_task.c:1772 */
#define   ENS113      (ERRNS +  113)    /*    np_task.c:1811 */
#define   ENS114      (ERRNS +  114)    /*    np_task.c:1818 */
#define   ENS115      (ERRNS +  115)    /*    np_task.c:1857 */
#define   ENS116      (ERRNS +  116)    /*    np_task.c:1898 */
#define   ENS117      (ERRNS +  117)    /*    np_task.c:1906 */
#define   ENS118      (ERRNS +  118)    /*    np_task.c:1957 */
#define   ENS119      (ERRNS +  119)    /*    np_task.c:1970 */
#define   ENS120      (ERRNS +  120)    /*    np_task.c:2079 */
#define   ENS121      (ERRNS +  121)    /*    np_task.c:2119 */
#define   ENS122      (ERRNS +  122)    /*    np_task.c:2160 */
#define   ENS123      (ERRNS +  123)    /*    np_task.c:2167 */
#define   ENS124      (ERRNS +  124)    /*    np_task.c:2210 */
#define   ENS125      (ERRNS +  125)    /*    np_task.c:2228 */
#define   ENS126      (ERRNS +  126)    /*    np_task.c:2267 */
#define   ENS127      (ERRNS +  127)    /*    np_task.c:2309 */
#define   ENS128      (ERRNS +  128)    /*    np_task.c:2317 */
#define   ENS129      (ERRNS +  129)    /*    np_task.c:2328 */
#define   ENS130      (ERRNS +  130)    /*    np_task.c:2375 */
#define   ENS131      (ERRNS +  131)    /*    np_task.c:2384 */
#define   ENS132      (ERRNS +  132)    /*    np_task.c:2399 */
#define   ENS133      (ERRNS +  133)    /*    np_task.c:2443 */
#define   ENS134      (ERRNS +  134)    /*    np_task.c:2451 */
#define   ENS135      (ERRNS +  135)    /*    np_task.c:2495 */
#define   ENS136      (ERRNS +  136)    /*    np_task.c:2500 */
#define   ENS137      (ERRNS +  137)    /*    np_task.c:2508 */
#define   ENS138      (ERRNS +  138)    /*    np_task.c:2547 */
#define   ENS139      (ERRNS +  139)    /*    np_task.c:2555 */
#define   ENS140      (ERRNS +  140)    /*    np_task.c:2594 */
#define   ENS141      (ERRNS +  141)    /*    np_task.c:2602 */
#define   ENS142      (ERRNS +  142)    /*    np_task.c:2641 */
#define   ENS143      (ERRNS +  143)    /*    np_task.c:2649 */
#define   ENS144      (ERRNS +  144)    /*    np_task.c:2693 */
#define   ENS145      (ERRNS +  145)    /*    np_task.c:2768 */
#define   ENS146      (ERRNS +  146)    /*    np_task.c:2841 */
#define   ENS147      (ERRNS +  147)    /*    np_task.c:2909 */
#define   ENS148      (ERRNS +  148)    /*    np_task.c:2970 */
#define   ENS149      (ERRNS +  149)    /*    np_task.c:2978 */
#define   ENS150      (ERRNS +  150)    /*    np_task.c:3018 */
#define   ENS151      (ERRNS +  151)    /*    np_task.c:3026 */
#define   ENS152      (ERRNS +  152)    /*    np_task.c:3066 */
#define   ENS153      (ERRNS +  153)    /*    np_task.c:3074 */
#define   ENS154      (ERRNS +  154)    /*    np_task.c:3114 */
#define   ENS155      (ERRNS +  155)    /*    np_task.c:3122 */
#define   ENS156      (ERRNS +  156)    /*    np_task.c:3667 */
#define   ENS157      (ERRNS +  157)    /*    np_task.c:3727 */
#define   ENS158      (ERRNS +  158)    /*    np_task.c:3742 */
#define   ENS159      (ERRNS +  159)    /*    np_task.c:3761 */
#define   ENS160      (ERRNS +  160)    /*    np_task.c:3772 */
#define   ENS161      (ERRNS +  161)    /*    np_task.c:3827 */
#define   ENS162      (ERRNS +  162)    /*    np_task.c:3855 */
#define   ENS163      (ERRNS +  163)    /*    np_task.c:3953 */
#define   ENS164      (ERRNS +  164)    /*    np_task.c:4009 */
#define   ENS165      (ERRNS +  165)    /*    np_task.c:4082 */
#define   ENS166      (ERRNS +  166)    /*    np_task.c:4092 */
#define   ENS167      (ERRNS +  167)    /*    np_task.c:4102 */
#define   ENS168      (ERRNS +  168)    /*    np_task.c:4145 */
#define   ENS169      (ERRNS +  169)    /*    np_task.c:4153 */
#define   ENS170      (ERRNS +  170)    /*    np_task.c:4202 */
#define   ENS171      (ERRNS +  171)    /*    np_task.c:4210 */
#define   ENS172      (ERRNS +  172)    /*    np_task.c:4254 */
#define   ENS173      (ERRNS +  173)    /*    np_task.c:4299 */
#define   ENS174      (ERRNS +  174)    /*    np_task.c:4309 */
#define   ENS175      (ERRNS +  175)    /*    np_task.c:4319 */
#define   ENS176      (ERRNS +  176)    /*    np_task.c:4364 */
#define   ENS177      (ERRNS +  177)    /*    np_task.c:4372 */
#define   ENS178      (ERRNS +  178)    /*    np_task.c:4422 */
#define   ENS179      (ERRNS +  179)    /*    np_task.c:4432 */
#define   ENS180      (ERRNS +  180)    /*    np_task.c:4443 */
#define   ENS181      (ERRNS +  181)    /*    np_task.c:4488 */
#define   ENS182      (ERRNS +  182)    /*    np_task.c:4533 */
#define   ENS183      (ERRNS +  183)    /*    np_task.c:4588 */
#define   ENS184      (ERRNS +  184)    /*    np_task.c:4600 */
#define   ENS185      (ERRNS +  185)    /*    np_task.c:4645 */
#define   ENS186      (ERRNS +  186)    /*    np_task.c:4716 */
#define   ENS187      (ERRNS +  187)    /*    np_task.c:4763 */
#define   ENS188      (ERRNS +  188)    /*    np_task.c:4813 */
#define   ENS189      (ERRNS +  189)    /*    np_task.c:4819 */
#define   ENS190      (ERRNS +  190)    /*    np_task.c:4861 */

#define   ENS191      (ERRNS +  191)    /*   np_timer.c: 234 */
#define   ENS192      (ERRNS +  192)    /*   np_timer.c: 251 */
#define   ENS193      (ERRNS +  193)    /*   np_timer.c: 278 */
#define   ENS194      (ERRNS +  194)    /*   np_timer.c: 313 */
#define   ENS195      (ERRNS +  195)    /*   np_timer.c: 331 */
#define   ENS196      (ERRNS +  196)    /*   np_timer.c: 342 */
#define   ENS197      (ERRNS +  197)    /*   np_timer.c: 372 */
#define   ENS198      (ERRNS +  198)    /*   np_timer.c: 385 */
#define   ENS199      (ERRNS +  199)    /*   np_timer.c: 418 */
#define   ENS200      (ERRNS +  200)    /*   np_timer.c: 430 */
#define   ENS201      (ERRNS +  201)    /*   np_timer.c: 449 */
#define   ENS202      (ERRNS +  202)    /*   np_timer.c: 508 */
#define   ENS203      (ERRNS +  203)    /*   np_timer.c: 542 */
#define   ENS204      (ERRNS +  204)    /*   np_timer.c: 550 */
#define   ENS205      (ERRNS +  205)    /*   np_timer.c: 563 */
#define   ENS206      (ERRNS +  206)    /*   np_timer.c: 583 */
#define   ENS207      (ERRNS +  207)    /*   np_timer.c: 600 */
#define   ENS208      (ERRNS +  208)    /*   np_timer.c: 618 */
#define   ENS209      (ERRNS +  209)    /*   np_timer.c: 632 */
#define   ENS210      (ERRNS +  210)    /*   np_timer.c: 678 */
#define   ENS211      (ERRNS +  211)    /*   np_timer.c: 701 */
#define   ENS212      (ERRNS +  212)    /*   np_timer.c: 711 */
#define   ENS213      (ERRNS +  213)    /*   np_timer.c: 737 */
#define   ENS214      (ERRNS +  214)    /*   np_timer.c: 783 */
#define   ENS215      (ERRNS +  215)    /*   np_timer.c: 799 */
#define   ENS216      (ERRNS +  216)    /*   np_timer.c: 811 */
#define   ENS217      (ERRNS +  217)    /*   np_timer.c: 821 */
#define   ENS218      (ERRNS +  218)    /*   np_timer.c: 838 */
#define   ENS219      (ERRNS +  219)    /*   np_timer.c: 849 */
#define   ENS220      (ERRNS +  220)    /*   np_timer.c: 860 */

#define   ENS221      (ERRNS +  221)    /*   ns_ex_ms.c: 198 */
#define   ENS222      (ERRNS +  222)    /*   ns_ex_ms.c: 204 */
#define   ENS223      (ERRNS +  223)    /*   ns_ex_ms.c: 225 */

#define   ENS224      (ERRNS +  224)    /*    ns_ptmi.c: 266 */
#define   ENS225      (ERRNS +  225)    /*    ns_ptmi.c: 322 */
#define   ENS226      (ERRNS +  226)    /*    ns_ptmi.c: 377 */
#define   ENS227      (ERRNS +  227)    /*    ns_ptmi.c: 435 */
#define   ENS228      (ERRNS +  228)    /*    ns_ptmi.c: 478 */
#define   ENS229      (ERRNS +  229)    /*    ns_ptmi.c: 519 */

#endif /* __NSERRH__ */

  
/********************************************************************30**
  
         End of file: ns_err.h 1.2  -  08/11/98 12:02:30
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release

1.2          ---      bsr  1. Regenareted the error codes
  
*********************************************************************91*/
