/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     C Source Code.
  
     Desc:     Memory configuration
 
     File:     ns_space.c

     Sid:      ns_space.c 1.1  -  08/11/98 12:01:34
  
     Prg:      bsr
  
*********************************************************************21*/

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm_mem.h"        /* common memory manager */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "lns.h"           /* NTSS mgmt */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_mem.x"        /* common memory manager */


#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "lns.x"           /* NTSS mgmt */


/* local defines */
#ifdef RY
#define RY_NTUK_REGION       1
#define RY_NTUK_POOLS        2
#define RY_BKT_0_DSIZE       64
#define RY_BKT_1_DSIZE       128
#endif

#define NS_MAX_BKTS          4

/* bkt sizes */
#define NS_BKT_0_DSIZE       64
#define NS_BKT_1_DSIZE       128
#define NS_BKT_2_DSIZE       512 
#define NS_BKT_3_DSIZE       2560

#ifdef CP_MASS_MEM
#define NS_BKT_0_NUMBLKS     300000
#define NS_BKT_1_NUMBLKS     600000
#define NS_BKT_2_NUMBLKS     200000
#define NS_BKT_3_NUMBLKS     200000

/* ns006.12: Increased the heap size */
#define NS_HEAP_DFLT_SIZE   231072 * 100 /* xqc for MAPSec test ; old is 131072 * 10 */  /* default heap size for CMM */
#else
#define NS_BKT_0_NUMBLKS     100000
#define NS_BKT_1_NUMBLKS     90000
#define NS_BKT_2_NUMBLKS     5000
#define NS_BKT_3_NUMBLKS     7000 

/* ns006.12: Increased the heap size */
#define NS_HEAP_DFLT_SIZE   231072 * 60 /* xqc for MAPSec test ; old is 131072 * 10 */  /* default heap size for CMM */

#endif /*CP_MASS_MEM*/

/* Define any region which requires contiguous memory as the first region */
PUBLIC NsMemCfg  nsMemCfg =
{
   1,                                          /* no. of regions */
   {
      {
         SS_DFLT_REGION,                       /* region id */
         NS_MAX_BKTS,                          /* no. of bkts */
         NS_NON_CONTIGUOUS_MEM,                /* non contiguous memory */
         NS_HEAP_DFLT_SIZE,                    /* heap size */
         {
            {NS_BKT_0_DSIZE, NS_BKT_0_NUMBLKS},/* Block size, no.of blocks */ 
            {NS_BKT_1_DSIZE, NS_BKT_1_NUMBLKS},/* Block size, no.of blocks */
            {NS_BKT_2_DSIZE, NS_BKT_2_NUMBLKS},/* Block size, no.of blocks */
            {NS_BKT_3_DSIZE, NS_BKT_3_NUMBLKS} /* Block size, no.of blocks */
         }
      },
   }
};

/* 
 * The following struct is defined for backward compatibility.
 * In the current memory architecture the concept of pool is obsoleted.
 * But to maintain the backward compatibity, a mapping between the configured
 * buckets and pools should be maintained.
 */

PUBLIC SsRegCfg cfgRegInfo[] = 
{
   {
      SS_DFLT_REGION,                      /* region id */
      SS_MAX_POOLS_PER_REG,                /* no. of pools */
      {
         {SS_POOL_DYNAMIC, NS_BKT_0_DSIZE},/* Pool 0: type, size */ 
         {SS_POOL_DYNAMIC, NS_BKT_1_DSIZE},/* Pool 1: type, size */
         {SS_POOL_DYNAMIC, NS_BKT_2_DSIZE},/* Pool 2: type, size */
         {SS_POOL_DYNAMIC, NS_BKT_3_DSIZE} /* Pool 3: type, size */
      },
   },
#ifdef RY
   {
      RY_NTUK_REGION,
      RY_NTUK_POOLS,
      {
         {SS_POOL_DYNAMIC, RY_BKT_0_DSIZE},/* Pool 0: type, size */ 
         {SS_POOL_DYNAMIC, RY_BKT_1_DSIZE},/* Pool 1: type, size */
      }
   }
#endif /* RY */
};

#ifdef RY
PUBLIC Cntr cfgNumRegs = 2;            /* no .of regions */
#else
PUBLIC Cntr cfgNumRegs = 1;            /* no .of regions */
#endif /* RY */


/********************************************************************30**
  
         End of file: ns_space.c 1.1  -  08/11/98 12:01:34
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      bsr  1. initial release
  
*********************************************************************91*/
