/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     System Services - VxWorks specific implementation

     Type:     C source file

     Desc:     C source code for the System Service service provider
               primitives that are necessary to work with VxWorks.

     File:     vw_ss.c

     Sid:      vw_ss.c 1.1  -  12/28/98 12:38:09

     Prg:      kp

*********************************************************************21*/


/* vxWorks includes */

#include "stdioLib.h"
#include "taskLib.h"
#include "tickLib.h"
#include "msgQLib.h"
#include "intLib.h"
#include "wdLib.h"
#include "logLib.h"
#include "sysLib.h"
#include "kernelLib.h"
#include "iv.h"
#include "time.h"
#include "string.h"
#include "rngLib.h"
/* vw014.21: addition for the cache library */
#ifdef SS_NOCACHE_MEM
#include "cacheLib.h"
#else
#ifdef SS_CACHE_FUNCTIONS
#include "cacheLib.h"
#endif /* SS_CACHE_FUNCTIONS */
#endif /* SS_NOCACHE_MEM */



/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "vw_ss.h"         /* VxWorks specific */
#include "vw_err.h"        /* VxWorks errors */

#include "ss_queue.h"      /* queues */
#if 1  /* vw020.21: Addition */
#include "ss_strm.h"       /* STREAMS */
#endif /* vw020.21: Addition */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */

#include "cm_mem.h"        /* memory manager */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "vw_ss.x"         /* VxWorks specific */

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */

#include "cm_mem.x"        /* memory manager */


/* forward references */

PUBLIC Void vwMain ARGS((int, char **));


#ifdef SS_AEHDPR_SUPPORT
PUBLIC  VOID INTERRPT ssIsr ARGS((S32));
PUBLIC  VOID INTERRPT ssDefault_isr(VOID);
PUBLIC  S16  ssdPutVect ARGS((VectNmb,PIF));
PUBLIC  S16  ssdChkVect ARGS((VectNmb));
PRIVATE VOID ssDprHdlr ARGS((S32,S32));
/* vw012.21 - not required for the 8260 driver */
#ifndef SS_PROC_8260
PRIVATE U32 pqGetHwBlk ARGS((VOID));
PRIVATE VOID pqDisInt ARGS((U32 *));
PRIVATE VOID pqEnbInt ARGS((U32));
#endif /* #ifndef SS_PROC_8260 */

PUBLIC AehDprCtl  sAehDprCtl;
PUBLIC Dpr     sDprTbl[MAX_DPR_PRIORITY];
#ifdef SS_PROC_68360 /* for PROC_68360 */
PRIVATE U32 qi8kblock;
#endif /* SS_PROC_68360 */

#endif /* SS_AEHDPR_SUPPORT */

PRIVATE Void vwTskHdlr ARGS((U32 arg));
PRIVATE Void vwTimeout ARGS((U32 arg));
PRIVATE Void vwTmrHdlr ARGS((U32 arg));

#ifdef SS_DRVR_SUPPORT
PRIVATE Void vwIsTskHdlr ARGS((U32 arg));
#endif

/* vw014.21: Addition */
#ifdef SS_NOCACHE_MEM
PRIVATE S16 SAllocNonCache ARGS((Size size, Data **addr));
PRIVATE S16 SFreeNonCache ARGS((Size size, Data *addr));
#endif /* SS_NOCACHE_MEM */
/* vw014.21: Addition */


/* type declarations */

#ifdef SS_DRVR_SUPPORT
typedef struct vwIsFlag
{
   U16 id;
   U8 action;

} VwIsFlag;
#endif



/* public variable declarations */

PUBLIC Cntr cfgNumRegs = SS_MAX_REGS;
/* vw025.201 - Modification to hard code region IDs */
PUBLIC SsRegCfg cfgRegInfo[SS_MAX_REGS] =
{
   {
      SS_DFLT_REGION, SS_MAX_POOLS_PER_REG - 1,
      {
         { SS_POOL_DYNAMIC, VW_POOL_0_DSIZE },
         { SS_POOL_DYNAMIC, VW_POOL_1_DSIZE },
         { SS_POOL_DYNAMIC, VW_POOL_2_DSIZE },
         { SS_POOL_DYNAMIC, VW_POOL_3_DSIZE },
         { SS_POOL_STATIC, 0 }
      }
   },
   {
      1, SS_MAX_POOLS_PER_REG - 1,
      {
         { SS_POOL_DYNAMIC, VW_POOL_0_DSIZE_REG1 },
         { SS_POOL_DYNAMIC, VW_POOL_1_DSIZE_REG1 },
         { SS_POOL_DYNAMIC, VW_POOL_2_DSIZE_REG1 },
         { SS_POOL_DYNAMIC, VW_POOL_3_DSIZE_REG1 },
         { SS_POOL_STATIC, 0 }
      }
   },
   {
      2, SS_MAX_POOLS_PER_REG - 1,
      {
         { SS_POOL_DYNAMIC, VW_POOL_0_DSIZE_REG2 },
         { SS_POOL_DYNAMIC, VW_POOL_1_DSIZE_REG2 },
         { SS_POOL_DYNAMIC, VW_POOL_2_DSIZE_REG2 },
         { SS_POOL_DYNAMIC, VW_POOL_3_DSIZE_REG2 },
         { SS_POOL_STATIC, 0 }
      }
   }
};
/* vw014.21: Addition */

PUBLIC S16 msArgc;              /* argc */
PUBLIC Txt **msArgv;            /* argv */
PUBLIC S16 msOptInd;            /* SGetOpt vars */
PUBLIC S8 *msOptArg;            /* SGetOpt vars */



/* private variable declarations */

PRIVATE CmMmRegCfg vwCMMRegCfg;
PRIVATE CmMmRegCb *vwCMMRegCb;
/* vw014.21: Addition */
#ifdef SS_REGION1_SUPPORT
PRIVATE CmMmRegCfg vwCMMReg1Cfg;
PRIVATE CmMmRegCb *vwCMMReg1Cb;
#endif /* SS_REGION1_SUPPORT */

/* vw024.201 - Addition for REGION2 support */
#ifdef SS_REGION2_SUPPORT
PRIVATE CmMmRegCfg vwCMMReg2Cfg;
PRIVATE CmMmRegCb *vwCMMReg2Cb;
#endif /* SS_REGION2_SUPPORT */


/*
*
*       Fun:   Entry point
*
*       Desc:  This function is the entry point for the final binary. It
*              calls SInit() in the common code. It can be replaced by a
*              user function if required (SInit() must still be called).
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void vwMain
(
int argc,                       /* argument count */
char **argv                     /* arguments */
)
#else
PUBLIC Void vwMain(argc, argv)
int argc;                       /* argument count */
char **argv;                    /* arguments */
#endif
{
   TRC0(vwMain);


   msArgc = argc;
   msArgv = argv;


   SInit();
}


/*
*   initialization functions
*/


/*
*
*       Fun:   Initialize OS control point
*
*       Desc:  This function initializes VxWorks-specific information
*              in the OS control point
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitGen
(
void
)
#else
PUBLIC S16 ssdInitGen()
#endif
{

   TRC0(ssdInitGen);


   /* initialize the started semaphore */
   if (ssInitSema(&osCp.dep.ssStarted, 0) != ROK)
   {
      RETVALUE(RFAILED);
   }

   osCp.dep.intKey = 0;
   osCp.dep.intCnt = 0;
   osCp.dep.intHoldKey = 0;
   osCp.dep.intHoldCnt = 0;
   osCp.dep.intLckLevel = intLockLevelGet();


#ifdef SS_AEHDPR_SUPPORT
   {
      U16 i;
      if((SInitLock(&(sAehDprCtl.sAehDprTblLock), SS_LOCK_MUTEX)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
		   "SInitLock for sAehDprCtl.sAehDprTblLock semaphore failed");
#endif
        RETVALUE(RFAILED);
      }
      for(i=0;i<MAX_VECT_NUM;i++)
      {
         sAehDprCtl.AehDprTbl[i].chipNum = 0;
         sAehDprCtl.AehDprTbl[i].vectNmb = i;
         sAehDprCtl.AehDprTbl[i].isr = NULLP;
         sAehDprCtl.AehDprTbl[i].isrContext = NULLP;
         sAehDprCtl.AehDprTbl[i].dpr = NULLP;
         sAehDprCtl.AehDprTbl[i].dprContext = NULLP;
         sAehDprCtl.AehDprTbl[i].synch_id = NULLP;
         sAehDprCtl.AehDprTbl[i].valid = FALSE;
         sAehDprCtl.AehDprTbl[i].tid = 0xFF;
         sAehDprCtl.AehDprTbl[i].old_isr = NULLP;
         sAehDprCtl.AehDprTbl[i].que_write_err = 0;
         sAehDprCtl.AehDprTbl[i].qid = NULLP;
      }

      for(i=0;i<MAX_DPR_PRIORITY;i++)
      {
         sDprTbl[i].tid=0x1ff;
         sDprTbl[i].valid = FALSE;
         sDprTbl[i].qid=(SsRingId)0xff;
         sDprTbl[i].synch_id = (SsSemaId)NULLP;
         sDprTbl[i].counter=0;
         sDprTbl[i].ssDprCnt=0;  /* vw016.21: Addition */
         sDprTbl[i].ssIsrCnt=0;  /* vw016.21: Addition */
      }

   }
#endif /* SS_AEHDPR_SUPPORT */

   RETVALUE(ROK);
}


/*
*
*       Fun:   De-initialize OS control point
*
*       Desc:  This function reverses the initialization in ssdInitGen().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitGen
(
void
)
#else
PUBLIC Void ssdDeinitGen()
#endif
{
   TRC0(ssdDeinitGen);

   if( ssDestroySema(&osCp.dep.ssStarted) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not delete the Semaphore");
#endif

   }


   RETVOID;
}


/*
*
*       Fun:   Initialize region/pool tables
*
*       Desc:  This function initializes VxWorks-specific information
*              in the region/pool tables
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitMem
(
void
)
#else
PUBLIC S16 ssdInitMem()
#endif
{
   TRC0(ssdInitMem);


   /* allocate space for the region control block */
   vwCMMRegCb = (CmMmRegCb *)calloc(1, sizeof(CmMmRegCb));
   if (vwCMMRegCb == NULL)
      RETVALUE(RFAILED);


   /* allocate space for the region */
#ifndef SS_CACHE_FUNCTIONS  /* vw019.21: Deletion */
   vwCMMRegCfg.vAddr = (Data *)calloc(VW_MEM_REG_SIZE, sizeof(Data));
#else  /* vw019.21: Addition */
   vwCMMRegCfg.vAddr = (Data *)memalign(_CACHE_ALIGN_SIZE, VW_MEM_REG_SIZE);
#endif /* vw019.21: Addition */
   if (vwCMMRegCfg.vAddr == NULL)
      RETVALUE(RFAILED);


   /* set up the CMM configuration structure */
   vwCMMRegCfg.size = VW_MEM_REG_SIZE;
   vwCMMRegCfg.lType = SS_LOCK_MUTEX;
   vwCMMRegCfg.chFlag = 0;
   vwCMMRegCfg.bktQnSize = 16;
   vwCMMRegCfg.numBkts = 2;

   vwCMMRegCfg.bktCfg[0].size = VW_MBUF_DSIZE;
   vwCMMRegCfg.bktCfg[0].numBlks = VW_MBUF_NMB_BUFS;

   vwCMMRegCfg.bktCfg[1].size = VW_DBUF_DSIZE;
   vwCMMRegCfg.bktCfg[1].numBlks = VW_DBUF_NMB_BUFS;


   /* initialize the CMM */
   if (cmMmRegInit(SS_DFLT_REGION, vwCMMRegCb, &vwCMMRegCfg) != ROK)
      RETVALUE(RFAILED);


   /* initialize the STREAMS module */
   if (ssStrmCfg(SS_DFLT_REGION, SS_DFLT_REGION) != ROK)
      RETVALUE(RFAILED);

/* vw014.21 : Addition */

#ifdef SS_REGION1_SUPPORT
   /* allocate space for the region 1 control block */
   vwCMMReg1Cb = (CmMmRegCb *)calloc(1, sizeof(CmMmRegCb));
   if (vwCMMReg1Cb == NULL)
      RETVALUE(RFAILED);

#ifdef SS_NOCACHE_MEM
   if(SAllocNonCache(VW_MEM_REG1_SIZE, &(vwCMMReg1Cfg.vAddr)) != ROK)
   RETVALUE(RFAILED);
#else
   /* allocate space for the region 1 */
   vwCMMReg1Cfg.vAddr = (Data *)calloc(VW_MEM_REG1_SIZE, sizeof(Data));
   if (vwCMMReg1Cfg.vAddr == NULL)
      RETVALUE(RFAILED);
#endif /* SS_REGION1_SUPPORT */


   /* set up the CMM configuration structure */
   vwCMMReg1Cfg.size = VW_MEM_REG1_SIZE;
   vwCMMReg1Cfg.lType = SS_LOCK_MUTEX;
   vwCMMReg1Cfg.chFlag = 0;
   vwCMMReg1Cfg.bktQnSize = 16;
   vwCMMReg1Cfg.numBkts = 2;

   /* vw024.201 - Modification for REGION1 configuration */
   vwCMMReg1Cfg.bktCfg[0].size = VW_MBUF_DSIZE_REG1;
   vwCMMReg1Cfg.bktCfg[0].numBlks = VW_MBUF_NMB_BUFS_REG1;

   vwCMMReg1Cfg.bktCfg[1].size = VW_DBUF_DSIZE_REG1;
   vwCMMReg1Cfg.bktCfg[1].numBlks = VW_DBUF_NMB_BUFS_REG1;

   /* initialize the CMM */
   if (cmMmRegInit(SS_REGION1, vwCMMReg1Cb, &vwCMMReg1Cfg) != ROK)
      RETVALUE(RFAILED);
#endif /* SS_REGION1_SUPPORT */
/* vw014.21: Addition */

/* vw024.201 - Addition for REGION2 support */
#ifdef SS_REGION2_SUPPORT
   /* allocate space for the region 2 control block */
   vwCMMReg2Cb = (CmMmRegCb *)calloc(1, sizeof(CmMmRegCb));
   if (vwCMMReg2Cb == NULL)
      RETVALUE(RFAILED);

   /* allocate space for the region 2 */
   vwCMMReg2Cfg.vAddr = (Data *) VW_MEM_REG2_ADDR;
   if (vwCMMReg2Cfg.vAddr == NULL)
      RETVALUE(RFAILED);

   /* set up the CMM configuration structure */
   vwCMMReg2Cfg.size = VW_MEM_REG2_SIZE;
   vwCMMReg2Cfg.lType = SS_LOCK_MUTEX;
   vwCMMReg2Cfg.chFlag = 0;
   vwCMMReg2Cfg.bktQnSize = 16;
   vwCMMReg2Cfg.numBkts = 2;

   vwCMMReg2Cfg.bktCfg[0].size = VW_MBUF_DSIZE_REG2;
   vwCMMReg2Cfg.bktCfg[0].numBlks = VW_MBUF_NMB_BUFS_REG2;

   vwCMMReg2Cfg.bktCfg[1].size = VW_DBUF_DSIZE_REG2;
   vwCMMReg2Cfg.bktCfg[1].numBlks = VW_DBUF_NMB_BUFS_REG2;

   /* initialize the CMM */
   if (cmMmRegInit(SS_REGION2, vwCMMReg2Cb, &vwCMMReg2Cfg) != ROK)
      RETVALUE(RFAILED);
#endif /* SS_REGION2_SUPPORT */

   RETVALUE(ROK);
}


/*
*
*       Fun:   De-initialize region/pool tables
*
*       Desc:  This function reverses the initialization in ssdInitMem().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitMem
(
void
)
#else
PUBLIC Void ssdDeinitMem()
#endif
{
   TRC0(ssdDeinitMem);


   cmMmRegDeInit(vwCMMRegCb);
   free(vwCMMRegCfg.vAddr);
   free(vwCMMRegCb);
/* vw014.21: Addition */
#ifdef SS_REGION1_SUPPORT
   cmMmRegDeInit(vwCMMReg1Cb);
#ifdef SS_NOCACHE_MEM
   SFreeNonCache(0,vwCMMReg1Cfg.vAddr);
#else
   free(vwCMMReg1Cfg.vAddr);
#endif /* SS_NOCACHE_MEM */
   free(vwCMMReg1Cb);
#endif /* SS_REGION1_SUPPORT */

/* vw024.201 - Addition for REGION2 support */
#ifdef SS_REGION2_SUPPORT
   cmMmRegDeInit(vwCMMReg2Cb);
   free(vwCMMReg2Cb);
#endif

   RETVOID;
}


/*
*
*       Fun:   Initialize task table
*
*       Desc:  This function initializes VxWorks-specific information
*              in the task table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitTsk
(
void
)
#else
PUBLIC S16 ssdInitTsk()
#endif
{
   REG1 S16 i;


   TRC0(ssdInitTsk);

   for (i = 0;  i < SS_MAX_STSKS;  i++)
   {
      osCp.sTskTbl[i].dep.tId = 0;
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   Deinitialize task table
*
*       Desc:  This function reverses the initialization perfomed in
*              ssdInitTsk().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitTsk
(
void
)
#else
PUBLIC Void ssdDeinitTsk()
#endif
{
   TRC0(ssdDeinitTsk);

   RETVOID;
}


#ifdef SS_DRVR_SUPPORT
/*
*
*       Fun:   Initialize driver information
*
*       Desc:  This function initializes VxWorks-specific information
*              in the driver information structure
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitDrvr
(
void
)
#else
PUBLIC S16 ssdInitDrvr()
#endif
{
   S16 i;


   TRC0(ssdInitDrvr);


   /* initialize dependent portion of driver task entries */
   for (i = 0;  i < SS_MAX_DRVRTSKS;  i++)
   {
      osCp.drvrTskTbl[i].dep.flag = FALSE;
   }


   /* create message queue for the interrupt service task */
   osCp.dep.isTskHdlrQId = msgQCreate(VW_MAX_ISTSK_MSGS,
                                 sizeof(VwIsFlag), MSG_Q_FIFO);
   if (osCp.dep.isTskHdlrQId == NULL)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW001, ERRZERO, "msgQCreate() failed");
#endif

      RETVALUE(RFAILED);
   }


   /* create driver interrupt service task */
   osCp.dep.isTskHdlrTId = taskSpawn("VWSS_ISTSK", VW_ISTASK_PRIORITY, VX_STDIO,
                              VW_ISTASK_STACK, (FUNCPTR)vwIsTskHdlr,
                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
   if (osCp.dep.isTskHdlrTId == NULL)
   {
      msgQDelete(osCp.dep.isTskHdlrQId);

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW002, ERRZERO, "taskSpawn() failed");
#endif

      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   Deinitialize driver information
*
*       Desc:  This function reverses the initialization performed in
*              ssdInitDrvr().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitDrvr
(
void
)
#else
PUBLIC Void ssdDeinitDrvr()
#endif
{
   TRC0(ssdDeinitDrvr);


   /* delete the IS task handler */
   taskDelete(osCp.dep.isTskHdlrTId);


   /* delete the IS task handler's message queue */
   msgQDelete(osCp.dep.isTskHdlrQId);


   RETVOID;
}
#endif


/*
*
*       Fun:   Initialize timer table
*
*       Desc:  This function initializes VxWorks-specific information
*              in the timer table
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitTmr
(
void
)
#else
PUBLIC S16 ssdInitTmr()
#endif
{
   S16 i;
   S32 tmr_ticks;


   TRC0(ssdInitTmr);

   /* vw026.201 - Removal of setting system clock resolution */
   
   /* get the system clock rate for a timing multiplier */
   tmr_ticks = sysClkRateGet();

#if (ERRCLASS & ERRCLS_DEBUG)
   /* vw029.201 - Modification to support SRegCfgTmr */
   if (tmr_ticks < SS_TICKS_SEC)
   {
      VWLOGERROR(ERRCLS_DEBUG, EVW003, ERRZERO, "Clock rate too slow");
      RETVALUE(RFAILED);
   }
   if (SS_1MS < SS_TICKS_SEC)
   {
      VWLOGERROR(ERRCLS_DEBUG, EVW003, ERRZERO, "Minimum SSI ticks is 1ms");
      RETVALUE(RFAILED);
   }
#endif

   /* vw029.201 - Modification to support SRegCfgTmr */
   osCp.dep.tmrMultiplier = tmr_ticks / SS_TICKS_SEC;


   /* initialize timer IDs */
   for (i = 0;  i < SS_MAX_TMRS;  i++)
      osCp.tmrTbl[i].dep.wdId = 0;


   /* create the timer handler's message queue */
   osCp.dep.tmrHdlrQId = msgQCreate(VW_MAX_TMRTSK_MSGS,
                                       sizeof(SsTmrEntry *), MSG_Q_FIFO);
   if (osCp.dep.tmrHdlrQId == NULL)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW004, ERRZERO, "msgQCreate() failed");
#endif

      RETVALUE(RFAILED);
   }


   /* start the timer handler task */
   osCp.dep.tmrHdlrTId = taskSpawn("VWSS_TMRTSK", VW_TMRTASK_PRIORITY, VX_STDIO,
                              VW_TMRTASK_STACK, (FUNCPTR)vwTmrHdlr,
                              0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
   if (osCp.dep.tmrHdlrTId == NULL)
   {
      msgQDelete(osCp.dep.tmrHdlrQId);

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW005, ERRZERO, "taskSpawn() failed");
#endif

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}


/*
*
*       Fun:   Deinitialize timer table
*
*       Desc:  This function reverses the initialization performed in
*              ssdInitTmr().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitTmr
(
void
)
#else
PUBLIC Void ssdDeinitTmr()
#endif
{
   TRC0(ssdDeinitTmr);

   /* vw030.201 */
   /* delete the timer task handler */
   taskDelete(osCp.dep.tmrHdlrTId);

   /* delete the timer task handler's message queue */
   msgQDelete(osCp.dep.tmrHdlrQId);

   RETVOID;
}


/*
*
*       Fun:   ssdInitFinal
*
*       Desc:  Pre-tst() initialization.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitFinal
(
void
)
#else
PUBLIC S16 ssdInitFinal()
#endif
{
   TRC0(ssdInitFinal);


   kernelTimeSlice(VW_TIMESLICE);


   RETVALUE(ROK);
}


/*
*
*       Fun:   ssdDeinitFinal
*
*       Desc:  This function reverses the initialization performed in
*              ssdInitFinal().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitFinal
(
void
)
#else
PUBLIC Void ssdDeinitFinal()
#endif
{
   TRC0(ssdDeinitFinal);


   RETVOID;
}


/*
*
*       Fun:   Start execution
*
*       Desc:  This function is the VxWorks-specific entry point for
*              System Services. It need not return.
*
*       Ret:   Void
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdStart
(
void
)
#else
PUBLIC Void ssdStart()
#endif
{
   S16 i;


   TRC0(ssdStart);


   for (i = 0;  i < SS_MAX_STSKS;  i++)
   {
      if (ssPostSema(&osCp.dep.ssStarted) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
      }
   }

   RETVOID;
}



/*
*       indirect interface functions to system services service user
*/


/*
*
*       Fun:   ssdAttachTTsk
*
*       Desc:  This function sends the initial tick message to a TAPA
*              task if the task is a permanent task.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdAttachTTsk
(
SsTTskEntry *tTsk           /* pointer to TAPA task entry */
)
#else
PUBLIC S16 ssdAttachTTsk(tTsk)
SsTTskEntry *tTsk;          /* pointer to TAPA task entry */
#endif
{
   Buffer *mBuf;
   SsMsgInfo *mInfo;
   S16 ret;


   TRC0(ssdAttachTTsk);


   if (tTsk->tskType == SS_TSK_PERMANENT)
   {
      /* Send a permanent tick message to this task, to start
       * execution.
       */
      ret = SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf);
      if (ret != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW006, ret, "SGetMsg() failed");
#endif
         RETVALUE(RFAILED);
      }

      mInfo = (SsMsgInfo *)mBuf->b_rptr;
      mInfo->eventInfo.event = SS_EVNT_PERMTICK;

      /* set up post structure */
      mInfo->pst.dstProcId = SFndProcId();
      mInfo->pst.srcProcId = SFndProcId();
      mInfo->pst.selector  = SEL_LC_NEW;
      mInfo->pst.region    = DFLT_REGION;
      mInfo->pst.pool      = DFLT_POOL;
      mInfo->pst.prior     = PRIOR3;
      mInfo->pst.route     = RTESPEC;
      mInfo->pst.event     = 0;
      mInfo->pst.dstEnt    = tTsk->ent;
      mInfo->pst.dstInst   = tTsk->inst;
      mInfo->pst.srcEnt    = tTsk->ent;
      mInfo->pst.srcInst   = tTsk->inst;

      ret = ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf,
                           (tTsk->tskPrior * SS_MAX_MSG_PRI) + PRIOR3);

      if (ret != ROK)
      {
         SPutMsg(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW007, ret,
                        "Could not write to demand queue");
#endif
         RETVALUE(RFAILED);
      }
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   ssdDetachTTsk
*
*       Desc:  This function marks the permanent tick message for
*              a permanent task to be dropped.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdDetachTTsk
(
SsTTskEntry *tTsk           /* pointer to TAPA task entry */
)
#else
PUBLIC S16 ssdDetachTTsk(tTsk)
SsTTskEntry *tTsk;          /* pointer to TAPA task entry */
#endif
{
   TRC0(ssdDetachTTsk);


   RETVALUE(ROK);
}


/* vw022.201 - Addition of vwCreateSTsk */
/*
*
*       Fun:   Create named system task
*
*       Desc:  This function is used to create a system task. An
*              entry is located in the system task table.
*              Priorities for vxworks can be given from 0 to 255.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*              ROUTRES  - failed, out of resources (optional)
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 vwCreateSTsk
(
SSTskPrior tskPrior,            /* task priority */
SSTskId *tskId,                 /* filled in with system task ID */
Txt *tskname
)
#else
PUBLIC S16 vwCreateSTsk(tskPrior, tskId, tskname)
SSTskPrior tskPrior;            /* task priority */
SSTskId *tskId;                 /* filled in with system task ID */
Txt *tskname;
#endif
{
   S16 ret;
   SsSTskEntry *sTsk;


   TRC1(vwCreateSTsk);


#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check task ID pointer */
   if (tskId == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW008, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }

   /* check system task priority */
   if ((tskPrior > VW_LOWEST_STSK_PRIOR) || (tskPrior < VW_HIGHEST_STSK_PRIOR))
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW010, ERRZERO,
                     "Invalid system task priority");
      RETVALUE(RFAILED);
   }
#endif

   /* lock the system task table */ 
   ret = SLock(&osCp.sTskTblLock);
   if (ret != ROK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW011, (ErrVal) ret,
                     "Could not lock system task table");
#endif

      RETVALUE(RFAILED);
   }

#ifdef SS_SINGLE_THREADED
   /* When singlethreaded, we only need to create one... */
   if (osCp.numSTsks == 1)
   {
      *tskId = 0;
      osCp.sTskTbl[0].termPend = FALSE;
      if ( SUnlock(&osCp.sTskTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW012, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
      }

      RETVALUE(ROK);
   }
#endif /* SS_SINGLE_THREADED */

   /* check count of system tasks */
   if (osCp.numSTsks == SS_MAX_STSKS)
   {
      if ( SUnlock(&osCp.sTskTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW013, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
      }
#if (ERRCLASS & ERRCLS_ADD_RES)
      VWLOGERROR(ERRCLS_ADD_RES, EVW014, ERRZERO, "Too many system tasks");
#endif

      RETVALUE(ROUTRES);
   }
   /* initialize the system task entry with the information we have */
   sTsk = &osCp.sTskTbl[osCp.nxtSTskEntry];

   /* store the system task priority */
   sTsk->tskPrior = tskPrior;

   /* initialize the demand queue */
   if (ssInitDmndQ(&sTsk->dQ) != ROK)
   {
      if ( SUnlock(&osCp.sTskTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW015, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
      }
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW016, (ErrVal) ret,
                  "Could not initialize demand queue");
#endif
      RETVALUE(RFAILED);
   }
   /* initialize the system task entry lock */
   if (SInitLock(&sTsk->lock, SS_STSKENTRY_LOCK) != ROK)
   {
      ssDestroyDmndQ(&sTsk->dQ);
      if ( SUnlock(&osCp.sTskTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW017, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
      }

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW018, (ErrVal) ret,
                  "Could not initialize system task entry lock");
#endif

      RETVALUE(RFAILED);
   }

#ifdef SS_SINGLE_THREADED
   if (osCp.numSTsks <= 0)
#endif
   {
      /* set the current executing entity and instance IDs to
       * 'not configured'. create the lock to access them.
       */
      sTsk->dep.ent = ENTNC;
      sTsk->dep.inst = INSTNC;
      if ((SInitLock(&sTsk->dep.lock, SS_LOCK_MUTEX)) != ROK)
      {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW008, ERRZERO, "Could not create lock");
#endif

      RETVALUE(RFAILED);
      }

      /* spawn a new task */
      sTsk->dep.tId = taskSpawn(tskname, tskPrior, VX_STDIO, VW_TASK_STACK,
                              (FUNCPTR)vwTskHdlr, (U32)sTsk,
                              0, 0, 0, 0, 0, 0, 0, 0, 0);
      if (sTsk->dep.tId == NULL)
      {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW009, ERRZERO, "taskSpawn() failed");
#endif
      
         /* failed, clean up */
         SDestroyLock(&sTsk->lock);
         ssDestroyDmndQ(&sTsk->dQ);
         sTsk->tskPrior = 0;
         if ( SUnlock(&osCp.sTskTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW010, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
         } 
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW011, (ErrVal) ret,
                  "Could not create system task");
#endif

         RETVALUE(RFAILED);
      
      }
   }
   
   /* success, update the table */
   *tskId = osCp.nxtSTskEntry;
   sTsk->tskId       = osCp.nxtSTskEntry;
   sTsk->used        = TRUE;
   sTsk->termPend    = FALSE;
   osCp.nxtSTskEntry = sTsk->nxt;
   osCp.numSTsks++;

   /* unlock the system task table */
      if ( SUnlock(&osCp.sTskTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
           VWLOGERROR(ERRCLS_DEBUG, EVW012, ERRZERO,
                       "Could not give the Semaphore");
           RETVALUE(RFAILED);
#endif
      }

   RETVALUE(ROK);

} /* vwCreateSTsk */

/*
*
*       Fun:   ssdCreateSTsk
*
*       Desc:  This function creates a system task. A thread is started
*              on the system task handler function defined by SS.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdCreateSTsk
(
SsSTskEntry *sTsk           /* pointer to system task entry */
)
#else
PUBLIC S16 ssdCreateSTsk(sTsk)
SsSTskEntry *sTsk;          /* pointer to system task entry */
#endif
{
   S32 pr;
   char name[128];


   TRC0(ssdCreateSTsk);


#ifdef SS_SINGLE_THREADED
   if (osCp.numSTsks > 0)
   {
      RETVALUE(ROK);
   }
#endif


   /* set the current executing entity and instance IDs to
    * 'not configured'. create the lock to access them.
    */
   sTsk->dep.ent = ENTNC;
   sTsk->dep.inst = INSTNC;
   if ((SInitLock(&sTsk->dep.lock, SS_LOCK_MUTEX)) != ROK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW008, ERRZERO, "Could not create lock");
#endif

      RETVALUE(RFAILED);
   }


   /* generate a task name */
   sprintf(name, "%s%p", "VWSS_STSK", sTsk);


   /* translate system task priority to VxWorks task priority */
   if (sTsk->tskPrior < 16)
   {
      pr = VW_TASK_PRIORITY_LOW;
   }
   else
   {
      pr = VW_TASK_PRIORITY_HIGH;
   }


   /* spawn a new task */
   sTsk->dep.tId = taskSpawn(name, pr, VX_STDIO, VW_TASK_STACK,
                              (FUNCPTR)vwTskHdlr, (U32)sTsk,
                              0, 0, 0, 0, 0, 0, 0, 0, 0);
   if (sTsk->dep.tId == NULL)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW009, ERRZERO, "taskSpawn() failed");
#endif

      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   ssdDestroySTsk
*
*       Desc:  This function destroys a system task.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdDestroySTsk
(
SsSTskEntry *sTsk           /* pointer to system task entry */
)
#else
PUBLIC S16 ssdDestroySTsk(sTsk)
SsSTskEntry *sTsk;          /* pointer to system task entry */
#endif
{
   Buffer *mBuf;
   SsMsgInfo *mInfo;


   TRC0(ssdDestroySTsk);


   /* we send a message to this system task to tell it to die */
   if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) != ROK)
   {

#if (ERRCLASS & ERRCLASS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW010, ERRZERO, "SGetMsg() failed");
#endif

      RETVALUE(RFAILED);
   }

   mInfo = (SsMsgInfo *)mBuf->b_rptr;
   mInfo->eventInfo.event = SS_EVNT_TERM;

   if (ssDmndQPutLast(&sTsk->dQ, mBuf, 0) != ROK)
   {
      SPutMsg(mBuf);

#if (ERRCLASS & ERRCLASS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW011, ERRZERO,
                     "Could not write to demand queue");
#endif

      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   Register timer
*
*       Desc:  This function is used to register a timer function for the
*              layer. The system services will periodically invoke the
*              function passed to it. The timer function will be used by the
*              layer to manage the layers internal protocol timers.
*              The timer entry will be recorded into the timer table and a
*              Vxworks timer will be started.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdRegTmr
(
SsTmrEntry *tmr             /* pointer to timer entry */
)
#else
PUBLIC S16 ssdRegTmr(tmr)
SsTmrEntry *tmr;            /* pointer to timer entry */
#endif
{
   TRC0(ssdRegTmr);


   /* create the watchdog timer */
   tmr->dep.wdId = wdCreate();
   if (tmr->dep.wdId == NULL)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW012, ERRZERO, "wdCreate() failed");
#endif

      RETVALUE(RFAILED);
   }


   /* start the timer */
   if (wdStart(tmr->dep.wdId, (tmr->interval * osCp.dep.tmrMultiplier),
                  (FUNCPTR)vwTimeout, (U32)tmr) != OK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW013, ERRZERO, "wdStart() failed");
#endif

      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   Deregister timer
*
*       Desc:  This function is used to deregister a timer function.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdDeregTmr
(
SsTmrEntry *tmr             /* pointer to timer entry */
)
#else
PUBLIC S16 ssdDeregTmr(tmr)
SsTmrEntry *tmr;            /* pointer to timer entry */
#endif
{
   TRC0(ssdDeregTmr);


   wdDelete(tmr->dep.wdId);
   tmr->dep.wdId = NULLP;


   RETVALUE(ROK);
}


/*
*
*       Fun:   Critical error
*
*       Desc:  This function is called when a critical error occurs.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdError
(
Seq seq,                    /* sequence number */
Reason reason               /* reset reason */
)
#else
PUBLIC S16 ssdError(seq, reason)
Seq seq;                    /* sequence number */
Reason reason;              /* reset reason */
#endif
{
   S16 i;
   U32 tskId;
   Txt errBuf[256];


   TRC0(ssdError);


   tskId = taskIdSelf();

   sprintf(errBuf, "\n\nFATAL ERROR - taskid = %lx, name %s, errno = %d,"
            "reason = %d\n\n", tskId, taskName(tskId), seq, reason);
   SPrint(errBuf);


   /* delete all system tasks */
   for (i = 0;  i < SS_MAX_STSKS;  i++)
      if (osCp.sTskTbl[i].used  &&  osCp.sTskTbl[i].dep.tId != tskId)
         taskDelete(osCp.sTskTbl[i].dep.tId);


   /* delete self */
   taskDelete(tskId);


   /* won't reach here */
   RETVALUE(ROK);
}


/*
*
*       Fun:   Log error
*
*       Desc:  This function is called to log an error.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void ssdLogError
(
Ent ent,                    /* Calling layer's entity id */
Inst inst,                  /* Calling layer's instance id */
ProcId procId,              /* Calling layer's processor id */
Txt *file,                  /* file name where error occured */
S32 line,                   /* line in file where error occured */
ErrCls errCls,              /* error class */
ErrCode errCode,            /* layer unique error code */
ErrVal errVal,              /* error value */
Txt *errDesc                /* description of error */
)
#else
PUBLIC Void ssdLogError(ent, inst, procId, file, line,
                        errCls, errCode, errVal, errDesc)
Ent ent;                    /* Calling layer's entity id */
Inst inst;                  /* Calling layer's instance id */
ProcId procId;              /* Calling layer's processor id */
Txt *file;                  /* file name where error occured */
S32 line;                   /* line in file where error occured */
ErrCls errCls;              /* error class */
ErrCode errCode;            /* layer unique error code */
ErrVal errVal;              /* error value */
Txt *errDesc;               /* description of error */
#endif
{
   S16 i;
   U32 tskId;
   Txt *errClsMsg;
   Txt errBuf[512];


   TRC0(ssdLogError);


   tskId = taskIdSelf();

   switch (errCls)
   {
      case ERRCLS_ADD_RES:
         errClsMsg = "ERRCLS_ADD_RES";
         break;

      case ERRCLS_INT_PAR:
         errClsMsg = "ERRCLS_INT_PAR";
         break;

      case ERRCLS_DEBUG:
         errClsMsg = "ERRCLS_DEBUG";
         break;

      default:
         errClsMsg = "INVALID ERROR CLASS!";
         break;
   }

   sprintf(errBuf, "\nvwss(vxworks): sw error:  ent: %03d  inst: %03d  "
             "proc id: %03d\nfile: %s line: %03ld errcode: %05ld "
             "errcls: %s\nerrval: %05ld  errdesc: %s\n",
             ent, inst, procId, file, line, errCode, errClsMsg,
             errVal, errDesc);
   SDisplay(0, errBuf);

#ifndef DEBUGNOEXIT
   if (errCls == ERRCLS_DEBUG)
   {
      /* delete all system tasks */
      for (i = 0;  i < SS_MAX_STSKS;  i++)
         if (osCp.sTskTbl[i].used  &&  osCp.sTskTbl[i].dep.tId != tskId)
            taskDelete(osCp.sTskTbl[i].dep.tId);

      /* delete self */
      taskDelete(tskId);
   }
#endif /* DEBUGNOEXIT */


   RETVOID;
}

#ifdef SS_DRVR_SUPPORT

/*
*
*       Fun:   ssdRegDrvrTsk
*
*       Desc:  This function is called to register the handlers for a
*              driver task.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdRegDrvrTsk
(
SsDrvrTskEntry *drvrTsk         /* driver task entry */
)
#else
PUBLIC S16 ssdRegDrvrTsk(drvrTsk)
SsDrvrTskEntry *drvrTsk;        /* driver task entry */
#endif
{
   TRC0(ss_regDrvrTsk);


   RETVALUE(ROK);
}
#endif




/*
*       private support functions
*/


/*
*
*       Fun:   Task handler
*
*       Desc:  This function will pend on a particular message queue.
*              When a message arrives, an event in the first byte of
*              this message will indicate that the message is a timer
*              message or task message.  If it's a timer message, an
*              identifier in the mesaage will indicate which timer has
*              expired.  The appropriate timer function will then be
*              called.  If it's a task message, a user registered function
*              will then be invoked.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PRIVATE Void vwTskHdlr
(
U32 arg                         /* pointer to the system task entry */
)
#else
PRIVATE Void vwTskHdlr(arg)
U32 arg;                        /* pointer to the system task entry */
#endif
{
   S16 i, ticks;   /* vw015.21: added ticks */
   S16 ret;
   SsIdx idx;
   SsSTskEntry *sTsk;
   SsTTskEntry *tTsk;
   Buffer *mBuf;
   SsMsgInfo *mInfo;
   Pst nPst;
   PFS16 tmrActvFn;


   TRC0(vwTskHdlr);


   sTsk = (SsSTskEntry *) arg;



   if( ssWaitSema(&osCp.dep.ssStarted) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not lock the Semaphore");
#endif
   }
   for (; ;)
   {
      /* get a message from the demand queue */
      ret = ssDmndQGet(&sTsk->dQ, &mBuf, SS_DQ_FIRST);
      if (ret != ROK)
      continue;


      /* if we can't lock this system task entry, return the message */
      ret = SLock(&sTsk->lock);
      if (ret != ROK)
      {

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW014, (ErrVal) ret,
                        "Could not lock system task entry");
#endif
         SPutMsg(mBuf);
         continue;
      }


      /* find out what kind of message this is */
      mInfo = (SsMsgInfo *)mBuf->b_rptr;
      switch (mInfo->eventInfo.event)
      {
         /* this is a termination event, we die */
         case SS_EVNT_TERM:
            /* release the message */
            SPutMsg(mBuf);
            if( SUnlock(&sTsk->lock) != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
#endif
            }


            /* lock the system task table to clean our entry up */
            ret = SLock(&osCp.sTskTblLock);
            if (ret != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVW015, (ErrVal) ret,
                           "Could not lock system task table");
#endif
               /* what to do here? */
               continue;
            }

            /* clean up the system task entry */
            sTsk->used = FALSE;
            sTsk->tskPrior = 0;
            sTsk->numTTsks = 0;
            SDestroyLock(&sTsk->lock);
            ssDestroyDmndQ(&sTsk->dQ);

            /* lock for current executing TAPA task */
            if( SLock(&sTsk->dep.lock) != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not Lock the Semaphore");
#endif
            }
            SDestroyLock(&sTsk->dep.lock);

            /* make this entry available in the system task table */
            sTsk->nxt = osCp.nxtSTskEntry;
            for (i = 0;  i < SS_MAX_STSKS;  i++)
            {
               if (sTsk == &osCp.sTskTbl[i])
               {
                  osCp.nxtSTskEntry = i;
                  break;
               }
            }

            osCp.numSTsks--;

            if( SUnlock(&osCp.sTskTblLock) != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
            }
            RETVOID;


         /* this is a data message or a permanent task keep-alive message */
         case SS_EVNT_DATA:
         case SS_EVNT_PERMTICK:
            /* message to a task. find the destination task */
            idx = osCp.tTskIds[mInfo->pst.dstEnt][mInfo->pst.dstInst];

            /* verify that it hasn't been deregistered */
            if (idx == SS_TSKNC)
            {
               SPutMsg(mBuf);
               break;
            }

            /* verify that this system task is still running it */
            tTsk = &osCp.tTskTbl[idx];
            if (tTsk->sTsk != sTsk)
            {
               SPutMsg(mBuf);
               break;
            }

            /* set the current executing TAPA task ID */
            ret = SLock(&sTsk->dep.lock);
            if (ret == ROK)
            {
               sTsk->dep.ent = mInfo->pst.dstEnt;
               sTsk->dep.inst = mInfo->pst.dstInst;

               if( SUnlock(&sTsk->dep.lock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }
            }


            /* copy the Pst structure from the message into a local */
            for (i = 0;  i < (S16) sizeof(Pst);  i++)
            {
               *(((U8 *)(&nPst)) + i) = *(((U8 *)&mInfo->pst) + i);
            }


            /* Give the message to the task activation function. If
             *  its a normal data message, we pass it, if this is a
             *  keep-alive message for a permanent task then we pass
             *  NULLP in place of the message to the task activation
             *  function.
             */
            if (mInfo->eventInfo.event == SS_EVNT_DATA)
            {
               tTsk->actvTsk(&nPst, mBuf);
               ticks = 0; /* vw015.21: addition */
            }
            else
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               /* this message should only come to a permanent task */
               if (tTsk->tskType != SS_TSK_PERMANENT)
               {
                  VWLOGERROR(ERRCLS_DEBUG, EVW016, ERRZERO, "Logic failure");
                  break;
               }
#endif

               tTsk->actvTsk(&nPst, NULLP);


               /* We need to re-send this message back to ourselves so
                *  the permanent task continues to run.
                */
               /* Check if this task got deregistered or detached
                *  by the activation function; if so, there's nothing
                *  more to do here, otherwise go ahead.
                */
               ret = ROK;
               if (tTsk->used == TRUE  &&  tTsk->sTsk != NULLP)
               {
                  ret = ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf,
                              ((tTsk->tskPrior) * SS_MAX_MSG_PRI) +
                              mInfo->pst.prior);
               }


               /* failure here is a real problem */
               if (ret != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVW017, ERRZERO,
                              "Could not write to demand queue");
#endif
                  SPutMsg(mBuf);
               }
               ticks = 1; /* vw015.21: addition */
            }


            /* unset the current executing TAPA task ID */
            ret = SLock(&sTsk->dep.lock);
            if (ret == ROK)
            {
               sTsk->dep.ent = ENTNC;
               sTsk->dep.inst = INSTNC;

               if( SUnlock(&sTsk->dep.lock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }
            }
            break;


         case SS_EVNT_TIMER:
            /* timer event. find the timer entry */
            idx = mInfo->eventInfo.u.tmr.tmrIdx;

            /* lock the timer table, coz we're going to peek in it */
            ret = SLock(&osCp.tmrTblLock);
            if (ret != ROK)
            {

#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVW018, (ErrVal) ret,
                              "Could not lock timer table");
#endif
               SPutMsg(mBuf);
               break;
            }

            /* verify that this timer entry is still around and that it
             *  belongs to our task
             */
            if (osCp.tmrTbl[idx].used == FALSE
                  ||  osCp.tmrTbl[idx].ownerEnt != mInfo->pst.dstEnt
                  ||  osCp.tmrTbl[idx].ownerInst != mInfo->pst.dstInst)
            {

               if( SUnlock(&osCp.tmrTblLock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }
               SPutMsg(mBuf);
               break;
            }

            /* set the current executing TAPA task ID */
            ret = SLock(&sTsk->dep.lock);
            if (ret == ROK)
            {
               sTsk->dep.ent = mInfo->pst.dstEnt;
               sTsk->dep.inst = mInfo->pst.dstInst;

               if( SUnlock(&sTsk->dep.lock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }
            }

            tmrActvFn = osCp.tmrTbl[idx].tmrActvFn;

            /* unlock the timer table */

               if( SUnlock(&osCp.tmrTblLock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }

            /* activate the timer function */
            tmrActvFn();

            /* unset the current executing TAPA task ID */
            ret = SLock(&sTsk->dep.lock);
            if (ret == ROK)
            {
               sTsk->dep.ent = ENTNC;
               sTsk->dep.inst = INSTNC;

               if( SUnlock(&sTsk->dep.lock) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not unlock the Semaphore");
#endif
               }
            }


            /* return the message buffer */
            SPutMsg(mBuf);
            ticks = 0; /* vw015.21: addition */
            break;


         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVW019, (ErrVal) ret,
                        "Illegal event");
#endif
            break;
      }


      /* unlock the system task entry */
      if( SUnlock(&sTsk->lock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
          VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
      }

      /* allow context switches here */
      taskDelay(ticks); /* vw015.21: modified taskDelay parameter
                           from hardcoded '0' to 'ticks' */ 
   }

   /* should not reach here */
}


/*
*
*       Fun:   vwTimeout
*
*       Desc:  This function will be invoked when a VxWorks timer
*              has expired. It posts a message to the timer handler
*              task which will post a timer message to the target
*              TAPA task.
*
*       Ret:   ROK      - ok
*
*       Notes: This function is called in interrupt context and so,
*              should not block.
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PRIVATE Void vwTimeout
(
U32 arg                         /* pointer to timer entry */
)
#else
PRIVATE Void vwTimeout(arg)
U32 arg;                        /* pointer to timer entry */
#endif
{
   SsTmrEntry *tEnt;


   TRC0(vwTimeout);


   /* get the timer entry */
   tEnt = (SsTmrEntry *)arg;


   /* write the pointer to the timer entry into the message queue */
   if (msgQSend(osCp.dep.tmrHdlrQId, (char *)&tEnt, sizeof(SsTmrEntry *),
                  NO_WAIT, MSG_PRI_NORMAL) != OK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVW020, ERRZERO,
                  "Could not write to timer handler message queue");
#endif

      RETVOID;
   }


   RETVOID;
}


/*
*
*       Fun:   vwTmrHdlr
*
*       Desc:  This function pends on a message queue that is fed
*              by the timeout handler. It reads a pointer from the
*              message queue that is a pointer to the timer that
*              expired and posts a timer message to the queue
*              of the target TAPA task.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PRIVATE Void vwTmrHdlr
(
U32 arg                         /* pointer to timer entry */
)
#else
PRIVATE Void vwTmrHdlr(arg)
U32 arg;                        /* pointer to timer entry */
#endif
{
   Buffer *mBuf;
   SsTmrEntry *tEnt;
   SsMsgInfo *mInfo;
   SsTTskEntry *tTsk;
   SsIdx idx;
   S16 ret;


   TRC0(vwTmrHdlr);


   for (; ;)
   {
      if (msgQReceive(osCp.dep.tmrHdlrQId, (char *)&tEnt, sizeof(SsTmrEntry *),
                      WAIT_FOREVER) != sizeof(SsTmrEntry *))
      {
         continue;
      }


      /* lock the timer table */
      if (SLock(&osCp.tmrTblLock) != ROK)
      {

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW021, ERRZERO,
                     "Could not lock timer table");
#endif

         continue;
      }


      /* ensure that this timer is still around */
      if (!tEnt->used)
      {
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }
         continue;
      }


      /* Get a message and set it up to send to the owner task's
       *  demand queue.
       */
      if (SGetMsg(SS_DFLT_REGION, SS_DFLT_POOL, &mBuf) != ROK)
      {
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }

#if (ERRCLASS & ERRCLS_ADD_RES)
         VWLOGERROR(ERRCLS_ADD_RES, EVW022, ERRZERO, "SGetMsg() failed");
#endif

         continue;
      }

      mInfo = (SsMsgInfo *)mBuf->b_rptr;
      mInfo->eventInfo.event = SS_EVNT_TIMER;
      mInfo->eventInfo.u.tmr.tmrIdx = tEnt->tmrId;

      mInfo->pst.dstEnt = tEnt->ownerEnt;
      mInfo->pst.dstInst = tEnt->ownerInst;
      mInfo->pst.srcEnt = tEnt->ownerEnt;
      mInfo->pst.srcInst = tEnt->ownerInst;
      mInfo->pst.dstProcId = SFndProcId();
      mInfo->pst.srcProcId = SFndProcId();
      mInfo->pst.selector = SEL_LC_NEW;
      mInfo->pst.region = DFLT_REGION;
      mInfo->pst.pool = DFLT_POOL;
      mInfo->pst.prior = PRIOR0;
      mInfo->pst.route = RTESPEC;
      mInfo->pst.event = 0;


      /* get a semaphore for the TAPA task table */
      SS_ACQUIRE_SEMA(&osCp.tTskTblSem, ret);
      if (ret != ROK)
      {
         SPutMsg(mBuf);
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW023, ret,
                     "Could not lock TAPA task table");
#endif
         continue;
      }


      /* find the owner TAPA task */
      idx = osCp.tTskIds[tEnt->ownerEnt][tEnt->ownerInst];
      if (idx == SS_TSKNC)
      {
         if( SS_RELEASE_SEMA(&osCp.tTskTblSem) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not release the Semaphore");
#endif
         }
         SPutMsg(mBuf);
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }
         continue;
      }


      /* ensure that the TAPA task is hale and hearty */
      tTsk = &osCp.tTskTbl[idx];
      if (!tTsk->used)
      {
         if( SS_RELEASE_SEMA(&osCp.tTskTblSem) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not release the Semaphore");
#endif
         }
         SPutMsg(mBuf);
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }
         continue;
      }


      /* write the timer message to the queue of the destination task */
      if (ssDmndQPutLast(&tTsk->sTsk->dQ, mBuf,
                  (tTsk->tskPrior * SS_MAX_MSG_PRI) + PRIOR0) != ROK)
      {
         if( SS_RELEASE_SEMA(&osCp.tTskTblSem) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not release the Semaphore");
#endif
         }
         SPutMsg(mBuf);
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW024, ERRZERO,
                        "Could not write to demand queue");
#endif

         continue;
      }


      /* release the semaphore for the TAPA task table */
         if( SS_RELEASE_SEMA(&osCp.tTskTblSem)!= ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not release the Semaphore");
#endif
         }


      /* restart the timer */
      if (wdStart(tEnt->dep.wdId, (tEnt->interval * osCp.dep.tmrMultiplier),
                     (FUNCPTR)vwTimeout, (U32)tEnt) != OK)
      {
         if( SUnlock(&osCp.tmrTblLock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
         }

#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVW025, ERRZERO, "wdStart failed");
#endif

         continue;
      }


      /* timer message is on its way, timer is restarted, we're done */
      if( SUnlock(&osCp.tmrTblLock) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
          VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not unlock the Semaphore");
#endif
      }
   }


   /* should not reach here */
}

#ifdef SS_DRVR_SUPPORT

/*
*
*       Fun:   vwIsTskHdlr
*
*       Desc:  This function handles scheduling of interrupt service
*              tasks. It is started and stopped by SSetIntPend().
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PRIVATE Void vwIsTskHdlr
(
U32 arg                         /* argument */
)
#else
PRIVATE Void vwIsTskHdlr(arg)
U32 arg;                        /* argument */
#endif
{
   VwIsFlag isFlag;


   TRC0(vwIsTskHdlr);


   for (; ;)
   {
      if (msgQReceive(osCp.dep.isTskHdlrQId, (char *)&isFlag, sizeof(VwIsFlag),
                      WAIT_FOREVER) != sizeof(VwIsFlag))
      {
         continue;
      }


      switch (isFlag.action)
      {
         case VW_IS_SET:
            osCp.drvrTskTbl[isFlag.id].dep.flag = TRUE;

            /* call the interrupt service task activation function */
            osCp.drvrTskTbl[isFlag.id].isTsk(isFlag.id);

            /* send self a message to keep doing this */
            isFlag.action = VW_IS_RESET;
            if (msgQSend(osCp.dep.isTskHdlrQId, (char *)&isFlag, sizeof(isFlag),
                        NO_WAIT, MSG_PRI_NORMAL) != OK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVW026, ERRZERO, "msgQSend() failed");
#endif
            }

            break;


         case VW_IS_UNSET:
            osCp.drvrTskTbl[isFlag.id].dep.flag = FALSE;
            break;


         case VW_IS_RESET:
            if (osCp.drvrTskTbl[isFlag.id].dep.flag)
            {
               /* call the interrupt service task activation function */
               osCp.drvrTskTbl[isFlag.id].isTsk(isFlag.id);

               /* send self a message to do this again */
               if (msgQSend(osCp.dep.isTskHdlrQId, (char *)&isFlag,
                           sizeof(isFlag), NO_WAIT, MSG_PRI_NORMAL) != OK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  VWLOGERROR(ERRCLS_DEBUG, EVW027, ERRZERO,
                              "msgQSend() failed");
#endif
               }
            }
            break;


         default:
            /* where did THIS come from?? */
            break;
      }
   }


   /* not reached */
   RETVOID;
}
#endif /* SS_DRVR_SUPPORT */




/*
*       interface functions
*/


/*
*
*       Fun:   SDisplay
*
*       Desc:  This function displays a string to a given output
*              channel. The current implementation logs the string
*              with VxWorks' message logging facility.
*
*       Ret:   ROK      - ok
*
*       Notes: Buffer should be null terminated.
*
*              channel 0 is reserved for backwards compatibility
*              with SPrint
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SDisplay
(
S16 chan,                   /* channel */
Txt *buf                    /* buffer */
)
#else
PUBLIC S16 SDisplay(chan, buf)
S16 chan;                   /* channel */
Txt *buf;                   /* buffer */
#endif
{
   static char text[512];


   TRC1(SDisplay);


#if (ERRCLASS & ERRCLS_INT_PAR)
    if (buf == NULLP)
    {
        VWLOGERROR(ERRCLS_INT_PAR, EVW028, ERRZERO, "Null pointer");
        RETVALUE(RFAILED);
    }
#endif


   if (intContext())
   {
      strncpy (text, buf, 510);
      text[510] = '\0';
      logMsg("%s", (int) text, 0, 0, 0, 0, 0);
   }
   else
   {
      printf("%s", buf);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   Set date and time
*
*       Desc:  This function is used to set the calendar
*              date and time.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SSetDateTime
(
REG1 DateTime *dt           /* date and time */
)
#else
PUBLIC S16 SSetDateTime(dt)
REG1 DateTime *dt;          /* date and time */
#endif
{
   TRC1(SSetDateTime);


   UNUSED(dt);


   RETVALUE(ROK);
}


/*
*
*       Fun:   Get date and time
*
*       Desc:  This function is used to determine the calendar
*              date and time. This information may be used for
*              some management functions.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetDateTime
(
REG1 DateTime *dt           /* date and time */
)
#else
PUBLIC S16 SGetDateTime(dt)
REG1 DateTime *dt;          /* date and time */
#endif
{
   struct tm *timePtr;
   time_t tmInSec;


   TRC1(SGetDateTime);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dt == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW029, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


   time(&tmInSec);
   timePtr = localtime(&tmInSec);

   dt->year   = (U8) timePtr->tm_year;
   dt->month  = (U8) timePtr->tm_mon + 1;
   dt->day    = (U8) timePtr->tm_mday;
   dt->hour   = (U8) timePtr->tm_hour;
   dt->min    = (U8) timePtr->tm_min;
   dt->sec    = (U8) timePtr->tm_sec;
   dt->tenths = 0;


   RETVALUE(ROK);
}


/*
*
*       Fun:   Get system time
*
*       Desc:  This function is used to determine the system
*              time. This information may be used for
*              some management functions.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetSysTime
(
Ticks *sysTime              /* system time */
)
#else
PUBLIC S16 SGetSysTime(sysTime)
Ticks *sysTime;             /* system time */
#endif
{
   TRC1(SGetSysTime);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sysTime == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW030, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


   *sysTime = (Ticks)(tickGet() / osCp.dep.tmrMultiplier);


   RETVALUE(ROK);
}

/* vw023.201 - Addition of SGetRefTime function */
/*
*
*       Fun:   Get referenced time
*
*       Desc:  This function is used to determine the time in seconds
*              and microseconds from a reference time.  The reference
*              time is expressed in seconds from UTC EPOC, January 1,
*              1970.
*
*       Ret:   ROK      - ok
*              RFAILED  - fail
*
*       Notes: Resolution of this function is determined by SYS_CLK_RATE_MIN
*              and SYS_CLK_RATE_MAX settings defined to build specific BSP.
*              Resolution of clock can be changed using VxWorks sysClkRateSet
*              call having in mind that it affects any applications on the
*              system depending on real-time clock. 
*              
*              Macros are defined for reference times:
*                 SS_REFTIME_01_01_1970
*                 SS_REFTIME_01_01_2002
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetRefTime
(
U32 refTime,             /* reference time */
U32 *sec,		/* returned referenced seconds */
U32 *usec		/* returned referenced micro seconds */
)
#else
PUBLIC S16 SGetRefTime(refTime, sec, usec)
U32 refTime;             /* reference time */
U32 *sec;		/* returned referenced seconds */
U32 *usec;		/* returned referenced micro seconds */
#endif
{
	
   struct timespec ptime;
   
   TRC1(SGetSysTime);

   clock_gettime(CLOCK_REALTIME, &ptime);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sec == NULLP || usec == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVWXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
   if (refTime > ptime.tv_sec)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVWXXX, ERRZERO, "Reference time exceeds present time");
      RETVALUE(RFAILED);
   }
#endif

   *sec = ptime.tv_sec - refTime;
   *usec = ptime.tv_nsec / 1000;

  RETVALUE(ROK);

}


/*
*
*       Fun:   Get Random Number
*
*       Desc:  Invoked by layer when a pseudorandom number
*              is required.
*
*       Ret:   ROK      - ok
*
*       Notes: Suggested approach uses shuffled Linear Congruential
*              Operators as described in Byte magazine October
*              1984; "Generating and Testing Pseudorandom Numbers"
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SRandom
(
Random *value               /* random number */
)
#else
PUBLIC S16 SRandom(value)
Random *value;              /* random number */
#endif
{
   TRC1(SRandom);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if( value == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW031, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   *value = (Random) rand();


   RETVALUE(ROK);
}

/* vw021.201: add SExit function */
/*
*
*       Fun:   SExit 
*
*       Desc:  This function exits all TAPA module.
*
*       Ret:   Void 
*
*       Notes: 
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC Void SExit 
(
void
)
#else
PUBLIC Void SExit()
#endif
{
   S16 i;
   U32 tskId;

   TRC1(SExit);

   tskId = taskIdSelf();

   /* delete all system tasks */
   for (i = 0; i < SS_MAX_STSKS; i++)
      if (osCp.sTskTbl[i].used && osCp.sTskTbl[i].dep.tId != tskId)
         taskDelete(osCp.sTskTbl[i].dep.tId);

   /* delete driver interrupt service task */
#ifdef SS_DRVR_SUPPORT
   if (osCp.dep.isTskHdlrTId != tskId && osCp.dep.isTskHdlrTId != NULL)
      taskDelete(osCp.dep.isTskHdlrTId);
#endif /* end of SS_DRVR_SUPPORT */

   /* delete the timer handler task */
   if (osCp.dep.tmrHdlrTId != tskId && osCp.dep.tmrHdlrTId != NULL)
      taskDelete(osCp.dep.tmrHdlrTId);

   /* delete DPR task */
#ifdef SS_AEHDPR_SUPPORT
   for (i = 0; i < MAX_DPR_PRIORITY; i++)
      if (sDprTbl[i].valid && sDprTbl[i].tid != tskId)
         taskDelete(sDprTbl[i].tid);
#endif /* SS_AEHDPR_SUPPORT */

   /* delete self */
   taskDelete(tskId);

   /* won't reach here */
   RETVOID;
}

/*
*
*       Fun:   Exit Task
*
*       Desc:  This function exits from a task.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing.
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SExitTsk
(
void
)
#else
PUBLIC S16 SExitTsk()
#endif
{
   TRC1(SExitTsk);


   RETVALUE(ROK);
}


/*
*
*       Fun:   Exit Interrupt
*
*       Desc:  This function exits from an interrupt.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing.
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SExitInt
(
void
)
#else
PUBLIC S16 SExitInt()
#endif
{
   TRC1(SExitInt);


   RETVALUE(ROK);
}


/*
*
*       Fun:   Hold Interrupt
*
*       Desc:  This function prohibits interrupts from being enabled until
*              release interrupt. This function should be called when
*              interrupts are disabled and prior to any call to system
*              services either by entry to an interrupt service routine or
*              by explicit call to disable interrupt.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SHoldInt
(
void
)
#else
PUBLIC S16 SHoldInt()
#endif
{
   TRC1(SHoldInt);


   if (osCp.dep.intHoldCnt == 0)
      osCp.dep.prevIntLevel = intLevelSet(osCp.dep.intLckLevel);

   osCp.dep.intHoldCnt++;


   RETVALUE(ROK);
}


/*
*
*       Fun:   Release Interrupt
*
*       Desc:  This function allows interrupts to be enabled.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SRelInt
(
void
)
#else
PUBLIC S16 SRelInt()
#endif
{
   TRC1(SRelInt);


   osCp.dep.intHoldCnt--;
   if (osCp.dep.intHoldCnt == 0)
      intLevelSet(osCp.dep.prevIntLevel);


   RETVALUE(ROK);
}


/*
*
*       Fun:   Enable interrupt
*
*       Desc:  This function enables interrupts.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SEnbInt
(
void
)
#else
PUBLIC S16 SEnbInt()
#endif
{
   TRC1(SEnbInt);


   if (osCp.dep.intCnt <= 0)
   {
      RETVALUE(RFAILED);
   }


   osCp.dep.intCnt--;
   if (osCp.dep.intCnt == 0)
      intUnlock(osCp.dep.intKey);


   RETVALUE(ROK);
}


/*
*
*       Fun:   Disable interrupt
*
*       Desc:  This function disables interrupts.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SDisInt
(
void
)
#else
PUBLIC S16 SDisInt()
#endif
{
   TRC1(SDisInt);


   if (osCp.dep.intCnt == 0)
      osCp.dep.intKey = intLock();

   osCp.dep.intCnt++;


   RETVALUE(ROK);
}


/*
*
*       Fun:   Get Vector
*
*       Desc:  This function gets the function address stored at the
*              specified interrupt vector.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetVect
(
VectNmb vectNmb,            /* vector number */
PIF *vectFnct               /* vector function */
)
#else
PUBLIC S16 SGetVect(vectNmb, vectFnct)
VectNmb vectNmb;            /* vector number */
PIF *vectFnct;              /* vector function */
#endif
{
   U32 vNum;


   TRC1(SGetVect);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if (vectFnct == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW032, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif
/* vw026.201 - Removal of specific CPU names */ 
#if (CPU_FAMILY != ARM)

   vNum = (U32)(IVEC_TO_INUM(vectNmb));
   *vectFnct = (PIF) intVecGet((FUNCPTR *) vNum);

   RETVALUE(ROK);
#else /* ARM family */

   UNUSED(vNum);
   *vectFnct = (PIF) 0;
   RETVALUE(RFAILED);

#endif /* ARM family */
}


/*
*
*       Fun:   Put Vector
*
*       Desc:  This function puts the function address at the
*              specified interrupt vector.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SPutVect
(
VectNmb vectNmb,            /* vector number */
PIF vectFnct                /* vector function */
)
#else
PUBLIC S16 SPutVect(vectNmb, vectFnct)
VectNmb vectNmb;            /* vector number */
PIF vectFnct;               /* vector function */
#endif
{
   U32 vNum;


   TRC1(SPutVect);


   vNum = (U32)(INUM_TO_IVEC((U32)vectNmb));
   if (intConnect((VOIDFUNCPTR *) vNum, (VOIDFUNCPTR) vectFnct, 0) != OK)
   {
      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}


/*
*
*       Fun:   SGetEntInst
*
*       Desc:  This function gets the current entity and instance.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: This function may be called by the OS or Layer 1
*              hardware drivers.
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetEntInst
(
Ent *ent,                       /* entity */
Inst *inst                      /* instance */
)
#else
PUBLIC S16 SGetEntInst(ent, inst)
Ent *ent;                       /* entity */
Inst *inst;                     /* instance */
#endif
{
   S16 i;
   S16 ret;
   U32 tId;
   SsSTskEntry *sTsk;


   TRC1(SGetEntInst);


#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check pointers */
   if (ent == NULLP  ||  inst == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW033, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif


   /* get the thread id */
   tId = taskIdSelf();


   /* find the system task in whose context we're running */
   sTsk = NULLP;
   ret = SLock(&osCp.sTskTblLock);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   for (i = 0;  i < SS_MAX_STSKS;  i++)
   {
      if (osCp.sTskTbl[i].dep.tId == tId)
      {
         sTsk = &osCp.sTskTbl[i];
         break;
      }
   }
   if (sTsk != NULLP)
   {
      ret = SLock(&sTsk->dep.lock);
      if (ret == ROK)
      {
         *ent = sTsk->dep.ent;
         *inst = sTsk->dep.inst;
/* vw013.21: changed &sTsk->lock to &sTsk->dep.lock */
          if( SUnlock(&sTsk->dep.lock) != ROK) 
          {
#if (ERRCLASS & ERRCLS_DEBUG)
              VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
              RETVALUE(RFAILED);
#endif
          }
      }
   }
   if( SUnlock(&osCp.sTskTblLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                    "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
   }

   RETVALUE(ret == ROK ? ROK : RFAILED);
}



/*
*
*       Fun:   SSetEntInst
*
*       Desc:  This function sets the current entity and instance.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SSetEntInst
(
Ent ent,                    /* entity */
Inst inst                   /* instance */
)
#else
PUBLIC S16 SSetEntInst(ent, inst)
Ent ent;                    /* entity */
Inst inst;                  /* instance */
#endif
{
   S16 i;
   S16 ret;
   U32 tId;
   SsSTskEntry *sTsk;


   TRC1(SSetEntInst);


#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check entity and instance IDs */
   if (ent >= ENTNC  ||  inst >= INSTNC)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW034, ERRZERO, "Invalid entity/instance");
      RETVALUE(RFAILED);
   }
#endif


   /* get the task id */
   tId = taskIdSelf();


   /* find the system task in whose context we're running */
   sTsk = NULLP;
   ret = SLock(&osCp.sTskTblLock);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   for (i = 0;  i < SS_MAX_STSKS;  i++)
   {
      if (osCp.sTskTbl[i].dep.tId == tId)
      {
         sTsk = &osCp.sTskTbl[i];
         break;
      }
   }
   if (sTsk != NULLP)
   {
      ret = SLock(&sTsk->dep.lock);
      if (ret == ROK)
      {
         sTsk->dep.ent = ent;
         sTsk->dep.inst = inst;
/* vw013.21: changed &sTsk->lock to &sTsk->dep.lock */
         if( SUnlock(&sTsk->dep.lock) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
             VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                        "Could not give the Semaphore");
             RETVALUE(RFAILED);
#endif
         }
      }
   }
   if( SUnlock(&osCp.sTskTblLock) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                    "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
   }


   RETVALUE(ret == ROK ? ROK : RFAILED);
}

#ifdef SS_DRVR_SUPPORT

/*
*
*       Fun:   SSetIntPend
*
*       Desc:  Set interrupt pending flag
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SSetIntPend
(
U16 id,                         /* driver task identifier */
Bool flag                       /* flag */
)
#else
PUBLIC INLINE S16 SSetIntPend(id, flag)
U16 id;                         /* driver task identifier */
Bool flag;                      /* flag */
#endif
{
   VwIsFlag isFlag;


   TRC1(SSetIntPend);


#if (ERRCLASS & ERRCLS_INT_PAR)
   if (id >= SS_MAX_DRVRTSKS  ||  osCp.drvrTskTbl[id].used == FALSE)
   {
      VWLOGERROR(ERRCLS_INT_PAR, EVW035, id, "Invalid instance");
      RETVALUE(RFAILED);
   }
#endif


   isFlag.id = id;
   isFlag.action = (flag ? VW_IS_SET : VW_IS_UNSET);

   if (msgQSend(osCp.dep.isTskHdlrQId, (char *)&isFlag, sizeof(isFlag),
                  WAIT_FOREVER, MSG_PRI_NORMAL) != OK)
   {
      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
}
#endif  /* SS_DRVR_SUPPORT */


#ifdef SS_AEHDPR_SUPPORT

/* init of semaphore done in initialisation similarly for initializing lock
   for the table which stores the ISR,isrContext,DPR,dprContext and so on */
/*
*
*       Fun:   SSetAehDpr
*
*       Desc:  This function sets the ISR-DPR mechanism.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes: This function creates the DPR (Deferred processing) task.This
*              task is meant for deferred processing of the Interrupts.
*              DPR communicates with ISR using semaphore mechanism.
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SSetAehDpr
(
ProcId chipNum,                 /* which chip/processor */
VectNmb vectNmb,                /* interrupt id,processor dependent */
PISR isr,                       /* ISR function pointer */
PTR isrContext,                 /* ISR context,isr called as isr(isrContext) */
PDPR dpr,                       /* DPR function pointer */
PTR dprContext                  /* DPR context */
)
#else
PUBLIC S16 SSetAehDpr(chipNum,vectNmb,isr,isrContext,dpr,dprContext)
ProcId chipNum;                 /* which chip/processor */
VectNmb vectNmb;                /* interrupt id,processor dependent */
PISR isr;                       /* ISR function pointer */
PTR isrContext;                 /* ISR context,isr called as isr(isrContext) */
PDPR dpr;                       /* DPR function pointer */
PTR dprContext;                 /* DPR context */
#endif
{
   S16 ret;
   AehDpr *vect_row;
   Prior   priority;
   SsRingId qid;
   U16 dpr_idx;

   TRC1(SSetAehDpr);

   /* Here regarding the chipNum if customer wants to use chipNum then
    * he may use it here and alter the C statement below.This may be used
    * to access the vector number if there are chips used in Master-slave
    * mode
    */
   UNUSED(chipNum);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check isr function  */
   if (isr == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR,EVWXXX,ERRZERO,"Null isr function pointer");
      RETVALUE(RFAILED);
   }

   /* check the dpr function */
   if (dpr == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR,EVWXXX,ERRZERO,"Null dpr function pointer");
      RETVALUE(RFAILED);
   }
   /* check the isr and dpr contexts */
   if (isrContext == NULLP || dprContext == NULLP)
   {
      VWLOGERROR(ERRCLS_INT_PAR,EVWXXX,ERRZERO,"Null isr-dpr contexts.");
      RETVALUE(RFAILED);
   }
   /* check the vector number */
   if (vectNmb >= MAX_VECT_NUM)
   {
      VWLOGERROR(ERRCLS_INT_PAR,EVWXXX,ERRZERO,"Invalid vector number");
      RETVALUE(RFAILED);
   }
#endif

   ret = SLock(&(sAehDprCtl.sAehDprTblLock));
   if (ret != ROK)
   {
#if  (ERRCLASS & ERRCLS_DEBUG)
     VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
       "SSetAehDpr:- Not able to lock the semaphore for Dprtbl");
#endif
      RETVALUE(RFAILED);
   }

   /* configure vector table based on vectNmb which will call ssIsr function
     while on MTSS it will be called by signal
   */

   vect_row = &(sAehDprCtl.AehDprTbl[vectNmb]);

/* MPC860MH driver requires that the vector can be reconfigured */
#ifndef PQ_PPC860
  /* check if overwriting,if yes then return failure */
  if(vect_row->valid == TRUE)
  {
#if  (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Trying to overwrite the same vector number");
#endif
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
      }
      RETVALUE(RFAILED);
  }
#endif /* PQ_PPC860 */

   vect_row->vectNmb = vectNmb;
   vect_row->isr = isr;
   vect_row->isrContext = isrContext;
   vect_row->dpr = dpr;
   vect_row->dprContext = dprContext;
   vect_row->valid = TRUE;

   /* Get the priority of the DPR thread which will be scheduled using
    * VECT_TO_PRIORITY macro which will return the priority of the thread
    * for different vector numbers of ISR.It may be possible that different
    * ISRs with different Priority might have the same priority DPR thread
    * or could have different priority DPR thread. Multiple DPRs with the
    * same priority are also acceptable.
    */
   VECT_TO_PRIORITY(priority);
   /* needed to access the DPR Table which has
    * one to one mapping with priority
    */
   VECT_TO_INDEX(dpr_idx);

   /* check the priority and DPR table's  index returned */
   if ((priority == 0xFF) || (dpr_idx == 0xFF))
   {
      /* though no need of this statement since validity of vector
       *  number is already checked
      */
#if  (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Got wrong priority means wrong vector number passed");
#endif
      vect_row->vectNmb = INVALID;
      vect_row->isr = INVALID;
      vect_row->isrContext = 0;
      vect_row->dpr = INVALID;
      vect_row->dprContext = 0;
      vect_row->valid = FALSE;
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
      }
      RETVALUE(RFAILED);
   }

   /* create DPR thread if not already created for that index */
   if (sDprTbl[dpr_idx].valid == FALSE)
   {
      /* initialize the counting semaphore */
      if (ssInitSema(&(vect_row->synch_id), 0) != ROK)
      {
#if   (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
           "SSetAehDpr:- failed,not able to initialise the counting semaphore");
#endif
         vect_row->vectNmb = INVALID;
         vect_row->isr = INVALID;
         vect_row->isrContext = 0;
         vect_row->dpr = INVALID;
         vect_row->dprContext = 0;
         vect_row->valid = FALSE;
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
      }
         RETVALUE(RFAILED);
      }

      if ((qid = rngCreate(MAX_RING_BUF_LEN)) == NULL)
      {
#if   (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX,ERRZERO,
                     "Could not create queue to store the context");
#endif
         vect_row->vectNmb = INVALID;
         vect_row->isr = INVALID;
         vect_row->isrContext = NULLP;
         vect_row->dpr = INVALID;
         vect_row->dprContext = NULLP;
         vect_row->valid = FALSE;
         if (ssDestroySema(&(vect_row->synch_id)) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not destroy the Semaphore");
#endif

         }
	 vect_row->synch_id = (SsSemaId)NULLP;
         if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
            RETVALUE(RFAILED);
#endif
         }
         RETVALUE(RFAILED);
      }

      sDprTbl[dpr_idx].synch_id = vect_row->synch_id;
      vect_row->qid = sDprTbl[dpr_idx].qid = qid;

      vect_row->tid = sDprTbl[dpr_idx].tid = taskSpawn("DPR_THREAD",priority,
		                          VX_STDIO,VW_TASK_STACK,
					  (FUNCPTR)ssDprHdlr,
					  (S32)(vect_row->synch_id),
                                          (S32)vect_row->qid,
                                          0,0,0,0,0,0,0,0);
      sDprTbl[dpr_idx].valid = TRUE;
      sDprTbl[dpr_idx].counter++;
   }
   else
   {
      vect_row->qid = sDprTbl[dpr_idx].qid;
      vect_row->tid = sDprTbl[dpr_idx].tid;
      vect_row->synch_id = sDprTbl[dpr_idx].synch_id;
/* vw012.21 - added support for the 8260 driver */
#ifdef SS_PROC_8260
      vect_row->dprIndex = dpr_idx;
#endif /* SS_PROC_8260 */
      sDprTbl[dpr_idx].counter++;
   }

   /* install an interrupt for the specific source */
   ret = ssdPutVect(vectNmb,(PIF)ssIsr);
   if (ret != ROK)
   {
      /*  Undo every thing till now */
#if (ERRCLASS & ERRCLS_DEBUG)
       VWLOGERROR(ERRCLS_DEBUG, EVWXXX,ERRZERO,
                     "Vector failed to be installed");
#endif
      vect_row->vectNmb = INVALID;
      vect_row->isr = INVALID;
      vect_row->isrContext = 0;
      vect_row->dpr = INVALID;
      vect_row->dprContext = 0;
      vect_row->valid = FALSE;
      sDprTbl[dpr_idx].counter--;
      if (!sDprTbl[dpr_idx].counter)
      {
         sDprTbl[dpr_idx].valid = FALSE;
         taskDelete(vect_row->tid);
         if( ssDestroySema(&(vect_row->synch_id)) != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not destroy the Semaphore");
#endif

         }
         vect_row->synch_id = (SsSemaId)NULLP;
         sDprTbl[dpr_idx].synch_id = (SsSemaId)NULLP;
         vect_row->tid = 0xFF;
         sDprTbl[dpr_idx].tid = 0xFF;
         rngDelete(qid);
         vect_row->qid = (SsRingId)0xFF;
         sDprTbl[dpr_idx].qid = (SsRingId)0xFF;
      }
      else
      {
         vect_row->tid = 0xFF;
         vect_row->synch_id = (SsSemaId)NULLP;
         vect_row->qid = (SsRingId)0xFF;
      }
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
          VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
          RETVALUE(RFAILED);
#endif
      }
      RETVALUE(RFAILED);
   }


    if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
    {
#if (ERRCLASS & ERRCLS_DEBUG)
        VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
        RETVALUE(RFAILED);
#endif
    }
   RETVALUE(ROK);
} /* end of SSetAehDpr */

/*
*
*       Fun:   SRemoveAehDpr
*
*       Desc:  This function removes a previously set DPR interrupt handler
*
*       Ret:   ROK      - ok
*              RFAILED  - failed
*
*       Notes:
*
*       File:  vw_ss.c
*
*/
#ifdef ANSI
PUBLIC S16 SRemoveAehDpr
(
ProcId               chipNum,    /* which chip/processor */
VectNmb              vectNmb     /* interrupt id,processor dependent */
)
#else
PUBLIC S16 SRemoveAehDpr(chipNum, vectNmb)
ProcId               chipNum;    /* which chip/processor */
VectNmb              vectNmb;    /* interrupt id,processor dependent */
#endif
{
   S16               ret;
   AehDpr            *vect_row;
   U16               dpr_idx;

   TRC1(SRemoveAehDpr);

   /* Here regarding the chipNum if customer wants to use chipNum then
    * he may use it here and alter the C statement below. This may be used
    * to access the vector number if there are chips used in Master-slave
    * mode
    */
   UNUSED(chipNum);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check the vector number */
   if (vectNmb >= MAX_VECT_NUM)
   {
      VWLOGERROR(ERRCLS_INT_PAR,EVWXXX,ERRZERO,"Invalid vector number");
      RETVALUE(RFAILED);
   }
#endif

   ret = SLock(&(sAehDprCtl.sAehDprTblLock));
   if (ret != ROK)
   {
#if  (ERRCLASS & ERRCLS_DEBUG)
     VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
       "SRemoveAehDpr:- Not able to lock the semaphore for Dprtbl");
#endif
      RETVALUE(RFAILED);
   }

   /*
    * Configure vector table based on vectNmb which will call ssIsr function
    * (on MTSS it will be called by signal)
    */

   vect_row = &(sAehDprCtl.AehDprTbl[vectNmb]);

  /* check if existing, if no then return failure */
  if (vect_row->valid != TRUE)
  {
#if  (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Trying to remove nonexistent vector");
#endif
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
      }
      RETVALUE(RFAILED);
  }

   /*
    * Platform-specific mapping from vector to DPR index
    */
   VECT_TO_INDEX(dpr_idx);

   /* check the DPR table's index */
   if (dpr_idx == 0xFF)
   {
#if  (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Got invalid index means wrong vector number passed");
#endif
      if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
      RETVALUE(RFAILED);
#endif
      }
      RETVALUE(RFAILED);
   }

   /* Point interrupt vector to SS default ISR */
   ret = ssdPutVect(vectNmb, (PIF)ssDefault_isr);
   /* Initialize vector entry */
   vect_row->vectNmb = INVALID;
   vect_row->isr = INVALID;
   vect_row->isrContext = 0;
   vect_row->dpr = INVALID;
   vect_row->dprContext = 0;
   vect_row->valid = FALSE;

   /* destroy DPR thread if not referenced anymore */
   if (sDprTbl[dpr_idx].valid == TRUE)
   {
      sDprTbl[dpr_idx].counter--;
      if (sDprTbl[dpr_idx].counter <= 0)
      {
         /* Delete task */
         taskDelete(sDprTbl[dpr_idx].tid);
         /* Destroy counting semaphore */
         if (ssDestroySema(&vect_row->synch_id) != ROK)
         {
#if   (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
         "SRemoveAehDpr:- failed, not able to destroy the counting semaphore");
#endif
            if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                           "Could not give the Semaphore");
            RETVALUE(RFAILED);
#endif
            }
            RETVALUE(RFAILED);
         }
         /* Destroy ring queue */
         rngDelete(sDprTbl[dpr_idx].qid);
         sDprTbl[dpr_idx].valid = FALSE;
         sDprTbl[dpr_idx].synch_id = (SsSemaId)NULLP;
         sDprTbl[dpr_idx].tid = 0xFF;
         sDprTbl[dpr_idx].qid = (SsRingId)0xFF;
      } /* end if counter <= 0 */
   } /* end if DPR entry valid */

    if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
    {
#if (ERRCLASS & ERRCLS_DEBUG)
        VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
        RETVALUE(RFAILED);
#endif
    }
   RETVALUE(ROK);
} /* end of SRemoveAehDpr */



/*
*
*       Fun:   ssDprHdlr
*
*       Desc:  This function is the entry point of the DPR thread/task
*
*       Ret:   NONE
*
*       Notes: This function waits for the counting semaphore forever
*              and calls the appropriate dpr function using the
*              vector number which it retrieves from the ring buffer
*              and again continue waiting to acquire the semaphore.
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE VOID ssDprHdlr
(
S32 synch_id,                /* semaphore id which will be used to acquire */
S32 qid                      /* qid needed to restore the context */
)
#else
PRIVATE VOID ssDprHdlr(synch_id,qid)
S32  synch_id;           /* semaphore id which will be used to acquire */
S32  qid;                /* qid needed to restore the context */
#endif
{
   S16 ret, vect_ret;
   VectNmb vectNmb, vect_arr[MAX_VECT_NUM], vect_ord[MAX_VECT_NUM]; /* vw016.21: Addition */
   AehDpr *vector_row;
   S32 vect_cnt, i, size; /* vw016.21: Addition */
   U16 dpr_idx, vect_idx;
   TRC0(ssDprHdlr);
/* vw016.21: Addition */
   vect_cnt = 0; 
   for (i = 0; i <MAX_VECT_NUM; i++)
     vect_arr[i] = vect_ord[i] = 0;
/* vw016.21: Addition */
   while(1)
   {

      SS_ACQUIRE_SEMA((SsSemaId *)(&synch_id),ret);
      if (ret != ROK)
      {
#if   (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not acquire semaphore");
#endif
         continue;
      }
      SDisInt();
      if ((size = rngBufGet((SsRingId)qid,(char *)(&vectNmb),
		             sizeof(VectNmb))) == 0)
      {
         SEnbInt();

#if   (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                     "Could not receive from ring buffer");
#endif

         continue;
      }

      SEnbInt();

/* vw012.21 - added support for the 8260 driver */
#ifndef SS_PROC_8260
      /* check the validity of the vector number which is retrieved */
      /* NOTE:- The vectNmb can vary from Processor to processor.
       *        For PQ_PPC860 vector numbers will be one of IV_SCC1,
       *        IV_SCC2,IV_SCC3 or IV_SCC4.
       *        Else for other processor they might vary
       */
      vect_ret = ssdChkVect(vectNmb);
#else
      vect_ret = ROK;
#endif

      if (vect_ret == ROK)
      {
/* vw016.21: Addition */
/* vect_arr signifies if a interrupt for a vector number has come.
   The order in which the vector number comes is stored in the
   vect_ord. For e.g. if the SCC1 interrupt comes, if the vect_arr[0]
   is zero, the vect_arr[0] is set to 1 and 
   vect_ord[vect_cnt] = SCC1 vector number.*/
   
         VECT_TO_INDEX(dpr_idx);
         sDprTbl[dpr_idx].ssDprCnt++;
         VECT_TO_IDX(vect_idx);
         if (!vect_arr[vect_idx])
         {
            vect_arr[vect_idx]++;
            vect_ord[vect_cnt] = vectNmb;
            vect_cnt++;
         }

         if (sDprTbl[dpr_idx].ssDprCnt != sDprTbl[dpr_idx].ssIsrCnt)
            continue;
/* vw016.21: Addition */
      /* call DPR function before validating the dpr
       * function from the AehDprTbl with dpr context */

         ret = SLock(&(sAehDprCtl.sAehDprTblLock));
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
               "Could not lock the (DPR)Vector table");
#endif
            continue;
         }
/* vw016.21: Addition */
         for ( i = 0; i < vect_cnt; i++)
         {
/* vw016.21: Addition */
/*          vector_row = &(sAehDprCtl.AehDprTbl[vectNmb]); */
            vector_row = &(sAehDprCtl.AehDprTbl[vect_ord[i]]);

            if (!vector_row->dpr)
            {
#if (ERRCLASS & ERRCLS_DEBUG)
            VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
               "Invalid DPR function pointer, in spite of valid vector number");
#endif

               if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
               {
#if (ERRCLASS & ERRCLS_DEBUG)
               VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
                  RETVOID;
#endif
               }
               continue;
            }

            /* call dpr function */
            vector_row->dpr(vector_row->dprContext);

         }/* End of For Loop vw016.21: Addition */
      vect_cnt = 0;
      for (i = 0; i <MAX_VECT_NUM; i++)
        vect_arr[i] = vect_ord[i] = 0;

          if (SUnlock(&(sAehDprCtl.sAehDprTblLock)) != ROK)
          {
#if (ERRCLASS & ERRCLS_DEBUG)
             VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO,
                         "Could not give the Semaphore");
             RETVOID;
#endif
          }

         continue;
      } /* end of the check validity of the vector number */
      else
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
            "ssDprHdlr:- invalid vector number retrieved from ring buffer");
#endif

         continue;
      }
   } /* end of while loop */
   /* should not reach here */
   RETVOID;

} /* end of ssDprHdlr function */

/*
*
*       Fun:   ssIsr
*
*       Desc:  This is the Interrupt routine which is called from every
*              SCC interrupt. This routine writes in the ring buffer the
*              vector number which will be accessed by the ssDprHdlr
*              thread/Task
*
*       Ret:   NONE
*
*       Notes: This Interrupt routine gets the vector number and writes in the
*              ring buffer and calls the appropriate routine which
*              clears the interrupt
*
*       File:  vw_ss.c
*
*/


#ifdef ANSI
PUBLIC VOID INTERRPT ssIsr
(
S32 vector_number
)
#else
PUBLIC VOID INTERRPT ssIsr(vector_number)
S32 vector_number;
#endif
{
   VectNmb vectnum, vectNmb; /* vw016.21: Addition */
   AehDpr *vector_row;
   S32 size;
/* vw012.21 - added support for the 8260 driver */
#ifdef SS_PROC_8260
/* vw029.201 - Addition of 6535 board support */
#ifndef SS_PROC_6535_REVF
   S16 key;
#endif /* SS_PROC_6535_REVF */
#else
   U32 old_cimr_value;
#endif
   U16 dpr_idx;  /* vw016.21: Addition */
   ISR_PUSH_ENV

   vectnum = (VectNmb) vector_number;

/* vw012.21 - added support for the 8260 driver */
#ifdef SS_PROC_8260
   /* maximum efficiency for MPC8260 */
   vector_row = &(sAehDprCtl.AehDprTbl[vectnum]);
   vector_row->isr(vector_row->isrContext);
/* vw029.201 - Addition of 6535 board support */
#ifndef SS_PROC_6535_REVF
   key = intLock();
#else /* SS_PROC_6535_REVF */
   intDisable(vector_number);
#endif /* SS_PROC_6535_REVF */ 
   if ((size = rngBufPut(vector_row->qid, (char *)(&vectnum), sizeof(VectNmb)))
		         != sizeof(VectNmb))
   {
      vector_row->que_write_err=1;
/* vw029.201 - Addition of 6535 board support */
#ifndef SS_PROC_6535_REVF
      intUnlock(key);
#endif /* SS_PROC_6535_REVF */ 
      ISR_POP_ENV
      RETVOID;
   }
#ifdef SS_PROC_8260_NESTED
#endif /* SS_PROC_8260_NESTED */
#else
   /* if implementation has to do anything it will be done here */

   if (vectnum == 0xFF)
   {
      ISR_POP_ENV
      RETVOID;
   }

   vector_row = &(sAehDprCtl.AehDprTbl[vectnum]);

   /* check the validity of the isr after retrieving the vector number */
   if(!vector_row->isr)
   {
      ISR_POP_ENV
      RETVOID;
   }

   /* call the routine which will clear the interrupt */
   vector_row->isr(vector_row->isrContext);

   pqDisInt(&old_cimr_value);

   if ((size = rngBufPut(vector_row->qid,(char *)(&vectnum),sizeof(VectNmb)))
		         != sizeof(VectNmb))
   {
      vector_row->que_write_err=1;
      pqEnbInt(old_cimr_value);
      ISR_POP_ENV
      RETVOID;
   }

   pqEnbInt(old_cimr_value);

#endif /* SS_PROC_8260 */

/* vw016.21: Addition Start */
   vectNmb = vectnum;
   VECT_TO_INDEX(dpr_idx);
   sDprTbl[dpr_idx].ssIsrCnt++;
/* vw016.21: Addition End */

   /* increment the semaphore by releasing it */
   (VOID)SS_RELEASE_SEMA(&(vector_row->synch_id));

/* vw012.21 - added support for the 8260 driver */
#ifdef SS_PROC_8260
/* vw029.201 - Addition of 6535 board support */
#ifndef SS_PROC_6535_REVF
   intUnlock(key);
#else /* SS_PROC_6535_REVF */
   intEnable(vector_number);
#endif /* SS_PROC_6535_REVF */
#endif /* SS_PROC_8260 */

   ISR_POP_ENV

   RETVOID;
} /* end of the ssIsr routine */

/* vw012.21 - not required for the 8260 driver */
#ifndef SS_PROC_8260
/*
*
*       Fun:   pqGetHwBlk()
*
*       Desc:  This routine returns the pointer to the hardware block.
*
*       Ret:   pointer to Hardware Block
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE U32 pqGetHwBlk
(
void
)
#else
PRIVATE U32 pqGetHwBlk()
#endif
{

#ifdef PQ_PPC860
       ASM("mfspr 3,638");   /* IMMR is spr #638 */
#endif

#ifdef SS_PROC_68360 /* for PROC_68360 */
   /* algorithm:
    * move 0x7 into sfc to allow access to the MBAR
    * the MBAR is always stored at address 0x3ff00
    *
    * move the MBAR into our local variable (qi8kblock)
    * so that our variable becomes a valid pointer to
    * the base of Dual Port Ram.
    */
   ASM(" move    #7,d0");
   ASM(" movec   d0,sfc");
   ASM(" move.l  #261888,a1");     /* 261888d == 0x3ff00h */
   ASM(" lea     (a1),a0");
   ASM(" moves.l (a0),d0");
   ASM(" andi.l  #4294959104,d0"); /*4294959104 == 0xffffe000 */
#ifdef __GNUC__
   ASM(" move.l  d0,_qi8kblock");
#else /* else of _GNUC */
#ifdef _MCC68K
   ASM(" move.l  d0,`qi8kblock`");
#else /* else of _MCC68k */
   ASM(" move.l  d0,_qi8kblock");
#endif /* _MCC68k */
#endif /* _GNUC */
   RETVALUE(qi8kblock);
#endif /* SS_PROC_68360 */
}
#endif /* #ifndef SS_PROC_8260 */

/*
*
*       Fun:   ssDefault_isr()
*
*       Desc:  This routine is default ISR
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PUBLIC VOID INTERRPT ssDefault_isr
(
VOID
)
#else
PUBLIC VOID INTERRPT ssDefault_isr()
#endif
{
   logMsg("default_ISR:- Got default ISR\n",0,0,0,0,0,0);
   RETVOID;
} /* end of ssDefault_isr */

/*
*
*       Fun:   ssdPutVect
*
*       Desc:  This function installs the ISR and passes the vector number
*
*       Ret:   ROK    -ok (If SUCCESS)
*                     -RFAILED(If failure)
*
*       Notes: This routine installs the appropriate CPM(SCC1/SCC2/SCC3/SCC4)
*              interrupt and passes the vector number as one of the
*              parameter.
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PUBLIC S16 ssdPutVect
(
VectNmb vectNmb,
PIF vectFnct
)
#else
PUBLIC S16 ssdPutVect(vectNmb,vectFnct)
VectNmb vectNmb;
PIF vectFnct;
#endif
{
   U32 vNum;

   TRC1(ssdPutVect);


   vNum = (U32)(INUM_TO_IVEC((U32)vectNmb));
   if (intConnect((VOIDFUNCPTR *) vNum, (VOIDFUNCPTR) vectFnct,
                        (S32)vectNmb) != OK)
   {
      RETVALUE(RFAILED);
   }


   RETVALUE(ROK);
} /* end of ssdPutVect() */

/* vw012.21 - not required for the 8260 driver */
#ifndef SS_PROC_8260
/*
*
*       Fun:   ssdChkVect
*
*       Desc:  This function checks the vector number which has been retrieved
*              from the ring buffer.
*
*       Ret:   ROK    -ok (If SUCCESS)
*                     -RFAILED(If failure)
*
*       Notes: This routine checks vector number against the valid vector
*              numbers.
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PUBLIC S16 ssdChkVect
(
VectNmb vectNmb
)
#else
PUBLIC S16 ssdChkVect(vectNmb)
VectNmb vectNmb;
#endif
{

   TRC1(ssdChkVect);
#if  (ERRCLASS & ERRCLS_DEBUG)
#ifdef PQ_PPC860
   if ((vectNmb == IV_SCC1) || (vectNmb == IV_SCC2) || (vectNmb == IV_SCC3)
           || (vectNmb == IV_SCC4) || (vectNmb == IV_IDMA1))
   {

      RETVALUE(ROK);

   }
   else
   {
     VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
       "ssdChkVect:- Invalid vector number retrieved from ring buffer");

      RETVALUE(RFAILED);

   }
#endif /* PQ_PPC860 */
#ifdef SS_PROC_68360
   if ((vectNmb == IV_SCC1) || (vectNmb == IV_SCC2) || (vectNmb == IV_SCC3)
           || (vectNmb == IV_SCC4))
   {

      RETVALUE(ROK);

   }
   else
   {
     VWLOGERROR(ERRCLS_DEBUG,EVWXXX,ERRZERO,
       "ssdChkVect:- Invalid vector number retrieved from ring buffer");

      RETVALUE(RFAILED);

   }
#endif /* SS_PROC_68360 */
#endif /* ERRCLASS */
   RETVALUE(ROK);
} /* end of ssdChkVect() */

/*
*
*       Fun:   pqDisInt()
*
*       Desc:  This routine disables the CPM interrupt
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE VOID pqDisInt
(
U32 *old_value             /* stores the old value of the CPM register */
)
#else
PRIVATE VOID pqDisInt(old_value)
U32 *old_value;           /* stores the old value of the CPM register */
#endif
{
   U8 *pHwBlk;

   pHwBlk = (U8 *)(pqGetHwBlk() & 0xffff0000);
    *old_value = *((U32 *)(pHwBlk+CIMR_REG));
    *((U32 *)(pHwBlk+CIMR_REG)) = 0x00000000;
}

/*
*
*       Fun:   pqEnbInt()
*
*       Desc:  This routine enables the CPM interrupt
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE Void pqEnbInt
(
U32 old_value              /* value for restoring the CPM register */
)
#else
PRIVATE Void pqEnbInt(old_value)
U32 old_value;             /* value for restoring the CPM register */
#endif
{
   U8 *pHwBlk;

   pHwBlk = (U8 *)(pqGetHwBlk() & 0xffff0000);
   *((U32 *)(pHwBlk+CIMR_REG)) |= old_value;
}

#endif /* #ifndef SS_PROC_8260 */
#endif /* SS_AEHDPR_SUPPORT */


/* vw014.21: Adddition */
#ifdef SS_NOCACHE_MEM
/*
*
*       Fun:   SAllocNonCache()
*
*       Desc:  This routine allocates cache safe buffer for DMA devices and driv
ers.
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE S16 SAllocNonCache
(
Size size,
Data **addr
)
#else
PRIVATE S16 SAllocNonCache(size, addr)
Size size;
Data **addr;
#endif
{
  TRC1(SAllocNonCache);
  if ( ( *addr = (Data *)cacheDmaMalloc(size)) == NULL)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "cacheDmaMalloc failed");
#endif

      RETVALUE(RFAILED);

  };
  RETVALUE(ROK);
}

/*
*
*       Fun:   SFreeNonCache()
*
*       Desc:  This routine allocates cache safe buffer for DMA devices and driv
ers.
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PRIVATE S16 SFreeNonCache
(
Size size,
Data *addr
)
#else
PRIVATE S16 SFreeNonCache(size, addr)
Size size;
Data *addr;
#endif
{
STATUS sts;
  TRC1(SFreeNonCache);
  sts = cacheDmaFree(addr);
  size = 0;
  if ( sts == ERROR)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "cacheDmaFree failed");
#endif

      RETVALUE(RFAILED);

  };

  RETVALUE(ROK);
}


#endif /* SS_NOCACHE_MEM */
#ifdef SS_CACHE_FUNCTIONS
/*
*
*       Fun:   SCacheFlush()
*
*       Desc: This routine writes to memory all or some of the entries
*             in the specified cache.
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PUBLIC S16 SCacheFlush
(
U16 cache_type,
Data *addr,
Size size
)
#else
PUBLIC S16 SCacheFlush(cache_type, addr, size)
U16 cache_type;
Data *addr;
Size size;
#endif
{
STATUS sts;
  TRC1(SCacheFlush);
  switch (cache_type)
  {
    case SS_DATA_CACHE:        cache_type = DATA_CACHE;
                               break;
    case SS_INSTRUCTION_CACHE: cache_type = INSTRUCTION_CACHE;
                               break;
    default:
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "Invalid cache_type");
#endif
                               break;
  }

  sts = cacheFlush(cache_type, addr, size);
  if ( sts == ERROR)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "cacheFlush failed");
#endif

      RETVALUE(RFAILED);

  };

  RETVALUE(ROK);
}

/*
*
*       Fun:   SCacheInvalidate()
*
*       Desc: This routine invalidates all or some of the entries
               in the specified cache.
*  
*
*       Ret:   NONE
*
*       Notes:
*
*       File:  vw_ss.c
*
*/

#ifdef ANSI
PUBLIC S16 SCacheInvalidate
(
U16 cache_type,
Data *addr,
Size size
)
#else
PUBLIC S16 SCacheInvalidate(cache_type, addr, size)
U16 cache_type;
Data *addr;
Size size;
#endif
{
STATUS sts;
  TRC1(SCacheInvalidate);
  switch (cache_type)
  {
    case SS_DATA_CACHE:        cache_type = DATA_CACHE;
                               break;
    case SS_INSTRUCTION_CACHE: cache_type = INSTRUCTION_CACHE;
                               break;
    default:
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "Invalid cache_type");
#endif
                               break;
  }

  sts = cacheInvalidate(cache_type, addr, size);
  if ( sts == ERROR)
  {
#if (ERRCLASS & ERRCLS_DEBUG)
      VWLOGERROR(ERRCLS_DEBUG, EVWXXX, ERRZERO, "cacheInvalidate failed");
#endif

      RETVALUE(RFAILED);

  };

  RETVALUE(ROK);
}

#endif /* SS_CACHE_FUNCTIONS */
/* vw014.21: Addition */
#if 1  /* vw020:21: Addition */
#ifdef SS_ZEROCOPY

/*
 *
 *      Fun:   ssConvPoolInit
 *
 *      Desc:  This function creates a network converting pool that
 *             contains a specified number of mBlk-clBlk constructs.
 *             This pool can be solely used for a zero-copy transmission
 *             from Trillium to VxWorks protocol stack layers.
 *
 *      Ret:   ROK      - ok
 *             RFAILED  - failure to create network converting pool
 *
 *      Notes: None
 *
 *      File:  vw_ss.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssConvPoolInit
(
U16      mBlkNum,  /* number of mBlks */
U16      clBlkNum, /* number of cluster blocks */
NET_POOL **pool    /* location of pointer to network pool */
)
#else
PUBLIC S16 ssConvPoolInit(mBlkNum, clBlkNum, pool)
U16      mBlkNum;  /* number of mBlks */
U16      clBlkNum; /* number of cluster blocks */
NET_POOL **pool;   /* location of pointer to network pool */
#endif
{
   int         num;            /* number of cluster description elements */
   ConvPool    *conv;          /* pointer to converting pool */
   M_CL_CONFIG blkCfg;         /* network pool configuration data */
   CL_DESC     clCfgTbl[] =    /* cluster description table */
   {
   /*
   clSize  clNum  memArea  memSize
   ------  -----  -------  -------
   */
   {0,    0,     NULL,    0}
   };

   TRC2(ssConvPoolInit)

   if (mBlkNum == 0 || clBlkNum == 0)
      RETVALUE(RFAILED);

   /* Allocate network pool's control block */
   if ((conv = (ConvPool *) malloc(sizeof(ConvPool))) == NULL)
      RETVALUE(RFAILED);

   num = NELEMENTS(clCfgTbl);
   blkCfg.mBlkNum = (int) mBlkNum;
   blkCfg.clBlkNum = (int) clBlkNum;

   /* Calculate total memory for all mBlks and clBlks */
   blkCfg.memSize = (((int) mBlkNum) * (M_BLK_SZ + sizeof(long))) +
                      (((int) clBlkNum) * (CL_BLK_SZ + sizeof(long)));

   if ((blkCfg.memArea = (char *) memalign(sizeof(long), blkCfg.memSize))
      == NULL)
   {
      free(conv);
      *pool = NULL;
      RETVALUE(RFAILED);
   }

   /* Initialize network pool */
   if (netPoolInit((NET_POOL *) conv, &blkCfg, clCfgTbl, num, NULL) == ERROR)
   {
      free(conv);
      free(blkCfg.memArea);
      *pool = NULL;
      RETVALUE(RFAILED);
   }

   /* Keep memory allocated for mBlks and clBlks */
   conv->mem = blkCfg.memArea;
   *pool = (NET_POOL *) conv;

   RETVALUE(ROK);
} /* end of ssConvPoolInit */

/*
 *
 *      Fun:   ssConvPoolFree
 *
 *      Desc:  This function frees a network converting pool that
 *             has been created by ssConvPoolInit. This encounters
 *             all system memory taken for the pool's control block
 *             and mBlk-clBlk elements.
 *
 *      Ret:   ROK      - ok
 *             RFAILED  - failure to free network converting pool
 *
 *      Notes: None
 *
 *      File:  vw_ss.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssConvPoolFree
(
NET_POOL *pool    /* pointer to network pool */
)
#else
PUBLIC S16 ssConvPoolFree(pool)
NET_POOL *pool;   /* pointer to network pool */
#endif
{
   TRC2(ssConvPoolFree)

   /* From WRS: netPoolDelete frees its own structures but does not free    */
   /* the memory that was passed to it. The memory allocated for the pool   */
   /* control block using malloc and for mBlks and clBlks using memalign    */
   /* have to be freed explicitly.                                          */
   if (pool->mBlkCnt != pool->mBlkFree)
      RETVALUE(RFAILED);

   if (netPoolDelete(pool) == ERROR)
      RETVALUE(RFAILED);

   /* Free memory keept for mBlk-dBlk constructs */
   free(((ConvPool *)pool)->mem);

   /* Free pool control block */
   free(pool);

   RETVALUE(ROK);
} /* end of ssConvPoolFree */

/*
 *
 *      Fun:   ssMsgConv2vw
 *
 *      Desc:  This function converts STREAMS message format defined by
 *             system services to netBuf message format used by vxWorks.
 *
 *
 *      Ret:   ROK      - ok
 *             RFAILED  - error
 *
 *      Notes: Requires vxWorks' netBufLib.
 *
 *      File:  vw_ss.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssMsgConv2vw
(
Buffer     *from,  /* message to be converted */
M_BLK      **to,   /* location of pointer to MBlock */
NET_POOL   *pool   /* pointer to pool */
)
#else
PUBLIC S16 ssMsgConv2vw(from, to, pool)
Buffer     *from;  /* message to be converted */
M_BLK      **to;   /* location of pointer to MBlock */
NET_POOL   *pool;  /* pointer to pool */
#endif
{
   SsMsgInfo *   minfo;      /* pointer to message info */
   M_BLK_ID      pPrvMblk;   /* pointer to previous MBlk */
   M_BLK_ID      pCurMblk;   /* pointer to current MBlk */
   CL_BLK_ID     pClBlk;     /* pointer to netBuf cluster block */
   Buffer *      dBuf;       /* pointer to dynamic buffer */
   Data *        data;       /* pointer to payload */
   MsgLen        dLen;       /* payload size */


   TRC1(ssMsgConv2vw)

   /* To achieve zero-copy transmission STREAMS message is mapped using   */
   /* netBufLib control structures before being passed further. Note that */
   /* we have to preserve original chaining of data we received. Original */
   /* message size equals to payload of all dynamic buffers in chain.     */

   if (SInitNxtDBuf(from) != ROK)      /* unwind original data buffer chain */
      RETVALUE(RFAILED);

   pPrvMblk = NULL;
   minfo = (SsMsgInfo *) from->b_rptr;   /* get message info */

   /* iterate through original message chain */
   while (SGetNxtDBuf(from, &dBuf) == OK)
   {
      /* grab cluster block to marry to data buffer */
      if ((pClBlk = netClBlkGet(pool, M_DONTWAIT)) == NULL)
         goto clean;

      /* grab message block */
      if ((pCurMblk = netMblkGet(pool, M_DONTWAIT, MT_DATA)) == NULL)
      {
         netClBlkFree(pool, pClBlk);
         goto clean;
      }

      /* Everything is in place. Assign free routine and its arguments, */
      /* join data buffer to MBlk. The following must always succeed.   */

      /* get effective size of data buffer */
      (Void) SGetDataTx(dBuf, &data, &dLen);
      (Void) netClBlkJoin(pClBlk, (char *)data, (int)dLen, (FUNCPTR) SPutDBuf,
                          (int) minfo->region, (int) minfo->pool, (int) dBuf);
      (Void) netMblkClJoin(pCurMblk, pClBlk);

      pCurMblk->mBlkHdr.mLen = (int) dLen;

      /* chain MBlks */
      if (pPrvMblk)
      {
         pPrvMblk->mBlkHdr.mNext = pCurMblk;
      }
      else
      {
         SFndLenMsg(from, &dLen);  /* get original message size */

         /* set message header and hook for caller */
         pCurMblk->mBlkHdr.mFlags |= M_PKTHDR;
         pCurMblk->mBlkPktHdr.len = (int) dLen;
         *to = pCurMblk;
      }

      pPrvMblk = pCurMblk;
   }

   /* Drop message header only if at least one dynamic */
   /* buffer is present in original message.           */
   if (pPrvMblk)
   {
      /* free original message header */
#ifdef SS_M_PROTO_REGION
      (Void) SPutDBuf(minfo->region, minfo->pool, from);
#else /* SS_M_PROTO_REGION */
      (Void) SPutDBuf(SS_DFLT_REGION, minfo->pool, from);
#endif /* SS_M_PROTO_REGION */

      /* signal that message is successfully converted */
      RETVALUE(ROK);
   }

clean:

   if (pPrvMblk)
   {
      /* free allocated netBufLib structures but not original message */

      pCurMblk = *to;

      while (pCurMblk)
      {
         pClBlk = pCurMblk->pClBlk;

         pClBlk->clSize = 0;
         pClBlk->clNode.pClBuf = NULL;
         pClBlk->pClFreeRtn = (FUNCPTR) NULL;
         pCurMblk->mBlkHdr.mLen = 0;
         pPrvMblk->mBlkHdr.mData = NULL;

         pCurMblk = netMblkClFree(pCurMblk);
      }
   }

   *to = NULL; /* invalidate message header */
   RETVALUE(RFAILED);
} /* end of ssMsgConv2vw */

/*
 *
 *      Fun:   ssMsgConv2ss
 *
 *      Desc:  This function converts netBuf message format used by vxWorks
 *             to STREAMS message format used by system services.
 *
 *
 *      Ret:   ROK      - ok
 *             RFAILED  - error
 *
 *      Notes: Requires vxWorks' netBufLib.
 *
 *      File:  vw_ss.c
 *
 */
#ifdef ANSI
PUBLIC S16 ssMsgConv2ss
(
M_BLK    *from,    /* message to be converted */
Buffer   **to,     /* location of pointer to message buffer */
Region   region,   /* region id */
Pool     pool      /* pool id */
)
#else
PUBLIC S16 ssMsgConv2ss(from, to, region, pool)
M_BLK    *from;    /* message to be converted */
Buffer   **to;     /* location of pointer to message buffer */
Region   region;   /* region id */
Pool     pool;     /* pool id */
#endif
{
   M_BLK_ID        pCurMblk;   /* pointer to current MBlk */
   SsFrtn *        finfo;      /* pointer to free info */
   Buffer *        mBuf;       /* pointer to message header */
   Buffer *        dBuf;       /* pointer to dynamic buffer */
   Size            dLen;       /* data buffer payload */
   register U8 *   tmp;        /* auxiliary pointer */


   TRC1(ssMsgConv2ss)

   /* get message header */
   if (SGetMsg(region, pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   pCurMblk = from;

   /* iterate through original message chain */
   do
   {
      /* get dynamic buffer for mapping */
      if (SGetDBuf(region, pool, &dBuf) != ROK)
         goto clean;

      dLen = (Size) pCurMblk->mBlkHdr.mLen;

      /* Replace links to internal data buffer with links to data  */
      /* buffer linked with current MBlk. Use internal data buffer */
      /* for free info storage. Note that we need to keep size of  */
      /* internal data buffer to be able to free that buffer.      */
      /* We store its size at location preceeding free info.       */
      /* This ensures that free routine can use as many space it   */
      /* needs for argument list.                                  */

      tmp = (U8 *) dBuf->b_datap->db_base;
      *((Size *) tmp) = (Size)(dBuf->b_datap->db_lim - dBuf->b_datap->db_base);

      /* this is OK since free routine requires only one argument */
      finfo = (SsFrtn *) (1 + ((Size *) tmp));
      finfo->free_func = (void (*)(char *)) netMblkClFree;
      finfo->free_arg = (char *) pCurMblk;

      dBuf->b_datap->db_frtnp = finfo;

      /* get pointer to external data buffer */
      tmp = (U8 *) pCurMblk->mBlkHdr.mData;
      /* set base and read pointers to external data buffer */
      dBuf->b_datap->db_base = tmp;
      dBuf->b_rptr = tmp;
      /* set limit and write pointers to external data buffer end */
      if (tmp) { tmp += dLen; }

      dBuf->b_datap->db_lim = tmp;
      dBuf->b_wptr = tmp;
      /* join dynamic buffer to message */
      if (SUpdMsg(mBuf, dBuf, dLen) != ROK)
      {
         tmp = (U8 *) (((Size *) dBuf->b_datap->db_frtnp) - 1);

         dBuf->b_datap->db_frtnp = NULLP;
         dBuf->b_datap->db_base = tmp;
         dBuf->b_datap->db_lim = tmp + *((Size *) tmp);
         dBuf->b_rptr = tmp;
         dBuf->b_wptr = tmp;

         (Void) SPutDBuf(region, pool, dBuf);
         goto clean;
      }
   }
   while ((pCurMblk = pCurMblk->mBlkHdr.mNext));

   if (mBuf->b_cont)
   {
      *to = mBuf;
      /* signal that message is successfully converted */
      RETVALUE(ROK);
   }

clean:
   /* free allocated netBufLib structures but not original message */

   /* free message header */
   dBuf = mBuf->b_cont;
   (Void) SPutDBuf(region, pool, mBuf);

   /* free dynamic buffer chain */
   while (dBuf)
   {
      mBuf = dBuf->b_cont;
      tmp = (U8 *) (((Size *) dBuf->b_datap->db_frtnp) - 1);

      dBuf->b_datap->db_frtnp = NULLP;
      dBuf->b_datap->db_base = tmp;
      dBuf->b_datap->db_lim = *((Size *) tmp) + tmp;
      dBuf->b_rptr = tmp;
      dBuf->b_wptr = tmp;

      (Void) SPutDBuf(region, pool, dBuf);

      dBuf = mBuf;
   }

   *to = NULLP; /* invalidate message header */
   RETVALUE(RFAILED);
} /* end of ssMsgConv2ss */

#endif /* SS_ZEROCOPY */
#endif  /* vw020.21: Addition */



/********************************************************************30**

         End of file: vw_ss.c 1.1  -  12/28/98 12:38:09

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. initial release

1.1+         vw001.21 kp   1. Use copy of Pst in message when activating
                              TAPA task activation function rather than
                              the Pst in the message buffer. In
                              vwTskHdlr().
                           2. Unlock timer table before activating timer
                              activation function so that if it calls
                              SDeregTmr() we don't deadlock. In vwTskHdlr().
                           3. Store current executing TAPA task ID for
                              SGetEntInst(). In vwTskHdlr().
                           4. Wait on a semaphore at the beginning of the
                              system task handler so that we don't start
                              running the permanent task before tst()
                              completes. In vwTskHdlr().
             vw007.21 vrp  5. Added support for 68360 (SSetAehDpr)
1.1+         vw008.21 jn   6. Compile warning removed for following
                              functions:
                              ssDestroySema, ssPostSema, ssWaitSema,
                              SUnlock and SS_RELEASE_SEMA.
1.1+         vw009.21 vrp  7. Added a patch which will give independence
                              in deciding whether to have only one DPR thread
                              or multiple DPR threads for every source of
                              interrupts or to have the combinations of above.
                              This patch is added in SSetAehDpr function.
1.1+         vw010.21 vrp  8. Modified the code under ssdChkVect which
                              would validate the vector number only if
                              ERRCLASS is defined.Also added IV_IDMA1 under
                              PQ_PPC860 and added the SS_PROC_68360 section
                              in ssdChkVect routine.
             vw012.21 ada  9. Cleaned up patches
                      ada  10.Added MPC8260 driver support in SS_PROC_8260
                              section
                      ada  11.Added SRemoveAehDpr function
             vw013.21 jn   12. In the SSetEntInst and SGetEntInst, replaced
                               SUnlock(&sTsk->lock) with 
                               SUnlock(&sTsk->dep.lock).
                               "SUnlock(&sTsk->lock)" was a typo error,
                                resulting in releasing wrong semaphore.
             vw014.21 jn   13.Registered a region1 with system services if
                              SS_REGION1_SUPPORT is enabled.
                              If SS_NOCACHE_MEM is enabled the region1
                              is allocated from the cache free memory.
                              If SS_CACHE_FUNCTIONS is enabled, then
                              SCacheFlush and SCacheInvalidate are available.
                              New functions added:
                              -SAllocNonCache
                              -SFreeNonCache
                              -SCacheFlush
                              -SCacheInvalidate
             vw015.21 jn   14. After the normal task  and timer activation 
                               function is called by the vwTskHdlr, 
                               taskDelay (0) is called to allow for context 
                               switch. After the permenant task is called 
                               taskDelay(1) is called for manual context switch.
             vw016.21 jn   15. Performance improvement in the ISR-DPR processing.
                               For e.g. if two SCC1 interrupts occur, instead
                               of scheduling the DPR twices, it will be scheduled
                               only once.
             vw018.21 jjn  16. Included the flag DEBUGNOEXIT, so that debug errors
                               do not delete the tasks and halt the system.
             vw019.21 jjn  17. The memory region is aligned at 16 byte boundary if
                               cache support is enabled.
             vw020.21 zo   18. Added functions to convert STREAMS message to
                               netBufLib message and viceversa.
1.1+        vw021.201 bdu  19. Added SExit function.
            vw022.201 bjp  20. Added vwCreateSTsk function.
	                       function adds ability to name task and set priority
			       of task from 0 to 255
            vw023.201 bjp  21. Added SGetRefTime function
	                       Add default configuration of system clock
            vw024.201 bjp  22. Add support for REGION2
	                       Modification for REGION1 configuration
            vw025.201 bjp  23. Modification to hard code regions in cfgRegInfo
            vw026.201 zo  24. Removed sysClkRateSet call
                              Removed specific CPU names for ARM family
1.1+        vw029.201 bjp  1. Additon of SRegCfgTmr support
                           2. Addition of 6535 board support
1.1+        vw030.201 pdb  1. Addition of code to delete the timer task
                              resources in ssdDeinitTmr API 
*********************************************************************91*/
