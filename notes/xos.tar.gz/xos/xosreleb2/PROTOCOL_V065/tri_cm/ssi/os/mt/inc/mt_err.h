/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     MTSS
  
     Type:     C source file
  
     Desc:     Version information
 
     File:     mt_err.h

     Sid:      mt_err.h 1.2  -  10/15/98 10:34:41
  
     Prg:      ada

*********************************************************************21*/


#ifndef __MTERRH__
#define __MTERRH__
  


/* log error macro */
#define MTLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError( ENTNC, INSTNC, 0, __FILE__, __LINE__, \
             (ErrCls)errCls, (ErrVal)errCode, (ErrVal)errVal, errDesc )


/* defines */

#define   ERRMT       0
#define   EMTBASE     (ERRMT + 0)    /* reserved */
#define   EMTXXX      (EMTBASE)      /* reserved */

#define   EMT001      (ERRMT +    1)    /*      mt_ss.c:1310 */
#define   EMT002      (ERRMT +    2)    /*      mt_ss.c:1351 */
#define   EMT003      (ERRMT +    3)    /*      mt_ss.c:1448 */
#define   EMT004      (ERRMT +    4)    /*      mt_ss.c:1469 */
#define   EMT005      (ERRMT +    5)    /*      mt_ss.c:1518 */
#define   EMT006      (ERRMT +    6)    /*      mt_ss.c:1532 */
#define   EMT007      (ERRMT +    7)    /*      mt_ss.c:1969 */
#define   EMT008      (ERRMT +    8)    /*      mt_ss.c:1996 */
#define   EMT009      (ERRMT +    9)    /*      mt_ss.c:2098 */
#define   EMT010      (ERRMT +   10)    /*      mt_ss.c:2129 */
#define   EMT011      (ERRMT +   11)    /*      mt_ss.c:2160 */
#define   EMT012      (ERRMT +   12)    /*      mt_ss.c:2226 */
#define   EMT013      (ERRMT +   13)    /*      mt_ss.c:2302 */
#define   EMT014      (ERRMT +   14)    /*      mt_ss.c:2329 */
#define   EMT015      (ERRMT +   15)    /*      mt_ss.c:2370 */
#define   EMT016      (ERRMT +   16)    /*      mt_ss.c:2473 */
#define   EMT017      (ERRMT +   17)    /*      mt_ss.c:2498 */
#define   EMT018      (ERRMT +   18)    /*      mt_ss.c:2535 */
#define   EMT019      (ERRMT +   19)    /*      mt_ss.c:2578 */
#define   EMT020      (ERRMT +   20)    /*      mt_ss.c:2747 */
#define   EMT021      (ERRMT +   21)    /*      mt_ss.c:2772 */
#define   EMT022      (ERRMT +   22)    /*      mt_ss.c:2882 */
#define   EMT023      (ERRMT +   23)    /*      mt_ss.c:2972 */
#define   EMT024      (ERRMT +   24)    /*      mt_ss.c:3022 */
#define   EMT025      (ERRMT +   25)    /*      mt_ss.c:3086 */
#define   EMT026      (ERRMT +   26)    /*      mt_ss.c:3092 */
#define   EMT027      (ERRMT +   27)    /*      mt_ss.c:3141 */
#define   EMT028      (ERRMT +   28)    /*      mt_ss.c:3144 */
#define   EMT029      (ERRMT +   29)    /*      mt_ss.c:3453 */
#define   EMT030      (ERRMT +   30)    /*      mt_ss.c:3533 */
#define   EMT031      (ERRMT +   31)    /*      mt_ss.c:3613 */
#define   EMT032      (ERRMT +   32)    /*      mt_ss.c:3685 */

#endif

  
/********************************************************************30**
  
         End of file: mt_err.h 1.2  -  10/15/98 10:34:41
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ada   1. initial release

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.2          ---      kp   1. MTSS-Solaris release 2.1
1.2+        mt028.201 kkj  1. Multiple procIds related changes
*********************************************************************91*/
