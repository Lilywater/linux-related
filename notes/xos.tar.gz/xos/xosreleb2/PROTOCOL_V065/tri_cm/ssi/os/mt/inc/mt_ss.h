/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
 
     Name:     MTSS -- implementation specific definitions
 
     Type:     C include file
 
     Desc:     Various macro definitions demanded by systems services.
               The contents of these are for the MTSS implementation.
 
     File:     mt_ss.h
 
     Sid:      mt_ss.h 1.1  -  10/15/98 10:33:09
 
     Prg:      kp
 
*********************************************************************21*/


#ifndef __MTSSH__
#define __MTSSH__


/* --- interface to SS --- */

/* general */
#define SS_PROC_ID                      0 /*chendh PID_STK(1)*/

/* task related */
/* mt028.201: addition: multiple procs support related changes */
#ifdef SS_MULTIPLE_PROCS
#define SS_MAX_PROCS                    100 /* max entries for proc list */
#endif /* SS_MULTIPLE_PROCS */

#define SS_MAX_ENT                      255
#define SS_MAX_INST                     8

/* mt028.201: modification: multiple procs support related changes */
#ifndef SS_MULTIPLE_PROCS
#define SS_MAX_TTSKS                    30
#define SS_MAX_STSKS                    30
#else /* SS_MULTIPLE_PROCS */
#define SS_MAX_TTSKS                    1000 
#define SS_MAX_STSKS                    30
#endif /* SS_MULTIPLE_PROCS */

#ifdef SS_DRVR_SUPPORT
#define SS_MAX_DRVRTSKS                 70
#endif

#ifdef SS_RTR_SUPPORT
#if 0   /* mt0012.21 : Deletion */
#define SS_MAX_RTRTSKS                  5
#endif /* mt0012.21: Deletion */
#if 1   /* mt0012.21 : Addition */
#define SS_MAX_RTRTSKS                  255
#endif /* mt0012.21: Addition */
#endif


/* timer related */
#if 0   /* mt0015.21 : change - old code */
#define SS_MAX_TMRS                     15
#else
#define SS_MAX_TMRS                     45
#endif /* mt0015.21 : change - new code */

/* memory related */
/* mt022.201 - Modification for shared memory relay and memcal regions */
#if (defined(RY_ENBS5SHM) && defined(USE_MEMCAL))
#define SS_MAX_REGS			3
#define RY_SHM_REGION			(SS_MAX_REGS - 2)
#define SS_STATIC_REGION		(SS_MAX_REGS - 1)
#else

#if (defined(RY_ENBS5SHM) || defined(USE_MEMCAL))
#define SS_MAX_REGS			2
#ifdef RY_ENBS5SHM
#define RY_SHM_REGION			(SS_MAX_REGS - 1)
#endif
#ifdef USE_MEMCAL
#define SS_STATIC_REGION		(SS_MAX_REGS - 1)
#endif
#else

#define SS_MAX_REGS			1
#endif
#endif

#ifdef CMM_MAX_BKT_ENT
#define SS_MAX_POOLS_PER_REG            CMM_MAX_BKT_ENT
#else
#define SS_MAX_POOLS_PER_REG            5
#endif

/* locks */
#define SS_STSKTBL_LOCK                 SS_LOCK_MUTEX
#define SS_STSKENTRY_LOCK               SS_LOCK_MUTEX
#define SS_TMRTBL_LOCK                  SS_LOCK_MUTEX
#define SS_DMNDQ_LOCK                   SS_LOCK_MUTEX
#define SS_DRVRENTRY_LOCK               SS_LOCK_MUTEX
#define SS_RTRENTRY_LOCK                SS_LOCK_MUTEX


/* types needed by common SSI code */
#define SsSemaId                        sem_t
#define SLockId                         pthread_mutex_t


/* calls needed by common SSI code */
#define SInitLock(l, t)                 pthread_mutex_init(l, NULL)
#define SLock(l)                        pthread_mutex_lock(l)
#define SUnlock(l)                      pthread_mutex_unlock(l)
#define SDestroyLock(l)                 pthread_mutex_destroy(l)

#define ssInitSema(s, c)                sem_init(s, 0, c)

/*chendh modify it*/
#ifndef SS_LINUX
/*solaris and so on*/
#define ssWaitSema(s)                   sem_wait(s)
#endif

#define ssPostSema(s)                   sem_post(s)
#define ssDestroySema(s)                sem_destroy(s)

#define SS_CHECK_CUR_STSK(t)            (pthread_equal(pthread_self(), \
                                          (t)->dep.tId))
#if 1 /* mt013.21: Addition */
#define SInitSemaphore(s, c)            sem_init(s, 0, c)
#define SWaitSemaphore(s)               sem_wait(s)                   
#define SPostSemaphore(s)               sem_post(s) 
#if 0 /* mt014.21 : Deletion */                  
#define SDestroySemaphore(s)            sem_destory(s)
#else
#define SDestroySemaphore(s)            sem_destroy(s)
#endif /* mt014.21: Addition */
#endif /* mt013.21: Addition */
                
#define ssdPstTsk(p, m, t)

/* added SExit() for exiting process : mt017.21 */
#define SExit()                         exit(0)	
#if 1  /* mt007.21 addition */ 
/* calls needed by Message Functions */
#define SMemCpy(d,s,c)	memcpy(d,s,c)
#define SMemSet(s,c,n)  memset(s,c,n)
#endif /* mt007.21 addition */
/* --- internal to MTSS-Solaris --- */


/* mt027.201 - Modification for SRegCfgTmr support */
/* number of nanoseconds per tick (used in nanosleep()) */
#define MT_TICK_CNT             (((U32)0x3B9ACA00)/SS_TICKS_SEC)


/* interrupt service flags */
#define MT_IS_SET               0
#define MT_IS_UNSET             1
#define MT_IS_RESET             2

/******************************************************************
 mt018.201 - Memory Configuration. 

Memory block sizes and counts for memory manager configuration 
There is no restriction in the size of each block for the bucket.
However, it is recommended that the bucket size should be word aligned.
The CMM (Common Memory Manager) also create a look up table which map 
the size to the bucket index. 
The number of entry in the lookup table  (CMM_MAX_MAP_ENT, defined in
cm_mem.h) = ((maximum bucket size)/(bucket quantum size)) + 1. 
The CMM_MAX_MAP_ENT should be changed depending on the bucket sizes
that are configured below.
*******************************************************************/ 

/*chendh modify the position and number*/
/* Bucket 0 configuration */ 
/* mt032.201 changed  MT_BKT_0_DSIZE from 120 to 128 for 64k compilation */
#define MT_BKT_0_DSIZE          64
#define MT_BKT_1_DSIZE          128
#define MT_BKT_2_DSIZE          512      /* Fill in this value as required */
#define MT_BKT_3_DSIZE          2560      /* Fill in this value as required */ 

#define MT_MAX_BKTS             4

#ifdef CP_MASS_MEM
#define MT_BKT_0_NUMBLKS     300000
#define MT_BKT_1_NUMBLKS     600000
#define MT_BKT_2_NUMBLKS     200000
#define MT_BKT_3_NUMBLKS     200000

/* mt026.201 - Modification to increase default heap size */
/* memory size used for heap by the memory manager (16MB) */
#define MT_HEAP_SIZE            16097152U

#else
#define MT_BKT_0_NUMBLKS        100000
#define MT_BKT_1_NUMBLKS        90000
#define MT_BKT_2_NUMBLKS        5000     /* Fill in this value as required */ 
#define MT_BKT_3_NUMBLKS        7000        /* Fill in this value as required */ 

/* mt026.201 - Modification to increase default heap size */
/* memory size used for heap by the memory manager (4MB) */
#define MT_HEAP_SIZE            4097152U

#endif /*CP_MASS_MEM*/


/* mt029.201 corrected typos */
/* memory pool data size definitions for pool-to-size mapping table */
#define MT_POOL_3_DSIZE        (MT_BKT_3_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define MT_POOL_2_DSIZE        (MT_BKT_2_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define MT_POOL_1_DSIZE        (MT_BKT_1_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))
#define MT_POOL_0_DSIZE        (MT_BKT_0_DSIZE-(sizeof(SsMblk)+sizeof(SsDblk)))

#ifndef USE_MEMCAL
#define STATIC_MEM_CFG
#endif

/* mt022.201 - definition of MT_BKTQNSIZE */
#define MT_BKTQNSIZE 64 /*chendh 16*/

/* mt021.201 - Addition for setting stack size for threads */
/* Configuration for stack size (in bytes) of spawned threads
 * Size of zero gives default of 1 MB or 2 MB for 32 bit or 64 bit
 * compilers, respectively */
#define MT_TASK_STACK		NULLD	/* stack size for task handler */
#define MT_ISTASK_STACK		NULLD	/* stack size for IS task handler */
#define MT_TMRTASK_STACK	NULLD	/* stack size for timer handler */
#define MT_CONSOLE_STACK	NULLD	/* stack size for console handler */


#endif  /*  __MTSSH__  */


  
/********************************************************************30**

         End of file: mt_ss.h 1.1  -  10/15/98 10:33:09

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**

        Revision history:

*********************************************************************61*/
  
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      kp   1. MTSS-Solaris release 2.1

1.1+         ---      ada  1. Changed common memory bucket size to
                              improve efficiency  

            mt007.21  jn   2. Defined Macros SMemCpy & SMemSet for
                              multiple byte copy
            mt012.21  jn   3. Defined the macro SS_MAX_RTRTSTS to 255
            mt013.21  jn   4. Defined the following macros:
                              SInitSemaphore,
                              SWaitSemaphore,
                              SPostSemaphore,
                              SDestroySemaphore. 
            mt014.21  jn   5. Corrected the typo in Macro definition for
                              SDestroySemaphore
            mt015.21  ada  6. Changed SS_MAX_TMRS from 15 to 45
                      ada  7. Changes to code to run on Linux
            mt016.21  ada  7. Increased MT_DBUF_NMB_BUFS and MT_HEAP_SIZE
                              to work with H.323 acceptance test
	    mt017.21  bdu  8. Added SExit() for exiting use		      
           mt018.201  bdu  9. Remove several macro defines, and change
                              the name of some macros.
           mt021.201  bjp 10. Added macro definition for stack sizes
	   mt022.201  bjp 11. Modifications for shared memory relay
	                      Modifications for memory calculation tool
1.1+  mt026.201  bjp  1. Modification to increase default heap size
1.1+  mt027.201  bjp  1. Modification for SRegCfgTmr support
2.1+  mt028.201  kkj  1. Support of multiple procs added
      mt029.201 bn    2. corrected typose in memory calculation.
      mt031.201 bn    1. changed  MT_BKT_0_DSIZE from 80 to 120 for 64k 
                         compilation 
      mt032.201 bn    2. changed  MT_BKT_0_DSIZE from 120 to 128 for 64k 
                         compilation 
*********************************************************************91*/
