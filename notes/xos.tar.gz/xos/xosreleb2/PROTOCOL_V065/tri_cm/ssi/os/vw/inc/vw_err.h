/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     VxWorks System Services - error defines

     Type:     C include file

     Desc:     Error defines required by VxWorks System Services.

     File:     vw_err.h

     Sid:      vw_err.h 1.8  -  12/28/98 12:32:46

     Prg:      mc

*********************************************************************21*/


#ifndef __VWERRH__
#define __VWERRH__
  
  

/* log error macro */
#define VWLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError( ENTNC, INSTNC, 0, __FILE__, __LINE__, \
             (ErrCls)errCls, (ErrVal)errCode, (ErrVal)errVal, errDesc )

/* defines */

#define   EVWBASE     (ERRVW + 0)    /* reserved */
#define   EVWXXX      (EVWBASE)      /* reserved */

#define   EVW001      (EVWBASE +    1)    /*      vw_ss.c: 535 */
#define   EVW002      (EVWBASE +    2)    /*      vw_ss.c: 551 */
#define   EVW003      (EVWBASE +    3)    /*      vw_ss.c: 637 */
#define   EVW004      (EVWBASE +    4)    /*      vw_ss.c: 657 */
#define   EVW005      (EVWBASE +    5)    /*      vw_ss.c: 673 */
#define   EVW006      (EVWBASE +    6)    /*      vw_ss.c: 860 */
#define   EVW007      (EVWBASE +    7)    /*      vw_ss.c: 890 */
#define   EVW008      (EVWBASE +    8)    /*      vw_ss.c: 981 */
#define   EVW009      (EVWBASE +    9)    /*      vw_ss.c:1011 */
#define   EVW010      (EVWBASE +   10)    /*      vw_ss.c:1057 */
#define   EVW011      (EVWBASE +   11)    /*      vw_ss.c:1071 */
#define   EVW012      (EVWBASE +   12)    /*      vw_ss.c:1120 */
#define   EVW013      (EVWBASE +   13)    /*      vw_ss.c:1133 */
#define   EVW014      (EVWBASE +   14)    /*      vw_ss.c:1426 */
#define   EVW015      (EVWBASE +   15)    /*      vw_ss.c:1449 */
#define   EVW016      (EVWBASE +   16)    /*      vw_ss.c:1517 */
#define   EVW017      (EVWBASE +   17)    /*      vw_ss.c:1534 */
#define   EVW018      (EVWBASE +   18)    /*      vw_ss.c:1553 */
#define   EVW019      (EVWBASE +   19)    /*      vw_ss.c:1584 */
#define   EVW020      (EVWBASE +   20)    /*      vw_ss.c:1646 */
#define   EVW021      (EVWBASE +   21)    /*      vw_ss.c:1710 */
#define   EVW022      (EVWBASE +   22)    /*      vw_ss.c:1734 */
#define   EVW023      (EVWBASE +   23)    /*      vw_ss.c:1766 */
#define   EVW024      (EVWBASE +   24)    /*      vw_ss.c:1804 */
#define   EVW025      (EVWBASE +   25)    /*      vw_ss.c:1823 */
#define   EVW026      (EVWBASE +   26)    /*      vw_ss.c:1893 */
#define   EVW027      (EVWBASE +   27)    /*      vw_ss.c:1916 */
#define   EVW028      (EVWBASE +   28)    /*      vw_ss.c:1983 */
#define   EVW029      (EVWBASE +   29)    /*      vw_ss.c:2074 */
#define   EVW030      (EVWBASE +   30)    /*      vw_ss.c:2127 */
#define   EVW031      (EVWBASE +   31)    /*      vw_ss.c:2172 */
#define   EVW032      (EVWBASE +   32)    /*      vw_ss.c:2425 */
#define   EVW033      (EVWBASE +   33)    /*      vw_ss.c:2522 */
#define   EVW034      (EVWBASE +   34)    /*      vw_ss.c:2603 */
#define   EVW035      (EVWBASE +   35)    /*      vw_ss.c:2681 */

/* Macro for logging error */
#define VWLOGERROR(errCls, errCode, errVal, errDesc) \
   SLogError( ENTNC, INSTNC, 0, __FILE__, __LINE__, \
              (ErrCls)errCls, (ErrVal)errCode, (ErrVal)errVal, errDesc )

#endif

  
/********************************************************************30**

         End of file: vw_err.h 1.8  -  12/28/98 12:32:46

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc    1. initial release

1.2          ---  mc    1. used error 104.

1.3          ---  mc    1. added more error numbers.        

1.4          ---  mc    1. used error 121.

1.5          ---  fmg   1. added error codes up to 200

1.6          ---  mb    1. added macro for SLogError.

1.7          --- kish   1. added error codes upto 232
             --- kish   2. added packing and unpacking macros

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.8          --- vs     1. Added error codes EVW240 - EVW246 for 
                           interaction with message exchange

             ---  kp    2. release 2.1, error codes regenerated

*********************************************************************91*/
 
