/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     C Source Code.
  
     Desc:     Initialization and miscellaneous functions
 
     File:     np_gen.c

     Sid:      np_gen.c 1.2  -  08/17/98 11:56:34
  
     Prg:      ag
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "cm_mem.h"        /* common memory manager */

#include "ss_err.h"        /* errors */
#include "ss_dep.h"        /* implementation-specific */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "lns.h"           /* NTSS mgmt */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_mem.x"        /* common memory manager */


#include "ss_dep.x"        /* implementation-specific */
#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "lns.x"           /* NTSS mgmt */


/* Extern variables */
EXTERN NsMemCfg nsMemCfg;

/* local defines */

#ifdef NU   /* UNTSS */
CONSTANT PUBLIC Txt nsPrgNme[] = "UNTSS";
#endif /* NU */


/* local typedefs */

/* local externs */

/* forward references */
EXTERN Void *sTskHandler ARGS((Void *context));


#ifdef NU
PRIVATE Void nsPrntUsage ARGS((Void));
#endif /* NU */

/* public variable declarations */
PUBLIC TskInit  nsInit;

/* private variables */
#ifdef NU
#ifdef CONAVL
/* ns010.102 - Addition for CONRD support */
#ifndef CONRD
PRIVATE HANDLE cInHandle;
#endif
PRIVATE HANDLE cOutHandle;
#endif /* CONAVL */

PRIVATE HANDLE pHeap;            /* process heap handle */
PRIVATE HANDLE outFileHandle;    /* output file handle for writing log */

/* ns006.12 - change the nsArgv, etc. to msArgv and scope as PUBLIC */
PUBLIC Txt **msArgv;            /* UNTSS argument vector */
PUBLIC S16 msArgc;              /* UNTSS argument count */
PUBLIC S16 msOptInd;            /* SGetOpt vars */
PUBLIC S16 msOptOpt;            /* SGetOpt vars */
PUBLIC S8 *msOptArg;            /* SGetOpt vars */

PRIVATE ProcId nsProcId;         /* Processor Id */

#endif /* NU */


#ifdef NU


/*
*
*       Fun:   nsPrntUsage
*
*       Desc:  print a usage message
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PRIVATE Void nsPrntUsage
(
void
)
#else
PRIVATE Void nsPrntUsage()
#endif
{
   Txt  pBuf[NSPBUFSIZE];    /* print buffer */

   TRC0(nsPrntUsage)

   sprintf(pBuf, "Usage: untssi -c <cfgFile> [-w] [-d <level>] [-h]\n\n");
   SDisplay(0,pBuf);
   sprintf(pBuf,"       -o <log file> -- ouput log file\n");
   SDisplay(0,pBuf);
   sprintf(pBuf,"       -s <stack id> -- Stack Id\n");
   SDisplay(0,pBuf);
   sprintf(pBuf,"       -?            -- print this menu\n");
   SDisplay(0,pBuf);
 
   RETVOID;

} /* end of nsPrntUsage */

  
/*
*
*       Fun:   nsGetOpts
*
*       Desc:  This function gets command line options.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC Void nsGetOpts
(
int argc,                   /* argument count */
char **argv                 /* argument values */
)
#else
PUBLIC Void nsGetOpts(argc, argv)
int argc;                   /* argument count */
char **argv;                /* argument values */
#endif
{
/* ns006.12 - when NOCMDLINE is defined, ret should also be declared */   
   S16 ret;                 /* return code */

   TRC0(nsGetOpts)

   msOptInd = 1;
   outFileHandle = NULLP;
   msArgv = argv;
   msArgc = argc;

   while ((ret = SGetOpt(argc, argv, "o:s:?:")) != EOF)
   {
      switch(ret)
      {
         case 'o':
         {
            /* this option for logging trace in a log file */
            outFileHandle = CreateFile((LPCTSTR)msOptArg, 
                                       GENERIC_WRITE |GENERIC_READ,
                                       FILE_SHARE_READ,
                                       NULL,
                                       CREATE_ALWAYS,
                                       FILE_ATTRIBUTE_NORMAL,
                                       NULL);
            if (outFileHandle == INVALID_HANDLE_VALUE)
            {
               RETVOID;
            }

            break;
         }

         case 's':
         {
            /* this option for getting stack id form commnad line */
            osCp.dep.stkId = (U16)strtol(msOptArg, NULLP, 0);
            break;
         } 

         case '?': 
         {   
            /* print the usage for command line */
            nsPrntUsage();
            break;
         }

         default:
         {
            break;
         }
      } /* end of switch */
   } /* end of while */

   /* ns010.102 - Addition to reset to msOptInd to 1 */
   msOptInd = 1;

   RETVOID;

} /* end of nsGetOpts */

#ifdef CONAVL
/* ns010.102 - Addition to disable console reading with CONRD */
#ifndef CONRD
  
/*
*
*       Fun:   nsScanCon
*
*       Desc:  This thread reads the console and hands over any
*              data read to a user function.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC Void *nsScanCon
(
Void *con
)
#else
PUBLIC Void *nsScanCon(con)
Void *con;
#endif
{
/* ns008.102 -- removed INPUT_RECORD */	
   U8   data;

#ifndef SS_SINGLE_THREADED
/* ns016.102 - Addition for Windows CE Support */
#ifndef SS_WINCE
   U8   numRead;
#endif /* SS_WINCE */
#endif /* SS_SINGLE_THREADED */

/* ns016.102 - Addition for Windows CE Support */
#ifdef SS_WINCE
   PRIVATE Bool bPressed = FALSE;
#endif

   TRC0(nsScanCon)

   UNUSED(con);
   
/* ns016.102 - Modification for Windows CE Support */
#if (defined(SS_SINGLE_THREADED) && !defined(SS_WINCE))
/* ns008.102 -- changed for console reading under single thread */
   if (kbhit())
   {
     if ((data = getche()))
     {
        rdConQ(data);
     }
     else
	RETVALUE(NULLP);
   }
   else
     RETVALUE(NULLP);
   
/* ns016.102 - Modification for Windows CE Support */
#else /* SS_SINGLE_THREADED && !SS_WINCE*/

   for (;;)
   {
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
      if (data = getchar())
#else /* SS_WINCE */
      if (ReadConsole(cInHandle, (Void *)&data, 1, (LPDWORD)&numRead, NULL))
#endif /* SS_WINCE */
      {
         rdConQ(data);
      }
      else
      {
#if (ERRCLASS & ERRCLS_DEBUG)
/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
         NSLOGERROR(ERRCLS_DEBUG, ENS001, (ErrVal)cInHandle, 
                                       "getchar Function failed");
#else /* SS_WINCE */
         NSLOGERROR(ERRCLS_DEBUG, ENS001, (ErrVal)cInHandle, 
                                       "ReadConsole Function failed");
#endif /* SS_WINCE */
#endif
         RETVALUE(NULLP);
      }
   }

/* ns016.102 - Modification for Windows CE Support */
#endif /* SS_SINGLE_THREADED && !SS_WINCE */
   RETVALUE(NULLP);

} /* end of nsScanCon */
#endif /* CONRD */
#endif /* CONAVL */
#endif /* NU */


#ifdef SS_DRVR_SUPPORT

/*
*
*       Fun:   nsScanInt
*
*       Desc:  scan interrupt service routines
*
*       Ret:   ROK
*
*       Notes: 
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void *nsScanInt
(
Void *context 
)
#else
PUBLIC Void *nsScanInt(context)
Void *context;
#endif
{
   SsDrvrTskEntry *drvrTsk;
   U16 i;
   
   TRC0(nsScanInt)

   UNUSED(context);
   
#ifndef SS_SINGLE_THREADED
   for(;;)
   {
      /* check if there is an interruprt */
#ifdef NU
      if (WaitForSingleObject(osCp.dep.eventWaitArray[NS_INTR_EVNT_IDX],
                                             INFINITE) != WAIT_OBJECT_0)
#endif /* NU */

         continue;
#endif /* SS_SINGLE_THREADED */

      if (osCp.numDrvrTsks)
      { 
         /* find out who interrupted  and call the corresponding function */
         for (i=0; i < SS_MAX_DRVRTSKS; i++)
         {
           drvrTsk = &osCp.drvrTskTbl[i];
           if ((drvrTsk->used == TRUE) && (drvrTsk->dep.isFlag == TRUE))
              (Void)(drvrTsk->isTsk((Inst)i));
         }
      }

#ifndef SS_SINGLE_THREADED
   }
#endif /* SS_SINGLE_THREADED */

   RETVALUE(NULLP);

} /* end of nsScanInt */
#endif /* SS_DRVR_SUPPORT */


#if 0 /* def NU */
  
/*
*
*       Fun:   main
*
*       Desc:  program execution starts here.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S32 main
(
int  argc,                  /* argument count */
char **argv                 /* argument values */
)
#else  
PUBLIC S32 main(argc, argv)
int  argc;                  /* argument count */
char **argv;                /* argument values */
#endif /* ANSI */
{
   /* ns009.102 - Removed closing of the console if CONVAL is enabled */

   /* get the command line options if any */
   nsGetOpts(argc, argv);

   /* NTSS Initailization function */
   SInit();

   RETVALUE(ROK);
} /* end of main */
#endif /* NU */

/* ns016.102 - Addition for Windows CE Support */
#ifdef SS_WINCE
/*
*
*       Fun:   WinMain
*
*       Desc:  program execution starts here.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S32 WINAPI WinMain
(	
HINSTANCE hInstance,
HINSTANCE hPrevInstance,
LPTSTR    lpCmdLine,
S32       nCmdShow
)
#else
PUBLIC S32 WINAPI WinMain(hInstance, hPrevInstance, lpCmdLine, nCmdShow)
HINSTANCE hInstance;
HINSTANCE hPrevInstance;
LPTSTR    lpCmdLine;
S32       nCmdShow;
#endif /* ANSI */
{
   U8 CmdLine[100];
   U8 *argv[20];
   U8 seps[] = " \t";
   U8 *token;
   U8 argc;
   U8 i;
   U8 acc[]= "acc";

	/* Copy command line */
	i=0;
	while(lpCmdLine[i] != L'\0')
	{
		CmdLine[i] = lpCmdLine[i];
		i++;
	}
   CmdLine[i] = '\0';

   /* Copy command line tokens to argv */
   argv[0] = acc;
   argc = 1;
   token = strtok( CmdLine, seps );
   while( token != NULL )
   {
	  argv[argc++]=token;
      token = strtok( NULL, seps ); 
   }
	  argv[argc]= '\0';
   
	return main(3,argv);
}
#endif /* SS_WINCE */



  
/*
*
*       Fun:   ssdInitGen
*
*       Desc:  Initialize the dependent data types
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitGen
(
VOID
)
#else
PUBLIC S16 ssdInitGen(VOID)
#endif
{
   S16   i;
#ifdef CONAVL 
/* ns010.102 - Addition for CONRD support */
#ifndef CONRD
/* ns016.102 - Addition for Windows CE Support */
#ifndef SS_WINCE
   U32   cMode;
#endif /* SS_WINCE */
#endif /* CONRD */
#endif /* CONAVL */

   TRC0(ssdInitGen)

#ifdef NU
/* ns016.102 - Addition for Windows CE Support */
#ifndef SS_WINCE
   /* Initialize prioritity lookup table */
   for (i=0; i < 6; i++)
   {
      osCp.dep.wPriorLookup[i] = 2;
   }
   for(; i < 10; i++)
   {
      osCp.dep.wPriorLookup[i] = 1;
   }
   for(; i < 21; i++)
   {
      osCp.dep.wPriorLookup[i] = 0;
   }
   for(; i < 25; i++)
   {
      osCp.dep.wPriorLookup[i] = -1;
   }
   for(; i < 29; i++)
   {
      osCp.dep.wPriorLookup[i] = -2;
   }
   for(; i < NS_MAX_PRIOR; i++)
   {
      osCp.dep.wPriorLookup[i] = -15;
   }
#else /* SS_WINCE */
   for (i=0; i < 4; i++)
   {
      osCp.dep.wPriorLookup[i] = 248;
   }
   for(; i < 8; i++)
   {
      osCp.dep.wPriorLookup[i] = 249;
   }
   for(; i < 12; i++)
   {
      osCp.dep.wPriorLookup[i] = 250;
   }
   for(; i < 16; i++)
   {
      osCp.dep.wPriorLookup[i] = 251;
   }
   for(; i < 20; i++)
   {
      osCp.dep.wPriorLookup[i] = 252;
   }
   for(; i < 24; i++)
   {
      osCp.dep.wPriorLookup[i] = 253;
   }
   for(; i < 28; i++)
   {
      osCp.dep.wPriorLookup[i] = 254;
   }
   for(; i < NS_MAX_PRIOR; i++)
   {
      osCp.dep.wPriorLookup[i] = 255;
   }
#endif /* SS_WINCE */
#endif /* NU */


   /* initialize event count */
   osCp.dep.eventCount = 0;

   /* initialize event count */
   osCp.dep.permTskCount = 0;

   /* initialize wait array lock */
   if (SInitLock (&osCp.dep.waitArrayLock, SS_LOCK_MUTEX) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS004, ERRZERO, "SInitLock failed");
#endif
      RETVALUE(RFAILED);
   }

#ifdef NU
   /* Get the process Heap to allocate the memeory from it */

   /* Memory size requirement of more than 0x7fff8 will not be
    * allocated from the heap. Sytem calls  "VirtualAlloc" to
    * obtain the memory needed for such larger blocks 
    */ 
   pHeap = GetProcessHeap();
   if (pHeap == NULLP)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS005, (ErrVal)pHeap, "Null Process Heap");
#endif
      RETVALUE(RFAILED);
   }
   
#ifdef CONAVL
   /* ns010.102 - Addition for CONRD support */
#ifndef CONRD

/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
   cInHandle = CreateEvent(NULL,FALSE,FALSE,"Sim_In_Handle");
   if (cInHandle == INVALID_HANDLE_VALUE)
      RETVALUE(RFAILED);
   if(SetEvent(cInHandle) == FALSE)
	  RETVALUE(RFAILED);
#else /* SS_WINCE */
   cInHandle  = GetStdHandle(STD_INPUT_HANDLE);
   if (cInHandle == INVALID_HANDLE_VALUE)
      RETVALUE(RFAILED);
#endif /* SS_WINCE */

#ifdef SS_SINGLE_THREADED
   osCp.dep.eventWaitArray[NS_CON_EVNT_IDX] = cInHandle;
   osCp.dep.eventCount++;
#endif /* SS_SINGLE_THREADED */

/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   if (GetConsoleMode(cInHandle, (LPDWORD) &cMode) == 0)
   {
      RETVALUE(RFAILED);
   }
   cMode = cMode & ~ENABLE_MOUSE_INPUT & ~ENABLE_LINE_INPUT 
                          & ~ENABLE_PROCESSED_INPUT & ~ENABLE_ECHO_INPUT; 
   if (SetConsoleMode(cInHandle, cMode) == 0)
   {
      RETVALUE(RFAILED);
   }
#endif /* SS_WINCE */
#endif /* CONRD */

/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   cOutHandle = GetStdHandle(STD_OUTPUT_HANDLE);
   if (cOutHandle == INVALID_HANDLE_VALUE)
      RETVALUE(RFAILED);
#endif /* SS_WINCE */
#endif /* CONAVL */

#endif /* NU */

   RETVALUE(ROK);

} /* end of ssdInitGen */



  
/*
*
*       Fun:   ssdInitMem
*
*       Desc:  Initialize the Memory Manager
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitMem
(
VOID
)
#else
PUBLIC S16 ssdInitMem(VOID)
#endif
{
   CmMmRegCb   *memCb;
   CmMmRegCfg  *memCfg;
   NsRegCfg    *region;
   S16          i;
   S16          j;
#ifdef NS_ENB_MGMT
   SsPoolEntry *pEntry;
#endif /* NS_ENB_MGMT */

   TRC0(ssdInitMem)
#ifdef 0 //SSI_XOS_MEM

   /* lock the region table */
   SS_ACQUIRE_ALL_SEMA(&osCp.regionTblSem, ret);
   if (ret != ROK)
   {

#if (ERRCLASS & ERRCLS_DEBUG)
      SSLOGERROR(ERRCLS_DEBUG, ESS669, (ErrVal) ret,
                  "Could not lock region table");
#endif

      RETVALUE(RFAILED);
   }


#if (ERRCLASS & ERRCLS_INT_PAR)
   /* verify that this region is not registered */
   if (osCp.regionTbl[nsMemCfg.region.regionId].used == TRUE)
   {
      SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);

      SSLOGERROR(ERRCLS_INT_PAR, ESS670, ERRZERO, "Region ID used");
      RETVALUE(RFAILED);
   }
#endif


   /* fill in the region information */
   osCp.regionTbl[nsMemCfg.region.regionId].used = TRUE;
   osCp.regionTbl[nsMemCfg.region.regionId].regCb = 0;
   osCp.regionTbl[nsMemCfg.region.regionId].flags = 0;
   osCp.regionTbl[nsMemCfg.region.regionId].start =0;
   osCp.regionTbl[nsMemCfg.region.regionId].size = 0;
   osCp.regionTbl[nsMemCfg.region.regionId].alloc = cmAlloc;
   osCp.regionTbl[nsMemCfg.region.regionId].free = cmFree;
   osCp.regionTbl[nsMemCfg.region.regionId].ctl = cmCtl;

   osCp.numRegions++;


   /* unlock the region table */
   SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);
    RETVALUE(ret);


#else

   /* CMM Initialization */
   for (i = 0; i < nsMemCfg.numRegions; i++)
   {
#ifdef NU
      memCb = (CmMmRegCb *)HeapAlloc(pHeap,
                                     HEAP_NO_SERIALIZE | HEAP_ZERO_MEMORY,
                                     sizeof(CmMmRegCb));
      if (memCb == NULLP)
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS006, (ErrVal)0, 
                              "Could not Allocate memory for Cb structure");
#endif
         RETVALUE(RFAILED);
      }
      memCfg = (CmMmRegCfg *)HeapAlloc(pHeap, 
                                       HEAP_NO_SERIALIZE | HEAP_ZERO_MEMORY,
                                       sizeof(CmMmRegCfg));
      if (memCfg == NULLP)
      {
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCb);
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS007, (ErrVal)0, 
                              "Could not Allocate memory for Cfg structure");
#endif
         RETVALUE(RFAILED);
      }
      region = &nsMemCfg.region[i];

      memCfg->size = region->heapSize;
      for (j = 0; j < region->numBkts; j++)
      {
         memCfg->size +=  region->bkt[j].blkSize * region->bkt[j].numBlks;
      }
      memCfg->vAddr = (U8 *)HeapAlloc(pHeap, HEAP_NO_SERIALIZE, memCfg->size);

      if (memCfg->vAddr == NULLP)
      {
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCb);
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCfg);
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS008, (ErrVal)region->regionId, 
                    "Could not allocate Memory for region");
#endif
         RETVALUE(RFAILED);
      }
#endif /* NU */


      memCfg->lType     = NS_MM_LOCK;
      memCfg->bktQnSize = NS_DFLT_MEM_QUNT_SIZE;
      memCfg->numBkts   = region->numBkts;

      for (j = 0; j < region->numBkts; j++)
      {
         memCfg->bktCfg[j].size    = region->bkt[j].blkSize;
         memCfg->bktCfg[j].numBlks = region->bkt[j].numBlks;
      }
   
      /* Now call CMM to initailize the information */
      if (cmMmRegInit(region->regionId, memCb, memCfg) != ROK)
      {
#ifdef NU
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCb);
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCfg->vAddr);
         HeapFree(pHeap, HEAP_NO_SERIALIZE, (Void *)memCfg);
#endif /* NU */


#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS012, (ErrVal)0, "Could not Init CMM ");
#endif
         RETVALUE(RFAILED);
      }


#ifdef NS_ENB_MGMT
      for (j = 0; j < region->numBkts; j++)
      {
         pEntry = &osCp.regionTbl[i].poolTbl[j];
         pEntry->u.dpool.dep.maxSize  =  region->bkt[j].blkSize;
         pEntry->u.dpool.dep.crntSize =  region->bkt[j].blkSize;
         pEntry->u.dpool.dep.minSize  =  region->bkt[j].blkSize;
      }
#endif /* NS_ENB_MGMT */
   }

   RETVALUE(ROK);
#endif   

} /* end of ssdInitMem */


  
/*
*
*       Fun:   ssdError
*
*       Desc:  Error function
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdError
(
Seq       sequence,              /* error sequence */
Reason    reason                 /* reason */
)
#else
PUBLIC S16 ssdError(sequence, reason)
Seq       sequence;              /* error sequence */
Reason    reason;                /* reason */
#endif
{
   TRC0(ssdError)

#if (ERRCLASS & ERRCLS_DEBUG)
   NSLOGERROR(ERRCLS_DEBUG, ENS013, sequence, "SError() called");
#endif

   RETVALUE(ROK);

} /* end of ssdError */


/*
*
*       Fun:   ssdLogError
*
*       Desc:  Error function
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void ssdLogError
(
Ent     ent,                /* Calling layer's entity id */
Inst    inst,               /* Calling layer's instance id */
ProcId  procId,             /* Calling layer's processor id */
Txt     *file,              /* file name where error occured */
S32     line,               /* line in file where error occured */
ErrCls  errCls,             /* error class */
ErrCode errCode,            /* layer unique error code */
ErrVal  errVal,             /* error value */
Txt     *errDesc            /* description of error */
)
#else
PUBLIC Void ssdLogError(ent, inst, procId, file, line,
                        errCls, errCode, errVal, errDesc)
Ent     ent;                /* Calling layer's entity id */
Inst    inst;               /* Calling layer's instance id */
ProcId  procId;             /* Calling layer's processor id */
Txt     *file;              /* file name where error occured */
S32     line;               /* line in file where error occured */
ErrCls  errCls;             /* error class */
ErrCode errCode;            /* layer unique error code */
ErrVal  errVal;             /* error value */
Txt     *errDesc;           /* description of error */
#endif
{
   Txt  errClsMsg[50];
#if ((defined CONAVL) || (defined NK))
   Txt  pBuf[NSPBUFSIZE];    /* print buffer */
#endif

   TRC0(ssdLogError)

   switch(errCls)
   {
      case ERRCLS_ADD_RES:
         sprintf(errClsMsg, "ERRCLS_ADD_RES");
         break;

      case ERRCLS_INT_PAR:
         sprintf(errClsMsg, "ERRCLS_INT_PAR");
         break;

      case ERRCLS_DEBUG:
         sprintf(errClsMsg, "ERRCLS_DEBUG");
         break;

      default:
         sprintf(errClsMsg, "INVALID ERROR CLASS !");
         break;
   }

#ifdef NU
#ifndef CONAVL
   /* we know we have the this, so use it */
   printf("\n%s: sw error:  ent: %03d  inst: %03d  proc id: %03d \n\
                file: %s line: %03d errcode: %05d errcls: %s\n\
                errval: %05d  errdesc: %s\n", nsPrgNme, ent, inst, 
          procId, file, (S32)line, (S32)errCode, errClsMsg, 
          (S32)errVal, errDesc);
#else
   sprintf(pBuf,"\n%s: sw error:  ent: %03d  inst: %03d  proc id: %03d \n\
                file: %s line: %03ld errcode: %05ld errcls: %s\n\
                errval: %05ld  errdesc: %s\n", nsPrgNme, ent, inst, 
           procId, file, line, errCode, errClsMsg, errVal, errDesc);
   SDisplay(0, pBuf);
#endif /* CONAVL */
#endif /* NU */


   if (errCls == ERRCLS_DEBUG )  /* these errors halt the system */
      SExitTsk();

   RETVOID;

} /* end of ssdLogError */

  
/*
*
*       Fun:   ssdInitFinal
*
*       Desc:  Initialize the dependent data structures here
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 ssdInitFinal
(
VOID
)
#else
PUBLIC S16 ssdInitFinal(VOID)
#endif
{
#ifdef NU
#ifdef SS_SINGLE_THREADED
   U32 error;
#endif /* SS_SINGLE_THREADED */
#endif /* NU */

/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_SINGLE_THREADED
#ifdef CONAVL
/* ns010.102 - Addition for CONRD support */
#ifndef CONRD
/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   SchedParam sParam;
#endif /* SS_WINCE */
#endif /* CONRD */
#endif /* CONAVL */
#endif /* SS_SINGLE_THREADED */

   TRC0(ssdInitFinal)

   /* Set procId depeding on stack id */
   SSetProcId((U16)PID_STK(osCp.dep.stkId));

   /* Initialize NTSS init strcture */

   nsInit.ent     = ENTSS;   
   nsInit.inst    = 0;
   nsInit.region  = SS_DFLT_REGION;
   nsInit.pool    = SS_DFLT_POOL;
   nsInit.reason  = PWR_UP;
   nsInit.cfgDone = TRUE;
   nsInit.acnt    = FALSE;
   nsInit.usta    = FALSE;
   nsInit.trc     = FALSE;

   /* register the external event function */
   if (SRegActvTsk(ENTSS, 0, TTNORM, PRIOR1, nsActvTsk) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS014, ERRZERO, 
                            "Could not register NTSS activation function");
#endif
      RETVALUE(RFAILED);
   }

/* ns016.102 - Modification for Windows CE Support */
#if (!defined(SS_SINGLE_THREADED) || defined(SS_WINCE))
#ifdef CONAVL
/* ns010.102 - Addition to disable console reading with CONRD enabled */
#ifndef CONRD
   /* Create a thread which will read the console queue */
/*chendh disable it*/
#if 0
   if (sspthreadCreate(&osCp.dep.conThrd, NULLP, nsScanCon, NULLP) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS015, ERRZERO, 
                            "Could not create Console Thread");
#endif
      RETVALUE(RFAILED);
   }

/* ns016.102 - Modification for Windows CE Support */
#ifndef SS_WINCE
   sParam.schedPrior = NS_CON_THRD_PRIOR;

   if (sspthreadSetSchedParam(&osCp.dep.conThrd, SCHED_OTHER, &sParam) != ROK)
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS016, ERRZERO, 
                            "Could not set Console Thread priority");
#endif
      RETVALUE(RFAILED);
   }
#endif /* SS_WINCE */
#endif /*if 0*/
#endif /* CONRD */
#endif /* CONAVL */
/* ns016.102 - Modification for Windows CE Support */
#endif /* !SS_SINGLE_THREADED || SS_WINCE */

#ifdef SS_SINGLE_THREADED
#ifdef NU
   /* 
    * Create an event on for indicating message delivery. This event
    * will be used only in single-threaded mode 
    */
   if ((osCp.dep.eventWaitArray[NS_MSD_EVNT_IDX] 
                   = CreateEvent(NULL, FALSE, FALSE, NULL)) == NULLP)
   {
      error = GetLastError();
#if (ERRCLASS & ERRCLS_DEBUG)
      NSLOGERROR(ERRCLS_DEBUG, ENS017, (ErrVal)error, 
                            "Could not create message delivery event");
#endif
      RETVALUE(RFAILED);
   }

   /* increment number of events */
   osCp.dep.eventCount++;
#endif /* NU */

#endif /* SS_SINGLE_THREADED */

   RETVALUE(ROK); 

} /* ssdInitFinal */

  
/*
*
*       Fun:   ssdStart
*
*       Desc:  starter function
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void ssdStart
(
Void
)
#else
PUBLIC Void ssdStart(Void)
#endif
{
   TRC0(ssdStart)

#ifdef NU
#ifdef SS_SINGLE_THREADED
   /* for this thread call the task handler function */

   sTskHandler((Void *)&osCp.sTskTbl[0]);
#endif /* SS_SINGLE_THREADED */

#ifndef SS_SINGLE_THREADED
   /* for the time being suspend the thread */
   SuspendThread(GetCurrentThread());
#endif /* SS_SINGLE_THREADED */
#endif /* NU */

   RETVOID;

} /* end of ssdStart */


#ifdef NU
  
/*
*
*       Fun:   SGetOpt
*
*       Desc:  get options from command line
*
*       Ret:   option  - success
*              '?'     - fail
*              EOF     - end of options
*
*       Notes: handles command lines like the following
*
*              if opts = "abc:d" 
*                 then command line should look like this...
*                    -a foo -b foo1 -c -d foo
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetOpt
(
int argc,                   /* argument count */
char **argv,                /* argument value */
char *opts                  /* options */
)
#else
PUBLIC S16 SGetOpt(argc, argv, opts)
int argc;                   /* argument count */
char **argv;                /* argument value */
char *opts;                 /* options */
#endif
{

#ifndef NOCMDLINE
   S16 sp;
   S16 c;
   S8 *cp;
#endif /* NOCMDLINE */

   TRC1(SGetOpt)

#ifdef NOCMDLINE
   UNUSED(argc);
   UNUSED(argv);
   UNUSED(opts);
#endif /* NOCMDLINE */

#ifdef NOCMDLINE
   RETVALUE(EOF);
#else
   sp = 1;
   if (sp == 1)
      if (msOptInd >= (S16) argc || argv[msOptInd][0] == '\0')
         RETVALUE(EOF);
      else
      {
         if (!strcmp(argv[msOptInd], "--"))
         {
            msOptInd++;
            RETVALUE(EOF);
         }
         else if (argv[msOptInd][0] != '-')
         {
            msOptInd++;
            RETVALUE('?');
         }
      }
      msOptOpt = c = argv[msOptInd][sp];
      if ( c == ':' || (cp = strchr(opts, c)) == (S8*)NULLP )
      {
         if (argv[msOptInd][++sp] == '\0')
         {
            msOptInd++;
            sp = 1;
         }
         RETVALUE('?');
      }
      if (*++cp == ':')
      {
			  if (argv[msOptInd][sp+1] != '\0')
				  msOptArg = &argv[msOptInd++][sp+1];
			  else
			  {
				  if (++msOptInd >= (S16) argc)
				  {
					  sp = 1;
					  RETVALUE('?');
				  }
				  else
					  msOptArg = argv[msOptInd++];
				  sp = 1;
		  }
      }
      else
      {
         if (argv[msOptInd][++sp] == '\0')
         {
            sp = 1;
            msOptInd++;
         }
         msOptArg = NULLP;
      }
      RETVALUE(c);
#endif /* NOCMDLINE */

} /* end of SGetOpt */
#endif /* NU */


/*
*
*       Fun:   SDisplay
*
*       Desc:  This function displays a string to a given output
*              channel.
*
*       Ret:   ROK      - ok
*
*       Notes: Buffer should be null terminated.
*
*              channel 0 is reserved for backwards compatibility
*              with SPrint
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SDisplay
(
S16 chan,                   /* channel */
Txt *buf                    /* buffer */
)
#else
PUBLIC S16 SDisplay(chan, buf)
S16 chan;                   /* channel */
Txt *buf;                   /* buffer */
#endif
{
   U8     numBytes;

   TRC1(SDisplay)

/* ns011.102 - Modification to fix typo */
#if (ERRCLASS & ERRCLS_INT_PAR)
   if (buf == NULLP)
   {
      RETVALUE(RFAILED);
   }
#endif
   
#ifdef NU
#ifdef CONAVL
      /* ns014.102 - Modification to fix bug when using WriteConsole */
/* ns016.102 - Modification for Windows CE Support */
/* #ifndef SS_WINCE --- Modified by xingzhou.xu for not printing '\n' 2006/03/29 */
#if 0
      printf("%s\n", buf);
#else /* SS_WINCE */
      printf("%s", buf);
#endif /* SS_WINCE */
#endif /* CONAVL */

   if (outFileHandle != NULLP)
   {
      if (WriteFile(outFileHandle, buf, strlen(buf), \
                                (DWORD *)&numBytes,  NULL) == 0)
      {
         RETVALUE(RFAILED);
      }
   }
#endif /* NU */


   RETVALUE(ROK);

} /* end of SDisplay */

/* mt022.201 - Addition of SRegInfoShow function */
/*
*
*       Fun:   SRegInfoShow
*
*       Desc:  This function displays the memory usage information
*              for the destined region. It will show the usage of
*              each configured bucket and the heap for the specified region.
*
*       Ret:   ROK		OK
*              RFAILED		Region not registered
*
*       Notes: A Sample Output from the function 
*       Bucket Memory: region 1
*       ==================================================================
*       Bucket  Number of Blks configured  Size  Allocated  Max Allocated
*       ==================================================================
*       0                     1             64          1         5
*       1                     1             128         0         3
*       2                     1             256         0         1
*       3                     1             1600        0         1
*
*       ---------------
*       Heap Memory: region 0
*       Heap Size: 0
*       Heap Allocated: 0
*       Heap Segmented blocks: 0
*
*
*       File:  ns_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SRegInfoShow
(
Region region
)
#else
PUBLIC S16 SRegInfoShow(region)
Region region;
#endif
{
    CmMmRegCb *regionCb;
    int       idx;
    Txt     prntBuf[100];
    TRC1(SRegInfoShow);

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (region >= nsMemCfg.numRegions )
   {
      RETVALUE(RFAILED);
   }
#endif

    regionCb = osCp.regionTbl[region].regCb;

    sprintf(prntBuf, "\n\nBucket Memory: region %d\n", regionCb->region);
    SDisplay(0, prntBuf);
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
	sprintf(prntBuf, "==================================================================\n");
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "Bucket  Number of Blks configured  Size  Allocated  Max Allocated\n");
    SDisplay(0, prntBuf);
	sprintf(prntBuf, "==================================================================\n");
    SDisplay(0, prntBuf);
#else	
    sprintf(prntBuf, "====================================================\n");
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "Bucket  Number of Blks configured  Size  Allocated\n");
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "====================================================\n");
    SDisplay(0, prntBuf);
#endif

    for (idx = 0; idx < regionCb->numBkts; idx++)
    {
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
      sprintf(prntBuf, "%2d              %8lu          %5lu  %8lu  %8lu\n", 
#else      
      sprintf(prntBuf, "%2d              %8lu          %5lu  %8lu\n", 
#endif /* SSI_MEM_DEBUG */      
              idx, regionCb->bktTbl[idx].numBlks,
              regionCb->bktTbl[idx].size,
              regionCb->bktTbl[idx].numAlloc
#ifdef SSI_MEM_DEBUG /* xingzhou.xu: added for debug statistics  -- 07/10/2006 */
              ,regionCb->bktTbl[idx].maxAlloc
#endif /* SSI_MEM_DEBUG */
               );
      SDisplay(0, prntBuf);
    }
    sprintf(prntBuf, "\n---------------\n");
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "Heap Memory: region %d\n", regionCb->region);
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "Heap Size: %lu\n", regionCb->heapSize);
    SDisplay(0, prntBuf);
    sprintf(prntBuf, "Heap Allocated: %lu\n", 
           (regionCb->heapSize - regionCb->heapCb.avlSize));
    SDisplay(0, prntBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
    sprintf(prntBuf, "Heap Segmented blocks: %d\n",
                    regionCb->heapCb.numFragBlk);
    SDisplay(0, prntBuf);
#endif
    sprintf(prntBuf, "\nNow, The total alloc mem mumber is %d\n\n", 
        regionCb->bktTbl[0].numAlloc*regionCb->bktTbl[0].size +
        regionCb->bktTbl[1].numAlloc*regionCb->bktTbl[1].size +
        regionCb->bktTbl[2].numAlloc*regionCb->bktTbl[2].size +
        regionCb->bktTbl[3].numAlloc*regionCb->bktTbl[3].size +
        regionCb->heapSize - regionCb->heapCb.avlSize);
    SDisplay(0, prntBuf);

    RETVALUE(ROK);
} /* end of SRegInfoShow */

  
/*
*
*       Fun:   SGetDateTime
*
*       Desc:  This function is used to determine the calendar
*              date and time. This information may be used for
*              some management functions.
*
*       Ret:   ROK      - ok
*              RFAILED  - error
*
*       Notes:
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetDateTime
(
REG1 DateTime *dt           /* date and time */
)
#else
PUBLIC S16 SGetDateTime(dt)
REG1 DateTime *dt;          /* date and time */
#endif
{
#ifdef NU
   SYSTEMTIME t1;           /* Windows NT - time */
#endif /* NU */


   TRC1(SGetDateTime)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dt == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS018, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

#ifdef NU
   GetLocalTime(&t1);
   dt->month  = (U8) t1.wMonth;
   dt->day    = (U8) t1.wDay;
   dt->year   = (U8) (t1.wYear - NS_BASE_YEAR);
   dt->hour   = (U8) t1.wHour;
   dt->min    = (U8) t1.wMinute;
   dt->sec    = (U8) t1.wSecond;
   dt->tenths = (U8) t1.wMilliseconds/NS_SYS_TICK;
#endif /* NU */


   RETVALUE(ROK);

} /* end of SGetDateTime */


/*
*
*       Fun:   SSetDateTime
*
*       Desc:  This function is used to set the calendar
*              date and time.
*
*       Ret:   ROK      - ok
*
*       Notes:
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SSetDateTime
(
REG1 DateTime *dt           /* date and time */
)
#else
PUBLIC S16 SSetDateTime(dt)
REG1 DateTime *dt;          /* date and time */
#endif
{

#ifdef NU
   SYSTEMTIME t1;           /* Windows NT - time */

   TRC1(SSetDateTime)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (dt == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS019, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

   t1.wMonth        = (WORD)dt->month;
   t1.wDay          = (WORD)dt->day;
   t1.wYear         = (WORD)(dt->year + NS_BASE_YEAR);
   t1.wHour         = (WORD)dt->hour;
   t1.wMinute       = (WORD)dt->min;
   t1.wSecond       = (WORD)dt->sec;
   t1.wMilliseconds = (WORD)(dt->tenths * NS_SYS_TICK);

   if (SetSystemTime(&t1) != 0)
   {
      RETVALUE(ROK);
   }
   else
   {
      RETVALUE(RFAILED);
   }
#endif /* NU*/

} /* end of SSetDateTime */
 

/*
*
*       Fun:   SGetSysTime
*
*       Desc:  This function is used to determine the system
*              time. This information may be used for
*              some management functions.
*
*       Ret:   ROK      - ok
*
*       Notes: 
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetSysTime
(
Ticks *sysTime              /* system time */
)
#else
PUBLIC S16 SGetSysTime(sysTime)
Ticks *sysTime;             /* system time */
#endif
{


   TRC1(SGetSysTime)

#if (ERRCLASS & ERRCLS_INT_PAR)      
   if (sysTime == (Ticks *) NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS020, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

#ifdef NU
   /* For Windows NT the tick resolution is 1 millisecond */
   /* For NTSS Assuming a tick is 100 millisec */

   *sysTime = (Ticks)(GetTickCount()/NS_SYS_TICK);

#endif /* NU */


   RETVALUE(ROK);

} /* end of SGetSysTime */

/* ns012.102 - Addition of SGetRefTime function */
/*
*
*       Fun:   Get referenced time
*
*       Desc:  This function is used to determine the time in seconds
*              and microseconds from a reference time.  The reference
*              time is expressed in seconds from UTC EPOC, January 1,
*              1970.
*
*       Ret:   ROK      - ok
*              RFAILED  - fail
*
*       Notes: Macros are defined for reference times:
*                 SS_REFTIME_01_01_1970
*                 SS_REFTIME_01_01_2002
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SGetRefTime
(
U32 refTime,             /* reference time */
U32 *sec,      		/* returned referenced seconds */
U32 *usec		/* returned referenced microseconds */
)
#else
PUBLIC S16 SGetRefTime(refTime, sec, usec)
U32 refTime;             /* reference time */
U32 *sec;      		/* returned referenced seconds */
U32 *usec;		/* returned referenced microseconds */
#endif
{
#ifdef NU
   SYSTEMTIME t1;
   FILETIME t2, t3;
   ULARGE_INTEGER t4;
   __int64 t5;
#endif /* NU */

   TRC1(SGetRefTime);


#ifdef NU
   GetLocalTime(&t1);			/* local time as SYSTEMTIME */
   SystemTimeToFileTime(&t1, &t2);	/* local time as FILETIME */
   LocalFileTimeToFileTime(&t2,&t3);	/* UTC time from Jan 1, 1601 as FILETIME*/
   t4 =*(ULARGE_INTEGER*)&t3;		/* copy UTC time to ULARGE_INTEGER structure */
   t5 =*(__int64 *)&t4;			/* covert UTC time to 64-bit for arithmetic */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (sec == NULLP || usec == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Null pointer");
      RETVALUE(RFAILED);
   }
   if (refTime > (U32)((t5 / 10000000) - 11644473599))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENSXXX, ERRZERO, "Reference time exceeds present time");
      RETVALUE(RFAILED);
   }
#endif

   *sec = (U32)( (t5 / 10000000) - 11644473599 - refTime);
   *usec = (U32)( (t5 % 10000000) / 10); 
#endif /* NU */

   RETVALUE(ROK);
}

/*
*
*       Fun:   SExit
*
*       Desc:  Call all the registered exit functions and exit
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes:
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void SExit
(
void
)
#else
PUBLIC Void SExit()
#endif
{
   TRC1(SExit)
#if 1 /*ns004.12: addition */
   ExitProcess(1);
#endif /*ns004.12: addition */

/* ns016.102 - Modification for Windows CE Support */
#ifdef SS_WINCE
   WaitForSingleObject(GetCurrentProcess(), INFINITE);
#endif
   
   RETVOID;

} /* end of SExit */


  
/*
*
*       Fun:   SRandom
*
*       Desc:  Invoked by layer when a pseudorandom number is required.
*
*       Ret:   ROK      - ok
*
*       Notes: Suggested approach uses shuffled Linear Congruential
*              Operators as described in Byte magazine October
*              1984; "Generating and Testing Pseudorandom Numbers"
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SRandom
(
Random *value               /* random number */
)
#else
PUBLIC S16 SRandom(value)
Random *value;              /* random number */
#endif
{

   TRC1(SRandom)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (value == NULLP)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS021, value, "Null pointer");
      RETVALUE(RFAILED);
   }
#endif

#ifdef NU
   *value = (Random )rand();
#endif /* NU */


   RETVALUE(ROK);

} /* end of SRandom */


/*
*
*       Fun:   SExitTsk
*
*       Desc:  This function exits from a task.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing.
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SExitTsk
(
void
)
#else
PUBLIC S16 SExitTsk()
#endif
{
   TRC1(SExitTsk)

   RETVALUE(ROK);

} /* end of SExitTsk */



/*
*
*       Fun:   Exit Interrupt
*
*       Desc:  This function exits from an interrupt.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing.
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SExitInt
(
void
)
#else
PUBLIC S16 SExitInt()
#endif
{
   TRC1(SExitInt)

   RETVALUE(ROK);

} /* end of SExitInt */

  
/*
*
*       Fun:   Hold Interrupt
*
*       Desc:  This function prohibits interrupts from being enabled until
*              release interrupt. This function should be called when
*              interrupts are disabled and prior to any call to system
*              services either by entry to an interrupt service routine or
*              by explicit call to disable interrupt.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SHoldInt
(
void
)
#else
PUBLIC S16 SHoldInt()
#endif
{
   TRC1(SHoldInt)

   RETVALUE(ROK);

} /* end of SHoldInt */


/*
*
*       Fun:   Release Interrupt
*
*       Desc:  This function allows interrupts to be enabled.
*
*       Ret:   ROK      - ok
*
*       Notes: Currently does nothing.
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 SRelInt
(
void
)
#else
PUBLIC S16 SRelInt()
#endif
{
   TRC1(SRelInt)

   RETVALUE(ROK);

} /* end of SRelInt */


/*
*
*       Fun:   SEnbInt
*
*       Desc:  Enable interrupts 
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Currently does nothing.
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SEnbInt
(
void
)
#else
PUBLIC INLINE S16 SEnbInt()
#endif
{
   TRC1(SEnbInt)

   RETVALUE(ROK);

} /* end of SEnbInt */


/*
*
*       Fun:   SDisInt
*
*       Desc:  Disable interrupts 
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Currently does nothing.
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SDisInt
(
void
)
#else
PUBLIC INLINE S16 SDisInt()
#endif
{
   TRC1(SDisInt)

   RETVALUE(ROK);

} /* end of SDisInt */


#ifdef SS_DRVR_SUPPORT

/*
*
*       Fun:   SSetIntPend
*
*       Desc:  set interrupt pending flag
*
*       Ret:   ROK on success
*              RFAILED on error
*
*       Notes: Set interrupt pending flags in System Service
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC INLINE S16 SSetIntPend
(
U16  id,
Bool flag
)
#else
PUBLIC INLINE S16 SSetIntPend(id, flag)
U16  id;
Bool flag;
#endif
{
#ifdef NU
   U32   error;
#endif /* NU */

   TRC1(SSetIntPend)
      
#if (ERRCLASS & ERRCLS_DEBUG)
   if (id >= SS_MAX_DRVRTSKS) 
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS022, ERRZERO, "Invalid channel");
      RETVALUE(RFAILED);
   }
#endif

   if (osCp.drvrTskTbl[id].used != FALSE)
   {
      osCp.drvrTskTbl[id].dep.isFlag = flag;

      /* singal the interrupt */
      if (flag == TRUE)
      {
#ifdef NU          
         if (!SetEvent(osCp.dep.eventWaitArray[NS_INTR_EVNT_IDX]))
         {
            error = GetLastError();
            NSLOGERROR(ERRCLS_DEBUG, ENS023, (ErrVal)error, 
                                        "Could not signal the interrupt ");
            RETVALUE(RFAILED);
         }
#endif /* NU */


      }
      else
      {
#ifdef NU
         if (!ResetEvent(osCp.dep.eventWaitArray[NS_INTR_EVNT_IDX]))
         {
            error = GetLastError();
            NSLOGERROR(ERRCLS_DEBUG, ENS024, (ErrVal)error, 
                                        "Could not reset the interrupt ");
            RETVALUE(RFAILED);
         }
#endif /* NU */


      }
   }
#if (ERRCLASS & ERRCLS_DEBUG)
   else
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS025, ERRZERO, "Invalid channel");
      RETVALUE(RFAILED);
   }
#endif

   RETVALUE(ROK);

} /* end of SSetIntPend */

#endif /* SS_DRVR_SUPPORT */


#ifdef NS_ENB_MGMT
  
/*
*
*       Fun:   SGetEntInst
*
*       Desc:  This function gets the current entity and instance.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: This function may be called by the LMI or layer
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SGetEntInst
(
Ent *ent,                    /* entity */
Inst *inst                   /* instance */
)
#else
PUBLIC S16 SGetEntInst(ent, inst)
Ent *ent;                    /* entity */
Inst *inst;                  /* instance */
#endif
{
   U8     i;
#ifdef NU
   HANDLE thread;
#endif /* NU */

   TRC1(SGetEntInst)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* check entity pointer */
   if (!ent)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS026, ERRZERO, "Null entity pointer");
      RETVALUE(RFAILED);
   }
   /* check instance pointer */
   if (!inst)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS027, ERRZERO, "Null instance pointer");
      RETVALUE(RFAILED);
   }
#endif

   thread = nsGetCurrentThread();

   if (SLock(&osCp.sTskTblLock) != ROK)
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS028, ERRZERO, "Could not System task table");
      RETVALUE(RFAILED);
   }
    
   for (i=0; i < osCp.numSTsks; i++)
   {
      if (osCp.sTskTbl[i].dep.sTskHandle == thread)
         break; 
   }

   if (SLock(&osCp.sTskTbl[i].dep.stsLock) != ROK)
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS029, ERRZERO, 
                            "Could not Lock System task ent/inst lock");
      SUnlock(&osCp.sTskTblLock);
      RETVALUE(RFAILED);
   }
    
   *ent  = osCp.sTskTbl[i].dep.crntEnt;  /* get current entity */
   *inst = osCp.sTskTbl[i].dep.crntInst; /* get current instance */

   SUnlock(&osCp.sTskTbl[i].dep.stsLock);
   SUnlock(&osCp.sTskTblLock);
   RETVALUE(ROK);

} /* end of SGetEntInst */

  
/*
*
*       Fun:   SSetEntInst
*
*       Desc:  This function sets the current entity and instance.
*
*       Ret:   ROK      - ok
*              RFAILED  - failed, general (optional)
*
*       Notes: This function may be called by the LMI or layer
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC S16 SSetEntInst
(
Ent  ent,                   /* entity */
Inst inst                   /* instance */
)
#else
PUBLIC S16 SSetEntInst(ent, inst)
Ent  ent;                   /* entity */
Inst inst;                  /* instance */
#endif
{
   U8     i;
#ifdef NU
   HANDLE thread;
#endif /* NU */

   TRC1(SSetEntInst)

#if (ERRCLASS & ERRCLS_INT_PAR)
 /* check entity and instance ranges */
   if (ent >= SS_MAX_ENT ||  inst >= SS_MAX_INST)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS030, ERRZERO, "Invalid entity/instance");
      RETVALUE(RFAILED);
   }
#endif

   thread = nsGetCurrentThread();

   if (SLock(&osCp.sTskTblLock) != ROK)
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS031, ERRZERO, "Could not System task table");
      RETVALUE(RFAILED);
   }
    
   for (i=0; i < osCp.numSTsks; i++)
   {
      if (osCp.sTskTbl[i].dep.sTskHandle == thread)
         break; 
   }

   if (SLock(&osCp.sTskTbl[i].dep.stsLock) != ROK)
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS032, ERRZERO, 
                            "Could not Lock System task ent/inst lock");
      SUnlock(&osCp.sTskTblLock);
      RETVALUE(RFAILED);
   }
    
   osCp.sTskTbl[i].dep.crntEnt  = ent;  /* set current entity */
   osCp.sTskTbl[i].dep.crntInst = inst; /* set current instance */

   SUnlock(&osCp.sTskTbl[i].dep.stsLock);
   SUnlock(&osCp.sTskTblLock);
   RETVALUE(ROK);

} /* end of SSetEntInst */

  
/*
*     interface functions to layer management
*/
  
/*
*
*       Fun:   NsMiLnsStaReq
*
*       Desc:  This function is used by the Layer Management to
*              gather solicited status information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC S16 NsMiLnsStaReq
(
Pst *pst,                       /* post */
NsMngmt *sta                    /* status */
)
#else
PUBLIC S16 NsMiLnsStaReq(pst, sta)
Pst *pst;                       /* post */
NsMngmt *sta;                   /* status */
#endif
{
   Pst smPst;
   S16 ret;                 /* return code */

   TRC3(NsMiLnsStaReq)

   ret = SGetDateTime(&sta->t.ssta.dt);
#if ( ERRCLASS & ERRCLS_DEBUG )
   if(ret != ROK)
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS033, (ErrVal)ret, "SGetDateTime Failed");
      RETVALUE(ret);
   }
#endif /* ERRCLASS */

   switch (sta->hdr.elmId.elmnt)
   {
      case STSPOOL:          /* static pool */
      {  
         /*
          * elmInst1 - gives region number 
          * elmInst2 - gives pool number
          */
         SsdSPoolEntry *s;              /* static pool */
         Region        region;

         /* lock the region table */
         SS_ACQUIRE_ALL_SEMA(&osCp.regionTblSem, ret);
         if (ret != ROK)
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS034, (ErrVal) ret,
                        "Could not lock region table");
#endif

            RETVALUE(RFAILED);
         }

         region = (Region)sta->hdr.elmId.elmntInst1;
         if (osCp.regionTbl[region].used == TRUE)
         {
            s = &osCp.regionTbl[region].
                              poolTbl[sta->hdr.elmId.elmntInst2].u.spool.dep;
            sta->t.ssta.s.nsSPool.maxSize  = s->maxSize;
            sta->t.ssta.s.nsSPool.minSize  = s->minSize;
            sta->t.ssta.s.nsSPool.crntSize = s->crntSize;
            sta->t.ssta.s.nsSPool.bufSize  = s->bufSize;
         } 
         else
         {
            /* Release region table lock */
            SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);
            RETVALUE(RFAILED);
         }
         /* Release region table lock */
         SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);

         break;
      }

      case STDPOOL:          /* dynamic pool */
      {
         /*
          * elmInst1 - gives region number 
          * elmInst2 - gives pool number
          */
         SsdDPoolEntry *d;
         Region        region;

         /* lock the region table */
         SS_ACQUIRE_ALL_SEMA(&osCp.regionTblSem, ret);
         if (ret != ROK)
         {

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS035, (ErrVal) ret,
                        "Could not lock region table");
#endif

            RETVALUE(RFAILED);
         }

         region = (Region)sta->hdr.elmId.elmntInst1;
         if(osCp.regionTbl[region].used == TRUE)
         {
            d = &osCp.regionTbl[region].
                              poolTbl[sta->hdr.elmId.elmntInst2].u.dpool.dep;
            sta->t.ssta.s.nsDPool.maxSize = d->maxSize;
            sta->t.ssta.s.nsDPool.minSize = d->minSize;
            sta->t.ssta.s.nsDPool.minSize = d->crntSize;
         } 
         else
         {
            /* Release region table lock */
            SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);
            RETVALUE(RFAILED);
         }
         /* Release region table lock */
         SS_RELEASE_ALL_SEMA(&osCp.regionTblSem);

         break;
      }

      case STDQ:            /* demand queue */
      {
         /* elmInst1 -  system task Id */
         SsDmndQ *d;
         SSTskId  sId;

         /* lock system task table */
         ret = SLock(&osCp.sTskTblLock);
         if (ret != ROK)
         {
            NSLOGERROR(ERRCLS_DEBUG, ENS036, ERRZERO,
                           "Could not lock system task table");
            RETVALUE(RFAILED);
         }

         sId = (SSTskId)sta->hdr.elmId.elmntInst1;
         if (osCp.sTskTbl[sId].used == TRUE)
         {
            d = &osCp.sTskTbl[sId].dQ;
            ssFndLenDmndQ(d, PRIORNC, &sta->t.ssta.s.nsDq.size);
         }
         else
         {
            SUnlock(&osCp.sTskTblLock);
            RETVALUE(RFAILED);
         }
         SUnlock(&osCp.sTskTblLock);

         break;
      }
      case STENT:           /* entity */
      {
         /* elmntInst1 - gives the entity id */
         Ent  ent;
         Bool found = FALSE;
         U8   i;

         /* lock TAPA task table */
         SS_ACQUIRE_ALL_SEMA(&osCp.tTskTblSem, ret);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS037, ERRZERO,
                           "Could not lock TAPA task table");
#endif
            RETVALUE(RFAILED);
         }
         
         ent = (Ent)sta->hdr.elmId.elmntInst1;
         for (i=0; i < SS_MAX_INST; i++)
         {
            if (osCp.tTskIds[ent][i] != SS_TSKNC)
            {
               found = TRUE;
               break;
            }
         }

         if (found == TRUE)
         {
            sta->t.ssta.s.nsEnt.nmbInst = 0;
            for (i=0; i < SS_MAX_INST; i++)
            {
               if(osCp.tTskIds[ent][i] != SS_TSKNC)
                  sta->t.ssta.s.nsEnt.nmbInst++;
                  
            }
            sta->t.ssta.s.nsEnt.maxInst = SS_MAX_INST;
         }
         else
         { 
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS038, ERRZERO,
                                      "Invalid Entity Id Passed");
#endif
            /* unlock table */
            SS_RELEASE_ALL_SEMA(&osCp.tTskTblSem);
            RETVALUE(RFAILED);
         }
         /* unlock tables */
         SS_RELEASE_ALL_SEMA(&osCp.tTskTblSem);

         break;
      }

      case STSID:           /* system id */
         nsGetSId(&sta->t.ssta.s.sysId);
         break;

      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS039, (ErrVal)sta->hdr.elmId.elmnt,  \
                                                                "Value Wrong");
#endif /* ERRCLASS */
         RETVALUE(RFAILED);
      }
   }

   smPst.dstProcId = pst->srcProcId;
   smPst.srcProcId = SFndProcId();

   smPst.dstEnt  = pst->srcEnt;
   smPst.dstInst = pst->srcInst;
   smPst.srcEnt  = nsInit.ent;
   smPst.srcInst = nsInit.inst;
   smPst.prior   = pst->prior;
   smPst.route   = pst->route;
   smPst.event   = 0;
   smPst.region  = SS_DFLT_REGION;
   smPst.pool    = SS_DFLT_POOL;

#ifdef LCNSMILNS
   smPst.selector = 0;          /* send it loosely coupled if possible */
#else
   smPst.selector = 1;          /* else tightly coupled to SM */
#endif /* LCNSMILNS */
   
   RETVALUE(NsMiLnsStaCfm(&smPst, sta));

} /* end of NsMiLnsStaReq */
  
  
/*
*
*       Fun:   NsMiLnsStsReq
*
*       Desc:  This function is used by the Layer Management to
*              gather solicited statistics information.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
  
#ifdef ANSI
PUBLIC S16 NsMiLnsStsReq
(
Pst *pst,                       /* post */
Action action,                  /* action */
NsMngmt *sts                    /* statistics */
)
#else
PUBLIC S16 NsMiLnsStsReq(pst, action, sts)
Pst *pst;                       /* post */
Action action;                  /* action */
NsMngmt *sts;                   /* statistics */
#endif
{
   Pst smPst;
   S16 ret;                 /* return code */

   TRC3(NsMiLnsStsReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (action > NOZEROSTS)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS040, (ErrVal)action, "Wrong Value");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   ret = SGetDateTime(&sts->t.sts.dt);
#if (ERRCLASS & ERRCLS_DEBUG)
   if ( ret != ROK )
   {
      NSLOGERROR(ERRCLS_DEBUG, ENS041, (ErrVal)ret, "SGetDateTime failed");
      RETVALUE(RFAILED);
   }
#endif  

   switch (sts->hdr.elmId.elmnt)
   {
      case STLOOP:           /* loop */
      {
         /* elmntInst1 -  system task id */
         SsSTskEntry *sTsk;

         /* lock system task table */
         ret = SLock(&osCp.sTskTblLock);
         if (ret != ROK)
         {
            NSLOGERROR(ERRCLS_DEBUG, ENS042, ERRZERO,
                           "Could not lock system task table");
            RETVALUE(RFAILED);
         }

         sTsk = &osCp.sTskTbl[sts->hdr.elmId.elmntInst1];
         if (sTsk->used == TRUE)
         { 
            /* lock this system task entry */
            if (!SS_CHECK_CUR_STSK(sTsk))
            {
               ret = SLock(&sTsk->lock);
               if (ret != ROK)
               {
                  SUnlock(&osCp.sTskTblLock);

#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS043, (ErrVal) ret,
                                 "Could not lock system task entry");
#endif
                  RETVALUE(RFAILED);
               }
            }
            
            sts->t.sts.s.nsLoop.loopActvCnt = sTsk->dep.loopActvCnt;
            sts->t.sts.s.nsLoop.loopIdleCnt = sTsk->dep.loopIdleCnt;
            sts->t.sts.s.nsLoop.loopPermCnt = sTsk->dep.loopPermCnt;
            sts->t.sts.s.nsLoop.loopNormCnt = sTsk->dep.loopNormCnt;
            sts->t.sts.s.nsLoop.loopTmrCnt  = sTsk->dep.loopTmrCnt;
            if (action == ZEROSTS)
            {
               /* zero statistics here */
               sTsk->dep.loopActvCnt = NULLD;
               sTsk->dep.loopIdleCnt = NULLD;
               sTsk->dep.loopPermCnt = NULLD;
               sTsk->dep.loopNormCnt = NULLD;
               sTsk->dep.loopTmrCnt  = NULLD;
            }
         }
         else
         {
            SUnlock(&osCp.sTskTblLock);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS044, ERRZERO, "Wrong System task Id");
#endif
            RETVALUE(RFAILED);
         }

         if (!SS_CHECK_CUR_STSK(sTsk))
         {
            SUnlock(&sTsk->lock);
         }
         SUnlock(&osCp.sTskTblLock);

         break;
      }
      case STDQ:             /* demand queue */
      {
         
         /* elmntInst1 -  system task id */
         SsSTskEntry *sTsk;

         /* lock system task table */
         ret = SLock(&osCp.sTskTblLock);
         if (ret != ROK)
         {
            NSLOGERROR(ERRCLS_DEBUG, ENS045, ERRZERO,
                           "Could not lock system task table");
            RETVALUE(RFAILED);
         }

         sTsk = &osCp.sTskTbl[sts->hdr.elmId.elmntInst1];
         if (sTsk->used == TRUE)
         { 
            /* lock this system task entry */
            if (!SS_CHECK_CUR_STSK(sTsk))
            {
               ret = SLock(&sTsk->lock);
               if (ret != ROK)
               {
                  SUnlock(&osCp.sTskTblLock);

#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS046, (ErrVal) ret,
                                 "Could not lock system task entry");
#endif
                  RETVALUE(RFAILED);
               }
            }
            
            sts->t.sts.s.nsDq.emptyCnt    = sTsk->dep.emptyCnt;
            sts->t.sts.s.nsDq.notEmptyCnt = sTsk->dep.notEmptyCnt;
            if (action == ZEROSTS)
            {
               /* zero statistics here */
               sTsk->dep.emptyCnt    = NULLD;
               sTsk->dep.notEmptyCnt = NULLD;
            }
         }
         else
         {
            SUnlock(&osCp.sTskTblLock);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS047, ERRZERO, "Wrong System task Id");
#endif
            RETVALUE(RFAILED);
         }

         if (!SS_CHECK_CUR_STSK(sTsk))
         {
            SUnlock(&sTsk->lock);
         }
         SUnlock(&osCp.sTskTblLock);

         break;
      }
         
      case STENT:          /* entity */
      {
         /* elmntInst1 = entity 
          * elmntInst2 = instance
          */
         Ent   ent;
         Inst  inst;

         /* lock TAPA task table */
         SS_ACQUIRE_ALL_SEMA(&osCp.tTskTblSem, ret);
         if (ret != ROK)
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS048, ERRZERO,
                           "Could not lock TAPA task table");
#endif
            RETVALUE(RFAILED);
         }
         
         ent  = (Ent)sts->hdr.elmId.elmntInst1;
         inst = (Inst)sts->hdr.elmId.elmntInst2;

         if (osCp.tTskIds[ent][inst] != SS_TSKNC)
         {
            sts->t.sts.s.nsEnt.actvCnt = 
                     osCp.tTskTbl[osCp.tTskIds[ent][inst]].dep.actvCnt;
            if (action == ZEROSTS)
            {
               /* zero statistics here */
               osCp.tTskTbl[osCp.tTskIds[ent][inst]].dep.actvCnt = NULLD;
            }
         }
         else
         {
            /* unlock TAPA task table */
            SS_RELEASE_ALL_SEMA(&osCp.tTskTblSem);

#if (ERRCLASS & ERRCLS_DEBUG)
            NSLOGERROR(ERRCLS_DEBUG, ENS049, 
                    (ErrVal)sts->hdr.elmId.elmntInst1, "Wrong Value");
#endif /* ERRCLASS */
            RETVALUE(RFAILED);
         }
         /* unlock table */
         SS_RELEASE_ALL_SEMA(&osCp.tTskTblSem);

         break;
      }

      default:
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS050, (ErrVal)sts->hdr.elmId.elmnt, 
                                                              "Wrong Value");
#endif /* ERRCLASS */
         RETVALUE(RFAILED);
      }
   }

   smPst.dstProcId = pst->srcProcId;
   smPst.srcProcId = osCp.procId;

   smPst.dstEnt  = pst->srcEnt;
   smPst.dstInst = pst->srcInst;
   smPst.srcEnt  = nsInit.ent;
   smPst.srcInst = nsInit.inst;
   smPst.prior   = pst->prior;
   smPst.route   = pst->route;
   smPst.event   = 0;
   smPst.region  = SS_DFLT_REGION;
   smPst.pool    = SS_DFLT_POOL;

#ifdef LCNSMILNS
   smPst.selector = 0;          /* send it loosely coupled if possible */
#else
   smPst.selector = 1;          /* else tightly coupled to SM */
#endif /* LCNSMILNS */

   RETVALUE(NsMiLnsStsCfm(&smPst, action, sts));

} /* end of NsMiLnsStsReq */



  
/*
*
*       Fun:   NsMiLnsCntrlReq
*
*       Desc:  Controls for SCCP
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC S16 NsMiLnsCntrlReq
(
Pst *pst,
NsMngmt *cntrl                     /* Control Strucutre */
)
#else
PUBLIC S16 NsMiLnsCntrlReq(pst, cntrl)
Pst *pst;
NsMngmt *cntrl;                    /* Control Structure */
#endif
{
   TRC3(NsMiLnsCntrlReq)

   
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* validate message type */
   if (cntrl->hdr.msgType != TCNTRL)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS051, ERRZERO, "Wrong Msg Type");
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS */

   switch (cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
         switch (cntrl->t.cntrl.action)
         {
            /* enable unsolicited alarms */
            case AENA:
               if (cntrl->t.cntrl.subAction == SAUSTA)
               {
                  nsInit.usta = TRUE;
                  nsInit.lmPst.selector = cntrl->t.cntrl.smPst.selector;
                  nsInit.lmPst.region = cntrl->t.cntrl.smPst.region;
                  nsInit.lmPst.pool = cntrl->t.cntrl.smPst.pool;
                  nsInit.lmPst.prior = cntrl->t.cntrl.smPst.prior;
                  nsInit.lmPst.dstProcId = cntrl->t.cntrl.smPst.dstProcId;
                  nsInit.lmPst.dstEnt = cntrl->t.cntrl.smPst.dstEnt;
                  nsInit.lmPst.dstInst = cntrl->t.cntrl.smPst.dstInst;
                  nsInit.lmPst.srcProcId = SFndProcId();
                  nsInit.lmPst.srcEnt = nsInit.ent;
                  nsInit.lmPst.srcInst = nsInit.inst;
                  nsInit.lmPst.event = EVTNONE;
               }
               else
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS052, 
                          (ErrVal)cntrl->t.cntrl.subAction, "Wrong Sub Action");
#endif /* ERRCLASS */
               }
               break;
            case ADISIMM:
               if (cntrl->t.cntrl.subAction == SAUSTA)
               {
                  nsInit.usta = FALSE;
               }
               else
               {
#if (ERRCLASS & ERRCLS_DEBUG)
                  NSLOGERROR(ERRCLS_DEBUG, ENS053, 
                          (ErrVal)cntrl->t.cntrl.subAction,"Wrong Sub Action");
#endif /* ERRCLASS */
               }
               break;
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS054, cntrl->t.cntrl.action, \
                                                     "Wrong Action");
#endif /* ERRCLASS */
         break;
   }

   RETVALUE(ROK);

} /* end of NsMiLnsCntrlReq */
  
#endif /* NS_ENB_MGMT */


  
/*
*
*       Fun:   ssdDeinitGen
*
*       Desc:  Deinitialize the dependent data types
*
*       Ret:   void
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitGen
(
VOID
)
#else
PUBLIC Void ssdDeinitGen(VOID)
#endif
{
   TRC0(ssdDeinitGen)

   RETVOID;

} /* end of ssdDeinitGen */

  
/*
*
*       Fun:   ssdDeinitMem
*
*       Desc:  Deinitialize the Memory Manager
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitMem
(
VOID
)
#else
PUBLIC Void ssdDeinitMem(VOID)
#endif
{

   TRC0(ssdDeinitMem)


   RETVOID;

} /* end of ssdDeinitMem */
  
/*
*
*       Fun:   ssdDeinitFinal
*
*       Desc:  Deinitialize the dependent data structures here
*
*       Ret:   ROK       - ok
*              RFAILED   - failed
*
*       Notes: None
*
*       File:  np_gen.c
*
*/
#ifdef ANSI
PUBLIC Void ssdDeinitFinal
(
VOID
)
#else
PUBLIC Void ssdDeinitFinal(VOID)
#endif
{
   TRC0(ssdDeinitFinal)


   RETVOID;

} /* ssdDeinitFinal */


/********************************************************************30**
  
         End of file: np_gen.c 1.2  -  08/17/98 11:56:34
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release
  
1.2          ---      ag   1. Added worker thread for scanning 
                              interrupts in multi-threaded case
             ---      ag   2. Enabled function nsScanInt for UNTSS and
                              KNTSS
             ---      ag   3. Added more options to SGetOpt call in
                              nsGetOpts function
             ---      ag   4. Added an event(interrupt) for nsScanInt
             ---      bsr  5. Added nsDispatchOpen, nsDispatchClose,
                              nsIoctl, nsRegDevice, nsDeregDevice,
                              nsReadRegistry, nsParseRegInfo and 
                              nsGetNext
             ---      ag   6. Moved function ssdInitDrvr to np_task.c
             ---      bsr  7. Added file logging for KNTSS
             ---      kr   8. Moved Mmemory Manager Config to
                              np_space.c
             ---      ag   9. Changed procId to stkId in nsGetOpts
             ---      bsr 10. Added ERRCLASS wherever appropriate.
             ---      bsr 11. Replaced *pool* with *bkt* in nsMemCfg
             ---      kr  12. Added new ISR/DPR routines
             ---      sn  13. Modifications to C++ compile

1.2+         ns001.12 bsr  1. Fixed C++ compile errors 
             ns004.12 bdu  2. Implemented SExit function,
             ns006.12 jjn  3. Change nsArgv, nsArgc, nsOptInd, nsOptOpt
                              nsOptArg to msArgv, msArgc, msOptInd, 
                              msOptOpt and msOptArg, also change their
                              scope to PUBLIC. Define the ret when 
                              NOCMDLINE is defined in nsGetOpts.
	    ns008.102 bdu  4. Fix the console reading problem in 
	                      SINGLE_THREADED mode.
            ns010.102 bjp  5. Create CONRD macro, define to disable
	                      console reading
			      Bug fix in nsGetOpts
            ns011.102 bjp  6. Modification for typo fix in SDisplay
	    ns012.102 bjp  7. Addition of SGetRefTime function
            ns014.102 bjp  8. Modification to fix bug with WriteConsole
1.2+        ns016.102 bjp  9. Addition of Windows CE Support
            ns017.102 bjp 10. switched printf statements for WINCE and not in 
                              SDisplay.
*********************************************************************91*/
