/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     NTSS - portable management interface
  
     Type:     C source file
  
     Desc:     C source code for the Layer Management
               service provider primitives used in loosely coupled
               systems via NTSS.
 
     File:     ns_ptmi.c

     Sid:      ns_ptmi.c 1.2  -  08/11/98 12:03:59
  
     Prg:      ag 
  
*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "lns.h"           /* NTSS layer mgmt */
#include "ss_err.h"        /* system service error */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "lns.x"           /* NTSS layer mgmt */


/* local defines */
#define NS_MAX_MI_SEL  2   /* maximum number of selectors */

#ifndef LCNSMILNS
#define PTNSMILNS          /* portable, NTSS management interface */
#else
#ifndef SM
#define PTNSMILNS          /* portable, NTSS management interface */
#endif  /* SM */
#endif

/* local typedefs */

/* local externs */
#ifdef DBNSMILNS
PUBLIC  Bool dbNsMiLns = FALSE;;  /* debug layer management interface */
#endif
  
/* forward references */

/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */
 
#ifdef PTNSMILNS
PRIVATE S16 PtMiLnsStaCfm     ARGS((Pst *pst, NsMngmt *sta));
PRIVATE S16 PtMiLnsStsCfm     ARGS((Pst *pst, Action action, NsMngmt *sts));
PRIVATE S16 PtMiLnsStaInd     ARGS((Pst *pst, NsMngmt *usta));
#endif /* PTNSMILNS */
 
/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

#ifdef DBNSMILNS
PRIVATE Txt  prntBuf[PRNTSZE];
#endif



/*

the following matrices define the mapping between the primitives
called by the layer management interface of NTSS and the corresponding
primitives of the NTSS service user(s).
 
The parameter NS_MAX_MI_SEL defines the maximum number of service users on
top of NTSS. There is an array of functions per primitive
invoked by NTSS. Every array is NS_MAX_MI_SEL long (i.e. there
are as many functions as the number of service users).
 
The dispatching is performed by the configurable variable: selector.
The selector is configured during general configuration.
 
The selectors are:
 
 0 - loosely coupled - (#define LCNSMILNS)
 1 - Lns (#define NS)
 
*/

/* Statistic Confirm primitive */
 
PRIVATE LnsStaCfm NsMiLnsStaCfmMt[NS_MAX_MI_SEL] =
{
#ifdef LCNSMILNS
   nsPkMiLnsStaCfm,        /* 0 - loosely coupled */
#else
   PtMiLnsStaCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLnsStaCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsStaCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Statistic Confirm primitive */
 
PRIVATE LnsStsCfm NsMiLnsStsCfmMt[NS_MAX_MI_SEL] =
{
#ifdef LCNSMILNS
   nsPkMiLnsStsCfm,        /* 0 - loosely coupled */
#else
   PtMiLnsStsCfm,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLnsStsCfm,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsStsCfm,          /* 1 - tightly coupled, portable */
#endif
};

/* Status Indication primitive */
 
PRIVATE LnsStaInd NsMiLnsStaIndMt[NS_MAX_MI_SEL] =
{
#ifdef LCNSMILNS
   nsPkMiLnsStaInd,        /* 0 - loosely coupled */
#else
   PtMiLnsStaInd,          /* 0 - tightly coupled, portable */
#endif
#ifdef SM
   SmMiLnsStaInd,          /* 1 - tightly coupled, layer management */
#else
   PtMiLnsStaInd,          /* 1 - tightly coupled, portable */
#endif
};

/*
 * support functions
 */

/*
*     layer management interface functions 
*/
 

/*
*
*       Fun:   Status Confirm
*
*       Desc:  This function is used to return the status of NTSS
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 NsMiLnsStaCfm
(
Pst *pst,                 /* post structure */     
NsMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 NsMiLnsStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
NsMngmt *sta;             /* solicited status */
#endif
{
   TRC3(NsMiLnsStaCfm)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == NULLP ||( pst->selector >= NS_MAX_MI_SEL))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS224, (ErrVal)ERRZERO,
                 "NsMiLnsStaCfm: Invalid selector");
      RETVALUE(RFAILED);
   }
#endif

#ifdef DBNSMILNS
   if (dbNsMiLns)
   {
      sprintf(prntBuf, "[NS] [SM] Invoking Status Confirm\n\n");
      SPrint(prntBuf);
   }
#endif

   /* jump to specific primitive depending on configured selector */
   (*NsMiLnsStaCfmMt[pst->selector])(pst, sta); 

   RETVALUE(ROK);

} /* end of NsMiLnsStaCfm */
 

/*
*
*       Fun:   Statistics Confirm
*
*       Desc:  This function is used to return the statistics of NTSS
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 NsMiLnsStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
NsMngmt *sts              /* statistics */
)
#else
PUBLIC S16 NsMiLnsStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
NsMngmt *sts;             /* statistics */
#endif
{
   TRC3(NsMiLnsStsCfm)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == NULLP ||( pst->selector >= NS_MAX_MI_SEL))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS225, (ErrVal)ERRZERO,
                 "NsMiLnsStsCfm: Invalid selector");
      RETVALUE(RFAILED);
   }
#endif

#ifdef DBNSMILNS
   if (dbNsMiLns)
   {
      sprintf(prntBuf, "[NS] [SM] Invoking Statistics Confirm\n\n");
      SPrint(prntBuf);
   }
#endif

   /* jump to specific primitive depending on configured selector */
   (*NsMiLnsStsCfmMt[pst->selector])(pst, action, sts); 

   RETVALUE(ROK);

} /* end of NsMiLnsStsCfm */



/*
*
*       Fun:   Status Indication
*
*       Desc:  This function is used to send the unsolicited status
*              indication to the Stack Manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 NsMiLnsStaInd
(
Pst *pst,                 /* post structure */    
NsMngmt *sta              /* status */
)
#else
PUBLIC S16 NsMiLnsStaInd(pst, sta)
Pst *pst;                 /* post structure */    
NsMngmt *sta;             /* status */
#endif
{
   TRC3(NsMiLnsStaInd)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst == NULLP ||( pst->selector >= NS_MAX_MI_SEL))
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS226, (ErrVal)ERRZERO,
                 "NsMiLnsStaInd: Invalid selector");
      RETVALUE(RFAILED);
   }
#endif

#ifdef DBNSMILNS
   if (dbNsMiLns)
   {
      sprintf(prntBuf, "[NS] [SM] Invoking Status Indication\n\n");
      SPrint(prntBuf);
   }
#endif
   /* jump to specific primitive depending on configured selector */
   (*NsMiLnsStaIndMt[pst->selector])(pst, sta); 

   RETVALUE(ROK);

} /* end of NsMiLnsStaInd */

#ifdef PTNSMILNS

/*
*     layer management interface portable functions
*/

/*
*
*       Fun:   portable - Status Confirm
*
*       Desc:  This function is used to return the status of NTSS
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsStaCfm
(
Pst *pst,                 /* post structure */     
NsMngmt *sta              /* solicited status */
)
#else
PRIVATE S16 PtMiLnsStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
NsMngmt *sta;             /* solicited status */
#endif
{
   TRC3(PtMiLnsStaCfm)

   UNUSED(sta);

#if (ERRCLASS & ERRCLS_DEBUG)
   NSLOGERROR(ERRCLS_DEBUG, ENS227, ERRZERO, 
                                   "PtMiLnsStaCfm: Invalid selcetor");
#endif

   RETVALUE(ROK);

} /* end of PtMiLnsStaCfm */
 
/*
*
*       Fun:   portable - Statistics Confirm
*
*       Desc:  This function is used to return the statistics of NTSS
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
NsMngmt *sts              /* statistics */
)
#else
PRIVATE S16 PtMiLnsStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
NsMngmt *sts;             /* statistics */
#endif
{
   TRC3(PtMiLnsStsCfm)

   UNUSED(action);
   UNUSED(sts);

#if (ERRCLASS & ERRCLS_DEBUG)
   NSLOGERROR(ERRCLS_DEBUG, ENS228, ERRZERO,
                                         "PtMiLnsStsCfm: Invalid Selector");
#endif

   RETVALUE(ROK);

} /* end of PtMiLnsStsCfm */


/*
*
*       Fun:   portable - Status Indication
*
*       Desc:  This function is used to send the unsolicited status 
*              of NTSS to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ns_ptmi.c
*
*/
  
#ifdef ANSI
PRIVATE S16 PtMiLnsStaInd
(
Pst *pst,                 /* post structure */     
NsMngmt *usta             /* unsolicited status */
)
#else
PRIVATE S16 PtMiLnsStaInd(pst, usta)
Pst *pst;                 /* post structure */     
NsMngmt *usta;            /* unsolicited status */
#endif
{
   TRC3(PtMiLnsStaInd)

   UNUSED(usta);

#if (ERRCLASS & ERRCLS_DEBUG)
   NSLOGERROR(ERRCLS_DEBUG, ENS229, ERRZERO, 
                                     "PtMiLnsStaInd: Invalid Selector");
#endif

   RETVALUE(ROK);

} /* end of PtMiLnsStaInd */

#endif /* PTNSMILNS */




/********************************************************************30**
  
         End of file: ns_ptmi.c 1.2  -  08/11/98 12:03:59
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release

1.2          ---      bsr  1. Regenerated the error codes
  
*********************************************************************91*/
