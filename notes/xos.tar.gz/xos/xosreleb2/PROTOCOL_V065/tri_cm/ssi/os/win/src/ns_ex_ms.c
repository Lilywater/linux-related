/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     NTSSI - external interface 
  
     Type:     C source file
  
     Desc:     Functions required for external interface
  
     File:     ns_ex_ms.c
  
     Sid:      ns_ex_ms.c 1.2  -  08/11/98 12:02:34
  
     Prg:      ag
  
*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "lns.h"           /* NTSS management */



/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "lns.x"           /* NTSS management */


  
/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */

/* public variable declarations */
  
/* private variable declarations */


/*
*
*       Fun:    initialize external
*
*       Desc:   Initializes variables used to interface with Upper/Lower
*               Layer  
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ns_ex_ms.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsInitExt
(
void
)
#else
PUBLIC S16 nsInitExt()
#endif
{
   TRC2(nsInitExt)
   RETVALUE(ROK);

} /* end of nsInitExt */

   
/*
*
*       Fun:    activate task 
*
*       Desc:   Processes received event from Stack Manager
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   ns_ex_ms.c
*
*/

#ifdef ANSI
PUBLIC S16 nsActvTsk
(
Pst *pst,                   /* post */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 nsActvTsk(pst, mBuf)
Pst *pst;                   /* post */
Buffer *mBuf;               /* message buffer */
#endif
{
   S16 ret;

   TRC3(nsActvTsk)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (pst->prior > PRIOR3)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS221, pst->prior, "Invalid Priority");
      RETVALUE(RFAILED);
   }
#ifndef SS_DRVR_SUPPORT
   if (pst->route > RTEALL)
   {
      NSLOGERROR(ERRCLS_INT_PAR, ENS222, pst->route, "Invalid Route");
      RETVALUE(RFAILED);
   }
#endif /* SS_DRVR_SUPPORT */
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   switch(pst->event)
   {
#ifdef LCNSMILNS
      case EVTLNSSTAREQ:             /* Status request */
         ret = nsUnpkMiLnsStaReq(pst, mBuf);
         break;
      case EVTLNSSTSREQ:             /* Statistics request */
         ret = nsUnpkMiLnsStsReq(pst, mBuf);
         break;
      case EVTLNSCNTRLREQ:            /* Control request */
         ret = nsUnpkMiLnsCntrlReq(pst, mBuf);
         break;
#endif /* LCNSMILNS */
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         NSLOGERROR(ERRCLS_DEBUG, ENS223, ERRZERO, "Invalid event");
#endif /* ERRCLASS */
         SPutMsg(mBuf);         /* drop data */
         ret = RFAILED;
         break;
   }

   SExitTsk();
   RETVALUE(ret);

} /* end of nsActvTsk */

  
/********************************************************************30**
  
         End of file: ns_ex_ms.c 1.2  -  08/11/98 12:02:34
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release

1.2          ---      bsr  1. Regenerated the error codes
  
*********************************************************************91*/
