/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     common abnf parsing encoding/decoding
  
     Type:     C include file
  
     Desc:     Hash Defines used by encoding/decoding routines. 
  
     File:     cm_abnf.h
  
     Sid:      cm_abnf.h@@/main/10 - Wed Mar 30 08:42:17 2005
  
     Prg:      rm
  
*********************************************************************21*/

#ifndef __CMABNFH__
#define __CMABNFH__

#define CM_ABNF_TYPE_CHOICE                1
#define CM_ABNF_TYPE_SEQ                   2
#define CM_ABNF_TYPE_OPTSEQ                3
#define CM_ABNF_TYPE_STA_OPTSEQOF          4
#define CM_ABNF_TYPE_OPTSEQOF              5
#define CM_ABNF_TYPE_CONDSEQOF             6
#define CM_ABNF_TYPE_STA_SEQOF             7
#define CM_ABNF_TYPE_CHSEQOF               8
#define CM_ABNF_TYPE_SEQOF                 9
#define CM_ABNF_TYPE_META                  10
#define CM_ABNF_TYPE_UINT8                 11
#define CM_ABNF_TYPE_UINT16                12
#define CM_ABNF_TYPE_UINT32                13 
#define CM_ABNF_TYPE_ENUM                  14 
#define CM_ABNF_TYPE_SKIP                  15 
#define CM_ABNF_TYPE_OCTSTRXL              16 
#define CM_ABNF_TYPE_OCTSTR8               17 
#define CM_ABNF_TYPE_OCTSTR32              18 
#define CM_ABNF_TYPE_SET                   19
#define CM_ABNF_TYPE_TKNBUF                20
#define CM_ABNF_TYPE_MARKER                21
#define CM_ABNF_TYPE_HEXUINT8              22
#define CM_ABNF_TYPE_HEXUINT16             23
#define CM_ABNF_TYPE_HEXUINT32             24
#define CM_ABNF_TYPE_SINT8                 25
#define CM_ABNF_TYPE_SINT16                26
#define CM_ABNF_TYPE_SINT32                27
#define CM_ABNF_TYPE_HEXSINT8              28
#define CM_ABNF_TYPE_HEXSINT16             29
#define CM_ABNF_TYPE_HEXSINT32             30

/*
 * [TEL]: Added new definitions for U16 support
 */
#define CM_ABNF_TYPE_CHOICE_U16            31
#define CM_ABNF_TYPE_ENUM_U16              32


/* Flags */
#define CM_ABNF_MANDATORY                  0x01
#define CM_ABNF_OPTIONAL                   0x02
#define CM_ABNF_TKN_NOT_CONSUMED           0x04

#define CM_ABNF_PROT_SDP               ((U32) 0x00000000)
#define CM_ABNF_PROT_SIP               ((U32) 0x00010001)
#define CM_ABNF_PROT_SIP_ANY           ((U32) 0x00010002)
#define CM_ABNF_PROT_MGCP_RFC2705      ((U32) 0x00020001)
#define CM_ABNF_PROT_MGCP_TGCP_1_0     ((U32) 0x00020002)
#define CM_ABNF_PROT_MGCP_NCS_1_0      ((U32) 0x00020003)
#define CM_ABNF_PROT_MEGACO_H248       ((U32) 0x00030001)
#define CM_ABNF_PROT_MEGACO_H248_V2    ((U32) 0x00030002)

#define CM_ABNF_PROT_SDP_DEF_OFFSET                   0
#define CM_ABNF_PROT_SDP_OPT_OFFSET                   4
#define CM_ABNF_PROT_SIP_DEF_OFFSET                   0
#define CM_ABNF_PROT_MGCP_DEF_OFFSET                  0
#define CM_ABNF_PROT_MGCP_TGCP_OFFSET                 4
#define CM_ABNF_PROT_MGCP_NCS_OFFSET                  8
#define CM_ABNF_PROT_MEGACO_DEF_OFFSET                0
#define CM_ABNF_PROT_MEGACO_V2_OFFSET                4
/*
 * 001.main_10 : Adding new defines for max U32
 *              value's length in base 10 & 16
 */
#define CM_ABNF_MAX_LEN_BASE_10_U32                   10
#define CM_ABNF_MAX_LEN_BASE_10_S32                   10
#define CM_ABNF_MAX_LEN_BASE_16_U32                   8
#define CM_ABNF_MAX_LEN_BASE_16_S32                   8


#define CM_ABNF_FIND_PROT_OFFSET(_protVar)                                    \
(                                                                             \
   (_protVar) == CM_ABNF_PROT_SDP ? CM_ABNF_PROT_SDP_DEF_OFFSET :             \
   (_protVar) == CM_ABNF_PROT_SIP ? CM_ABNF_PROT_SIP_DEF_OFFSET :             \
   (_protVar) == CM_ABNF_PROT_MEGACO_H248 ? CM_ABNF_PROT_MEGACO_DEF_OFFSET :  \
   (_protVar) == CM_ABNF_PROT_MEGACO_H248_V2 ? CM_ABNF_PROT_MEGACO_V2_OFFSET :  \
   (_protVar) == CM_ABNF_PROT_MGCP_RFC2705 ? CM_ABNF_PROT_MGCP_DEF_OFFSET :   \
   (_protVar) == CM_ABNF_PROT_MGCP_TGCP_1_0 ? CM_ABNF_PROT_MGCP_TGCP_OFFSET : \
   (_protVar) == CM_ABNF_PROT_MGCP_NCS_1_0 ? CM_ABNF_PROT_MGCP_NCS_OFFSET :   \
   0                                                                          \
)

#define CM_ABNF_FIND_SDP_OFFSET(_protVar)                                     \
(                                                                             \
   (_protVar) == CM_ABNF_PROT_SDP ? CM_ABNF_PROT_SDP_DEF_OFFSET :             \
   (_protVar) == CM_ABNF_PROT_SIP ? CM_ABNF_PROT_SDP_DEF_OFFSET :             \
   (_protVar) == CM_ABNF_PROT_MEGACO_H248 ? CM_ABNF_PROT_SDP_OPT_OFFSET :     \
   (_protVar) == CM_ABNF_PROT_MEGACO_H248_V2 ? CM_ABNF_PROT_SDP_OPT_OFFSET :     \
   (_protVar) == CM_ABNF_PROT_MGCP_RFC2705 ? CM_ABNF_PROT_SDP_OPT_OFFSET :    \
   (_protVar) == CM_ABNF_PROT_MGCP_TGCP_1_0 ? CM_ABNF_PROT_SDP_DEF_OFFSET :   \
   (_protVar) == CM_ABNF_PROT_MGCP_NCS_1_0 ? CM_ABNF_PROT_SDP_DEF_OFFSET :    \
   0                                                                          \
)

/* Max defines */
#define CM_ABNF_MAX_UINTSZ                 10
#define CM_ABNF_MAX_HEXUINTSZ              10 /* For leading 0x/0X */
#define CM_ABNF_MAX_SEQOFELMNT            500

/* Marker types */
#define CM_ABNF_MARKER_SDP_BEGIN           1
#define CM_ABNF_MARKER_SDP_END             2
#define CM_ABNF_MARKER_ESC_FUNC            3

/* Error codes */
#define CM_ABNF_ERR_NONE                   0
#define CM_ABNF_ERR_TKN_NOTPRST            1
#define CM_ABNF_ERR_INV_CHOICE             2
#define CM_ABNF_ERR_DBELMNT                3
#define CM_ABNF_ERR_INV_UINTRNG            4
#define CM_ABNF_ERR_INV_STRRNG             5
#define CM_ABNF_ERR_ENCPARAM               7
#define CM_ABNF_ERR_PARSE                  8
#define CM_ABNF_ERR_RESFAIL                9
#define CM_ABNF_ERR_SEQEMPTY               10
#define CM_ABNF_ERR_SEQOFELM_MORE          11
#define CM_ABNF_ERR_SEQOFELM_LESS          12
#define CM_ABNF_ERR_REGEXP                 13
#define CM_ABNF_ERR_DUPLICATE              14


/* return values */
#define CM_ABNF_ROK      0
#define CM_ABNF_RFAILED  1  
#define CM_ABNF_ROPT     2

/* are we in encode path or decode path (for escape functions) */

#define CM_ABNF_ENCODE_PATH         0
#define CM_ABNF_DECODE_PATH         1

#define CM_ABNF_DBUF_ARRAY  30

#define CM_ABNF_ELMNID_CM_BASE                  0
#define CM_ABNF_ELMNID_SDP_BASE              1000 

#define CM_ABNF_ELMNID_MG_BASE              10000 
#define CM_ABNF_ELMNID_MGCO_BASE            14000 
#define CM_ABNF_ELMNID_MGCO_PKG_BASE        17000

#define CM_ABNF_ELMNID_NEXT_BASE            20000
#define CM_ABNF_ELMNID_SIP_BASE            CM_ABNF_ELMNID_NEXT_BASE

/* defines for multithreading support */
/* defines for different events */
#define EVTMEDDECREQ        0
#define EVTMEDENCREQ        1
#define EVTMEDDECCFM        2
#define EVTMEDENCCFM        3
#define EMEDBASE            0
#define EMEDXXX             EMEDBASE  

/* cm_abnf_h_001.main_3: Put following macros inside 
   a flag, so as to enable a choice of function/macro */

#ifndef CM_ABNF_USE_FUNC
#define cmAbnfGetChar(_offset)                                                 \
  ((((_offset)->dBufInfo[(_offset)->cur].cur) ==                               \
  ((_offset)->dBufInfo[(_offset)->cur].end)) ?  -1 :                           \
    (S16)(*((_offset)->dBufInfo[(_offset)->cur].cur)))

/* 001.main_6 : Patch propagation from 1.2 */
#define cmAbnfGetNxtChar(_offset, _numB)                                       \
  (((++((_offset)->dBufInfo[(_offset)->cur].cur)) ==                           \
  ((_offset)->dBufInfo[(_offset)->cur].end)) ?                                 \
   ((cmAbnfInitNxtDBuf((_offset)) != ROK) ? (((*(_numB))++),-1):               \
    ((*(_numB))++,                                                             \
     (*((_offset)->dBufInfo[(_offset)->cur].cur))))  :                         \
     ((*(_numB))++,                                                            \
      ((*((_offset)->dBufInfo[(_offset)->cur].cur)))))
#endif /* CM_ABNF_USE_FUNC*/

/* Common macro defines */
#define CM_ABNF_DECRET(_decCp, _yyret, _yydecode, _tkn, _len)  \
{                                                              \
   if (_len)                                                   \
      *(_len) = _yydecode;                                     \
   if (((_tkn) == FALSE) || ((_yyret) < 0))                    \
   {                                                           \
     cmAbnfDecOffset((_decCp), (_yydecode));                   \
   }                                                           \
   return((_yyret));                                           \
}

#define CM_ABNF_DEC_CHKLEN(_len, _yydecode)                    \
   (_len) ? ((_yydecode) >= (*(_len)) ? TRUE: FALSE) : FALSE       

#define CM_ABNF_DEC_CHCPY(_mem, _yych)                         \
{                                                              \
   if ((_mem) && (*(_mem)))                                    \
   {                                                           \
      (**(_mem)) = ((U8)(_yych));                              \
      (*(_mem))++;                                             \
   }                                                           \
}

#define  CM_ABNF_DEC_CSPSTRXL(_decCp, _mem, _len, _yydecode)              \
{                                                                         \
   U8  _ch;                                                               \
   if ((_mem) && (*(_mem) == NULLP) && (_len))                            \
   {                                                                      \
        cmAbnfDecOffset((_decCp), (_yydecode));                           \
        if (cmGetMem((_decCp)->memCp, (Size)(_yydecode),                  \
                     (Ptr *)(_mem)) != ROK)                               \
        {                                                                 \
           return(-1);                                                    \
        }                                                                 \
        (**(_mem)) = (U8)cmAbnfGetChar((_decCp)->offset);                 \
        (*(_mem))++;                                                      \
        for ((*(_len)) = 1;                                               \
                (*(_len)) < (_yydecode); (*(_len))++, (*(_mem))++)        \
        {                                                                 \
           (**(_mem)) =                                                   \
            (U8)cmAbnfGetNxtChar((_decCp)->offset, (_decCp)->numBytes);   \
        }                                                                 \
        _ch = (U8)cmAbnfGetNxtChar((_decCp)->offset, (_decCp)->numBytes); \
        *(_mem) = *(_mem) - *(_len);                                      \
    }                                                                     \
}

/* Debug macros */
#ifdef CM_ABNF_DBG
#ifdef CM_ABNF_DBGP

#define CM_ABNF_IS_PRINT(_c)                                            \
   (((_c) >= ' ' && (_c) <= '~') || (_c) == '\t')

#define CM_ABNF_DEC_DBGP(_event, _elmDef, _decCp)                       \
{                                                                       \
   sprintf(cmAbnfPrntBuf, "\nElmDef %s (RegExp %s)\n", (_elmDef)->str,  \
      (_elmDef)->regExpr);                                              \
   SPrint(cmAbnfPrntBuf);                                               \
   sprintf(cmAbnfPrntBuf, "event ptr = 0x%lx, decCp at '",              \
      ((_event) != NULLP) ? (PTR)(*(_event)) : (PTR)0 );                \
   SPrint(cmAbnfPrntBuf);                                               \
   if ((_decCp) != NULLP && (_decCp)->offset != NULLP &&                \
       (_decCp)->offset->dBufInfo[(_decCp)->offset->cur].cur != NULLP) \
   {                                                                    \
      U16 _i;                                                           \
      for (_i = 0; (_decCp)->offset->dBufInfo[(_decCp)->offset->cur].cur  \
           + _i != (_decCp)->offset->dBufInfo[(_decCp)->offset->cur].end; \
           _i++)                                                        \
      {                                                                 \
         Txt c;                                                         \
         c = (Txt)((_decCp)->offset->dBufInfo[(_decCp)->offset->cur].cur[_i]);\
         cmAbnfPrntBuf[_i] = (CM_ABNF_IS_PRINT(c) ? c : (Txt)'.');      \
      }                                                                 \
      cmAbnfPrntBuf[_i] = (Txt)0;                                       \
      SPrint(cmAbnfPrntBuf);                                            \
      sprintf(cmAbnfPrntBuf, "'");                                      \
      SPrint(cmAbnfPrntBuf);                                            \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      sprintf(cmAbnfPrntBuf, "<unknown>'");                              \
      SPrint(cmAbnfPrntBuf);                                            \
   }                                                                    \
   sprintf(cmAbnfPrntBuf, "\nMore info: elmDef -> id = %d, size = %ld\n",  \
      (_elmDef)->idNum, (_elmDef)->evSize);                             \
   SPrint(cmAbnfPrntBuf);                                               \
}

#define CM_ABNF_ENC_DBGP(_event, _elmDef, _encCp)                       \
{                                                                       \
   sprintf(cmAbnfPrntBuf, "\nElmDef %s (RegExp %s)\n", (_elmDef)->str,  \
      (_elmDef)->regExpr);                                              \
   SPrint(cmAbnfPrntBuf);                                               \
   sprintf(cmAbnfPrntBuf, "event ptr = 0x%lx, EncCp dBuf at '",         \
      ((_event) != NULLP) ? (PTR)(*(_event)) : (PTR)0 );                \
   SPrint(cmAbnfPrntBuf);                                               \
   if ((_encCp) != NULLP && (_encCp)->offset != NULLP &&                \
       (_encCp)->offset->start != NULLP &&                              \
       (_encCp)->offset->cur != NULLP)                                  \
   {                                                                    \
      U16 _i;                                                           \
      for (_i = 0; (_encCp)->offset->start + _i != (_encCp)->offset->cur;  \
           _i++)                                                        \
      {                                                                 \
         Txt c;                                                         \
         c = (Txt)(_encCp)->offset->start[_i];                          \
         cmAbnfPrntBuf[_i] = (CM_ABNF_IS_PRINT(c) ? c : (Txt)'.');      \
      }                                                                 \
      cmAbnfPrntBuf[_i] = (Txt)0;                                       \
      SPrint(cmAbnfPrntBuf);                                            \
      sprintf(cmAbnfPrntBuf, "'");                                      \
      SPrint(cmAbnfPrntBuf);                                            \
   }                                                                    \
   else                                                                 \
   {                                                                    \
      sprintf(cmAbnfPrntBuf, "<unknown>'");                             \
      SPrint(cmAbnfPrntBuf);                                            \
   }                                                                    \
   sprintf(cmAbnfPrntBuf, "\nMore info: elmDef -> id = %d, size = %ld\n",  \
      (_elmDef)->idNum, (_elmDef)->evSize);                             \
   SPrint(cmAbnfPrntBuf);                                               \
}

#else /* !CM_ABNF_DBGP */

#define CM_ABNF_DEC_DBGP(_event, _elmDef, _decCp)
#define CM_ABNF_ENC_DBGP(_event, _elmDef, _encCp)

#endif /* CM_ABNF_DBGP */

#else /* !CM_ABNF_DBG */

#define CM_ABNF_DEC_DBGP(_event, _elmDef, _decCp)
#define CM_ABNF_ENC_DBGP(_event, _elmDef, _encCp)

#endif /* CM_ABNF_DBG */

#define CMABNFLOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(ENTNC, INSTNC, SFndProcId(), \
                  __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

/* Error defines */
#define ECMABNFBASE     0
#define ECMABNFXXX      0

#define   ECMABNF001      (ECMABNFBASE +    1)    /*    cm_abnf.c:1302 */
#define   ECMABNF002      (ECMABNFBASE +    2)    /*    cm_abnf.c:1307 */
#define   ECMABNF003      (ECMABNFBASE +    3)    /*    cm_abnf.c:2498 */
#define   ECMABNF004      (ECMABNFBASE +    4)    /*    cm_abnf.c:2504 */

#endif  /* __CMABNFH__ */

  
/********************************************************************30**
  
         End of file:     cm_abnf.h@@/main/mgcp_rel_1.5_mnt/1 - Tue May 31 11:38:28 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.
/main/2      ---      nct  1. New release with GCP 1.2.
/main/3      ---      bsr  1. Added offset defines for SIP
/main/4      ---      asa  1. Put cmAbnfGetChar and cmAbnfGetNxtChar 
                              inside a compile time flag CM_ABNF_USE_FUNC
/main/6      ---      ra   1. Added defines for support of signed integers
/main/6  001.main_6   ra   1. Patch propagation from 1.2. numB var is
                              updated in all cases now - even when
                              cmAbnfInitNxtDBuf fails.
/main/8      ---      cy   1. Added define CM_ABNF_PROT_SIP_ANY
/main/9      ---     TEL   1. New hash defines included to support the  
                              change in mgEventDesc structure.
/main/10     ---      pk   1. GCP release 1.5 changes.                       
/main/10  001.main_10   ra   1. Adding new defines for max U32 & S32's value's
                              length in base 10 & 16.

*********************************************************************91*/
