/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
        Name:     common Internet socket library
    
        Type:     header file 
  
        Desc:     common library for Internet sockets
 
        File:     cm_inet.h

        Sid:      cm_inet.h@@/main/17 - Thu Jul 28 15:46:44 2005
  
        Prg:      mf
  
*********************************************************************21*/
 

/*
 *      This software may be combined with the following TRILLIUM
 *      software:
 *
 *      part no.                      description
 *      --------    ----------------------------------------------
 *      1000151     TCAP over TCP/IP
 */

#ifndef __CMINETH__
#define __CMINETH__

#define CM_INET_IPV4ADDR_SIZE      4
#define CM_INET_IPV6ADDR_SIZE      16

#define CM_INET_IPV4PORT_SIZE      2 
#define CM_INET_IPV6PORT_SIZE      2 

/* cm_inet_h_001.main_17 - reusing the definition */
#define CM_INET_IPV4ADDR_TYPE CM_IPV4ADDR_TYPE
#define CM_INET_IPV6ADDR_TYPE CM_IPV6ADDR_TYPE

#ifdef WIN32
#define CM_INET_HIGH_VER     2
#define CM_INET_LOW_VER      2
#endif /* WIN32 */

/* Invalid socket flag */
#ifdef WIN32
#define CM_INET_INV_SOCKFD INVALID_SOCKET
#else
#define CM_INET_INV_SOCKFD -1
#endif

#define CM_INET_IPV4_NUM_ADDR   16
#define CM_INET_IPV6_NUM_ADDR   4 

#ifdef IPV6_SUPPORTED 
#define CM_INET_IPV4_DOMAIN     AF_INET
#define CM_INET_IPV6_DOMAIN     AF_INET6
#endif /* IPV6_SUPPORTED */

/* domain */

/* socket types */
#define CM_INET_STREAM  SOCK_STREAM   
#define CM_INET_DGRAM   SOCK_DGRAM

#ifdef CM_INET2  
#define   CM_INET_RAW   SOCK_RAW
#endif  /* CM_INET2 */ 

/* socket options type */
#define CM_INET_OPT_BLOCK         0  /* blocking socket */ 
#define CM_INET_OPT_REUSEADDR     1  /* reuse socket address */
#define CM_INET_OPT_RX_BUF_SIZE   2  /* socket receive buffer size */
#define CM_INET_OPT_TX_BUF_SIZE   3  /* socket transmitt buffer size */
#define CM_INET_OPT_ADD_MCAST_MBR 4  /* add IP multicast group membership */
#define CM_INET_OPT_DRP_MCAST_MBR 5  /* drop IP multicast group membership */
#define CM_INET_OPT_TCP_NODELAY   6  /* disable TCP Nagle algorithm */



#ifdef SS_LINUX
#define CM_INET_OPT_BSD_COMPAT    7  /* BSD compatible option for Linux */
#endif /* SS_LINUX */

#define CM_INET_OPT_MCAST_LOOP    8  /* Multicast loop enable/disable */
#define CM_INET_OPT_MCAST_IF      9  /* specify local outgoing interface */
#define CM_INET_OPT_MCAST_TTL     14 /* Specify TTL value for multicast
                                      * applications */
#ifdef CM_INET2  
#define CM_INET_OPT_HDR_INCLD     10 /* Header Include */
#define CM_INET_OPT_DONTFRAGMENT  11 /* Don't Fragment  */
#define CM_INET_OPT_TOS           12 /* Type of service  */
#define CM_INET_OPT_TTL           13 /* Time to Live   */

#ifdef IPV6_SUPPORTED
#define CM_INET_OPT_ADD_MCAST6_MBR  15 /* Add IPV6 multicast member */
#define CM_INET_OPT_DRP_MCAST6_MBR  16 /* Drop IPV6 multicast member */
#define CM_INET_OPT_MCAST6_LOOP     17 /* Enable or disable multicast loop 
                                        * packets */
#define CM_INET_OPT_MCAST6_IF       18 /* Specify multicast interface */
#define CM_INET_OPT_MCAST6_HOPS     19 /* Specify multicast hop limit */

#define CM_INET_OPT_ICMP6_FILTER    20 /* Specify icmp V6 filter */
#define CM_INET_OPT_IPV6_TTL        21 /* Specify unicast hop limit */

/* IPv6 socket options */
#ifdef IPV6_OPTS_SUPPORTED
#define CM_INET_OPT_RECVIPV6_HOPLIM  22 /* Receive hop limit */
#define CM_INET_OPT_RECVIPV6_HBHOPTS 25  /* Receive HopByHop options */
#define CM_INET_OPT_RECVIPV6_DSTOPTS 26  /* Receive Destination options */
#define CM_INET_OPT_RECVIPV6_RTHDR   27  /* Receive Route header options */
#define CM_INET_ALL_IPV6_EXTHDRS_LEN 512 /* total length of 3 IPV6 ext hdrs */
#define CM_INET_OPT_IP_ROUTER_ALERT6 30
#endif /* IPV6_OPTS_SUPPORTED */
#define CM_INET_OPT_IPV6_PKTINFO     31
#endif /* IPV6_SUPPORTED */

/* IPv4 socket options */
#ifdef IPV4_OPTS_SUPPORTED
#define CM_INET_OPT_IP_OPTIONS       28 /* Router Alert in IPv4 */
#define CM_INET_OPT_IPV4_PKTINFO     32 /* IPv4 PKTINFO */
#define CM_INET_OPT_IP_ROUTER_ALERT  29 /* Router Alert to Intercept Linux */
#endif /* IPV4_OPTS_SUPPORTED */
#endif  /* CM_INET2 */ 

#define CM_INET_OPT_BROADCAST        23 /* Broadcasting enable/disable */
#define CM_INET_OPT_KEEPALIVE        24 /* KEEPALIVE enable/disable */

/* socket option value */
#define CM_INET_OPT_DISABLE  0      /* enable option */
#define CM_INET_OPT_ENABLE   1      /* disable option */

/* level for cmInetSetOpt */
#define CM_INET_LEVEL_SOCKET      SOL_SOCKET  /* socket level option */
#define CM_INET_LEVEL_IP          IPPROTO_IP  /* IP level option */
#define CM_INET_LEVEL_TCP         IPPROTO_TCP /* TCP level option */

/* shutdown options */
#ifdef WIN32
#define CM_INET_SHTDWN_RECV  SD_RECEIVE
#define CM_INET_SHTDWN_SEND  SD_SEND
#define CM_INET_SHTDWN_BOTH  SD_BOTH 
#else
#define CM_INET_SHTDWN_RECV  0
#define CM_INET_SHTDWN_SEND  1
#define CM_INET_SHTDWN_BOTH  2
#endif /* WIN32 */

/* send/recv control flags */
#define CM_INET_NO_FLAG   0
#define CM_INET_MSG_PEEK  MSG_PEEK

#if !(defined(WIN32) || defined(SS_LINUX))
#define CM_INET_MAX_INFO 512 
#endif /* WIN32 || SS_LINUX */

#define CM_INET_MAX_DBUF  15 /* max. number of dBufs for a message */

#define CM_INET_MAX_MSG_LEN  0x7fff  /* max length of a message */

#ifdef CMIET_LARGE_MAX_UDPRAW_SIZE
#define CM_INET_MAX_UDPRAW_MSGSIZE 4096 /* max size of UDP datagram */
#else
#define CM_INET_MAX_UDPRAW_MSGSIZE 2048 /* max size of UDP datagram */
#endif

#define CM_INET_IPV6_ANCIL_DATA  512
#define CM_INET_IPV4_ANCIL_DATA  128

#define CM_INET_READ_ANY  -1  /* read any pending data */

#define CM_INET_INADDR_ANY  INADDR_ANY  /* accepts any address */

#ifdef CM_INET2  

/* protocol values */
#define   CM_INET_PROTO_IP    IPPROTO_IP   /* IP protocol */
#define   CM_INET_PROTO_ICMP  IPPROTO_ICMP /* ICMP protocol */
#define   CM_INET_PROTO_TCP   IPPROTO_TCP  /* TCP  protocol */
#define   CM_INET_PROTO_UDP   IPPROTO_UDP  /* UDP protocol */
#define   CM_INET_PROTO_RAW   IPPROTO_RAW  /* Raw protocol */
#define   CM_INET_PROTO_SCTP  132          /* SCTP protocol  */
#define   CM_INET_PROTO_RSVP  46           /* RSVP protocol */

#ifdef IPV6_SUPPORTED
#define   CM_INET_LEVEL_IPV6   IPPROTO_IPV6   /* IP V6 protocol */
#define   CM_INET_PROTO_IPV6   IPPROTO_IPV6   /* IP V6 protocol */
#define   CM_INET_PROTO_ICMPV6 IPPROTO_ICMPV6 /* ICMP V6 protocol */
#endif /* IPV6_SUPPORTED */

#endif  /* CM_INET2 */ 

/* macros */

/* macros to manipulate and checking a socket file descriptor set */
#define CM_INET_FD_SET(_sockFd, _fdSet)    FD_SET((_sockFd)->fd, _fdSet) 
#define CM_INET_FD_CLR(_sockFd, _fdSet)    FD_CLR((_sockFd)->fd, _fdSet)
#define CM_INET_FD_ISSET(_sockFd, _fdSet)  FD_ISSET((_sockFd)->fd, _fdSet)
#define CM_INET_FD_ZERO(_fdSet)            FD_ZERO(_fdSet)

/* macros to convert from network to host byteorder and vice versa */
#define CM_INET_NTOH_U32(_long)  ntohl(_long)
#define CM_INET_HTON_U32(_long)  htonl(_long)
#define CM_INET_NTOH_U16(_word)  ntohs(_word)
#define CM_INET_HTON_U16(_word)  htons(_word)

/* peeks a U8 from the given position */
#define CM_INET_PEEK_U8(_sockFd, _fromAddr, _info, _pos, _octet, _ret)  \
   _ret = cmInetPeek(_sockFd, _fromAddr, _info, _pos, sizeof(U8), &_octet)  
          
/* 
 * peeks a U16 from the given position (it is supposed that the U16 is 
 * represented in big endian representation within the data stream) 
 */
#define CM_INET_PEEK_U16(_sockFd, _fromAddr, _info, _pos, _word, _ret)  \
   {  \
      U8 _tempWord[2];  \
      \
      _ret = cmInetPeek(_sockFd, _fromAddr, _info, _pos, sizeof(U16), _tempWord);  \
      if (_ret == ROK)  \
      {  \
         _word = ((_tempWord[0] << 8) + (_tempWord[1]));  \
      }  \
   }

/* 
 * peeks a U32 from the given position (it is supposed that the U32 is 
 * represented in big endian representation within the data stream)
 */
#define CM_INET_PEEK_U32(_sockFd, _fromAddr, _info, _pos, _long, _ret)  \
   {  \
      U8 _tempLong[4];  \
      \
      _ret = cmInetPeek(_sockFd, _fromAddr, _info, _pos, sizeof(U32), _tempLong);  \
      if (_ret == ROK)  \
      {  \
         _long = ((_tempLong[0] << 24) + (_tempLong[1] << 16)  \
                + (_tempLong[2] << 8) + _tempLong[3]);  \
      }  \
   }

/* tests if socket descriptor is invalide */
#ifdef WIN32 
#define CM_INET_INV_SOCK_FD(_sockFd)  ((_sockFd)->fd == INVALID_SOCKET)
#else
#define CM_INET_INV_SOCK_FD(_sockFd)  ((_sockFd)->fd < 0)
#endif /* WIN32 */

/* tests if two socket descriptor are equal */
#define CM_INET_SOCK_SAME(_s1, _s2, _ret)  \
   {  \
      _ret = FALSE;  \
      if ((_s1->fd == _s2->fd) &&  \
          (_s1->blocking == _s2->blocking) &&  \
          (_s1->type == _s2->type))  \
      {  \
         _ret = TRUE;  \
      }  \
   }

/* set socket descriptor to an invalid (uninitialized) value */
#ifdef WIN32 
#define CM_INET_SET_INV_SOCK_FD(_sockFd)  ((_sockFd)->fd = INVALID_SOCKET)
#else
#define CM_INET_SET_INV_SOCK_FD(_sockFd)  ((_sockFd)->fd = -1)
#endif /* WIN32 */

/* This macro frees ipHdrParm structure memory allocated to hold ipv6
 * extension headers */

#ifdef IPV6_OPTS_SUPPORTED
#define CM_INET_FREE_IPV6_HDRPARM(_region, _pool, _hdrParmIpv6) \
{ \
   U8 numOpts; \
   if( _hdrParmIpv6->ipv6ExtHdr.hbhHdrPrsnt) \
   { \
      for(numOpts = _hdrParmIpv6->ipv6ExtHdr.hbhOptsArr.numHBHOpts;  \
          numOpts > 0; numOpts--) \
      { \
         if (_hdrParmIpv6->ipv6ExtHdr.hbhOptsArr.hbhOpts[numOpts - 1].length) \
            SPutSBuf(_region, _pool, (Data *)_hdrParmIpv6->ipv6ExtHdr. \
                 hbhOptsArr.hbhOpts[numOpts - 1].value, (Size)(_hdrParmIpv6-> \
                 ipv6ExtHdr.hbhOptsArr.hbhOpts[numOpts - 1].length)); \
            SPutSBuf(_region, _pool, (Data *)&_hdrParmIpv6->ipv6ExtHdr. \
                 hbhOptsArr.hbhOpts[numOpts - 1], \
                 (Size)sizeof(CmInetIpv6HBHHdr)); \
      } \
   } \
   if(_hdrParmIpv6->ipv6ExtHdr.destOptsPrsnt) \
   { \
      for(numOpts = _hdrParmIpv6->ipv6ExtHdr.destOptsArr.numDestOpts; \
          numOpts > 0; numOpts--) \
      { \
         SPutSBuf(_region, _pool, (Data *)_hdrParmIpv6->ipv6ExtHdr. \
                destOptsArr.destOpts[numOpts - 1].value, (Size)(_hdrParmIpv6-> \
                ipv6ExtHdr.destOptsArr.destOpts[numOpts - 1].length)); \
         SPutSBuf(_region, _pool, (Data *)&_hdrParmIpv6->ipv6ExtHdr. \
                destOptsArr.destOpts[numOpts - 1], \
                (Size)sizeof(CmInetIpv6DestOptsHdr)); \
      } \
   } \
   if( _hdrParmIpv6->ipv6ExtHdr.rtOptsPrsnt) \
   { \
      SPutSBuf(_region, _pool, \
               (Data *)_hdrParmIpv6->ipv6ExtHdr.rtOptsArr.ipv6Addrs, \
               (Size)(_hdrParmIpv6->ipv6ExtHdr.rtOptsArr.numAddrs * 16)); \
   } \
}
/* Use the function for HBH options for destinations options as both ext
 * header has similar format */
  
#define cmInet6BuildRecvDstOptsArr(cmsgPtr, cmsg_len, destOptsArr, hdrId, info) \
        cmInet6BuildRecvHopOptsArr(cmsgPtr, cmsg_len, \
                              (CmInetIpv6HBHHdrArr *)destOptsArr, hdrId, info)

#define cmInet6BuildSendDestOpts(destOptsArr, cmsgData, curMsgIdx, hdrId) \
        cmInet6BuildSendHBHOpts((CmInetIpv6HBHHdrArr *)destOptsArr, \
                                 cmsgData, curMsgIdx, hdrId)
   
#endif /* IPV6_OPTS_SUPPORTED */

#ifdef IPV6_SUPPORTED
#define CM_INET_COPY_IPV6ADDR(_addrToFill, _fromAddr)   \
{                                                       \
   (Void)cmMemcpy((U8 *)_addrToFill, (U8 *)_fromAddr, sizeof(CmInetIpAddr6)); \
}

#if (defined(SUNOS) || defined(HPOS) || defined(SS_VW))

#define CM_INET_ICMP6_FILTER_SETPASSALL(_icmp6Filter)    \
{                                                        \
   ICMP6_FILTER_SETPASSALL(&_icmp6Filter);               \
}

#define CM_INET_ICMP6_FILTER_SETBLOCKALL(_icmp6Filter)   \
{                                                        \
   ICMP6_FILTER_SETBLOCKALL(&_icmp6Filter);              \
}

#define CM_INET_ICMP6_FILTER_SETPASS(msgType, _icmp6Filter)  \
{                                                            \
   ICMP6_FILTER_SETPASS(msgType, &_icmp6Filter);             \
}

#define CM_INET_ICMP6_FILTER_SETBLOCK(msgType, _icmp6Filter) \
{                                                            \
   ICMP6_FILTER_SETBLOCK(msgType, &_icmp6Filter);            \
}

#define CM_INET_ICMP6_FILTER_WILLPASS(msgType, _icmp6Filter) \
{                                                            \
   ICMP6_FILTER_WILLPASS(msgType, &_icmp6Filter);            \
}

#define CM_INET_ICMP6_FILTER_WILLBLOCK(msgType, _icmp6Filter) \
{                                                             \
   ICMP6_FILTER_WILLBLOCK(msgType, &_icmp6Filter);            \
}
#endif /* SUNOS || HPOS */
#endif /* IPV6_SUPPORTED */

#define cmPkCmInetIpAddr(x, mBuf)       SPkU32(x, mBuf)  /* pack IP Address */
#define cmUnpkCmInetIpAddr(x, mBuf)     SUnpkU32(x, mBuf)  /* unpacks IP Address */

#ifdef SS_VW
#define CM_COPY_VWIPADDR(vwIpAddr, addr) \
   { \
      (Void)cmMemcpy((U8 *)addr, (U8 *)&vwIpAddr, sizeof(S32)); \
   }
#endif

/* Changes for peeking into the file descriptor set */
#ifdef WIN32
#define CM_INET_FDSETINFO_RESET(_fdSetInfo) \
{ \
   _fdSetInfo->numFds = 0; \
}
#else
#define CM_INET_FDSETINFO_RESET(_fdSetInfo) \
{ \
   _fdSetInfo->arIdx = 0; \
}
#endif /* WIN32 */

/* convert a hex character in ASCII to int format */
#define CM_INET_ATOH(_intVal, _asciiVal)                                   \
{                                                                         \
   if ((_asciiVal >='a') && (_asciiVal <='f'))                            \
   {                                                                      \
     _intVal = (16 * _intVal) + (_asciiVal - 'a' +10 );                   \
   }                                                                      \
   else if ((_asciiVal >='A') && (_asciiVal <= 'F'))                      \
   {                                                                      \
     _intVal = (16 * _intVal) + (_asciiVal - 'A' +10 );                   \
   }                                                                      \
   else                                                                   \
   {                                                                      \
     _intVal = (16 * _intVal) + (_asciiVal - '0');                        \
   }                                                                      \
}

/* convert a decimal digit in ASCII to int format */
#define CM_INET_ATOI(_intVal, _asciiVal)                                  \
{                                                                         \
   _intVal = (10 * _intVal) + (_asciiVal - '0');                          \
}


#define CM_INET_GET_IPV4_ADDR_FRM_STRING(_value, _str)                    \
{                                                                         \
   U16     _hiWord;                                                       \
   U16     _loWord;                                                       \
                                                                          \
   _hiWord = 0;                                                           \
   _loWord = 0;                                                           \
   _hiWord = PutHiByte(_hiWord, (_str[0]));                               \
   _hiWord = PutLoByte(_hiWord, (_str[1]));                               \
   _loWord = PutHiByte(_loWord, (_str[2]));                               \
   _loWord = PutLoByte(_loWord, (_str[3]));                               \
   _value  = PutLoWord(_value, _loWord);                                  \
   _value  = PutHiWord(_value, _hiWord);                                  \
}

#endif /* __CMINETH__ */


/********************************************************************30**
 
         End of file:     cm_inet.h@@/main/17 - Thu Jul 28 15:46:44 2005
 
*********************************************************************31*/

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
 
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      mf   1. initial release.
1.2          ---      aa   1. Added packing and unpacking of CmInetIpAddr
1.3          ---      asa  1. Added new defines for socket options and
                              level
                           2. VxWorks support from GTP product group
1.4          ---      bbk  1. Added CM_INET_IPV4_ADDR_TBL_SZ define 
/main/5                 cvp  1. Changed the copyright headers
            001.main_5 cvp 1. Added CM_INET_OPT_BSD_COMPAT define for 
                              Linux.
                           2. Changed the CM_INET_MAX_INFO header 
                              define.
/main/7      ---       sb   1. Change for support of Raw Sockets.
                      cvp  2. Added CM_INET_OPT_MCAST_IF and 
                              CM_INET_OPT_MCAST_LOOP.
/main/7+    001.main_7 cvp  1. Changes to peek into the file descriptor
                               set.
                            2. Changed the value of CM_INET_MAX_DBUF
                              from 1000 to 15.
/main/7      ---      cvp   1. Added macro to reset file descriptor set 
                               information.
/main/8      ---      dvs  1. ClearCase release
/main/9      ---      cvp  1. Added the invalid socket define.
/main/10     ---      cvp  1. IPv6 related changes.
                           2. Changed the copyright header.
/main/10+  001.main_10 cvp 1. Changed the value of CM_INET_MAX_DBUF 
                              from 1 to 15.
/main/10+  002.main_10 mmh 1. Add the CM_INET_OPT_BROADCAST option.
                           2. Add the define CM_INET_MAX_UDPRAW_MSGSIZE.
/main/10+  003.main_10 bdu 1. Add the CM_INET_OPT_KEEPALIVE option.
/main/10+  004.main_10 bdu 1. Add more macros
/main/10+  005.main_10 bdu 1. added new IPv6 socket options
                           2. added new IPv4 socket options
                           3. added new service type RSVP
                           4. added new macros
                           5. added 2 new defines for size of ancill data
/main/10+  006.main_10 cg  1. VxWorks compilation for IPv6 Suppport 
/main/15+  002.main_15 cg  1. Correction for patch 001
/main/16     ---      pk   1. GCP 1.5 release
/main/17     ---       kp   1. Removed conditional define CM_INET_FDSET_PEEK
cm_inet_h_001.main_17 sal  1. Reusing the definition.
*********************************************************************91*/
