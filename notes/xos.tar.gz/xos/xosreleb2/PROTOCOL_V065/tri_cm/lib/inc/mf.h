/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     message functions
  
     Type:     C include file

     Desc:     Defines required by the message functions.
  
     File:     mf.h

     Sid:      mf.h@@/main/25 - Fri Feb  9 14:32:09 2001

     Prg:      bn
  
*********************************************************************21*/
  
#ifndef __MFH__
#define __MFH__


/* macros */

#define MSGRET(mcp, err) return(mfMsgRet(mcp, err, __LINE__))

/* initialize profile */
#define MFINITPROF(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   (ctlp)->numPdus = a1; \
   (ctlp)->numSdus = a2; \
   (ctlp)->pduDefs = a3; \
   (ctlp)->sduDefs = a4; \
   (ctlp)->maxRepElmt = a5; \
   (ctlp)->flags = a6; \
   (ctlp)->errMapFunc = a7; \
   ret = mfInitProf(ctlp); \
}

/* initialize message control */
#define MFINITMSGCTL(ctlp, ret, a1, a2) \
{ \
   (ctlp)->cfgp = a1; \
   (ctlp)->usrErrStP = a2; \
   ret = mfInitMsgCtl(ctlp); \
}

/* set message control */
#define MFSETMSGCTL(ctlp, a1, a2, a3, a4, a5, a6) \
{ \
   (ctlp)->validate = a1; \
   (ctlp)->encode = a2; \
   (ctlp)->decode = a3; \
   (ctlp)->mode = a4; \
   (ctlp)->swtch = a5; \
   (ctlp)->flags = a6; \
}

/* initialize sdu */
#define MFINITSDU(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   (ctlp)->smsgIdx = a1; \
   (ctlp)->dmsgIdx = a2; \
   (ctlp)->dup1 = a3; \
   (ctlp)->dup2 = a4; \
   (ctlp)->mode = a5; \
   (ctlp)->swtch = a6; \
   (ctlp)->flags = a7; \
   ret = mfInitSdu(ctlp); \
}

/* initialize pdu */
#define MFINITPDU(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   (ctlp)->smsgIdx = a1; \
   (ctlp)->dmsgIdx = a2; \
   (ctlp)->dup1 = a3; \
   (ctlp)->dup2 = a4; \
   (ctlp)->mode = a5; \
   (ctlp)->swtch = a6; \
   (ctlp)->flags = a7; \
   ret = mfInitPdu(ctlp); \
}

/* initialize element */
#define MFINITELMT(ctlp, ret, a1, a2, a3, a4, a5, a6) \
{ \
   (ctlp)->dup1 = a1; \
   (ctlp)->dup2 = a2; \
   (ctlp)->mep = a3; \
   (ctlp)->mode = a4; \
   (ctlp)->swtch = a5; \
   (ctlp)->flags = a6; \
   ret = mfInitElmt(ctlp); \
}

/* check du */
#define MFCHKDU(ctlp, ret, a1, a2, a3, a4) \
{ \
   (ctlp)->dup1 = a1; \
   (ctlp)->smsgIdx = a2; \
   (ctlp)->swtch = a3; \
   (ctlp)->flags = a4; \
   ret = mfChkDu(ctlp); \
}

/* decode pdu header */
#define MFDECPDUHDR(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   (ctlp)->mp = a1; \
   (ctlp)->dup1 = a2; \
   (ctlp)->melp1 = a3; \
   (ctlp)->validate = a4; \
   (ctlp)->decode = a5; \
   (ctlp)->swtch = a6; \
   (ctlp)->flags = a7; \
   (ctlp)->exMandCnt = (ctlp)->acMandCnt = (U8) 0; \
   (ctlp)->firstPass = (U8) TRUE; \
   ret = mfDecPduHdr(ctlp); \
}

/* decode pdu */
#define MFDECPDU(ctlp, ret, a1) \
{ \
   (ctlp)->dup1 = a1; \
   (ctlp)->exMandCnt = (ctlp)->acMandCnt = 0; \
   (ctlp)->firstPass = TRUE; \
   ret = mfDecPdu(ctlp); \
}

/* decode pdu continue */
#define MFDECPDUCONT(ctlp, ret) \
{ \
   mfDecCont = TRUE; \
   ret = mfDecPdu(ctlp); \
   mfDecCont = FALSE; \
}

/* encode pdu header */
#define MFENCPDUHDR(ctlp, ret, a1, a2, a3, a4, a5, a6, a7) \
{ \
   (ctlp)->mp = a1; \
   (ctlp)->dup1 = a2; \
   (ctlp)->melp1 = a3; \
   (ctlp)->validate = a4; \
   (ctlp)->encode = a5; \
   (ctlp)->swtch = a6; \
   (ctlp)->flags = a7; \
   ret = mfEncPduHdr(ctlp); \
}

/* encode pdu */
#define MFENCPDU(ctlp, ret, a1) \
{ \
   (ctlp)->dup1 = a1; \
   ret = mfEncPdu(ctlp); \
}

/* encode pdu continue */
#define MFENCPDUCONT(ctlp, ret) \
{ \
   ret = mfEncPdu(ctlp); \
}


/* defines */

#define MFROK             0       /* ok error return */
#define MFRFAILED         1       /* failed error return */
#define MFREOM            2       /* failed error return */

/* Fail return for Q933 specific */
/* Q933 special return value */
#define FN_MFRET          3       

/* new returns for dubugging and resource failure cases */
#define MFDEBUGERR        4       /* software error */       
#define MFRESFAILURE      5       /* resource allocation failure */       


#define MFMEI_CAUSE       0x0c    /* cause element index */
#define MFME_CAUSE        0x08    /* cause element id */
#define MFME_SHIFT        0x10    /* shift element */

/* error codes returned by message functions */

#define MFCCINVMSG      95    /* invalid message, unspecified */
#define MFCCINFOELMSSG  96    /* mandatory info element is missing */
#define MFCCNOMSGTYP    97    /* msg type is non-existent or not implemented */
#define MFCCNOINFOEL    99    /* info element non-existent or not implemented */
#define MFCCINVINFOEL   100   /* invalid info element */
#define MFCCINVMSGLEN   104   /* incorrect message length */
#define MFCCOPTELMERR   127   /* invalid optional info element */

#define MF_DECODE 0
#define MF_ENCODE 1

/* element/token present flags */

#define M_UNKNOWN         0xff   /* Unknown Message Type */
#define MI_UNKNOWN        0xff   /* Unknown Message Index */
#define ME_UNKNOWN        0xff   /* Unknown Element Id */
#define MEI_UNKNOWN       0xff   /* Unknown Element Index */


/* defines for support of message construction */

#define MF_MID_MASK        0x7f   /* message type mask */
#define MF_MAX_ENUMS       64     /* number of enumerated items */
#define MF_STKSIZE         16     /* stack size */
#define MF_MAX_CAUSEDGN    4      /* maximum cause/diagnostic */
#define MF_EID_MASK        0x7f   /* element id mask */
#define MF_MAX_ERRORS      2      /* max error count */

#define MET_SINGLE1        1      /* single octet - type 1 */
#define MET_SINGLE2        2      /* single octet - type 2 */
#define MET_VARIABLE       3      /* variable octet */
#define MET_FIXED          4      /* fixed position and length data type */
#define MET_FIXED_REM      5      /* fixed remainder of element */
#define MET_FIXED_PTR      6      /* fixed position and length pointer type */
#define MET_OPT            7      /* optional parameter (TUP) */
#define MET_HEADER_ATM     8      /* ATM message header element */
#define MET_VARIABLE_ATM   9      /* variable length ATM element */

#define MET_FIXED_PTR2     10     /* fixed position and length pointer type 2 */

/* element definition flags */

#define EF_NONLOCK         0x0001 /* use non-locking shift */
#define EF_REP             0x0002 /* element can be repeated */
#define EF_NA              0x0004 /* not applicable */
#define EF_MAND            0x0008 /* mandatory */
#define EF_UNUSED          0x0010 /* not used */
#define EF_BREAK           0x0020 /* break out of decode */
#define EF_NU              0x0040 /* network to user */
#define EF_UN              0x0080 /* user to network */
#ifdef V5X
#define EF_V5X             0x0010 /* V5.X */
#endif /* V5X */
#ifdef SS7
#define EF_LAST            0x0100 /* Elment is Last MVP element */
#define EF_VARLEN          0x0200 /* variable length element */
#define EF_FIXED           0x0300 /* fixed length element */
#define EF_BASE            0x0400 /* base of user defined flags */
#else
#define EF_BASE            0x0100 /* base of user defined flags */
#endif /* SS7 */

/* database profile flags */

#define MF_ORDERED         0x0001  /* message elements must be in order */
#define MF_IGNORE          0x0002  /* ignore invalid / unrecognized elements */
#define MF_ISUP            0x0004  /* these are ISUP elements */
#define MF_TUP             0x0008  /* these are TUP elements */
#define MF_SCCP            0x0010  /* these are SCCP elements */
#define MF_ATM             0x0020  /* these are ATM elements */

/* message definition flags */

#define MF_NA              0x0001  /* not applicable */
#define MF_NET             0x0002  /* acting as network side */
#define MF_USR             0x0004  /* acting as user size */
#define MF_BASE            0x0008  /* base of user defined flags */

#define FN_MF              (MF_BASE << 4) /* Q.933 specific flag */

#ifdef SS7
#define MF_OP              0x0000  /* optional parameters possible */
#define MF_NO_OP           0x0010  /* no optional parameters */
#endif

/* message element types */

/* token element types */

#define TET_UND            0      /* undefined */
#define TET_BITS           1      /* bit string */
#define TET_BITS_ENUM      2      /* bit string enumerated */
#define TET_U8             3      /* unsigned 8 bit */
#define TET_U8_ENUM        4      /* unsigned 8 bit enumerated */
#define TET_U16            5      /* unsigned 16 bit */
#define TET_U16_ENUM       6      /* unsigned 16 bit enumerated */
#define TET_U16_EXT        7      /* unsigned 16 bit extended */
#define TET_U32            8      /* unsigned 32 bit */
#define TET_U32_ENUM       9      /* unsigned 32 bit enumerated */
#define TET_STR            10     /* string */
#define TET_STR_IA5        11     /* string international alphabet 5 */
#define TET_U24            12     /* unsigned 24 bit */
#define TET_DATA           13     /* Data */
#define TET_STRL           14     /* extended string */
#define TET_STRS           15     /* string short */
#define TET_STRS_IA5       16     /* string international alphabet 5 */
#define TET_STRM           17     /* string medium */

/* token element definition flags */

#define TF_NEXT          0x0001   /* token marks end of octet, no  ext */
#define TF_EXT           0x0002   /* token marks end of octet with ext */
#define TF_PUSHF         0x0004   /* token is a push flag for later reference */
#define TF_PEXT          0x0008   /* token present based on last ext flag */
#define TF_PEXTN         0x0010   /* token present based on f - n skip flag */
#define TF_EREM          0x0020   /* token is uses remainder of element */
#define TF_LEN           0x0040   /* token is a length field */
#define TF_PLEN          0x0080   /* token present based on prev length field */
#define TF_DEF           0x0100   /* token has a default in database */
#define TF_UNUSED        0x0200   /* unused */
#define TF_MAND          0x0400   /* token is mandatory */
#define TF_PEXTN0        0x0800   /* token marks end of octet, maybe ext */
#define TF_MSGTYP        0x1000   /* token is a message type field */
#define TF_SI            0x2000   /* token is a message type field */
#define TF_SAVE          0x4000   /* Token value should be saved. */
#define TF_OPT1          0x8000   /* Token Option 1 */
#define TF_OPT2          0x00010000 /* Token Option 2 */
#define TF_OPT3          0x00020000 /* Token Option 2 */
#define TF_OPT4          0x00040000 /* Token Option 2 */
#define TF_OPT5          0x00080000 /* Token Option 5 */
#define TF_LAST          0x00100000 /* Last token in octet */
#define TF_BASE          0x00200000 /* base of user defined flags */
#define TF_EXTINT        0x00400000 /* Extended Integral Dependent on Ext*/
#define TF_PADDEXTN      0x00800000 /* token pres if addition extension used */

/* action for optional elements errors for SW_AUSP */

#define ACTNRELEASE      0x3      /* generate release */   
#define ACTNRELCMPL      0x4      /* generate release complete */   
#define ACTNIGNORE       0x5      /* ignore message */
#define ACTNSTATUS       0x6      /* generate status and drop message */
#define ACTNSTATPRC      0x7      /* generate status and process message */
#define ACTNPRCESS       0x8      /* process message */

#endif

  
/********************************************************************30**
  
         End of file:     mf.h@@/main/25 - Fri Feb  9 14:32:09 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
1.1.0.0         jkm     1. initial release.

1.2             jrl     1. trillium development system checkpoint (dvs)
                           at version: 1.1.0.0

1.3             ma      1. removed NOTPRSNT, PRSNT_NODEF, PRSNT_DEF
                           which are defined in gen.h

1.4             gp      1. comments added

1.5             jrl     1. split (ERRCHK || DBG4) into ERRCHK and DBG4

1.6             bn      1. added  mfDecCont = TRUE and mfDecCont = FALSE
                           in MFDECPDUCONT macro

1.7             rk      1. added TET_U24

1.8             lc      1. changed assert

1.9             bn      1. added defines for optional elements errors.

*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.10         ---  jrl   1. text changes

1.11         ---  bn    1. removed assert macro.
             ---  bn    2. added ISUP flags definition.
             ---  jrl   3. move MIN and MAX macros to envind.h

1.12         ---  bn    1. change ifdef ISUP to ifdef SI
             ---  bn    2. add MF_OP and MF_NO_OP defines

1.13         ---  rg    1. added ACTNSTATUS define for optional
                           element error for AUS

1.14         ---  fmg   1. added changes for TUP and SCCP
                        2. added ifdef SS7 to code, and removed #ifdef SI

1.15         ---  bn    1. text changes

1.16         ---  rg    1. added define for MF_ATM, MF_HEADER_ATM & 
                           MF_VARIABLE_ATM, MFCCINVMSGLEN

1.17         ---  bn    1. added define for TET_STRL.

1.18         ---  bn    1. added defines for TET_STRS and TET_STRS_IA5

1.19         ---  krp   1. added FN_MF and FN_MFRET for Q.933 operations
             ---  bn    2. added define for EF_V51.

1.20         ---  bn    1. defined new return values: MFRESFAILURE and 
                           MFDEBUGERR.

1.21         ---  bn    1. defined TET_STRM.

1.22         ---  bn    1. added flags for V5X


*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- -----------------------------------------------
1.23         in012.38 pk   1. Added token flags for ISDN.
             in014.38 pk   2. Added token flags for ISDN
             ---      sb   3. Text changes

1.24         ---      pk   1. Text changes
/main/25         ---      vb   1. Added new define MET_FIXED_PTR2 for 
                              message element type
   mf_h_001.main_25    rc  1. Sid correction
*********************************************************************91*/

