/********************************************************************10**

        (c) COPYRIGHT 1989-1992, Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.. No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as provided by the written License Agreement between
     Trillium and its Licensee.

     Trillium warrants that for a period as provided by the written
     License Agreement between Trillium and its Licensee that this
     software will perform substantially to Trillium published
     specifications at the time of shipment and that the media and
     related materials will be free from defects in materials and
     workmanship.

     Trillium makes no other warranties, either express or implied,
     including without limitation warranties of merchantability and
     fitness for a particular purpose, with regard to the software
     or any related materials.

     In no event shall Trillium be liable for any indirect, special,
     or consequential damages in connection with or arising out of
     the use or inability to use this software, whether based on
     breach of contract, tort (including negligence), product
     liability, or otherwise, and whether or not it has been advised
     of the possiblity of such damage.


                     Trillium Digital Systems, Inc.
                         Los Angeles, Ca. 90025

                          Tel: (310) 479-0500
                          Fax: (310) 575-0172

*********************************************************************11*/


/********************************************************************20**
  
     Name:     message functions - error
  
     Type:     C include file
  
     Desc:     Error defines required by message functions
  
     File:     mf_err.h
  
     Sid:      mf_err.h 1.11  -  01/25/94 16:05:22
 
     Prg:      na
  
*********************************************************************21*/
  
#ifndef __MFERRH__
#define __MFERRH__
  

/*
*  The defines declared in this file correspond to defines
*  used by the following TRILLIUM software:
*
*  part no.   description
*  -------- ----------------------------------------------
*
*/


/* defines */

#define  EMFBASE (ERRMF + 0) /* reserved */
#define  EMFXXX  (EMFBASE)   /* reserved */

/* Unique errors id's */

#define  EMF001 (ERRMF + 1)  /* fpAdd: illegal segment address */
#define  EMF002 (ERRMF + 2)  /* mfDecMsgType: illegal message index */
#define  EMF003 (ERRMF + 3)  /* mfDecMsgType: no flags defined for message */
#define  EMF004 (ERRMF + 4)  /* mfEncMsgType: illegal message index */
#define  EMF005 (ERRMF + 5)  /* mfEncMsgType: no flags defined for message */
#define  EMF006 (ERRMF + 6)  /* mfChkEnum: null enum list pointer */
#define  EMF007 (ERRMF + 7)  /* mfSkipTkns: illegal token type value */
#define  EMF008 (ERRMF + 8)  /* mfSetExt: call to SRemPstMsg not ok */
#define  EMF009 (ERRMF + 9)  /* mfSetExt: call to SAddPstMsg not ok */
#define  EMF010 (ERRMF + 10) /* mfEncU8: call to SAddPstMsg not ok */
#define  EMF011 (ERRMF + 11) /* mfEncU8: call to SAddPstMsg not ok */
#define  EMF012 (ERRMF + 12) /* mfEncU8Enum: call to SAddPstMsg not ok */
#define  EMF013 (ERRMF + 13) /* mfEncU8Enum: call to SAddPstMsg not ok */
#define  EMF014 (ERRMF + 14) /* mfEncBits: call to SAddPstMsg not ok */
#define  EMF015 (ERRMF + 15) /* mfEncBits: call to SAddPstMsg not ok */
#define  EMF016 (ERRMF + 16) /* mfEncBits: call to SAddPstMsg not ok */
#define  EMF017 (ERRMF + 17) /* mfEncBits: call to SAddPstMsg not ok   */
#define  EMF018 (ERRMF + 18) /* mfEncBits: call to SAddPstMsg not ok    */
#define  EMF019 (ERRMF + 19) /* mfEncBits: call to SAddPstMsg not ok   */
#define  EMF020 (ERRMF + 20) /* mfEncBits: illegal value of token maximum length */
#define  EMF021 (ERRMF + 21) /* mfEncU16: call to SAddPstMsg not ok   */
#define  EMF022 (ERRMF + 22) /* mfEncU16Ext: call to SAddPstMsg not ok   */
#define  EMF023 (ERRMF + 23) /* mfEncU24: call to SAddPstMsg not ok   */
#define  EMF024 (ERRMF + 24) /* mfEncU32: call to SAddPstMsg not ok   */
#define  EMF025 (ERRMF + 25) /* mfEncStr: call to SAddPstMsg not ok   */
#define  EMF026 (ERRMF + 26) /* mfInitTkns: no flags defined for token */
#define  EMF027 (ERRMF + 27) /* mfInitTkns: illegal value for pres field */
#define  EMF028 (ERRMF + 28) /* mfInitTkns: no default value defined for token */
#define  EMF029 (ERRMF + 29) /* mfInitTkns: illegal token type value */
#define  EMF030 (ERRMF + 30) /* mfDecTkns: no flags defined for token */
#define  EMF031 (ERRMF + 31) /* mfDecTkns: illegal token type value */
#define  EMF032 (ERRMF + 32) /* mfEncTkns: illegal value for pres field */
#define  EMF033 (ERRMF + 33) /* mfEncTkns: no flags defined for token */
#define  EMF034 (ERRMF + 34) /* mfEncTkns: illegal token type value*/
#define  EMF035 (ERRMF + 35) /* mfInitElmts: improper init mode for supplied parameters */
#define  EMF036 (ERRMF + 36) /* mfInitElmts: improper init mode for supplied parameters */
#define  EMF037 (ERRMF + 37) /* mfInitElmts: no destination message element list defined */
#define  EMF038 (ERRMF + 38) /* mfInitElmts: no flags defined for element */
#define  EMF039 (ERRMF + 39) /* mfInitElmts: no flags defined for element */
#define  EMF040 (ERRMF + 40) /* mfInitElmt: improper init mode for supplied parameters */
#define  EMF041 (ERRMF + 41) /* mfInitElmt: improper init mode for supplied parameters */
#define  EMF042 (ERRMF + 42) /* mfInitElmt: no flags defined for element */
#define  EMF043 (ERRMF + 43) /* mfDecElmts: no flags defined for element */
#define  EMF044 (ERRMF + 44) /* mfDecElmts: call to SFndLenMsg not ok */
#define  EMF045 (ERRMF + 45) /* mfDecElmts: (sp == msgCtlp->melp1) */
#define  EMF046 (ERRMF + 46) /* mfDecElmts: (sp == msgCtlp->melp1) */
#define  EMF047 (ERRMF + 47) /* mfEncElmts: no flags defined for element */
#define  EMF048 (ERRMF + 48) /* mfEncElmts: illegal value for pres field */
#define  EMF049 (ERRMF + 49) /* mfEncElmts: call to SAddPstMsg not ok */
#define  EMF050 (ERRMF + 50) /* mfEncElmts: call to SAddPstMsg not ok */
#define  EMF051 (ERRMF + 51) /* mfEncElmts: call to SAddPstMsg not ok */
#define  EMF052 (ERRMF + 52) /* mfEncElmts: call to SAddPstMsg not ok */
#define  EMF053 (ERRMF + 53) /* mfDecPduHdr: call to SFndLenMsg not ok */
#define  EMF054 (ERRMF + 54) /* mfEncPduHdr: call to SFndLenMsg not ok */
#define  EMF055 (ERRMF + 55) /* mfDecSS7Elmts: call to SFndLenMsg not ok */
#define  EMF056 (ERRMF + 56) /* mfEncSS7Elmts: illegal value for pres field */
#define  EMF057 (ERRMF + 57) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF058 (ERRMF + 58) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF059 (ERRMF + 59) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF060 (ERRMF + 60) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF061 (ERRMF + 61) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF062 (ERRMF + 62) /* mfEncSS7Elmts: call to SRepMsg not ok */
#define  EMF063 (ERRMF + 63) /* mfEncSS7Elmts: call to SRepMsg not ok */
#define  EMF064 (ERRMF + 64) /* mfEncSS7Elmts: call to SRepMsg not ok */
#define  EMF065 (ERRMF + 65) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF066 (ERRMF + 66) /* mfEncATMElmts: illegal message element type */
#define  EMF067 (ERRMF + 67) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF068 (ERRMF + 68) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF069 (ERRMF + 69) /* mfEncSS7Elmts: call to SAddPstMsg not ok */
#define  EMF070 (ERRMF + 70) /* mfEncSS7Elmts: call to SRepMsg not ok */
#define  EMF071 (ERRMF + 71) /* mfDecATMElmts: illegal message element type */
#define  EMF072 (ERRMF + 72) /* mfEncATMElmts: illegal value of pres field */
#define  EMF073 (ERRMF + 73) /* mfEncSS7Elmts: call to SRepMsg not ok */
#define  EMF074 (ERRMF + 74) /* mfEncStrL: call to SAddPstMsg not ok */

#endif

  
/********************************************************************30**
  
         End of file: mf_err.h 1.11  -  01/25/94 16:05:22
 
*********************************************************************31*/


/********************************************************************40**
  
   Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

 
/********************************************************************60**
  
   Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
1.1.0.0         jrl     1. initial release.

1.2             jrl     1. trillium development system checkpoint (dvs)
                           at version: 1.1.0.0

1.3             jrl     1. add error codes

*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.4          ---  jrl   1. text changes

1.5          ---  fmg   1. add error codes

1.6          ---  jrl   1. text changes

1.7          ---  rg    1. annotated error codes with function names and
                           brief descriptions.

1.8          ---  bn    1. text changes

1.9          ---  rg    1. added error codes for q.93b

1.10         ---  bn    1. changed error codes.

1.11         ---  bn    1. added error codes.

*********************************************************************81*/

