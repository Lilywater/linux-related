/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Common Distributed Fault Tolerant/High Availability
               Architecture
  
     Type:     C include file
  
     Desc:     Constant Defines and Macros required by all Distributed
               Fault Tolerance/High Availability protocol layers, protocol
               layer components and CORE components.
   
     File:     cm_ftha.h
  
     Sid:      cm_ftha.h@@/main/3 - Fri Aug 31 15:29:05 2001
   
     Prg:      ark
  
*********************************************************************21*/

#ifndef __CMFTHAH__
#define __CMFTHAH__


/* system dimensioning defines                  */
#define CMFTHA_MAX_SYS_PROCS            30      /* max nodes in system  */
#define CMFTHA_MAX_SYS_ENTS             10      /* max ents in system   */
#define CMFTHA_MAX_NODE_ENTS            5       /* max ents per node    */
#define CMFTHA_MAX_NODES_PER_ENT        10      /* max nodes per entity */     
#define CMFTHA_MAX_ENT_RSETS            30      /* max ents per rset    */

/* resource set type defines                    */
#define CMFTHA_RSET_TYPE_INVALID        0       /* invalid rset type    */
#define CMFTHA_RSET_TYPE_CRIT           1       /* critical rset        */
#define CMFTHA_RSET_TYPE_NONCRIT        2       /* non critical rset    */

/* resource set qualifier defines               */
#define CMFTHA_RSET_QUAL_TAPA           1       /* TAPA management rset */
#define CMFTHA_RSET_QUAL_NORMAL         2       /* normal resource set  */
#define CMFTHA_RSET_QUAL_DEFAULT        3       /* default resource set */
#define CMFTHA_RSET_QUAL_LYR_SPEC       20      /* layer specific quals */

#define CMFTHA_RES_RSETID               0x0     /* reserved by CORE     */
#define CMFTHA_INV_RSETID               0xffff  /* reserved by CORE     */
#define CMFTHA_RES_RSETID_RNG_START     0xfff0  /* start of reserved    */
#define CMFTHA_RES_RSETID_RNG_END       0xffff  /* end of reserved      */

/* resource set action defines                  */
#define CMFTHA_AGOACTIVE                1       /* go active action     */
#define CMFTHA_AGOSTANDBY               2       /* go standby action    */
#define CMFTHA_ASHUTDOWN                3       /* shutdown action      */
#define CMFTHA_ABNDENA                  4       /* bind & enable act    */
#define CMFTHA_AUBNDDIS                 5       /* unbind & disable act */
#define CMFTHA_AABORT                   6       /* operation abort act  */
#define CMFTHA_ASTAT                    7       /* status request act   */
#define CMFTHA_ADIS_PEERSAP             8       /* disable peer SAP act */
#define CMFTHA_AWARMSTART               9       /* warm start action    */
#define CMFTHA_ASYNCHRONIZE             10      /* peer sync action     */
#define CMFTHA_APEERPING                11      /* peer ping action     */
/* Added for rolling upgrade */
#define CMFTHA_AGETVER                  12      /* get ver action       */
#define CMFTHA_ASETVER                  13      /* set ver action       */

/* Subactions for AGETVER and ASETVER for rolling upgrade feature */
#define CMFTHA_SACORE                   1       /* core comp subaction  */
#define CMFTHA_SALAYER                  2       /* prot layer subaction */

/* Defines for CmPFthaDistType.dist */
#define CMFTHA_DIST_STATIC             0x01     /* Static distribution  */
#define CMFTHA_DIST_DYNAMIC            0x02     /* Dynamic distribution */

/* Defines for CmPFthaDistType.qual */
#define CMFTHA_QUAL_UNUSED             0x01     /* qualifier unused     */
#define CMFTHA_QUAL_DEFAULT            0x02     /* default              */
#define CMFTHA_QUAL_SAMEPROC           0x03     /* same proc distibtion */
 
/* Defines for CmPFthaInterface (BitMask) */
#define CMFTHA_IF_UPPER                0x01     /* Upper interface      */
#define CMFTHA_IF_LOWER                0x02     /* Lower interface      */
#define CMFTHA_IF_BOTH (CMFTHA_IF_UPPER | CMFTHA_IF_LOWER)/* Both if's  */

/* common packing and unpacking macros          */
#define cmPkFthaRsetId(x, mBuf)                 cmPkProcId(x, mBuf)
#define cmPkFthaMasterId(x, mBuf)               SPkU8(x, mBuf)
#define cmPkFthaSeqNum(x, mBuf)                 SPkU16(x, mBuf)
#define cmPkFthaRsetStaType(x, mBuf)            SPkU8(x, mBuf)
#define cmPkFthaInterface(x, mBuf)              SPkU8(x, mBuf)
#define cmUnpkFthaInterface(x, mBuf)            SUnpkU8(x, mBuf)

#define cmUnpkFthaRsetId(x, mBuf)               cmUnpkProcId(x, mBuf)
#define cmUnpkFthaMasterId(x, mBuf)             SUnpkU8(x, mBuf)
#define cmUnpkFthaSeqNum(x, mBuf)               SUnpkU16(x, mBuf)
#define cmUnpkFthaRsetStaType(x, mBuf)          SUnpkU8(x, mBuf)

/* common DFTHA error codes                     */
#define ECMFTHABASE             0               /* error code base val  */
#define ECMFTHAXXX              (ECMFTHABASE)   /* dummy error code val */

#endif /* __CMFTHAH__ */

/********************************************************************30**
  
         End of file:     cm_ftha.h@@/main/3 - Fri Aug 31 15:29:05 2001

*********************************************************************31*/
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ark  1. Initial release

/main/2      ---      cp   1. Added interface, distype defines and 
                              pk/unpk prototypes.
             ---      ark  2. Moved read/write lock defines to cm_rwlck.h
/main/3      ---      ns   1. Changes for rolling upgrade feature. Added new
                              actions and subaction defines for get and set
                              interface version

*********************************************************************91*/
