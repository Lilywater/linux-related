/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
        Name:     Common PSF file (fault tolerance)
    
        Type:     C include file
  
        Desc:     This file contains common PSF defines. At 
                  present majority of defines are valid on PSF's
                  management interface. This file should be included in Update
                  module of all layers which are implementing fault tolerance. 
 
        File:     cm_pftha.h

        Sid:      cm_pftha.h@@/main/4 - Thu Oct 12 09:22:37 2000
  
        Prg:      ash
  
*********************************************************************21*/
 
#ifndef __CMPFTHAH__
#define __CMPFTHAH__

/* protocol state defines */

#define ACTIVE                1       /* active state of the protocol layer */
#define STANDBY               2       /* standby state of the protocol layer */
/* cm_pftha_h_001.main_4 - Removed warning - Comment not completed */
#define OOS                   3       /* out of service state of the */

/* request type */

#define CMPFTHA_UPD_REQ        1   /* update request type */
#define CMPFTHA_DELETE_REQ     2   /* delete request type */
#define CMPFTHA_CREATE_REQ     3   /* create request type */
#define CMPFTHA_CTL_REQ        4   /* Control request type */

/* defines for updState in peer sap control block */
#define CMPFTHA_IDLE           1  /* update SAP is in idle state */
#define CMPFTHA_WRMSTRT        2  /* update SAP is in warmstart state */
#define CMPFTHA_SYNC           3  /* update SAP is in synchronization state */
#define CMPFTHA_WRMSTRT_WAIT   4  /* waiting for warm start data confirm */
#define CMPFTHA_SYNC_WAIT      5  /* waiting for sync data confirm  */

/* peer sap state */

#define CMPFTHA_BND              1         /* bound state */
#define CMPFTHA_UBND             2         /* unbound state */

/* timers */

#define CMPFTHA_TMR_UPD          0x01          /* update timer */

/* more field in update message header */
#define CMPFTHA_MORE_UPD_REQ     1  /* more update requests to follow */
#define CMPFTHA_NO_MORE_UPD_REQ  2  /* no more update requests */

/* type of update message */
#define CMPFTHA_RUN_TIME_UPD     1  /* runtime state update request */
#define CMPFTHA_WARM_START_UPD   2  /* warmstart update request */
#define CMPFTHA_CON_SWTCH_UPD    3  /* controlled switchover update request */

/* unsolicited status indications events */

#define CMPFTHA_SEQERR           1  /* sequence error (standby) */
#define CMPFTHA_MEM_FAILURE      2  /* memory allocation failure (active) */
#define CMPFTHA_UPDMSG_ERR       3  /* update message decode error (standby) */
#define CMPFTHA_GENERAL_ERR      4  /* general error */

#define CMPFTHA_USTA_EP_MAX     16  /* length of event parameter array */

/* status in DatCfm primitive */
#define CMPFTHA_OK               0  /* ok status */ 
#define CMPFTHA_NOK              1  /* not ok status */

/* Offset of "more" byte in the header of update message */
#define CMPFTHA_MORE_OFFSET     (3*sizeof(S16) + sizeof(U8) + sizeof(U16)) 

/* define for the size of systemId structure packed in update message */
#define CMPFTHA_SIZE_SYSTEMID (3 * sizeof(S16))

/* error logging macro */

#define CMPFTHALOGERRORPK(errCls, errCode, errVal, errDesc) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, \
                   __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

#define CMPFTHALOGERRORUNPK(errCls, errCode, errVal, errDesc) \
        SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, \
                   __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

/* common error codes */

#define ECMPFTHABASE     0           /* reserved */
#define ECMPFTHAXXX      (ECMPFTHABASE)  /* reserved */

#define   ECMPFTHA001      (ECMPFTHABASE +    1)    /*       cm_pftha.c: 202 */
#define   ECMPFTHA002      (ECMPFTHABASE +    2)    /*       cm_pftha.c: 203 */
#define   ECMPFTHA003      (ECMPFTHABASE +    3)    /*       cm_pftha.c: 204 */
#define   ECMPFTHA004      (ECMPFTHABASE +    4)    /*       cm_pftha.c: 205 */
#define   ECMPFTHA005      (ECMPFTHABASE +    5)    /*       cm_pftha.c: 210 */
#define   ECMPFTHA006      (ECMPFTHABASE +    6)    /*       cm_pftha.c: 211 */
#define   ECMPFTHA007      (ECMPFTHABASE +    7)    /*       cm_pftha.c: 212 */
#define   ECMPFTHA008      (ECMPFTHABASE +    8)    /*       cm_pftha.c: 213 */
#define   ECMPFTHA009      (ECMPFTHABASE +    9)    /*       cm_pftha.c: 214 */
#define   ECMPFTHA010      (ECMPFTHABASE +   10)    /*       cm_pftha.c: 215 */
#define   ECMPFTHA011      (ECMPFTHABASE +   11)    /*       cm_pftha.c: 216 */
#define   ECMPFTHA012      (ECMPFTHABASE +   12)    /*       cm_pftha.c: 217 */
#define   ECMPFTHA013      (ECMPFTHABASE +   13)    /*       cm_pftha.c: 218 */
#define   ECMPFTHA014      (ECMPFTHABASE +   14)    /*       cm_pftha.c: 223 */
#define   ECMPFTHA015      (ECMPFTHABASE +   15)    /*       cm_pftha.c: 230 */
#define   ECMPFTHA016      (ECMPFTHABASE +   16)    /*       cm_pftha.c: 274 */
#define   ECMPFTHA017      (ECMPFTHABASE +   17)    /*       cm_pftha.c: 277 */
#define   ECMPFTHA018      (ECMPFTHABASE +   18)    /*       cm_pftha.c: 321 */
#define   ECMPFTHA019      (ECMPFTHABASE +   19)    /*       cm_pftha.c: 322 */
#define   ECMPFTHA020      (ECMPFTHABASE +   20)    /*       cm_pftha.c: 323 */
#define   ECMPFTHA021      (ECMPFTHABASE +   21)    /*       cm_pftha.c: 324 */
#define   ECMPFTHA022      (ECMPFTHABASE +   22)    /*       cm_pftha.c: 327 */
#define   ECMPFTHA023      (ECMPFTHABASE +   23)    /*       cm_pftha.c: 371 */
#define   ECMPFTHA024      (ECMPFTHABASE +   24)    /*       cm_pftha.c: 373 */
#define   ECMPFTHA025      (ECMPFTHABASE +   25)    /*       cm_pftha.c: 417 */
#define   ECMPFTHA026      (ECMPFTHABASE +   26)    /*       cm_pftha.c: 464 */
#define   ECMPFTHA027      (ECMPFTHABASE +   27)    /*       cm_pftha.c: 468 */
#define   ECMPFTHA028      (ECMPFTHABASE +   28)    /*       cm_pftha.c: 474 */
#define   ECMPFTHA029      (ECMPFTHABASE +   29)    /*       cm_pftha.c: 482 */
#define   ECMPFTHA030      (ECMPFTHABASE +   30)    /*       cm_pftha.c: 485 */
#define   ECMPFTHA031      (ECMPFTHABASE +   31)    /*       cm_pftha.c: 533 */
#define   ECMPFTHA032      (ECMPFTHABASE +   32)    /*       cm_pftha.c: 535 */
#define   ECMPFTHA033      (ECMPFTHABASE +   33)    /*       cm_pftha.c: 538 */
#define   ECMPFTHA034      (ECMPFTHABASE +   34)    /*       cm_pftha.c: 584 */
#define   ECMPFTHA035      (ECMPFTHABASE +   35)    /*       cm_pftha.c: 589 */
#define   ECMPFTHA036      (ECMPFTHABASE +   36)    /*       cm_pftha.c: 590 */
#define   ECMPFTHA037      (ECMPFTHABASE +   37)    /*       cm_pftha.c: 591 */
#define   ECMPFTHA038      (ECMPFTHABASE +   38)    /*       cm_pftha.c: 592 */
#define   ECMPFTHA039      (ECMPFTHABASE +   39)    /*       cm_pftha.c: 597 */
#define   ECMPFTHA040      (ECMPFTHABASE +   40)    /*       cm_pftha.c: 598 */
#define   ECMPFTHA041      (ECMPFTHABASE +   41)    /*       cm_pftha.c: 599 */
#define   ECMPFTHA042      (ECMPFTHABASE +   42)    /*       cm_pftha.c: 600 */
#define   ECMPFTHA043      (ECMPFTHABASE +   43)    /*       cm_pftha.c: 601 */
#define   ECMPFTHA044      (ECMPFTHABASE +   44)    /*       cm_pftha.c: 602 */
#define   ECMPFTHA045      (ECMPFTHABASE +   45)    /*       cm_pftha.c: 603 */
#define   ECMPFTHA046      (ECMPFTHABASE +   46)    /*       cm_pftha.c: 604 */
#define   ECMPFTHA047      (ECMPFTHABASE +   47)    /*       cm_pftha.c: 605 */
#define   ECMPFTHA048      (ECMPFTHABASE +   48)    /*       cm_pftha.c: 610 */
#define   ECMPFTHA049      (ECMPFTHABASE +   49)    /*       cm_pftha.c: 660 */
#define   ECMPFTHA050      (ECMPFTHABASE +   50)    /*       cm_pftha.c: 662 */
#define   ECMPFTHA051      (ECMPFTHABASE +   51)    /*       cm_pftha.c: 707 */
#define   ECMPFTHA052      (ECMPFTHABASE +   52)    /*       cm_pftha.c: 708 */
#define   ECMPFTHA053      (ECMPFTHABASE +   53)    /*       cm_pftha.c: 709 */
#define   ECMPFTHA054      (ECMPFTHABASE +   54)    /*       cm_pftha.c: 710 */
#define   ECMPFTHA055      (ECMPFTHABASE +   55)    /*       cm_pftha.c: 711 */
#define   ECMPFTHA056      (ECMPFTHABASE +   56)    /*       cm_pftha.c: 757 */
#define   ECMPFTHA057      (ECMPFTHABASE +   57)    /*       cm_pftha.c: 759 */
#define   ECMPFTHA058      (ECMPFTHABASE +   58)    /*       cm_pftha.c: 804 */
#define   ECMPFTHA059      (ECMPFTHABASE +   59)    /*       cm_pftha.c: 849 */
#define   ECMPFTHA060      (ECMPFTHABASE +   60)    /*       cm_pftha.c: 851 */
#define   ECMPFTHA061      (ECMPFTHABASE +   61)    /*       cm_pftha.c: 856 */
#define   ECMPFTHA062      (ECMPFTHABASE +   62)    /*       cm_pftha.c: 860 */
#define   ECMPFTHA063      (ECMPFTHABASE +   63)    /*       cm_pftha.c: 866 */
#define   ECMPFTHA064      (ECMPFTHABASE +   64)    /*       cm_pftha.c: 919 */
#define   ECMPFTHA065      (ECMPFTHABASE +   65)    /*       cm_pftha.c: 921 */
#define   ECMPFTHA066      (ECMPFTHABASE +   66)    /*       cm_pftha.c: 924 */
#define   ECMPFTHA067      (ECMPFTHABASE +   67)    /*       cm_pftha.c: 981 */
#define   ECMPFTHA068      (ECMPFTHABASE +   68)    /*       cm_pftha.c: 992 */

#endif /* __CMPFTHAH__ */
  
/********************************************************************30**
  
         End of file:     cm_pftha.h@@/main/4 - Thu Oct 12 09:22:37 2000
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ash  1. initial release.
                      pm   2. added defines for updState.
                      ash  3. defines added 
                      pm   4. added define for CMPFTHA_MORE_OFFSET.
                      ash  5. error codes changed 
                           6. Added CMPFTHA_SIZE_SYSTEMID
1.2          ---      rs   1. Added define CMPFTHA_CTL_REQ
             /main/4                 cp   1. Rereleasing the same file. (To avoid usage of the
                              cm_pftha.* released with LDF-MTP3) 
/main/4  cm_pftha_h_001.main_4 dv 1. Removed warning - Comment not completed
*********************************************************************91*/


