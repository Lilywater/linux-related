/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     common hash functions
  
     Type:     C include file
  
     Desc:     Defines required by common functions.
               (Newer version of functions in cm_bdy1)
  
     File:     cm_hash.h

     Sid:      cm_hash.h@@/main/12 - Fri Jun  7 14:16:18 2002
  
     Prg:      rg
  
*********************************************************************21*/
  
#ifndef __CMHASHH__
#define __CMHASHH__ 

  
/* defines */

/* key types */

#define CM_HASH_KEYTYPE_DEF         0  /* default key type - selects 
                                          Trillium supplied default function */
#define CM_HASH_KEYTYPE_MULT24      1  /* key type which uses multiplication 
                                          method to compute hash list index 
                                          - function supplied by Trillium */
#define CM_HASH_KEYTYPE_DIRIDX      2  /* direct indexing of hash tables */

#define CM_HASH_KEYTYPE_STR         3  /* Hash Function for Strings */

#define CM_HASH_KEYTYPE_U32MOD      4  /* Mods the key with number of bins
                                        * useful if key is U32 numeric */

#define CM_HASH_KEYTYPE_CONID       5  /* Uses diff computation for keylen
                                         < U32. Ideal fo conId type params */

#define CM_HASH_KEYTYPE_BCD8        6  /* Converts the 8 BCD coded octets 
                                        * into 2 U32s and then adds 2 
                                        * U32s to get one U32. Then applies the 
                                        * U32Mod technique to get the index */
#define CM_HASH_KEYTYPE_ANY         7  /* Converts a variable length key into
                                        * a U32 which is then mapped to number
                                        * of hash bins
                                        */

/* Constants */
#define CM_STR_HASHFUNC_CONSTANT    31 /* Constant for CM_HASH_KEYTYPE_STR */

/* CONSTANTS for CmHashFuncConId */
#define CM_HASHKEYLEN_U32              4  /* size of U32 */
#define CM_HASHKEYLEN_U16              2  /* size of U16 */
#define CM_HASHKEYLEN_U8               1  /* size of U8 */

/* query types */

#define CM_HASH_QUERYTYPE_BINS     1  /* number of bins */
#define CM_HASH_QUERYTYPE_BINSIZE  2  /* storage for each bin */
#define CM_HASH_QUERYTYPE_ENTRIES  3  /* current number of entries */
#define CM_HASH_QUERYTYPE_OFFSET   4  /* offset of CmHashListEnt in entries */
#define CM_HASH_QUERYTYPE_DUPFLG   5  /* allow duplicate keys */
#define CM_HASH_QUERYTYPE_KEYTYPE  6  /* key type for selecting hash functions */

#define CM_HASH_VALUE(entry)       (entry)->hashVal  /* computed hash value */
#define CM_HASH_SIZE(tbl)          (tbl)->nmbBins    /* hash table size */

#define CM_HASH_NMBENT(tbl)        (tbl)->nmbEnt     /* number of entries in
                                                      * table
                                                      */

#define CM_HASH_DUPFLG(tbl)        (tbl)->dupFlg     /* allow duplicate keys */

#define CM_HASH_OFFSET(tbl)        (tbl)->offset     /* offset of CmHashListEnt
                                                      * structure in hash list
                                                      * entry
                                                      */

#define CM_HASH_KEYTYPE(tbl)       (tbl)->keyType    /* key type for selecting
                                                      * hash function
                                                      */

#define CM_HASH_BINSIZE       sizeof(CmListEnt) /* size of a single bin
                                                 */
/* bin bit mask */

#define CM_HASH_NOBITMASK          0x8000  /* illegal bin bit mask */

/* constant multiplier for multiplication method of computing hash index */
#define CM_HASH_MULT24_CONST       10368890   /* when key is of max 24 bits */

/* bit position where the hash index is extracted in multiplication method */
#define CM_HASH_MULT24_BITPOS        24       /* when key is of max 24 bits */

/*
 *  delete an entry from the hash table with open addressing
 */
#define cmHashListOADelete(hashListCp, entry) cmHashListDelete(hashListCp, (PTR)entry)


/* 
 * CM_HASH_MIX -- mix 3 32-bit values reversibly.
 * For every delta with one or two bits set, and the deltas of all three
 * high bits or all three low bits, whether the original value of a,b,c
 * is almost all zero or is uniformly distributed,
 * If CM_HASH_MIX() is run forward or backward, at least 32 bits in a,b,c
 * have at least 1/4 probability of changing.
 * If CM_HASH_MIX() is run forward, every bit of c will change between 1/3 and
 * 2/3 of the time.  (Well, 22/100 and 78/100 for some 2-bit deltas.)
 * CM_HASH_MIX() was built out of 36 single-cycle latency instructions in a 
 * structure that could supported 2x parallelism, like so:
 *     a -= b; 
 *     a -= c; x = (c>>13);
 *     b -= c; a ^= x;
 *     b -= a; x = (a<<8);
 *     c -= a; b ^= x;
 *     c -= b; x = (b>>13);
 *     ...
 */
#define CM_HASH_MIX(a,b,c) \
{ \
  a -= b; a -= c; a ^= (c>>13); \
  b -= c; b -= a; b ^= (a<<8);  \
  c -= a; c -= b; c ^= (b>>13); \
  a -= b; a -= c; a ^= (c>>12); \
  b -= c; b -= a; b ^= (a<<16); \
  c -= a; c -= b; c ^= (b>>5);  \
  a -= b; a -= c; a ^= (c>>3);  \
  b -= c; b -= a; b ^= (a<<10); \
  c -= a; c -= b; c ^= (b>>15); \
}

#endif /* __CMHASHH__ */

  
/********************************************************************30**
  
         End of file:     cm_hash.h@@/main/12 - Fri Jun  7 14:16:18 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  rg    1. initial release.

1.2          ---  bw    1. add define's CM_HASH_VALUE & CM_HASH_SIZE
             ---  bw    2. add support for hash table with open addressing
             ---  vk    3. change copyright header

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.3          ---      ak   1. added macros for all queries in
                             cmHashListQuery
             ---      sg   2. changed CM_HASH_BINSIZE definition  
             ---      rg   3. add define for CM_HASH_NOBITMASK.
             ---      rg   4. removed define for CM_HASH_SIZE.
             ---      kvm  5. added defines CM_HASH_KEYTYPE_MULT24,    
                                           CM_HASH_MULT24_CONST,      
                                           CM_HASH_MULT24_BITPOS,      
                                       and CM_HASH_KEYTYPE_DIRIDX.

1.4          ---      bbk  1. Changed copyright header date.

1.5          ---      tej  1. Changed copyright header date.
1.6          ---      bbk  1. Added CM_HASH_KEYTYPE_STR, 
                              CM_STR_HASHFUNC_CONSTANT
/main/8      ---      dw   1. Added CM_HASH_KEYTYPE_U32MOD
/main/9      ---      cvp  1. Changed the copyright header date.
/main/10     ---      an   1. Added the constants for new hash function
                              CM_HASH_KEYTYPE_CONID
/main/11     ---      ck   1. Added CM_HASH_KEYTYPE_BCD8
/main/12     ---      ds   1. Added define for CM_HASH_KEYTYPE_ANY and defined
                              macro CM_HASH_MIX
*********************************************************************91*/
