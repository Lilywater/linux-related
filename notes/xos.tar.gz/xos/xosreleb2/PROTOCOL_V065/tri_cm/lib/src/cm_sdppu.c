/********************************************************************16**

        (c) COPYRIGHT 1989-2002 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SDP common module
  
     Type:     C file
  
     Desc:     This file contains the packing/unpacking functions for
               common SDP types

     File:     cm_sdppu.c

     Sid:      cm_sdppu.c@@/main/5 - Thu Jul 22 12:21:20 2004
  
     Prg:      rrp
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#ifdef LCCMSDP            

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_tkns.h"       /* common tokens */

#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport */
#include "cm_mblk.h"       /* common mblk alloc */
#include "cm_sdp.h"        /* common sdp defines */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_tkns.x"       /* common tokens */

#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* common mem block alloc */
#include "cm_sdp.x"        /* common sdp types */

#ifndef CM_SDP_V_2
#define CMMEMCHKUNPK(func, val, mBuf, ptr) \
   { \
      S16 ret; \
      if ((ret = func(val, mBuf, ptr)) != ROK) \
         RETVALUE(ret); \
   }

#define CMGETMBLK(ptr, size, pptr) \
   { \
      S16 ret; \
      ret = cmGetMem( ptr, size, pptr); \
      if (ret != ROK) \
      { \
          RETVALUE(RFAILED); \
      } \
   }

/*
*
*       Fun:   cmPkCmSdpOrig
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpOrig
(
CmSdpOrig                *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpOrig (pkParam, mBuf)
CmSdpOrig                *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpOrig)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknStrOSXL, &pkParam->sdpAddr, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->addrType, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->netType, mBuf);
      CMCHKPK(cmPkTknU32, &pkParam->sessVer, mBuf);
      CMCHKPK(cmPkTknU32, &pkParam->sessId, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->usrName, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpOrig */

/*
*
*       Fun:   cmPkCmSdpConn
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpConn
(
CmSdpConn                *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpConn (pkParam, mBuf)
CmSdpConn                *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpConn)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknStrOSXL, &pkParam->sdpAddr, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->addrType, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->netType, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpConn */

/*
*
*       Fun:   cmPkCmSdpConnSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpConnSet
(
CmSdpConnSet             *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpConnSet (pkParam, mBuf)
CmSdpConnSet             *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpConnSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpConn, &pkParam->infoSet[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpConnSet */

/*
*
*       Fun:   cmPkCmSdpTypedTime
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpTypedTime
(
CmSdpTypedTime           *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpTypedTime (pkParam, mBuf)
CmSdpTypedTime           *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpTypedTime)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknU8, &pkParam->unit, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->val, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpTypedTime */

/*
*
*       Fun:   cmPkCmSdpZoneAdj
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpZoneAdj
(
CmSdpZoneAdj             *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpZoneAdj (pkParam, mBuf)
CmSdpZoneAdj             *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpZoneAdj)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpTypedTime, &pkParam->typedTime, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->time, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpZoneAdj */

/*
*
*       Fun:   cmPkCmSdpTypedTimeSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpTypedTimeSet
(
CmSdpTypedTimeSet        *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpTypedTimeSet (pkParam, mBuf)
CmSdpTypedTimeSet        *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpTypedTimeSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpTypedTime, &pkParam->typedTime[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpTypedTimeSet */

/*
*
*       Fun:   cmPkCmSdpRepField
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpRepField
(
CmSdpRepField            *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpRepField (pkParam, mBuf)
CmSdpRepField            *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpRepField)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpTypedTimeSet, &pkParam->offsetList, mBuf);
      CMCHKPK(cmPkCmSdpTypedTime, &pkParam->actvDur, mBuf);
      CMCHKPK(cmPkCmSdpTypedTime, &pkParam->repInterval, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpRepField */

/*
*
*       Fun:   cmPkCmSdpRepFieldSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpRepFieldSet
(
CmSdpRepFieldSet         *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpRepFieldSet (pkParam, mBuf)
CmSdpRepFieldSet         *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpRepFieldSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpRepField, &pkParam->repField[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpRepFieldSet */

/*
*
*       Fun:   cmPkCmSdpZoneAdjSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpZoneAdjSet
(
CmSdpZoneAdjSet          *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpZoneAdjSet (pkParam, mBuf)
CmSdpZoneAdjSet          *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpZoneAdjSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j<pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpZoneAdj, &pkParam->zoneAdj[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpZoneAdjSet */

/*
*
*       Fun:   cmPkCmSdpOpTime
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpOpTime
(
CmSdpOpTime              *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpOpTime (pkParam, mBuf)
CmSdpOpTime              *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpOpTime)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpRepFieldSet, &pkParam->repFieldSet, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->stopTime, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->startTime, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpOpTime */

/*
*
*       Fun:   cmPkCmSdpOpTimeSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpOpTimeSet
(
CmSdpOpTimeSet           *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpOpTimeSet (pkParam, mBuf)
CmSdpOpTimeSet           *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpOpTimeSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpOpTime, pkParam->sdpOpTime[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpOpTimeSet */

/*
*
*       Fun:   cmPkCmSdpTime
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpTime
(
CmSdpTime                *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpTime (pkParam, mBuf)
CmSdpTime                *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpTime)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpZoneAdjSet, &pkParam->zoneAdjSet, mBuf);
      CMCHKPK(cmPkCmSdpOpTimeSet, &pkParam->sdpOpTimeSet, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpTime */

/*
*
*       Fun:   cmPkCmSdpKeyType
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpKeyType
(
CmSdpKeyType             *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpKeyType (pkParam, mBuf)
CmSdpKeyType             *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpKeyType)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknStrOSXL, &pkParam->key_data, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->keyType, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpKeyType */

/*
*
*       Fun:   cmPkCmSdpAttr
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpAttr
(
CmSdpAttr                *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpAttr (pkParam, mBuf)
CmSdpAttr                *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpAttr)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknStr32, &pkParam->attrVal, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->attrType, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpAttr */



/*
*
*       Fun:   cmPkCmSdpAttrSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpAttrSet
(
CmSdpAttrSet             *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpAttrSet (pkParam, mBuf)
CmSdpAttrSet             *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpAttrSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpAttr, &pkParam->attr[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpAttrSet */

/*
*
*       Fun:   cmPkCmSdpEmailSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpEmailSet
(
CmSdpEmailSet            *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpEmailSet (pkParam, mBuf)
CmSdpEmailSet            *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpEmailSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkTknStrOSXL, &pkParam->email[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpEmailSet */

/*
*
*       Fun:   cmPkCmSdpPhoneSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpPhoneSet
(
CmSdpPhoneSet            *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpPhoneSet (pkParam, mBuf)
CmSdpPhoneSet            *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpPhoneSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkTknStrOSXL, &pkParam->phone[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpPhoneSet */

/*
*
*       Fun:   cmPkCmSdpBw
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpBw
(
CmSdpBw                  *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpBw (pkParam, mBuf)
CmSdpBw                  *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpBw)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkTknU32, &pkParam->bWidth, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->bwType, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpBw */

/*
*
*       Fun:   cmPkCmSdpBwSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpBwSet
(
CmSdpBwSet               *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpBwSet (pkParam, mBuf)
CmSdpBwSet               *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpBwSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpBw, &pkParam->sdpBw[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpBwSet */


/*
*
*       Fun:   cmPkCmSdpFmtSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpFmtSet
(
CmSdpFmtSet              *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpFmtSet (pkParam, mBuf)
CmSdpFmtSet              *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpFmtSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j<pkParam->numComp.val; j++)
         CMCHKPK(cmPkTknStrOSXL, &pkParam->fmtInfo[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpFmtSet */

/*
*
*       Fun:   cmPkCmSdpMediaField
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpMediaField
(
CmSdpMediaField          *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpMediaField (pkParam, mBuf)
CmSdpMediaField          *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpMediaField)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpFmtSet, &pkParam->fmtSet, mBuf);
      CMCHKPK(cmPkTknStr32, &pkParam->proto, mBuf);
      CMCHKPK(cmPkTknU16, &pkParam->portInt, mBuf);
      CMCHKPK(cmPkTknU16, &pkParam->port, mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->mediaType, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpMediaField */

/*
*
*       Fun:   cmPkCmSdpMediaDesc
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpMediaDesc
(
CmSdpMediaDesc           *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpMediaDesc (pkParam, mBuf)
CmSdpMediaDesc           *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpMediaDesc)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpAttrSet, &pkParam->attrSet, mBuf);
      CMCHKPK(cmPkCmSdpKeyType, &pkParam->keyType, mBuf);
      CMCHKPK(cmPkCmSdpBwSet, &pkParam->bwSet, mBuf);
      CMCHKPK(cmPkCmSdpConnSet, &pkParam->connSet, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->info, mBuf);
      CMCHKPK(cmPkCmSdpMediaField, &pkParam->field, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpMediaDesc */

/*
*
*       Fun:   cmPkCmSdpMediaDescSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCmSdpMediaDescSet
(
CmSdpMediaDescSet        *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkCmSdpMediaDescSet (pkParam, mBuf)
CmSdpMediaDescSet        *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpMediaDescSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j<pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpMediaDesc, pkParam->mediaDesc[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpMediaDescSet */

/*
*
*       Fun:   cmPkCmSdpInfo
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpInfo
(
CmSdpInfo                *pkParam,     /**/
Buffer                   *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmPkCmSdpInfo (pkParam, mBuf)
CmSdpInfo                *pkParam;     /**/
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkCmSdpInfo)

   if (pkParam->pres.pres == TRUE)
   {
      CMCHKPK(cmPkCmSdpMediaDescSet, &pkParam->mediaDescSet, mBuf);
      CMCHKPK(cmPkCmSdpAttrSet, &pkParam->attrSet, mBuf);
      CMCHKPK(cmPkCmSdpKeyType, &pkParam->keyType, mBuf);
      CMCHKPK(cmPkCmSdpTime, &pkParam->sdpTime, mBuf);
      CMCHKPK(cmPkCmSdpBwSet, &pkParam->bwSet, mBuf);
      CMCHKPK(cmPkCmSdpConn, &pkParam->conn, mBuf);
      CMCHKPK(cmPkCmSdpPhoneSet, &pkParam->phoneSet, mBuf);
      CMCHKPK(cmPkCmSdpEmailSet, &pkParam->emailSet, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->uri, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->info, mBuf);
      CMCHKPK(cmPkTknStrOSXL, &pkParam->sessName, mBuf);
      CMCHKPK(cmPkCmSdpOrig, &pkParam->orig, mBuf);
      CMCHKPK(cmPkTknU16, &pkParam->ver, mBuf);
   }
   CMCHKPK(cmPkTknU8, &pkParam->pres, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpInfo */

/*
*
*       Fun:   cmPkCmSdpInfoSet
*
*       Desc:  This function packs the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpInfoSet
(
CmSdpInfoSet             *pkParam,     /**/
CmIntfVer                intfVer,      /* 001.main_4 : addition */
Buffer                   *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmPkCmSdpInfoSet (pkParam, intfVer, mBuf)
CmSdpInfoSet             *pkParam;     /**/
CmIntfVer                intfVer;      /* 001.main_4 : addition */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 j;
   TRC2(cmPkCmSdpInfoSet)

   if (pkParam->numComp.pres == TRUE)
   {
      for(j=0; j < pkParam->numComp.val; j++)
         CMCHKPK(cmPkCmSdpInfo, pkParam->info[j], mBuf);
   }
   CMCHKPK(cmPkTknU16, &pkParam->numComp, mBuf);

   RETVALUE(ROK);
}   /* cmPkCmSdpInfoSet */

/**************************************************************************
                Unpacking Functions  
**************************************************************************/

/*
*
*       Fun:   cmUnpkCmSdpOrig
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpOrig
(
CmSdpOrig                *unpkParam,   /**/
Buffer                   *mBuf,        /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpOrig (unpkParam, mBuf, ptr)
CmSdpOrig                *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr;
#endif
{
   TRC2(cmUnpkCmSdpOrig)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->usrName, mBuf, ptr);
      CMCHKUNPK(cmUnpkTknU32, &unpkParam->sessId, mBuf);
      CMCHKUNPK(cmUnpkTknU32, &unpkParam->sessVer, mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->netType, mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->addrType, mBuf);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->sdpAddr, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpOrig */

/*
*
*       Fun:   cmUnpkCmSdpConn
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpConn
(
CmSdpConn                *unpkParam,   /**/
Buffer                   *mBuf,        /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpConn (unpkParam, mBuf, ptr)
CmSdpConn                *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpConn)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->netType, mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->addrType, mBuf);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->sdpAddr, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpConn */

/*
*
*       Fun:   cmUnpkCmSdpConnSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpConnSet
(
CmSdpConnSet             *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpConnSet (unpkParam, mBuf, ptr)
CmSdpConnSet             *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpConnSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpConn, &unpkParam->infoSet[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpConnSet */

/*
*
*       Fun:   cmUnpkCmSdpTypedTime
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpTypedTime
(
CmSdpTypedTime           *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr 
)
#else
PRIVATE S16 cmUnpkCmSdpTypedTime (unpkParam, mBuf, ptr)
CmSdpTypedTime           *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpTypedTime)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->val, mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->unit, mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpTypedTime */

/*
*
*       Fun:   cmUnpkCmSdpZoneAdj
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpZoneAdj
(
CmSdpZoneAdj             *unpkParam,   /**/
Buffer                   *mBuf,        /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpZoneAdj (unpkParam, mBuf, ptr)
CmSdpZoneAdj             *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpZoneAdj)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->time, mBuf);
      CMMEMCHKUNPK(cmUnpkCmSdpTypedTime, &unpkParam->typedTime, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpZoneAdj */

/*
*
*       Fun:   cmUnpkCmSdpTypedTimeSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpTypedTimeSet
(
CmSdpTypedTimeSet        *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpTypedTimeSet (unpkParam, mBuf, ptr)
CmSdpTypedTimeSet        *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpTypedTimeSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpTypedTime, &unpkParam->typedTime[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpTypedTimeSet */

/*
*
*       Fun:   cmUnpkCmSdpRepField
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpRepField
(
CmSdpRepField            *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr 
)
#else
PRIVATE S16 cmUnpkCmSdpRepField (unpkParam, mBuf, ptr)
CmSdpRepField            *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpRepField)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMMEMCHKUNPK(cmUnpkCmSdpTypedTime, &unpkParam->repInterval, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpTypedTime, &unpkParam->actvDur, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpTypedTimeSet, &unpkParam->offsetList, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpRepField */

/*
*
*       Fun:   cmUnpkCmSdpRepFieldSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpRepFieldSet
(
CmSdpRepFieldSet         *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpRepFieldSet (unpkParam, mBuf, ptr)
CmSdpRepFieldSet         *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpRepFieldSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpRepField, &unpkParam->repField[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpRepFieldSet */

/*
*
*       Fun:   cmUnpkCmSdpZoneAdjSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpZoneAdjSet
(
CmSdpZoneAdjSet          *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr 
)
#else
PRIVATE S16 cmUnpkCmSdpZoneAdjSet (unpkParam, mBuf, ptr)
CmSdpZoneAdjSet          *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpZoneAdjSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpZoneAdj, &unpkParam->zoneAdj[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpZoneAdjSet */

/*
*
*       Fun:   cmUnpkCmSdpOpTime
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpOpTime
(
CmSdpOpTime              *unpkParam,   /**/
Buffer                   *mBuf,        /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpOpTime (unpkParam, mBuf, ptr)
CmSdpOpTime              *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpOpTime)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->startTime, mBuf);
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->stopTime, mBuf);
      CMMEMCHKUNPK(cmUnpkCmSdpRepFieldSet, &unpkParam->repFieldSet, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpOpTime */

/*
*
*       Fun:   cmUnpkCmSdpOpTimeSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpOpTimeSet
(
CmSdpOpTimeSet           *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpOpTimeSet (unpkParam, mBuf, ptr)
CmSdpOpTimeSet           *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpOpTimeSet);

   /*DOUBLE PTR */
   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);
   
   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      CMGETMBLK(ptr,(sizeof(Ptr) * unpkParam->numComp.val), 
                (Ptr *)&unpkParam->sdpOpTime);

      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
      {
         CMGETMBLK(ptr, sizeof(CmSdpOpTime), (Ptr *)&unpkParam->sdpOpTime[j]);
         CMMEMCHKUNPK(cmUnpkCmSdpOpTime, unpkParam->sdpOpTime[j], mBuf, ptr);
      }
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpOpTimeSet */

/*
*
*       Fun:   cmUnpkCmSdpTime
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpTime
(
CmSdpTime                *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpTime (unpkParam, mBuf, ptr)
CmSdpTime                *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpTime)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMMEMCHKUNPK(cmUnpkCmSdpOpTimeSet, &unpkParam->sdpOpTimeSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpZoneAdjSet, &unpkParam->zoneAdjSet, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpTime */

/*
*
*       Fun:   cmUnpkCmSdpKeyType
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpKeyType
(
CmSdpKeyType             *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpKeyType (unpkParam, mBuf, ptr)
CmSdpKeyType             *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpKeyType)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->keyType, mBuf);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->key_data, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpKeyType */

/*
*
*       Fun:   cmUnpkCmSdpAttr
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpAttr
(
CmSdpAttr                *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpAttr (unpkParam, mBuf, ptr)
CmSdpAttr                *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpAttr)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->attrType, mBuf);
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->attrVal, mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpAttr */



/*
*
*       Fun:   cmUnpkCmSdpAttrSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpAttrSet
(
CmSdpAttrSet             *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpAttrSet (unpkParam, mBuf, ptr)
CmSdpAttrSet             *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpAttrSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpAttr, &unpkParam->attr[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpAttrSet */

/*
*
*       Fun:   cmUnpkCmSdpEmailSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpEmailSet
(
CmSdpEmailSet            *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpEmailSet (unpkParam, mBuf, ptr)
CmSdpEmailSet            *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpEmailSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->email[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpEmailSet */

/*
*
*       Fun:   cmUnpkCmSdpPhoneSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpPhoneSet
(
CmSdpPhoneSet            *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpPhoneSet (unpkParam, mBuf, ptr)
CmSdpPhoneSet            *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpPhoneSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->phone[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpPhoneSet */

/*
*
*       Fun:   cmUnpkCmSdpBw
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpBw
(
CmSdpBw                  *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpBw (unpkParam, mBuf, ptr)
CmSdpBw                  *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpBw)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->bwType, mBuf, ptr);
      CMCHKUNPK(cmUnpkTknU32, &unpkParam->bWidth, mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpBw */

/*
*
*       Fun:   cmUnpkCmSdpBwSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpBwSet
(
CmSdpBwSet               *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpBwSet (unpkParam, mBuf, ptr)
CmSdpBwSet               *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpBwSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkCmSdpBw, &unpkParam->sdpBw[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpBwSet */



/*
*
*       Fun:   cmUnpkCmSdpFmtSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpFmtSet
(
CmSdpFmtSet              *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpFmtSet (unpkParam, mBuf, ptr)
CmSdpFmtSet              *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpFmtSet)

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
         CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->fmtInfo[j], mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpFmtSet */

/*
*
*       Fun:   cmUnpkCmSdpMediaField
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpMediaField
(
CmSdpMediaField          *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpMediaField (unpkParam, mBuf, ptr)
CmSdpMediaField          *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpMediaField)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->mediaType, mBuf);
      CMCHKUNPK(cmUnpkTknU16, &unpkParam->port, mBuf);
      CMCHKUNPK(cmUnpkTknU16, &unpkParam->portInt, mBuf);
      CMCHKUNPK(cmUnpkTknStr32, &unpkParam->proto, mBuf);
      CMMEMCHKUNPK(cmUnpkCmSdpFmtSet, &unpkParam->fmtSet, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpMediaField */

/*
*
*       Fun:   cmUnpkCmSdpMediaDesc
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpMediaDesc
(
CmSdpMediaDesc           *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpMediaDesc (unpkParam, mBuf, ptr)
CmSdpMediaDesc           *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpMediaDesc)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMMEMCHKUNPK(cmUnpkCmSdpMediaField, &unpkParam->field, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->info, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpConnSet, &unpkParam->connSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpBwSet, &unpkParam->bwSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpKeyType, &unpkParam->keyType, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpAttrSet, &unpkParam->attrSet, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpMediaDesc */

/*
*
*       Fun:   cmUnpkCmSdpMediaDescSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCmSdpMediaDescSet
(
CmSdpMediaDescSet        *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PRIVATE S16 cmUnpkCmSdpMediaDescSet (unpkParam, mBuf, ptr)
CmSdpMediaDescSet        *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpMediaDescSet);

   /*DOUBLE PTR */

   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;      
      CMGETMBLK(ptr,(sizeof(Ptr) * unpkParam->numComp.val), 
                (Ptr *)&unpkParam->mediaDesc);

      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
      {
         CMGETMBLK(ptr, sizeof(CmSdpMediaDesc), (Ptr *)&unpkParam->mediaDesc[j]);
         CMMEMCHKUNPK(cmUnpkCmSdpMediaDesc, unpkParam->mediaDesc[j], mBuf, ptr);
      }
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpMediaDescSet */

/*
*
*       Fun:   cmUnpkCmSdpInfo
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpInfo
(
CmSdpInfo                *unpkParam,   /**/
Buffer                   *mBuf,         /* message buffer */
Ptr                      ptr
)
#else
PUBLIC S16 cmUnpkCmSdpInfo (unpkParam, mBuf, ptr)
CmSdpInfo                *unpkParam;   /**/
Buffer                   *mBuf;        /* message buffer */
Ptr                      ptr; 
#endif
{
   TRC2(cmUnpkCmSdpInfo)

   CMCHKUNPK(cmUnpkTknU8, &unpkParam->pres, mBuf);

   if (unpkParam->pres.pres == TRUE)
   {
      CMCHKUNPK(cmUnpkTknU16, &unpkParam->ver, mBuf);
      CMMEMCHKUNPK(cmUnpkCmSdpOrig, &unpkParam->orig, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->sessName, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->info, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkTknStrOSXL, &unpkParam->uri, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpEmailSet, &unpkParam->emailSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpPhoneSet, &unpkParam->phoneSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpConn, &unpkParam->conn, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpBwSet, &unpkParam->bwSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpTime, &unpkParam->sdpTime, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpKeyType, &unpkParam->keyType, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpAttrSet, &unpkParam->attrSet, mBuf, ptr);
      CMMEMCHKUNPK(cmUnpkCmSdpMediaDescSet, &unpkParam->mediaDescSet, mBuf, ptr);
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpInfo */

/*
*
*       Fun:   cmUnpkCmSdpInfoSet
*
*       Desc:  This function unpacks the 
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_sdppu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpInfoSet
(
CmSdpInfoSet             *unpkParam,   /**/
Ptr                      ptr,
CmIntfVer                intfVer,       /* 001.main_4 : addition */
Buffer                   *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmUnpkCmSdpInfoSet (unpkParam, ptr, intfVer, mBuf)
CmSdpInfoSet             *unpkParam;   /**/
Ptr                      ptr; 
CmIntfVer                intfVer;      /* 001.main_4 : addition */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkCmSdpInfoSet)

   /*DOUBLE PTR */
   CMCHKUNPK(cmUnpkTknU16, &unpkParam->numComp, mBuf);

   if (unpkParam->numComp.pres == TRUE)
   {
      Cntr j;
      CMGETMBLK(ptr,(sizeof(Ptr) * unpkParam->numComp.val), (Ptr *)&unpkParam->info);
      for(j=(unpkParam->numComp.val - 1); j>=0; j--)
      {
         CMGETMBLK(ptr, sizeof(CmSdpInfo), (Ptr *)&unpkParam->info[j]);
         CMMEMCHKUNPK(cmUnpkCmSdpInfo, unpkParam->info[j], mBuf, ptr);
      }
   }

   RETVALUE(ROK);
}   /* cmUnpkCmSdpInfoSet */

#endif /* CM_SDP_V_2 */
#endif /* LCCMSDP */

  
/********************************************************************30**
  
         End of file:     cm_sdppu.c@@/main/5 - Thu Jul 22 12:21:20 2004
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. initial release.
/main/2      ---      nt   1. Release 1.2
/main/4      ---      ra   1. Release 1.3
/main/4  001.main_4   ra   1. Now passing interface version to pack/unpack
                              functions for CmSdpInfoSet if CM_SDP_OPAQUE
                              is defined.
*********************************************************************91*/
