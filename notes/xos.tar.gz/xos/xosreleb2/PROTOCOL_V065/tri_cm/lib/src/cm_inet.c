/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
        Name:     common Internet socket library
    
        Type:     C Source file 
  
        Desc:     common library for Internet sockets,
                  always link this library with following libraries:
                       Trillium's libos.a
                       Solaris    nsl, socket 
 
        File:     cm_inet.c

        Sid:      cm_inet.c@@/main/32 - Thu Jul 28 15:46:34 2005
  
        Prg:      mf
  
*********************************************************************21*/
 

/*
 *      This software may be combined with the following TRILLIUM
 *      software:
 *
 *      part no.                      description
 *      --------    ----------------------------------------------
 *      1000151     TCAP over TCP/IP   
 */

  
/* header include files (.h) */
  
#include "envopt.h"             /* environment options */  
#include "envdep.h"             /* environment dependent */
#include "envind.h"             /* environment independent */

#include "gen.h"                /* general */
#include "ssi.h"                /* system services interface */
#include "cm_inet.h"            /* socket library file */

/* environment dependent include files */
#ifdef WIN32
#ifndef IN
#define IN
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#ifdef WIN2K
#include <Mswsock.h>
#endif /* WIN2K */
#else /* WIN32 */
#include <errno.h>
#if (!defined(SS_VW) && !defined(SS_PS))
#include <netdb.h>
#endif
#ifndef SS_PS
#include <unistd.h>
#endif
#include <string.h>
#include <sys/types.h>
#ifdef SS_PS
#include <pna.h>
#else
#include <sys/socket.h>
#include <sys/ioctl.h>
#endif /* SS_PS */
#ifdef SS_VW
#include <sys/times.h>
#include <ioLib.h>
#include <sockLib.h>
#include <selectLib.h>
#include <hostLib.h>
#else
#if (!defined (SS_PS) && !defined(HPOS))
#include <sys/select.h>
#include <sys/time.h>
#ifdef SS_LINUX
#include <sys/uio.h>
#else
#include <sys/filio.h>
#endif /* SS_LINUX */
#endif /* SS_PS && HPOS */
#ifdef HPOS
#include <sys/time.h>
#endif /* HPOS */
#endif /* SS_VW */
#ifndef SS_PS
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/tcp.h>
#ifdef IPV6_SUPPORTED 
#include <netinet/icmp6.h>
#endif /* IPV6_SUPPORTED */
#endif /* SS_PS */
#endif /* WIN32 */

/* header/extern include files (.x) */

#include "gen.x"                /* general */
#include "ssi.x"                /* system services interface */
#include "cm_inet.x"            /* socket library file */
#include "cm_lib.x"             /* lib library file */

  
/* local defines */

/* BSD and Winsock error handling is different */
#ifdef WIN32
#define INET_ERR             SOCKET_ERROR
#define INET_ERR_CODE        WSAGetLastError()
#define ERR_INPROGRESS       WSAEINPROGRESS  
#define ERR_ISCONN           WSAEISCONN
#define ERR_WOULDBLOCK       WSAEWOULDBLOCK
#define ERR_INADDRNONE       INADDR_NONE
#define ERR_NOTCONN          WSAENOTCONN
#define ERR_ALREADY          WSAEALREADY
#define ERR_AGAIN            WSAEWOULDBLOCK 
#define ERR_INVAL            WSAEINVAL
#define ERR_CONNREFUSED       WSAECONNREFUSED
#define ERR_PIPE             WSAENOTCONN
/* Changed ERR_TIMEOUT for pSos compilation */
#define ERR_TIMEDOUT         WSAETIMEDOUT
#define ERR_CONNRESET        WSAECONNRESET
#define ERR_CONNABORTED      WSAECONNABORTED
#else
#define INET_ERR             -1
#define INET_ERR_CODE        errno
#define ERR_INPROGRESS       EINPROGRESS
#define ERR_ISCONN           EISCONN
#define ERR_WOULDBLOCK       EWOULDBLOCK
#define ERR_INADDRNONE       -1
#define ERR_NOTCONN          ENOTCONN       
#define ERR_ALREADY          EALREADY
#define ERR_AGAIN            EAGAIN
/* EINVAL is not mapped because it is a valid error code here */
#define ERR_INVAL            0 
#define ERR_CONNREFUSED      ECONNREFUSED
#define ERR_PIPE             EPIPE 
/* Changed ERR_TIMEOUT for pSos compilation */
#define ERR_TIMEDOUT         ETIMEDOUT
#define ERR_CONNRESET        ECONNRESET
#define ERR_CONNABORTED      ECONNABORTED
#endif /* WIN32 */

/* back log range */
#define MIN_BACK_LOG  0

/* added a win2k specific defines in. */
#ifdef WIN32
#ifdef WIN2K
#ifndef SIO_UDP_CONNRESET
#define SIO_UDP_CONNRESET _WSAIOW(IOC_VENDOR, 12)
#endif 
#endif /* WIN2K */
#define MAX_BACK_LOG  1
#else
#define MAX_BACK_LOG  5
#endif /* WIN32 */

#ifdef IPV6_OPTS_SUPPORTED
#ifndef IPV6_SUPPORTED
#error "Enable IPV6_SUPPORTED flag if IPV6_OPTS_SUPPORTED is defined."
#endif 
#if (!defined(SS_LINUX) && !defined(_XPG4_2))
#error "Enable _XPG4_2 or SS_LINUX if IPV6_OPTS_SUPPORTED is defined."
#endif /* SS_LINUX || _XPG4_2 */
#endif /* IPV6_OPTS_SUPPORTED */

#ifdef LOCAL_INTF
#if (!defined(SS_LINUX) && !defined(_XPG4_2))
#error "Enable _XPG4_2 or SS_LINUX if LOCAL_INTF is defined."
#endif /* SS_LINUX || _XPG4_2 */
#endif /* LOCAL_INTF */

/* local typedefs */

/* local externs */
  
/* forward references */

/* added !(defined(CMINETFLATBUF) */
#if (!(defined(WIN32)) && !(defined(CMINETFLATBUF)))
/* Added another function parameter */
PRIVATE S16 buildRecvBuf ARGS((CmInetMemInfo *info, MsgLen len, 
                               CmInetIovec rxArr[], Buffer *dBuf[], U16 maxSize,
                               struct msghdr *msg, Bool isStrmMsg));
PRIVATE S16 buildRecvMsg ARGS((CmInetMemInfo *info, CmInetIovec rxArr[], 
                               S16 numBduf, MsgLen msgLen, Buffer *dBufs[], 
                               Buffer **mPtr));
PRIVATE S16 buildSendIovec ARGS((Buffer *mBuf, MsgLen msgLen, 
                                 CmInetIovec txArr[], S16 numDBuf, 
                                 S16 *numIovElems, U32 *strtEndDBufNum)); 
#endif /* (defined(WIN32)) && !(defined(CMINETFLATBUF)) */

/* prototypes of new functions needed to send and 
 * process after receiving the extension headers through ancillary data */

#ifdef IPV6_SUPPORTED
#ifdef IPV6_OPTS_SUPPORTED
PRIVATE S16 cmInet6BuildSendHBHOpts    ARGS((CmInetIpv6HBHHdrArr *hbhOptsArr, 
                                            U8 *cmsgBuf, U32 *curMsgIdx, 
                                            U8 hdrId));
PRIVATE S16 cmInet6BuildSendRouteOpts  ARGS((CmInetIpv6RtHdr *rtOptsArr, 
                                            U8 *cmsgBuf, U32 *curMsgIdx));

PRIVATE S16 cmInet6BuildRecvRtHdr      ARGS((U8 *cmsgData, U32 rtDataLen, 
                                            CmInetIpv6RtHdr0 *rtHdr0, 
                                            CmInetIpv6RtHdr *rtOptsArr,
                                            CmInetMemInfo *info));
PRIVATE S16 cmInet6BuildRecvHopOptsArr ARGS((U8 *cmsgData, U32 hbhDataLen, 
                                            CmInetIpv6HBHHdrArr *hbhOptsArr, 
                                            U8 hdrId, CmInetMemInfo *info));
PRIVATE S16 cmInet6GetHopLimitValue    ARGS((U8 *cmsgData, U32 hopLimitDataLen,
                                            CmInetIpv6HdrParm *ipv6HdrParam));

#ifdef SS_LINUX
PRIVATE S16 cmInetBuildSendHoplimit        ARGS((U32 hoplimit, U8 *cmsgBuf, 
                                            U32 *curMsgIdx));
#endif /* SS_LINUX */
#ifdef LOCAL_INTF
PRIVATE S16 cmInet6BuildSendPktinfo         ARGS((CmInetIpAddr6 *srcAddr,
                                            U8 *cmsgBuf, U32 *curMsgIdx,
                                            U8 protType));
#endif /* LOCAL_INTF */
#endif /* IPV6_OPTS_SUPPORTED */
#endif /* IPV6_SUPPORTED */

/* public variable declarations */

/* private variable declarations */

#ifdef CMINETDBG
/* Global buffer for debug prints */
Txt   prntBuf[512];
#endif /* CMINETDBG */

#if (!(defined(WIN32)) && !(defined(CMINETFLATBUF)))
/*
*
*      Fun:   buildRecvBuf
*
*      Desc:  Allocates dBufs to receive an entire message.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*             ROUTRES - failed, out of resources
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 buildRecvBuf
(
CmInetMemInfo  *info,           /* buffer allocation info */
MsgLen          len,            /* message length */
CmInetIovec     rxArr[],        /* gather array */
Buffer         *dBuf[],         /* allocated dBufs */
U16             maxSize,        /* size of rxArr/dBuf array */       
struct msghdr  *msg,            /* message header for recvmsg() */           
Bool           isStrmMsg        /* Is a TCP message */
)
#else
PRIVATE S16 buildRecvBuf(info, len, rxArr, dBuf, maxSize, msg, isStrmMsg)
CmInetMemInfo   *info;          /* buffer allocation info */
MsgLen           len;           /* message length */        
CmInetIovec      rxArr[];       /* gather array */         
Buffer          *dBuf[];        /* allocated dBufs */
U16              maxSize;       /* size of rxArr/dBuf array */       
struct msghdr   *msg;           /* message header for recvmsg() */        
Bool            isStrmMsg;      /* Is a TCP message */
#endif
{
   S16     ret;                 /* temporary return value */
   U16     numBuf;              /* number of dBufs */
   U16     i;                   /* dBuf index counter */
   Data   *dPtr;                /* data pointer */
   S32     bufLen;              /* entire receive buffer length, if S16 
                                   could wrap to negative number */
   MsgLen  dLen;                /* buffer length */ 
  
   numBuf = 0;
   bufLen = 0; 

   /* Initialise ret and part of msg here */
   ret = ROK;

   /* added defined(_XPG4_2) */
   /* Moved initialisation of msg here. */

#if (defined(SS_LINUX) || defined(_XPG4_2))
   msg->msg_control    = NULLP;
   msg->msg_controllen  = 0;
#else
   msg->msg_accrights     = NULLP;
   msg->msg_accrightslen  = 0;
#endif /* SS_LINUX */   

   /* Check if maxSize if enough to hold the entire message length before 
    * going into the loop. If the boolean isStrmMsg is TRUE then the recv 
    * buf is built even if the whole message cannot be accomodated. */
   ret = SGetDBuf(info->region, info->pool, &dBuf[numBuf]); 
   if (ret != ROK)
      RETVALUE(ret);
  
   /* Get the data part */
   ret = SGetDataRx(dBuf[numBuf], 0, &dPtr, &dLen);
   if (ret != ROK)
   {
      numBuf++;           /* because of cleanup */
      goto cleanup;
   }

   if (!isStrmMsg)
   {
      /* The assumption here is that all dBuf's from a given region and 
       * pool have a constance size */
      if (len > (maxSize * dLen))
      {
         ret = RNA;
         numBuf++;           /* because of cleanup */
         goto cleanup;
      }
   }

#ifdef SS_LINUX
  rxArr[numBuf].iov_base = (Void*)dPtr;  
  rxArr[numBuf].iov_len = (U32)dLen;    
#else
  rxArr[numBuf].iov_base = (S8*)dPtr;
  rxArr[numBuf].iov_len = dLen;
#endif /* SS_LINUX */
      
  bufLen += dLen;
  numBuf++;  

   /* allocate buffer space for entire message length */
   while (bufLen < len)
   {
      if (numBuf >= maxSize)
      {
         /* to big to fit in gather vector array */ 
         ret = RNA;
         break;
      }
      ret = SGetDBuf(info->region, info->pool, &dBuf[numBuf]); 
      if (ret != ROK)
      {
         goto cleanup;
      } 
      ret = SGetDataRx(dBuf[numBuf], 0, &dPtr, &dLen);
      if (ret != ROK)
      {
         numBuf++;           /* because of cleanup */
         goto cleanup;
      }
#ifdef SS_LINUX
      rxArr[numBuf].iov_base = (Void*)dPtr;  
      rxArr[numBuf].iov_len = (U32)dLen;    
#else
      rxArr[numBuf].iov_base = (S8*)dPtr;
      rxArr[numBuf].iov_len = dLen;
#endif /* SS_LINUX */
      
      bufLen += dLen;
      numBuf++;  
   }
   /* adjust last buffer length */
   /*  check if we broke out because numBuf >= maxSize */
   if (bufLen < len)
      rxArr[numBuf - 1].iov_len = dLen;
   else
      rxArr[numBuf - 1].iov_len = dLen - (bufLen - len); 
   
   /* setup recvmsg() message header */
   msg->msg_iov           = rxArr;
   msg->msg_iovlen        = numBuf;

   RETVALUE(ret);

cleanup:
   /* cleanup */
   for (i = 0; i < numBuf; i++)
      SPutDBuf(info->region, info->pool, dBuf[i]);
   
   msg->msg_iovlen = 0;

   RETVALUE(ret);
} /* end of buildRecvBuf */

/*
*
*      Fun:   buildRecvMsg
*
*      Desc:  Builds a message out of the received dBufs.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*             ROUTRES - failed, out of resources
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 buildRecvMsg
(
CmInetMemInfo  *info,           /* buffer allocation info */
CmInetIovec     rxArr[],        /* scatter array */  
S16             numBuf,         /* number of allocated dBufs */
MsgLen          msgLen,         /* message length */
Buffer         *dBufs[],        /* dBufs */
Buffer        **mPtr            /* message built from dBufs */     
)
#else
PRIVATE S16 buildRecvMsg(info, rxArr, numBuf, msgLen, dBufs, mPtr)
CmInetMemInfo  *info;           /* buffer allocation info */   
CmInetIovec     rxArr[];        /* scatter array */            
S16             numBuf;         /* number of allocated dBufs */
MsgLen          msgLen;         /* length of one particular dBuf */          
Buffer         *dBufs[];        /* dBufs */
Buffer        **mPtr;           /* message built from dBufs */   
#endif
{
   S16      ret;                 /* return value */ 
   S16      i;                   /* dBuf index counter */
   MsgLen   bufLen;              /* length of one particular dBuf */
   Buffer  *mBuf;                /* allocated message */  

   ret = RFAILED;   
   i   = 0;

   /* build message */
   ret = SGetMsg(info->region, info->pool, &mBuf);
   if (ret != ROK)
   {
      goto cleanup;
   }
   
   /* link buffers to message */
   while (i < numBuf)
   {
      bufLen = rxArr[i].iov_len; 
      if (msgLen < bufLen)
      {
         bufLen = msgLen;
      }
      ret = SUpdMsg(mBuf, dBufs[i], bufLen);
      if (ret != ROK)
      { 
         SPutMsg(mBuf);
         goto cleanup;
      }
      msgLen -= bufLen;
      i++;
      if (msgLen <= 0)
      {
         ret = ROK;      
         break;
      }
   }
   
   *mPtr = mBuf;

cleanup:
   /* cleanup unused buffers */
   while (i < numBuf)
   {
      SPutDBuf(info->region, info->pool, dBufs[i]);
      i++;
   }

   RETVALUE(ret);
} /* end of buildRecvMsg */


/*
*
*      Fun:   buildSendIovec 
*
*      Desc:  Builds a io vector to send a message.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*             ROUTRES - failed, out of resources
*             RNA     - failed, not available, indicates that the
*                       maximum number of dBufs are not sufficient
*                       to hold the entire message.
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
PRIVATE S16 buildSendIovec
(
Buffer         *mBuf,           /* Message buffer */
MsgLen         msgLen,          /* Length of mBuf */
CmInetIovec    txArr[],         /* transmit scatter vector array */ 
S16            numDBufs,        /* Maximum number of dBufs to use */
S16            *numIovElems,    /* Number of iov elements in array */
U32            *strtEndDBufNum  /* dBuf number to start and end */
)
#else
PRIVATE S16 buildSendIovec(mBuf, msgLen, txArr, numDBufs, numIovElems, 
                           strtEndDBufNum) 
Buffer         *mBuf;           /* Message buffer */
MsgLen         msgLen;          /* Length of mBuf */
CmInetIovec    txArr[];         /* transmit scatter vector array */ 
S16            numDBufs;        /* Maximum number of dBufs to use */
S16            *numIovElems;    /* Number of iov elements in array */
U32            *strtEndDBufNum; /* dBuf number to start and end */
#endif
{
   S16         ret;
   MsgLen      dLen;
   S16         iovIdx;       
   Buffer      *dBuf;
   Data        *dPtr;
   MsgLen      allocLen;
   U32         dBufsToSkip;

   /* Initialisations */
   (*numIovElems) = 0;
   iovIdx = 0;
   allocLen = 0;

   /* Set up vector for gathering send */
   ret = SInitNxtDBuf(mBuf);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   iovIdx = 0;
   txArr[iovIdx].iov_len = 0;

   if ((*strtEndDBufNum != 0))
   {
      /* Skip through the required number of dBufs */
      dBufsToSkip = *strtEndDBufNum;

      while(dBufsToSkip)
      {
         ret = SGetNxtDBuf(mBuf, &dBuf);
         if (ret != ROK)
            RETVALUE(RFAILED);
         dBufsToSkip --;
      }
   }

   for (;;)
   {
      ret = SGetNxtDBuf(mBuf, &dBuf);
      if (ret == ROK)
      {
         ret = SGetDataTx(dBuf, &dPtr, &dLen);
         if (ret != ROK)
         {  
            ret = RFAILED;
            break;
         }

         txArr[iovIdx].iov_base = (S8 *)dPtr;
         txArr[iovIdx].iov_len = dLen;

         allocLen += dLen;
      }
      else if  (ret == ROKDNA)
      {  
         ret = ROK;
         break;
      }
      else
      {
         ret = RFAILED;
         break;
      }
      
      iovIdx += 1;

      if (iovIdx >= numDBufs)
      {
         if (allocLen >= msgLen)
            ret = ROK;
         else
            ret = RNA;
         break;
      }
   }
   
   (*numIovElems) = iovIdx;
   (*strtEndDBufNum) += iovIdx;

   RETVALUE(ret);

} /* end of buildSendIovec */
#endif /* (defined(WIN32)) && !(defined(CMINETFLATBUF)) */


/*
*
*      Fun:   cmInetSocket
*
*      Desc:  Creates an Internet socket descriptor.
*             On default the socket is non-blocking ( can be changed 
*             with the function cmInetSetOpt()).
*             Values for type:
*
*             CM_INET_STREAM   (TCP)
*             CM_INET_DGRAM    (UDP)
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
#ifdef CM_INET2  
#ifdef IPV6_SUPPORTED
PUBLIC S16 cmInetSocket
(
U8        type,                 /* socket type */
CmInetFd *sockFd,               /* socket file descriptor */
U8       protocol,              /* protocol value */
U8       domain                 /* domain */
)
#else
PUBLIC S16 cmInetSocket
(
U8        type,                 /* socket type */
CmInetFd *sockFd,               /* socket file descriptor */
U8       protocol               /* protocol value */
)
#endif /* IPV6_SUPPORTED */
#else   /* CM_INET2 */ 
PUBLIC S16 cmInetSocket
(
U8        type,                 /* socket type */
CmInetFd *sockFd                /* socket file descriptor */
)
#endif /* CM_INET2 */ 
#else
#ifdef CM_INET2  
#ifdef IPV6_SUPPORTED
PUBLIC S16 cmInetSocket(type, sockFd, protocol, domain)
U8        type;                 /* socket type */
CmInetFd *sockFd;               /* socket file descriptor */
U8        protocol;             /* protocol value */
U8        domain;               /* domain */
#else
PUBLIC S16 cmInetSocket(type, sockFd, protocol)
U8        type;                 /* socket type */
CmInetFd *sockFd;               /* socket file descriptor */
U8        protocol;             /* protocol value */
#endif /* IPV6_SUPPORTED */
#else /* CM_INET2 */ 
PUBLIC S16 cmInetSocket(type, sockFd)
U8        type;                 /* socket type */
CmInetFd *sockFd;               /* socket file descriptor */
#endif /* CM_INET2 */ 
#endif /* ANSI */
{
   S32 ret;                     /* temporary return value */

   U32 optVal;
   
#if (defined(WIN32) && defined(WIN2K))
   S32 bytesReturned;
   Bool bNewBehavior;
#endif /* WIN2K && WIN32 */
   
   TRC2(cmInetSocket);

#if (defined(WIN32) && defined(WIN2K))
   bytesReturned = 0;
   bNewBehavior = FALSE;
#endif /* WIN32 && WIN2K */  

   /* create socket */
#ifdef CM_INET2  
#ifdef IPV6_SUPPORTED
   sockFd->fd = socket(domain, type, protocol);
#else
   sockFd->fd = socket(AF_INET, type, protocol);
#endif /* IPV6_SUPPORTED */
#else   /* CM_INET2 */ 
   sockFd->fd = socket(AF_INET, type, 0);
#endif  /* CM_INET2 */ 
   if (CM_INET_INV_SOCK_FD(sockFd))
   {   
#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetSocket() failed on line: %d \n\
              error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      /* Set sockFd->fd to invalid socket */
      sockFd->fd = CM_INET_INV_SOCKFD;
      RETVALUE(RFAILED);   
   }
   
   /* set socket type */
   sockFd->type = type;

   /* set socket protocol type (IPv4/IPv6) */
#ifdef IPV6_SUPPORTED   
   sockFd->protType = domain; 
#endif /* IPV6_SUPPORTED */
   
   /* set default options */
   optVal = CM_INET_OPT_DISABLE;
   ret = cmInetSetOpt(sockFd, SOL_SOCKET, CM_INET_OPT_BLOCK, (Ptr)&optVal); 
   if (ret != ROK) 
   {
      ret = cmInetClose(sockFd);
      RETVALUE(RFAILED);
   }

#ifdef SS_LINUX
   optVal = CM_INET_OPT_ENABLE;
   ret = cmInetSetOpt(sockFd, SOL_SOCKET, CM_INET_OPT_BSD_COMPAT, (Ptr)&optVal);
   if (ret != ROK) 
   {
      ret = cmInetClose(sockFd);
      RETVALUE(RFAILED);
   }
#endif /* SS_LINUX */

#if (defined(WIN32) && defined(WIN2K))   
   if(type == CM_INET_DGRAM)
   {
      ret = WSAIoctl(sockFd->fd, SIO_UDP_CONNRESET, &bNewBehavior,
                     sizeof(bNewBehavior), NULLP, 0, &bytesReturned,
                     NULLP, NULLP);
      if(ret == INET_ERR)
      {
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, WSAIoctl() failed on line: %d \n\
                 error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
#endif /* CMINETDBG */      
         ret = cmInetClose(sockFd);
         RETVALUE(RFAILED);
      }
   }
#endif /* WIN2K && WIN32 */   
   RETVALUE(ROK);
} /* end of cmInetSocket */


/*
*
*      Fun:   cmInetBind 
*
*      Desc:  Binds a socket file descriptor to a local Internet 
*             address/port.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetBind
(
CmInetFd   *sockFd,             /* socket file descriptor */ 
CmInetAddr *myAddr              /* locale Internet address/port */
)
#else
PUBLIC S16 cmInetBind(sockFd, myAddr)
CmInetFd   *sockFd;             /* socket file descriptor */ 
CmInetAddr *myAddr;             /* locale Internet address/port */
#endif
{
   S32 ret;                     /* temporary return value */
   struct sockaddr_in srcAddr;  /* local Internet address/port */
#ifdef IPV6_SUPPORTED 
   struct sockaddr_in6 srcAddr6; /* local IPV6 address/port */
#ifdef CMINETDBG
   U16    port;
#endif /* CMINETDBG */
#endif /* IPV6_SUPPORTED */
   U32    sizeOfAddr;            /* sizeof address passed to the bind call */
   CmInetSockAddr *sockAddrPtr; 

   TRC2(cmInetBind);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (myAddr == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef IPV6_SUPPORTED 
   if (myAddr->type == CM_INET_IPV6ADDR_TYPE)
   {
      cmMemset((U8*)&srcAddr6, 0, sizeof(srcAddr6));
      srcAddr6.sin6_family      = AF_INET6;
      srcAddr6.sin6_port        = CM_INET_HTON_U16(myAddr->u.ipv6Addr.port);
      CM_INET_COPY_IPV6ADDR(&srcAddr6.sin6_addr, 
                            &myAddr->u.ipv6Addr.ipv6NetAddr);
      sizeOfAddr               = sizeof(struct sockaddr_in6);
      sockAddrPtr              = (CmInetSockAddr *)&srcAddr6;
   }
   else 
   {
      cmMemset((U8*)&srcAddr, 0, sizeof(srcAddr));
      srcAddr.sin_family      = AF_INET;
      srcAddr.sin_port        = CM_INET_HTON_U16(myAddr->u.ipv4Addr.port);
      srcAddr.sin_addr.s_addr = CM_INET_HTON_U32(myAddr->u.ipv4Addr.address);
      sizeOfAddr               = sizeof(struct sockaddr_in);
      sockAddrPtr              = (CmInetSockAddr *)&srcAddr;
   }
#else 
   cmMemset((U8*)&srcAddr, 0, sizeof(srcAddr));
   srcAddr.sin_family      = AF_INET;
   srcAddr.sin_port        = CM_INET_HTON_U16(myAddr->port);
   srcAddr.sin_addr.s_addr = CM_INET_HTON_U32(myAddr->address);
   sizeOfAddr              = sizeof(struct sockaddr_in);
   sockAddrPtr             = (CmInetSockAddr *)&srcAddr;
#endif /* IPV6_SUPPORTED */

   ret = bind(sockFd->fd, sockAddrPtr, sizeOfAddr); 
   if (ret == INET_ERR)
   {
#ifdef CMINETDBG
#ifdef IPV6_SUPPORTED 
      if (myAddr->type == CM_INET_IPV6ADDR_TYPE)
         port = myAddr->u.ipv6Addr.port;
      else
         port = myAddr->u.ipv4Addr.port;
      sprintf(prntBuf, "File: %s, cmInetBind() failed on line: %d\n\
              error(%d), addrType(%d), port(%d)\n ", __FILE__, __LINE__,
              INET_ERR_CODE , myAddr->type, port);
      SPrint(prntBuf);
#else
      sprintf(prntBuf, "File: %s, cmInetBind() failed on line: %d\n\
              error(%d), addr(0x%lx), port(%d)\n", __FILE__, __LINE__,
              INET_ERR_CODE , myAddr->address, myAddr->port);
      SPrint(prntBuf);
#endif /* IPV6_SUPPORTED */
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK); 
} /* end of cmInetBind */


/*
*
*      Fun:   cmInetConnect
*
*      Desc:  Establishs a connection to a foreign address (TCP) or associates
*             a UDP socket to a foreign address.
*
*      Ret:   ROK         - successful
*             ROKDNA      - resource temporarily unavaiable
*             RINPROGRESS - connection is in progress (only non-blocking)
*             RISCONN     - connection is established (only non-blocking)
*             RFAILED     - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetConnect
(
CmInetFd   *sockFd,             /* socket file descriptor */
CmInetAddr *servAddr            /* foreign Internet address/port */  
)
#else
PUBLIC S16 cmInetConnect(sockFd, servAddr)
CmInetFd   *sockFd;             /* socket file descriptor */
CmInetAddr *servAddr;           /* foreign Internet address/port */  
#endif
{
   S32 ret;                     /* temporary return value */
   struct sockaddr_in dstAddr;  /* foreign Internet address/port */
#ifdef IPV6_SUPPORTED 
   struct sockaddr_in6 dstAddr6; /* foreign Internet IPV6 address/port */
#ifdef CMINETDBG
   U16            port;
#endif /* CMINETDBG */
#endif /* IPV6_SUPPORTED */
   S32    sizeOfAddr;
   CmInetSockAddr *sockAddrPtr;  

   TRC2(cmInetConnect);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (servAddr == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef IPV6_SUPPORTED 
   if (servAddr->type == CM_INET_IPV6ADDR_TYPE)
   {
      cmMemset((U8*)&dstAddr6, 0, sizeof(dstAddr6));
      dstAddr6.sin6_family     = AF_INET6;
      dstAddr6.sin6_port       = CM_INET_HTON_U16(servAddr->u.ipv6Addr.port);
      CM_INET_COPY_IPV6ADDR(&dstAddr6.sin6_addr, 
                            &servAddr->u.ipv6Addr.ipv6NetAddr);
      sizeOfAddr              = sizeof(struct sockaddr_in6);
      sockAddrPtr             = (CmInetSockAddr *)&dstAddr6;
   }
   else
   {
      cmMemset((U8*)&dstAddr, 0, sizeof(dstAddr));
      dstAddr.sin_family      = AF_INET;
      dstAddr.sin_port        = CM_INET_HTON_U16(servAddr->u.ipv4Addr.port);
      dstAddr.sin_addr.s_addr = CM_INET_HTON_U32(servAddr->u.ipv4Addr.address);
      sizeOfAddr              = sizeof(struct sockaddr_in);
      sockAddrPtr             = (CmInetSockAddr *)&dstAddr;
   }
#else
   cmMemset((U8*)&dstAddr, 0, sizeof(dstAddr));
   dstAddr.sin_family      = AF_INET;
   dstAddr.sin_port        = CM_INET_HTON_U16(servAddr->port);
   dstAddr.sin_addr.s_addr = CM_INET_HTON_U32(servAddr->address);
   sizeOfAddr              = sizeof(struct sockaddr_in);
   sockAddrPtr             = (CmInetSockAddr *)&dstAddr;
#endif /* IPV6_SUPPORTED */

   ret = connect(sockFd->fd, sockAddrPtr, sizeOfAddr);
   if (ret == INET_ERR)
   {
      switch (INET_ERR_CODE)
      {
         /* non-blocking: connection is in progress */
         case ERR_INPROGRESS:
            RETVALUE(RINPROGRESS);
            break;   

         /* 
          * non-blocking: connection is established 
          * blocking    : connection is already established
          */
         case ERR_ISCONN:
            RETVALUE(RISCONN);
            break;               

         /* resource temporarily unavailable */
         case ERR_WOULDBLOCK:
            RETVALUE(ROKDNA);
            break;
        
         /* non-blocking: connection is in progress */
         case ERR_ALREADY:
            RETVALUE(RINPROGRESS);
            break;

         case ERR_INVAL:
            RETVALUE(RINPROGRESS);
            break;

         /*  Check for connection refused and timeout errors */
         case ERR_CONNREFUSED:
         case ERR_TIMEDOUT:
            RETVALUE(RCLOSED);
            break;

         /* it is a real error */ 
         default:
#ifdef CMINETDBG
#ifdef IPV6_SUPPORTED 
            if (servAddr->type == CM_INET_IPV6ADDR_TYPE)
               port = servAddr->u.ipv6Addr.port;
            else
               port = servAddr->u.ipv4Addr.port;

            sprintf(prntBuf, "File: %s, cmInetConnect() failed on line: %d \n\
                error(%d), addrtype(0x%x), port(0x%1x)\n", __FILE__, __LINE__, 
                 INET_ERR_CODE, servAddr->type, port);
            SPrint(prntBuf);
#else
         sprintf(prntBuf, "File: %s, cmInetConnect() failed on line: %d \n\
                 error(%d), addr(0x%lx), port(0x%1x)\n", __FILE__, __LINE__, 
                 INET_ERR_CODE , servAddr->address, servAddr->port);
            SPrint(prntBuf);
#endif /* IPV6_SUPPORTED */
#endif /* CMINETDBG */
            RETVALUE(RFAILED);
            break;
      }
   }

   RETVALUE(ROK);
} /* end of cmInetConnect */


/*
*
*      Fun:   cmInetListen
*
*      Desc:  Indicates the willingness of a socket to listen for incomming 
*             connection requests.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: The backLog value has to be within 0..5
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetListen
(
CmInetFd *sockFd,               /* socket file descriptor */ 
S16       backLog               /* max. number of outstandig connections 0..5 */
)
#else
PUBLIC S16 cmInetListen(sockFd, backLog)
CmInetFd *sockFd;               /* socket file descriptor */ 
S16       backLog;              /* max. number of outstandig connections 0..5 */
#endif
{
   S32 ret;                     /* temporary return value */

   TRC2(cmInetListen);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (backLog < MIN_BACK_LOG) || (backLog > MAX_BACK_LOG))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   ret = listen(sockFd->fd, backLog);
   if (ret == INET_ERR) 
   {
#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetListen() failed on line: %d \n\
              error(%d), backLog(%d)\n", __FILE__, __LINE__, INET_ERR_CODE, 
              backLog);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmInetListen */


/*
*
*      Fun:   cmInetAccept 
*
*      Desc:  Accepts an incoming connection.
*             On default the new socket is non-blocking. The options can be 
*             changed with the function cmInetSetOpt().
*
*      Ret:   ROK     - successful
*             ROKDNA  - there is no connection present to accept (only 
*                       non-blocking) 
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetAccept
(
CmInetFd   *sockFd,     /* socket file descriptor */ 
CmInetAddr *fromAddr,   /* calling Internet address/port */
CmInetFd   *newSockFd   /* socket file descriptor for new connection*/
)
#else
PUBLIC S16 cmInetAccept(sockFd, fromAddr, newSockFd)
CmInetFd   *sockFd;     /* socket file descriptor */ 
CmInetAddr *fromAddr;   /* calling Internet address/port */
CmInetFd   *newSockFd;  /* socket file descriptor for new connection*/
#endif
{
   S32 ret;                         /* temporary return value */
   S32 addrLen;                     /* address structure length */
   struct sockaddr_in  *peerAddr;   /* calling Internet address/port */
#ifdef IPV6_SUPPORTED 
   struct sockaddr_in6 *peerAddr6;  /* calling Internet address/port */
   struct sockaddr_in6 sockAddr;
#else
   CmInetSockAddr sockAddr;  
#endif /* IPV6_SUPPORTED */

   U32 optVal;

   /* added */
   TRC2(cmInetAccept)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* change CmInetSockAddr to sockAddr */
   addrLen = sizeof(sockAddr);   

   /* INSURE fix */
#if ( defined(SUNOS) || defined(SS_LINUX)) 
   newSockFd->fd = accept(sockFd->fd, (CmInetSockAddr*)&sockAddr, 
                          (socklen_t *)&addrLen);
#else
   newSockFd->fd = accept(sockFd->fd, (CmInetSockAddr*)&sockAddr, 
                          (int*)&addrLen);
#endif /* SUNOS || SS_LINUX */   

   /* added for IPv6/IPv4 socket distinguishing */
#ifdef IPV6_SUPPORTED   
   if (addrLen == sizeof(struct sockaddr_in))
      newSockFd->protType = AF_INET;
   else if(addrLen == sizeof(struct sockaddr_in6))
      newSockFd->protType = AF_INET6;
   else
      newSockFd->protType = -1;
#endif /* IPV6_SUPPORTED */      
   
   if (CM_INET_INV_SOCK_FD(newSockFd))
   {
      if (INET_ERR_CODE == ERR_WOULDBLOCK)
      {
         /* no connection present to accept */ 
         RETVALUE(ROKDNA);
      }
      else
      {
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, cmInetAccept() failed on line: %d \n\
                 error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         RETVALUE(RFAILED);
      }
   }     

   /* set the new socket file descriptor type */
   newSockFd->type = CM_INET_STREAM;

   /* set default options for new socket file descriptor */
   optVal = CM_INET_OPT_DISABLE;
   ret = cmInetSetOpt(newSockFd, SOL_SOCKET, CM_INET_OPT_BLOCK, &optVal); 
   if ( ret != ROK) 
   {
      ret = cmInetClose(newSockFd);
      RETVALUE(RFAILED);
   }

#ifdef IPV6_SUPPORTED
   cmMemset((U8*)fromAddr, 0, sizeof(fromAddr));
   if (addrLen == sizeof(struct sockaddr_in))
   {
      peerAddr = (struct sockaddr_in *)&sockAddr;
      fromAddr->type = CM_INET_IPV4ADDR_TYPE;
      fromAddr->u.ipv4Addr.port    = CM_INET_NTOH_U16(peerAddr->sin_port);
      fromAddr->u.ipv4Addr.address = 
                              CM_INET_NTOH_U32(peerAddr->sin_addr.s_addr);
   }
   else if (addrLen == sizeof(struct sockaddr_in6))
   {
      peerAddr6 = (struct sockaddr_in6 *)&sockAddr;
      fromAddr->type = CM_INET_IPV6ADDR_TYPE;
      fromAddr->u.ipv6Addr.port    = CM_INET_NTOH_U16(peerAddr6->sin6_port);
      CM_INET_COPY_IPV6ADDR(&fromAddr->u.ipv6Addr.ipv6NetAddr, 
                            &peerAddr6->sin6_addr);
   }
#else
   peerAddr = (struct sockaddr_in *)&sockAddr;
   fromAddr->port    = CM_INET_NTOH_U16(peerAddr->sin_port);
   fromAddr->address = CM_INET_NTOH_U32(peerAddr->sin_addr.s_addr);
#endif /* IPV6_SUPPORTED */
   RETVALUE(ROK);
} /* end of cmInetAccept */ 


/*
*
*      Fun:   cmInetSendMsg
*
*      Desc:  Sends the message data hold by mBuf. 
*             The len paramter gives the actual written octets. If the socket
*             is non-blocking this value can be differ from the mBuf length 
*             because there was not enough transmit buffer space available. If 
*             this occurs, RWOULDBLOCK is returned and only a part of the mBuf
*             is sent.
*             Values for flag parameter:
*  
*             CM_INET_NO_FLAG - no additional control flag
*
*      Ret:   ROK         - successful
*             RWOULDBLOCK - no or not entire mBuf sent because would block
*             ROUTRES     - failed, out of resources
*             RCLOSED     - connection was closed by the peer
*             RFAILED     - failed
*                           
*      Notes: The successful completion of a send call does not indicate that 
*             the data has been successfully delivered! 
*
*             This function does not free any sent buffers.  
*
*   
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetSendMsg
(
CmInetFd       *sockFd,         /* socket file descriptor */
CmInetAddr     *dstAddr,        /* destination Internet address/port */
CmInetMemInfo  *info,           /* buffer allocation info */
Buffer         *mBuf,           /* buffer structure to send */
MsgLen         *len,            /* number of actually sent octets */
/* added for IPv6 ext hdr */
#ifdef IPV6_OPTS_SUPPORTED
CmInetIpHdrParm *ipHdrParams,   /* IPv6 extensions headers */
#endif /* IPV6_OPTS_SUPPORTED */
S16             flags           /* additional control flags, unused */
)
#else
/* added for IPv6 ext hdr */
#ifdef IPV6_OPTS_SUPPORTED
PUBLIC S16 cmInetSendMsg(sockFd, dstAddr, info, mBuf, len, ipHdrParams, flags)
CmInetFd       *sockFd;         /* socket file descriptor */
CmInetAddr     *dstAddr;        /* destination Internet address/port */
CmInetMemInfo  *info;           /* buffer allocation info */
Buffer         *mBuf;           /* buffer structure to send */
MsgLen         *len;            /* number of actually sent octets */
CmInetIpHdrParm *ipHdrParams;   /* IPv6 extensions headers */
S16             flags;          /* additional control flags, unused */
#else
PUBLIC S16 cmInetSendMsg(sockFd, dstAddr, info, mBuf, len, flags)
CmInetFd       *sockFd;         /* socket file descriptor */
CmInetAddr     *dstAddr;        /* destination Internet address/port */
CmInetMemInfo  *info;           /* buffer allocation info */
Buffer         *mBuf;           /* buffer structure to send */
MsgLen         *len;            /* number of actually sent octets */
S16             flags;          /* additional control flags, unused */
#endif /* IPV6_OPTS_SUPPORTED */
#endif /* ANSI */
{
#if (defined(WIN32) || defined(CMINETFLATBUF))
   S32     ret;                 /* temporary return value */
   MsgLen  msgLen;              /* message length */ 
   MsgLen  bufLen;              /* send buffer length */
   Data   *sendBuf;             /* plain send buffer */
#else
   S32 ret;                     /* temporary return value */
   S32 retVal;                  /* temporary return value */
   S16 i;                       /* loop index */
   CmInetIovec  txArr[CM_INET_MAX_DBUF]; /* scatter vector */
   S16      numDBufs;           /* number of dBufs in message */
   struct   msghdr msg;         /* sendmsg() message header */
   MsgLen   msgLen;             /* message length */ 
   U32      strtEndDBufNum;     /* starting/ending DBuf number */ 
   MsgLen   unSentLen;          /* sent len */
   Bool     sentMsg;            /* flag to indicate the entire message is
                                 * sent */
#ifdef IPV6_SUPPORTED 
   /* added for IPv6 ext hdr */
#ifdef IPV6_OPTS_SUPPORTED
   U32    curMsgIdx;            /* indx in cmsgData where to write an ext hdr */
#endif /* IPV6_OPTS_SUPPORTED */
#if (defined(SS_LINUX) || defined(_XPG4_2))
   /* alloc from stack for IPv6 ancill data */
   U8     cmsgData[CM_INET_IPV6_ANCIL_DATA];
#endif /* SS_LINUX || _XPG4_2 */
#else
#if (defined(SS_LINUX) || defined(_XPG4_2))
   /* alloc from stack for IPv4 ancill data */ 
   U8     cmsgData[CM_INET_IPV4_ANCIL_DATA];
#endif /* SS_LINUX || _XPG4_2 */
#endif /* IPV6_SUPPORTED */   
#endif /* WIN32 | CMINETFLATBUF */  

   struct  sockaddr_in remAddr; /* remote Internet address */   
#ifdef IPV6_SUPPORTED
   struct   sockaddr_in6  remAddr6; /* remote Internet address */   
#endif /* IPV6_SUPPORTED */
   CmInetSockAddr *sockAddrPtr;
   S16            sizeOfAddr;
   
   TRC2(cmInetSendMsg)

   UNUSED(flags);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (info == NULLP) || (len == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* added for IPv6 ext hdr */
#if !(defined(WIN32) || defined(CMINETFLATBUF))
#if (defined(SS_LINUX) || defined(_XPG4_2))
   cmMemset((U8*)cmsgData, 0, sizeof(cmsgData));   
#endif /* SS_LINUX || _XPG4_2 */
#ifdef IPV6_OPTS_SUPPORTED
   curMsgIdx   = 0;
#endif /* IPV6_SUPPORTED */ 
#endif /* WIN32 | CMINETFLATBUF */
   
   msgLen = 0;  /* need by CC to pass without warning */
   sockAddrPtr = NULLP;
   sizeOfAddr = 0;

   /* setup remote address */
   if (dstAddr != NULLP)
   {
#ifdef IPV6_SUPPORTED
      if (dstAddr->type == CM_INET_IPV6ADDR_TYPE)
      {
         cmMemset((U8*)&remAddr6, 0, sizeof(remAddr6));
         remAddr6.sin6_family = AF_INET6;
         remAddr6.sin6_port   = CM_INET_HTON_U16(dstAddr->u.ipv6Addr.port);
         CM_INET_COPY_IPV6ADDR(&remAddr6.sin6_addr, 
                               &dstAddr->u.ipv6Addr.ipv6NetAddr); 
         sizeOfAddr = sizeof(remAddr6);
         sockAddrPtr = (CmInetSockAddr *)&remAddr6;
      }
      else
      {
         cmMemset((U8*)&remAddr, 0, sizeof(remAddr));
         remAddr.sin_family = AF_INET;
         remAddr.sin_port   = CM_INET_HTON_U16(dstAddr->u.ipv4Addr.port);
         remAddr.sin_addr.s_addr = 
                              CM_INET_HTON_U32(dstAddr->u.ipv4Addr.address);
         sizeOfAddr = sizeof(remAddr);
         sockAddrPtr = (CmInetSockAddr *)&remAddr;
      }
#else
      cmMemset((U8*)&remAddr, 0, sizeof(remAddr));
      remAddr.sin_family      = AF_INET;
      remAddr.sin_port        = CM_INET_HTON_U16(dstAddr->port);
      remAddr.sin_addr.s_addr = CM_INET_HTON_U32(dstAddr->address);
      sizeOfAddr = sizeof(remAddr);
      sockAddrPtr = (CmInetSockAddr *)&remAddr;
#endif /* IPV6_SUPPORTED */
   }
   
#if (defined(WIN32) || defined(CMINETFLATBUF))
   /* copy message to a flat buffer */
   ret = SFndLenMsg(mBuf, &bufLen);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* max message length is limited to control the memory usage */
   /* casting bufLen to avoid warnings */
   if ((bufLen > 0) && ((U32)bufLen > CM_INET_MAX_MSG_LEN))
   {
      RETVALUE(RFAILED);
   }
   ret = SGetSBuf(info->region, info->pool, &sendBuf, bufLen);                  
   if (ret != ROK)
   {
      RETVALUE(ROUTRES);
   }
   ret = SCpyMsgFix(mBuf, 0, bufLen, sendBuf, &msgLen);
   if ((ret != ROK) || (msgLen != bufLen)) 
   {
      /* cleanup */
      SPutSBuf(info->region, info->pool, sendBuf, bufLen);       
      RETVALUE(RFAILED);
   }
  
   if (dstAddr == NULLP)
   {
      /* VxWorks sendto has some problem
       * with connected UDP socket, use send */
#ifndef SS_VW
      ret = sendto(sockFd->fd, (S8 *)sendBuf, bufLen, 0, 
                   NULLP, sizeOfAddr);
#else
      ret = send(sockFd->fd, (S8 *)sendBuf, bufLen, 0);
#endif /* end of SS_VW */
   }
   else
      ret = sendto(sockFd->fd, (S8 *)sendBuf, bufLen, 0, 
                   sockAddrPtr, sizeOfAddr); 
   if (ret == INET_ERR)
   {
      /* cleanup */
      SPutSBuf(info->region, info->pool, sendBuf, bufLen);      

      if(INET_ERR_CODE == ERR_AGAIN)
      {
         *len = 0;
         RETVALUE(RWOULDBLOCK);
      }

      /* Check for ERR_WOULDBLOCK */
      if(INET_ERR_CODE == ERR_WOULDBLOCK)
      {
         *len = 0;
         RETVALUE(RWOULDBLOCK);
      }

#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetSendMsg() failed on line: %d \n\
              error(%d), msgLen(%d)\n", __FILE__, __LINE__, INET_ERR_CODE, 
              bufLen);
      SPrint(prntBuf);
#endif /* CMINETDBG */

      /*  Check if connection was closed */
      if ((INET_ERR_CODE == ERR_PIPE) ||
          (INET_ERR_CODE == ERR_CONNABORTED) || 
          (INET_ERR_CODE == ERR_CONNRESET))
      {
         *len = 0;
         RETVALUE(RCLOSED);
      }

      RETVALUE(RFAILED);
   }

   *len = ret;
   
   /* check if entire message could be sent */

   if (ret < bufLen) 
   {   
      /* cleanup */
      SPutSBuf(info->region, info->pool, sendBuf, bufLen);      
      RETVALUE(RWOULDBLOCK);
   }
    
   /* cleanup */
   SPutSBuf(info->region, info->pool, sendBuf, bufLen);      

#else /* end of Win NT/flat buffer specific part */
   ret = SFndLenMsg(mBuf, &msgLen);
   if (ret != ROK)
   {
      RETVALUE(RFAILED);
   }

   /* added */
   cmMemset((U8*)&msg, 0, sizeof(msg));
   
   if (dstAddr != NULLP)
   {
#ifdef SS_LINUX
      msg.msg_name    = (Void*)sockAddrPtr;
#else
#ifdef SS_PS
      msg.msg_name    = (char *)sockAddrPtr;
#else
      msg.msg_name    = (caddr_t)sockAddrPtr;
#endif /* SS_PS */
#endif /* SS_LINUX */
      msg.msg_namelen = sizeOfAddr;
   }
   else
   {
      msg.msg_name    = NULLP;         
      msg.msg_namelen = 0;
   }
/* added  defined(_XPG4_2) */
#if (defined(SS_LINUX) || defined(_XPG4_2))
   msg.msg_control    = NULLP;
   msg.msg_controllen  = 0;
#else
   msg.msg_accrights     = 0;
   msg.msg_accrightslen  = NULLP; 
#endif /* SS_LINUX */

   /* allocate scatter vector */
   numDBufs = CM_INET_MAX_DBUF;
   retVal = RNA;
   ret = ROK;
   unSentLen = msgLen;
   strtEndDBufNum = 0;
   *len = 0;
   sentMsg = FALSE;

   /* if the sender wants to send Ipv6 exten. headers */
#ifdef IPV6_OPTS_SUPPORTED
   if (ipHdrParams != NULLP && (ipHdrParams->type == CM_INET_IPV6ADDR_TYPE))
   {     
#ifdef SS_LINUX
      if(ipHdrParams->u.ipv6HdrParm.ttl.pres == TRUE)
      {
         cmInetBuildSendHoplimit((U32)ipHdrParams->u.ipv6HdrParm.ttl.val,
                              (U8 *)(cmsgData + curMsgIdx), &curMsgIdx);  
      }
#endif /* SS_LINUX */

#ifdef LOCAL_INTF      
      /* have to decide how to get the src addr to add in in6_pktinfo */
      if(ipHdrParams->u.ipv6HdrParm.srcAddr6.type == 6)
      {  
         cmInet6BuildSendPktinfo(
                         &ipHdrParams->u.ipv6HdrParm.srcAddr6.u.ipv6NetAddr, 
                         (U8 *)(cmsgData + curMsgIdx), &curMsgIdx,
                         sockFd->protType);
      }
#endif /* LOCAL_INTF */

     /* copy each ipv6 ext header from ipHdrParams to the flat buffer
      * cmsgData one by one. */

      if (ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.hbhHdrPrsnt == TRUE)
         /* build HBH ext header in cmsgData starting at indx 0 */
         cmInet6BuildSendHBHOpts(
                           &ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.hbhOptsArr, 
                           (U8 *)(cmsgData + curMsgIdx), &curMsgIdx, 0);                           
        
     /* now copy the elements from the Destination Option array one by
      * one to the Flat Buffer cmsgData. Start filling at indx curMsgIdx 
      * which is the end of HBH hdr. */          
      if (ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.destOptsPrsnt == TRUE)
         /* build Dest opt hdr starting at (cmsgData + curMsgIdx) */
         cmInet6BuildSendDestOpts(
                       &(ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.destOptsArr),
                       (U8 *)(cmsgData + curMsgIdx), &curMsgIdx, 1);

      /* copy Route header to to the Flat Buffer cmsgData */
      if (ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.rtOptsPrsnt == TRUE)
         /* curMsgIdx will be the indx where Dest opt ends in cmsgData */
         cmInet6BuildSendRouteOpts(
               &ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.rtOptsArr,
               (U8 *)(cmsgData + curMsgIdx), &curMsgIdx);
      
     /* msghrd struc's msg_control will point cmsgData and msg_controllen
      * will be the curMsgIdx */ 
      msg.msg_control = cmsgData;     /* pointer to Ancillary Data */
      msg.msg_controllen = curMsgIdx; /* total length of ancillary Data */
      
   }
#endif /* IPV6_OPTS_SUPPORTED */
   
   /* Loop till all the data is sent or till the sendmsg call cannot send 
    * any more data. */
   do
   {
      /* build the send vector */ 
      retVal = buildSendIovec(mBuf, unSentLen, txArr, numDBufs, &i, 
                              &strtEndDBufNum);
      if (retVal != ROK)
      {
         if (retVal == RNA)
         {
            /* Incase of UDP/RAW messages call SCompressMsg. */
            if (sockFd->type != CM_INET_STREAM)
            {
               /* Compress the message into a single dBuf */
               ret = SCompressMsg(mBuf);
               if (ret != ROK)
                  RETVALUE(RFAILED);
        
               strtEndDBufNum = 0;
               /* Rebuild the send vector */
               ret = buildSendIovec(mBuf, msgLen, txArr, numDBufs, &i,
                                    &strtEndDBufNum);
               if (ret != ROK)
                  RETVALUE(RFAILED);

               retVal = ROK;
            }
         }
         else
            RETVALUE(RFAILED);
      }
      msg.msg_iov           = txArr;
      msg.msg_iovlen        = i;

      
      ret = sendmsg(sockFd->fd, &msg, 0);
      *len += ret;

      if (ret == INET_ERR)
      {
         if((INET_ERR_CODE == ERR_AGAIN) ||
            (INET_ERR_CODE == ERR_WOULDBLOCK))
         {
            *len = 0;
            RETVALUE(RWOULDBLOCK);
         }
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, cmInetSendMsg() failed on line: %d, \n\
                 error(%d) \n", __FILE__, __LINE__, INET_ERR_CODE);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         /*  Check if connection was closed by the peer */
         if ((INET_ERR_CODE == ERR_PIPE) ||
             (INET_ERR_CODE == ERR_CONNREFUSED) ||
             (INET_ERR_CODE == ERR_CONNABORTED))
         {
            *len = 0;
            RETVALUE(RCLOSED);
         }
         RETVALUE(RFAILED);
      }

      /* Check if the entire message could be sent */
      if (*len < msgLen)
      {
         if (retVal != RNA)
            RETVALUE(RWOULDBLOCK);
         /* The first *len bytes have been sent. Try and send the rest of
          * the message */
         unSentLen -= ret;
      }
      else
         sentMsg = TRUE;

   } while ((retVal == RNA) && (sentMsg == FALSE));
#endif /* WIN32 | CMINETFLATBUF */
   
   RETVALUE(ROK);

} /* end of cmInetSendMsg */


/* added new functions for IPv6 extension headers */
#ifdef IPV6_OPTS_SUPPORTED
#ifdef LOCAL_INTF
/*
*
*      Fun:   cmInet6BuildSendPktinfo
*
*      Desc:  This function inserts src address (into ancillary data) which 
*             will be used as the src addr in outgoing IP packet when sending
*             that packet using sendmsg()function.
*
*      Ret:   ROK   
*
*      Notes:  
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6BuildSendPktinfo
(
CmInetIpAddr6 *srcAddr, /* src ip addr to set on outgoing packet */
U8  *cmsgBuf,   /* flat buffer where to build ext hdrs */
U32 *curMsgIdx, /* idx in cmsgBuf where HBH/Dest ext hdr ends */
U8   protType   /* whether IPv4/IPv6 socket */
)
#else
PRIVATE S16 cmInet6BuildSendPktinfo(srcAddr, cmsgBuf, curMsgIdx, protType)
CmInetIpAddr6 *srcAddr; /* src ip addr to set on outgoing packet */
U8  *cmsgBuf;   /* flat buffer where to build ext hdrs */
U32 *curMsgIdx; /* idx in cmsgBuf where HBH/Dest ext hdr ends */
U8   protType;  /* whether IPv4/IPv6 socket */
#endif /* ANSI */
{
   struct cmsghdr *tempHdr;
   struct in6_pktinfo *ipv6Pktinfo;
   struct in6_addr lpBkAddr;
   U8     len;

   TRC2(cmInet6BuildSendPktinfo)
   
   len = 0;

   lpBkAddr = in6addr_loopback;
   
  /* cmsghdr struc will appear before data in the ancillary data object. 
   * So put cmsghdr struc in flat buffer first. */

  /* cmsghdr struc points to flat buffer's starting address */
   tempHdr = (struct cmsghdr *)cmsgBuf;  

   /* fill up level & type of cmsghdr structure */
   if (protType == AF_INET6)
   {   
      tempHdr->cmsg_level = IPPROTO_IPV6;
      tempHdr->cmsg_type = IPV6_PKTINFO;
   }
#ifdef CMINETDBG   
   else if(protType == AF_INET)
   {
      sprintf(prntBuf, "Invalid socket type in cmInet6BuildPktinfo()\n");
      SPrint(prntBuf);
 
   }
#endif
   /* skip length of cmsghdr structure - 12 bytes */
   len += sizeof(struct cmsghdr); 

   if(protType == AF_INET6)
      ipv6Pktinfo = (struct in6_pktinfo *)(cmsgBuf + len);
#ifdef CMINETDBG   
   else
   {
     sprintf(prntBuf, "Invalid socket type in cmInet6BuildPktinfo()\n");
     SPrint(prntBuf);
   }
#endif

   /* insert the hoplimit. This will override the kernel's
    * default hoplimit value */
   if(protType == AF_INET6)
   {  
      /* store ipv6 src addr */ 
      cmMemcpy((U8 *)&(ipv6Pktinfo->ipi6_addr), (U8 *)srcAddr, 16);
      len += 16;
      
      /* store interface index */
      /* 0 is invalid intf indx it tells kernel to chose any intf it likes to
       * send this pkt. if we use nozero intf indx then kernel will send this
       * pkt only through that intf */
      ipv6Pktinfo->ipi6_ifindex = 0;
      len += sizeof(int);
   }   
#ifdef CMINETDBG   
   else if(protType == AF_INET)
   {
      sprintf(prntBuf, "Invalid socket type in cmInet6BuildPktinfo()\n");
      SPrint(prntBuf);
   }
#endif

   /* fill up the length of cmsghdr structure */
   tempHdr->cmsg_len = len;  
   *curMsgIdx += len;

   RETVALUE(ROK);

}/* end of cmInet6BuildSendPktinfo */ 
#endif /* LOCAL_INTF */


#ifdef SS_LINUX
/*
*
*      Fun:   cmInetBuildSendHoplimit
*
*      Desc:  This function inserts hoplimit value to be sent out by ancillary
*             data by calling sendmsg()function.
*
*      Ret:   ROK   
*
*      Notes:  
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInetBuildSendHoplimit
(
U32   hoplimit,  /* the hoplimit value to be set on outgoing packet */
U8  *cmsgBuf,   /* flat buffer where to build ext hdrs */
U32 *curMsgIdx  /* idx in cmsgBuf where HBH/Dest ext hdr ends */
)
#else
PRIVATE S16 cmInetBuildSendHoplimit(hoplimit, cmsgBuf, curMsgIdx)
U32  hoplimit;  /* the hoplimit value to be sent on outgoing packet */
U8  *cmsgBuf;   /* flat buffer where to build ext hdrs */
U32 *curMsgIdx; /* idx in cmsgBuf where HBH/Dest ext hdr ends */
#endif /* ANSI */
{
   struct cmsghdr *tempHdr; 
   U8    len;

   TRC2(cmInetBuildSendHoplimit)
   
   len = 0;

  /* cmsghdr struc will appear before data in the ancillary data object. 
   * So put cmsghdr struc in flat buffer first. */

   /* cmsghdr struc points to flat buffer's starting address */
   tempHdr = (struct cmsghdr *)cmsgBuf;  

   /* fill up level & type of cmsghdr structure */
   tempHdr->cmsg_level = IPPROTO_IPV6;
   tempHdr->cmsg_type = IPV6_HOPLIMIT;
   
   /* skip cmsghdr struc (length of cmsghdr structure) */
   len += sizeof(struct cmsghdr); 

   /* insert the hoplimit. This will override the kernel's
    * default hoplimit value */ 
   *(cmsgBuf + len) = hoplimit;
   len += sizeof(hoplimit);
   
   /* fill up the length of cmsghdr structure */
   tempHdr->cmsg_len = len;
   *curMsgIdx += len;

   RETVALUE(ROK);
} /* end of cmInetBuildSendHoplimit  */
#endif /* SS_LINUX */


/*
*
*      Fun:   cmInet6BuildSendHBHOpts
*
*      Desc:  This function builds the HopByHop option which will be put
*             in the data portion of the ancillary data object. To build  
*             the HopByHop option this function takes an array of 
*             individual HopByHop option and fill them in a flat buffer.
*             cmsghdr struc always appear before HopBYHop Options, Dest 
*             Options and Route header option.
*
*             The address of the flat Buffer *cmsgBuf is passed to this
*             function from cmInetSendMsg. This buffer will have all extension
*             headers. This buffer is passed as ancillary data by sendmsg()
*     
*      Ret:   
*
*      Notes: This function will also be used for Destination options 
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6BuildSendHBHOpts
(
CmInetIpv6HBHHdrArr *hbhOptsArr,/* IPv6 extensions headers HBH/Dest opts */
U8 *cmsgBuf,                    /* flat buffer where to build ext hdrs */
U32 *curMsgIdx,                 /* idx in cmsgBuf where HBH/Dest ext hdr ends */
U8 hdrId                        /* 0: HBH hdr, 1:Dest Hdr */
)
#else
PRIVATE S16 cmInet6BuildSendHBHOpts(hbhOptsArr, cmsgBuf, curMsgIdx, hdrId)
CmInetIpv6HBHHdrArr *hbhOptsArr;/* IPv6 extensions headers HBH/Dest opts */
U8 *cmsgBuf;                    /* flat buffer where to build ext hdrs */
U32 *curMsgIdx;                 /* idx in cmsgBuf where HBH/Dest ext hdr ends */
U8 hdrId;                       /* 0: HBH hdr, 1:Dest Hdr */
#endif
{
   struct cmsghdr *tempHdr; 
   U8    len;
   U8    optsIdx;

   TRC2(cmInet6BuildSendHBHOpts)
   
   len = 0;
   optsIdx = 0;

  /* cmsghdr struc will appear before data in the ancillary data object. 
   * So put cmsghdr struc in flat buffer first. */

  /* cmsghdr struc points to flat buffer's starting address */
   tempHdr = (struct cmsghdr *)cmsgBuf;  

   /* fill up level & type of cmsghdr structure */
   if (hdrId == 0)
   {   
      tempHdr->cmsg_level = IPPROTO_IPV6;
      tempHdr->cmsg_type = IPV6_HOPOPTS;
   }
   else if (hdrId == 1)
   {
      tempHdr->cmsg_level = IPPROTO_IPV6;
      tempHdr->cmsg_type = IPV6_DSTOPTS;
   }
   
   /* skip cmsghdr struc (length of cmsghdr structure) */
   len += (sizeof(tempHdr->cmsg_level) + sizeof(tempHdr->cmsg_len) + 
          sizeof(tempHdr->cmsg_type));

   /* Next Hdr: will be fill up accordingly by Kernel */ 
   *(cmsgBuf + len) = 0x00;
   len += 1;
                     
   /* Header Ext Length: will be fill up by us. In units of 8-byte excluding 
    * first 8 bytes starting from Next Header field. */       
   *(cmsgBuf + len) = 0x00; 
   len += 1;

   /* fillup all HBH/dest options' TLV. Here, we assume that all the HBH/dest
    * options are packed inside 1 HBH option header. */      
   for (optsIdx = 0; optsIdx < hbhOptsArr->numHBHOpts; 
        optsIdx ++)
   {
      /* Copy the TLV into cmsgBuf data portion */
      /* copy type field of every HBH/dest option */
      *(cmsgBuf + len) = hbhOptsArr->hbhOpts[optsIdx].type;
      len += sizeof(hbhOptsArr->hbhOpts[optsIdx].type);

      /* copy length field of every HBH/dest option */
      *(cmsgBuf + len) = hbhOptsArr->hbhOpts[optsIdx].length; 
      len += sizeof(hbhOptsArr->hbhOpts[optsIdx].length);         

      /* copy all value bytes of current HBH/dest option to the flat buffer */
      cmMemcpy((U8 *)(cmsgBuf + len),
                 (U8 *)(hbhOptsArr->hbhOpts[optsIdx].value), 
                 hbhOptsArr->hbhOpts[optsIdx].length);
      len += hbhOptsArr->hbhOpts[optsIdx].length; 
   }

   /* cuMsgIdx will have the total length of HBH options array */
   /* add this length to the length of cmsgHdr struc */

   /* Padding: Different header has different padding requirement(xn+y). For
    * HBH Router Alert we need 2 bytes of padding. As this same function is
    * used for Destination option also and there is no option for it is yet
    * proposed, we are passing padN options - 6 bytes to make the Dest Option
    * hdr a multiple of 8 bytes. */
   
   /* HBH: padN of 2 bytes needed for Router Alert */
   /* This logic is present currently to support router alert which is the 
    * only supported HBH option today. For other, generic method needed */ 
   if (hdrId == 0)
   {       
      *(cmsgBuf + len) = 0x01;
      len += 1;
      *(cmsgBuf + len) = 0x00;
      len += 1;
   }
  
   /* fill up the length of cmsghdr structure */
   tempHdr->cmsg_len = len;
   *curMsgIdx += len;

   RETVALUE(ROK);    
} /* end of cmInet6BuildSendHBHOpts */


/*
*
*      Fun:   cmInet6BuildSendRouteOpts
*
*      Desc:  This function transfers bytes from the Route hdr array to the 
*             flat buffer. First the top cmsghdr structure will be filled in
*             the flat buffer, then route hdr type 0 will be added after 
*             cmsghdr struc in the flat buffer. Then all IPV6 addresses will
*             be filled up.
*     
*      Ret:   
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6BuildSendRouteOpts
(
CmInetIpv6RtHdr *rtOptsArr,  /* IPv6 destination options array */
U8 *cmsgBuf,                 /* flat buffer where to build ext hdrs */
U32 *curMsgIdx               /* idx in cmsgBuf where to start building RT hdr */
)
#else
PRIVATE S16 cmInet6BuildSendRouteOpts(rtOptsArr, cmsgBuf, curMsgIdx)
CmInetIpv6RtHdr *rtOptsArr;  /* IPv6 destination options array */
U8 *cmsgBuf;                 /* flat buffer where to build ext hdrs */
U32 *curMsgIdx;              /* idx in cmsgBuf where to start building RT hd */
#endif /* ANSI */
{
   struct cmsghdr *tempHdr;
   CmInetIpv6RtHdr0 *tempRtHdr;
   U8    len; 
   U8    addrIdx;

   TRC2(cmInet6BuildSendRouteOpts);
   
   len = 0;
   addrIdx = 0;

  /* cmsghdr struc will appear before data in the ancillary data object. 
  * So put cmsghdr struc in flat buffer first */

  /* cmsghdr struc points to flat buffer */
   tempHdr = (struct cmsghdr *)(cmsgBuf); 

   tempHdr->cmsg_level = IPPROTO_IPV6;
   tempHdr->cmsg_type = IPV6_RTHDR;

  /* skip cmsghdr structure */
   len += sizeof(struct cmsghdr);
  
   /* we know the total size of Route hdr if we know the num of ipv6 addrs */
   tempHdr->cmsg_len = len + sizeof(CmInetIpv6RtHdr0)
                   + rtOptsArr->numAddrs * sizeof(CmInetIpAddr6);
   
   /* attach route hdr type 0 after cmsghdr structure */
   tempRtHdr = (CmInetIpv6RtHdr0 *)(cmsgBuf + len);

   /* fill up fields of route hdr type 0 */

   /* will be filled up by Kernel */
   tempRtHdr->ip6r0_nextHdr = 0x00;  
   
   tempRtHdr->ip6r0_hdrExtLen = (2 * rtOptsArr->numAddrs); 

   /* only type supported today */
   tempRtHdr->ip6r0_type = 0x00;        

   tempRtHdr->ip6r0_segLeft = rtOptsArr->numAddrs; 

   /* Note: rfc 2292(1998) mentions 1 reserve byte & 3 strict/loose bytes 
    * restricting total 23 ipv6 addresses can be added to the route header.
    * But rfc 2292(2002) mentions all 4 bytes are reserved which allows 
    * as many ipv6 addresses as wishes to be added to the route header */
   
   tempRtHdr->ip6r0_resrvAndSLmap = rtOptsArr->slMap;

   /* move pointer in the flat buffer to the end of this structure */
   len +=  sizeof(CmInetIpv6RtHdr0); 
   
   /* fill up all IPV6 addresses from rtOptsArr in the flat buffer */
   for (addrIdx = 0; addrIdx < rtOptsArr->numAddrs; addrIdx++)
   {   
     cmMemcpy((U8 *)(cmsgBuf + len),
              (U8 *)(rtOptsArr->ipv6Addrs[addrIdx]), 16);
     len += 16;
   }
   
   *curMsgIdx += len;  
   RETVALUE(ROK);
} /* end of cmInet6BuildSendRouteOpts */


/*
*
*      Fun:   cmInet6BuildRecvHopOptsArr
*
*      Desc:  This function fills up the HopByHop Array of ipHdrParam from 
*             the ancillary data received through recvmsg() call. The memory
*             to hold the extension headers is allocated here. All received 
*             ext hdr info will be passed to upper user as ipHdrParam.
*     
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6BuildRecvHopOptsArr
(
U8 *cmsgData,                    /* flat buffer where to build ext hdrs */
U32 hbhDataLen,                  /* byte len of cmsghdr + hbh ancil data */
CmInetIpv6HBHHdrArr *hbhOptsArr, /* IPv6 extensions headers */
U8 hdrId,                        /* 0: HBH, 1: DEST */
CmInetMemInfo   *info            /* Memory information */
)
#else
PRIVATE S16 cmInet6BuildRecvHopOptsArr(cmsgData, hbhDataLen, hbhOptsArr, hdrId, 
                                      info)
U8 *cmsgData;                    /* flat buffer where to build ext hdrs  */
U32 hbhDataLen;                  /* byte len of cmsghdr + hbh ancil data */
CmInetIpv6HBHHdrArr *hbhOptsArr; /* IPv6 extensions headers */
U8 hdrId;                        /* 0: HBH, 1: DEST */
CmInetMemInfo   *info;           /* Memory information */
#endif /* ANSI */
{
   U32 curDataIdx;       /* to keep track where we are in the hbh Data */
   U8  optsIdx;          /* how many hbh opts present in data */
   U8  numOpts;          /* number of hbh opts present in data */
   U8  tempLen;
   U8  tempType;
   S16 ret;
      
   TRC2(cmInet6BuildRecvHopOptsArr)
   
   /* get length of actual hbh ancillary data */
   hbhDataLen -= sizeof(struct cmsghdr); 

   curDataIdx = 0;                
   optsIdx = 0;
   numOpts = 0;

   /* skip Next Hdr byte & Hdr Ext Length byte */
   curDataIdx += 2;               

   /* First find out how many hop-by-hop headers we need to allocate */
   for (;;)   
   {
      /* break when all HBH data is copied to hbhOptsArr */
      if (curDataIdx >= hbhDataLen)
         break;   

      numOpts += 1;
      
      /* get type */ 
      tempType = *(U8 *)(cmsgData + curDataIdx);
      curDataIdx += 1;               

      /* take care of pad1 option */
      if (tempType == 0) 
      {
         /* not considering the pad1 as valid option */
         numOpts -= 1; 
         continue;
      }

      /* get length */
      tempLen = *(U8 *)(cmsgData + curDataIdx);

      /* 1 is to skip length. tempLen to skip the value field */
      curDataIdx += (1 + tempLen);
      
      /* considering the padN as valid option for Dest Opt Hdr!!! As this is
       * the "only" valid option today. Ignore for HBH hdr */
      if (hdrId != 1)
         if (tempType == 1) 
            numOpts -= 1;
   }

   /* allocate mem needed to hold all HBH/Dest options */
   ret = SGetSBuf(info->region, info->pool, 
                  (Data **)&hbhOptsArr->hbhOpts, 
                  (Size)((sizeof(CmInetIpv6HBHHdr)) * numOpts)); 
   if (ret != ROK)
   {
#ifdef CMINETDBG      
      sprintf(prntBuf, "SGetSBuf failure 1 in cmInet6BuildRecvHopOptsArr\n");
      SPrint(prntBuf);
#endif /* CMINETDBG */     
      RETVALUE(ROUTRES);
   }   

   curDataIdx = 0;                
   optsIdx = 0;
   
   /* skip Next Hdr byte & Hdr Ext Length byte */
   curDataIdx += 2;               

   hbhOptsArr->numHBHOpts = numOpts;
   
   /* fill up HBH/dest opt array from recvd ancillary data */
   for (;;)   
   {
      /* break when all HBH data is copied to hbhOptsArr */
      if (curDataIdx >= hbhDataLen)
         break;   
     
      /* only copy Router Alert HBH option part which has type 5. Otherwise,
       * skip it when it is a PAD1, PADN or Jumbogram option for HBH. But 
       * consider padN as valid option for dest opt hdr. */
   
      /* get the type of current HBH/dest option */
      tempType = *(cmsgData + curDataIdx);
      curDataIdx += 1;

      /* ignore PAD1 for both HBH/dest by skipping to next option */
      if (tempType == 0)
         continue; 
      
      /* calculate how much to skip for padN in case of HBH */
      if (hdrId != 1)
      {   
         if (tempType == 1)
         {
            /* get the length field of padN option */
            tempLen = *(cmsgData + curDataIdx);
            curDataIdx += 1;
            
            /* move pointer forward to skip value field */
            curDataIdx += tempLen;
            continue;
         }
      } 
      hbhOptsArr->hbhOpts[optsIdx].type = tempType; 

      /* copy the length */
      hbhOptsArr->hbhOpts[optsIdx].length = *(cmsgData + curDataIdx);
      curDataIdx += 1;
 
      /* take care of PADN = 2 when value field empty. We also don't need
       * to allocate memory for empty value field */
      if (hbhOptsArr->hbhOpts[optsIdx].length == 0)
         hbhOptsArr->hbhOpts[optsIdx].value = NULLP;
      else
      {   
         /* take care of all other options having valid value field
          * such as Router Alert, PADN >= 3 bytes and Jumbo */
         ret = SGetSBuf(info->region, info->pool, 
                     (Data **)&hbhOptsArr->hbhOpts[optsIdx].value, 
                     (Size)hbhOptsArr->hbhOpts[optsIdx].length);
         if (ret != ROK)
         {
#ifdef CMINETDBG            
            sprintf(prntBuf, "SGetSBuf failure 2 cmInet6BuildRecvHopOptsArr\n");
            SPrint(prntBuf);
#endif /* CMINETDBG */           
            /* now go inside every separate HBH option and free the memory
             * allocated for its value field */
            for (; optsIdx > 0; optsIdx --)
            {
               if (hbhOptsArr->hbhOpts[optsIdx - 1].value != NULLP)
               {
#ifdef CMINETDBG                  
                  sprintf(prntBuf, "SPutSBuf call 1 in BuildRecvHopOptsArr\n");
                  SPrint(prntBuf);
#endif /* CMINETDBG */                  
                  SPutSBuf(info->region, info->pool, 
                           (Data *)hbhOptsArr->hbhOpts[optsIdx - 1].value,
                           (Size)hbhOptsArr->hbhOpts[optsIdx - 1].length);
               }
            }
            /* clean up all CmInetIpv6HBHHdr structures allocated for all
             * arrived HBH options OR numOpts CmInetIpv6HBHHdr structures
             * allocated after counting numOpts */
#ifdef CMINETDBG                                     
            sprintf(prntBuf, "SPutSBuf call 2 in BuildRecvHopOptsArr\n");
            SPrint(prntBuf);
#endif /* CMINETDBG */            
            SPutSBuf(info->region, info->pool, 
               (Data *)hbhOptsArr->hbhOpts, numOpts * sizeof(CmInetIpv6HBHHdr));
            hbhOptsArr->numHBHOpts = 0;
            hbhOptsArr->hbhOpts = NULLP;
            RETVALUE(ROUTRES);
         }
         /* copy the value bytes */
         cmMemcpy((U8 *)hbhOptsArr->hbhOpts[optsIdx].value, 
                  (U8 *)(cmsgData + curDataIdx),
                  hbhOptsArr->hbhOpts[optsIdx].length);
         curDataIdx += hbhOptsArr->hbhOpts[optsIdx].length;      
      }  

      /* get next option */
      optsIdx++; 
   }
   RETVALUE(ROK);
} /* end of cmInet6BuildRecvHopOptsArr() */


/*
*
*      Fun:   cmInet6BuildRecvRtHdr
*
*      Desc:  This function fills up the Route Header in the cmInetIpv6HdrParm
*             from the recvd ancillary data from recvmsg system call.
*     
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6BuildRecvRtHdr
(
U8 *cmsgData,              /* flat buffer where to build Route hdr */ 
U32 rtDataLen,             /* byte len of cmsghdr struc+rtHdr ancil data */
CmInetIpv6RtHdr0 *rtHdr0,  /* rtHeader0 struct that precedes IPV6 addrss */
CmInetIpv6RtHdr *rtOptsArr,/* IPv6 extensions headers */
CmInetMemInfo   *info      /* Memory information */
)
#else
PRIVATE S16 cmInet6BuildRecvRtHdr(cmsgData, rtDataLen, rtHdr0, rtOptsArr, info)
U8 *cmsgData;              /* flat buffer where to build Route hdr */
U32 rtDataLen;             /* byte len of cmsghdr struc+rtHdr ancil data */
CmInetIpv6RtHdr0 *rtHdr0;  /* rtHeader0 struct that precedes IPV6 addrss */
CmInetIpv6RtHdr *rtOptsArr;/* IPv6 extensions headers */
CmInetMemInfo   *info;     /* Memory information */
#endif /* ANSI */
{
   U32 curDataIdx;         /* to keep track where we are in hbh Data */
   U8 i;                   /* loop counter */
   S16 ret;                /* temporary return value */
   
   TRC2(cmInet6BuildRecvRtHdr)
   
   /* byte len of actual rtHdr ancil data */
   rtDataLen -= sizeof(struct cmsghdr);

   /* start from beginning */
   curDataIdx = 0;                

   /* copy next header byte */
   rtHdr0->ip6r0_nextHdr = *(cmsgData + curDataIdx);
   curDataIdx += 1;  

   /* copy header extension length byte */
   rtHdr0->ip6r0_hdrExtLen = *(cmsgData + curDataIdx);
   curDataIdx += 1;

   /* copy type byte (always 0) */
   rtHdr0->ip6r0_type = 0x00;
   curDataIdx += 1;
      
   /* copy segment left byte */
   rtHdr0->ip6r0_segLeft = *(cmsgData + curDataIdx);
   curDataIdx += 1;

   /* copy 1 reserve byte + 3 strict/loose bytes */  
   cmMemcpy((U8 *)(&rtOptsArr->slMap),
            (U8 *)(cmsgData + curDataIdx), 4);
   curDataIdx += 4;
  
   /* also save reserv byte + 3 sl bytes to rtHdro struc */
   rtHdr0->ip6r0_resrvAndSLmap = rtOptsArr->slMap;
      
   /* subtract 8 bytes for Next Hdr, Hdr Ext Len, .... + SL bit map */
   rtOptsArr->numAddrs = (rtDataLen - 8)/16;

   ret = SGetSBuf(info->region, info->pool, 
                  (Data **)&rtOptsArr->ipv6Addrs, 
                  (Size)rtOptsArr->numAddrs * 16);
   if (ret != ROK)
   {
#ifdef CMINETDBG      
      sprintf(prntBuf, "SGetSBuf failure 1 in cmInet6BuildRecvRtHdr\n");
      SPrint(prntBuf);
#endif /* CMINETDBG */     
      RETVALUE(ROUTRES);
   }

   /* copy all the ipv6 addresses */
   for(i=0; i < rtOptsArr->numAddrs; i++)
   {
      cmMemcpy((U8 *)(rtOptsArr->ipv6Addrs[i]),
               (U8 *)(cmsgData + curDataIdx), 16);
      curDataIdx += 16;
   }

   RETVALUE(ROK);
} /* end of cmInet6BuildRecvRtHdr() */


/*
*
*      Fun:   cmInet6GetHopLimitValue
*
*      Desc:  This function extracts the hop limit value(ttl) of from the 
*             ancillary data received through recvmsg() call. Then this
*             hoplimit value will be passed to upper user as ipHdrParam.
*     
*      Ret:   ROK     - successful
*
*      Notes: None
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PRIVATE S16 cmInet6GetHopLimitValue
(
U8 *cmsgData,        /* flat buffer where to build ext hdrs */
U32 hopLimitDataLen, /* byte len of cmsghdr + hbh ancil data */
CmInetIpv6HdrParm *ipv6HdrParam /* ipv6 header parameters */ 
)
#else
PRIVATE S16 cmInet6GetHopLimitValue(cmsgData, hopLimitDataLen, ipv6HdrParam)
U8 *cmsgData;         /* flat buffer where to build ext hdrs */
U32 hopLimitDataLen;  /* byte len of cmsghdr + hbh ancil data */
CmInetIpv6HdrParm *ipv6HdrParam; /* ipv6 header parameters */
#endif /* ANSI */
{
   U16 curDataIdx;       /* to keep track where we are in the ancillary Data */
   U32 *hopLimitValue;   /* ttl/hoplimit value */
   
   hopLimitValue = NULL;
   curDataIdx = 0;                

   /* get length of actual hbh ancillary data */
   hopLimitDataLen -= sizeof(struct cmsghdr);

   /* go to the first byte of hop limit which present after cmsghdr struc */
   curDataIdx += sizeof(struct cmsghdr);

   /* mark that hoplimit(ttl) is present */
   ipv6HdrParam->ttl.pres = TRUE;

   /* the first byte will be the HopLimit value */
   hopLimitValue = (U32 *)(cmsgData);
   ipv6HdrParam->ttl.val = (U8)(*hopLimitValue);

   RETVALUE(ROK);
 }
#endif /* IPV6_OPTS_SUPPORTED */


/*
*
*      Fun:   cmInetRecvMsg
*
*      Desc:  Reads data from a socket into a message. 
*             The buffers for the message  are allocated within the 
*             cmInetRead() function from the pool and region Id set in the 
*             info struct.  
*             If the number of octets given by the paramter len is not 
*             available the function immediately returns with RKDNA. 
*             If the len parameter is set to CM_INET_READ_ANY, the currently 
*             available data is read. 
*             Values for flag parameter:
*  
*             CM_INET_NO_FLAG  - no additional control flag
*             CM_INET_MSG_PEEK - do not destroy data on receive buffer
*
*      Ret:   ROK     - successful
*             ROKDNA  - ok, data not available
*             RCLOSED - connection closed by peer
*             ROUTRES - failed, out of resources
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
PUBLIC S16 cmInetRecvMsg
(
CmInetFd        *sockFd,        /* socket file descriptor */ 
CmInetAddr      *fromAddr,      /* sender Internet address/port */ 
CmInetMemInfo   *info,          /* buffer allocation info */
Buffer         **mPtr,          /* received buffer structure */
MsgLen          *len,           /* number of octets to read */ 
/*  added for IPv6 */
#ifdef IPV6_OPTS_SUPPORTED
CmInetIpHdrParm *ipHdrParams,    /* IPv6 extensions headers */
#endif /* IPV6_OPTS_SUPPORTED */
#ifdef LOCAL_INTF
CmInetLocalInf  *localIf,       /* local interface on which pkt was recvd */
#endif /* LOCAL_INTF */ 
S32              flags          /* additional control flags */
)
#else
/*  added for IPv6 */
#ifdef IPV6_OPTS_SUPPORTED
#ifdef LOCAL_INTF
PUBLIC S16 cmInetRecvMsg(sockFd, fromAddr, info, mPtr, len,
                         ipHdrParams, localIf, flags)
CmInetFd        *sockFd;        /* socket file descriptor */ 
CmInetAddr      *fromAddr;      /* sender Internet address/port */ 
CmInetMemInfo   *info;          /* buffer allocation info */
Buffer         **mPtr;          /* received buffer structure */
MsgLen          *len;           /* number of octets to read */ 
CmInetIpHdrParm *ipHdrParams;   /* IPv6 extensions headers */
CmInetLocalInf  *localIf;       /* local interface on which pkt was recvd */
S32              flags;         /* additional control flags */
#else
PUBLIC S16 cmInetRecvMsg(sockFd, fromAddr, info, mPtr, len, ipHdrParams, flags)
CmInetFd        *sockFd;        /* socket file descriptor */ 
CmInetAddr      *fromAddr;      /* sender Internet address/port */ 
CmInetMemInfo   *info;          /* buffer allocation info */
Buffer         **mPtr;          /* received buffer structure */
MsgLen          *len;           /* number of octets to read */ 
CmInetIpHdrParm *ipHdrParams;   /* IPv6 extensions headers */
S32              flags;         /* additional control flags */
#endif /* LOCAL_INTF */
#else
#ifdef LOCAL_INTF
PUBLIC S16 cmInetRecvMsg(sockFd, fromAddr, info, mPtr, len, localIf, flags)
CmInetFd        *sockFd;        /* socket file descriptor */ 
CmInetAddr      *fromAddr;      /* sender Internet address/port */ 
CmInetMemInfo   *info;          /* buffer allocation info */
Buffer         **mPtr;          /* received buffer structure */
MsgLen          *len;           /* number of octets to read */ 
CmInetLocalInf  *localIf;       /* local interface on which pkt was recvd */
S32              flags;         /* additional control flags */
#else
PUBLIC S16 cmInetRecvMsg(sockFd, fromAddr, info, mPtr, len, flags)
CmInetFd        *sockFd;        /* socket file descriptor */ 
CmInetAddr      *fromAddr;      /* sender Internet address/port */ 
CmInetMemInfo   *info;          /* buffer allocation info */
Buffer         **mPtr;          /* received buffer structure */
MsgLen          *len;           /* number of octets to read */ 
S32              flags;         /* additional control flags */
#endif /* LOCAL_INTF */
#endif /* IPV6_OPTS_SUPPORTED */
#endif /* ANSI */
{
#if (defined(WIN32) || defined(CMINETFLATBUF))
   S32           ret;            /* temporary return value */
   U32           pendLen;        /* pending data length */
   S32           recvLen;        /* number of received octets by recvmsg() */
   MsgLen        bufLen;         /* entire number of received octets */
   MsgLen        curLen;         /* current number of octets in buffer */ 
   Data         *recvBuf;        /* receive buffer */
   Data         *bufPtr;         /* current buffer position */   
   Buffer       *mBuf;           /* received message */ 
   U32           remAddrLen;     /* length of remote address */
   struct sockaddr_in  *remAddr;    /* remote Internet address */       
#ifdef IPV6_SUPPORTED 
   struct sockaddr_in6  *remAddr6;  /* remote Internet address */       
   struct sockaddr_in6 remSockAddr; /* to get packet's source IP address */
#else
   CmInetSockAddr  remSockAddr;     /* to get packet's source IP address */
#endif /* IPV6_SUPPORTED */
#else
   S32           ret;            /* temporary return value */
   S16           i;              /* index */
   U32           pendLen;        /* pending data length */
   S32           numBuf;         /* number of allocated dBufs */
   S32           recvLen;        /* number of received octets by recvmsg() */
   MsgLen        bufLen;         /* entire number of received octets */
   struct msghdr msg;            /* message header */ 
   Buffer       *tempMsg;        /* temporary message */
   CmInetIovec  rxArr[CM_INET_MAX_DBUF]; /* dynamic gather array */
   Buffer      **dBufs;          /* dynamic array with allocated dBufs */
   S16           numDBufs;       /* number of allocated dBufs */
   struct sockaddr_in *remAddr;  /* remote Internet address */       
#ifdef IPV6_SUPPORTED 
   struct sockaddr_in6 *remAddr6;  /* remote Internet address */       
   struct sockaddr_in6 remSockAddr;/* to get packet's source IP address */
   /* added for IPv6 ext headers support */
#ifdef IPV6_OPTS_SUPPORTED
   CmInetIpv6RtHdr0     rtHdr0;          /* type 0 route header */      
#endif /* IPV6_OPTS_SUPPORTED */
   
#ifdef LOCAL_INTF
   struct in6_pktinfo  *pkt6Info;        /* IPv6 IP_PKTINFO */
#endif /* LOCAL_INTF */   
   
#if (defined(SS_LINUX) || defined(_XPG4_2))
   U8                   ancillData[CM_INET_IPV6_ANCIL_DATA];
                                         /* from stack for IPv6 ancill data */
#endif
#else
   CmInetSockAddr       remSockAddr;     /* to get packet's src IP address */
#if (defined(SS_LINUX) || defined(_XPG4_2))
   U8                   ancillData[CM_INET_IPV4_ANCIL_DATA];
                                         /* from stack for IPv4 ancill data */
#endif
#endif /* IPV6_SUPPORTED */
   /* added new definitions */
   Bool                 allocFlatBuf;    /* allocate a flat buffer */
   Data                 *recvBuf;        /* receive buffer */
#ifdef SS_LINUX
#ifdef LOCAL_INTF
   struct in_pktinfo    *pkt4Info;       /* IPv4 IP_PKTINFO */
#endif
#endif /* SS_LINUX */
#if (defined(IPV6_OPTS_SUPPORTED) || defined(LOCAL_INTF))   
   struct               cmsghdr *cmsgptr;/* pointer to struct cmsghdr */
#endif
#endif /* WIN32 | CMINETFLATBUF */
   /* used by getsockopt */
   U32          errValue;                /* error value */
   U32          optLen;                  /* option length */
 
   TRC2(cmInetRecvMsg)

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (info == NULLP) || (mPtr == NULLP) || (len == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   *mPtr = NULLP;

#if (defined(WIN32) || defined(CMINETFLATBUF))
   remAddr = NULLP;  
#ifdef IPV6_SUPPORTED 
   remAddr6 = NULLP;
#endif /* IPV6_SUPPORTED */   
#else
#ifdef IPV6_SUPPORTED 
   remAddr = NULLP;
   remAddr6 = NULLP;
#endif /* IPV6_SUPPORTED */  

#if (defined(SS_LINUX) || defined(_XPG4_2))
   cmMemset((U8*)ancillData, 0, sizeof(ancillData));
#endif /* SS_LINUX || _XPG4_2 */

#endif /* (WIN32 | CMINETFLATBUF) */

   /* clear the structure */   
   cmMemset((U8*)&remSockAddr, 0, sizeof(remSockAddr));

   /* get number of pending data */
   /* removed 3rd arg memInfo. MemInfo is no longer
      needed as we call ioctl for all sockets */
   ret = cmInetGetNumRead(sockFd, &pendLen);
   if (ret != ROK)
   {
      /* ret may be RFAILED or ROUTRES */
      RETVALUE(ret);
   }

   /* check if connection got closed */
   if (pendLen == 0)
   {
      /* removed second call to select */
      /* if socket is not TCP return ROKDNA */
      if (sockFd->type == CM_INET_STREAM)
         RETVALUE(RCLOSED);
      else
      /* clear error if there is any, because if there is internal error
       * here it will cause infinite loop in TUCL */
      {
         errValue = 0;
         optLen = sizeof(int);
#ifdef UNIX
         ret = getsockopt(sockFd->fd, SOL_SOCKET, SO_ERROR,
                          (char*)&errValue, (socklen_t *)&optLen);
#else
#if (defined(SS_VW) || defined(SS_PS))
         ret = getsockopt(sockFd->fd, SOL_SOCKET, SO_ERROR,
                          (char*)&errValue, (int *)&optLen);
#else
#ifndef SS_WINCE
         ret = getsockopt(sockFd->fd, SOL_SOCKET, SO_ERROR,
                          (char*)&errValue, (int *)&optLen);
#endif /* SS_WINCE */
#endif /* SS_VW */
#endif /* SS_LINUX */
         if (ret == INET_ERR)
         {
#ifdef CMINETDBG
            sprintf(prntBuf,"File: %s, cmInetRecvMsg() failed on line: %d\n\
                    error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
            SPrint(prntBuf);            
#endif /* CMINETDBG */
            RETVALUE(RFAILED);
         }
         else
            RETVALUE(ROKDNA);
      }
   }

   /* check if there are enough pending data to read */
   if ((*len == CM_INET_READ_ANY) || ((U32)*len <= pendLen))
   {
      if (*len == CM_INET_READ_ANY)
      {
         /* added check for TCP/UDP socket. Pending data length in 
            the socket recv buffer is determined by ioctl call in 
            cmInetGetNumRead. 
            For TCP it can't be > CM_INET_MAX_MSG_LEN. 
            For UDP it can't be > CM_INET_MAX_UDPRAW_MSGSIZE. */ 
         if (sockFd->type == CM_INET_STREAM) 
         {
            /* max message length is limited to control the memory usage */
            if (pendLen > CM_INET_MAX_MSG_LEN)
               pendLen = CM_INET_MAX_MSG_LEN;
         }
         else
         {
            if (pendLen > CM_INET_MAX_UDPRAW_MSGSIZE)
               pendLen = CM_INET_MAX_UDPRAW_MSGSIZE;
         }
         /* read all pending data */ 
         bufLen = pendLen;
         *len = pendLen; 
      }
      else
      {
         /* max message length is limited to control the memory usage */
         if (pendLen > CM_INET_MAX_MSG_LEN)
         {
            RETVALUE(RFAILED);
         }            
         /* read data length given by user */ 
         bufLen = *len;
      }

#if (defined(WIN32) || defined(CMINETFLATBUF))

      /* set destination Internet address structure */
      if (fromAddr != NULLP)
      {
         remAddrLen = sizeof(remSockAddr); 
      }
      else
      {
         remAddrLen = 0;
      }

      /* allocate flat receive buffer */
      ret = SGetSBuf(info->region, info->pool, &recvBuf, bufLen);
      if (ret != ROK)
      {
         RETVALUE(ROUTRES);
      }          
      curLen = bufLen;
      bufPtr = recvBuf;
      
      /* 
       * maybe needs more than one recvfrom() call to read an entire 
       * message from a stream socket (TCP)
       */
      while (curLen > 0)
      {
         /* added separate recvfrom calls different OS */

#if( defined(SS_VW) || defined(HPOS) || defined(SS_PS))
         if (remAddrLen)
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                                &remSockAddr, (int *)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                                NULLP, (int *)&remAddrLen);
#else         
#if ( defined(SUNOS) || defined(SS_LINUX))
         if (remAddrLen)
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                    (struct sockaddr *)&remSockAddr, (socklen_t *)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                                NULLP, (socklen_t *)&remAddrLen); 
#else
         if (remAddrLen)
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                                &remSockAddr, (S32 *)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd, (S8 *)bufPtr, curLen, 0, 
                                NULLP, (S32 *)&remAddrLen); 
                                
#endif /* defined(SUNOS) || defined(SS_LINUX) */
#endif /* defined(SS_VW) || defined(HPOS) || defined(SS_PS) */ 
                  
         if (recvLen == INET_ERR)
         {
            /* cleanup */
            /* moved cleanup here */
            SPutSBuf(info->region, info->pool, recvBuf, bufLen); 

            /*  added check ERR_WOULDBLOCK */
            if ((INET_ERR_CODE == ERR_AGAIN) ||
                (INET_ERR_CODE == ERR_WOULDBLOCK))
            {
               *len = 0;
               RETVALUE(ROKDNA);
            }
                                 

            /*  In Windows the recvfrom function fails
             *  with error code which maps to either WSAECONNABORTED. If
             *  this happens then cmInetRecvMsg must return RCLOSED */
            if ((INET_ERR_CODE == ERR_CONNABORTED) || 
                (INET_ERR_CODE == ERR_CONNRESET))
            {
               *len = 0;
               RETVALUE(RCLOSED);
            }

#ifdef CMINETDBG
            sprintf(prntBuf,"File: %s, cmInetRecvMsg() failed on line: %d\n\
                    error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
            SPrint(prntBuf);
#endif /* CMINETDBG */

            RETVALUE(RFAILED);
         } 
         curLen -= recvLen;
         bufPtr += recvLen;

         /* 
          * a message is always read atomically on a datagram socket,
          * therefore it's ok to read less than pending data!
          */
#ifdef CM_INET2  
         if ((sockFd->type == CM_INET_RAW) || 
             (sockFd->type == CM_INET_DGRAM))
         {
            *len = recvLen;
            break; 
         }
#else /* CM_INET2 */ 
         if (sockFd->type == CM_INET_DGRAM)
         {
            *len = recvLen;
            break; 
         }
#endif /* CM_INET2 */ 
      } /* while (curLen > 0) (only for stream sockets) */ 

      /* For UDP, it is possible to receive
       * a 0 byte datagram, in this case just return ROKDNA */
      if ((sockFd->type == CM_INET_DGRAM) && (*len == 0))
      {
         SPutSBuf(info->region, info->pool, recvBuf, bufLen);
         RETVALUE(ROKDNA);
      }

      /* copy data to a message structure */
      ret = SGetMsg(info->region, info->pool, &mBuf);
      if (ret != ROK)
      {
         /* cleanup */
         SPutSBuf(info->region, info->pool, recvBuf, bufLen);       
         RETVALUE(ret);
      }

#ifdef CM_INET2  
      if ((sockFd->type == CM_INET_DGRAM) ||
               (sockFd->type == CM_INET_RAW))
      {
         ret = SAddPstMsgMult(recvBuf, *len, mBuf);        
      }
      else
      {
         ret = SAddPstMsgMult(recvBuf, bufLen, mBuf);        
      }

#else /* CM_INET2 */ 
      if (sockFd->type == CM_INET_DGRAM)
      {
         ret = SAddPstMsgMult(recvBuf, *len, mBuf);        
      }
      else
      {
         ret = SAddPstMsgMult(recvBuf, bufLen, mBuf);        
      }
#endif /* CM_INET2 */ 

      if (ret != ROK)
      {
         SPutSBuf(info->region, info->pool, recvBuf, bufLen);    
         SPutMsg(mBuf); 
         RETVALUE(ret);
      }
      *mPtr = mBuf;

      /* setup return destination Internet address */
      /* added the check of (remAddrLen > 0) */
      if ((fromAddr != NULLP) && (remAddrLen > 0))
      {
#ifdef IPV6_SUPPORTED
         if (remAddrLen == sizeof(struct sockaddr_in6))
         {
            remAddr6 = (struct sockaddr_in6 *)&remSockAddr;
            fromAddr->type = CM_INET_IPV6ADDR_TYPE;
            fromAddr->u.ipv6Addr.port = CM_INET_NTOH_U16(remAddr6->sin6_port);
            CM_INET_COPY_IPV6ADDR(&fromAddr->u.ipv6Addr.ipv6NetAddr, 
                                  &remAddr6->sin6_addr);
         }
         else
         {
            remAddr = (struct sockaddr_in *)&remSockAddr;
            fromAddr->type = CM_INET_IPV4ADDR_TYPE;
            fromAddr->u.ipv4Addr.port = CM_INET_NTOH_U16(remAddr->sin_port);
            fromAddr->u.ipv4Addr.address = CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
         }
#else
         remAddr = (struct sockaddr_in *)&remSockAddr;
         fromAddr->port    = CM_INET_NTOH_U16(remAddr->sin_port);
         fromAddr->address = CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
#endif /* IPV6_SUPPORTED */
      }   

      /* cleanup */
      SPutSBuf(info->region, info->pool, recvBuf, bufLen);      
      
#else  /* end of Win NT/flat buffer specific part */

      /* Initialise variable */
      allocFlatBuf = FALSE;

      /* 
       * maybe needs more than one recvmsg() call to read entire message 
       * on a stream socket 
       */
      while (bufLen > 0)
      {
         /* allocate gather vector, it's a dynamic array */    
         numDBufs =  CM_INET_MAX_DBUF;

         ret = SGetSBuf(info->region, info->pool, (Data**)&dBufs, 
                        numDBufs*sizeof(Buffer*));
         if (ret != ROK)
         {
            RETVALUE(ROUTRES);
         }                     

         /* Allocate dBufs for gather read */ 
         /* allocate dBufs for gathering read */
         if (sockFd->type == CM_INET_STREAM)
            ret = buildRecvBuf(info, bufLen, rxArr, dBufs, numDBufs, &msg,
                               TRUE);
         else
            ret = buildRecvBuf(info, bufLen, rxArr, dBufs, numDBufs, &msg,
                               FALSE);
         if (ret != ROK)
         {
            /* check if the function returned RNA */ 
            if (ret == RNA)
            {
               /* Incase of UDP/RAW messages allocate a flat buffer. Incase
                * of TCP ignore this error condition. The user will call 
                * cmInetRecvMsg again */
               if (sockFd->type != CM_INET_STREAM)
               {
                  /* cleanup  the dBuf array */
                  for (i = 0; i < msg.msg_iovlen; i++)
                     SPutDBuf(info->region, info->pool, dBufs[i]);   
                  
                  SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                           numDBufs * sizeof(Buffer*)); 

                  /* allocate flat receive buffer */
                  ret = SGetSBuf(info->region, info->pool, &recvBuf, bufLen);
                  if (ret != ROK)
                     RETVALUE(ROUTRES);

                  allocFlatBuf = TRUE;

                  /* update the message structure */
#ifdef SS_LINUX
                  rxArr[0].iov_base = (Void*)recvBuf;  
                  rxArr[0].iov_len = (U32)bufLen;    
#else
                  rxArr[0].iov_base = (S8*)recvBuf;
                  rxArr[0].iov_len = bufLen;
#endif /* SS_LINUX */
                  msg.msg_iov           = rxArr;
                  msg.msg_iovlen        = 1;
               }
            }
            else
            {
               SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                        numDBufs*sizeof(Buffer*)); 
               RETVALUE(ret);
            }
         }

         numBuf =  msg.msg_iovlen;

         /* setup destination Internet address structure */
         if (fromAddr != NULLP)
         {
#ifdef SS_LINUX
            msg.msg_name    = (Void*)&remSockAddr;
#else
#ifdef SS_PS
            msg.msg_name    = (char *)&remSockAddr;
#else
            msg.msg_name    = (caddr_t)&remSockAddr;
#endif /* SS_PS */
#endif /* SS_LINUX */
            msg.msg_namelen = sizeof(remSockAddr);
         }
         else
         {
            msg.msg_name    = NULLP;
            msg.msg_namelen = 0;
         }

         /* added defined(_XPG4_2). Also changed the
          * assignments */
#if (defined(SS_LINUX) || defined(_XPG4_2))
         msg.msg_control      = ancillData;
         msg.msg_controllen   = sizeof(ancillData);
#else
         msg.msg_accrights     = NULLP;
         msg.msg_accrightslen  = 0;
#endif /* SS_LINUX */
                  
         recvLen = recvmsg(sockFd->fd, &msg, flags);
         if ((recvLen == INET_ERR) || (recvLen > CM_INET_MAX_MSG_LEN))
         {
           /* Moved up the cleanup precedures here before returning */
           /* Cleanup flat buffer if allocated */
            if (allocFlatBuf)
               SPutSBuf(info->region, info->pool, recvBuf, bufLen);
            else
            {
               /* cleanup */
               for (i = 0; i < numBuf; i++)
               { 
                  SPutDBuf(info->region, info->pool, dBufs[i]);   
               }
               SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                        numDBufs*sizeof(Buffer*)); 
            }

            if (*mPtr != NULLP)
            {
               SPutMsg(*mPtr);
            }

            /* added check ERR_AGAIN when CMINETFLATBUF is not defined. 
               added check ERR_WOULDBLOCK */
            if ((INET_ERR_CODE == ERR_AGAIN) ||
                (INET_ERR_CODE == ERR_WOULDBLOCK))
            {
               *len = 0;  
               RETVALUE(ROKDNA);
            }
            
#ifdef CMINETDBG
            sprintf(prntBuf,"File: %s, cmInetRecvMsg() failed on line: %d\n\
                    error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
            SPrint(prntBuf);
#endif /* CMINETDBG */
            
            /*  If this happens then cmInetRecvMsg must return RCLOSED. 
             *  Needed for getting icmp msgs */
            if (INET_ERR_CODE == ERR_CONNABORTED)
            {
               *len = 0;
               RETVALUE(RCLOSED);
            }
            RETVALUE(RFAILED); 
         } 
      
         bufLen -= recvLen;

         /* added for IPv6 extn headers */
#if (defined(IPV6_OPTS_SUPPORTED) || defined(LOCAL_INTF))
         
         /* check if ancillary data has been received. 
          * Return the allocated memory when no ancillary data received */
#if (defined(SS_LINUX) || defined(_XPG4_2))         
         if (msg.msg_controllen)
         {   
            cmsgptr = CMSG_FIRSTHDR(&msg);
         }   
         else 
            cmsgptr = NULLP;
#else
         cmsgptr = NULLP;         
#endif  /* SS_LINUX || _XPG4_2 */        

         if (cmsgptr != NULLP) 
         {
#ifdef IPV6_OPTS_SUPPORTED            
            if(ipHdrParams != NULLP)
            {   
               ipHdrParams->u.ipv6HdrParm.ttl.pres = FALSE;
               ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.hbhHdrPrsnt = FALSE;
               ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.destOptsPrsnt = FALSE;
               ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.rtOptsPrsnt = FALSE;

               /* get all ancillary data objects recvd one by one */
               for (cmsgptr = CMSG_FIRSTHDR(&msg); cmsgptr != NULLP; 
                    cmsgptr = CMSG_NXTHDR(&msg, cmsgptr))
               {
                  if (cmsgptr->cmsg_level == IPPROTO_IPV6)
                  {
                     /* Initialise ipHdrParams properly */
                     ipHdrParams->type = CM_INET_IPV6ADDR_TYPE;   

                     if (cmsgptr->cmsg_type == IPV6_HOPOPTS) 
                     {
                        /* build up HBH opt array from recvd ancillary data */
                        ret = cmInet6BuildRecvHopOptsArr(
                                 (U8 *)CMSG_DATA(cmsgptr), cmsgptr->cmsg_len, 
                              &ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.hbhOptsArr,
                                 0, info);
                        if (ret != ROK)
                           RETVALUE(ret);
                        ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.hbhHdrPrsnt = 
                                                                          TRUE; 
                     }
#ifdef SS_LINUX
                     else if(cmsgptr->cmsg_type == IPV6_DSTOPTS)
#else
                     else if ((cmsgptr->cmsg_type == IPV6_DSTOPTS) ||
                              (cmsgptr->cmsg_type == IPV6_RTHDRDSTOPTS))
#endif /* SS_LINUX */  
                     {
                        /* build up Dest opt array from recvd ancillary data */
                        ret = cmInet6BuildRecvDstOptsArr(
                                (U8 *)CMSG_DATA(cmsgptr), cmsgptr->cmsg_len, 
                            &ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.destOptsArr,
                                1, info); 
                        if (ret != ROK)
                           RETVALUE(ret);
                        ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.destOptsPrsnt = 
                                                                          TRUE;
                     }
                     else if (cmsgptr->cmsg_type == IPV6_RTHDR)
                     {
                        /* build up Route Hdr from recvd ancillary data */
                        ret = cmInet6BuildRecvRtHdr(
                           (U8 *)CMSG_DATA(cmsgptr), cmsgptr->cmsg_len, &rtHdr0,
                              &ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.rtOptsArr, 
                              info);
                        if (ret != ROK)
                           RETVALUE(ret);
                        ipHdrParams->u.ipv6HdrParm.ipv6ExtHdr.rtOptsPrsnt = 
                                                                        TRUE; 
                     }
                     else if(cmsgptr->cmsg_type == IPV6_HOPLIMIT)
                     {
                         /* get the received hoplimit */
                         ret = cmInet6GetHopLimitValue((U8 *)CMSG_DATA(cmsgptr),                                cmsgptr->cmsg_len, &ipHdrParams->u.ipv6HdrParm);
                         if (ret != ROK)
                            RETVALUE(ret);
                     }
                  }
               }  /* for */            
            } /* ipHdrParams */
#endif /* IPV6_OPTS_SUPPORTED */

#ifdef IPV6_SUPPORTED
#ifdef LOCAL_INTF 
            for (cmsgptr = CMSG_FIRSTHDR(&msg); cmsgptr != NULLP; 
                 cmsgptr = CMSG_NXTHDR(&msg, cmsgptr))
            {   
               if(cmsgptr->cmsg_type == IPV6_PKTINFO)
               {
                  pkt6Info = (struct in6_pktinfo *)CMSG_DATA(cmsgptr);
                  localIf->intfPrsnt = TRUE;
                  localIf->localIf = pkt6Info->ipi6_ifindex;
                  localIf->localIfAddr.type =  CM_INET_IPV6ADDR_TYPE;
                  cmMemcpy((U8 *)&localIf->localIfAddr.u.ipv6NetAddr,
                        (U8 *)(int *)&pkt6Info->ipi6_addr, 16);
               }
            }   
#endif /* LOCAL_INTF */
#endif            

#if (defined(SS_LINUX) && defined(LOCAL_INTF))
#ifdef IPV6_SUPPORTED        
            if(sockFd->protType == AF_INET) 
            { 
#endif               
               for (cmsgptr = CMSG_FIRSTHDR(&msg); cmsgptr != NULL; 
                    cmsgptr = CMSG_NXTHDR(&msg, cmsgptr))
               {
                  if (cmsgptr->cmsg_level == IPPROTO_IP && 
                      cmsgptr->cmsg_type == IP_PKTINFO)
                  {
                     pkt4Info = (struct in_pktinfo *)CMSG_DATA(cmsgptr);
                     localIf->intfPrsnt = TRUE;
                     localIf->localIf = pkt4Info->ipi_ifindex;
                     localIf->localIfAddr.type =  CM_INET_IPV4ADDR_TYPE;
                     localIf->localIfAddr.u.ipv4NetAddr = 
                                     ntohl(*(int *)&pkt4Info->ipi_addr);     
                  }
               }
#ifdef IPV6_SUPPORTED               
            }
#endif 
#endif /* SS_LINUX */ 
         }
#endif /* IPV6_OPTS_SUPPORTED || LOCAL_INTF */
         
         /* setup return destination Internet address */
         if (fromAddr != NULLP)
         {
#ifdef IPV6_SUPPORTED
            if (msg.msg_namelen == sizeof(struct sockaddr_in6))
            {
               remAddr6 = (struct sockaddr_in6 *)&remSockAddr;
               fromAddr->type = CM_INET_IPV6ADDR_TYPE;
               fromAddr->u.ipv6Addr.port = 
                                     CM_INET_NTOH_U16(remAddr6->sin6_port);
               CM_INET_COPY_IPV6ADDR(&fromAddr->u.ipv6Addr.ipv6NetAddr, 
                                     &remAddr6->sin6_addr);
            }
            else
            {
               remAddr = (struct sockaddr_in *)&remSockAddr;
               fromAddr->type = CM_INET_IPV4ADDR_TYPE;
               fromAddr->u.ipv4Addr.port = CM_INET_NTOH_U16(remAddr->sin_port);
               fromAddr->u.ipv4Addr.address = 
                                    CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
            }
#else
            remAddr = (struct sockaddr_in *)&remSockAddr;
            fromAddr->port    = CM_INET_NTOH_U16(remAddr->sin_port);
            fromAddr->address = CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
#endif /* IPV6_SUPPORTED */
         }
        
         /* Incase a flat buffer was allocated get
          * a message to pass up */
         if (allocFlatBuf)
         {
            bufLen += recvLen;

            /* Get a message */
            ret = SGetMsg(info->region, info->pool, &tempMsg);
            if (ret != ROK)
            {
               /* cleanup */
               SPutSBuf(info->region, info->pool, recvBuf, bufLen);       
               RETVALUE(ret);
            }
            ret = SAddPstMsgMult(recvBuf, recvLen, tempMsg);        
            if (ret != ROK)
            {
               SPutSBuf(info->region, info->pool, recvBuf, bufLen);    
               SPutMsg(tempMsg); 
               RETVALUE(ret);
            }

            *mPtr = tempMsg;

            SPutSBuf(info->region, info->pool, recvBuf, bufLen);    
            /* flat buffers are allocated for non -TCP sockets. On these
             * sockets we can receive only one message at a time 
             */
            break;
         }
         else
         {
            /* build message out of dBufs */
            ret = buildRecvMsg(info, rxArr, numBuf, recvLen, dBufs, &tempMsg);
            if (ret != ROK)
            {
               /* Deallocate previously allocated
                * mBuf */
               if (*mPtr != NULLP)
                  SPutMsg(*mPtr);
               SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                        numDBufs*sizeof(Buffer*)); 
               RETVALUE(ret);
            }
         }

         if (*mPtr == NULLP)
         {
            /* it's first recvmsg() call */ 
            *mPtr = tempMsg;
         }
         else
         {
           /* concatenate messages */  
            ret = SCatMsg(*mPtr, tempMsg, M1M2);
            if (ret != ROK)
            {
               /* cleanup */
               SPutMsg(*mPtr);
               SPutMsg(tempMsg);
               SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                        numDBufs*sizeof(Buffer*)); 
               RETVALUE(RFAILED);
            }
            SPutMsg(tempMsg);
         }
            
         SPutSBuf(info->region, info->pool, (Data*)dBufs, 
                  numDBufs*sizeof(Buffer*)); 
              
         /* 
          * a message is always read atomically on a datagram socket,
          * therefore it's ok to read less than pending data!
          */
#ifdef CM_INET2  
         if ((sockFd->type == CM_INET_DGRAM) ||
                  (sockFd->type == CM_INET_RAW))
         {
            *len = recvLen;
            break; 
         }
#else /* CM_INET2 */ 
         if (sockFd->type == CM_INET_DGRAM)
         {
            *len = recvLen;
            break; 
         }
#endif /* CM_INET2 */ 
      } /* while(bufLen > 0) (only for stream sockets) */

#endif /* WIN32 | CMINETFLATBUF  */
   }
   else
   {
      /* not enough data pending yet */
      RETVALUE(ROKDNA);
   }

   RETVALUE(ROK);
} /* end of cmInetRecvMsg */


/*
*
*      Fun:   cmInetPeek
*
*      Desc:  Reads some data from the socket without destroying the socket
*             receive buffer.
*             The data is specified by the byte positon (first byte is at
*             position 0) and the length.  
*     
*      Ret:   ROK     - successful
*             ROKDNA  - ok, data not available
*             RCLOSED - connection closed by peer
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetPeek
(
CmInetFd        *sockFd,        /* socket file descriptor */ 
CmInetAddr      *fromAddr,      /* sender Internet address/port */ 
CmInetMemInfo   *info,          /* buffer allocation info */
MsgLen           dataPos,       /* position of data */
MsgLen           dataLen,       /* length of read data */
Data            *data           /* read data */
)
#else
PUBLIC S16 cmInetPeek(sockFd, fromAddr, info, dataPos, dataLen, data)
CmInetFd        *sockFd;        /* socket file descriptor */ 
CmInetAddr      *fromAddr;      /* sender Internet address/port */ 
CmInetMemInfo   *info;          /* buffer allocation info */
MsgLen           dataPos;       /* position of data */
MsgLen           dataLen;       /* length of read data */
Data            *data;          /* read data */
#endif
{
   Data        *recvBuf;           /* plain receive buffer */
   U16          bufLen;            /* buffer length */ 
   U16          i;                 /* index */
   S32          j;                 /* index */
   S32          ret;               /* temporary return value */
   U32          timeout;           /* timeout for cmInetSelect() */ 
   U32         *timeoutPtr;        /* pointer to timeout */
   S16          numFdS;            /* number of ready descriptors */
   U32          pendLen;           /* pending data length */
   S32          recvLen;           /* number of received octets */
   S32          remAddrLen;        /* length of remote address length */
   CmInetFdSet  readFdS;           /* socket file descriptor set */
   struct sockaddr_in  *remAddr;    /* remote Internet address */      
#ifdef IPV6_SUPPORTED
   struct sockaddr_in6  *remAddr6;  /* remote Internet IPV6 address */      
   struct sockaddr_in6 remSockAddr; /* to get packet's source IP address */
#else
   CmInetSockAddr  remSockAddr;     /* to get packet's source IP address */
#endif /* IPV6_SUPPORTED */

   TRC2(cmInetPeek);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (info == NULLP) || (data == NULLP) ||
       (dataPos < 0) || (dataLen < 0))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* check if there are some datas */
   if (sockFd->blocking) 
   {
      /* blocking */ 
      timeoutPtr = NULLP;  
   } 
   else 
   {
      /* poll (non-blocking) */ 
      timeout = 0;
      timeoutPtr = &timeout;
   }
   CM_INET_FD_ZERO(&readFdS);
   CM_INET_FD_SET(sockFd, &readFdS);
   
   ret = cmInetSelect(&readFdS, NULLP, timeoutPtr, &numFdS);
   if (CM_INET_FD_ISSET(sockFd, &readFdS))
   {
      /* get number of pending data */
      /* removed 3rd arg memInfo. MemInfo is no longer needed as we 
         call ioctl for all sockets */
      ret = cmInetGetNumRead(sockFd, &pendLen);
      if (ret != ROK)
      {
         RETVALUE(RFAILED);
      }
        
      /* check if connection got closed */
      if (pendLen == 0)
      {
         /* return RCLOSED for TCP else return ROKDNA */
         if (sockFd->type == CM_INET_STREAM)
            RETVALUE(RCLOSED);
         else
            RETVALUE(ROKDNA);
      }
      /* added check for TCP/UDP socket. Pending data len in the socket 
         recv buffer is determined by ioctl call in cmInetGetNumRead. 
         For TCP it can't be > CM_INET_MAX_MSG_LEN. 
         For UDP it can't be > CM_INET_MAX_UDPRAW_MSGSIZE. */ 
      if (sockFd->type == CM_INET_STREAM) 
      {
         /* max message length is limited to control the memory usage */
         if (pendLen > CM_INET_MAX_MSG_LEN)
            pendLen = CM_INET_MAX_MSG_LEN;
            /* In STREAM remote address is not required */
         remAddrLen = 0;
      }
      else
      {
         if (pendLen > CM_INET_MAX_UDPRAW_MSGSIZE)
            pendLen = CM_INET_MAX_UDPRAW_MSGSIZE;

         remAddrLen = sizeof(CmInetSockAddr);
      }

      /* check if there are enough pending data to read */
      bufLen = dataPos + dataLen;

      /* check if fromAddr is present or not */
      if (fromAddr != NULLP)
      {
         remAddrLen = sizeof(remSockAddr); 
      }
      else
      {
         remAddrLen = 0;
      }

      if (pendLen >= bufLen)
      {        
         /* allocate receive buffer (flat structure) */
         ret = SGetSBuf(info->region, info->pool, &recvBuf, bufLen);                  
         if (ret != ROK)
         {
            RETVALUE(ROUTRES);
         }          

         /* added different recvfrom calls with 
          * different 6th arg for different OS */

         /* If remAddrLen is 0, pass NULLP */
#if( defined(SS_VW) || defined(HPOS) || defined(SS_PS))
         if(remAddrLen)
            recvLen = recvfrom(sockFd->fd,(S8*)recvBuf, bufLen, 
                            CM_INET_MSG_PEEK, &remSockAddr, (int*)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd,(S8*)recvBuf, bufLen, 
                            CM_INET_MSG_PEEK, NULLP, (int*)&remAddrLen);
#else
#if ( defined(SUNOS) || defined(SS_LINUX))
         if(remAddrLen)
            recvLen = recvfrom(sockFd->fd, (S8*)recvBuf,bufLen, 
                            CM_INET_MSG_PEEK, (struct sockaddr *)&remSockAddr, 
                            (socklen_t *)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd, (S8*)recvBuf,bufLen, 
                            CM_INET_MSG_PEEK, NULLP, (socklen_t *)&remAddrLen);
#else         
         if(remAddrLen)
            recvLen = recvfrom(sockFd->fd,(S8*)recvBuf, bufLen, 
                            CM_INET_MSG_PEEK, &remSockAddr, (S32*)&remAddrLen);
         else
            recvLen = recvfrom(sockFd->fd,(S8*)recvBuf, bufLen, 
                            CM_INET_MSG_PEEK, NULLP, (S32*)&remAddrLen);
#endif /* defined(SUNOS) || defined(SS_LINUX) */
#endif /* defined(SS_VW) || defined(HPOS) || defined(SS_PS) */
         
         /* removed the check of returned remAddrLen */ 
         if (recvLen == INET_ERR)
         {
            /* cleanup */
            /* moved cleanup here */
            SPutSBuf(info->region, info->pool, recvBuf, bufLen); 

            /* added check ERR_WOULDBLOCK */
            if ((INET_ERR_CODE == ERR_AGAIN) ||
                (INET_ERR_CODE == ERR_WOULDBLOCK))
            {
               recvLen = 0;
               RETVALUE(ROKDNA);
            }
            
            /* moved up the cleanup */
                           
#ifdef CMINETDBG
            sprintf(prntBuf,"File: %s, cmInetPeek() failed on line: %d \n\
                    error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
            SPrint(prntBuf);
#endif /* CMINETDBG */

            if ((INET_ERR_CODE == ERR_CONNABORTED) ||
                (INET_ERR_CODE == ERR_CONNRESET))
            {
               recvLen = 0;
               RETVALUE(RCLOSED);
            }
            RETVALUE(RFAILED);
         } 

         if (recvLen < (S32)bufLen)  /* maybe happen */
         {
            /* cleanup */
            SPutSBuf(info->region, info->pool, recvBuf, bufLen);                            
            RETVALUE(ROKDNA);
         } 

         /* copy data */
         for (j = 0, i = dataPos; i < bufLen; j++, i++)
            data[j] = recvBuf[i];             

         /* setup return destination Internet address */
         /* added the check of (remAddLen > 0) */
         if ((fromAddr != NULLP) && (remAddrLen > 0))
         {
#ifdef IPV6_SUPPORTED
            cmMemset((U8*)&fromAddr, 0, sizeof(fromAddr));
            if (remAddrLen == sizeof(struct sockaddr_in6))
            {
               remAddr6 = (struct sockaddr_in6 *)&remSockAddr;
               fromAddr->type = CM_INET_IPV6ADDR_TYPE;
               fromAddr->u.ipv6Addr.port = 
                           CM_INET_NTOH_U16(remAddr6->sin6_port);
               CM_INET_COPY_IPV6ADDR(&fromAddr->u.ipv6Addr.ipv6NetAddr, 
                                     &remAddr6->sin6_addr);
            }
            else
            {
               remAddr = (struct sockaddr_in *)&remSockAddr;
               fromAddr->type = CM_INET_IPV4ADDR_TYPE;
               fromAddr->u.ipv4Addr.port = CM_INET_NTOH_U16(remAddr->sin_port);
               fromAddr->u.ipv4Addr.address = 
                                CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
            } 
#else
            remAddr = (struct sockaddr_in *)&remSockAddr;
            fromAddr->port    = CM_INET_NTOH_U16(remAddr->sin_port);
            fromAddr->address = CM_INET_NTOH_U32(remAddr->sin_addr.s_addr);
#endif /* IPV6_SUPPORTED */
         }   

         /* cleanup */
         SPutSBuf(info->region, info->pool, recvBuf, bufLen);                            
      }
      else
      {
         /* not enough data pending yet */
         RETVALUE(ROKDNA);
      }
   }
   else
   {
      /* no data pending */ 
      RETVALUE(ROKDNA);
   }   

   RETVALUE(ROK);
} /* end of cmInetPeek */


/*
*
*      Fun:   cmInetClose 
*
*      Desc:  Close a socket gracefully. 
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetClose
(
CmInetFd *sockFd                /* socket file descriptor */
)
#else
PUBLIC S16 cmInetClose(sockFd)
CmInetFd *sockFd;               /* socket file descriptor */
#endif
{
   S32 ret;                     /* temporary return value */

   TRC2(cmInetClose);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef WIN32
   ret = closesocket(sockFd->fd);
#else
   ret = close(sockFd->fd);
#endif /* WIN32 */
   if (ret == INET_ERR) 
   {
#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetClose() failed on line: %d \n\
              error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }
 
   RETVALUE(ROK);
} /* end of cmInetClose */


/*
*
*      Fun:   cmInetShutdown
*
*      Desc:  Close an Internet connection with more control over the data of 
*             the full-duplex connection.
*             Values for the howTo parameter:
*
*             CM_INET_SHTDWN_RECV - discard data in receive buffer
*             CM_INET_SHTDWN_SEND - discard data in transmit buffer
*             CM_INET_SHTDWN_BOTH - discard data in receive and transmit buffer      
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: This function does not free the socket descriptor but only closes the 
*             connection (cmInetClose() has to be called afterwards).
*             No error is returned if the socket is not connected while calling
*             this function. 
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetShutdown
(
CmInetFd *sockFd,               /* socket file descriptor */
S32       howTo                 /* operation flag */
)
#else
PUBLIC S16 cmInetShutdown(sockFd, howTo)
CmInetFd *sockFd;               /* socket file descriptor */
S32       howTo;                /* operation flag */
#endif
{
   S32 ret;                     /* temporary return value */
   
   TRC2(cmInetShutdown);
  
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   ret = shutdown(sockFd->fd, howTo);
   if (ret == INET_ERR)
   {
      if (INET_ERR_CODE == ERR_NOTCONN)
      {
         /* socket is not connected */ 
         RETVALUE(ROK); 
      }
      else
      {
         /* real problem */ 
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, cmInetShutdown() failed on line: %d \n\
                 error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         RETVALUE(RFAILED);
      }
   }   

   RETVALUE(ROK);
} /* end of cmInetShutdown */


/*
*
*      Fun:   cmInetSelect   
*
*      Desc:  Allows multiplex i/o requests among multiple sockets.
*             If the parameter mSecTimeout points to a value of zero the 
*             call immediatley returns (poll), if it is a null pointer, the
*             timeout is set to infinit.
*             numFdS returns the number of ready file  descriptors  contained  
*             in  the  file  descriptor  sets 
*
*      Ret:   ROK      - successful
*             RTIMEOUT - timout expired
*             RFAILED  - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetSelect
(
CmInetFdSet *readFdS,           /* read socket descriptor file set */  
CmInetFdSet *writeFdS,          /* write socket descriptor file set */
U32         *mSecTimeout,       /* timeout in msecs */
S16         *numFdS             /* number of ready descriptors */
)
#else
PUBLIC S16 cmInetSelect(readFdS, writeFdS, mSecTimeout, numFdS)
CmInetFdSet *readFdS;           /* read socket descriptor file set */  
CmInetFdSet *writeFdS;          /* write socket descriptor file set */
U32         *mSecTimeout;       /* timeout in msecs */
S16         *numFdS;            /* number of ready descriptors */
#endif
{
   S32 ret;                     /* temporary return value */
   struct timeval  timeout;     /* timeout structure */
   struct timeval *timeoutPtr;
   S32 errCode;

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if (numFdS == NULLP)
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   *numFdS = 0;

   if (mSecTimeout != NULLP)
   {
      timeout.tv_sec  = *mSecTimeout / 1000;
      timeout.tv_usec = (*mSecTimeout % 1000) * 1000;
      timeoutPtr      = &timeout;
   }
   else
   {
      /* infinite timeout */ 
      timeoutPtr = NULLP;
   }
      
   ret = select(FD_SETSIZE, readFdS, writeFdS, (fd_set*)0, timeoutPtr);

   /* timeout occured */
   if (ret == 0)
   { 
      RETVALUE(RTIMEOUT);
   }
   
   if (ret == INET_ERR)
   {
      /* asa: Added a check for ERR_INVAL to return ROK
       * readFdS and writeFdS may be passed as NULL to
       * cmInetSelect() call
       */
      switch(errCode = INET_ERR_CODE)
      {
         case ERR_INVAL:
            RETVALUE(ROK);
         
         default:
#ifdef CMINETDBG
            sprintf(prntBuf, "File: %s, cmInetSelect() failed on line: %d \n\
                    error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
            SPrint(prntBuf);
#endif /* CMINETDBG */
            RETVALUE(RFAILED);

      } /* end of switch */
   }
   
   /* return number of ready file descriptors */
   *numFdS = ret;   

   RETVALUE(ROK); 
} /* end of  cmInetSelect */


/*
*
*      Fun:   cmInetSetOpt
*
*      Desc:  Sets a socket option.
*             The function supports following options:
*
*             CM_INET_OPT_BLOCK:
*                value: CM_INET_OPT_DISABLE  non-blocking
*                value: CM_INET_OPT_ENABLE   blocking
*
*             CM_INET_OPT_REUSEADDR:   
*                value: CM_INET_OPT_ENABLE   reuse address 
*
*             CM_INET_OPT_BROADCAST:
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_KEEPALIVE:
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_RX_BUF_SIZE:
*                value: receive buffer size in bytes
*
*             CM_INET_OPT_TX_BUF_SIZE:
*                value: transmitter buffer size in bytes
*
*             CM_INET_OPT_ADD_MCAST_MBR:
*                value: address of CmInetMCastInf structure
*
*             CM_INET_OPT_DRP_MCAST_MBR:
*                value: address of CmInetMCastInf structure
*
*             CM_INET_OPT_TCP_NODELAY:  
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_BSD_COMPAT: For Linux only
*                value: CM_INET_OPT_ENABLE   
*                value: CM_INET_OPT_DISABLE 
*
*             CM_INET_OPT_HDR_INCLD: 
*                value: CM_INET_ENABLE
*                value: CM_INET_DISABLE
*
*             CM_INET_OPT_DONT_FRAGMENT:
*                value: CM_INET_OPT_ENABLE
*                value: CM_INET_DISABLE
*
*             CM_INET_OPT_TOS:
*                value: Type of Service.
* 
*             CM_INET_OPT_TTL:
*                value: Time To Live.
*
*             CM_INET_OPT_IP_OPTIONS:
*                value: IPv4 header option value 
*                ENABLE/DISABLE.
*
*             CM_INET_OPT_IP_ROUTER_ALERT:
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_IPV4_PKTINFO
*                value: CM_INET_OPT_ENABLE
*                value: CM_INET_OPT_DISABLE
*
*             CM_INET_OPT_MCAST_LOOP:  
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_MCAST_IF:
*                value: Address of interface.
*
*             CM_INET_OPT_MCAST_TTL:
*                value: TTL of the outgoing multicast packet.
*
*             The next  options are defined only if IPV6 is 
*             supported.
*
*             CM_INET_OPT_ADD_MCAST6_MBR:
*                value: address of CmInetMCastInf6 structure
*
*             CM_INET_OPT_DRP_MCAST6_MBR:
*                value: address of CmInetMCastInf6 structure
*
*             CM_INET_OPT_MCAST6_LOOP:  
*                value: CM_INET_OPT_DISABLE
*                value: CM_INET_OPT_ENABLE
*
*             CM_INET_OPT_MCAST6_IF:
*                value: Interface index
*
*             CM_INET_OPT_MCAST6_HOPS:  
*                value: multicast hop limit 
*
*             CM_INET_OPT_RECVIPV6_HOPLIM:
*                value: CM_INET_OPT_ENABLE   hop limit will be returned
*                                            on the socket.
*                value: CM_INET_OPT_DISABLE  hop limit wont be returned 
*                                            on the socket.
*
*             CM_INET_OPT_RECVIPV6_HBHOPTS:
*                value: CM_INET_OPT_ENABLE   HBH Options will be returned
*                                            on the socket.
*                value: CM_INET_OPT_DISABLE  HBH Options wont be returned 
*                                            on the socket. 
*                                            
*             CM_INET_OPT_RECVIPV6_DSTOPTS:
*                value: CM_INET_OPT_ENABLE   Dest Options will be returned
*                                            on the socket.
*                value: CM_INET_OPT_DISABLE  Dest Options wont be returned 
*                                            on the socket.                     
*                                            
*             CM_INET_OPT_RECVIPV6_RTHDR:
*                value: CM_INET_OPT_ENABLE   Route Hdr Opt will be turned
*                                            ON on the socket.
*                value: CM_INET_OPT_DISABLE  Route Hdr Opt will be turned 
*                                            OFF on the socket.
*
*             CM_INET_OPT_IP_ROUTER_ALERT6  
*                value: CM_INET_OPT_ENABLE
*                value: CM_INET_OPT_DISABLE
* 
*             CM_INET_OPT_IPV6_PKTINFO
*                value: CM_INET_OPT_ENABLE   Enable sending and receiving
*                                            of packet info
*                value: CM_INET_OPT_DISABLE  Disable sending and receiving
*                                            of packet info
* 
*      Ret:   ROK     - successful
*             RFAILED - failed
*             RNA     - failed, option not available
*             (Only when CM_INET2 is defined)
*
*      Notes: The send and receive buffer size may be system
*             specific. The cmInetSetOpt() call may return
*             successfuly although not the entire buffer size 
*             could be set!
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
PUBLIC S16 cmInetSetOpt
(
CmInetFd *sockFd,               /* socket file descriptor */ 
U32       level,                /* option level */
U32       type,                 /* option type */
Ptr       value                 /* option value */ 
) 
#else
PUBLIC S16 cmInetSetOpt(sockFd, level, type, value)
CmInetFd *sockFd;               /* socket file descriptor */ 
U32       level;                /* option level */
U32       type;                 /* option type */
Ptr       value;                /* option value */
#endif
{
   S32  ret = ROK;              /* temporary return value */
   U32  disable = 0;            /* disable option */
   U32  enable = 1;             /* enable option */

   /* added for IPv4 options */
#ifdef IPV4_OPTS_SUPPORTED
#if((!defined (SS_VW)) && (!defined(SS_LINUX)))   
   TknStr64 *tempTknStr64;      /* points TknStr64 structure */
                                /* which has value for IPv4 hdr options.*/
#endif /* SS_VW && SS_LINUX */   
#ifdef WIN32   
   int disableOpt = 0;
#endif /* WIN32 */   
#endif /* IPV4_OPTS_SUPPORTED */ 

#if (defined(SUNOS)|| defined(WIN32) || defined(SS_PS) || defined(SS_VW_MCAST)\
     || defined(HPOS))
   U8   lpEnable = 1;           /* multicast loop enable */
   U8   lpDisable = 0;          /* multicast loop disable */
#endif /* SUNOS || WIN32 || SS_PS || SS_VW_MCAST || HPOS */

#ifdef WIN32
   BOOL boolEnable = TRUE;      /* enable option */
   BOOL boolDisable = FALSE;    /* disable option */
#endif /* WIN32 */

#if (defined(SUNOS) || defined(WIN32) || defined(SS_PS) || \
     defined(SS_VW_MCAST) || defined(HPOS))
   struct ip_mreq stMreq;
   CmInetMCastInf *mCast;
#endif /* SUNOS || WIN32  || SS_PS || SS_VW_MCAST || HPOS */

#ifdef IPV6_SUPPORTED
   U32    loopEna = 1;     /* IPv6 multicast loop enable */
   U32    loopDis = 0;     /* IPv6 multicast loop disable */
   struct ipv6_mreq     *stMreq6Ptr;
   struct icmp6_filter  *icmp6Filter; 
#endif /* IPV6_SUPPORTED */

   U32    *optVal;

   TRC2(cmInetSetOpt);
   
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   switch (type) 
   {
      case CM_INET_OPT_BLOCK:
          optVal = (U32*)value;
          switch(*optVal)
          {
             case CM_INET_OPT_ENABLE:

#ifdef WIN32
                ret = ioctlsocket(sockFd->fd, FIONBIO, (U64 *)&disable);     
#else 
#ifdef SS_PS
                ret = ioctl(sockFd->fd, FIONBIO, (char*)&disable);
#else
#ifdef SS_VW
                ret = ioctl(sockFd->fd, (S32)FIONBIO, (S32)&disable);
#else
                ret = ioctl(sockFd->fd, (S32)FIONBIO, &disable);
                  
#endif /* SS_VW */
#endif /* SS_PS */
#endif /* WIN32 */
                sockFd->blocking = 1;
                break;
              
             case CM_INET_OPT_DISABLE:
#ifdef WIN32
                ret = ioctlsocket(sockFd->fd, FIONBIO, (U64 *)&enable);     
#else 
#ifdef SS_PS
                ret = ioctl(sockFd->fd, FIONBIO, (char*)&enable);
#else
#ifdef SS_VW
                ret = ioctl(sockFd->fd, (S32)FIONBIO, (S32)&enable);
#else
                ret = ioctl(sockFd->fd, (S32)FIONBIO, &enable);
#endif /* SS_VW */
#endif /* SS_PS */
#endif /* WIN32 */
                sockFd->blocking = 0;
                break;
             
             default:
                /* wrong value */ 
                RETVALUE(RFAILED);
                break;
          }
          break;

      case CM_INET_OPT_REUSEADDR:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&boolEnable, sizeof(boolEnable));
#else
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&enable, sizeof(enable));
#ifdef SS_VW
            setsockopt(sockFd->fd, level, SO_REUSEPORT, 
                       (char*)&enable, sizeof(enable));
#endif /* SS_VW */
#endif /* WIN32 */
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&boolDisable, sizeof(boolDisable));
#else
            ret = setsockopt(sockFd->fd, level, SO_REUSEADDR, 
                             (char*)&disable, sizeof(disable));
#ifdef SS_VW
            setsockopt(sockFd->fd, level, SO_REUSEPORT, 
                             (char*)&disable, sizeof(disable));
#endif /* SS_VW */
#endif /* WIN32 */
         }
         break;

      case CM_INET_OPT_BROADCAST:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                             (char*)&boolEnable, sizeof(boolEnable));
#else
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                             (char*)&enable, sizeof(enable));
#endif /* WIN32 */
          }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                            (char*)&boolDisable, sizeof(boolDisable));
#else
            ret = setsockopt(sockFd->fd, level, SO_BROADCAST,
                             (char*)&disable, sizeof(disable));
#endif /* WIN32 */
         }
         break; 

      case CM_INET_OPT_KEEPALIVE:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                             (char*)&boolEnable, sizeof(boolEnable));
#else
            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                             (char*)&enable, sizeof(enable));
#endif /* WIN32 */
          }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                            (char*)&boolDisable, sizeof(boolDisable));
#else
            ret = setsockopt(sockFd->fd, level, SO_KEEPALIVE,
                             (char*)&disable, sizeof(disable));
#endif /* WIN32 */
         }
         break;

      case CM_INET_OPT_RX_BUF_SIZE:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, SO_RCVBUF, 
                          (char*)optVal, sizeof(*optVal));
         break;

      case CM_INET_OPT_TX_BUF_SIZE:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, SO_SNDBUF, 
                          (char*)optVal, sizeof(*optVal));
         break;

      case CM_INET_OPT_TCP_NODELAY:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32
#ifndef SS_WINCE
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&boolEnable, sizeof(boolEnable));
#endif /* SS_WINCE */
#else
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&enable, sizeof(enable)); 
#endif /* WIN32 */
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
#ifndef SS_WINCE
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&boolDisable, sizeof(boolDisable));
#endif /* SS_WINCE */
#else
            ret = setsockopt(sockFd->fd, level, TCP_NODELAY,
                             (char*)&disable, sizeof(disable));
#endif /* WIN32 */
         }
         break;

#if (defined(SUNOS)|| defined(WIN32) || defined(SS_PS) || \
     defined(SS_VW_MCAST) || defined(HPOS))

      case CM_INET_OPT_ADD_MCAST_MBR:
         mCast = (CmInetMCastInf*)value;

         /* Copy the addresses to stMreq structure */
#ifdef SS_PS
         stMreq.imr_mcastaddr.s_addr = CM_INET_HTON_U32(mCast->mCastAddr);
#else
         stMreq.imr_multiaddr.s_addr = CM_INET_HTON_U32(mCast->mCastAddr);
#endif
         stMreq.imr_interface.s_addr = CM_INET_HTON_U32(mCast->localAddr);

         ret = setsockopt(sockFd->fd, level, IP_ADD_MEMBERSHIP,
                          (char*)&stMreq, sizeof(stMreq));
         break;

      case CM_INET_OPT_DRP_MCAST_MBR:
         mCast = (CmInetMCastInf*)value;

         /* Copy the addresses to stMreq structure */
#ifdef SS_PS
         stMreq.imr_mcastaddr.s_addr = CM_INET_HTON_U32(mCast->mCastAddr);
#else
         stMreq.imr_multiaddr.s_addr = CM_INET_HTON_U32(mCast->mCastAddr);
#endif
         stMreq.imr_interface.s_addr = CM_INET_HTON_U32(mCast->localAddr);

         ret = setsockopt(sockFd->fd, level, IP_DROP_MEMBERSHIP,
                          (char*)&stMreq, sizeof(stMreq));
         break;

#endif /* SUNOS || WIN32 || SS_PS || SS_VW_MCAST || HPOS */

#ifdef SS_LINUX
      case CM_INET_OPT_BSD_COMPAT:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_BSDCOMPAT,
                             &enable, sizeof(enable));
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
            ret = setsockopt(sockFd->fd, level, SO_BSDCOMPAT,
                             &disable, sizeof(disable));
         }
         break;
#endif /* SS_LINUX */

#ifdef CM_INET2  
     /* Added for support of Raw socket  modify according to the 
      * option available on different platform  */
#if (defined(SUNOS)|| defined(WIN32) || defined(SS_PS) || defined(SS_VW) \
      || defined(HPOS))
      case CM_INET_OPT_HDR_INCLD:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32 
            RETVALUE(RNA);    
#else
            ret = setsockopt(sockFd->fd, level, IP_HDRINCL,
                             (char*)&enable, sizeof(enable));
#endif /* WIN32 */
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
            RETVALUE(RNA);    
#else
            ret = setsockopt(sockFd->fd, level, IP_HDRINCL,
                             (char*)&disable, sizeof(disable));
#endif /* WIN32 */
         }
         break;

         /* added new options */
#ifdef IPV4_OPTS_SUPPORTED
#ifdef SS_LINUX
      /* Linux: set Router Alert socket option to Intercept RAW RSVP 
         packets at the Intermediate node(Router) with Router Alert SET.
         This socket option is MUST be set (when this server is opened)
         if the RSVP server wants to intercept raw RSVP packets. */
      case CM_INET_OPT_IP_ROUTER_ALERT:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {   
            ret = setsockopt(sockFd->fd, level, IP_ROUTER_ALERT,
                             (char*)&enable, sizeof(enable));
            if (ret != ROK)
               RETVALUE(RFAILED);
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {   
            ret = setsockopt(sockFd->fd, level, IP_ROUTER_ALERT,
                            (char*)&disable, sizeof(disable));
            if (ret != ROK)
               RETVALUE(RFAILED);
         }   
         break;         
#endif /* SS_LINUX */

         /* set Router Alert socket option */
      case CM_INET_OPT_IP_OPTIONS:
#if (defined (SS_VW) || defined(SS_LINUX))
         RETVALUE(RNA);
#else  
         tempTknStr64=(TknStr64 *)value;
         if (tempTknStr64->pres == TRUE)
         {
            if (tempTknStr64->len == 0)
            {
               /* disable the IP_OPTIONS for Router Alert.  */
#ifdef WIN32                          
               ret = setsockopt(sockFd->fd, level, IP_OPTIONS, 
                                (const char *)&disableOpt, sizeof(int));
#else
               ret = setsockopt(sockFd->fd, level, IP_OPTIONS, NULL, 0);
#endif /* WIN32 */                  
            }  
            else
               /* enable the IP_OPTIONS for Router Alert */
               ret = setsockopt(sockFd->fd, level, IP_OPTIONS,
                               (char *)tempTknStr64->val, tempTknStr64->len);
         }
         else
            RETVALUE(RFAILED); /* Trying to set IPv4 Hdr option
                                   * without giving option values*/
#endif /* SS_VW || SS_LINUX */
         break;
#endif /* IPV4_OPTS_SUPPORTED */

       /* added new options */
#if (defined(SS_LINUX) && (!defined(SS_VW) && !defined(WIN32)))
#ifdef LOCAL_INTF
      case CM_INET_OPT_IPV4_PKTINFO:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {   
            /* set IP_PKTINFO option when IP_ROUTER_ALERT is set in linux */
            ret = setsockopt(sockFd->fd, level, IP_PKTINFO,
                   (char*)&enable, sizeof(enable));

            if (ret != ROK)
               RETVALUE(RFAILED);
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {   
            /* disable IP_PKTINFO when IP_ROUTER_ALERT is set in linux */ 
            ret = setsockopt(sockFd->fd, level, IP_PKTINFO,
                             (char*)&disable, sizeof(disable));

            if (ret != ROK)
               RETVALUE(RFAILED);
         }   
         break;   
#endif /* LOCAL_INTF */            
#endif /* SS_LINUX */

#endif /* SUNOS || WIN32 || SS_PS || SS_VW || HPOS */

      case CM_INET_OPT_DONTFRAGMENT:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, IP_DONTFRAGMENT,
                             (char*)&boolEnable, sizeof(boolEnable));
#endif /* WIN32 */
         }
         else if (*optVal == CM_INET_OPT_DISABLE)
         {
#ifdef WIN32
            ret = setsockopt(sockFd->fd, level, IP_DONTFRAGMENT,
                            (char*)&boolDisable, sizeof(boolDisable));
#endif /* WIN32 */
         }
         break;

/* also add these 2 options for VxWorks */         
#if (defined(SUNOS)|| defined(WIN32) || defined(HPOS) || defined(SS_VW))
      case CM_INET_OPT_TOS:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, IP_TOS,
                             (char*)optVal, sizeof(*optVal));
         break;
      
      case CM_INET_OPT_TTL:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, IP_TTL,
                             (char*)optVal, sizeof(*optVal));
         break;
#endif /* SUNOS || WIN32 || HPOS || SS_VW */
#endif  /* CM_INET2 */ 

#if (defined(SUNOS)|| defined(WIN32) || defined(SS_PS) || defined(SS_VW_MCAST) \
     || defined(HPOS))
      case CM_INET_OPT_MCAST_LOOP:
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
#ifdef SS_VW            
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (char *)&lpEnable, sizeof(lpEnable));
#else
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (CONSTANT char *)&lpEnable, sizeof(lpEnable));
#endif /* SS_VW */           
         }
         else
         {
#ifdef SS_VW            
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (char *)&lpDisable, sizeof(lpDisable));
#else
            ret = setsockopt(sockFd->fd, level, IP_MULTICAST_LOOP,
                             (CONSTANT char *)&lpDisable, sizeof(lpDisable));
#endif /* SS_VW */            
         }
         break;

      case CM_INET_OPT_MCAST_IF:
         optVal = (U32*)value;
         *optVal = CM_INET_HTON_U32((U32)*optVal); 
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_IF,
                          (char *)optVal, sizeof(struct in_addr));
         break;
      
      case CM_INET_OPT_MCAST_TTL:
         optVal = (U32*)value;
         /* remove CONSTANT in setsockopt for VW */
#ifdef SS_VW      
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_TTL,
                          (char *)optVal, sizeof(U8));
#else
         ret = setsockopt(sockFd->fd, level, IP_MULTICAST_TTL,
                          (CONSTANT char *)optVal, sizeof(U8));
#endif /* SS_VW */         
         break;
#endif /* SUNOS || WIN32 || SS_PS || SS_VW_MCAST || HPOS */

#ifdef IPV6_SUPPORTED
      case CM_INET_OPT_IPV6_TTL:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, IPV6_UNICAST_HOPS,
                             (char*)optVal, sizeof(*optVal));
         break;

      case CM_INET_OPT_ADD_MCAST6_MBR:
         stMreq6Ptr = (struct ipv6_mreq *)value;
         ret = setsockopt(sockFd->fd, level, IPV6_JOIN_GROUP,
                          (char*)stMreq6Ptr, sizeof(struct ipv6_mreq));
      break;

      case CM_INET_OPT_DRP_MCAST6_MBR:
         stMreq6Ptr = (struct ipv6_mreq *)value;
         ret = setsockopt(sockFd->fd, level, IPV6_LEAVE_GROUP,
                          (char*)stMreq6Ptr, sizeof(struct ipv6_mreq));
      break;

      case CM_INET_OPT_MCAST6_LOOP:  
         optVal = (U32*)value;
         if (*optVal == CM_INET_OPT_ENABLE)
         {
            ret = setsockopt(sockFd->fd, level, IPV6_MULTICAST_LOOP,
                             &loopEna, sizeof(loopEna));
         }
         else
         {
            ret = setsockopt(sockFd->fd, level, IPV6_MULTICAST_LOOP,
                             &loopDis, sizeof(loopDis));
         }
      break;

      case CM_INET_OPT_MCAST6_IF:
         ret = setsockopt(sockFd->fd, level, IPV6_MULTICAST_IF,
                          (U32 *)value, sizeof(U32));
      break;

      case CM_INET_OPT_MCAST6_HOPS:
         optVal = (U32*)value;
         ret = setsockopt(sockFd->fd, level, IPV6_MULTICAST_HOPS,
                          (char *)optVal, sizeof(U32));
      break;

      case CM_INET_OPT_ICMP6_FILTER:  
         icmp6Filter = (struct icmp6_filter *)value;
         ret = setsockopt(sockFd->fd, level, ICMP6_FILTER,
                          (char *)icmp6Filter, sizeof(struct icmp6_filter));
      break;

      /* added new options */
#ifdef IPV6_OPTS_SUPPORTED
      case CM_INET_OPT_RECVIPV6_HOPLIM:
         optVal = (U32*)value;
#ifdef SS_LINUX         
        ret = setsockopt(sockFd->fd, level, IPV6_HOPLIMIT,
                          (char *)optVal, sizeof(U32)); 
#else
        ret = setsockopt(sockFd->fd, level, IPV6_HOPLIMIT,
                          (char *)optVal, sizeof(U32)); 
        /* enable the reception of IPv6 HopLimit value as ancillary data */
        ret = setsockopt(sockFd->fd, level, IPV6_RECVHOPLIMIT,
                          (char*)&enable, sizeof(enable)); 
#endif /* SS_LINUX */
         
         break;
         
      case CM_INET_OPT_RECVIPV6_HBHOPTS:
         optVal = (U32*)value;
#ifdef SS_LINUX
         ret = setsockopt(sockFd->fd, level, IPV6_HOPOPTS,
                          (char *)optVal, sizeof(U32));
#else
         ret = setsockopt(sockFd->fd, level, IPV6_RECVHOPOPTS,
                          (char *)optVal, sizeof(U32)); 
#endif /* SS_LINUX */          
         break;
         
      case CM_INET_OPT_RECVIPV6_DSTOPTS:
         optVal = (U32*)value;
#ifdef SS_LINUX         
         ret = setsockopt(sockFd->fd, level, IPV6_DSTOPTS,
                          (char *)optVal, sizeof(U32));
#else         
         ret = setsockopt(sockFd->fd, level, IPV6_RECVDSTOPTS,
                          (char *)optVal, sizeof(U32));
#endif /* SS_LINUX */
         break;
         
      case CM_INET_OPT_RECVIPV6_RTHDR:
         optVal = (U32*)value;
#ifdef SS_LINUX         
         ret = setsockopt(sockFd->fd, level, IPV6_RTHDR,
                          (char *)optVal, sizeof(U32));
#else
         ret = setsockopt(sockFd->fd, level, IPV6_RECVRTHDR,
                          (char *)optVal, sizeof(U32));
#endif /* SS_LINUX */         
         break;      
 
      /* works ONLY for IPPROTO_RAW type socket. so if it this socket
      * option is tried to set for IPPROTO_RSVP, then it is supposed
      * to fail with EINVAL according to net/ipv6/ipv6_sockglue.c 
      *
      * if HI_SRVC_RAW_RAW is not used during ServOpenReq as the server 
      * type, then it will fail here due to above reason */
#ifdef SS_LINUX
      case CM_INET_OPT_IP_ROUTER_ALERT6:
         optVal = (U32*)value;
         if(*optVal == CM_INET_OPT_ENABLE)
            ret = setsockopt(sockFd->fd, IPPROTO_IPV6, IPV6_ROUTER_ALERT,
                          (char *)&enable, sizeof(enable));          
         else
            ret = setsockopt(sockFd->fd, level, IPV6_ROUTER_ALERT,
                          (char *)&disable, sizeof(disable));

         break;
#endif /* SS_LINUX */
#endif /* IPV6_OPTS_SUPPORTED */

#ifdef LOCAL_INTF         
      case CM_INET_OPT_IPV6_PKTINFO:
         optVal = (U32*)value;
#ifdef SS_LINUX         
         ret = setsockopt(sockFd->fd, level, IPV6_PKTINFO,
                          (char *)optVal, sizeof(U32));
#else         
         ret = setsockopt(sockFd->fd, level, IPV6_RECVPKTINFO,
                          (char *)&enable, sizeof(enable));
#endif /* SS_LINUX */
         break;
#endif /* LOCAL_INTF */

#endif /* IPV6_SUPPORTED */

      default:  
         /* wrong socket option type */
         RETVALUE(RFAILED);
         break;
   }

   if (ret == INET_ERR)
   {
#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetSetOpt() failed on line: %d \n\
              error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }          
   RETVALUE(ROK);
} /* end of cmInetSetOpt */



/*
*
*      Fun:   cmInetGetNumRead
*
*      Desc:  Gives the number of pending octets in the socket receive buffer.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*             
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetGetNumRead
(
CmInetFd *sockFd,               /* socket file descriptor */
U32      *dataLen               /* number of pending octets */
/* removed 3rd argument memInfo */
)
#else
PUBLIC S16 cmInetGetNumRead(sockFd, dataLen)
CmInetFd *sockFd;               /* socket file descriptor */
U32      *dataLen;              /* number of pending octets */
/* removed 3rd argument memInfo */
#endif
{
   S32 ret;                     /* temporary return value */

   /* removed local variables added for recvfrom call */
   
   TRC2(cmInetGetNumRead);   

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (dataLen == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif

   /* use ioctl call for all types of socket to get length of 
      pending data in the socket recv buffer */
#ifdef WIN32
   ret = ioctlsocket(sockFd->fd, FIONREAD, (U64 *)dataLen);     
#else 
#ifdef SS_PS
   ret = ioctl(sockFd->fd, FIOREAD, (char*)dataLen);
#else
#ifdef SS_VW
   ret = ioctl(sockFd->fd, FIONREAD, (S32)dataLen);
#else
   ret = ioctl(sockFd->fd, FIONREAD, dataLen);
#endif /* SS_VW */
#endif /* SS_PS */
#endif /* WIN32 */

   /* For UDP socket assign the length of pending data in the 
      socket recv buffer to largest datagram size. 
      Removed recvfrom call & necessary processing for it. */
   
   if (ret == INET_ERR)
   {
      /* removed error check CONABORTED added for recvfrom call. 
         Also return value changed from RCLOSED to ROK */
      /*  Check for reset connection */
      if ((INET_ERR_CODE == ERR_CONNREFUSED) ||
          (INET_ERR_CODE == ERR_CONNRESET))
      {
         *dataLen = 0;
         RETVALUE(ROK);
      }
     
      /* removed error check ERR_WOULDBLOCK */ 
      if (INET_ERR_CODE == ERR_AGAIN)
      {
         *dataLen = 0;
         RETVALUE(ROKDNA);
      }

#ifdef SS_LINUX
      *dataLen = 2048;
      RETVALUE(ROK);
#endif /* SS_LINUX */

      /* removed error debug printing added for recvfrom call. */
         
#ifdef CMINETDBG
      sprintf(prntBuf,"File: %s, cmInetGetNumRead() failed on line: %d \n\
              error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmInetGetNumRead */


#ifndef SS_PS
/*
*
*      Fun:   cmInetGetHostByName
*
*      Desc:  Resolves a host name into the appropriate 4 byte Internet 
*             address.     
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/
 
#ifdef ANSI
PUBLIC S16 cmInetGetHostByName
(
S8              *hostName,         /* host name */  
CmInetIpAddrTbl *addrTbl           /* Address Table of IPV4 Addresses */
)
#else
PUBLIC S16 cmInetGetHostByName (hostName, addrTbl)
S8              *hostName;         /* host name */  
CmInetIpAddrTbl *addrTbl;          /* Address Table of IPV4 Addresses */
#endif
{
#ifndef SS_VW
   U8            numAddrs;       /* Number of Addresses */
#endif /* SS_VW */

#if (defined(WIN32) || defined(SS_LINUX) || defined(HPOS))
   struct hostent *hostid;       /* pointer to host information */
#else
#ifndef SS_VW
   struct hostent hostid;        /* host information */
   S8 infoBuf[CM_INET_MAX_INFO]; /* info buffer */
   S32 err;                      /* error code */
#endif /* SS_VW */
#endif /* WIN32 || SS_LINUX || HPOS  */
   
   TRC2(cmInetGetHostByName)
 
#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((hostName == NULLP) || (addrTbl == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
 
   /* Initialise */
#ifndef SS_VW
   numAddrs       = 0;
#endif /* SS_VW */

   addrTbl->count = 0;

#if (defined(WIN32) || defined(SS_LINUX) || defined(HPOS))
   hostid = gethostbyname(hostName);
   if (hostid == 0) 
   {
#ifdef CMINETDBG
      sprintf(prntBuf,"File: %s, cmInetGetHostByName() failed on line:\n\
              %d, error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }
   if (hostid->h_addrtype != AF_INET)
   {
#ifdef CMINETDBG
      sprintf(prntBuf, "File: %s, cmInetGetHostByName() failed on line: %d,\n\
              error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }
   else
   {
      while ((numAddrs < CM_INET_IPV4_NUM_ADDR) &&
             (hostid->h_addr_list[numAddrs] != NULLP))
      {
         addrTbl->netAddr[addrTbl->count++] = 
            CM_INET_NTOH_U32 (*((U32 *) hostid->h_addr_list[numAddrs]));
         numAddrs += 1;
      }
   }
#else
 
#ifdef SS_VW
   {
      S32 vwIpAddr;
 
      vwIpAddr = hostGetByName(hostName);
      if (vwIpAddr == INET_ERR)
      {
#ifdef CMINETDBG
         sprintf(prntBuf,"File: %s, cmInetGetHostByName() failed on line:\n\
                 %d, error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         RETVALUE(RFAILED);
      }
      CM_COPY_VWIPADDR(vwIpAddr, &(addrTbl->netAddr[addrTbl->count]));
      addrTbl->count++;
   }
#else
 
   err = 0;                     /* err is not reset by gethostnyname_r()! */
   
   gethostbyname_r(hostName, &hostid, infoBuf, CM_INET_MAX_INFO, (int*)&err);
   if ((hostid.h_addrtype != AF_INET) || (err < 0))
   {
#ifdef CMINETDBG
      sprintf(prntBuf,"File: %s, cmInetGetHostByName() failed on line:\n\
              %d, error(%d)\n", __FILE__, __LINE__, INET_ERR_CODE);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }
   else
   {
      while ((numAddrs < CM_INET_IPV4_NUM_ADDR) &&
             (hostid.h_addr_list[numAddrs] != NULLP))
      {
         addrTbl->netAddr[addrTbl->count++] = 
            CM_INET_NTOH_U32 (*((U32 *) hostid.h_addr_list[numAddrs]));
         numAddrs += 1;
      }
   }
#endif /* SS_VW */
 
#endif /* WIN32  || SS_LINUX || HPOS */
   
   RETVALUE(ROK);
 
} /* end of cmInetGetHostByName */


/* The getipnodebyname is not supported on all the Solaris Operating system
 * versions. This has to be supported on operating systems that support IPV6
 * as per the RFC on the IPV6 socket interface. Hence this function is moved
 * under the IPV6_SUPPORTED flag */

/* This function now can be called for both IPv4 and IPv6. However, we will 
 * call cmInetGetHostByName inside for IPv4. Move all flag dependencies 
 * inside this function. */
/*
*
*      Fun:   cmInetGetIpNodeByName
*
*      Desc:  Resolves a host name into the appropriate 4 byte Internet 
*             address or into the appropriate 16 byte IPV6 address.
*             This function is expected to be thread safe and should be used
*             instead of the cmInetGetHostByName function.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
PUBLIC S16 cmInetGetIpNodeByName
(
S8              *hostName,         /* host name */  
CmInetIpAddrArr *addrArr           /* Array of addressed filled in */
)
#else
PUBLIC S16 cmInetGetIpNodeByName(hostName, addrArr)
S8              *hostName;         /* host name */  
CmInetIpAddrArr *addrArr;          /* Array of addressed filled in */
#endif
{
   /* for return value from cmInetGetHostByName */
#ifndef IPV6_SUPPORTED   
   S16    ret; 
#else   
   U8     numAddrs;              /* Number of addresses */
   int err;                      /* error code */
#ifdef SUNOS
#ifndef SS_LINUX
   struct hostent *hostid;       /* host information */
#endif /* SS_LINUX */
#endif /* SUNOS */
#endif /* IPV6_SUPPORTED */

   TRC2(cmInetGetIpNodeByName)

#ifdef IPV6_SUPPORTED      
      /* Initialisations */
   numAddrs = 0;
   err = 0;
#endif /* IPV6_SUPPORTED */   

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((hostName == NULLP) || (addrArr == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef IPV6_SUPPORTED
#ifdef SUNOS
#ifndef SS_LINUX
   
#ifdef IPV6_SUPPORTED
   if (addrArr->type == CM_INET_IPV6ADDR_TYPE)
      hostid = getipnodebyname(hostName, AF_INET6, 0, &err);
   else
#endif /* IPV6_SUPPORTED */
      hostid = getipnodebyname(hostName, AF_INET, 0, &err);
   if (!hostid)
   {
#ifdef CMINETDBG
      sprintf(prntBuf,"File: %s, cmInetGetIpNodeByName() failed on line:\n\
              %d, error(%d)\n", __FILE__, __LINE__, err);
      SPrint(prntBuf);
#endif /* CMINETDBG */
      RETVALUE(RFAILED);
   }

#ifdef IPV6_SUPPORTED
   if (addrArr->type == CM_INET_IPV6ADDR_TYPE)
   {
      if (hostid->h_addrtype == AF_INET6)
      {
         while ((numAddrs < CM_INET_IPV6_NUM_ADDR) &&
                 (hostid->h_addr_list[numAddrs] != NULLP))
         {
            /* Use the cminet fill macro here */
            CM_INET_COPY_IPV6ADDR(&addrArr->u.ipv6AddrArr.netAddr[numAddrs],
                                  hostid->h_addr_list[numAddrs]);
            addrArr->u.ipv6AddrArr.count++; 
            numAddrs += 1;
         }
      }
      else
      {
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, cmInetGetIpNodeByName() failed line: %d,\n\
                           error(%d)\n", __FILE__, __LINE__, err);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         RETVALUE(RFAILED);
      }
   }
   else
#endif /* IPV6_SUPPORTED */
   {
      if (hostid->h_addrtype == AF_INET)
      {
         while ((numAddrs < CM_INET_IPV4_NUM_ADDR) &&
                (hostid->h_addr_list[numAddrs] != NULLP))
         {
            addrArr->u.ipv4AddrArr.count ++;
            addrArr->u.ipv4AddrArr.netAddr[numAddrs] =
               CM_INET_NTOH_U32 (*((U32 *) hostid->h_addr_list[numAddrs]));
            numAddrs += 1;
         }
      }
      else
      {
#ifdef CMINETDBG
         sprintf(prntBuf, "File: %s, cmInetGetIpNodeByName() failed line: %d,\n\
                           error(%d)\n", __FILE__, __LINE__, err);
         SPrint(prntBuf);
#endif /* CMINETDBG */
         RETVALUE(RFAILED);
      }
   }
#endif /* SS_LINUX */
#endif /* SUNOS */

   RETVALUE(ROK);
#else
   ret = cmInetGetHostByName(hostName, &addrArr->u.ipv4AddrArr); 
   RETVALUE(ret);
#endif /* IPV6_SUPPORTED */
   
} /* end of cmInetGetIpNodeByName */


/*
*
*      Fun:   cmInetAddr
*
*      Desc:  Converts an ASCII string containig an internet address
*             ("xxx.xxx.xxx.xxx") into a CmInetIpAddr (U32) format.
*             This function is a wrapper for the inet_addr() call.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetAddr(
S8           *asciiAddr,        /* ascii address representation */
CmInetIpAddr *address           /* 4 byte interent address */
)
#else
PUBLIC S16 cmInetAddr(asciiAddr, address)
S8           *asciiAddr;        /* ascii address representation */
CmInetIpAddr *address;          /* 4 byte interent address */
#endif
{
   TRC2(cmInetAddr); 

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if (asciiAddr == NULLP)
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   
   *address = inet_addr(asciiAddr);
   if (*address == (U32)ERR_INADDRNONE)
   {
      /* asciiAddr does not contain a valid internet address */ 
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}


/*
*
*      Fun:   cmInetNtoa
*
*      Desc:  Converts an CmInetIPAddr based IP address into a string 
*             of the format "xxx.xxx.xxx.xxx".
*             This function is a wrapper for the inet_ntoa() call.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: This function delivers a pointer to a static buffer 
*             within the system. Therefore the string has to be copied 
*             by the caller before another call is made!
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetNtoa(
CmInetIpAddr   address,         /* 4 byte interent address */
S8           **asciiAddr        /* ascii address representation */
)
#else
PUBLIC S16 cmInetNtoa(address, asciiAddr)
CmInetIpAddr   address;         /* 4 byte interent address */
S8           **asciiAddr;       /* ascii address representation */
#endif
{
   struct in_addr inetAddr;     /* internet address structure */

   TRC2(cmInetNtoa); 

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if (asciiAddr == NULLP)
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   inetAddr.s_addr = address;

   *asciiAddr = inet_ntoa(inetAddr);
   if (*asciiAddr == NULL)
   { 
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}

/* The inet_pton is not supported on all the Solaris Operating system 
 * versions. This has to be supported on operating systems that support 
 * IPV6 as per the RFC on the IPV6 socket interface. Hence this function
 *is moved under the IPV6_SUPPORTED flag */
#ifdef IPV6_SUPPORTED
#ifdef SUNOS

/*
*
*      Fun:   cmInetPton
*
*      Desc:  Converts a IP address string to address.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: 
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetPton(
CmInetIpAddr  *address,         /* 4 byte interent address */
S8           *asciiAddr         /* ascii address representation */
)
#else
PUBLIC S16 cmInetPton(address, asciiAddr)
CmInetIpAddr  *address;         /* 4 byte interent address */
S8            *asciiAddr;       /* ascii address representation */
#endif
{
   S16    ret;

   TRC2(cmInetPton); 

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((asciiAddr == NULLP) || (address == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   ret = inet_pton(AF_INET, asciiAddr, (void *)address);
   if (ret != 1)
   { 
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmInetPton */
#endif /* SUNOS */
#endif /* IPV6_SUPPORTED */

#ifdef IPV6_SUPPORTED

/*
*
*      Fun:   cmInetPton6
*
*      Desc:  Converts a IP address string to IPV6 address suitable 
*             to be used in bind.
*
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: 
*
*      File:  cm_inet.c
*
*/
#ifdef ANSI
PUBLIC S16 cmInetPton6(
CmInetIpAddr6  *address6,       /* 16 byte interent address */
S8             *asciiAddr       /* ascii address representation */
)
#else 
PUBLIC S16 cmInetPton6(address6, asciiAddr)
CmInetIpAddr6 *address6;        /* 16 byte interent address */
S8            *asciiAddr;       /* ascii address representation */
#endif
{
   S16    ret;

   TRC2(cmInetPton); 

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((asciiAddr == NULLP) || (address6 == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   ret = inet_pton(AF_INET6, asciiAddr, (void *)address6);
   if (ret != 1)
   { 
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmInetPton6 */
#endif /* IPV6_SUPPORTED */
#endif /* SS_PS */


/*
*
*      Fun:   cmInetGetMemSize
*
*      Desc:  This function gives the max number of static buffer space that
*             the internet library will allocate. 
*
*      Ret:   ROK - successful
*
*      Notes: None.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetGetMemSize(
S32 *size                       /* max used memory size */
)
#else
PUBLIC S16 cmInetGetMemSize(size)
S32 *size;                      /* max used memory size */
#endif
{
#ifdef WIN32
   /* max static memory size depends on max flat buffer size */
   *size = CM_INET_MAX_MSG_LEN;
#else   
   /* max static memory size depends on max flat buffer or iovect size */
   *size = CM_INET_MAX_MSG_LEN;
#endif 

   RETVALUE(ROK);
}



/*
*
*      Fun:   cmInetInit
*
*      Desc:  This function initializes the socket library.
*
*      Ret:   ROK - successful
*
*      Notes: Required only for Winsock and not for 4.3BSD
*
*      File:  cm_inet.c
*
*/
 
#ifdef ANSI
PUBLIC S16 cmInetInit(
Void
)
#else
PUBLIC S16 cmInetInit(Void)
#endif
{
#ifdef WIN32
   U16     version;
   S32     err;
   WSADATA data;
 
   version = MAKEWORD(CM_INET_HIGH_VER, CM_INET_LOW_VER);
   err = WSAStartup(version, &data);
   if (err != 0)
   {
      RETVALUE(RFAILED);
   }
#endif
 
   RETVALUE(ROK);
}


/*
*
*      Fun:   cmInetDeInit
*
*      Desc:  This function de initializes the socket library. The
*             WINSOCK implementation de registers the application and
*             releases any resources allocated on behalf of the
*             application.
*
*      Ret:   ROK - successful
*
*      Notes: Required only for Winsock and not for 4.3BSD
*
*      File:  cm_inet.c
*
*/
 
#ifdef ANSI
PUBLIC S16 cmInetDeInit(
Void
)
#else
PUBLIC S16 cmInetDeInit(Void)
#endif
{
#ifdef WIN32
   S32     err;

   err = WSACleanup();
   if (err != 0)
   {
      RETVALUE(RFAILED);
   }
#endif
 
   RETVALUE(ROK);
}/* end of cmInetDeInit() */


/*
*
*      Fun:   cmInetGetSockName
*
*      Desc:  This function is used to retireve the current name 
*             for the specified socket descriptor. It returns the 
*             local association(address and port) for the socket.
* 
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: Please note if the socket was bound to CM_INET_INADDR_ANY
*             cmInetGetSockName() will not necessarily return the local
*             address information unless the socket has been connected.
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetGetSockName
(
CmInetFd *sockFd,               /* socket file descriptor */ 
CmInetAddr *locAddr
) 
#else
PUBLIC S16 cmInetGetSockName(sockFd, locAddr)
CmInetFd *sockFd;               /* socket file descriptor */ 
CmInetAddr *locAddr;
#endif
{
   struct sockaddr_in *sockAddr; 
#ifdef IPV6_SUPPORTED
   struct sockaddr_in6 *sockAddr6;
   struct sockaddr_in6 lclSockAddr;
#else
   CmInetSockAddr lclSockAddr;
#endif /* IPV6_SUPPORTED */
#ifdef UNIX
   socklen_t size;
#else
   U32  size;
#endif /* SS_LINUX */
   S32  errCode;
   S16  ret;

   TRC2(cmInetGetSockName);

#if (ERRCLASS & ERRCLS_INT_PAR)
   /* error check on parameters */
   if ((sockFd == NULLP) || CM_INET_INV_SOCK_FD(sockFd) ||
       (locAddr == NULLP))
   {
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   cmMemset((U8*)&lclSockAddr, 0, sizeof(lclSockAddr));
   size = sizeof(lclSockAddr);

#ifdef UNIX
   ret = getsockname(sockFd->fd, (CmInetSockAddr*)&lclSockAddr, 
                     (socklen_t *)&size);
#else
   ret = getsockname(sockFd->fd, (CmInetSockAddr*)&lclSockAddr, (int*)&size);
#endif /* SS_LINUX */

   if(ret == INET_ERR)
   {
      switch(errCode = INET_ERR_CODE)
      {
         case ERR_INVAL:
             sockAddr = (struct sockaddr_in *)&lclSockAddr;
#ifdef IPV6_SUPPORTED
             locAddr->type = CM_INET_IPV4ADDR_TYPE;
             locAddr->u.ipv4Addr.port = CM_INET_NTOH_U16(sockAddr->sin_port);
#else
             locAddr->port = CM_INET_NTOH_U16(sockAddr->sin_port);
#endif /* IPV6_SUPPORTED */
             RETVALUE(ROK);
         
         default:
#ifdef CMINETDBG
            sprintf(prntBuf,"File: %s, cmInetGetHostByName() failed \n\
                    on line: %d, error(%d)\n", __FILE__, __LINE__, 
                    INET_ERR_CODE);
             SPrint(prntBuf);
#endif /* CMINETDBG */
             RETVALUE(RFAILED);
      }/* end of switch */

   }/* end if */

   /* Fill the returned address in to locAddr */
#ifdef IPV6_SUPPORTED
   cmMemset((U8*)locAddr, 0, sizeof(CmInetAddr));
   if (size == sizeof(struct sockaddr_in6))
   {
      sockAddr6 = (struct sockaddr_in6 *)&lclSockAddr;
      locAddr->type = CM_INET_IPV6ADDR_TYPE;
      locAddr->u.ipv6Addr.port = CM_INET_NTOH_U16(sockAddr6->sin6_port);
      CM_INET_COPY_IPV6ADDR(&locAddr->u.ipv6Addr.ipv6NetAddr, 
                            &sockAddr6->sin6_addr);
   }
   else
   {
      sockAddr = (struct sockaddr_in *)&lclSockAddr;
      locAddr->type = CM_INET_IPV4ADDR_TYPE;
      locAddr->u.ipv4Addr.port = CM_INET_NTOH_U16(sockAddr->sin_port);
      locAddr->u.ipv4Addr.address = 
                                   CM_INET_NTOH_U32(sockAddr->sin_addr.s_addr);
   }
#else
   sockAddr = (struct sockaddr_in *)&lclSockAddr;
   locAddr->port    = CM_INET_NTOH_U16(sockAddr->sin_port);
   locAddr->address = CM_INET_NTOH_U32(sockAddr->sin_addr.s_addr);
#endif /* IPV6_SUPPORTED */
   RETVALUE(ROK);
}/* end of cmInetGetSockName() */

/*  New functions to peek into the file descriptor 
 * set */
#if (defined(SUNOS) || defined(WIN32) || defined(SS_LINUX) || defined(SS_VW) \
     || defined(HPOS))

/*
*
*      Fun:   cmInetFdSetInfoInit
*
*      Desc:  This function is used to initialise operating system specific
*             data that will be used to peek into the file descriptor lists
*             to get the sockets that are set 
* 
*      Ret:   ROK     - successful
*             RFAILED - failed
*
*      Notes: 
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetFdSetInfoInit
(
CmInetFdSetInfo *fdSetInfo
) 
#else
PUBLIC S16 cmInetFdSetInfoInit(fdSetInfo)
CmInetFdSetInfo *fdSetInfo;
#endif
{
#if (defined(SUNOS) || defined(SS_LINUX) || defined(SS_VW) || defined(HPOS))
   U16   arIdx;
   U8    curByte;
   U8    bitPos;
   CmInetFdSet *fdSet;
#endif /* SUNOS || SS_LINUX || SS_VW */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (fdSetInfo == NULLP)
      RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_INT_PAR */
  
   if (fdSetInfo->initDone == TRUE)
      RETVALUE(ROK);

#ifdef WIN32
   fdSetInfo->numFds = 0;
#endif /* WIN32 */

#if (defined(SUNOS) || defined(SS_LINUX) || defined(SS_VW)|| defined(HPOS))
   /* Check if we are on a big endian machine */
   arIdx = 0x01;
   if (*(U8 *)&arIdx)
      fdSetInfo->bigEndian = FALSE;
   else
      fdSetInfo->bigEndian = TRUE;

   fdSetInfo->arIdx = 0;
   fdSetInfo->ar[0] = 0xff;

   /* Initialise the array */
   /* The array contains bit positions for the first bit 
    * for each integer from 1 to 2^8. 
    */
   for (arIdx = 1; arIdx < 256; arIdx++)
   {
      curByte = arIdx;
      bitPos = 0;

      while(bitPos < 8)
      {
         if (curByte & 0x01)
         {
            fdSetInfo->ar[arIdx] = bitPos;
            break;
         }
         bitPos += 1;
         curByte = curByte >> 1;
      }
   }
   /* Calculate the number of array elements in this fd_set */
#if (defined(SS_LINUX)  &&  !defined(_GNU_SOURCE))
   fdSetInfo->numArElems = sizeof(CmInetFdSet)/sizeof(fdSet->__fds_bits[0]);
#else
   fdSetInfo->numArElems = sizeof(CmInetFdSet)/sizeof(fdSet->fds_bits[0]);
#endif /* SS_LINUX */
#endif /* SUNOS  || SS_LINUX || SS_VW || HPOS */   

   fdSetInfo->initDone = TRUE;
   RETVALUE(ROK);
}/* end of cmInetFdSetInfoInit() */


/*
*
*      Fun:   cmInetGetFd
*
*      Desc:  This function is used to get the file descriptor from the
*             file descriptor set.
* 
*      Ret:   ROK     - successful
*             ROKDNA  - socket not found
*             RFAILED - failed
*             RNA     - failed, initialisation not done
*
*      Notes: If the application modifies fdSet between calls to this
*             function then the results are undefined. This function should
*             be called in a loop till either it returns - not ROK, or if 
*             all sockets in the file descriptor set are processed. 
*
*      File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetGetFd
(
CmInetFdSetInfo *fdSetInfo,
CmInetFdSet     *fdSet,
CmInetFdType    *sockFd
) 
#else
PUBLIC S16 cmInetGetFd(fdSetInfo, fdSet, sockFd)
CmInetFdSetInfo *fdSetInfo;
CmInetFdSet     *fdSet;
CmInetFdType    *sockFd;
#endif
{
#if (defined(SUNOS) || defined(SS_LINUX) || defined(SS_VW) || defined(HPOS))
   U8 sizOfFdSetArElem;
   U8 bytesScanned;
   Bool found;
   U32 curIdx;
   U8 *tempByte;
   U8 bitPos;
#endif /* SUNOS || SS_LINUX || SS_VW */

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((fdSetInfo == NULLP) || (fdSet == NULLP) || (sockFd == NULLP))
      RETVALUE(RFAILED);

   if (fdSetInfo->initDone != TRUE)
      RETVALUE(RNA);
#endif /* ERRCLASS & ERRCLS_INT_PAR */

#ifdef WIN32
#if (ERRCLASS & ERRCLS_DEBUG)
   if (fdSetInfo->numFds > FD_SETSIZE)
      RETVALUE(RFAILED);
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if (!fdSet->fd_count)
      RETVALUE(ROKDNA);

   *sockFd = fdSet->fd_array[fdSetInfo->numFds];
   fdSetInfo->numFds += 1;
   RETVALUE(ROK);
#endif /* WIN32 */

#if (defined(SUNOS) || defined(SS_LINUX) || defined(SS_VW) || defined(HPOS))
   /* Start with arIdx and continue upto number of array elements. */
   curIdx = fdSetInfo->arIdx;
   found = FALSE;
   
#if (defined(SS_LINUX)  &&  !defined(_GNU_SOURCE))
   sizOfFdSetArElem = sizeof(fdSet->__fds_bits[0]);
#else
   sizOfFdSetArElem = sizeof(fdSet->fds_bits[0]);
#endif /* SS_LINUX */
    
   for (curIdx = fdSetInfo->arIdx; curIdx < fdSetInfo->numArElems;
        curIdx ++)
   {
#if (defined(SS_LINUX)  &&  !defined(_GNU_SOURCE))
      if (fdSet->__fds_bits[curIdx])
#else
      if (fdSet->fds_bits[curIdx])
#endif /* SS_LINUX */
      {
         /* Walk through the bytes in this element */
#if (defined(SS_LINUX)  &&  !defined(_GNU_SOURCE))
         tempByte = (U8 *)&fdSet->__fds_bits[curIdx];
#else
         tempByte = (U8 *)&fdSet->fds_bits[curIdx];
#endif /* SS_LINUX */

         /* Set the starting byte offset */
         if (fdSetInfo->bigEndian)
            tempByte += sizOfFdSetArElem - 1;

         for (bytesScanned = 0; bytesScanned < sizOfFdSetArElem; 
              bytesScanned ++)
         {
            if (*tempByte)
            {
               bitPos = fdSetInfo->ar[*tempByte];
               fdSetInfo->arIdx = curIdx;
               /* Calculate fd depending on where we are */
               *sockFd = ((bytesScanned << 3) + bitPos);
               *sockFd += (curIdx  * (sizOfFdSetArElem << 3));
               /* Clear the file descriptor */
               *tempByte &= ~(1 << bitPos);
               RETVALUE(ROK);
            }
            if (fdSetInfo->bigEndian)
               tempByte -= 1;
            else
               tempByte += 1;
         }
         break;
      }
   }

   if (!found)
      RETVALUE(ROKDNA);
    
   RETVALUE(ROK);
#endif /* SUNOS || SS_LINUX || SS_VW || HPOS */
} /* end of cmInetGetFd */

#endif /* SUNOS || WIN32  || SS_LINUX || SS_VW || HPOS  */ 


/* add cmInetConvertStrToIpAddr and
 * cmInetAsciiToIpv4 functions */
/*
*
*       Fun:   cmInetConvertStrToIpAddr
*
*       Desc:  This function parses the input string for an IPV4/IPV6 address.
*              formats:
*              1) IPV4 in dot number format:
*                    206.216.108.253
*              2) IPV6, in uncompressed, compressed, and IPV4 embedded format 
*                    10:20:30:40:502:610:70C:80ad
*                    A5::34:45
*                    45::AB:34:123.34.5.667
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  cm_inet.c
*
*/

#ifdef ANSI
PUBLIC S16 cmInetConvertStrToIpAddr
(
U16                len,                /* Length of IP address */
U8                 *val,               /* Domain Name String */
CmInetNetAddr      *address            /* IP Address */
)
#else
PUBLIC S16 cmInetConvertStrToIpAddr(len, val, address)
U16                len;                /* Length of IP address */
U8                 *val;               /* Domain Name String */
CmInetNetAddr      *address;           /* IP Address */
#endif
{
   U8              idx;                /* Index for string*/
   U8              ipv4[CM_INET_IPV4ADDR_SIZE]; /* IPV4 Address bytes */
#ifdef IPV6_SUPPORTED
   U16             *ipv6;                 /* IPV6 Address bytes */
   U16             ipv6Reg[8];           /* regular IPV6 Address bytes */
   U16             ipv6Cmp[8];           /* compressed IPV6 Address bytes */
   U8              numBlk;               /* number of blocks in IPV6 addr */
   Bool            compressed;           /* IPV6 in compressed format */
   U8              ipv6Idx;              /* counter for IPV6 */
   U8              blkBeginIdx;          /* IPV6, char index for the 
                                            beginning of the block */
   U8              i;                    /* counter for IPV6 */
   S16             retVal;               /* return value */
   Bool            embedIPV4 = FALSE;    /* IPV4 embedded in IPV6 ? */
#endif /* IPV6_SUPPORTED*/

   TRC2(cmInetConvertStrToIpAddr)

   idx = 0;
#ifdef IPV6_SUPPORTED
   numBlk = 0;
   ipv6Idx = 0;
   compressed = FALSE;
   embedIPV4 = FALSE;
   ipv6 = ipv6Reg; /* assign pointer to IPV6 regular, uncompressed */
   cmMemset((U8 *)ipv6Reg, 0, CM_INET_IPV6ADDR_SIZE);
   cmMemset((U8 *)ipv6Cmp, 0, CM_INET_IPV6ADDR_SIZE);
#endif /* IPV6_SUPPORTED*/

   cmMemset((U8 *)ipv4, 0, CM_INET_IPV4ADDR_SIZE);

   /* Check for IP Address */
   while ((val[idx] != '.') && (val[idx] != ':') && 
          (idx < len))
   {
#if (ERRCLASS & ERRCLS_DEBUG)
      if (((val[idx] < '0') || (val[idx] > '9')) &&
          ((val[idx] < 'a') || (val[idx] > 'f')) &&
          ((val[idx] < 'A') || (val[idx] > 'F')))
      {
         /* Not a digit */
         RETVALUE(RFAILED);
      }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

      /* Convert Ascii to integer */
      CM_INET_ATOI(ipv4[0], val[idx]);

#ifdef IPV6_SUPPORTED
      /* convert Ascii to hex */
      CM_INET_ATOH(ipv6[0], val[idx]);
#endif /* IPV6_SUPPORTED */

      idx++; /* move to the next character */
   } /* while, try to determine IPV4 or IPV6 */

#if (ERRCLASS & ERRCLS_DEBUG)
   if ((val[idx] != '.') && (val[idx] != ':'))
   {
      /* Not a digit */
      RETVALUE(RFAILED);
   } /* if, couldn't determine IPV4 or IPV6 */
#endif /* (ERRCLASS & ERRCLS_DEBUG) */


   if (val[idx] == '.')
   {
      idx++;
      cmInetAsciiToIpv4(3, &(ipv4[1]), (U16)(len - idx), &(val[idx]));
         
      address->type = CM_INET_IPV4ADDR_TYPE;
      CM_INET_GET_IPV4_ADDR_FRM_STRING(address->u.ipv4NetAddr, ipv4);
   } /* if, IPV4 */
#ifdef IPV6_SUPPORTED
   else 
   {
      numBlk = 1; /* already converted the 1st block */
      ipv6Idx = 0;
      while ((val[idx] != '\0') && (idx < len) && (numBlk <= 8))
      {
         idx++; /* go to the next char, either a number or the 2nd : */
         if (val[idx] == ':')
         {
#if (ERRCLASS & ERRCLS_DEBUG)
            if (compressed == TRUE)
            {
               /* can't have 2 :: */
               RETVALUE(RFAILED);
            } /* if, 2 :: */
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

            compressed = TRUE;
            idx++; /* skip the : */
            ipv6 = ipv6Cmp;
            ipv6Idx = 0;
         } /* if, IPV6 in compressed format :: */
         else
         {
            ipv6Idx++;
         } /* else, uncompressed, convert next block */

         numBlk++; /* increase number of blocks */

         /* assign the index the beginning of the block */
         blkBeginIdx = idx;

         while(val[idx] != ':' && val[idx] != '\0' && idx < len)
         {
            if (val[idx] == '.')
            {
               /* convert number to IPV4 */
              ipv6[ipv6Idx] = 0; /* clear out whatever we did */
              cmMemset((U8 *)ipv4, 0, CM_INET_IPV4ADDR_SIZE);
              retVal = cmInetAsciiToIpv4(4, ipv4, len - blkBeginIdx, 
                                     &(val[blkBeginIdx]));
              /* stop the loop, embedded IPV4 is the last part of
                 an IPV6 address */
              if (retVal != ROK)
              {
                 RETVALUE(retVal);
              }
              embedIPV4 = TRUE;
              break;
            } /* if, '.' means IPV4 address embedded in IPV6 */

#if (ERRCLASS & ERRCLS_DEBUG)
            if (((val[idx] < '0') || (val[idx] > '9')) &&
                ((val[idx] < 'a') || (val[idx] > 'f')) &&
                ((val[idx] < 'A') || (val[idx] > 'F')))
            {
               /* Not a digit */
               RETVALUE(RFAILED);
            }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

            /* Convert Ascii to integer */
            CM_INET_ATOH(ipv6[ipv6Idx], val[idx]);

            /* move to the next index */
            idx++;
         } /* while, convert a block of 16 bits Hex number */
         if (embedIPV4 == TRUE)
         {
            ipv6Idx--; /* deccrease in case of compressed IPV6 */
            break; /* stop the while look */
         } /* if, IPV4 embedded in IPV6 */
      } /* while, IPV6 parsing */
      if (compressed == TRUE)
      {
         if (embedIPV4 == TRUE)
         {
            numBlk = 5; /* the last 2 blocks are IPV4 */
         } /* if, IPV4 embedded */
         else
         {
            numBlk = 7; /* copy from the last block */
         } /* else, no embedded IPV4 */

         /* type cast U8 over -1 becasue we want to copy the last block,
            ipv6Cmp[0]
         */
         for (i = ipv6Idx; i != (U8) (-1); i --)
         {
            ipv6Reg[numBlk] = ipv6Cmp[i];
            numBlk--;
         } /* for, copying compress IPV6 to regular IPV6 */
      } /* if, compressed format */

      if (embedIPV4 == TRUE)
      {
         ipv6Reg[6] = PutHiByte(ipv6Reg[6], ipv4[0]);
         ipv6Reg[6] = PutLoByte(ipv6Reg[6], ipv4[1]);
         ipv6Reg[7] = PutHiByte(ipv6Reg[7], ipv4[2]);
         ipv6Reg[7] = PutLoByte(ipv6Reg[7], ipv4[3]);
      } /* if, IPV4 embedded */

      /* convert IPV6 to cmInetIpv6 */
      address->type = CM_INET_IPV6ADDR_TYPE;
      cmMemcpy((U8 *)address->u.ipv6NetAddr,
               (CONSTANT U8 *) ipv6Reg,  CM_INET_IPV6ADDR_SIZE);
   } /* else, IPV6 */
#endif /* IPV6_SUPPORTED */

   RETVALUE(ROK);
} /* cmInetConvertStrToIpAddr */


/*
*
*       Fun:   cmInetAsciiToIpv4
*
*       Desc:  This function parses the input string to an IPV4 address.
*              The input string can be 
*              - the whole IPV4 address, '123.43.45.56', or
*              - a part of it. '34.56.454'
*              numBytes: number of bytes needs to be converted, IPV4 has
*                        4 bytes. If we are only converting the end of an
*                        address, this number needs to be adjusted. For
*                        example, when converting '34.56.454]', the number
*                        is 3.
*
*       Ret:   ROK     - SUCCESS
*              RFAILED - FAILURE
*
*       Notes: 
*
*       File:  cm_inet.c
*
*/
#ifdef ANSI 
PUBLIC S16  cmInetAsciiToIpv4
(
U8                 numBytes,           /* number of Byte to convert */
U8                 *ipv4Addr,          /* IPV4 Address */
U16                len,                /* Length of IP address */
U8                 *val                /* Domain Name String */
)
#else
PUBLIC S16 cmInetAsciiToIpv4(numBytes, ipv4Addr, len, val)
U8                 numBytes;           /* number of Byte to convert */
U8                 *ipv4Addr;          /* IPV4 Address */
U16                len;                /* Length of IP address */
U8                 *val;               /* Domain Name String */
#endif
{
   U8              byteCount;          /* Byte Count */
   U8              idx;                /* Index for string*/

   TRC2(cmInetAsciiToIpv4)

   idx = 0;
   for (byteCount = 0; byteCount < numBytes; byteCount++)
   {
      while((val[idx] != '.') && (idx < len))
      {
#if (ERRCLASS & ERRCLS_DEBUG)
         if (val[idx] < '0' || val[idx] > '9')
         {
            /* Not a digit */
            RETVALUE(RFAILED);
         }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         /* Convert Ascii to integer */
         CM_INET_ATOI(ipv4Addr[byteCount], val[idx]);

         /* move to the next index */
         idx++;
      }
      idx++;
   }
   
   RETVALUE(ROK);
} /* cmInetAsciiToIpv4 */

/*
 * Packing Functions
 */

  
/*
 *      UNPACKING FUNCTIONS
 */





/********************************************************************30**
 
         End of file:     cm_inet.c@@/main/32 - Thu Jul 28 15:46:34 2005
 
*********************************************************************31*/

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
 
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      mf   1. initial release.
1.2          ---      aa   1. Added packing and unpacking for cmInetAddr

1.3          ---      asa  1. Added cmInetGetSockName, cmInetDeInit.
                           2. Changed Prototype for cmInetSetOpt
                           3. VxWorks Support from GTP product group
1.4          ---      asa  1. Added support for PSOS
                           2. Initialized msgLen in cmInetSendMsg.
1.5          ---      bbk  1. Upgraded cmInetGetHostByName() to return
                              address table and fixed endian problem in 
                              previous code
                           2. New defines added and used
                              ERR_ALREADY maps to WSAEALREADY on windows
                              and to EAGAIN on other platforms
                              ERR_AGAIN maps to WSAEWOULDBLOCK on windows
                              and to EAGAIN on other platforms.
                           3. Check for ERR_AGAIN for as return value of
                              sendto and sendmsg functions
                           4. Corrected problem of indicating wrong length
                              of datagram received to the library user.
                           5. ioctl warnings on VxWorks fixed
/main/6                 cvp  1. New defines added and used
                              ERR_EINVAL maps to WSAEINVAL on windows 
                              and to 0 on other platforms
                           2. Added a check for EINVAL in connect for 
                              Windows
                           3. Added ROUTRES as return value from 
                              buildRecvBuf, buildRecvMsg, cmInetRecvMsg 
                              and cmInetSendMsg functions.
                           4. Changed MAX_BACKLOG for Windows NT to 1.
                           5. Added CMINETDBG flag to enable debug 
                              prints.
                           6. Changed the copyright header.
            001.main_6 cvp 1. Added support for Linux.
                           2. Changed logic of filling the address table 
                              in cmInetGetHostByName function.
             /main/8                  sb  1. Protocol field added in cmInetSocket 
                              primitive.
                           2. Options added in setsockOpt for TOS, TTL, 
                              DF, & IP_HDRINCLD.
                       cvp 3. Added CM_INET_OPT_MCAST_IF and 
                              CM_INET_OPT_MCAST_LOOP options.
                           4. Added check for ERR_WOULDBLOCK from 
                              sendmsg function.
/main/9      ---       cvp 1. Updated for 64 bit compilation.
/main/9      ---       cvp 1. New defines added and used ERR_PIPE, 
                              ERR_TIMEOUT and ERR_CONNRESET.
                           2. Changed the logic in buildRecvBuf.
                           3. Check for connection refused and timeout
                              errors in cmInetConnect.
                           4. Initialising new socket type in 
                              cmInetAccept.
                           5. Put transmit and send iov vector arrays
                              on stack.
                           6. Moved debug statements as close to the 
                              system call as possible.
                           7. Check for ERR_PIPE in send function.
                           8. Removed call to select in receive 
                              function. 
                           9. Added new functions to peek into the 
                              file descriptor set. 
/main/10     ---      dvs  1. ClearCase release
/main/11     ---       cg  1. updating cmInetSetOpt to add multicast 
                              support for VxWorks (SS_VW_MCAST).
/main/12     ---       cvp 1. If socket creation failed set the 
                              sockFd->fd to CM_INET_INV_SOCKFD. 
                           2. Added a function buildSendIovec to build 
                              the iov vector array. 
                           3. The mBuf to be sent in cmInetSendMsg is 
                              compressed if the number of dBufs in the 
                              mBuf is greater than CM_INET_MAX_DBUF. 
                           4. buildRecvBuf returns RNA if the message to 
                              be read is bigger than the gather array.
                           5. If RNA is returned then a flat buffer is 
                              allocated in cmInetRecvMsg. 
                           6. The changes in points 2, 3, 4, and 5 are to 
                              account for mBufs with a large number of 
                              dBufs to be sent or received. These changes 
                              are not valid for TCP sockets.
                           7. Removed second call to cmInetSelect in 
                              cmInetRecvMsg. The funciton user must call
                              cmInetSelect before calling cmInetRecvMsg,
                              which is usually the case. Hence the 
                              second call to cmInetSelect is an overhead.
                           8. Changed ERR_TIMEOUT to ERR_TIMEDOUT. 
                              ERR_TIMEOUT is being used in a pSos 
                              header file.
/main/13     ---      cvp  1. Added IPV6 support.
                           2. Changed the buildSendIovec function to 
                              accept a new parameter. The cmInetSendMsg
                              function will now send data in a loop 
                              till either the kernel buffer is full or
                              till all the data is sent. This change
                              applies to non windows operating systems.
                           3. changed the copyright header.
/main/13+  001.main_13 cvp 1. moved IPv4 address/port packing unpacking
                              functions to cm_tpt.c file. M3UA needs 
                              these functions but does not compile 
                              cm_inet.c file.
/main/13+  002.main_13 mmh 1. Moved initialisation of msg structure.
                           2. Incase of flat buffer allocation copy only
                              the received length.
                           3. Added ERR_AGAIN check in cmInetRecvMsg
                              function.
                           4. In most cases, multicasting should be enough,
                              if in some special cases the broadcasting
                              is needed, the CM_INET_OPT_BROADCAST (broadcast)
                              options is available.
                           5. Adding workarround for UDP socket receiving
                              ICMP message bug in Windows 2000 OS, to make
                              it work please also download Windows Service
                              Pack 2 for Win2K from Microsoft. To use this
                              feature please also enable WIN2K flag.
                           6. Add 3rd argument in cmInetGetNumRead to carry
                              memory info to allocate recv buffer for recvfrom()
                           7. Use ioctl for TCP socket and recvfrom for UDP
                              socket in cmInetGetNumRead function.
                           8. Changed all calls made to cmInetGetNumRead. The
                              cmInetGetNumRead may return ROKDNA, RCLOSED, 
                              RFAILED, ROUTRES or ROK.
                           9. Added flag ERR_CONNABORTED. added check after
                              function call sendmsg, sendto, recvfrom and
                              recvmsg    
                          10. Added check for ERR_AGAIN after recvfrom call.
                          11. Added check for ERR_CONNREFUSED in 
                              cmInetGetNumRead function call.
                          12. Added check for ERR_AGAIN after recvfrom call
                              in the cmInetGetNumRead function.
                          13. Moved cmInetGetIpNodeByName to be under the 
                              IPV6_SUPPORTED flag.
                          14. Moved the cmInetPtoN to be under the 
                              IPV6_SUPPORTED flag.
/main/13+  003.main_13 mmh 1. Corrected WIN2k flag by replacing it with WIN2K.
                           2. Removing 3rd arg for MemInfo in cmInetGetNumRead
                              func. 
                           3. Removing call to recvfrom in cmInetGetNumRead
                              fun to get pending data len for UDP socket. 
                           4. Corrected all calls made to cmInetGetNumRead by
                              removing 3rd arg.
                           5. Added check for socket type after cmInetGetNUmRead
                              call returns. Set pendLen depending on socket type.
                           6. Return RCLOSED for TCP & return ROKDNA for UDP
                              when pendLen is 0 in cmInetPeek fun.
                           7. Removed error check CONABORTED from 
                              cmInetGetNumRead function.
                           8. Added check ERR_WOULDBLOCK after recvfrom, 
                              ERR_AGAIN after recvmsg call.
                           9. Changed type of 6th arg in recvfrom call to (int *).
                              Put recvfrom call separately under SS_VW flag.
                          10. Removed CONSTANT in setsockopt calls under for VW.
                          11. Moved up cleanup before error checks made after 
                              recvfrom & recvmsg calls in cmInetRecvMsg.
/main/13+  004.main_13 ml 1. Added !(defined(CMINETFLATBUF) for buildRecvBuf(),
                             buildRecvMsg() and buildSendIovec().
                          2. Casting bufLen to avoid compilar warnings.    
                          3. Added different recvfrom calls with different
                             6th arg for different OS.
/main/13+  005.main_13 bdu 1. Add check for ERR_WOULDBLOCK.
                           2. Add SO_KEEPALIVE option.
                           3. Support TOS and TTL option in VxWorks.
                           4. In cmInetRecvMsg(), if a 0 byte UDP message is
                              received return ROKDNA.
                           5. Moved the error print message.
                           6. Use send instead of sendto on VxWorks.
/main/13+  006.main_13 bdu 1. Some changes for IPV6 support.
                           2. Remove the compiler warings on some platform.
                           3. fix some bugs.
                           4. Add 2 new functions: cmInetConvertStrToIpAddr
                              and cmInetAsciiToIpv4.
/main/13+  007.main_13 bdu 1. Call getsockopt in cmInetRecvMsg for UDP
                              socket if pending bytes is 0.
                           2. Correct the bug in cmInetGetSockName.
                           3. Correct the error checking in cmInetAddr.
                           4. Remove some compiler warnings.
/main/13+  008.main_13 mmh 1. Move flag dependency of cmInetGetIpNodeByName
                              inside & call cmInetGetHostByName for IPv4
/main/13+  009.main_13 bdu 1. Change for MCAST_IF and MCAST_LOOP option.
/main/13+  010.main_13 bdu 1. added new prototypes of private functions added
                              under IPV6_OPTS_SUPPORTED & LOCAL_INTF flags
                           2. in function buildRecvBuf added defined(_XPG4_2)
                           3. in function cmInetAccept 
                              - change CmInetSockAddr to sockAddr
                              - INSURE fix
                              - added for IPv6/IPv4 socket distinguishing
                           4. in function cmInetSendMsg
                              - added new declarations for 
                                IPV6_OPTS_SUPPORTED flag
                              - declare local var curMsgIdx, cmsgData
                              - init cmsgData and curMsgIdx to 0
                              - init msg structure to 0
                              - added  defined(_XPG4_2) with SS_LINUX
                              - if the sender wants to send Ipv6 exten. 
                                headers then call proper functions
                           5. added following new functions for IPv6 extn hdrs
                              - cmInet6BuildSendPktinfo,cmInetBuildSendHoplimit 
                                cmInet6BuildSendHBHOpts,cmInet6BuildRecvRtHdr
                                cmInet6BuildSendRouteOpts,
                                cmInet6GetHopLimitValue and
                                cmInet6BuildRecvHopOptsArr
                           6. in function cmInetRecvMsg
                              - added new function declaration for LOCAL_INTF
                                and IPV6_OPTS_SUPPORTED flags
                              - declare local vars under LOCAL_INTF & 
                                IPV6_OPTS_SUPPORTED flags
                              - init some variables to fix insure warnings
                              - cast parameter of getsockopt to remove warning
                              - assign msg.msg_control to ancillData and 
                                msg.msg_controllen to sizeof(ancillData)
                              - call proper functions to process IPv6 extn hdrs
                           7. in function cmInetSetOpt
                              - added following socket options 
                                IP_OPTIONS, IP_ROUTER_ALERT, IPV4_PKTINFO, 
                                RECVIPV6_HBHOPTS, RECVIPV6_DSTOPTS, 
                                RECVIPV6_RTHDR, IP_ROUTER_ALERT6, IPV6_PKTINFO
/main/13+  011.main_13 bdu 1. change for pSOS compilation
/main/13+  012.main_13 bdu 1. change in cmInetConvertStrToIpAddr function.
/main/13+  013.main_13 rs  1. WINCE support.
/main/13+  014.main_13 cg  1. VxWorks compilation for IPv6 Support.
/main/30     ---      pk   1. GCP 1.5 release
/main/30  001.main_30 dp   1. Revert back to main29+GCP bug fixes after wrong
                              release in GCP1.5
                           2. ipv4 cmmeset moved outside the 
                              ifdef IPV6_SUPPORTED    
                           3. moved err out of SUNOS
/main/31     ---      dp   1. clearcase release for main29 correction
/main/32     ---       kp   1. Fixed some warnings.
                           2. Removed conditional define CM_INET_FDSET_PEEK
                           3. Fix for returning ROKDNA in cmInetGetFd() on
                              WIN32.

*********************************************************************91*/

