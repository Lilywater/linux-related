/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     Common Conversion Function - Hooks

     Type:     C source file
  
     Desc:     C source code to initialize the System Agent Conversion
               function hooks array. This structure is used by the System
               Agent Distributed FT/HA CORE component.

     File:     cm_cfn.c
  
     Sid:      cm_cfn.c@@/main/1 - Thu Oct 12 09:22:54 2000
  
     Prg:      ark
  
*********************************************************************21*/

/* header include files (.h)            */
#include "envopt.h"                             /* environ options      */  
#include "envdep.h"                             /* environ dependent    */
#include "envind.h"                             /* environ independent  */
#include "gen.h"                                /* general layer        */
#include "ssi.h"                                /* system services      */
#include "cm_ftha.h"                            /* common DFT/HA        */

/* header/extern include files (.x)     */
#include "gen.x"                                /* general layer        */
#include "ssi.x"                                /* system services      */
#include "cm_ftha.x"                            /* common DFT/HA        */
#include "cm_cfn.x"                             /* conv fn data structs */



/* the following array contains pointers to the *
 * encode and decode functions for each protocl *
 * layter PSF                                   *
 * The cmCfnInfo type is defined in cm_cfn.x    */
CmCfnInfo cmCfInfo[] =
{
   {                                            /****************************/
      0,                                        /* WARNING: Do not remove   */
      NULLP,                                    /* dummy first enity        */
      NULLP                                     /* this is unused           */
   },                                           /****************************/
#ifdef DL                                       /* Entity: Dummy Layer      */
   {
      ENTDL,                                    /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef SH                                       /* Entity: SH - Peer        */
   {
      ENTSH,                                    /* Conv. fn for this entity */
      shEncodePeerReq,                          /* Encode conversion fn.    */
      shDecodePeerCfm                           /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef SG                                       /* Entity: System Manager   */
   {
      ENTSG,                                    /* Conv. fn for this entity */
      sgCfnEncode,                              /* Encode conversion fn.    */
      sgCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef DL1                                      /* Entity: Dummy Layer      */
   {
      ENTDL+1,                                  /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef DL2                                      /* Entity: Dummy Layer      */
   {
      ENTDL+2,                                  /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef DL3                                      /* Entity: Dummy Layer      */
   {
      ENTDL+3,                                  /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef DL4                                      /* Entity: Dummy Layer      */
   {
      ENTDL+4,                                  /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
#ifdef DL5                                      /* Entity: Dummy Layer      */
   {
      ENTDL+5,                                  /* Conv. fn for this entity */
      dlCfnEncode,                              /* Encode conversion fn.    */
      dlCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag SP to ZP */
#ifdef ZP                                       /* Entity: PSF-SCCP         */
   {
      ENTSP,                                    /* Conv. fn for this entity */
      zpCfnEncode,                              /* Encode conversion fn.    */
      zpCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag SN to ZN */
#ifdef ZN                                       /* Entity: PSF-MTP3         */
   {
      ENTSN,                                    /* Conv. fn for this entity */
      znCfnEncode,                              /* Encode conversion fn.    */
      znCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag SI to ZI */
#ifdef ZI                                       /* Entity: PSF-ISUP         */
   {
      ENTSI,                                    /* Conv. fn for this entity */
      ziCfnEncode,                              /* Encode conversion fn.    */
      ziCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag ST to ZT */
#ifdef ZT                                       /* Entity: PSF-TCAP         */
   {
      ENTST,                                    /* Conv. fn for this entity */
      ztCfnEncode,                              /* Encode conversion fn.    */
      ztCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag IN to ZQ */
#ifdef ZQ                                       /* Entity: PSF-Q.930/Q.931  */
   {
      ENTIN,                                    /* Conv. fn for this entity */
      zqCfnEncode,                              /* Encode conversion fn.    */
      zqCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag AM to ZM */
#ifdef ZM                                       /* Entity: Q.93B            */
   {
      ENTAM,                                    /* Conv. fn for this entity */
      zmCfnEncode,                              /* Encode conversion fn.    */
      zmCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag CC to ZC */
#ifdef ZC                                       /* Entity: PSF-ICC          */
   {
      ENTCC,                                    /* Conv. fn for this entity */
      zcCfnEncode,                              /* Encode conversion fn.    */
      zcCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag RM to ZR */
#ifdef ZR                                       /* Entity: PSF-Resource Manager */
   {
      ENTRM,                                    /* Conv. fn for this entity */
      zrCfnEncode,                              /* Encode conversion fn.    */
      zrCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_001.main_1 - Changed compile time flag RT to ZS */
#ifdef ZS                                       /* Entity: PSF-Router       */
   {
      ENTRT,                                    /* Conv. fn for this entity */
      zsCfnEncode,                              /* Encode conversion fn.    */
      zsCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
/* cm_cfn_c_002.main_1 - Adding conversion functions for PSF-MG */
#ifdef ZG                                        /* Entity: MG              */
   {
      ENTMG,                                    /* Conv. fn for this entity */
      zgCfnEncode,                              /* Encode conversion fn.    */
      zgCfnDecode                               /* Decode conversion fn.    */
   },
#endif                                          /****************************/
   {                                            /* WARNING: This is the end */
      ENTNC                                     /* of list marker. Add ent. */
   }                                            /* info before this slot.   */
};


/********************************************************************30**
  
         End of file:     cm_cfn.c@@/main/1 - Thu Oct 12 09:22:54 2000
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      ark  1. Initial release.
  cm_cfn_c_001.main_1  ns  2. Changed the product compile time flag to
                              product PSF compile time flag
  cm_cfn_c_002.main_1  ds  3. Adding conversion functions for PSF-MG.

*********************************************************************91*/
