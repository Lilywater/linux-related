/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
        Name:     common PSF file
    
        Type:     C source file
  
        Desc:     This file contains common PSF upd hdr packing unpacking 
                  fns. All prds _released_ with COER2 compliance should use 
                  this file instead of cm_pftha.c

                  TDS_FTHA_CUST_PKUNPK is to be defined if the customer 
                  has a heterogeneous env, and needs to to 
                  byte-by-byte packing fns (NOT PROVIDED!). This file 
                  does structure packing.

        File:     cm_psfft.c

        Sid:      cm_psfft.c@@/main/3 - Thu Jan 24 14:18:13 2002
  
        Prg:      cp
  
*********************************************************************21*/
 
  
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_lib.x"        /* common library */
#include "cm_ftha.x"       /* common FTHA */
#include "cm_psfft.x"      /* common PSF */

  
/* local defines */

/* local typedefs */

/* function declerations */

/* public variable declarations */

/* public variable definitions */

/* private variable definitions */

/* loosely coupled update moudle - management interface */

/* primtive packing functions */

/**************************************************************************
 * All CORE2 related stuff present after this line.                       *
 **************************************************************************/

#ifndef TDS_FTHA_CUST_PKUNPK
/* API for header manipulation */

/*
 *
 *      Fun:   cmPFthaUHPk
 *
 *      Desc:  This function packs the update message header in the buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed. (***mBuf contents are not to be 
 *                                   trusted on failure***)
 *
 *      Notes: Pass a filled header to this function.  If the order of
 *             packing is changed, all teh header manipulation
 *             functions should be relooked because of padding
 *             concerns.
 *             
 *             **IMPORTANT** On failure of thsi function, the contents of
 *             mBuf  (parameter) are not to be trusted.
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHPk
(
CmPFthaUpdHdr *hdr,            /* Update message header */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmPFthaUHPk (hdr, mBuf)
CmPFthaUpdHdr *hdr;            /* Update message header */
Buffer *mBuf;                  /* message buffer */
#endif
{
   U8 tmpArr[sizeof (CmPFthaUpdHdr)];
   U8 tmpArrRev[sizeof (CmPFthaUpdHdr)];
   U16 len;
   U16 i;

   TRC2 (cmPFthaUHPk);

   len = 0;

   /* Sanity checks */
   if ((NULLP == hdr) || (NULLP == mBuf))
      RETVALUE (RFAILED);      

   /* 1. Copy the fixed portion in the buffer */
   /* Note : We are packing multiple fields in one shot for efficiency */
   cmMemcpy (&tmpArr[len], (U8 *)hdr, 
             ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
              (U32)(Void *)(NULLP)));

   len += ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
          (U32)(Void *)(NULLP));

   /* 2. Based on the flag copy teh optional part of the header */
   if (hdr->flag & CMPFTHA_FLAG_RSETID_CRIT)
   {
      /* Pack the optional portion for the critical resource set Id */
      cmMemcpy (&tmpArr[len], (U8 *)&hdr->opt.crit.masterId, sizeof (CmFthaMasterId));
      len += sizeof (CmFthaMasterId);

      cmMemcpy (&tmpArr[len], (U8 *)&hdr->opt.crit.updType, sizeof (U8));
      len += sizeof (U8);

      if (hdr->opt.crit.updType == CMPFTHA_UPDTYPE_M_CON) 
      {
         /* pack the proc list for master controlled updates */
         if (hdr->opt.crit.opt.procList.num > CMFTHA_MAX_NODES_PER_ENT)
            RETVALUE (RFAILED);

         cmMemcpy (&tmpArr[len], (U8 *)&hdr->opt.crit.opt.procList.num, 
                   sizeof (U16));
         len +=  sizeof (U16);

         cmMemcpy (&tmpArr[len], (U8 *)&hdr->opt.crit.opt.procList.list[0], 
                   hdr->opt.crit.opt.procList.num * sizeof (ProcId));
         len +=  hdr->opt.crit.opt.procList.num * sizeof (ProcId);
      }
      /* Insert procedures for other types of updates here */
   }
   else
   {
      /* Pack the optional portion for the non critical resource set Id */
      /* None for now */
   }

   /* Reverse the tmpArr so that we can use SAddPreMsgMult */
   for (i = 0; i < len; i++)
      tmpArrRev[i] = tmpArr[len-i-1];

   if (SAddPreMsgMult (&tmpArrRev[0], len, mBuf) != ROK)
      RETVALUE (RFAILED);

   RETVALUE (ROK);
} /* cmPFthaUHPk */


/*
 *
 *      Fun:   cmPFthaUHUnpk
 *
 *      Desc:  This function unpacks the update message header from the buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: 
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHUnpk
(
CmPFthaUpdHdr *hdr,            /* Update message header */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmPFthaUHUnpk (hdr, mBuf)
CmPFthaUpdHdr *hdr;            /* Update message header */
Buffer *mBuf;                  /* message buffer */
#endif
{
   TRC2 (cmPFthaUHUnpk);
   
   /* 1. Unpack the fixed portion of the header */
   if (SRemPreMsgMult ((Data *)hdr, 
                       ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
                        (U32)(Void *)(NULLP)), mBuf) != ROK)
      RETVALUE (RFAILED);
   /* 2. Based on teh flag unpack the optional portion */
   if (hdr->flag & CMPFTHA_FLAG_RSETID_CRIT)
   {
      /* Unpack the optional portion for the critical resource set Id */
      if ((SRemPreMsgMult ((Data *)&hdr->opt.crit.masterId, sizeof (CmFthaMasterId), mBuf)
           != ROK) ||
          (SRemPreMsgMult ((Data *)&hdr->opt.crit.updType, sizeof (U8), mBuf)
           != ROK))
         RETVALUE (RFAILED);
      if (hdr->opt.crit.updType == CMPFTHA_UPDTYPE_M_CON)
      {
         /* unpack the proc list for master controlled updates */
         if ((SRemPreMsgMult ((Data *)&hdr->opt.crit.opt.procList.num, 
                              sizeof (U16), mBuf)
             != ROK) || 
             (hdr->opt.crit.opt.procList.num > CMFTHA_MAX_NODES_PER_ENT) ||
             (SRemPreMsgMult ((Data *)hdr->opt.crit.opt.procList.list, 
                              (MsgLen)(hdr->opt.crit.opt.procList.num * 
                               sizeof (ProcId)), 
                              mBuf)
              != ROK))             
            RETVALUE (RFAILED);
      }
      /* add code for other types of updates here */         
   }
   else
   {
      /* Unpack the optional portion for the non critical resource set Id */
      /* None for now */
   }
   RETVALUE (ROK);   
} /* cmPFthaUHUnpk */


/*
 *
 *      Fun:   cmPFthaUHGetRsetId
 *
 *      Desc:  This function gets the rsetId from a unpacked buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used when generating a update message trace.
 *
 *      File:  cm_psfft.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPFthaUHGetRsetId
(
Buffer *mBuf,                  /* message buffer */
CmFthaRsetId *rsetId           /* RsetID - returned */
)
#else
PUBLIC S16 cmPFthaUHGetRsetId (mBuf, rsetId)
Buffer *mBuf;                  /* message buffer */
CmFthaRsetId *rsetId;          /* RsetID - returned */
#endif
{
   S16 i;

   TRC2 (cmPFthaUHGetRsetId);

   for (i = 0; i < (S16) (sizeof (CmFthaRsetId) / sizeof (U8)); i++)
   {
      if (SExamMsg ((Data *)((U8 *)rsetId + i), mBuf, 
                    (MsgLen)((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->rsetId + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   
} /* cmPFthaUHGetRsetId */


/*
 *
 *      Fun:   cmPFthaUHGetSeqNum
 *
 *      Desc:  This function gets the rsetId from a unpacked buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: For a crit rset during WS, the first few messages will
 *      be RT messages. Since these messages will be made part of the
 *      RT window, the rtSeqNum on the standby cannot start from
 *      zeor. It has to start from the seqNum of first RT message
 *      packed in the first WS message.
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHGetSeqNum
(
Buffer *mBuf,                  /* message buffer */
CmFthaSeqNum *seqNum           /* SeqNum - returned */
)
#else
PUBLIC S16 cmPFthaUHGetSeqNum (mBuf, seqNum)
Buffer *mBuf;                  /* message buffer */
CmFthaSeqNum *seqNum;          /* SeqNum - returned */
#endif
{
   S16 i;

   TRC2 (cmPFthaUHGetSeqNum);

   for (i = 0; i < (S16) (sizeof (CmFthaSeqNum) / sizeof (U8)); i++)
   {
      if (SExamMsg ((Data *)((U8 *)seqNum + i), mBuf, 
                    (MsgLen)((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->seqNum + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   
} /* cmPFthaUHGetSeqNum */


/*
 *
 *      Fun:   cmPFthaUHChngMId
 *
 *      Desc:  This function changes the master Id in the update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used for all the messages in teh
 *      crit rset window when the master Id is changed by teh system
 *      manager.
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHChngMId
(
Buffer *mBuf,                  /* message buffer */
CmFthaMasterId masterId        /* New masterId */
)
#else
PUBLIC S16 cmPFthaUHChngMId (mBuf, masterId)
Buffer *mBuf;                  /* message buffer */
CmFthaMasterId masterId;       /* New masterId */
#endif
{
   S16 i;
   U16 offset;

   TRC2 (cmPFthaUHChngMId);
   /* 
    * The position of the masterId is at :
    *
    * ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
    * (U32)(Void *)(NULLP)) 
    * 
    * Any change in the hdr packing function will change the above
    * because we have to take care of padding in unknown places.
    */

   offset = ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
             (U32)(Void *)(NULLP));
   for (i = 0; i < (S16) (sizeof (CmFthaMasterId) / sizeof (U8)); i++)
   {
      if (SRepMsg ((Data)*((U8 *)&masterId + i), mBuf, (S16) (offset + i))
          != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   
} /* cmPFthaChngMId */


/*
 *
 *      Fun:   cmPFthaUHGetFlag
 *
 *      Desc:  This function gets the flag in the update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used for run time update messages
 *      which are queued and have to be sent out during UpdPeer
 *      call. The flag will have to changed in the last message to
 *      convey that no more update messages are following this one. 
 *      Typical operation would be :
 *      1) cmPFthaUHGetFlag (...);
 *      2) modify teh flag;
 *      1) cmPFthaUHSetFlag (...);
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHGetFlag
(
Buffer *mBuf,                  /* message buffer */
U8 *flag                       /* New flag */
)
#else
PUBLIC S16 cmPFthaUHGetFlag (mBuf, flag)
Buffer *mBuf;                  /* message buffer */
U8 *flag;                      /* New flag */
#endif
{
   S16 i;

   TRC2 (cmPFthaUHGetFlag);

   for (i = 0; i < (S16) (sizeof (U8) / sizeof (U8)); i++)
   {
      if (SExamMsg ((Data *)((U8 *)flag + i), mBuf, 
                    (MsgLen)((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->flag + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   

} /* cmPFthaGetFlag */



/*
 *
 *      Fun:   cmPFthaUHSetFlag
 *
 *      Desc:  This function changes the flag in the update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used for run time update messages
 *      which are queued and have to be sent out during UpdPeer
 *      call. The flag will have to changed in the last message to
 *      convey that no more update messages are following this one.
 *      Typical operation would be :
 *      1) cmPFthaUHGetFlag (...);
 *      2) modify teh flag;
 *      1) cmPFthaUHSetFlag (...);
 *
 *      File:  cm_psfft.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPFthaUHSetFlag
(
Buffer *mBuf,                  /* message buffer */
U8 flag                        /* New flag */
)
#else
PUBLIC S16 cmPFthaUHSetFlag (mBuf, flag)
Buffer *mBuf;                  /* message buffer */
U8 flag;                       /* New flag */
#endif
{
   S16 i;

   TRC2 (cmPFthaUHSetFlag);

   for (i = 0; i < (S16) (sizeof (U8) / sizeof (U8)); i++)
   {
      if (SRepMsg ((Data)*((U8 *)&flag + i), mBuf, 
                   (MsgLen)((U32)(U8 *)(&((CmPFthaUpdHdr *)(NULLP))->flag) + i)) 
          != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);
} /* cmPFthaUHSetFlag */


/*
 *
 *      Fun:   cmPFthaUHChngUpdType
 *
 *      Desc:  This function changes the update type from the update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used for run time update messages
 *      _only_ for _critical_ resource sets which are to be broadcast
 *      from the new active after a forced swtchover. UpdType of
 *      the received messages is changed 
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHChngUpdType
(
Buffer *mBuf,                  /* message buffer */
U8 updType                    /* Update type */
)
#else
PUBLIC S16 cmPFthaUHChngUpdType (mBuf, updType)
Buffer *mBuf;                  /* message buffer */
U8 updType;                   /* Update type */
#endif
{
   S16 i;
   U32 offset;

   TRC2 (cmPFthaUHChngUpdType);
      
   offset = ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
             (U32)(Void *)(NULLP)) + sizeof (CmFthaMasterId);

   for (i = 0; i < (S16) (sizeof (updType) / sizeof (U8)); i++)
   {
      if (SRepMsg ((Data)*((U8 *)&updType + i), mBuf, 
                   (MsgLen)(offset + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   

} /* cmPFthaChngUpdType */

/*
 *
 *      Fun:   cmPFthaUHGetUpdType
 *
 *      Desc:  This function gets the update type from the update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used for run time update messages
 *      _only_ for _critical_ resource sets which are to be broadcast
 *      from the new active after a forced swtchover. UpdType of
 *      the received messages is retained and used when broadcasting
 *      from the window. 
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaUHGetUpdType
(
Buffer *mBuf,                  /* message buffer */
U8 *updType                    /* Update type */
)
#else
PUBLIC S16 cmPFthaUHGetUpdType (mBuf, updType)
Buffer *mBuf;                  /* message buffer */
U8 *updType;                   /* Update type */
#endif
{
   S16 i;
   U8 flag;
   U32 offset;

   TRC2 (cmPFthaUHGetUpdType);

   cmPFthaUHGetFlag (mBuf, &flag);
   if (!(flag & CMPFTHA_FLAG_RSETID_CRIT))
      RETVALUE (FALSE);
      
   /* 
    * The position of the updType is at :
    *
    * ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
    * (U32)(Void *)(NULLP))) + sizeof (CmFthaMasterId)
    * 
    * Any change in the hdr packing function will change the above
    * because we have to take care of padding in unknown places.
    */

   offset = ((U32)(Void *)&((CmPFthaUpdHdr *)(NULLP))->opt - 
             (U32)(Void *)(NULLP)) + sizeof (CmFthaMasterId);

   for (i = 0; i < (S16) (sizeof (U8) / sizeof (U8)); i++)
   {
      if (SExamMsg ((Data *)((U8 *)updType + i), mBuf, 
                    (MsgLen)(offset + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   

} /* cmPFthaGetUpdType */


/*
 *
 *      Fun:   cmPFthaCHPk
 *
 *      Desc:  This function packs the Confirm Header in the buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: Pass a filled header to this function.
 *
 *      File:  cm_psfft.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPFthaCHPk
(
CmPFthaCfmHdr *hdr,            /* Confirm message Header */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmPFthaCHPk (hdr, mBuf)
CmPFthaCfmHdr *hdr;            /* Confirm message Header */
Buffer *mBuf;                  /* message buffer */
#endif
{
   U8 tmpArr[sizeof (CmPFthaCfmHdr)];
   U8 tmpArrRev[sizeof (CmPFthaCfmHdr)];
   U16 len;
   U16 i;

   TRC2 (cmPFthaCHPk);
   
   len = 0;

   cmMemcpy (&tmpArr[len], (U8 *)hdr, sizeof (CmPFthaCfmHdr));

   len += sizeof (CmPFthaCfmHdr);

   /* Reverse the tmpArr so that we can use SAddPreMsgMult */
   for (i = 0; i < len; i++)
      tmpArrRev[i] = tmpArr[len-i-1];
   
   if (SAddPreMsgMult (&tmpArrRev[0], len, mBuf) != ROK)
      RETVALUE (RFAILED);

   RETVALUE (ROK);
} /* cmPFthaCHPk */


/*
 *
 *      Fun:   cmPFthaCHUnpk
 *
 *      Desc:  This function unpacks the update message header from the buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: For pointers within teh header (example procList) this
 *      function will allocate a buffer and this buffer should be
 *      deallocated by the layer after processing the message.
 *
 *      File:  cm_psfft.c
 * */
#ifdef ANSI
PUBLIC S16 cmPFthaCHUnpk
(
CmPFthaCfmHdr *hdr,            /* Confirm message Header */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmPFthaCHUnpk (hdr, mBuf)
CmPFthaCfmHdr *hdr;            /* Confirm message Header */
Buffer *mBuf;                  /* message buffer */
#endif
{
   TRC2 (cmPFthaCHUnpk);
   if (SRemPreMsgMult ((Data *)hdr, sizeof (CmPFthaCfmHdr), mBuf) != ROK)
      RETVALUE (RFAILED);
   RETVALUE (ROK);
} /* cmPFthaCHUnpk */


/*
 *
 *      Fun:   cmPFthaCHGetRsetId
 *
 *      Desc:  This function gets the rsetId from a unpacked buffer.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function will be used when generating a update message trace.
 *
 *      File:  cm_psfft.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPFthaCHGetRsetId
(
Buffer *mBuf,                  /* message buffer */
CmFthaRsetId *rsetId           /* RsetID - returned */
)
#else
PUBLIC S16 cmPFthaCHGetRsetId (mBuf, rsetId)
Buffer *mBuf;                  /* message buffer */
CmFthaRsetId *rsetId;          /* RsetID - returned */
#endif
{
   S16 i;

   TRC2 (cmPFthaCHGetRsetId);

   for (i = 0; i < (S16) (sizeof (CmFthaRsetId) / sizeof (U8)); i++)
   {
      if (SExamMsg ((Data *)((U8 *)rsetId + i), mBuf, 
                    (MsgLen)((U32)(Void *)&((CmPFthaCfmHdr *)(NULLP))->rsetId + i)) != ROK)
         RETVALUE (RFAILED);
   }      
   RETVALUE (ROK);   
} /* cmPFthaCHGetRsetId */
#endif /* TDS_FTHA_CUST_PKUNPK */

  
/********************************************************************30**
  
         End of file:     cm_psfft.c@@/main/3 - Thu Jan 24 14:18:13 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      cp   1. initial release.
/main/2      ---      mp   1. Copyright header changed and warnings removal 
/main/3      ---      ds   1. type casting var in for loop to remove warnings
*********************************************************************91*/
