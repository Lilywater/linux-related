/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
        Name:     common PSF file
    
        Type:     C source file
  
        Desc:     This file contains mainly the packing/unpacking functions
                  for structures and primtives on PSF's management
                  interface. This file could be used by all products whose
                  PSF has a similar management interface. 
                  Additionally this file may have some other common functions
                  based on the common functionlity in PSFs.
 
        File:     cm_pftha.c

        Sid:      cm_pftha.c@@/main/4 - Thu Oct 12 09:22:35 2000
  
        Prg:      ash
  
*********************************************************************21*/
 

/*
 *      This software may be combined with the following TRILLIUM
 *      software:
 *
 *      part no.                      description
 *      --------    ----------------------------------------------
 *    
 *      1000028     Message Transfer Part 3 -- (MTP3)
 *      1000030     Signalling Connection Control Part -- (SCCP)
 */

  
/* header include files (.h) */
  
#include "envopt.h"             /* environment options */  
#include "envdep.h"             /* environment dependent */
#include "envind.h"             /* environment independent */

#include "gen.h"                /* general */
#include "ssi.h"                /* system services interface */
#include "cm_pftha.h"               /* common PSF */

/* header/extern include files (.x) */

#include "gen.x"                /* general */
#include "ssi.x"                /* system services interface */
#include "cm_pftha.x"               /* common PSF */

  
/* local defines */

/* local typedefs */

/* function declerations */

/* public variable declarations */

/* public variable definitions */

/* private variable definitions */

/* loosely coupled update moudle - management interface */

/* primtive packing functions */

/*
 *
 *      Fun:   cmPkPFthaCfgReq
 *
 *      Desc:  This function packs PSF's configuration request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaCfgReq
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *cfg,               /* management structure */
Buffer      **mBuf              /* message buffer pointer */
)
#else
PUBLIC S16 cmPkPFthaCfgReq(pst, cfg, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *cfg;               /* management structure */
Buffer      **mBuf;             /* message buffer pointer */
#endif
{
   CmPFthaGenCfg *gCfg;   /* general configuration structure pointer */
   CmPFthaSAPCfg *sCfg;   /* SAP configuration structure pointer */

   TRC2(cmPkPFthaCfgReq)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   switch(cfg->hdr.elmId.elmnt)
   {
      case STGEN:   /* general configuration */
         gCfg = &cfg->t.cfg.s.genCfg;
         CMCHKPKLOG(cmPkPst, &gCfg->smPst, *mBuf, ECMPFTHA001, pst);
         CMCHKPKLOG(SPkU8, gCfg->updateOption, *mBuf, ECMPFTHAXXX, pst);
         CMCHKPKLOG(cmPkMemoryId, &gCfg->mem, *mBuf, ECMPFTHA002, pst);
         CMCHKPKLOG(cmPkProcId, gCfg->vProcId, *mBuf, ECMPFTHA003, pst);
         CMCHKPKLOG(SPkS16, gCfg->timeRes, *mBuf, ECMPFTHA004, pst);
         break;

      case STPEERSAP:  /* peer sap configuration */
         sCfg = &cfg->t.cfg.s.peerSAPCfg;
         CMCHKPKLOG(SPkU32, sCfg->maxUpdMsgSize, *mBuf, ECMPFTHA005, pst);
         CMCHKPKLOG(cmPkTmrCfg, &sCfg->tUpdCompAck, *mBuf, ECMPFTHA005, pst);
         CMCHKPKLOG(cmPkSelector, sCfg->selector, *mBuf, ECMPFTHA006, pst);
         CMCHKPKLOG(cmPkRoute, sCfg->route, *mBuf, ECMPFTHA007, pst);
         CMCHKPKLOG(cmPkPriority, sCfg->prior, *mBuf, ECMPFTHA008, pst);
         CMCHKPKLOG(cmPkInst, sCfg->dstInst, *mBuf, ECMPFTHA009, pst);
         CMCHKPKLOG(cmPkEnt, sCfg->dstEnt, *mBuf, ECMPFTHA010, pst);
         CMCHKPKLOG(cmPkProcId, sCfg->dstProcId, *mBuf, ECMPFTHA011, pst);
         CMCHKPKLOG(cmPkPool, sCfg->pool, *mBuf, ECMPFTHA012, pst);
         CMCHKPKLOG(cmPkRegion, sCfg->region, *mBuf, ECMPFTHA013, pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMPFTHALOGERRORPK(ERRCLS_INT_PAR, ECMPFTHA014, (ErrVal)cfg->hdr.elmId.elmnt,
                              "cmPkPFthaCfgReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         SPutMsg(*mBuf);
         RETVALUE(RFAILED);
   }
   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfg->hdr, *mBuf, ECMPFTHA015, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaCfgReq */


/*
 *
 *      Fun:   cmPkPFthaCfgCfm
 *
 *      Desc:  This function packs PSF's configuration confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaCfgCfm
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *cfm,               /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaCfgCfm(pst, cfm, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *cfm;               /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{

   TRC2(cmPkPFthaCfgCfm)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, *mBuf, ECMPFTHA016, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, *mBuf, ECMPFTHA017, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaCfgCfm */


/*
 *
 *      Fun:   cmPkPFthaCntrlReq
 *
 *      Desc:  This function packs PSF's control request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaCntrlReq
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *cntrl,             /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaCntrlReq(pst, cntrl, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *cntrl;             /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{

   TRC2(cmPkPFthaCntrlReq)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   /* pack control structure */
   CMCHKPKLOG(SPkU32, cntrl->t.cntrl.ctlType.umDbg.dbgMask, *mBuf, ECMPFTHA018, pst);
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.subAction, *mBuf, ECMPFTHA019, pst);
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.action, *mBuf, ECMPFTHA020, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt, *mBuf, ECMPFTHA021, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cntrl->hdr, *mBuf, ECMPFTHA022, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaCntrlReq */


/*
 *
 *      Fun:   cmPkPFthaCntrlCfm
 *
 *      Desc:  This function packs PSF's control confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaCntrlCfm
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *cfm,               /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaCntrlCfm(pst, cfm, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *cfm;               /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{

   TRC2(cmPkPFthaCntrlCfm)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, *mBuf, ECMPFTHA023, pst);
   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, *mBuf, ECMPFTHA024, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaCntrlCfm */


/*
 *
 *      Fun:   cmPkPFthaStaReq
 *
 *      Desc:  This function packs PSF'solicited status request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaStaReq
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *sta,               /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaStaReq(pst, sta, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *sta;               /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{

   TRC2(cmPkPFthaStaReq)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, *mBuf, ECMPFTHA025, pst);

   /* post buffer */
   RETVALUE(ROK);

} /* end of cmPkPFthaStaReq */


/*
 *
 *      Fun:   cmPkPFthaStaCfm
 *
 *      Desc:  This function packs PSF'solicited status confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaStaCfm
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *sta,               /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaStaCfm(pst, sta, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *sta;               /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{

   TRC2(cmPkPFthaStaCfm)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   switch(sta->hdr.elmId.elmnt)
   {
      case STGEN:    /* general type */
         CMCHKPKLOG(SPkU8, sta->t.sta.s.genSta, *mBuf, ECMPFTHA026, pst);
         break;

      case STPEERSAP: /* peer sap */
         CMCHKPKLOG(SPkU8, sta->t.sta.s.peerSapSta.updState, 
                                         *mBuf, ECMPFTHA027, pst);
         CMCHKPKLOG(SPkU8, sta->t.sta.s.peerSapSta.bndState, 
                                         *mBuf, ECMPFTHA027, pst);
         break;
 
      case STSID:         /* system id */
         /* pack system id structure */
         CMCHKPKLOG(cmPkSystemId, &sta->t.sta.s.sysId, *mBuf, ECMPFTHA030, pst)
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMPFTHALOGERRORPK(ERRCLS_INT_PAR, ECMPFTHA028, (ErrVal)sta->hdr.elmId.elmnt,
                              "cmPkPFthaStaCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;
   }

   /* pack status structure */
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, *mBuf, ECMPFTHA029, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, *mBuf, ECMPFTHA030, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaStaCfm */


/*
 *
 *      Fun:   cmPkPFthaStaInd
 *
 *      Desc:  This function packs PSF's unsolicited status
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkPFthaStaInd
(
Pst         *pst,               /* post structure */
CmPFthaMngmt *sta,               /* management structure */
Buffer      **mBuf              /* message buffer */
)
#else
PUBLIC S16 cmPkPFthaStaInd(pst, sta, mBuf)
Pst         *pst;               /* post structure */
CmPFthaMngmt *sta;               /* management structure */
Buffer      **mBuf;             /* message buffer */
#endif
{
   S16 i;                 /* counter */

   TRC2(cmPkPFthaStaInd)

   /* get a buffer for packing */
   if(SGetMsg(pst->region, pst->pool, mBuf) != ROK)
      RETVALUE(RFAILED);

   /* pack usta structure */
   for (i = CMPFTHA_USTA_EP_MAX - 1; i >= 0; i--)
   {
      CMCHKPKLOG(SPkU8, sta->t.usta.evntParm[i], *mBuf, ECMPFTHA031, pst);
   }
   CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, *mBuf, ECMPFTHA032, pst); 

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, *mBuf, ECMPFTHA033, pst);

   RETVALUE(ROK);

} /* end of cmPkPFthaStaInd */

/* unpacking functions */



/*
 *
 *      Fun:   cmUnpkPFthaCfgReq
 *
 *      Desc:  This function unpacks configuration request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaCfgReq
(
CmPFthaCfgReq func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaCfgReq(func, pst, mBuf)
CmPFthaCfgReq func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt cfg;      /* management structure */
   CmPFthaGenCfg *gCfg;   /* general configuration structure pointer */
   CmPFthaSAPCfg *sCfg;   /* SAP configuration structure pointer */

   TRC2(cmUnpkPFthaCfgReq)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ECMPFTHA034, pst);
   switch(cfg.hdr.elmId.elmnt)
   {
      case STGEN:   /* general configuration */
         gCfg = &cfg.t.cfg.s.genCfg;
         CMCHKUNPKLOG(SUnpkS16, &gCfg->timeRes, mBuf, ECMPFTHA035, pst);
         CMCHKUNPKLOG(cmUnpkProcId, &gCfg->vProcId, mBuf, ECMPFTHA036, pst);
         CMCHKUNPKLOG(cmUnpkMemoryId, &gCfg->mem, mBuf, ECMPFTHA037, pst);
         CMCHKUNPKLOG(SUnpkU8, &gCfg->updateOption, mBuf, ECMPFTHAXXX, pst);
         CMCHKUNPKLOG(cmUnpkPst, &gCfg->smPst, mBuf, ECMPFTHA038, pst);
         break;

      case STPEERSAP:  /* peer sap configuration */
         sCfg = &cfg.t.cfg.s.peerSAPCfg;
         CMCHKUNPKLOG(cmUnpkRegion, &sCfg->region, mBuf, ECMPFTHA039, pst);
         CMCHKUNPKLOG(cmUnpkPool, &sCfg->pool, mBuf, ECMPFTHA040, pst);
         CMCHKUNPKLOG(cmUnpkProcId, &sCfg->dstProcId, mBuf, ECMPFTHA041, pst);
         CMCHKUNPKLOG(cmUnpkEnt, &sCfg->dstEnt, mBuf, ECMPFTHA042, pst);
         CMCHKUNPKLOG(cmUnpkInst, &sCfg->dstInst, mBuf, ECMPFTHA043, pst);
         CMCHKUNPKLOG(cmUnpkPriority, &sCfg->prior, mBuf, ECMPFTHA044, pst);
         CMCHKUNPKLOG(cmUnpkRoute, &sCfg->route, mBuf, ECMPFTHA045, pst);
         CMCHKUNPKLOG(cmUnpkSelector, &sCfg->selector, mBuf, ECMPFTHA046, pst);
         CMCHKUNPKLOG(cmUnpkTmrCfg, &sCfg->tUpdCompAck, mBuf, ECMPFTHA047, pst);
         CMCHKUNPKLOG(SUnpkU32, &sCfg->maxUpdMsgSize, mBuf, ECMPFTHA047, pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMPFTHALOGERRORUNPK(ERRCLS_INT_PAR, ECMPFTHA048, (ErrVal)cfg.hdr.elmId.elmnt,
                              "cmUnPkPFthaCfgReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfg));

} /* end of cmUnpkPFthaCfgReq */


/*
 *
 *      Fun:   cmUnpkPFthaCfgCfm
 *
 *      Desc:  This function unpacks configuration confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaCfgCfm
(
CmPFthaCfgCfm func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaCfgCfm(func, pst, mBuf)
CmPFthaCfgCfm func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt cfm;

   TRC2(cmUnpkPFthaCfgCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ECMPFTHA049, pst);
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ECMPFTHA050, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfm));

} /* end of cmUnpkPFthaCfgCfm */


/*
 *
 *      Fun:   cmUnpkPFthaCntrlReq
 *
 *      Desc:  This function unpacks control request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaCntrlReq
(
CmPFthaCntrlReq func,            /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaCntrlReq(func, pst, mBuf)
CmPFthaCntrlReq func;            /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt cntrl;      /* management structure */

   TRC2(cmUnpkPFthaCntrlReq)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &cntrl.hdr, mBuf, ECMPFTHA051, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ECMPFTHA052, pst);
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.action, mBuf, ECMPFTHA053, pst);
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.subAction, mBuf, ECMPFTHA054, pst);
   CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.ctlType.umDbg.dbgMask, mBuf, ECMPFTHA055, 
                                                                        pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cntrl));

} /* end of cmUnpkPFthaCntrlReq */


/*
 *
 *      Fun:   cmUnpkPFthaCntrlCfm
 *
 *      Desc:  This function unpacks control confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaCntrlCfm
(
CmPFthaCntrlCfm func,            /* primtive to call */
Pst            *pst,            /* post */
Buffer         *mBuf            /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaCntrlCfm(func, pst, mBuf)
CmPFthaCntrlCfm func;              /* primtive to call */
Pst            *pst;              /* post */
Buffer         *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt cfm;

   TRC2(cmUnpkPFthaCntrlCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ECMPFTHA056, pst);
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ECMPFTHA057, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfm));

} /* end of cmUnpkPFthaCntrlCfm */


/*
 *
 *      Fun:   cmUnpkPFthaStaReq
 *
 *      Desc:  This function unpacks status request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaStaReq
(
CmPFthaStaReq func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaStaReq(func, pst, mBuf)
CmPFthaStaReq func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt sta;      /* management structure */

   TRC2(cmUnpkPFthaStaReq)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ECMPFTHA058, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sta));

} /* end of cmUnpkPFthaStaReq */


/*
 *
 *      Fun:   cmUnpkPFthaStaCfm
 *
 *      Desc:  This function unpacks status confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaStaCfm
(
CmPFthaStaCfm func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaStaCfm(func, pst, mBuf)
CmPFthaStaCfm func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt sta;      /* management structure */
   Txt ptNmb[32];         /* part number */

   TRC2(cmUnpkPFthaStaCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ECMPFTHA059, pst);
   /* unpack confirm structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ECMPFTHA060, pst);

   switch(sta.hdr.elmId.elmnt)
   {
      case STGEN:    /* general type */
         CMCHKUNPKLOG(SUnpkU8, &sta.t.sta.s.genSta, mBuf, ECMPFTHA061, pst);
         break;

      case STPEERSAP: /* peer sap */
         CMCHKUNPKLOG(SUnpkU8, &sta.t.sta.s.peerSapSta.bndState, 
                                                 mBuf, ECMPFTHA062, pst);
         CMCHKUNPKLOG(SUnpkU8, &sta.t.sta.s.peerSapSta.updState, 
                                                 mBuf, ECMPFTHA062, pst);
         break;
 
      case STSID:         /* system id */
         /* unpack system id structure */
         sta.t.sta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.sta.s.sysId, mBuf, ECMPFTHA030, pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMPFTHALOGERRORUNPK(ERRCLS_INT_PAR, ECMPFTHA063, 
                          (ErrVal)sta.hdr.elmId.elmnt,
                          "cmUnpkPFthaStaCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         break;
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sta));

} /* end of cmUnpkPFthaStaCfm */


/*
 *
 *      Fun:   cmUnpkPFthaStaInd
 *
 *      Desc:  This function unpacks unsolicited status indication from 
 *             PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkPFthaStaInd
(
CmPFthaStaInd func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkPFthaStaInd(func, pst, mBuf)
CmPFthaStaInd func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmPFthaMngmt sta;      /* management structure */
   S16 i;                /* counter */

   TRC2(cmUnpkPFthaStaInd)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ECMPFTHA064, pst);

   CMCHKUNPKLOG(cmUnpkCmAlarm, &sta.t.usta.alarm, mBuf, ECMPFTHA065, pst);
   for (i = 0; i < CMPFTHA_USTA_EP_MAX; i++)
   {
      CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evntParm[i], mBuf, ECMPFTHA066, pst);
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sta));

} /* end of cmUnpkPFthaStaInd */



/*
 *
 *      Fun:   cmPFthaGetUpdMsg
 *
 *      Desc:  This function allocates message buffer and packs update message
 *             header in the message 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: In case of failure this function will take care of freeing
 *             allocated message buffer 
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPFthaGetUpdMsg
(
Pst    *pst,          /* post structure */
U8     type,          /* update type */
U16    sNum,          /* sequence number */
U8     more,          /* more indication */
SystemId *sysId,      /* system Id structure */
Buffer **mBuf         /* message buffer */
)
#else
PUBLIC S16 cmPFthaGetUpdMsg(pst, type, sNum, more, sysId, mBuf)
Pst    *pst;          /* post structure */
U8     type;          /* update type */
U16    sNum;          /* sequence number */
U8     more;          /* more indication */
SystemId *sysId;      /* system Id structure */
Buffer **mBuf;        /* message buffer */
#endif
{
   S16 ret1;           /* return value */
   CmPFthaMsgHdr hdr;   /* message header */  

   TRC2(cmPFthaGetUpdMsg)

   if ((ret1 = SGetMsg(pst->region, pst->pool, mBuf)) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      CMPFTHALOGERRORPK(ERRCLS_ADD_RES, ECMPFTHA067, (ErrVal)0, 
                               "cmPFthaGetUpdMsg() SGetMsg failed ");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
      RETVALUE(ret1);
   }

   /* pack parameters */
   hdr.type = type;
   hdr.sNum = sNum;
   hdr.more = more;

   if ((ret1 = cmPFthaPkMsgHdr(&hdr, sysId, *mBuf)) != ROK)
   {
      SPutMsg(*mBuf);
      RETVALUE(ret1);
   }

   RETVALUE(ROK);
} /* end of cmPFthaGetUpdMsg */


/*
 *
 *      Fun:   cmPFthaPkMsgHdr
 *
 *      Desc:  This function packs update message header in the message 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: 
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPFthaPkMsgHdr
(
CmPFthaMsgHdr *hdr,          /* update message header */
SystemId      *sysId,        /* system Id */
Buffer        *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmPFthaPkMsgHdr(hdr, sysId, mBuf)
CmPFthaMsgHdr *hdr;          /* update message header */
SystemId      *sysId;        /* system Id */
Buffer        *mBuf;         /* message buffer */
#endif
{

   TRC2(cmPFthaPkMsgHdr)

   /* pack update message header */
   CMCHKPK(SPkU8, hdr->more, mBuf);
   CMCHKPK(SPkU16, hdr->sNum, mBuf);
   CMCHKPK(SPkU8, hdr->type, mBuf);

   /* pack system Id structure parameters */
   CMCHKPK(SPkS16, sysId->bVer, mBuf);
   CMCHKPK(SPkS16, sysId->mRev, mBuf);
   CMCHKPK(SPkS16, sysId->mVer, mBuf);
   RETVALUE(ROK);
} /* end of cmPFthaPkMsgHdr */


/*
 *
 *      Fun:   cmPFthaUnpkMsgHdr
 *
 *      Desc:  This function unpacks update message header from the message 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: 
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPFthaUnpkMsgHdr
(
CmPFthaMsgHdr *hdr,          /* update message header */
SystemId      *sysId,        /* system Id */
Buffer        *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmPFthaUnpkMsgHdr(hdr, sysId, mBuf)
CmPFthaMsgHdr *hdr;          /* update message header */
SystemId      *sysId;        /* system Id */
Buffer        *mBuf;         /* message buffer */
#endif
{

   TRC2(cmPFthaUnpkMsgHdr)

   /* unpack system Id structure parameters */
   CMCHKUNPK(SUnpkS16, &sysId->mVer, mBuf); 
   CMCHKUNPK(SUnpkS16, &sysId->mRev, mBuf); 
   CMCHKUNPK(SUnpkS16, &sysId->bVer, mBuf); 

   /* unpack update message header parameters */
   CMCHKUNPK(SUnpkU8, &hdr->type, mBuf);
   CMCHKUNPK(SUnpkU16, &hdr->sNum, mBuf);
   CMCHKUNPK(SUnpkU8, &hdr->more, mBuf);

   RETVALUE(ROK);
} /* end of cmPFthaUnpkMsgHdr */

/*
 *
 *      Fun:   cmPFthaYield
 *
 *      Desc:  Provides a yield function so that PSF can take a real
 *             time break and deschedule itself during warmstart. This
 *             function will allow PSF not to starve other system 
 *             processes during warmstart 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function should be modified by customers using PSF
 *             on a non preemptive OS.
 *
        File:  cm_pftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPFthaYield
(
)
#else
PUBLIC S16 cmPFthaYield()
#endif
{

   TRC2(cmPFthaYield)

   RETVALUE(ROK);
} /* end of cmPFthaYield */

  
/********************************************************************30**
  
         End of file:     cm_pftha.c@@/main/4 - Thu Oct 12 09:22:35 2000
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ash  1. initial release.
                           2. CfgReq packing/unpacking modified for smPst
                              structure 
                           3. CfgReq packing/unpacking modified for mem
                              structure 
                           4. Modified CntrlReq packing/unpakcing to
                              include ctlType structure
                           5. All primtive packing function should have 
                              **mBuf as parameter instead of *mBuf
                           6. packed and unpacked CmPFthaPeerSapSta structure.
                           7. compilation warnings removed for both ANSI
                              and non ANSI GCC compilation
                           8. packed and unpacked maxUpdMsgSize in peersap
                              configuration structure.
                       pm  9. removed redundant declarations.
                       pm  10. packed and unpacked sysId structure for
                               status confirm.
                       pm  11. While packing the sysId structure, the part 
                               number was not correctly packed.
                       ash 12. SPutMsg removed from default legs of 
                               cmPkPFthaStaReq and cmUnpkPFthaStaReq functions
                       pm  13. Removed LCLMUM flag.
                       ash 14. Added SystemId structure in cmPFthaPkMsgHdr
                               and cmPFthaUnpkMsgHdr parameter list. Only 
                               some elements of systemId structure are 
                               packed in update message
                           15. Added cmPFthaYield() function
1.2          ---      rs   1.  Added updateOption in GenCfg.
             /main/4                 cp   1. Rereleasing the same file. (To avoid usage of the
                              cm_pftha.* released with LDF-MTP3) 
*********************************************************************91*/
