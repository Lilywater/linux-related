/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SDP common module
  
     Type:     C file
  
     Desc:     This file contains the packing/unpacking functions for
               common SDP types

     File:     cm_sdp.c

     Sid:      cm_sdp.c@@/main/12 - Tue Nov  9 23:10:52 2004
  
     Prg:      rrp
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_tkns.h"       /* common tokens */

#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport */
#include "cm_mblk.h"       /* common mblk alloc */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_sdp.h"        /* common sdp defines */
#ifdef MG
#include "mgt.h"           /* MGT interface defines */
#endif /* MG */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_lib.x"        /* Common library functions */
#include "cm_tkns.x"       /* common tokens */

#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* common mem block alloc */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_sdp.x"        /* common sdp types */
#ifdef CM_SDP_V_2
#define cmPkCmSdpIpFQDN cmPkMacroTknStrOSXL
#define cmUnpkCmSdpIpFQDN cmUnpkMacroTknStrOSXL
#define cmPkCmSdpIp6 cmPkMacroTknStrOSXL
#define cmUnpkCmSdpIp6 cmUnpkMacroTknStrOSXL
#define cmPkCmSdpMimeSubtype cmPkMacroTknStrOSXL
#define cmUnpkCmSdpMimeSubtype cmUnpkMacroTknStrOSXL
#define cmPkCmSdpVpci cmPkCmSdpVpVcCid
#define cmUnpkCmSdpVpci cmUnpkCmSdpVpVcCid
#endif /* CM_SDP_V_2 */
/* Packing/Unpacking Macros */
#define cmPkMacroTknStrOSXL(tknStr, mBuf) cmPkTknStrOSXL(tknStr, mBuf)
#define cmUnpkMacroTknStrOSXL(tknStr, ptr, mBuf) cmUnpkTknStrOSXL(tknStr, mBuf, ptr)
#define cmPkMacroTknBuf(val, mBuf) cmPkTknBuf(val, mBuf)
#define cmUnpkMacroTknBuf(val, mBuf) cmUnpkTknBuf(val, &mBuf)
#ifdef LCCMSDP
#ifdef CM_SDP_V_2
#ifdef CM_SDP_V_3
/*
*
*    Fun:    cmPkCmSdpAttrCapParam
*
*    Desc:    pack the structure CmSdpAttrCapParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrCapParam
(
CmSdpAttrCapParam *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrCapParam(param ,intfVer ,mBuf)
CmSdpAttrCapParam *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrCapParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_CPAR_BW :
             ret1 = cmPkCmSdpBwSet( (CmSdpBwSet *)(&(param->u.bwSet)),mBuf );
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_ATTR :
             ret1 = cmPkCmSdpAttrSet( (CmSdpAttrSet *)(&(param->u.attrSet)), intfVer, mBuf );
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrCapParam*/
#endif


/*
*
*    Fun:    cmPkCmSdpIp4Unicast
*
*    Desc:    pack the structure CmSdpIp4Unicast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp4Unicast
(
CmSdpIp4Unicast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp4Unicast(param ,mBuf)
CmSdpIp4Unicast *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpIp4Unicast)

    for (i=4 -1;i>=0;i--)
    {
       CMCHKPK(cmPkTknU8, &param->b[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp4Unicast*/

/*
*
*    Fun:    cmPkCmSdpIp4Multicast
*
*    Desc:    pack the structure CmSdpIp4Multicast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp4Multicast
(
CmSdpIp4Multicast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp4Multicast(param ,mBuf)
CmSdpIp4Multicast *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpIp4Multicast)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->numAddr,mBuf);
       CMCHKPK(cmPkTknU8, &param->ttl,mBuf);
       CMCHKPK(cmPkCmSdpIp4Unicast, &param->ip,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp4Multicast*/

/*
*
*    Fun:    cmPkCmSdpIp4Addr
*
*    Desc:    pack the structure CmSdpIp4Addr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp4Addr
(
CmSdpIp4Addr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp4Addr(param ,mBuf)
CmSdpIp4Addr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpIp4Addr)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV4_FQDN :
             ret1 = cmPkCmSdpIpFQDN(&param->u.fqdn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV4_IP_ANY :
             break;
          case  CM_SDP_IPV4_IP_MULTI :
             break;
          case  CM_SDP_IPV4_IP_UNI :
             CMCHKPK(cmPkCmSdpIp4Unicast, &param->u.ip,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp4Addr*/

/*
*
*    Fun:    cmPkCmSdpIp4Conn
*
*    Desc:    pack the structure CmSdpIp4Conn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp4Conn
(
CmSdpIp4Conn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp4Conn(param ,mBuf)
CmSdpIp4Conn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpIp4Conn)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV4_FQDN :
             ret1 = cmPkCmSdpIpFQDN(&param->u.fqdn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV4_IP_ANY :
             break;
          case  CM_SDP_IPV4_IP_MULTI :
             CMCHKPK(cmPkCmSdpIp4Multicast, &param->u.multiIp,mBuf);
             break;
          case  CM_SDP_IPV4_IP_UNI :
             CMCHKPK(cmPkCmSdpIp4Unicast, &param->u.uniIp,mBuf);
             break;
          case  CM_SDP_NIL :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp4Conn*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpIp6MultiCast
*
*    Desc:    pack the structure CmSdpIp6MultiCast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp6MultiCast
(
CmSdpIp6MultiCast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp6MultiCast(param ,mBuf)
CmSdpIp6MultiCast *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpIp6MultiCast)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->numAddr,mBuf);
       CMCHKPK(cmPkTknU8, &param->ttl,mBuf);
       CMCHKPK(cmPkCmSdpIp4Multicast, &param->ip4Multi,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->hexPart,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp6MultiCast*/
#endif

/*
*
*    Fun:    cmPkCmSdpIp6Addr
*
*    Desc:    pack the structure CmSdpIp6Addr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpIp6Addr
(
CmSdpIp6Addr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpIp6Addr(param ,mBuf)
CmSdpIp6Addr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpIp6Addr)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV6_FQDN :
             ret1 = cmPkCmSdpIpFQDN(&param->u.fqdn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV6_IP :
             ret1 = cmPkCmSdpIp6(&param->u.ip,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_IPV6_MULTI :
             ret1 = cmPkCmSdpIp6MultiCast(&param->u.ipMulti,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpIp6Addr*/

/*
*
*    Fun:    cmPkCmSdpLclAddr
*
*    Desc:    pack the structure CmSdpLclAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpLclAddr
(
CmSdpLclAddr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpLclAddr(param ,mBuf)
CmSdpLclAddr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpLclAddr)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->lclName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->domName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpLclAddr*/

/*
*
*    Fun:    cmPkCmSdpTnExtn
*
*    Desc:    pack the structure CmSdpTnExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTnExtn
(
CmSdpTnExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTnExtn(param ,mBuf)
CmSdpTnExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpTnExtn)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->phone,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->format,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTnExtn*/

/*
*
*    Fun:    cmPkCmSdpAddr
*
*    Desc:    pack the structure CmSdpAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAddr
(
CmSdpAddr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAddr(param ,mBuf)
CmSdpAddr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAddr)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.e164,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmPkCmSdpIp4Addr(&param->u.ip4,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmPkCmSdpIp6Addr(&param->u.ip6,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmPkMacroTknStrOSXL(&param->u.nsap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.sip,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmPkCmSdpTnExtn(&param->u.extn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    CMCHKPK(cmPkTknU8, &param->netType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAddr*/

/*
*
*    Fun:    cmPkCmSdpConn
*
*    Desc:    pack the structure CmSdpConn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpConn
(
CmSdpConn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpConn(param ,mBuf)
CmSdpConn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpConn)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.e164,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmPkCmSdpIp4Conn(&param->u.ip4,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmPkCmSdpIp6Addr(&param->u.ip6,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_LCL :
             ret1 = cmPkCmSdpLclAddr(&param->u.lcl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmPkMacroTknStrOSXL(&param->u.nsap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.sip,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmPkCmSdpTnExtn(&param->u.extn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    CMCHKPK(cmPkTknU8, &param->netType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpConn*/

/*
*
*    Fun:    cmPkCmSdpAnycastAddr
*
*    Desc:    pack the structure CmSdpAnycastAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAnycastAddr
(
CmSdpAnycastAddr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAnycastAddr(param ,mBuf)
CmSdpAnycastAddr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAnycastAddr)

    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.e164,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmPkMacroTknStrOSXL(&param->u.gwid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmPkCmSdpIp4Addr(&param->u.ip4,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmPkCmSdpIp6Addr(&param->u.ip6,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmPkMacroTknStrOSXL(&param->u.nsap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmPkMacroTknStrOSXL(&param->u.sip,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmPkCmSdpTnExtn(&param->u.extn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAnycastAddr*/

/*
*
*    Fun:    cmPkCmSdpOrig
*
*    Desc:    pack the structure CmSdpOrig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpOrig
(
CmSdpOrig *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpOrig(param ,mBuf)
CmSdpOrig *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpOrig)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpAddr(&param->sdpAddr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->sessVer,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->sessId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->usrName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpOrig*/

/*
*
*    Fun:    cmPkCmSdpOptOrig
*
*    Desc:    pack the structure CmSdpOptOrig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpOptOrig
(
CmSdpOptOrig *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpOptOrig(param ,mBuf)
CmSdpOptOrig *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpOptOrig)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT && param->type.val == CM_SDP_SPEC )
       {
          ret1 = cmPkCmSdpOrig(&param->orig,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpOptOrig*/

/*
*
*    Fun:    cmPkCmSdpConnSet
*
*    Desc:    pack the structure CmSdpConnSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpConnSet
(
CmSdpConnSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpConnSet(param ,mBuf)
CmSdpConnSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpConnSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpConn,  (param->connSet[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpConnSet*/

/*
*
*    Fun:    cmPkCmSdpTypedTime
*
*    Desc:    pack the structure CmSdpTypedTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTypedTime
(
CmSdpTypedTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTypedTime(param ,mBuf)
CmSdpTypedTime *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpTypedTime)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->unit,mBuf);
       CMCHKPK(cmPkTknStr32, &param->val,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTypedTime*/

/*
*
*    Fun:    cmPkCmSdpZoneAdj
*
*    Desc:    pack the structure CmSdpZoneAdj
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpZoneAdj
(
CmSdpZoneAdj *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpZoneAdj(param ,mBuf)
CmSdpZoneAdj *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpZoneAdj)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpTypedTime, &param->typedTime,mBuf);
       CMCHKPK(cmPkTknStr32, &param->time,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpZoneAdj*/

/*
*
*    Fun:    cmPkCmSdpTypedTimeSet
*
*    Desc:    pack the structure CmSdpTypedTimeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTypedTimeSet
(
CmSdpTypedTimeSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTypedTimeSet(param ,mBuf)
CmSdpTypedTimeSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpTypedTimeSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpTypedTime,  (param->typedTime[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTypedTimeSet*/

/*
*
*    Fun:    cmPkCmSdpRepField
*
*    Desc:    pack the structure CmSdpRepField
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpRepField
(
CmSdpRepField *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpRepField(param ,mBuf)
CmSdpRepField *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpRepField)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpTypedTimeSet(&param->offsetList,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpTypedTime, &param->actvDur,mBuf);
       CMCHKPK(cmPkCmSdpTypedTime, &param->repInterval,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpRepField*/

/*
*
*    Fun:    cmPkCmSdpRepFieldSet
*
*    Desc:    pack the structure CmSdpRepFieldSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpRepFieldSet
(
CmSdpRepFieldSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpRepFieldSet(param ,mBuf)
CmSdpRepFieldSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpRepFieldSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpRepField,  (param->repField[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpRepFieldSet*/

/*
*
*    Fun:    cmPkCmSdpZoneAdjSet
*
*    Desc:    pack the structure CmSdpZoneAdjSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpZoneAdjSet
(
CmSdpZoneAdjSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpZoneAdjSet(param ,mBuf)
CmSdpZoneAdjSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpZoneAdjSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpZoneAdj,  (param->zoneAdj[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpZoneAdjSet*/

/*
*
*    Fun:    cmPkCmSdpOpTime
*
*    Desc:    pack the structure CmSdpOpTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpOpTime
(
CmSdpOpTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpOpTime(param ,mBuf)
CmSdpOpTime *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpOpTime)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpRepFieldSet(&param->repFieldSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStr32, &param->stopTime,mBuf);
       CMCHKPK(cmPkTknStr32, &param->startTime,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpOpTime*/

/*
*
*    Fun:    cmPkCmSdpOpTimeSet
*
*    Desc:    pack the structure CmSdpOpTimeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpOpTimeSet
(
CmSdpOpTimeSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpOpTimeSet(param ,mBuf)
CmSdpOpTimeSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpOpTimeSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpOpTime,  (param->sdpOpTime[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpOpTimeSet*/

/*
*
*    Fun:    cmPkCmSdpTime
*
*    Desc:    pack the structure CmSdpTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTime
(
CmSdpTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTime(param ,mBuf)
CmSdpTime *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpTime)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpZoneAdjSet(&param->zoneAdjSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpOpTimeSet(&param->sdpOpTimeSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTime*/

/*
*
*    Fun:    cmPkCmSdpKeyType
*
*    Desc:    pack the structure CmSdpKeyType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpKeyType
(
CmSdpKeyType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpKeyType(param ,mBuf)
CmSdpKeyType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpKeyType)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->keyType.pres != NOTPRSNT 
         && param->keyType.val != CM_SDP_KEY_TYPE_PROMPT )
       {
          ret1 = cmPkMacroTknStrOSXL(&param->key_data,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->keyType,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpKeyType*/

/*
*
*    Fun:    cmPkCmSdpAttrType
*
*    Desc:    pack the structure CmSdpAttrType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrType
(
CmSdpAttrType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrType(param ,mBuf)
CmSdpAttrType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrType)

    ret1 = cmPkMacroTknStrOSXL(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrType*/

/*
*
*    Fun:    cmPkCmSdpU8OrNil
*
*    Desc:    pack the structure CmSdpU8OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpU8OrNil
(
CmSdpU8OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpU8OrNil(param ,mBuf)
CmSdpU8OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpU8OrNil)

    CMCHKPK(cmPkTknU8, &param->val,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpU8OrNil*/

/*
*
*    Fun:    cmPkCmSdpU16OrNil
*
*    Desc:    pack the structure CmSdpU16OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpU16OrNil
(
CmSdpU16OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpU16OrNil(param ,mBuf)
CmSdpU16OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpU16OrNil)

    CMCHKPK(cmPkTknU16, &param->val,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpU16OrNil*/

/*
*
*    Fun:    cmPkCmSdpU32OrNil
*
*    Desc:    pack the structure CmSdpU32OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpU32OrNil
(
CmSdpU32OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpU32OrNil(param ,mBuf)
CmSdpU32OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpU32OrNil)

    CMCHKPK(cmPkTknU32, &param->val,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpU32OrNil*/

/*
*
*    Fun:    cmPkCmSdpEncName
*
*    Desc:    pack the structure CmSdpEncName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpEncName
(
CmSdpEncName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpEncName(param ,mBuf)
CmSdpEncName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpEncName)

    ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpEncName*/

/*
*
*    Fun:    cmPkCmSdpAttrRtpMap
*
*    Desc:    pack the structure CmSdpAttrRtpMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrRtpMap
(
CmSdpAttrRtpMap *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrRtpMap(param ,mBuf)
CmSdpAttrRtpMap *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrRtpMap)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->parms,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->clk,mBuf);
       ret1 = cmPkCmSdpEncName(&param->enc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpU8OrNil, &param->pay,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrRtpMap*/

/*
*
*    Fun:    cmPkCmSdpAttrAtmMap
*
*    Desc:    pack the structure CmSdpAttrAtmMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAtmMap
(
CmSdpAttrAtmMap *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAtmMap(param ,mBuf)
CmSdpAttrAtmMap *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrAtmMap)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpEncName(&param->enc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpU8OrNil, &param->pay,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAtmMap*/

/*
*
*    Fun:    cmPkCmSdpAttrSilSupp
*
*    Desc:    pack the structure CmSdpAttrSilSupp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrSilSupp
(
CmSdpAttrSilSupp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrSilSupp(param ,mBuf)
CmSdpAttrSilSupp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrSilSupp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->fxns,mBuf);
       CMCHKPK(cmPkTknU8, &param->sid,mBuf);
       CMCHKPK(cmPkTknU8, &param->pref,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->timer,mBuf);
       CMCHKPK(cmPkTknU8, &param->enb,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrSilSupp*/

/*
*
*    Fun:    cmPkCmSdpAttrEchoCan
*
*    Desc:    pack the structure CmSdpAttrEchoCan
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrEchoCan
(
CmSdpAttrEchoCan *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrEchoCan(param ,mBuf)
CmSdpAttrEchoCan *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrEchoCan)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkTknU8, &param->enb,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrEchoCan*/

/*
*
*    Fun:    cmPkCmSdpAttrGainCtl
*
*    Desc:    pack the structure CmSdpAttrGainCtl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrGainCtl
(
CmSdpAttrGainCtl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrGainCtl(param ,mBuf)
CmSdpAttrGainCtl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrGainCtl)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->lvl,mBuf);
       CMCHKPK(cmPkTknU8, &param->enb,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrGainCtl*/

/*
*
*    Fun:    cmPkCmSdpAttrDirection
*
*    Desc:    pack the structure CmSdpAttrDirection
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrDirection
(
CmSdpAttrDirection *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrDirection(param ,mBuf)
CmSdpAttrDirection *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrDirection)

    CMCHKPK(cmPkTknU16, &param->port,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrDirection*/

/*
*
*    Fun:    cmPkCmSdpAttrAtmAbrSetup
*
*    Desc:    pack the structure CmSdpAttrAtmAbrSetup
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAtmAbrSetup
(
CmSdpAttrAtmAbrSetup *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAtmAbrSetup(param ,mBuf)
CmSdpAttrAtmAbrSetup *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAtmAbrSetup)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->brdf,mBuf);
       CMCHKPK(cmPkTknU8, &param->frdf,mBuf);
       CMCHKPK(cmPkTknU8, &param->brif,mBuf);
       CMCHKPK(cmPkTknU8, &param->frif,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->crmrtt,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->btbe,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->ftbe,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->bicr,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->ficr,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAtmAbrSetup*/

/*
*
*    Fun:    cmPkCmSdpAttrAal2CpsSduRate
*
*    Desc:    pack the structure CmSdpAttrAal2CpsSduRate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal2CpsSduRate
(
CmSdpAttrAal2CpsSduRate *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal2CpsSduRate(param ,mBuf)
CmSdpAttrAal2CpsSduRate *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal2CpsSduRate)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU32OrNil, &param->bSduRate,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->fSduRate,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal2CpsSduRate*/

/*
*
*    Fun:    cmPkCmSdpAttrAal5Sscop
*
*    Desc:    pack the structure CmSdpAttrAal5Sscop
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal5Sscop
(
CmSdpAttrAal5Sscop *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal5Sscop(param ,mBuf)
CmSdpAttrAal5Sscop *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal5Sscop)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->bsscopUu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->fsscopUu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->bsscopSdu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->fsscopSdu,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal5Sscop*/

/*
*
*    Fun:    cmPkCmSdpAttrAtmBrrSigIe
*
*    Desc:    pack the structure CmSdpAttrAtmBrrSigIe
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAtmBrrSigIe
(
CmSdpAttrAtmBrrSigIe *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAtmBrrSigIe(param ,mBuf)
CmSdpAttrAtmBrrSigIe *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrAtmBrrSigIe)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->val,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->lng,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->type,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAtmBrrSigIe*/

/*
*
*    Fun:    cmPkCmSdpUuiCodeRng
*
*    Desc:    pack the structure CmSdpUuiCodeRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpUuiCodeRng
(
CmSdpUuiCodeRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpUuiCodeRng(param ,mBuf)
CmSdpUuiCodeRng *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpUuiCodeRng)

    CMCHKPK(cmPkTknU8, &param->high,mBuf);
    CMCHKPK(cmPkTknU8, &param->low,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpUuiCodeRng*/

/*
*
*    Fun:    cmPkCmSdpProfComp
*
*    Desc:    pack the structure CmSdpProfComp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpProfComp
(
CmSdpProfComp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpProfComp(param ,mBuf)
CmSdpProfComp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpProfComp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->pktz,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->len,mBuf);
       ret1 = cmPkCmSdpEncName(&param->enc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpUuiCodeRng, &param->uui,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpProfComp*/

/*
*
*    Fun:    cmPkCmSdpProfCompSet
*
*    Desc:    pack the structure CmSdpProfCompSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpProfCompSet
(
CmSdpProfCompSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpProfCompSet(param ,mBuf)
CmSdpProfCompSet *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpProfCompSet)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpProfComp( (param->comps[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpProfCompSet*/

/*
*
*    Fun:    cmPkCmSdpMedProtoSubtype
*
*    Desc:    pack the structure CmSdpMedProtoSubtype
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedProtoSubtype
(
CmSdpMedProtoSubtype *param,
U8 protType,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedProtoSubtype(param ,protType, mBuf)
CmSdpMedProtoSubtype *param;
U8 protType;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpMedProtoSubtype)

    if( param->type.pres != NOTPRSNT )
    {
       switch( protType )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmPkMacroTknStrOSXL(&param->u.unknownOrCorporate,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKPK(cmPkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmPkMacroTknStrOSXL(&param->u.unknownOrCorporate,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKPK(cmPkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmPkMacroTknStrOSXL(&param->u.unknownOrCorporate,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKPK(cmPkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_RTP_AVP :
                   break;
                case  CM_SDP_PROTO_RTP_AVP_TCP :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedProtoSubtype*/

/*
*
*    Fun:    cmPkCmSdpMedProto
*
*    Desc:    pack the structure CmSdpMedProto
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedProto
(
CmSdpMedProto *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedProto(param ,mBuf)
CmSdpMedProto *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpMedProto)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             ret1 = cmPkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             ret1 = cmPkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             ret1 = cmPkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_H323C :
             break;
          case  CM_SDP_MEDIA_PROTO_LCL :
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             ret1 = cmPkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_SAP :
             break;
          case  CM_SDP_MEDIA_PROTO_TCP :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_FAX :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_PAGER :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_VOICE :
             break;
          case  CM_SDP_MEDIA_PROTO_UDP :
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_MEDIA_PROTO_UDPTL :
             break;
#endif /* CM_SDP_V_3 */
#ifdef CM_SDP_SIP_IM_SUPPORT
          case CM_SDP_MEDIA_PROTO_SIP:             
             break;
#endif /* CM_SDP_SIP_IM_SUPPORT */
          case  CM_SDP_MEDIA_PROTO_UNKNOWN :
             ret1 = cmPkMacroTknStrOSXL(&param->u.name,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedProto*/

/*
*
*    Fun:    cmPkCmSdpAttrProfDesc
*
*    Desc:    pack the structure CmSdpAttrProfDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrProfDesc
(
CmSdpAttrProfDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrProfDesc(param ,mBuf)
CmSdpAttrProfDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrProfDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpProfCompSet(&param->comps,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpU8OrNil, &param->prof,mBuf);
       ret1 = cmPkCmSdpMedProto(&param->transport,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrProfDesc*/

/*
*
*    Fun:    cmPkCmSdpAttrDevSelComp
*
*    Desc:    pack the structure CmSdpAttrDevSelComp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrDevSelComp
(
CmSdpAttrDevSelComp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrDevSelComp(param ,mBuf)
CmSdpAttrDevSelComp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrDevSelComp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->pktz,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->len,mBuf);
       ret1 = cmPkCmSdpEncName(&param->enc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrDevSelComp*/

/*
*
*    Fun:    cmPkCmSdpAttrDevSel
*
*    Desc:    pack the structure CmSdpAttrDevSel
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrDevSel
(
CmSdpAttrDevSel *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrDevSel(param ,mBuf)
CmSdpAttrDevSel *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpAttrDevSel)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->numComp.pres != NOTPRSNT )
       {
          for (i=param->numComp.val-1;i>=0;i--)
          {
             ret1 = cmPkCmSdpAttrDevSelComp( (param->comps[i]),mBuf);
             if(ret1 != ROK)
             {
                SPutMsg(mBuf );
                RETVALUE( ret1 );
             }
          }
       }
       CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
       CMCHKPK(cmPkTknU8, &param->fxIncl,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrDevSel*/

/*
*
*    Fun:    cmPkCmSdpAttrOneWaySel
*
*    Desc:    pack the structure CmSdpAttrOneWaySel
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrOneWaySel
(
CmSdpAttrOneWaySel *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrOneWaySel(param ,mBuf)
CmSdpAttrOneWaySel *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpAttrOneWaySel)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->numComp.pres != NOTPRSNT )
       {
          for (i=param->numComp.val-1;i>=0;i--)
          {
             ret1 = cmPkCmSdpAttrDevSelComp( (param->comps[i]),mBuf);
             if(ret1 != ROK)
             {
                SPutMsg(mBuf );
                RETVALUE( ret1 );
             }
          }
       }
       CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
       CMCHKPK(cmPkTknU8, &param->dirFlg,mBuf);
       CMCHKPK(cmPkTknU8, &param->srvTyp,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrOneWaySel*/

/*
*
*    Fun:    cmPkCmSdpAttrAal23661Ass
*
*    Desc:    pack the structure CmSdpAttrAal23661Ass
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal23661Ass
(
CmSdpAttrAal23661Ass *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal23661Ass(param ,mBuf)
CmSdpAttrAal23661Ass *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal23661Ass)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->bsscopUu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->fsscopUu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->bsscopSdu,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->fsscopSdu,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->bsssar,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->fsssar,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->rasTimer,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal23661Ass*/

/*
*
*    Fun:    cmPkCmSdpAttrCapab
*
*    Desc:    pack the structure CmSdpAttrCapab
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrCapab
(
CmSdpAttrCapab *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrCapab(param ,mBuf)
CmSdpAttrCapab *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrCapab)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cfg,mBuf);
       if( param->type.pres != NOTPRSNT 
         && param->type.val == CM_SDP_CAPAB_NONSTD )
       {
          ret1 = cmPkMacroTknStrOSXL(&param->nonstd,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrCapab*/

/*
*
*    Fun:    cmPkCmSdpAttrAtmBcob
*
*    Desc:    pack the structure CmSdpAttrAtmBcob
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAtmBcob
(
CmSdpAttrAtmBcob *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAtmBcob(param ,mBuf)
CmSdpAttrAtmBcob *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAtmBcob)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->eetim,mBuf);
       CMCHKPK(cmPkTknU8, &param->bcob,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAtmBcob*/

/*
*
*    Fun:    cmPkCmSdpAttrQosParms
*
*    Desc:    pack the structure CmSdpAttrQosParms
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrQosParms
(
CmSdpAttrQosParms *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrQosParms(param ,mBuf)
CmSdpAttrQosParms *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrQosParms)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->aclr,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->cctd,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->actd,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->ccdv,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->acdv,mBuf);
       CMCHKPK(cmPkTknU8, &param->cdvtype,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrQosParms*/

/*
*
*    Fun:    cmPkCmSdpAttrTfcDesc
*
*    Desc:    pack the structure CmSdpAttrTfcDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrTfcDesc
(
CmSdpAttrTfcDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrTfcDesc(param ,mBuf)
CmSdpAttrTfcDesc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrTfcDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->te,mBuf);
       CMCHKPK(cmPkTknU8, &param->fd,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->mfs,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->mcr,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->cdvt,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->mbs,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->scr,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->pcr,mBuf);
       CMCHKPK(cmPkTknU8, &param->clp,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrTfcDesc*/

/*
*
*    Fun:    cmPkCmSdpAttrAbrParms
*
*    Desc:    pack the structure CmSdpAttrAbrParms
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAbrParms
(
CmSdpAttrAbrParms *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAbrParms(param ,mBuf)
CmSdpAttrAbrParms *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAbrParms)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->adtf,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cdf,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->trm,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->nrm,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAbrParms*/

/*
*
*    Fun:    cmPkCmSdpAttrBearType
*
*    Desc:    pack the structure CmSdpAttrBearType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrBearType
(
CmSdpAttrBearType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrBearType(param ,mBuf)
CmSdpAttrBearType *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrBearType)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->init,mBuf);
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrBearType*/

/*
*
*    Fun:    cmPkCmSdpAttrStruc
*
*    Desc:    pack the structure CmSdpAttrStruc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrStruc
(
CmSdpAttrStruc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrStruc(param ,mBuf)
CmSdpAttrStruc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrStruc)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->blksz,mBuf);
       CMCHKPK(cmPkTknU8, &param->enb,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrStruc*/

/*
*
*    Fun:    cmPkCmSdpAttrCpsSduSize
*
*    Desc:    pack the structure CmSdpAttrCpsSduSize
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrCpsSduSize
(
CmSdpAttrCpsSduSize *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrCpsSduSize(param ,mBuf)
CmSdpAttrCpsSduSize *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrCpsSduSize)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->cpcs,mBuf);
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrCpsSduSize*/

/*
*
*    Fun:    cmPkCmSdpAttrAal2Cps
*
*    Desc:    pack the structure CmSdpAttrAal2Cps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal2Cps
(
CmSdpAttrAal2Cps *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal2Cps(param ,mBuf)
CmSdpAttrAal2Cps *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal2Cps)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->simCPS,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->timerCU,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->maxCid,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->minCid,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal2Cps*/

/*
*
*    Fun:    cmPkCmSdpAttrAal23661
*
*    Desc:    pack the structure CmSdpAttrAal23661
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal23661
(
CmSdpAttrAal23661 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal23661(param ,mBuf)
CmSdpAttrAal23661 *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal23661)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU32OrNil, &param->bsssar,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->fsssar,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->rasTimer,mBuf);
       CMCHKPK(cmPkTknU8, &param->ted,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal23661*/

/*
*
*    Fun:    cmPkCmSdpAttrAal23662
*
*    Desc:    pack the structure CmSdpAttrAal23662
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAal23662
(
CmSdpAttrAal23662 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAal23662(param ,mBuf)
CmSdpAttrAal23662 *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrAal23662)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU16OrNil, &param->bmaxfrm,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->fmaxfrm,mBuf);
       CMCHKPK(cmPkTknU8, &param->enc,mBuf);
       CMCHKPK(cmPkTknU8, &param->mfr2,mBuf);
       CMCHKPK(cmPkTknU8, &param->mfr1,mBuf);
       CMCHKPK(cmPkTknU8, &param->mfall,mBuf);
       CMCHKPK(cmPkTknU8, &param->dtmf,mBuf);
       CMCHKPK(cmPkTknU8, &param->cas,mBuf);
       CMCHKPK(cmPkTknU8, &param->faxdm,mBuf);
       CMCHKPK(cmPkTknU8, &param->frmmd,mBuf);
       CMCHKPK(cmPkTknU8, &param->cktmd,mBuf);
       CMCHKPK(cmPkTknU8, &param->sap,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAal23662*/

/*
*
*    Fun:    cmPkCmSdpAttrLij
*
*    Desc:    pack the structure CmSdpAttrLij
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrLij
(
CmSdpAttrLij *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrLij(param ,mBuf)
CmSdpAttrLij *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrLij)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU32OrNil, &param->lsn,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->sci,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrLij*/

/*
*
*    Fun:    cmPkCmSdpAttrAnycast
*
*    Desc:    pack the structure CmSdpAttrAnycast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAnycast
(
CmSdpAttrAnycast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAnycast(param ,mBuf)
CmSdpAttrAnycast *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrAnycast)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cssel,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->csttype,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cdstd,mBuf);
       ret1 = cmPkCmSdpAnycastAddr(&param->grpAddr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAnycast*/

/*
*
*    Fun:    cmPkCmSdpAttrGeneric
*
*    Desc:    pack the structure CmSdpAttrGeneric
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrGeneric
(
CmSdpAttrGeneric *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrGeneric(param ,mBuf)
CmSdpAttrGeneric *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrGeneric)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->val,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrGeneric*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtp2848Res
*
*    Desc:    pack the structure CmSdpAttrFmtp2848Res
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp2848Res
(
CmSdpAttrFmtp2848Res *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp2848Res(param ,mBuf)
CmSdpAttrFmtp2848Res *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFmtp2848Res)

    if( param->type.pres != NOTPRSNT )
    {
       ret1 = cmPkMacroTknStrOSXL(&param->ref,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp2848Res*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtp2848ResSet
*
*    Desc:    pack the structure CmSdpAttrFmtp2848ResSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp2848ResSet
(
CmSdpAttrFmtp2848ResSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp2848ResSet(param ,mBuf)
CmSdpAttrFmtp2848ResSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpAttrFmtp2848ResSet)

    if( param->numRes.pres != NOTPRSNT )
    {
       for (i=param->numRes.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpAttrFmtp2848Res,  (param->resSet[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numRes,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp2848ResSet*/

/*
*
*    Fun:    cmPkCmSdpOptAttrSet
*
*    Desc:    pack the structure CmSdpOptAttrSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpOptAttrSet
(
CmSdpOptAttrSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpOptAttrSet(param ,intfVer, mBuf)
CmSdpOptAttrSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpOptAttrSet)

    if( param->numAttr.pres != NOTPRSNT )
    {
       for (i=param->numAttr.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpAttr( (param->attrSet[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numAttr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpOptAttrSet*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtp2848
*
*    Desc:    pack the structure CmSdpAttrFmtp2848
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp2848
(
CmSdpAttrFmtp2848 *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp2848(param ,intfVer, mBuf)
CmSdpAttrFmtp2848 *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFmtp2848)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpOptAttrSet(&param->attrSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpAttrFmtp2848ResSet(&param->resSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->subType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp2848*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtp2733
*
*    Desc:    pack the structure CmSdpAttrFmtp2733
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp2733
(
CmSdpAttrFmtp2733 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp2733(param ,mBuf)
CmSdpAttrFmtp2733 *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFmtp2733)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpAddr(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->num,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->pay,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp2733*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtp2833
*
*    Desc:    pack the structure CmSdpAttrFmtp2833
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp2833
(
CmSdpAttrFmtp2833 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp2833(param ,mBuf)
CmSdpAttrFmtp2833 *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFmtp2833)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->str,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkCmSdpU8OrNil, &param->pay,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp2833*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpAttrFmtpChnOrdSeq
*
*    Desc:    pack the structure CmSdpAttrFmtpChnOrdSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtpChnOrdSeq
(
CmSdpAttrFmtpChnOrdSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtpChnOrdSeq(param ,mBuf)
CmSdpAttrFmtpChnOrdSeq *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrFmtpChnOrdSeq)

    CMCHKPK(cmPkTknU8, &param->order,mBuf);
    CMCHKPK(cmPkTknU8, &param->convention,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtpChnOrdSeq*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtpEmChnChc
*
*    Desc:    pack the structure CmSdpAttrFmtpEmChnChc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtpEmChnChc
(
CmSdpAttrFmtpEmChnChc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtpEmChnChc(param ,mBuf)
CmSdpAttrFmtpEmChnChc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrFmtpEmChnChc)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_FMTP_CHANEL_ORDER :
             CMCHKPK(cmPkCmSdpAttrFmtpChnOrdSeq, &param->u.chnOrd,mBuf);
             break;
          case  CM_SDP_ATTR_FMTP_EMPHASIS :
             CMCHKPK(cmPkTknU8, &param->u.emphTyp,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtpEmChnChc*/

/*
*
*    Fun:    cmPkCmSdpAttrFmtpEmpChnOrd
*
*    Desc:    pack the structure CmSdpAttrFmtpEmpChnOrd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtpEmpChnOrd
(
CmSdpAttrFmtpEmpChnOrd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtpEmpChnOrd(param ,mBuf)
CmSdpAttrFmtpEmpChnOrd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrFmtpEmpChnOrd)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpAttrFmtpEmChnChc, &param->val,mBuf);
       CMCHKPK(cmPkTknU32, &param->payLoad,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtpEmpChnOrd*/
#endif

/*
*
*    Fun:    cmPkCmSdpAttrFmtp
*
*    Desc:    pack the structure CmSdpAttrFmtp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFmtp
(
CmSdpAttrFmtp *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFmtp(param ,intfVer, mBuf)
CmSdpAttrFmtp *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFmtp)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_FMTP_EMP_ORD :
             CMCHKPK(cmPkCmSdpAttrFmtpEmpChnOrd, &param->u.empChnOrd,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_FMTP_RFC2733 :
             ret1 = cmPkCmSdpAttrFmtp2733(&param->u.rfc2733,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_RFC2833 :
             ret1 = cmPkCmSdpAttrFmtp2833(&param->u.rfc2833,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_RFC2848 :
             ret1 = cmPkCmSdpAttrFmtp2848(&param->u.rfc2848, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_UNSPEC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.other,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFmtp*/

/*
*
*    Fun:    cmPkCmSdpSmpte
*
*    Desc:    pack the structure CmSdpSmpte
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpSmpte
(
CmSdpSmpte *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpSmpte(param ,mBuf)
CmSdpSmpte *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpSmpte)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->frac,mBuf);
       CMCHKPK(cmPkTknU8, &param->centisec,mBuf);
       CMCHKPK(cmPkTknU8, &param->sec,mBuf);
       CMCHKPK(cmPkTknU8, &param->min,mBuf);
       CMCHKPK(cmPkTknU8, &param->hr,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpSmpte*/

/*
*
*    Fun:    cmPkCmSdpTimeSmpte
*
*    Desc:    pack the structure CmSdpTimeSmpte
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTimeSmpte
(
CmSdpTimeSmpte *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTimeSmpte(param ,mBuf)
CmSdpTimeSmpte *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpTimeSmpte)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpSmpte, &param->end,mBuf);
       CMCHKPK(cmPkCmSdpSmpte, &param->start,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTimeSmpte*/

/*
*
*    Fun:    cmPkCmSdpNptSec
*
*    Desc:    pack the structure CmSdpNptSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpNptSec
(
CmSdpNptSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpNptSec(param ,mBuf)
CmSdpNptSec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpNptSec)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->frac,mBuf);
       CMCHKPK(cmPkTknU32, &param->sec,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpNptSec*/

/*
*
*    Fun:    cmPkCmSdpNptHMS
*
*    Desc:    pack the structure CmSdpNptHMS
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpNptHMS
(
CmSdpNptHMS *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpNptHMS(param ,mBuf)
CmSdpNptHMS *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpNptHMS)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->frac,mBuf);
       CMCHKPK(cmPkTknU8, &param->sec,mBuf);
       CMCHKPK(cmPkTknU8, &param->min,mBuf);
       CMCHKPK(cmPkTknU8, &param->hr,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpNptHMS*/

/*
*
*    Fun:    cmPkCmSdpNpt
*
*    Desc:    pack the structure CmSdpNpt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpNpt
(
CmSdpNpt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpNpt(param ,mBuf)
CmSdpNpt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpNpt)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_NPT_HMS :
             CMCHKPK(cmPkCmSdpNptHMS, &param->u.hms,mBuf);
             break;
          case  CM_SDP_NPT_SEC :
             CMCHKPK(cmPkCmSdpNptSec, &param->u.sec,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpNpt*/

/*
*
*    Fun:    cmPkCmSdpTimeNpt
*
*    Desc:    pack the structure CmSdpTimeNpt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTimeNpt
(
CmSdpTimeNpt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTimeNpt(param ,mBuf)
CmSdpTimeNpt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpTimeNpt)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpNpt, &param->end,mBuf);
       CMCHKPK(cmPkCmSdpNpt, &param->start,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTimeNpt*/

/*
*
*    Fun:    cmPkCmSdpUtc
*
*    Desc:    pack the structure CmSdpUtc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpUtc
(
CmSdpUtc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpUtc(param ,mBuf)
CmSdpUtc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpUtc)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->frac,mBuf);
       CMCHKPK(cmPkTknU32, &param->hms,mBuf);
       CMCHKPK(cmPkTknU32, &param->date,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpUtc*/

/*
*
*    Fun:    cmPkCmSdpTimeUtc
*
*    Desc:    pack the structure CmSdpTimeUtc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpTimeUtc
(
CmSdpTimeUtc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpTimeUtc(param ,mBuf)
CmSdpTimeUtc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpTimeUtc)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpUtc, &param->end,mBuf);
       CMCHKPK(cmPkCmSdpUtc, &param->start,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpTimeUtc*/

/*
*
*    Fun:    cmPkCmSdpAttrRange
*
*    Desc:    pack the structure CmSdpAttrRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrRange
(
CmSdpAttrRange *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrRange(param ,mBuf)
CmSdpAttrRange *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrRange)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_RANGE_NPT :
             CMCHKPK(cmPkCmSdpTimeNpt, &param->u.npt,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE :
             CMCHKPK(cmPkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE_25 :
             CMCHKPK(cmPkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE_30_DROP :
             CMCHKPK(cmPkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_UTC :
             CMCHKPK(cmPkCmSdpTimeUtc, &param->u.utc,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrRange*/

/*
*
*    Fun:    cmPkCmSdpAttrWtp
*
*    Desc:    pack the structure CmSdpAttrWtp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrWtp
(
CmSdpAttrWtp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrWtp(param ,mBuf)
CmSdpAttrWtp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrWtp)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->cccId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->iapSystemId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrWtp*/

/*
*
*    Fun:    cmPkCmSdpAttrCache
*
*    Desc:    pack the structure CmSdpAttrCache
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrCache
(
CmSdpAttrCache *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrCache(param ,mBuf)
CmSdpAttrCache *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrCache)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU32OrNil, &param->timer,mBuf);
       CMCHKPK(cmPkTknU8, &param->enable,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrCache*/

/*
*
*    Fun:    cmPkCmSdpAttrPhCxtId
*
*    Desc:    pack the structure CmSdpAttrPhCxtId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrPhCxtId
(
CmSdpAttrPhCxtId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrPhCxtId(param ,mBuf)
CmSdpAttrPhCxtId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrPhCxtId)

    ret1 = cmPkMacroTknStrOSXL(&param->uri,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMacroTknStrOSXL(&param->number,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrPhCxtId*/

/*
*
*    Fun:    cmPkCmSdpAttrRequire
*
*    Desc:    pack the structure CmSdpAttrRequire
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrRequire
(
CmSdpAttrRequire *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrRequire(param ,mBuf)
CmSdpAttrRequire *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpAttrRequire)

    if( param->numAttr.pres != NOTPRSNT )
    {
       for (i=param->numAttr.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->names[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numAttr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrRequire*/

/*
*
*    Fun:    cmPkCmSdpAttrAalApp
*
*    Desc:    pack the structure CmSdpAttrAalApp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrAalApp
(
CmSdpAttrAalApp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrAalApp(param ,mBuf)
CmSdpAttrAalApp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrAalApp)

    ret1 = cmPkMacroTknStrOSXL(&param->nonstd,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrAalApp*/

/*
*
*    Fun:    cmPkCmSdpAttrIpBcp
*
*    Desc:    pack the structure CmSdpAttrIpBcp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     abc.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrIpBcp
(
CmSdpAttrIpBcp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrIpBcp(param ,mBuf)
CmSdpAttrIpBcp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrIpBcp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->msgType,mBuf);
       CMCHKPK(cmPkTknU8, &param->version,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrIpBcp*/

#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpCnfmTg
*
*    Desc:    pack the structure CmSdpCnfmTg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpCnfmTg
(
CmSdpCnfmTg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpCnfmTg(param ,mBuf)
CmSdpCnfmTg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpCnfmTg)

    CMCHKPK(cmPkTknU8, &param->dirTg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpCnfmTg*/

/*
*
*    Fun:    cmPkCmSdpAttrQosSec
*
*    Desc:    pack the structure CmSdpAttrQosSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrQosSec
(
CmSdpAttrQosSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrQosSec(param ,mBuf)
CmSdpAttrQosSec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrQosSec)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpCnfmTg, &param->cnfmTg,mBuf);
       CMCHKPK(cmPkTknU8, &param->dirTg,mBuf);
       CMCHKPK(cmPkTknU8, &param->strnTg,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrQosSec*/

/*
*
*    Fun:    cmPkCmSdpAttrFidMid
*
*    Desc:    pack the structure CmSdpAttrFidMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrFidMid
(
CmSdpAttrFidMid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrFidMid(param ,mBuf)
CmSdpAttrFidMid *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrFidMid)

    ret1 = cmPkMacroTknStrOSXL(&param->idTag,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrFidMid*/

/*
*
*    Fun:    cmPkCmSdpAttrIdSet
*
*    Desc:    pack the structure CmSdpAttrIdSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrIdSet
(
CmSdpAttrIdSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrIdSet(param ,mBuf)
CmSdpAttrIdSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpAttrIdSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->idTags[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrIdSet*/

/*
*
*    Fun:    cmPkCmSdpAttrGroup
*
*    Desc:    pack the structure CmSdpAttrGroup
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrGroup
(
CmSdpAttrGroup *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrGroup(param ,mBuf)
CmSdpAttrGroup *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttrGroup)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpAttrIdSet(&param->ids,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->semantics,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrGroup*/
#endif

/*
*
*    Fun:    cmPkCmSdpEmailName
*
*    Desc:    pack the structure CmSdpEmailName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpEmailName
(
CmSdpEmailName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpEmailName(param ,mBuf)
CmSdpEmailName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpEmailName)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->email,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpEmailName*/

/*
*
*    Fun:    cmPkCmSdpNameEmail
*
*    Desc:    pack the structure CmSdpNameEmail
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpNameEmail
(
CmSdpNameEmail *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpNameEmail(param ,mBuf)
CmSdpNameEmail *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpNameEmail)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->email,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpNameEmail*/

/*
*
*    Fun:    cmPkCmSdpEmail
*
*    Desc:    pack the structure CmSdpEmail
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpEmail
(
CmSdpEmail *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpEmail(param ,mBuf)
CmSdpEmail *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpEmail)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_EMAIL_NAME :
             ret1 = cmPkCmSdpEmailName(&param->u.en,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_EMAIL_ONLY :
             ret1 = cmPkMacroTknStrOSXL(&param->u.email,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_NAME_EMAIL :
             ret1 = cmPkCmSdpNameEmail(&param->u.ne,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpEmail*/

/*
*
*    Fun:    cmPkCmSdpEmailSet
*
*    Desc:    pack the structure CmSdpEmailSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpEmailSet
(
CmSdpEmailSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpEmailSet(param ,mBuf)
CmSdpEmailSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpEmailSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpEmail,  (param->email[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpEmailSet*/

/*
*
*    Fun:    cmPkCmSdpPhoneName
*
*    Desc:    pack the structure CmSdpPhoneName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPhoneName
(
CmSdpPhoneName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPhoneName(param ,mBuf)
CmSdpPhoneName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpPhoneName)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->phone,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPhoneName*/

/*
*
*    Fun:    cmPkCmSdpNamePhone
*
*    Desc:    pack the structure CmSdpNamePhone
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpNamePhone
(
CmSdpNamePhone *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpNamePhone(param ,mBuf)
CmSdpNamePhone *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpNamePhone)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->phone,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpNamePhone*/

/*
*
*    Fun:    cmPkCmSdpPhone
*
*    Desc:    pack the structure CmSdpPhone
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPhone
(
CmSdpPhone *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPhone(param ,mBuf)
CmSdpPhone *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpPhone)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_NAME_PHONE :
             ret1 = cmPkCmSdpNamePhone(&param->u.np,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_PHONE_NAME :
             ret1 = cmPkCmSdpPhoneName(&param->u.pn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_PHONE_ONLY :
             ret1 = cmPkMacroTknStrOSXL(&param->u.phone,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPhone*/

/*
*
*    Fun:    cmPkCmSdpPhoneSet
*
*    Desc:    pack the structure CmSdpPhoneSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPhoneSet
(
CmSdpPhoneSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPhoneSet(param ,mBuf)
CmSdpPhoneSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpPhoneSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpPhone,  (param->phone[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPhoneSet*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpBwTyp
*
*    Desc:    pack the structure CmSdpBwTyp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpBwTyp
(
CmSdpBwTyp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpBwTyp(param ,mBuf)
CmSdpBwTyp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpBwTyp)

    ret1 = cmPkMacroTknStrOSXL(&param->unKnownBw,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->knownBw,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpBwTyp*/

/*
*
*    Fun:    cmPkCmSdpT38Fmt
*
*    Desc:    pack the structure CmSdpT38Fmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpT38Fmt
(
CmSdpT38Fmt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpT38Fmt(param ,mBuf)
CmSdpT38Fmt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpT38Fmt)

    ret1 = cmPkMacroTknStrOSXL(&param->unknownFmt,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->knownFmt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpT38Fmt*/
#endif /* CM_SDP_V_3 */

/*
*
*    Fun:    cmPkCmSdpMedFmtUnknownList
*
*    Desc:    pack the structure CmSdpMedFmtUnknownList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtUnknownList
(
CmSdpMedFmtUnknownList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtUnknownList(param ,mBuf)
CmSdpMedFmtUnknownList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtUnknownList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtUnknownList*/

/*
*
*    Fun:    cmPkCmSdpMedFmtAalxList
*
*    Desc:    pack the structure CmSdpMedFmtAalxList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtAalxList
(
CmSdpMedFmtAalxList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtAalxList(param ,mBuf)
CmSdpMedFmtAalxList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtAalxList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpU8OrNil,  (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtAalxList*/

/*
*
*    Fun:    cmPkCmSdpMedFmtRtpList
*
*    Desc:    pack the structure CmSdpMedFmtRtpList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
/* 001.main_12: change to support a mix of "$" & integers in RTP list */
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtRtpList
(
CmSdpMedFmtRtpList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtRtpList(param ,mBuf)
CmSdpMedFmtRtpList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtRtpList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpU8OrNil, (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtRtpList*/

/*
*
*    Fun:    cmPkCmSdpMedFmtLclList
*
*    Desc:    pack the structure CmSdpMedFmtLclList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtLclList
(
CmSdpMedFmtLclList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtLclList(param ,mBuf)
CmSdpMedFmtLclList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtLclList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtLclList*/

/*
*
*    Fun:    cmPkCmSdpMedFmtTnList
*
*    Desc:    pack the structure CmSdpMedFmtTnList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtTnList
(
CmSdpMedFmtTnList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtTnList(param ,mBuf)
CmSdpMedFmtTnList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtTnList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpMimeSubtype,  (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtTnList*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpMedFmtUdptlList
*
*    Desc:    pack the structure CmSdpMedFmtUdptlList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtUdptlList
(
CmSdpMedFmtUdptlList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtUdptlList(param ,mBuf)
CmSdpMedFmtUdptlList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtUdptlList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpT38Fmt,  (param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedFmtUdptlList*/
#endif /* CM_SDP_V_3 */

/*
*
*    Fun:    cmPkCmSdpMedProtoFmts
*
*    Desc:    pack the structure CmSdpMedProtoFmts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedProtoFmts
(
CmSdpMedProtoFmts *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedProtoFmts(param ,intfVer, mBuf)
CmSdpMedProtoFmts *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpMedProtoFmts)

    if( param->protType.pres != NOTPRSNT )
    {
       switch( param->protType.val )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             ret1 = cmPkCmSdpMedFmtAalxList(&param->u.aalx,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             ret1 = cmPkCmSdpMedFmtAalxList(&param->u.aalx,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             ret1 = cmPkCmSdpMedFmtAalxList(&param->u.aalx,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_LCL :
             ret1 = cmPkCmSdpMedFmtLclList(&param->u.lcl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             ret1 = cmPkCmSdpMedFmtRtpList(&param->u.rtp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_SAP :
             break;
          case  CM_SDP_MEDIA_PROTO_TCP :
             ret1 = cmPkCmSdpMedFmtTnList(&param->u.tn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_FAX :
             ret1 = cmPkCmSdpMedFmtTnList(&param->u.tn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_PAGER :
             ret1 = cmPkCmSdpMedFmtTnList(&param->u.tn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_VOICE :
             ret1 = cmPkCmSdpMedFmtTnList(&param->u.tn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_UDP :
             ret1 = cmPkCmSdpMedFmtTnList(&param->u.tn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;

#ifdef CM_SDP_V_3
          case  CM_SDP_MEDIA_PROTO_UDPTL :
             ret1 = cmPkCmSdpMedFmtUdptlList(&param->u.t38,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /* CM_SDP_V_3 */

#ifdef CM_SDP_SIP_IM_SUPPORT
          case  CM_SDP_MEDIA_PROTO_SIP:
             ret1 = cmPkCmSdpMedFmtAddrSpecList(&param->u.sip,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /* CM_SDP_SIP_IM_SUPPORT */

          case  CM_SDP_MEDIA_PROTO_UNKNOWN :
             ret1 = cmPkCmSdpMedFmtUnknownList(&param->u.unknown,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->protType,mBuf);
    ret1 = cmPkCmSdpMedProto(&param->prot,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedProtoFmts*/

/*
*
*    Fun:    cmPkCmSdpMedPar
*
*    Desc:    pack the structure CmSdpMedPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedPar
(
CmSdpMedPar *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedPar(param ,intfVer, mBuf)
CmSdpMedPar *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpMedPar)

    if( param->numProtFmts.pres != NOTPRSNT )
    {
       for (i=param->numProtFmts.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpMedProtoFmts( (param->pflst[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numProtFmts,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMedPar*/

/*
*
*    Fun:    cmPkCmSdpVcci
*
*    Desc:    pack the structure CmSdpVcci
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpVcci
(
CmSdpVcci *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpVcci(param ,mBuf)
CmSdpVcci *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpVcci)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cid,mBuf);
       CMCHKPK(cmPkCmSdpU32OrNil, &param->vcci,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpVcci*/

/*
*
*    Fun:    cmPkCmSdpVpVcCid
*
*    Desc:    pack the structure CmSdpVpVcCid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpVpVcCid
(
CmSdpVpVcCid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpVpVcCid(param ,mBuf)
CmSdpVpVcCid *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpVpVcCid)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpU8OrNil, &param->cid,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->vci,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->vpi,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpVpVcCid*/

/*
*
*    Fun:    cmPkCmSdpAddrVcci
*
*    Desc:    pack the structure CmSdpAddrVcci
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAddrVcci
(
CmSdpAddrVcci *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAddrVcci(param ,mBuf)
CmSdpAddrVcci *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAddrVcci)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  CM_SDP_ADDR_VCCI :
                CMCHKPK(cmPkCmSdpVcci, &param->u.vcci,mBuf);
                break;
             case  CM_SDP_ADDR_VPCIVCI :
                CMCHKPK(cmPkCmSdpVpVcCid, &param->u.vpcid,mBuf);
                break;
             case  CM_SDP_CHOOSE :
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       ret1 = cmPkCmSdpAddr(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAddrVcci*/

/*
*
*    Fun:    cmPkCmSdpBcg
*
*    Desc:    pack the structure CmSdpBcg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpBcg
(
CmSdpBcg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpBcg(param ,mBuf)
CmSdpBcg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpBcg)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  CM_SDP_ADDR_VCCI :
                CMCHKPK(cmPkCmSdpVcci, &param->u.vcci,mBuf);
                break;
             case  CM_SDP_ADDR_VPIVCI :
                CMCHKPK(cmPkCmSdpVpVcCid, &param->u.vpcid,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkCmSdpU8OrNil, &param->bcg,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpBcg*/

/*
*
*    Fun:    cmPkCmSdpPortIdVpVcCid
*
*    Desc:    pack the structure CmSdpPortIdVpVcCid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPortIdVpVcCid
(
CmSdpPortIdVpVcCid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPortIdVpVcCid(param ,mBuf)
CmSdpPortIdVpVcCid *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpPortIdVpVcCid)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkCmSdpVpVcCid, &param->vpcid,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->portId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPortIdVpVcCid*/

/*
*
*    Fun:    cmPkCmSdpPortInt
*
*    Desc:    pack the structure CmSdpPortInt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPortInt
(
CmSdpPortInt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPortInt(param ,mBuf)
CmSdpPortInt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpPortInt)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->rep,mBuf);
       CMCHKPK(cmPkCmSdpU16OrNil, &param->port,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPortInt*/

/*
*
*    Fun:    cmPkCmSdpPort
*
*    Desc:    pack the structure CmSdpPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpPort
(
CmSdpPort *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpPort(param ,mBuf)
CmSdpPort *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpPort)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_PORT_INT :
             CMCHKPK(cmPkCmSdpPortInt, &param->u.portInt,mBuf);
             break;
          case  CM_SDP_PORT_VPCID :
             ret1 = cmPkCmSdpPortIdVpVcCid(&param->u.vpcid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpPort*/

/*
*
*    Fun:    cmPkCmSdpVcId
*
*    Desc:    pack the structure CmSdpVcId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpVcId
(
CmSdpVcId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpVcId(param ,mBuf)
CmSdpVcId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpVcId)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_VCID_ATM_ADDR_VCCI :
             ret1 = cmPkCmSdpAddrVcci(&param->u.atmAddrVcci,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_BCG :
             CMCHKPK(cmPkCmSdpBcg, &param->u.bcg,mBuf);
             break;
          case  CM_SDP_VCID_CHOOSE :
             break;
          case  CM_SDP_VCID_IMPLICIT :
             ret1 = cmPkMacroTknStrOSXL(&param->u.impl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_NIL :
             break;
          case  CM_SDP_VCID_PORT :
             ret1 = cmPkCmSdpPort(&param->u.port,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_VCCI :
             CMCHKPK(cmPkCmSdpVcci, &param->u.vcci,mBuf);
             break;
          case  CM_SDP_VCID_VPCI :
             CMCHKPK(cmPkCmSdpVpci, &param->u.vpci,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpVcId*/

/*
*
*    Fun:    cmPkCmSdpMediaField
*
*    Desc:    pack the structure CmSdpMediaField
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMediaField
(
CmSdpMediaField *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMediaField(param ,intfVer, mBuf)
CmSdpMediaField *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;

    /*
     * 002.main_6: Changing Code for 001.main_6 so that dependency on
     * MGT Interface is not there and doesn't affect other products
     */
    CmIntfVer   verDelta;                 
    TRC3(cmPkCmSdpMediaField)

/* 003.main_6: changed dependency from MG to MG_RUG */
#ifdef MG_RUG
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */
    /*
     * 002.main_6 :- Modified switch statement to make code independent of
     *               protocol used
     */
    switch(verDelta)
    {
       case 0 :
               /*
                * remote ver is same as ours (latest). So pack as latest.
                * this part is the generated code
                */
               if(param->pres.pres != NOTPRSNT)
               {
                  ret1 = cmPkCmSdpMedPar(&param->par, intfVer ,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
                  ret1 = cmPkCmSdpVcId(&param->id,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
                  if( ( param->mediaType.pres != NOTPRSNT )
                    && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                  {
                     ret1 = cmPkMacroTknStrOSXL(&param->media,mBuf);
                     if (ret1 != ROK)
                     {
                        RETVALUE(RFAILED);
                     }
                  }
                  CMCHKPK(cmPkTknU8, &param->mediaType,mBuf);
               }
               CMCHKPK(cmPkTknPres, &param->pres,mBuf);

               break;
       case 1 :
               /*
                * 001.main_6 :- pack occording to the lower version;
                * hand written code;
                */

               {
                  CmSdpMediaField_V1     *med;
                  EXTERN CmAbnfElmDef cmMsgDefSdpMediaField;
                  EXTERN CmAbnfElmDef cmMsgDefSdpMediaField_V1;

                   /*
                    * Call the following func to -
                    * 1. encode the event struct (param) passed to it
                    *    occording to the new DB (cmMsgDefSdpMediaField)
                    * 2. decode the resulting mBuf in the new event struct
                    *    (med) passed to it occording to the old DB
                    *    (cmMsgDefSdpMediaField_V1)
                    */

                   CM_TRANSLATE_FUNC(param, cmMsgDefSdpMediaField,
                                     cmMsgDefSdpMediaField_V1, med,
                                     med->memCp, med->pres,
                                     CM_ABNF_PROT_SDP)

                   /*
                    * Now pack it occording to CmSdpMediaField_V1
                    */
                   if(med->pres.pres != NOTPRSNT)
                   {
                      ret1 = cmPkCmSdpMedPar(&med->par, intfVer ,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmPkCmSdpVcId(&med->id,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      if( ( med->mediaType.pres != NOTPRSNT )
                        && ( med->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                      {
                         ret1 = cmPkMacroTknStrOSXL(&med->media,mBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      CMCHKPK(cmPkTknU8, &med->mediaType,mBuf);
                   }
                   CMCHKPK(cmPkTknPres, &med->pres,mBuf);

                   cmFreeMem((Ptr)med);
                   RETVALUE(ROK);
               }

               break;
       default :
                RETVALUE(RFAILED);
               break;
    }

    RETVALUE(ROK);
} /*end of function cmPkCmSdpMediaField*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpAttrCapDesc
*
*    Desc:    pack the structure CmSdpAttrCapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrCapDesc
(
CmSdpAttrCapDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrCapDesc(param ,intfVer, mBuf)
CmSdpAttrCapDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    /*
     * 002.main_6: Changing Code for 001.main_6 so that dependency on
     * MGT Interface is not there and doesn't affect other products
     */
    CmIntfVer   verDelta;                 
    TRC3(cmPkCmSdpAttrCapDesc)

/* 003.main_6: changed dependency from MG to MG_RUG */
#ifdef MG_RUG
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */
    /*
     * 002.main_6 :- Modified switch statement to make code independent of
     *               protocol used
     */
    switch(verDelta)
    {
       case 0 :
               /*
                * remote ver is same as ours (latest). So pack as latest.
                * this part is the generated code
                */
               if(param->pres.pres != NOTPRSNT)
               {
                  ret1 = cmPkCmSdpMedPar(&param->par, intfVer ,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
                  if( ( param->mediaType.pres != NOTPRSNT )
                    && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
                  {
                     ret1 = cmPkMacroTknStrOSXL(&param->media,mBuf);
                     if (ret1 != ROK)
                     {
                        RETVALUE(RFAILED);
                     }
                  }
                  CMCHKPK(cmPkTknU8, &param->mediaType,mBuf);
                  CMCHKPK(cmPkTknU8, &param->capNum,mBuf);
               }
               CMCHKPK(cmPkTknPres, &param->pres,mBuf);

               break;
       case 1 :
               /*
                * 001.main_6 :- pack occording to the lower version;
                * hand written code
                */

               {
                   CmSdpAttrCapDesc_V1     *capDesc;
                   EXTERN CmAbnfElmDef cmMsgDefSdpAttrCdsc;
                   EXTERN CmAbnfElmDef cmMsgDefSdpAttrCdsc_V1;

                   /*
                    * Call the following func to -
                    * 1. encode the event struct (param) passed to it
                    *    occording to the new DB (cmMsgDefSdpAttrCapCdsc)
                    * 2. decode the resulting mBuf in the new event struct
                    *    (capDesc) passed to it occording to the old DB
                    *    (cmMsgDefSdpAttrCapDesc_V1)
                    */

                   CM_TRANSLATE_FUNC(param, cmMsgDefSdpAttrCdsc,
                                     cmMsgDefSdpAttrCdsc_V1, capDesc,
                                     capDesc->memCp, capDesc->pres,
                                     CM_ABNF_PROT_SDP)

                   /*
                    * Now pack it occording to CmSdpAttrCapDesc_V1
                    */
                   if(capDesc->pres.pres != NOTPRSNT)
                   {
                      ret1 = cmPkCmSdpMedPar(&capDesc->par,intfVer,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmPkCmSdpVcId(&capDesc->id,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      if( ( capDesc->mediaType.pres != NOTPRSNT )
                        && ( capDesc->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
                        
                      {
                         ret1 = cmPkMacroTknStrOSXL(&capDesc->media,mBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      CMCHKPK(cmPkTknU8, &capDesc->mediaType,mBuf);
                      CMCHKPK(cmPkTknU8, &capDesc->capNum,mBuf);
                   }
                   CMCHKPK(cmPkTknPres, &capDesc->pres,mBuf);

                   cmFreeMem((Ptr)capDesc);
                   RETVALUE(ROK);
               }

               break;
       default :
                RETVALUE(RFAILED);
               break;
    }

    RETVALUE(ROK);


} /*end of function cmPkCmSdpAttrCapDesc*/

/*
*
*    Fun:    cmPkCmSdpAttrT38Fax
*
*    Desc:    pack the structure CmSdpAttrT38Fax
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrT38Fax
(
CmSdpAttrT38Fax *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrT38Fax(param ,mBuf)
CmSdpAttrT38Fax *param;
Buffer *mBuf;
#endif
{
    S16 ret1;

    TRC3(cmPkCmSdpAttrT38Fax)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_T38_FAX_FILL_BIT_RMVL :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_MAX_BFR :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_MAX_DATAGRAM :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_RATE_MNGMNT :
             CMCHKPK(cmPkTknU8, &param->u.val,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_TRNS_JBIG :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_TRNS_MMR :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_UDP_EC :
             CMCHKPK(cmPkTknU8, &param->u.val,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_VER :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_MAX_BIT_RATE :
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;

             /* 001.main_12: t38 enhancements */
          case CM_SDP_ATTR_T38_FAX_HIGH_RDNCY:
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;

          case CM_SDP_ATTR_T38_FAX_LOW_RDNCY:
             CMCHKPK(cmPkTknU32, &param->u.num,mBuf);
             break;

          case CM_SDP_ATTR_T38_FAX_UNKNOWN:
             ret1 = cmPkCmSdpAttrGeneric(&param->u.unknown,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;

          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrT38Fax*/
#endif
/* cm_sdp_c_002.main_12: Modified to allow $ (CHOOSE)
 * in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE

/*
*
*    Fun:    cmPkCmSdpAttrEecId
*
*    Desc:    pack the structure CmSdpAttrAttrEecId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrEecId
(
CmSdpAttrEecId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrEecId(param, mBuf)
CmSdpAttrEecId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkCmSdpAttrEecId)

    CMCHKPK(cmPkTknU32, &param->eecid,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);


} /*end of function cmPkCmSdpAttrEecId*/
#endif

/*
*
*    Fun:    cmPkCmSdpAttr
*
*    Desc:    pack the structure CmSdpAttr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttr
(
CmSdpAttr *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttr(param ,intfVer, mBuf)
CmSdpAttr *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpAttr)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_AAL2BTRFCDESC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.aal2_tfcb,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2CPS :
             CMCHKPK(cmPkCmSdpAttrAal2Cps, &param->u.aal2_cps,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2FTRFCDESC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.aal2_tfcf,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2QOSBPARMS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.aal2_qosb,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2QOSFPARMS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.aal2_qosf,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2SSCS3652 :
             break;
          case  CM_SDP_ATTR_AAL2SSCS3653 :
             break;
          case  CM_SDP_ATTR_AAL2SSCS3661 :
             CMCHKPK(cmPkCmSdpAttrAal23661, &param->u.aal2_3661,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2SSCS3661_ASS :
             CMCHKPK(cmPkCmSdpAttrAal23661Ass, &param->u.aal2_3661Ass,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2SSCS3662 :
             CMCHKPK(cmPkCmSdpAttrAal23662, &param->u.aal2_3662,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2_CPSSDURATE :
             CMCHKPK(cmPkCmSdpAttrAal2CpsSduRate, &param->u.al2CpSduRt,mBuf);
             break;
          case  CM_SDP_ATTR_AAL5APP :
             ret1 = cmPkCmSdpAttrAalApp(&param->u.aal5_app,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL5_SSCOP :
             CMCHKPK(cmPkCmSdpAttrAal5Sscop, &param->u.al5Sscop,mBuf);
             break;
          case  CM_SDP_ATTR_AALTYPE :
             CMCHKPK(cmPkTknU8, &param->u.aaltype,mBuf);
             break;
          case  CM_SDP_ATTR_ABRPARMS :
             CMCHKPK(cmPkCmSdpAttrAbrParms, &param->u.abr,mBuf);
             break;
          case  CM_SDP_ATTR_ABR_SETUP :
             CMCHKPK(cmPkCmSdpAttrAtmAbrSetup, &param->u.abrSetup,mBuf);
             break;
          case  CM_SDP_ATTR_ANYCAST :
             ret1 = cmPkCmSdpAttrAnycast(&param->u.anycast,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ATMMAP :
             ret1 = cmPkCmSdpAttrAtmMap(&param->u.atmmap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ATMQOSPARMS :
             CMCHKPK(cmPkCmSdpAttrQosParms, &param->u.qos,mBuf);
             break;
          case  CM_SDP_ATTR_ATMTRFCDESC :
             CMCHKPK(cmPkCmSdpAttrTfcDesc, &param->u.tfc,mBuf);
             break;
          case  CM_SDP_ATTR_BCOB :
             CMCHKPK(cmPkCmSdpAttrAtmBcob, &param->u.bcob,mBuf);
             break;
          case  CM_SDP_ATTR_BEARERTYPE :
             CMCHKPK(cmPkCmSdpAttrBearType, &param->u.bearer,mBuf);
             break;
          case  CM_SDP_ATTR_BRR_SIGIE :
             ret1 = cmPkCmSdpAttrAtmBrrSigIe(&param->u.brrSigIe,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CACHE :
             CMCHKPK(cmPkCmSdpAttrCache, &param->u.cache,mBuf);
             break;
          case  CM_SDP_ATTR_CAPABILITY :
             ret1 = cmPkCmSdpAttrCapab(&param->u.capab,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CAT :
             ret1 = cmPkMacroTknStrOSXL(&param->u.cat,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CBR_RATE :
             CMCHKPK(cmPkTknU8, &param->u.cbrRate,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_CDSC :
             ret1 = cmPkCmSdpAttrCapDesc(&param->u.cdsc, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_CHAIN :
             CMCHKPK(cmPkTknU8, &param->u.chain,mBuf);
             break;
          case  CM_SDP_ATTR_CHARSET :
             ret1 = cmPkMacroTknStrOSXL(&param->u.charset,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CLIR :
             CMCHKPK(cmPkTknU8, &param->u.clir,mBuf);
             break;
          case  CM_SDP_ATTR_CLKREC :
             CMCHKPK(cmPkTknU8, &param->u.clcrec,mBuf);
             break;
          case  CM_SDP_ATTR_CODEC_CFG :
             ret1 = cmPkMacroTknStrOSXL(&param->u.codecCfg,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CONTROL :
             ret1 = cmPkMacroTknStrOSXL(&param->u.control,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_CPAR :
             ret1 = cmPkCmSdpAttrCapParam(&param->u.capPar, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_MAX :
             ret1 = cmPkCmSdpAttrCapParam(&param->u.capPar, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_MIN :
             ret1 = cmPkCmSdpAttrCapParam(&param->u.capPar, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_CPSSDUSIZE :
             CMCHKPK(cmPkCmSdpAttrCpsSduSize, &param->u.cpss,mBuf);
             break;
          case  CM_SDP_ATTR_DIRECTION :
             CMCHKPK(cmPkCmSdpAttrDirection, &param->u.direction,mBuf);
             break;
          case  CM_SDP_ATTR_DSEL :
             ret1 = cmPkCmSdpAttrDevSel(&param->u.dsel,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ECAN :
             CMCHKPK(cmPkCmSdpAttrEchoCan, &param->u.ecan,mBuf);
             break;
          case  CM_SDP_ATTR_EECID :
/* cm_sdp_c_002.main_12: Modified to allow $ (CHOOSE) in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE
             CMCHKPK(cmPkCmSdpAttrEecId, &param->u.eecid,mBuf);
#else
             CMCHKPK(cmPkTknU32, &param->u.eecid,mBuf);
#endif
             break;
          case  CM_SDP_ATTR_ETAG :
             ret1 = cmPkMacroTknStrOSXL(&param->u.etag,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FEC :
             CMCHKPK(cmPkTknU8, &param->u.fec,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_FID :
             ret1 = cmPkCmSdpAttrFidMid(&param->u.fidVal,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_FMTP :
             ret1 = cmPkCmSdpAttrFmtp(&param->u.fmtp, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FRAMERATE :
             ret1 = cmPkMacroTknStrOSXL(&param->u.framerate,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FSEL :
             ret1 = cmPkCmSdpAttrDevSel(&param->u.fsel,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_GC :
             CMCHKPK(cmPkCmSdpAttrGainCtl, &param->u.gc,mBuf);
             break;
          case  CM_SDP_ATTR_GENERIC :
             ret1 = cmPkCmSdpAttrGeneric(&param->u.unknown,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_GROUP :
             ret1 = cmPkCmSdpAttrGroup(&param->u.group,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_INACTIVE :
             break;
          case  CM_SDP_ATTR_ISUP_USI :
             ret1 = cmPkMacroTknStrOSXL(&param->u.isupUsi,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_KEYWDS :
             ret1 = cmPkMacroTknStrOSXL(&param->u.keywds,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_LANG :
             ret1 = cmPkMacroTknStrOSXL(&param->u.lang,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_LIJ :
             CMCHKPK(cmPkCmSdpAttrLij, &param->u.lij,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_MID :
             ret1 = cmPkCmSdpAttrFidMid(&param->u.midVal,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_ONE_WAY_SEL :
             ret1 = cmPkCmSdpAttrOneWaySel(&param->u.oneWaySel,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ORIENT :
             CMCHKPK(cmPkTknU8, &param->u.orient,mBuf);
             break;
          case  CM_SDP_ATTR_PHONECONTEXT :
             ret1 = cmPkCmSdpAttrPhCxtId(&param->u.phoneContextIdent,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_PROFILEDESC :
             ret1 = cmPkCmSdpAttrProfDesc(&param->u.profd,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_PRTFL :
             CMCHKPK(cmPkTknU8, &param->u.prtfl,mBuf);
             break;
          case  CM_SDP_ATTR_PTIME :
             CMCHKPK(cmPkTknU32, &param->u.ptime,mBuf);
             break;
          case  CM_SDP_ATTR_Q763INN :
             CMCHKPK(cmPkTknU8, &param->u.q763Inn,mBuf);
             break;
          case  CM_SDP_ATTR_Q763NATURE :
             CMCHKPK(cmPkTknU8, &param->u.q763Nature,mBuf);
             break;
          case  CM_SDP_ATTR_Q763PLAN :
             CMCHKPK(cmPkTknU8, &param->u.q763Plan,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_QOS :
             CMCHKPK(cmPkCmSdpAttrQosSec, &param->u.qosVal,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_QOSCLASS :
             CMCHKPK(cmPkCmSdpU8OrNil, &param->u.qoscls,mBuf);
             break;
          case  CM_SDP_ATTR_QUALITY :
             ret1 = cmPkMacroTknStrOSXL(&param->u.quality,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_RANGE :
             CMCHKPK(cmPkCmSdpAttrRange, &param->u.range,mBuf);
             break;
          case  CM_SDP_ATTR_RECVONLY :
             break;
          case  CM_SDP_ATTR_REQUIRE :
             ret1 = cmPkCmSdpAttrRequire(&param->u.require,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_RTPMAP :
             ret1 = cmPkCmSdpAttrRtpMap(&param->u.rtpmap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_SBC :
             CMCHKPK(cmPkTknU8, &param->u.sbc,mBuf);
             break;
          case  CM_SDP_ATTR_SDPLANG :
             ret1 = cmPkMacroTknStrOSXL(&param->u.sdplang,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_SECURE :
             CMCHKPK(cmPkCmSdpAttrQosSec, &param->u.secVal,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_SENDONLY :
             break;
          case  CM_SDP_ATTR_SENDRECV :
             break;
          case  CM_SDP_ATTR_SILENCESUPP :
             CMCHKPK(cmPkCmSdpAttrSilSupp, &param->u.silsupp,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_SQN_NUM :
             CMCHKPK(cmPkTknU8, &param->u.sqnNum,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_STC :
             CMCHKPK(cmPkTknU8, &param->u.stc,mBuf);
             break;
          case  CM_SDP_ATTR_STRUCTURE :
             CMCHKPK(cmPkCmSdpAttrStruc, &param->u.struc,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_T38_FAX :
             CMCHKPK(cmPkCmSdpAttrT38Fax, &param->u.fax,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_TOOL :
             ret1 = cmPkMacroTknStrOSXL(&param->u.tool,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_TYPE :
             ret1 = cmPkCmSdpAttrType(&param->u.type,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_UILYR1_PROT :
             CMCHKPK(cmPkTknU8, &param->u.uiLr1Prot,mBuf);
             break;
          case  CM_SDP_ATTR_UPCC :
             CMCHKPK(cmPkCmSdpU8OrNil, &param->u.upcc,mBuf);
             break;
          case  CM_SDP_ATTR_VSEL :
             ret1 = cmPkCmSdpAttrDevSel(&param->u.vsel,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_WTP :
             ret1 = cmPkCmSdpAttrWtp(&param->u.wtp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_IPBCP :
             ret1 = cmPkCmSdpAttrIpBcp(&param->u.bcp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttr*/

/*
*
*    Fun:    cmPkCmSdpAttrSet
*
*    Desc:    pack the structure CmSdpAttrSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpAttrSet
(
CmSdpAttrSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpAttrSet(param ,intfVer, mBuf)
CmSdpAttrSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpAttrSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpAttr( (param->attr[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpAttrSet*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmPkCmSdpBw
*
*    Desc:    pack the structure CmSdpBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpBw
(
CmSdpBw *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpBw(param ,mBuf)
CmSdpBw *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpBw)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->bWidth,mBuf);
       ret1 = cmPkCmSdpBwTyp(&param->bwType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpBw*/
#else

/*
*
*    Fun:    cmPkCmSdpBw
*
*    Desc:    pack the structure CmSdpBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpBw
(
CmSdpBw *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpBw(param ,mBuf)
CmSdpBw *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpBw)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->bWidth,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->bwType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpBw*/
#endif

/*
*
*    Fun:    cmPkCmSdpBwSet
*
*    Desc:    pack the structure CmSdpBwSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpBwSet
(
CmSdpBwSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpBwSet(param ,mBuf)
CmSdpBwSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpBwSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkCmSdpBw,  (param->sdpBw[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpBwSet*/

/*
*
*    Fun:    cmPkCmSdpMediaDesc
*
*    Desc:    pack the structure CmSdpMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMediaDesc
(
CmSdpMediaDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMediaDesc(param ,intfVer, mBuf)
CmSdpMediaDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpMediaDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpAttrSet(&param->attrSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpKeyType(&param->keyType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpBwSet(&param->bwSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpConnSet(&param->connSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->info,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpMediaField(&param->field, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMediaDesc*/

/*
*
*    Fun:    cmPkCmSdpMediaDescSet
*
*    Desc:    pack the structure CmSdpMediaDescSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMediaDescSet
(
CmSdpMediaDescSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMediaDescSet(param ,intfVer, mBuf)
CmSdpMediaDescSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpMediaDescSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpMediaDesc( (param->mediaDesc[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpMediaDescSet*/

/*
*
*    Fun:    cmPkCmSdpInfo
*
*    Desc:    pack the structure CmSdpInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpInfo
(
CmSdpInfo *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpInfo(param ,intfVer, mBuf)
CmSdpInfo *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkCmSdpInfo)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpMediaDescSet(&param->mediaDescSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpAttrSet(&param->attrSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpKeyType(&param->keyType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpTime(&param->sdpTime,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpBwSet(&param->bwSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpConn(&param->conn,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpPhoneSet(&param->phoneSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpEmailSet(&param->emailSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->uri,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->info,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->sessName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkCmSdpOptOrig(&param->orig,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->ver,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpInfo*/

/*
*
*    Fun:    cmPkCmSdpInfoSet
*
*    Desc:    pack the structure CmSdpInfoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpInfoSet
(
CmSdpInfoSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpInfoSet(param ,intfVer, mBuf)
CmSdpInfoSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkCmSdpInfoSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkCmSdpInfo( (param->info[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkCmSdpInfoSet*/
#endif /* CM_SDP_V_2 */
#ifdef CM_SDP_V_2
#ifdef CM_SDP_V_3
/*
*
*    Fun:    cmUnpkCmSdpAttrCapParam
*
*    Desc:    unpack the structure CmSdpAttrCapParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrCapParam
(
CmSdpAttrCapParam *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrCapParam(param ,ptr ,intfVer ,mBuf)
CmSdpAttrCapParam *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrCapParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_CPAR_BW :
             ret1 = cmUnpkCmSdpBwSet( (CmSdpBwSet *)(&(param->u.bwSet)),ptr, mBuf );
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_ATTR :
             ret1 = cmUnpkCmSdpAttrSet( (CmSdpAttrSet *)(&(param->u.attrSet)),ptr, intfVer, mBuf );
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrCapParam*/
#endif


/*
*
*    Fun:    cmUnpkCmSdpIp4Unicast
*
*    Desc:    unpack the structure cmSdpIp4Unicast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp4Unicast
(
CmSdpIp4Unicast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp4Unicast(param ,mBuf)
CmSdpIp4Unicast *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpIp4Unicast)

    for (i=0;i<4 ;i++)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->b[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp4Unicast*/

/*
*
*    Fun:    cmUnpkCmSdpIp4Multicast
*
*    Desc:    unpack the structure cmSdpIp4Multicast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp4Multicast
(
CmSdpIp4Multicast *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp4Multicast(param ,mBuf)
CmSdpIp4Multicast *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpIp4Multicast)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpIp4Unicast, &param->ip,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->ttl,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->numAddr,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp4Multicast*/

/*
*
*    Fun:    cmUnpkCmSdpIp4Addr
*
*    Desc:    unpack the structure CmSdpIp4Addr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp4Addr
(
CmSdpIp4Addr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp4Addr(param ,ptr, mBuf)
CmSdpIp4Addr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpIp4Addr)

    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV4_FQDN :
             ret1 = cmUnpkCmSdpIpFQDN(&param->u.fqdn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV4_IP_ANY :
             break;
          case  CM_SDP_IPV4_IP_MULTI :
             break;
          case  CM_SDP_IPV4_IP_UNI :
             CMCHKUNPK(cmUnpkCmSdpIp4Unicast, &param->u.ip,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp4Addr*/

/*
*
*    Fun:    cmUnpkCmSdpIp4Conn
*
*    Desc:    unpack the structure CmSdpIp4Conn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp4Conn
(
CmSdpIp4Conn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp4Conn(param ,ptr, mBuf)
CmSdpIp4Conn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpIp4Conn)

    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV4_FQDN :
             ret1 = cmUnpkCmSdpIpFQDN(&param->u.fqdn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV4_IP_ANY :
             break;
          case  CM_SDP_IPV4_IP_MULTI :
             CMCHKUNPK(cmUnpkCmSdpIp4Multicast, &param->u.multiIp,mBuf);
             break;
          case  CM_SDP_IPV4_IP_UNI :
             CMCHKUNPK(cmUnpkCmSdpIp4Unicast, &param->u.uniIp,mBuf);
             break;
          case  CM_SDP_NIL :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp4Conn*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpIp6MultiCast
*
*    Desc:    unpack the structure CmSdpIp6MultiCast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp6MultiCast
(
CmSdpIp6MultiCast *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp6MultiCast(param ,ptr, mBuf)
CmSdpIp6MultiCast *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpIp6MultiCast)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->hexPart, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpIp4Multicast, &param->ip4Multi,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->ttl,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->numAddr,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp6MultiCast*/
#endif

/*
*
*    Fun:    cmUnpkCmSdpIp6Addr
*
*    Desc:    unpack the structure CmSdpIp6Addr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpIp6Addr
(
CmSdpIp6Addr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpIp6Addr(param ,ptr, mBuf)
CmSdpIp6Addr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpIp6Addr)

    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_IPV6_FQDN :
             ret1 = cmUnpkCmSdpIpFQDN(&param->u.fqdn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_IPV6_IP :
             ret1 = cmUnpkCmSdpIp6(&param->u.ip, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_IPV6_MULTI :
             ret1 = cmUnpkCmSdpIp6MultiCast(&param->u.ipMulti, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpIp6Addr*/

/*
*
*    Fun:    cmUnpkCmSdpLclAddr
*
*    Desc:    unpack the structure CmSdpLclAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpLclAddr
(
CmSdpLclAddr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpLclAddr(param ,ptr, mBuf)
CmSdpLclAddr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpLclAddr)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->domName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->lclName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpLclAddr*/

/*
*
*    Fun:    cmUnpkCmSdpTnExtn
*
*    Desc:    unpack the structure CmSdpTnExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTnExtn
(
CmSdpTnExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTnExtn(param ,ptr, mBuf)
CmSdpTnExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpTnExtn)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->format, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->phone, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTnExtn*/

/*
*
*    Fun:    cmUnpkCmSdpAddr
*
*    Desc:    unpack the structure CmSdpAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAddr
(
CmSdpAddr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAddr(param ,ptr, mBuf)
CmSdpAddr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAddr)

    CMCHKUNPK(cmUnpkTknU8, &param->netType,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.e164, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmUnpkCmSdpIp4Addr(&param->u.ip4, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmUnpkCmSdpIp6Addr(&param->u.ip6, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.nsap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.sip, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmUnpkCmSdpTnExtn(&param->u.extn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAddr*/

/*
*
*    Fun:    cmUnpkCmSdpConn
*
*    Desc:    unpack the structure CmSdpConn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpConn
(
CmSdpConn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpConn(param ,ptr, mBuf)
CmSdpConn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpConn)

    CMCHKUNPK(cmUnpkTknU8, &param->netType,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.e164, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmUnpkCmSdpIp4Conn(&param->u.ip4, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmUnpkCmSdpIp6Addr(&param->u.ip6, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_LCL :
             ret1 = cmUnpkCmSdpLclAddr(&param->u.lcl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.nsap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.sip, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmUnpkCmSdpTnExtn(&param->u.extn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpConn*/

/*
*
*    Fun:    cmUnpkCmSdpAnycastAddr
*
*    Desc:    unpack the structure CmSdpAnycastAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAnycastAddr
(
CmSdpAnycastAddr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAnycastAddr(param ,ptr, mBuf)
CmSdpAnycastAddr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAnycastAddr)

    CMCHKUNPK(cmUnpkTknU8, &param->addrType,mBuf);
    if( param->addrType.pres != NOTPRSNT )
    {
       switch( param->addrType.val )
       {
          case  CM_SDP_ADDR_TYPE_ALIAS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_ALIAS_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_CHOOSE_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_E164 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.e164, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_E164_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_E164_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_GWID :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.gwid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_GWID_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_GWID_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_IPV4 :
             ret1 = cmUnpkCmSdpIp4Addr(&param->u.ip4, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_IPV6 :
             ret1 = cmUnpkCmSdpIp6Addr(&param->u.ip6, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NIL_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NIL_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.nsap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_CHOOSE :
             break;
          case  CM_SDP_ADDR_TYPE_NSAP_NIL :
             break;
          case  CM_SDP_ADDR_TYPE_RFC2543 :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.sip, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ADDR_TYPE_XTOKEN :
             ret1 = cmUnpkCmSdpTnExtn(&param->u.extn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAnycastAddr*/

/*
*
*    Fun:    cmUnpkCmSdpOrig
*
*    Desc:    unpack the structure CmSdpOrig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpOrig
(
CmSdpOrig *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpOrig(param ,ptr, mBuf)
CmSdpOrig *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpOrig)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->usrName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->sessId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->sessVer, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpAddr(&param->sdpAddr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpOrig*/

/*
*
*    Fun:    cmUnpkCmSdpOptOrig
*
*    Desc:    unpack the structure CmSdpOptOrig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpOptOrig
(
CmSdpOptOrig *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpOptOrig(param ,ptr, mBuf)
CmSdpOptOrig *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpOptOrig)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT && param->type.val == CM_SDP_SPEC )
       {
          ret1 = cmUnpkCmSdpOrig(&param->orig, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpOptOrig*/

/*
*
*    Fun:    cmUnpkCmSdpConnSet
*
*    Desc:    unpack the structure CmSdpConnSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpConnSet
(
CmSdpConnSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpConnSet(param ,ptr, mBuf)
CmSdpConnSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpConnSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->connSet));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpConn), (Ptr*)&(param->connSet[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpConn,  (param->connSet[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpConnSet*/

/*
*
*    Fun:    cmUnpkCmSdpTypedTime
*
*    Desc:    unpack the structure cmSdpTypedTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTypedTime
(
CmSdpTypedTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTypedTime(param ,mBuf)
CmSdpTypedTime *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpTypedTime)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr32, &param->val,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->unit,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTypedTime*/

/*
*
*    Fun:    cmUnpkCmSdpZoneAdj
*
*    Desc:    unpack the structure cmSdpZoneAdj
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpZoneAdj
(
CmSdpZoneAdj *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpZoneAdj(param ,mBuf)
CmSdpZoneAdj *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpZoneAdj)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr32, &param->time,mBuf);
       CMCHKUNPK(cmUnpkCmSdpTypedTime, &param->typedTime,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpZoneAdj*/

/*
*
*    Fun:    cmUnpkCmSdpTypedTimeSet
*
*    Desc:    unpack the structure CmSdpTypedTimeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTypedTimeSet
(
CmSdpTypedTimeSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTypedTimeSet(param ,ptr, mBuf)
CmSdpTypedTimeSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpTypedTimeSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->typedTime));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpTypedTime), (Ptr*)&(param->typedTime[i]));
          CMCHKUNPK(cmUnpkCmSdpTypedTime,  (param->typedTime[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTypedTimeSet*/

/*
*
*    Fun:    cmUnpkCmSdpRepField
*
*    Desc:    unpack the structure CmSdpRepField
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpRepField
(
CmSdpRepField *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpRepField(param ,ptr, mBuf)
CmSdpRepField *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpRepField)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpTypedTime, &param->repInterval,mBuf);
       CMCHKUNPK(cmUnpkCmSdpTypedTime, &param->actvDur,mBuf);
       ret1 = cmUnpkCmSdpTypedTimeSet(&param->offsetList, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpRepField*/

/*
*
*    Fun:    cmUnpkCmSdpRepFieldSet
*
*    Desc:    unpack the structure CmSdpRepFieldSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpRepFieldSet
(
CmSdpRepFieldSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpRepFieldSet(param ,ptr, mBuf)
CmSdpRepFieldSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpRepFieldSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->repField));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpRepField), (Ptr*)&(param->repField[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpRepField,  (param->repField[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpRepFieldSet*/

/*
*
*    Fun:    cmUnpkCmSdpZoneAdjSet
*
*    Desc:    unpack the structure CmSdpZoneAdjSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpZoneAdjSet
(
CmSdpZoneAdjSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpZoneAdjSet(param ,ptr, mBuf)
CmSdpZoneAdjSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpZoneAdjSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->zoneAdj));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpZoneAdj), (Ptr*)&(param->zoneAdj[i]));
          CMCHKUNPK(cmUnpkCmSdpZoneAdj,  (param->zoneAdj[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpZoneAdjSet*/

/*
*
*    Fun:    cmUnpkCmSdpOpTime
*
*    Desc:    unpack the structure CmSdpOpTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpOpTime
(
CmSdpOpTime *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpOpTime(param ,ptr, mBuf)
CmSdpOpTime *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpOpTime)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr32, &param->startTime,mBuf);
       CMCHKUNPK(cmUnpkTknStr32, &param->stopTime,mBuf);
       ret1 = cmUnpkCmSdpRepFieldSet(&param->repFieldSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpOpTime*/

/*
*
*    Fun:    cmUnpkCmSdpOpTimeSet
*
*    Desc:    unpack the structure CmSdpOpTimeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpOpTimeSet
(
CmSdpOpTimeSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpOpTimeSet(param ,ptr, mBuf)
CmSdpOpTimeSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpOpTimeSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->sdpOpTime));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpOpTime), (Ptr*)&(param->sdpOpTime[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpOpTime,  (param->sdpOpTime[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpOpTimeSet*/

/*
*
*    Fun:    cmUnpkCmSdpTime
*
*    Desc:    unpack the structure CmSdpTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTime
(
CmSdpTime *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTime(param ,ptr, mBuf)
CmSdpTime *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpTime)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpOpTimeSet(&param->sdpOpTimeSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpZoneAdjSet(&param->zoneAdjSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTime*/

/*
*
*    Fun:    cmUnpkCmSdpKeyType
*
*    Desc:    unpack the structure CmSdpKeyType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpKeyType
(
CmSdpKeyType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpKeyType(param ,ptr, mBuf)
CmSdpKeyType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpKeyType)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->keyType,mBuf);
       if( param->keyType.pres != NOTPRSNT 
         && param->keyType.val != CM_SDP_KEY_TYPE_PROMPT )
         
       {
          ret1 = cmUnpkMacroTknStrOSXL(&param->key_data, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpKeyType*/

/*
*
*    Fun:    cmUnpkCmSdpAttrType
*
*    Desc:    unpack the structure CmSdpAttrType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrType
(
CmSdpAttrType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrType(param ,ptr, mBuf)
CmSdpAttrType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrType)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrType*/

/*
*
*    Fun:    cmUnpkCmSdpU8OrNil
*
*    Desc:    unpack the structure cmSdpU8OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpU8OrNil
(
CmSdpU8OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpU8OrNil(param ,mBuf)
CmSdpU8OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpU8OrNil)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpU8OrNil*/

/*
*
*    Fun:    cmUnpkCmSdpU16OrNil
*
*    Desc:    unpack the structure cmSdpU16OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpU16OrNil
(
CmSdpU16OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpU16OrNil(param ,mBuf)
CmSdpU16OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpU16OrNil)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU16, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpU16OrNil*/

/*
*
*    Fun:    cmUnpkCmSdpU32OrNil
*
*    Desc:    unpack the structure cmSdpU32OrNil
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpU32OrNil
(
CmSdpU32OrNil *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpU32OrNil(param ,mBuf)
CmSdpU32OrNil *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpU32OrNil)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpU32OrNil*/

/*
*
*    Fun:    cmUnpkCmSdpEncName
*
*    Desc:    unpack the structure CmSdpEncName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpEncName
(
CmSdpEncName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpEncName(param ,ptr, mBuf)
CmSdpEncName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpEncName)

    CMCHKUNPK(cmUnpkTknU8, &param->val,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpEncName*/

/*
*
*    Fun:    cmUnpkCmSdpAttrRtpMap
*
*    Desc:    unpack the structure CmSdpAttrRtpMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrRtpMap
(
CmSdpAttrRtpMap *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrRtpMap(param ,ptr, mBuf)
CmSdpAttrRtpMap *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrRtpMap)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->pay,mBuf);
       ret1 = cmUnpkCmSdpEncName(&param->enc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU32, &param->clk,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->parms, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrRtpMap*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAtmMap
*
*    Desc:    unpack the structure CmSdpAttrAtmMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAtmMap
(
CmSdpAttrAtmMap *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAtmMap(param ,ptr, mBuf)
CmSdpAttrAtmMap *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrAtmMap)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->pay,mBuf);
       ret1 = cmUnpkCmSdpEncName(&param->enc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAtmMap*/

/*
*
*    Fun:    cmUnpkCmSdpAttrSilSupp
*
*    Desc:    unpack the structure cmSdpAttrSilSupp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrSilSupp
(
CmSdpAttrSilSupp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrSilSupp(param ,mBuf)
CmSdpAttrSilSupp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrSilSupp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->enb,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->timer,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->pref,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->sid,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->fxns,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrSilSupp*/

/*
*
*    Fun:    cmUnpkCmSdpAttrEchoCan
*
*    Desc:    unpack the structure cmSdpAttrEchoCan
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrEchoCan
(
CmSdpAttrEchoCan *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrEchoCan(param ,mBuf)
CmSdpAttrEchoCan *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrEchoCan)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->enb,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrEchoCan*/

/*
*
*    Fun:    cmUnpkCmSdpAttrGainCtl
*
*    Desc:    unpack the structure cmSdpAttrGainCtl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrGainCtl
(
CmSdpAttrGainCtl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrGainCtl(param ,mBuf)
CmSdpAttrGainCtl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrGainCtl)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->enb,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->lvl,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrGainCtl*/

/*
*
*    Fun:    cmUnpkCmSdpAttrDirection
*
*    Desc:    unpack the structure cmSdpAttrDirection
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrDirection
(
CmSdpAttrDirection *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrDirection(param ,mBuf)
CmSdpAttrDirection *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrDirection)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrDirection*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAtmAbrSetup
*
*    Desc:    unpack the structure cmSdpAttrAtmAbrSetup
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAtmAbrSetup
(
CmSdpAttrAtmAbrSetup *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAtmAbrSetup(param ,mBuf)
CmSdpAttrAtmAbrSetup *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAtmAbrSetup)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->ficr,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->bicr,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->ftbe,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->btbe,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->crmrtt,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->frif,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->brif,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->frdf,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->brdf,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAtmAbrSetup*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal2CpsSduRate
*
*    Desc:    unpack the structure cmSdpAttrAal2CpsSduRate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal2CpsSduRate
(
CmSdpAttrAal2CpsSduRate *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal2CpsSduRate(param ,mBuf)
CmSdpAttrAal2CpsSduRate *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal2CpsSduRate)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->fSduRate,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->bSduRate,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal2CpsSduRate*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal5Sscop
*
*    Desc:    unpack the structure cmSdpAttrAal5Sscop
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal5Sscop
(
CmSdpAttrAal5Sscop *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal5Sscop(param ,mBuf)
CmSdpAttrAal5Sscop *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal5Sscop)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->fsscopSdu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->bsscopSdu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->fsscopUu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->bsscopUu,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal5Sscop*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAtmBrrSigIe
*
*    Desc:    unpack the structure CmSdpAttrAtmBrrSigIe
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAtmBrrSigIe
(
CmSdpAttrAtmBrrSigIe *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAtmBrrSigIe(param ,ptr, mBuf)
CmSdpAttrAtmBrrSigIe *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrAtmBrrSigIe)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->type, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->lng,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->val, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAtmBrrSigIe*/

/*
*
*    Fun:    cmUnpkCmSdpUuiCodeRng
*
*    Desc:    unpack the structure cmSdpUuiCodeRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpUuiCodeRng
(
CmSdpUuiCodeRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpUuiCodeRng(param ,mBuf)
CmSdpUuiCodeRng *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpUuiCodeRng)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->low,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->high,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpUuiCodeRng*/

/*
*
*    Fun:    cmUnpkCmSdpProfComp
*
*    Desc:    unpack the structure CmSdpProfComp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpProfComp
(
CmSdpProfComp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpProfComp(param ,ptr, mBuf)
CmSdpProfComp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpProfComp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpUuiCodeRng, &param->uui,mBuf);
       ret1 = cmUnpkCmSdpEncName(&param->enc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->len,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->pktz,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpProfComp*/

/*
*
*    Fun:    cmUnpkCmSdpProfCompSet
*
*    Desc:    unpack the structure CmSdpProfCompSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpProfCompSet
(
CmSdpProfCompSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpProfCompSet(param ,ptr, mBuf)
CmSdpProfCompSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpProfCompSet)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->comps));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpProfComp), (Ptr*)&(param->comps[i]));
          ret1 = cmUnpkCmSdpProfComp( (param->comps[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpProfCompSet*/

/*
*
*    Fun:    cmUnpkCmSdpMedProtoSubtype
*
*    Desc:    unpack the structure CmSdpMedProtoSubtype
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedProtoSubtype
(
CmSdpMedProtoSubtype *param,
U8 protType,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedProtoSubtype(param ,protType, ptr, mBuf)
CmSdpMedProtoSubtype *param;
U8 protType;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpMedProtoSubtype)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( protType )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmUnpkMacroTknStrOSXL(&param->u.unknownOrCorporate, ptr ,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKUNPK(cmUnpkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmUnpkMacroTknStrOSXL(&param->u.unknownOrCorporate, ptr ,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKUNPK(cmUnpkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_AALX_ATMF :
                   break;
                case  CM_SDP_PROTO_AALX_CORPORATE :
                   ret1 = cmUnpkMacroTknStrOSXL(&param->u.unknownOrCorporate, ptr ,mBuf);
                   if (ret1 != ROK)
                   {
                      RETVALUE(RFAILED);
                   }
                   break;
                case  CM_SDP_PROTO_AALX_CUSTOM :
                   break;
                case  CM_SDP_PROTO_AALX_IEEE :
                   CMCHKUNPK(cmUnpkTknU32, &param->u.ieee,mBuf);
                   break;
                case  CM_SDP_PROTO_AALX_ITU :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             switch( param->type.val )
             {
                case  CM_SDP_PROTO_RTP_AVP :
                   break;
                case  CM_SDP_PROTO_RTP_AVP_TCP :
                   break;
                default:
                   RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedProtoSubtype*/

/*
*
*    Fun:    cmUnpkCmSdpMedProto
*
*    Desc:    unpack the structure CmSdpMedProto
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedProto
(
CmSdpMedProto *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedProto(param ,ptr, mBuf)
CmSdpMedProto *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpMedProto)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             ret1 = cmUnpkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val , ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             ret1 = cmUnpkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val , ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             ret1 = cmUnpkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val , ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_H323C :
             break;
          case  CM_SDP_MEDIA_PROTO_LCL :
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             ret1 = cmUnpkCmSdpMedProtoSubtype(&param->u.subtype, param->type.val , ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_SAP :
             break;
          case  CM_SDP_MEDIA_PROTO_TCP :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_FAX :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_PAGER :
             break;
          case  CM_SDP_MEDIA_PROTO_TN_VOICE :
             break;
          case  CM_SDP_MEDIA_PROTO_UDP :
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_MEDIA_PROTO_UDPTL :
             break;
#endif /* CM_SDP_V_3 */
#ifdef CM_SDP_SIP_IM_SUPPORT
          case CM_SDP_MEDIA_PROTO_SIP:             
             break;
#endif /* CM_SDP_SIP_IM_SUPPORT */
          case  CM_SDP_MEDIA_PROTO_UNKNOWN :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.name, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedProto*/

/*
*
*    Fun:    cmUnpkCmSdpAttrProfDesc
*
*    Desc:    unpack the structure CmSdpAttrProfDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrProfDesc
(
CmSdpAttrProfDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrProfDesc(param ,ptr, mBuf)
CmSdpAttrProfDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrProfDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpMedProto(&param->transport, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->prof,mBuf);
       ret1 = cmUnpkCmSdpProfCompSet(&param->comps, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrProfDesc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrDevSelComp
*
*    Desc:    unpack the structure CmSdpAttrDevSelComp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrDevSelComp
(
CmSdpAttrDevSelComp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrDevSelComp(param ,ptr, mBuf)
CmSdpAttrDevSelComp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrDevSelComp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpEncName(&param->enc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->len,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->pktz,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrDevSelComp*/

/*
*
*    Fun:    cmUnpkCmSdpAttrDevSel
*
*    Desc:    unpack the structure CmSdpAttrDevSel
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrDevSel
(
CmSdpAttrDevSel *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrDevSel(param ,ptr, mBuf)
CmSdpAttrDevSel *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpAttrDevSel)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->fxIncl,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
       if( param->numComp.pres != NOTPRSNT )
       {
          CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->comps));
          for (i=0;i<param->numComp.val;i++)
          {
             CMGETMBLK(ptr, sizeof(CmSdpAttrDevSelComp), (Ptr*)&(param->comps[i]));
             ret1 = cmUnpkCmSdpAttrDevSelComp( (param->comps[i]), ptr ,mBuf);
             if(ret1 != ROK)
             {
                SPutMsg(mBuf);
                RETVALUE( ret1 );
             }
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrDevSel*/

/*
*
*    Fun:    cmUnpkCmSdpAttrOneWaySel
*
*    Desc:    unpack the structure CmSdpAttrOneWaySel
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrOneWaySel
(
CmSdpAttrOneWaySel *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrOneWaySel(param ,ptr, mBuf)
CmSdpAttrOneWaySel *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpAttrOneWaySel)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->srvTyp,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->dirFlg,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
       if( param->numComp.pres != NOTPRSNT )
       {
          CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->comps));
          for (i=0;i<param->numComp.val;i++)
          {
             CMGETMBLK(ptr, sizeof(CmSdpAttrDevSelComp), (Ptr*)&(param->comps[i]));
             ret1 = cmUnpkCmSdpAttrDevSelComp( (param->comps[i]), ptr ,mBuf);
             if(ret1 != ROK)
             {
                SPutMsg(mBuf);
                RETVALUE( ret1 );
             }
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrOneWaySel*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal23661Ass
*
*    Desc:    unpack the structure cmSdpAttrAal23661Ass
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal23661Ass
(
CmSdpAttrAal23661Ass *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal23661Ass(param ,mBuf)
CmSdpAttrAal23661Ass *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal23661Ass)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->rasTimer,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->fsssar,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->bsssar,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->fsscopSdu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->bsscopSdu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->fsscopUu,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->bsscopUu,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal23661Ass*/

/*
*
*    Fun:    cmUnpkCmSdpAttrCapab
*
*    Desc:    unpack the structure CmSdpAttrCapab
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrCapab
(
CmSdpAttrCapab *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrCapab(param ,ptr, mBuf)
CmSdpAttrCapab *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrCapab)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT 
         && param->type.val == CM_SDP_CAPAB_NONSTD )
       {
          ret1 = cmUnpkMacroTknStrOSXL(&param->nonstd, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cfg,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrCapab*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAtmBcob
*
*    Desc:    unpack the structure cmSdpAttrAtmBcob
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAtmBcob
(
CmSdpAttrAtmBcob *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAtmBcob(param ,mBuf)
CmSdpAttrAtmBcob *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAtmBcob)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->bcob,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->eetim,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAtmBcob*/

/*
*
*    Fun:    cmUnpkCmSdpAttrQosParms
*
*    Desc:    unpack the structure cmSdpAttrQosParms
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrQosParms
(
CmSdpAttrQosParms *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrQosParms(param ,mBuf)
CmSdpAttrQosParms *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrQosParms)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->cdvtype,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->acdv,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->ccdv,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->actd,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->cctd,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->aclr,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrQosParms*/

/*
*
*    Fun:    cmUnpkCmSdpAttrTfcDesc
*
*    Desc:    unpack the structure cmSdpAttrTfcDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrTfcDesc
(
CmSdpAttrTfcDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrTfcDesc(param ,mBuf)
CmSdpAttrTfcDesc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrTfcDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->clp,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->pcr,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->scr,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->mbs,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->cdvt,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->mcr,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->mfs,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->fd,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->te,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrTfcDesc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAbrParms
*
*    Desc:    unpack the structure cmSdpAttrAbrParms
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAbrParms
(
CmSdpAttrAbrParms *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAbrParms(param ,mBuf)
CmSdpAttrAbrParms *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAbrParms)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->nrm,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->trm,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cdf,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->adtf,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAbrParms*/

/*
*
*    Fun:    cmUnpkCmSdpAttrBearType
*
*    Desc:    unpack the structure cmSdpAttrBearType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrBearType
(
CmSdpAttrBearType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrBearType(param ,mBuf)
CmSdpAttrBearType *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrBearType)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->init,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrBearType*/

/*
*
*    Fun:    cmUnpkCmSdpAttrStruc
*
*    Desc:    unpack the structure cmSdpAttrStruc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrStruc
(
CmSdpAttrStruc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrStruc(param ,mBuf)
CmSdpAttrStruc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrStruc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->enb,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->blksz,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrStruc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrCpsSduSize
*
*    Desc:    unpack the structure cmSdpAttrCpsSduSize
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrCpsSduSize
(
CmSdpAttrCpsSduSize *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrCpsSduSize(param ,mBuf)
CmSdpAttrCpsSduSize *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrCpsSduSize)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->cpcs,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrCpsSduSize*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal2Cps
*
*    Desc:    unpack the structure cmSdpAttrAal2Cps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal2Cps
(
CmSdpAttrAal2Cps *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal2Cps(param ,mBuf)
CmSdpAttrAal2Cps *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal2Cps)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->minCid,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->maxCid,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->timerCU,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->simCPS,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal2Cps*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal23661
*
*    Desc:    unpack the structure cmSdpAttrAal23661
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal23661
(
CmSdpAttrAal23661 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal23661(param ,mBuf)
CmSdpAttrAal23661 *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal23661)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->ted,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->rasTimer,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->fsssar,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->bsssar,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal23661*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAal23662
*
*    Desc:    unpack the structure cmSdpAttrAal23662
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAal23662
(
CmSdpAttrAal23662 *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAal23662(param ,mBuf)
CmSdpAttrAal23662 *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrAal23662)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->sap,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->cktmd,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->frmmd,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->faxdm,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->cas,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->dtmf,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->mfall,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->mfr1,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->mfr2,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->enc,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->fmaxfrm,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->bmaxfrm,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAal23662*/

/*
*
*    Fun:    cmUnpkCmSdpAttrLij
*
*    Desc:    unpack the structure cmSdpAttrLij
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrLij
(
CmSdpAttrLij *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrLij(param ,mBuf)
CmSdpAttrLij *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrLij)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->sci,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->lsn,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrLij*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAnycast
*
*    Desc:    unpack the structure CmSdpAttrAnycast
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAnycast
(
CmSdpAttrAnycast *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAnycast(param ,ptr, mBuf)
CmSdpAttrAnycast *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrAnycast)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpAnycastAddr(&param->grpAddr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cdstd,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->csttype,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cssel,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAnycast*/

/*
*
*    Fun:    cmUnpkCmSdpAttrGeneric
*
*    Desc:    unpack the structure CmSdpAttrGeneric
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrGeneric
(
CmSdpAttrGeneric *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrGeneric(param ,ptr, mBuf)
CmSdpAttrGeneric *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrGeneric)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->val, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrGeneric*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp2848Res
*
*    Desc:    unpack the structure CmSdpAttrFmtp2848Res
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848Res
(
CmSdpAttrFmtp2848Res *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848Res(param ,ptr, mBuf)
CmSdpAttrFmtp2848Res *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFmtp2848Res)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->ref, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp2848Res*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp2848ResSet
*
*    Desc:    unpack the structure CmSdpAttrFmtp2848ResSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848ResSet
(
CmSdpAttrFmtp2848ResSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848ResSet(param ,ptr, mBuf)
CmSdpAttrFmtp2848ResSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpAttrFmtp2848ResSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numRes,mBuf);
    if( param->numRes.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numRes.val), (Ptr*)&(param->resSet));
       for (i=0;i<param->numRes.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpAttrFmtp2848Res), (Ptr*)&(param->resSet[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpAttrFmtp2848Res,  (param->resSet[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp2848ResSet*/

/*
*
*    Fun:    cmUnpkCmSdpOptAttrSet
*
*    Desc:    unpack the structure CmSdpOptAttrSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpOptAttrSet
(
CmSdpOptAttrSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpOptAttrSet(param ,ptr, intfVer, mBuf)
CmSdpOptAttrSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpOptAttrSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numAttr,mBuf);
    if( param->numAttr.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numAttr.val), (Ptr*)&(param->attrSet));
       for (i=0;i<param->numAttr.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpAttr), (Ptr*)&(param->attrSet[i]));
          ret1 = cmUnpkCmSdpAttr( (param->attrSet[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpOptAttrSet*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp2848
*
*    Desc:    unpack the structure CmSdpAttrFmtp2848
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848
(
CmSdpAttrFmtp2848 *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp2848(param ,ptr, intfVer, mBuf)
CmSdpAttrFmtp2848 *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFmtp2848)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->subType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpAttrFmtp2848ResSet(&param->resSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpOptAttrSet(&param->attrSet, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp2848*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp2733
*
*    Desc:    unpack the structure CmSdpAttrFmtp2733
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp2733
(
CmSdpAttrFmtp2733 *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp2733(param ,ptr, mBuf)
CmSdpAttrFmtp2733 *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFmtp2733)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->pay,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
       ret1 = cmUnpkCmSdpAddr(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp2733*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp2833
*
*    Desc:    unpack the structure CmSdpAttrFmtp2833
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp2833
(
CmSdpAttrFmtp2833 *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp2833(param ,ptr, mBuf)
CmSdpAttrFmtp2833 *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFmtp2833)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->pay,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->str, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp2833*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtpChnOrdSeq
*
*    Desc:    unpack the structure cmSdpAttrFmtpChnOrdSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtpChnOrdSeq
(
CmSdpAttrFmtpChnOrdSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtpChnOrdSeq(param ,mBuf)
CmSdpAttrFmtpChnOrdSeq *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrFmtpChnOrdSeq)

    CMCHKUNPK(cmUnpkTknU8, &param->convention,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->order,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtpChnOrdSeq*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtpEmChnChc
*
*    Desc:    unpack the structure cmSdpAttrFmtpEmChnChc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtpEmChnChc
(
CmSdpAttrFmtpEmChnChc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtpEmChnChc(param ,mBuf)
CmSdpAttrFmtpEmChnChc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrFmtpEmChnChc)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_FMTP_CHANEL_ORDER :
             CMCHKUNPK(cmUnpkCmSdpAttrFmtpChnOrdSeq, &param->u.chnOrd,mBuf);
             break;
          case  CM_SDP_ATTR_FMTP_EMPHASIS :
             CMCHKUNPK(cmUnpkTknU8, &param->u.emphTyp,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtpEmChnChc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtpEmpChnOrd
*
*    Desc:    unpack the structure cmSdpAttrFmtpEmpChnOrd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtpEmpChnOrd
(
CmSdpAttrFmtpEmpChnOrd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtpEmpChnOrd(param ,mBuf)
CmSdpAttrFmtpEmpChnOrd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrFmtpEmpChnOrd)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->payLoad,mBuf);
       CMCHKUNPK(cmUnpkCmSdpAttrFmtpEmChnChc, &param->val,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtpEmpChnOrd*/
#endif

/*
*
*    Fun:    cmUnpkCmSdpAttrFmtp
*
*    Desc:    unpack the structure CmSdpAttrFmtp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFmtp
(
CmSdpAttrFmtp *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFmtp(param ,ptr, intfVer, mBuf)
CmSdpAttrFmtp *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFmtp)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_FMTP_EMP_ORD :
             CMCHKUNPK(cmUnpkCmSdpAttrFmtpEmpChnOrd, &param->u.empChnOrd,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_FMTP_RFC2733 :
             ret1 = cmUnpkCmSdpAttrFmtp2733(&param->u.rfc2733, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_RFC2833 :
             ret1 = cmUnpkCmSdpAttrFmtp2833(&param->u.rfc2833, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_RFC2848 :
             ret1 = cmUnpkCmSdpAttrFmtp2848(&param->u.rfc2848, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FMTP_UNSPEC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.other, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFmtp*/

/*
*
*    Fun:    cmUnpkCmSdpSmpte
*
*    Desc:    unpack the structure cmSdpSmpte
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpSmpte
(
CmSdpSmpte *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpSmpte(param ,mBuf)
CmSdpSmpte *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpSmpte)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->hr,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->min,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->sec,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->centisec,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->frac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpSmpte*/

/*
*
*    Fun:    cmUnpkCmSdpTimeSmpte
*
*    Desc:    unpack the structure cmSdpTimeSmpte
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTimeSmpte
(
CmSdpTimeSmpte *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTimeSmpte(param ,mBuf)
CmSdpTimeSmpte *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpTimeSmpte)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpSmpte, &param->start,mBuf);
       CMCHKUNPK(cmUnpkCmSdpSmpte, &param->end,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTimeSmpte*/

/*
*
*    Fun:    cmUnpkCmSdpNptSec
*
*    Desc:    unpack the structure cmSdpNptSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpNptSec
(
CmSdpNptSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpNptSec(param ,mBuf)
CmSdpNptSec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpNptSec)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->sec,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->frac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpNptSec*/

/*
*
*    Fun:    cmUnpkCmSdpNptHMS
*
*    Desc:    unpack the structure cmSdpNptHMS
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpNptHMS
(
CmSdpNptHMS *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpNptHMS(param ,mBuf)
CmSdpNptHMS *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpNptHMS)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->hr,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->min,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->sec,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->frac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpNptHMS*/

/*
*
*    Fun:    cmUnpkCmSdpNpt
*
*    Desc:    unpack the structure cmSdpNpt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpNpt
(
CmSdpNpt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpNpt(param ,mBuf)
CmSdpNpt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpNpt)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_NPT_HMS :
             CMCHKUNPK(cmUnpkCmSdpNptHMS, &param->u.hms,mBuf);
             break;
          case  CM_SDP_NPT_SEC :
             CMCHKUNPK(cmUnpkCmSdpNptSec, &param->u.sec,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpNpt*/

/*
*
*    Fun:    cmUnpkCmSdpTimeNpt
*
*    Desc:    unpack the structure cmSdpTimeNpt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTimeNpt
(
CmSdpTimeNpt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTimeNpt(param ,mBuf)
CmSdpTimeNpt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpTimeNpt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpNpt, &param->start,mBuf);
       CMCHKUNPK(cmUnpkCmSdpNpt, &param->end,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTimeNpt*/

/*
*
*    Fun:    cmUnpkCmSdpUtc
*
*    Desc:    unpack the structure cmSdpUtc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpUtc
(
CmSdpUtc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpUtc(param ,mBuf)
CmSdpUtc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpUtc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->date,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->hms,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->frac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpUtc*/

/*
*
*    Fun:    cmUnpkCmSdpTimeUtc
*
*    Desc:    unpack the structure cmSdpTimeUtc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpTimeUtc
(
CmSdpTimeUtc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpTimeUtc(param ,mBuf)
CmSdpTimeUtc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpTimeUtc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpUtc, &param->start,mBuf);
       CMCHKUNPK(cmUnpkCmSdpUtc, &param->end,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpTimeUtc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrRange
*
*    Desc:    unpack the structure cmSdpAttrRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrRange
(
CmSdpAttrRange *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrRange(param ,mBuf)
CmSdpAttrRange *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrRange)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_RANGE_NPT :
             CMCHKUNPK(cmUnpkCmSdpTimeNpt, &param->u.npt,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE :
             CMCHKUNPK(cmUnpkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE_25 :
             CMCHKUNPK(cmUnpkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_SMPTE_30_DROP :
             CMCHKUNPK(cmUnpkCmSdpTimeSmpte, &param->u.smpte,mBuf);
             break;
          case  CM_SDP_RANGE_UTC :
             CMCHKUNPK(cmUnpkCmSdpTimeUtc, &param->u.utc,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrRange*/

/*
*
*    Fun:    cmUnpkCmSdpAttrWtp
*
*    Desc:    unpack the structure CmSdpAttrWtp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrWtp
(
CmSdpAttrWtp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrWtp(param ,ptr, mBuf)
CmSdpAttrWtp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrWtp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->iapSystemId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->cccId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrWtp*/

/*
*
*    Fun:    cmUnpkCmSdpAttrCache
*
*    Desc:    unpack the structure cmSdpAttrCache
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrCache
(
CmSdpAttrCache *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrCache(param ,mBuf)
CmSdpAttrCache *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrCache)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->enable,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->timer,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrCache*/

/*
*
*    Fun:    cmUnpkCmSdpAttrPhCxtId
*
*    Desc:    unpack the structure CmSdpAttrPhCxtId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrPhCxtId
(
CmSdpAttrPhCxtId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrPhCxtId(param ,ptr, mBuf)
CmSdpAttrPhCxtId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrPhCxtId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->number, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMacroTknStrOSXL(&param->uri, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrPhCxtId*/

/*
*
*    Fun:    cmUnpkCmSdpAttrRequire
*
*    Desc:    unpack the structure CmSdpAttrRequire
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrRequire
(
CmSdpAttrRequire *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrRequire(param ,ptr, mBuf)
CmSdpAttrRequire *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpAttrRequire)

    CMCHKUNPK(cmUnpkTknU16, &param->numAttr,mBuf);
    if( param->numAttr.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numAttr.val), (Ptr*)&(param->names));
       for (i=0;i<param->numAttr.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->names[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->names[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrRequire*/

/*
*
*    Fun:    cmUnpkCmSdpAttrAalApp
*
*    Desc:    unpack the structure CmSdpAttrAalApp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrAalApp
(
CmSdpAttrAalApp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrAalApp(param ,ptr, mBuf)
CmSdpAttrAalApp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrAalApp)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->nonstd, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrAalApp*/

/*
*
*    Fun:    cmUnpkCmSdpAttrIpBcp
*
*    Desc:    unpack the structure cmSdpAttrIpBcp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     abc.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrIpBcp
(
CmSdpAttrIpBcp *param,
Buffer *mBuf
)   
#else
PUBLIC S16 cmUnpkCmSdpAttrIpBcp(param ,mBuf)
CmSdpAttrIpBcp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrIpBcp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->version,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->msgType,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrIpBcp*/

#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpCnfmTg
*
*    Desc:    unpack the structure cmSdpCnfmTg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpCnfmTg
(
CmSdpCnfmTg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpCnfmTg(param ,mBuf)
CmSdpCnfmTg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpCnfmTg)

    CMCHKUNPK(cmUnpkTknU8, &param->dirTg,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpCnfmTg*/

/*
*
*    Fun:    cmUnpkCmSdpAttrQosSec
*
*    Desc:    unpack the structure cmSdpAttrQosSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrQosSec
(
CmSdpAttrQosSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrQosSec(param ,mBuf)
CmSdpAttrQosSec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrQosSec)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->strnTg,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->dirTg,mBuf);
       CMCHKUNPK(cmUnpkCmSdpCnfmTg, &param->cnfmTg,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrQosSec*/

/*
*
*    Fun:    cmUnpkCmSdpAttrFidMid
*
*    Desc:    unpack the structure CmSdpAttrFidMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrFidMid
(
CmSdpAttrFidMid *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrFidMid(param ,ptr, mBuf)
CmSdpAttrFidMid *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrFidMid)

    ret1 = cmUnpkMacroTknStrOSXL(&param->idTag, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrFidMid*/

/*
*
*    Fun:    cmUnpkCmSdpAttrIdSet
*
*    Desc:    unpack the structure CmSdpAttrIdSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrIdSet
(
CmSdpAttrIdSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrIdSet(param ,ptr, mBuf)
CmSdpAttrIdSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpAttrIdSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->idTags));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->idTags[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->idTags[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrIdSet*/

/*
*
*    Fun:    cmUnpkCmSdpAttrGroup
*
*    Desc:    unpack the structure CmSdpAttrGroup
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrGroup
(
CmSdpAttrGroup *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrGroup(param ,ptr, mBuf)
CmSdpAttrGroup *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttrGroup)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->semantics,mBuf);
       ret1 = cmUnpkCmSdpAttrIdSet(&param->ids, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrGroup*/
#endif

/*
*
*    Fun:    cmUnpkCmSdpEmailName
*
*    Desc:    unpack the structure CmSdpEmailName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpEmailName
(
CmSdpEmailName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpEmailName(param ,ptr, mBuf)
CmSdpEmailName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpEmailName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->email, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpEmailName*/

/*
*
*    Fun:    cmUnpkCmSdpNameEmail
*
*    Desc:    unpack the structure CmSdpNameEmail
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpNameEmail
(
CmSdpNameEmail *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpNameEmail(param ,ptr, mBuf)
CmSdpNameEmail *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpNameEmail)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->email, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpNameEmail*/

/*
*
*    Fun:    cmUnpkCmSdpEmail
*
*    Desc:    unpack the structure CmSdpEmail
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpEmail
(
CmSdpEmail *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpEmail(param ,ptr, mBuf)
CmSdpEmail *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpEmail)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_EMAIL_NAME :
             ret1 = cmUnpkCmSdpEmailName(&param->u.en, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_EMAIL_ONLY :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.email, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_NAME_EMAIL :
             ret1 = cmUnpkCmSdpNameEmail(&param->u.ne, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpEmail*/

/*
*
*    Fun:    cmUnpkCmSdpEmailSet
*
*    Desc:    unpack the structure CmSdpEmailSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpEmailSet
(
CmSdpEmailSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpEmailSet(param ,ptr, mBuf)
CmSdpEmailSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpEmailSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->email));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpEmail), (Ptr*)&(param->email[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpEmail,  (param->email[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpEmailSet*/

/*
*
*    Fun:    cmUnpkCmSdpPhoneName
*
*    Desc:    unpack the structure CmSdpPhoneName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPhoneName
(
CmSdpPhoneName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPhoneName(param ,ptr, mBuf)
CmSdpPhoneName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpPhoneName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->phone, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPhoneName*/

/*
*
*    Fun:    cmUnpkCmSdpNamePhone
*
*    Desc:    unpack the structure CmSdpNamePhone
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpNamePhone
(
CmSdpNamePhone *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpNamePhone(param ,ptr, mBuf)
CmSdpNamePhone *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpNamePhone)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->phone, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpNamePhone*/

/*
*
*    Fun:    cmUnpkCmSdpPhone
*
*    Desc:    unpack the structure CmSdpPhone
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPhone
(
CmSdpPhone *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPhone(param ,ptr, mBuf)
CmSdpPhone *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpPhone)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_NAME_PHONE :
             ret1 = cmUnpkCmSdpNamePhone(&param->u.np, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_PHONE_NAME :
             ret1 = cmUnpkCmSdpPhoneName(&param->u.pn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_PHONE_ONLY :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.phone, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPhone*/

/*
*
*    Fun:    cmUnpkCmSdpPhoneSet
*
*    Desc:    unpack the structure CmSdpPhoneSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPhoneSet
(
CmSdpPhoneSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPhoneSet(param ,ptr, mBuf)
CmSdpPhoneSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpPhoneSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->phone));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpPhone), (Ptr*)&(param->phone[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpPhone,  (param->phone[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPhoneSet*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpBwTyp
*
*    Desc:    unpack the structure CmSdpBwTyp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpBwTyp
(
CmSdpBwTyp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpBwTyp(param ,ptr, mBuf)
CmSdpBwTyp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpBwTyp)

    CMCHKUNPK(cmUnpkTknU8, &param->knownBw,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->unKnownBw, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpBwTyp*/

/*
*
*    Fun:    cmUnpkCmSdpT38Fmt
*
*    Desc:    unpack the structure CmSdpT38Fmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpT38Fmt
(
CmSdpT38Fmt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpT38Fmt(param ,ptr, mBuf)
CmSdpT38Fmt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpT38Fmt)

    CMCHKUNPK(cmUnpkTknU8, &param->knownFmt,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->unknownFmt, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpT38Fmt*/
#endif /* CM_SDP_V_3 */

/*
*
*    Fun:    cmUnpkCmSdpMedFmtUnknownList
*
*    Desc:    unpack the structure CmSdpMedFmtUnknownList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtUnknownList
(
CmSdpMedFmtUnknownList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtUnknownList(param ,ptr, mBuf)
CmSdpMedFmtUnknownList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtUnknownList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->fmts[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->fmts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtUnknownList*/

/*
*
*    Fun:    cmUnpkCmSdpMedFmtAalxList
*
*    Desc:    unpack the structure CmSdpMedFmtAalxList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtAalxList
(
CmSdpMedFmtAalxList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtAalxList(param ,ptr, mBuf)
CmSdpMedFmtAalxList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtAalxList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpU8OrNil), (Ptr*)&(param->fmts[i]));
          CMCHKUNPK(cmUnpkCmSdpU8OrNil,  (param->fmts[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtAalxList*/

/*
*
*    Fun:    cmUnpkCmSdpMedFmtRtpList
*
*    Desc:    unpack the structure CmSdpMedFmtRtpList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
/* 001.main_12: change to support a mix of "$" & integers in RTP list */
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtRtpList
(
CmSdpMedFmtRtpList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtRtpList(param ,ptr, mBuf)
CmSdpMedFmtRtpList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtRtpList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpU8OrNil), (Ptr*)&(param->fmts[i]));
          CMCHKUNPK(cmUnpkCmSdpU8OrNil, (param->fmts[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtRtpList*/

/*
*
*    Fun:    cmUnpkCmSdpMedFmtLclList
*
*    Desc:    unpack the structure CmSdpMedFmtLclList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtLclList
(
CmSdpMedFmtLclList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtLclList(param ,ptr, mBuf)
CmSdpMedFmtLclList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtLclList)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->fmts[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->fmts[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtLclList*/

/*
*
*    Fun:    cmUnpkCmSdpMedFmtTnList
*
*    Desc:    unpack the structure CmSdpMedFmtTnList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtTnList
(
CmSdpMedFmtTnList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtTnList(param ,ptr, mBuf)
CmSdpMedFmtTnList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtTnList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpMimeSubtype), (Ptr*)&(param->fmts[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpMimeSubtype,  (param->fmts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtTnList*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpMedFmtUdptlList
*
*    Desc:    unpack the structure CmSdpMedFmtUdptlList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtUdptlList
(
CmSdpMedFmtUdptlList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtUdptlList(param ,ptr, mBuf)
CmSdpMedFmtUdptlList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtUdptlList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpT38Fmt), (Ptr*)&(param->fmts[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpT38Fmt,  (param->fmts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedFmtUdptlList*/
#endif /* CM_SDP_V_3 */

/*
*
*    Fun:    cmUnpkCmSdpMedProtoFmts
*
*    Desc:    unpack the structure CmSdpMedProtoFmts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedProtoFmts
(
CmSdpMedProtoFmts *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedProtoFmts(param ,ptr, intfVer, mBuf)
CmSdpMedProtoFmts *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpMedProtoFmts)

    ret1 = cmUnpkCmSdpMedProto(&param->prot, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkTknU8, &param->protType,mBuf);
    if( param->protType.pres != NOTPRSNT )
    {
       switch( param->protType.val )
       {
          case  CM_SDP_MEDIA_PROTO_AAL1 :
             ret1 = cmUnpkCmSdpMedFmtAalxList(&param->u.aalx, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL2 :
             ret1 = cmUnpkCmSdpMedFmtAalxList(&param->u.aalx, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_AAL5 :
             ret1 = cmUnpkCmSdpMedFmtAalxList(&param->u.aalx, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_LCL :
             ret1 = cmUnpkCmSdpMedFmtLclList(&param->u.lcl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_RTP :
             ret1 = cmUnpkCmSdpMedFmtRtpList(&param->u.rtp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_SAP :
             break;
          case  CM_SDP_MEDIA_PROTO_TCP :
             ret1 = cmUnpkCmSdpMedFmtTnList(&param->u.tn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_FAX :
             ret1 = cmUnpkCmSdpMedFmtTnList(&param->u.tn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_PAGER :
             ret1 = cmUnpkCmSdpMedFmtTnList(&param->u.tn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_MEDIA_PROTO_TN_VOICE :
             ret1 = cmUnpkCmSdpMedFmtTnList(&param->u.tn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;

          case  CM_SDP_MEDIA_PROTO_UDP :
             ret1 = cmUnpkCmSdpMedFmtTnList(&param->u.tn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;

#ifdef CM_SDP_V_3
          case  CM_SDP_MEDIA_PROTO_UDPTL :
             ret1 = cmUnpkCmSdpMedFmtUdptlList(&param->u.t38, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /* CM_SDP_V_3 */
#ifdef CM_SDP_SIP_IM_SUPPORT
          case  CM_SDP_MEDIA_PROTO_SIP :
             ret1 = cmUnpkCmSdpMedFmtAddrSpecList(&param->u.sip, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /* CM_SDP_SIP_IM_SUPPORT */
          case  CM_SDP_MEDIA_PROTO_UNKNOWN :
             ret1 = cmUnpkCmSdpMedFmtUnknownList(&param->u.unknown, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedProtoFmts*/

/*
*
*    Fun:    cmUnpkCmSdpMedPar
*
*    Desc:    unpack the structure CmSdpMedPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedPar
(
CmSdpMedPar *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedPar(param ,ptr, intfVer, mBuf)
CmSdpMedPar *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpMedPar)

    CMCHKUNPK(cmUnpkTknU16, &param->numProtFmts,mBuf);
    if( param->numProtFmts.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numProtFmts.val), (Ptr*)&(param->pflst));
       for (i=0;i<param->numProtFmts.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpMedProtoFmts), (Ptr*)&(param->pflst[i]));
          ret1 = cmUnpkCmSdpMedProtoFmts( (param->pflst[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMedPar*/

/*
*
*    Fun:    cmUnpkCmSdpVcci
*
*    Desc:    unpack the structure cmSdpVcci
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpVcci
(
CmSdpVcci *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpVcci(param ,mBuf)
CmSdpVcci *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpVcci)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU32OrNil, &param->vcci,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cid,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpVcci*/

/*
*
*    Fun:    cmUnpkCmSdpVpVcCid
*
*    Desc:    unpack the structure cmSdpVpVcCid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpVpVcCid
(
CmSdpVpVcCid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpVpVcCid(param ,mBuf)
CmSdpVpVcCid *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpVpVcCid)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->vpi,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->vci,mBuf);
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->cid,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpVpVcCid*/

/*
*
*    Fun:    cmUnpkCmSdpAddrVcci
*
*    Desc:    unpack the structure CmSdpAddrVcci
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAddrVcci
(
CmSdpAddrVcci *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAddrVcci(param ,ptr, mBuf)
CmSdpAddrVcci *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAddrVcci)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpAddr(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  CM_SDP_ADDR_VCCI :
                CMCHKUNPK(cmUnpkCmSdpVcci, &param->u.vcci,mBuf);
                break;
             case  CM_SDP_ADDR_VPCIVCI :
                CMCHKUNPK(cmUnpkCmSdpVpVcCid, &param->u.vpcid,mBuf);
                break;
             case  CM_SDP_CHOOSE :
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAddrVcci*/

/*
*
*    Fun:    cmUnpkCmSdpBcg
*
*    Desc:    unpack the structure cmSdpBcg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpBcg
(
CmSdpBcg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpBcg(param ,mBuf)
CmSdpBcg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpBcg)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->bcg,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  CM_SDP_ADDR_VCCI :
                CMCHKUNPK(cmUnpkCmSdpVcci, &param->u.vcci,mBuf);
                break;
             case  CM_SDP_ADDR_VPIVCI :
                CMCHKUNPK(cmUnpkCmSdpVpVcCid, &param->u.vpcid,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpBcg*/

/*
*
*    Fun:    cmUnpkCmSdpPortIdVpVcCid
*
*    Desc:    unpack the structure CmSdpPortIdVpVcCid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPortIdVpVcCid
(
CmSdpPortIdVpVcCid *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPortIdVpVcCid(param ,ptr, mBuf)
CmSdpPortIdVpVcCid *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpPortIdVpVcCid)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->portId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkCmSdpVpVcCid, &param->vpcid,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPortIdVpVcCid*/

/*
*
*    Fun:    cmUnpkCmSdpPortInt
*
*    Desc:    unpack the structure cmSdpPortInt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPortInt
(
CmSdpPortInt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPortInt(param ,mBuf)
CmSdpPortInt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpPortInt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkCmSdpU16OrNil, &param->port,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->rep,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPortInt*/

/*
*
*    Fun:    cmUnpkCmSdpPort
*
*    Desc:    unpack the structure CmSdpPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpPort
(
CmSdpPort *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpPort(param ,ptr, mBuf)
CmSdpPort *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpPort)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_PORT_INT :
             CMCHKUNPK(cmUnpkCmSdpPortInt, &param->u.portInt,mBuf);
             break;
          case  CM_SDP_PORT_VPCID :
             ret1 = cmUnpkCmSdpPortIdVpVcCid(&param->u.vpcid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpPort*/

/*
*
*    Fun:    cmUnpkCmSdpVcId
*
*    Desc:    unpack the structure CmSdpVcId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpVcId
(
CmSdpVcId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpVcId(param ,ptr, mBuf)
CmSdpVcId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpVcId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_VCID_ATM_ADDR_VCCI :
             ret1 = cmUnpkCmSdpAddrVcci(&param->u.atmAddrVcci, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_BCG :
             CMCHKUNPK(cmUnpkCmSdpBcg, &param->u.bcg,mBuf);
             break;
          case  CM_SDP_VCID_CHOOSE :
             break;
          case  CM_SDP_VCID_IMPLICIT :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.impl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_NIL :
             break;
          case  CM_SDP_VCID_PORT :
             ret1 = cmUnpkCmSdpPort(&param->u.port, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_VCID_VCCI :
             CMCHKUNPK(cmUnpkCmSdpVcci, &param->u.vcci,mBuf);
             break;
          case  CM_SDP_VCID_VPCI :
             CMCHKUNPK(cmUnpkCmSdpVpci, &param->u.vpci,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpVcId*/

/*
*
*    Fun:    cmUnpkCmSdpMediaField
*
*    Desc:    unpack the structure CmSdpMediaField
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMediaField
(
CmSdpMediaField *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMediaField(param ,ptr, intfVer, mBuf)
CmSdpMediaField *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    /*
     * 002.main_6: Changing Code for 001.main_6 so that dependency on
     * MGT Interface is not there and doesn't affect other products
     */
    CmIntfVer   verDelta;                 
    TRC3(cmUnpkCmSdpMediaField)

/* 003.main_6: changed dependency from MG to MG_RUG */
#ifdef MG_RUG
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */
    /*
     * 002.main_6 :- Modified switch statement to make code independent of
     *               protocol used
     */
    switch(verDelta)
    {
       case 0 :
               /*
                * remote ver is same as ours (latest). So unpack as latest.
                * this part is the generated code
                */
               CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
               if(param->pres.pres != NOTPRSNT)
               {
                  CMCHKUNPK(cmUnpkTknU8, &param->mediaType,mBuf);
                  if( ( param->mediaType.pres != NOTPRSNT )
                    && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                  {
                     ret1 = cmUnpkMacroTknStrOSXL(&param->media, ptr ,mBuf);
                     if (ret1 != ROK)
                     {
                        RETVALUE(RFAILED);
                     }
                  }
                  ret1 = cmUnpkCmSdpVcId(&param->id, ptr ,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
                  ret1 = cmUnpkCmSdpMedPar(&param->par, ptr , intfVer ,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
               }

               break;
       case 1 :
               /*
                * 001.main_6 :- unpack occording to the lower version;
                * this is hand written code
                */

               {
                   CmSdpMediaField_V1      *newMed;
                   CmSdpMediaField_V1      oldMed;
                   Buffer                  *tmpBuf;
                   EXTERN CmAbnfElmDef cmMsgDefSdpMediaField;
                   EXTERN CmAbnfElmDef cmMsgDefSdpMediaField_V1;


                   /*
                    * First of all unpack the info occording to the old
                    * MGTIFVER
                    */
                   CMCHKUNPK(cmUnpkTknPres, &oldMed.pres,mBuf);
                   if(oldMed.pres.pres != NOTPRSNT)
                   {
                      CMCHKUNPK(cmUnpkTknU8, &oldMed.mediaType,mBuf);
                      if( ( oldMed.mediaType.pres != NOTPRSNT )
                        && ( oldMed.mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                      {
                         ret1 = cmUnpkMacroTknStrOSXL(&oldMed.media, ptr ,mBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      ret1 = cmUnpkCmSdpVcId(&oldMed.id, ptr ,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmUnpkCmSdpMedPar(&oldMed.par, ptr , intfVer ,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                   }


                   /*
                    * Call the following func to -
                    * 1. encode the event struct (oldMed) passed to it
                    *    occording to the old DB (cmMsgDefSdpMediaField_V1)
                    * 2. decode the resulting mBuf in the new event struct
                    *    (newMed) passed to it occording to the new DB
                    *    (cmMsgDefSdpMediaField)
                    */

                   CM_TRANSLATE_FUNC((&(oldMed.pres)), cmMsgDefSdpMediaField_V1,
                                     cmMsgDefSdpMediaField, newMed,
                                     newMed->memCp, newMed->pres,
                                     CM_ABNF_PROT_SDP)

                   /*
                    * Now pack it occording to CmSdpMediaField (new def)
                    * into a tmp buf
                    */

                   if (ROK != SGetMsg(DFLT_REGION, DFLT_POOL, &tmpBuf))
                   {
                      cmFreeMem((Ptr)newMed);
                      RETVALUE(RFAILED);
                   }

                   if(newMed->pres.pres != NOTPRSNT)
                   {
                      ret1 = cmPkCmSdpMedPar(&newMed->par, intfVer ,tmpBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmPkCmSdpVcId(&newMed->id,tmpBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      if( ( newMed->mediaType.pres != NOTPRSNT )
                        && ( newMed->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                      {
                         ret1 = cmPkMacroTknStrOSXL(&newMed->media,tmpBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      CMCHKPK(cmPkTknU8, &newMed->mediaType,tmpBuf);
                   }
                   CMCHKPK(cmPkTknPres, &newMed->pres,tmpBuf);


                   /*
                    * Now unpack it occording to CmSdpMediaField (new def)
                    * using the tmp buf
                    */
                   CMCHKUNPK(cmUnpkTknPres, &param->pres,tmpBuf);
                   if(param->pres.pres != NOTPRSNT)
                   {
                      CMCHKUNPK(cmUnpkTknU8, &param->mediaType,tmpBuf);
                      if( ( param->mediaType.pres != NOTPRSNT )
                        && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                      {
                         ret1 = cmUnpkMacroTknStrOSXL(&param->media, ptr ,tmpBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      ret1 = cmUnpkCmSdpVcId(&param->id, ptr ,tmpBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmUnpkCmSdpMedPar(&param->par, ptr , intfVer ,tmpBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                   }

                   cmFreeMem((Ptr)newMed);
                   SPutMsg(tmpBuf);
                   RETVALUE(ROK);

               }

               break;
       default :
                RETVALUE(RFAILED);
               break;
    }

    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMediaField*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpAttrCapDesc
*
*    Desc:    unpack the structure CmSdpAttrCapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrCapDesc
(
CmSdpAttrCapDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrCapDesc(param ,ptr, intfVer, mBuf)
CmSdpAttrCapDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    /*
     * 002.main_6: Changing Code for 001.main_6 so that dependency on
     * MGT Interface is not there and doesn't affect other products
     */
    CmIntfVer   verDelta;                 
    TRC3(cmUnpkCmSdpAttrCapDesc)

/* 003.main_6: changed dependency from MG to MG_RUG */
#ifdef MG_RUG
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */
    /*
     * 002.main_6 :- Modified switch statement to make code independent of
     *               protocol used
     */
    switch(verDelta)
    {
       case 0 :
               /*
                * remote ver is same as ours (latest). So unpack as latest.
                * this part is the generated code
                */
               CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
               if(param->pres.pres != NOTPRSNT)
               {
                  CMCHKUNPK(cmUnpkTknU8, &param->capNum,mBuf);
                  CMCHKUNPK(cmUnpkTknU8, &param->mediaType,mBuf);
                  if( ( param->mediaType.pres != NOTPRSNT )
                    && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
                  {
                     ret1 = cmUnpkMacroTknStrOSXL(&param->media, ptr ,mBuf);
                     if (ret1 != ROK)
                     {
                        RETVALUE(RFAILED);
                     }
                  }
                  ret1 = cmUnpkCmSdpMedPar(&param->par, ptr , intfVer ,mBuf);
                  if (ret1 != ROK)
                  {
                     RETVALUE(RFAILED);
                  }
               }

               break;
       case 1 :
               /*
                * 001.main_6 :- unpack occording to the lower version;
                * this is hand written code
                */

               {
                   CmSdpAttrCapDesc_V2     *capDesc;
                   CmSdpAttrCapDesc_V1      oldCdsc; /* already typedefed before */
                   Buffer                   *tmpBuf;
                   EXTERN CmAbnfElmDef cmMsgDefSdpAttrCdsc;
                   EXTERN CmAbnfElmDef cmMsgDefSdpAttrCdsc_V1;


                   /*
                    * First of all unpack the info occording to the old
                    * MGTIFVER
                    */
                   CMCHKUNPK(cmUnpkTknPres, &oldCdsc.pres,mBuf);
                   if(oldCdsc.pres.pres != NOTPRSNT)
                   {
                      CMCHKUNPK(cmUnpkTknU8, &oldCdsc.capNum,mBuf);
                      CMCHKUNPK(cmUnpkTknU8, &oldCdsc.mediaType,mBuf);
                      if( ( oldCdsc.mediaType.pres != NOTPRSNT )
                        && ( oldCdsc.mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
         
                      {
                         ret1 = cmUnpkMacroTknStrOSXL(&oldCdsc.media, ptr ,mBuf);
                         if (ret1 != ROK)
                         {
                            RETVALUE(RFAILED);
                         }
                      }
                      ret1 = cmUnpkCmSdpVcId(&oldCdsc.id, ptr ,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                      ret1 = cmUnpkCmSdpMedPar(&oldCdsc.par, ptr ,intfVer ,mBuf);
                      if (ret1 != ROK)
                      {
                         RETVALUE(RFAILED);
                      }
                   }


                   /*
                    * Call the following func to -
                    * 1. encode the event struct (oldCdsc) passed to it
                    *    occording to the old DB (cmMsgDefSdpAttrCapCdsc_V1)
                    * 2. decode the resulting mBuf in the new event struct
                    *    (capDesc) passed to it occording to the new DB
                    *    (cmMsgDefSdpAttrCapDesc)
                    */

                   CM_TRANSLATE_FUNC((&(oldCdsc.pres)), cmMsgDefSdpAttrCdsc_V1,
                                     cmMsgDefSdpAttrCdsc, capDesc,
                                     capDesc->memCp, capDesc->pres,
                                     CM_ABNF_PROT_SDP)

                   /*
                    * Now pack it occording to CmSdpAttrCapDesc (new def)
                    * into a tmp buf
                    */

                   if (ROK != SGetMsg(DFLT_REGION, DFLT_POOL, &tmpBuf))
                   {
                      cmFreeMem((Ptr)capDesc);
                      RETVALUE(RFAILED);
                   }

                   if(capDesc->pres.pres != NOTPRSNT)
                   {
                      ret1 = cmPkCmSdpMedPar(&capDesc->par, intfVer ,tmpBuf);
                      if (ret1 != ROK)
                      {
                         cmFreeMem((Ptr)capDesc);
                         SPutMsg(tmpBuf);
                         RETVALUE(RFAILED);
                      }
                      if( ( capDesc->mediaType.pres != NOTPRSNT )
                        && ( capDesc->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
                      {
                         ret1 = cmPkMacroTknStrOSXL(&capDesc->media,tmpBuf);
                         if (ret1 != ROK)
                         {
                            cmFreeMem((Ptr)capDesc);
                            SPutMsg(tmpBuf);
                            RETVALUE(RFAILED);
                         }
                      }
                      CMCHKPK(cmPkTknU8, &capDesc->mediaType,tmpBuf);
                      CMCHKPK(cmPkTknU8, &capDesc->capNum,tmpBuf);
                   }
                   CMCHKPK(cmPkTknPres, &capDesc->pres,tmpBuf);


                   /*
                    * Now unpack it occording to CmSdpAttrCapDesc (new def)
                    * using the tmp buf
                    */
                   CMCHKUNPK(cmUnpkTknPres, &param->pres,tmpBuf);
                   if(param->pres.pres != NOTPRSNT)
                   {
                      CMCHKUNPK(cmUnpkTknU8, &param->capNum,tmpBuf);
                      CMCHKUNPK(cmUnpkTknU8, &param->mediaType,tmpBuf);
                      if( ( param->mediaType.pres != NOTPRSNT )
                        && ( param->mediaType.val == CM_SDP_MEDIA_UNKNOWN ))
                      {
                         ret1 = cmUnpkMacroTknStrOSXL(&param->media, ptr ,tmpBuf);
                         if (ret1 != ROK)
                         {
                            cmFreeMem((Ptr)capDesc);
                            SPutMsg(tmpBuf);
                            RETVALUE(RFAILED);
                         }
                      }
                      ret1 = cmUnpkCmSdpMedPar(&param->par, ptr , intfVer ,tmpBuf);
                      if (ret1 != ROK)
                      {
                         cmFreeMem((Ptr)capDesc);
                         SPutMsg(tmpBuf);
                         RETVALUE(RFAILED);
                      }
                   }

                   cmFreeMem((Ptr)capDesc);
                   SPutMsg(tmpBuf);
                   RETVALUE(ROK);
               }

               break;
       default :
                RETVALUE(RFAILED);
               break;
    }

    RETVALUE(ROK);


} /*end of function cmUnpkCmSdpAttrCapDesc*/

/*
*
*    Fun:    cmUnpkCmSdpAttrT38Fax
*
*    Desc:    unpack the structure cmSdpAttrT38Fax
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrT38Fax
(
CmSdpAttrT38Fax *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrT38Fax(param, ptr, mBuf)
CmSdpAttrT38Fax *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;

    TRC3(cmUnpkCmSdpAttrT38Fax)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_T38_FAX_FILL_BIT_RMVL :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_MAX_BFR :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_MAX_DATAGRAM :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_RATE_MNGMNT :
             CMCHKUNPK(cmUnpkTknU8, &param->u.val,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_TRNS_JBIG :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_TRNS_MMR :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_UDP_EC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.val,mBuf);
             break;
          case  CM_SDP_ATTR_T38_FAX_VER :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;
          case  CM_SDP_ATTR_T38_MAX_BIT_RATE :
             CMCHKUNPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;

             /* 001.main_12: t38 enhancements */
          case CM_SDP_ATTR_T38_FAX_HIGH_RDNCY:
             CMCHKPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;

          case CM_SDP_ATTR_T38_FAX_LOW_RDNCY:
             CMCHKPK(cmUnpkTknU32, &param->u.num,mBuf);
             break;

          case CM_SDP_ATTR_T38_FAX_UNKNOWN:
             ret1 = cmUnpkCmSdpAttrGeneric(&param->u.unknown, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;


          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrT38Fax*/
#endif
/* cm_sdp_c_002.main_12: Modified to allow $ (CHOOSE) in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE

/*
*
*    Fun:    cmUnpkCmSdpAttrEecId
*
*    Desc:    unpack the structure CmSdpAttrAttrEecId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrEecId
(
CmSdpAttrEecId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrEecId(param, mBuf)
CmSdpAttrEecId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkCmSdpAttrEecId)

    CMCHKPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKPK(cmUnpkTknU32, &param->eecid,mBuf);
    RETVALUE(ROK);


} /*end of function cmUnpkCmSdpAttrEecId*/
#endif

/*
*
*    Fun:    cmUnpkCmSdpAttr
*
*    Desc:    unpack the structure CmSdpAttr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttr
(
CmSdpAttr *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttr(param ,ptr, intfVer, mBuf)
CmSdpAttr *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpAttr)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  CM_SDP_ATTR_AAL2BTRFCDESC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.aal2_tfcb, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2CPS :
             CMCHKUNPK(cmUnpkCmSdpAttrAal2Cps, &param->u.aal2_cps,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2FTRFCDESC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.aal2_tfcf, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2QOSBPARMS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.aal2_qosb, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2QOSFPARMS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.aal2_qosf, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL2SSCS3652 :
             break;
          case  CM_SDP_ATTR_AAL2SSCS3653 :
             break;
          case  CM_SDP_ATTR_AAL2SSCS3661 :
             CMCHKUNPK(cmUnpkCmSdpAttrAal23661, &param->u.aal2_3661,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2SSCS3661_ASS :
             CMCHKUNPK(cmUnpkCmSdpAttrAal23661Ass, &param->u.aal2_3661Ass,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2SSCS3662 :
             CMCHKUNPK(cmUnpkCmSdpAttrAal23662, &param->u.aal2_3662,mBuf);
             break;
          case  CM_SDP_ATTR_AAL2_CPSSDURATE :
             CMCHKUNPK(cmUnpkCmSdpAttrAal2CpsSduRate, &param->u.al2CpSduRt,mBuf);
             break;
          case  CM_SDP_ATTR_AAL5APP :
             ret1 = cmUnpkCmSdpAttrAalApp(&param->u.aal5_app, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_AAL5_SSCOP :
             CMCHKUNPK(cmUnpkCmSdpAttrAal5Sscop, &param->u.al5Sscop,mBuf);
             break;
          case  CM_SDP_ATTR_AALTYPE :
             CMCHKUNPK(cmUnpkTknU8, &param->u.aaltype,mBuf);
             break;
          case  CM_SDP_ATTR_ABRPARMS :
             CMCHKUNPK(cmUnpkCmSdpAttrAbrParms, &param->u.abr,mBuf);
             break;
          case  CM_SDP_ATTR_ABR_SETUP :
             CMCHKUNPK(cmUnpkCmSdpAttrAtmAbrSetup, &param->u.abrSetup,mBuf);
             break;
          case  CM_SDP_ATTR_ANYCAST :
             ret1 = cmUnpkCmSdpAttrAnycast(&param->u.anycast, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ATMMAP :
             ret1 = cmUnpkCmSdpAttrAtmMap(&param->u.atmmap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ATMQOSPARMS :
             CMCHKUNPK(cmUnpkCmSdpAttrQosParms, &param->u.qos,mBuf);
             break;
          case  CM_SDP_ATTR_ATMTRFCDESC :
             CMCHKUNPK(cmUnpkCmSdpAttrTfcDesc, &param->u.tfc,mBuf);
             break;
          case  CM_SDP_ATTR_BCOB :
             CMCHKUNPK(cmUnpkCmSdpAttrAtmBcob, &param->u.bcob,mBuf);
             break;
          case  CM_SDP_ATTR_BEARERTYPE :
             CMCHKUNPK(cmUnpkCmSdpAttrBearType, &param->u.bearer,mBuf);
             break;
          case  CM_SDP_ATTR_BRR_SIGIE :
             ret1 = cmUnpkCmSdpAttrAtmBrrSigIe(&param->u.brrSigIe, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CACHE :
             CMCHKUNPK(cmUnpkCmSdpAttrCache, &param->u.cache,mBuf);
             break;
          case  CM_SDP_ATTR_CAPABILITY :
             ret1 = cmUnpkCmSdpAttrCapab(&param->u.capab, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CAT :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.cat, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CBR_RATE :
             CMCHKUNPK(cmUnpkTknU8, &param->u.cbrRate,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_CDSC :
             ret1 = cmUnpkCmSdpAttrCapDesc(&param->u.cdsc, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_CHAIN :
             CMCHKUNPK(cmUnpkTknU8, &param->u.chain,mBuf);
             break;
          case  CM_SDP_ATTR_CHARSET :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.charset, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CLIR :
             CMCHKUNPK(cmUnpkTknU8, &param->u.clir,mBuf);
             break;
          case  CM_SDP_ATTR_CLKREC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.clcrec,mBuf);
             break;
          case  CM_SDP_ATTR_CODEC_CFG :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.codecCfg, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CONTROL :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.control, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_CPAR :
             ret1 = cmUnpkCmSdpAttrCapParam(&param->u.capPar, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_MAX :
             ret1 = cmUnpkCmSdpAttrCapParam(&param->u.capPar, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_CPAR_MIN :
             ret1 = cmUnpkCmSdpAttrCapParam(&param->u.capPar, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_CPSSDUSIZE :
             CMCHKUNPK(cmUnpkCmSdpAttrCpsSduSize, &param->u.cpss,mBuf);
             break;
          case  CM_SDP_ATTR_DIRECTION :
             CMCHKUNPK(cmUnpkCmSdpAttrDirection, &param->u.direction,mBuf);
             break;
          case  CM_SDP_ATTR_DSEL :
             ret1 = cmUnpkCmSdpAttrDevSel(&param->u.dsel, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ECAN :
             CMCHKUNPK(cmUnpkCmSdpAttrEchoCan, &param->u.ecan,mBuf);
             break;
          case  CM_SDP_ATTR_EECID :
/* cm_sdp_c_002.main_12: Modified to allow $ (CHOOSE) in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE
             CMCHKUNPK(cmUnpkCmSdpAttrEecId, &param->u.eecid,mBuf);
#else
             CMCHKUNPK(cmUnpkTknU32, &param->u.eecid,mBuf);
#endif
             break;
          case  CM_SDP_ATTR_ETAG :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.etag, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FEC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.fec,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_FID :
             ret1 = cmUnpkCmSdpAttrFidMid(&param->u.fidVal, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_FMTP :
             ret1 = cmUnpkCmSdpAttrFmtp(&param->u.fmtp, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FRAMERATE :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.framerate, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_FSEL :
             ret1 = cmUnpkCmSdpAttrDevSel(&param->u.fsel, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_GC :
             CMCHKUNPK(cmUnpkCmSdpAttrGainCtl, &param->u.gc,mBuf);
             break;
          case  CM_SDP_ATTR_GENERIC :
             ret1 = cmUnpkCmSdpAttrGeneric(&param->u.unknown, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_GROUP :
             ret1 = cmUnpkCmSdpAttrGroup(&param->u.group, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_INACTIVE :
             break;
          case  CM_SDP_ATTR_ISUP_USI :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.isupUsi, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_KEYWDS :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.keywds, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_LANG :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.lang, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_LIJ :
             CMCHKUNPK(cmUnpkCmSdpAttrLij, &param->u.lij,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_MID :
             ret1 = cmUnpkCmSdpAttrFidMid(&param->u.midVal, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_ONE_WAY_SEL :
             ret1 = cmUnpkCmSdpAttrOneWaySel(&param->u.oneWaySel, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_ORIENT :
             CMCHKUNPK(cmUnpkTknU8, &param->u.orient,mBuf);
             break;
          case  CM_SDP_ATTR_PHONECONTEXT :
             ret1 = cmUnpkCmSdpAttrPhCxtId(&param->u.phoneContextIdent, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_PROFILEDESC :
             ret1 = cmUnpkCmSdpAttrProfDesc(&param->u.profd, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_PRTFL :
             CMCHKUNPK(cmUnpkTknU8, &param->u.prtfl,mBuf);
             break;
          case  CM_SDP_ATTR_PTIME :
             CMCHKUNPK(cmUnpkTknU32, &param->u.ptime,mBuf);
             break;
          case  CM_SDP_ATTR_Q763INN :
             CMCHKUNPK(cmUnpkTknU8, &param->u.q763Inn,mBuf);
             break;
          case  CM_SDP_ATTR_Q763NATURE :
             CMCHKUNPK(cmUnpkTknU8, &param->u.q763Nature,mBuf);
             break;
          case  CM_SDP_ATTR_Q763PLAN :
             CMCHKUNPK(cmUnpkTknU8, &param->u.q763Plan,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_QOS :
             CMCHKUNPK(cmUnpkCmSdpAttrQosSec, &param->u.qosVal,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_QOSCLASS :
             CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->u.qoscls,mBuf);
             break;
          case  CM_SDP_ATTR_QUALITY :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.quality, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_RANGE :
             CMCHKUNPK(cmUnpkCmSdpAttrRange, &param->u.range,mBuf);
             break;
          case  CM_SDP_ATTR_RECVONLY :
             break;
          case  CM_SDP_ATTR_REQUIRE :
             ret1 = cmUnpkCmSdpAttrRequire(&param->u.require, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_RTPMAP :
             ret1 = cmUnpkCmSdpAttrRtpMap(&param->u.rtpmap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_SBC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.sbc,mBuf);
             break;
          case  CM_SDP_ATTR_SDPLANG :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.sdplang, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_SECURE :
             CMCHKUNPK(cmUnpkCmSdpAttrQosSec, &param->u.secVal,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_SENDONLY :
             break;
          case  CM_SDP_ATTR_SENDRECV :
             break;
          case  CM_SDP_ATTR_SILENCESUPP :
             CMCHKUNPK(cmUnpkCmSdpAttrSilSupp, &param->u.silsupp,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_SQN_NUM :
             CMCHKUNPK(cmUnpkTknU8, &param->u.sqnNum,mBuf);
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_STC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.stc,mBuf);
             break;
          case  CM_SDP_ATTR_STRUCTURE :
             CMCHKUNPK(cmUnpkCmSdpAttrStruc, &param->u.struc,mBuf);
             break;
#ifdef CM_SDP_V_3
          case  CM_SDP_ATTR_T38_FAX :
             ret1 = cmUnpkCmSdpAttrT38Fax(&param->u.fax, ptr, mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  CM_SDP_V_3  */
          case  CM_SDP_ATTR_TOOL :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.tool, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_TYPE :
             ret1 = cmUnpkCmSdpAttrType(&param->u.type, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_UILYR1_PROT :
             CMCHKUNPK(cmUnpkTknU8, &param->u.uiLr1Prot,mBuf);
             break;
          case  CM_SDP_ATTR_UPCC :
             CMCHKUNPK(cmUnpkCmSdpU8OrNil, &param->u.upcc,mBuf);
             break;
          case  CM_SDP_ATTR_VSEL :
             ret1 = cmUnpkCmSdpAttrDevSel(&param->u.vsel, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_WTP :
             ret1 = cmUnpkCmSdpAttrWtp(&param->u.wtp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  CM_SDP_ATTR_IPBCP :
             ret1 = cmUnpkCmSdpAttrIpBcp(&param->u.bcp, mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttr*/

/*
*
*    Fun:    cmUnpkCmSdpAttrSet
*
*    Desc:    unpack the structure CmSdpAttrSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpAttrSet
(
CmSdpAttrSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpAttrSet(param ,ptr, intfVer, mBuf)
CmSdpAttrSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpAttrSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->attr));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpAttr), (Ptr*)&(param->attr[i]));
          ret1 = cmUnpkCmSdpAttr( (param->attr[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpAttrSet*/
#ifdef CM_SDP_V_3

/*
*
*    Fun:    cmUnpkCmSdpBw
*
*    Desc:    unpack the structure CmSdpBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpBw
(
CmSdpBw *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpBw(param ,ptr, mBuf)
CmSdpBw *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpBw)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpBwTyp(&param->bwType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU32, &param->bWidth,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpBw*/
#else

/*
*
*    Fun:    cmUnpkCmSdpBw
*
*    Desc:    unpack the structure CmSdpBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpBw
(
CmSdpBw *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpBw(param ,ptr, mBuf)
CmSdpBw *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpBw)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->bwType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU32, &param->bWidth,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpBw*/
#endif

/*
*
*    Fun:    cmUnpkCmSdpBwSet
*
*    Desc:    unpack the structure CmSdpBwSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpBwSet
(
CmSdpBwSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpBwSet(param ,ptr, mBuf)
CmSdpBwSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpBwSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->sdpBw));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpBw), (Ptr*)&(param->sdpBw[i]));
          CMCHKUNPKPTR(cmUnpkCmSdpBw,  (param->sdpBw[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpBwSet*/

/*
*
*    Fun:    cmUnpkCmSdpMediaDesc
*
*    Desc:    unpack the structure CmSdpMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMediaDesc
(
CmSdpMediaDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMediaDesc(param ,ptr, intfVer, mBuf)
CmSdpMediaDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpMediaDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkCmSdpMediaField(&param->field, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->info, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpConnSet(&param->connSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpBwSet(&param->bwSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpKeyType(&param->keyType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpAttrSet(&param->attrSet, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMediaDesc*/

/*
*
*    Fun:    cmUnpkCmSdpMediaDescSet
*
*    Desc:    unpack the structure CmSdpMediaDescSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMediaDescSet
(
CmSdpMediaDescSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMediaDescSet(param ,ptr, intfVer, mBuf)
CmSdpMediaDescSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpMediaDescSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->mediaDesc));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpMediaDesc), (Ptr*)&(param->mediaDesc[i]));
          ret1 = cmUnpkCmSdpMediaDesc( (param->mediaDesc[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpMediaDescSet*/

/*
*
*    Fun:    cmUnpkCmSdpInfo
*
*    Desc:    unpack the structure CmSdpInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpInfo
(
CmSdpInfo *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpInfo(param ,ptr, intfVer, mBuf)
CmSdpInfo *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkCmSdpInfo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->ver,mBuf);
       ret1 = cmUnpkCmSdpOptOrig(&param->orig, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->sessName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->info, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->uri, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpEmailSet(&param->emailSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpPhoneSet(&param->phoneSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpConn(&param->conn, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpBwSet(&param->bwSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpTime(&param->sdpTime, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpKeyType(&param->keyType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpAttrSet(&param->attrSet, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkCmSdpMediaDescSet(&param->mediaDescSet, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpInfo*/

/*
*
*    Fun:    cmUnpkCmSdpInfoSet
*
*    Desc:    unpack the structure CmSdpInfoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpInfoSet
(
CmSdpInfoSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpInfoSet(param ,ptr, intfVer, mBuf)
CmSdpInfoSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkCmSdpInfoSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->info));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(CmSdpInfo), (Ptr*)&(param->info[i]));
          ret1 = cmUnpkCmSdpInfo( (param->info[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkCmSdpInfoSet*/
#endif /* CM_SDP_V_2 */


#endif /* not defined __CMSDPX__ */


/********************************************************************30**

         End of file:     cm_sdp.c@@/main/mgcp_rel_1.5_mnt/1 - Tue May 31 11:34:54 2005

*********************************************************************31*/
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      nct  1. Initial release
/main/3      ---      dw   1. Added ATM support
/main/6      ---      ra   1. GCP 1.3 release
/main/7  001.main_6   ra   1. Hand modification of pack/unpack routines -
                              cmPkCmSdpAttrCapDesc
                              cmUnpkCmSdpAttrCapDesc
                              While packing, if remote interface version
                              is lower than ours then pack occording to
                              the remote interface version (previous ver).
                              Ditto while unpacking.
                           2. Extra argument - interface version (intfVer)
                              added in many functions.
                           3. Now #include ing cm_abnf.[hx], cm_lib.x & mgt.h
/main/8  002.main_6   ra   1. Modifications in following routines -
                              cmPkCmSdpMediaField
                              cmUnpkCmSdpMediaField
                              cmPkCmSdpAttrCapDesc
                              cmUnpkCmSdpAttrCapDesc
                              so that other products like SIP can use these
                              routines. Removed dependency on GCP.
/main/9  003.main_6   rg   1. Modifications in routines patched above in 
                              002.main_6. The dependency is changed from MG to
                              MG_RUG.
/main/10     ---   rg   1. Modifications in pack/unpack for
                              cmSdpMedProtoFmts for TCP and UDP.
/main/12     ---      up   1. Support for IPBCP in SDP
/main/12 001.main_12 ra    1. Change to support a mix of "$" & integers
                              in RTP list.
                           2. Pk/UnPk changes to support CmSdpAttrT38Fax
                              enhancements.
  cm_sdp_c_002.main_12 gk  1. Modified to allow $ (CHOOSE) in the place of 
                              single parameter value under the flag 
                              CM_SDP_MEGACO_EECID_CHOICE
*********************************************************************91*/
