/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     common ABNF  
  
     Type:     C Source file
  
     Desc:     C source code for common ABNF encoding
               routines
  
     File:     cm_abnf.c
     
     Sid:      cm_abnf.c@@/main/12 - Wed Mar 30 08:41:58 2005
  
     Prg:      rm
  
*********************************************************************21*/


/************************************************************************
 
     Note: 
 
     This file has been extracted to support the following options:
 
     Option                Description
     ------          ------------------------------
     CM_ABNF_V_1_2   More capabilities like protocol variants, int ranges
     CM_ABNF_DBG     Enable debug
     CM_ABNF_DBGP    Debug printing

************************************************************************/
 

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_lib.x"        /* common library file */


/* Local variable definition */

/*
 * 001.main_12 : Added variables representing the maximum values
 *              of U32 & S32 in bases 10 and 16. 4294967295 represents
 *              the max val of U32 in base 10 whereas ffffffff
 *              represents this value in base 16. Similarly,
 *              2147483647 represents the max val of S32 in base 10
 *              whereas 7fffffff represents this value in base 16.
 */
PRIVATE U8 cmAbnfBase10MaxU32[] = {'4', '2', '9', '4', '9',
                                   '6', '7', '2', '9', '5'};

PRIVATE U8 cmAbnfBase16MaxU32[] = {'f', 'f', 'f', 'f',
                                   'f', 'f', 'f', 'f'};

PRIVATE U8 cmAbnfBase10MaxS32[] = {'2', '1', '4', '7', '4',
                                   '8', '3', '6', '4', '7'};

PRIVATE U8 cmAbnfBase16MaxS32[] = {'7', 'f', 'f', 'f',
                                   'f', 'f', 'f', 'f'};



/* Local macro definition */

#define CM_ABNF_GET_NXTDBUF(_dBufInfo, _off)                                  \
{                                                                             \
      MsgLen _len;                                                            \
      S16    _ret;                                                            \
      if (((_ret) = SGetNxtDBuf((_off)->mBuf, &(_dBufInfo)->dBuf)) != ROK)    \
      {                                                                       \
            RETVALUE(_ret);                                                   \
      }                                                                       \
                                                                              \
      if (SGetDataTx((_dBufInfo)->dBuf, &(_dBufInfo)->start, &(_len))  != ROK)\
      {                                                                       \
            RETVALUE(RFAILED);                                                \
      }                                                                       \
      (_dBufInfo)->cur = (_dBufInfo)->start;                                  \
      (_dBufInfo)->end = (_dBufInfo)->start + (_len);                         \
                                                                              \
      (_off)->end =                                                           \
            ((++(_off)->end == CM_ABNF_DBUF_ARRAY) ? 0 : (_off)->end);        \
}

S16 cmAbnfEncMsg ARGS ((
                 U8 **event, CmAbnfElmDef *elmDef, 
                 CmAbnfEncCp *encCp, U16 numSkip 
                 ));

PRIVATE  S16 cmAbnfEncChoiceElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

/*
 * [TEL]: Added new element for U16 support
 */
PRIVATE  S16 cmAbnfEncU16ChoiceElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncSeqElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncOptSeqElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

S16 cmAbnfEncOptSeqOfElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncCondSeqOfElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncSeqOfElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncChSeqOfElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

S16 cmAbnfEncSkipElmnt ARGS (( U8 **event, CmAbnfElmDef *elmDef ));
 
PRIVATE  S16 cmAbnfEncMetaElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncEnumElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

/*
 * [TEL]: Added new element for U16 support
 */
PRIVATE  S16 cmAbnfEncU16EnumElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncUintElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));
PRIVATE  S16 cmAbnfEncHexUintElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));

PRIVATE  S16 cmAbnfEncOctStrElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef, 
                           CmAbnfEncCp *encCp, U16 numSkip 
                           ));
PRIVATE  S16 cmAbnfEncTknBufElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef,
                           CmAbnfEncCp *encCp
                           ));
PRIVATE  S16 cmAbnfEncMarkerElmnt ARGS ((
                           U8 **event, CmAbnfElmDef *elmDef,
                           CmAbnfEncCp *encCp
                           ));


PRIVATE  S16 cmAbnfDecChoiceElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

/*
 * [TEL]: Added new element for U16 support
 */
PRIVATE  S16 cmAbnfDecU16ChoiceElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecSeqElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecOptSeqElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecOptSeqOfElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecSeqOfElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecCondSeqOfElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecChSeqOfElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecMetaElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecEnumElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

/*
 * [TEL]: Added new element for U16 support
 */
PRIVATE  S16 cmAbnfDecU16EnumElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecSkipElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecUintElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));
PRIVATE  S16 cmAbnfDecHexUintElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE  S16 cmAbnfDecOctStrElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));
PRIVATE  S16 cmAbnfDecTknBufElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));
PRIVATE  S16 cmAbnfDecMarkerElmnt ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

S16 cmAbnfDecMsg  ARGS ((
                      U8 **event, CmAbnfElmDef  *elmDef, CmAbnfDecCp *decCp ));

PRIVATE S16 cmAbnfDecSkipNChars ARGS ((
                      CmAbnfDecOff *offset, U32 numB ));

/* local defines */
#define CM_ABNF_TKNPRES(_evt)       (**(_evt))
#define CM_ABNF_TKNNUMVAL(_evt)     (((TknU16 *)(*(_evt)))->val)
#define CM_ABNF_TKNU8VAL(_evt)      (((TknU8 *)(*(_evt)))->val)
#define CM_ABNF_TKNU16VAL(_evt)     (((TknU16 *)(*(_evt)))->val)
#define CM_ABNF_TKNU32VAL(_evt)     (((TknU32 *)(*(_evt)))->val)
#define CM_ABNF_TKNSTR8VAL(_evt)    &(((TknStr8 *)(*(_evt)))->val[0])
#define CM_ABNF_TKNSTR32VAL(_evt)   &(((TknStr32 *)(*(_evt)))->val[0])
#define CM_ABNF_TKNSTRXLVAL(_evt)   (((TknStrOSXL *)(*(_evt)))->val)
#define CM_ABNF_TKNSTR8LEN(_evt)    (((TknStr8 *)(*(_evt)))->len)
#define CM_ABNF_TKNSTR32LEN(_evt)   (((TknStr32 *)(*(_evt)))->len)
#define CM_ABNF_TKNSTRXLLEN(_evt)   (((TknStrOSXL *)(*(_evt)))->len)
#define CM_ABNF_SET_TKNPRES(_evt)   ((*((U8 *)(*(_evt)))) = TRUE)
#define CM_ABNF_SETPTR(_evt, _ptr)  ((*((Ptr *)(*(_evt)))) = ((Ptr)(_ptr)))

#define CM_ABNF_TKNS8VAL(_evt)      (((TknS8 *)(*(_evt)))->val)
#define CM_ABNF_TKNS16VAL(_evt)     (((TknS16 *)(*(_evt)))->val)
#define CM_ABNF_TKNS32VAL(_evt)     (((TknS32 *)(*(_evt)))->val)

#define CM_ABNF_SET_TKNU8(_evt, _val)                         \
{                                                             \
   (((TknU8 *)(*_evt))->pres) = PRSNT_NODEF;                  \
   (((TknU8 *)(*_evt))->val)  = (_val);                       \
}

#define CM_ABNF_SET_TKNS8(_evt, _val)                         \
{                                                             \
   (((TknS8 *)(*_evt))->pres) = PRSNT_NODEF;                  \
   (((TknS8 *)(*_evt))->val)  = (_val);                       \
}

#define CM_ABNF_SET_TKNS32(_evt, _val)                        \
{                                                             \
   (((TknS32 *)(*_evt))->pres) = PRSNT_NODEF;                 \
   (((TknS32 *)(*_evt))->val)  = (_val);                      \
}

#define CM_ABNF_SET_TKNU32(_evt, _val)                        \
{                                                             \
   (((TknU32 *)(*_evt))->pres) = PRSNT_NODEF;                 \
   (((TknU32 *)(*_evt))->val)  = (_val);                      \
}
#define CM_ABNF_SET_TKNNUMVAL(_evt, _val)                     \
{                                                             \
   (((TknU16 *)(*_evt))->pres) = PRSNT_NODEF;                 \
   (((TknU16 *)(*_evt))->val) = (_val);                       \
}
#define CM_ABNF_SET_TKNU16(_evt, _val)   CM_ABNF_SET_TKNNUMVAL(_evt, _val)

#define CM_ABNF_SET_TKNS16(_evt, _val)                       \
{                                                            \
   (((TknS16 *)(*_evt))->pres) = PRSNT_NODEF;                \
   (((TknS16 *)(*_evt))->val) = (_val);                      \
}

#define CM_ABNF_SET_TKNSTR8(_evt, _len)                      \
{                                                            \
   (((TknStr8 *)(*_evt))->pres) = PRSNT_NODEF;               \
   (((TknStr8 *)(*_evt))->len) = (U8)(_len);                 \
}

#define CM_ABNF_SET_TKNSTR16(_evt, _len)                     \
{                                                            \
   (((TknStr16 *)(*_evt))->pres) = PRSNT_NODEF;              \
   (((TknStr16 *)(*_evt))->len) = (_len);                    \
}

#define CM_ABNF_SET_TKNSTR32(_evt, _len)                     \
{                                                            \
   (((TknStr32 *)(*_evt))->pres) = PRSNT_NODEF;              \
   (((TknStr32 *)(*_evt))->len) = (U8)(_len);                \
}

#define CM_ABNF_SET_TKNSTRXL(_evt, _str, _len)               \
{                                                            \
   (((TknStrOSXL *)(*_evt))->pres) = PRSNT_NODEF;            \
   (((TknStrOSXL *)(*_evt))->val) = (_str);                  \
   (((TknStrOSXL *)(*_evt))->len) = (_len);                  \
}

#define CM_ABNF_STRLEN(_data, _len)  for ((_len) = 0; (_data)[_len]; (_len)++)

#define CM_ABNF_SI2A(_val, _str, _len)                        \
{                                                            \
   U8  _idx = CM_ABNF_MAX_UINTSZ - 1;                        \
   U8  _neg = 0;                                            \
   if ( (_val) < 0 )                                         \
    {                                                        \
        (_val) = - (_val);                                  \
        (_neg) =1;                                         \
    }                                                        \
   (_len) = 0;                                               \
   do                                                        \
   {                                                         \
      (_str)[(_idx)] = (U8)((_val) % 10) + '0';              \
      (_idx)--;                                              \
      (_val) = (_val)/10;                                    \
      (_len)++;                                              \
   } while((_val));                                          \
   if ( (_neg) )                                             \
    {                                                        \
      (_str)[(_idx)] = '-';                                  \
      (_len)++;                                              \
    }                                                        \
}

/* Alter the value of _val */
#define CM_ABNF_I2A(_val, _str, _len)                        \
{                                                            \
   U8  _idx = CM_ABNF_MAX_UINTSZ - 1;                        \
   (_len) = 0;                                               \
   do                                                        \
   {                                                         \
      (_str)[(_idx)] = (U8)((_val) % 10) + '0';              \
      (_idx)--;                                              \
      (_val) = (_val)/10;                                    \
      (_len)++;                                              \
   } while((_val));                                          \
}


#define CM_ABNF_SH2A(_val, _str, _len)                       \
{                                                           \
   U8 _idx;                                                 \
   U8  _neg = 0;                                            \
   _idx = CM_ABNF_MAX_HEXUINTSZ - 1;                        \
   if ( (_val) < 0 )                                         \
    {                                                        \
        (_val) = - (_val);                                  \
        (_neg) = 1;                                         \
    }                                                        \
   (_len) = 0;                                              \
   do                                                       \
   {                                                        \
      (_str)[(_idx)] = ((U8 )((_val) & 0xF));               \
      if ((_str)[(_idx)] > 9)                               \
      {                                                     \
         (_str)[(_idx)] += 'A' - 10;                        \
      }                                                     \
      else                                                  \
      {                                                     \
         (_str)[(_idx)] += '0';                             \
      }                                                     \
      _idx--;                                               \
      (_val) /= 16; /* Don't use >> 4 (signed/unsigned) */  \
      (_len)++;                                             \
   } while (_val);                                          \
   if ( (_neg) )                                             \
    {                                                        \
      (_str)[(_idx)] = '-';                                  \
      (_len)++;                                              \
    }                                                        \
}

#define CM_ABNF_H2A(_val, _str, _len)                       \
{                                                           \
   U8 _idx;                                                 \
   _idx = CM_ABNF_MAX_HEXUINTSZ - 1;                        \
   (_len) = 0;                                              \
   do                                                       \
   {                                                        \
      (_str)[(_idx)] = ((U8 )((_val) & 0xF));               \
      if ((_str)[(_idx)] > 9)                               \
      {                                                     \
         (_str)[(_idx)] += 'A' - 10;                        \
      }                                                     \
      else                                                  \
      {                                                     \
         (_str)[(_idx)] += '0';                             \
      }                                                     \
      _idx--;                                               \
      (_val) /= 16; /* Don't use >> 4 (signed/unsigned) */  \
      (_len)++;                                             \
   } while (_val);                                          \
}





/*
 * 001.main_12 : Enhanced the following macro to check for
 *              boundary condition. If the length of the string
 *              is the same as the length of the maximum value
 *              of S32, then the string value can overflow.
 *              To ensure that the overflow is not happening
 *              checks have been added.
 */

#define CM_ABNF_A2SI(_str, _len, _val)                       \
{                                                           \
   U8 i;                                                    \
   U8 _base;                                                \
   U8 _start;                                               \
   U8 _neg;                                                 \
   U32 _tmpVal;                                             \
   _base = 10;                                              \
   _start = 0;                                              \
   (_val) = 0;                                              \
   _neg = 0;                                                \
   _tmpVal = 0;                                             \
                                                            \
 if( (_str)[0] == '-' )                                      \
 {                                                           \
     _start = 1;                                              \
     _neg = 1;                                                 \
      if ((_str)[1] == '0')                                    \
      {                                                        \
         if ((_len) == 2)                                      \
            _base = 10;                                        \
         else if ((_str)[2] == 'x' || (_str)[2] == 'X')        \
         {                                                     \
            _base = 16;                                        \
            _start = 3;                                        \
         }                                                     \
         else                                                  \
         {                                                     \
            _base = 10; /* No support for octals */            \
            _start = 2;                                        \
         }                                                     \
      }                                                        \
      else                                                     \
      {                                                        \
         for (i = 1; i < (_len); i++)                          \
         {                                                     \
            if ( ((_str)[i] >= 'a' && (_str)[i] <= 'f') ||     \
                 ((_str)[i] >= 'A' && (_str)[i] <= 'F')        \
               )                                               \
               {                                               \
                  _base = 16;                                  \
               }                                               \
         }                                                     \
      }                                                        \
 }                                                             \
 else                                                          \
 {                                                             \
      if ((_str)[0] == '0')                                    \
      {                                                        \
         if ((_len) == 1)                                      \
            _base = 10;                                        \
         else if ((_str)[1] == 'x' || (_str)[1] == 'X')        \
         {                                                     \
            _base = 16;                                        \
            _start = 2;                                        \
         }                                                     \
         else                                                  \
         {                                                     \
            _base = 10; /* No support for octals */            \
            _start = 1;                                        \
         }                                                     \
      }                                                        \
      else                                                     \
      {                                                        \
         for (i = 0; i < (_len); i++)                          \
         {                                                     \
            if ( ((_str)[i] >= 'a' && (_str)[i] <= 'f') ||     \
                 ((_str)[i] >= 'A' && (_str)[i] <= 'F')        \
               )                                               \
               {                                               \
                  _base = 16;                                  \
               }                                               \
         }                                                     \
      }                                                        \
 }                                                          \
                                                            \
   if (_base == 10 || _base == 8)                           \
   {                                                        \
      if (((_base) == 10) &&                                \
          (((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_10_S32))   \
      {                                                     \
         for (i = _start; i < (_len-1); i++)                \
         {                                                  \
            (_val) *= _base;                                \
            (_val) += ((_str)[i] - '0');                    \
            _tmpVal *= _base;                                \
            _tmpVal += (cmAbnfBase10MaxS32[i - (_start) - '0']);  \
         }                                                  \
         if (_val > _tmpVal)                                \
            {                                               \
               *event += elmDef->evSize;                    \
               decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG; \
               decCp->err->idNum = elmDef->idNum;           \
               RETVALUE(CM_ABNF_RFAILED);                   \
            }                                               \
         if (_val == _tmpVal &&                             \
               ((_str)[i]) > cmAbnfBase10MaxS32[i - (_start)])    \
         {                                                  \
            *event += elmDef->evSize;                       \
            decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;    \
            decCp->err->idNum = elmDef->idNum;              \
            RETVALUE(CM_ABNF_RFAILED);                      \
         }                                                  \
         (_val) *= _base;                                   \
         (_val) += ((_str)[i] - '0');                       \
      }                                                     \
      else                                                  \
      {                                                     \
         for (i = _start; i < (_len); i++)                  \
         {                                                  \
            (_val) *= _base;                                \
            (_val) += ((_str)[i] - '0');                    \
         }                                                  \
      }                                                     \
   }                                                        \
   else if (_base == 16)                                    \
   {                                                        \
      for (i = _start; i < (_len); i++)                     \
      {                                                     \
         if ((((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_16_S32)   \
                              &&                            \
             (((_str)[i]) > cmAbnfBase16MaxS32[i - (_start)]))      \
         {                                                  \
            *event += elmDef->evSize;                       \
            decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;    \
            decCp->err->idNum = elmDef->idNum;              \
            RETVALUE(CM_ABNF_RFAILED);                      \
         }                                                  \
                                                            \
         (_val) *= _base;                                   \
         if ((_str)[i] >= '0' && (_str)[i] <= '9')          \
         {                                                  \
            (_val) += (_str)[i] - '0';                      \
         }                                                  \
         else if ((_str)[i] >= 'A' && (_str)[i] <= 'F')     \
         {                                                  \
            (_val) += (_str)[i] - 'A' + 10;                 \
         }                                                  \
         else if ((_str)[i] >= 'a' && (_str)[i] <= 'f')     \
         {                                                  \
            (_val) += (_str)[i] - 'a' + 10;                 \
         }                                                  \
         else                                               \
         {                                                  \
            break;                                          \
         }                                                  \
      }                                                     \
   }                                                        \
                                                            \
   if ( _neg )                                              \
        (_val) = - (_val);                                  \
}


/*
 * 001.main_12 : Enhanced the following macro to check for
 *              boundary condition. If the length of the string
 *              is the same as the length of the maximum value
 *              of U32, then the string value can overflow.
 *              To ensure that the overflow is not happening
 *              checks have been added.
 */

#define CM_ABNF_A2I(_str, _len, _val)                       \
{                                                           \
   U8 i;                                                    \
   U8 _base;                                                \
   U8 _start;                                               \
   U32 _tmpVal;                                             \
   _base = 10;                                              \
   _start = 0;                                              \
   (_val) = 0;                                              \
   _tmpVal = 0;                                             \
                                                            \
   if ((_str)[0] == '0')                                    \
   {                                                        \
      if ((_len) == 1)                                      \
         _base = 10;                                        \
      else if ((_str)[1] == 'x' || (_str)[1] == 'X')        \
      {                                                     \
         _base = 16;                                        \
         _start = 2;                                        \
      }                                                     \
      else                                                  \
      {                                                     \
         _base = 10; /* No support for octals */            \
         _start = 1;                                        \
      }                                                     \
   }                                                        \
   else                                                     \
   {                                                        \
      for (i = 0; i < (_len); i++)                          \
      {                                                     \
         if ( ((_str)[i] >= 'a' && (_str)[i] <= 'f') ||     \
              ((_str)[i] >= 'A' && (_str)[i] <= 'F')        \
            )                                               \
            {                                               \
               _base = 16;                                  \
            }                                               \
      }                                                     \
   }                                                        \
                                                            \
   if (_base == 10 || _base == 8)                           \
   {                                                        \
      if (((_base) == 10) &&                                \
          (((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_10_U32))   \
      {                                                     \
         for (i = _start; i < (_len-1); i++)                \
         {                                                  \
            (_val) *= _base;                                \
            (_val) += ((_str)[i] - '0');                    \
            _tmpVal *= _base;                               \
            _tmpVal += (cmAbnfBase10MaxU32[i - (_start)] -'0');   \
         }                                                  \
         if (_val > _tmpVal)                                \
            {                                               \
               *event += elmDef->evSize;                    \
               decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG; \
               decCp->err->idNum = elmDef->idNum;           \
               RETVALUE(CM_ABNF_RFAILED);                   \
            }                                               \
         if (_val == _tmpVal &&                             \
               ((_str)[i]) > cmAbnfBase10MaxU32[i - (_start)])    \
         {                                                  \
            *event += elmDef->evSize;                       \
            decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;    \
            decCp->err->idNum = elmDef->idNum;              \
            RETVALUE(CM_ABNF_RFAILED);                      \
         }                                                  \
         (_val) *= _base;                                   \
         (_val) += ((_str)[i] - '0');                       \
      }                                                     \
      else                                                  \
      {                                                     \
         for (i = _start; i < (_len); i++)                  \
         {                                                  \
            (_val) *= _base;                                \
            (_val) += ((_str)[i] - '0');                    \
         }                                                  \
      }                                                     \
   }                                                        \
   else if (_base == 16)                                    \
   {                                                        \
      for (i = _start; i < (_len); i++)                     \
      {                                                     \
         if ((((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_16_U32)   \
                              &&                            \
             (((_str)[i]) > cmAbnfBase16MaxU32[i - (_start)]))      \
         {                                                  \
            *event += elmDef->evSize;                       \
            decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;    \
            decCp->err->idNum = elmDef->idNum;              \
            RETVALUE(CM_ABNF_RFAILED);                      \
         }                                                  \
                                                            \
         (_val) *= _base;                                   \
         if ((_str)[i] >= '0' && (_str)[i] <= '9')          \
         {                                                  \
            (_val) += (_str)[i] - '0';                      \
         }                                                  \
         else if ((_str)[i] >= 'A' && (_str)[i] <= 'F')     \
         {                                                  \
            (_val) += (_str)[i] - 'A' + 10;                 \
         }                                                  \
         else if ((_str)[i] >= 'a' && (_str)[i] <= 'f')     \
         {                                                  \
            (_val) += (_str)[i] - 'a' + 10;                 \
         }                                                  \
         else                                               \
         {                                                  \
            break;                                          \
         }                                                  \
      }                                                     \
   }                                                        \
}


/*
 * 001.main_12 : Enhanced the following macro to check for
 *              boundary condition. If the length of the string
 *              is the same as the length of the maximum value
 *              of S32, then the string value can overflow.
 *              To ensure that the overflow is not happening
 *              checks have been added.
 */

#define CM_ABNF_A2SH(_str, _len, _val)                          \
{                                                              \
   U8 i;                                                       \
   U8 _neg;                                                 \
   U8 _start;                                               \
   _neg = 0;                                                \
   _start = 0;                                              \
   (_val) = 0;                                                 \
                                                            \
 if( (_str)[0] == '-' )                                      \
 {                                                           \
   _neg = 1;                                                 \
   _start = 1;                                              \
 }                                                           \
                                                            \
     for (i = (_start); i < (_len); i++)                         \
     {                                                           \
      if ((((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_16_S32)\
                         &&                                 \
          (((_str)[i]) > cmAbnfBase16MaxS32[i - (_start)])) \
      {                                                     \
         *event += elmDef->evSize;                          \
         decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;       \
         decCp->err->idNum = elmDef->idNum;                 \
         RETVALUE(CM_ABNF_RFAILED);                         \
      }                                                     \
                                                            \
        (_val) *= 16;                                            \
        if ((_str)[i] >= '0' && (_str)[i] <= '9')                \
        {                                                        \
           (_val) += (_str)[i] - '0';                            \
        }                                                        \
        else if ((_str)[i] >= 'A' && (_str)[i] <= 'F')           \
        {                                                        \
           (_val) += (_str)[i] - 'A' + 10;                       \
        }                                                        \
        else if ((_str)[i] >= 'a' && (_str)[i] <= 'f')           \
        {                                                        \
           (_val) += (_str)[i] - 'a' + 10;                       \
        }                                                        \
        else                                                     \
        {                                                        \
           break;                                                \
        }                                                        \
     }                                                           \
                                                            \
   if ( _neg )                                              \
        (_val) = - (_val);                                  \
}



/*
 * 001.main_12 : Enhanced the following macro to check for
 *              boundary condition. If the length of the string
 *              is the same as the length of the maximum value
 *              of U32, then the string value can overflow.
 *              To ensure that the overflow is not happening
 *              checks have been added.
 */

#define CM_ABNF_A2H(_str, _len, _val)                          \
{                                                              \
   U8 i;                                                       \
   U8 _start;                                               \
   _start = 0;                                              \
   (_val) = 0;                                                 \
                                                            \
   for (i = 0; i < (_len); i++)                                \
   {                                                           \
      if ((((_len) - (_start)) == CM_ABNF_MAX_LEN_BASE_16_U32)\
                         &&                                 \
          (((_str)[i]) > cmAbnfBase16MaxU32[i - (_start)])) \
      {                                                     \
         *event += elmDef->evSize;                          \
         decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;       \
         decCp->err->idNum = elmDef->idNum;                 \
         RETVALUE(CM_ABNF_RFAILED);                         \
      }                                                     \
                                                            \
      (_val) *= 16;                                            \
      if ((_str)[i] >= '0' && (_str)[i] <= '9')                \
      {                                                        \
         (_val) += (_str)[i] - '0';                            \
      }                                                        \
      else if ((_str)[i] >= 'A' && (_str)[i] <= 'F')           \
      {                                                        \
         (_val) += (_str)[i] - 'A' + 10;                       \
      }                                                        \
      else if ((_str)[i] >= 'a' && (_str)[i] <= 'f')           \
      {                                                        \
         (_val) += (_str)[i] - 'a' + 10;                       \
      }                                                        \
      else                                                     \
      {                                                        \
         break;                                                \
      }                                                        \
   }                                                           \
}



#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
/* Right-shift _flagp by _protOffset then mask with 0xF */ 
/* _protOffsets should be 4, 8, ..., 28 (7 in all) */     
/* 0 is a special value for common DB elements */        
#define CM_ABNF_FLAGP(_flagp, _protOffset)                     \
   ((U32)(                                                     \
            (                                                  \
      ((_flagp) >> (_protOffset)) ? ((_flagp) >> (_protOffset)) : (_flagp) \
            ) & 0x0F                                           \
         )                                                     \
   )
#else /* not CM_ABNF_V_1_2 */
#define CM_ABNF_FLAGP(_flagp, _protOffset) (_flagp)
#endif /* CM_ABNF_V_1_2 */

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
#define CM_ABNF_TKNPRES_CHK(_pOff, _event, _elmDef, _err) \
{                                                            \
   U32 _flagp;                                               \
   _flagp = CM_ABNF_FLAGP((_elmDef)->flagp, _pOff);          \
   if (CM_ABNF_TKNPRES(_event) == NOTPRSNT)                  \
   {                                                         \
      *(_event) += (_elmDef)->evSize;                        \
      if (_flagp & CM_ABNF_OPTIONAL)                          \
      {                                                      \
         RETVALUE(CM_ABNF_ROK);                              \
      }                                                      \
      else                                                   \
      {                                                      \
         (_err)->code  = CM_ABNF_ERR_TKN_NOTPRST;            \
         (_err)->idNum = (_elmDef)->idNum;                   \
         RETVALUE(CM_ABNF_RFAILED);                          \
      }                                                      \
   }                                                         \
}

#define CM_ABNF_TKNNUMPRES_CHK(_pOff, _event, _elmDef, _err) \
{                                                            \
   U32 _flagp;                                               \
   _flagp = CM_ABNF_FLAGP((_elmDef)->flagp, _pOff);          \
   if ((CM_ABNF_TKNPRES(_event) == NOTPRSNT) ||              \
       (CM_ABNF_TKNNUMVAL(_event) < 1))                      \
   {                                                         \
      *(_event) += (_elmDef)->evSize;                        \
      if (_flagp & CM_ABNF_OPTIONAL)                         \
      {                                                      \
         RETVALUE(CM_ABNF_ROK);                              \
      }                                                      \
      else                                                   \
      {                                                      \
         (_err)->code  = CM_ABNF_ERR_TKN_NOTPRST;            \
         (_err)->idNum = (_elmDef)->idNum;                   \
         RETVALUE(CM_ABNF_RFAILED);                          \
      }                                                      \
   }                                                         \
}

#define CM_REGEXP_OPT_CHK(_pOff, _event, _def, _err, _index) \
{                                                            \
   U32 _flagp;                                               \
   _flagp = CM_ABNF_FLAGP((_def)->flagp, _pOff);             \
   if (_index < 0)                                           \
   {                                                         \
      /* regexp match failed */                              \
       *_event += (_def)->evSize;                            \
       if (_flagp & CM_ABNF_OPTIONAL)                         \
          RETVALUE(CM_ABNF_ROPT);                            \
       else                                                  \
       {                                                     \
         (_err)->idNum = (_def)->idNum;                      \
         (_err)->code = CM_ABNF_ERR_PARSE;                   \
          RETVALUE(CM_ABNF_RFAILED);                         \
       }                                                     \
   }                                                         \
}
#else /* not CM_ABNF_V_1_2 */
#define CM_ABNF_TKNPRES_CHK(_event, _elmDef, _err)           \
{                                                            \
   if (CM_ABNF_TKNPRES(_event) == NOTPRSNT)                  \
   {                                                         \
      *(_event) += (_elmDef)->evSize;                        \
      if ((_elmDef)->flagp & CM_ABNF_OPTIONAL)               \
      {                                                      \
         RETVALUE(CM_ABNF_ROK);                              \
      }                                                      \
      else                                                   \
      {                                                      \
         (_err)->code  = CM_ABNF_ERR_TKN_NOTPRST;            \
         (_err)->idNum = (_elmDef)->idNum;                   \
         RETVALUE(CM_ABNF_RFAILED);                          \
      }                                                      \
   }                                                         \
}
#define CM_ABNF_TKNNUMPRES_CHK(_event, _elmDef, _err)        \
{                                                            \
   if ((CM_ABNF_TKNPRES(_event) == NOTPRSNT) ||              \
       (CM_ABNF_TKNNUMVAL(_event) < 1))                      \
   {                                                         \
      *(_event) += (_elmDef)->evSize;                        \
      if ((_elmDef)->flagp & CM_ABNF_OPTIONAL)               \
      {                                                      \
         RETVALUE(CM_ABNF_ROK);                              \
      }                                                      \
      else                                                   \
      {                                                      \
         (_err)->code  = CM_ABNF_ERR_TKN_NOTPRST;            \
         (_err)->idNum = (_elmDef)->idNum;                   \
         RETVALUE(CM_ABNF_RFAILED);                          \
      }                                                      \
   }                                                         \
}
#define  CM_REGEXP_OPT_CHK(_event, _def, _err, _index)       \
{                                                            \
   if (_index < 0)                                           \
   {                                                         \
      /* regexp match failed */                              \
       *_event += (_def)->evSize;                            \
       if ((_def)->flagp & CM_ABNF_OPTIONAL)                 \
          RETVALUE(CM_ABNF_ROPT);                            \
       else                                                  \
       {                                                     \
         (_err)->idNum = (_def)->idNum;                      \
         (_err)->code = CM_ABNF_ERR_PARSE;                   \
          RETVALUE(CM_ABNF_RFAILED);                         \
       }                                                     \
   }                                                         \
}
#endif /* CM_ABNF_V_1_2 */

PUBLIC Txt cmAbnfPrntBuf[1000];
/****************************************************************************
                  Routines for encoding message
****************************************************************************/

/*
*
*       Fun:   cmAbnfEncChoiceElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type choice
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncChoiceElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncChoiceElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   CmAbnfElmDef *def;
   U8           indx;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeChoice *chcElmnt = (CmAbnfElmTypeChoice *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncChoiceElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err); 
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   indx = CM_ABNF_TKNU8VAL(event);

   if ((chcElmnt->numIdx) && (indx > chcElmnt->numIdx))
   {
      /* Increment the event pointer before returning error */
      *event += elmDef->evSize;
      encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* 
    * Store the event pointer and pass the tmpEvt which will be 
    * modified by the corrsponding element as we traversed down the
    * sub trees.
    */
   *tmpEvt = *event;
   *event += elmDef->evSize;

   if (chcElmnt->numIdx)
   { 
      if (indx >= chcElmnt->numIdx)
      {
         encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
         encCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
    }
   else if (indx >= chcElmnt->numElmnt)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
    
   /* Call the ENUM element index by the TknU8 val */
   if (chcElmnt->enumElmnDef != NULLP)
   {
      def = chcElmnt->enumElmnDef[indx];
      if (def  && (cmAbnfEncEnumElmnt(tmpEvt, def, encCp, 0) != CM_ABNF_ROK))
         RETVALUE(CM_ABNF_RFAILED);
   }

   if ((chcElmnt->numIdx) && (chcElmnt->index != NULLP))
   {
      indx = chcElmnt->index[indx];
   }

   if (chcElmnt->elmnDef != NULLP)
   {
      def = chcElmnt->elmnDef[indx];
      if (def && cmAbnfEncMsg(tmpEvt, def, encCp, 0) 
            != CM_ABNF_ROK)
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
      
} /* cmAbnfEncChoiceElmnt */

/*
 * [TEL]: Added new function for U16 support
 */

/*
*
*       Fun:   cmAbnfEncU16ChoiceElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type U16choice
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncU16ChoiceElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncU16ChoiceElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   CmAbnfElmDef *def;
   S32          indx;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeU16Choice *chcElmnt =
                           (CmAbnfElmTypeU16Choice *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncU16ChoiceElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err); 
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   indx = CM_ABNF_TKNU16VAL(event);

   if ((chcElmnt->numIdx) && (indx > chcElmnt->numIdx))
   {
      /* Increment the event pointer before returning error */
      *event += elmDef->evSize;
      encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* 
    * Store the event pointer and pass the tmpEvt which will be 
    * modified by the corrsponding element as we traversed down the
    * sub trees.
    */
   *tmpEvt = *event;
   *event += elmDef->evSize;

   if (chcElmnt->numIdx)
   { 
      if (indx >= chcElmnt->numIdx)
      {
         encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
         encCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
    }
   else if (indx >= chcElmnt->numElmnt)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
    
   /* Call the ENUM element index by the TknU16 val */
   if (chcElmnt->enumElmnDef != NULLP)
   {
      def = chcElmnt->enumElmnDef[indx];
      if (def  && (cmAbnfEncU16EnumElmnt(tmpEvt, def, encCp, 0) != CM_ABNF_ROK))
         RETVALUE(CM_ABNF_RFAILED);
   }

   if ((chcElmnt->numIdx) && (chcElmnt->index != NULLP))
   {
      indx = chcElmnt->index[indx];
   }

   if (chcElmnt->elmnDef != NULLP)
   {
      def = chcElmnt->elmnDef[indx];
      if (def && cmAbnfEncMsg(tmpEvt, def, encCp, 0) 
            != CM_ABNF_ROK)
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
      
} /* cmAbnfEncU16ChoiceElmnt */


/*
*
*       Fun:   cmAbnfEncSeqElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type seq
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncSeqElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncSeqElmnt (event, elmDef, encCp, err, numSkip) 
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
CmAbnfErr     *err;       /* error to be returned back to the caller */ 
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U16          i;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncSeqElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   *tmpEvt = *event;
   *event += elmDef->evSize;
   *tmpEvt += sizeof(TknPres);

   for (i =0; i <  seqElmnt->numElmnt; i++)
   {
      def = seqElmnt->elmnDef[i];
      if (cmAbnfEncMsg(tmpEvt, def, encCp, 0) != CM_ABNF_ROK)
        RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncSeqElmnt */


/*
*
*       Fun:   cmAbnfEncOptSeqElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type OptSeq
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncOptSeqElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncOptSeqElmnt (event, elmDef, encCp, err, numSkip) 
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
CmAbnfErr     *err;       /* error to be returned back to the caller */ 
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U16          i;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   U32          flagp;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncOptSeqElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

   *tmpEvt = *event;
   *event += elmDef->evSize;

   if (CM_ABNF_TKNPRES(tmpEvt) == NOTPRSNT)
   {
      flagp = CM_ABNF_FLAGP(elmDef->flagp, encCp->protOffset);
      if (flagp & CM_ABNF_MANDATORY)
      {
         U8 j;
         U8 *childEvt = *tmpEvt;
         def = NULLP;
         for (j = 0; j < seqElmnt->numElmnt; j++)
         {
            def = seqElmnt->elmnDef[j];
            if (def->elmnType != CM_ABNF_TYPE_META &&
                def->elmnType != CM_ABNF_TYPE_SKIP &&
                def->elmnType != CM_ABNF_TYPE_MARKER)
            {
               break;
            }
            childEvt += def->evSize;
         }
         if (j != seqElmnt->numElmnt)
         {
            flagp = CM_ABNF_FLAGP(def->flagp, encCp->protOffset);
            if (flagp & CM_ABNF_MANDATORY && 
               CM_ABNF_TKNPRES(&childEvt) == NOTPRSNT)
            {
               if (def->elmnType != CM_ABNF_TYPE_OPTSEQ)
               {
                  encCp->err->code = CM_ABNF_ERR_ENCPARAM;
                  encCp->err->idNum = def->idNum;
                  RETVALUE(CM_ABNF_RFAILED);
               }
            }
         }
      }
      else if (flagp & CM_ABNF_OPTIONAL)
      {
         U8 j;
         U8 *childEvt = *tmpEvt;
         def = NULLP;
         for (j = 0; j < seqElmnt->numElmnt; j++)
         {
            def = seqElmnt->elmnDef[j];
            if (def->elmnType != CM_ABNF_TYPE_META &&
                def->elmnType != CM_ABNF_TYPE_SKIP &&
                def->elmnType != CM_ABNF_TYPE_MARKER)
            {
               break;
            }
            childEvt += def->evSize;
         }
         if (j != seqElmnt->numElmnt && CM_ABNF_TKNPRES(&childEvt) == NOTPRSNT)
         {
            RETVALUE(CM_ABNF_ROK);
         }
      }
   }

   for (i =0; i <  seqElmnt->numElmnt; i++)
   {
      def = seqElmnt->elmnDef[i];
      if (cmAbnfEncMsg(tmpEvt, def, encCp, 0) != CM_ABNF_ROK)
        RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncOptSeqElmnt */


/*
*
*       Fun:   cmAbnfEncSetElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type set
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncSetElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncSetElmnt (event, elmDef, encCp, err, numSkip) 
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
CmAbnfErr     *err;       /* error to be returned back to the caller */ 
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U16          i;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmDef *sepDef;
   CmAbnfElmTypeSet *setElmnt = (CmAbnfElmTypeSet *)elmDef->typeSpecDef;
   U8           didEnc;

   TRC2(cmAbnfEncSetElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   *tmpEvt = *event;
   *event += elmDef->evSize;

   *tmpEvt += sizeof(TknPres);

   sepDef = setElmnt->sep;
   didEnc = 0;
   for (i = 0; i < setElmnt->numElmnt; i++)
   {
      def = setElmnt->elmnDef[i];
      if (CM_ABNF_TKNPRES(tmpEvt))
      {
         if (didEnc && sepDef != NULLP)
         {
            if (cmAbnfEncMsg(tmpEvt, sepDef, encCp, 0) != CM_ABNF_ROK)
               RETVALUE(CM_ABNF_RFAILED);
         }
         if (cmAbnfEncMsg(tmpEvt, def, encCp, 0) != CM_ABNF_ROK)
            RETVALUE(CM_ABNF_RFAILED);
         didEnc++;
      }
      else
      {
         *tmpEvt += def->evSize;
      }
   }
   /* 001.main_3 Changed ;Encode should fail if none of the element is 
    * present */
   /* Atleast one element should be present */
   if(didEnc > 0)
      RETVALUE(CM_ABNF_ROK);
   else
      RETVALUE(CM_ABNF_RFAILED);

} /* cmAbnfEncSetElmnt */


/*
*
*       Fun:   cmAbnfEncMarkerElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type marker
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncMarkerElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp      /* Encode control point */
)
#else
PRIVATE S16 cmAbnfEncMarkerElmnt (event, elmDef, encCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
#endif
{                                               
   S16          ret;
   CmAbnfElmTypeMarker *markerElmnt = 
      (CmAbnfElmTypeMarker *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncMarkerElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

   *event += elmDef->evSize;
   switch (markerElmnt->type)
   {
      case CM_ABNF_MARKER_SDP_BEGIN:
      {
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
         encCp->protOffset = CM_ABNF_FIND_SDP_OFFSET(encCp->protVar);
#endif /* CM_ABNF_V_1_2 */
         break;
      }
      case CM_ABNF_MARKER_SDP_END:
      {
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
         encCp->protOffset = CM_ABNF_FIND_PROT_OFFSET(encCp->protVar);
#endif /* CM_ABNF_V_1_2 */
         break;
      }
      case CM_ABNF_MARKER_ESC_FUNC:
      {
         cmAbnfEscFunc *func = (cmAbnfEscFunc *) markerElmnt->info;
         if ((ret = cmAbnfEncChainLastDBuf(encCp)) != CM_ABNF_ROK)
            RETVALUE(ret);
         *event -= elmDef->evSize; /* usually 0 for marker */
         ret = (*func)(CM_ABNF_ENCODE_PATH, encCp->mBuf, 
               event,
            elmDef->idNum, NULLP, encCp);   /* 001.main_6 */
         if (ret != ROK)
            RETVALUE(CM_ABNF_RFAILED);
         break;
      }
      default:
         break;
   }

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncMarkerElmnt */


/*
*
*       Fun:   cmAbnfEncOptseqOfElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type optional
*              sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
S16 cmAbnfEncOptSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
S16 cmAbnfEncOptSeqOfElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncOptSeqOfElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNNUMPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNNUMPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */


#if (ERRCLASS & ERRCLS_DEBUG)
   if ((seqElmnt->numElmnt > 2) ||
       (seqElmnt->elmnDef[0] == NULLP))
   {
      *event += elmDef->evSize;
      encCp->err->code  = CM_ABNF_ERR_DBELMNT;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* The second elment must be of type sequece of */
   if ((seqElmnt->elmnDef[1] == NULLP) || 
       (((seqElmnt->elmnDef[1])->elmnType != CM_ABNF_TYPE_SEQOF) &&
        ((seqElmnt->elmnDef[1])->elmnType != CM_ABNF_TYPE_STA_SEQOF)))
   {
      *event += elmDef->evSize;
      encCp->err->code  = CM_ABNF_ERR_DBELMNT;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *tmpEvt += sizeof(TknU16);

   if (elmDef->elmnType == CM_ABNF_TYPE_OPTSEQOF)
   { 
         /* Not decipherable */
      /* We're trying to encode X **ptr. tmpEvt = &&ptr, *tmpEvt == &ptr,
       * *((PTR *)*tmpEvt) == ptr, ((PTR *)(*((PTR *)*tmpEvt)))[0] == ptr[0],
       * so finally, *tmpEvt gets (U8 *)ptr[0].
       */

      *tmpEvt = (U8 *)(((PTR *)(*((PTR *)(*tmpEvt))))[0]); 
   }

   if (cmAbnfEncMsg(tmpEvt, (seqElmnt->elmnDef[0]), encCp, 0) 
         != CM_ABNF_ROK)
   {
      *event += elmDef->evSize;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* Reset the tmpEvt */
   *tmpEvt = *event;
   *event += elmDef->evSize;

   /* 
    * Check if the number of element is one. If so, no point of going
    *  down the database tree from this point 
    */
   if (CM_ABNF_TKNNUMVAL(tmpEvt) == 1)
      RETVALUE(CM_ABNF_ROK);

   if (cmAbnfEncMsg(tmpEvt, (seqElmnt->elmnDef[1]), encCp, 1) 
         != CM_ABNF_ROK)
      RETVALUE(CM_ABNF_RFAILED);

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncOptSeqOfElmnt */


/*
*
*       Fun:   cmAbnfEncCondSeqOfElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type 
*              conditional sequenceof.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncCondSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncCondSeqOfElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U16    i;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncCondSeqOfElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNNUMPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNNUMPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */


   *tmpEvt = *event;

   *event += elmDef->evSize;
   for (i =0; i <  seqElmnt->numElmnt; i++)
   {
      if (cmAbnfEncMsg(tmpEvt, (seqElmnt->elmnDef[i]), encCp, 0) 
            != CM_ABNF_ROK)
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncCondSeqOfElmnt */


/*
*
*       Fun:   cmAbnfEncSeqOfElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncSeqOfElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8           *evt;
   U8           **tmpEvt = &evt;
   U16          num;
   U16          i;
   U8           j;
   
   CmAbnfElmTypeSeqOf *seqOfElmnt = (CmAbnfElmTypeSeqOf *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncSeqOfElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNNUMPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNNUMPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   num = (U16)CM_ABNF_TKNNUMVAL(event);

   if ((num < seqOfElmnt->min) || (num > seqOfElmnt->max))
   {
      *event += (elmDef->evSize);
      if (num < seqOfElmnt->min)
         encCp->err->code  = CM_ABNF_ERR_SEQOFELM_LESS;
      else
         encCp->err->code  = CM_ABNF_ERR_SEQOFELM_MORE;
      encCp->err->idNum = elmDef->idNum;  
      RETVALUE(CM_ABNF_RFAILED);
   } 

   *event += sizeof(TknU16);
   *tmpEvt = *event;

   if (elmDef->elmnType == CM_ABNF_TYPE_STA_SEQOF)
   {

      if (numSkip)
      {
         for (i = 0; i < numSkip; i++)
         {
            for (j = 0; j < seqOfElmnt->numElmnt; j++)
            {
               if (cmAbnfEncSkipElmnt(tmpEvt, 
                                     (seqOfElmnt->elmnDef[j])) != CM_ABNF_ROK)
               {
                  *event += ((elmDef->evSize) - sizeof(TknU16));
                  RETVALUE(CM_ABNF_RFAILED);
               }
            }
         }
       } /* if (numSkip) */
   }

   for (i = numSkip; i < num; i++)
   {
      if (elmDef->elmnType == CM_ABNF_TYPE_SEQOF)
      { 
         /* Not decipherable */
         /* We're trying to encode X **ptr. event = &&ptr, *event == &ptr,
         * *((PTR *)*event) == ptr, ((PTR *)(*((PTR *)*event)))[i] == ptr[i],
         * so finally, *tmpEvt gets (U8 *)ptr[i].
         */
         *tmpEvt = (U8 *)(((PTR *)(*((PTR *)(*event))))[i]); 
      }

      for (j = 0; j < seqOfElmnt->numElmnt; j++)
      {
         if (cmAbnfEncMsg(tmpEvt,
                          (seqOfElmnt->elmnDef[j]), encCp, 0) != CM_ABNF_ROK)
         {
            *event += ((elmDef->evSize) - sizeof(TknU16));
            RETVALUE(CM_ABNF_RFAILED);
         }
      }

      /* 
       * Set the event pointer accordingly. Only required for double pointer 
       * array. Fot the case static array, the event pointer will be 
       * automatically incremented.
       */
   }

   *event += ((elmDef->evSize) - sizeof(TknU16));

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncSeqOfElmnt */


/*
*
*       Fun:   cmAbnfEncChSeqOfElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type choice
*              sequenceof.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncChSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncChSeqOfElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8           num;
   U8           *evt;
   U8           isSta = 0;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncChSeqOfElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNNUMPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNNUMPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   num = (U8)CM_ABNF_TKNNUMVAL(event);

   *tmpEvt = *event;

   if (num <= 1)
   {
      U8 found = 0;
      U8 i;
      CmAbnfElmDef *tmpDef;
      def = seqElmnt->elmnDef[1];
#if (ERRCLASS & ERRCLS_DEBUG)
      if (def == NULLP)
      {
         *event += elmDef->evSize;
         encCp->err->code  = CM_ABNF_ERR_DBELMNT;
         encCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
#endif /* ERRCLASS & ERRCLS_DEBUG */
      if (def->elmnType != CM_ABNF_TYPE_CONDSEQOF)
      {
         *event += elmDef->evSize;
         encCp->err->code  = CM_ABNF_ERR_DBELMNT;
         encCp->err->idNum = def->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
      for (i = 0; !found && 
         i < ((CmAbnfElmTypeSeq *)(def->typeSpecDef))->numElmnt; i++)
      {
         tmpDef = ((CmAbnfElmTypeSeq *)(def->typeSpecDef))->elmnDef[i];
         if (tmpDef->elmnType == CM_ABNF_TYPE_STA_OPTSEQOF ||
             tmpDef->elmnType == CM_ABNF_TYPE_STA_SEQOF)
         {
            isSta = 1;
            found = 1;
         }
         else if (tmpDef->elmnType == CM_ABNF_TYPE_OPTSEQOF ||
                  tmpDef->elmnType == CM_ABNF_TYPE_SEQOF)
         {
            isSta = 0;
            found = 1;
         }
      }
      if (!found)
      {
         *event += elmDef->evSize;
         encCp->err->code  = CM_ABNF_ERR_DBELMNT;
         encCp->err->idNum = def->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
      def = seqElmnt->elmnDef[0];
      *tmpEvt = (*tmpEvt) + sizeof(TknU16);
      if (!isSta)
      {
         *tmpEvt = (U8 *)(((PTR *)(*((PTR *)(*tmpEvt))))[0]); 
      }
   }
   else
   {
      def = seqElmnt->elmnDef[1];
#if (ERRCLASS & ERRCLS_DEBUG)
      if (def == NULLP)
      {
         *event += elmDef->evSize;
         encCp->err->code  = CM_ABNF_ERR_DBELMNT;
         encCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   }
   if (cmAbnfEncMsg(tmpEvt, def, encCp,  0) != CM_ABNF_ROK)
   {
      *event += elmDef->evSize;
      RETVALUE(CM_ABNF_RFAILED);
   }
  *event += elmDef->evSize;
  RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncChSeqOfElmnt */


/*
*
*       Fun:   cmAbnfEncMetaElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type meta
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncMetaElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncMetaElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{
   U8  len;
   Data *str;

   TRC2(cmAbnfEncMetaElmnt)
   UNUSED(numSkip);
   UNUSED(event);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (((CmAbnfElmTypeMeta *)elmDef->typeSpecDef) == NULLP)
   {
      encCp->err->code  = CM_ABNF_ERR_DBELMNT;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   str = ((CmAbnfElmTypeMeta *)elmDef->typeSpecDef)->str;

  /* Do not emit the meta charachter if optional */
  /* TODO (For OptCOMMA etc) */
  if ((CM_ABNF_FLAGP(elmDef->flagp, encCp->protOffset)) & CM_ABNF_OPTIONAL)
     RETVALUE(CM_ABNF_ROK);

   CM_ABNF_STRLEN(str, len);

   if (cmAbnfEncOut2Buf(encCp, str, len) != CM_ABNF_ROK)
   {
      encCp->err->code = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
   
} /* cmAbnfEncMetaElmnt */


/*
*
*       Fun:   cmAbnfEncEnumElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type enum
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncEnumElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncEnumElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{
   U8  len;
   CmAbnfElmTypeEnum *enumElmnt = (CmAbnfElmTypeEnum *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncEnumElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

   *event += elmDef->evSize;

   if (enumElmnt->str == NULLP)
      RETVALUE(CM_ABNF_ROK);

   CM_ABNF_STRLEN(enumElmnt->str, len);

   if (cmAbnfEncOut2Buf(encCp, enumElmnt->str, len) != CM_ABNF_ROK)
   {
      encCp->err->code = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
   
} /* cmAbnfEncEnumElmnt */

/*
 * [TEL]: Added new function for U16 support
 */

/*
*
*       Fun:   cmAbnfEncU16EnumElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type enum
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncU16EnumElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncU16EnumElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{
   U8  len;
   CmAbnfElmTypeU16Enum *enumElmnt =
                         (CmAbnfElmTypeU16Enum *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncU16EnumElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

   *event += elmDef->evSize;

   if (enumElmnt->str == NULLP)
      RETVALUE(CM_ABNF_ROK);

   CM_ABNF_STRLEN(enumElmnt->str, len);

   if (cmAbnfEncOut2Buf(encCp, enumElmnt->str, len) != CM_ABNF_ROK)
   {
      encCp->err->code = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
   
} /* cmAbnfEncU16EnumElmnt */




/*
*
*       Fun:   cmAbnfEncSintElmnt 
*
*       Desc:  This function encodes Element definition elemnt of type uint
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncSintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncSintElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8  len;
   S32 val;
   Data abnfStr[CM_ABNF_MAX_UINTSZ];
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeSIntRange *range = (CmAbnfElmTypeSIntRange *)elmDef->typeSpecDef;
#else /* CM_ABNF_V_1_2 defined */
   CmAbnfElmTypeRange *range= (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfEncSintElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_SINT8:
         val = CM_ABNF_TKNS8VAL(event);
         break;

      case CM_ABNF_TYPE_SINT16:
         val = CM_ABNF_TKNS16VAL(event);
         break;

      case CM_ABNF_TYPE_SINT32:
         val = CM_ABNF_TKNS32VAL(event);
         break;
   } 

#ifdef CM_ABNF_V_1_2
   if ((range->minVal && val < range->minVal) || val > range->maxVal)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* CM_ABNF_V_1_2 */
   
   CM_ABNF_SI2A(val, abnfStr, len);
   *event += elmDef->evSize;

#ifdef CM_ABNF_V_1_2

   if (len > range->maxLen)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if (len < range->minLen)
   {
      U8 i;
      for (i = len + 1; i <= range->minLen; i++)
      {
         abnfStr[CM_ABNF_MAX_UINTSZ - i] = '0';
      }
      len = (U8)(range->minLen);
   }

#else /* !CM_ABNF_V_1_2 */

   if (len > range->max)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if (len < range->min)
   {
      U8 i;
      for (i = len + 1; i <= range->min; i++)
      {
         abnfStr[CM_ABNF_MAX_UINTSZ - i] = '0';
      }
      len = range->min;
   }
#endif /* CM_ABNF_V_1_2 */
  
   if (cmAbnfEncOut2Buf(encCp, &(abnfStr[CM_ABNF_MAX_UINTSZ - len]), 
                               len) != CM_ABNF_ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK); 

} /* cmAbnfEncSintElmnt */


/*
*
*       Fun:   cmAbnfEncUintElmnt 
*
*       Desc:  This function encodes Element definition elemnt of type uint
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncUintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncUintElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8  len;
   U32 val;
   Data abnfStr[CM_ABNF_MAX_UINTSZ];
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeIntRange *range = (CmAbnfElmTypeIntRange *)elmDef->typeSpecDef;
#else /* CM_ABNF_V_1_2 defined */
   CmAbnfElmTypeRange *range= (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfEncUintElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_UINT8:
         val = CM_ABNF_TKNU8VAL(event);
         break;

      case CM_ABNF_TYPE_UINT16:
         val = CM_ABNF_TKNU16VAL(event);
         break;

      case CM_ABNF_TYPE_UINT32:
         val = CM_ABNF_TKNU32VAL(event);
         break;
   } 

#ifdef CM_ABNF_V_1_2
   if ((range->minVal && val < range->minVal) || val > range->maxVal)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* CM_ABNF_V_1_2 */
   
   CM_ABNF_I2A(val, abnfStr, len);
   *event += elmDef->evSize;

#ifdef CM_ABNF_V_1_2

   if (len > range->maxLen)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if (len < range->minLen)
   {
      U8 i;
      for (i = len + 1; i <= range->minLen; i++)
      {
         abnfStr[CM_ABNF_MAX_UINTSZ - i] = '0';
      }
      len = (U8)(range->minLen);
   }

#else /* !CM_ABNF_V_1_2 */

   if (len > range->max)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if (len < range->min)
   {
      U8 i;
      for (i = len + 1; i <= range->min; i++)
      {
         abnfStr[CM_ABNF_MAX_UINTSZ - i] = '0';
      }
      len = range->min;
   }
#endif /* CM_ABNF_V_1_2 */
  
   if (cmAbnfEncOut2Buf(encCp, &(abnfStr[CM_ABNF_MAX_UINTSZ - len]), 
                               len) != CM_ABNF_ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK); 

} /* cmAbnfEncUintElmnt */



/*
*
*       Fun:   cmAbnfEncHexSintElmnt 
*
*       Desc:  This function encodes Element definition elemnt of type hexint
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncHexSintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncHexSintElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8  len;
   S32 val;
   Data abnfStr[CM_ABNF_MAX_HEXUINTSZ];
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeSIntRange *range = (CmAbnfElmTypeSIntRange *)elmDef->typeSpecDef;
#else /* !CM_ABNF_V_1_2 */
   CmAbnfElmTypeRange *range= (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfEncHexSintElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_HEXSINT8:
         val = CM_ABNF_TKNS8VAL(event);
         break;

      case CM_ABNF_TYPE_HEXSINT16:
         val = CM_ABNF_TKNS16VAL(event);
         break;

      case CM_ABNF_TYPE_HEXSINT32:
         val = CM_ABNF_TKNS32VAL(event);
         break;
   } 

#ifdef CM_ABNF_V_1_2

   if ((range->minVal && val < range->minVal) || val > range->maxVal)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

#endif /* CM_ABNF_V_1_2 */

   CM_ABNF_SH2A(val, abnfStr, len);

   *event += elmDef->evSize;

#ifdef CM_ABNF_V_1_2

   if (len > range->maxLen)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
  
   if (len < range->minLen)
   {
      U8 i;
      for (i = len + 1; i <= range->minLen; i++)
      {
         abnfStr[CM_ABNF_MAX_HEXUINTSZ - i] = '0';
      }
      len = (U8)(range->minLen);
   }

#else /* !CM_ABNF_V_1_2 */

   if (len > range->max)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
  
   if (len < range->min)
   {
      U8 i;
      for (i = len + 1; i <= range->min; i++)
      {
         abnfStr[CM_ABNF_MAX_HEXUINTSZ - i] = '0';
      }
      len = range->min;
   }

#endif /* CM_ABNF_V_1_2 */

   if (cmAbnfEncOut2Buf(encCp, &(abnfStr[CM_ABNF_MAX_HEXUINTSZ - len]), 
                               len) != CM_ABNF_ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK); 

} /* cmAbnfEncHexSintElmnt */


/*
*
*       Fun:   cmAbnfEncHexUintElmnt 
*
*       Desc:  This function encodes Element definition elemnt of type hexint
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncHexUintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncHexUintElmnt (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8  len;
   U32 val;
   Data abnfStr[CM_ABNF_MAX_HEXUINTSZ];
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeIntRange *range = (CmAbnfElmTypeIntRange *)elmDef->typeSpecDef;
#else /* !CM_ABNF_V_1_2 */
   CmAbnfElmTypeRange *range= (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfEncHexUintElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_HEXUINT8:
         val = CM_ABNF_TKNU8VAL(event);
         break;

      case CM_ABNF_TYPE_HEXUINT16:
         val = CM_ABNF_TKNU16VAL(event);
         break;

      case CM_ABNF_TYPE_HEXUINT32:
         val = CM_ABNF_TKNU32VAL(event);
         break;
   } 

#ifdef CM_ABNF_V_1_2

   if ((range->minVal && val < range->minVal) || val > range->maxVal)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

#endif /* CM_ABNF_V_1_2 */

   CM_ABNF_H2A(val, abnfStr, len);

   *event += elmDef->evSize;

#ifdef CM_ABNF_V_1_2

   if (len > range->maxLen)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
  
   if (len < range->minLen)
   {
      U8 i;
      for (i = len + 1; i <= range->minLen; i++)
      {
         abnfStr[CM_ABNF_MAX_HEXUINTSZ - i] = '0';
      }
      len = (U8)(range->minLen);
   }

#else /* !CM_ABNF_V_1_2 */

   if (len > range->max)
   {
      encCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
  
   if (len < range->min)
   {
      U8 i;
      for (i = len + 1; i <= range->min; i++)
      {
         abnfStr[CM_ABNF_MAX_HEXUINTSZ - i] = '0';
      }
      len = range->min;
   }

#endif /* CM_ABNF_V_1_2 */

   if (cmAbnfEncOut2Buf(encCp, &(abnfStr[CM_ABNF_MAX_HEXUINTSZ - len]), 
                               len) != CM_ABNF_ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK); 

} /* cmAbnfEncHexUintElmnt */


/*
*
*       Fun:   cmAbnfEncSkipElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type skip
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
S16 cmAbnfEncSkipElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef     /* message defintion */
)
#else
S16 cmAbnfEncSkipElmnt (event, elmDef)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
#endif
{                                               
   TRC2(cmAbnfEncSkipElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, (CmAbnfEncCp *)NULLP);

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncSkipElmnt */


/*
*
*       Fun:   cmAbnfEncOctStrElmnt 
*
*       Desc:  This function encodes Elemnt definition elemnt of type octect
*              string. 
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncOctStrElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
PRIVATE S16 cmAbnfEncOctStrElmnt (event, elmDef, encCp,  numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{                                               
   U8   *val;
   U16  len;
   CmAbnfElmTypeRange *range= (CmAbnfElmTypeRange *)elmDef->typeSpecDef;

   TRC2(cmAbnfEncOctStrElmnt)
   UNUSED(numSkip);

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */


   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_OCTSTR8:
         val = CM_ABNF_TKNSTR8VAL(event);
         len = CM_ABNF_TKNSTR8LEN(event);
         break;

      case CM_ABNF_TYPE_OCTSTR32:
         val = CM_ABNF_TKNSTR32VAL(event);
         len = CM_ABNF_TKNSTR32LEN(event);
         break;

      case CM_ABNF_TYPE_OCTSTRXL:
         val = CM_ABNF_TKNSTRXLVAL(event);
         len = CM_ABNF_TKNSTRXLLEN(event);
         break;
   }
 
   *event += elmDef->evSize;
   if ((len < range->min) || (len > range->max))
   {
      encCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if (cmAbnfEncOut2Buf(encCp, val, len) != CM_ABNF_ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_ENCPARAM;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncOctStrElmnt */


/*
*
*       Fun:   cmAbnfEncTknBufElmnt 
*
*       Desc:  This function encodes Element definition elemnt of type TknBuf.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfEncTknBufElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp      /* Encode control point */
)
#else
PRIVATE S16 cmAbnfEncTknBufElmnt (event, elmDef, encCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
#endif
{                                               
   Buffer *tknBufVal;
   Buffer *mToAttach;
   Region region;
   Pool   pool;
   U8     *evt;

   TRC2(cmAbnfEncTknBufElmnt)

   CM_ABNF_ENC_DBGP(event, elmDef, encCp);

#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   CM_ABNF_TKNPRES_CHK(encCp->protOffset, event, elmDef, encCp->err);
#else /* not CM_ABNF_V_1_2 */
   CM_ABNF_TKNPRES_CHK(event, elmDef, encCp->err);
#endif /* CM_ABNF_V_1_2 */

   evt = *event;
   tknBufVal = ((TknBuf *)evt)->val;
   *event += elmDef->evSize;

   /* Encode in our current mBuf */
   /* First, flush current dBuf */
   if (cmAbnfEncChainLastDBuf(encCp) != ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_RESFAIL;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
   if (SGetBufRegionPool(encCp->mBuf, &region, &pool) != ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_RESFAIL;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
   mToAttach = (Buffer *)NULLP;
   if (tknBufVal != (Buffer *)NULLP && 
       (SCpyMsgMsg(tknBufVal, region, pool, &mToAttach) != ROK))
   {
      encCp->err->code  = CM_ABNF_ERR_RESFAIL;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
   if (SCatMsg(encCp->mBuf, mToAttach, M1M2) != ROK)
   {
      encCp->err->code  = CM_ABNF_ERR_RESFAIL;
      encCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
   (Void)SPutMsg(mToAttach);
   (Void)SPutMsg(tknBufVal);
   ((TknBuf *)evt)->val = (Buffer *)NULLP;
   encCp->offset->dBuf = NULLP;

   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfEncTknBufElmnt */


/*
*
*       Fun:   cmAbnfEncMsg 
*
*       Desc:  This function encodes the message by encoding all the token
*              elements it contains.  
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
S16 cmAbnfEncMsg 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfEncCp   *encCp,     /* Encode control point */
U16           numSkip     /* number of elements to be skipped */
)
#else
S16 cmAbnfEncMsg (event, elmDef, encCp, numSkip)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfEncCp   *encCp;     /* Encode control point */
U16           numSkip;    /* number of elements to be skipped */
#endif
{
   S16  ret = CM_ABNF_ROK;

   TRC2(cmAbnfEncMsg)

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_CHOICE:
         ret = cmAbnfEncChoiceElmnt(event, elmDef, encCp, numSkip);
         break;

      /*
       * [TEL]: Added new case for U16 support
       */
      case CM_ABNF_TYPE_CHOICE_U16:
         ret = cmAbnfEncU16ChoiceElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_SET:
          ret = cmAbnfEncSetElmnt(event, elmDef, encCp, numSkip);
          break;

      case CM_ABNF_TYPE_SEQ:
         ret = cmAbnfEncSeqElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_OPTSEQ:
         ret = cmAbnfEncOptSeqElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_STA_OPTSEQOF:
      case CM_ABNF_TYPE_OPTSEQOF:
         ret = cmAbnfEncOptSeqOfElmnt(event, elmDef, 
            encCp, numSkip);
         break;

      case CM_ABNF_TYPE_CONDSEQOF:
         ret = cmAbnfEncCondSeqOfElmnt(event, elmDef, 
            encCp, numSkip);
         break;

      case CM_ABNF_TYPE_STA_SEQOF:
      case CM_ABNF_TYPE_SEQOF:
         ret = cmAbnfEncSeqOfElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_CHSEQOF:
         ret = cmAbnfEncChSeqOfElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_META:
         ret = cmAbnfEncMetaElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_UINT8:
      case CM_ABNF_TYPE_UINT16:
      case CM_ABNF_TYPE_UINT32:
         ret = cmAbnfEncUintElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_SINT8:
      case CM_ABNF_TYPE_SINT16:
      case CM_ABNF_TYPE_SINT32:
         ret = cmAbnfEncSintElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_HEXUINT8:
      case CM_ABNF_TYPE_HEXUINT16:
      case CM_ABNF_TYPE_HEXUINT32:
         ret = cmAbnfEncHexUintElmnt(event, elmDef, encCp, numSkip);
         break;


      case CM_ABNF_TYPE_HEXSINT8:
      case CM_ABNF_TYPE_HEXSINT16:
      case CM_ABNF_TYPE_HEXSINT32:
         ret = cmAbnfEncHexSintElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_ENUM:
         ret = cmAbnfEncEnumElmnt(event, elmDef, encCp, numSkip);
         break;

      /*
       * [TEL]: Added new case for U16 support
       */
      case CM_ABNF_TYPE_ENUM_U16:
         ret = cmAbnfEncU16EnumElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_SKIP:
         ret = cmAbnfEncSkipElmnt(event, elmDef);
         break;

      case CM_ABNF_TYPE_OCTSTRXL:
      case CM_ABNF_TYPE_OCTSTR8:
      case CM_ABNF_TYPE_OCTSTR32:
         ret = cmAbnfEncOctStrElmnt(event, elmDef, encCp, numSkip);
         break;

      case CM_ABNF_TYPE_TKNBUF:
         ret = cmAbnfEncTknBufElmnt(event, elmDef, encCp);
         break;
      case CM_ABNF_TYPE_MARKER:
         ret = cmAbnfEncMarkerElmnt(event, elmDef, encCp);
         break;
   }

   RETVALUE(ret);
}


/*
*
*       Fun:   cmAbnfEncPduMsg 
*
*       Desc:  Encoding interface function.
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfEncPduMsg 
(
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
U32           protVar,    /* protocol and variant */
#endif /* CM_ABNF_V_1_2 */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
Mem           *memReg,    /* Memory: region/pool */
CmAbnfErr     *err        /* error to be returned back to the caller */ 
)
#else
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
PUBLIC S16 cmAbnfEncPduMsg (protVar, event, mBuf, elmDef, memReg,  err)
U32           protVar;    /* protocol and variant */
#else /* Not Version 1.2 */
PUBLIC S16 cmAbnfEncPduMsg (event, mBuf, elmDef, memReg,  err)
#endif /* CM_ABNF_V_1_2 */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
Mem           *memReg;    /* Memory: region/pool */
CmAbnfErr     *err;       /* error to be returned back to the caller */ 
#endif
{
   CmAbnfEncOff  offset;    
   CmAbnfEncCp   encCp;
   U8            *evt;
   U8            **tmpEvt = &evt;

   TRC2(cmAbnfEncPduMsg)

#if (ERRCLASS & ERRCLS_INT_PAR)
  if (err == NULLP)
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNF001, 0,
         "cmAbnfEncMsg() failed, Invalid err pointer");

   if ((mBuf == NULLP) || (event == NULLP) || (elmDef == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNF002, 0,
         "cmAbnfEncMsg() failed, Invalid parameters ");

      err->code = CM_ABNF_ERR_ENCPARAM;
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   cmMemset((U8 *)&encCp, (U8)0, (PTR)sizeof(CmAbnfEncCp));
   cmMemset((U8 *)&offset, (U8)0, (PTR)sizeof(CmAbnfEncOff));

   encCp.mBuf   = mBuf;
   encCp.offset = &offset;
   encCp.offset->region = memReg->region;
   encCp.offset->pool   = memReg->pool;
   encCp.err    = err;
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   encCp.protOffset   = CM_ABNF_FIND_PROT_OFFSET(protVar);
   encCp.protVar      = protVar;
#endif /* CM_ABNF_V_1_2 */

   *tmpEvt = event;

   if (cmAbnfEncMsg(tmpEvt, elmDef, &encCp, 0) != CM_ABNF_ROK)
   {
      /* remember that the last dbuf is not yet chained to mBuf */
      cmAbnfEncChainLastDBuf(&encCp);
      RETVALUE(RFAILED);
   }

   /* remember that the last dbuf is not yet chained to mBuf */
   if (cmAbnfEncChainLastDBuf(&encCp) != CM_ABNF_ROK)
      RETVALUE(RFAILED);

   err->code = CM_ABNF_ERR_NONE;  /* reset err code if decoding passed */
   RETVALUE(ROK);
} /* cmAbnfEncPduMsg */
 
/****************************************************************************
                  Routines for decoding message
****************************************************************************/

/*
*
*       Fun:   cmAbnfDecChoiceElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type choice
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecChoiceElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecChoiceElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   CmAbnfElmDef *def;
   S16          indx = -1;
   Bool         consumed;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeChoice *chcElmnt = (CmAbnfElmTypeChoice *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecChoiceElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   if (elmDef->regExp)
   {
      consumed = ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & 
         CM_ABNF_TKN_NOT_CONSUMED) ? FALSE : TRUE; 
      indx = (elmDef->regExp)(decCp, consumed, NULLP, NULLP);
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
      CM_REGEXP_OPT_CHK (decCp->protOffset, event, elmDef, decCp->err, indx); 
#else /* not CM_ABNF_V_1_2 */
      CM_REGEXP_OPT_CHK (event, elmDef, decCp->err, indx);
#endif /* CM_ABNF_V_1_2 */
    }

   if ((chcElmnt->numIdx) && (indx > chcElmnt->numIdx))
   {
      /* Increment the event pointer before returning error */
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* 
    * Store the event pointer and pass the tmpEvt which will be 
    * modified by the corrsponding element as we traversed down the
    * sub trees.
    */
   *tmpEvt = *event;
   *event += elmDef->evSize;
   

   /* Call the ENUM element index by the TknU8 val */
   if (chcElmnt->enumElmnDef != NULLP)
   {
      def = chcElmnt->enumElmnDef[(U16)indx];   /* 002.main_6 : change */
      if (def && (cmAbnfDecEnumElmnt(tmpEvt, def, decCp) == 
            CM_ABNF_RFAILED))
         RETVALUE(CM_ABNF_RFAILED);
   }

   if ((chcElmnt->numIdx) && (chcElmnt->index != NULLP))
   {
      indx = chcElmnt->index[(U16)indx];   /* 002.main_6 : change */
   }

   if (chcElmnt->elmnDef != NULLP)
   {
      def = chcElmnt->elmnDef[(U16)indx];  /* 002.main_6 : change */
      if (def && (cmAbnfDecMsg(tmpEvt, def, decCp) == 
            CM_ABNF_RFAILED))
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
      
} /* cmAbnfDecChoiceElmnt */

/*
 * [TEL]: Added new function for U16 support
 */

/*
*
*       Fun:   cmAbnfDecU16ChoiceElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type U16choice
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecU16ChoiceElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecU16ChoiceElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   CmAbnfElmDef *def;
   S32          indx = -1;
   Bool         consumed;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmTypeU16Choice *chcElmnt =
                           (CmAbnfElmTypeU16Choice *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecU16ChoiceElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   if (elmDef->regExp)
   {
      consumed = ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & 
         CM_ABNF_TKN_NOT_CONSUMED) ? FALSE : TRUE; 
      indx = (elmDef->regExp)(decCp, consumed, NULLP, NULLP);
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
      CM_REGEXP_OPT_CHK (decCp->protOffset, event, elmDef, decCp->err, indx); 
#else /* not CM_ABNF_V_1_2 */
      CM_REGEXP_OPT_CHK (event, elmDef, decCp->err, indx);
#endif /* CM_ABNF_V_1_2 */
    }

   if ((chcElmnt->numIdx) && (indx > chcElmnt->numIdx))
   {
      /* Increment the event pointer before returning error */
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_CHOICE;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   /* 
    * Store the event pointer and pass the tmpEvt which will be 
    * modified by the corrsponding element as we traversed down the
    * sub trees.
    */
   *tmpEvt = *event;
   *event += elmDef->evSize;
   

   /* Call the ENUM element index by the TknU16 val */
   if (chcElmnt->enumElmnDef != NULLP)
   {
      def = chcElmnt->enumElmnDef[(U32)indx];   /* 002.main_6 : change */
      if (def && (cmAbnfDecU16EnumElmnt(tmpEvt, def, decCp) == 
            CM_ABNF_RFAILED))
         RETVALUE(CM_ABNF_RFAILED);
   }

   if ((chcElmnt->numIdx) && (chcElmnt->index != NULLP))
   {
      indx = chcElmnt->index[(U32)indx];   /* 002.main_6 : change */
   }

   if (chcElmnt->elmnDef != NULLP)
   {
      def = chcElmnt->elmnDef[(U32)indx];  /* 002.main_6 : change */
      if (def && (cmAbnfDecMsg(tmpEvt, def, decCp) == 
            CM_ABNF_RFAILED))
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
      
} /* cmAbnfDecU16ChoiceElmnt */


/*
*
*       Fun:   cmAbnfDecSeqElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type sequence
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecSeqElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecSeqElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   U16          i;
   Bool         consumed;
   S16          indx = -1;   /* 002.main_6 : change */
   S16          ret;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecSeqElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   if (elmDef->regExp)
   {
      consumed = ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) 
         & CM_ABNF_TKN_NOT_CONSUMED) ? FALSE: TRUE; 
      indx = (elmDef->regExp)(decCp, consumed, NULLP, NULLP);
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
      CM_REGEXP_OPT_CHK (decCp->protOffset, event, elmDef, decCp->err, indx); 
#else /* not CM_ABNF_V_1_2 */
      CM_REGEXP_OPT_CHK (event, elmDef, decCp->err, indx);
#endif /* CM_ABNF_V_1_2 */
   }

   *tmpEvt = *event;
   *tmpEvt += sizeof(TknPres);

   for (i =0; i <  seqElmnt->numElmnt; i++)
   {
      def = seqElmnt->elmnDef[i];
      if ((ret = cmAbnfDecMsg(tmpEvt, def, decCp)) == 
            CM_ABNF_RFAILED)
      {
         *event += elmDef->evSize;
         RETVALUE(ret);
      }
      else if (ret == CM_ABNF_ROK)
         CM_ABNF_SET_TKNPRES(event);
   }

   if (CM_ABNF_TKNPRES(event)) 
   {
      *event += elmDef->evSize;
      RETVALUE(CM_ABNF_ROK);
   }
   else
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      { 
         decCp->err->idNum = elmDef->idNum;
         decCp->err->code  = CM_ABNF_ERR_SEQEMPTY;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }
} /* cmAbnfDecSeqElmnt */


/*
*
*       Fun:   cmAbnfDecSetElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type set
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecSetElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecSetElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   U16          i;
   S16          indx = -1;   /* 002.main_6 : change */
   S16          ret;
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmDef *sepDef;
   CmAbnfElmTypeSet *setElmnt = (CmAbnfElmTypeSet *)elmDef->typeSpecDef;
   CmAbnfElmDef **children;

   TRC2(cmAbnfDecSetElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   if (setElmnt != NULLP)
   {
      children = setElmnt->elmnDef;
      sepDef = setElmnt->sep;
   }
   else
   {
      decCp->err->idNum = elmDef->idNum;
      decCp->err->code  = CM_ABNF_ERR_SEQEMPTY;
      RETVALUE(CM_ABNF_RFAILED);
   }
   if (elmDef->regExp)
   {
      indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
      CM_REGEXP_OPT_CHK (decCp->protOffset, event, elmDef, decCp->err, indx); 
#else /* not CM_ABNF_V_1_2 */
      CM_REGEXP_OPT_CHK (event, elmDef, decCp->err, indx);
#endif /* CM_ABNF_V_1_2 */
   }
   else
   {
      decCp->err->idNum = elmDef->idNum;
      decCp->err->code  = CM_ABNF_ERR_REGEXP;
      RETVALUE(CM_ABNF_RFAILED); /* Must have a RegExp for a set */
   }
   CM_ABNF_SET_TKNPRES(event); /* Assume present if any element present */

   while (1)
   {
      *tmpEvt = *event + sizeof(TknPres);
      indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);
      if (indx < 0) /* no more components found */
      {
         break;
      }
      for (i = 0; i < indx; i++)
      {
         *tmpEvt += children[i]->evSize; /* Find correct offset in struct */
      }
      if ( ((TknU8 *)(*tmpEvt))->pres != NOTPRSNT)
      {
         /* *tmpEvt actually can point to any tokenized structure whose
          * first element is a TknXXX and is set when decoding that
          * structure... this is true for choice/enum (starts with TknU8),
          * seq (first element is TknPres), seq-of (TknU16) */
         /* If we come here it means a duplicate element */
         decCp->err->code = CM_ABNF_ERR_DUPLICATE;
         decCp->err->idNum = children[(U16)indx]->idNum;   /* 002.main_6 : change */
         RETVALUE(CM_ABNF_RFAILED);
      }
      def = setElmnt->elmnDef[(U16)indx];   /* 002.main_6 : change */
      if ((ret = cmAbnfDecMsg(tmpEvt, def, decCp)) != CM_ABNF_ROK)
      {
         RETVALUE(ret);
      }
      /* Consume the seperator if any */
      if (sepDef != NULLP && sepDef->regExp != NULLP)
      {
         indx = (sepDef->regExp)(decCp, FALSE, NULLP, NULLP);
         if (indx >= 0)
            indx = (sepDef->regExp)(decCp, TRUE, NULLP, NULLP);
      }
   }
   if (CM_ABNF_TKNPRES(event)) 
   {
      *event += elmDef->evSize;
      RETVALUE(CM_ABNF_ROK);
   }
   else
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      { 
         decCp->err->idNum = elmDef->idNum;
         decCp->err->code  = CM_ABNF_ERR_SEQEMPTY;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }
} /* cmAbnfDecSetElmnt */


/*
*
*       Fun:   cmAbnfDecMarkerElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type marker
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecMarkerElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecMarkerElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   S16         ret;
   CmAbnfElmTypeMarker *markerElmnt = 
      (CmAbnfElmTypeMarker *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecMarkerElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   *event += elmDef->evSize;
   switch (markerElmnt->type)
   {
      case CM_ABNF_MARKER_SDP_BEGIN:
      {
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
         decCp->protOffset = CM_ABNF_FIND_SDP_OFFSET(decCp->protVar);
#endif /* CM_ABNF_V_1_2 */
         break;
      }
      case CM_ABNF_MARKER_SDP_END:
      {
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
         decCp->protOffset = CM_ABNF_FIND_PROT_OFFSET(decCp->protVar);
#endif /* CM_ABNF_V_1_2 */
         break;
      }
      case CM_ABNF_MARKER_ESC_FUNC:
      {
         cmAbnfEscFunc *func = (cmAbnfEscFunc *) markerElmnt->info;
         *event -= elmDef->evSize; /* usually 0 for marker */
         ret = (*func)(CM_ABNF_DECODE_PATH, decCp->offset->mBuf, 
               event,
               elmDef->idNum, decCp, NULLP);   /* 001.main_6 */
         if (ret != ROK)
            RETVALUE(CM_ABNF_RFAILED);
         break;
      }
      default:
         break;
   }
   RETVALUE(CM_ABNF_ROK);
} /* cmAbnfDecMarkerElmnt */


/*
*
*       Fun:   cmAbnfDecOptSeqElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type 
*              optional sequence
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecOptSeqElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecOptSeqElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   U16          i;
   S16          indx = -1;   /* 002.main_6 : change */
   U8           *evt;
   U8           **tmpEvt = &evt;
   CmAbnfElmDef *def;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecOptSeqElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   if (elmDef->regExp)
   {
      indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
      CM_REGEXP_OPT_CHK (decCp->protOffset, event, elmDef, decCp->err, indx); 
#else /* not CM_ABNF_V_1_2 */
      CM_REGEXP_OPT_CHK (event, elmDef, decCp->err, indx);
#endif /* CM_ABNF_V_1_2 */
   }

   *tmpEvt = *event;
   *event += elmDef->evSize;

   for (i =0; i <  seqElmnt->numElmnt; i++)
   {
      def = seqElmnt->elmnDef[i];
      if (cmAbnfDecMsg(tmpEvt, def, decCp) == CM_ABNF_RFAILED)
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);
      
} /* cmAbnfDecOptSeqElmnt */


/*
*
*       Fun:   cmAbnfDecOptSeqOfElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type 
*              optional sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecOptSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecOptSeqOfElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   U8           *evt;
   U8           **tmpEvt = &evt;
   U8           *evtElmnt = NULLP;
   CmAbnfElmDef *def;
   S16          ret;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecOptSeqOfElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *tmpEvt += sizeof(TknU16);

   def = seqElmnt->elmnDef[0];
#if (ERRCLASS & ERRCLS_DEBUG)
   if ((def == NULLP) || (seqElmnt->elmnDef[1] == NULLP) ||
       (((seqElmnt->elmnDef[1])->elmnType != CM_ABNF_TYPE_STA_SEQOF) &&
       ((seqElmnt->elmnDef[1])->elmnType != CM_ABNF_TYPE_SEQOF)))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if (elmDef->elmnType == CM_ABNF_TYPE_OPTSEQOF)
   {
      if (cmGetMem(decCp->memCp, def->evSize, (Ptr *)tmpEvt) != CM_ABNF_ROK)
      {
         *event += elmDef->evSize;
         decCp->err->code  = CM_ABNF_ERR_RESFAIL;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }

      /* Store the event structure */
      evtElmnt = *tmpEvt;
   }

 
   if (elmDef->regExp != NULLP)
   {
      S16 indx;   /* 002.main_6 : change */
      indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);

      if (indx < 0)
      {
         if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & 
                                                   CM_ABNF_OPTIONAL)
         {
            *event += elmDef->evSize;
            RETVALUE(CM_ABNF_ROPT);
         }
         else
         {
            *event += elmDef->evSize;
            decCp->err->code  = CM_ABNF_ERR_PARSE;
            decCp->err->idNum = elmDef->idNum;
            RETVALUE(CM_ABNF_RFAILED);
         }
      }
   }

   ret = cmAbnfDecMsg(tmpEvt, def, decCp);
   decCp->evtElmnt = (Ptr)evtElmnt;

   if (ret == CM_ABNF_RFAILED)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
         RETVALUE(CM_ABNF_RFAILED);
   }
   else if (ret == CM_ABNF_ROPT)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT); 
      else
         RETVALUE(CM_ABNF_RFAILED);
   }


   CM_ABNF_SET_TKNNUMVAL(event, 1);

   /* Reset the tmpEvt */
   *tmpEvt = *event;
   *event += elmDef->evSize;

   if (cmAbnfDecMsg(tmpEvt, (seqElmnt->elmnDef[1]), 
         decCp) != CM_ABNF_ROK)
   {
      decCp->evtElmnt = NULLP;
      RETVALUE(CM_ABNF_RFAILED);
   }

   decCp->evtElmnt = NULLP;
   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecOptSeqOfElmnt */


/*
*
*       Fun:   cmAbnfDecSeqOfElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type 
*              sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecSeqOfElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                               
   U16          i;
   U8           j;
   U8           *evt;
   U8           **tmpEvt = &evt;
   S16          indx = -1;   /* 002.main_6 : change */
   U16          val;
   S16          ret;
   U8           *evtArray[CM_ABNF_MAX_SEQOFELMNT];
   CmAbnfElmTypeSeqOf *seqOfElmnt = (CmAbnfElmTypeSeqOf *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecSeqOfElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *tmpEvt += sizeof(TknU16);

   val = CM_ABNF_TKNNUMVAL(event);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (val > 1)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* 
    * Check at all if there is any seqof event elements. If not, there
    * is no point of going inside. 
    */
   if (val)
   {
      if (elmDef->elmnType == CM_ABNF_TYPE_SEQOF)
      {
         /* double pointer array */
         evtArray[0] = (U8 *) decCp->evtElmnt;
      }
      else
      { 
         for (i = 0; i < val; i++)
         {
            for (j = 0; j < seqOfElmnt->numElmnt; j++)
            {
               if (cmAbnfEncSkipElmnt(tmpEvt, 
                                     (seqOfElmnt->elmnDef[j])) != CM_ABNF_ROK)
               {
                  *event += elmDef->evSize;
                  RETVALUE(CM_ABNF_RFAILED);
               }
            }
         }
      }
   }

   if (elmDef->regExp != NULLP)
      indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);
   if (indx >= 0)
   {
      while(1)
      { 
         if (elmDef->elmnType == CM_ABNF_TYPE_SEQOF)
         {
            if (cmGetMem(decCp->memCp, seqOfElmnt->elmnSize, 
                                       (Ptr *)tmpEvt) != CM_ABNF_ROK)
            {
               *event += elmDef->evSize;
               decCp->err->code  = CM_ABNF_ERR_RESFAIL;
               decCp->err->idNum = elmDef->idNum;
               RETVALUE(CM_ABNF_RFAILED);
            }
            evtArray[val] = *tmpEvt;
         }

         for (i = 0; i < seqOfElmnt->numElmnt; i++)
         {
            if ((ret = cmAbnfDecMsg(tmpEvt, 
                          (seqOfElmnt->elmnDef[i]), decCp)) == CM_ABNF_RFAILED)
               RETVALUE(CM_ABNF_RFAILED);
         }
         
         /* Check for minimum elements */
         if (val >= seqOfElmnt->max)
         {
             *event += elmDef->evSize;
             decCp->err->idNum = elmDef->idNum;
             decCp->err->code  = CM_ABNF_ERR_SEQOFELM_MORE;
             RETVALUE(CM_ABNF_RFAILED);
         }

         val++;
         /* 001.main_12 Make sure there aren't too many elements */
         if (val >= CM_ABNF_MAX_SEQOFELMNT)
         {
           *event += elmDef->evSize;
           decCp->err->code  = CM_ABNF_ERR_SEQOFELM_MORE;
           decCp->err->idNum = elmDef->idNum;
           RETVALUE(CM_ABNF_RFAILED);
         }

         if ((indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP)) < 0)
           break;
      }
   }

   if (val < seqOfElmnt->min)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_SEQOFELM_LESS;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   if(val > 0)
   {
      CM_ABNF_SET_TKNNUMVAL(event, val);

      if (elmDef->elmnType == CM_ABNF_TYPE_SEQOF)
      {
         /* Allocate double pointers array and initialize each pointers */
         if (cmGetMem(decCp->memCp, 
                      (sizeof(Ptr) * val), (Ptr *)tmpEvt) != CM_ABNF_ROK)
         {
            *event += elmDef->evSize;
            decCp->err->code  = CM_ABNF_ERR_RESFAIL;
            decCp->err->idNum = elmDef->idNum;
            RETVALUE(CM_ABNF_RFAILED);
         }

         *((PTR *)(*event + sizeof(TknU16))) = (PTR)(*tmpEvt);

         for (i = 0; i < val; i++)
         {
            ((PTR *)(*tmpEvt))[i] = (PTR)evtArray[i];
         }
      }
   }
  
   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecOptSeqOfElmnt */


/*
*
*       Fun:   cmAbnfDecCondSeqOfElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type 
*              conditional sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecCondSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecCondSeqOfElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U16          i;
   U8           *evt;
   U8           **tmpEvt = &evt;
   S16          indx;   /* 002.main_6 : change */
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecCondSeqOfElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *event += elmDef->evSize;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);

   if (indx < 0)
   {
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL) 
          RETVALUE(CM_ABNF_ROPT);
      else
      {
          decCp->err->code  = CM_ABNF_ERR_PARSE;
          decCp->err->idNum = elmDef->idNum;
          RETVALUE(CM_ABNF_RFAILED);
      }
   }

   for (i =0; i < seqElmnt->numElmnt; i++)
   {
      if (cmAbnfDecMsg(tmpEvt, seqElmnt->elmnDef[i], decCp) 
            == CM_ABNF_RFAILED)
         RETVALUE(CM_ABNF_RFAILED);
   }

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecCondSeqOfElmnt */


/*
*
*       Fun:   cmAbnfDecChSeqOfElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type 
*              choice sequenceof
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecChSeqOfElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecChSeqOfElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U8           *evt;
   U8           **tmpEvt = &evt;
   S16          indx;   /* 002.main_6 : change */
   Ptr          **dPtr;
   U32          elmnSize;
   CmAbnfElmTypeSeq *seqElmnt = (CmAbnfElmTypeSeq *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecChSeqOfElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *event += elmDef->evSize;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   indx = (elmDef->regExp)(decCp, FALSE, NULLP, NULLP);

   if (indx < 0)
   {
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL) 
          RETVALUE(CM_ABNF_ROPT);
      else
      {
          decCp->err->code  = CM_ABNF_ERR_PARSE;
          decCp->err->idNum = elmDef->idNum;
          RETVALUE(CM_ABNF_RFAILED);
      }
   }

   if (indx >= seqElmnt->numElmnt)
   {
      decCp->err->code  = CM_ABNF_ERR_REGEXP;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   } 

   if (!indx)
   {
      CM_ABNF_SET_TKNNUMVAL(tmpEvt, 1);
      *tmpEvt += sizeof(TknU16);
      /* Find out if static or dynamic array */
      {
         U8 isSta = 0;
         U8 found = 0;
         U8 i;
         CmAbnfElmDef *condDef;
         CmAbnfElmTypeSeq *seq;
         condDef = seqElmnt->elmnDef[1];
         if (!condDef || condDef->elmnType != CM_ABNF_TYPE_CONDSEQOF)
         {
            decCp->err->code  = CM_ABNF_ERR_DBELMNT;
            decCp->err->idNum = elmDef->idNum;
            RETVALUE(CM_ABNF_RFAILED);
         }
         seq = (CmAbnfElmTypeSeq *)(condDef->typeSpecDef);
         for (i = 0; !found && i < seq->numElmnt; i++)
         {
            if (seq->elmnDef[i])
            {
               if (seq->elmnDef[i]->elmnType == CM_ABNF_TYPE_STA_OPTSEQOF ||
                   seq->elmnDef[i]->elmnType == CM_ABNF_TYPE_STA_SEQOF)
               {
                  isSta = 1;
                  found = 1;
               }
               else if (seq->elmnDef[i]->elmnType == CM_ABNF_TYPE_OPTSEQOF ||
                        seq->elmnDef[i]->elmnType == CM_ABNF_TYPE_SEQOF)
               {
                  isSta = 0;
                  found = 1;
                  if (seq->elmnDef[i]->elmnType == CM_ABNF_TYPE_SEQOF)
                  {
                     elmnSize = ((CmAbnfElmTypeSeqOf *)
                        (seq->elmnDef[i]->typeSpecDef))->elmnSize;
                  }
                  else
                  {
                     elmnSize = ((CmAbnfElmTypeSeqOf *)
                        (((CmAbnfElmTypeSeq *)(seq->elmnDef[i]->typeSpecDef))->
                        elmnDef[1])->typeSpecDef)->elmnSize;
                  }
               }
            }
         }
         if (!found)
         {
            decCp->err->code  = CM_ABNF_ERR_DBELMNT;
            decCp->err->idNum = condDef->idNum;
            RETVALUE(CM_ABNF_RFAILED);
         }
         if (!isSta)
         {
            /* Allocate double pointer array of size 1 */
            dPtr = (Ptr **) (*((PTR *)tmpEvt));
            if (cmGetMem(decCp->memCp, sizeof(Ptr), (Ptr *)dPtr) != 
                CM_ABNF_ROK)
            {
               *event += elmDef->evSize;
               decCp->err->code  = CM_ABNF_ERR_RESFAIL;
               decCp->err->idNum = elmDef->idNum;
               RETVALUE(CM_ABNF_RFAILED);
            }
            if (cmGetMem(decCp->memCp, elmnSize, (Ptr *)*dPtr) != CM_ABNF_ROK)
            {
               *event += elmDef->evSize;
               decCp->err->code  = CM_ABNF_ERR_RESFAIL;
               decCp->err->idNum = elmDef->idNum;
               RETVALUE(CM_ABNF_RFAILED);
            }
            *tmpEvt = (U8 *)**dPtr;
         }
      }
   }
   /* 002.main_6 : change */
   if (cmAbnfDecMsg(tmpEvt, 
                    seqElmnt->elmnDef[(U16)indx], decCp) == CM_ABNF_RFAILED)
      RETVALUE(CM_ABNF_RFAILED);

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecChSeqOfElmnt */


/*
*
*       Fun:   cmAbnfDecMetaElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type meta.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecMetaElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecMetaElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U8           *evt;
   U8           **tmpEvt = &evt;

   TRC2(cmAbnfDecMetaElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *tmpEvt = *event;
   *event += elmDef->evSize;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
       decCp->err->code  = CM_ABNF_ERR_DBELMNT;
       decCp->err->idNum = elmDef->idNum;
       RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   if ((elmDef->regExp)(decCp, TRUE, NULLP, NULLP) < 0)
   {
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL) 
          RETVALUE(CM_ABNF_ROPT);
      else
      {
          decCp->err->code  = CM_ABNF_ERR_PARSE;
          decCp->err->idNum = elmDef->idNum;
          RETVALUE(CM_ABNF_RFAILED);
      }
   }

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecMetaElmnt */


/*
*
*       Fun:   cmAbnfDecEnumElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type Enum.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecEnumElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecEnumElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   CmAbnfElmTypeEnum *enumElmnt = (CmAbnfElmTypeEnum *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecEnumElmnt)
   UNUSED(decCp);

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   CM_ABNF_SET_TKNU8(event, enumElmnt->val);

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecEnumElmnt */


/*
 * [TEL]: Added new function for U16 support
 */

/*
*
*       Fun:   cmAbnfDecU16EnumElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type Enum.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecU16EnumElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecU16EnumElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   CmAbnfElmTypeU16Enum *enumElmnt =
                         (CmAbnfElmTypeU16Enum *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecU16EnumElmnt)
   UNUSED(decCp);

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   CM_ABNF_SET_TKNU16(event, enumElmnt->val);

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecU16EnumElmnt */



/*
*
*       Fun:   cmAbnfDecSkipElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type skip.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecSkipElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecSkipElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   TRC2(cmAbnfDecSkipElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

   /* Store the event pointer and pass the tmpEvt. */
   *event += elmDef->evSize;
   if (elmDef->regExp != NULLP)
   {
      if ((elmDef->regExp)(decCp, TRUE, NULLP, NULLP) < 0)
      {
         if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & 
            CM_ABNF_OPTIONAL) 
             RETVALUE(CM_ABNF_ROPT);
         else
         {
             decCp->err->code  = CM_ABNF_ERR_PARSE;
             decCp->err->idNum = elmDef->idNum;
             RETVALUE(CM_ABNF_RFAILED);
         }
      }
   }

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecSkipElmnt */


/*
*
*       Fun:   cmAbnfDecSintElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type SINTX.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecSintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecSintElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   S32    dgt;
   U16    len = CM_ABNF_MAX_UINTSZ;
   /* 
    * cm_abnf_c_001.main_11:
    * new variable tlen has been introduced
    */
   U16    tlen = 0;
   U8     abnfStr[CM_ABNF_MAX_UINTSZ];
   U8     *str = abnfStr;
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeSIntRange *range = (CmAbnfElmTypeSIntRange *)elmDef->typeSpecDef;
#else /* CM_ABNF_V_1_2 defined */
   CmAbnfElmTypeRange *range = (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfDecSintElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* 
    * cm_abnf_c_001.main_11:
    * abnffStr is initialized
    */
   cmMemset(abnfStr, 0, CM_ABNF_MAX_UINTSZ);
   if ((elmDef->regExp)(decCp, TRUE, (&str), &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }

#ifdef CM_ABNF_V_1_2

   /* 
    * cm_abnf_c_001.main_11:
    * tlen is adjusted for hex digits and used to check lengths
    */
   tlen=(len>0)?((abnfStr[1]=='x' || abnfStr[1]=='X')?len-2:len):len;
   if ((tlen < range->minLen) || (tlen > range->maxLen))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2SI(abnfStr, len, dgt);

   if (dgt < range->minVal || dgt > range->maxVal)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   };

#else /* !CM_ABNF_V_1_2 */

   /* 
    * cm_abnf_c_001.main_11:
    * tlen is adjusted for hex digits and used to check lengths
    */
   tlen=(len>0)?((abnfStr[1]=='x' || abnfStr[1]=='X')?len-2:len):len;
   if ((tlen < range->min) || (tlen > range->max))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2SI(abnfStr, len, dgt);

#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_SINT8:
         CM_ABNF_SET_TKNS8(event, dgt);
         break;

      case CM_ABNF_TYPE_SINT16:
         CM_ABNF_SET_TKNS16(event, dgt);
         break;

      case CM_ABNF_TYPE_SINT32:
         CM_ABNF_SET_TKNS32(event, dgt);
         break;
   }

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecSintElmnt */


/*
*
*       Fun:   cmAbnfDecUintElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type UINTX.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecUintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecUintElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U32    dgt;
   U16    len = CM_ABNF_MAX_UINTSZ;
   /* 
    * cm_abnf_c_001.main_11:
    * tlen is initialized
    */
   U16    tlen = 0;
   U8     abnfStr[CM_ABNF_MAX_UINTSZ];
   U8     *str = abnfStr;
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeIntRange *range = (CmAbnfElmTypeIntRange *)elmDef->typeSpecDef;
#else /* CM_ABNF_V_1_2 defined */
   CmAbnfElmTypeRange *range = (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfDecUintElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   /* 
    * cm_abnf_c_001.main_11:
    * abnfStr is initialized
    */
   cmMemset(abnfStr, 0, CM_ABNF_MAX_UINTSZ);
   if ((elmDef->regExp)(decCp, TRUE, (&str), &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }

#ifdef CM_ABNF_V_1_2

   /* 
    * cm_abnf_c_001.main_11:
    * tlen is adjusted for hex digits and used to check lengths
    */
   tlen=(len>0)?((abnfStr[1]=='x' || abnfStr[1]=='X')?len-2:len):len;
   if ((tlen < range->minLen) || (tlen > range->maxLen))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2I(abnfStr, len, dgt);

   if (dgt < range->minVal || dgt > range->maxVal)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   };

#else /* !CM_ABNF_V_1_2 */

   /* 
    * cm_abnf_c_001.main_11:
    * tlen is adjusted for hex digits and used to check lengths
    */
   tlen=(len>0)?((abnfStr[1]=='x' || abnfStr[1]=='X')?len-2:len):len;
   if ((tlen < range->min) || (tlen > range->max))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2I(abnfStr, len, dgt);

#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_UINT8:
         CM_ABNF_SET_TKNU8(event, dgt);
         break;

      case CM_ABNF_TYPE_UINT16:
         CM_ABNF_SET_TKNU16(event, dgt);
         break;

      case CM_ABNF_TYPE_UINT32:
         CM_ABNF_SET_TKNU32(event, dgt);
         break;
   }

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecUintElmnt */


/*
*
*       Fun:   cmAbnfDecHexSintElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type HEXSINTX.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecHexSintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecHexSintElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   S32    dgt;
   U16    len = CM_ABNF_MAX_HEXUINTSZ;
   U8     abnfStr[CM_ABNF_MAX_HEXUINTSZ];
   U8     *str = abnfStr;
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeSIntRange *range = (CmAbnfElmTypeSIntRange *)elmDef->typeSpecDef;
#else /* !CM_ABNF_V_1_2 */
   CmAbnfElmTypeRange *range = (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfDecHexSintElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if ((elmDef->regExp)(decCp, TRUE, (&str), &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }

#ifdef CM_ABNF_V_1_2

   if ((len < range->minLen) || (len > range->maxLen))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2SH(abnfStr, len, dgt);

   if (dgt < range->minVal || dgt > range->maxVal)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   };

#else /* !CM_ABNF_V_1_2 */

   if ((len < range->min) || (len > range->max))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2SH(abnfStr, len, dgt);

#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_HEXSINT8:
         CM_ABNF_SET_TKNS8(event, dgt);
         break;

      case CM_ABNF_TYPE_HEXSINT16:
         CM_ABNF_SET_TKNS16(event, dgt);
         break;

      case CM_ABNF_TYPE_HEXSINT32:
         CM_ABNF_SET_TKNS32(event, dgt);
         break;
   }

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecHexSintElmnt */



/*
*
*       Fun:   cmAbnfDecHexUintElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type HEXUINTX.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecHexUintElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecHexUintElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U32    dgt;
   U16    len = CM_ABNF_MAX_HEXUINTSZ;
   U8     abnfStr[CM_ABNF_MAX_HEXUINTSZ];
   U8     *str = abnfStr;
#ifdef CM_ABNF_V_1_2
   CmAbnfElmTypeIntRange *range = (CmAbnfElmTypeIntRange *)elmDef->typeSpecDef;
#else /* !CM_ABNF_V_1_2 */
   CmAbnfElmTypeRange *range = (CmAbnfElmTypeRange *)elmDef->typeSpecDef;
#endif /* CM_ABNF_V_1_2 */

   TRC2(cmAbnfDecHexUintElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   if ((elmDef->regExp)(decCp, TRUE, (&str), &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }

#ifdef CM_ABNF_V_1_2

   if ((len < range->minLen) || (len > range->maxLen))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2H(abnfStr, len, dgt);

   if (dgt < range->minVal || dgt > range->maxVal)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   };

#else /* !CM_ABNF_V_1_2 */

   if ((len < range->min) || (len > range->max))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_UINTRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   CM_ABNF_A2H(abnfStr, len, dgt);

#endif /* CM_ABNF_V_1_2 */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_HEXUINT8:
         CM_ABNF_SET_TKNU8(event, dgt);
         break;

      case CM_ABNF_TYPE_HEXUINT16:
         CM_ABNF_SET_TKNU16(event, dgt);
         break;

      case CM_ABNF_TYPE_HEXUINT32:
         CM_ABNF_SET_TKNU32(event, dgt);
         break;
   }

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecHexUintElmnt */


/*
*
*       Fun:   cmAbnfDecOctStrElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type OCTSTR.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecOctStrElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecOctStrElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   Data   *str = NULLP;
   U16    len = 0;
   CmAbnfElmTypeRange *range = (CmAbnfElmTypeRange *)elmDef->typeSpecDef;

   TRC2(cmAbnfDecOctStrElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_OCTSTR8:
         str = CM_ABNF_TKNSTR8VAL(event);
         len = 8;
         break;

      case CM_ABNF_TYPE_OCTSTR32:
         str = CM_ABNF_TKNSTR32VAL(event);
         len = 32;
         break;
      case CM_ABNF_TYPE_OCTSTRXL:
         len = 0xFFFF;
         break;
   }
   
   if ((elmDef->regExp)(decCp, TRUE, &str, &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }

   if ((len < range->min) || (len > range->max))
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_INV_STRRNG;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_OCTSTR8:
         CM_ABNF_SET_TKNSTR8(event, len);
         break;

      case CM_ABNF_TYPE_OCTSTR32:
         CM_ABNF_SET_TKNSTR32(event, len);
         break;

      case CM_ABNF_TYPE_OCTSTRXL:
         CM_ABNF_SET_TKNSTRXL(event, str, len);
         break;
   }

   *event += elmDef->evSize;

   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecOctStrElmnt */


/*
*
*       Fun:   cmAbnfDecTknBufElmnt 
*
*       Desc:  This function decodes Elemnt definition elemnt of type TKNBUF.
*
*       Ret:   CM_ABNF_ROK
*              CM_ABNF_RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmAbnfDecTknBufElmnt 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
PRIVATE S16 cmAbnfDecTknBufElmnt (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{                                
   U16    len = 0;

   TRC2(cmAbnfDecTknBufElmnt)

   CM_ABNF_DEC_DBGP(event, elmDef, decCp);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (elmDef->regExp == NULLP)
   {
      *event += elmDef->evSize;
      decCp->err->code  = CM_ABNF_ERR_DBELMNT;
      decCp->err->idNum = elmDef->idNum;
      RETVALUE(CM_ABNF_RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_DEBUG */
   
   if ((elmDef->regExp)(decCp, FALSE, NULLP, &len) < 0)
   {
      *event += elmDef->evSize;
      if ((CM_ABNF_FLAGP(elmDef->flagp, decCp->protOffset)) & CM_ABNF_OPTIONAL)
         RETVALUE(CM_ABNF_ROPT);
      else
      {
         decCp->err->code  = CM_ABNF_ERR_PARSE;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
   }
   /* At this point len has number of bytes decoded; decCp->offset has
    * been set back to beginning of pattern to be placed in (*event)->val.
    */
   /* NOTE: user MUST allocate tknBuf.val via SGetMsg or else we'll do so
    * using DFLT_REGION, DFLT_POOL.
    */
   if (len)
   {
      Buffer *mToAttach;
      Buffer *mPost;
      Buffer *tknBufVal;
      Region region;
      Pool   pool;
      S16 ret;

      mToAttach = (Buffer *)NULLP;
      mPost = (Buffer *)NULLP;
      tknBufVal = ((TknBuf *)*event)->val;
      if (SSegMsg(decCp->offset->mBuf, *(decCp->numBytes), 
          &mToAttach) != ROK)
      {
         decCp->err->code  = CM_ABNF_ERR_RESFAIL;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
      if ((ret = SSegMsg(mToAttach, len, &mPost)) != ROK &&
           ret != ROKDNA)
      {
         decCp->err->code  = CM_ABNF_ERR_RESFAIL;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
      if (tknBufVal == (Buffer *)NULLP || 
          SGetBufRegionPool(tknBufVal, &region, &pool) != ROK)
      {
         if (tknBufVal != NULLP)
         {
            (Void)SPutMsg(tknBufVal);
         }
         if (SGetMsg(DFLT_REGION, DFLT_POOL, &tknBufVal) != ROK) 
         {
            decCp->err->code  = CM_ABNF_ERR_RESFAIL;
            decCp->err->idNum = elmDef->idNum;
            RETVALUE(CM_ABNF_RFAILED);
         }
         SGetBufRegionPool(tknBufVal, &region, &pool);
      }
      /* Now region/pool should have proper values */
      (Void)SPutMsg(tknBufVal);
      tknBufVal = (Buffer *)NULLP;
      if (SCpyMsgMsg(mToAttach, region, pool, &tknBufVal) != ROK) 
      {
         decCp->err->code  = CM_ABNF_ERR_RESFAIL;
         decCp->err->idNum = elmDef->idNum;
         RETVALUE(CM_ABNF_RFAILED);
      }
      ((TknBuf *)*event)->val = tknBufVal;
      /* previous mBuf is now in three parts: mBuf, mToAttach and mPost.
       * Leave it as we found it.
       */
      (Void)SCatMsg(decCp->offset->mBuf, mToAttach, M1M2);
      (Void)SPutMsg(mToAttach);
      if (mPost != (Buffer *)NULLP)
      {
         (Void)SCatMsg(decCp->offset->mBuf, mPost, M1M2);
         (Void)SPutMsg(mPost);
      }
      (Void)cmAbnfDecSkipNChars(decCp->offset, (U32)len);
      *(decCp->numBytes) += len;
      CM_ABNF_SET_TKNPRES(event);
   }
   else
   {
      (*((U8 *)(*event))) = FALSE;
   }
   *event += elmDef->evSize;
   RETVALUE(CM_ABNF_ROK);

} /* cmAbnfDecTknBufElmnt */


/*
*
*       Fun:   cmAbnfDecMsg 
*
*       Desc:  This function decodes the message in the event structure.
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
S16 cmAbnfDecMsg 
(
U8            **event,    /* pointer to the event structure */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmAbnfDecCp   *decCp      /* Decode control point */
)
#else
S16 cmAbnfDecMsg (event, elmDef, decCp)
U8            **event;    /* pointer to the event structure */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmAbnfDecCp   *decCp;     /* Decode control point */
#endif
{
   S16  ret = CM_ABNF_ROK;

   TRC2(cmAbnfDecMsg)

   switch (elmDef->elmnType)
   {
      case CM_ABNF_TYPE_CHOICE:
         ret = cmAbnfDecChoiceElmnt(event, elmDef, decCp);
         break;

      /*
       * [TEL]: Added new case for U16 support
       */
      case CM_ABNF_TYPE_CHOICE_U16:
         ret = cmAbnfDecU16ChoiceElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_SET:
         ret = cmAbnfDecSetElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_SEQ:
         ret = cmAbnfDecSeqElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_OPTSEQ:
         ret = cmAbnfDecOptSeqElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_STA_OPTSEQOF:
      case CM_ABNF_TYPE_OPTSEQOF:
         ret = cmAbnfDecOptSeqOfElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_CONDSEQOF:
         ret = cmAbnfDecCondSeqOfElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_STA_SEQOF:
      case CM_ABNF_TYPE_SEQOF:
         ret = cmAbnfDecSeqOfElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_CHSEQOF:
         ret = cmAbnfDecChSeqOfElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_META:
         ret = cmAbnfDecMetaElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_UINT8:
      case CM_ABNF_TYPE_UINT16:
      case CM_ABNF_TYPE_UINT32:
         ret = cmAbnfDecUintElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_SINT8:
      case CM_ABNF_TYPE_SINT16:
      case CM_ABNF_TYPE_SINT32:
         ret = cmAbnfDecSintElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_HEXUINT8:
      case CM_ABNF_TYPE_HEXUINT16:
      case CM_ABNF_TYPE_HEXUINT32:
         ret = cmAbnfDecHexUintElmnt(event, elmDef, decCp);
         break;


      case CM_ABNF_TYPE_HEXSINT8:
      case CM_ABNF_TYPE_HEXSINT16:
      case CM_ABNF_TYPE_HEXSINT32:
         ret = cmAbnfDecHexSintElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_ENUM:
         ret = cmAbnfDecEnumElmnt(event, elmDef, decCp);
         break;

      /*
       * [TEL]: Added new case for U16 support
       */
      case CM_ABNF_TYPE_ENUM_U16:
         ret = cmAbnfDecU16EnumElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_SKIP:
         ret = cmAbnfDecSkipElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_OCTSTR8:
      case CM_ABNF_TYPE_OCTSTR32:
      case CM_ABNF_TYPE_OCTSTRXL:
         ret = cmAbnfDecOctStrElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_TKNBUF:
         ret = cmAbnfDecTknBufElmnt(event, elmDef, decCp);
         break;

      case CM_ABNF_TYPE_MARKER:
         ret = cmAbnfDecMarkerElmnt(event, elmDef, decCp);
         break;
   }

   RETVALUE(ret);
} /* cmAbnfDecMsg */


/*
*
*       Fun:   cmAbnfDecPduMsg 
*
*       Desc:  Decoding interface function.
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfDecPduMsg 
(
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
U32           protVar,      /* protocol and variant */
CmMemListCp   *memCp,       /* Memory allocation control point */
#endif /* CM_ABNF_V_1_2 */
U8            *event,       /* pointer to the event structure */
Buffer        *mBuf,        /* Message buffer */
CmAbnfElmDef  *elmDef,      /* message defintion */
MsgLen        *numDecBytes, /* Number of message bytes decoded */
CmAbnfDecOff  *offset,      /* Decode buffer offset info */
CmAbnfErr     *err          /* error to be returned back to the caller */ 
)
#else
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
PUBLIC S16 cmAbnfDecPduMsg (protVar, memCp, event, mBuf, elmDef, 
                            numDecBytes, offset, err)
U32           protVar;      /* protocol and variant */
CmMemListCp   *memCp;       /* Memory allocation control point */
#else /* not CM_ABNF_V_1_2 */
PUBLIC S16 cmAbnfDecPduMsg (event, mBuf, elmDef, numDecBytes, offset, err)
#endif /* CM_ABNF_V_1_2 */
U8            *event;       /* pointer to the event structure */
Buffer        *mBuf;        /* Message buffer */
CmAbnfElmDef  *elmDef;      /* message defintion */
MsgLen        *numDecBytes; /* Number of message bytes decoded */
CmAbnfDecOff  *offset;      /* Decode buffer offset info */
CmAbnfErr     *err;         /* error to be returned back to the caller */ 
#endif
{
   CmAbnfDecCp   decCp;
   U8            *evt;
   S16           ret;
   U8            **tmpEvt = &evt;

   TRC2(cmAbnfDecPduMsg)

#if (ERRCLASS & ERRCLS_INT_PAR)
  if (err == NULLP)
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNF003, 0,
         "cmAbnfDecPduMsg() failed, Invalid err pointer");

   if ((mBuf == NULLP) || (event == NULLP) || 
       (elmDef == NULLP) || (numDecBytes == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNF004, 0,
         "cmAbnfEncMsg() failed, Invalid parameters ");

      err->code = CM_ABNF_ERR_ENCPARAM;
      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   err->code      = 0;
   err->idNum     = 0;
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   decCp.memCp    = (Ptr)memCp;
#else /* not CM_ABNF_V_1_2 */
   decCp.memCp    = (Ptr)event;
#endif /* CM_ABNF_V_1_2 */
   decCp.offset   = offset;
   *numDecBytes   = 0;
   decCp.numBytes = numDecBytes;
   decCp.err      = err;
   decCp.evtElmnt = NULLP;
   if (!offset->mBuf)
      offset->mBuf  = mBuf;
#ifdef CM_ABNF_V_1_2 /* Version 1.2 */
   *tmpEvt        = event;
   decCp.protOffset     = CM_ABNF_FIND_PROT_OFFSET(protVar);
   decCp.protVar        = protVar;
#else /* not CM_ABNF_V_1_2 */
   *tmpEvt        = (event + sizeof(CmMemListCp));
#endif /* CM_ABNF_V_1_2 */

   if (cmAbnfDecInitDBuf(offset) != ROK)
   {
      decCp.err->code = CM_ABNF_ERR_RESFAIL;
   }    

   ret = cmAbnfDecMsg(tmpEvt, elmDef, &decCp);
   if (ret == CM_ABNF_RFAILED)
   {
      RETVALUE(RFAILED);
   }
   else if (ret == CM_ABNF_ROPT)
   {
      (*numDecBytes) = 0;
      err->code = CM_ABNF_ERR_NONE;  /* reset err code if decoding passed */
      RETVALUE(ROK);
   }
   /* IF we come here, ret == CM_ABNF_ROK */
   /* 
    * Increment the numDecBytes by one as the value returned by the internal
    * decoded is zero based. The value to be returned to the caller must be
    * 1 based.
    */
    (*numDecBytes) +=1;
    err->code = CM_ABNF_ERR_NONE;  /* reset err code if decoding passed */
    RETVALUE(ROK);
} /* cmAbnfDecPduMsg */


/************************************************************************
           Buffer manipulating functions 
*************************************************************************/

/*
*
*       Fun:   cmAbnfEncChainLastDBuf 
*
*       Desc:  Chain the last dBuff to the mBuf
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: Last buffer before the encoder returns to the caller
*              needs to be chained. The last bufffer is stiill hanging
*              due to the logic implmented for buffer chaining in the
*              function cmAbnfEncOut2Buf. 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfEncChainLastDBuf 
(
CmAbnfEncCp   *encCp        /* Encode control point */
)
#else
PUBLIC S16 cmAbnfEncChainLastDBuf (encCp)
CmAbnfEncCp   *encCp;       /* Encode control point */
#endif
{
   CmAbnfEncOff    *offset;

   TRC2(cmAbnfEncChainLastDBuf)

   offset = encCp->offset;
   if (offset->dBuf == (Buffer *)NULLP)
   {
      RETVALUE(CM_ABNF_ROK);
   }
   /* Buffer is exhausted, so update the message */
   if (SUpdMsg(encCp->mBuf, offset->dBuf, 
               (MsgLen) (offset->cur - offset->start)) != ROK)
   {
      encCp->err->code = CM_ABNF_ERR_RESFAIL;
      RETVALUE(CM_ABNF_RFAILED);
   }
   encCp->offset->dBuf = NULLP;

   RETVALUE(CM_ABNF_ROK);
   
} /* cmAbnfEncChainLastDBuf */


/*
*
*       Fun:   cmAbnfEncLast
*
*       Desc:  Encode the string in the message buffer for transmission
*
*       Ret:   CM_ABNF_ROK  (encoding successful)
*              CM_ABNF_RFAILED (failed, general)
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfEncOut2Buf 
(
CmAbnfEncCp   *encCp,       /* Encode control point */
U8            *str,         /* string to be encoded in the buffer */
U16           len           /* length of the string */
)
#else
PUBLIC S16 cmAbnfEncOut2Buf (encCp, str, len)
CmAbnfEncCp   *encCp;       /* Encode control point */
U8            *str;         /* string to be encoded in the buffer */
U16           len;          /* length of the string */
#endif
{
   CmAbnfEncOff    *offset;
   MsgLen          size;

   TRC2(cmAbnfEncOut2Buf)

   /*
    *  No parameter checking. This are internal function to be only
    *  called by the encoding functions, preety sure of the stae of the
    *  paratemeters passed.
    */

   offset = encCp->offset;

   while (len)
   {
      if (offset->dBuf == NULLP)
      {
         /* Allocate a dBuf for message encoding */
         if (SGetDBuf(offset->region, offset->pool, &(offset->dBuf)) != ROK)
         {
            encCp->err->code = CM_ABNF_ERR_RESFAIL;
            RETVALUE(CM_ABNF_RFAILED);
         }
   
         /* 
          * Get the memory address of the writable location for direct memory
          * memory access with in the buffer 
          */
         if (SGetDataRx (offset->dBuf, 0, &(offset->start), &size) != ROK)
         {
            /* Commm...onnnn .................*/
            encCp->err->code = CM_ABNF_ERR_RESFAIL;
            RETVALUE(CM_ABNF_RFAILED);
         }
   
         offset->cur = offset->start; 
         offset->end = offset->start + size;
      }
   
      /* Available buffer size */
      size = offset->end - offset->cur;
     
      /* 
       * Remaining bytes to be copied: may be zero if the present buffere
       * has enough space.
       */
      len = ((len > size) ? (len - size) : ((size = len), 0));
   
      while(size--)
      {
         *offset->cur++ = *str++; 
      } 
   
      if (len)
      {
         /* Buffer is exhausted, so update the message */
         if (SUpdMsg(encCp->mBuf, offset->dBuf, 
                     (MsgLen) (offset->end - offset->start)) != ROK)
         {
            encCp->err->code = CM_ABNF_ERR_RESFAIL;
            RETVALUE(CM_ABNF_RFAILED);
         }
         offset->dBuf = NULLP;
      }
   }

   RETVALUE(CM_ABNF_ROK);
   
} /* cmAbnfEncOut2Buf */


/*
*
*       Fun:   cmAbnfDecInitDBuf
*
*       Desc:  Initilaize the dBuf before decoding 
*
*       Ret:   ROK  
*              RFAILED 
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfDecInitDBuf 
(
CmAbnfDecOff   *offset        /*  Decode buffer offset */
)
#else
PUBLIC S16 cmAbnfDecInitDBuf (offset)
CmAbnfDecOff   *offset;       /*  Decode buffer offset */
#endif
{
   CmAbnfDBufInfo *dBufInfo;

   TRC2(cmAbnfDecInitDBuf)

   if (offset->start == offset->end)
   {
      if (SInitNxtDBuf(offset->mBuf) != ROK)
         RETVALUE(RFAILED);

      dBufInfo = &offset->dBufInfo[offset->start];

      CM_ABNF_GET_NXTDBUF(dBufInfo, offset);
      offset->cur = offset->start;
   }

   RETVALUE(ROK);
} /* cmAbnfDecInitDBuf */


/*
*
*       Fun:   cmAbnfInitNxtDBuf
*
*       Desc:  Initialize the next dBuf
*
*       Ret:   ROK  
*              RFAILED 
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfInitNxtDBuf 
(
CmAbnfDecOff   *offset        /*  Decode buffer offset */
)
#else
PUBLIC S16 cmAbnfInitNxtDBuf(offset)
CmAbnfDecOff   *offset;       /*  Decode buffer offset */
#endif
{
   CmAbnfDBufInfo *dBufInfo;

   TRC2(cmAbnfInitNxtDBuf)

   offset->cur = ((++offset->cur) == CM_ABNF_DBUF_ARRAY ? 0 : offset->cur);
 
   if (offset->cur == offset->end)
   {
      /* last buffer in the array. Fetch the next buffer */
      dBufInfo = &offset->dBufInfo[offset->end];
      CM_ABNF_GET_NXTDBUF(dBufInfo, offset);
   }

   if (offset->end == offset->start)
   {
      /* 
       * The dBuf array was full, so delete the oldest buffer
       * entry pointed by the first.
       */
       offset->start = 
              ((++offset->start == CM_ABNF_DBUF_ARRAY) ? 0 : offset->start);
   }
   RETVALUE(ROK);

} /* cmAbnfInitNxtDBuf */


/*
*
*       Fun:   cmAbnfDecOffset
*
*       Desc:  Decrement the offset to the decoded offset.
*
*       Ret:   ROK  
*              RFAILED 
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfDecOffset 
(
CmAbnfDecCp   *decCp,       /* Decode control point */
U16           numDecode     /* number of decode bytes */
)
#else
PUBLIC S16 cmAbnfDecOffset(decCp, numDecode)
CmAbnfDecCp   *decCp;       /* Decode control point */
U16           numDecode;    /* number of decode bytes */
#endif
{
   CmAbnfDecOff    *offset;
   CmAbnfDBufInfo  *dBufInfo = NULLP;
   U16             numBytes;
   S16             ret = ROK;

   TRC2(cmAbnfDecOffset)

   offset = decCp->offset;
   dBufInfo = &(offset->dBufInfo[offset->cur]);

   /* Decrement the numbytes now. Will be adjusted later for error */
   *(decCp->numBytes) -= numDecode;

   while ((dBufInfo) && (numDecode))
   {
      if ((numBytes = (dBufInfo->cur - dBufInfo->start))  < numDecode)
      {
         numDecode = numDecode - numBytes;
         dBufInfo->cur = dBufInfo->start;
      }
      else
      {
         dBufInfo->cur -= numDecode;
         numDecode = 0;
      }

      if (numDecode)
      {
         /* we will need to trek back in the buffer chain */
 
         /* Check if the current buffer is the earliest buffer */
         if (offset->cur == offset->start)
         { 
            /* 
             * No previous buffer. serious goofup. Will need to increase the
             * size of the CM_ABNF_DBUF_ARRAY 
             */
             ret = RFAILED;
             *(decCp->numBytes) += numDecode;
             break;
         }
         /* Decrement the cur, to go back to the previous buffer */
         offset->cur = (offset->cur == 0 ? (CM_ABNF_DBUF_ARRAY - 1) :
                                           (offset->cur - 1));

         dBufInfo = &(offset->dBufInfo[offset->cur]);
      }
   }

   RETVALUE(ret);

} /* cmAbnfDecOffset */

/*
 *
 *       Fun:    cmAbnfDecSkipNChars
 *
 *       Desc:   advances the read pointer in the mBuf by N octets.
 *
 *       Ret:    ROK     - succeeded
 *               RFAILED - failed
 *
 *       Notes:  None
 *
 *       File:   cm_abnf.c
 *
 */

#ifdef ANSI
PRIVATE S16 cmAbnfDecSkipNChars
(
CmAbnfDecOff   *offset,
U32            numB
)
#else
PRIVATE S16 cmAbnfDecSkipNChars(offset, numB)
CmAbnfDecOff   *offset;
U32            numB;
#endif /* ANSI */
{
   S16 ret;

   TRC2(cmAbnfDecSkipNChars)

   /* Error checks here, if needed */

   if (!numB)
   {
      RETVALUE(ROK);
   }

   if (offset->dBufInfo[offset->cur].cur == offset->dBufInfo[offset->cur].end)
   {
      ret = cmAbnfInitNxtDBuf(offset);
      if (ret != ROK)
      {
         RETVALUE(ret);
      }
   }

   while (numB)
   {
      if (numB < (U32)(offset->dBufInfo[offset->cur].end -
                       offset->dBufInfo[offset->cur].cur))
      {
         offset->dBufInfo[offset->cur].cur += numB;
         numB = 0;
      }
      else
      {
         numB -= (U32)(offset->dBufInfo[offset->cur].end -
                       offset->dBufInfo[offset->cur].cur);
         ret = cmAbnfInitNxtDBuf(offset);
         if (ret != ROK)
         {
            RETVALUE(ret);
         }
      }
   }
   RETVALUE(ROK);
} /* end of cmAbnfDecSkipNChars */

#ifdef  CM_ABNF_USE_FUNC 

/*
 *
 *       Fun:    cmAbnfGetChar
 *
 *       Desc:   reads the current character under cursor
 *
 *       Ret:    character read or -1 if EOF
 *
 *       Notes:  None
 *
 *       File:   cm_abnf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmAbnfGetChar
(
CmAbnfDecOff   *offset
)
#else
PUBLIC S16 cmAbnfGetChar(offset)
CmAbnfDecOff   *offset;
#endif /* ANSI */
{
   S16      ret;
   TRC2(cmAbnfGetChar)
   ret = ((((offset)->dBufInfo[(offset)->cur].cur) ==
      ((offset)->dBufInfo[(offset)->cur].end)) ?  -1 :
      (S16)(*((offset)->dBufInfo[(offset)->cur].cur)));
   RETVALUE(ret);
}

/*
 *
 *       Fun:    cmAbnfGetNxtChar
 *
 *       Desc:   advances the read pointer in the mBuf by one octet, then
 *               returns the character under the cursor.
 *
 *       Ret:    character read or -1 if EOF.
 *
 *       Notes:  None
 *
 *       File:   cm_abnf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmAbnfGetNxtChar
(
CmAbnfDecOff   *offset,
MsgLen         *numB
)
#else
PUBLIC S16 cmAbnfGetNxtChar(offset, numB)
CmAbnfDecOff   *offset;
MsgLen         *numB;
#endif /* ANSI */
{
   S16 ret;
   TRC2(cmAbnfGetNxtChar)
   (*(numB))++;      /* 003.main_6 : patch propagation from 1.2 */
   ret = (((++((offset)->dBufInfo[(offset)->cur].cur)) ==
      ((offset)->dBufInfo[(offset)->cur].end)) ?
      ((cmAbnfInitNxtDBuf((offset)) != ROK) ? -1 :
      ((*((offset)->dBufInfo[(offset)->cur].cur)))) :
      ((*((offset)->dBufInfo[(offset)->cur].cur))));
   RETVALUE(ret);
}
#endif /* CM_ABNF_USE_FUNC*/

#ifdef CM_ABNF_MT_LIB



/*
*
*       Fun:   cmAbnfDecCfm 
*
*       Desc:  send decode cfm
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfDecCfm
(
Pst           *pst,        /* Post structure */
U32           protVar,     /* protocol and variant */
U8            *event,      /* pointer to the event structure */
Buffer        *mBuf,       /* Message buffer */
MsgLen        *numDecBytes,/* no of decoded bytes */
CmAbnfErr     *err,        /* error */
Ptr           usrCxt       /* user context */
)
#else
PUBLIC S16 cmAbnfDecCfm(pst, protVar, event, mBuf, numDecBytes, err, usrCxt)
Pst           *pst;        /* Post structure */
U32           protVar;     /* protocol and variant */
U8            *event;      /* pointer to the event structure */
Buffer        *mBuf;       /* Message buffer */
MsgLen        *numDecBytes;/* no of decoded bytes */
CmAbnfErr     *err;        /* error */
Ptr           usrCxt;      /* user context */
#endif
{
   Pst        cfmPst;     /* post structure */

   TRC3(cmAbnfDecCfm)

   /* Copy post structure */
   cmMemcpy((U8 *)&cfmPst, (U8 *)pst, sizeof(Pst));
   cfmPst.srcProcId = pst->dstProcId;
   cfmPst.dstProcId = pst->srcProcId;
   cfmPst.srcInst = pst->dstInst;
   cfmPst.dstInst = pst->srcInst;
   cfmPst.event = EVTMEDDECCFM;

   cmPkMedDecCfm(&cfmPst, protVar, event, mBuf,
                       *numDecBytes, err, usrCxt);
   
   RETVALUE(ROK);
} /* cmAbnfDecCfm */
  

/*
*
*       Fun:   cmAbnfEncCfm 
*
*       Desc:  send Encode cfm
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfEncCfm
(
Pst           *pst,       /* Post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfErr     *err,       /* error */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 cmAbnfEncCfm(pst, protVar, event, mBuf, err, usrCxt)
Pst           *pst;       /* Post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfErr     *err;       /* error */
Ptr           usrCxt;     /* user context */
#endif
{
   Pst        cfmPst;     /* post structure */

   TRC3(cmAbnfEncCfm)
   /* Copy post structure */
   cmMemcpy((U8 *)&cfmPst, (U8 *)pst, sizeof(Pst));

   cfmPst.srcProcId = pst->dstProcId;
   cfmPst.dstProcId = pst->srcProcId;
   cfmPst.srcInst = pst->dstInst;
   cfmPst.dstInst = pst->srcInst;
   cfmPst.event = EVTMEDENCCFM;
   cmPkMedEncCfm(&cfmPst, protVar, event, mBuf, 
          err, usrCxt);
   
   RETVALUE(ROK);
} /* cmAbnfEncCfm */
 

/*
*
*       Fun:   cmAbnfDecReq 
*
*       Desc:  Process decode Req
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfDecReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
CmMemListCp   *memCp,     /* Memory: region/pool */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 cmAbnfDecReq(pst, protVar, event, mBuf, elmDef, memCp, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
CmMemListCp   *memCp;     /* Memory: region/pool */
Ptr           usrCxt;     /* user context */
#endif
{
   MsgLen          numDecBytes;       /* no of decoded bytes */
   CmAbnfErr       err;               /* error */
   CmAbnfDecOff    offset;            /* DBUF offset information */
   
   

   TRC2(cmAbnfDecReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mBuf == NULLP) || (event == NULLP) || (elmDef == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
         "cmAbnfDecReq() failed, Invalid parameters ");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */
   /* Initialize err */
   cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
   err.code = CM_ABNF_ERR_NONE;
   cmMemset((U8 *)&offset, 0, sizeof(CmAbnfDecOff));
   cmAbnfDecPduMsg (protVar, memCp, event, mBuf, elmDef, 
             &numDecBytes, &offset, &err);

   /* send Decode cfm back */
   cmAbnfDecCfm(pst, protVar, event, mBuf, &numDecBytes, &err, usrCxt);
   RETVALUE(ROK);
}


/*
*
*       Fun:   cmAbnfEncReq 
*
*       Desc:  Process Encode Req
*
*       Ret:   ROK
*              RFAILED
*
*       Notes: None 
*
*       File:  cm_abnf.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfEncReq
(
Pst           *pst,       /* post structure */
U32           protVar,    /* protocol and variant */
U8            *event,     /* pointer to the event structure */
Buffer        *mBuf,      /* Message buffer */
CmAbnfElmDef  *elmDef,    /* message defintion */
Mem           *memReg,    /* Memory: region/pool */
Ptr           usrCxt      /* user context */
)
#else
PUBLIC S16 cmAbnfEncReq(pst, protVar, event, mBuf, elmDef, memReg, usrCxt)
Pst           *pst;       /* post structure */
U32           protVar;    /* protocol and variant */
U8            *event;     /* pointer to the event structure */
Buffer        *mBuf;      /* Message buffer */
CmAbnfElmDef  *elmDef;    /* message defintion */
Mem           *memReg;    /* Memory: region/pool */
Ptr           usrCxt;     /* user context */
#endif
{
   CmAbnfErr     err;     /* error */
   S16           ret;     /* return value */

   TRC2(cmAbnfEncReq)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if ((mBuf == NULLP) || (event == NULLP) || (elmDef == NULLP))
   {
      CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
         "cmAbnfEncReq() failed, Invalid parameters ");

      RETVALUE(RFAILED);
   }
#endif /* ERRCLASS & ERRCLS_INT_PAR */

   /* Initialize err */
   cmMemset((U8 *)&err, 0, sizeof(CmAbnfErr));
   err.code = CM_ABNF_ERR_NONE;

   ret = cmAbnfEncPduMsg(protVar, event, mBuf, elmDef, memReg, &err);

   /* send cfm back */
   cmAbnfEncCfm(pst, protVar, event, mBuf, &err, usrCxt);

   RETVALUE(ret);
} /* cmAbnfEncReq */
 

/*
*
*       Fun:    Activation task
*
*       Desc:   Processes events received for Encode or Decode req.
*
*       Ret:    ROK
*
*       Notes:  None
*
*       File:   cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmAbnfActvTsk
(
Pst            *post,           /* post structure */
Buffer         *mBuf            /* message buffer */
)
#else
PUBLIC S16 cmAbnfActvTsk(post, mBuf)
Pst            *post;           /* post structure */
Buffer         *mBuf;           /* message buffer */
#endif
{
   S16 ret = ROK;

   TRC3(cmAbnfActvTsk)

   switch(post->event)
   {
      case EVTMEDENCREQ:
         ret = cmUnpkMedEncReq(cmAbnfEncReq, post, mBuf);
         break;
      case EVTMEDDECREQ:
         ret = cmUnpkMedDecReq(cmAbnfDecReq, post, mBuf);
         break;
      default:
#if  (ERRCLASS & ERRCLS_DEBUG)
         CMABNFLOGERROR(ERRCLS_INT_PAR, ECMABNFXXX, 0,
            "cmAbnfActvTsk() failed, Invalid event");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         (Void) SPutMsg(mBuf);
         ret = RFAILED;
         break;
   }

   SExitTsk();

   RETVALUE(ret);
}
/* Pack unpack functions for cmAbnfLib */



/*
*
*       Fun:   cmUnpkMedEncReq
*
*       Desc:  Unpack Encode Req
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedEncReq
(
MedEncReq  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedEncReq(func, pst, mBuf)
MedEncReq  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U8             *event;           /* event structure */
   Buffer         *encBuf;          /* Buffer */
   CmAbnfElmDef   *elmDef;          /* root of database tree */
   Mem            mem;              /* memory region/pool */
   Ptr            usrCxt;           /* user context */
    
   TRC3(cmUnpkMedEncReq)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   /* Now unpack memory region/pool */
   CMCHKUNPKLOG(cmUnpkPool, &(mem.pool), mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkRegion, &(mem.region), mBuf, EMEDXXX, pst);

   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&elmDef, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&encBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);
   SPutMsg(mBuf);
   /* call the primitive */
   (*func)(pst, protVar, event, encBuf, elmDef, &mem, usrCxt);

   RETVALUE(ROK);
} /* end of cmUnpkMedEncReq */



/*
*
*       Fun:   cmUnpkMedDecReq
*
*       Desc:  Unpack Dec Req
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMedDecReq
(
MedDecReq  func,                    /* function */
Pst        *pst,                    /* post structure */
Buffer     *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkMedDecReq(func, pst, mBuf)
MedDecReq  func;                    /* function */
Pst        *pst;                    /* post structure */
Buffer     *mBuf;                   /* message buffer */
#endif
{

   U32            protVar;          /* protocol variant */
   U8             *event;           /* event structure */
   Buffer         *decBuf;          /* Buffer */
   CmAbnfElmDef   *elmDef;          /* root of database tree */
   CmMemListCp    *memCp;           /* memory region/pool */
   Ptr            usrCxt;           /* user context */
    
   TRC3(cmUnpkMedDecReq)
   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&usrCxt, mBuf, EMEDXXX, pst);
   /* Now unpack memory control block */
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&memCp, mBuf, EMEDXXX, pst);

   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&elmDef, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&decBuf, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(cmUnpkPtr,   (PTR *)&event, mBuf, EMEDXXX, pst);
   CMCHKUNPKLOG(SUnpkU32,   &protVar, mBuf, EMEDXXX, pst);

   SPutMsg(mBuf);
   /* call the primitive */
   (*func)(pst, protVar, event, decBuf, elmDef, memCp, usrCxt);

   RETVALUE(ROK);
} /* end of cmUnpkMedDecReq */


/*
*
*    Fun:    cmPkMedEncCfm
*
*    Desc:    pack the primitive Encode Cfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMedEncCfm
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *encBuf,          /* encoded buffer */
CmAbnfErr      *err,           /* error */
Ptr            usrCxt          /* user context */
)
#else
PUBLIC S16 cmPkMedEncCfm(pst, protVar, event, encBuf, err, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *encBuf;          /* encoded buffer */
CmAbnfErr      *err;           /* error */
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkMedEncCfm)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)encBuf, mBuf, EMEDXXX, pst); 
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(SPkU16, err->code, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(SPkU16, err->idNum, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDENCCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMedEncCfm */



/*
 * 004.main_6 : Corrected the type of argument - numDecBytes
 */

/*
*
*    Fun:    cmPkMedDecCfm
*
*    Desc:    pack the primitive Encode Cfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_abnf.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMedDecCfm
(
Pst            *pst,           /* post structure */
U32            protVar,        /* protocol variant */
U8             *event,         /* event structure */
Buffer         *decBuf,        /* encoded buffer */
MsgLen         numDecBytes,    /* no of decoded bytes */
CmAbnfErr      *err,           /* error */
Ptr            usrCxt          /* user context */
)
#else
PUBLIC S16 cmPkMedDecCfm(pst, protVar, event, decBuf, numDecBytes, err, usrCxt)
Pst            *pst;           /* post structure */
U32            protVar;        /* protocol variant */
U8             *event;         /* event structure */
Buffer         *decBuf;        /* encoded buffer */
MsgLen         numDecBytes;    /* no of decoded bytes */
CmAbnfErr      *err;           /* error */
Ptr            usrCxt;         /* user context */
#endif
{
    S16        ret1;
    Buffer     *mBuf;

    TRC3(cmPkMedDecCfm)

    mBuf = NULLP;

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMEDXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU32, protVar, mBuf, EMEDXXX, pst);
/*
 * 004.main_6 : Corrected the packing function for numDecBytes
 */
    CMCHKPKLOG(cmPkMsgLen, numDecBytes, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)decBuf, mBuf, EMEDXXX, pst); 
    /* Now pack error->idNum and error->code */
    CMCHKPKLOG(SPkU16, err->code, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(SPkU16, err->idNum, mBuf, EMEDXXX, pst);
    CMCHKPKLOG(cmPkPtr, (PTR)usrCxt, mBuf, EMEDXXX, pst); 
    CMCHKPKLOG(cmPkPtr, (PTR)event, mBuf, EMEDXXX, pst); 
    
    pst->event = (Event) EVTMEDDECCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMedDecCfm */




#endif /* CM_ABNF_MT_LIB */

  
/********************************************************************30**
  
         End of file:     cm_abnf.c@@/main/mgcp_rel_1.5_mnt/2 - Fri Jul  1 16:20:43 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.

1.2          ---      kr   1. removed C++ compilation warnings
/main/3      ---      nct  1. New release for GCP 1.2.
/main/4      ---      sk   1. Changed fn cmAbnfEncSetElmnt. Encode fails for 
                              set element if none of setelement is present 
/main/5      ---      ra   1. Added functions and macros for supporting
                              signed decimal and hexadecimal integers
/main/6      ---      rg   1. Changed variable 'index' to 'indx'
/main/7  001.main_6   ra   1. Passing decCp and encCp instead of err
                              field for marked functions.
/main/8  002.main_6   ra   1. Changed the type of indx vars to S16 and
                              typecasted these by U16 instead of U8.
/main/9  003.main_6   ra   1. Patch propagation from 1.2. numB var is
                              updated in all cases now - even when
                              cmAbnfInitNxtDBuf fails.
/main/10     ---      ra   1. Now passing numDecBytes as MsgLen which is
                              the correct type of numDecBytes.
                           2. Corrected the packing function for numDecBytes.
                              This patch must be applied along with -
                              cm_abnf_x_002.main_5
                              mg011.103
/main/11     ---     TEL   1. File modified to support the change in 
                              mgEventDesc structure.
/main/12     ---      pk   1. GCP release 1.5 changes                           
/main/12 001.main_12   ra   1. Enhanced the following macros -
                                 CM_ABNF_A2SI
                                 CM_ABNF_A2I
                                 CM_ABNF_A2SH
                                 CM_ABNF_A2H
                              to check for boundary condition. If the length
                              of the string is the same as the length of
                              the maximum value of S32, then the string
                              value can overflow. To ensure that the overflow
                              is not happening checks have been added.
                       ab   2. Correction in comparison of string for base_10
                              ascii to integer conversion
*********************************************************************91*/
