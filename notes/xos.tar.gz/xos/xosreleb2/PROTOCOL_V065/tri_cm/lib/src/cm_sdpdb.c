/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SDP message database for encoding/decoding
  
     Type:     C source file 
  
     Desc:     Definition for SDP encoding/decoding Database Elements
  
     File:     cm_sdpdb.c
  
     Sid:      cm_sdpdb.c@@/main/14 - Tue Nov  9 23:09:01 2004
  
     Prg:      rm
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* Memory Management Defines */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"        /* SDP  header file */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* Memory Block Management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"        /* SDP  header file */
#include "cm_abndb.x"      /* Common database elemet definition */
#include "cm_sdpdb.x"      /* Common database elemet definition */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpFalseEnum =
{
   (Data *)"FALSE",
   CM_SDP_FALSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpFalse =
{
#ifdef CM_ABNF_DBG
   "SDP False",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpFalseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTrueEnum =
{
   (Data *)"TRUE",
   CM_SDP_TRUE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTrue =
{
#ifdef CM_ABNF_DBG
   "SDP True",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 2,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTrueEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNilEnum =
{
   (Data *)"-",
   CM_SDP_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNil =
{
#ifdef CM_ABNF_DBG
   "SDP -",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 3,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNilEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpOnEnum =
{
   (Data *)"on",
   CM_SDP_ON
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOnStr =
{
#ifdef CM_ABNF_DBG
   "SDP on",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 4,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpOnEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpOffEnum =
{
   (Data *)"off",
   CM_SDP_OFF
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOffStr =
{
#ifdef CM_ABNF_DBG
   "SDP on",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 5,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpOffEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOnOffOrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpOnStr,
   &cmMsgDefSdpOffStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpOnOffOrNullChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpOnOffOrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOnOffOrNull =
{
#ifdef CM_ABNF_DBG        
   "SDP on off or null",
   "SDPOnOffOrNull",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 6,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpOnOffOrNullChc,
   cmSdpRegExpOnOffOrNull
};

#ifndef CM_SDP_OPAQUE
#ifdef CM_SDP_V_2
/* New database, added ATM SDP and a few other SDP extensions. */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNamePCMGEnum =
{
   (Data *)"PCMG",
   CM_SDP_ENC_PCMG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNamePCMGStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding PCMG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 7,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNamePCMGEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameSIDGEnum =
{
   (Data *)"SIDG",
   CM_SDP_ENC_SIDG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameSIDGStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding SIDG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 8,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameSIDGEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameSID729Enum =
{
   (Data *)"SID729",
   CM_SDP_ENC_SID729
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameSID729Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding SID729",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 9,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameSID729Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNamePCMUEnum =
{
   (Data *)"PCMU",
   CM_SDP_ENC_PCMU
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNamePCMUStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding PCMU",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 10,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNamePCMUEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameG726_32Enum =
{
   (Data *)"G726-32",
   CM_SDP_ENC_G726_32
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameG726_32Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding G726_32",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 11,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameG726_32Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameG723Enum =
{
   (Data *)"G723",
   CM_SDP_ENC_G723
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameG723Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding G723",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 12,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameG723Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNamePCMAEnum =
{
   (Data *)"PCMA",
   CM_SDP_ENC_PCMA
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNamePCMAStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding PCMA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 13,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNamePCMAEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameG722Enum =
{
   (Data *)"G722",
   CM_SDP_ENC_G722
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameG722Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding G722",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 14,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameG722Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameG728Enum =
{
   (Data *)"G728",
   CM_SDP_ENC_G728
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameG728Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding G728",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 15,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameG728Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameG729Enum =
{
   (Data *)"G729",
   CM_SDP_ENC_G729
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameG729Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding G729",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 16,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameG729Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G729AEnum =
{
   (Data *)"X-G729a",
   CM_SDP_ENC_X_G729A
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G729AStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G729A",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 17,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G729AEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G729BEnum =
{
   (Data *)"X-G729b",
   CM_SDP_ENC_X_G729B
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G729BStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G729B",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 18,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G729BEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G729ABEnum =
{
   (Data *)"X-G729ab",
   CM_SDP_ENC_X_G729AB
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G729ABStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G729AB",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 19,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G729ABEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G726_16Enum =
{
   (Data *)"X-G726-16",
   CM_SDP_ENC_X_G726_16
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G726_16Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G726_16",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 20,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G726_16Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G726_24Enum =
{
   (Data *)"X-G726-24",
   CM_SDP_ENC_X_G726_24
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G726_24Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G726_24",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 21,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G726_24Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G726_40Enum =
{
   (Data *)"X-G726-40",
   CM_SDP_ENC_X_G726_40
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G726_40Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G726_40",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 22,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G726_40Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G7231_HEnum =
{
   (Data *)"X-G7231-H",
   CM_SDP_ENC_X_G7231_H
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G7231_HStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G7231_H",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 23,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G7231_HEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G7231_LEnum =
{
   (Data *)"X-G7231-L",
   CM_SDP_ENC_X_G7231_L
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G7231_LStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G7231_L",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 24,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G7231_LEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G7231A_HEnum =
{
   (Data *)"X-G7231a-H",
   CM_SDP_ENC_X_G7231A_H
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G7231A_HStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G7231A_H",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 25,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G7231A_HEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G7231A_LEnum =
{
   (Data *)"X-G7231a-L",
   CM_SDP_ENC_X_G7231A_L
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G7231A_LStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G7231A_L",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 26,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G7231A_LEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G727_16Enum =
{
   (Data *)"X-G727-16",
   CM_SDP_ENC_X_G727_16
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G727_16Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G727_16",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 27,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G727_16Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G727_24Enum =
{
   (Data *)"X-G727-24",
   CM_SDP_ENC_X_G727_24
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G727_24Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G727_24",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 28,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G727_24Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_G727_32Enum =
{
   (Data *)"X-G727-32",
   CM_SDP_ENC_X_G727_32
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_G727_32Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_G727_32",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 29,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_G727_32Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_CCDEnum =
{
   (Data *)"X-CCD",
   CM_SDP_ENC_X_CCD
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_CCDStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_CCD",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 30,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_CCDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_CCD_CASEnum =
{
   (Data *)"X-CCD-CAS",
   CM_SDP_ENC_X_CCD_CAS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_CCD_CASStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_CCD_CAS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 31,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_CCD_CASEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameGSMEnum =
{
   (Data *)"GSM",
   CM_SDP_ENC_GSM
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameGSMStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding GSM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 32,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameGSMEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_GSM_HREnum =
{
   (Data *)"X-GSM-HR",
   CM_SDP_ENC_X_GSM_HR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_GSM_HRStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_GSM_HR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 33,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_GSM_HREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_GSM_EFREnum =
{
   (Data *)"X-GSM-EFR",
   CM_SDP_ENC_X_GSM_EFR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_GSM_EFRStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_GSM_EFR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 34,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_GSM_EFREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_GSM_EHREnum =
{
   (Data *)"X-GSM-EHR",
   CM_SDP_ENC_X_GSM_EHR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_GSM_EHRStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_GSM_EHR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 35,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_GSM_EHREnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_FXDMOD_3Enum =
{
   (Data *)"X-FXDMOD-3",
   CM_SDP_ENC_X_FXDMOD_3
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_FXDMOD_3Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_FXDMOD_3",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 36,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_FXDMOD_3Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncName1016Enum =
{
   (Data *)"1016",
   CM_SDP_ENC_1016
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncName1016Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding 1016",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 37,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncName1016Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameDVI4Enum =
{
   (Data *)"DVI4",
   CM_SDP_ENC_DVI4
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameDVI4Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding DVI4",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 38,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameDVI4Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameL16Enum =
{
   (Data *)"L16",
   CM_SDP_ENC_L16
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameL16Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding L16",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 39,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameL16Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameLPCEnum =
{
   (Data *)"LPC",
   CM_SDP_ENC_LPC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameLPCStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding LPC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 40,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameLPCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameMPAEnum =
{
   (Data *)"MPA",
   CM_SDP_ENC_MPA
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameMPAStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding MPA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 41,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameMPAEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameQCELPEnum =
{
   (Data *)"QCELP",
   CM_SDP_ENC_QCELP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameQCELPStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding QCELP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 42,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameQCELPEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameJPEGEnum =
{
   (Data *)"JPEG",
   CM_SDP_ENC_JPEG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameJPEGStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding JPEG",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 43,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameJPEGEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameH261Enum =
{
   (Data *)"H261",
   CM_SDP_ENC_H261
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameH261Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding H261",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 44,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameH261Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameMPVEnum =
{
   (Data *)"MPV",
   CM_SDP_ENC_MPV
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameMPVStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding MPV",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 45,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameMPVEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameMP2TEnum =
{
   (Data *)"MP2T",
   CM_SDP_ENC_MP2T
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameMP2TStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding MP2T",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 46,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameMP2TEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameNVEnum =
{
   (Data *)"nv",
   CM_SDP_ENC_NV
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameNVStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding NV",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 47,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameNVEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameREDEnum =
{
   (Data *)"RED",
   CM_SDP_ENC_RED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameREDStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding RED",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 48,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameREDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameX_REDEnum =
{
   (Data *)"X-RED",
   CM_SDP_ENC_X_RED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameX_REDStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding X_RED",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 49,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameX_REDEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameCELBEnum =
{
   (Data *)"CelB",
   CM_SDP_ENC_CELB
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameCELBStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding CELB",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 50,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameCELBEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameL8Enum =
{
   (Data *)"L8",
   CM_SDP_ENC_L8
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameL8Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding L8",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 51,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameL8Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameVDVIEnum =
{
   (Data *)"VDVI",
   CM_SDP_ENC_VDVI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameVDVIStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding VDVI",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 52,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameVDVIEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameH263Enum =
{
   (Data *)"H263",
   CM_SDP_ENC_H263
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameH263Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding H263",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 53,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameH263Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameH263_1998Enum =
{
   (Data *)"H263-1998",
   CM_SDP_ENC_H263_1998
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameH263_1998Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding H263-1998",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 54,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameH263_1998Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameMP1SEnum =
{
   (Data *)"MP1S",
   CM_SDP_ENC_MP1S
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameMP1SStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding MP1S",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 55,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameMP1SEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameMP2PEnum =
{
   (Data *)"MP2P",
   CM_SDP_ENC_MP2P
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameMP2PStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding MP2P",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 56,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameMP2PEnum,
   NULLP
};

#ifdef CM_SDP_V_3

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameL20Enum =
{
   (Data *)"L20",
   CM_SDP_ENC_L20
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameL20Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding L20",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 56,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameL20Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameL24Enum =
{
   (Data *)"L24",
   CM_SDP_ENC_L24
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameL24Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding L24",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 56,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameL24Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameDat12Enum =
{
   (Data *)"DAT12",
   CM_SDP_ENC_DAT12
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameDat12Str =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding DAT12",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 56,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameDat12Enum,
   NULLP
};

/* 004.main_7: added new message definitions here */
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameTelephoneEventEnum =
{
   (Data *)"telephone-event",
   CM_SDP_ENC_TELEPHONE_EVENT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameTelephoneEventStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding Telephone-event",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1030,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameTelephoneEventEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameCNEnum =
{
   (Data *)"CN",
   CM_SDP_ENC_CN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameCNStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding CN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1031,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameCNEnum,
   NULLP
};
#endif   /*  CM_SDP_V_3  */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEncNameUnknownEnum =
{
   (Data *)NULLP,
   CM_SDP_ENC_UNKNOWN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameUnknownStr =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding Unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 57,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEncNameUnknownEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpEncNameUnknownRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameUnknown =
{
#ifdef CM_ABNF_DBG
   "SDP EncNameUnknown",
   "SDPEncUnknown",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 58,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpEncNameUnknownRng,
   cmSdpRegExpEncUnknown
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEncodingNameChcEnum[] =
{
  /*  0 */   &cmMsgDefSdpNil,
  /*  1 */   &cmMsgDefSdpEncNameUnknownStr,
  /*  2 */   &cmMsgDefSdpEncNamePCMGStr,
  /*  3 */   &cmMsgDefSdpEncNameSIDGStr,
  /*  4 */   &cmMsgDefSdpEncNameSID729Str,
  /*  5 */   &cmMsgDefSdpEncNamePCMUStr,
  /*  6 */   &cmMsgDefSdpEncNameG726_32Str,
  /*  7 */   &cmMsgDefSdpEncNameG723Str,
  /*  8 */   &cmMsgDefSdpEncNamePCMAStr,
  /*  9 */   &cmMsgDefSdpEncNameG722Str,
  /* 10 */   &cmMsgDefSdpEncNameG728Str,
  /* 11 */   &cmMsgDefSdpEncNameG729Str,
  /* 12 */   &cmMsgDefSdpEncNameX_G729AStr,
  /* 13 */   &cmMsgDefSdpEncNameX_G729BStr,
  /* 14 */   &cmMsgDefSdpEncNameX_G729ABStr,
  /* 15 */   &cmMsgDefSdpEncNameX_G726_16Str,
  /* 16 */   &cmMsgDefSdpEncNameX_G726_24Str,
  /* 17 */   &cmMsgDefSdpEncNameX_G726_40Str,
  /* 18 */   &cmMsgDefSdpEncNameX_G7231_HStr,
  /* 19 */   &cmMsgDefSdpEncNameX_G7231_LStr,
  /* 20 */   &cmMsgDefSdpEncNameX_G7231A_HStr,
  /* 21 */   &cmMsgDefSdpEncNameX_G7231A_LStr,
  /* 22 */   &cmMsgDefSdpEncNameX_G727_16Str,
  /* 23 */   &cmMsgDefSdpEncNameX_G727_24Str,
  /* 24 */   &cmMsgDefSdpEncNameX_G727_32Str,
  /* 25 */   &cmMsgDefSdpEncNameX_CCDStr,
  /* 26 */   &cmMsgDefSdpEncNameX_CCD_CASStr,
  /* 27 */   &cmMsgDefSdpEncNameGSMStr,
  /* 28 */   &cmMsgDefSdpEncNameX_GSM_HRStr,
  /* 29 */   &cmMsgDefSdpEncNameX_GSM_EFRStr,
  /* 30 */   &cmMsgDefSdpEncNameX_GSM_EHRStr,
  /* 31 */   &cmMsgDefSdpEncNameX_FXDMOD_3Str,
  /* 32 */   &cmMsgDefSdpEncName1016Str,
  /* 33 */   &cmMsgDefSdpEncNameDVI4Str,
  /* 34 */   &cmMsgDefSdpEncNameL16Str,
  /* 35 */   &cmMsgDefSdpEncNameLPCStr,
  /* 36 */   &cmMsgDefSdpEncNameMPAStr,
  /* 37 */   &cmMsgDefSdpEncNameQCELPStr,
  /* 38 */   &cmMsgDefSdpEncNameJPEGStr,
  /* 39 */   &cmMsgDefSdpEncNameH261Str,
  /* 40 */   &cmMsgDefSdpEncNameMPVStr,
  /* 41 */   &cmMsgDefSdpEncNameMP2TStr,
  /* 42 */   &cmMsgDefSdpEncNameNVStr,
  /* 43 */   &cmMsgDefSdpEncNameREDStr,
  /* 44 */   &cmMsgDefSdpEncNameX_REDStr,
  /* 45 */   &cmMsgDefSdpEncNameCELBStr,
  /* 46 */   &cmMsgDefSdpEncNameL8Str,
  /* 47 */   &cmMsgDefSdpEncNameVDVIStr,
  /* 48 */   &cmMsgDefSdpEncNameH263Str,
  /* 49 */   &cmMsgDefSdpEncNameH263_1998Str,
  /* 50 */   &cmMsgDefSdpEncNameMP1SStr,
  /* 51 */   &cmMsgDefSdpEncNameMP2PStr

#ifdef CM_SDP_V_3
  /* 52 */   , &cmMsgDefSdpEncNameL20Str,
  /* 53 */   &cmMsgDefSdpEncNameL24Str,
  /* 54 */   &cmMsgDefSdpEncNameDat12Str,
/*004.main_7: added new message defs here */
  /* 55 */   &cmMsgDefSdpEncNameTelephoneEventStr,
  /* 56 */   &cmMsgDefSdpEncNameCNStr,
#endif
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEncNameUnknownEncSeqElmnt[] =
{
   &cmMsgDefSdpEncNameUnknownStr,
   &cmMsgDefSdpEncNameUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpEncNameUnknownEncSeq =
{
   2,
   cmMsgDefSdpEncNameUnknownEncSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncNameUnknownEnc =
{
#ifdef CM_ABNF_DBG
   "SDP EncNameUnknownEnc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 59,
   sizeof(CmSdpEncName),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpEncNameUnknownEncSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpEncodingNameKnownChc =
{
#ifdef CM_SDP_V_3
  /* 55,  004.main_7: modified this figure */
   57,
#else
   52,
#endif
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpEncodingNameChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncodingNameKnown =
{
#ifdef CM_ABNF_DBG
   "SDP EncodingNameKnown",
   "SDPEncodingName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 60,
   sizeof(CmSdpEncName),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpEncodingNameKnownChc,
   cmSdpRegExpSDPEncodingName
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEncodingNameChcElmnt[] =
{
   &cmMsgDefSdpEncodingNameKnown,
   &cmMsgDefSdpEncNameUnknownEnc,
};

PUBLIC U8 cmMsgDefSdpEncodingNameChcIdx[] =
{
   0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
   0, 0,
#ifdef CM_SDP_V_3
   0, 0, 0, 0, 0                /* 004.main_7: added two indices */
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpEncodingNameChc =
{
   2,
#ifdef CM_SDP_V_3
  /* 55,  004.main_7: modified this figure */
   57,
#else
   52,
#endif
   cmMsgDefSdpEncodingNameChcIdx,
   cmMsgDefSdpEncodingNameChcElmnt,
   NULLP,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEncodingName =
{
#ifdef CM_ABNF_DBG
   "SDP Encoding name",
   "SDPEncodingName",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 61,
   sizeof(CmSdpEncName),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpEncodingNameChc,
   cmSdpRegExpSDPEncodingName
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSpecEnum =
{
   (Data *)NULLP,
   CM_SDP_SPEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSpec =
{
#ifdef CM_ABNF_DBG
   "SDP specified",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 62,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSpecEnum,
   NULLP
};

/************************************************************************
                         SDP Generic Types
*************************************************************************/
#ifdef CM_SDP_V_3

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpDecUcharm1Rng = {3, 3, 224, 239};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpDecUcharm1Rng = {3, 3};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpm1 =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal m1",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 751 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT8,
   (U8 *)&cmMsgDefSdpDecUcharm1Rng,
   cmSdpRegExpm1
};
#endif

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpDecUcharRng = {1, 3, 0, 255};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpDecUcharRng = {1, 3};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpDecUchar =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal Uchar",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 63,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT8,
   (U8 *)&cmMsgDefSdpDecUcharRng,
   cmAbnfRegExpDgt
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpDecU16Rng = {1, 5, 0, 65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpDecU16Rng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU16 =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U16",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 64,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpDecU16Rng,
   cmAbnfRegExpDgt
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpDecU32Rng = {1, 10, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpDecU32Rng = {1, 10};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU32 =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U32",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 65,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpDecU32Rng,
   cmAbnfRegExpDgt
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpGenU8Rng = {1, 4, 0, 255};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpGenU8Rng = {1, 4};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU8 =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U8 (hex or decimal)",
   "SDPGenUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 66,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT8,
   (U8 *)&cmMsgDefSdpGenU8Rng,
   cmSdpRegExpGenUint
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpGenU16Rng = {1, 6, 0, 65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpGenU16Rng = {1, 6};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU16 =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U16 (hex or decimal)",
   "SDPGenUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 67,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpGenU16Rng,
   cmSdpRegExpGenUint
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpHexU32Rng = {1, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpHexU32Rng = {1, 8};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpHexU32 =
{
#ifdef CM_ABNF_DBG
   "SDP Hex U32",
   "CM_RXDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 68,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_HEXUINT32,
   (U8 *)&cmMsgDefSdpHexU32Rng,
   cmAbnfRegExpXDgt
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpGenU32Rng = {1, 10, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpGenU32Rng = {1, 10};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU32 =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U32 (hex or decimal)",
   "SDPGenUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 69,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpGenU32Rng,
   cmSdpRegExpGenUint
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipU8Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipU8 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipU8",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 70,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipU8Rng,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU8OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU8,
   &cmMsgDefSdpGenU8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU8OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU8OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU8OrNullChcElmnt,
   cmMsgDefSdpGenU8OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU8OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U8 or null",
   "SDPGenUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 71,
   sizeof(CmSdpU8OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU8OrNullChc,
   cmSdpRegExpGenUintOrNull
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipU16Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipU16 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipU16",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 72,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipU16Rng,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU16OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU16,
   &cmMsgDefSdpGenU16
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU16OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU16OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU16OrNullChcElmnt,
   cmMsgDefSdpGenU16OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU16OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U16 or null",
   "SDPGenUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 73,
   sizeof(CmSdpU16OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU16OrNullChc,
   cmSdpRegExpGenUintOrNull
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipU32Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipU32 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipU32",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 74,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipU32Rng,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU32OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU32,
   &cmMsgDefSdpGenU32
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU32OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU32OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU32OrNullChcElmnt,
   cmMsgDefSdpGenU32OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU32OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U32 or null",
   "SDPGenUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 75,
   sizeof(CmSdpU32OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU32OrNullChc,
   cmSdpRegExpGenUintOrNull
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU8OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU8,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU8OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpDecU8OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpDecU8OrNullChcElmnt,
   cmMsgDefSdpDecU8OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU8OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U8 or null",
   "SDPDecUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 76,
   sizeof(CmSdpU8OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpDecU8OrNullChc,
   cmSdpRegExpDecUintOrNull
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU16OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU16,
   &cmMsgDefSdpDecU16
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU16OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpDecU16OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpDecU16OrNullChcElmnt,
   cmMsgDefSdpDecU16OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU16OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U16 or null",
   "SDPDecUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 77,
   sizeof(CmSdpU16OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpDecU16OrNullChc,
   cmSdpRegExpDecUintOrNull
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU32OrNullChcElmnt[] =
{
   &cmMsgDefSdpSkipU32,
   &cmMsgDefSdpDecU32
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU32OrNullChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpDecU32OrNullChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpDecU32OrNullChcElmnt,
   cmMsgDefSdpDecU32OrNullChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU32OrNull =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U32 or null",
   "SDPDecUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 78,
   sizeof(CmSdpU32OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpDecU32OrNullChc,
   cmSdpRegExpDecUintOrNull
};

/************************************************************************
                              SDP Version
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVerStrMeta = {(Data *)"v="};
PUBLIC CmAbnfElmDef cmMsgDefSdpVerStr =
{
#ifdef CM_ABNF_DBG
   "SDP VERSTR",
   "SDPR1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 79,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVerStrMeta,
   cmSdpRegExpR1
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpVerValRng = {1, 4, 0, 9999};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpVerValRng = {1, 4};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpVerVal =
{
#ifdef CM_ABNF_DBG
   "SDP VERVAL",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 80,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpVerValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVerSeqElmnt[] =
{
   &cmMsgDefSdpVerStr,
   &cmMsgDefSdpVerVal,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVerSeq =
{
   3,
   cmMsgDefSdpVerSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVer =
{
#ifdef CM_ABNF_DBG
   "SDP VER",
   "SDPR1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 81,
   sizeof(TknU16),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED)<<CM_ABNF_PROT_SDP_DEF_OFFSET|
   (CM_ABNF_OPTIONAL |CM_ABNF_TKN_NOT_CONSUMED)<< CM_ABNF_PROT_SDP_OPT_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpVerSeq,
   cmSdpRegExpR1
};

/************************************************************************
                  Components of SDP Origin Field
*************************************************************************/

/************************************************************************
                             SDP User Name
*************************************************************************/
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUsrNameRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpUsrName =
{
#ifdef CM_ABNF_DBG
   "SDP USRNAME",
   "SDPR3",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 82,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpUsrNameRng,
   cmSdpRegExpR3
};

/************************************************************************
                         SDP session ID
*************************************************************************/
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSsIdRng = {1, 34};
PUBLIC CmAbnfElmDef cmMsgDefSdpSsId =
{
#ifdef CM_ABNF_DBG
   "SDP SSID",
   "SDPGenUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 83,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpSsIdRng,
   cmSdpRegExpGenUint
};

/************************************************************************
                         SDP Session Version
*************************************************************************/
/* cm_sdpdb_c_001.main_2: deleted IntRange/Range 1..10 for SsVer
 * because its type changed from TknU32 to TknStrOSXL.
 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSsVerRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpSsVer =
{
#ifdef CM_ABNF_DBG
   "SDP SSVER",
   "SDPGenUint",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 84,
   sizeof(TknStrOSXL), /* cm_sdpdb_c_001.main_2: changed from TknU32 */
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL, /* cm_sdpdb_c_001.main_2: changed from UINT32 */
   (U8 *)&cmMsgDefSdpSsVerRng,
   cmSdpRegExpGenUint
};

/************************************************************************
                     SDP FQDN
*************************************************************************/
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpInIpFqdnRng = {4, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIpFqdn =
{
#ifdef CM_ABNF_DBG
   "SDP FQDN def",
   "SDPFQDN",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 85,
   sizeof(CmSdpIpFQDN),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpInIpFqdnRng,
   cmSdpRegExpFQDN
};

/************************************************************************
                   SDP IPV4 Unicast Address
*************************************************************************/
PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp4IpSeqElmnt[] =
{
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaDot,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaDot,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaDot,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpInIp4IpSeq =
{
   7,
   cmMsgDefSdpInIp4IpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4Ip =
{
#ifdef CM_ABNF_DBG
   "SDP IPV4 unicast address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 86,
   sizeof(CmSdpIp4Unicast),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpInIp4IpSeq,
   NULLP
};

/************************************************************************
                     SDP IP4 Address Enums
*************************************************************************/
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp4FqdnEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV4_FQDN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4FqdnStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP4 FQDN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 87,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp4FqdnEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp4IpUniEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV4_IP_UNI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4IpUniStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP4 IP unicast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 88,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp4IpUniEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp4IpMultiEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV4_IP_MULTI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4IpMultiStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP4 IP multicast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 89,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp4IpMultiEnum,
   NULLP
};

/************************************************************************
                     SDP IP4 Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipIp4AddrRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipIp4Addr =
{
#ifdef CM_ABNF_DBG
   "SDP Skip Ip4Addr",
   "SDPIpv4AddrType",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 90,
   sizeof(((CmSdpIp4Addr *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipIp4AddrRng,
   cmSdpRegExpIpv4AddrType
};

EXTERN CmAbnfElmDef cmMsgDefSdpInIp4IpMulti;
EXTERN CmAbnfElmDef cmMsgDefSdpDollarIpAddr;

PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp4AddrChcElmnt[] =
{
   &cmMsgDefSdpSkipIp4Addr,
   &cmMsgDefSdpInIpFqdn,
   &cmMsgDefSdpInIp4Ip,
   NULLP,   /* no multicast allowed */
   &cmMsgDefSdpSkipIp4Addr,
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp4AddrChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpInIp4FqdnStr,
   &cmMsgDefSdpInIp4IpUniStr,
   NULLP,   /* no multicast allowed */
   &cmMsgDefSdpDollarIpAddr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpInIp4AddrChc =
{
   5,
   0,
   NULLP,
   cmMsgDefSdpInIp4AddrChcElmnt,
   cmMsgDefSdpInIp4AddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4Addr =
{
#ifdef CM_ABNF_DBG
   "SDP IPV4 address",
   "SDPIpv4AddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 91,
   sizeof(CmSdpIp4Addr),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpInIp4AddrChc,
   cmSdpRegExpIpv4AddrType
};

/************************************************************************
                  SDP IPV6 Address
*************************************************************************/

/* following is being placed up starting here */
PUBLIC CmAbnfElmDef *cmMsgDefSdpSlashIntSeqElmnt[] =
{
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpDecU32
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSlashIntSeq =
{
   2,
   cmMsgDefSdpSlashIntSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSlashInt =
{
#ifdef CM_ABNF_DBG
   "SDP / integer",
   "CM_RSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 752 ,
   sizeof(TknU32),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpSlashIntSeq,
   cmAbnfRegExpSlash
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp4IpMultiSeqElmnt[] =
{
   &cmMsgDefSdpInIp4Ip,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpDecUchar,   /* ttl */
   &cmMsgDefSdpSlashInt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpInIp4IpMultiSeq =
{
   4,
   cmMsgDefSdpInIp4IpMultiSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp4IpMulti =
{
#ifdef CM_ABNF_DBG
   "SDP IPV4 multicast address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 753 ,
   sizeof(CmSdpIp4Multicast),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpInIp4IpMultiSeq,
   NULLP
};
/* above is being placed up  */

#ifdef CM_SDP_V_3
PUBLIC CmAbnfElmDef  *cmMsgDefSdpInIp4IpColonMultiOptSeqSeqElmnts[] =
{
    &cmMsgDefMetaColon ,
    &cmMsgDefSdpInIp4IpMulti    /* forward reference */
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpInIp4IpColonMultiOptSeqSeq =
{
    2 ,
    cmMsgDefSdpInIp4IpColonMultiOptSeqSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpInIp4IpColonMultiOptSeq =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP IN IP4 IP COLON MULTI OPT SEQ " ,
    "cmAbnfRegExpColon" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 754 ,
    sizeof(CmSdpIp4Multicast) ,
    ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &cmMsgDefSdpInIp4IpColonMultiOptSeqSeq ,
    cmAbnfRegExpColon
};

PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpIpv6HexPrtRange =  {   1 , 0xffff  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpIpv6HexPrt =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP IPV6 HEX PRT " ,
    "cmSdpRegExpIp6HexPart" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 755 ,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &cmMsgDefSdpIpv6HexPrtRange ,
    cmSdpRegExpIp6HexPart
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpInIp6IpMultiCastSeqElmnts[] =
{
    &cmMsgDefSdpIpv6HexPrt ,
    &cmMsgDefSdpInIp4IpColonMultiOptSeq ,
    &cmMsgDefMetaSlash ,
    &cmMsgDefSdpDecUchar ,
    &cmMsgDefSdpSlashInt       /* forward reference */
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpInIp6IpMultiCastSeq =
{
    5 ,
    cmMsgDefSdpInIp6IpMultiCastSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpInIp6IpMultiCast =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP IN IP6 IP MULTI CAST " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 756 ,
    sizeof(CmSdpIp6MultiCast) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpInIp6IpMultiCastSeq ,
    NULLP
};


#endif

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpInIp6IpRng = {1, 55};
PUBLIC CmAbnfElmDef cmMsgDefSdpInIp6Ip =
{
#ifdef CM_ABNF_DBG
   "SDP IPV6 address",
   "Ipv6",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 92,
   sizeof(CmSdpIp6),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpInIp6IpRng,
   cmSdpRegExpIpv6
};

/************************************************************************
                     SDP IP6 Address Enums
*************************************************************************/
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp6FqdnEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV6_FQDN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp6FqdnStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP6 FQDN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 93,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp6FqdnEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp6IpEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV6_IP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp6IpStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP6 IP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 94,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp6IpEnum,
   NULLP
};

#ifdef CM_SDP_V_3

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpInIp6IpMultiCastEnum =
{
   (Data *)NULLP,
   CM_SDP_IPV6_MULTI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp6IpMultiCastStr =
{
#ifdef CM_ABNF_DBG
   "SDP IP6 IP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 757 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpInIp6IpMultiCastEnum,
   NULLP
};

#endif  /*  CM_SDP_V_3  */

/************************************************************************
                        SDP IPv6 Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipIp6AddrRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipIp6Addr =
{
#ifdef CM_ABNF_DBG
   "SDP Skip Ip6Addr",
   "SDPIpv6AddrType",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 95,
   sizeof(((CmSdpIp6Addr *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipIp6AddrRng,
   cmSdpRegExpIpv6AddrType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp6AddrChcElmnt[] =
{
   &cmMsgDefSdpSkipIp6Addr,
   &cmMsgDefSdpInIpFqdn,
   &cmMsgDefSdpInIp6Ip
#ifdef CM_SDP_V_3
 , &cmMsgDefSdpInIp6IpMultiCast
#endif
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInIp6AddrChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpInIp6FqdnStr,
   &cmMsgDefSdpInIp6IpStr
#ifdef CM_SDP_V_3
   , &cmMsgDefSdpInIp6IpMultiCastStr
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpInIp6AddrChc =
{
#ifdef CM_SDP_V_3
   4,
#else
   3,
#endif
   0,
   NULLP,
   cmMsgDefSdpInIp6AddrChcElmnt,
   cmMsgDefSdpInIp6AddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInIp6Addr =
{
#ifdef CM_ABNF_DBG
   "SDP IPV6 address",
   "SDPIpv6AddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 96,
   sizeof(CmSdpIp6Addr),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpInIp6AddrChc,
   cmSdpRegExpIpv6AddrType
};

#ifdef CM_SDP_ATM_SUPPORT
/************************************************************************
                        SDP E164 Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAtmE164Rng = {1, 15};

PUBLIC CmAbnfElmDef cmMsgDefSdpAtmE164Addr =
{
#ifdef CM_ABNF_DBG
   "SDP E164 address def",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 97,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAtmE164Rng,
   cmAbnfRegExpDgt
};

/************************************************************************
                   SDP ATM NSAP Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAtmNsapAddrRng = {1, 52};

PUBLIC CmAbnfElmDef cmMsgDefSdpAtmNsapAddr =
{
#ifdef CM_ABNF_DBG
   "SDP NSAP address def",
   "SDPNsapAddr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 98,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAtmNsapAddrRng,
   cmSdpRegExpNsapAddr
};

/************************************************************************
                        SDP Gwid Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAtmGwidRng = {1, 34};

PUBLIC CmAbnfElmDef cmMsgDefSdpAtmGwidAddr =
{
#ifdef CM_ABNF_DBG
   "SDP Gwid address def",
   "SDPGwidAddr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 99,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAtmGwidRng,
   cmSdpRegExpGwidAddr
};

#endif /* CM_SDP_ATM_SUPPORT */
/************************************************************************
                     SDP Address Type Enums
*************************************************************************/

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeNilNilEnum =
{
   (Data *)"- -",
   CM_SDP_ADDR_TYPE_NIL_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeNilNilStr =
{
#ifdef CM_ABNF_DBG
   "SDP - -",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 100,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeNilNilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeNilChooseEnum =
{
   (Data *)"- $",
   CM_SDP_ADDR_TYPE_NIL_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeNilChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP - $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 101,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeNilChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeChooseNilEnum =
{
   (Data *)"$ -",
   CM_SDP_ADDR_TYPE_CHOOSE_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeChooseNilStr =
{
#ifdef CM_ABNF_DBG
   "SDP $ -",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 102,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeChooseNilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeChooseChooseEnum =
{
   (Data *)"$ $",
   CM_SDP_ADDR_TYPE_CHOOSE_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeChooseChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP $ $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 103,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeChooseChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeNsapEnum =
{
   (Data *)"NSAP ",
   CM_SDP_ADDR_TYPE_NSAP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeNsapStr =
{
#ifdef CM_ABNF_DBG
   "SDP NSAP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 104,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeNsapEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeE164Enum =
{
   (Data *)"E164 ",
   CM_SDP_ADDR_TYPE_E164
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeE164Str =
{
#ifdef CM_ABNF_DBG
   "SDP E164",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 105,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeE164Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeGwidEnum =
{
   (Data *)"GWID ",
   CM_SDP_ADDR_TYPE_GWID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeGwidStr =
{
#ifdef CM_ABNF_DBG
   "SDP GWID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 106,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeGwidEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeAliasEnum =
{
   (Data *)"ALIAS ",
   CM_SDP_ADDR_TYPE_ALIAS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeAliasStr =
{
#ifdef CM_ABNF_DBG
   "SDP ALIAS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 107,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeAliasEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeNsapChooseEnum =
{
   (Data *)"NSAP $",
   CM_SDP_ADDR_TYPE_NSAP_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeNsapChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP NSAP_CHOOSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 108,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeNsapChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeE164ChooseEnum =
{
   (Data *)"E164 $",
   CM_SDP_ADDR_TYPE_E164_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeE164ChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP E164_CHOOSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 109,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeE164ChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeGwidChooseEnum =
{
   (Data *)"GWID $",
   CM_SDP_ADDR_TYPE_GWID_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeGwidChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP GWID_CHOOSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 110,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeGwidChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeAliasChooseEnum =
{
   (Data *)"ALIAS $",
   CM_SDP_ADDR_TYPE_ALIAS_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeAliasChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP ALIAS_CHOOSE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 111,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeAliasChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeNsapNilEnum =
{
   (Data *)"NSAP -",
   CM_SDP_ADDR_TYPE_NSAP_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeNsapNilStr =
{
#ifdef CM_ABNF_DBG
   "SDP NSAP_NIL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 112,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeNsapNilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeE164NilEnum =
{
   (Data *)"E164 -",
   CM_SDP_ADDR_TYPE_E164_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeE164NilStr =
{
#ifdef CM_ABNF_DBG
   "SDP E164_NIL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 113,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeE164NilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeGwidNilEnum =
{
   (Data *)"GWID -",
   CM_SDP_ADDR_TYPE_GWID_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeGwidNilStr =
{
#ifdef CM_ABNF_DBG
   "SDP GWID_NIL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 114,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeGwidNilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeAliasNilEnum =
{
   (Data *)"ALIAS -",
   CM_SDP_ADDR_TYPE_ALIAS_NIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeAliasNilStr =
{
#ifdef CM_ABNF_DBG
   "SDP ALIAS_NIL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 115,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeAliasNilEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeIP6StrEnum =
{
   (Data *)"IP6 ",
   CM_SDP_ADDR_TYPE_IPV6
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeIP6Str =
{
#ifdef CM_ABNF_DBG
   "SDP IP6STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 116,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeIP6StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeIP4StrEnum =
{
   (Data *)"IP4 ",
   CM_SDP_ADDR_TYPE_IPV4
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeIP4Str =
{
#ifdef CM_ABNF_DBG
   "SDP IP4STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 117,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeIP4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeRFC2543Enum =
{
   (Data *)"RFC2543 ",
   CM_SDP_ADDR_TYPE_RFC2543
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeRFC2543Str =
{
#ifdef CM_ABNF_DBG
   "SDP RFC2543",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 118,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeRFC2543Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeXTokenEnum =
{
   (Data *)"X-",
   CM_SDP_ADDR_TYPE_XTOKEN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeXTokenStr =
{
#ifdef CM_ABNF_DBG
   "SDP X-Token",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 119,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeXTokenEnum,
   NULLP
};

/************************************************************************
                     SDP Address-Type Address
*************************************************************************/

EXTERN CmAbnfElmDef cmMsgDefSdpTnRFC2543Addr;
EXTERN CmAbnfElmDef cmMsgDefSdpTnXTokenAddr;

PUBLIC CmAbnfElmDef *cmMsgDefSdpAddrTypeAddrChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpInIp4Addr,
   &cmMsgDefSdpInIp6Addr,
   &cmMsgDefSdpTnRFC2543Addr,
   &cmMsgDefSdpTnXTokenAddr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAtmNsapAddr,
   &cmMsgDefSdpAtmE164Addr,
   &cmMsgDefSdpAtmGwidAddr,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAddrTypeAddrChcEnum[] =
{
   &cmMsgDefSdpAddrTypeNilNilStr,      /* 0  -> 0 */ 
   &cmMsgDefSdpAddrTypeNilChooseStr,   /* 1  -> 0 */
   &cmMsgDefSdpAddrTypeChooseNilStr,   /* 2  -> 0 */
   &cmMsgDefSdpAddrTypeChooseChooseStr,/* 3  -> 0 */
   &cmMsgDefSdpAddrTypeIP4Str,         /* 4  -> 1 */
   &cmMsgDefSdpAddrTypeIP6Str,         /* 5  -> 2 */
   &cmMsgDefSdpAddrTypeRFC2543Str,     /* 6  -> 3 */
   &cmMsgDefSdpAddrTypeXTokenStr,      /* 7  -> 4 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAddrTypeNsapStr,        /* 8  -> 5 */
   &cmMsgDefSdpAddrTypeE164Str,        /* 9  -> 6 */
   &cmMsgDefSdpAddrTypeGwidStr,        /* 10 -> 7 */
   &cmMsgDefSdpAddrTypeAliasStr,       /* 11 -> 7 */
   &cmMsgDefSdpAddrTypeNsapChooseStr,  /* 12 -> 0 */
   &cmMsgDefSdpAddrTypeE164ChooseStr,  /* 13 -> 0 */
   &cmMsgDefSdpAddrTypeGwidChooseStr,  /* 14 -> 0 */
   &cmMsgDefSdpAddrTypeAliasChooseStr, /* 15 -> 0 */
   &cmMsgDefSdpAddrTypeNsapNilStr,     /* 16 -> 0 */
   &cmMsgDefSdpAddrTypeE164NilStr,     /* 17 -> 0 */
   &cmMsgDefSdpAddrTypeGwidNilStr,     /* 18 -> 0 */
   &cmMsgDefSdpAddrTypeAliasNilStr,    /* 19 -> 0 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   NULLP    /* 003.main_2 addition */
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC U8 cmMsgDefSdpAddrTypeAddrChcIdx[] = 
   {0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 7, 0, 0, 0, 0, 0, 0, 0, 0,0};/* 003.main_2 addition */
#else /* !CM_SDP_ATM_SUPPORT */
PUBLIC U8 cmMsgDefSdpAddrTypeAddrChcIdx[] = 
   {0, 0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0};/* 003.main_2 addition */
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAddrTypeAddrChc =
{
   8,
   21,               /* 003.main_2 changed */
   cmMsgDefSdpAddrTypeAddrChcIdx,
   cmMsgDefSdpAddrTypeAddrChcElmnt,
   cmMsgDefSdpAddrTypeAddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeAddr =
{
#ifdef CM_ABNF_DBG
   "SDP address-type address",
   "SDPAddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 120,
   /* cm_sdpdb_c_001.main_2 - Change: Old was sizeof(CmSdpAddr) */
   sizeof(CmSdpAddr) - sizeof(TknU8), 
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAddrTypeAddrChc,
   cmSdpRegExpAddrType
};

/************************************************************************
                        TN Address
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTnRFC2543AddrRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpTnRFC2543Addr =
{
#ifdef CM_ABNF_DBG
   "SDP TN RFC2543 address",
   "SDPRfc2543Addr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 121,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpTnRFC2543AddrRng,
   cmSdpRegExpRfc2543Addr
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTnExtnFormatRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpTnExtnFormat =
{
#ifdef CM_ABNF_DBG
   "SDP TN X-Token Token",
   "SDPToken",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 122,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpTnExtnFormatRng,
   cmSdpRegExpToken
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTnExtnPhoneRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpTnExtnPhone =
{
#ifdef CM_ABNF_DBG
   "SDP TN X-Token Phone",
   "SDPUri",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 123,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpTnExtnPhoneRng,
   cmSdpRegExpUri
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTnXTokenAddrSeqElmnt[] =
{
   &cmMsgDefSdpTnExtnFormat,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTnExtnPhone
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTnXTokenAddrSeq =
{
   3,
   cmMsgDefSdpTnXTokenAddrSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTnXTokenAddr =
{
#ifdef CM_ABNF_DBG
   "SDP TN XToken address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 124,
   sizeof(CmSdpTnExtn),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpTnXTokenAddrSeq,
   NULLP
};

/************************************************************************
                     SDP Net(Type) Enums
*************************************************************************/
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeINStrEnum =
{
   (Data *)"IN",
   CM_SDP_NET_TYPE_IN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeINStr =
{
#ifdef CM_ABNF_DBG
   "SDP INSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 125,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeINStrEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeATMStrEnum =
{
   (Data *)"ATM",
   CM_SDP_NET_TYPE_ATM
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeATMStr =
{
#ifdef CM_ABNF_DBG
   "SDP ATMSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 126,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeATMStrEnum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeTNStrEnum =
{
   (Data *)"TN",
   CM_SDP_NET_TYPE_TN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeTNStr =
{
#ifdef CM_ABNF_DBG
   "SDP TNSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 127,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeTNStrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeANYStrEnum =
{
   (Data *)"$",
   CM_SDP_NET_TYPE_ANY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeANYStr =
{
#ifdef CM_ABNF_DBG
   "SDP ANYSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 128,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeANYStrEnum,
   NULLP
};

/* 003.main_2 additions of new elements;*/ 
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeLCLStrEnum =
{
   (Data *)"LOCAL",
   CM_SDP_NET_TYPE_LCL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeLCLStr =
{
#ifdef CM_ABNF_DBG
   "SDP LCLSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 746,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeLCLStrEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeLCLStrEnum =
{
   (Data *)NULLP,
   CM_SDP_ADDR_TYPE_LCL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeLCLStr =
{
#ifdef CM_ABNF_DBG
   "SDP Addr LCLSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 745,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeLCLStrEnum,
   NULLP
};

/************************************************************************
                     SDP Net(Type) (Address)Type Address
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpNetTypeChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpNetTypeINStr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpNetTypeATMStr,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpNetTypeTNStr,
   &cmMsgDefSdpNetTypeANYStr,
   &cmMsgDefSdpNetTypeLCLStr              /* 003.main_2 additions */
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpNetTypeChc =
{
   6,    /* 003.main_2 changed from 5 to 6 */
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpNetTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetType =
{
#ifdef CM_ABNF_DBG
   "SDP NetType",
   "SDPR4",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 129,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpNetTypeChc,
   cmSdpRegExpR4
};

/************************************************************************
                              SDP Origin Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpOrigStrMeta = {(Data *)"o="};
PUBLIC CmAbnfElmDef cmMsgDefSdpOrigStr =
{
#ifdef CM_ABNF_DBG
   "SDP ORGNSTR",
   "SDPR2",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 130,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpOrigStrMeta,
   cmSdpRegExpR2
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOrigFieldSeqElmnt[] =
{
   &cmMsgDefSdpUsrName,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpSsId,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpSsVer,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpNetType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAddrTypeAddr,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOrigFieldSeq =
{
   9,
   cmMsgDefSdpOrigFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOrigField =
{
#ifdef CM_ABNF_DBG
   "SDP: ORGN1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 131,
   sizeof(CmSdpOrig),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpOrigFieldSeq,
   NULLP
};


PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipOrigRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipOrig =
{
#ifdef CM_ABNF_DBG
   "SDP Skip origin",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 132,
   sizeof(CmSdpOrig),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipOrigRng,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptOrigChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec,
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptOrigChcElmnt[] =
{
   &cmMsgDefSdpSkipOrig,
   &cmMsgDefSdpOrigField
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpOptOrigChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpOptOrigChcElmnt,
   cmMsgDefSdpOptOrigChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptOrig =
{
#ifdef CM_ABNF_DBG
   "ORGN or -",
   "SDPUsrNameOrHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 133,
   sizeof(CmSdpOptOrig) - sizeof(TknPres),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpOptOrigChc,
   cmSdpRegExpUsrNameOrHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOrigSeqElmnt[] =
{
   &cmMsgDefSdpOrigStr,
   &cmMsgDefSdpOptOrig,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOrigSeq =
{
   3,
   cmMsgDefSdpOrigSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOrig =
{
#ifdef CM_ABNF_DBG
   "SDP: ORGN2",
   "SDP R2",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 134,
   sizeof(CmSdpOptOrig),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED)<<CM_ABNF_PROT_SDP_DEF_OFFSET|
   (CM_ABNF_OPTIONAL |CM_ABNF_TKN_NOT_CONSUMED)<<CM_ABNF_PROT_SDP_OPT_OFFSET,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpOrigSeq,
   cmSdpRegExpR2
};

/************************************************************************
                              SDP Session Name Field
*************************************************************************/

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpSesNameStrMeta = {(Data *)"s="};
PUBLIC CmAbnfElmDef cmMsgDefSdpSesNameStr =
{
#ifdef CM_ABNF_DBG
   "SDP SSNNMSTR",
   "SDPR7",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 135,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpSesNameStrMeta,
   cmSdpRegExpR7
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTextRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpText =
{
#ifdef CM_ABNF_DBG
   "SDP TEXT",
   "SDPR8",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 136,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpTextRng,
   cmSdpRegExpR8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptTextSeqElmnt[] =
{
   &cmMsgDefSdpText
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptTextSeq =
{
   1,
   cmMsgDefSdpOptTextSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptText =
{
#ifdef CM_ABNF_DBG
   "SDP optional TEXT",
   "SDPR8",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 137,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY| CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptTextSeq,
   cmSdpRegExpR8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpSesNameSeqElmnt[] =
{
   &cmMsgDefSdpSesNameStr,
   &cmMsgDefSdpOptText,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSesNameSeq =
{
   3,
   cmMsgDefSdpSesNameSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSesName =
{
#ifdef CM_ABNF_DBG
   "SDP: SSNNM",
   "SDPR7",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 138,
   sizeof(TknStrOSXL),
   (CM_ABNF_MANDATORY|CM_ABNF_TKN_NOT_CONSUMED)<<CM_ABNF_PROT_SDP_DEF_OFFSET|
   (CM_ABNF_OPTIONAL |CM_ABNF_TKN_NOT_CONSUMED)<<CM_ABNF_PROT_SDP_OPT_OFFSET,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpSesNameSeq,
   cmSdpRegExpR7
};

/************************************************************************
                              SDP Information Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpInfoStrMeta = {(Data *)"i="};
PUBLIC CmAbnfElmDef cmMsgDefSdpInfoStr =
{
#ifdef CM_ABNF_DBG
   "SDP INFOSTR ",
   "SDPR9",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 139,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpInfoStrMeta,
   cmSdpRegExpR9
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInfoSeqElmnt[] =
{
   &cmMsgDefSdpInfoStr,
   &cmMsgDefSdpText,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpInfoSeq =
{
   3,
   cmMsgDefSdpInfoSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInfo =
{
#ifdef CM_ABNF_DBG
   "SDP: INFO ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 140,
   sizeof(TknStrOSXL),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpInfoSeq,
   cmSdpRegExpR9
};

/************************************************************************
                              SDP URI Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpUriStrMeta = {(Data *)"u="};
PUBLIC CmAbnfElmDef cmMsgDefSdpUriStr =
{
#ifdef CM_ABNF_DBG
   "SDP URISTR ",
   "SDPR10",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 141,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpUriStrMeta,
   cmSdpRegExpR10
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUriValRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpUriVal =
{
#ifdef CM_ABNF_DBG
   "SDP URI",
   "SDPUri",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 142,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpUriValRng,
   cmSdpRegExpUri
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUriSeqElmnt[] =
{
   &cmMsgDefSdpUriStr,
   &cmMsgDefSdpUriVal,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpUriSeq =
{
   3,
   cmMsgDefSdpUriSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUri =
{
#ifdef CM_ABNF_DBG
   "SDP: URI ",
   "SDPR10",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 143,
   sizeof(TknStrOSXL),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpUriSeq,
   cmSdpRegExpR10
};

/************************************************************************
                              SDP Email Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpEmailStrMeta = {(Data *)"e="};
PUBLIC CmAbnfElmDef cmMsgDefSdpEmailStr =
{
#ifdef CM_ABNF_DBG
   "SDP EMLSTR ",
   "SDPR12",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 144,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpEmailStrMeta,
   cmSdpRegExpR12
};

/************************************************************************
                   SDP Email in different formats
*************************************************************************/
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpEmailAddrEmailOnlyRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrEmailOnly =
{
#ifdef CM_ABNF_DBG
   "SDP Email Only string",
   "SDPAddrSpecRfc822",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 145,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpEmailAddrEmailOnlyRng,
   cmSdpRegExpAddrSpecRfc822
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpEmailSafeStringRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpEmailSafeString =
{
#ifdef CM_ABNF_DBG
   "SDP EmailSafeString",
   "SDPEmailSafeString",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 146,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpEmailSafeStringRng,
   cmSdpRegExpEmailSafe
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailSafeSeqElmnt[] =
{
   &cmMsgDefSdpEmailSafeString
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpEmailSafeSeq =
{
   1,
   cmMsgDefSdpEmailSafeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailSafe =
{
#ifdef CM_ABNF_DBG
   "SDP EmailSafe",
   "SDPEmailSafe",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 147,
   sizeof(TknStrOSXL),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpEmailSafeSeq,
   cmSdpRegExpEmailSafe
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailAddrEmailNameSeqElmnt[] =
{
   &cmMsgDefSdpEmailAddrEmailOnly,
   &cmMsgDefOptMetaSpace,   /* 003.main_2; added optional space */
   &cmMsgDefMetaOpenBrace,
   &cmMsgDefSdpEmailSafe,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpEmailAddrEmailNameSeq =
{
   5,      /* 003.main_2; changed from 4 to 5 */
   cmMsgDefSdpEmailAddrEmailNameSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrEmailName =
{
#ifdef CM_ABNF_DBG
   "SDP Email Name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 148,
   sizeof(CmSdpEmailName),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpEmailAddrEmailNameSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailAddrNameEmailSeqElmnt[] =
{
   &cmMsgDefSdpEmailSafe,
   &cmMsgDefOptMetaSpace,   /* 003.main_2; added optional space */
   &cmMsgDefMetaOpenAngleBrkt,
   &cmMsgDefSdpEmailAddrEmailOnly,
   &cmMsgDefMetaCloseAngleBrkt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpEmailAddrNameEmailSeq =
{
   5,       /* 003.main_2; changed from 4 to 5 */ 
   cmMsgDefSdpEmailAddrNameEmailSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrNameEmail =
{
#ifdef CM_ABNF_DBG
   "SDP Name Email",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 149,
   sizeof(CmSdpNameEmail),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpEmailAddrNameEmailSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEmailAddrEmailOnlyEnum =
{
   (Data *)NULLP,
   CM_SDP_EMAIL_ONLY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrEmailOnlyStr =
{
#ifdef CM_ABNF_DBG
   "SDP Email only",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 150,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEmailAddrEmailOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEmailAddrEmailNameEnum =
{
   (Data *)NULLP,
   CM_SDP_EMAIL_NAME
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrEmailNameStr =
{
#ifdef CM_ABNF_DBG
   "SDP Email Name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 151,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEmailAddrEmailNameEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEmailAddrNameEmailEnum =
{
   (Data *)NULLP,
   CM_SDP_NAME_EMAIL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddrNameEmailStr =
{
#ifdef CM_ABNF_DBG
   "SDP Name Email",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 152,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEmailAddrNameEmailEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailAddrChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpEmailAddrEmailOnly,
   &cmMsgDefSdpEmailAddrEmailName,
   &cmMsgDefSdpEmailAddrNameEmail
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailAddrChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpEmailAddrEmailOnlyStr,
   &cmMsgDefSdpEmailAddrEmailNameStr,
   &cmMsgDefSdpEmailAddrNameEmailStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpEmailAddrChc =
{
   4,
   0,
   NULLP,
   cmMsgDefSdpEmailAddrChcElmnt,
   cmMsgDefSdpEmailAddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddr =
{
#ifdef CM_ABNF_DBG
   "SDP EMLADDR ",
   "SDPEmailAddrFormat",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 153,
   sizeof(CmSdpEmail),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpEmailAddrChc,
   cmSdpRegExpEmailAddrFormat
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailSetSeqOfElmnt[] =
{
   &cmMsgDefSdpEmailStr,
   &cmMsgDefSdpEmailAddr,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpEmailSetSeqOf =
{
   0,
   CM_SDP_MAX_EMAIL,
   3,
   cmMsgDefSdpEmailSetSeqOfElmnt,
   sizeof(CmSdpEmail)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailSet =
{
#ifdef CM_ABNF_DBG
   "SDP: EMLSET ",
   "SDPR12",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 154,
   sizeof(CmSdpEmailSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpEmailSetSeqOf,
   cmSdpRegExpR12
};

/************************************************************************
                              SDP Phone Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpPhoneStrMeta = {(Data *)"p="};
PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneStr =
{
#ifdef CM_ABNF_DBG
   "SDP PHSTR ",
   "SDPR14",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 155,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpPhoneStrMeta,
   cmSdpRegExpR14
};

/************************************************************************
                   SDP Phone in different formats
*************************************************************************/
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPhoneAddrPhoneOnlyRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrPhoneOnly =
{
#ifdef CM_ABNF_DBG
   "SDP Phone Only string",
   "SDPPhone",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 156,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpPhoneAddrPhoneOnlyRng,
   cmSdpRegExpPhone
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneAddrPhoneNameSeqElmnt[] =
{
   &cmMsgDefSdpPhoneAddrPhoneOnly,
   &cmMsgDefOptMetaSpace,   /* 003.main_2; added optional space */
   &cmMsgDefMetaOpenBrace,
   &cmMsgDefSdpEmailSafe,
   &cmMsgDefMetaCloseBrace
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPhoneAddrPhoneNameSeq =
{
   5,       /* 003.main_2; changed from 4 to 5 */
   cmMsgDefSdpPhoneAddrPhoneNameSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrPhoneName =
{
#ifdef CM_ABNF_DBG
   "SDP Phone Name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 157,
   sizeof(CmSdpPhoneName),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpPhoneAddrPhoneNameSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneAddrNamePhoneSeqElmnt[] =
{
   &cmMsgDefSdpEmailSafe,
   &cmMsgDefOptMetaSpace,   /* 003.main_2; added optional space */
   &cmMsgDefMetaOpenAngleBrkt,
   &cmMsgDefSdpPhoneAddrPhoneOnly,
   &cmMsgDefMetaCloseAngleBrkt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPhoneAddrNamePhoneSeq =
{
   5,       /* 003.main_2; changed from 4 to 5 */
   cmMsgDefSdpPhoneAddrNamePhoneSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrNamePhone =
{
#ifdef CM_ABNF_DBG
   "SDP Name Phone",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 158,
   sizeof(CmSdpNamePhone),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpPhoneAddrNamePhoneSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhoneAddrPhoneOnlyEnum =
{
   (Data *)NULLP,
   CM_SDP_PHONE_ONLY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrPhoneOnlyStr =
{
#ifdef CM_ABNF_DBG
   "SDP Phone only",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 159,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhoneAddrPhoneOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhoneAddrPhoneNameEnum =
{
   (Data *)NULLP,
   CM_SDP_PHONE_NAME
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrPhoneNameStr =
{
#ifdef CM_ABNF_DBG
   "SDP Phone Name",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 160,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhoneAddrPhoneNameEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhoneAddrNamePhoneEnum =
{
   (Data *)NULLP,
   CM_SDP_NAME_PHONE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddrNamePhoneStr =
{
#ifdef CM_ABNF_DBG
   "SDP Name Phone",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 161,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhoneAddrNamePhoneEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneAddrChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpPhoneAddrPhoneOnly,
   &cmMsgDefSdpPhoneAddrPhoneName,
   &cmMsgDefSdpPhoneAddrNamePhone
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneAddrChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpPhoneAddrPhoneOnlyStr,
   &cmMsgDefSdpPhoneAddrPhoneNameStr,
   &cmMsgDefSdpPhoneAddrNamePhoneStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpPhoneAddrChc =
{
   4,
   0,
   NULLP,
   cmMsgDefSdpPhoneAddrChcElmnt,
   cmMsgDefSdpPhoneAddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneAddr =
{
#ifdef CM_ABNF_DBG
   "SDP PhoneAddr ",
   "SDPPhoneAddrFormat",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 162,
   sizeof(CmSdpPhone),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpPhoneAddrChc,
   cmSdpRegExpPhoneAddrFormat
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneSetSeqOfElmnt[] =
{
   &cmMsgDefSdpPhoneStr,
   &cmMsgDefSdpPhoneAddr,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpPhoneSetSeqOf =
{
   0,
   CM_SDP_MAX_PHONE,
   3,
   cmMsgDefSdpPhoneSetSeqOfElmnt,
   sizeof(CmSdpPhone)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneSet =
{
#ifdef CM_ABNF_DBG
   "SDP: PHSET ",
   "SDPR14",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 163,
   sizeof(CmSdpPhoneSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpPhoneSetSeqOf,
   cmSdpRegExpR14
};

/************************************************************************
                              SDP Connection Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpConnStrMeta = {(Data *)"c="};
PUBLIC CmAbnfElmDef cmMsgDefSdpConnStr =
{
#ifdef CM_ABNF_DBG
   "SDP CONNSTR",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 164,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpConnStrMeta,
   cmSdpRegExpR16
};

/************************************************************************
                       Components of SDP Conn field
*************************************************************************/



PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipIp4ConnRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipIp4Conn =
{
#ifdef CM_ABNF_DBG
   "SDP Skip Ip4Conn",
   "SDPIpv4AddrType",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 167,
   sizeof(((CmSdpIp4Conn *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipIp4ConnRng,
   cmSdpRegExpIpv4AddrType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnInIp4AddrChcElmnt[] =
{
   &cmMsgDefSdpSkipIp4Conn,
   &cmMsgDefSdpInIpFqdn,
   &cmMsgDefSdpInIp4Ip,
   &cmMsgDefSdpInIp4IpMulti,
   &cmMsgDefSdpSkipIp4Conn
};

EXTERN CmAbnfElmDef cmMsgDefSdpDollarIpAddr;

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnInIp4AddrChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpInIp4FqdnStr,
   &cmMsgDefSdpInIp4IpUniStr,
   &cmMsgDefSdpInIp4IpMultiStr,
   &cmMsgDefSdpDollarIpAddr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpConnInIp4AddrChc =
{
   5,
   0,
   NULLP,
   cmMsgDefSdpConnInIp4AddrChcElmnt,
   cmMsgDefSdpConnInIp4AddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnInIp4Addr =
{
#ifdef CM_ABNF_DBG
   "SDP IPV4 address in c=",
   "SDPIpv4AddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 168,
   sizeof(CmSdpIp4Conn),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpConnInIp4AddrChc,
   cmSdpRegExpIpv4AddrType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnAddrTypeAddrChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpConnInIp4Addr,
   &cmMsgDefSdpInIp6Addr,
   &cmMsgDefSdpTnRFC2543Addr,
   &cmMsgDefSdpTnXTokenAddr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAtmNsapAddr,
   &cmMsgDefSdpAtmE164Addr,
   &cmMsgDefSdpAtmGwidAddr,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpConnAddrTypeAddrChc =
{
   8,
   21,    /* 003.main_2 changed from 20 to 21 */
   cmMsgDefSdpAddrTypeAddrChcIdx,
   cmMsgDefSdpConnAddrTypeAddrChcElmnt,
   cmMsgDefSdpAddrTypeAddrChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddrTypeAddr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrType-Addr in c=",
   "SDPAddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 169,
   /* cm_sdpdb_c_001.main_2 - Change: Old was sizeof(CmSdpConn) */
   sizeof(CmSdpConn) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpConnAddrTypeAddrChc,
   cmSdpRegExpAddrType
};

/* 003.main_2 Additions */

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpConnAddrTypeLclDmnRng = {1, 64};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddrTypeLclDmnStr=
{
#ifdef CM_ABNF_DBG
   "SDP Domain address def",
   "SDP Lcl Domain Addr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 741,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpConnAddrTypeLclDmnRng,
   cmSdpRegExpDmnName
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpConnAddrTypeLclLclRng = {1, 64};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddrTypeLclLclStr=
{
#ifdef CM_ABNF_DBG
   "SDP Local address def",
   "SDP Lcl Lcl Addr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 742,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpConnAddrTypeLclLclRng,
   cmSdpRegExpLclName
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnAddrTypeLclDmnSeqElmnt[] =
{
   &cmMsgDefSdpConnAddrTypeLclDmnStr,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpConnAddrTypeLclLclStr,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpConnAddrTypeLclDmnSeq =
{
   3,
   cmMsgDefSdpConnAddrTypeLclDmnSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddrTypeLclDmn =
{
#ifdef CM_ABNF_DBG
   "SDP: Local Domain Addr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 744,
   sizeof(CmSdpLclAddr),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpConnAddrTypeLclDmnSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnAddrTypeLclEnum[] =
{
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   NULLP,NULLP,NULLP,NULLP,NULLP,NULLP,
   NULLP,NULLP,
   &cmMsgDefSdpAddrTypeLCLStr
};

PUBLIC U8 cmMsgDefSdpAddrTypeAddrTopChcIdx[] = 
   {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,2}; 

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnAddrTypeAddrTopChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpConnAddrTypeAddr,
   &cmMsgDefSdpConnAddrTypeLclDmn,
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpConnAddrTypeAddrTopChc =
{
   3,
   21, 
   cmMsgDefSdpAddrTypeAddrTopChcIdx,
   cmMsgDefSdpConnAddrTypeAddrTopChcElmnt,
   cmMsgDefSdpConnAddrTypeLclEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddrTypeAddrTop =
{
#ifdef CM_ABNF_DBG
   "SDP AddrType-AddrTop in c=",
   "SDPAddrType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 743,
   sizeof(CmSdpConn) - sizeof(TknU8),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED) ,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpConnAddrTypeAddrTopChc,
   cmSdpRegExpAddrType
};

/************************************************************************
                       SDP Connection Field
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnSeqElmnt[] =
{
   &cmMsgDefSdpConnStr,
   &cmMsgDefSdpNetType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpConnAddrTypeAddrTop, /* 003.main_2 Changed */
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpConnSeq =
{
   5,
   cmMsgDefSdpConnSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConn =
{
#ifdef CM_ABNF_DBG
   "SDP: CONNFLD",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 170,
   sizeof(CmSdpConn),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpConnSeq,
   cmSdpRegExpR16
};

/************************************************************************
                              SDP Band Width
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpBWStrMeta = {(Data *)"b="};
PUBLIC CmAbnfElmDef cmMsgDefSdpBWStr =
{
#ifdef CM_ABNF_DBG
   "SDP BWSTR",
   "SDPR17",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 171,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpBWStrMeta,
   cmSdpRegExpR17
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpBwTypeRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpBwType =
{
#ifdef CM_ABNF_DBG
   "SDP BWTYPE",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 172,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpBwTypeRng,
   cmAbnfRegExpAlDgChar
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpBWidthRng = {1, 10, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpBWidthRng = { 1, 10 };
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpBWidth =
{
#ifdef CM_ABNF_DBG
   "SDP BWTYPE",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 173,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpBWidthRng,
   cmAbnfRegExpDgt
};


#ifdef CM_SDP_V_3
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpBwTypeAppSpecMaxEnum =
 {
     (Data *)"AS" ,
     CM_SDP_BW_TYPE_APP_SPEC_MAX
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpBwTypeAppSpecMaxEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP BW TYPE APP SPEC MAX ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 758 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpBwTypeAppSpecMaxEnum ,
     NULLP
 };
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpBwTypeRtcpSndrEnum =
 {
     (Data *)"RS" ,
     CM_SDP_BW_TYPE_RTCP_SNDR
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpBwTypeRtcpSndrEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP BW TYPE RTCP SNDR ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 759 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpBwTypeRtcpSndrEnum ,
     NULLP
 };
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpBwTypeRtcpOthrEnum =
 {
     (Data *)"RR" ,
     CM_SDP_BW_TYPE_RTCP_OTHR
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpBwTypeRtcpOthrEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP BW TYPE RTCP OTHR ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 760 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpBwTypeRtcpOthrEnum ,
     NULLP
 };
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpBwTypeEnum =
 {
     NULLP ,
     CM_SDP_BW_TYPE_UNKNOWN
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpBwTypeEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP BW TYPE ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 761 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpBwTypeEnum ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpBwTypeModifrChcEnum[] =
 {
 &cmMsgDefSdpBwTypeAppSpecMaxEnumDef ,
 &cmMsgDefSdpBwTypeRtcpSndrEnumDef ,
 &cmMsgDefSdpBwTypeRtcpOthrEnumDef ,
 &cmMsgDefSdpBwTypeEnumDef ,
 
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpBwTypeModifrChcElmnt[] =
 {
     NULLP ,
     NULLP ,
     NULLP ,
     &cmMsgDefSdpBwType ,
 };
 
 PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpBwTypeModifrChc =
 {
     4 ,
     0 ,
     NULLP ,
     cmMsgDefSdpBwTypeModifrChcElmnt ,
     cmMsgDefSdpBwTypeModifrChcEnum
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpBwTypeModifr =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP BW TYPE MODIFR " ,
     "cmSdpRegExpBwModifr" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 762 ,
     sizeof(CmSdpBwTyp) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &cmMsgDefSdpBwTypeModifrChc ,
     cmSdpRegExpBwModifr
 };



#endif


PUBLIC CmAbnfElmDef *cmMsgDefSdpBWSeqElmnt[] =
{
   &cmMsgDefSdpBWStr,
#ifdef CM_SDP_V_3
   &cmMsgDefSdpBwTypeModifr,
#else
   &cmMsgDefSdpBwType,
#endif
   &cmMsgDefMetaColon,
   &cmMsgDefSdpBWidth,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpBWSeq =
{
   5,
   cmMsgDefSdpBWSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBW =
{
#ifdef CM_ABNF_DBG
   "SDP: BW",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 174,
   sizeof(CmSdpBw),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpBWSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpBWSetSeqOfElmnt[] =
{
   &cmMsgDefSdpBW
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpBWSetSeqOf =
{
   0,
   CM_SDP_MAX_BW,
   1,
   cmMsgDefSdpBWSetSeqOfElmnt,
   sizeof(CmSdpBw)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBWSet =
{
#ifdef CM_ABNF_DBG
   "SDP: BWSET",
   "SDPR17",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 175,
   sizeof(CmSdpBwSet),
   (CM_ABNF_TKN_NOT_CONSUMED |CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpBWSetSeqOf,
   cmSdpRegExpR17
};

/************************************************************************
                              SDP Time
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpTimeStrMeta = {(Data *)"t="};
PUBLIC CmAbnfElmDef cmMsgDefSdpTimeStr =
{
#ifdef CM_ABNF_DBG
   "SDP TMSTR",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 176,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpTimeStrMeta,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitDayEnum =
{
   (Data *)"d",
   CM_SDP_TIME_UNIT_DAY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitDay =
{
#ifdef CM_ABNF_DBG
   "SDP: TMDAY ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 177,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitDayEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitHourEnum =
{
   (Data *)"h",
   CM_SDP_TIME_UNIT_HR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitHour =
{
#ifdef CM_ABNF_DBG
   "SDP: TMHR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 178,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitHourEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitMinEnum =
{
   (Data *)"m",
   CM_SDP_TIME_UNIT_MIN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitMin =
{
#ifdef CM_ABNF_DBG
   "SDP: TMMIN ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 179,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitMinEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitSecEnum =
{
   (Data *)"s",
   CM_SDP_TIME_UNIT_SEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitSec =
{
#ifdef CM_ABNF_DBG
   "SDP: TMSEC ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 180,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitSecEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeUnitChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpTimeUnitDay,
   &cmMsgDefSdpTimeUnitHour,
   &cmMsgDefSdpTimeUnitMin,
   &cmMsgDefSdpTimeUnitSec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpTypedTimeUnitChc =
{
   5,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpTypedTimeUnitChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeUnit =
{
#ifdef CM_ABNF_DBG
   "SDP: TMUNT",
   "SDPR19",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 181,
   sizeof(TknU8),
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpTypedTimeUnitChc,
   cmSdpRegExpR19
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTypedTimeValRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeVal =
{
#ifdef CM_ABNF_DBG
   "SDP: TPTMVAL",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 182,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpTypedTimeValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeSeqElmnt[] =
{
   &cmMsgDefSdpTypedTimeVal,
   &cmMsgDefSdpTypedTimeUnit
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTypedTimeSeq =
{
   2,
   cmMsgDefSdpTypedTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTime =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTM ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 183,
   sizeof(CmSdpTypedTime),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpTypedTimeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeListSeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTypedTime
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpTypedTimeListSeqOf =
{
   1,
   (CM_SDP_MAX_REP_FIELD - 1),
   2,
   cmMsgDefSdpTypedTimeListSeqOfElmnt,
   sizeof(CmSdpTypedTime)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeList =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTMSET ",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 184,
   sizeof(CmSdpTypedTimeSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpTypedTimeListSeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefRepfTypedTimeSetSeqOfElmnt[] =
{
   &cmMsgDefSdpTypedTime,
   &cmMsgDefSdpTypedTimeList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefRepfTypedTimeSetSeqOf =
{
   2,
   cmMsgDefRepfTypedTimeSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefRepfTypedTimeSet =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTMSET ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 185,
   sizeof(CmSdpTypedTimeSet),
   (CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefRepfTypedTimeSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefRepFieldStrMeta = {(Data *)"\r\nr="};
PUBLIC CmAbnfElmDef cmMsgDefRepFieldStr =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLDSTR ",
   "SDPR22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 186,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefRepFieldStrMeta,
   cmSdpRegExpR22
};

PUBLIC CmAbnfElmDef *cmMsgDefRepFieldSeqElmnt[] =
{
   &cmMsgDefRepFieldStr,
   &cmMsgDefSdpTypedTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTypedTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefRepfTypedTimeSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefRepFieldSeq =
{
   6,
   cmMsgDefRepFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefRepField =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLD ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 187,
   sizeof(CmSdpRepField),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefRepFieldSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefRepFieldSetSeqOfElmnt[] =
{
   &cmMsgDefRepField
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefRepFieldSetSeqOf =
{
   0,
   CM_SDP_MAX_REP_FIELD,
   1,
   cmMsgDefRepFieldSetSeqOfElmnt,
   sizeof(CmSdpRepField)
};

PUBLIC CmAbnfElmDef cmMsgDefRepFieldSet =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLDSET",
   "SDPR22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 188,
   sizeof(CmSdpRepFieldSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefRepFieldSetSeqOf,
   cmSdpRegExpR22
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpStTimeRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpStTime =
{
#ifdef CM_ABNF_DBG
   "SDP: STTIME",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 189,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpStTimeRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeSeqElmnt[] =
{
   &cmMsgDefSdpTimeStr,
   &cmMsgDefSdpStTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpStTime,
   &cmMsgDefRepFieldSet,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOpTimeSeq =
{
   6,
   cmMsgDefSdpOpTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTime =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTM",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 190,
   sizeof(CmSdpOpTime),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpOpTimeSeq,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeListSeqOfElmnt[] =
{
   &cmMsgDefSdpOpTime
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpOpTimeListSeqOf =
{
   0,
   CM_SDP_MAX_UNKNOWN,
   1,
   cmMsgDefSdpOpTimeListSeqOfElmnt,
   sizeof(CmSdpOpTime)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTimeList =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTMLIST",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 191,
   sizeof(CmSdpOpTimeSet),
   (CM_ABNF_TKN_NOT_CONSUMED |CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpOpTimeListSeqOf,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeSetSeqOfElmnt[] =
{
   &cmMsgDefSdpOpTime,
   &cmMsgDefSdpOpTimeList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOpTimeSetSeqOf =
{
   2,
   cmMsgDefSdpOpTimeSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTimeSet =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTMSET",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 192,
   sizeof(CmSdpOpTimeSet),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpOpTimeSetSeqOf,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTimeValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeVal =
{
#ifdef CM_ABNF_DBG
   "SDP: TIME",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 193,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpTimeValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjSeqElmnt[] =
{
   &cmMsgDefSdpTimeVal,
   &cmMsgDefMetaSpace,
   &cmMsgDefOptMetaHyphen,
   &cmMsgDefSdpTypedTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneAdjSeq =
{
   4,
   cmMsgDefSdpZoneAdjSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdj =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 194,
   sizeof(CmSdpZoneAdj),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpZoneAdjSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjListSeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpZoneAdj
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpZoneAdjListSeqOf =
{
   0,
   (CM_SDP_MAX_ZONE_ADJ - 1),
   2,
   cmMsgDefSdpZoneAdjListSeqOfElmnt,
   sizeof(CmSdpZoneAdj)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdjList =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTMLIST",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 195,
   sizeof(CmSdpZoneAdjSet),
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpZoneAdjListSeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjSetSeqOfElmnt[] =
{
   &cmMsgDefSdpZoneAdj,
   &cmMsgDefSdpZoneAdjList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneAdjSetSeqOf =
{
   2,
   cmMsgDefSdpZoneAdjSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdjSet =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTMSET",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 196,
   sizeof(CmSdpZoneAdjSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpZoneAdjSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpZoneAdjStrMeta = {(Data *)"z="};
PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdjStr =
{
#ifdef CM_ABNF_DBG
   "SDP ZONEADJSTR",
   "SDPzEqual",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 197,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpZoneAdjStrMeta,
   cmSdpRegExpzEqual
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneOptAdjSetSeqElmnt[] =
{
   &cmMsgDefSdpZoneAdjStr,
   &cmMsgDefSdpZoneAdjSet,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneOptAdjSetSeq =
{
   3,
   cmMsgDefSdpZoneOptAdjSetSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneOptAdjSet =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTADJ",
   "SDPzEqual",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 198,
   sizeof(CmSdpZoneAdjSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpZoneOptAdjSetSeq,
   cmSdpRegExpzEqual
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTimeSeqElmnt[] =
{
   &cmMsgDefSdpOpTimeSet,
   &cmMsgDefSdpZoneOptAdjSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTimeSeq =
{
   2,
   cmMsgDefSdpTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTime =
{
#ifdef CM_ABNF_DBG
   "SDP: TM",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 199,
   sizeof(CmSdpTime),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpTimeSeq,
   cmSdpRegExpR18
};

/************************************************************************
                              SDP Key Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpKeyStrMeta = {(Data *)"k="};
PUBLIC CmAbnfElmDef cmMsgDefSdpKeyStr =
{
#ifdef CM_ABNF_DBG
   "SDP: KSTR",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 200,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpKeyStrMeta,
   cmSdpRegExpR23
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypePromptEnum =
{
   (Data *)"prompt",
   CM_SDP_KEY_TYPE_PROMPT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypePromptStr =
{
#ifdef CM_ABNF_DBG
   "SDP: PROMPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 201,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypePromptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeClearEnum =
{
   (Data *)"clear",
   CM_SDP_KEY_TYPE_CLEAR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeClearStr =
{
#ifdef CM_ABNF_DBG
   "SDP: CLEAR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 202,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeClearEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeBase64Enum =
{
   (Data *)"base64",
   CM_SDP_KEY_TYPE_BASE64
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeBase64Str =
{
#ifdef CM_ABNF_DBG
   "SDP: BASE64",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 203,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeBase64Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeUriEnum =
{
   (Data *)"uri",
   CM_SDP_KEY_TYPE_URI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeUriStr =
{
#ifdef CM_ABNF_DBG
   "SDP: URI",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 204,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeUriEnum,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypePrompt =
{
#ifdef CM_ABNF_DBG
   "SDP: PROMPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 205,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeClearRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeClear =
{
#ifdef CM_ABNF_DBG
   "SDP: CLEAR",
   "SDPEmailSafe",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 206,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeClearRng,
   cmSdpRegExpEmailSafe
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeBase64Rng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeBase64 =
{
#ifdef CM_ABNF_DBG
   "SDP: BASE64",
   "SDPEmailSafe",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 207,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeBase64Rng,
   cmSdpRegExpEmailSafe
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeUriRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeUri =
{
#ifdef CM_ABNF_DBG
   "SDP: URI",
   "SDPUri",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 208,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeUriRng,
   cmSdpRegExpUri
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyTypeChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpKeyTypePrompt,
   &cmMsgDefSdpKeyTypeClear,
   &cmMsgDefSdpKeyTypeBase64,
   &cmMsgDefSdpKeyTypeUri
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpKeyTypePromptStr,
   &cmMsgDefSdpKeyTypeClearStr,
   &cmMsgDefSdpKeyTypeBase64Str,
   &cmMsgDefSdpKeyTypeUriStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpKeyTypeChc =
{
   5,
   0,
   NULLP,
   cmMsgDefSdpKeyTypeChcElmnt,
   cmMsgDefSdpKeyTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyType =
{
#ifdef CM_ABNF_DBG
   "SDP: KTYPE",
   "SDPR24",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 209,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpKeyTypeChc,
   cmSdpRegExpR24
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyInfoSeqElmnt[] =
{
   &cmMsgDefSdpKeyStr,
   &cmMsgDefSdpKeyType,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpKeyInfoSeq =
{
   3,
   cmMsgDefSdpKeyInfoSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyInfo =
{
#ifdef CM_ABNF_DBG
   "SDP: KEY",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 210,
   sizeof(CmSdpKeyType),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpKeyInfoSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeySeqElmnt[] =
{
   &cmMsgDefSdpKeyInfo
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpKeySeq =
{
   1,
   cmMsgDefSdpKeySeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKey =
{
#ifdef CM_ABNF_DBG
   "SDP: KEY",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 211,
   sizeof(CmSdpKeyType),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpKeySeq,
   cmSdpRegExpR23
};

/************************************************************************
                              SDP Attribute Fields
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttrValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrVal =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "SDPByteString",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 212,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAttrValRng,
   cmSdpRegExpByteString
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptAttrValSeqElmnt[] =
{
   &cmMsgDefOptMetaSpace,  /* 003.main_2; added to allow optional space */
   &cmMsgDefMetaColon,
   &cmMsgDefOptMetaSpace,  /* 003.main_2; added to allow optional space */
   &cmMsgDefSdpAttrVal
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptAttrValSeq =
{
   4, /* 003.main_2; changed from 2 to 4 */
   cmMsgDefSdpOptAttrValSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptAttrVal =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "CM_RCOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 213,
   sizeof(TknStrOSXL),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptAttrValSeq,
   /* 003.main_2 changed regexp; it was cmAbnfRegExpColon */
   cmSdpRegExpColonSpc
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttFieldRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttField =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "SDPAlDgHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 214,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAttFieldRng,
   cmSdpRegExpAlDgHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSeqElmnt[] =
{
   &cmMsgDefSdpAttField,
   &cmMsgDefSdpOptAttrVal,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrSeq =
{
  2,
  cmMsgDefSdpAttrSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrGeneric =
{
#ifdef CM_ABNF_DBG
   "SDP: Generic ATTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 215,
   sizeof(CmSdpAttrGeneric),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttrByteStringRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpAttrByteString =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - ByteString",
   "SDPByteString",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 216,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAttrByteStringRng,
   cmSdpRegExpByteString
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSkip =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Skip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 217,
   sizeof(((CmSdpAttr *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrOrientSeascapeEnum =
{
   (Data *)"seascape",
   CM_SDP_ATTR_ORIENT_SEASCAPE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrOrientSeascapeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Orient Seascape",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 218,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrOrientSeascapeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrOrientLandscapeEnum =
{
   (Data *)"landscape",
   CM_SDP_ATTR_ORIENT_LANDSCAPE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrOrientLandscapeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Orient Landscape",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 219,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrOrientLandscapeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrOrientPortraitEnum =
{
   (Data *)"portrait",
   CM_SDP_ATTR_ORIENT_PORTRAIT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrOrientPortraitStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Orient Portrait",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 220,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrOrientPortraitEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrOrientChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpAttrOrientPortraitStr,
   &cmMsgDefSdpAttrOrientLandscapeStr,
   &cmMsgDefSdpAttrOrientSeascapeStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrOrientChc =
{
   4,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrOrientChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrOrient =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Orient",
   "SDPOrient",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 221,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrOrientChc,
   cmSdpRegExpOrient
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeUnknownEnum =
{
   NULLP,
   CM_SDP_ATTR_TYPE_UNKNOWN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeUnknownStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - Unknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 222,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeUnknownEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeBroadcastEnum =
{
   (Data *)"broadcast",
   CM_SDP_ATTR_TYPE_BROADCAST
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeBroadcastStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - Broadcast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 223,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeBroadcastEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeMeetingEnum =
{
   (Data *)"meeting",
   CM_SDP_ATTR_TYPE_MEETING
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeMeetingStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - Meeting",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 224,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeMeetingEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeModeratedEnum =
{
   (Data *)"moderated",
   CM_SDP_ATTR_TYPE_MODERATED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeModeratedStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - Moderated",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 225,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeModeratedEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeTestEnum =
{
   (Data *)"test",
   CM_SDP_ATTR_TYPE_TEST,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeTestStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - Test",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 226,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeTestEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeH332Enum =
{
   (Data *)"H332",
   CM_SDP_ATTR_TYPE_H332,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeH332Str =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Type - H332",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 227,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeH332Enum,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeSkip =
{
#ifdef CM_ABNF_DBG
   "SDP AttrType skip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 228,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrTypeChcElmnt[] =
{
   &cmMsgDefSdpAttrByteString,
   &cmMsgDefSdpAttrTypeSkip
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrTypeChcEnum[] =
{
   &cmMsgDefSdpAttrTypeUnknownStr,
   &cmMsgDefSdpAttrTypeBroadcastStr,
   &cmMsgDefSdpAttrTypeMeetingStr,
   &cmMsgDefSdpAttrTypeModeratedStr,
   &cmMsgDefSdpAttrTypeTestStr,
   &cmMsgDefSdpAttrTypeH332Str
};

PUBLIC U8 cmMsgDefSdpAttrTypeChcIdx[] = {0, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrTypeChc =
{
   2,
   6,
   cmMsgDefSdpAttrTypeChcIdx,
   cmMsgDefSdpAttrTypeChcElmnt,
   cmMsgDefSdpAttrTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrType =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Type",
   "SDPType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 229,
   sizeof(CmSdpAttrType),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrTypeChc,
   cmSdpRegExpType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrTypeNotConsumedChcElmnt[] =
{
   &cmMsgDefSdpAttrByteString,
   &cmMsgDefSdpAttrType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrTypeNotConsumedChcEnum[] =
{
   &cmMsgDefSdpAttrTypeUnknownStr,
   NULLP, NULLP, NULLP, NULLP, NULLP
};

PUBLIC U8 cmMsgDefSdpAttrTypeNotConsumedChcIdx[] = {0, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrTypeNotConsumedChc =
{
   2,
   6,
   cmMsgDefSdpAttrTypeNotConsumedChcIdx,
   cmMsgDefSdpAttrTypeNotConsumedChcElmnt,
   cmMsgDefSdpAttrTypeNotConsumedChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeNotConsumed =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field - Type not consumed",
   "SDPType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 230,
   sizeof(CmSdpAttrType),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrTypeNotConsumedChc,
   cmSdpRegExpType
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpOtherEnum =
{
   NULLP,
   CM_SDP_ATTR_FMTP_UNSPEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpOtherStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpOther",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 231,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpOtherEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtp2848Enum =
{
   NULLP,
   CM_SDP_ATTR_FMTP_RFC2848
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2848Str =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtp2848",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 232,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtp2848Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtp2733Enum =
{
   NULLP,
   CM_SDP_ATTR_FMTP_RFC2733
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2733Str =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtp2733",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 233,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtp2733Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtp2833Enum =
{
   NULLP,
   CM_SDP_ATTR_FMTP_RFC2833
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2833Str =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtp2833",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 234,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtp2833Enum,
   NULLP
};


#ifdef CM_SDP_V_3
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpChOrEnum =
{
   NULLP,
   CM_SDP_ATTR_FMTP_EMP_ORD
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpChOrStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpChOr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 234,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpChOrEnum,
   NULLP
};
#endif

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpSkip =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Fmtp - skip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 235,
   sizeof(((CmSdpAttrFmtp *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMimeSubtypeRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpMimeSubtype =
{
#ifdef CM_ABNF_DBG
   "SDP - Mime Subtype",
   "SDPAlDgHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 236,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpMimeSubtypeRng,
   cmSdpRegExpAlDgHyphen
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpResUriEnum =
{
   (Data *)" uri:",
   CM_SDP_ATTR_FMTP_RFC2848_URI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpResUriStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpResUri",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 237,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpResUriEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpResOprEnum =
{
   (Data *)" opr:",
   CM_SDP_ATTR_FMTP_RFC2848_OPR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpResOprStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpResOpr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 238,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpResOprEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpResSprEnum =
{
   (Data *)" spr:",
   CM_SDP_ATTR_FMTP_RFC2848_SPR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpResSprStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpResSpr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 239,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpResSprEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpResolutionChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpAttrByteString
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpResolutionChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpAttrFmtpResUriStr,
   &cmMsgDefSdpAttrFmtpResOprStr,
   &cmMsgDefSdpAttrFmtpResSprStr
};

PUBLIC U8 cmMsgDefSdpAttrFmtpResolutionChcIdx[] = {0, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrFmtpResolutionChc =
{
   2,
   4,
   cmMsgDefSdpAttrFmtpResolutionChcIdx,
   cmMsgDefSdpAttrFmtpResolutionChcElmnt,
   cmMsgDefSdpAttrFmtpResolutionChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpResolution =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpResolution",
   "SDPSpaceRef",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 240,
   sizeof(CmSdpAttrFmtp2848Res),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrFmtpResolutionChc,
   cmSdpRegExpSpaceRef
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpResolutionSetSeqOfElmnt[] =
{
   &cmMsgDefSdpAttrFmtpResolution
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttrFmtpResolutionSetSeqOf =
{
   1,
   CM_SDP_MAX_FMTP_RES,
   1,
   cmMsgDefSdpAttrFmtpResolutionSetSeqOfElmnt,
   sizeof(CmSdpAttrFmtp2848Res)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpResolutionSet =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpResolutionSet",
   "SDPSpaceRef",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 241,
   sizeof(CmSdpAttrFmtp2848ResSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttrFmtpResolutionSetSeqOf,
   cmSdpRegExpSpaceRef
};

EXTERN CmAbnfElmDef cmMsgDefSdpAttribute;

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttributeArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttribute
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttributeArraySeqOf =
{
   0,
   CM_SDP_MAX_ATTR_FMTP_ATTR,
   2,
   cmMsgDefSdpAttributeArraySeqOfElmnt,
   sizeof(CmSdpAttr)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttributeArray =
{
#ifdef CM_ABNF_DBG
   "SDP AttributeArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 242,
   sizeof(CmSdpOptAttrSet),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttributeArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpAttrLstSeqElmnt[] =
{
   &cmMsgDefSdpAttribute,
   &cmMsgDefSdpAttributeArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrFmtpAttrLstSeq =
{
   2,
   cmMsgDefSdpAttrFmtpAttrLstSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpAttrLst =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpAttrLst",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 243,
   sizeof(CmSdpOptAttrSet),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpAttrFmtpAttrLstSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpSpaceSemicolonStrMeta = {(Data *)" ;"};
PUBLIC CmAbnfElmDef cmMsgDefSdpSpaceSemicolonStr =
{
#ifdef CM_ABNF_DBG
   "SDP space ;",
   "SDPSpaceSemicolon",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 244,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpSpaceSemicolonStrMeta,
   cmSdpRegExpSpaceSemicolon
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpOptAttrSetSeqElmnt[] =
{
   &cmMsgDefSdpSpaceSemicolonStr,
   &cmMsgDefSdpAttrFmtpAttrLst
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrFmtpOptAttrSetSeq =
{
   2,
   cmMsgDefSdpAttrFmtpOptAttrSetSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpOptAttrSet =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtpOptAttrSet",
   "SDPSpaceSemicolon",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 245,
   sizeof(CmSdpOptAttrSet),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpAttrFmtpOptAttrSetSeq,
   cmSdpRegExpSpaceSemicolon
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtp2848SeqElmnt[] =
{
   &cmMsgDefSdpMimeSubtype,
   &cmMsgDefSdpAttrFmtpResolutionSet,
   &cmMsgDefSdpAttrFmtpOptAttrSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrFmtp2848Seq =
{
   3,
   cmMsgDefSdpAttrFmtp2848SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2848 =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Fmtp - 2848",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 246,
   sizeof(CmSdpAttrFmtp2848),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrFmtp2848Seq,
   NULLP
};

#define cmMsgDefSdpPayloadType cmMsgDefSdpDecU8OrNull

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtp2733SeqElmnt[] =
{
   &cmMsgDefSdpPayloadType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU16OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpNetType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAddrTypeAddr,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrFmtp2733Seq =
{
   7,
   cmMsgDefSdpAttrFmtp2733SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2733 =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtp2733",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 247,
   sizeof(CmSdpAttrFmtp2733),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrFmtp2733Seq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtp2833SeqElmnt[] =
{
   &cmMsgDefSdpPayloadType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrByteString
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrFmtp2833Seq =
{
   3,
   cmMsgDefSdpAttrFmtp2833SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp2833 =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFmtp2833",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 248,
   sizeof(CmSdpAttrFmtp2833),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrFmtp2833Seq,
   NULLP
};

#ifdef CM_SDP_V_3
/*
   Additions for draft-ietf-avt-dv-audio-03.txt
*/


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderch41Enum =
{
    (Data *)"LRLsRs" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDERCH41
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderch41EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDERCH41 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  999 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderch41Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderch42Enum =
{
    (Data *)"LRCS" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDERCH42
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderch42EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDERCH42 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1000 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderch42Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderch43Enum =
{
    (Data *)"LRCWo" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDERCH43
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderch43EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDERCH43 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1001 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderch43Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderch5Enum =
{
    (Data *)"LRLsRsC" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDERCH5
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderch5EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDERCH5 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1002 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderch5Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderCh61Enum =
{
    (Data *)"LRLsRsCS" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CH61
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderCh61EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CH61 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderCh61Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderCh62Enum =
{
    (Data *)"LmixRmixTWoQ1Q2" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CH62
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderCh62EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CH62 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1004 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderCh62Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderCh81Enum =
{
    (Data *)"LRCWoLsRsLmixRmix" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CH81
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderCh81EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CH81 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1005 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderCh81Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderCh82Enum =
{
    (Data *)"LRCWoLs1Rs1Ls2Rs2" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CH82
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderCh82EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CH82 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1006 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderCh82Enum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderCh83Enum =
{
    (Data *)"LRCWoLsRsLcRc" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CH83
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderCh83EnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CH83 ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1007 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderCh83Enum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpChanelOrderOrdChcEnum[] =
{
&cmMsgDefSdpAttrFmtpChanelOrderch41EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderch42EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderch43EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderch5EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderCh61EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderCh62EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderCh81EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderCh82EnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderCh83EnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrFmtpChanelOrderOrdChc =
{
    9 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrFmtpChanelOrderOrdChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderOrd =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER ORD " ,
    "cmSdpRegExpEmpOrd" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1008 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderOrdChc ,
    cmSdpRegExpEmpOrd
};






PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderConvAiffcEnum =
{
    (Data *)"AIFF-C" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CONV_AIFFC
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderConvAiffcEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CONV AIFFC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1009 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderConvAiffcEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderConvDvEnum =
{
    (Data *)"DV" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER_CONV_DV
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderConvDvEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CONV DV ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1010 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderConvDvEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpChanelOrderConvChcEnum[] =
{
&cmMsgDefSdpAttrFmtpChanelOrderConvAiffcEnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderConvDvEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrFmtpChanelOrderConvChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrFmtpChanelOrderConvChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderConv =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER CONV " ,
    "cmSdpRegExpEmpConv" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1011 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderConvChc ,
    cmSdpRegExpEmpConv
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpChanelOrderSeqElmnts[] =
{
    &cmMsgDefSdpAttrFmtpChanelOrderConv ,
    &cmMsgDefMetaColon ,
    &cmMsgDefSdpAttrFmtpChanelOrderOrd
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrFmtpChanelOrderSeq =
{
    3 ,
    cmMsgDefSdpAttrFmtpChanelOrderSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrder =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1012 ,
    sizeof(CmSdpAttrFmtpChnOrdSeq) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderSeq ,
    NULLP
};






PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpEmphasisEnum =
{
    (Data *)"emphasis=" ,
    CM_SDP_ATTR_FMTP_EMPHASIS
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpEmphasisEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP EMPHASIS ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1013 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpEmphasisEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeMeta  cmMsgDefSdpAttrFmtpEmphasisMeta =  {  (Data *) "50/15"  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpEmphasis =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP EMPHASIS " ,
    "Emphasis" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1014 ,
    0 ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_META ,
    (U8 *) &cmMsgDefSdpAttrFmtpEmphasisMeta ,
    cmSdpRegExpEmphasis
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrFmtpChanelOrderEnum =
{
    (Data *)"channel-order=" ,
    CM_SDP_ATTR_FMTP_CHANEL_ORDER
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChanelOrderEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHANEL ORDER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1015 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrFmtpChanelOrderEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpEmpOrdChoiceChcEnum[] =
{
&cmMsgDefSdpAttrFmtpEmphasisEnumDef ,
&cmMsgDefSdpAttrFmtpChanelOrderEnumDef ,

};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpEmpOrdChoiceChcElmnt[] =
{
    &cmMsgDefSdpAttrFmtpEmphasis ,
    &cmMsgDefSdpAttrFmtpChanelOrder ,
};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrFmtpEmpOrdChoiceChc =
{
    2 ,
    0 ,
    NULLP ,
    cmMsgDefSdpAttrFmtpEmpOrdChoiceChcElmnt ,
    cmMsgDefSdpAttrFmtpEmpOrdChoiceChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpEmpOrdChoice =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP EMP ORD CHOICE " ,
    "cmSdpRegExpEmpOrOrd" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1016 ,
    sizeof(CmSdpAttrFmtpEmChnChc) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrFmtpEmpOrdChoiceChc ,
    cmSdpRegExpEmpOrOrd
};

#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefSdpAttrFmtpChnOrdPyLdRange =  {   1 , 8 , 0 , (U32)99999999  };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrFmtpChnOrdPyLdRange =  {   1 , 8  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChnOrdPyLd =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHN ORD PY LD " ,
    "cmAbnfRegExpDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1017 ,
    sizeof (TknU32) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_UINT32 ,
    (U8 *) &cmMsgDefSdpAttrFmtpChnOrdPyLdRange ,
    cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrFmtpChnOrdSeqElmnts[] =
{
    &cmMsgDefSdpAttrFmtpChnOrdPyLd ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpAttrFmtpEmpOrdChoice
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrFmtpChnOrdSeq =
{
    3 ,
    cmMsgDefSdpAttrFmtpChnOrdSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrFmtpChnOrd =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHN ORD " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1018 ,
    sizeof(CmSdpAttrFmtpEmpChnOrd) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrFmtpChnOrdSeq ,
    NULLP
};


#endif

#define cmMsgDefSdpAttrFmtpOther cmMsgDefSdpAttrByteString 

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpChcElmnt[] =
{
   &cmMsgDefSdpAttrFmtpOther,
   &cmMsgDefSdpAttrFmtp2848,
   &cmMsgDefSdpAttrFmtp2733,
   &cmMsgDefSdpAttrFmtp2833
#ifdef CM_SDP_V_3
   , &cmMsgDefSdpAttrFmtpChnOrd
#endif
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFmtpChcEnum[] =
{
   &cmMsgDefSdpAttrFmtpOtherStr,
   &cmMsgDefSdpAttrFmtp2848Str,
   &cmMsgDefSdpAttrFmtp2733Str,
   &cmMsgDefSdpAttrFmtp2833Str
#ifdef CM_SDP_V_3
   , &cmMsgDefSdpAttrFmtpChOrStr
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrFmtpChc =
{
#ifdef CM_SDP_V_3
   5,
#else
   4,
#endif
   0,
   NULLP,
   cmMsgDefSdpAttrFmtpChcElmnt,
   cmMsgDefSdpAttrFmtpChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtp =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Field Fmtp",
   "SDPFmtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 249,
   sizeof(CmSdpAttrFmtp),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrFmtpChc,
   cmSdpRegExpFmtp
};
PUBLIC CmAbnfElmDef *cmMsgDefSdpOptRtpMapParamsSeqElmnt[] =
{
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpAttrByteString
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptRtpMapParamsSeq =
{
   2,
   cmMsgDefSdpOptRtpMapParamsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptRtpMapParams =
{
#ifdef CM_ABNF_DBG
   "SDP OptRtpMapParams",
   "CM_RSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 250,
   sizeof(TknStrOSXL),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptRtpMapParamsSeq,
   cmAbnfRegExpSlash
};



/* 001.main_14: changes to support a mix of "$" & integers in a RTP list */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpChooseEnum =
{
   (Data *)"$",
   CM_SDP_CHOICE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpChoose =
{
#ifdef CM_ABNF_DBG
   "SDP $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 555,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpChooseEnum,
   NULLP
};



PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipU8AtDlrRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipU8AtDlr =
{
#ifdef CM_ABNF_DBG
   "SDP SkipU8",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 70,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipU8AtDlrRng,
   cmAbnfRegExpDollar
};



PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU8OrNullOrDollarChcElmnt[] =
{
   &cmMsgDefSdpSkipU8,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefSdpSkipU8AtDlr,
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU8OrNullOrDollarChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec,
   &cmMsgDefSdpChoose,
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpDecU8OrNullOrDollarChc =
{
   3,
   0,
   NULLP,
   cmMsgDefSdpDecU8OrNullOrDollarChcElmnt,
   cmMsgDefSdpDecU8OrNullOrDollarChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU8OrNullOrDollar =
{
#ifdef CM_ABNF_DBG
   "SDP Decimal U8 or null",
   "SDPDecUintOrNull",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 76,
   sizeof(CmSdpU8OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpDecU8OrNullOrDollarChc,
   cmSdpRegExpDecUintOrNullOrDollar
};





PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrRtpMapSeqElmnt[] =
{
   &cmMsgDefSdpDecU8OrNullOrDollar,
   /* 001.main_14: Replaced the following with the above */
   /* &cmMsgDefSdpPayloadType, */

   &cmMsgDefMetaSpace,
   &cmMsgDefSdpEncodingName,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpDecU32,
   &cmMsgDefSdpOptRtpMapParams
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrRtpMapSeq =
{
   6,
   cmMsgDefSdpAttrRtpMapSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRtpMap =
{
#ifdef CM_ABNF_DBG
   "SDP AttrRtpMap",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 251,
   sizeof(CmSdpAttrRtpMap),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrRtpMapSeq,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAtmMapSeqElmnt[] =
{
   &cmMsgDefSdpPayloadType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpEncodingName
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAtmMapSeq =
{
   3,
   cmMsgDefSdpAttrAtmMapSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmMap =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAtmMap",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 252,
   sizeof(CmSdpAttrAtmMap),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAtmMapSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptSmpteTimeFracSeqElmnt[] =
{
   &cmMsgDefMetaDot,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptSmpteTimeFracSeq =
{
   2,
   cmMsgDefSdpOptSmpteTimeFracSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptSmpteTimeFrac =
{
#ifdef CM_ABNF_DBG
   "SDP . frac in SMPTE",
   "CM_RDOT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 253,
   sizeof(TknU8),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptSmpteTimeFracSeq,
   cmAbnfRegExpDot
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptSmpteTimeSeqElmnt[] =
{
   &cmMsgDefMetaColon,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefSdpOptSmpteTimeFrac
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptSmpteTimeSeq =
{
   3,
   cmMsgDefSdpOptSmpteTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptSmpteTime =
{
#ifdef CM_ABNF_DBG
   "SDP : centisec . frac",
   "CM_RCOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 254,
   sizeof(TknU8) + sizeof(TknU8),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptSmpteTimeSeq,
   cmAbnfRegExpColon
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpSmpteTimeSeqElmnt[] =
{
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefSdpOptSmpteTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSmpteTimeSeq =
{
   6,
   cmMsgDefSdpSmpteTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSmpteTime =
{
#ifdef CM_ABNF_DBG
   "SDP SmpteTime",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 255,
   sizeof(CmSdpSmpte),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpSmpteTimeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpHyphenSmpteTimeSeqElmnt[] =
{
   &cmMsgDefMetaHyphen,
   &cmMsgDefSdpSmpteTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpHyphenSmpteTimeSeq =
{
   2,
   cmMsgDefSdpHyphenSmpteTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpHyphenSmpteTime =
{
#ifdef CM_ABNF_DBG
   "SDP HyphenSmpteTime",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 256,
   sizeof(CmSdpSmpte),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpHyphenSmpteTimeSeq,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpSmpteSeqElmnt[] =
{
   &cmMsgDefSdpSmpteTime,
   &cmMsgDefSdpHyphenSmpteTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSmpteSeq =
{
   2,
   cmMsgDefSdpSmpteSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSmpte =
{
#ifdef CM_ABNF_DBG
   "SDP Smpte",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 257,
   sizeof(CmSdpTimeSmpte),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpSmpteSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNptNowEnum =
{
   (Data *)"now",
   CM_SDP_NPT_NOW
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptNowStr =
{
#ifdef CM_ABNF_DBG
   "SDP NOWSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 258,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNptNowEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNptSecEnum =
{
   (Data *)NULLP,
   CM_SDP_NPT_SEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptSecStr =
{
#ifdef CM_ABNF_DBG
   "SDP SECSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 259,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNptSecEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNptHmsEnum =
{
   (Data *)NULLP,
   CM_SDP_NPT_HMS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptHmsStr =
{
#ifdef CM_ABNF_DBG
   "SDP HHMMSS STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 260,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNptHmsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpNptSkipRng = {3, 3};
PUBLIC CmAbnfElmDef cmMsgDefSdpNptSkip =
{
#ifdef CM_ABNF_DBG
   "SDP NPT skip for 'now'",
   "SDPNowOrSecOrHhmmss",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 261,
   sizeof(((CmSdpNpt *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpNptSkipRng,
   cmSdpRegExpNowOrSecOrHhmmss
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptDotFracSeqElmnt[] =
{
   &cmMsgDefMetaDot,
   &cmMsgDefSdpDecU32
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptDotFracSeq =
{
   2,
   cmMsgDefSdpOptDotFracSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptDotFrac =
{
#ifdef CM_ABNF_DBG
   "SDP . frac in NPT SEC or HHMMSS",
   "CM_RDOT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 262,
   sizeof(TknU32),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptDotFracSeq,
   cmAbnfRegExpDot
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpNptSecSeqElmnt[] =
{
   &cmMsgDefSdpDecU32,
   &cmMsgDefSdpOptDotFrac
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpNptSecSeq =
{
   2,
   cmMsgDefSdpNptSecSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptSec =
{
#ifdef CM_ABNF_DBG
   "SDP NptSec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 263,
   sizeof(CmSdpNptSec),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpNptSecSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpNptHmsSeqElmnt[] =
{
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpDecUchar,
   &cmMsgDefSdpOptDotFrac
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpNptHmsSeq =
{
   6,
   cmMsgDefSdpNptHmsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptHms =
{
#ifdef CM_ABNF_DBG
   "SDP NPT HHMMSS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 264,
   sizeof(CmSdpNptHMS),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpNptHmsSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptNptTimeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpNptNowStr,
   &cmMsgDefSdpNptSecStr,
   &cmMsgDefSdpNptHmsStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptNptTimeChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpNptSkip,
   &cmMsgDefSdpNptSec,
   &cmMsgDefSdpNptHms
};


PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpOptNptTimeChc =
{
   4,
   0,
   NULLP,
   cmMsgDefSdpOptNptTimeChcElmnt,
   cmMsgDefSdpOptNptTimeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptNptTime =
{
#ifdef CM_ABNF_DBG
   "SDP OptNptTime",
   "NowOrSecOrHhmmss",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 265,
   sizeof(CmSdpNpt),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpOptNptTimeChc,
   cmSdpRegExpNowOrSecOrHhmmss
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpNptSeqElmnt[] =
{
   &cmMsgDefSdpOptNptTime,
   &cmMsgDefMetaHyphen,
   &cmMsgDefSdpOptNptTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpNptSeq =
{
   3,
   cmMsgDefSdpNptSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNpt =
{
#ifdef CM_ABNF_DBG
   "SDP NPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 266,
   sizeof(CmSdpTimeNpt),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpNptSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpTStrMeta = {(Data *)"T"};
PUBLIC CmAbnfElmDef cmMsgDefSdpTStr =
{
#ifdef CM_ABNF_DBG
   "SDP T",
   "SDPT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 267,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpTStrMeta,
   cmSdpRegExpT
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpZStrMeta = {(Data *)"Z"};
PUBLIC CmAbnfElmDef cmMsgDefSdpZStr =
{
#ifdef CM_ABNF_DBG
   "SDP Z",
   "SDPZ",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 268,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpZStrMeta,
   cmSdpRegExpZ
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpUtcTimeDateRng = {8, 8, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUtcTimeDateRng = {8, 8};
#endif /* CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmDef cmMsgDefSdpUtcTimeDate =
{
#ifdef CM_ABNF_DBG
   "SDP UTC TIME - date",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 269,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpUtcTimeDateRng,
   cmAbnfRegExpDgt
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpUtcTimeTimeRng = {6, 6, 0, 235959};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUtcTimeTimeRng = {6, 6};
#endif /* CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmDef cmMsgDefSdpUtcTimeTime =
{
#ifdef CM_ABNF_DBG
   "SDP UtcTimeTime",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 270,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpUtcTimeTimeRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUtcTimeSeqElmnt[] =
{
   &cmMsgDefSdpUtcTimeDate,
   &cmMsgDefSdpTStr,
   &cmMsgDefSdpUtcTimeTime,
   &cmMsgDefSdpOptDotFrac,
   &cmMsgDefSdpZStr
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpUtcTimeSeq =
{
   5,
   cmMsgDefSdpUtcTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUtcTime =
{
#ifdef CM_ABNF_DBG
   "SDP UtcTime",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 271,
   sizeof(CmSdpUtc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpUtcTimeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptUtcTime =
{
#ifdef CM_ABNF_DBG
   "SDP OptUtcTime",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 272,
   sizeof(CmSdpUtc),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpUtcTimeSeq,    /* NB */
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUtcSeqElmnt[] =
{
   &cmMsgDefSdpUtcTime,
   &cmMsgDefMetaHyphen,
   &cmMsgDefSdpOptUtcTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpUtcSeq =
{
   3,
   cmMsgDefSdpUtcSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUtc =
{
#ifdef CM_ABNF_DBG
   "SDP UTC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 273,
   sizeof(CmSdpTimeUtc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpUtcSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSmpteEnum =
{
   (Data *)"smpte=",
   CM_SDP_RANGE_SMPTE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSmpteStr =
{
#ifdef CM_ABNF_DBG
   "SDP SmpteStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 274,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSmpteEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSmpte30DropEnum =
{
   (Data *)"smpte-30-drop=",
   CM_SDP_RANGE_SMPTE_30_DROP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSmpte30DropStr =
{
#ifdef CM_ABNF_DBG
   "SDP Smpte30DropStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 275,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSmpte30DropEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSmpte25Enum =
{
   (Data *)"smpte-25=",
   CM_SDP_RANGE_SMPTE_25
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSmpte25Str =
{
#ifdef CM_ABNF_DBG
   "SDP Smpte25Str",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 276,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSmpte25Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNptEnum =
{
   (Data *)"npt=",
   CM_SDP_RANGE_NPT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNptStr =
{
#ifdef CM_ABNF_DBG
   "SDP NptStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 277,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpUtcEnum =
{
   (Data *)"clock=",
   CM_SDP_RANGE_UTC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUtcStr =
{
#ifdef CM_ABNF_DBG
   "SDP UtcStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 278,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpUtcEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrRangeChcElmnt[] =
{
   &cmMsgDefSdpSmpte,
   &cmMsgDefSdpNpt,
   &cmMsgDefSdpUtc
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrRangeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpSmpteStr,
   &cmMsgDefSdpSmpte30DropStr,
   &cmMsgDefSdpSmpte25Str,
   &cmMsgDefSdpNptStr,
   &cmMsgDefSdpUtcStr
};

PUBLIC U8 cmMsgDefSdpAttrRangeChcIdx[] = {99, 0, 0, 0, 1, 2};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrRangeChc =
{
   3,
   6,
   cmMsgDefSdpAttrRangeChcIdx,
   cmMsgDefSdpAttrRangeChcElmnt,
   cmMsgDefSdpAttrRangeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRange =
{
#ifdef CM_ABNF_DBG
   "SDP AttrRange",
   "SDPRangeType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 279,
   sizeof(CmSdpAttrRange),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrRangeChc,
   cmSdpRegExpRangeType
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal1Enum =
{
   (Data *)"AAL1",
   CM_SDP_AAL_TYPE_1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal1Str =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 280,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal1Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal2Enum =
{
   (Data *)"AAL2",
   CM_SDP_AAL_TYPE_2
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal2Str =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 281,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal2Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal34Enum =
{
   (Data *)"AAL3/4",
   CM_SDP_AAL_TYPE_34
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal34Str =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal34",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 282,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal34Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAalUserEnum =
{
   (Data *)"USER_DEFINED_AAL",
   CM_SDP_AAL_TYPE_USERDEF
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAalUserStr =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAalUser",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 283,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAalUserEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal5Enum =
{
   (Data *)"AAL5",
   CM_SDP_AAL_TYPE_5
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal5Str =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 284,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal5Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal1_SDTEnum =
{
   (Data *)"AAL1_SDT",
   CM_SDP_AAL_TYPE_AAL1_SDT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal1_SDTStr =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal1_SDT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 285,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal1_SDTEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeAal1_UDTEnum =
{
   (Data *)"AAL1_UDT",
   CM_SDP_AAL_TYPE_AAL1_UDT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeAal1_UDTStr =
{
#ifdef CM_ABNF_DBG
   "SDP AalTypeAal1_UDT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 286,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeAal1_UDTEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttAalTypeEnum[] =
{
   NULLP,
   &cmMsgDefSdpAttrAalTypeAal1Str,
   &cmMsgDefSdpAttrAalTypeAal2Str,
   &cmMsgDefSdpAttrAalTypeAal34Str,
   &cmMsgDefSdpAttrAalTypeAalUserStr,
   &cmMsgDefSdpAttrAalTypeAal5Str,
   &cmMsgDefSdpAttrAalTypeAal1_SDTStr, 
   &cmMsgDefSdpAttrAalTypeAal1_UDTStr 
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrAalTypeChc =
{
   8,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttAalTypeEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalType =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AAL Type",
   "SDPAalType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 287,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrAalTypeChc,
   cmSdpRegExpAalType
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSuppPrefStandardEnum =
{
   (Data *)"standard",
   CM_SDP_SIL_SUPP_PREF_STANDARD
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSuppPrefStandardStr =
{
#ifdef CM_ABNF_DBG
   "SDP standard",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 288,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSuppPrefStandardEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSuppPrefCustomEnum =
{
   (Data *)"custom",
   CM_SDP_SIL_SUPP_PREF_CUSTOM
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSuppPrefCustomStr =
{
#ifdef CM_ABNF_DBG
   "SDP custom",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 289,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSuppPrefCustomEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSilSuppPrefChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSuppPrefStandardStr,
   &cmMsgDefSdpSuppPrefCustomStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrSilSuppPrefChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrSilSuppPrefChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSilSuppPref =
{
#ifdef CM_ABNF_DBG
   "SDP AttrSilSuppPref",
   "SDPSuppPref",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 290,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrSilSuppPrefChc,
   cmSdpRegExpSuppPref
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSidUseNoSidEnum =
{
   (Data *)"No SID",
   CM_SDP_SID_USE_NO_SID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSidUseNoSidStr =
{
#ifdef CM_ABNF_DBG
   "SDP SidUseNoSid",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 291,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSidUseNoSidEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSidUseFixedNoiseEnum =
{
   (Data *)"Fixed Noise",
   CM_SDP_SID_USE_FIXED_NOISE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSidUseFixedNoiseStr =
{
#ifdef CM_ABNF_DBG
   "SDP SidUseFixedNoise",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 292,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSidUseFixedNoiseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpSidUseSampledNoiseEnum =
{
   (Data *)"Sampled Noise",
   CM_SDP_SID_USE_SAMPLED_NOISE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSidUseSampledNoiseStr =
{
#ifdef CM_ABNF_DBG
   "SDP SidUseSampledNoise",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 293,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpSidUseSampledNoiseEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSilSuppSidUseChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSidUseNoSidStr,
   &cmMsgDefSdpSidUseFixedNoiseStr,
   &cmMsgDefSdpSidUseSampledNoiseStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrSilSuppSidUseChc =
{
   4,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrSilSuppSidUseChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSilSuppSidUse =
{
#ifdef CM_ABNF_DBG
   "SDP SidUse",
   "SDPSidUse",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 294,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrSilSuppSidUseChc,
   cmSdpRegExpSidUse
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSilSuppSeqElmnt[] =
{
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrSilSuppPref,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrSilSuppSidUse,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrSilSuppSeq =
{
   9,
   cmMsgDefSdpAttrSilSuppSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSilSupp =
{
#ifdef CM_ABNF_DBG
   "SDP AttrSilSupp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 295,
   sizeof(CmSdpAttrSilSupp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrSilSuppSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEcanTypeG165Enum =
{
   (Data *)"G165",
   CM_SDP_ECHO_CAN_G165
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEcanTypeG165Str =
{
#ifdef CM_ABNF_DBG
   "SDP EcanTypeG165",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 296,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEcanTypeG165Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpEcanTypeG168Enum =
{
   (Data *)"G168",
   CM_SDP_ECHO_CAN_G168
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEcanTypeG168Str =
{
#ifdef CM_ABNF_DBG
   "SDP EcanTypeG168",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 297,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpEcanTypeG168Enum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEcanTypeChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpEcanTypeG165Str,
   &cmMsgDefSdpEcanTypeG168Str
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpEcanTypeChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpEcanTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEcanType =
{
#ifdef CM_ABNF_DBG
   "SDP EcanType",
   "SDPEcanType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 298,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpEcanTypeChc,
   cmSdpRegExpEcanType
};



PUBLIC CmAbnfElmTypeEnum  cmSdpAtmDirFlgForwEnum =
{
    (Data *)"f" ,
    CM_SDP_DIR_FLG_FORW
};

PUBLIC CmAbnfElmDef  cmSdpAtmDirFlgForwEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: DIR FLG FORW ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  999 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmSdpAtmDirFlgForwEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmSdpAtmDirFlgBackEnum =
{
    (Data *)"b" ,
    CM_SDP_DIR_FLG_BACK
};

PUBLIC CmAbnfElmDef  cmSdpAtmDirFlgBackEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: DIR FLG BACK ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1000 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmSdpAtmDirFlgBackEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmSdpAtmDirFlgBothEnum =
{
    (Data *)"fb" ,
    CM_SDP_DIR_FLG_BOTH
};

PUBLIC CmAbnfElmDef  cmSdpAtmDirFlgBothEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: DIR FLG BOTH ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1001 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmSdpAtmDirFlgBothEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrDirFlgChcEnum[] =
{
&cmSdpAtmDirFlgForwEnumDef ,
&cmSdpAtmDirFlgBackEnumDef ,
&cmSdpAtmDirFlgBothEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrDirFlgChc =
{
    3 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrDirFlgChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrDirFlg =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR DIR FLG " ,
    "cmSdpRegExpDirFlg" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1002 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrDirFlgChc ,
    cmSdpRegExpDirFlg
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrEchoCanSeqElmnt[] =
{
   &cmMsgDefSdpAttrDirFlg,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpEcanType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrEchoCanSeq =
{
   5,
   cmMsgDefSdpAttrEchoCanSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEchoCan =
{
#ifdef CM_ABNF_DBG
   "SDP AttrEchoCan",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 299,
   sizeof(CmSdpAttrEchoCan),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrEchoCanSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrGainCtlSeqElmnt[] =
{
   &cmMsgDefSdpAttrDirFlg,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrGainCtlSeq =
{
   5,
   cmMsgDefSdpAttrGainCtlSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrGainCtl =
{
#ifdef CM_ABNF_DBG
   "SDP AttrGainCtl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 300,
   sizeof(CmSdpAttrGainCtl),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrGainCtlSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSkipSubType =
{
#ifdef CM_ABNF_DBG
   "SDP Skip MedProto SubType",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 301,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMedProtoUnknownValRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUnknownVal =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUnknownVal",
   "SDPMedProtoVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 302,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpMedProtoUnknownValRng,
   cmSdpRegExpMedProtoVal
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUnknownSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUnknownVal
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUnknownSeq =
{
   1,
   cmMsgDefSdpMedProtoUnknownSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUnknown =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUnknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 303,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUnknownSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoUdpMeta = {(Data *)"udp"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdpMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdpMetaStr",
   "SDPMedProtoUdp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 304,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoUdpMeta,
   cmSdpRegExpMedProtoUdp
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUdpSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUdpMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUdpSeq =
{
   2,
   cmMsgDefSdpMedProtoUdpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdp =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 305,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUdpSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoTcpMeta = {(Data *)"tcp"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoTcpMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoTcpMetaStr",
   "SDPMedProtoTcp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 306,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoTcpMeta,
   cmSdpRegExpMedProtoTcp
};

 /* 003.main_2 addition */
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoLclMeta = {(Data *)"local"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoLclMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoLclMetaStr",
   "SDPMedProtoLcl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 749,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoLclMeta,
   cmSdpRegExpMedProtoLcl
};

#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoSipMeta = {(Data *)"sip"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSipMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoSipMetaStr",
   "SDPMedProtoSip",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 749,  
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoSipMeta,
   cmSdpRegExpMedProtoSip
};
#endif /* CM_SDP_SIP_IM_SUPPORT */


PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoTcpSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoTcpMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoTcpSeq =
{
   2,
   cmMsgDefSdpMedProtoTcpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoTcp =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoTcp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 307,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoTcpSeq,
   NULLP
};

/* 003.main_2 addition*/
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoLclSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoLclMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoLclSeq =
{
   2,
   cmMsgDefSdpMedProtoLclSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoLcl =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtolcl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 748,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoLclSeq,
   NULLP
};

#ifdef CM_SDP_V_3

PUBLIC CmAbnfElmTypeMeta  cmMsgDefSdpMedProtoSapMeta =  {  (Data *) "sap"  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpMedProtoSapMetastr =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP MED PROTO SAP METASTR " ,
    "MedProtoSap" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 763 ,
    0 ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_META ,
    (U8 *) &cmMsgDefSdpMedProtoSapMeta ,
    cmSdpRegExpMedProtoSap
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpMedProtoSapSeqElmnts[] =
{
    &cmMsgDefSdpMedProtoSapMetastr ,
    &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpMedProtoSapSeq =
{
    2 ,
    cmMsgDefSdpMedProtoSapSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpMedProtoSap =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP MED PROTO SAP " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 764 ,
    sizeof( ((CmSdpMedProto *)0)->u ),
    CM_ABNF_MANDATORY ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &cmMsgDefSdpMedProtoSapSeq ,
    NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoUdptlMeta = {(Data *)"udptl"};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdptlMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdptlMetaStr",
   "SDPMedProtoUdptl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1021,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoUdptlMeta,
   cmSdpRegExpMedProtoUdptl
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUdptlSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUdptlMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUdptlSeq =
{
   2,
   cmMsgDefSdpMedProtoUdptlSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdptl =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdptl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1022,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUdptlSeq,
   NULLP
};

#endif /* CM_SDP_V_3 */

#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoSipSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoSipMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoSipSeq =
{
   2,
   cmMsgDefSdpMedProtoSipSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSip =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoSip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 748,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoSipSeq,
   NULLP
};
#endif /* CM_SDP_SIP_IM_SUPPORT */

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoRtpMeta = {(Data *)"RTP"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtpMetaStr",
   "SDPMedProtoRtp",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 308,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoRtpMeta,
   cmSdpRegExpMedProtoRtp
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoRtpAvpEnum =
{
   (Data *)"AVP",
   CM_SDP_PROTO_RTP_AVP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpAvpStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtpAvp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 309,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoRtpAvpEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoRtpAvpTcpEnum =
{
   (Data *)"AVP-TCP",
   CM_SDP_PROTO_RTP_AVP_TCP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpAvpTcpStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtpAvpTcp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 310,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoRtpAvpTcpEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoRtpSubtypeChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpMedProtoRtpAvpStr,
   &cmMsgDefSdpMedProtoRtpAvpTcpStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoRtpSubtypeChcElmnt[] =
{
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC U8 cmMsgDefSdpMedProtoRtpSubtypeChcIdx[] = {0, 0, 0};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMedProtoRtpSubtypeChc =
{
   1,
   3,
   cmMsgDefSdpMedProtoRtpSubtypeChcIdx,
   cmMsgDefSdpMedProtoRtpSubtypeChcElmnt,
   cmMsgDefSdpMedProtoRtpSubtypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpSubtype =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtpSubtype",
   "SDPRtpSubtype",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 311,
   sizeof(CmSdpMedProtoSubtype),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMedProtoRtpSubtypeChc,
   cmSdpRegExpRtpSubtype
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoRtpSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoRtpMetaStr,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpMedProtoRtpSubtype
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoRtpSeq =
{
   3,
   cmMsgDefSdpMedProtoRtpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtp =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 312,
   sizeof(CmSdpMedProto) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoRtpSeq,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal1Meta = {(Data *)"AAL1"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1MetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1MetaStr",
   "SDPMedProtoAal1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 313,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal1Meta,
   cmSdpRegExpMedProtoAal1
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1CorporateEnum =
{
   (Data *)NULLP,
   CM_SDP_PROTO_AALX_CORPORATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1CorporateStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1CorporateStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 314,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1CorporateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1AtmfEnum =
{
   (Data *)NULLP,
   CM_SDP_PROTO_AALX_ATMF
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1AtmfStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1AtmfStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 315,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1AtmfEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1ItuEnum =
{
   (Data *)NULLP,
   CM_SDP_PROTO_AALX_ITU
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1ItuStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1ItuStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 316,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1ItuEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1IeeeEnum =
{
   (Data *)NULLP,
   CM_SDP_PROTO_AALX_IEEE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1IeeeStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1IeeeStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 317,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1IeeeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1CustomEnum =
{
   (Data *)NULLP,
   CM_SDP_PROTO_AALX_CUSTOM
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1CustomStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1CustomStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 318,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1CustomEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMedProtoAal1CorporateRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Corporate =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Corporate",
   "SDPAal1Corporate",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 319,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpMedProtoAal1CorporateRng,
   cmSdpRegExpAal1Corporate
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal1AtmfMeta = {(Data *)"ATMF"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1AtmfMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1AtmfMetaStr",
   "SDPAtmfStr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 320,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal1AtmfMeta,
   cmSdpRegExpAtmfStr
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSkipSubTypeUnion =
{
#ifdef CM_ABNF_DBG
   "SDP SkipSubTypeUnion",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 321,
   sizeof(((CmSdpMedProtoSubtype *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1AtmfSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1AtmfMetaStr,
   &cmMsgDefSdpMedProtoSkipSubTypeUnion
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1AtmfSeq =
{
   2,
   cmMsgDefSdpMedProtoAal1AtmfSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Atmf =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Atmf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 322,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1AtmfSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal1ItuMeta = {(Data *)"ITU"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1ItuMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1ItuMetaStr",
   "SDPItuStr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 323,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal1ItuMeta,
   cmSdpRegExpItuStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1ItuSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1ItuMetaStr,
   &cmMsgDefSdpMedProtoSkipSubTypeUnion
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1ItuSeq =
{
   2,
   cmMsgDefSdpMedProtoAal1ItuSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Itu =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Itu",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 324,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1ItuSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal1CustomMeta =
   {(Data *)"custom"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1CustomMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1CustomMetaStr",
   "SDPCustomStr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 325,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal1CustomMeta,
   cmSdpRegExpCustomStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1CustomSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1CustomMetaStr,
   &cmMsgDefSdpMedProtoSkipSubTypeUnion
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1CustomSeq =
{
   2,
   cmMsgDefSdpMedProtoAal1CustomSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Custom =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Custom",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 326,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1CustomSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal1IeeeMeta = {(Data *)"IEEE:"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1IeeeMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1IeeeMetaStr",
   "SDPIeeeColon",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 327,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal1IeeeMeta,
   cmSdpRegExpIeeeColon
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpMedProtoAal1IeeeIdRng = 
   {6, 6, 0, 0xFFFFFF};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMedProtoAal1IeeeIdRng = {6, 6};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1IeeeId =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1IeeeId",
   "CM_RXDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 328,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_HEXUINT32,
   (U8 *)&cmMsgDefSdpMedProtoAal1IeeeIdRng,
   cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1IeeeSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1IeeeMetaStr,
   &cmMsgDefSdpMedProtoAal1IeeeId
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1IeeeSeq =
{
   2,
   cmMsgDefSdpMedProtoAal1IeeeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Ieee =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Ieee",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 329,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1IeeeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1SubtypeChcEnum[] =
{
   &cmMsgDefSdpMedProtoAal1CorporateStr,
   &cmMsgDefSdpMedProtoAal1AtmfStr,
   &cmMsgDefSdpMedProtoAal1ItuStr,
   &cmMsgDefSdpMedProtoAal1IeeeStr,
   &cmMsgDefSdpMedProtoAal1CustomStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1SubtypeChcElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1Corporate,
   &cmMsgDefSdpMedProtoAal1Atmf,
   &cmMsgDefSdpMedProtoAal1Itu,
   &cmMsgDefSdpMedProtoAal1Ieee,
   &cmMsgDefSdpMedProtoAal1Custom
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMedProtoAal1SubtypeChc =
{
   5,
   0,
   NULLP,
   cmMsgDefSdpMedProtoAal1SubtypeChcElmnt,
   cmMsgDefSdpMedProtoAal1SubtypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Subtype =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1Subtype",
   "SDPAal1Subtype",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 330,
   sizeof(CmSdpMedProtoSubtype),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMedProtoAal1SubtypeChc,
   cmSdpRegExpAal1Subtype
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1SeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1MetaStr,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpMedProtoAal1Subtype
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1Seq =
{
   3,
   cmMsgDefSdpMedProtoAal1SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1 =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 331,
   sizeof(((CmSdpMedProto *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1Seq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal2Meta = {(Data *)"AAL2"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal2MetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal2MetaStr",
   "SDPMedProtoAal2",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 332,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal2Meta,
   cmSdpRegExpMedProtoAal2
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal2SeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal2MetaStr,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpMedProtoAal1Subtype
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal2Seq =
{
   3,
   cmMsgDefSdpMedProtoAal2SeqElmnt
};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal2 =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 333,
   sizeof(CmSdpMedProtoSubtype),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal2Seq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoAal5Meta = {(Data *)"AAL5"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal5MetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal5MetaStr",
   "SDPMedProtoAal5",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 334,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoAal5Meta,
   cmSdpRegExpMedProtoAal5
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal5SeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal5MetaStr,
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpMedProtoAal1Subtype
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal5Seq =
{
   3,
   cmMsgDefSdpMedProtoAal5SeqElmnt
};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal5 =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 335,
   sizeof(CmSdpMedProtoSubtype),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal5Seq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoH323cMeta = {(Data *)"H323c"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoH323cMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoH323cMetaStr",
   "SDPMedProtoH323c",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 336,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoH323cMeta,
   cmSdpRegExpMedProtoH323c
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoH323cSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoH323cMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoH323cSeq =
{
   2,
   cmMsgDefSdpMedProtoH323cSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoH323c =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoH323c",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 337,
   sizeof(CmSdpMedProto) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoH323cSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoVoiceMeta = {(Data *)"voice"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoVoiceMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoVoiceMetaStr",
   "SDPMedProtoVoice",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 338,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoVoiceMeta,
   cmSdpRegExpMedProtoVoice
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoVoiceSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoVoiceMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoVoiceSeq =
{
   2,
   cmMsgDefSdpMedProtoVoiceSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoVoice =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoVoice",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 339,
   sizeof(CmSdpMedProto) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoVoiceSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoFaxMeta = {(Data *)"fax"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFaxMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFaxMetaStr",
   "SDPMedProtoFax",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 340,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoFaxMeta,
   cmSdpRegExpMedProtoFax
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFaxSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoFaxMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFaxSeq =
{
   2,
   cmMsgDefSdpMedProtoFaxSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFax =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFax",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 341,
   sizeof(CmSdpMedProto) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoFaxSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMedProtoPagerMeta = {(Data *)"pager"};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoPagerMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoPagerMetaStr",
   "SDPMedProtoPager",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 342,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMedProtoPagerMeta,
   cmSdpRegExpMedProtoPager
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoPagerSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoPagerMetaStr,
   &cmMsgDefSdpMedProtoSkipSubType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoPagerSeq =
{
   2,
   cmMsgDefSdpMedProtoPagerSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoPager =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoPager",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 343,
   sizeof(CmSdpMedProto) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoPagerSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoUnknownEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_UNKNOWN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUnknownStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUnknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 344,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoUnknownEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoUdpEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_UDP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdpStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 345,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoUdpEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoTcpEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_TCP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoTcpStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoTcp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 346,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoTcpEnum,
   NULLP
};

/* 003.main_2 additions */
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoLclEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_LCL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoLclStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProto Lcl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 747,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoLclEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoSapEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_SAP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSapStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProto Lcl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 765 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoSapEnum,
   NULLP
};

#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoSipEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_SIP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSipStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProto Sip",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 747,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoSipEnum,
   NULLP
};
#endif /* CM_SDP_SIP_IM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoRtpEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_RTP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 347,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoRtpEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal1Enum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_AAL1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1Str =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 348,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal1Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal2Enum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_AAL2
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal2Str =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal2",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 349,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal2Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoAal5Enum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_AAL5
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal5Str =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 350,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoAal5Enum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoH323cEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_H323C
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoH323cStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoH323c",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 351,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoH323cEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoVoiceEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_TN_VOICE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoVoiceStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoVoice",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 352,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoVoiceEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoFaxEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_TN_FAX
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFaxStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFax",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 353,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoFaxEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoPagerEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_TN_PAGER
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoPagerStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoPager",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 354,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoPagerEnum,
   NULLP
};

#ifdef CM_SDP_V_3
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMedProtoUdptlEnum =
{
   NULLP,
   CM_SDP_MEDIA_PROTO_UDPTL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdptlStr =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdptlStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1023,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMedProtoUdptlEnum,
   NULLP
};
#endif /* CM_SDP_V_3 */

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoChcEnum[] =
{
   &cmMsgDefSdpMedProtoUnknownStr,
   &cmMsgDefSdpMedProtoUdpStr,
   &cmMsgDefSdpMedProtoRtpStr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpMedProtoAal1Str,
   &cmMsgDefSdpMedProtoAal2Str,
   &cmMsgDefSdpMedProtoAal5Str,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpMedProtoH323cStr,
   &cmMsgDefSdpMedProtoVoiceStr,
   &cmMsgDefSdpMedProtoFaxStr,
   &cmMsgDefSdpMedProtoPagerStr,
   &cmMsgDefSdpMedProtoTcpStr,
   &cmMsgDefSdpMedProtoLclStr      /*003.main_2 addition */
#ifdef CM_SDP_V_3
#ifdef CM_SDP_SIP_IM_SUPPORT
   , &cmMsgDefSdpMedProtoSapStr,
   &cmMsgDefSdpMedProtoUdptlStr,
   &cmMsgDefSdpMedProtoSipStr
#else 
   , &cmMsgDefSdpMedProtoSapStr,
   &cmMsgDefSdpMedProtoUdptlStr
#endif /* CM_SDP_SIP_IM_SUPPORT */
#else
#ifdef CM_SDP_SIP_IM_SUPPORT
   , NULLP, NULLP, &cmMsgDefSdpMedProtoSipStr
#endif /* CM_SDP_SIP_IM_SUPPORT */
#endif
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoChcElmnt[] =
{
   &cmMsgDefSdpMedProtoUnknown,
   &cmMsgDefSdpMedProtoUdp,
   &cmMsgDefSdpMedProtoRtp,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpMedProtoAal1,
   &cmMsgDefSdpMedProtoAal2,
   &cmMsgDefSdpMedProtoAal5,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpMedProtoH323c,
   &cmMsgDefSdpMedProtoVoice,
   &cmMsgDefSdpMedProtoFax,
   &cmMsgDefSdpMedProtoPager,
   &cmMsgDefSdpMedProtoTcp,
   &cmMsgDefSdpMedProtoLcl     /* 003.main_2 addition */
#ifdef CM_SDP_V_3
#ifdef CM_SDP_SIP_IM_SUPPORT
   , &cmMsgDefSdpMedProtoSap,
   &cmMsgDefSdpMedProtoUdptl,
   &cmMsgDefSdpMedProtoSip
#else 
   , &cmMsgDefSdpMedProtoSap,
   &cmMsgDefSdpMedProtoUdptl
#endif /* CM_SDP_SIP_IM_SUPPORT */
#else
#ifdef CM_SDP_SIP_IM_SUPPORT
   , NULLP, NULLP, &cmMsgDefSdpMedProtoSip
#endif /* CM_SDP_SIP_IM_SUPPORT */
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMedProtoChc =
{
#ifdef CM_SDP_V_3
#ifdef CM_SDP_SIP_IM_SUPPORT
   15,
#else 
/* 001.main_7: incremented to include "udptl" */
   14,
#endif /* CM_SDP_SIP_IM_SUPPORT */
#else
#ifdef CM_SDP_SIP_IM_SUPPORT
   15,
#else 
   12, 
#endif /* CM_SDP_SIP_IM_SUPPORT */
#endif
   0,
   NULLP,
   cmMsgDefSdpMedProtoChcElmnt,
   cmMsgDefSdpMedProtoChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProto =
{
#ifdef CM_ABNF_DBG
   "SDP Media Proto (aka Transport)",
   "SDPMedProto",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 355,
   sizeof(CmSdpMedProto),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMedProtoChc,
   cmSdpRegExpMedProto
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipUuiCodeRngRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipUuiCodeRng =
{
#ifdef CM_ABNF_DBG
   "SDP SkipUuiCodeRng",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 356,
   sizeof(TknU8) * 2,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipUuiCodeRngRng,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpSpecUuiCodeRngSeqElmnt[] =
{
   &cmMsgDefSdpDecUchar,
   &cmMsgDefMetaHyphen,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSpecUuiCodeRngSeq =
{
   3,
   cmMsgDefSdpSpecUuiCodeRngSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSpecUuiCodeRng =
{
#ifdef CM_ABNF_DBG
   "SDP SpecUuiCodeRng",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 357,
   sizeof(TknU8) * 2,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpSpecUuiCodeRngSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUuiCodeRngChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUuiCodeRngChcElmnt[] =
{
   &cmMsgDefSdpSkipUuiCodeRng,
   &cmMsgDefSdpSpecUuiCodeRng
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpUuiCodeRngChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpUuiCodeRngChcElmnt,
   cmMsgDefSdpUuiCodeRngChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUuiCodeRng =
{
#ifdef CM_ABNF_DBG
   "SDP UuiCodeRng",
   "SDPUuiCodeRng",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 358,
   sizeof(CmSdpUuiCodeRng),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpUuiCodeRngChc,
   cmSdpRegExpUuiCodeRng
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpProfDescCompSeqElmnt[] =
{
   &cmMsgDefSdpUuiCodeRng,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpEncodingName,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpProfDescCompSeq =
{
   7,
   cmMsgDefSdpProfDescCompSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpProfDescComp =
{
#ifdef CM_ABNF_DBG
   "SDP ProfDescComp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 359,
   sizeof(CmSdpProfComp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpProfDescCompSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpProfDescCompArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpProfDescComp
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpProfDescCompArraySeqOf =
{
   1,
   CM_SDP_MAX_PROF_COMPS,
   2,
   cmMsgDefSdpProfDescCompArraySeqOfElmnt,
   sizeof(CmSdpProfComp)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpProfDescCompArray =
{
#ifdef CM_ABNF_DBG
   "SDP ProfDescCompArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 360,
   sizeof(CmSdpProfCompSet),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpProfDescCompArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpProfDescCompSetSeqElmnt[] =
{
   &cmMsgDefSdpProfDescComp,
   &cmMsgDefSdpProfDescCompArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpProfDescCompSetSeq =
{
   2,
   cmMsgDefSdpProfDescCompSetSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpProfDescCompSet =
{
#ifdef CM_ABNF_DBG
   "SDP ProfDescCompSet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 361,
   sizeof(CmSdpProfCompSet),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpProfDescCompSetSeq,
   NULLP
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrProfDescSeqElmnt[] =
{
   &cmMsgDefSdpMedProto,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpProfDescCompSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrProfDescSeq =
{
   5,
   cmMsgDefSdpAttrProfDescSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrProfDesc =
{
#ifdef CM_ABNF_DBG
   "SDP ProfDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 362,
   sizeof(CmSdpAttrProfDesc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrProfDescSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDevSelCompSeqElmnt[] =
{
   &cmMsgDefSdpEncodingName,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrDevSelCompSeq =
{
   5,
   cmMsgDefSdpAttrDevSelCompSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDevSelComp =
{
#ifdef CM_ABNF_DBG
   "SDP AttrDevSelComp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 363,
   sizeof(CmSdpAttrDevSelComp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrDevSelCompSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDevSelCompArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrDevSelComp
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttrDevSelCompArraySeqOf =
{
   1,
   CM_SDP_MAX_DEV_SEL_COMPS,
   2,
   cmMsgDefSdpAttrDevSelCompArraySeqOfElmnt,
   sizeof(CmSdpAttrDevSelComp)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDevSelCompArray =
{
#ifdef CM_ABNF_DBG
   "SDP DevSelCompArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 364,
   sizeof(CmSdpAttrDevSel) - sizeof(TknPres) - sizeof(TknU8),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttrDevSelCompArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDevSelCompSetSeqElmnt[] =
{
   &cmMsgDefSdpAttrDevSelComp,
   &cmMsgDefSdpAttrDevSelCompArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrDevSelCompSetSeq =
{
   2,
   cmMsgDefSdpAttrDevSelCompSetSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDevSelCompSet =
{
#ifdef CM_ABNF_DBG
   "SDP DevSelCompSet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 365,
   sizeof(CmSdpAttrDevSel) - sizeof(TknPres) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpAttrDevSelCompSetSeq,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDevSelSkipFxIncl =
{
#ifdef CM_ABNF_DBG
   "SDP AttrDevSelSkipFxIncl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 366,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDevSelSeqElmnt[] =
{
   &cmMsgDefSdpAttrDevSelSkipFxIncl,
   &cmMsgDefSdpAttrDevSelCompSet
};

   
PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrDevSelSeq =
{
   2,
   cmMsgDefSdpAttrDevSelSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDevSel =
{
#ifdef CM_ABNF_DBG
   "SDP AttrDevSel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 367,
   sizeof(CmSdpAttrDevSel),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrDevSelSeq,
   NULLP
};

#define cmMsgDefSdpAttrDSelFxIncl cmMsgDefSdpOnOffOrNull

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDSelSeqElmnt[] =
{
   &cmMsgDefSdpAttrDSelFxIncl,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrDevSelCompSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrDSelSeq =
{
   3,
   cmMsgDefSdpAttrDSelSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDSel = 
{
#ifdef CM_ABNF_DBG
   "SDP AttrDSel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 368,
   sizeof(CmSdpAttrDevSel),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrDSelSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscCbrEnum =
{
   (Data *)"CBR",
   CM_SDP_CAPAB_ASC_CBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscCbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscCbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 369,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscCbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscNrtVbrEnum =
{
   (Data *)"nrt-VBR",
   CM_SDP_CAPAB_ASC_NRT_VBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscNrtVbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscNrtVbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 370,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscNrtVbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscRtVbrEnum =
{
   (Data *)"rt-VBR",
   CM_SDP_CAPAB_ASC_RT_VBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscRtVbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscRtVbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 371,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscRtVbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscUbrEnum =
{
   (Data *)"UBR",
   CM_SDP_CAPAB_ASC_UBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscUbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscUbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 372,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscUbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscAbrEnum =
{
   (Data *)"ABR",
   CM_SDP_CAPAB_ASC_ABR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscAbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscAbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 373,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscAbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAscGfrEnum =
{
   (Data *)"GFR",
   CM_SDP_CAPAB_ASC_GFR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAscGfrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAscGfr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 374,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAscGfrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAtcDbrEnum =
{
   (Data *)"DBR",
   CM_SDP_CAPAB_ATC_DBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAtcDbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAtcDbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 375,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAtcDbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAtcSbrEnum =
{
   (Data *)"SBR",
   CM_SDP_CAPAB_ATC_SBR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAtcSbrStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAtcSbr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 376,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAtcSbrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAtcAbtItEnum =
{
   (Data *)"ABT/IT",
   CM_SDP_CAPAB_ATC_ABT_IT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAtcAbtItStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAtcAbtIt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 377,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAtcAbtItEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCapabAtcAbtDtEnum =
{
   (Data *)"ABT/DT",
   CM_SDP_CAPAB_ATC_ABT_DT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCapabAtcAbtDtStr =
{
#ifdef CM_ABNF_DBG
   "SDP CapabAtcAbtDt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 378,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCapabAtcAbtDtEnum,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabStdSkipNonStd =
{
#ifdef CM_ABNF_DBG
   "SDP Skip NonStdCapab",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 379,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCapabStdChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpCapabAscCbrStr,
   &cmMsgDefSdpCapabAscNrtVbrStr,
   &cmMsgDefSdpCapabAscRtVbrStr,
   &cmMsgDefSdpCapabAscUbrStr,
   &cmMsgDefSdpCapabAscAbrStr,
   &cmMsgDefSdpCapabAscGfrStr,
   &cmMsgDefSdpCapabAtcDbrStr,
   &cmMsgDefSdpCapabAtcSbrStr,
   &cmMsgDefSdpCapabAtcAbtItStr,
   &cmMsgDefSdpCapabAtcAbtDtStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCapabStdChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpAttrCapabStdSkipNonStd
};

PUBLIC U8 cmMsgDefSdpAttrCapabStdChcIdx[] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrCapabStdChc =
{
   2,
   11,
   cmMsgDefSdpAttrCapabStdChcIdx,
   cmMsgDefSdpAttrCapabStdChcElmnt,
   cmMsgDefSdpAttrCapabStdChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabStd =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCapabStd",
   "SDPCapabType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 380,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrCapabStdChc,
   cmSdpRegExpCapabType
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCapabNonStdEnum =
{
   (Data *)NULLP,
   CM_SDP_CAPAB_NONSTD
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabNonStdStr =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCapabNonStdStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 381,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCapabNonStdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttrCapabNonStdValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabNonStdVal =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCapabNonStdVal",
   "CM_RALDGCHAR",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 382,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAttrCapabNonStdValRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCapabTypeChcElmnt[] =
{
   &cmMsgDefSdpAttrCapabNonStdVal,
   &cmMsgDefSdpAttrCapabStd
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCapabTypeChcEnum[] =
{
   &cmMsgDefSdpAttrCapabNonStdStr,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
};

PUBLIC U8 cmMsgDefSdpAttrCapabTypeChcIdx[] = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrCapabTypeChc =
{
   2,
   11,
   cmMsgDefSdpAttrCapabTypeChcIdx,
   cmMsgDefSdpAttrCapabTypeChcElmnt,
   cmMsgDefSdpAttrCapabTypeChcEnum,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabType =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCapabType",
   "SDPCapabType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 383,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrCapabTypeChc,
   cmSdpRegExpCapabType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCapabSeqElmnt[] =
{
   &cmMsgDefSdpAttrCapabType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU8OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrCapabSeq =
{
   3,
   cmMsgDefSdpAttrCapabSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapab =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCapab",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 384,
   sizeof(CmSdpAttrCapab),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrCapabSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCdvType2PtEnum =
{
   (Data *)"2p",
   CM_SDP_CDV_TYPE_2_POINT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCdvType2PtStr =
{
#ifdef CM_ABNF_DBG
   "SDP CdvType2Pt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 385,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCdvType2PtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpCdvTypePeakToPeakEnum =
{
   (Data *)"pp",
   CM_SDP_CDV_TYPE_PEAK_TO_PEAK
};

PUBLIC CmAbnfElmDef cmMsgDefSdpCdvTypePeakToPeakStr =
{
#ifdef CM_ABNF_DBG
   "SDP CdvTypePeakToPeak",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 386,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpCdvTypePeakToPeakEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpQosParmsCdvTypeChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpCdvTypePeakToPeakStr,
   &cmMsgDefSdpCdvType2PtStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpQosParmsCdvTypeChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpQosParmsCdvTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpQosParmsCdvType =
{
#ifdef CM_ABNF_DBG
   "SDP QosParmsCdvType",
   "SDPCdvType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 387,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpQosParmsCdvTypeChc,
   cmSdpRegExpCdvType
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrQosParmsSeqElmnt[] =
{
   &cmMsgDefSdpAttrDirFlg,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpQosParmsCdvType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrQosParmsSeq =
{
   13,
   cmMsgDefSdpAttrQosParmsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQosParms =
{
#ifdef CM_ABNF_DBG
   "SDP AttrQosParms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 388,
   sizeof(CmSdpAttrQosParms),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrQosParmsSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTfcDescClpLvl0Enum =
{
   (Data *)"0",
   CM_SDP_CLP_LEVEL_0
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTfcDescClpLvl0Str =
{
#ifdef CM_ABNF_DBG
   "SDP TfcDescClpLvl0",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 389,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTfcDescClpLvl0Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTfcDescClpLvl0Plus1Enum =
{
   (Data *)"0+1",
   CM_SDP_CLP_LEVEL_0_PLUS_1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTfcDescClpLvl0Plus1Str =
{
#ifdef CM_ABNF_DBG
   "SDP TfcDescClpLvl0Plus1",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 390,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTfcDescClpLvl0Plus1Enum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTfcDescClpLvlChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpTfcDescClpLvl0Str,
   &cmMsgDefSdpTfcDescClpLvl0Plus1Str
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpTfcDescClpLvlChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpTfcDescClpLvlChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTfcDescClpLvl =
{
#ifdef CM_ABNF_DBG
   "SDP TfcDescClpLvl",
   "SDPClpLvl",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 391,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpTfcDescClpLvlChc,
   cmSdpRegExpClpLvl
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrTfcDescSeqElmnt[] =
{
   &cmMsgDefSdpAttrDirFlg,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTfcDescClpLvl,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrTfcDescSeq =
{
   19,
   cmMsgDefSdpAttrTfcDescSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTfcDesc =
{
#ifdef CM_ABNF_DBG
   "SDP AttrTfcDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 392,
   sizeof(CmSdpAttrTfcDesc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrTfcDescSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAbrParmsSeqElmnt[] =
{
   &cmMsgDefSdpAttrDirFlg,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAbrParmsSeq =
{
   9,
   cmMsgDefSdpAttrAbrParmsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAbrParms =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAbrParms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 393,
   sizeof(CmSdpAttrAbrParms),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAbrParmsSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrClkRecNullEnum =
{
   (Data *)"NULL",
   CM_SDP_CLK_REC_NULL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClkRecNullStr =
{
#ifdef CM_ABNF_DBG
   "SDP ClkRecNull",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 394,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrClkRecNullEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrClkRecSrtsEnum =
{
   (Data *)"SRTS",
   CM_SDP_CLK_REC_SRTS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClkRecSrtsStr =
{
#ifdef CM_ABNF_DBG
   "SDP ClkRecSrts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 395,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrClkRecSrtsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrClkRecAdaptiveEnum =
{
   (Data *)"ADAPTIVE",
   CM_SDP_CLK_REC_ADAPTIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClkRecAdaptiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP ClkRecAdaptive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 396,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrClkRecAdaptiveEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrClkRecChcEnum[] =
{
   &cmMsgDefSdpAttrClkRecNullStr,
   &cmMsgDefSdpAttrClkRecSrtsStr,
   &cmMsgDefSdpAttrClkRecAdaptiveStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrClkRecChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrClkRecChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClkRec =
{
#ifdef CM_ABNF_DBG
   "SDP AttrClkRec",
   "SDPClkRec",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 397,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrClkRecChc,
   cmSdpRegExpClkRec
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpFecNullEnum =
{
   (Data *)"NULL",
   CM_SDP_FEC_NULL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpFecNullStr =
{
#ifdef CM_ABNF_DBG
   "SDP FecNull",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 398,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpFecNullEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpFecLossSensitiveEnum =
{
   (Data *)"LOSS_SENSITIVE",
   CM_SDP_FEC_LOSS_SENSITIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpFecLossSensitiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP FecLossSensitive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 399,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpFecLossSensitiveEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpFecDelaySensitiveEnum =
{
   (Data *)"DELAY_SENSITIVE",
   CM_SDP_FEC_DELAY_SENSITIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpFecDelaySensitiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP FecDelaySensitive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 400,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpFecDelaySensitiveEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrFecChcEnum[] =
{
   &cmMsgDefSdpFecNullStr,
   &cmMsgDefSdpFecLossSensitiveStr,
   &cmMsgDefSdpFecDelaySensitiveStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrFecChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrFecChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFec =
{
#ifdef CM_ABNF_DBG
   "SDP AttrFec",
   "SDPFec",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 401,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrFecChc,
   cmSdpRegExpFec
};


PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrAtmBcobSeqElmnts[] =
{
    &cmMsgDefSdpGenU8 ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpOnOffOrNull
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrAtmBcobSeq =
{
    3 ,
    cmMsgDefSdpAttrAtmBcobSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrAtmBcob =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR ATM BCOB " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1003 ,
    sizeof(CmSdpAttrAtmBcob) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrAtmBcobSeq ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpBearTypePVCEnum =
{
   (Data *)"PVC",
   CM_SDP_BEAR_TYPE_PVC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBearTypePVCStr =
{
#ifdef CM_ABNF_DBG
   "SDP BearTypePVC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 402,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpBearTypePVCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpBearTypeSVCEnum =
{
   (Data *)"SVC",
   CM_SDP_BEAR_TYPE_SVC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBearTypeSVCStr =
{
#ifdef CM_ABNF_DBG
   "SDP BearTypeSVC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 403,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpBearTypeSVCEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpBearTypeCIDEnum =
{
   (Data *)"CID",
   CM_SDP_BEAR_TYPE_CID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBearTypeCIDStr =
{
#ifdef CM_ABNF_DBG
   "SDP BearTypeCID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 404,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpBearTypeCIDEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpBearTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpBearTypePVCStr,
   &cmMsgDefSdpBearTypeSVCStr,
   &cmMsgDefSdpBearTypeCIDStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpBearTypeChc =
{
   4,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpBearTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBearType =
{
#ifdef CM_ABNF_DBG
   "SDP BearType",
   "SDPBearType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 405,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpBearTypeChc,
   cmSdpRegExpBearType
};

#define cmMsgDefSdpLocalInit cmMsgDefSdpOnOffOrNull /* but maybe "omitted"! */

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrBearTypeSeqElmnt[] =
{
   &cmMsgDefSdpBearType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpLocalInit
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrBearTypeSeq =
{
   3,
   cmMsgDefSdpAttrBearTypeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrBearType =
{
#ifdef CM_ABNF_DBG
   "SDP AttrBearType",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 406,
   sizeof(CmSdpAttrBearType),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrBearTypeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrStrucSeqElmnt[] =
{
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrStrucSeq =
{
   3,
   cmMsgDefSdpAttrStrucSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrStruc =
{
#ifdef CM_ABNF_DBG
   "SDP AttrStruc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 407,
   sizeof(CmSdpAttrStruc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrStrucSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAal2CpsSeqElmnt[] =
{
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAal2CpsSeq =
{
   7,
   cmMsgDefSdpAttrAal2CpsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2Cps =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAal2Cps",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 408,
   sizeof(CmSdpAttrAal2Cps),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAal2CpsSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAal23661SeqElmnt[] =
{
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAal23661Seq =
{
   7,
   cmMsgDefSdpAttrAal23661SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal23661 =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAal23661",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 409,
   sizeof(CmSdpAttrAal23661),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAal23661Seq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal23662SapAudioEnum =
{
   (Data *)"audio",
   CM_SDP_AAL2_366_2_SAP_AUDIO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662SapAudioStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662SapAudio",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 410,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal23662SapAudioEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal23662SapMultiRateEnum =
{
   (Data *)"multirate",
   CM_SDP_AAL2_366_2_SAP_MULTIRATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662SapMultiRateStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662SapMultiRate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 411,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal23662SapMultiRateEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAal23662SapChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpAal23662SapAudioStr,
   &cmMsgDefSdpAal23662SapMultiRateStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAal23662SapChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAal23662SapChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662Sap =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662Sap",
   "SDPAal23662Sap",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 412,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAal23662SapChc,
   cmSdpRegExpAal23662Sap
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal23662EncALawEnum =
{
   (Data *)"PCMA",
   CM_SDP_AAL2_366_2_ENC_ALAW
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662EncALawStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662EncALaw",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 413,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal23662EncALawEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal23662EncMuLawEnum =
{
   (Data *)"PCMU",
   CM_SDP_AAL2_366_2_ENC_MULAW
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662EncMuLawStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662EncMuLaw",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 414,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal23662EncMuLawEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAal23662EncChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpAal23662EncALawStr,
   &cmMsgDefSdpAal23662EncMuLawStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAal23662EncChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAal23662EncChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal23662Enc =
{
#ifdef CM_ABNF_DBG
   "SDP Aal23662Enc",
   "SDPAal23662Enc",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 415,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAal23662EncChc,
   cmSdpRegExpAal23662Enc
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAal23662SeqElmnt[] =
{
   &cmMsgDefSdpAal23662Sap,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAal23662Enc,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAal23662Seq =
{
   23,
   cmMsgDefSdpAttrAal23662SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal23662 =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAal23662",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 416,
   sizeof(CmSdpAttrAal23662),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAal23662Seq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppH323cEnum =
{
   (Data *)"itu_h323c",
   CM_SDP_AAL5APP_H323C
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppH323cStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppH323c",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 417,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppH323cEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppAf83Enum =
{
   (Data *)"af83",
   CM_SDP_AAL5APP_AF83
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppAf83Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppAf83",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 418,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppAf83Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppAssuredSscopEnum =
{
   (Data *)"assuredSSCOP",
   CM_SDP_AAL5APP_ASSURED_SSCOP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppAssuredSscopStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppAssuredSscop",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 419,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppAssuredSscopEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppNonAssuredSscopEnum =
{
   (Data *)"nonassuredSSCOP",
   CM_SDP_AAL5APP_NONASSURED_SSCOP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppNonAssuredSscopStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppNonAssuredSscop",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 420,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppNonAssuredSscopEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuI3651Enum =
{
   (Data *)"itu_i3651",
   CM_SDP_AAL5APP_ITU_I3651
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuI3651Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuI3651",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 421,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuI3651Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuI3652Enum =
{
   (Data *)"itu_i3652",
   CM_SDP_AAL5APP_ITU_I3652
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuI3652Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuI3652",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 422,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuI3652Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuI3653Enum =
{
   (Data *)"itu_i3653",
   CM_SDP_AAL5APP_ITU_I3653
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuI3653Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuI3653",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 423,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuI3653Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppFrf11Enum =
{
   (Data *)"FRF11",
   CM_SDP_AAL5APP_FRF11
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppFrf11Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppFrf11",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 424,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppFrf11Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuH2221Enum =
{
   (Data *)"itu_h2221",
   CM_SDP_AAL5APP_ITU_H2221
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuH2221Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuH2221",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 425,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuH2221Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuI3661Enum =
{
   (Data *)"itu_i3661",
   CM_SDP_AAL5APP_ITU_I3661
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuI3661Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuI3661",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 426,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuI3661Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppItuI3662Enum =
{
   (Data *)"itu_i3662",
   CM_SDP_AAL5APP_ITU_I3662
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppItuI3662Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppItuI3662",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 427,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppItuI3662Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppFrf8Enum =
{
   (Data *)"FRF8",
   CM_SDP_AAL5APP_FRF8
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppFrf8Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppFrf8",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 428,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppFrf8Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppFrf5Enum =
{
   (Data *)"FRF5",
   CM_SDP_AAL5APP_FRF5
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppFrf5Str =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppFrf5",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 429,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppFrf5Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAal5AppNonStdEnum =
{
   (Data *)"X-",
   CM_SDP_AAL5APP_NONSTD
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppNonStdStr =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppNonStd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 429,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAal5AppNonStdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAal5AppNonStdRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAal5AppNonStd =
{
#ifdef CM_ABNF_DBG
   "SDP Aal5AppNonStd value without X-",
   "SDPAal5AppNonStd",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 429,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAal5AppNonStdRng,
   cmSdpRegExpAal5AppNonStd
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAal5AppChcEnum[] =
{
   &cmMsgDefSdpAal5AppNonStdStr,                   /*  0 */
   &cmMsgDefSdpAal5AppH323cStr,                    /*  1 */
   &cmMsgDefSdpAal5AppAf83Str,                     /*  2 */
   &cmMsgDefSdpAal5AppAssuredSscopStr,             /*  3 */
   &cmMsgDefSdpAal5AppNonAssuredSscopStr,          /*  4 */
   &cmMsgDefSdpAal5AppItuI3651Str,                 /*  5 */
   &cmMsgDefSdpAal5AppItuI3652Str,                 /*  6 */
   &cmMsgDefSdpAal5AppItuI3653Str,                 /*  7 */
   &cmMsgDefSdpAal5AppFrf11Str,                    /*  8 */
   &cmMsgDefSdpAal5AppItuH2221Str,                 /*  9 */
   &cmMsgDefSdpAal5AppItuI3661Str,                 /* 10 */
   &cmMsgDefSdpAal5AppItuI3662Str,                 /* 11 */
   &cmMsgDefSdpAal5AppFrf8Str,                     /* 12 */
   &cmMsgDefSdpAal5AppFrf5Str,                     /* 13 */
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAal5AppChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpAal5AppNonStd
};

PUBLIC U8 cmMsgDefSdpAttrAal5AppChcIdx[] = 
   {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrAal5AppChc =
{
   2,
   14,
   cmMsgDefSdpAttrAal5AppChcIdx,
   cmMsgDefSdpAttrAal5AppChcElmnt,
   cmMsgDefSdpAttrAal5AppChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal5App =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAal5App",
   "SDPAal5App",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 430,
   sizeof(CmSdpAttrAalApp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrAal5AppChc,
   cmSdpRegExpAal5App
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrLijSeqElmnt[] =
{
   &cmMsgDefSdpGenU8OrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrLijSeq =
{
   3,
   cmMsgDefSdpAttrLijSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrLij =
{
#ifdef CM_ABNF_DBG
   "SDP AttrLij",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 431,
   sizeof(CmSdpAttrLij),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrLijSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAnycastSeqElmnt[] =
{
   &cmMsgDefSdpAddrTypeAddr,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull, 
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull, 
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU8OrNull,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrAnycastSeq =
{
   7,
   cmMsgDefSdpAttrAnycastSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAnycast =
{
#ifdef CM_ABNF_DBG
   "SDP AttrAnycast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 432,
   sizeof(CmSdpAttrAnycast),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrAnycastSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpWtpIapSystemIdRng = {1, 15};
PUBLIC CmAbnfElmDef cmMsgDefSdpWtpIapSystemId =
{
#ifdef CM_ABNF_DBG
   "SDP WtpIapSystemId",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 433,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpWtpIapSystemIdRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpWtpCccIdRng = {1, 20};
PUBLIC CmAbnfElmDef cmMsgDefSdpWtpCccId =
{
#ifdef CM_ABNF_DBG
   "SDP WtpCccId",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 434,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpWtpCccIdRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrWtpSeqElmnt[] =
{
   &cmMsgDefSdpWtpIapSystemId,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpWtpCccId
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrWtpSeq =
{
   3,
   cmMsgDefSdpAttrWtpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrWtp =
{
#ifdef CM_ABNF_DBG
   "SDP AttrWtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 435,
   sizeof(CmSdpAttrWtp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrWtpSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrDirectionPassiveEnum =
{
   (Data *)"passive",
   CM_SDP_ATTR_DIRECTION_PASSIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionPassiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP Direction Passive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 436,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrDirectionPassiveEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrDirectionActiveEnum =
{
   (Data *)"active",
   CM_SDP_ATTR_DIRECTION_ACTIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionActiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP Direction Active",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 437,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrDirectionActiveEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrDirectionBothEnum =
{
   (Data *)"both",
   CM_SDP_ATTR_DIRECTION_BOTH
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionBothStr =
{
#ifdef CM_ABNF_DBG
   "SDP Direction Both",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 438,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrDirectionBothEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDirectionOptPortSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU16
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrDirectionOptPortSeq =
{
   2,
   cmMsgDefSdpAttrDirectionOptPortSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionOptPort =
{
#ifdef CM_ABNF_DBG
   "SDP space port",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 439,
   sizeof(TknU16),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpAttrDirectionOptPortSeq,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionSkipPort =
{
#ifdef CM_ABNF_DBG
   "SDP Skip DirectionPort",
   "EMPTY",
#endif /* CM_ABNF_DBG */   
   CM_ABNF_ELMNID_SDP_BASE + 440,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDirectionChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpAttrDirectionSkipPort,
   &cmMsgDefSdpAttrDirectionOptPort,
   &cmMsgDefSdpAttrDirectionOptPort
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrDirectionChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpAttrDirectionPassiveStr,
   &cmMsgDefSdpAttrDirectionActiveStr,
   &cmMsgDefSdpAttrDirectionBothStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrDirectionChc =
{
   4,
   0,
   NULLP,
   cmMsgDefSdpAttrDirectionChcElmnt,
   cmMsgDefSdpAttrDirectionChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirection =
{
#ifdef CM_ABNF_DBG
   "SDP AttrDirection",
   "SDPDirection",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 441,
   sizeof(CmSdpAttrDirection),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrDirectionChc,
   cmSdpRegExpDirection
};

#ifdef CM_SDP_V_3
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSStrnTagMandEnum =
 {
     (Data *)"mandatory" ,
     CM_SDP_ATTR_QS_STRN_TAG_MAND
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSStrnTagMandEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S STRN TAG MAND ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 766 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSStrnTagMandEnum ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSStrnTagOptEnum =
 {
     (Data *)"optional" ,
     CM_SDP_ATTR_QS_STRN_TAG_OPT
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSStrnTagOptEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S STRN TAG OPT ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 767 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSStrnTagOptEnum ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSStrnTagSuccEnum =
 {
     (Data *)"success" ,
     CM_SDP_ATTR_QS_STRN_TAG_SUCC
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSStrnTagSuccEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S STRN TAG SUCC ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 768 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSStrnTagSuccEnum ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSStrnTagFailEnum =
 {
     (Data *)"failure" ,
     CM_SDP_ATTR_QS_STRN_TAG_FAIL
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSStrnTagFailEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S STRN TAG FAIL ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 769 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSStrnTagFailEnum ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrQSStrnTagChcEnum[] =
 {
 &cmMsgDefSdpAttrQSStrnTagMandEnumDef ,
 &cmMsgDefSdpAttrQSStrnTagOptEnumDef ,
 &cmMsgDefSdpAttrQSStrnTagSuccEnumDef ,
 &cmMsgDefSdpAttrQSStrnTagFailEnumDef ,
 
 };
 
 PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrQSStrnTagChc =
 {
     4 ,
     0 ,
     NULLP ,
     NULLP ,
     cmMsgDefSdpAttrQSStrnTagChcEnum
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSStrnTag =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR Q S STRN TAG " ,
     "SdpAttrQSStrn" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 770 ,
     sizeof(TknU8) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &cmMsgDefSdpAttrQSStrnTagChc ,
     cmSdpRegExpAttrQSStrn
 };
 
 
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSDirSendEnum =
 {
     (Data *)"send" ,
     CM_SDP_ATTR_QS_DIR_TAG_SEND
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSDirSendEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S DIR SEND ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 771 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSDirSendEnum ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSDirRecvEnum =
 {
     (Data *)"recv" ,
     CM_SDP_ATTR_QS_DIR_TAG_RECV
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSDirRecvEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S DIR RECV ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 772 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSDirRecvEnum ,
     NULLP
 };
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrQSDirSendRecvEnum =
 {
     (Data *)"sendrecv" ,
     CM_SDP_ATTR_QS_DIR_TAG_SEND_RECV
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSDirSendRecvEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR Q S DIR SEND RECV ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 773 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrQSDirSendRecvEnum ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  *cmMsfDefSdpAttrQSDirTagChcEnum[] =
 {
 &cmMsgDefSdpAttrQSDirSendEnumDef ,
 &cmMsgDefSdpAttrQSDirRecvEnumDef ,
 &cmMsgDefSdpAttrQSDirSendRecvEnumDef ,
 
 };
 
 PUBLIC CmAbnfElmTypeChoice  cmMsfDefSdpAttrQSDirTagChc =
 {
     3 ,
     0 ,
     NULLP ,
     NULLP ,
     cmMsfDefSdpAttrQSDirTagChcEnum
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSDirTag =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR Q S DIR TAG " ,
     "SdpAttrQSDir" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 774 ,
     sizeof(TknU8) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &cmMsfDefSdpAttrQSDirTagChc ,
     cmSdpRegExpAttrQSDir
 };
 

 PUBLIC CmAbnfElmTypeMeta  cmMsgDefSdpAttrQSCnfmTagMetaMeta =  {  (Data *) "confirm"  };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSCnfmTagMeta =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR Q S CNFM TAG META " ,
     "SdpAttrCnfm" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 775 ,
     0 ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_META ,
     (U8 *) &cmMsgDefSdpAttrQSCnfmTagMetaMeta ,
     cmSdpRegExpSdpAttrCnfm
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrQSCnfmTagOptSeqElmnts[] =
 {
     &cmMsgDefMetaSpace ,
     &cmMsgDefSdpAttrQSCnfmTagMeta ,
     &cmMsgDefMetaSpace ,
     &cmMsgDefSdpAttrQSDirTag ,
 };
 
 PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrQSCnfmTagOptSeq =
 {
     4 ,
     cmMsgDefSdpAttrQSCnfmTagOptSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQSCnfmTagOpt =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR Q S CNFM TAG OPT " ,
     "cmAbnfRegExpSpace" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 776 ,
     sizeof(CmSdpCnfmTg) ,
     ( CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_OPTSEQ ,
     (U8 *) &cmMsgDefSdpAttrQSCnfmTagOptSeq ,
     cmAbnfRegExpSpace
 };
 
 
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrQosOrSecureSeqElmnts[] =
 {
     &cmMsgDefSdpAttrQSStrnTag ,
     &cmMsgDefMetaSpace ,
     &cmMsgDefSdpAttrQSDirTag ,
     &cmMsgDefSdpAttrQSCnfmTagOpt
 };
 
 PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrQosOrSecureSeq =
 {
     4 ,
     cmMsgDefSdpAttrQosOrSecureSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrQosOrSecure =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR QOS OR SECURE " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 777 ,
     sizeof(CmSdpAttrQosSec) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_SEQ ,
     (U8 *) &cmMsgDefSdpAttrQosOrSecureSeq ,
     NULLP
 };
 


#endif


#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrCacheSeqElmnt[] =
{
   &cmMsgDefSdpOnOffOrNull,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpGenU32OrNull
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrCacheSeq =
{
   3,
   cmMsgDefSdpAttrCacheSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCache =
{
#ifdef CM_ABNF_DBG
   "SDP AttrCache",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 442,
   sizeof(CmSdpAttrCache),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrCacheSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpChainNullEnum =
{
   (Data *)"NULL",
   CM_SDP_CHAIN_NULL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpChainNullStr =
{
#ifdef CM_ABNF_DBG
   "SDP ChainNull",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 443,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpChainNullEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpChainPrevEnum =
{
   (Data *)"previous",
   CM_SDP_CHAIN_PREV
};

PUBLIC CmAbnfElmDef cmMsgDefSdpChainPrevStr =
{
#ifdef CM_ABNF_DBG
   "SDP ChainPrev",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 444,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpChainPrevEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpChainNextEnum =
{
   (Data *)"next",
   CM_SDP_CHAIN_NEXT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpChainNextStr =
{
#ifdef CM_ABNF_DBG
   "SDP ChainNext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 445,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpChainNextEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrChainChcEnum[] =
{
   &cmMsgDefSdpChainNullStr,
   &cmMsgDefSdpChainPrevStr,
   &cmMsgDefSdpChainNextStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrChainChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrChainChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrChain =
{
#ifdef CM_ABNF_DBG
   "SDP AttrChain",
   "SDPChain",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 446,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrChainChc,
   cmSdpRegExpChain
};


PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrAal23661AssrdSeqElmnts[] =
{
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrAal23661AssrdSeq =
{
    13 ,
    cmMsgDefSdpAttrAal23661AssrdSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrAal23661Assrd =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR AAL23661 ASSRD " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1003 ,
    sizeof(CmSdpAttrAal23661Ass) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrAal23661AssrdSeq ,
    NULLP
};


PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrCodecCfgRange =  {   4 , 32  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCodecCfg =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR CODEC CFG " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &cmMsgDefSdpAttrCodecCfgRange ,
    cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrIsupUsiRange =  {   4 , 24  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrIsupUsi =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR ISUP USI " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1004 ,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &cmMsgDefSdpAttrIsupUsiRange ,
    cmAbnfRegExpXDgt
};

#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefSdpAttrCbrRateRange =  {   2 , 2 , 0 , (U32)255  };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrCbrRateRange =  {   2 , 2  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCbrRate =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR CBR RATE " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1005 ,
    sizeof (TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_HEXUINT8 ,
    (U8 *) &cmMsgDefSdpAttrCbrRateRange ,
    cmAbnfRegExpXDgt
};


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrSrvTypVoiceEnum =
{
    (Data *)"v" ,
   CM_SDP_ATTR_SRV_TYP_VOICE
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvTypVoiceEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYP VOICE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrSrvTypVoiceEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrSrvTypVoiceBndDatEnum =
{
    (Data *)"d" ,
   CM_SDP_ATTR_SRV_TYP_VOICE_BND_DAT
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvTypVoiceBndDatEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYP VOICE BND DAT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1004 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrSrvTypVoiceBndDatEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrSrvTypFaxEnum =
{
    (Data *)"f" ,
   CM_SDP_ATTR_SRV_TYP_FAX
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvTypFaxEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYP FAX ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1005 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrSrvTypFaxEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrSrvTypVoiceBndDatFaxEnum =
{
    (Data *)"df" ,
   CM_SDP_ATTR_SRV_TYP_VOICE_BND_DAT_FAX
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvTypVoiceBndDatFaxEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYP VOICE BND DAT FAX ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1006 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrSrvTypVoiceBndDatFaxEnum ,
    NULLP
};


PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrSrvTypAllEnum =
{
    (Data *)"all" ,
   CM_SDP_ATTR_SRV_TYP_ALL
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvTypAllEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYP ALL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1007 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrSrvTypAllEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrSrvTypeChcEnum[] =
{
&cmMsgDefSdpAttrSrvTypVoiceEnumDef ,
&cmMsgDefSdpAttrSrvTypVoiceBndDatEnumDef ,
&cmMsgDefSdpAttrSrvTypFaxEnumDef ,
&cmMsgDefSdpAttrSrvTypVoiceBndDatFaxEnumDef ,
&cmMsgDefSdpAttrSrvTypAllEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrSrvTypeChc =
{
    5 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrSrvTypeChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSrvType =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR SRV TYPE " ,
    "cmSdpRegExpAttrSrvType" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1008 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrSrvTypeChc ,
    cmSdpRegExpAttrSrvType
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrOneWaySelSeqElmnts[] =
{
    &cmMsgDefSdpAttrSrvType ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpAttrDirFlg ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpAttrDevSelCompSet
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrOneWaySelSeq =
{
    5 ,
    cmMsgDefSdpAttrOneWaySelSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrOneWaySel =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR ONE WAY SEL " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1009 ,
    sizeof(CmSdpAttrOneWaySel) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrOneWaySelSeq ,
    NULLP
};


PUBLIC CmAbnfElmTypeRange  cmMsgDefAtmBrrSigIeTypeRange =  {   2 , 0xffff  };

PUBLIC CmAbnfElmDef  cmMsgDefAtmBrrSigIeType =
{
#ifdef  CM_ABNF_DBG
    "MGCP: ATM BRR SIG IE TYPE " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &cmMsgDefAtmBrrSigIeTypeRange ,
    cmAbnfRegExpXDgt
};

#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefAtmBrrSigIeLngRange =  {   1 , 5 , 0 , (U32)65535 };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefAtmBrrSigIeLngRange =  {   1 , 5  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefAtmBrrSigIeLng =
{
#ifdef  CM_ABNF_DBG
    "MGCP: ATM BRR SIG IE LNG " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1004 ,
    sizeof (TknU16) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_HEXUINT16 ,
    (U8 *) &cmMsgDefAtmBrrSigIeLngRange ,
    cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmTypeRange  cmMsgDefAtmBrrSigIeValRange =  {   2 , 512  };

PUBLIC CmAbnfElmDef  cmMsgDefAtmBrrSigIeVal =
{
#ifdef  CM_ABNF_DBG
    "MGCP: ATM BRR SIG IE VAL " ,
    "cmAbnfRegExpXDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1005 ,
    sizeof (TknStrOSXL) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OCTSTRXL ,
    (U8 *) &cmMsgDefAtmBrrSigIeValRange ,
    cmAbnfRegExpXDgt
};

PUBLIC CmAbnfElmDef  *cmMsgDefAtmBrrSigIeSeqElmnts[] =
{
    &cmMsgDefAtmBrrSigIeType ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefAtmBrrSigIeLng ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefAtmBrrSigIeVal
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefAtmBrrSigIeSeq =
{
    5 ,
    cmMsgDefAtmBrrSigIeSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefAtmBrrSigIe =
{
#ifdef  CM_ABNF_DBG
    "MGCP: ATM BRR SIG IE " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1006 ,
    sizeof(CmSdpAttrAtmBrrSigIe) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefAtmBrrSigIeSeq ,
    NULLP
};


PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrAal5SscopSeqElmnts[] =
{
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16OrNull
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrAal5SscopSeq =
{
    7 ,
    cmMsgDefSdpAttrAal5SscopSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrAal5Sscop =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR AAL5 SSCOP " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1003 ,
    sizeof(CmSdpAttrAal5Sscop) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrAal5SscopSeq ,
    NULLP
};


PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrAal2CpsSduRateSeqElmnts[] =
{
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrAal2CpsSduRateSeq =
{
    3 ,
    cmMsgDefSdpAttrAal2CpsSduRateSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrAal2CpsSduRate =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR AAL2 CPS SDU RATE " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1003 ,
    sizeof(CmSdpAttrAal2CpsSduRate) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrAal2CpsSduRateSeq ,
    NULLP
};


#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefSdpUpto2DigsRange =  {   1 , 2 , 0 , (U32)99  };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpUpto2DigsRange =  {   1 , 2  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefSdpUpto2Digs =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP UPTO2 DIGS " ,
    "cmAbnfRegExpDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_UINT8 ,
    (U8 *) &cmMsgDefSdpUpto2DigsRange ,
    cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrAtmAbrSetupSeqElmnts[] =
{
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU32OrNull ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpUpto2Digs ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpUpto2Digs ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpUpto2Digs ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpUpto2Digs
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrAtmAbrSetupSeq =
{
    17 ,
    cmMsgDefSdpAttrAtmAbrSetupSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrAtmAbrSetup =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR ATM ABR SETUP " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1004 ,
    sizeof(CmSdpAttrAtmAbrSetup) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrAtmAbrSetupSeq ,
    NULLP
};



#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhCxtIdLocalEnum =
{
   (Data *)NULLP,
   CM_SDP_PHONE_CONTEXT_LOCAL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdLocalStr =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdLocal",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 447,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhCxtIdLocalEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhCxtIdInternationalEnum =
{
   (Data *)NULLP,
   CM_SDP_PHONE_CONTEXT_INTL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdInternationalStr =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdInternational",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 448,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhCxtIdInternationalEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPhCxtIdPrivateEnum =
{
   (Data *)NULLP,
   CM_SDP_PHONE_CONTEXT_PRIVATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPrivateStr =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPrivate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 449,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPhCxtIdPrivateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPhCxtIdPublicValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPublicVal =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPublicVal",
   "SDPPhCxtIdPublicVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 450,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpPhCxtIdPublicValRng,
   cmSdpRegExpPhCxtIdPublicVal
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdSkipUri =
{
#ifdef CM_ABNF_DBG
   "SDP Skip URI part in PhCxtId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 451,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhCxtIdPublicSeqElmnt[] =
{
   &cmMsgDefSdpPhCxtIdPublicVal,
   &cmMsgDefSdpPhCxtIdSkipUri
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPhCxtIdPublicSeq =
{
   2,
   cmMsgDefSdpPhCxtIdPublicSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPublic =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPublic",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 452,
   sizeof(CmSdpAttrPhCxtId) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpPhCxtIdPublicSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPhCxtIdPrivateValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPrivateVal =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPrivateVal",
   "SDPPhCxtIdPrivateVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 453,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpPhCxtIdPrivateValRng,
   cmSdpRegExpPhCxtIdPrivateVal
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhCxtIdPrivateOptUriSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpUriVal 
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPhCxtIdPrivateOptUriSeq =
{
   2,
   cmMsgDefSdpPhCxtIdPrivateOptUriSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPrivateOptUri =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPrivateOptUri",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 454,
   sizeof(TknStrOSXL),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpPhCxtIdPrivateOptUriSeq,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhCxtIdPrivateSeqElmnt[] =
{
   &cmMsgDefSdpPhCxtIdPrivateVal,
   &cmMsgDefSdpPhCxtIdPrivateOptUri
};


PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPhCxtIdPrivateSeq =
{
   2,
   cmMsgDefSdpPhCxtIdPrivateSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhCxtIdPrivate =
{
#ifdef CM_ABNF_DBG
   "SDP PhCxtIdPrivate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 455,
   sizeof(CmSdpAttrPhCxtId) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpPhCxtIdPrivateSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrPhoneContextIdentChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpPhCxtIdLocalStr,
   &cmMsgDefSdpPhCxtIdInternationalStr,
   &cmMsgDefSdpPhCxtIdPrivateStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrPhoneContextIdentChcElmnt[] =
{
   &cmMsgDefSdpPhCxtIdPublic,
   &cmMsgDefSdpPhCxtIdPrivate
};

PUBLIC U8 cmMsgDefSdpAttrPhoneContextIdentChcIdx[] = {0, 0, 0, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrPhoneContextIdentChc =
{
   2,
   4,
   cmMsgDefSdpAttrPhoneContextIdentChcIdx,
   cmMsgDefSdpAttrPhoneContextIdentChcElmnt,
   cmMsgDefSdpAttrPhoneContextIdentChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrPhoneContextIdent =
{
#ifdef CM_ABNF_DBG
   "SDP PhoneContextIdent",
   "SDPPhoneContextIdent",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 456,
   sizeof(CmSdpAttrPhCxtId),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrPhoneContextIdentChc,
   cmSdpRegExpPhoneContextIdent
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrClirChcEnum[] =
{
   &cmMsgDefSdpFalse,
   &cmMsgDefSdpTrue
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrClirChc =
{
   2,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrClirChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClir =
{
#ifdef CM_ABNF_DBG
   "SDP AttrClir",
   "SDPFalseTrue",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 457,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrClirChc,
   cmSdpRegExpFalseTrue
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpZeroEnum =
{
   (Data *)"0",
   CM_SDP_ZERO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZero =
{
#ifdef CM_ABNF_DBG
   "SDP Zero",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 458,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpZeroEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpOneEnum =
{
   (Data *)"1",
   CM_SDP_ONE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOne =
{
#ifdef CM_ABNF_DBG
   "SDP One",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 459,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpOneEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrInnChcEnum[] =
{
   &cmMsgDefSdpZero,
   &cmMsgDefSdpOne
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrInnChc =
{
   2,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrInnChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrInn =
{
#ifdef CM_ABNF_DBG
   "SDP AttrInn",
   "SDPZeroOne",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 460,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrInnChc,
   cmSdpRegExpZeroOne
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttFieldArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttField 
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttFieldArraySeqOf =
{
   0,
   CM_SDP_MAX_REQUIRE_ATTRS,
   2,
   cmMsgDefSdpAttFieldArraySeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttFieldArray =
{
#ifdef CM_ABNF_DBG
   "SDP AttFieldArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 461,
   sizeof(CmSdpAttrRequire),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttFieldArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrRequireSeqElmnt[] =
{
   &cmMsgDefSdpAttField,
   &cmMsgDefSdpAttFieldArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrRequireSeq =
{
   2,
   cmMsgDefSdpAttrRequireSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRequire =
{
#ifdef CM_ABNF_DBG
   "SDP AttrRequire",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 462,
   sizeof(CmSdpAttrRequire),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpAttrRequireSeq,
   NULLP
};

/************************************************************************
                              SDP Attribute Enums
*************************************************************************/

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrGenericEnum =
{
   (Data *)NULLP,
   CM_SDP_ATTR_GENERIC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrGenericStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Generic",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 463,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrGenericEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCatEnum =
{
   (Data *)"cat:",
   CM_SDP_ATTR_CAT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCatStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Cat",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 464,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCatEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrKeywdsEnum =
{
   (Data *)"keywds:",
   CM_SDP_ATTR_KEYWDS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrKeywdsStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Keywds",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 465,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrKeywdsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrToolEnum =
{
   (Data *)"tool:",
   CM_SDP_ATTR_TOOL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrToolStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Tool",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 466,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrToolEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrPtimeEnum =
{
   (Data *)"ptime:",
   CM_SDP_ATTR_PTIME
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrPtimeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Ptime",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 467,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrPtimeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrRecvOnlyEnum =
{
   (Data *)"recvonly",
   CM_SDP_ATTR_RECVONLY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRecvOnlyStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute RecvOnly",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 468,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrRecvOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSendRecvEnum =
{
   (Data *)"sendrecv",
   CM_SDP_ATTR_SENDRECV
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSendRecvStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute SendRecv",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 469,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSendRecvEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSendOnlyEnum =
{
   (Data *)"sendonly",
   CM_SDP_ATTR_SENDONLY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSendOnlyStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute SendOnly",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 470,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSendOnlyEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrOrientEnum =
{
   (Data *)"orient:",
   CM_SDP_ATTR_ORIENT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrOrientStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Orient",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 471,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrOrientEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrTypeEnum =
{
   (Data *)"type:",
   CM_SDP_ATTR_TYPE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrTypeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Type",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 472,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrTypeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCharSetEnum =
{
   (Data *)"charset:",
   CM_SDP_ATTR_CHARSET
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCharSetStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute CharSet",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 473,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCharSetEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSdpLangEnum =
{
   (Data *)"sdplang:",
   CM_SDP_ATTR_SDPLANG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSdpLangStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute SdpLang",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 474,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSdpLangEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrLangEnum =
{
   (Data *)"lang:",
   CM_SDP_ATTR_LANG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrLangStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Lang",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 475,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrLangEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFrameRateEnum =
{
   (Data *)"framerate:",
   CM_SDP_ATTR_FRAMERATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFrameRateStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute FrameRate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 476,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFrameRateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQualityEnum =
{
   (Data *)"quality:",
   CM_SDP_ATTR_QUALITY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQualityStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Quality",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 477,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQualityEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFmtpEnum =
{
   (Data *)"fmtp:",
   CM_SDP_ATTR_FMTP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFmtpStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Fmtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 478,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFmtpEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrRtpMapEnum =
{
   (Data *)"rtpmap:",
   CM_SDP_ATTR_RTPMAP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRtpMapStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute RtpMap",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 479,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrRtpMapEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrInactiveEnum =
{
   (Data *)"inactive",
   CM_SDP_ATTR_INACTIVE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrInactiveStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Inactive",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 480,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrInactiveEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrControlEnum =
{
   (Data *)"control:",
   CM_SDP_ATTR_CONTROL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrControlStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Control",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 481,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrControlEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrRangeEnum =
{
   (Data *)"range:",
   CM_SDP_ATTR_RANGE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRangeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Range",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 482,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrRangeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrEtagEnum =
{
   (Data *)"etag:",
   CM_SDP_ATTR_ETAG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEtagStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Etag",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 483,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrEtagEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmMapEnum =
{
   (Data *)"atmmap:",
   CM_SDP_ATTR_ATMMAP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmMapStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmMap",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 484,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmMapEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrEecIdEnum =
{
   (Data *)"eecid:",
   CM_SDP_ATTR_EECID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEecIdStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute EecId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 485,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrEecIdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAalTypeEnum =
{
   (Data *)"aalType:",
   CM_SDP_ATTR_AALTYPE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAalTypeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AalType",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 486,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAalTypeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSilenceSuppEnum =
{
   (Data *)"silenceSupp:",
   CM_SDP_ATTR_SILENCESUPP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSilenceSuppStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute SilenceSupp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 487,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSilenceSuppEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrEcanfEnum =
{
   (Data *)"ecan:",
   CM_SDP_ATTR_ECAN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEcanfStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Ecanf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 488,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrEcanfEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrGcfEnum =
{
   (Data *)"gc:",
   CM_SDP_ATTR_GC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrGcfStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Gcf",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 490,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrGcfEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrProfileDescEnum =
{
   (Data *)"profiledesc:",
   CM_SDP_ATTR_PROFILEDESC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrProfileDescStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute ProfileDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 492,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrProfileDescEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrVselEnum =
{
   (Data *)"vsel:",
   CM_SDP_ATTR_VSEL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrVselStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Vsel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 493,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrVselEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrDselEnum =
{
   (Data *)"dsel:",
   CM_SDP_ATTR_DSEL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDselStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Dsel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 494,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrDselEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFselEnum =
{
   (Data *)"fsel:",
   CM_SDP_ATTR_FSEL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFselStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Fsel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 495,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFselEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCapabilityEnum =
{
   (Data *)"capability:",
   CM_SDP_ATTR_CAPABILITY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCapabilityStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Capability",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 496,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCapabilityEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQosClassEnum =
{
   (Data *)"qosclass:",
   CM_SDP_ATTR_QOSCLASS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQosClassStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute QosClass",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 497,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQosClassEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrBcobEnum =
{
   (Data *)"bcob:",
   CM_SDP_ATTR_BCOB
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrBcobStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Bcob",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 498,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrBcobEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrStcEnum =
{
   (Data *)"stc:",
   CM_SDP_ATTR_STC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrStcStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Stc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 499,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrStcEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrUpccEnum =
{
   (Data *)"upcc:",
   CM_SDP_ATTR_UPCC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrUpccStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Upcc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 500,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrUpccEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmQOSfparmsEnum =
{
   (Data *)"atmQOSparms:",
   CM_SDP_ATTR_ATMQOSPARMS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmQOSfparmsStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmQOSfparms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 501,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmQOSfparmsEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2QOSfparmsEnum =
{
   (Data *)"aal2QOSfparms:",
   CM_SDP_ATTR_AAL2QOSFPARMS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2QOSfparmsStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2QOSfparms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 503,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2QOSfparmsEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2QOSbparmsEnum =
{
   (Data *)"aal2QOSbparms:",
   CM_SDP_ATTR_AAL2QOSBPARMS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2QOSbparmsStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2QOSbparms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 504,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2QOSbparmsEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmFtrfcDescEnum =
{
   (Data *)"atmtrfcDesc:",
   CM_SDP_ATTR_ATMTRFCDESC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmFtrfcDescStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmFtrfcDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 505,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmFtrfcDescEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2FtrfcDescEnum =
{
   (Data *)"aal2FtrfcDesc:",
   CM_SDP_ATTR_AAL2FTRFCDESC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2FtrfcDescStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2FtrfcDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 507,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2FtrfcDescEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2BtrfcDescEnum =
{
   (Data *)"aal2BtrfcDesc:",
   CM_SDP_ATTR_AAL2BTRFCDESC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2BtrfcDescStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2BtrfcDesc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 508,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2BtrfcDescEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAbrFparmsEnum =
{
   (Data *)"abrparms:",
   CM_SDP_ATTR_ABRPARMS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAbrFparmsStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AbrFparms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 509,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAbrFparmsEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrClkRecEnum =
{
   (Data *)"clkrec:",
   CM_SDP_ATTR_CLKREC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClkRecStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute ClkRec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 511,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrClkRecEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFecEnum =
{
   (Data *)"fec:",
   CM_SDP_ATTR_FEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFecStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Fec",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 512,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFecEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrPrtflEnum =
{
   (Data *)"prtfl:",
   CM_SDP_ATTR_PRTFL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrPrtflStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Prtfl",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 513,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrPrtflEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrBearerTypeEnum =
{
   (Data *)"bearertype:",
   CM_SDP_ATTR_BEARERTYPE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrBearerTypeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute BearerType",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 514,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrBearerTypeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrStructureEnum =
{
   (Data *)"structure:",
   CM_SDP_ATTR_STRUCTURE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrStructureStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Structure",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 515,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrStructureEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSbcEnum =
{
   (Data *)"sbc:",
   CM_SDP_ATTR_SBC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSbcStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Sbc",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 516,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSbcEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFcpsSduSizeEnum =
{
   (Data *)"cpssdusize:",
   CM_SDP_ATTR_CPSSDUSIZE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFcpsSduSizeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute FcpsSduSize",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 517,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFcpsSduSizeEnum,
   NULLP
};


PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2CPSEnum =
{
   (Data *)"aal2CPS:",
   CM_SDP_ATTR_AAL2CPS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2CPSStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2CPS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 519,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2CPSEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2Sscs3661Enum =
{
   (Data *)"aal2sscs3661unassured:",
   CM_SDP_ATTR_AAL2SSCS3661_UNASS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2Sscs3661Str =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2Sscs3661 Unassured",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 520,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2Sscs3661Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2Sscs3662Enum =
{
   (Data *)"aal2sscs3662:",
   CM_SDP_ATTR_AAL2SSCS3662
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2Sscs3662Str =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2Sscs3662",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 521,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2Sscs3662Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2Sscs3652Enum =
{
   (Data *)"aal2sscs3652",
   CM_SDP_ATTR_AAL2SSCS3652
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2Sscs3652Str =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2Sscs3652",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 522,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2Sscs3652Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal2Sscs3653Enum =
{
   (Data *)"aal2sscs3653",
   CM_SDP_ATTR_AAL2SSCS3653
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal2Sscs3653Str =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal2Sscs3653",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 523,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal2Sscs3653Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAal5AppEnum =
{
   (Data *)"aalApp:",
   CM_SDP_ATTR_AAL5APP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAal5AppStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Aal5App",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 524,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAal5AppEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrLijEnum =
{
   (Data *)"lij:",
   CM_SDP_ATTR_LIJ
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrLijStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Lij",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 525,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrLijEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAnycastEnum =
{
   (Data *)"anycast:",
   CM_SDP_ATTR_ANYCAST
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAnycastStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Anycast",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 526,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAnycastEnum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

#ifdef CM_SDP_V_3

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrT38FaxEnum =
{
   (Data *)"T38" ,
   CM_SDP_ATTR_T38_FAX
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrT38FaxStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute T38 FAX",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 778 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrT38FaxEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCparMaxEnum =
{
   (Data *)"cparMax:",
   CM_SDP_ATTR_CPAR_MAX
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCparMaxStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute CPAR MAX",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 778 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCparMaxEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCparMinEnum =
{
   (Data *)"cparMin:",
   CM_SDP_ATTR_CPAR_MIN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCparMinStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute CPAR MIN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 779 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCparMinEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCparEnum =
{
   (Data *)"cpar:",
   CM_SDP_ATTR_CPAR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCparStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute CPAR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 780 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCparEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCdscEnum =
{
   (Data *)"cdsc:",
   CM_SDP_ATTR_CDSC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCdscStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute CDSC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 781 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCdscEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSqnEnum =
{
   (Data *)"sqn:",
   CM_SDP_ATTR_SQN_NUM
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSqnStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute SQN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 782 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSqnEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrGroupEnum =
{
   (Data *)"group:",
   CM_SDP_ATTR_GROUP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrGroupStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute GROUP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 783 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrGroupEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrMidEnum =
{
   (Data *)"mid:",
   CM_SDP_ATTR_MID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrMidStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute MID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 784 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrMidEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrFidEnum =
{
   (Data *)"fid:",
   CM_SDP_ATTR_FID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrFidStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute FID",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 785 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrFidEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQosEnum =
{
   (Data *)"qos:",
   CM_SDP_ATTR_QOS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQosStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute QoS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 786 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQosEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrSecureEnum =
{
   (Data *)"secure:",
   CM_SDP_ATTR_SECURE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSecureStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute QoS",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 787 ,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrSecureEnum,
   NULLP
};
#endif

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrDirectionEnum =
{
   (Data *)"direction:",
   CM_SDP_ATTR_DIRECTION
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrDirectionStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Direction",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 527,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrDirectionEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrWtpEnum =
{
   (Data *)"wtp:",
   CM_SDP_ATTR_WTP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrWtpStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Wtp",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 528,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrWtpEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrCacheEnum =
{
   (Data *)"cache:",
   CM_SDP_ATTR_CACHE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrCacheStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Cache",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 529,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrCacheEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrChainEnum =
{
   (Data *)"chain:",
   CM_SDP_ATTR_CHAIN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrChainStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Chain",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrChainEnum,
   NULLP
};

/* The new ATM enum defs */
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmAbrSetupEnum =
{
   (Data *)"abrSetup:",
   CM_SDP_ATTR_ABR_SETUP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmAbrSetupStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmAbrSetup",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmAbrSetupEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmAal2CpsSduRateEnum =
{
   (Data *)"aal2CPSSDUrate:",
   CM_SDP_ATTR_AAL2_CPSSDURATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmAal2CpsSduRateStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmAal2CpsSduRate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmAal2CpsSduRateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmAal5SscopEnum =
{
   (Data *)"aal5sscop:",
   CM_SDP_ATTR_AAL5_SSCOP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmAal5SscopStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmAal5Sscop",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmAal5SscopEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmBrrSigIeEnum =
{
   (Data *)"bearerSigIE:",
   CM_SDP_ATTR_BRR_SIGIE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmBrrSigIeStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmBrrSigIe",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmBrrSigIeEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmOneWaySelEnum =
{
   (Data *)"onewaySel:",
   CM_SDP_ATTR_ONE_WAY_SEL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmOneWaySelStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmOneWaySel",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmOneWaySelEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmCodecCfgEnum =
{
   (Data *)"codecconfig:",
   CM_SDP_ATTR_CODEC_CFG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmCodecCfgStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmCodecCfg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmCodecCfgEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmIsupUsiEnum =
{
   (Data *)"isup_usi:",
   CM_SDP_ATTR_ISUP_USI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmIsupUsiStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmIsupUsi",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmIsupUsiEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmUiLyr1ProtEnum =
{
   (Data *)"uiLayer1_Prot:",
   CM_SDP_ATTR_UILYR1_PROT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmUiLyr1ProtStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmUiLyr1Prot",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmUiLyr1ProtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmCbrRateEnum =
{
   (Data *)"cbrRate:",
   CM_SDP_ATTR_CBR_RATE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmCbrRateStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmCbrRate",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmCbrRateEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrAtmAal2sscs3611AssEnum =
{
   (Data *)"aal2sscs3661assured:",
   CM_SDP_ATTR_AAL2SSCS3661_ASS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtmAal2sscs3611AssStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute AtmAal2sscs3611Ass",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 530,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrAtmAal2sscs3611AssEnum,
   NULLP
};


#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrPhoneContextEnum =
{
   (Data *)"phone-context:",
   CM_SDP_ATTR_PHONECONTEXT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrPhoneContextStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute PhoneContext",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 531,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrPhoneContextEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrClirEnum =
{
   (Data *)"clir:",
   CM_SDP_ATTR_CLIR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrClirStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Clir",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 532,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrClirEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQ763NatureEnum =
{
   (Data *)"Q763-nature:",
   CM_SDP_ATTR_Q763NATURE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQ763NatureStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Q763Nature",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 533,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQ763NatureEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQ763PlanEnum =
{
   (Data *)"Q763-plan:",
   CM_SDP_ATTR_Q763PLAN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQ763PlanStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Q763Plan",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 534,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQ763PlanEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrQ763INNEnum =
{
   (Data *)"Q763-INN:",
   CM_SDP_ATTR_Q763INN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrQ763INNStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Q763INN",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 535,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrQ763INNEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrRequireEnum =
{
   (Data *)"require:",
   CM_SDP_ATTR_REQUIRE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrRequireStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute Require",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 536,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrRequireEnum,
   NULLP
};

#ifdef CM_SDP_V_3

 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrIdenTagSetSeqOfElmnts[] =
 {
     &cmMsgDefMetaSpace ,
     &cmMsgDefSdpTnExtnFormat
 };
 
 PUBLIC CmAbnfElmTypeSeqOf  cmMsgDefSdpAttrIdenTagSetSeqOf =
 {
     2 ,
     0xffff ,
     2 ,
     cmMsgDefSdpAttrIdenTagSetSeqOfElmnts ,
     sizeof (TknStrOSXL)
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrIdenTagSet =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR IDEN TAG SET " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 788 ,
     sizeof(CmSdpAttrIdSet) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_SEQOF ,
     (U8 *) &cmMsgDefSdpAttrIdenTagSetSeqOf ,
     cmAbnfRegExpSpace
 };
 
 
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrGroupSemnLsEnum =
 {
     (Data *)"LS" ,
     CM_SDP_ATTR_GROUP_SEMN_LS
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrGroupSemnLsEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR GROUP SEMN LS ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 789 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrGroupSemnLsEnum ,
     NULLP
 };
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrGroupSemnFidEnum =
 {
     (Data *)"FID" ,
     CM_SDP_ATTR_GROUP_SEMN_FID
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrGroupSemnFidEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR GROUP SEMN FID ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 790 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrGroupSemnFidEnum ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrGroupSemanticsChoiceChcEnum[] =
 {
 &cmMsgDefSdpAttrGroupSemnLsEnumDef ,
 &cmMsgDefSdpAttrGroupSemnFidEnumDef ,
 
 };
 
 PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrGroupSemanticsChoiceChc =
 {
     2 ,
     0 ,
     NULLP ,
     NULLP ,
     cmMsgDefSdpAttrGroupSemanticsChoiceChcEnum
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrGroupSemanticsChoice =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR GROUP SEMANTICS CHOICE " ,
     "cmSdpRegExpAttrGroupSemantics" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 791 ,
     sizeof(TknU8) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &cmMsgDefSdpAttrGroupSemanticsChoiceChc ,
     cmSdpRegExpAttrGroupSemantics
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrGroupSeqElmnts[] =
 {
     &cmMsgDefSdpAttrGroupSemanticsChoice ,
     &cmMsgDefSdpAttrIdenTagSet
 };
 
 PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrGroupSeq =
 {
     2 ,
     cmMsgDefSdpAttrGroupSeqElmnts
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrGroup =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR GROUP " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 792 ,
     sizeof(CmSdpAttrGroup) ,
     ( CM_ABNF_MANDATORY ) ,
     CM_ABNF_TYPE_SEQ ,
     (U8 *) &cmMsgDefSdpAttrGroupSeq ,
     NULLP
 };


#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefSdpAttrSqnRange =  {   1 , 3 , 0 , (U32)255  };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrSqnRange =  {   1 , 3  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrSqn =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP ATTR SQN " ,
    "cmSdpRegExpDigits" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 793 ,
    sizeof (TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_UINT8 ,
    (U8 *) &cmMsgDefSdpAttrSqnRange ,
   cmSdpRegExpDigits
};

#ifdef  CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange  cmMsgDefSdpAttrCdscCapNumRange =  {   1 , 3 , 1 , (U32)255  };
#else
PUBLIC CmAbnfElmTypeRange  cmMsgDefSdpAttrCdscCapNumRange =  {   1 , 3  };
#endif

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCdscCapNum =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP ATTR CDSC CAP NUM " ,
    "cmSdpRegExpDigits" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 794 ,
    sizeof (TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_UINT8 ,
    (U8 *) &cmMsgDefSdpAttrCdscCapNumRange ,
    cmSdpRegExpDigits
};


EXTERN CmAbnfElmDef cmMsgDefSdpMediaNotConsumed;
/* 001.main_7: removed SdpVcId */
EXTERN CmAbnfElmDef cmMsgDefSdpMediaPar;

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrCdscSeqElmnts[] =
{
    &cmMsgDefSdpAttrCdscCapNum ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpMediaNotConsumed ,     /* forward referencing */
    &cmMsgDefMetaSpace ,
/* 001.main_7: removed SdpVcId */
    &cmMsgDefSdpMediaPar ,             /* forward referencing */
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrCdscSeq =
{
/* 001.main_7: reduced the number to remove SdpVcId */
    5 ,
    cmMsgDefSdpAttrCdscSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCdsc =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP ATTR CDSC " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 795 ,
    sizeof(CmSdpAttrCapDesc) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrCdscSeq ,
    NULLP
};




 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrCparBWEnum =
 {
     NULLP ,
     CM_SDP_ATTR_CPAR_BW
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCparBWEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR CPAR BW ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 796 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrCparBWEnum ,
     NULLP
 };
 
 
 
 PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrCparAttrEnum =
 {
     NULLP ,
     CM_SDP_ATTR_CPAR_ATTR
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCparAttrEnumDef =
 {
 #ifdef CM_ABNF_DBG
     "SDP: SDP ATTR CPAR ATTR ENUM DEF " ,
     "EMPTY" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 797 ,
     sizeof (TknU8) ,
     0 ,
     CM_ABNF_TYPE_ENUM ,
     (U8 *) &cmMsgDefSdpAttrCparAttrEnum ,
     NULLP
 };
 
 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrCparParValChcEnum[] =
 {
 &cmMsgDefSdpAttrCparBWEnumDef ,
 &cmMsgDefSdpAttrCparAttrEnumDef ,
 
 };
 
EXTERN CmAbnfElmDef cmMsgDefSdpAttrStr;
EXTERN CmAbnfElmDef cmMsgDefSdpAttributeNotConsumed;


PUBLIC CmAbnfElmDef *cmMsgDefSdpAttWithoutEOLSeqElmnt[] =
{
   &cmMsgDefSdpAttrStr,
   &cmMsgDefSdpAttributeNotConsumed,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttWithoutEOLSeq =
{
   2,
   cmMsgDefSdpAttWithoutEOLSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrWithoutEOL =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 541,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpAttWithoutEOLSeq,
   NULLP
};

/* cm_sdpdb_c_002.main_14: Modified to allow attribute or BW in the cpar,
 * cparmin, and cparmax with and without space after colon */
PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrAtSetSeqOfElmnt[] =
{
/*   &cmMsgDefMetaSpace ,*/
   &cmMsgDefSdpAttrWithoutEOL
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttrAtSetSeqOf =
{
   1,
   1,
   1, 
   cmMsgDefSdpAttrAtSetSeqOfElmnt,
   sizeof(CmSdpAttr)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrAtSet =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRSET",
   "SDPDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 714,
   sizeof(CmSdpAttrSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttrAtSetSeqOf,
/* cm_sdpdb_c_002.main_14: Modified to allow attribute or BW in the cpar,
 * cparmin, and cparmax with and without space after colon */
   cmSdpRegExpAttrBW
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpBWWithoutEOLSeqElmnt[] =
{
   &cmMsgDefSdpBWStr,
   &cmMsgDefSdpBwTypeModifr,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpBWidth,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpBWWithoutEOLSeq =
{
   4,
   cmMsgDefSdpBWWithoutEOLSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBWWithoutEOL =
{
#ifdef CM_ABNF_DBG
   "SDP: BW",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 672,
   sizeof(CmSdpBw),
   (CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpBWWithoutEOLSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpBWAtSetSeqOfElmnt[] =
{
/* cm_sdpdb_c_002.main_14: Modified to allow attribute or BW in the cpar,
 * cparmin, and cparmax with and without space after colon */
/*   &cmMsgDefMetaSpace ,*/
   &cmMsgDefSdpBWWithoutEOL
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpBWAtSetSeqOf =
{
   1,
   1,
   1,
   cmMsgDefSdpBWAtSetSeqOfElmnt,
   sizeof(CmSdpBw)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBWAtSet =
{
#ifdef CM_ABNF_DBG
   "SDP: BWSET",
   "SDPDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 175,
   sizeof(CmSdpBwSet),
   (CM_ABNF_TKN_NOT_CONSUMED |CM_ABNF_MANDATORY),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpBWAtSetSeqOf,
/* cm_sdpdb_c_002.main_14: Modified to allow attribute or BW in the cpar,
 * cparmin, and cparmax with and without space after colon */
   cmSdpRegExpAttrBW
};

 PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrCparParValChcElmnt[] =
 {
     &cmMsgDefSdpBWAtSet ,
     &cmMsgDefSdpAttrAtSet ,
 };
 
 PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrCparParValChc =
 {
     2 ,
     0 ,
     NULLP ,
     cmMsgDefSdpAttrCparParValChcElmnt ,
     cmMsgDefSdpAttrCparParValChcEnum
 };
 
 PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCparParVal =
 {
 #ifdef  CM_ABNF_DBG
     "SDP: SDP ATTR CAP PAR PAR VAL " ,
     "cmSdpRegExpAttrCparVal" ,
 #endif
     CM_ABNF_ELMNID_SDP_BASE + 798 ,
     sizeof( CmSdpAttrCapParam ) ,
     ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
     CM_ABNF_TYPE_CHOICE ,
     (U8 *) &cmMsgDefSdpAttrCparParValChc ,
     cmSdpRegExpAttrCparVal
 };

/*
   for draft-mule-sip-t38callflows-01.txt
*/




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxRateMngLocTcfEnum =
{
    (Data *)"localTCF" ,
    CM_SDP_ATTR_T38_FAX_RATE_MNG_LOC_TCF
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxRateMngLocTcfEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX RATE MNG LOC TCF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  999 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxRateMngLocTcfEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxRateMngTransfTcfEnum =
{
    (Data *)"transferredTCF" ,
    CM_SDP_ATTR_T38_FAX_RATE_MNG_TRANSF_TCF
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxRateMngTransfTcfEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX RATE MNG TRANSF TCF ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1000 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxRateMngTransfTcfEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrT38FaxRateMngmntChcEnum[] =
{
&cmMsgDefSdpAttrT38FaxRateMngLocTcfEnumDef ,
&cmMsgDefSdpAttrT38FaxRateMngTransfTcfEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrT38FaxRateMngmntChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrT38FaxRateMngmntChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxRateMngmnt =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX RATE MNGMNT " ,
    "cmSdpRegExpT38FaxRateMng" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1001 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrT38FaxRateMngmntChc ,
    cmSdpRegExpT38FaxRateMng
};






PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxUdpECUdpFecEnum =
{
    (Data *)"t38UDPFEC" ,
    CM_SDP_ATTR_T38_FAX_UDP_EC_UDP_FEC
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxUdpECUdpFecEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX UDP E C UDP FEC ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1002 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxUdpECUdpFecEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxUdpECUdpRedEnum =
{
    (Data *)"t38UDPRedundancy" ,
    CM_SDP_ATTR_T38_FAX_UDP_EC_UDP_RED
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxUdpECUdpRedEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX UDP E C UDP RED ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1003 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxUdpECUdpRedEnum ,
    NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrT38FaxUdpECChcEnum[] =
{
&cmMsgDefSdpAttrT38FaxUdpECUdpFecEnumDef ,
&cmMsgDefSdpAttrT38FaxUdpECUdpRedEnumDef ,

};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrT38FaxUdpECChc =
{
    2 ,
    0 ,
    NULLP ,
    NULLP ,
    cmMsgDefSdpAttrT38FaxUdpECChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxUdpEC =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX UDP E C " ,
    "cmSdpRegExpT38FaxUpdEc" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1004 ,
    sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrT38FaxUdpECChc ,
    cmSdpRegExpT38FaxUpdEc
};






PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxVerEnum =
{
    (Data *)"FaxVersion:" ,
    CM_SDP_ATTR_T38_FAX_VER
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxVerEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX VER ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1005 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxVerEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38MaxBitRateEnum =
{
    (Data *)"maxBitRate:" ,
    CM_SDP_ATTR_T38_MAX_BIT_RATE
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38MaxBitRateEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 MAX BIT RATE ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1006 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38MaxBitRateEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxFillBitRmvlEnum =
{
    (Data *)"FaxFillBitRemoval:" ,
    CM_SDP_ATTR_T38_FAX_FILL_BIT_RMVL
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxFillBitRmvlEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX FILL BIT RMVL ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1007 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxFillBitRmvlEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxTrnsMMREnum =
{
    (Data *)"FaxTranscodingMMR:" ,
    CM_SDP_ATTR_T38_FAX_TRNS_MMR
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxTrnsMMREnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX TRNS M M R ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1008 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxTrnsMMREnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxTrnsJBIGEnum =
{
    (Data *)"FaxTranscodingJBIG:" ,
    CM_SDP_ATTR_T38_FAX_TRNS_JBIG
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxTrnsJBIGEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX TRNS J B I G ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1009 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxTrnsJBIGEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxRateMngmntEnum =
{
    (Data *)"FaxRateManagement:" ,
    CM_SDP_ATTR_T38_FAX_RATE_MNGMNT
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxRateMngmntEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX RATE MNGMNT ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1010 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxRateMngmntEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxMaxBfrEnum =
{
    (Data *)"FaxMaxBuffer:" ,
    CM_SDP_ATTR_T38_FAX_MAX_BFR
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxMaxBfrEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX MAX BFR ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1011 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxMaxBfrEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxMaxDatagramEnum =
{
    (Data *)"FaxMaxDatagram:" ,
    CM_SDP_ATTR_T38_FAX_MAX_DATAGRAM
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxMaxDatagramEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX MAX DATAGRAM ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1012 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxMaxDatagramEnum ,
    NULLP
};




PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxUdpECEnum =
{
    (Data *)"FaxUdpEC:" ,
    CM_SDP_ATTR_T38_FAX_UDP_EC
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxUdpECEnumDef =
{
#ifdef CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX UDP E C ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1013 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxUdpECEnum ,
    NULLP
};


/* 001.main_14: t38 modification */
PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxLowRdncyEnum =
{
    (Data *)"LowSpeedRedundancy:" ,
    CM_SDP_ATTR_T38_FAX_LOW_RDNCY
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxLowRdncyEnumDef =
{
#ifdef CM_ABNF_DBG
    " SDP ATTR T38 FAX LOW SPEED REDUNDANCY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1898 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxLowRdncyEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpAttrT38FaxHighRdncyEnum =
{
    (Data *)"HighSpeedRedundancy:" ,
    CM_SDP_ATTR_T38_FAX_HIGH_RDNCY
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38FaxHighRdncyEnumDef =
{
#ifdef CM_ABNF_DBG
    " SDP ATTR T38 FAX HIGH SPEED REDUNDANCY ENUM DEF " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1897 ,
    sizeof (TknU8) ,
    0 ,
    CM_ABNF_TYPE_ENUM ,
    (U8 *) &cmMsgDefSdpAttrT38FaxHighRdncyEnum ,
    NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrT38FaxUnknownEnum =
{
   NULLP,
   CM_SDP_ATTR_T38_FAX_UNKNOWN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrT38FaxUnknownEnumDef =
{
#ifdef CM_ABNF_DBG
   "SDP SDPT38UnknownString",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1899,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrT38FaxUnknownEnum,
   NULLP
};
/* 001.main_14: t38 modification */


PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrT38FaxChcEnum[] =
{
&cmMsgDefSdpAttrT38FaxVerEnumDef ,
&cmMsgDefSdpAttrT38MaxBitRateEnumDef ,
&cmMsgDefSdpAttrT38FaxFillBitRmvlEnumDef ,
&cmMsgDefSdpAttrT38FaxTrnsMMREnumDef ,
&cmMsgDefSdpAttrT38FaxTrnsJBIGEnumDef ,
&cmMsgDefSdpAttrT38FaxRateMngmntEnumDef ,
&cmMsgDefSdpAttrT38FaxMaxBfrEnumDef ,
&cmMsgDefSdpAttrT38FaxMaxDatagramEnumDef ,
&cmMsgDefSdpAttrT38FaxUdpECEnumDef ,
/* 001.main_14: t38 modification */
&cmMsgDefSdpAttrT38FaxHighRdncyEnumDef ,
&cmMsgDefSdpAttrT38FaxLowRdncyEnumDef ,
&cmMsgDefSdpAttrT38FaxUnknownEnumDef

};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38OptDigits =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR FMTP CHN ORD PY LD " ,
    "cmAbnfRegExpDgt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE  +  1017 ,
    sizeof (TknU32) ,
    ( CM_ABNF_OPTIONAL ) ,
    CM_ABNF_TYPE_UINT32 ,
    (U8 *) &cmMsgDefSdpAttrFmtpChnOrdPyLdRange ,
    cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrT38FaxChcElmnt[] =
{
    &cmMsgDefSdpAttrT38FaxRateMngmnt ,
    &cmMsgDefSdpAttrT38FaxUdpEC ,
    &cmMsgDefSdpAttrFmtpChnOrdPyLd ,
    &cmMsgDefSdpAttrT38OptDigits ,
/* 001.main_14: t38 modification */
    &cmMsgDefSdpAttrGeneric
};

PUBLIC U8 cmMsgDefSdpAttrT38FaxChcIdx[] =
{
   2, 2, 2, 2, 2,   0, 3, 3, 1,
   /* 001.main_14: t38 modification */
   3, 3, 4
};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpAttrT38FaxChc =
{
    5,  /* 001.main_14: t38 modification */
    12, /* 001.main_14: t38 modification */
    cmMsgDefSdpAttrT38FaxChcIdx ,
    cmMsgDefSdpAttrT38FaxChcElmnt ,
    cmMsgDefSdpAttrT38FaxChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrT38Fax =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR T38 FAX " ,
    "cmSdpRegExpT38" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1014 ,
    sizeof(CmSdpAttrT38Fax) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_CHOICE ,
    (U8 *) &cmMsgDefSdpAttrT38FaxChc ,
    cmSdpRegExpT38
};


#endif


#ifdef CM_SDP_ATM_SUPPORT

PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrCpsSduSizeSeqElmnts[] =
{
    &cmMsgDefSdpAttrDirFlg ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpGenU16
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrCpsSduSizeSeq =
{
    3 ,
    cmMsgDefSdpAttrCpsSduSizeSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCpsSduSize =
{
#ifdef  CM_ABNF_DBG
    "MGCP: SDP ATTR CPS SDU SIZE " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1003 ,
    sizeof(CmSdpAttrCpsSduSize) ,
    ( CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrCpsSduSizeSeq ,
    NULLP
};

#endif

/*--- IPBCP Support in SDP ---*/
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrIpBcpEnum =
{
   (Data *)"ipbcp:",
   CM_SDP_ATTR_IPBCP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute IPBCP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 738,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrIpBcpEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrIpBcpRequestEnum =
{
   (Data *)"Request",
   CM_SDP_ATTR_IPBCP_REQUEST
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpRequestStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute IPBCP Request",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 739,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrIpBcpRequestEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrIpBcpAcceptedEnum =
{
   (Data *)"Accepted",
   CM_SDP_ATTR_IPBCP_ACCEPTED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpAcceptedStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute IPBCP Accepted",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 740,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrIpBcpAcceptedEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrIpBcpConfusedEnum =
{
   (Data *)"Confused",
   CM_SDP_ATTR_IPBCP_CONFUSED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpConfusedStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute IPBCP Confused",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 741,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrIpBcpConfusedEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrIpBcpRejectedEnum =
{
   (Data *)"Rejected",
   CM_SDP_ATTR_IPBCP_REJECTED
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpRejectedStr =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute IPBCP Rejected",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 742,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrIpBcpRejectedEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrIpBcpTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpAttrIpBcpRequestStr,
   &cmMsgDefSdpAttrIpBcpAcceptedStr,
   &cmMsgDefSdpAttrIpBcpRejectedStr,
   &cmMsgDefSdpAttrIpBcpConfusedStr,
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrIpBcpTypeChc =
{
   5,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAttrIpBcpTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrIpBcpType =
{
#ifdef CM_ABNF_DBG
   "SDP Attr IPBCP Type",
   "SDP IPBCP Type",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 743,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrIpBcpTypeChc,
   cmSdpRegExpIpBcp
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpIpBcpVerRng = {1, 1, 1, 9};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpIpBcpVerRng = {1, 1};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpIpBcpVer =
{
#ifdef CM_ABNF_DBG
   "SDP IPBCP Version",
   "Dgt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 744,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_UINT8,
   (U8 *)&cmMsgDefSdpIpBcpVerRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpIpBcpSeqElmnt[] =
{
   &cmMsgDefSdpIpBcpVer,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAttrIpBcpType
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpIpBcpSeq =
{
   3,
   cmMsgDefSdpIpBcpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpIpBcp =
{
#ifdef CM_ABNF_DBG
   "SDP Attr IPBCP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 845 ,
   sizeof(CmSdpAttrIpBcp),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpIpBcpSeq,
   NULLP
};

/* cm_sdpdb_c_002.main_14: Modified to allow $ (CHOOSE) in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrEecIdChooseEnum =
{
   (Data *)"$",
   CM_SDP_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEecIdChoose =
{
#ifdef CM_ABNF_DBG
   "SDP EECID $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 555,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrEecIdChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAttrEecIdOtherEnum  =
{
   (Data *)NULLP,
   CM_SDP_SPEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEecIdOther  =
{
#ifdef CM_ABNF_DBG
   "SDP EECID - other",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE  + 847,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAttrEecIdOtherEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrEecIdChcEnum[]   =
{
   &cmMsgDefSdpAttrEecIdChoose,
   &cmMsgDefSdpAttrEecIdOther
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrEecIdChcElmnts[]   =
{
   NULLP,                           /* Choose */
   &cmMsgDefSdpHexU32,              /* Other */
};

PUBLIC U8 cmMsgDefSdpAttrEecIdChcIdx[] = {0, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttrEecIdChc =
{
   2,
   2,
   cmMsgDefSdpAttrEecIdChcIdx,
   cmMsgDefSdpAttrEecIdChcElmnts,
   cmMsgDefSdpAttrEecIdChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrEecId  =
{
#ifdef CM_ABNF_DBG
   "SDP EECID",
   "SDP_Type",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE  + 848,
   sizeof(CmSdpAttrEecId),
   CM_ABNF_MANDATORY, /* | CM_ABNF_TKN_NOT_CONSUMED,*/
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttrEecIdChc,
   cmSdpRegExpEecIdType
};
#endif

/************************************************************************
                              SDP Attribute Choice
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttributeChcEnum[] =
{
   &cmMsgDefSdpAttrGenericStr,            /*  0 */
   &cmMsgDefSdpAttrCatStr,                /*  1 */  
   &cmMsgDefSdpAttrKeywdsStr,             /*  1 */
   &cmMsgDefSdpAttrToolStr,               /*  1 */
   &cmMsgDefSdpAttrPtimeStr,              /*  1 */
   &cmMsgDefSdpAttrRecvOnlyStr,           /*  2 */
   &cmMsgDefSdpAttrSendRecvStr,           /*  2 */
   &cmMsgDefSdpAttrSendOnlyStr,           /*  2 */
   &cmMsgDefSdpAttrOrientStr,             /*  3 */
   &cmMsgDefSdpAttrTypeStr,               /*  4 */
   &cmMsgDefSdpAttrCharSetStr,            /*  1 */
   &cmMsgDefSdpAttrSdpLangStr,            /*  1 */
   &cmMsgDefSdpAttrLangStr,               /*  1 */
   &cmMsgDefSdpAttrFrameRateStr,          /*  1 */
   &cmMsgDefSdpAttrQualityStr,            /*  1 */
   &cmMsgDefSdpAttrFmtpStr,               /*  5 */
   &cmMsgDefSdpAttrRtpMapStr,             /*  6 */
   &cmMsgDefSdpAttrInactiveStr,           /*  2 */
   &cmMsgDefSdpAttrControlStr,            /*  7 */
   &cmMsgDefSdpAttrRangeStr,              /*  8 */
   &cmMsgDefSdpAttrEtagStr,               /*  1 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrAtmMapStr,             /*  9 */
   &cmMsgDefSdpAttrEecIdStr,              /* 10 */
   &cmMsgDefSdpAttrAalTypeStr,            /* 11 */
   &cmMsgDefSdpAttrSilenceSuppStr,        /* 12 */
   &cmMsgDefSdpAttrEcanfStr,              /* 13 */
   NULLP,                                 /* 13 */
   &cmMsgDefSdpAttrGcfStr,                /* 14 */
   NULLP,                                 /* 14 */
   &cmMsgDefSdpAttrProfileDescStr,        /* 15 */
   &cmMsgDefSdpAttrVselStr,               /* 16 */
   &cmMsgDefSdpAttrDselStr,               /* 41 */
   &cmMsgDefSdpAttrFselStr,               /* 16 */
   &cmMsgDefSdpAttrCapabilityStr,         /* 17 */ 
   /* cm_sdpdb_c_001.main_2 - Change: Old was cmMsgDefSdpAttrQosClassStr -> 18 */
   &cmMsgDefSdpAttrQosClassStr,           /* 43 */
   &cmMsgDefSdpAttrBcobStr,               /* 24 */
   &cmMsgDefSdpAttrStcStr,                /* 18 */
   &cmMsgDefSdpAttrUpccStr,               /* 18 */
   &cmMsgDefSdpAttrAtmQOSfparmsStr,       /* 19 */
   NULLP,                                 /* 19 */
   &cmMsgDefSdpAttrAal2QOSfparmsStr,      /*  1 */
   &cmMsgDefSdpAttrAal2QOSbparmsStr,      /*  1 */
   &cmMsgDefSdpAttrAtmFtrfcDescStr,       /* 20 */
   NULLP,                                 /* 20 */
   &cmMsgDefSdpAttrAal2FtrfcDescStr,      /*  1 */
   &cmMsgDefSdpAttrAal2BtrfcDescStr,      /*  1 */
   &cmMsgDefSdpAttrAbrFparmsStr,          /* 21 */
   NULLP,                                 /* 21 */
   &cmMsgDefSdpAttrClkRecStr,             /* 22 */
   &cmMsgDefSdpAttrFecStr,                /* 23 */
   &cmMsgDefSdpAttrPrtflStr,              /* 61 */
   &cmMsgDefSdpAttrBearerTypeStr,         /* 25 */
   &cmMsgDefSdpAttrStructureStr,          /* 26 */
   &cmMsgDefSdpAttrSbcStr,                /* 61 */
   &cmMsgDefSdpAttrFcpsSduSizeStr,        /* 27 */
   NULLP,                                 /* 27 */
   &cmMsgDefSdpAttrAal2CPSStr,            /* 28 */
   &cmMsgDefSdpAttrAal2Sscs3661Str,       /* 29 */
   &cmMsgDefSdpAttrAal2Sscs3662Str,       /* 30 */
   &cmMsgDefSdpAttrAal2Sscs3652Str,       /*  2 */
   &cmMsgDefSdpAttrAal2Sscs3653Str,       /*  2 */
   &cmMsgDefSdpAttrAal5AppStr,            /* 31 */
   &cmMsgDefSdpAttrLijStr,                /* 32 */
   &cmMsgDefSdpAttrAnycastStr,            /* 33 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
   NULLP, NULLP, NULLP, 
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpAttrWtpStr,                /* 34 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrCacheStr,              /* 35 */
   &cmMsgDefSdpAttrChainStr,              /* 36 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpAttrPhoneContextStr,       /* 37 */
   &cmMsgDefSdpAttrClirStr,               /* 38 */
   &cmMsgDefSdpAttrQ763NatureStr,         /* 18 */
   &cmMsgDefSdpAttrQ763PlanStr,           /* 18 */
   &cmMsgDefSdpAttrQ763INNStr,            /* 39 */
   &cmMsgDefSdpAttrRequireStr,            /* 40 */
   &cmMsgDefSdpAttrDirectionStr           /* 42 */
#ifdef CM_SDP_V_3
   , &cmMsgDefSdpAttrQosStr
   , &cmMsgDefSdpAttrSecureStr
   , &cmMsgDefSdpAttrFidStr
   , &cmMsgDefSdpAttrMidStr
   , &cmMsgDefSdpAttrGroupStr
   , &cmMsgDefSdpAttrSqnStr
   , &cmMsgDefSdpAttrCdscStr
   , &cmMsgDefSdpAttrCparStr
   , &cmMsgDefSdpAttrCparMinStr
   , &cmMsgDefSdpAttrCparMaxStr
   , &cmMsgDefSdpAttrT38FaxStr
#else
   , NULLP, NULLP, NULLP, NULLP, NULLP
   , NULLP, NULLP, NULLP, NULLP, NULLP, NULLP
#endif

#ifdef CM_SDP_ATM_SUPPORT
   , &cmMsgDefSdpAttrAtmAbrSetupStr
   , &cmMsgDefSdpAttrAtmAal2CpsSduRateStr
   , &cmMsgDefSdpAttrAtmAal5SscopStr
   , &cmMsgDefSdpAttrAtmBrrSigIeStr
   , &cmMsgDefSdpAttrAtmOneWaySelStr
   , &cmMsgDefSdpAttrAtmCodecCfgStr
   , &cmMsgDefSdpAttrAtmIsupUsiStr
   , &cmMsgDefSdpAttrAtmUiLyr1ProtStr
   , &cmMsgDefSdpAttrAtmCbrRateStr
   , &cmMsgDefSdpAttrAtmAal2sscs3611AssStr
#else
   , NULLP, NULLP, NULLP, NULLP, NULLP
   , NULLP, NULLP, NULLP, NULLP, NULLP
#endif
   , &cmMsgDefSdpAttrIpBcpStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttributeChcElmnt[] =
{
   &cmMsgDefSdpAttrGeneric,                                 /*  0 */
   &cmMsgDefSdpAttrByteString,                              /*  1 */
   &cmMsgDefSdpAttrSkip,                                    /*  2 */
   &cmMsgDefSdpAttrOrient,                                  /*  3 */
   &cmMsgDefSdpAttrType,                                    /*  4 */
   &cmMsgDefSdpAttrFmtp,                                    /*  5 */
   &cmMsgDefSdpAttrRtpMap,                                  /*  6 */
   &cmMsgDefSdpUriVal,                                      /*  7 */
   &cmMsgDefSdpAttrRange,                                   /*  8 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrAtmMap,                                  /*  9 */
/* cm_sdpdb_c_002.main_14: Modified to allow $ (CHOOSE) in the place of single parameter value */
#ifdef CM_SDP_MEGACO_EECID_CHOICE
   &cmMsgDefSdpAttrEecId,
#else
   &cmMsgDefSdpHexU32,                                      /* 10 */
#endif
   &cmMsgDefSdpAttrAalType,                                 /* 11 */
   &cmMsgDefSdpAttrSilSupp,                                 /* 12 */
   &cmMsgDefSdpAttrEchoCan,                                 /* 13 */
   &cmMsgDefSdpAttrGainCtl,                                 /* 14 */
   &cmMsgDefSdpAttrProfDesc,                                /* 15 */
   &cmMsgDefSdpAttrDevSel,                                  /* 16 */
   &cmMsgDefSdpAttrCapab,                                   /* 17 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpDecUchar,                                    /* 18 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrQosParms,                                /* 19 */
   &cmMsgDefSdpAttrTfcDesc,                                 /* 20 */
   &cmMsgDefSdpAttrAbrParms,                                /* 21 */
   &cmMsgDefSdpAttrClkRec,                                  /* 22 */
   &cmMsgDefSdpAttrFec,                                     /* 23 */

   &cmMsgDefSdpAttrAtmBcob,                                 /* 24 */

   &cmMsgDefSdpAttrBearType,                                /* 25 */
   &cmMsgDefSdpAttrStruc,                                   /* 26 */

   &cmMsgDefSdpAttrCpsSduSize,                              /* 27 */

   &cmMsgDefSdpAttrAal2Cps,                                 /* 28 */
   &cmMsgDefSdpAttrAal23661,                                /* 29 */
   &cmMsgDefSdpAttrAal23662,                                /* 30 */
   &cmMsgDefSdpAttrAal5App,                                 /* 31 */
   &cmMsgDefSdpAttrLij,                                     /* 32 */
   &cmMsgDefSdpAttrAnycast,                                 /* 33 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, 
   NULLP, NULLP, NULLP, NULLP, NULLP, 
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpAttrWtp,                                     /* 34 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrCache,                                   /* 35 */
   &cmMsgDefSdpAttrChain,                                   /* 36 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpAttrPhoneContextIdent,                       /* 37 */
   &cmMsgDefSdpAttrClir,                                    /* 38 */
   &cmMsgDefSdpAttrInn,                                     /* 39 */
   &cmMsgDefSdpAttrRequire,                                 /* 40 */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpAttrDSel,                                    /* 41 */
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpAttrDirection,                               /* 42 */
   /* cm_sdpdb_c_001.main_2 - Addition */
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpDecU8OrNull                                  /* 43 */
#else
   NULLP
#endif
#ifdef CM_SDP_V_3
   , &cmMsgDefSdpAttrQosOrSecure,                           /* 44 */
     &cmMsgDefSdpTnExtnFormat,                              /* 45 */
     &cmMsgDefSdpAttrGroup,                                 /* 46 */
     &cmMsgDefSdpAttrSqn,                                   /* 47 */
     &cmMsgDefSdpAttrCdsc,                                  /* 48 */
     &cmMsgDefSdpAttrCparParVal,                            /* 49 */
     &cmMsgDefSdpAttrT38Fax,                                /* 50 */
#else
     , NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP,
#endif

    /* Now come the new ATM Rfc 3108 attributes */
#ifdef CM_SDP_ATM_SUPPORT
     &cmMsgDefSdpAttrAtmAbrSetup,
     &cmMsgDefSdpAttrAal2CpsSduRate,
     &cmMsgDefSdpAttrAal5Sscop,
     &cmMsgDefAtmBrrSigIe,
     &cmMsgDefSdpAttrOneWaySel,
     &cmMsgDefSdpAttrCodecCfg,
     &cmMsgDefSdpAttrIsupUsi,
     &cmMsgDefSdpAttrCbrRate,        /* UiLyr1Prot is the same as cbrRate */
     &cmMsgDefSdpAttrCbrRate,
     &cmMsgDefSdpAttrAal23661Assrd,
     &cmMsgDefSdpGenU8,              /* this is for prtfl & sbc */
#else
     NULLP, NULLP, NULLP, NULLP, NULLP, 
     NULLP, NULLP, NULLP, NULLP, NULLP, 
     NULLP,
#endif

     &cmMsgDefSdpDecU32,              /* new element added for ptime */
     &cmMsgDefSdpIpBcp,
};

PUBLIC U8 cmMsgDefSdpAttributeChcIdx[] =
{
   0, 1, 1, 1, 62, 2, 2, 2, 3, 4,
   1, 1, 1, 1, 1, 5, 6, 2, 7, 8,
   1, 9, 10, 11, 12, 13, 13, 14, 14, 15,
   /* cm_sdpdb_c_001.main_2 - Change: Old 4th row was 16, 41, 16, 17, 18, 24, 18,
    * 18, 19, 19,
    */
   16, 41, 16, 17, 43, 24, 18, 18, 19, 19,  
   1, 1, 20, 20, 1, 1, 21, 21, 22, 23,
   61, 25, 26, 61, 27, 27, 28, 29, 30, 2,
   2, 31, 32, 33, 34, 35, 36, 37, 38, 18,
   18, 39, 40, 42
#ifdef CM_SDP_V_3
   , 44, 44, 45, 45, 46, 47, 48, 49, 49, 49, 50
/* new additions for QOS, secure, fid, mid, group, sqn,
   cdsc, cpar and T38 fax attributes */
#else
   , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
#endif

    /* Now come the new ATM Rfc 3108 attributes */
#ifdef CM_SDP_ATM_SUPPORT
   , 51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
#else
   , 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#endif
   63,    /* IPBCP Support */
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttributeChc =
{
/* *ifdef CM_SDP_V_3  */
   64, /* new additions for QOS, secure, fid, mid, group, T38 fax */
   CM_SDP_ATTR_MAX, /* sqn, cdsc, cpar, cparmin and cparmax, T38 fax attributes */
/*
   *else
   44,
   84,
   *endif
*/
   cmMsgDefSdpAttributeChcIdx,
   cmMsgDefSdpAttributeChcElmnt,
   cmMsgDefSdpAttributeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttribute =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute",
   "SDPAttribute",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 537,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttributeChc,
   cmSdpRegExpAttribute
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttributeNonStdSeqElmnt[] =
{
   &cmMsgDefSdpAttrGenericStr,
   &cmMsgDefSdpAttrGeneric
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttributeNonStdSeq =
{
   2,
   cmMsgDefSdpAttributeNonStdSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttributeNonStd =
{
#ifdef CM_ABNF_DBG
   "SDP AttributeNonStd",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 538,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpAttributeNonStdSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttributeNotConsumedChcElmnt[] =
{
   &cmMsgDefSdpAttributeNonStd,
   &cmMsgDefSdpAttribute
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC U8 cmMsgDefSdpAttributeNotConsumedChcIdx[] =
{
   0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
   1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,

};
#else /* !CM_SDP_ATM_SUPPORT */
PUBLIC U8 cmMsgDefSdpAttributeNotConsumedChcIdx[] =
{
   0,    /* CM_SDP_ATTR_GENERIC */
   1,    /* CM_SDP_ATTR_CAT */
   1,    /* CM_SDP_ATTR_KEYWDS */
   1,    /* CM_SDP_ATTR_TOOL */
   1,    /* CM_SDP_ATTR_PTIME */
   1,    /* CM_SDP_ATTR_RECVONLY */
   1,    /* CM_SDP_ATTR_SENDRECV */
   1,    /* CM_SDP_ATTR_SENDONLY */
   1,    /* CM_SDP_ATTR_ORIENT */
   1,    /* CM_SDP_ATTR_TYPE */
   1,    /* CM_SDP_ATTR_CHARSET */
   1,    /* CM_SDP_ATTR_SDPLANG */
   1,    /* CM_SDP_ATTR_LANG */
   1,    /* CM_SDP_ATTR_FRAMERATE */
   1,    /* CM_SDP_ATTR_QUALITY */
   1,    /* CM_SDP_ATTR_FMTP */
   1,    /* CM_SDP_ATTR_RTPMAP */
   1,    /* CM_SDP_ATTR_INACTIVE */
   1,    /* CM_SDP_ATTR_CONTROL */
   1,    /* CM_SDP_ATTR_RANGE */
   1,    /* CM_SDP_ATTR_ETAG */
   0,    /* CM_SDP_ATTR_ATMMAP */
   0,    /* CM_SDP_ATTR_EECID */
   0,    /* CM_SDP_ATTR_AALTYPE */
   0,    /* CM_SDP_ATTR_SILENCESUPP */
   0,    /* CM_SDP_ATTR_ECANF */
   0,    /* CM_SDP_ATTR_ECANB */
   0,    /* CM_SDP_ATTR_GCF */
   0,    /* CM_SDP_ATTR_GCB */
   0,    /* CM_SDP_ATTR_PROFILEDESC */
   0,    /* CM_SDP_ATTR_VSEL */
   0,    /* CM_SDP_ATTR_DSEL */
   0,    /* CM_SDP_ATTR_FSEL */
   0,    /* CM_SDP_ATTR_CAPABILITY */
   0,    /* CM_SDP_ATTR_QOSCLASS */
   0,    /* CM_SDP_ATTR_BCOB */
   0,    /* CM_SDP_ATTR_STC */
   0,    /* CM_SDP_ATTR_UPCC */
   0,    /* CM_SDP_ATTR_ATMQOSFPARMS */
   0,    /* CM_SDP_ATTR_ATMQOSBPARMS */
   0,    /* CM_SDP_ATTR_AAL2QOSFPARMS */
   0,    /* CM_SDP_ATTR_AAL2QOSBPARMS */
   0,    /* CM_SDP_ATTR_ATMFTRFCDESC */
   0,    /* CM_SDP_ATTR_ATMBTRFCDESC */
   0,    /* CM_SDP_ATTR_AAL2FTRFCDESC */
   0,    /* CM_SDP_ATTR_AAL2BTRFCDESC */
   0,    /* CM_SDP_ATTR_ABRFPARMS */
   0,    /* CM_SDP_ATTR_ABRBPARMS */
   0,    /* CM_SDP_ATTR_CLKREC */
   0,    /* CM_SDP_ATTR_FEC */
   0,    /* CM_SDP_ATTR_PRTFL */
   0,    /* CM_SDP_ATTR_BEARERTYPE */
   0,    /* CM_SDP_ATTR_STRUCTURE */
   0,    /* CM_SDP_ATTR_SBC */
   0,    /* CM_SDP_ATTR_FCPSSDUSIZE */
   0,    /* CM_SDP_ATTR_BCPSSDUSIZE */
   0,    /* CM_SDP_ATTR_AAL2CPS */
   0,    /* CM_SDP_ATTR_AAL2SSCS3661 */
   0,    /* CM_SDP_ATTR_AAL2SSCS3662 */
   0,    /* CM_SDP_ATTR_AAL2SSCS3652 */
   0,    /* CM_SDP_ATTR_AAL2SSCS3653 */
   0,    /* CM_SDP_ATTR_AAL5APP */
   0,    /* CM_SDP_ATTR_LIJ */
   0,    /* CM_SDP_ATTR_ANYCAST */
   1,    /* CM_SDP_ATTR_WTP */
   0,    /* CM_SDP_ATTR_CACHE */
   0,    /* CM_SDP_ATTR_CHAIN */
   1,    /* CM_SDP_ATTR_PHONECONTEXT */
   1,    /* CM_SDP_ATTR_CLIR */
   1,    /* CM_SDP_ATTR_Q763NATURE */
   1,    /* CM_SDP_ATTR_Q763PLAN */
   1,    /* CM_SDP_ATTR_Q763INN */
   1,    /* CM_SDP_ATTR_REQUIRE */
   1,    /* CM_SDP_ATTR_DIRECTION */
#ifdef CM_SDP_V_3
   1,    /* CM_SDP_ATTR_QOS */
   1,    /* CM_SDP_ATTR_SECURE */
   1,    /* CM_SDP_ATTR_FID */
   1,    /* CM_SDP_ATTR_MID */
   1,    /* CM_SDP_ATTR_GROUP */
   1,    /* CM_SDP_ATTR_SQN_NUM */
   1,    /* CM_SDP_ATTR_CDSC */
   1,    /* CM_SDP_ATTR_CPAR */
   1,    /* CM_SDP_ATTR_CPAR_MIN */
   1,    /* CM_SDP_ATTR_CPAR_MAX */
   1,    /* CM_SDP_ATTR_T38_FAX */
#else
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#endif
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,

};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAttributeNotConsumedChc =
{
   2,
/* *ifdef CM_SDP_V_3  */
   CM_SDP_ATTR_MAX,
/*
   *else
   84,
   *endif
*/
   cmMsgDefSdpAttributeNotConsumedChcIdx,
   cmMsgDefSdpAttributeNotConsumedChcElmnt,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttributeNotConsumed =
{
#ifdef CM_ABNF_DBG
   "SDP Attribute - token not consumed",
   "SDPAttribute",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 539,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAttributeNotConsumedChc,
   cmSdpRegExpAttribute
};

/************************************************************************
                              SDP Attribute
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpAttrStrMeta = {(Data *)"a="};
PUBLIC CmAbnfElmDef cmMsgDefSdpAttrStr =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRSTR",
   "SDPR27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 540,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpAttrStrMeta,
   cmSdpRegExpR27
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttSeqElmnt[] =
{
   &cmMsgDefSdpAttrStr,
   &cmMsgDefSdpAttributeNotConsumed,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttSeq =
{
   3,
   cmMsgDefSdpAttSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttr =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 541,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpAttSeq,
   NULLP
};

/************************************************************************
                              SDP Attribute fields
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSetSeqOfElmnt[] =
{
   &cmMsgDefSdpAttr
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttrSetSeqOf =
{
   0,
   CM_SDP_MAX_ATTR,
   1,
   cmMsgDefSdpAttrSetSeqOfElmnt,
   sizeof(CmSdpAttr)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSet =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRSET",
   "SDPR27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 542,
   sizeof(CmSdpAttrSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpAttrSetSeqOf,
   cmSdpRegExpR27
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMediaStrMeta = {(Data *)"m="};
PUBLIC CmAbnfElmDef cmMsgDefSdpMediaStr =
{
#ifdef CM_ABNF_DBG
   "SDP: MDSTR",
   "SDPR29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 543,
   0, 
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMediaStrMeta,
   cmSdpRegExpR29
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaUnknownEnum =
{
   (Data *)NULLP,
   CM_SDP_MEDIA_UNKNOWN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaUnknownStr =
{
#ifdef CM_ABNF_DBG
   "SDP: UNKNOWN MEDIA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 544,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaUnknownEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaAudioEnum =
{
   (Data *)"audio",
   CM_SDP_MEDIA_AUDIO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaAudio =
{
#ifdef CM_ABNF_DBG
   "SDP: AUDIO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 545,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaAudioEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaVideoEnum =
{
   (Data *)"video",
   CM_SDP_MEDIA_VIDEO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaVideo =
{
#ifdef CM_ABNF_DBG
   "SDP: VIDEO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 546,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaVideoEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaDataEnum =
{
   (Data *)"data",
   CM_SDP_MEDIA_DATA
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaData =
{
#ifdef CM_ABNF_DBG
   "SDP: DATA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 547,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaDataEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaAppAppEnum =
{
   (Data *)"application",
   CM_SDP_MEDIA_APP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaApp =
{
#ifdef CM_ABNF_DBG
   "SDP: APP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 548,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaAppAppEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaControlEnum =
{
   (Data *)"control",
   CM_SDP_MEDIA_CONTROL
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaControl =
{
#ifdef CM_ABNF_DBG
   "SDP: CONTROL",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 549,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaControlEnum,
   NULLP
};

/* 001.main_7: Added EnumType for image */
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaImageEnum =
{
   (Data *)"image",
   CM_SDP_MEDIA_IMAGE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaImage =
{
#ifdef CM_ABNF_DBG
   "SDP: IMAGE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1019,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaImageEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaTextEnum =
{
   (Data *)"text",
   CM_SDP_MEDIA_TEXT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaText =
{
#ifdef CM_ABNF_DBG
   "SDP: TEXT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 751,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaTextEnum,
   NULLP
};

#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaMessageEnum =
{
   (Data *)"message",
   CM_SDP_MEDIA_MESSAGE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaMessage =
{
#ifdef CM_ABNF_DBG
   "SDP: TEXT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 751,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaMessageEnum,
   NULLP
};
#endif /* CM_SDP_SIP_IM_SUPPORT */

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaSkipName =
{
#ifdef CM_ABNF_DBG
   "SDP MediaSkipName",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 550,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpMediaAudio,
   &cmMsgDefSdpMediaVideo,
   &cmMsgDefSdpMediaData,
   &cmMsgDefSdpMediaApp,
   &cmMsgDefSdpMediaControl,
   &cmMsgDefSdpMediaImage,
   &cmMsgDefSdpMediaText
#ifdef CM_SDP_SIP_IM_SUPPORT 
   , &cmMsgDefSdpMediaMessage
#endif /* CM_SDP_IM_SUPPORT */
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaChcElmnt[] =
{
   &cmMsgDefSdpMediaSkipName
};

#ifdef CM_SDP_SIP_IM_SUPPORT 
PUBLIC U8 cmMsgDefSdpMediaChcIdx[] = {0, 0, 0, 0, 0, 0, 0, 0 , 0};
#else
PUBLIC U8 cmMsgDefSdpMediaChcIdx[] = {0, 0, 0, 0, 0, 0, 0, 0};
#endif /* CM_SDP_IM_SUPPORT */

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaChc =
{
   1,
/* 001.main_7: incremented to add new media type */
#ifdef CM_SDP_SIP_IM_SUPPORT
   9,
#else
   8,
#endif /* CM_SDP_SIP_IM_SUPPORT */
   cmMsgDefSdpMediaChcIdx,
   cmMsgDefSdpMediaChcElmnt,
   cmMsgDefSdpMediaChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedia =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA ",
   "SDPR30",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 551,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaChc,
   cmSdpRegExpR30
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMediaUnknownValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaUnknownVal =
{
#ifdef CM_ABNF_DBG
   "SDP MEDIA unknown name",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 552,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpMediaUnknownValRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaUnknownSeqElmnt[] =
{
   &cmMsgDefSdpMediaUnknownStr,
   &cmMsgDefSdpMediaUnknownVal
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaUnknownSeq =
{
   2,
   cmMsgDefSdpMediaUnknownSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaUnknown =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA unknown type",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 553,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMediaUnknownSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaNotConsumedChcElmnt[] =
{
   &cmMsgDefSdpMediaUnknown,
   &cmMsgDefSdpMedia
};

/* 001.main_7: incremented number of elements to include IMAGE type */
#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC U8 cmMsgDefSdpMediaNotConsumedChcIdx[] = {0, 1, 1, 1, 1, 1, 1, 1, 1};
#else
PUBLIC U8 cmMsgDefSdpMediaNotConsumedChcIdx[] = {0, 1, 1, 1, 1, 1, 1, 1};
#endif /* CM_SDP_SIP_IM_SUPPORT */

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaNotConsumedChc =
{
   2,
/* 001.main_7: incremented number of elements to include IMAGE type */
#ifdef CM_SDP_SIP_IM_SUPPORT
   9,
#else
   8,
#endif /* CM_SDP_SIP_IM_SUPPORT */
   cmMsgDefSdpMediaNotConsumedChcIdx,
   cmMsgDefSdpMediaNotConsumedChcElmnt,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaNotConsumed =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA known/unknown",
   "SDPR30",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 554,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaNotConsumedChc,
   cmSdpRegExpR30
};


/************************************************************************
                              SDP Generic Choose types 
*************************************************************************/

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpDollarEnum =
{
   (Data *)"$",
   CM_SDP_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDollar =
{
#ifdef CM_ABNF_DBG
   "SDP $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 555,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpDollarEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpDollarIpAddrEnum =
{
   (Data *)"$",
   CM_SDP_IPV4_IP_ANY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDollarIpAddr =
{
#ifdef CM_ABNF_DBG
   "SDP $ in IP Address",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 556,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpDollarIpAddrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpDollarVcIdEnum =
{
   (Data *)"$",
   CM_SDP_VCID_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDollarVcId =
{
#ifdef CM_ABNF_DBG
   "SDP $ in VcId",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 556,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpDollarVcIdEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipDollarU8Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipDollarU8 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipDollarU8",
   "CM_RDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 557,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipDollarU8Rng,
   cmAbnfRegExpDollar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU8OrDollarChcElmnt[] =
{
   &cmMsgDefSdpSkipDollarU8,
   &cmMsgDefSdpGenU8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU8OrDollarChcEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU8OrDollarChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU8OrDollarChcElmnt,
   cmMsgDefSdpGenU8OrDollarChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU8OrDollar =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U8 or $",
   "SDPGenUintOrDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 558,
   sizeof(CmSdpU8OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU8OrDollarChc,
   cmSdpRegExpGenUintOrDollar
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipDollarU16Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipDollarU16 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipDollarU16",
   "CM_RDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 559,
   sizeof(TknU16),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipDollarU16Rng,
   cmAbnfRegExpDollar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU16OrDollarChcElmnt[] =
{
   &cmMsgDefSdpSkipDollarU16,
   &cmMsgDefSdpGenU16
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU16OrDollarChcEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU16OrDollarChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU16OrDollarChcElmnt,
   cmMsgDefSdpGenU16OrDollarChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU16OrDollar =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U16 or $",
   "SDPGenUintOrDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 560,
   sizeof(CmSdpU16OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU16OrDollarChc,
   cmSdpRegExpGenUintOrDollar
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSkipDollarU32Rng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpSkipDollarU32 =
{
#ifdef CM_ABNF_DBG
   "SDP SkipDollarU32",
   "CM_RDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 561,
   sizeof(TknU32),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpSkipDollarU32Rng,
   cmAbnfRegExpDollar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU32OrDollarChcElmnt[] =
{
   &cmMsgDefSdpSkipDollarU32,
   &cmMsgDefSdpGenU32
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpGenU32OrDollarChcEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpSpec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpGenU32OrDollarChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpGenU32OrDollarChcElmnt,
   cmMsgDefSdpGenU32OrDollarChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpGenU32OrDollar =
{
#ifdef CM_ABNF_DBG
   "SDP Generic U32 or $",
   "SDPGenUintOrDollar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 562,
   sizeof(CmSdpU32OrNil),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpGenU32OrDollarChc,
   cmSdpRegExpGenUintOrDollar
};

/************************************************************************
                              SDP VcId
*************************************************************************/

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpVcIdImplicitRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdImplicit =
{
#ifdef CM_ABNF_DBG
   "SDP Implicit VcId",
   "SDPImplicitVcId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 563,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpVcIdImplicitRng,
   cmSdpRegExpImplicitVcId
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpCidStrMeta = {(Data *)"/CID-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpCidStr =
{
#ifdef CM_ABNF_DBG
   "SDP /CID-",
   "SDPCid",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 564,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpCidStrMeta,
   cmSdpRegExpCid
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdOptCidSeqElmnt[] =
{
   &cmMsgDefSdpCidStr,
   &cmMsgDefSdpGenU8OrDollar
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVcIdOptCidSeq =
{
   2,
   cmMsgDefSdpVcIdOptCidSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdOptCid =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdOptCid",
   "SDP Cid",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 565,
   sizeof(TknU8),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpVcIdOptCidSeq,
   cmSdpRegExpCid
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVcIdVcciMeta = {(Data *)" VCCI-"};
PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdVcciMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdVcciMetaStr",
   "SDPSpaceVCCIHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 566,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVcIdVcciMeta,
   cmSdpRegExpSpaceVCCIHyphen
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdVcciSeqElmnt[] =
{
   &cmMsgDefSdpVcIdVcciMetaStr,
   &cmMsgDefSdpGenU32OrDollar,
   &cmMsgDefSdpVcIdOptCid
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVcIdVcciSeq =
{
   3,
   cmMsgDefSdpVcIdVcciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdVcci =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdVcci",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 567,
   sizeof(CmSdpVcci),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVcIdVcciSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVxciVcciSeqElmnt[] =
{
   &cmMsgDefSdpGenU32OrDollar,
   &cmMsgDefSdpVcIdOptCid
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVxciVcciSeq =
{
   2,
   cmMsgDefSdpVxciVcciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVcci =
{
#ifdef CM_ABNF_DBG
   "SDP VxciVcci",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 568,
   sizeof(CmSdpVcci),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVxciVcciSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVxciVcciEnum =
{
   (Data *)"/VCCI-",
   CM_SDP_ADDR_VCCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVcciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VxciVcciStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 569,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVxciVcciEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVxciVciStrMeta = {(Data *)"/VCI-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VciStr",
   "SDPVci",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 570,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVxciVciStrMeta,
   cmSdpRegExpVci
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVxciVpciVciSeqElmnt[] =
{
   &cmMsgDefSdpGenU16OrDollar,
   &cmMsgDefSdpVxciVciStr,
   &cmMsgDefSdpGenU16OrDollar,
   &cmMsgDefSdpVcIdOptCid
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVxciVpciVciSeq =
{
   4,
   cmMsgDefSdpVxciVpciVciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVpciVci =
{
#ifdef CM_ABNF_DBG
   "SDP VxciVpciVci",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 571,
   sizeof(CmSdpVpVcCid),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVxciVpciVciSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVxciVpciVciEnum =
{
   (Data *)"/VPCI-",
   CM_SDP_ADDR_VPCIVCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVpciVciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VxciVpciVciStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 572,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVxciVpciVciEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVxciChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpVxciVcciStr,
   &cmMsgDefSdpVxciVpciVciStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVxciChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpVxciVcci,
   &cmMsgDefSdpVxciVpciVci
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpVxciChc =
{
   3,
   0,
   NULLP,
   cmMsgDefSdpVxciChcElmnt,
   cmMsgDefSdpVxciChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxci =
{
#ifdef CM_ABNF_DBG
   "SDP Vxci",
   "SDPVxci",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 573,
   sizeof(TknU8) + sizeof(((CmSdpAddrVcci *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpVxciChc,
   cmSdpRegExpVxci
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptVxciSeqElmnt[] =
{
   &cmMsgDefSdpVxci
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptVxciSeq =
{
   1,
   cmMsgDefSdpOptVxciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptVxci =
{
#ifdef CM_ABNF_DBG
   "SDP OptVxci",
   "SDPVxci",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 574,
   sizeof(TknU8) + sizeof(((CmSdpAddrVcci *)0)->u),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptVxciSeq,
   cmSdpRegExpVxci
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMNsapEnum =
{
   (Data *)"NSAP-",
   CM_SDP_ADDR_TYPE_NSAP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMNsapStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-Nsap",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 575,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMNsapEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeME164Enum =
{
   (Data *)"E164-",
   CM_SDP_ADDR_TYPE_E164
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeME164Str =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-E164",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 576,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeME164Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMGwidEnum =
{
   (Data *)"GWID-",
   CM_SDP_ADDR_TYPE_GWID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMGwidStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-Gwid",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 577,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMGwidEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMAliasEnum =
{
   (Data *)"ALIAS-",
   CM_SDP_ADDR_TYPE_ALIAS
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMAliasStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-Alias",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 578,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMAliasEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMNsapChooseEnum =
{
   (Data *)"NSAP-$",
   CM_SDP_ADDR_TYPE_NSAP_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMNsapChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-NsapChoose",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 579,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMNsapChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeME164ChooseEnum =
{
   (Data *)"E164-$",
   CM_SDP_ADDR_TYPE_E164_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeME164ChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-E164Choose",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 580,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeME164ChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMGwidChooseEnum =
{
   (Data *)"GWID-$",
   CM_SDP_ADDR_TYPE_GWID_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMGwidChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-GwidChoose",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 581,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMGwidChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeMAliasChooseEnum =
{
   (Data *)"ALIAS-$",
   CM_SDP_ADDR_TYPE_ALIAS_CHOOSE
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeMAliasChooseStr =
{
#ifdef CM_ABNF_DBG
   "SDP AddrTypeM-AliasChoose",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 582,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeMAliasChooseEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAtmTypeAddrMElmnt[] =
{
   NULLP,
   &cmMsgDefSdpAtmNsapAddr,
   &cmMsgDefSdpAtmE164Addr,
   &cmMsgDefSdpAtmGwidAddr,
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAtmTypeAddrMEnum[] =
{
   NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, NULLP, /* 0..7 N/A */
   &cmMsgDefSdpAddrTypeMNsapStr,          /*  8 -> 1 */
   &cmMsgDefSdpAddrTypeME164Str,          /*  9 -> 2 */
   &cmMsgDefSdpAddrTypeMGwidStr,          /* 10 -> 3 */
   &cmMsgDefSdpAddrTypeMAliasStr,         /* 11 -> 3 */
   &cmMsgDefSdpAddrTypeMNsapChooseStr,    /* 12 -> 0 */
   &cmMsgDefSdpAddrTypeME164ChooseStr,    /* 13 -> 0 */
   &cmMsgDefSdpAddrTypeMGwidChooseStr,    /* 14 -> 0 */
   &cmMsgDefSdpAddrTypeMAliasChooseStr,   /* 15 -> 0 */
   NULLP, NULLP, NULLP, NULLP,   /* 16..19 N/A */
};

PUBLIC U8 cmMsgDefSdpAtmTypeAddrMIdx[] =
   {0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 3, 0, 0, 0, 0, 0, 0, 0, 0, };

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAtmTypeAddrMChc =
{
   4,
   20,
   cmMsgDefSdpAtmTypeAddrMIdx,
   cmMsgDefSdpAtmTypeAddrMElmnt,
   cmMsgDefSdpAtmTypeAddrMEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAtmTypeAddrM =
{
#ifdef CM_ABNF_DBG
   "SDP Atm Address in media",
   "SDPAtmTypeAddrM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 583,
   /* cm_sdpdb_c_001.main_2 - Change: Old was sizeof(CmSdpAddr) */
   sizeof(CmSdpAddr) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAtmTypeAddrMChc,
   cmSdpRegExpAtmTypeAddrM
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdAtmAddrVcciSeqElmnt[] =
{
   &cmMsgDefSdpAtmTypeAddrM,
   &cmMsgDefSdpOptVxci
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVcIdAtmAddrVcciSeq =
{
   2,
   cmMsgDefSdpVcIdAtmAddrVcciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdAtmAddrVcci =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdAtmAddrVcci",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 584,
   sizeof(CmSdpAddrVcci),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVcIdAtmAddrVcciSeq,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVcIdBcgMeta = {(Data *)" BCG-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdBcgMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP BcgStr",
   "SDPBcg",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 585,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVcIdBcgMeta,
   cmSdpRegExpBcg
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVxciVpiEnum =
{
   (Data *)"/VPI-",
   CM_SDP_ADDR_VPIVCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVxciVpiStr =
{
#ifdef CM_ABNF_DBG
   "SDP VxciVpiStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 586,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVxciVpiEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcciOrVpiVciChcEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpVxciVcciStr,
   &cmMsgDefSdpVxciVpciVciStr,
   &cmMsgDefSdpVxciVpiStr
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcciOrVpiVciChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpVxciVcci,
   &cmMsgDefSdpVxciVpciVci
};

PUBLIC U8 cmMsgDefSdpVcciOrVpiVciChcIdx[] = {0, 1, 2, 2};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpVcciOrVpiVciChc =
{
   3,
   4,
   cmMsgDefSdpVcciOrVpiVciChcIdx,
   cmMsgDefSdpVcciOrVpiVciChcElmnt,
   cmMsgDefSdpVcciOrVpiVciChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcciOrVpiVci =
{
#ifdef CM_ABNF_DBG
   "SDP VcciOrVpiVci",
   "SDPVxci",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 587,
   sizeof(TknU8) + sizeof(((CmSdpBcg *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpVcciOrVpiVciChc,
   cmSdpRegExpVxci
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdBcgSeqElmnt[] =
{
   &cmMsgDefSdpVcIdBcgMetaStr,
   &cmMsgDefSdpGenU8OrDollar,
   &cmMsgDefSdpVcciOrVpiVci
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVcIdBcgSeq =
{
   3,
   cmMsgDefSdpVcIdBcgSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdBcg =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdBcg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 588,
   sizeof(CmSdpBcg),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVcIdBcgSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPortAndIntEnum =
{
   NULLP,
   CM_SDP_PORT_INT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortAndIntStr =
{
#ifdef CM_ABNF_DBG
   "SDP PortAndIntStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 589,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPortAndIntEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpPortVpcidEnum =
{
   NULLP,
   CM_SDP_PORT_VPCID
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortVpcidStr =
{
#ifdef CM_ABNF_DBG
   "SDP PortVpcidStr",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 590,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpPortVpcidEnum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpPortIntRng = {1, 5, 0, 65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPortIntRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmDef cmMsgDefSdpPortInt =
{
#ifdef CM_ABNF_DBG
   "SDP: INT",
   "SDPR32",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 591,
   sizeof(TknU16),
   CM_ABNF_OPTIONAL, 
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpPortIntRng,
   cmSdpRegExpR32
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPortIntSeqElmnt[] =
{
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpPortInt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPortIntSeq =
{
   2,
   cmMsgDefSdpPortIntSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaPortInt =
{
#ifdef CM_ABNF_DBG
   "SDP: PORTI",
   "CM_RSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 592,
   sizeof(TknU16),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpPortIntSeq,
   cmAbnfRegExpSlash
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPortAndIntSeqElmnt[] =
{
   &cmMsgDefSdpDecU16OrNull,
   &cmMsgDefSdpMediaPortInt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPortAndIntSeq =
{
   2,
   cmMsgDefSdpPortAndIntSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortAndInt =
{
#ifdef CM_ABNF_DBG
   "SDP PortAndInt",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 593,
   sizeof(CmSdpPortInt),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpPortAndIntSeq,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpPortMeta = {(Data *)" PORT-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortStr =
{
#ifdef CM_ABNF_DBG
   "SDP PortStr",
   "SDPPortStr",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 594,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpPortMeta,
   cmSdpRegExpPortStr
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPortIdRng = {1, 34};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortId =
{
#ifdef CM_ABNF_DBG     
   "SDP PortId",
   "SDPPortId",
#endif /* CM_ABNF_DBG */ 
   CM_ABNF_ELMNID_SDP_BASE + 595,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpPortIdRng,
   cmSdpRegExpPortId
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVpiMeta = {(Data *)"/VPI-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpVpiMetaStr =
{
#ifdef CM_ABNF_DBG
   "SDP VpiMetaStr",
   "SDPVpi",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 596,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVpiMeta,
   cmSdpRegExpVpi
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPortVpcidSeqElmnt[] =
{
   &cmMsgDefSdpPortStr,
   &cmMsgDefSdpPortId,
   &cmMsgDefSdpVpiMetaStr,
   &cmMsgDefSdpVxciVpciVci 
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPortVpcidSeq =
{
   4,
   cmMsgDefSdpPortVpcidSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPortVpcid =
{
#ifdef CM_ABNF_DBG
   "SDP PortVpcid",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 597,
   sizeof(CmSdpPortIdVpVcCid),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpPortVpcidSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdPortChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpPortAndIntStr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpPortVpcidStr
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP
#endif /* CM_SDP_ATM_SUPPORT */
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdPortChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpPortAndInt,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpPortVpcid
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP
#endif /* CM_SDP_ATM_SUPPORT */
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpVcIdPortChc =
{
   3,
   0,
   NULLP,
   cmMsgDefSdpVcIdPortChcElmnt,
   cmMsgDefSdpVcIdPortChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdPort =
{
#ifdef CM_ABNF_DBG    
   "SDP VcIdPort",
   "SDPPortType",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 598,
   sizeof(CmSdpPort),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpVcIdPortChc,
   cmSdpRegExpPortType
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVpciStrMeta = {(Data *)" VPCI-"};

PUBLIC CmAbnfElmDef cmMsgDefSdpVpciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VpciStr",
   "SDPVpci",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 599,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVpciStrMeta,
   cmSdpRegExpVpci
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdVpciSeqElmnt[] =
{
   &cmMsgDefSdpVpciStr,
   &cmMsgDefSdpVxciVpciVci
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVcIdVpciSeq =
{
   2,
   cmMsgDefSdpVcIdVpciSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdVpci =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdVpci",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 600,
   sizeof(CmSdpVpVcCid),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpVcIdVpciSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdImplicitEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_IMPLICIT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdImplicitStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdImplicit ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 601,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdImplicitEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdVcciEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_VCCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdVcciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdVcci ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 602,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdVcciEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdAtmAddrVcciEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_ATM_ADDR_VCCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdAtmAddrVcciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdAtmAddrVcci ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 603,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdAtmAddrVcciEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdBcgEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_BCG
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdBcgStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdBcg ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 604,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdBcgEnum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdPortEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_PORT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdPortStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdPort ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 605,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdPortEnum,
   NULLP
};

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpVcIdVpciEnum =
{
   (Data *)NULLP,
   CM_SDP_VCID_VPCI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcIdVpciStr =
{
#ifdef CM_ABNF_DBG
   "SDP VcIdVpci ENUM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 606,
   sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpVcIdVpciEnum,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdChcEnum[] =
{
   &cmMsgDefSdpNil,
   &cmMsgDefSdpDollarVcId,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpVcIdVcciStr,
   &cmMsgDefSdpVcIdAtmAddrVcciStr,
   &cmMsgDefSdpVcIdBcgStr,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpVcIdPortStr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpVcIdVpciStr,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpVcIdImplicitStr,
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVcIdChcElmnt[] =
{
   &cmMsgDefSdpSkipU8,     /* Size doesn't matter;-) have to consume "-" */
   &cmMsgDefSdpSkipDollarU8,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpVcIdVcci,
   &cmMsgDefSdpVcIdAtmAddrVcci,
   &cmMsgDefSdpVcIdBcg,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpVcIdPort,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpVcIdVpci,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpVcIdImplicit,
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpVcIdChc =
{
   8,
   0,
   NULLP,
   cmMsgDefSdpVcIdChcElmnt,
   cmMsgDefSdpVcIdChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVcId =
{
#ifdef CM_ABNF_DBG
   "SDP VcId",
   "SDPVcId",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 607,
   sizeof(CmSdpVcId),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpVcIdChc,
   cmSdpRegExpVcId
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMedProtoFmtsUnknownValRng = {1, 0xFFFF};
PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsUnknownVal =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsUnknownVal",
   "SDPProtoFmtsUnknownVal",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 608,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpMedProtoFmtsUnknownValRng,
   cmSdpRegExpProtoFmtsUnknownVal
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsUnknownValArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsUnknownVal
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpMedProtoFmtsUnknownValArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpMedProtoFmtsUnknownValArraySeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsUnknownValArray =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsUnknownValArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 609,
   sizeof(CmSdpMedFmtUnknownList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsUnknownValArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsUnknownSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoFmtsUnknownVal,
   &cmMsgDefSdpMedProtoFmtsUnknownValArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsUnknownSeq =
{
   2,
   cmMsgDefSdpMedProtoFmtsUnknownSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsUnknown =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsUnknown",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 610,
   sizeof(CmSdpMedFmtUnknownList),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsUnknownSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedOptProtoFmtsUnknownSeqElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedOptProtoFmtsUnknownSeq =
{
   2,
   cmMsgDefSdpMedOptProtoFmtsUnknownSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedOptProtoFmtsUnknown =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsUnknown - optional",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 611,
   sizeof(CmSdpMedFmtUnknownList),
   CM_ABNF_OPTIONAL | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedOptProtoFmtsUnknownSeq,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMedProtoFmtsSkipRng = {1, 1};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsSkip =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsSkip",
   "CM_RHyphen",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 612,
   sizeof(((CmSdpMedProtoFmts *)0)->u),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   (U8 *)&cmMsgDefSdpMedProtoFmtsSkipRng,
   cmAbnfRegExpHyphen
};

#ifdef CM_SDP_SIP_IM_SUPPORT
extern CmAbnfElmDef soMsgDefAddrSpec;
PUBLIC CmAbnfElmDef *cmMsgDefSdpSipUrlArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &soMsgDefAddrSpec
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpSipUrlArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpSipUrlArraySeqOfElmnt,
   sizeof(CmSdpU8OrNil)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSipUrlArray =
{
#ifdef CM_ABNF_DBG
   "SDP SipUrlArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 613,
   sizeof(CmSdpMedFmtSipList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpSipUrlArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsSipParmsSeqElmnt[] =
{
   &soMsgDefAddrSpec,
   &cmMsgDefSdpSipUrlArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsSipParmsSeq =
{
   2,
   cmMsgDefSdpMedProtoFmtsSipParmsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsSipParms =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsSipParms",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 614,
   sizeof(CmSdpMedFmtSipList),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsSipParmsSeq,
   NULLP
};
#endif /* CM_SDP_SIP_IM_SUPPORT */

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpDecU8OrNullArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecU8OrNull
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpDecU8OrNullArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpDecU8OrNullArraySeqOfElmnt,
   sizeof(CmSdpU8OrNil)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecU8OrNullArray =
{
#ifdef CM_ABNF_DBG
   "SDP DecU8OrNullArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 613,
   sizeof(CmSdpMedFmtAalxList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpDecU8OrNullArraySeqOf,
   /* 001.main_7: changed the regular expression. 
      Previously was cmAbnfRegExpSpace */
   cmSdpRegExpSpaceU8OrNull
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsGenIntsSeqElmnt[] =
{
   &cmMsgDefSdpDecU8OrNull,
   &cmMsgDefSdpDecU8OrNullArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsGenIntsSeq =
{
   2,
   cmMsgDefSdpMedProtoFmtsGenIntsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsGenInts =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsGenInts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 614,
   sizeof(CmSdpMedFmtAalxList),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsGenIntsSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecUcharArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpDecUcharArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpDecUcharArraySeqOfElmnt,
   sizeof(TknU8)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecUcharArray =
{
#ifdef CM_ABNF_DBG
   "SDP DecUcharArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 615,
   sizeof(CmSdpMedFmtRtpList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpDecUcharArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsDecIntsSeqElmnt[] =
{
   &cmMsgDefSdpDecUchar,
   &cmMsgDefSdpDecUcharArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsDecIntsSeq =
{
   2,
   cmMsgDefSdpMedProtoFmtsDecIntsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsDecInts =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsDecInts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 616,
   sizeof(CmSdpMedFmtRtpList),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsDecIntsSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUnknownListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUnknown,
   &cmMsgDefSdpMedProtoUnknownStr,
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUnknownListSeq =
{
   3,
   cmMsgDefSdpMedProtoUnknownListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUnknownList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUnknownList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 617,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUnknownListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUdpListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUdp,
   &cmMsgDefSdpMedProtoUdpStr,
   /* mg004.main_7: changed &cmMsgDefSdpMedProtoFmtsDecInts */
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUdpListSeq =
{
   3,
   cmMsgDefSdpMedProtoUdpListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdpList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdpList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 618,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUdpListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoTcpListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoTcp,
   &cmMsgDefSdpMedProtoTcpStr,
   /* mg004.main_7: changed &cmMsgDefSdpMedProtoFmtsDecInts */
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoTcpListSeq =
{
   3,
   cmMsgDefSdpMedProtoTcpListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoTcpList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoTcpList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 619,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoTcpListSeq,
   NULLP
};
/* 002.main_2 additions */


PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsDlr=
{
#ifdef CM_ABNF_DBG
   "SDP: FMTS $",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 739,
   sizeof(CmSdpMedFmtRtpList) - sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SKIP,
   NULLP,
   cmAbnfRegExpDollar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsDlrOrDecIntsEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpSpec 
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsDlrOrDecIntsElmnt[] =
{
   &cmMsgDefSdpMedProtoFmtsDlr,
   &cmMsgDefSdpMedProtoFmtsDecInts
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMedProtoFmtsDlrOrDecIntsChc=
{
   2,
   0,
   NULLP,
   cmMsgDefSdpMedProtoFmtsDlrOrDecIntsElmnt,
   cmMsgDefSdpMedProtoFmtsDlrOrDecIntsEnum,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsDlrOrDecInts  =
{
#ifdef CM_ABNF_DBG
   "SDP DecInt or Dollar",
   "SDP DecInt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 740,
   sizeof(CmSdpEncName),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMedProtoFmtsDlrOrDecIntsChc,
   cmSdpRegExpGenUintOrDollar
};



/* 001.main_14: changes to support "$" as the rtpmap in the
 *              "a=rtpmap:$" attribute */

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMetaDollarStr =  {(Data *) ""};

PUBLIC CmAbnfElmDef cmMsgDefSdpMetaDollar =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP MED PROTO SAP SDP META STR ",
    "MedProtoSapSdp",
#endif
    CM_ABNF_ELMNID_SDP_BASE + 799,
    0,
    (CM_ABNF_MANDATORY),
    CM_ABNF_TYPE_META,
    (U8 *)&cmMsgDefSdpMetaDollarStr,
    cmAbnfRegExpDollar
};




PUBLIC CmAbnfElmDef *cmMsgDefSdpDecUcharOrDlrEnum[] =
{
   &cmMsgDefSdpDollar,
   &cmMsgDefSdpSpec 
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpDecUcharOrDlrElmnt[] =
{
   &cmMsgDefSdpMetaDollar,
   &cmMsgDefSdpDecUchar
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpDecUcharOrDlrChc=
{
   2,
   0,
   NULLP,
   cmMsgDefSdpDecUcharOrDlrElmnt,
   cmMsgDefSdpDecUcharOrDlrEnum,
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecUcharOrDlr  =
{
#ifdef CM_ABNF_DBG
   "SDP DecInt or Dollar",
   "SDP DecInt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 740,
   sizeof(CmSdpU8OrNil),
   (CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED),
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpDecUcharOrDlrChc,
   cmSdpRegExpGenUintOrDollar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpDecUcharOrDlrArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpDecUcharOrDlr
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpDecUcharOrDlrArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpDecUcharOrDlrArraySeqOfElmnt,
   sizeof(CmSdpU8OrNil)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpDecUcharOrDlrArray =
{
#ifdef CM_ABNF_DBG
   "SDP DecUcharArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 615,
   sizeof(CmSdpMedFmtRtpList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpDecUcharOrDlrArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecIntsSeqElmnt[] =
{
   &cmMsgDefSdpDecUcharOrDlr,
   &cmMsgDefSdpDecUcharOrDlrArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecIntsSeq =
{
   2,
   cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecIntsSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecInts =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsLstOfDlrOrDecInts",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 616,
   sizeof(CmSdpMedFmtRtpList),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecIntsSeq,
   NULLP
};





PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoRtpListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoRtp,
   &cmMsgDefSdpMedProtoRtpStr,
   &cmMsgDefMetaSpace,
/* 002.main_2 Changed; it was cmMsgDefSdpMedProtoFmtsDecInts */
   /* &cmMsgDefSdpMedProtoFmtsDlrOrDecInts        */
   /* 001.main_14: Changed above to the following */
   &cmMsgDefSdpMedProtoFmtsLstOfDlrOrDecInts
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoRtpListSeq =
{
   4,
   cmMsgDefSdpMedProtoRtpListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoRtpList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoRtpList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 620,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoRtpListSeq,
   NULLP
};

/* 003.main_2 addition */
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoLclListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoLcl,
   &cmMsgDefSdpMedProtoLclStr,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsDlrOrDecInts  
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoLclListSeq =
{
   4,
   cmMsgDefSdpMedProtoLclListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoLclList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoLclList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 750,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoLclListSeq,
   NULLP
};

#ifdef CM_SDP_V_3
/* 001.main_7: additions for Udptl formats */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUdptlFmtRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpUnknownUdptlFmt =
{
#ifdef CM_ABNF_DBG
   "SDP Unknown Udptl Fmt",
   "RegExpAlDgChar",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1029,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpUdptlFmtRng,
   cmAbnfRegExpAlDgChar
 /*  cmSdpRegExpR3 */
};

PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpT38FmtEnum =
{
   (Data *)"t38",
   CM_SDP_UDPTL_FMT_T38
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpT38FmtEnumDef =
{
#ifdef CM_ABNF_DBG
   "SDP: SDP Udptl T38 Fmt ENUM DEF",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_SDP_BASE + 1028,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *) &cmMsgDefSdpT38FmtEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum  cmMsgDefSdpUnknownUdptlFmtEnum =
{
   NULLP,
   CM_SDP_UDPTL_FMT_UNKNOWN
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpUnknownUdptlFmtEnumDef =
{
#ifdef CM_ABNF_DBG
   "SDP: SDP Udptl Unknown Fmt ENUM DEF",
   "EMPTY",
#endif
   CM_ABNF_ELMNID_SDP_BASE + 1027,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *) &cmMsgDefSdpUnknownUdptlFmtEnum,
   NULLP
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpT38FmtChcEnum[] =
{
   &cmMsgDefSdpUnknownUdptlFmtEnumDef,
   &cmMsgDefSdpT38FmtEnumDef
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpT38FmtChcElmnt[] = 
{
   &cmMsgDefSdpUnknownUdptlFmt,
   NULLP
};

PUBLIC CmAbnfElmTypeChoice  cmMsgDefSdpT38FmtChc =
{
   2,
   0,
   NULLP,
   cmMsgDefSdpT38FmtChcElmnt,
   cmMsgDefSdpT38FmtChcEnum
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpT38Fmt =
{
#ifdef  CM_ABNF_DBG
    "SDP: T38 Fmt" ,
    "cmSdpRegExpUdptlT38Fmt" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 1026 ,
    sizeof(CmSdpT38Fmt),
    (CM_ABNF_MANDATORY),
    CM_ABNF_TYPE_CHOICE,
    (U8 *) &cmMsgDefSdpT38FmtChc ,
    cmSdpRegExpUdptlT38Fmt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpT38FmtArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpT38Fmt
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpT38FmtArraySeqOf =
{
   0,
   CM_SDP_MAX_FMTS,
   2,
   cmMsgDefSdpT38FmtArraySeqOfElmnt,
   sizeof(CmSdpT38Fmt)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpT38FmtArray =
{
#ifdef CM_ABNF_DBG
   "SDP T38FmtArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1025,
   sizeof(CmSdpMedFmtUdptlList),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpT38FmtArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFmtsUdptlT38SeqElmnt[] =
{
   &cmMsgDefSdpT38Fmt,
   &cmMsgDefSdpT38FmtArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFmtsUdptlT38Seq =
{
   2,
   cmMsgDefSdpMedProtoFmtsUdptlT38SeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFmtsUdptlT38 =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFmtsUdptlT38",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1024,
   sizeof(CmSdpMedFmtUdptlList),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMedProtoFmtsUdptlT38Seq,
   NULLP
};
/*
  * Note: In event struct CmSdpMedProtoFmts no additional field of union is
  * added for SDP as paramter type since its implicit from protType as SAP type
*/

PUBLIC CmAbnfElmTypeMeta  cmMsgDefSdpMedProtoSapSdpMetaStrMeta =  {  (Data *) "sdp"  };

PUBLIC CmAbnfElmDef  cmMsgDefSdpMedProtoSapSdpMetaStr =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP MED PROTO SAP SDP META STR " ,
    "MedProtoSapSdp" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 799 ,
    0 ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_META ,
    (U8 *) &cmMsgDefSdpMedProtoSapSdpMetaStrMeta ,
    cmSdpRegExpMedProtoSapSdp
};

PUBLIC CmAbnfElmDef  *cmMsgDefSdpMedProtoSapSdpSeqElmnts[] =
{
    &cmMsgDefSdpMedProtoSap ,
    &cmMsgDefSdpMedProtoSapStr ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpMedProtoSapSdpMetaStr
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpMedProtoSapSdpSeq =
{
    4 ,
    cmMsgDefSdpMedProtoSapSdpSeqElmnts
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpMedProtoSapSdp =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP MED PROTO SAP SDP " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 800 ,
    sizeof(CmSdpMedProtoFmts) - sizeof(TknU8) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_OPTSEQ ,
    (U8 *) &cmMsgDefSdpMedProtoSapSdpSeq ,
    NULLP
};

/* 001.main_7: Added UdptlList */
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoUdptlListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoUdptl,
   &cmMsgDefSdpMedProtoUdptlStr,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsUdptlT38    
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoUdptlListSeq =
{
   4,
   cmMsgDefSdpMedProtoUdptlListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoUdptlList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoUdptlList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 1020,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoUdptlListSeq,
   NULLP
};
#endif /* CM_SDP_V_3 */

#ifdef CM_SDP_SIP_IM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoSipListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoSip,
   &cmMsgDefSdpMedProtoSipStr,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsSipParms
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoSipListSeq =
{
   4,
   cmMsgDefSdpMedProtoSipListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoSipList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoSipList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 750,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoSipListSeq,
   NULLP
};
#endif /* CM_SDP_SIP_IM_SUPPORT */

#ifdef CM_SDP_ATM_SUPPORT
PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal1ListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal1,
   &cmMsgDefSdpMedProtoAal1Str,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsGenInts,
   &cmMsgDefOptMetaSpace   /* 003.main_7; added to allow optional space */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal1ListSeq =
{
   5,
   cmMsgDefSdpMedProtoAal1ListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal1List =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal1List",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 621,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal1ListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal2ListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal2,
   &cmMsgDefSdpMedProtoAal2Str,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsGenInts,
   &cmMsgDefOptMetaSpace   /* 003.main_7; added to allow optional space */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal2ListSeq =
{
   5,
   cmMsgDefSdpMedProtoAal2ListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal2List =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal2List",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 622,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal2ListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoAal5ListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoAal5,
   &cmMsgDefSdpMedProtoAal5Str,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMedProtoFmtsGenInts,
   &cmMsgDefOptMetaSpace   /* 003.main_7; added to allow optional space */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoAal5ListSeq =
{
   5,
   cmMsgDefSdpMedProtoAal5ListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoAal5List =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoAal5List",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 623,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoAal5ListSeq,
   NULLP
};
#endif /* CM_SDP_ATM_SUPPORT */

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoVoiceListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoVoice,
   &cmMsgDefSdpMedProtoVoiceStr,
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoVoiceListSeq =
{
   3,
   cmMsgDefSdpMedProtoVoiceListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoVoiceList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoVoiceList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 624,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoVoiceListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoFaxListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoFax,
   &cmMsgDefSdpMedProtoFaxStr,
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoFaxListSeq =
{
   3,
   cmMsgDefSdpMedProtoFaxListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoFaxList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoFaxList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 625,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoFaxListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoPagerListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoPager,
   &cmMsgDefSdpMedProtoPagerStr,
   &cmMsgDefSdpMedOptProtoFmtsUnknown
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoPagerListSeq =
{
   3,
   cmMsgDefSdpMedProtoPagerListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoPagerList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoPagerList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 626,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoPagerListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoH323cListSeqElmnt[] =
{
   &cmMsgDefSdpMedProtoH323c,
   &cmMsgDefSdpMedProtoH323cStr,
   &cmMsgDefMetaSpace,
   &cmMsgDefMetaHyphen,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMedProtoH323cListSeq =
{
   4,
   cmMsgDefSdpMedProtoH323cListSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedProtoH323cList =
{
#ifdef CM_ABNF_DBG
   "SDP MedProtoH323cList",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 627,
   sizeof(CmSdpMedProtoFmts) - sizeof(TknU8),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpMedProtoH323cListSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaProtoFmtListChcElmnt[] =
{
   &cmMsgDefSdpMedProtoUnknownList,
   &cmMsgDefSdpMedProtoUdpList,
   &cmMsgDefSdpMedProtoRtpList,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpMedProtoAal1List,
   &cmMsgDefSdpMedProtoAal2List,
   &cmMsgDefSdpMedProtoAal5List,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
   NULLP,
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpMedProtoH323cList,
   &cmMsgDefSdpMedProtoVoiceList,
   &cmMsgDefSdpMedProtoFaxList,
   &cmMsgDefSdpMedProtoPagerList,
   &cmMsgDefSdpMedProtoTcpList,
   &cmMsgDefSdpMedProtoLclList   /* 003.main_2 Addition */
#ifdef CM_SDP_V_3
#ifdef CM_SDP_SIP_IM_SUPPORT 
   , &cmMsgDefSdpMedProtoSapSdp,
/* 001.main_7: incremented to include "udptl" */
   &cmMsgDefSdpMedProtoUdptlList,
   &cmMsgDefSdpMedProtoSipList
#else
   , &cmMsgDefSdpMedProtoSapSdp,
/* 001.main_7: incremented to include "udptl" */
   &cmMsgDefSdpMedProtoUdptlList
#endif /* CM_SDP_IM_SUPPORT */
#else
#ifdef CM_SDP_SIP_IM_SUPPORT 
   , NULLP,
   NULLP,
   &cmMsgDefSdpMedProtoSipList
#endif /* CM_SDP_IM_SUPPORT */
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaProtoFmtListChc =
{
#ifdef CM_SDP_V_3
#ifdef CM_SDP_SIP_IM_SUPPORT
   15,
#else
   14,
#endif /* CM_SDP_IM_SUPPORT */
#else
#ifdef CM_SDP_SIP_IM_SUPPORT
   15,
#else 
   12,   /* 003.main_2 changed from 11 to 12 */
#endif /* CM_SDP_SIP_IM_SUPPORT */
#endif
   0,
   NULLP,
   cmMsgDefSdpMediaProtoFmtListChcElmnt,
   cmMsgDefSdpMedProtoChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaProtoFmtList =
{
#ifdef CM_ABNF_DBG
   "SDP MediaProtoFmtList",
   "SDPMedProto",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 628,
   sizeof(CmSdpMedProtoFmts),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaProtoFmtListChc,
   cmSdpRegExpMedProto
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaProtoFmtListArraySeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaProtoFmtList
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpMediaProtoFmtListArraySeqOf =
{
   0,
   CM_SDP_MAX_PROTFMTLISTS,
   2,
   cmMsgDefSdpMediaProtoFmtListArraySeqOfElmnt,
   sizeof(CmSdpMedProtoFmts)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaProtoFmtListArray =
{
#ifdef CM_ABNF_DBG
   "SDP ProtoFmtListArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 629,
   sizeof(CmSdpMedPar),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpMediaProtoFmtListArraySeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaParSeqElmnt[] =
{
   &cmMsgDefSdpMediaProtoFmtList,
   &cmMsgDefSdpMediaProtoFmtListArray
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaParSeq =
{
   2,
   cmMsgDefSdpMediaParSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaPar =
{
#ifdef CM_ABNF_DBG
   "SDP MediaPar",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 630,
   sizeof(CmSdpMedPar),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMediaParSeq,
   NULLP
};


/************************************************************************
                              SDP Media descriptor set
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaFieldSeqElmnt[] =
{
   &cmMsgDefSdpMediaStr,
   &cmMsgDefSdpMediaNotConsumed,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpVcId,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaPar,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaFieldSeq =
{
   7,
   cmMsgDefSdpMediaFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaField =
{
#ifdef CM_ABNF_DBG
   "SDP: MDFIELD ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 631,
   sizeof(CmSdpMediaField),
   0,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpMediaFieldSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnSetSeqOfElmnt[] =
{
   &cmMsgDefSdpConn
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpConnSetSeqOf =
{
   0,
   CM_SDP_MAX_CONN,
   1,
   cmMsgDefSdpConnSetSeqOfElmnt,
   sizeof(CmSdpConn)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnSet =
{
#ifdef CM_ABNF_DBG
   "SDP: CONNSET",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 632,
   sizeof(CmSdpConnSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpConnSetSeqOf,
   cmSdpRegExpR16
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaDescSeqElmnt[] =
{
   &cmMsgDefSdpMediaField,
   &cmMsgDefSdpInfo,
   &cmMsgDefSdpConnSet,
   &cmMsgDefSdpBWSet,
   &cmMsgDefSdpKey,
   &cmMsgDefSdpAttrSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaDescSeq =
{
   6,
   cmMsgDefSdpMediaDescSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaDesc =
{
#ifdef CM_ABNF_DBG
   "SDP: MDESC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 633,
   sizeof(CmSdpMediaDesc),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpMediaDescSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaDescSetSeqOfElmnt[] =
{
   &cmMsgDefSdpMediaDesc,
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpMediaDescSetSeqOf =
{
   0,
   CM_SDP_MAX_UNKNOWN,
   1,
   cmMsgDefSdpMediaDescSetSeqOfElmnt,
   sizeof(CmSdpMediaDesc)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaDescSet =
{
#ifdef CM_ABNF_DBG
   "SDP: MDESC",
   "SDPR29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 634,
   sizeof(CmSdpMediaDescSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpMediaDescSetSeqOf,
   cmSdpRegExpR29
};

/************************************************************************
                              SDP Message
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpSeqElmnt[] =
{
   &cmMsgDefSdpVer,
   &cmMsgDefSdpOrig,
   &cmMsgDefSdpSesName,
   &cmMsgDefSdpInfo,
   &cmMsgDefSdpUri,
   &cmMsgDefSdpEmailSet,
   &cmMsgDefSdpPhoneSet,
   &cmMsgDefSdpConn,
   &cmMsgDefSdpBWSet,
   &cmMsgDefSdpTime,
   &cmMsgDefSdpKey,
   &cmMsgDefSdpAttrSet,
   &cmMsgDefSdpMediaDescSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSeq =
{
   13,
   cmMsgDefSdpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdp =
{
#ifdef CM_ABNF_DBG
   "SDP: Msg",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 635,
   sizeof(CmSdpInfo),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpSeq,
   NULLP
};

/************************************************************************
                                 SDP info set
*************************************************************************/

PUBLIC CmAbnfElmDef *cmMsgDefSdpInfoSetSeqOfElmnt[] =
{
   &cmMsgDefSdp
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpInfoSetSeqOf =
{
   0,      /* 001.main_14: made 0 so that this is ignored for optional SDP */
   CM_SDP_MAX_SZ,
   1,
   cmMsgDefSdpInfoSetSeqOfElmnt,
   sizeof(CmSdpInfo)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInfoSet =
{
#ifdef CM_ABNF_DBG
   "SDP: MSGSET",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 636,
   sizeof(CmSdpInfoSet),
   /* 001.main_14: made optional */
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL),
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpInfoSetSeqOf,
   cmSdpRegExpXEq     /* 002.main2; changed , it was cmSdpRegExpR1 */
};





/*
* **********************************************
* 001.main_7 : Addition - Old MGTIFVER V1 Database Begins
*/

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaChcEnum_V1[] =
{
   NULLP,
   &cmMsgDefSdpMediaAudio,
   &cmMsgDefSdpMediaVideo,
   &cmMsgDefSdpMediaData,
   &cmMsgDefSdpMediaApp,
   &cmMsgDefSdpMediaControl
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaChcElmnt_V1[] =
{
   &cmMsgDefSdpMediaSkipName
};

PUBLIC U8 cmMsgDefSdpMediaChcIdx_V1[] = {0, 0, 0, 0, 0, 0};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaChc_V1 =
{
   1,
   6,
   cmMsgDefSdpMediaChcIdx_V1,
   cmMsgDefSdpMediaChcElmnt_V1,
   cmMsgDefSdpMediaChcEnum_V1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedia_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA ",
   "SDPR30",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 551,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaChc_V1,
   cmSdpRegExpR30_V1
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaNotConsumedChcElmnt_V1[] =
{
   &cmMsgDefSdpMediaUnknown,
   &cmMsgDefSdpMedia_V1
};

PUBLIC U8 cmMsgDefSdpMediaNotConsumedChcIdx_V1[] = 
                                      {0, 1, 1, 1, 1, 1};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaNotConsumedChc_V1 =
{
   2,
   6,
   cmMsgDefSdpMediaNotConsumedChcIdx_V1,
   cmMsgDefSdpMediaNotConsumedChcElmnt_V1,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaNotConsumed_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA known/unknown",
   "SDPR30",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 554,
   sizeof(TknU8) + sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaNotConsumedChc_V1,
   cmSdpRegExpR30_V1
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpMedProtoChcEnum_V1[] =
{
   &cmMsgDefSdpMedProtoUnknownStr,
   &cmMsgDefSdpMedProtoUdpStr,
   &cmMsgDefSdpMedProtoRtpStr,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpMedProtoAal1Str,
   &cmMsgDefSdpMedProtoAal2Str,
   &cmMsgDefSdpMedProtoAal5Str,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP, NULLP, NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpMedProtoH323cStr,
   &cmMsgDefSdpMedProtoVoiceStr,
   &cmMsgDefSdpMedProtoFaxStr,
   &cmMsgDefSdpMedProtoPagerStr,
   &cmMsgDefSdpMedProtoTcpStr,
   &cmMsgDefSdpMedProtoLclStr,     /*003.main_2 addition */
#ifdef CM_SDP_V_3
 /*  NULLP  */
   &cmMsgDefSdpMedProtoSapStr
#endif
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaProtoFmtListChcElmnt_V1[] =
{
   &cmMsgDefSdpMedProtoUnknownList,
   &cmMsgDefSdpMedProtoUdpList,
   &cmMsgDefSdpMedProtoRtpList,
#ifdef CM_SDP_ATM_SUPPORT
   &cmMsgDefSdpMedProtoAal1List,
   &cmMsgDefSdpMedProtoAal2List,
   &cmMsgDefSdpMedProtoAal5List,
#else /* !CM_SDP_ATM_SUPPORT */
   NULLP,
   NULLP,
   NULLP,
#endif /* CM_SDP_ATM_SUPPORT */
   &cmMsgDefSdpMedProtoH323cList,
   &cmMsgDefSdpMedProtoVoiceList,
   &cmMsgDefSdpMedProtoFaxList,
   &cmMsgDefSdpMedProtoPagerList,
   &cmMsgDefSdpMedProtoTcpList,
   &cmMsgDefSdpMedProtoLclList,   /* 003.main_2 Addition */
#ifdef CM_SDP_V_3
   &cmMsgDefSdpMedProtoSapSdp
#endif
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaProtoFmtListChc_V1 =
{
#ifdef CM_SDP_V_3
   13,
#else
   12,   /* 003.main_2 changed from 11 to 12 */
#endif
   0,
   NULLP,
   cmMsgDefSdpMediaProtoFmtListChcElmnt_V1,
   cmMsgDefSdpMedProtoChcEnum_V1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaProtoFmtList_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP MediaProtoFmtList",
   "SDPMedProto",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 628,
   sizeof(CmSdpMedProtoFmts),
   CM_ABNF_MANDATORY | CM_ABNF_TKN_NOT_CONSUMED,
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaProtoFmtListChc_V1,
   cmSdpRegExpMedProto_V1
};


PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaProtoFmtListArraySeqOfElmnt_V1[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaProtoFmtList_V1
};

PUBLIC CmAbnfElmTypeSeqOf 
                   cmMsgDefSdpMediaProtoFmtListArraySeqOf_V1 =
{
   0,
   CM_SDP_MAX_PROTFMTLISTS,
   2,
   cmMsgDefSdpMediaProtoFmtListArraySeqOfElmnt_V1,
   sizeof(CmSdpMedProtoFmts)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaProtoFmtListArray_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP ProtoFmtListArray",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 629,
   sizeof(CmSdpMedPar),
   CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpMediaProtoFmtListArraySeqOf_V1,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaParSeqElmnt_V1[] =
{
   &cmMsgDefSdpMediaProtoFmtList_V1,
   &cmMsgDefSdpMediaProtoFmtListArray_V1
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaParSeq_V1 =
{
   2,
   cmMsgDefSdpMediaParSeqElmnt_V1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaPar_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP MediaPar",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 630,
   sizeof(CmSdpMedPar),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpMediaParSeq_V1,
   NULLP
};


#ifdef CM_SDP_V_3
PUBLIC CmAbnfElmDef  *cmMsgDefSdpAttrCdscSeqElmnts_V1[] =
{
    &cmMsgDefSdpAttrCdscCapNum ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpMediaNotConsumed_V1 ,
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpVcId ,              /* forward referencing */
    &cmMsgDefMetaSpace ,
    &cmMsgDefSdpMediaPar_V1 ,       /* forward referencing */
};

PUBLIC CmAbnfElmTypeSeq  cmMsgDefSdpAttrCdscSeq_V1 =
{
    7 ,
    cmMsgDefSdpAttrCdscSeqElmnts_V1
};

PUBLIC CmAbnfElmDef  cmMsgDefSdpAttrCdsc_V1 =
{
#ifdef  CM_ABNF_DBG
    "SDP: SDP ATTR CDSC " ,
    "EMPTY" ,
#endif
    CM_ABNF_ELMNID_SDP_BASE + 795 ,
/*
 * new CmSdpAttrCapDesc has no CmSdpVcId
 */
    sizeof(CmSdpAttrCapDesc) + sizeof(CmSdpVcId) ,
    ( CM_ABNF_MANDATORY ) ,
    CM_ABNF_TYPE_SEQ ,
    (U8 *) &cmMsgDefSdpAttrCdscSeq_V1 ,
    NULLP
};
#endif /* CM_SDP_V_3 */



PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaFieldSeqElmnt_V1[] =
{
   &cmMsgDefSdpMediaStr,
   &cmMsgDefSdpMediaNotConsumed_V1,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpVcId,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaPar_V1,
   &cmMsgDefMetaEOL
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaFieldSeq_V1 =
{
   7,
   cmMsgDefSdpMediaFieldSeqElmnt_V1
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaField_V1 =
{
#ifdef CM_ABNF_DBG
   "SDP: MDFIELD ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 631,
   sizeof(CmSdpMediaField),
   0,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpMediaFieldSeq_V1,
   NULLP
};
/*
 * **********************************************
 * Old MGTIFVER V1 Database ends
 */






#else /* CM_SDP_V_2 not defined */
/* Database for SDP v.1. For SDP v.2 see corresponding above. */

/************************************************************************
                              SDP Version
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpVerStrMeta = {(Data *)"v="};
PUBLIC CmAbnfElmDef cmMsgDefSdpVerStr =
{
#ifdef CM_ABNF_DBG
   "SDP VERSTR",
   "SDPR1",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 637,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpVerStrMeta,
   cmSdpRegExpR1
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpVerValRng = {1, 1, 0, 9};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpVerValRng = { 1, 1};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpVerVal =
{
#ifdef CM_ABNF_DBG
   "SDP VERVAL",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 638,
   sizeof(TknU16),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpVerValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpVerSeqElmnt[] =
{
   &cmMsgDefSdpVerStr,
   &cmMsgDefSdpVerVal,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpVerSeq =
{
   3,
   cmMsgDefSdpVerSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpVer =
{
#ifdef CM_ABNF_DBG
   "SDP VER",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 639,
   sizeof(TknU16),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpVerSeq,
   NULLP
};

/************************************************************************
                              SDP Origin Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpOrigStrMeta = {(Data *)"o="};
PUBLIC CmAbnfElmDef cmMsgDefSdpOrigStr =
{
#ifdef CM_ABNF_DBG
   "SDP ORGNSTR",
   "SDPR2",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 640,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpOrigStrMeta,
   cmSdpRegExpR2
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUsrNameRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpUsrName =
{
#ifdef CM_ABNF_DBG
   "SDP USRNAME",
   "SDPR3",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 641,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpUsrNameRng,
   cmSdpRegExpR3
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSsIdRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpSsId =
{
#ifdef CM_ABNF_DBG
   "SDP SSID",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 642,
   sizeof(TknU32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpSsIdRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpSsVerRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpSsVer =
{
#ifdef CM_ABNF_DBG
   "SDP SSVER",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 643,
   sizeof(TknU32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpSsVerRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpNetTypeINStrEnum =
{
   (Data *)"IN",
   CM_SDP_NET_TYPE_IN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetTypeINStr =
{
#ifdef CM_ABNF_DBG
   "SDP INSTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 644,
   sizeof(TknU8),
   0, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpNetTypeINStrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpNetTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpNetTypeINStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpNetTypeChc =
{
   2,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpNetTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpNetType =
{
#ifdef CM_ABNF_DBG
   "SDP NETTP",
   "SDPR4",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 645,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpNetTypeChc,
   cmSdpRegExpR4
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeIP6StrEnum =
{
   (Data *)"IP6",
   CM_SDP_ADDR_TYPE_IPV6
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeIP6Str =
{
#ifdef CM_ABNF_DBG
   "SDP IP6STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 646,
   sizeof(TknU8),
   0, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeIP6StrEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpAddrTypeIP4StrEnum =
{
   (Data *)"IP4",
   CM_SDP_ADDR_TYPE_IPV4
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrTypeIP4Str =
{
#ifdef CM_ABNF_DBG
   "SDP IP4STR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 647,
   sizeof(TknU8),
   0, 
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpAddrTypeIP4StrEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAddrTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpAddrTypeIP4Str,
   &cmMsgDefSdpAddrTypeIP6Str
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpAddrTypeChc =
{
   3,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpAddrTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAddrType =
{
#ifdef CM_ABNF_DBG
   "SDP ADDRTP",
   "SDPR5",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 648,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpAddrTypeChc,
   cmSdpRegExpR5
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAddrRng = {4, 0xFFFF}; 

PUBLIC CmAbnfElmDef cmMsgDefSdpAddr =
{
#ifdef CM_ABNF_DBG
   "SDP ADDR",
   "SDPR6",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 649,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAddrRng,
   cmSdpRegExpR6
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOrigSeqElmnt[] =
{
   &cmMsgDefSdpOrigStr,
   &cmMsgDefSdpUsrName,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpSsId,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpSsVer,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpNetType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAddrType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAddr,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOrigSeq =
{
   13,
   cmMsgDefSdpOrigSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOrig =
{
#ifdef CM_ABNF_DBG
   "SDP: ORGN3",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 650,
   sizeof(CmSdpOrig),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpOrigSeq,
   NULLP
};

/************************************************************************
                              SDP Sesssion Name Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpSesNameStrMeta = {(Data *)"s="};
PUBLIC CmAbnfElmDef cmMsgDefSdpSesNameStr =
{
#ifdef CM_ABNF_DBG
   "SDP SSNNMSTR",
   "SDPR7",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 651,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpSesNameStrMeta,
   cmSdpRegExpR7
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTextRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpText =
{
#ifdef CM_ABNF_DBG
   "SDP TEXT",
   "SDPR8",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 652,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpTextRng,
   cmSdpRegExpR8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpSesNameSeqElmnt[] =
{
   &cmMsgDefSdpSesNameStr,
   &cmMsgDefSdpText,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSesNameSeq =
{
   3,
   cmMsgDefSdpSesNameSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpSesName =
{
#ifdef CM_ABNF_DBG
   "SDP: SSNNM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 653,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpSesNameSeq,
   NULLP
};

/************************************************************************
                              SDP Information Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpInfoStrMeta = {(Data *)"i="};
PUBLIC CmAbnfElmDef cmMsgDefSdpInfoStr =
{
#ifdef CM_ABNF_DBG
   "SDP INFOSTR ",
   "SDPR9",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 654,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpInfoStrMeta,
   cmSdpRegExpR9
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInfoSeqElmnt[] =
{
   &cmMsgDefSdpInfoStr,
   &cmMsgDefSdpText,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpInfoSeq =
{
   3,
   cmMsgDefSdpInfoSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInfo =
{
#ifdef CM_ABNF_DBG
   "SDP: INFO ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 655,
   sizeof(TknStrOSXL),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpInfoSeq,
   cmSdpRegExpR9
};

/************************************************************************
                              SDP URI Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpUriStrMeta = {(Data *)"u="};
PUBLIC CmAbnfElmDef cmMsgDefSdpUriStr =
{
#ifdef CM_ABNF_DBG
   "SDP URISTR ",
   "SDPR10",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 656,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpUriStrMeta,
   cmSdpRegExpR10 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpUriValRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpUriVal =
{
#ifdef CM_ABNF_DBG
   "SDP URI",
   "SDPR11",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 657,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpUriValRng,
   cmSdpRegExpR11
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpUriSeqElmnt[] =
{
   &cmMsgDefSdpUriStr,
   &cmMsgDefSdpUriVal,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpUriSeq =
{
   3,
   cmMsgDefSdpUriSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpUri =
{
#ifdef CM_ABNF_DBG
   "SDP: URI ",
   "SDPR10",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 658,
   sizeof(TknStrOSXL),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpUriSeq,
   cmSdpRegExpR10 
};

/************************************************************************
                              SDP Email Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpEmailStrMeta = {(Data *)"e="};
PUBLIC CmAbnfElmDef cmMsgDefSdpEmailStr =
{
#ifdef CM_ABNF_DBG
   "SDP EMLSTR ",
   "SDPR12",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 659,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpEmailStrMeta,
   cmSdpRegExpR12
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpEmailAddrRng = {1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailAddr =
{
#ifdef CM_ABNF_DBG
   "SDP EMLADDR ",
   "SDPR13",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 660,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpEmailAddrRng,
   cmSdpRegExpR13
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpEmailSetSeqOfElmnt[] =
{
   &cmMsgDefSdpEmailStr,
   &cmMsgDefSdpEmailAddr,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpEmailSetSeqOf =
{
   /* cm_sdpdb_c_001.101 - Changed minimum number of elements from 1 to 0 */
   0,
   CM_SDP_MAX_EMAIL,
   3,
   cmMsgDefSdpEmailSetSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEmailSet =
{
#ifdef CM_ABNF_DBG
   "SDP: EMLSET ",
   "SDPR12",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 661,
   sizeof(CmSdpEmailSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpEmailSetSeqOf,
   cmSdpRegExpR12
};

/************************************************************************
                              SDP Phone Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpPhoneStrMeta = {(Data *)"p="};
PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneStr =
{
#ifdef CM_ABNF_DBG
   "SDP PHSTR ",
   "SDPR14",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 662,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpPhoneStrMeta,
   cmSdpRegExpR14 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPhoneRng = { 2, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhone =
{
#ifdef CM_ABNF_DBG
   "SDP PHONE ",
   "R15",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 663,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpPhoneRng,
   cmSdpRegExpR15 
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPhoneSetSeqOfElmnt[] =
{
   &cmMsgDefSdpPhoneStr,
   &cmMsgDefSdpPhone,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpPhoneSetSeqOf =
{
   /* cm_sdpdb_c_001.101 - Changed minimum number of elements from 1 to 0 */
   0,
   CM_SDP_MAX_PHONE,
   3,
   cmMsgDefSdpPhoneSetSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpPhoneSet =
{
#ifdef CM_ABNF_DBG
   "SDP: PHSET ",
   "SDPR14",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 664,
   sizeof(CmSdpPhoneSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpPhoneSetSeqOf,
   cmSdpRegExpR14
};

/************************************************************************
                              SDP Connection Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta CmSdpConnStrMeta = {(Data *)"c="};
PUBLIC CmAbnfElmDef CmSdpConnStr =
{
#ifdef CM_ABNF_DBG
   "SDP CONNSTR",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 665,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&CmSdpConnStrMeta,
   cmSdpRegExpR16
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpConnAddrRng = {4, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnAddr =
{
#ifdef CM_ABNF_DBG
   "SDP CONNADDR",
   "SDPR31",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 666,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpAddrRng,
   cmSdpRegExpR31
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnFieldSeqElmnt[] =
{
   &CmSdpConnStr,
   &cmMsgDefSdpNetType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpAddrType,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpConnAddr,   
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpConnFieldSeq =
{
   7,
   cmMsgDefSdpConnFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnField =
{
#ifdef CM_ABNF_DBG
   "SDP: CONNFLD",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 667,
   sizeof(CmSdpConn),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpConnFieldSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnSeqElmnt[] =
{
   &cmMsgDefSdpConnField
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpConnSeq =
{
   1,
   cmMsgDefSdpConnSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConn =
{
#ifdef CM_ABNF_DBG
   "SDP: CONN",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 668,
   sizeof(CmSdpConn),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpConnSeq,
   cmSdpRegExpR16
};

/************************************************************************
                              SDP Band Width 
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpBWStrMeta = {(Data *)"b="};
PUBLIC CmAbnfElmDef cmMsgDefSdpBWStr =
{
#ifdef CM_ABNF_DBG
   "SDP BWSTR",
   "SDPR17",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 669,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpBWStrMeta,
   cmSdpRegExpR17 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpBwTypeRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpBwType =
{
#ifdef CM_ABNF_DBG
   "SDP BWTYPE",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 670,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpBwTypeRng,
   cmAbnfRegExpAlDgChar
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpBWidthRng = { 1, 10, 0, (U32)~0};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpBWidthRng = { 1, 10};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpBWidth =
{
#ifdef CM_ABNF_DBG
   "SDP BWTYPE",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 671,
   sizeof(TknU32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_UINT32,
   (U8 *)&cmMsgDefSdpBWidthRng,
   cmAbnfRegExpDgt 
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpBWSeqElmnt[] =
{
   &cmMsgDefSdpBWStr,
   &cmMsgDefSdpBwType,
   &cmMsgDefMetaColon,
   &cmMsgDefSdpBWidth,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpBWSeq =
{
   5,
   cmMsgDefSdpBWSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBW =
{
#ifdef CM_ABNF_DBG
   "SDP: BW",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 672,
   sizeof(CmSdpBw),
   (CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpBWSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpBWSetSeqOfElmnt[] =
{
   &cmMsgDefSdpBW
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpBWSetSeqOf =
{
   0,
   CM_SDP_MAX_BW,
   1,
   cmMsgDefSdpBWSetSeqOfElmnt,
   sizeof(CmSdpBw)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBWSet =
{
#ifdef CM_ABNF_DBG
   "SDP: BWSET",
   "SDPR17",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 673,
   sizeof(CmSdpBwSet),
   (CM_ABNF_TKN_NOT_CONSUMED |CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpBWSetSeqOf,
   cmSdpRegExpR17
};

/************************************************************************
                              SDP Time 
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpTimeStrMeta = {(Data *)"t="};
PUBLIC CmAbnfElmDef cmMsgDefSdpTimeStr =
{
#ifdef CM_ABNF_DBG
   "SDP TMSTR",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 674,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpTimeStrMeta,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitDayEnum =
{
   (Data *)"d",
   CM_SDP_TIME_UNIT_DAY
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitDay =
{
#ifdef CM_ABNF_DBG
   "SDP: TMDAY ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 675,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitDayEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitHourEnum =
{
   (Data *)"h",
   CM_SDP_TIME_UNIT_HR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitHour =
{
#ifdef CM_ABNF_DBG
   "SDP: TMHR ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 676,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitHourEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitMinEnum =
{
   (Data *)"m",
   CM_SDP_TIME_UNIT_MIN
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitMin =
{
#ifdef CM_ABNF_DBG
   "SDP: TMMIN ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 677,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitMinEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpTimeUnitSecEnum =
{
   (Data *)"s",
   CM_SDP_TIME_UNIT_SEC
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeUnitSec =
{
#ifdef CM_ABNF_DBG
   "SDP: TMSEC ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 678,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpTimeUnitSecEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeUnitChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpTimeUnitDay,
   &cmMsgDefSdpTimeUnitHour,
   &cmMsgDefSdpTimeUnitMin,
   &cmMsgDefSdpTimeUnitSec
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpTypedTimeUnitChc =
{
   5,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpTypedTimeUnitChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeUnit =
{
#ifdef CM_ABNF_DBG
   "SDP: TMUNT",
   "SDPR19",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 679,
   sizeof(TknU8),
   CM_ABNF_OPTIONAL, 
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpTypedTimeUnitChc,
   cmSdpRegExpR19
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTypedTimeValRng = { 1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeVal =
{
#ifdef CM_ABNF_DBG
   "SDP: TPTMVAL",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 680,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpTypedTimeValRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeSeqElmnt[] =
{
   &cmMsgDefSdpTypedTimeVal,
   &cmMsgDefSdpTypedTimeUnit
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTypedTimeSeq =
{
   2,
   cmMsgDefSdpTypedTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTime =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTM ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 681,
   sizeof(CmSdpTypedTime),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpTypedTimeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTypedTimeListSeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTypedTime
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpTypedTimeListSeqOf =
{
   1,
   (CM_SDP_MAX_REP_FIELD - 1),
   2,
   cmMsgDefSdpTypedTimeListSeqOfElmnt,
   sizeof(CmSdpTypedTime)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTypedTimeList =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTMSET ",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 682,
   sizeof(CmSdpTypedTimeSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpTypedTimeListSeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefRepfTypedTimeSetSeqOfElmnt[] =
{
   &cmMsgDefSdpTypedTime,
   &cmMsgDefSdpTypedTimeList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefRepfTypedTimeSetSeqOf =
{
   2,
   cmMsgDefRepfTypedTimeSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefRepfTypedTimeSet =
{
#ifdef CM_ABNF_DBG
   "SDP: TYPTMSET ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 683,
   sizeof(CmSdpTypedTimeSet),
   (CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_STA_OPTSEQOF,
   (U8 *)&cmMsgDefRepfTypedTimeSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefRepFieldStrMeta = {(Data *)"\r\nr="};
PUBLIC CmAbnfElmDef cmMsgDefRepFieldStr =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLDSTR ",
   "SDPR22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 684,
   0,
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefRepFieldStrMeta,
   cmSdpRegExpR22
};

PUBLIC CmAbnfElmDef *cmMsgDefRepFieldSeqElmnt[] =
{
   &cmMsgDefRepFieldStr,
   &cmMsgDefSdpTypedTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpTypedTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefRepfTypedTimeSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefRepFieldSeq =
{
   6,
   cmMsgDefRepFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefRepField =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLD ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 685,
   sizeof(CmSdpRepField),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefRepFieldSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefRepFieldSetSeqOfElmnt[] =
{
   &cmMsgDefRepField
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefRepFieldSetSeqOf =
{
   0,
   CM_SDP_MAX_REP_FIELD,
   1,
   cmMsgDefRepFieldSetSeqOfElmnt,
   sizeof(CmSdpRepField)
};

PUBLIC CmAbnfElmDef cmMsgDefRepFieldSet =
{
#ifdef CM_ABNF_DBG
   "SDP: RPTFLDSET",
   "SDPR22",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 686,
   sizeof(CmSdpRepFieldSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefRepFieldSetSeqOf,
   cmSdpRegExpR22
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpStTimeRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpStTime =
{
#ifdef CM_ABNF_DBG
   "SDP: STTIME",
   "SDPR21",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 687,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpStTimeRng,
   cmSdpRegExpR21
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeSeqElmnt[] =
{
   &cmMsgDefSdpTimeStr,
   &cmMsgDefSdpStTime,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpStTime,
   &cmMsgDefRepFieldSet,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOpTimeSeq =
{
   6,
   cmMsgDefSdpOpTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTime =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 688,
   sizeof(CmSdpOpTime),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpOpTimeSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeListSeqOfElmnt[] =
{
   &cmMsgDefSdpOpTime
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpOpTimeListSeqOf =
{
   0,
   CM_SDP_MAX_UNKNOWN ,
   1,
   cmMsgDefSdpOpTimeListSeqOfElmnt,
   sizeof(CmSdpOpTime)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTimeList =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTMLIST",
   "SDPR18",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 689,
   sizeof(CmSdpOpTimeSet),
   (CM_ABNF_TKN_NOT_CONSUMED |CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpOpTimeListSeqOf,
   cmSdpRegExpR18
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOpTimeSetSeqOfElmnt[] =
{
   &cmMsgDefSdpOpTime,
   &cmMsgDefSdpOpTimeList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOpTimeSetSeqOf =
{
   2,
   cmMsgDefSdpOpTimeSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOpTimeSet =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTMSET",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 690,
   sizeof(CmSdpOpTimeSet),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OPTSEQOF,
   (U8 *)&cmMsgDefSdpOpTimeSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpTimeValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpTimeVal =
{
#ifdef CM_ABNF_DBG
   "SDP: TIME",
   "SDPR20",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 691,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpTimeValRng,
   cmSdpRegExpR20
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjSeqElmnt[] =
{
   &cmMsgDefSdpTimeVal,
   &cmMsgDefMetaSpace,
   &cmMsgDefOptMetaHyphen,
   &cmMsgDefSdpTypedTime
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneAdjSeq =
{
   4,
   cmMsgDefSdpZoneAdjSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdj =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 692,
   sizeof(CmSdpZoneAdj),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpZoneAdjSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjListSeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpZoneAdj
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpZoneAdjListSeqOf =
{
   0,
   (CM_SDP_MAX_ZONE_ADJ - 1),
   2,
   cmMsgDefSdpZoneAdjListSeqOfElmnt,
   sizeof(CmSdpZoneAdj)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdjList =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTMLIST",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 693,
   sizeof(CmSdpZoneAdjSet),
   CM_ABNF_OPTIONAL, 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpZoneAdjListSeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneAdjSetSeqOfElmnt[] =
{
   &cmMsgDefSdpZoneAdj,
   &cmMsgDefSdpZoneAdjList,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneAdjSetSeqOf =
{
   2,
   cmMsgDefSdpZoneAdjSetSeqOfElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneAdjSet =
{
#ifdef CM_ABNF_DBG
   "SDP: ZNADJTMSET",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 694,
   sizeof(CmSdpZoneAdjSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_OPTSEQOF,
   (U8 *)&cmMsgDefSdpZoneAdjSetSeqOf,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpZoneOptAdjSetSeqElmnt[] =
{
   &cmMsgDefSdpZoneAdjSet,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpZoneOptAdjSetSeq =
{
   2,
   cmMsgDefSdpZoneOptAdjSetSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpZoneOptAdjSet =
{
#ifdef CM_ABNF_DBG
   "SDP: OPTADJ",
   "CM_RPOSDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 695,
   sizeof(CmSdpZoneAdjSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpZoneOptAdjSetSeq,
   cmAbnfRegExpPosDgt
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTimeSeqElmnt[] =
{
   &cmMsgDefSdpOpTimeSet,
   &cmMsgDefSdpZoneOptAdjSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTimeSeq =
{
   2,
   cmMsgDefSdpTimeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTime =
{
#ifdef CM_ABNF_DBG
   "SDP: TM",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 696,
   sizeof(CmSdpTime),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpTimeSeq,
   NULLP
};

/************************************************************************
                              SDP Key Field
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpKeyStrMeta = {(Data *)"k="};
PUBLIC CmAbnfElmDef cmMsgDefSdpKeyStr =
{
#ifdef CM_ABNF_DBG
   "SDP: KSTR",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 697,
   0, 
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpKeyStrMeta,
   cmSdpRegExpR23
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypePromptEnum =
{
   (Data *)"prompt",
   CM_SDP_KEY_TYPE_PROMPT
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypePromptStr =
{
#ifdef CM_ABNF_DBG
   "SDP: PROMPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 698,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypePromptEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeClearEnum =
{
   (Data *)"clear",
   CM_SDP_KEY_TYPE_CLEAR
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeClearStr =
{
#ifdef CM_ABNF_DBG
   "SDP: CLEAR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 699,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeClearEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeBase64Enum =
{
   (Data *)"base64",
   CM_SDP_KEY_TYPE_BASE64
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeBase64Str =
{
#ifdef CM_ABNF_DBG
   "SDP: BASE64",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 700,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeBase64Enum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpKeyTypeUriEnum =
{
   (Data *)"uri",
   CM_SDP_KEY_TYPE_URI
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeUriStr =
{
#ifdef CM_ABNF_DBG
   "SDP: URI",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 701,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpKeyTypeUriEnum,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypePrompt =
{
#ifdef CM_ABNF_DBG
   "SDP: PROMPT",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 702,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeClearRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeClear =
{
#ifdef CM_ABNF_DBG
   "SDP: CLEAR",
   "SDPR25",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 703,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeClearRng,
   cmSdpRegExpR25 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeBase64Rng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeBase64 =
{
#ifdef CM_ABNF_DBG
   "SDP: BASE64",
   "SDPR25",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 704,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeBase64Rng,
   cmSdpRegExpR25 
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpKeyTypeUriRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyTypeUri =
{
#ifdef CM_ABNF_DBG
   "SDP: URI",
   "SDPR11",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 705,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpKeyTypeUriRng,
   cmSdpRegExpR11 
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyTypeChcElmnt[] =
{
   NULLP,
   &cmMsgDefSdpKeyTypePrompt,
   &cmMsgDefSdpKeyTypeClear,
   &cmMsgDefSdpKeyTypeBase64,
   &cmMsgDefSdpKeyTypeUri
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyTypeChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpKeyTypePromptStr,
   &cmMsgDefSdpKeyTypeClearStr,
   &cmMsgDefSdpKeyTypeBase64Str,
   &cmMsgDefSdpKeyTypeUriStr
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpKeyTypeChc =
{
   5,
   0,
   NULLP,
   cmMsgDefSdpKeyTypeChcElmnt,
   cmMsgDefSdpKeyTypeChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyType =
{
#ifdef CM_ABNF_DBG
   "SDP: KTYPE",
   "SDPR24",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 706,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpKeyTypeChc,
   cmSdpRegExpR24
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeyInfoSeqElmnt[] =
{
   &cmMsgDefSdpKeyStr,
   &cmMsgDefSdpKeyType,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpKeyInfoSeq =
{
   3,
   cmMsgDefSdpKeyInfoSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKeyInfo =
{
#ifdef CM_ABNF_DBG
   "SDP: KEY",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 707,
   sizeof(CmSdpKeyType),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpKeyInfoSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpKeySeqElmnt[] =
{
   &cmMsgDefSdpKeyInfo
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpKeySeq =
{
   1,
   cmMsgDefSdpKeySeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpKey =
{
#ifdef CM_ABNF_DBG
   "SDP: KEY",
   "SDPR23",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 708,
   sizeof(CmSdpKeyType),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpKeySeq,
   cmSdpRegExpR23
};
/************************************************************************
                              SDP Attribute Fields
*************************************************************************/

PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpAttrStrMeta = {(Data *)"a="};
PUBLIC CmAbnfElmDef cmMsgDefSdpAttrStr =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRSTR",
   "SDPR27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 709,
   0, 
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpAttrStrMeta,
   cmSdpRegExpR27
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttrValRng = {1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrVal =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "SDP8",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 710,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpAttrValRng,
   cmSdpRegExpR8
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpOptAttrValSeqElmnt[] =
{
   &cmMsgDefOptMetaSpace,  /* 003.main_2; added to allow optional space */
   /* cm_sdpdb_c_002.101 - Changed Meta Element from ";" to ":" */
   &cmMsgDefMetaColon,
   &cmMsgDefOptMetaSpace,  /* 003.main_2; added to allow optional space */
   &cmMsgDefSdpAttrVal
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpOptAttrValSeq =
{
   4, /* 003.main_2; changed from 2 to 4 */
   cmMsgDefSdpOptAttrValSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpOptAttrVal =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 711,
   sizeof(TknStr32),
   CM_ABNF_OPTIONAL, 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpOptAttrValSeq,
   /* cm_sdpdb_c_002.101 - Changed RegExp for ";" to RegExp for ":" */
   /* 003.main_2 changed regexp; it was cmAbnfRegExpColon */
   cmSdpRegExpColonSpc
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpAttFieldRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttField =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRVAL ",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 712,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpAttFieldRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSeqElmnt[] =
{
   &cmMsgDefSdpAttrStr,
   &cmMsgDefSdpAttField,
   &cmMsgDefSdpOptAttrVal,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpAttrSeq =
{
  4,
  cmMsgDefSdpAttrSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttr =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTR",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 713,
   sizeof(CmSdpAttr),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpAttrSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpAttrSetSeqOfElmnt[] =
{
   &cmMsgDefSdpAttr
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpAttrSetSeqOf =
{
   0,
   CM_SDP_MAX_ATTR,
   1, 
   cmMsgDefSdpAttrSetSeqOfElmnt,
   sizeof(CmSdpAttr)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpAttrSet =
{
#ifdef CM_ABNF_DBG
   "SDP: ATTRSET",
   "SDPR27",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 714,
   sizeof(CmSdpAttrSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpAttrSetSeqOf,
   cmSdpRegExpR27
};

/************************************************************************
                              SDP Media Description
*************************************************************************/
PUBLIC CmAbnfElmTypeMeta cmMsgDefSdpMediaStrMeta = {(Data *)"m="};
PUBLIC CmAbnfElmDef cmMsgDefSdpMediaStr =
{
#ifdef CM_ABNF_DBG
   "SDP: MDSTR",
   "SDPR29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 715,
   0, 
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefSdpMediaStrMeta,
   cmSdpRegExpR29
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpPortIntRng = {1, 5, 0, 65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpPortIntRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpPortInt =
{
#ifdef CM_ABNF_DBG
   "SDP: INT",
   "SDPR32",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 716,
   sizeof(TknU16),
   CM_ABNF_OPTIONAL, 
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpPortIntRng,
   cmSdpRegExpR32
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpPortIntSeqElmnt[] =
{
   &cmMsgDefMetaSlash,
   &cmMsgDefSdpPortInt
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpPortIntSeq =
{
   2,
   cmMsgDefSdpPortIntSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaPortInt =
{
#ifdef CM_ABNF_DBG
   "SDP: PORTI",
   "CM_RSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 717,
   sizeof(TknU16),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpPortIntSeq,
   cmAbnfRegExpSlash
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpFmtRng = {1, 0xFFFF };

PUBLIC CmAbnfElmDef cmMsgDefSdpFmt =
{
#ifdef CM_ABNF_DBG
   "SDP: FMT",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 718,
   sizeof(TknStrOSXL),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTRXL,
   (U8 *)&cmMsgDefSdpFmtRng,
   cmAbnfRegExpAlDgChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpFmtSetSeqOfElmnt[] =
{
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpFmt
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpFmtSetSeqOf =
{
   1,
   CM_SDP_MAX_FMT,
   2,
   cmMsgDefSdpFmtSetSeqOfElmnt,
   sizeof(TknStrOSXL)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpFmtSet =
{
#ifdef CM_ABNF_DBG
   "SDP: FMT ",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 719,
   sizeof(CmSdpFmtSet),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpFmtSetSeqOf,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaAudioEnum =
{
   (Data *)"audio",
   CM_SDP_MEDIA_AUDIO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaAudio =
{
#ifdef CM_ABNF_DBG
   "SDP: AUDIO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 720,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaAudioEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaVideoEnum =
{
   (Data *)"video",
   CM_SDP_MEDIA_VIDEO
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaVideo =
{
#ifdef CM_ABNF_DBG
   "SDP: VIDEO",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 721,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaVideoEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaDataEnum =
{
   (Data *)"data",
   CM_SDP_MEDIA_DATA
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaData =
{
#ifdef CM_ABNF_DBG
   "SDP: DATA",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 722,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaDataEnum,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefSdpMediaAppAppEnum =
{
   (Data *)"application",
   CM_SDP_MEDIA_APP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaApp =
{
#ifdef CM_ABNF_DBG
   "SDP: APP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 723,
   sizeof(TknU8),
   0,
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefSdpMediaAppAppEnum,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaChcEnum[] =
{
   NULLP,
   &cmMsgDefSdpMediaAudio,
   &cmMsgDefSdpMediaVideo,
   &cmMsgDefSdpMediaData,
   &cmMsgDefSdpMediaApp,
};

PUBLIC CmAbnfElmTypeChoice cmMsgDefSdpMediaChc =
{
   5,
   0,
   NULLP,
   NULLP,
   cmMsgDefSdpMediaChcEnum
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMedia =
{
#ifdef CM_ABNF_DBG
   "SDP: MEDIA ",
   "SDPR30",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 724,
   sizeof(TknU8),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_CHOICE,
   (U8 *)&cmMsgDefSdpMediaChc,
   cmSdpRegExpR30
};

#ifdef CM_ABNF_V_1_2
PUBLIC CmAbnfElmTypeIntRange cmMsgDefSdpMediaPortRng = {1, 5, 0, 65535};
#else /* !CM_ABNF_V_1_2 */
PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMediaPortRng = {1, 5};
#endif /* CM_ABNF_V_1_2 */

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaPort =
{
#ifdef CM_ABNF_DBG
   "SDP: PORT ",
   "CM_RDGT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 725,
   sizeof(TknU16),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_UINT16,
   (U8 *)&cmMsgDefSdpMediaPortRng,
   cmAbnfRegExpDgt
};

PUBLIC CmAbnfElmTypeRange cmMsgDefSdpMediaProtoRng = { 1, 0xFFFF};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaProto =
{
#ifdef CM_ABNF_DBG
   "SDP: PROTO ",
   "CM_RALNUM",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 726,
   sizeof(TknStr32),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_OCTSTR32,
   (U8 *)&cmMsgDefSdpMediaProtoRng,
   /* 
    * cm_sdpdb_c_001.101 - Changed regular expression function from
    * cmAbnfRegExpAlDgChar to cmAbnfRegExpSutblChar
    */
   cmAbnfRegExpSutblChar
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaFieldSeqElmnt[] =
{
   &cmMsgDefSdpMediaStr,
   &cmMsgDefSdpMedia,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaPort,
   &cmMsgDefSdpMediaPortInt,
   &cmMsgDefMetaSpace,
   &cmMsgDefSdpMediaProto,
   &cmMsgDefSdpFmtSet,
   &cmMsgDefMetaEOL /* cm_sdpdb_c_003.101 - Change: CRLF to EOL */
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaFieldSeq =
{
   9,
   cmMsgDefSdpMediaFieldSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaField =
{
#ifdef CM_ABNF_DBG
   "SDP: MDFIELD ",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 727,
   sizeof(CmSdpMediaField),
   0,
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpMediaFieldSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpConnSetSeqOfElmnt[] =
{
   &cmMsgDefSdpConn
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpConnSetSeqOf =
{
   0,
   CM_SDP_MAX_CONN,
   1,
   cmMsgDefSdpConnSetSeqOfElmnt,
   sizeof(CmSdpConn)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpConnSet =
{
#ifdef CM_ABNF_DBG
   "SDP: CONNSET",
   "SDPR16",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 728,
   sizeof(CmSdpConnSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_STA_SEQOF,
   (U8 *)&cmMsgDefSdpConnSetSeqOf,
   cmSdpRegExpR16
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaDescSeqElmnt[] =
{
   &cmMsgDefSdpMediaField,
   &cmMsgDefSdpInfo,
   &cmMsgDefSdpConnSet,
   &cmMsgDefSdpBWSet,
   &cmMsgDefSdpKey,
   &cmMsgDefSdpAttrSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpMediaDescSeq =
{
   6,
   cmMsgDefSdpMediaDescSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaDesc =
{
#ifdef CM_ABNF_DBG
   "SDP: MDESC",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 729,
   sizeof(CmSdpMediaDesc),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpMediaDescSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpMediaDescSetSeqOfElmnt[] =
{
   &cmMsgDefSdpMediaDesc,
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpMediaDescSetSeqOf =
{
   0,
   CM_SDP_MAX_UNKNOWN,
   1,
   cmMsgDefSdpMediaDescSetSeqOfElmnt,
   sizeof(CmSdpMediaDesc)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpMediaDescSet =
{
#ifdef CM_ABNF_DBG
   "SDP: MDESC",
   "SDPR29",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 730,
   sizeof(CmSdpMediaDescSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_OPTIONAL), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpMediaDescSetSeqOf,
   cmSdpRegExpR29
};

/************************************************************************
                              SDP Message
*************************************************************************/
PUBLIC CmAbnfElmDef *cmMsgDefSdpSeqElmnt[] =
{
   &cmMsgDefSdpVer,
   &cmMsgDefSdpOrig,
   &cmMsgDefSdpSesName,
   &cmMsgDefSdpInfo,
   &cmMsgDefSdpUri,
   &cmMsgDefSdpEmailSet,
   &cmMsgDefSdpPhoneSet,
   &cmMsgDefSdpConn,
   &cmMsgDefSdpBWSet,
   &cmMsgDefSdpTime,
   &cmMsgDefSdpKey,
   &cmMsgDefSdpAttrSet,
   &cmMsgDefSdpMediaDescSet
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpSeq =
{
   13,
   cmMsgDefSdpSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdp =
{
#ifdef CM_ABNF_DBG
   "SDP: Msg",
   "EMPTY",                          
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 731,
   sizeof(CmSdpInfo),
   CM_ABNF_MANDATORY, 
   CM_ABNF_TYPE_SEQ,
   (U8 *)&cmMsgDefSdpSeq,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpInfoSetSeqOfElmnt[] =
{
   &cmMsgDefSdp
};

PUBLIC CmAbnfElmTypeSeqOf cmMsgDefSdpInfoSetSeqOf =
{
   1,
   CM_SDP_MAX_SZ,
   1,
   cmMsgDefSdpInfoSetSeqOfElmnt,
   sizeof(CmSdpInfo)
};

PUBLIC CmAbnfElmDef cmMsgDefSdpInfoSet =
{
#ifdef CM_ABNF_DBG
   "SDP: MSGSET",
   "EMPTY",                          
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 732,
   sizeof(CmSdpInfoSet),
   (CM_ABNF_TKN_NOT_CONSUMED | CM_ABNF_MANDATORY), 
   CM_ABNF_TYPE_SEQOF,
   (U8 *)&cmMsgDefSdpInfoSetSeqOf,
   cmSdpRegExpR1
};

#endif /* CM_SDP_V_2 */

/* SDP Begin marker */

PUBLIC CmAbnfElmTypeMarker cmMsgDefSdpBeginMarker =
{
   CM_ABNF_MARKER_SDP_BEGIN,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpBegin =
{
#ifdef CM_ABNF_DBG
   "Begin SDP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 733,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&cmMsgDefSdpBeginMarker,
   NULLP
};

/************************************************************************/

/* SDP End marker */

PUBLIC CmAbnfElmTypeMarker cmMsgDefSdpEndMarker =
{
   CM_ABNF_MARKER_SDP_END,
   NULLP
};

PUBLIC CmAbnfElmDef cmMsgDefSdpEnd =
{
#ifdef CM_ABNF_DBG
   "End SDP",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 734,
   0,
   0,
   CM_ABNF_TYPE_MARKER,
   (U8 *)&cmMsgDefSdpEndMarker,
   NULLP
};

PUBLIC CmAbnfElmDef *cmMsgDefSdpTopNodeSeqElmnt[] =
{
   &cmMsgDefSdpBegin,
   &cmMsgDefSdpInfoSet,
   &cmMsgDefSdpEnd,
};

PUBLIC CmAbnfElmTypeSeq cmMsgDefSdpTopNodeSeq =
{
   3,
   cmMsgDefSdpTopNodeSeqElmnt
};

PUBLIC CmAbnfElmDef cmMsgDefSdpTopNode =
{
#ifdef CM_ABNF_DBG
   "SDP: Top node",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 738,
   sizeof(CmSdpInfoSet),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_OPTSEQ,
   (U8 *)&cmMsgDefSdpTopNodeSeq,
   NULLP
};

/* Skip token buffer structure */
PUBLIC CmAbnfElmDef cmMsgDefSkipSdpTknBuf =
{
#ifdef CM_ABNF_DBG
   "Skip token buffer structure",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 735,
   sizeof(TknBuf),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

#else /* CM_SDP_OPAQUE defined */

/* SDP Token buffer */
PUBLIC CmAbnfElmDef cmMsgDefSdpTknBuf =
{
#ifdef CM_ABNF_DBG
   "SDP Token buffer",
   "ConsumeSDP",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 736,
   sizeof(TknBuf),
   /* 001.main_14: changes to support empty SDP body - made OPTIONAL */
   CM_ABNF_OPTIONAL,
   CM_ABNF_TYPE_TKNBUF,
   (U8 *)NULLP,
   cmSdpRegExpConsumeSDP
};

/* Skip SDP infoset struct */
PUBLIC CmAbnfElmDef cmMsgDefSkipSdpInfo =
{
#ifdef CM_ABNF_DBG
   "Skip SDP infoset struct",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_SDP_BASE + 737,
   sizeof(CmSdpInfoSet),
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_SKIP,
   NULLP,
   NULLP
};

#endif /* CM_SDP_OPAQUE */

  
/********************************************************************30**
  
         End of file:     cm_sdpdb.c@@/main/mgcp_rel_1.5_mnt/2 - Fri Jun 24 18:41:23 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.
1.1+         001.101  bbk  1. Fixed minimum number of email sets 
                              required in cmMsgDefSdpEmailSetSeqOf from
                              1 to 0
                           2. Fixed minimum number of phone sets
                              required in cmMsgDefSdpPhoneSetSeqOf from
                              1 to 0
                           3. Changed regular expression for 
                              cmMsgDefSdpMediaProto from cmAbnfRegExpAlDgChar
                              to cmAbnfRegExpSutblChar
             002.101  bbk  1. SDP Attribute field has meta-character as ":"
                              and not ";"..Fixed that
             003.101  nct  1. SDP parser now decodes LF or CRLF as end-of-line.
/main/2      ---      nct  1. New release for GCP 1.2.
/main/2+  001.main_2  nct  1. Changed sizes of cmMsgDefSdpAddrTypeAddr,
                              SdpConnAddrTypeAddr and SdpAtmTypeAddrM.
                           2. Changed type of SdpAttrQosClass to U8OrNil from
                              U8.
                           3. Changed type of session version from U32 to
                              StrOSXL.
          002.main_2  sk   1. Added new elements.
                           2. Changed regexp for cmMsgDefSdpInfoSet 
          003.main_2  sk   1. Optional Space is allowed between Email and Name
                              part (db element cmMsgDefSdpEmailAddrNameEmail and
                              cmMsgDefSdpEmailAddrEmailName )
                           2. Optional Space is allowed between Phone and Name 
                              part (db element cmMsgDefSdpPhoneAddrNamePhone and
                              cmMsgDefSdpPhoneAddrPhoneName )
                           3. Added new database elements to allow "LOCAL" 
                              as connection address and media transport.
/main/7      ---      ra   1. GCP Release 1.3
/main/7   001.main_7  rg   1. Added elements for T.38 Annex D - Image media,
                              Transport Udptl and format t38.
                           2. Removed SdpVcId element from cmMsgDefSdpAttrCdsc
                           3. Changed the regular expression cmAbnfRegExpSpace
                              to cmSdpRegExpSpaceU8OrNull for FmtsGenInts
                      ra   4. Added a parallel database to help in decoding
                              of a=cdsc type line occording to the old MGT
                              interface. All elements end with _V1 in this
                              database denoting MGT version 1.
/main/7   002.main_7  cv   1. SIP related changes.
/main/7   003.main_7  ra   1. Allowing optional space after
                              cmMsgDefSdpMedProtoFmtsGenInts
                              type of element.
/main/7   004.main_7  rg   1. Added two more elements for EncodingName
                              CM_SDP_ENC_TELEPHONE_EVENT
                              CM_SDP_ENC_CN
                           2. Changed the format for ProtoFmts = TCP and UDP
/main/12     ---  up   1. Changed case for TELEPHONE-EVENT string
/main/14     ---      up   1. Support for IPBCP in SDP
/main/14   001.main_14  ra  1. Changes to support mix of "$" & integer in
                              RTP list.
                           2. Changes to support "$" in "a=rtpmap:$"
                              attribute line.
                           3. Database changes for supporting the
                              Enhancements to the struct CmSdpAttrT38Fax 
                           4. Changes to support optional SDP body.
cm_sdpdb_c_002.main_14 gk  1. Modified to allow $ (CHOOSE) in the place of 
                              single parameter value under the flag 
                              CM_SDP_MEGACO_EECID_CHOICE
                           2. Modified to allow attribute or BW in the cpar,
                              cparmin, and cparmax with and without
                              space after colon
*********************************************************************91*/
