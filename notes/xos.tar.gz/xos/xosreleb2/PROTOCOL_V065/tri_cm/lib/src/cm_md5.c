/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

     Name:    MD5 common module

     Type:    C source file

     Desc:    MD5 file; This file is derived from the RSA Data Security, Inc. 
              MD5 Message-Digest Algorithm

     File:    cm_md5c.c

     Sid:      cm_md5.c@@/main/1 - Tue Feb 27 09:26:31 2001

     Prg:     bsr

*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"           /* environment options */
#include "envdep.h"           /* environment dependent */
#include "envind.h"           /* environment independent */
#include "gen.h"              /* general layer */
#include "ssi.h"              /* system services */
#include "cm_md5.h"           /* md5 defines */

/* header/extern include files (.x) */
#include "gen.x"              /* general layer */
#include "ssi.x"              /* system services */
#include "cm_lib.x"           /* common library functions */
#include "cm_md5.x"           /* md5 typedefs */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

PRIVATE Void cmMD5Transform ARGS
((
U32     *state,           /* state */
U8      *block            /* block */
));

PRIVATE Void cmMD5Encode ARGS
((
U8      *output,          /* output */
U32     *input,           /* input */
U32      len              /* length */
));

PRIVATE Void cmMD5Decode ARGS
((
U32     *output,          /* output */
U8      *input,           /* input */
U32      len              /* length */
));


/*
*
*       Fun:   cmMD5Init
*
*       Desc:  MD5 initialization. Begins an MD5 operation, writing a new 
*              context
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
  
#ifdef ANSI
PUBLIC Void cmMD5Init
(
CmMD5Ctx *context          /* MD5 context */
)
#else  /* ANSI */
PUBLIC Void cmMD5Init(context)
CmMD5Ctx *context;         /* MD5 context */
#endif /* ANSI */
{
   TRC2(cmMD5Init)

   context->count[0] = context->count[1] = 0;
   /* Load magic initialization constants  */
   context->state[0] = 0x67452301;
   context->state[1] = 0xefcdab89;
   context->state[2] = 0x98badcfe;
   context->state[3] = 0x10325476;

   RETVOID;
} /* end of cmMD5Init */


/*
*
*       Fun:   cmMD5Update
*
*       Desc:  MD5 block update operation. Continues an MD5 message-digest
*              operation, processing another message block, and updating the
*              context.
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
  
#ifdef ANSI
PUBLIC Void cmMD5Update
(
CmMD5Ctx *context,         /* MD5 context */
U8       *input,           /* input block */
U32      inputLen          /* length of input block */
)
#else  /* ANSI */
PUBLIC Void cmMD5Update(context, input, inputLen)
CmMD5Ctx *context;         /* MD5 context */
U8       *input;           /* input block */
U32      inputLen;         /* length of input block */
#endif /* ANSI */
{
   U32 i; 
   U32 idx; 
   U32 partLen;

   TRC2(cmMD5Update)

   /* Compute number of bytes mod 64 */
   idx = (U32)((context->count[0] >> 3) & 0x3F);

   /* Update number of bits */
   if ((context->count[0] += ((U32)inputLen << 3)) < ((U32)inputLen << 3))
      context->count[1]++;
   context->count[1] += ((U32)inputLen >> 29);

   partLen = 64 - idx;

   /* Transform as many times as possible.  */
   if (inputLen >= partLen) 
   {
      cmMemcpy ((U8 *)&context->buffer[idx], (U8 *)input, partLen);
      cmMD5Transform (context->state, context->buffer);

      for (i = partLen; i + 63 < inputLen; i += 64)
         cmMD5Transform (context->state, &input[i]);

      idx = 0;
   }
   else
      i = 0;

   /* Buffer remaining input */
   cmMemcpy ((U8 *)&context->buffer[idx], (U8 *)&input[i], inputLen-i);

   RETVOID;
} /* end of cmMD5Update */


/*
*
*       Fun:   cmMD5Final
*
*       Desc:  MD5 finalization. Ends an MD5 message-digest operation, writing 
*              the the message digest and zeroizing the context.
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
  
#ifdef ANSI
PUBLIC Void cmMD5Final
(
U8       *digest,          /* message digest */
CmMD5Ctx *context          /* MD5 context */
)
#else  /* ANSI */
PUBLIC Void cmMD5Final(digest, context)
U8       *digest;          /* message digest */
CmMD5Ctx *context;         /* MD5 context */
#endif /* ANSI */
{
  U8  bits[8];
  U32 idx; 
  U32 padLen;

  TRC2(cmMD5Final)

  /* Save number of bits */
  cmMD5Encode (bits, context->count, 8);

  /* Pad out to 56 mod 64.  */
  idx = (U32)((context->count[0] >> 3) & 0x3f);
  padLen = (idx < 56) ? (56 - idx) : (120 - idx);
  cmMD5Update (context, CM_MD5_PADDING, padLen);

  /* Append length (before padding) */
  cmMD5Update (context, bits, 8);

  /* Store state in digest */
  cmMD5Encode (digest, context->state, 16);

  /* Zeroize sensitive information.  */
  cmMemset ((U8 *)context, 0, sizeof (*context));

  RETVOID;
} /* end of cmMD5Final */


/*
*
*       Fun:   cmMD5Transform
*
*       Desc:  MD5 basic transformation. Transforms state based on block
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
  
#ifdef ANSI
PRIVATE Void cmMD5Transform
(
U32     *state,           /* state */
U8      *block            /* block */
)
#else  /* ANSI */
PRIVATE Void cmMD5Transform(state, block)
U32     *state;           /* state */
U8      *block;           /* block */
#endif /* ANSI */
{
   U32 a;
   U32 b;
   U32 c;
   U32 d;
   U32 x[16];

   TRC2(cmMD5Transform)

   a = state[0]; 
   b = state[1]; 
   c = state[2]; 
   d = state[3], 

   cmMD5Decode (x, block, 64);

   /* Round 1 */
   CM_MD5_FF (a, b, c, d, x[ 0], CM_MD5_S11, 0xd76aa478); /* 1 */
   CM_MD5_FF (d, a, b, c, x[ 1], CM_MD5_S12, 0xe8c7b756); /* 2 */
   CM_MD5_FF (c, d, a, b, x[ 2], CM_MD5_S13, 0x242070db); /* 3 */
   CM_MD5_FF (b, c, d, a, x[ 3], CM_MD5_S14, 0xc1bdceee); /* 4 */
   CM_MD5_FF (a, b, c, d, x[ 4], CM_MD5_S11, 0xf57c0faf); /* 5 */
   CM_MD5_FF (d, a, b, c, x[ 5], CM_MD5_S12, 0x4787c62a); /* 6 */
   CM_MD5_FF (c, d, a, b, x[ 6], CM_MD5_S13, 0xa8304613); /* 7 */
   CM_MD5_FF (b, c, d, a, x[ 7], CM_MD5_S14, 0xfd469501); /* 8 */
   CM_MD5_FF (a, b, c, d, x[ 8], CM_MD5_S11, 0x698098d8); /* 9 */
   CM_MD5_FF (d, a, b, c, x[ 9], CM_MD5_S12, 0x8b44f7af); /* 10 */
   CM_MD5_FF (c, d, a, b, x[10], CM_MD5_S13, 0xffff5bb1); /* 11 */
   CM_MD5_FF (b, c, d, a, x[11], CM_MD5_S14, 0x895cd7be); /* 12 */
   CM_MD5_FF (a, b, c, d, x[12], CM_MD5_S11, 0x6b901122); /* 13 */
   CM_MD5_FF (d, a, b, c, x[13], CM_MD5_S12, 0xfd987193); /* 14 */
   CM_MD5_FF (c, d, a, b, x[14], CM_MD5_S13, 0xa679438e); /* 15 */
   CM_MD5_FF (b, c, d, a, x[15], CM_MD5_S14, 0x49b40821); /* 16 */
   
   /* Round 2 */
   CM_MD5_GG (a, b, c, d, x[ 1], CM_MD5_S21, 0xf61e2562); /* 17 */
   CM_MD5_GG (d, a, b, c, x[ 6], CM_MD5_S22, 0xc040b340); /* 18 */
   CM_MD5_GG (c, d, a, b, x[11], CM_MD5_S23, 0x265e5a51); /* 19 */
   CM_MD5_GG (b, c, d, a, x[ 0], CM_MD5_S24, 0xe9b6c7aa); /* 20 */
   CM_MD5_GG (a, b, c, d, x[ 5], CM_MD5_S21, 0xd62f105d); /* 21 */
   CM_MD5_GG (d, a, b, c, x[10], CM_MD5_S22,  0x2441453); /* 22 */
   CM_MD5_GG (c, d, a, b, x[15], CM_MD5_S23, 0xd8a1e681); /* 23 */
   CM_MD5_GG (b, c, d, a, x[ 4], CM_MD5_S24, 0xe7d3fbc8); /* 24 */
   CM_MD5_GG (a, b, c, d, x[ 9], CM_MD5_S21, 0x21e1cde6); /* 25 */
   CM_MD5_GG (d, a, b, c, x[14], CM_MD5_S22, 0xc33707d6); /* 26 */
   CM_MD5_GG (c, d, a, b, x[ 3], CM_MD5_S23, 0xf4d50d87); /* 27 */
   CM_MD5_GG (b, c, d, a, x[ 8], CM_MD5_S24, 0x455a14ed); /* 28 */
   CM_MD5_GG (a, b, c, d, x[13], CM_MD5_S21, 0xa9e3e905); /* 29 */
   CM_MD5_GG (d, a, b, c, x[ 2], CM_MD5_S22, 0xfcefa3f8); /* 30 */
   CM_MD5_GG (c, d, a, b, x[ 7], CM_MD5_S23, 0x676f02d9); /* 31 */
   CM_MD5_GG (b, c, d, a, x[12], CM_MD5_S24, 0x8d2a4c8a); /* 32 */
   
   /* Round 3 */
   CM_MD5_HH (a, b, c, d, x[ 5], CM_MD5_S31, 0xfffa3942); /* 33 */
   CM_MD5_HH (d, a, b, c, x[ 8], CM_MD5_S32, 0x8771f681); /* 34 */
   CM_MD5_HH (c, d, a, b, x[11], CM_MD5_S33, 0x6d9d6122); /* 35 */
   CM_MD5_HH (b, c, d, a, x[14], CM_MD5_S34, 0xfde5380c); /* 36 */
   CM_MD5_HH (a, b, c, d, x[ 1], CM_MD5_S31, 0xa4beea44); /* 37 */
   CM_MD5_HH (d, a, b, c, x[ 4], CM_MD5_S32, 0x4bdecfa9); /* 38 */
   CM_MD5_HH (c, d, a, b, x[ 7], CM_MD5_S33, 0xf6bb4b60); /* 39 */
   CM_MD5_HH (b, c, d, a, x[10], CM_MD5_S34, 0xbebfbc70); /* 40 */
   CM_MD5_HH (a, b, c, d, x[13], CM_MD5_S31, 0x289b7ec6); /* 41 */
   CM_MD5_HH (d, a, b, c, x[ 0], CM_MD5_S32, 0xeaa127fa); /* 42 */
   CM_MD5_HH (c, d, a, b, x[ 3], CM_MD5_S33, 0xd4ef3085); /* 43 */
   CM_MD5_HH (b, c, d, a, x[ 6], CM_MD5_S34,  0x4881d05); /* 44 */
   CM_MD5_HH (a, b, c, d, x[ 9], CM_MD5_S31, 0xd9d4d039); /* 45 */
   CM_MD5_HH (d, a, b, c, x[12], CM_MD5_S32, 0xe6db99e5); /* 46 */
   CM_MD5_HH (c, d, a, b, x[15], CM_MD5_S33, 0x1fa27cf8); /* 47 */
   CM_MD5_HH (b, c, d, a, x[ 2], CM_MD5_S34, 0xc4ac5665); /* 48 */
   
   /* Round 4 */
   CM_MD5_II (a, b, c, d, x[ 0], CM_MD5_S41, 0xf4292244); /* 49 */
   CM_MD5_II (d, a, b, c, x[ 7], CM_MD5_S42, 0x432aff97); /* 50 */
   CM_MD5_II (c, d, a, b, x[14], CM_MD5_S43, 0xab9423a7); /* 51 */
   CM_MD5_II (b, c, d, a, x[ 5], CM_MD5_S44, 0xfc93a039); /* 52 */
   CM_MD5_II (a, b, c, d, x[12], CM_MD5_S41, 0x655b59c3); /* 53 */
   CM_MD5_II (d, a, b, c, x[ 3], CM_MD5_S42, 0x8f0ccc92); /* 54 */
   CM_MD5_II (c, d, a, b, x[10], CM_MD5_S43, 0xffeff47d); /* 55 */
   CM_MD5_II (b, c, d, a, x[ 1], CM_MD5_S44, 0x85845dd1); /* 56 */
   CM_MD5_II (a, b, c, d, x[ 8], CM_MD5_S41, 0x6fa87e4f); /* 57 */
   CM_MD5_II (d, a, b, c, x[15], CM_MD5_S42, 0xfe2ce6e0); /* 58 */
   CM_MD5_II (c, d, a, b, x[ 6], CM_MD5_S43, 0xa3014314); /* 59 */
   CM_MD5_II (b, c, d, a, x[13], CM_MD5_S44, 0x4e0811a1); /* 60 */
   CM_MD5_II (a, b, c, d, x[ 4], CM_MD5_S41, 0xf7537e82); /* 61 */
   CM_MD5_II (d, a, b, c, x[11], CM_MD5_S42, 0xbd3af235); /* 62 */
   CM_MD5_II (c, d, a, b, x[ 2], CM_MD5_S43, 0x2ad7d2bb); /* 63 */
   CM_MD5_II (b, c, d, a, x[ 9], CM_MD5_S44, 0xeb86d391); /* 64 */
   
   state[0] += a;
   state[1] += b;
   state[2] += c;
   state[3] += d;
   
   /* Zeroize sensitive information.  */
   cmMemset ((U8 *)x, 0, sizeof (x));

   RETVOID;
} /* end of cmMD5Transform */


/*
*
*       Fun:   cmMD5Encode
*
*       Desc:  Encodes input (U32) into output (unsigned char). Assumes len 
*              is a multiple of 4.
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
#ifdef ANSI
PRIVATE Void cmMD5Encode
(
U8      *output,          /* output */
U32     *input,           /* input */
U32      len              /* length */
)
#else  /* ANSI */
PRIVATE Void cmMD5Encode(output, input, len)
U8      *output;          /* output */
U32     *input;           /* input */
U32      len;             /* length */
#endif /* ANSI */
{
   U32 i;
   U32 j;

   TRC2(cmMD5Encode)

   for (i = 0, j = 0; j < len; i++, j += 4) 
   {
      output[j]   = (U8)(input[i] & 0xff);
      output[j+1] = (U8)((input[i] >> 8) & 0xff);
      output[j+2] = (U8)((input[i] >> 16) & 0xff);
      output[j+3] = (U8)((input[i] >> 24) & 0xff);
   }

   RETVOID;
} /* end of cmMD5Encode */


/*
*
*       Fun:   cmMD5Decode
*
*       Desc:  Decodes input (unsigned char) into output (U32). Assumes len 
*              is a multiple of 4.
*
*       Ret:   void    
*
*       Notes: None.
*
*       File:  cm_md5c.c
*
*/
#ifdef ANSI
PRIVATE Void cmMD5Decode
(
U32     *output,          /* output */
U8      *input,           /* input */
U32      len              /* length */
)
#else  /* ANSI */
PRIVATE Void cmMD5Decode(output, input, len)
U32     *output;          /* output */
U8      *input;           /* input */
U32      len;             /* length */
#endif /* ANSI */
{
   U32 i;
   U32 j;

   TRC2(cmMD5Decode)

   for (i = 0, j = 0; j < len; i++, j += 4)
   {
      output[i] = ((U32)input[j]) | (((U32)input[j+1]) << 8) |
         (((U32)input[j+2]) << 16) | (((U32)input[j+3]) << 24);
   }

   RETVOID;
} /* end of cmMD5Decode */

#ifdef __cplusplus
}
#endif /* __cplusplus */



/********************************************************************30**

         End of file:     cm_md5.c@@/main/1 - Tue Feb 27 09:26:31 2001

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************70**

*********************************************************************71*/

/********************************************************************80**

*********************************************************************81*/
/********************************************************************90**

    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
/main/1      ---   ms                 1. initial release.
*********************************************************************91*/
