/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Common ABNF message database for encoding/decoding
  
     Type:     C source file
  
     Desc:     Definition for common encoding/decoding Database Elements
  
     File:     cm_abndb.c
  
     Sid:      cm_abndb.c@@/main/2 - Fri Dec 22 15:22:04 2000
  
     Prg:      rm
  
*********************************************************************21*/
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tkns.h"       /* common token structures */
#include "cm_mblk.h"       /* common event memory management */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_inet.h"       /* Inet header file */
#include "cm_tpt.h"        /* Transport  header file */
#include "cm_sdp.h"        /* SDP  header file */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_tkns.x"       /* common token structures */
#include "cm_mblk.x"       /* common event memory management */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_inet.x"       /* Inet header file */
#include "cm_tpt.x"        /* Transport  header file */
#include "cm_sdp.x"        /* SDP  header file */
#include "cm_abndb.x"      /* Prototype definition for common reg exp */

/* cm_abndb_c_001.101 - Change: EOL encoded as \r\n instead of \n */
PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaEOLStr =  {(Data *)"\r\n"};

PUBLIC CmAbnfElmDef cmMsgDefMetaEOL = 
{
#ifdef CM_ABNF_DBG
   "CM : EOL ",
   "CM_REOL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 1,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaEOLStr,
   cmAbnfRegExpEOL
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaCRLFStr =  {(Data *)"\r\n"};

PUBLIC CmAbnfElmDef cmMsgDefMetaCRLF = 
{
#ifdef CM_ABNF_DBG
   "CM : EOL ",
   "CM_REOL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 2,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaCRLFStr,
   cmAbnfRegExpCRLF
};
PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaOpenBraceStr =  {(Data *)"("};
PUBLIC CmAbnfElmDef cmMsgDefMetaOpenBrace = 
{
#ifdef CM_ABNF_DBG
   "CM: ( ",
   "CM_OPENBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 3,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaOpenBraceStr,
   cmAbnfRegExpOpenBrace
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaCloseBraceStr =  {(Data *)")"};
PUBLIC CmAbnfElmDef cmMsgDefMetaCloseBrace = 
{
#ifdef CM_ABNF_DBG
   "CM: ) ",
   "CM_RCLOSEBRACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 4,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaCloseBraceStr,
   cmAbnfRegExpCloseBrace
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaSlashStr =  {(Data *)"/"};
PUBLIC CmAbnfElmDef cmMsgDefMetaSlash = 
{
#ifdef CM_ABNF_DBG
   "CM: / ",
   "CM_RSLASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 5,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaSlashStr,
   cmAbnfRegExpSlash
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaSemiColonStr =  {(Data *)";"};
PUBLIC CmAbnfElmDef cmMsgDefMetaSemiColon = 
{
#ifdef CM_ABNF_DBG
   "CM: Semicolon ",
   "CM_RSEMICOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 6,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaSemiColonStr, 
   cmAbnfRegExpSemiColon
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaEqualStr =  {(Data *)"="};
PUBLIC CmAbnfElmDef cmMsgDefMetaEqual = 
{
#ifdef CM_ABNF_DBG
   "CM: EQUAL ",
   "CM_REQUAL",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 7,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaEqualStr,
   cmAbnfRegExpEqual
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaSpaceStr =  {(Data *)" "};
PUBLIC CmAbnfElmDef cmMsgDefMetaSpace = 
{
#ifdef CM_ABNF_DBG
   "CM: Space",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 8,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaSpaceStr,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmDef cmMsgDefOptMetaSpace = 
{
#ifdef CM_ABNF_DBG
   "CM: Space",
   "CM_RSPACE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 9,
   0,
   CM_ABNF_OPTIONAL,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaSpaceStr,
   cmAbnfRegExpSpace
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaAtStr =  {(Data *)"@"};
PUBLIC CmAbnfElmDef cmMsgDefMetaAt = 
{
#ifdef CM_ABNF_DBG
   "CM: @",
   "CM_RAT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 10,
   0,   
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaAtStr,
   cmAbnfRegExpAt
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaDotStr =  {(Data *)"."};
PUBLIC CmAbnfElmDef cmMsgDefMetaDot = 
{
#ifdef CM_ABNF_DBG
   "CM: Dot",
   "CM_RDOT",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 11,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaDotStr,
   cmAbnfRegExpDot
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaCommaStr =  {(Data *)","};
PUBLIC CmAbnfElmDef cmMsgDefMetaComma = 
{
#ifdef CM_ABNF_DBG
   "CM: Comma",
   "CM_RCOMMA",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 12,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaCommaStr,
   cmAbnfRegExpComma
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaHyphenStr =  {(Data *)"-"};
PUBLIC CmAbnfElmDef cmMsgDefMetaHyphen = 
{
#ifdef CM_ABNF_DBG
   "CM: Dash",
   "CM_RDASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 13,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaHyphenStr,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmDef cmMsgDefOptMetaHyphen = 
{
#ifdef CM_ABNF_DBG
   "CM: Dash",
   "CM_RDASH",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 14,
   0,
   CM_ABNF_OPTIONAL,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaHyphenStr,
   cmAbnfRegExpHyphen
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaDQouteStr =  {(Data *)"\""};
PUBLIC CmAbnfElmDef cmMsgDefMetaDQoute = 
{
#ifdef CM_ABNF_DBG
   "CM: DQOUTE",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 15,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaDQouteStr,
   cmAbnfRegExpDquote
};

PUBLIC CmAbnfElmTypeMeta cmAbnfRegExpPipeStr =  {(Data *)"|"};
PUBLIC CmAbnfElmDef cmMsgDefMetaPipe = 
{
#ifdef CM_ABNF_DBG
   "CM: |",
   "CM_RPIPE",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 16,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmAbnfRegExpPipeStr,
   cmAbnfRegExpPipe
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaColonStr =  {(Data *)":"};
PUBLIC CmAbnfElmDef cmMsgDefMetaColon = 
{
#ifdef CM_ABNF_DBG
   "CM: COLON",
   "CM_RCOLON",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 17,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaColonStr,
   cmAbnfRegExpColon
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefQuoteEscStr =  {(Data *)"\"\""};
PUBLIC CmAbnfElmDef cmMsgDefQuoteEsc = 
{
#ifdef CM_ABNF_DBG
   "CM: QTESC",
   "CM_QTESC",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 18,
   0,
   CM_ABNF_MANDATORY,   
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefQuoteEscStr,
   cmAbnfRegExpQuoteEsc
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaOpenAngleBrktStr = {(Data *)"<"};
PUBLIC CmAbnfElmDef cmMsgDefMetaOpenAngleBrkt =
{
#ifdef CM_ABNF_DBG
   "CM: <",
   "CM_OpenAngleBrkt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 21,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaOpenAngleBrktStr,
   cmAbnfRegExpOpenAngleBrkt
};

PUBLIC CmAbnfElmTypeMeta cmMsgDefMetaCloseAngleBrktStr = {(Data *)">"};
PUBLIC CmAbnfElmDef cmMsgDefMetaCloseAngleBrkt =
{
#ifdef CM_ABNF_DBG
   "CM: >",
   "CM_CloseAngleBrkt",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 21,
   0,
   CM_ABNF_MANDATORY,
   CM_ABNF_TYPE_META,
   (U8 *)&cmMsgDefMetaCloseAngleBrktStr,
   cmAbnfRegExpCloseAngleBrkt
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefEnumOff =  
{
   (Data *)"off",
   FALSE
};

PUBLIC CmAbnfElmDef cmMsgDefEnumOffBool = 
{
#ifdef CM_ABNF_DBG
   "CM: OFF",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 19,
   sizeof(TknU8),
   0,   
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefEnumOff,
   NULLP
};

PUBLIC CmAbnfElmTypeEnum cmMsgDefEnumOn =  
{
   (Data *)"on",
   TRUE
};

PUBLIC CmAbnfElmDef cmMsgDefEnumOnBool = 
{
#ifdef CM_ABNF_DBG
   "CM: ON",
   "EMPTY",
#endif /* CM_ABNF_DBG */
   CM_ABNF_ELMNID_CM_BASE + 20,
   sizeof(TknU8),
   0,   
   CM_ABNF_TYPE_ENUM,
   (U8 *)&cmMsgDefEnumOn,
   NULLP
};

  
/********************************************************************30**
  
         End of file:     cm_abndb.c@@/main/2 - Fri Dec 22 15:22:04 2000
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.
1.1+         001.101  nct  1. Changed EOL encoding from LF to CRLF.
/main/2      ---      nct  1. New release for GCP 1.2.
*********************************************************************91*/
