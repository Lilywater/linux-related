/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Common SS7 
  
     Type:     Common Source Code
  
     Desc:     Routines shared by more than one ss7 layer
 
     File:     cm_ss7.c

     Sid:      cm_ss7.c@@/main/18 - Fri Sep 16 02:57:40 2005
  
     Prg:      fmg
  
*********************************************************************21*/
 

#ifndef DONT_USE_SYS_LIB

#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#define MEMCPY_AVAIL   1
#define MEMCMP_AVAIL   1
#define MEMSET_AVAIL   1
#define STRCMP_AVAIL   1
#define STRNCMP_AVAIL  1
#define STRLEN_AVAIL   1

#else  /* DONT_USE_SYS_LIB */
#define MEMCPY_AVAIL   0
#define MEMCMP_AVAIL   0
#define MEMSET_AVAIL   0
#define STRCMP_AVAIL   0
#define STRNCMP_AVAIL  0
#define STRLEN_AVAIL   0
#endif /* not DONT_USE_SYS_LIB */

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#ifndef CMFILE_REORG_1
#include "cm_gen.h"        /*  general layer */
#endif
#include "cm_ss7.h"        /* common ss7 */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/*
 * support functions
 */


/*
*
*       Fun:   cmCopy
*
*       Desc:  copy a block from src to dest
*
*       Ret:   RETVOID
*
*       Notes: none
*
*       File:  cm_ss7.c
*
*/
  
#ifdef ANSI
PUBLIC Void cmCopy
(
REG1 U8 *src,               /* source */
REG2 U8 *dst,               /* destination */
REG3 U32 count              /* count */
)
#else
PUBLIC Void cmCopy(src, dst, count)
REG1 U8 *src;               /* source */
REG2 U8 *dst;               /* destination */
REG3 U32 count;             /* count */
#endif
{
   TRC3(cmCopy)
#if (MEMCPY_AVAIL) /* memcpy is available */
   memcpy((Void *)dst, (CONSTANT Void *)src, (size_t)count);
#else
       while (count--)
      *dst++ = *src++;

#endif /* MEMCPY_AVAIL */
   RETVOID;
} /* end of cmCopy */


/*
*
*       Fun:   cmCopyLngAddrs
*
*       Desc:  Copy one long address into another
*
*       Ret:   RETVOID
*
*       Notes: This routine only copies the bytes in use...
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC Void cmCopyLngAddrs
(
LngAddrs *src,                    /* source */
LngAddrs *dest                    /* destination */
)
#else
PUBLIC Void cmCopyLngAddrs(src, dest)
LngAddrs *src;                    /* source */
LngAddrs *dest;                   /* destination */
#endif
{
   TRC2(cmCopyLngAddrs)
   if(src->length > LNGADRLEN)/*xqc for override the */
   {
      printf("file:cm_ss7.c line : %d error, the length of Tkn exceed the val length!\r\n", __LINE__);
      RETVOID;         
   }

   dest->length = src->length;
   if(dest->length)
      cmCopy(src->strg, dest->strg, dest->length);
   RETVOID;
} /* end of cmCopyLngAddrs */


/*
*
*       Fun:   cmCopyGt
*
*       Desc:  Copy Global Titles
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/
#ifdef ANSI
PUBLIC Void cmCopyGt
(
Swtch sw,      /* SW_ANSI, SW_ITU */
GlbTi *src,
GlbTi *dst
)
#else
PUBLIC Void cmCopyGt(sw, src, dst)
Swtch sw;      /* SW_ANSI, SW_ITU */
GlbTi *src;
GlbTi *dst;
#endif
{
   U8 adjFrmt;

   TRC2(cmCopyGt)
  
   dst->format = src->format;
   if (dst->format == GTFRMT_0)
      RETVOID;
   cmCopyLngAddrs((LngAddrs*)&src->addr, (LngAddrs*)&dst->addr);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
    if ((sw == SW_ANSI) && (src->format == GTFRMT_1))
       adjFrmt = GTFRMT_3;
    else
#else
       UNUSED(sw);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
       adjFrmt = src->format;

   switch(adjFrmt)
   {
      case GTFRMT_1:
         dst->gt.f1.oddEven = src->gt.f1.oddEven;
         dst->gt.f1.natAddr = src->gt.f1.natAddr;
         break;
      case GTFRMT_2:
         dst->gt.f2.tType = src->gt.f2.tType;
         break;
      case GTFRMT_3:
         dst->gt.f3.tType = src->gt.f3.tType;
         dst->gt.f3.numPlan = src->gt.f3.numPlan;
         dst->gt.f3.encSch = src->gt.f3.encSch;
         break;
      case GTFRMT_4:
         dst->gt.f4.tType = src->gt.f4.tType;
         dst->gt.f4.numPlan = src->gt.f4.numPlan;
         dst->gt.f4.encSch = src->gt.f4.encSch;
         dst->gt.f4.natAddr = src->gt.f4.natAddr;
         break;
      case GTFRMT_5:
         dst->gt.f5.ipAddr = src->gt.f5.ipAddr;
         break;
   }
   RETVOID;
} /* end of cmCopyGt */


/*
*
*       Fun:    cmIsANumber
*
*       Desc:   Checks if ASCII digit is in the given Base
*
*       Ret:    TRUE   - c is digit in the given base
*               FALSE  - c is not digit in the given base
*
*       Notes:  None
*
*       File:   cm_ss7.c
*
*/
  
#ifdef ANSI
PUBLIC Bool cmIsANumber
(
S16 *p,              /* pointer to store the result */
Data c,              /* number */
S16 base             /* base */
)
#else
PUBLIC Bool cmIsANumber(p, c, base)
S16 *p;              /* pointer to store the result */
Data c;              /* number */
S16 base;            /* base */
#endif
{
   TRC2(cmIsANumber)
  
   if (base == BASE16)
   {
      if (('0' <= c) && (c <= '9'))
      {
         *p = c - '0';
         RETVALUE(TRUE);
      }
      else if (('a' <= c) && (c <= 'f'))
      {
         *p = c - 'a' + BASE10;
         RETVALUE(TRUE);
      }
      else if (('A' <= c) && (c <= 'F'))
      {
         *p = c - 'A' + BASE10;
         RETVALUE(TRUE);
      }
      else
         RETVALUE(FALSE);
   }
   else
   {
      c -= '0';
      if (c < (U8) base)
      {
         *p = c;
         RETVALUE(TRUE);
      }
      else
         RETVALUE(FALSE);
   }
} /* end of cmIsANumber */


/*
*
*       Fun:    cmAscHexAdrToBcd
*
*       Desc:   Converts Ascii (hexadecimal format) Address to BCD
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmAscHexAdrToBcd
(
LngAddrs *inpBuf,        /* ascii buffer */
ShrtAddrs *bcdBuf        /* bcd buffer */
)
#else
PUBLIC S16 cmAscHexAdrToBcd(inpBuf, bcdBuf)
LngAddrs *inpBuf;        /* ascii buffer */
ShrtAddrs *bcdBuf;       /* bcd buffer */
#endif
{
   REG1 U8 c;
   REG2 U8 i;
   REG3 U8 *src;
   REG4 U8 *dst;
   S16 d;
  
   TRC2(cmAscHexAdrToBcd)
  
   src = inpBuf->strg;
   dst = bcdBuf->strg;

   /* sanity check */
   if (inpBuf->length > LNGADRLEN)
      RETVALUE(RFAILED);

   for (i = inpBuf->length; i; i--)
   {
      d = 0;
      if (!cmIsANumber(&d, c = *src++, (S16) BASE16))
         RETVALUE(RFAILED);
      *dst = (U8) (d << 4);
      i--;
      if (!i)
         break;
      if (!cmIsANumber(&d, c = *src++, (S16) BASE16))
         RETVALUE(RFAILED);
      *dst++ |= d;
   }
   bcdBuf->length = (U8) (inpBuf->length % 2) ?
      (U8)((U8)(inpBuf->length + 1)/2) : (U8)(inpBuf->length/2);
   RETVALUE(ROK);
} /* end of cmAscHexAdrToBcd */


/*
*
*       Fun:    cmAscDecAdrToBcd
*
*       Desc:   Converts Ascii (decimal format) Address to BCD
*
*       Ret:    ROK  - ok
*
*       Notes:  None
*
*       File:   cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmAscDecAdrToBcd
(
LngAddrs *inpBuf,        /* ascii buffer */
ShrtAddrs *bcdBuf        /* bcd buffer */
)
#else
PUBLIC S16 cmAscDecAdrToBcd(inpBuf, bcdBuf)
LngAddrs *inpBuf;        /* ascii buffer */
ShrtAddrs *bcdBuf;       /* bcd buffer */
#endif
{
   REG1 U8 c;
   REG2 U8 i;
   REG3 U8 *src;
   REG4 U8 *dst;
   S16 d;
  
   TRC2(cmAscDecAdrToBcd)
  
   src = inpBuf->strg;
   dst = bcdBuf->strg;
  
   for (i = inpBuf->length; i; i--)
   {
      d = 0;
      if (!cmIsANumber(&d, c = *src++, (S16) BASE10))
         RETVALUE(RFAILED);
      *dst = (U8) (d << 4);
      i--;
      if (!i)
         break;
      if (!cmIsANumber(&d, c = *src++, (S16) BASE10))
         RETVALUE(RFAILED);
      *dst++ |= d;
   }
   bcdBuf->length = (U8)(inpBuf->length % 2) ?
         (U8)((U8)(inpBuf->length + 1)/2) : (U8)(inpBuf->length/2);
   RETVALUE(ROK);
} /* end of cmAscDecAdrToBcd */

/*
*
*       Fun:   cmCopySpAddr
*
*       Desc:  Copy one sccp address into another
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC Void cmCopySpAddr
(
SpAddr *src,      /* source */
SpAddr *dst       /* destination */
)
#else
PUBLIC Void cmCopySpAddr(src, dst)
SpAddr *src;      /* source */
SpAddr *dst;      /* destination */
#endif
{
   TRC2(cmCopySpAddr)
   if(src == (SpAddr*)NULLP)
   {
#ifdef CMSS7_SPHDROPT
      dst->spHdrOpt = CMSS7_DEF_OPT; /* No options are enabled */
#endif /* CMSS7_SPHDROPT */   
      dst->pres = FALSE;
      dst->gt.format = GTFRMT_0;
      RETVOID;
   }
#ifdef CMSS7_SPHDROPT
   dst->spHdrOpt = src->spHdrOpt;
#endif /* CMSS7_SPHDROPT */   
   dst->pres = src->pres;
   if (!src->pres)
      RETVOID;
   dst->sw = src->sw;
   dst->ssfPres = src->ssfPres;
   dst->ssf = src->ssf;
   dst->niInd = src->niInd;
   dst->rtgInd = src->rtgInd;
   dst->pcInd = src->pcInd;
   dst->ssnInd = src->ssnInd;
   if (dst->ssnInd)
      dst->ssn = src->ssn;
   if (dst->pcInd)
      dst->pc = src->pc;
   cmCopyGt(src->sw, &src->gt, &dst->gt);
   RETVOID;
} /* end of cmCopySpAddr */


/*
*
*       Fun:   cmZero
*
*       Desc:  zero a block of memory
*
*       Ret:   RETVOID
*
*       Notes: none
*
*       File:  cm_ss7.c
*
*/
#ifdef ANSI
PUBLIC Void cmZero
(
REG1 U8 *pVal,               /* source */
REG3 U32 count              /* count */
)
#else
PUBLIC Void cmZero(pVal, count)
REG1 U8 *pVal;               /* source */
REG3 U32 count;             /* count */
#endif
{
   TRC3(cmZero)
#if (MEMSET_AVAIL) /* memset is available */
   memset((Void *)pVal, (U8)0, (size_t)count);
#else  /* MEMSET_AVAIL: memset is not available */
   while (count --)
      *pVal++ = (U8)0;

#endif /* MEMSET_AVAIL */
   RETVOID;
} /* end of cmZero */


/* 
* 
*       Fun:   Build TCAP style String
*  
*       Desc:  Place a character string into a fixed length string
*  
*       Ret:   None
* 
*       Notes: None 
* 
*       File:  cm_ss7.c
* 
*/ 

#ifdef ANSI
PUBLIC Void cmBldStStr
(
StStr *stStr,
S8 *string
)
#else
PUBLIC Void cmBldStStr(stStr, string)
StStr *stStr;
S8 *string;
#endif
{
   U16 count;

   TRC2(cmBldStStr);

   if (*string == '\0')
   {
      stStr->len = 0;
      RETVOID;
   }
   for(count=0;*string && count < (U16)MAX_ST_STRING;string++)
      stStr->string[count++] = *string;
   stStr->len = (U16)(count);

   RETVOID;
} /* end of cmBldStStr */


/*
*
*       Fun:    cmCopyStStr
*
*       Desc:   Copy dst, src
*
*       Ret:    RETVOID
*
*       Notes:  None
*
*       File:   cm_ss7.c
*
*/
  
#ifdef ANSI
PUBLIC Void cmCopyStStr
(
StStr *src,                /* source string */
StStr *dst                 /* destination string */
)
#else
PUBLIC Void cmCopyStStr(src, dst)
StStr *src;                /* source string */
StStr *dst;                /* destination string */
#endif
{
   S16 i;

   TRC2(cmCopyStStr)
   if(src->len > MAX_ST_STRING)/*xqc for override the */
   {
      printf("file:cm_ss7.c line : %d error, the length of Tkn exceed the val length!\r\n", __LINE__);
      RETVOID;         
   }
   dst->len = src->len;
   for(i=0;i<(S16)src->len;i++)
      dst->string[i] = src->string[i];

   RETVOID;
} /* end of cmCopyStStr */

/*
*
*       Fun:   cmPkLngAddr
*
*       Desc:  pack  long address
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkLngAddr
(
LngAddrs *add,
Buffer *mBuf,
U8 *l
)
#else
PUBLIC S16 cmPkLngAddr(add, mBuf, l)
LngAddrs *add;
Buffer *mBuf;
U8 *l;
#endif
{
   REG1 U8 i;

   TRC2(cmPkLngAddr)
   /* Pack data bits */
   for( i = add->length; i > 0; i--)
   {
      CMCHKPK( SPkU8, add->strg[i-1], mBuf);
   }
  
   CMCHKPK( SPkU8, add->length, mBuf);
   if (l != (U8 *)NULLP)
      *l = (U8)(add->length + (U8)1);
   RETVALUE(ROK);
} /* end of cmPkLngAddrs */

/*
*
*       Fun:   cmUnpkLngAddr
*
*       Desc:  unpack long address
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLngAddr
(
LngAddrs *add,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLngAddr(add, mBuf)
LngAddrs *add;
Buffer *mBuf;
#endif
{
   REG1 U8 i;
   
   TRC2(cmUnpkLngAddr)
   CMCHKUNPK( SUnpkU8, &add->length, mBuf);
   /* Pack data bits */
   for( i = 0; i < add->length; i++)
   {
      CMCHKUNPK( SUnpkU8, &add->strg[i], mBuf);
   }
   RETVALUE(ROK);
} /* end of cmUnpkLngAddr */


/*
*
*       Fun:    cmPrntShrtAddrs
*
*       Desc:   Prints the short Address
*
*       Ret:    Void
*
*       Notes:  None
*
*       File:   cm_ss7.c
*
*/
#ifdef ANSI
PUBLIC Void cmPrntShrtAddrs
(
ShrtAddrs   *addr
)
#else
PUBLIC Void cmPrntShrtAddrs(addr)
ShrtAddrs   *addr;
#endif
{
   Txt      prntBuf[PRNTSZE];
   Cntr     i;
 
   TRC2(cmPrntShrtAddrs)
 
   SPrint("Address: ");
   sprintf(prntBuf, "\t Length %d \n\t", addr->length);
   SPrint(prntBuf);
   for (i = 0; i < (Cntr) addr->length; i++)
   {
      sprintf(prntBuf, "%c", addr->strg[i]);
      SPrint(prntBuf);
   } /* end of for */
   SPrint("\n");
 
   RETVOID;
} /* end of cmPrntShrtAddrs */


/*
*
*       Fun:   cmPkGlbTi
*
*       Desc:  Pack an global title structure (between layers)
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkGlbTi
(
GlbTi  *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkGlbTi(param, mBuf)
GlbTi  *param;
Buffer *mBuf;
#endif
{
   U8 len;
   U8 octet;
   S16 rVal;
  
   TRC2(cmPkGlbTi);

   /* Initialize */
   len = 0;
   octet = 0;

   if (param->format != GTFRMT_0)
   {
     /* Pack the  address bits */
     rVal = cmPkLngAddr((LngAddrs*)&param->addr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (rVal != ROK)
     {
       RETVALUE(rVal);
     }
#endif
   }
  
   switch (param->format)
   {
      case GTFRMT_0:
      {
         break;
      }
      case GTFRMT_1:
      {
         /* encode global title header */
         octet |= ((param->gt.f1.oddEven & 0x01) << 7);
         octet |= (param->gt.f1.natAddr & 0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         break;
      }
      case GTFRMT_2:
      {
         /* encode translation type */
         CMCHKPK( SPkU8, param->gt.f2.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_3:
      {
         /* encode global title header */
         octet |= ((param->gt.f3.numPlan & 0x0f) << 4);
         octet |= (param->gt.f3.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         CMCHKPK( SPkU8, param->gt.f3.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_4:
      {
         /* encode global title header */
         octet = (U8)(param->gt.f4.natAddr & (U8)0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         octet = 0;
         octet |= ((param->gt.f4.numPlan & 0x0f) << 4);
         octet |= (param->gt.f4.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         CMCHKPK( SPkU8, param->gt.f4.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_5:
      {
         CMCHKPK( SPkU32, param->gt.f5.ipAddr, mBuf);
         break;
      }
   }
  
   /* encode the format of the global title */
   CMCHKPK( SPkU8,  (U8)param->format, mBuf);
   len++;

   /* encode the length of the entire element */
   CMCHKPK( SPkU8,  (U8)len, mBuf);

   RETVALUE(ROK);
} /* end of cmPkGlbTi */


/*           
*
*       Fun:   cmUnpkGlbTi
*
*       Desc:  Unpack an Global Title structure (between layers)
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkGlbTi
(
GlbTi  *param,       /* global title */
Buffer *mBuf         /* message buffer  */
)
#else
PUBLIC S16 cmUnpkGlbTi(param, mBuf)
GlbTi  *param;       /* global title */
Buffer *mBuf;        /* message buffer  */
#endif
{
   U8 octet;
   U8 len;
   
   TRC2(cmUnpkGlbTi);

   /* First octet is the length */
   CMCHKUNPK( SUnpkU8, &len, mBuf);
  
   CMCHKUNPK( SUnpkU8, &param->format, mBuf);
   len--;

   switch(param->format)
   {
      case GTFRMT_1:
      {
         /*
          * Odd/Even, and Nature of Address Indicator
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f1.oddEven = (U8)((octet >> 0x07) & 0x01);
         param->gt.f1.natAddr = (U8)(octet & 0x7f);
         break;
      }
      case GTFRMT_2:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f2.tType = octet;
  
         break;
      }
      case GTFRMT_3:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f3.tType = octet;
  
         /*
          * Encoding Scheme and Numbering Plan
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f3.encSch = (U8)(octet & 0x0f);
         param->gt.f3.numPlan = (U8)((octet >> 0x04) & 0x0f);
         break;
      }
      case GTFRMT_4:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f4.tType = octet;
  
         /*
          * Encoding Scheme and Numbering Plan
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f4.encSch = (U8)(octet & 0x0f);
         param->gt.f4.numPlan = (U8)((octet >> 0x04) & 0x0f);
  
         /*
          * Nature of address indicator
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         param->gt.f4.natAddr = (U8)(octet & 0x7f);
         break;
      }
      case GTFRMT_5:
      {
         CMCHKUNPK( SUnpkU32, &param->gt.f5.ipAddr, mBuf);
         break;
      }
   }

   if (param->format != GTFRMT_0)
   {
      /* Address nibbles */
      CMCHKUNPK( cmUnpkLngAddr, (LngAddrs*)&param->addr, mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkGlbTi */


/*
*
*       Fun:   cmPkSpAddr
*
*       Desc:  Pack an sccp address structure (between layers)
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSpAddr
(
SpAddr *addr,
Buffer *mBuf,
U8 *l
)
#else
PUBLIC S16 cmPkSpAddr(addr, mBuf, l)
SpAddr *addr;
Buffer *mBuf;
U8 *l;
#endif
{
   U8 len;
   U8 adjFrmt;             /* adjusted format */
   U8 octet;
   S16 rVal;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;    /* bitvector for compile flag CMSS7_SPHDROPT */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
  
   TRC2(cmPkSpAddr)
   /* Initialize */
   len = 0;
   octet = 0;

   if (!addr->pres)
      goto PKPRES;

   /* We do this backwards because the mos pack routines prepend */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   /* Adjust ansi type 1 to equivalent ccitt (type 3) */
   if ((addr->sw == SW_ANSI) && (addr->gt.format == GTFRMT_1))
       adjFrmt = GTFRMT_3;
   else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
      adjFrmt = addr->gt.format;

   if (adjFrmt != GTFRMT_0)
   {
     /* Pack the  address bits */
     rVal = cmPkLngAddr((LngAddrs*)&addr->gt.addr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
     if (rVal != ROK)
     {
       RETVALUE(rVal);
     }
#endif
   }
  
   switch (adjFrmt)
   {
      case GTFRMT_0:
      {
         break;
      }
      case GTFRMT_1:
      {
         /* encode global title header */
         octet |= ((addr->gt.gt.f1.oddEven & 0x01) << 7);
         octet |= (addr->gt.gt.f1.natAddr & 0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         break;
      }
      case GTFRMT_2:
      {
         /* encode translation type */
         CMCHKPK( SPkU8, addr->gt.gt.f2.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_3:
      {
         /* encode global title header */
         octet |= ((addr->gt.gt.f3.numPlan & 0x0f) << 4);
         octet |= (addr->gt.gt.f3.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         CMCHKPK( SPkU8, addr->gt.gt.f3.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_4:
      {
         /* encode global title header */
         octet = (U8)(addr->gt.gt.f4.natAddr & (U8)0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         octet = 0;
         octet |= ((addr->gt.gt.f4.numPlan & 0x0f) << 4);
         octet |= (addr->gt.gt.f4.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         len++;
         CMCHKPK( SPkU8, addr->gt.gt.f4.tType, mBuf);
         len++;
         break;
      }
      case GTFRMT_5:
      {
         CMCHKPK( SPkU32, addr->gt.gt.f5.ipAddr, mBuf);
         break;
      }
   }
  
   /* ANSI & CCITT, have different orderings of the following
    * parameters, but we don't care about that between layers
    * which is the only circumstances that this routine should
    * be used 
    */

   /* encode the subsystem */
   if (addr->ssnInd)
   {
      CMCHKPK( SPkU8, addr->ssn, mBuf);
      len++;
   }
  
   /* encode the point code */
   if (addr->pcInd)
   {
      CMCHKPK( SPkU32, addr->pc, mBuf);
      len+=4;
   }

   /* encode the address indicators */
   octet = 0;
   octet |= ((addr->niInd & 0x01) << 7);
   octet |= ((addr->rtgInd & 0x01) << 6);
   octet |= ((addr->gt.format & 0x0f) << 2);
   octet |= ((addr->ssnInd & 0x01) << 1);
   octet |= ((addr->pcInd & 0x01) << 0);
  
   CMCHKPK( SPkU8, octet, mBuf);
   len++;

   /* encode the ssf */
   if (addr->ssfPres)
   {
      CMCHKPK( SPkU8, addr->ssf, mBuf);
      len++;
   }
   CMCHKPK( SPkU8, addr->ssfPres, mBuf);
   len++;
  
   /* encode switch last */
   CMCHKPK( SPkS16, addr->sw, mBuf);
   len+=2;

PKPRES:
   CMCHKPK( SPkU8, addr->pres, mBuf);
   len++;

#ifdef CMSS7_SPHDROPT
   CMCHKPK( SPkU8, addr->spHdrOpt, mBuf);
   len++;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* filling presence of hdr option */
   bitVector |= CMSS7_SPHDROPT_BIT;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* CMSS7_SPHDROPT */  

   /* encode the length of the entire element */
   CMCHKPK( SPkU8,  (U8)len, mBuf);
   *l = len+1;

/* if rolling upgrade support is ON, pack the bitVector for
 * compile flag on top of entire element
 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK( SPkU8, (U8)bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
} /* end of cmPkSpAddr */


/*           
*
*       Fun:   cmUnpkSpAddr
*
*       Desc:  Unpack an sccp address structure (between layers)
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSpAddr
(
SpAddr* addr,        /* address */
Buffer* mBuf         /* message buffer  */
)
#else
PUBLIC S16 cmUnpkSpAddr(addr, mBuf)
SpAddr* addr;        /* address */
Buffer* mBuf;        /* message buffer  */
#endif
{
   U8 octet;
   U8 len;
   U8 adjFrmt;       /* adjusted format */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;     /* bit vector for compile flag */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   TRC2(cmUnpkSpAddr)

/* if rolling upgrade support is ON, unpack the bitVector
 * for compile flags
 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK( SUnpkU8, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
  
   /* next octet is the length */
   CMCHKUNPK( SUnpkU8, &len, mBuf);
  
#ifdef CMSS7_SPHDROPT
/* unpacking of hdr option */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* if CMSS7_SPHDROPT is defined, unpack spHdrOpt, if the bit vector
      indicates its presence, else assign a default value */
   if (bitVector & CMSS7_SPHDROPT_BIT)
   {
      CMCHKUNPK( SUnpkU8, &addr->spHdrOpt, mBuf);
      len--;
   }
   else
      addr->spHdrOpt = CMSS7_DEF_OPT;
#else /* TDS_ROLL_UPGRADE_SUPPORT */
   /* no rolling upgrade support, unpack spHdrOpt solely on the basis of
      compile flag */
   CMCHKUNPK( SUnpkU8, &addr->spHdrOpt, mBuf);
   len--;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#else /* CMSS7_SPHDROPT */

/* compile flag is not defined at our end but may be defined at originating
   end, so unpack and ignore spHdrOpt, if bit vector indicates its presence */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & CMSS7_SPHDROPT_BIT)
   {
      U8 tempVar;  /* temp variable to unpack and ignore spHdrOpt present */
      CMCHKUNPK( SUnpkU8, &tempVar, mBuf);
      len--;
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#endif /* CMSS7_SPHDROPT */  

   /* get the present indicator */
   CMCHKUNPK( SUnpkU8, &addr->pres, mBuf);
   len--;
 
   if (!len)
      RETVALUE(ROK);

   /* get the switch */
   CMCHKUNPK( SUnpkS16, &addr->sw, mBuf);

   /* if available, get the ssf */
   CMCHKUNPK ( SUnpkU8, &addr->ssfPres, mBuf );
   if (addr->ssfPres)
   {
      CMCHKUNPK( SUnpkU8, &addr->ssf, mBuf);
   }

   /* get address indicators */
   CMCHKUNPK( SUnpkU8, &octet, mBuf);
   
   addr->pcInd = (U8)(octet & 0x01);
   addr->ssnInd = (U8)((octet >> 1) & 0x01);
   addr->gt.format = (U8)((octet >> 2) & 0x0f);
   addr->rtgInd = (U8)((octet >> 6) & 0x01);
   addr->niInd = (U8)((octet >> 7) & 0x01);
  
   /* if available, get the point code */
   if (addr->pcInd)
   {
      CMCHKUNPK( SUnpkU32, &addr->pc, mBuf);
   }
  
   /* if available, grab the subsystem number */
   if (addr->ssnInd)
   {
      CMCHKUNPK( SUnpkU8, &addr->ssn, mBuf);
   }
  
   /* if available, unpack the address....  */
   /* initialize length of GT digits to 0 if no GT present */
   if (addr->gt.format == GTFRMT_0)
   {
      addr->gt.addr.length = 0;
      RETVALUE(ROK);
   }

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   if ( (addr->sw == SW_ANSI) && (addr->gt.format == GTFRMT_1) )
       adjFrmt = GTFRMT_3;
   else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
       adjFrmt = addr->gt.format;

   switch(adjFrmt)
   {
      case GTFRMT_1:
      {
         /*
          * Odd/Even, and Nature of Address Indicator
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f1.oddEven = (U8)((octet >> 0x07) & 0x01);
         addr->gt.gt.f1.natAddr = (U8)(octet & 0x7f);
         break;
      }
      case GTFRMT_2:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f2.tType = octet;
  
         break;
      }
      case GTFRMT_3:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f3.tType = octet;
  
         /*
          * Encoding Scheme and Numbering Plan
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f3.encSch = (U8)(octet & 0x0f);
         addr->gt.gt.f3.numPlan = (U8)((octet >> 0x04) & 0x0f);
         break;
      }
      case GTFRMT_4:
      {
         /*
          * Translation type
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f4.tType = octet;
  
         /*
          * Encoding Scheme and Numbering Plan
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f4.encSch = (U8)(octet & 0x0f);
         addr->gt.gt.f4.numPlan = (U8)((octet >> 0x04) & 0x0f);
  
         /*
          * Nature of address indicator
          */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         addr->gt.gt.f4.natAddr = (U8)(octet & 0x7f);
         break;
      }
      case GTFRMT_5:
      {
         CMCHKUNPK( SUnpkU32, &addr->gt.gt.f5.ipAddr, mBuf);
         break;
      }
   }
   /* Address nibbles */
   CMCHKUNPK( cmUnpkLngAddr, (LngAddrs*)&addr->gt.addr, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSpAddr */

/*
*
*       Fun:   cmPkStOctet
*
*       Desc:  Pack an TCAP Octet
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkStOctet
(
StOctet *octet,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkStOctet(octet, mBuf)
StOctet *octet;
Buffer *mBuf;
#endif
{
   TRC2(cmPkStOctet)

   if (octet->pres == TRUE)
   {
      /* pack octet contents */
      CMCHKPK( SPkU8, octet->octet, mBuf);
   }
   /* pack present/nonpresent */
   CMCHKPK(cmPkBool, octet->pres, mBuf);
  
   RETVALUE(ROK);
}  /* end of cmPkStOctet */


/*
*
*       Fun:   Unpack TCAP Octet
*
*       Desc:  This function is used to unpack a TCAP octet
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkStOctet
(
StOctet *octet,
Buffer *mBuf 
)
#else
PUBLIC S16 cmUnpkStOctet(octet, mBuf)
StOctet *octet;
Buffer *mBuf;
#endif
{
   
   TRC2(cmUnpkStOctet)

   CMCHKUNPK( cmUnpkBool, &octet->pres, mBuf);
   
   if (octet->pres == TRUE)
   {
      /* unpack contents */
      CMCHKUNPK( SUnpkU8, &octet->octet, mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkStOctet */

/*
*
*       Fun:   cmPkStStr
*
*       Desc:  Pack an TCAP variable length string
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkStStr
(
StStr *string,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkStStr(string, mBuf)
StStr *string;
Buffer *mBuf;
#endif
{
   S16  i;
   
   TRC2(cmPkStStr)

   if (string == (StStr *)NULLP || string->len == 0)
   {
      RETVALUE(SPkU16(0, mBuf));
   }
   /* pack contents of string first - reverse order */
   for(i=string->len-1;i>=0;i--)
   {
      CMCHKPK( SPkU8, string->string[i], mBuf);
   }
   /* pack length of string */
   CMCHKPK( SPkU16, (U16)string->len, mBuf);
   RETVALUE(ROK);
}  /* end of cmPkStStr */

/*
*
*       Fun:   Unpack TCAP String
*
*       Desc:  This function is used to unpack a TCAP string
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkStStr
(
StStr *string,
Buffer *mBuf 
)
#else
PUBLIC S16 cmUnpkStStr(string, mBuf)
StStr *string;
Buffer *mBuf;
#endif
{
   U16 i;
   
   TRC2(cmUnpkStStr)

   CMCHKUNPK( SUnpkU16, &string->len, mBuf); 
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if(string->len > MAX_ST_STRING)
   {
      RETVALUE(RFAILED);
   }
#endif
   for(i=0;i<string->len;i++)
   {
      CMCHKUNPK( SUnpkU8, &string->string[i], mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkStStr */

/*
*
*       Fun:   cmPkSteMgmt
*
*       Desc:  Pack an status management structure 
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSteMgmt
(
CmSS7SteMgmt *steMgmt,
Buffer       *mBuf
)
#else
PUBLIC S16 cmPkSteMgmt(steMgmt, mBuf)
CmSS7SteMgmt *steMgmt;
Buffer       *mBuf;
#endif
{
   
   TRC2(cmPkSteMgmt)

   switch(steMgmt->evntType)
   {
      case EVTSSN_STE_REQ:
        CMCHKPK(cmPkUStat, steMgmt->mgmt.steReq.uStat, mBuf); 
        CMCHKPK(cmPkSsn,   steMgmt->mgmt.steReq.aSsn,  mBuf); 
        break;

      case EVTSSN_STE_IND:
        CMCHKPK(cmPkSmi,   steMgmt->mgmt.steInd.smi,   mBuf); 
        CMCHKPK(cmPkUStat, steMgmt->mgmt.steInd.uStat, mBuf); 
        CMCHKPK(cmPkSsn,   steMgmt->mgmt.steInd.aSsn,  mBuf); 
        CMCHKPK(cmPkDpc,   steMgmt->mgmt.steInd.aDpc,  mBuf); 
        break;

      case EVTSSN_CORD_REQ:
        CMCHKPK(cmPkSsn, steMgmt->mgmt.cordReq.aSsn, mBuf); 
        break;

      case EVTSSN_CORD_IND:
        CMCHKPK(cmPkSmi, steMgmt->mgmt.cordInd.smi,  mBuf); 
        CMCHKPK(cmPkSsn, steMgmt->mgmt.cordInd.aSsn, mBuf); 
        break;

      case EVTSSN_CORD_RSP:
        CMCHKPK(cmPkSsn, steMgmt->mgmt.cordRsp.aSsn, mBuf); 
        break;

      case EVTSSN_CORD_CFM:
        CMCHKPK(cmPkSmi, steMgmt->mgmt.cordCfm.smi,  mBuf); 
        CMCHKPK(cmPkSsn, steMgmt->mgmt.cordCfm.aSsn, mBuf); 
        break;

      case EVTPC_STE_IND:
        CMCHKPK(cmPkSps, steMgmt->mgmt.PCSteInd.sps, mBuf); 
        CMCHKPK(cmPkDpc, steMgmt->mgmt.PCSteInd.dpc, mBuf); 
        break;

      case EVTSSN_STA_REQ:
        CMCHKPK(cmPkSsn, steMgmt->mgmt.staCfm.ssn,    mBuf); 
        CMCHKPK(cmPkDpc, steMgmt->mgmt.staCfm.dpc,    mBuf); 
        CMCHKPK(SPkU8,   steMgmt->mgmt.steCfm.status, mBuf); 
        break;

      case EVTSSN_STE_CFM:
        CMCHKPK(SPkU8, steMgmt->mgmt.steCfm.status, mBuf); 
        break;

      case EVTSSN_STA_CFM:
        CMCHKPK(cmPkSmi,   steMgmt->mgmt.staCfm.smi,    mBuf); 
        CMCHKPK(cmPkUStat, steMgmt->mgmt.staCfm.ustat,  mBuf); 
        CMCHKPK(cmPkSsn,   steMgmt->mgmt.staCfm.ssn,    mBuf); 
        CMCHKPK(cmPkDpc,   steMgmt->mgmt.staCfm.dpc,    mBuf); 
        CMCHKPK(SPkU8,     steMgmt->mgmt.staCfm.status, mBuf); 
        break;

      default:
        RETVALUE(RFAILED);
   }

   CMCHKPK(SPkU8, steMgmt->evntType, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSteMgmt */

/*
*
*       Fun:   cmUnpkSteMgmt
*
*       Desc:  Pack an status management structure 
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  cm_ss7.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSteMgmt
(
CmSS7SteMgmt *steMgmt,
Buffer       *mBuf
)
#else
PUBLIC S16 cmUnpkSteMgmt(steMgmt, mBuf)
CmSS7SteMgmt *steMgmt;
Buffer       *mBuf;
#endif
{
   
   TRC2(cmUnpkSteMgmt)

   CMCHKUNPK(SUnpkU8, &steMgmt->evntType, mBuf);

   switch(steMgmt->evntType)
   {
      case EVTSSN_STE_REQ:
        CMCHKUNPK(cmUnpkSsn,   &steMgmt->mgmt.steReq.aSsn,  mBuf); 
        CMCHKUNPK(cmUnpkUStat, &steMgmt->mgmt.steReq.uStat, mBuf); 
        break;

      case EVTSSN_STE_IND:
        CMCHKUNPK(cmUnpkDpc,   &steMgmt->mgmt.steInd.aDpc,  mBuf); 
        CMCHKUNPK(cmUnpkSsn,   &steMgmt->mgmt.steInd.aSsn,  mBuf); 
        CMCHKUNPK(cmUnpkUStat, &steMgmt->mgmt.steInd.uStat, mBuf); 
        CMCHKUNPK(cmUnpkSmi,   &steMgmt->mgmt.steInd.smi,   mBuf); 
        break;

      case EVTSSN_CORD_REQ:
        CMCHKUNPK(cmUnpkSsn, &steMgmt->mgmt.cordReq.aSsn, mBuf); 
        break;

      case EVTSSN_CORD_IND:
        CMCHKUNPK(cmUnpkSsn, &steMgmt->mgmt.cordInd.aSsn, mBuf); 
        CMCHKUNPK(cmUnpkSmi, &steMgmt->mgmt.cordInd.smi,  mBuf); 
        break;

      case EVTSSN_CORD_RSP:
        CMCHKUNPK(cmUnpkSsn, &steMgmt->mgmt.cordRsp.aSsn, mBuf); 
        break;

      case EVTSSN_CORD_CFM:
        CMCHKUNPK(cmUnpkSsn, &steMgmt->mgmt.cordCfm.aSsn, mBuf); 
        CMCHKUNPK(cmUnpkSmi, &steMgmt->mgmt.cordCfm.smi,  mBuf); 
        break;

      case EVTPC_STE_IND:
        CMCHKUNPK(cmUnpkDpc, &steMgmt->mgmt.PCSteInd.dpc, mBuf); 
        CMCHKUNPK(cmUnpkSps, &steMgmt->mgmt.PCSteInd.sps, mBuf); 
        break;

      case EVTSSN_STA_REQ:
        CMCHKUNPK(SUnpkU8,   &steMgmt->mgmt.steCfm.status, mBuf); 
        CMCHKUNPK(cmUnpkDpc, &steMgmt->mgmt.staCfm.dpc,    mBuf); 
        CMCHKUNPK(cmUnpkSsn, &steMgmt->mgmt.staCfm.ssn,    mBuf); 
        break;

      case EVTSSN_STE_CFM:
        CMCHKUNPK(SUnpkU8, &steMgmt->mgmt.steCfm.status, mBuf); 
        break;

      case EVTSSN_STA_CFM:
        CMCHKUNPK(SUnpkU8,     &steMgmt->mgmt.staCfm.status, mBuf); 
        CMCHKUNPK(cmUnpkDpc,   &steMgmt->mgmt.staCfm.dpc,    mBuf); 
        CMCHKUNPK(cmUnpkSsn,   &steMgmt->mgmt.staCfm.ssn,    mBuf); 
        CMCHKUNPK(cmUnpkUStat, &steMgmt->mgmt.staCfm.ustat,  mBuf); 
        CMCHKUNPK(cmUnpkSmi,   &steMgmt->mgmt.staCfm.smi,    mBuf); 
        break;

      default:
        RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}  /* end of cmUnpkSteMgmt */


/*
*
*       Fun:   cmPkSpIsni
*
*       Desc:  Pack SpIsni
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpIsni
(
SpIsni *spIsni,        /* Isni */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmPkSpIsni(spIsni, mBuf)
SpIsni *spIsni;        /* Isni */
Buffer *mBuf;          /* message buffer */
#endif
{
   U16 i;              /* loop counter */
   
   TRC2(cmPkSpIsni)

   /* if isni parameter is present then pack other fields of SpIsni struct */
   if (spIsni->isniPres != NOTPRSNT)
   {
      for (i = 0; i < spIsni->noOfNids; i++)
         CMCHKPK(SPkU16, spIsni->nid[i], mBuf);

      CMCHKPK(SPkU8, spIsni->noOfNids, mBuf);
      CMCHKPK(SPkU8, spIsni->isniRtCtrlExt, mBuf);
      CMCHKPK(SPkU8, spIsni->isniCounter, mBuf);
      CMCHKPK(SPkU8, spIsni->isniTypInd, mBuf);
      CMCHKPK(SPkU8, spIsni->isniRteInd, mBuf);
      CMCHKPK(SPkU8, spIsni->isniMiInd, mBuf);
   }

   /* pack isniPres field */
   CMCHKPK(SPkU8, spIsni->isniPres, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSpIsni */


/*
*
*       Fun:   cmUnpkSpIsni
*
*       Desc:  Unpack SpIsni
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpIsni
(
SpIsni *spIsni,        /* Isni */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSpIsni(spIsni, mBuf)
SpIsni *spIsni;        /* Isni */
Buffer *mBuf;          /* message buffer */
#endif
{
   S16 i;              /* loop counter */
   
   TRC2(cmUnpkSpIsni)

   /* Unpack isniPres field */
   CMCHKUNPK(SUnpkU8, &spIsni->isniPres, mBuf);

   /* if isni parameter is present then unpack other fields of SpIsni struct */
   if (spIsni->isniPres != NOTPRSNT)
   {
      CMCHKUNPK(SUnpkU8, &spIsni->isniMiInd, mBuf);
      CMCHKUNPK(SUnpkU8, &spIsni->isniRteInd, mBuf);
      CMCHKUNPK(SUnpkU8, &spIsni->isniTypInd, mBuf);
      CMCHKUNPK(SUnpkU8, &spIsni->isniCounter, mBuf);
      CMCHKUNPK(SUnpkU8, &spIsni->isniRtCtrlExt, mBuf);
      CMCHKUNPK(SUnpkU8, &spIsni->noOfNids, mBuf);

      for (i = (S16) (spIsni->noOfNids - 1); i >= 0; i--)
         CMCHKUNPK(SUnpkU16, &spIsni->nid[i], mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkSpIsni */


/*
*
*       Fun:   cmPkSpIns
*
*       Desc:  Pack SpIns
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpIns
(
SpIns *spIns,          /* Ins */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmPkSpIns(spIns, mBuf)
SpIns *spIns;          /* Ins */
Buffer *mBuf;          /* message buffer */
#endif
{
   U16 i;              /* loop counter */
   
   TRC2(cmPkSpIns)

   /* if ins parameter is present then pack other fields of SpIns struct */
   if (spIns->insPres != NOTPRSNT)
   {
      for (i = 0; i < spIns->noOfNids; i++)
         CMCHKPK(SPkU16, spIns->nid[i], mBuf);

      CMCHKPK(SPkU8, spIns->noOfNids, mBuf);
      CMCHKPK(SPkU8, spIns->insCounter, mBuf);
      CMCHKPK(SPkU8, spIns->insRteInd, mBuf);
      CMCHKPK(SPkU8, spIns->insInfTypInd, mBuf);
   }

   /* pack insPres field */
   CMCHKPK(SPkU8, spIns->insPres, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSpIns */


/*
*
*       Fun:   cmUnpkSpIns
*
*       Desc:  Unpack SpIns
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpIns
(
SpIns *spIns,          /* Ins */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSpIns(spIns, mBuf)
SpIns *spIns;          /* Ins */
Buffer *mBuf;          /* message buffer */
#endif
{
   S16 i;              /* loop counter */
   
   TRC2(cmUnpkSpIns)

   /* Unpack insPres field */
   CMCHKUNPK(SUnpkU8, &spIns->insPres, mBuf);

   /* if ins parameter is present then unpack other fields of SpIns struct */
   if (spIns->insPres != NOTPRSNT)
   {
      CMCHKUNPK(SUnpkU8, &spIns->insInfTypInd, mBuf);
      CMCHKUNPK(SUnpkU8, &spIns->insRteInd, mBuf);
      CMCHKUNPK(SUnpkU8, &spIns->insCounter, mBuf);
      CMCHKUNPK(SUnpkU8, &spIns->noOfNids, mBuf);

      for (i = (S16) (spIns->noOfNids - 1); i >= 0; i--)
         CMCHKUNPK(SUnpkU16, &spIns->nid[i], mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkSpIns */


/********************************************************************30**
  
         End of file:     cm_ss7.c@@/main/18 - Fri Sep 16 02:57:40 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.

1.2          ---  aa    1. Changed the packing and unpacking such that the
                           return values of functions are checked only under
                           ADD_RES calss (for packing) and under the DEBUG
                           class for unpacking routines. The macro's used 
                           can be found in ssi.h
1.3          ---  mjp   1. changed cmCopyGt to use SW_ANSI and SW_ITU
             ---  mjp   2. changed spaddr switch to SW_ANSI from SW_ANSI88,
                           or SW_ANSI92
             ---  aa    3. Added the packing and unpacking for steMgmt.

1.4          ---  mjp   1. added packing/unpacking of ssf in spAddr structure 
                           added ssf and ssfPress to cmCopySpAddr

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.5          ---      sg   1. added conditional compile time inclusion for
                              the header file cm_gen.h

1.6          ---      nj   1. Added packing and unpacking for the aDpc
                              parameter to the CmSS7SteMgmt structure for
                              SteInd primitive at the STU interface.

1.7          ---      nj   1. Added packing and unpacking for more
                              event types in CmSS7SteMgmt structure for STU2.

1.8          ---      hrg  1. Added function cmPrntShrtAddrs.
                           2. Added support for the fifth format of global
                              title for TCAP over TCP/IP addressing.

1.9          ---      cp   1. Modified packing/unpacking fns for SpAddr 
                              and cmCopySpAddr for spHdrOpt field.
/main/11     ---      jjn  1. Added 64 bit support for cmZero and cmCopy.
                              To take advantage of the library functions,
                              do not turn on the DONT_USE_SYS_LIB flag.
                      hy   2. File header is updated.
/main/12     ---      dw   1. Added pk/unpk for GlbTi
/main/13     ---      rc   1. Rolling upgrade changes as per tcr0020.txt:
                              -  defining bit vector for CMSS7_SPHDROPT and 
                                 unpacking fields accordingly.
/main/14     ---      rc   1. functions for packing/unpacking isni and ins added
                           2. compile flag SS7_ANS96 and SS7_BELL05 are ORed
                              along with ANS88 and ANS92 flags.
/main/15     ---      rc   1. Initializing length of GT digits to 0 if no GT
                              is present when unpacking SpAddr
/main/16     ---     ssk   1. Fixed the UNPK macro in cmUnpkSteMgmt.        

/main/17     ---      cp   1. Removed STU2 flag
/main/18     ---      st   1. Update for MAP Release 2.3
*********************************************************************91*/
