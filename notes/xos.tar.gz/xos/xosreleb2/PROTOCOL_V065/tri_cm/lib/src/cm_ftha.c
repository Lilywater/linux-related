/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Common Distributed Fault Tolerant/High Availability
               Architecture
  
     Type:     C Source Code.
  
     Desc:     This file contains structure packing and unpacking functions
               for all common distributed fault tolerant/high availability
               structures.

     File:     cm_ftha.c

     Sid:      cm_ftha.c@@/main/4 - Mon Nov  5 14:26:33 2001
  
     Prg:      ark
  
*********************************************************************21*/

/* Header include files (.h)            */
#include "envopt.h"                             /* environment options      */
#include "envdep.h"                             /* environment dependent    */
#include "envind.h"                             /* environment independent  */
#include "gen.h"                                /* general layer            */
#include "ssi.h"                                /* system service interface */
#include "cm_ftha.h"                            /* common dist FT/HA        */
 
/* header/extern include files (.x)     */
#include "gen.x"                                /* general layer            */
#include "ssi.x"                                /* system service interface */
#include "cm_ftha.x"                            /* common dist FT/HA        */


/*
 *
 *      Fun  : cmPkFthaRset
 *
 *      Desc : This function packs a resource set identification structure
 *             containing an entity, instance and resource set identifier.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaRset
(
CmFthaRset      *rset,                          /* rset spec to pack    */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaRset(rset, mBuf)
CmFthaRset      *rset;                          /* rset spec to pack    */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaRset)

   /* pack structure fields             */
   CMCHKPK(cmPkEnt,        rset->ent,    mBuf);
   CMCHKPK(cmPkInst,       rset->inst,   mBuf);
   CMCHKPK(cmPkFthaRsetId, rset->rsetId, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaRset */


/*
 *
 *      Fun  : cmPkFthaRsetType
 *
 *      Desc : This function packs a resource set type structure. This
 *             structure contains the resource set type and an additional type
 *             qualifier.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaRsetType
(
CmFthaRsetType  *type,                          /* rset type to pack    */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaRsetType(type, mBuf)
CmFthaRsetType  *type;                          /* rset type to pack    */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaRsetType)

   /* pack structure fields             */
   CMCHKPK(SPkU8, type->type, mBuf);
   CMCHKPK(SPkU8, type->qual, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaRsetType */


/*
 *
 *      Fun  : cmPkFthaRsetRange
 *
 *      Desc : This function packs a resource set range structure. This
 *             structure contains the ids of the first and last resource sets
 *             in the range.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaRsetRange
(
CmFthaRsetRange *range,                         /* rset range to pack   */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaRsetRange(range, mBuf)
CmFthaRsetRange *range;                         /* rset range to pack   */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaRsetRange)

   /* pack structure fields             */
   CMCHKPK(cmPkFthaRsetId, range->start, mBuf);
   CMCHKPK(cmPkFthaRsetId, range->end, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaRsetRange */


/*
 *
 *      Fun  : cmPkFthaRsetGrp
 *
 *      Desc : This function packs a resource set group identification
 *             structure containing an entity, instance and a list of
 *             resource set identifiers.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaRsetGrp
(
CmFthaRsetGrp   *rsetGrp,                       /* rset grp to pack     */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaRsetGrp(rsetGrp, mBuf)
CmFthaRsetGrp   *rsetGrp;                       /* rset grp to pack     */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   S32          idx;                          /* rset id list index   */

   TRC2(cmPkFthaRsetGrp)

   /* pack structure fields             */
   CMCHKPK(cmPkEnt,  rsetGrp->ent,  mBuf);
   CMCHKPK(cmPkInst, rsetGrp->inst, mBuf);
   /* pack array first, then length     */
   for(idx = 0; idx < rsetGrp->nmbRsets; ++idx)
      CMCHKPK(cmPkFthaRsetId, rsetGrp->rsetId[idx], mBuf);
   CMCHKPK(SPkU16, rsetGrp->nmbRsets, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaRsetGrp */


/*
 *
 *      Fun  : cmPkFthaGoActPar
 *
 *      Desc : This function packs parameters for the goActive control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaGoActPar
(
CmFthaGoActPar  *actPar,                        /* Active par to pack   */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaGoActPar(actPar, mBuf)
CmFthaGoActPar  *actPar;                        /* Active par to pack   */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaGoActPar)

   /* pack structure fields             */
   CMCHKPK(cmPkBool,         actPar->disPeerSap,     mBuf);
   CMCHKPK(cmPkFthaMasterId, actPar->masterId,       mBuf);
   CMCHKPK(cmPkFthaSeqNum,   actPar->startUpdSeqNum, mBuf);
   CMCHKPK(cmPkBool,         actPar->recovery,       mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaGoActPar */


/*
 *
 *      Fun  : cmPkFthaGoSbyPar
 *
 *      Desc : This function packs parameters for the goStandby control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaGoSbyPar
(
CmFthaGoSbyPar  *sbyPar,                        /* Standby par to pack  */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaGoSbyPar(sbyPar, mBuf)
CmFthaGoSbyPar  *sbyPar;                        /* Standby par to pack  */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaGoSbyPar)

   /* pack structure fields             */
   CMCHKPK(cmPkFthaMasterId, sbyPar->masterId,        mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaGoSbyPar */


/*
 *
 *      Fun  : cmPkFthaBndEnaPar
 *
 *      Desc : This function packs parameters for the Bind & Enable control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaBndEnaPar
(
CmFthaBndEnaPar *bndEnaPar,                     /* Bnd&Ena par to pack  */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaBndEnaPar(bndEnaPar, mBuf)
CmFthaBndEnaPar *bndEnaPar;                     /* Bnd&Ena par to pack  */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaBndEnaPar)

   /* pack structure fields             */
   CMCHKPK(SPkU8,      bndEnaPar->grpType,   mBuf);
   CMCHKPK(cmPkProcId, bndEnaPar->dstProcId, mBuf);
   CMCHKPK(cmPkEnt,    bndEnaPar->dstEnt,    mBuf);
   CMCHKPK(cmPkInst,   bndEnaPar->dstInst,   mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaBndEnaPar */


/*
 *
 *      Fun  : cmPkFthaUBndDisPar
 *
 *      Desc : This function packs parameters for the UnBind & Disable control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaUBndDisPar
(
CmFthaUBndDisPar *uBndDisPar,                   /* UBnd&Dis par to pack */
Buffer           *mBuf                          /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaUBndDisPar(uBndDisPar, mBuf)
CmFthaUBndDisPar *uBndDisPar;                   /* UBnd&Dis par to pack */
Buffer           *mBuf;                         /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaUBndDisPar)

   /* pack structure fields             */
   CMCHKPK(SPkU8,      uBndDisPar->grpType,   mBuf);
   CMCHKPK(cmPkProcId, uBndDisPar->dstProcId, mBuf);
   CMCHKPK(cmPkEnt,    uBndDisPar->dstEnt,    mBuf);
   CMCHKPK(cmPkInst,   uBndDisPar->dstInst,   mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaUBndDisPar */


/*
 *
 *      Fun  : cmPkFthaPeerPingPar
 *
 *      Desc : This function packs parameters for the Peer Ping control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaPeerPingPar
(
CmFthaPeerPingPar *peerPing,                    /* PeerPing par to pack */
Buffer            *mBuf                         /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaPeerPingPar(peerPing, mBuf)
CmFthaPeerPingPar *peerPing;                    /* PeerPing par to pack */
Buffer            *mBuf;                        /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaPeerPingPar)

   /* pack structure fields             */
   CMCHKPK(cmPkProcId, peerPing->dstProcId, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaPeerPingPar */


/*
 *
 *      Fun  : cmPkFthaAbortPar
 *
 *      Desc : This function packs parameters for the Abort control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaAbortPar
(
CmFthaAbortPar  *abrt,                          /* Abort par to pack    */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaAbortPar(abrt, mBuf)
CmFthaAbortPar  *abrt;                          /* Abort par to pack    */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaAbortPar)

   /* pack structure fields             */
   CMCHKPK(cmPkTranId, abrt->transId, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaAbortPar */


/*
 *
 *      Fun  : cmPkFthaStaPar
 *
 *      Desc : This function packs parameters for the common resource set
 *             Status request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaStaPar
(
CmFthaStaPar    *sta,                           /* Sta par to pack      */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaStaPar(sta, mBuf)
CmFthaStaPar    *sta;                           /* Sta par to pack      */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaStaPar)

   /* pack structure fields             */
   CMCHKPK(cmPkFthaMasterId, sta->masterId,      mBuf);
   CMCHKPK(cmPkFthaSeqNum,   sta->crntUpdSeqNum, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaStaPar */


#ifdef TDS_ROLL_UPGRADE_SUPPORT
/*
 *
 *      Fun  : cmPkFthaGetVer
 *
 *      Desc : This function packs parameters for the get interface version
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaGetVer
(
CmFthaGetVer    *gvPar,                         /* get ver par to pack  */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaGetVer(gvPar, mBuf)
CmFthaGetVer    *gvPar;                         /* get ver par to pack  */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   U16     intfIndex;

   TRC2(cmPkFthaGetVer)

   /* pack structure fields             */
   for(intfIndex=0; intfIndex < gvPar->rc.gvCfm.numUif; intfIndex++)
      CMCHKPK(cmPkIntf, &gvPar->rc.gvCfm.uifList[intfIndex], mBuf);
   CMCHKPK(SPkU16, gvPar->rc.gvCfm.numUif, mBuf);
   for(intfIndex=0; intfIndex < gvPar->rc.gvCfm.numLif; intfIndex++)
      CMCHKPK(cmPkIntf, &gvPar->rc.gvCfm.lifList[intfIndex], mBuf);
   CMCHKPK(SPkU16, gvPar->rc.gvCfm.numLif, mBuf);
   CMCHKPK(cmPkIntf, &gvPar->rc.gvCfm.pif, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaGetVer */


/*
 *
 *      Fun  : cmPkFthaSetVerPar
 *
 *      Desc : This function packs parameters for the set interface version
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaSetVerPar
(
CmFthaSetVerPar *svPar,                         /* set ver par to pack  */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaSetVerPar(svPar, mBuf)
CmFthaSetVerPar *svPar;                         /* set ver par to pack  */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{

   TRC2(cmPkFthaSetVerPar)

   /* pack structure fields             */
   CMCHKPK(SPkU8,        svPar->grpType,   mBuf);
   CMCHKPK(cmPkProcId,   svPar->dstProcId, mBuf);
   CMCHKPK(cmPkEntityId, &svPar->dstEnt,   mBuf);
   CMCHKPK(cmPkIntf,     &svPar->intf,     mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaSetVerPar */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */


/*
 *
 *      Fun  : cmPkFthaRsetPar
 *
 *      Desc : This function packs parameters of the resource set parameter
 *             structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaRsetPar
(
CmFthaRsetPar   *rset,                          /* Rset par to pack     */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaRsetPar(rset, action, subAction, mBuf)
CmFthaRsetPar   *rset;                          /* Rset par to pack     */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   TRC2(cmPkFthaRsetPar)

   /* pack params based on action fld   */
   switch(action)
   {
      case CMFTHA_AGOACTIVE:
         cmPkFthaGoActPar(&rset->cntrlPar.gaPar, mBuf);
         break;
      case CMFTHA_AGOSTANDBY:
         cmPkFthaGoSbyPar(&rset->cntrlPar.gsPar, mBuf);
         break;
      case CMFTHA_ABNDENA:
         cmPkFthaBndEnaPar(&rset->cntrlPar.bePar, mBuf);
         break;
      case CMFTHA_AUBNDDIS:
         cmPkFthaUBndDisPar(&rset->cntrlPar.udPar, mBuf);
         break;
      case CMFTHA_APEERPING:
         cmPkFthaPeerPingPar(&rset->cntrlPar.ppPar, mBuf);
         break;
      case CMFTHA_AABORT:
         cmPkFthaAbortPar(&rset->cntrlPar.abPar, mBuf);
         break;
      case CMFTHA_ASTAT:
         cmPkFthaStaPar(&rset->cntrlPar.statPar, mBuf);
         break;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      case CMFTHA_AGETVER:
         cmPkFthaGetVer(&rset->cntrlPar.gvPar, mBuf);
         break;
      case CMFTHA_ASETVER:
         cmPkFthaSetVerPar(&rset->cntrlPar.svPar, mBuf);
         break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      default:
         break;
   }
   /* pack structure fields             */
   CMCHKPK(cmPkFthaRsetId, rset->rsetId,  mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaRsetPar */


/*
 *
 *      Fun  : cmPkFthaEntPar
 *
 *      Desc : This function packs parameters of the entity parameter
 *             structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaEntPar
(
CmFthaEntPar    *ent,                           /* Ent par to pack      */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaEntPar(ent, action, subAction, mBuf)
CmFthaEntPar    *ent;                           /* Ent par to pack      */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   S32          idx;                          /* ent par list index   */

   TRC2(cmPkFthaEntPar)

   /* pack structure fields             */
   CMCHKPK(cmPkEnt,  ent->entId,      mBuf);
   CMCHKPK(cmPkInst, ent->instId,     mBuf);
   CMCHKPK(cmPkBool, ent->waitForAck, mBuf);
   /* pack ent par list then length     */
   for(idx = 0; idx < ent->nmbRsets; ++idx)
   {
      cmPkFthaRsetPar(&ent->rsetPar[idx], action, subAction, mBuf);
   }
   CMCHKPK(SPkU16, ent->nmbRsets, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaEntPar */


/*
 *
 *      Fun  : cmPkFthaCfnPar
 *
 *      Desc : This function packs parameters of the conversion fn. parameter
 *             structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkFthaCfnPar
(
CmFthaCfnPar    *cfn,                           /* Cfn par to pack      */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* pack into this mBuf  */
)
#else
PUBLIC S16 cmPkFthaCfnPar(cfn, action, subAction, mBuf)
CmFthaCfnPar    *cfn;                           /* Cfn par to pack      */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* pack into this mBuf  */
#endif
{
   S32          idx;                          /* cfn par list index   */

   TRC2(cmPkFthaCfnPar)

   /* pack cfn par list then length     */
   for(idx = 0; idx < cfn->nmbEnts; ++idx)
   {
      cmPkFthaEntPar(&cfn->entPar[idx], action, subAction, mBuf);
   }
   CMCHKPK(SPkU16, cfn->nmbEnts, mBuf);

   RETVALUE(ROK);
} /* end of cmPkFthaCfnPar */



/*=============================================================================
 *
 * Unpacking Functions
 *
 ============================================================================*/

/*
 *
 *      Fun  : cmUnpkFthaRset
 *
 *      Desc : This function unpacks a resource set identification structure
 *             containing an entity, instance and resource set identifier.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaRset
(
CmFthaRset      *rset,                          /* upack rset spec here */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaRset(rset, mBuf)
CmFthaRset      *rset;                          /* upack rset spec here */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaRset)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkFthaRsetId, &rset->rsetId, mBuf);
   CMCHKUNPK(cmUnpkInst,       &rset->inst,   mBuf);
   CMCHKUNPK(cmUnpkEnt,        &rset->ent,    mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaRset */


/*
 *
 *      Fun  : cmUnpkFthaRsetType
 *
 *      Desc : This function unpacks a resource set type structure. This
 *             structure contains the resource set type and an additional type
 *             qualifier.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaRsetType
(
CmFthaRsetType  *type,                          /* upack rset type here */
Buffer          *mBuf                           /* upack from this mBuf */
)
#else
PUBLIC S16 cmUnpkFthaRsetType(type, mBuf)
CmFthaRsetType  *type;                          /* upack rset type here */
Buffer          *mBuf;                          /* upack from this mBuf */
#endif
{
   TRC2(cmUnpkFthaRsetType)

   /* unpack structure fields           */
   CMCHKUNPK(SUnpkU8, &type->qual, mBuf);
   CMCHKUNPK(SUnpkU8, &type->type, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaRsetType */


/*
 *
 *      Fun  : cmUnpkFthaRsetRange
 *
 *      Desc : This function unpacks a resource set range structure. This
 *             structure contains the ids of the first and last resource sets
 *             in the range.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaRsetRange
(
CmFthaRsetRange *range,                         /* upack range here     */
Buffer          *mBuf                           /* upack from this mBuf */
)
#else
PUBLIC S16 cmUnpkFthaRsetRange(range, mBuf)
CmFthaRsetRange *range;                         /* upack range here     */
Buffer          *mBuf;                          /* upack from this mBuf */
#endif
{
   TRC2(cmUnpkFthaRsetRange)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkFthaRsetId, &range->end, mBuf);
   CMCHKUNPK(cmUnpkFthaRsetId, &range->start, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaRsetRange */


/*
 *
 *      Fun  : cmUnpkFthaRsetGrp
 *
 *      Desc : This function unpacks a resource set group identification
 *             structure containing an entity, instance and a list of
 *             resource set identifiers.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaRsetGrp
(
CmFthaRsetGrp   *rsetGrp,                       /* upack rset grp here  */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaRsetGrp(rsetGrp, mBuf)
CmFthaRsetGrp   *rsetGrp;                       /* upack rset grp here  */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   S32          idx;                          /* rset id list index   */

   TRC2(cmUnpkFthaRsetGrp)

   /* unpack length then array entries  */
   CMCHKUNPK(SUnpkU16, &rsetGrp->nmbRsets, mBuf);
   for(idx = rsetGrp->nmbRsets-1; idx >= 0; --idx)
      CMCHKUNPK(cmUnpkFthaRsetId, &rsetGrp->rsetId[idx], mBuf);
   /* unpack structure fields           */
   CMCHKUNPK(cmUnpkInst, &rsetGrp->inst, mBuf);
   CMCHKUNPK(cmUnpkEnt,  &rsetGrp->ent,  mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaRsetGrp */


/*
 *
 *      Fun  : cmUnpkFthaGoActPar
 *
 *      Desc : This function unpacks parameters for the goActive control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaGoActPar
(
CmFthaGoActPar  *actPar,                        /* upack act par here   */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaGoActPar(actPar, mBuf)
CmFthaGoActPar  *actPar;                        /* upack act par here   */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaGoActPar)

   /* unpack structure fields           */
   CMCHKUNPK(cmUnpkBool,         &actPar->recovery,       mBuf);
   CMCHKUNPK(cmUnpkFthaSeqNum,   &actPar->startUpdSeqNum, mBuf);
   CMCHKUNPK(cmUnpkFthaMasterId, &actPar->masterId,       mBuf);
   CMCHKUNPK(cmUnpkBool,         &actPar->disPeerSap,     mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaGoActPar */


/*
 *
 *      Fun  : cmUnpkFthaGoSbyPar
 *
 *      Desc : This function unpacks parameters for the goStandby control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaGoSbyPar
(
CmFthaGoSbyPar  *sbyPar,                        /* upack sby par here   */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaGoSbyPar(sbyPar, mBuf)
CmFthaGoSbyPar  *sbyPar;                        /* upack sby par here   */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaGoSbyPar)

   /* unpack structure fields           */
   CMCHKUNPK(cmUnpkFthaMasterId, &sbyPar->masterId, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaGoSbyPar */


/*
 *
 *      Fun  : cmUnpkFthaBndEnaPar
 *
 *      Desc : This function unpacks parameters for the Bind & Enable control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaBndEnaPar
(
CmFthaBndEnaPar *bndEnaPar,                     /* upack BndEna par here*/
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaBndEnaPar(bndEnaPar, mBuf)
CmFthaBndEnaPar *bndEnaPar;                     /* upack BndEna par here*/
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaBndEnaPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkInst,   &bndEnaPar->dstInst,   mBuf);
   CMCHKUNPK(cmUnpkEnt,    &bndEnaPar->dstEnt,    mBuf);
   CMCHKUNPK(cmUnpkProcId, &bndEnaPar->dstProcId, mBuf);
   CMCHKUNPK(SUnpkU8,      &bndEnaPar->grpType,   mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaBndEnaPar */


/*
 *
 *      Fun  : cmUnpkFthaUBndDisPar
 *
 *      Desc : This function unpacks parameters for the UnBind & Disable control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaUBndDisPar
(
CmFthaUBndDisPar *uBndDisPar,                   /* upack UBndDis here   */
Buffer           *mBuf                          /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaUBndDisPar(uBndDisPar, mBuf)
CmFthaUBndDisPar *uBndDisPar;                   /* upack UBndDis here   */
Buffer           *mBuf;                         /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaUBndDisPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkInst,   &uBndDisPar->dstInst,   mBuf);
   CMCHKUNPK(cmUnpkEnt,    &uBndDisPar->dstEnt,    mBuf);
   CMCHKUNPK(cmUnpkProcId, &uBndDisPar->dstProcId, mBuf);
   CMCHKUNPK(SUnpkU8,      &uBndDisPar->grpType,   mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaUBndDisPar */


/*
 *
 *      Fun  : cmUnpkFthaPeerPingPar
 *
 *      Desc : This function unpacks parameters for the Peer Ping control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaPeerPingPar
(
CmFthaPeerPingPar *peerPing,                    /* upack PeerPing here  */
Buffer            *mBuf                         /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaPeerPingPar(peerPing, mBuf)
CmFthaPeerPingPar *peerPing;                    /* upack PeerPing here  */
Buffer            *mBuf;                        /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaPeerPingPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkProcId, &peerPing->dstProcId, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaPeerPingPar */


/*
 *
 *      Fun  : cmUnpkFthaAbortPar
 *
 *      Desc : This function unpacks parameters for the Abort control
 *             request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaAbortPar
(
CmFthaAbortPar  *abrt,                          /* upack Abort par here */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaAbortPar(abrt, mBuf)
CmFthaAbortPar  *abrt;                          /* upack Abort par here */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaAbortPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkTranId, &abrt->transId, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaAbortPar */


/*
 *
 *      Fun  : cmUnpkFthaStaPar
 *
 *      Desc : This function unpacks parameters for the common resource set
 *             Status request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaStaPar
(
CmFthaStaPar    *sta,                           /* upack Sta par here   */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaStaPar(sta, mBuf)
CmFthaStaPar    *sta;                           /* upack Sta par here   */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaStaPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkFthaSeqNum,   &sta->crntUpdSeqNum, mBuf);
   CMCHKUNPK(cmUnpkFthaMasterId, &sta->masterId,      mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaStaPar */


#ifdef TDS_ROLL_UPGRADE_SUPPORT
/*
 *
 *      Fun  : cmUnpkFthaGetVer
 *
 *      Desc : This function unpacks parameters for the common Get interface
 *             version request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaGetVer
(
CmFthaGetVer    *gvPar,                         /* upack get par here   */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaGetVer(gvPar, mBuf)
CmFthaGetVer    *gvPar;                         /* upack get par here   */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   S32      intfIndex;

   TRC2(cmUnpkFthaGetVer)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkIntf, &gvPar->rc.gvCfm.pif, mBuf);
   CMCHKUNPK(SUnpkU16, &gvPar->rc.gvCfm.numLif, mBuf);
   for(intfIndex = gvPar->rc.gvCfm.numLif-1; intfIndex >= 0; --intfIndex)
      CMCHKUNPK(cmUnpkIntf, &gvPar->rc.gvCfm.lifList[intfIndex], mBuf);
   CMCHKUNPK(SUnpkU16, &gvPar->rc.gvCfm.numUif, mBuf);
   for(intfIndex = gvPar->rc.gvCfm.numUif-1; intfIndex >= 0; --intfIndex)
      CMCHKUNPK(cmUnpkIntf, &gvPar->rc.gvCfm.uifList[intfIndex], mBuf);


   RETVALUE(ROK);
} /* end of cmUnpkFthaGetVer */


/*
 *
 *      Fun  : cmUnpkFthaSetVerPar
 *
 *      Desc : This function unpacks parameters for the common Set interface
 *             version request.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaSetVerPar
(
CmFthaSetVerPar *setVerPar,                     /* upack set par here   */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaSetVerPar(setVerPar, mBuf)
CmFthaSetVerPar *setVerPar;                     /* upack set par here   */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   TRC2(cmUnpkFthaSetVerPar)

   /* pack structure fields             */
   CMCHKUNPK(cmUnpkIntf,      &setVerPar->intf,      mBuf);
   CMCHKUNPK(cmUnpkEntityId,  &setVerPar->dstEnt,    mBuf);
   CMCHKUNPK(cmUnpkProcId,    &setVerPar->dstProcId, mBuf);
   CMCHKUNPK(SUnpkU8,         &setVerPar->grpType,   mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaSetVerPar */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */


/*
 *
 *      Fun  : cmUnpkFthaRsetPar
 *
 *      Desc : This function unpacks parameters of the resource set parameter
 *             structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaRsetPar
(
CmFthaRsetPar   *rset,                          /* Rset par to pack     */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* upack from this mBuf */
)
#else
PUBLIC S16 cmUnpkFthaRsetPar(rset, action, subAction, mBuf)
CmFthaRsetPar   *rset;                          /* Rset par to pack     */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* upack from this mBuf */
#endif
{
   TRC2(cmUnpkFthaRsetPar)

   /* unpack structure fields           */
   CMCHKPK(cmUnpkFthaRsetId, &rset->rsetId,  mBuf);
   /* unpack params based on action fld */
   switch(action)
   {
      case CMFTHA_AGOACTIVE:
         cmUnpkFthaGoActPar(&rset->cntrlPar.gaPar, mBuf);
         break;
      case CMFTHA_AGOSTANDBY:
         cmUnpkFthaGoSbyPar(&rset->cntrlPar.gsPar, mBuf);
         break;
      case CMFTHA_ABNDENA:
         cmUnpkFthaBndEnaPar(&rset->cntrlPar.bePar, mBuf);
         break;
      case CMFTHA_AUBNDDIS:
         cmUnpkFthaUBndDisPar(&rset->cntrlPar.udPar, mBuf);
         break;
      case CMFTHA_APEERPING:
         cmUnpkFthaPeerPingPar(&rset->cntrlPar.ppPar, mBuf);
         break;
      case CMFTHA_AABORT:
         cmUnpkFthaAbortPar(&rset->cntrlPar.abPar, mBuf);
         break;
      case CMFTHA_ASTAT:
         cmUnpkFthaStaPar(&rset->cntrlPar.statPar, mBuf);
         break;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      case CMFTHA_AGETVER:
         cmUnpkFthaGetVer(&rset->cntrlPar.gvPar, mBuf);
         break;
      case CMFTHA_ASETVER:
         cmUnpkFthaSetVerPar(&rset->cntrlPar.svPar, mBuf);
         break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      default:
         break;
   }

   RETVALUE(ROK);
} /* end of cmUnpkFthaRsetPar */


/*
 *
 *      Fun  : cmUnpkFthaEntPar
 *
 *      Desc : This function unpacks parameters of the entity parameter
 *             structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaEntPar
(
CmFthaEntPar    *ent,                           /* upack Ent par here   */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* from this mBuf       */
)
#else
PUBLIC S16 cmUnpkFthaEntPar(ent, action, subAction, mBuf)
CmFthaEntPar    *ent;                           /* upack Ent par here   */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* from this mBuf       */
#endif
{
   S32          idx;                          /* ent par list index   */

   TRC2(cmUnpkFthaEntPar)

   /* unpack length then ent par list   */
   CMCHKUNPK(SUnpkU16, &ent->nmbRsets, mBuf);
   for(idx = ent->nmbRsets-1; idx >= 0; --idx)
   {
      cmUnpkFthaRsetPar(&ent->rsetPar[idx], action, subAction, mBuf);
   }
   /* unpack structure fields           */
   CMCHKUNPK(cmUnpkBool, &ent->waitForAck, mBuf);
   CMCHKUNPK(cmUnpkInst, &ent->instId,     mBuf);
   CMCHKUNPK(cmUnpkEnt,  &ent->entId,      mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkFthaEntPar */


/*
 *
 *      Fun  : cmUnpkFthaCfnPar
 *
 *      Desc : This function unpacks parameters of the conversion fn.
 *             parameter structure.
 *
 *      Ret  : ROK     - successful.
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkFthaCfnPar
(
CmFthaCfnPar    *cfn,                           /* upack Cfn par here   */
Action          action,                         /* action value         */
Action          subAction,                      /* sub action value     */
Buffer          *mBuf                           /* from this  mBuf      */
)
#else
PUBLIC S16 cmUnpkFthaCfnPar(cfn, action, subAction, mBuf)
CmFthaCfnPar    *cfn;                           /* upack Cfn par here   */
Action          action;                         /* action value         */
Action          subAction;                      /* sub action value     */
Buffer          *mBuf;                          /* from this  mBuf      */
#endif
{
   S32          idx;                          /* cfn par list index   */

   TRC2(cmUnpkFthaCfnPar)

   /* unpack length then cfn par list   */
   CMCHKUNPK(SUnpkU16, &cfn->nmbEnts, mBuf);
   for(idx = cfn->nmbEnts-1; idx >= 0; --idx)
   {
      cmUnpkFthaEntPar(&cfn->entPar[idx], action, subAction, mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkFthaCfnPar */

/* Packing/Unpacking functions for the structures in cm_pftha.x */


/*
 *
 *      Fun  : cmPkFthaDistType
 *
 *      Desc : This function packs the CmFthaDistType structure
 *
 *      Ret  : ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkFthaDistType
(
CmFthaDistType *distType,                          /* dist type structure */
Buffer *mBuf                                       /* message buffer pointer */
)
#else
PUBLIC S16 cmPkFthaDistType (distType, mBuf)
CmFthaDistType *distType;                          /* dist type structure */
Buffer *mBuf;                                      /* message buffer pointer */
#endif
{
   TRC2(cmPkFthaDistType);

   CMCHKPK (SPkU8, distType->qual, mBuf);
   CMCHKPK (SPkU8, distType->dist, mBuf);
   RETVALUE(ROK);
} /* end of cmPkFthaDistType */


/*
 *
 *      Fun  : cmUnpkFthaDistType
 *
 *      Desc : This function unpacks the CmFthaDistType structure
 *
 *      Ret  : ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File : cm_ftha.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkFthaDistType
(
CmFthaDistType *distType,                          /* dist type structure */
Buffer *mBuf                                       /* message buffer pointer */
)
#else
PUBLIC S16 cmUnpkFthaDistType (distType, mBuf)
CmFthaDistType *distType;                          /* dist type structure */
Buffer *mBuf;                                      /* message buffer pointer */
#endif
{
   TRC2(cmUnpkFthaDistType);

   CMCHKUNPK (SUnpkU8, &distType->dist, mBuf);
   CMCHKUNPK (SUnpkU8, &distType->qual, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkFthaDistType */



/********************************************************************30**
  
         End of file:     cm_ftha.c@@/main/4 - Mon Nov  5 14:26:33 2001

*********************************************************************31*/

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ark  1. initial release.
             ---      ssk  2. added the lock routines.

/main/2      ---      cp   1. Added the pk/unpk structure for DistType
             ---      ark  2. Moved read/lock functions to cm_rwlck.c
/main/3      ---      ns   1. Changes for rolling upgrade feature. Added
                              pk/unpk of get and set interface version structs
/main/4      ---      lrb  1. Changed the name of "index" variable to "idx"
                              to remove warnings on Vxworks
*********************************************************************91*/
