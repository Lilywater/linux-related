/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

    Name:      message functions

    Type:      C source file

    Desc:      Message Processing Functions

    File:      mf.c
  
    Sid:      mf.c@@/main/71 - Tue Jan 22 15:19:15 2002
  
    Prg:       na

*********************************************************************21*/


/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*     1000009     Network Layer - Q.930/Q.931
*     1000017     Data Link Layer - Basic Frame Relay
*     1000018     Data Link Layer - Extended Frame Relay
*     1000023     X.31
*     1000029     SS7 - ISUP
*     1000043     Network Layer - Q.93B
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "mf.h"            /* message functions */

/* header/extern include files (.x) */

#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "mf.x"            /* message functions */


/* local defines */
Bool mfLength;

/* local typedefs */

/* local externs */


/* forward references */

PRIVATE S16 mfReinitMsgCtl ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfChkEnum ARGS((U32 val, CONSTANT TknElmtDef *tep, Swtch swtch));
PRIVATE S16 mfPushFlag ARGS((U8 flag));
PRIVATE S16 mfChkFlag ARGS((U8 cnt));
PRIVATE S16 mfSkipTkns ARGS((TknHdr **cmsp, CONSTANT TknElmtDef *CONSTANT *telp));
PRIVATE S16 mfSetExt ARGS((Buffer *mp,U8 val));
PRIVATE S16 mfSetFlag ARGS((U8 reg,Buffer *mp));
PRIVATE S16 mfDecMsgType ARGS((MfMsgCtl *msgCtlp, Data val));
PRIVATE S16 mfEncMsgType ARGS((MfMsgCtl *msgCtlp, Data val));
PRIVATE S16 mfDecU8 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep, 
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU8 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecBits ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncBits ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecU16 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecU16Ext ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU16 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU16Ext ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecU24 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU24 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecU32 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU32 ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
#ifdef SS7
#ifdef SP
PRIVATE S16 mfEncData ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecData ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
#endif /* SP */
#endif /* SS7 */
PRIVATE S16 mfDecU8Enum ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncU8Enum ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecStr ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncStr ARGS((Buffer *mp, CONSTANT TknElmtDef *tep,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecTkns ARGS((Buffer *mp, CONSTANT TknElmtDef *CONSTANT *telp,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncTkns ARGS((Buffer *mp, CONSTANT TknElmtDef *CONSTANT *telp,
        MfMsgCtl *msgCtlp));
PRIVATE S16 mfDecElmts ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncElmts ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfInitElmts ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfInitTkns ARGS((TknHdr **scmsp,TknHdr **dcmsp, 
        CONSTANT TknElmtDef *CONSTANT *telp,U8 mode,Swtch swtch,U32 *flags));

PRIVATE  S16 fpAdd ARGS((PTR *adrp, U32 len));
PRIVATE  S16 mfBcopy ARGS((U8 *src,U8 *dest,U32 count));
PRIVATE  U32 mfStrlen ARGS((U8 *src));
#ifdef SS7
PRIVATE S16 mfDecSS7Elmts ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfEncSS7Elmts ARGS((MfMsgCtl *msgCtlp));
PRIVATE S16 mfInitSS7Elmts ARGS((MfMsgCtl *msgCtlp));
#endif

#if (MF_IN || MF_NV)
PRIVATE  S16 mfInitErr ARGS((MfMsgCtl *msgCtlp, U8 eid, U8 errCode));
#endif
#if MF_IN
#ifdef __cplusplus
extern "C" {
#endif 
EXTERN S16 inChkComprehension (U8 infByte);
#ifdef __cplusplus
           }
#endif
#endif 
/* public variable declarations */

PUBLIC Bool mfDecCont;
PUBLIC U8 mfExt;
PUBLIC U8 mfAddExt;
#ifdef DEBUGP
U8 g_DBGMsgErr = FALSE;  /*DBG4*/
#endif

/* token value enumeration lists */

TknEnum mfCauseValEnums0[] = 
  { 5, MFCCINVMSG, MFCCINFOELMSSG, MFCCNOMSGTYP, MFCCNOINFOEL, MFCCINVINFOEL,};

TknEnum *mfTeCauseValEnums[1] = 
{
   mfCauseValEnums0,    /* message functions */
};

/* token flag sets */

U32 mfTf0 = 0;          /* flags */
U32 mfTf1 = TF_EREM;    /* flags */
U32 mfTf2 = TF_NEXT;    /* flags */

/* element flag sets */

U32 mfEf0[] =
{
   0,                   /* flags */
};

/* internal cause & diagnostic error element */

TknElmtDef mfTeCauseVal = /* cause value */
{
   TET_U8_ENUM,         /* token element type */
   7,                   /* minimum length */
   7,                   /* maximum length */
   0x7f,                /* bit mask */
   0,                   /* minimum value */
   0,                   /* maximum value */
   NULLP,               /* pointer default value switch list */
   0,                   /* bit offset */
   &mfTf2,              /* flags */
   0,                   /* general register value */
   NULLP,               /* escape to function */
   &mfTeCauseValEnums[0],  /* pointer to enumerated list */
};

TknElmtDef mfTeDgnVal = /* diagnostic value */
{
   TET_STR,             /* token element type */
   0,                   /* minimum length */
   3,                   /* maximum length */
   0,                   /* bit mask */
   0,                   /* minimum value */
   0,                   /* maximum value */
   NULLP,               /* pointer default value switch list */
   0,                   /* bit offset */
   &mfTf1,              /* flags */
   0,                   /* general register value */
   NULLP,               /* escape to function */
   /* enumerated values, length in first byte */
   NULLP,               /* pointer to enumerated list */
};

CONSTANT TknElmtDef *mfCauseDgnTkns[] = /* cause and diagnostic tokens */
{
   &mfTeCauseVal,             /* cause value */
   &mfTeDgnVal,               /* diagnostics */
   NULLP,
};

MsgElmtDef mfMeCauseDgn =     /* Cause and Diagnostic element */
{
   MET_VARIABLE,              /* element type */
   MFME_CAUSE,                /* element id */
   MFMEI_CAUSE,               /* internal element index */
   2,                         /* minimum length */
   7,                         /* maximum length */
   0,                         /* element error code */
   mfEf0,                     /* pointer switch flag list */
   &mfCauseDgnTkns[0],        /* pointer to token list */
};


/* message decode/encode variables */

PRIVATE Bool mfInitFlag = FALSE;
PRIVATE U8 mfStk[MF_STKSIZE];
PRIVATE U8 mfSp;
PRIVATE U8 mfOctet;
PRIVATE S16 mfCodeSet;
PRIVATE U8 mfShftLock;
PRIVATE Bool mfBackOut;
PRIVATE U16 mfMaxRepElmt;

U8 mfSaveLyr1ProtVal;
U8 mfSaveLyrIdent;
U8 mfSaveMultiRate;
U8 mfSaveOctet;
U8 mfLen;

/*
 *     support functions
 */

/* message processing functions */

#if (MF_IN || MF_NV)

/*
*
*       Fun:   mfInitErr
*
*       Desc:  message function - initializes cause dgn element in
*              msgCtl ee[] structure
*
*       Ret:   MFROK - ok
*
*       Notes: None
*
*       File:  mf.c
*/
 
#ifdef ANSI
PRIVATE S16 mfInitErr
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
U8 eid,                    /* element ID */
U8 errCode                 /* error code */
)
#else
PRIVATE S16 mfInitErr(msgCtlp, eid, errCode)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
U8 eid;                    /* element ID */
U8 errCode;                /* error code */
#endif
{

   TRC2(mfInitErr)    

   msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.causeVal.pres = PRSNT_NODEF;
   msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.causeVal.val = errCode;
   msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.dgnVal.pres = PRSNT_NODEF;
   msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.dgnVal.len = 1; 
   msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.dgnVal.val[0]  = eid;

   RETVALUE(ROK);
} /* end of mfInitErr */
#endif

  
/*
*
*       Fun:   fpAdd
*
*       Desc:  message function - add far pointers
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 fpAdd
(
REG1 PTR *adrp,     /* address pointer */
REG2 U32 len        /* length */
)
#else
PRIVATE S16 fpAdd(adrp, len)
REG1 PTR *adrp;     /* address pointer */
REG2 U32 len;       /* length */
#endif
{
#ifdef DOS
#ifdef PTRFAR
   REG3 U32 seg;
   REG4 U32 off;

   TRC2(fpAdd)
   seg = *adrp & 0xffff0000;
   off = (*adrp & 0xffff);

   off += len;
   seg += ((off & 0xffff0000) << 12);
   *adrp = seg | (off & 0xffff);
#else
   *adrp += len;
#endif
#else
   TRC2(fpAdd)
   *adrp += len;
#endif

   RETVALUE(ROK);
} /* end of fpAdd */

  
/*
*
*       Fun:   mfInit
*
*       Desc:  message function - initialization
*
*       Ret:   MFROK      - ok
*
*       Notes: Needs to be called once at startup
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInit
(
void
)
#else
PUBLIC S16 mfInit()
#endif
{
   TRC2(mfInit)
   mfInitFlag = 1;
   mfBackOut = 0;
   mfDecCont = FALSE;
   mfLen = 0;
   for (mfSp = 0; mfSp < MF_STKSIZE; mfSp++)
      mfStk[mfSp] = 0;
   mfSp = MF_STKSIZE; 
   mfOctet = 0;
   mfCodeSet = 0;
   mfShftLock = 0;
   RETVALUE(MFROK);
} /* end of mfInit */

  
/*
*
*       Fun:   mfReinitMsgCtl
*
*       Desc:  message function - reinit message control structure
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfReinitMsgCtl
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfReinitMsgCtl(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   U16 i;                 /* counter */

   TRC2(mfReinitMsgCtl)
   mfBackOut = 0;
   if (msgCtlp)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->errCnt = 0;
      msgCtlp->octIdx = 0;
      msgCtlp->bitIdx = 0;
      msgCtlp->msgType = M_UNKNOWN;
      msgCtlp->msgIdx = MI_UNKNOWN;
      msgCtlp->smelp1 = NULLP;
      for (i = 0; i < MF_MAX_ERRORS; i++)
      {
         msgCtlp->ee[i].elmtId  = ME_UNKNOWN;
         msgCtlp->ee[i].elmtIdx = MEI_UNKNOWN;
         msgCtlp->ee[i].tknIdx  = MEI_UNKNOWN;
         msgCtlp->ee[i].mfCauseDgn.eh.pres = NOTPRSNT;
         msgCtlp->ee[i].mfCauseDgn.causeVal.pres = NOTPRSNT;
      }
   }
   RETVALUE(MFROK);
} /* end of mfReinitMsgCtl */

  
/*
*
*       Fun:   mfInitMsgCtl
*
*       Desc:  message function - init message control structure
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInitMsgCtl
(
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PUBLIC S16 mfInitMsgCtl(msgCtlp)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */

   TRC2(mfInitMsgCtl)
   mfBackOut = 0;
   msgCtlp->mdbp = NULLP;
   msgCtlp->mode = NOTPRSNT;
   msgCtlp->swtch = 0;
   msgCtlp->flags = 0;
   msgCtlp->errCnt = 0;
   msgCtlp->octIdx = 0;
   msgCtlp->bitIdx = 0;
   msgCtlp->msgType = M_UNKNOWN;
   msgCtlp->msgIdx = MI_UNKNOWN;
   msgCtlp->smelp1 = NULLP;
   for (i = 0; i < MF_MAX_ERRORS; i++)
   {
      msgCtlp->ee[i].elmtId  = ME_UNKNOWN;
      msgCtlp->ee[i].elmtIdx = MEI_UNKNOWN;
      msgCtlp->dup1 = (ElmtHdr *) NULLP;
      msgCtlp->dup2 = (ElmtHdr *) &msgCtlp->ee[i].mfCauseDgn;
      msgCtlp->mep = &mfMeCauseDgn;
      ret = mfInitElmt(msgCtlp);
   }      
#ifdef SI
      msgCtlp->uBuf = NULLP;
#endif /* SI */
   RETVALUE(ret);
} /* end of mfInitMsgCtl */

  
/*
*
*       Fun:   mfMsgRet
*
*       Desc:  message function - return error structure
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfMsgRet
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
U16 err,                    /* error */
U16 line                    /* line number */
)
#else
PUBLIC S16 mfMsgRet(msgCtlp, err, line)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
U16 err;                    /* error */
U16 line;                   /* line number */
#endif
{
   U8 errCnt;               /* error counter */
#ifdef DBG4

   Txt prntBuf[PRNTSZE];    /* print buffer */

#endif

   TRC2(mfMsgRet)
   if ((err != MFROK) && (mfBackOut == 0))
   { 
#ifdef DBG4
      if (TRUE == g_DBGMsgErr)
      {
          sprintf(prntBuf, "mfMsgRet: err: %04d, line: %05d\n", err, line);
          SPrint(prntBuf);
      }
#endif
      mfBackOut = 1;
      /* the following check is needed to keep index, errCnt, within bounds
       * i.e. when msgCtlp->errCnt equals MF_MAX_ERRORS
       */
      errCnt = (U8) MIN((U8) msgCtlp->errCnt, (U8) (MF_MAX_ERRORS - 1));
      msgCtlp->line = line;
      msgCtlp->ee[errCnt].mfCauseDgn.eh.pres = PRSNT_NODEF; 
      msgCtlp->ee[errCnt].mfCauseDgn.causeVal.pres = PRSNT_NODEF; 
      msgCtlp->ee[errCnt].mfCauseDgn.causeVal.val = (U8) err; 
      if (err == MFCCNOMSGTYP)
      { 
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.pres = PRSNT_NODEF; 
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.len = 1; 
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.val[0] 
            = msgCtlp->msgType; 
      } 
      else if (err != MFCCINVMSG) 
      { 
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.pres = PRSNT_NODEF; 
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.len = 1;
         msgCtlp->ee[errCnt].mfCauseDgn.dgnVal.val[0] = 
            (U8) msgCtlp->ee[errCnt].elmtId; 
      } 
      
      /* call users error mapping function */
      if (msgCtlp->cfgp->errMapFunc != NULLP)
         (*msgCtlp->cfgp->errMapFunc)
            (msgCtlp, msgCtlp->usrErrStP);

      /* bump error counter */
      if (errCnt < MF_MAX_ERRORS) 
         msgCtlp->errCnt++; 
   } 
   RETVALUE(err); 
} /* end of mfMsgRet */

  
/*
*
*       Fun:   mfInitProf
*
*       Desc:  message function - initialization of profiles
*
*       Ret:   MFROK      - ok
*
*       Notes: Initializes one or more profiles, called at startup.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInitProf
(
MfCfgProf *mfCfgProfPtr     /* pointer to configuration profile */
)
#else
PUBLIC S16 mfInitProf(mfCfgProfPtr)
MfCfgProf *mfCfgProfPtr;    /* pointer to configuration profile */
#endif
{
   S16 ret;                 /* return code */
   MfCfgProf *mfCp;         /* pointer to configuration profile */

   TRC2(mfInitProf)
   ret = MFROK;
   mfCp = mfCfgProfPtr;
   mfMaxRepElmt = (U16)mfCp->maxRepElmt;
   if (mfInitFlag == FALSE)
      mfInit();
   RETVALUE(ret);
} /* end of mfInitProf */


  
/*
*
*       Fun:   mfDecMsgType
*
*       Desc:  message function - decode message type
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecMsgType
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
Data c                      /* message type octet */
)
#else
PRIVATE S16 mfDecMsgType(msgCtlp, c)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
Data c;                     /* message type octet */
#endif
{
   CONSTANT MsgElmtDef *CONSTANT *melp;  /* pointer to message element list 
                                            pointers */
   U16 i;                                /* counter */
   U16 swtch;                            /* switch index */
   CONSTANT MsgDef *allPduDefs;          /* pointer to all pdu definition 
                                            structure */

   TRC2(mfDecMsgType)
   swtch = msgCtlp->swtch;
   allPduDefs = msgCtlp->cfgp->pduDefs;
   melp = NULLP;

   /* validate msg type */

   for (i = 0; allPduDefs[i].melp; i++)
   {
      if ((c == allPduDefs[i].id) && (msgCtlp->protDisc 
         == allPduDefs[i].protDisc[swtch]))
      {
         if (!(i == allPduDefs[i].idx))
         {
            MSGRET(msgCtlp, MFCCNOMSGTYP);
         }
         if (msgCtlp->validate)
         {
            /* check if message applicable for ckt/pkt/usr */
            if (!allPduDefs[i].flagp)
            {
               MSGRET(msgCtlp, MFCCNOMSGTYP);
            }
            
            if (allPduDefs[i].flagp[swtch] & MF_NA)
               continue;
         }

         melp = allPduDefs[i].melp;
         break;
      }
   }

   msgCtlp->msgType = c;
   if (melp == NULLP)
      MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (i >= msgCtlp->cfgp->numPdus)
      MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (msgCtlp->validate)
   {
      /* check if message applicable for ckt/pkt/usr */
      if (!allPduDefs[i].flagp)
      {
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      }

      if (allPduDefs[i].flagp[swtch] & MF_NA)
         MSGRET(msgCtlp, MFCCNOMSGTYP);
   }

   msgCtlp->msgIdx = allPduDefs[i].idx;
   msgCtlp->smelp1 = melp;   
   msgCtlp->mdbp = &allPduDefs[i];

   RETVALUE(MFROK);
} /* end of mfDecMsgType */

  
/*
*
*       Fun:   mfEncMsgType
*
*       Desc:  message function - encode message type
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncMsgType
(
MfMsgCtl *msgCtlp,          /* pointer to message control structure */
Data c                      /* message type octet */
)
#else
PRIVATE S16 mfEncMsgType(msgCtlp, c)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
Data c;                     /* message type octet */
#endif
{
   U16 i;                                /* counter */
   U16 swtch;                            /* switch index */
   CONSTANT MsgElmtDef *CONSTANT *melp;  /* pointer to message element list 
                                            pointers */
   CONSTANT MsgDef *allPduDefs;          /* pointer to all pdu definition 
                                            structure */

   TRC2(mfEncMsgType)
   swtch = msgCtlp->swtch;
   allPduDefs = msgCtlp->cfgp->pduDefs;
   melp = NULLP;

   /* validate msg type */

   for (i = 0; allPduDefs[i].melp; i++)
   {
      if ((c == allPduDefs[i].id) && (msgCtlp->protDisc == 
         allPduDefs[i].protDisc[swtch]))
      {
         if (!(i == allPduDefs[i].idx))
         {
            MSGRET(msgCtlp, MFCCNOMSGTYP);
         }

         melp = allPduDefs[i].melp;
         break;
      }
   }

   msgCtlp->msgType = c;
   if (melp == NULLP)
      MSGRET(msgCtlp, MFCCNOMSGTYP);

   if (msgCtlp->validate)
   {
      /* check if message applicable for ckt/pkt/usr */
      if (!(allPduDefs[i].flagp))
      {
         MSGRET(msgCtlp, MFCCNOMSGTYP);
      }
      if (allPduDefs[i].flagp[swtch] & MF_NA)
         MSGRET(msgCtlp, MFCCNOMSGTYP);
   }

   msgCtlp->msgIdx = (U8) i;
   msgCtlp->smelp1 = melp;   
   msgCtlp->mdbp = &allPduDefs[i];

   RETVALUE(MFROK);
} /* end of mfEncMsgType */

  
/*
*
*       Fun:   mfChkEnum
*
*       Desc:  message function - check enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfChkEnum
(
REG1 U32 val,               /* enumerated value */
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
Swtch swtch                 /* switch */
)
#else
PRIVATE S16 mfChkEnum(val, tep, swtch)
REG1 U32 val;               /* enumerated value */
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
Swtch swtch;                /* switch */
#endif
{
   REG2 TknEnum *elistp;    /* enum list pointer */
   REG3 U32 i;              /* counter */
   REG4 U32 ecnt;           /* enumerated element count */

   TRC2(mfChkEnum)
   elistp = tep->elist[swtch];

   if (!elistp)
   {
      RETVALUE(MFCCINVINFOEL);
   }

   ecnt = (U16) *elistp;
   elistp++;

   for (i = 0; i < ecnt; i++)
   {
      if (val == *elistp)
         RETVALUE(MFROK);
      elistp++;
   } 
   RETVALUE(MFCCINVINFOEL);
} /* end of mfChkEnum */

  
/*
*
*       Fun:   mfPushFlag
*
*       Desc:  message function - push flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfPushFlag
(
Bool flag                   /* flag to push, true or false */
)
#else
PRIVATE S16 mfPushFlag(flag)
Bool flag;                  /* flag to push, true or false */
#endif
{
   TRC2(mfPushFlag)
   mfStk[--mfSp] = flag;
   if (mfSp == 0)
      mfSp = MF_STKSIZE;
   RETVALUE(MFROK);
} /* end of mfPushFlag */

  
/*
*
*       Fun:   mfChkFlag
*
*       Desc:  message function - check flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfChkFlag
(
U8 idx                      /* stack backward index */
)
#else
PRIVATE S16 mfChkFlag(idx)
U8 idx;                     /* stack backward index */
#endif
{
   U16 sidx;                /* absolute stack index */

   TRC2(mfChkFlag)
   sidx = (mfSp + idx) & (MF_STKSIZE - 1);
   RETVALUE(mfStk[sidx]);
} /* end of mfChkFlag */

  
/*
*
*       Fun:   mfSkipTkns
*
*       Desc:  message function - skip tokens
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfSkipTkns
(
TknHdr **cmsp,              /* pointer to pointer of token header */
CONSTANT TknElmtDef *CONSTANT *telp  /* pointer to pointer of token definition */
)
#else
PRIVATE S16 mfSkipTkns(cmsp, telp)
TknHdr **cmsp;              /* pointer to pointer of token header */
CONSTANT TknElmtDef *CONSTANT *telp; /* pointer to pointer of token definition */
#endif
{
   CONSTANT TknElmtDef *tep;/* token element definition pointer */
   U32 skip_sz;

   TRC2(mfSkipTkns)
   skip_sz = 0;
   /* loop thru token elements and decode to done or error */
   while (*telp)
   {
      tep = *telp;
      telp += 1;
      switch (tep->type)
      {
         case TET_U8:
         case TET_U8_ENUM:
            skip_sz += sizeof(TknU8);
            break;

         case TET_BITS:
         case TET_BITS_ENUM:
            switch(tep->maxLen)
            {
                case 2:
                   skip_sz += sizeof(TknU16);
                   break;
                case 3:
                case 4:
                   skip_sz += sizeof(TknU32);
                   break;
            }
            break;

         case TET_U16:
         case TET_U16_EXT:
            skip_sz += sizeof(TknU16);
            break;

         case TET_U24:
         case TET_U32:
            skip_sz += sizeof(TknU32);
            break;

         case TET_STR:
         case TET_STR_IA5:
            skip_sz += sizeof(TknStr);
            break;

         case TET_STRS:
         case TET_STRS_IA5:
            skip_sz += sizeof(TknStrS);
            break;

         case TET_STRM:
            skip_sz += sizeof(TknStrM);
            break;

         case TET_STRL:
            skip_sz += sizeof(TknStrE);
            break;

         case TET_DATA:
            skip_sz += sizeof(TknU8);
            break;

      }
   }
   fpAdd((PTR *) cmsp, (U32)skip_sz);
   RETVALUE(MFROK);
} /* end of mfSkipTkns */

  
/*
*
*       Fun:   mfSetExt
*
*       Desc:  message function - set extension
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfSetExt
(
Buffer *mp,                /* pointer to buffer */
U8 val                     /* value */
)
#else
PRIVATE S16 mfSetExt(mp, val)
Buffer *mp;                /* pointer to buffer */
U8 val;                    /* value */
#endif
{
   Data c;                 /* data character */
   S16 ret;

   TRC2(mfSetExt)
   SRemPstMsg(&c, mp);
   c &= 0x7f;
   if (val)
      c |= 0x80;
   ret = SAddPstMsg(c, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
   if (ret != ROK)
      RETVALUE(MFRESFAILURE);
#endif
   RETVALUE(MFROK);
} /* end of mfSetExt */

  
/*
*
*       Fun:   mfSetFlag
*
*       Desc:  message function - set flag
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfSetFlag
(
U8 reg,                    /* register value */
Buffer *mp                 /* message pointer */
)
#else
PRIVATE S16 mfSetFlag(reg, mp)
U8 reg;                    /* register value */
Buffer *mp;                /* message pointer */
#endif
{
   U8 treg;                /* register value */
   Buffer *tmp;            /* message pointer */

   TRC2(mfSetFlag)

   /* RG: only dynamic variables initialized! */
   treg = reg;
   tmp = mp;

   RETVALUE(MFROK);
} /* end of mfSetFlag */

  
/*
*
*       Fun:   mfDecU8
*
*       Desc:  message function - decode unsigned 8 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU8
(
Buffer *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecU8(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;                  /* data character */
   U8 val;                  /* token value */
   TknU8 *tp;               /* token pointer */

   TRC2(mfDecU8)
   ret = 0xff;
   /* if token present based on last ext flag and not extended */
   tp = (TknU8 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN)
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (mfSaveMultiRate)
   {
      mfSaveMultiRate = FALSE;
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);
   else if ((*tep->flagp & TF_PLEN) && (mfLen < 1))
      RETVALUE(ROK);

   if (*tep->flagp & TF_OPT4)
   {
     if (mfSaveLyrIdent != 0)
     {
       tp->pres = NOTPRSNT;
       RETVALUE(MFROK);
     }
   }

   /* token must be present, check it */
   if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
      MSGRET(msgCtlp, MFCCINVMSG);
   val = (U8)(c >> tep->offset);
   if (tep->mask)
      val &= (U8) tep->mask;

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = mfDecMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if (msgCtlp->validate)
      if ((val < (U8) tep->minVal) || (val > (U8) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* if there is a user function, execute it */
   if (tep->func)
      if (((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK) && 
          (ret != MFREOM) && (ret != MFRFAILED) && (ret != MFCCINVMSGLEN))
         MSGRET(msgCtlp, ret);
   if (ret == MFREOM)
   {
      if ((msgCtlp->validate) && ((ret = mfChkEnum((U32) val, tep, 
           msgCtlp->swtch)) != MFROK))
         MSGRET(msgCtlp, ret);
   }
   else
      if (ret == MFRFAILED)
      {
         mfExt = 1;
         RETVALUE(MFROK);
      }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
#if (ISDN_NI1 || ISDN_Q932)
   if ((ret == MFCCINVMSGLEN) && (msgCtlp->swtch == 13)) /* switch NI1 */
   {
      msgCtlp->octIdx -= 1;
      val = 1;
   }
#endif
#ifdef QSIG
   if ((ret == MFCCINVMSGLEN) && (msgCtlp->swtch == 19)) /* switch QSIG */
      val = 2;
#endif
#endif
   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         mfLen--;
   }
   else if (*tep->flagp & TF_NEXT)
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         mfLen--;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP)) 
              && (*tep->flagp & TF_LAST) )
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }
#endif /* SS7 */

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* if token is a length field, save it */
   if (*tep->flagp & TF_LEN)
     mfLen = val;

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val  = val;
   }

   RETVALUE(MFROK);
} /* end of mfDecU8 */

  
/*
*
*       Fun:   mfEncU8
*
*       Desc:  message function - encode unsigned 8 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU8
(
Buffer *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU8(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U8 val;                  /* token value */
   TknU8 *tp;               /* token pointer */

   TRC2(mfEncU8)
   /* check mandatory dependencies */
   tp = (TknU8 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   val = tp->val;      

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = mfEncMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if (msgCtlp->validate)
      if ((val < (U8) tep->minVal) || (val > (U8) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   mfOctet |= val << tep->offset;

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
/* KRP - for FN lyr identifiers */
#ifdef FN
         if((msgCtlp->cfgp->flags & FN_MF) && (ret == FN_MFRET))
            mfOctet = val;
         else
#endif
         MSGRET(msgCtlp, ret);

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if ((*tep->flagp & TF_EXT) || (*tep->flagp & TF_NEXT))
   {
      if ((U8 )(tep->offset + tep->maxLen) < (U8 )8)
            mfOctet |= 0x80;
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }

      mfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      U8 diff;
      diff = (U8)(tep->offset + tep->maxLen);
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }

      if  (diff < (U8)8)
         msgCtlp->bitIdx += diff;
      mfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#endif /* SS7 */

   RETVALUE(MFROK);
} /* end of mfEncU8 */

  
/*
*
*       Fun:   mfDecU8Enum
*
*       Desc:  message function - decode unsigned 8 bit enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU8Enum
(
Buffer *mp,                /* message pointer */
CONSTANT TknElmtDef *tep,  /* token element definition pointer */
MfMsgCtl *msgCtlp          /* message control pointer */
)
#else
PRIVATE S16 mfDecU8Enum(mp, tep, msgCtlp)
Buffer *mp;                /* message pointer */
CONSTANT TknElmtDef *tep;  /* token element definition pointer */
MfMsgCtl *msgCtlp;         /* message control pointer */
#endif
{
   S16 ret;                /* return code */
   Data c;                 /* data character */
   U8 val;                 /* token value */
   TknU8 *tp;              /* token pointer */

   TRC2(mfDecU8Enum)

   /* if token present based on last ext flag and not extended */
   tp = (TknU8 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_OPT1)
   {
     if (mfSaveLyr1ProtVal == 0x08)
       RETVALUE(MFROK);
   }
   else
   {
     if (*tep->flagp & TF_OPT2)
     {
       if (mfSaveLyr1ProtVal == 0x01)
         RETVALUE(MFROK);
     }
   }


   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);
   else if ((*tep->flagp & TF_PLEN) && (mfLen < 1))
      RETVALUE(ROK);

   if (*tep->flagp & TF_OPT4)
   {
     if (mfSaveLyrIdent != 0)
     {
       tp->pres = NOTPRSNT;
       RETVALUE(MFROK);
     }
   }

   /* token must be present, check it */
   if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
      MSGRET(msgCtlp, MFCCINVMSG);
   val = (U8)(c >> tep->offset);
   if (tep->mask)
      val &= (U8) tep->mask;

   if (*tep->flagp & TF_OPT3)
   {
    /* if there is a user function, execute it */
     if (tep->func)
     {
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
      {
 
        mfSaveLyrIdent = val;
        tp->pres = NOTPRSNT;
        RETVALUE(MFROK);
      }
      else
        mfSaveLyrIdent = 0;
     }
   }


   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = mfDecMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if ((msgCtlp->validate) && ((ret = mfChkEnum((U32) val, tep, 
             msgCtlp->swtch)) != MFROK))
      MSGRET(msgCtlp, ret);

   if (!(*tep->flagp & TF_OPT3))
   {

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);
   }


   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         mfLen--;
   }
   else if (*tep->flagp & TF_NEXT)
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (*tep->flagp & TF_PLEN)
         mfLen--;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }
#endif /* SS7 */

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* if token is a length field, save it */
   if (*tep->flagp & TF_LEN)
     mfLen = val;

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;

      /*
       * If TF_SAVE is set then save the value into mfSaveLyr1ProtVal.
       */
      if (*tep->flagp & TF_SAVE)
        mfSaveLyr1ProtVal = tp->val;

   }


#ifdef QSIG
   if ((msgCtlp->swtch == 19)
       &&((*msgCtlp->melp1)->id == 0x27))
   {
     if (!(c & 0x80) )
     {
       mfInitErr(msgCtlp, (*msgCtlp->melp1)->id, MFCCINVINFOEL);
       RETVALUE(MFRFAILED);
     }
   }
#endif


   RETVALUE(MFROK);
} /* end of mfDecU8Enum */

  
/*
*
*       Fun:   mfEncU8Enum
*
*       Desc:  message function - encode unsigned 8 bit enumerated list
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU8Enum
(
Buffer *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU8Enum(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U8 val;
   TknU8 *tp;

   TRC2(mfEncU8Enum)
   /* check mandatory dependencies */
   tp = (TknU8 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   val = tp->val;      

   /* if token is a message type field */
   if (*tep->flagp & TF_MSGTYP)
   {
      if ((ret = mfEncMsgType(msgCtlp, val)) != MFROK)
         RETVALUE(ret);
   }
   else if ((msgCtlp->validate) && ((ret = mfChkEnum((U32) val, tep, 
            msgCtlp->swtch)) != MFROK))
      MSGRET(msgCtlp, ret);
   mfOctet |= val << tep->offset;

   mfSaveOctet = mfOctet;

   /* if there is a user function, execute it */
   if (tep->func)
   {
      ret = (*tep->func)(msgCtlp, (PTR) &val);
      if (ret != MFROK && ret != MFREOM)
         MSGRET(msgCtlp, ret);
      if (ret == MFREOM)
      {
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
         if ((msgCtlp->swtch == 2) || (msgCtlp->swtch == 17) || 
              (msgCtlp->swtch == 3) || (msgCtlp->swtch == 15))
            mfOctet = val;
         else
#endif
/* krp - in042.31*/
            MSGRET(msgCtlp, ret);
      }
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* save token info in msg struct */
   /* if last token in octet */
   msgCtlp->bitIdx += tep->maxLen;
   if ((*tep->flagp & TF_EXT) || (*tep->flagp & TF_NEXT))
   {
      if ((U8 )(tep->offset + tep->maxLen) < (U8 )8)
         mfOctet |= 0x80;
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
#if (ISDN_303TMC || ISDN_303CSC)
      if ((msgCtlp->swtch == 15) || (msgCtlp->swtch == 16))
         if ((*tep->flagp & TF_PUSHF) && (*tep->flagp & TF_NEXT))  
            mfOctet &= 0x7f;
#endif
#endif
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      mfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#ifdef SS7
   else if ( ((msgCtlp->cfgp->flags & MF_ISUP) || 
              (msgCtlp->cfgp->flags & MF_TUP) ||
              (msgCtlp->cfgp->flags & MF_SCCP))
              && (*tep->flagp & TF_LAST) )
   {
      U8 diff;
      diff = (U8)(tep->offset + tep->maxLen);
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }

      if  (diff < (U8)8)
         msgCtlp->bitIdx += diff; /* step past spare bits */
      mfOctet = 0;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }
#endif /* SS7 */

   RETVALUE(MFROK);
} /* end of mfEncU8Enum */


/*
*
*       Fun:   mfDecBits
*
*       Desc:  message function - decode bit string (portable version)
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/

#ifdef ANSI
PRIVATE S16 mfDecBits
(
Buffer *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecBits(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;                  /* data character */
   TknU16 *tp;
   TknU32 *tp1;
   U16 word, word1;
   U32 val;
   
   TRC2(mfDecBits);

   /* initialize token structure */
   tp = NULLP;
   tp1 = NULLP;


   switch(tep->maxLen)
   {
      case 2:                              /* 16 Bits */
         tp = (TknU16 *) msgCtlp->dup1;
         tp->pres = NOTPRSNT;

         word = 0;

         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         if (tep->mask)
         word &= tep->mask;

         if ( msgCtlp->validate && 
            ((word < (U16) tep->minVal) || (word > (U16) tep->maxVal)) )
               MSGRET(msgCtlp, MFCCINVINFOEL);

         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = mfChkEnum((U32) word, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         tp->val = (U16)word;
         tp->pres = PRSNT_NODEF;
         msgCtlp->elen -=2;
         break;
      case 3:                  /* 24 Bits */
         tp1 = (TknU32 *) msgCtlp->dup1;
         tp1->pres = NOTPRSNT;
         word = 0;
         val = 0;

         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         word1=0;
         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word1 = (U16) PutLoByte(word1, c);
         msgCtlp->octIdx++;

         val = PutLoWord(val, word);
         val = PutHiWord(val, word1);

         if (tep->mask)
         val &= tep->mask;
         if ( msgCtlp->validate && 
            ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal)) )
               MSGRET(msgCtlp, MFCCINVINFOEL);
         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = mfChkEnum((U32)val, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         tp1->val = val;
         tp1->pres = PRSNT_NODEF;
         msgCtlp->elen -=3;
         break;
      case 4:                  /* 32 Bits */
         tp1 = (TknU32 *) msgCtlp->dup1;
         tp1->pres = NOTPRSNT;

         word = 0;
         val = 0;  /* RG: added initialization */

         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word, c);
         msgCtlp->octIdx++;

         word1 = 0;
         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutLoByte(word1, c);
         msgCtlp->octIdx++;

         if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
            MSGRET(msgCtlp, MFCCINVMSG);
         word = (U16) PutHiByte(word1, c);
         msgCtlp->octIdx++;

         val = PutLoWord(val, word);
         val = PutHiWord(val, word1);

         if (tep->mask)
         val &= tep->mask;

         if ( msgCtlp->validate && ((val < (U32) tep->minVal) || 
               (val > (U32) tep->maxVal)) )
            MSGRET(msgCtlp, MFCCINVINFOEL);

         if ((tep->type == TET_BITS_ENUM) && (msgCtlp->validate))
         {
            if ((ret = mfChkEnum((U32) val, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }

         tp1->val = val;
         tp1->pres = PRSNT_NODEF;
         msgCtlp->elen-=4;

         break;
      default:
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }
   if (tep->func)
   {
      if (tep->maxLen <= 2)
      {
         ret = (*tep->func)(msgCtlp,  (PTR) &tp->val);
         if (ret != MFROK)
            MSGRET(msgCtlp, ret);
      }
      else
      {
         ret = (*tep->func)(msgCtlp, (PTR) &tp1->val);
         if (ret != MFROK)
            MSGRET(msgCtlp, ret);
      }
   }
      RETVALUE(MFROK);
} /* end of mfDecBits */


/*
*
*       Fun:   mfEncBits
*
*       Desc:  message function - encode bit string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
#ifdef ANSI
PRIVATE S16 mfEncBits
(
Buffer *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncBits(mp, tep, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   TknU16 *tp16;
   TknU32 *tp32;
   U16 val16;               /* 32 bit value */
   U32 val32;               /* 32 bit value */
   U8 octet;

   TRC2(mfEncBits)
   /* check mandatory dependencies */
   switch( tep->maxLen)
   {
      case 2:
         tp16 = (TknU16 *) msgCtlp->dup1;
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
         if (!tp16->pres)
         {
            if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            else
               RETVALUE(MFROK);
         }
         val16 = (U16) tp16->val;
         if ( (tep->type == TET_BITS) && (msgCtlp->validate) )
         {
            if ((val16 < (U16) tep->minVal) || (val16 > (U16) tep->maxVal))
               MSGRET(msgCtlp, MFCCINVINFOEL);
         }
         else if ( (tep->type == TET_BITS_ENUM) && (msgCtlp->validate) )
         {
            if ((ret = mfChkEnum((U32)val16, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         if (tep->func)
         if ((ret = (*tep->func)(msgCtlp, (PTR) &tp16->val)) 
               != MFROK)
            MSGRET(msgCtlp, ret);

         if (!tep->offset)
         {
            mfOctet = (U8)GetLoByte(val16);
            octet = 0;
         }
         else  /* not the first token in the octet */
         {
            octet = (U8)GetLoByte(val16);
            mfOctet = (U8) (((octet << tep->offset) & 0xf0) | mfOctet);
         }

         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         mfOctet = (U8)GetHiByte(val16);
         if (tep->offset)
            mfOctet = (U8) (((mfOctet << tep->offset) & 0xf0) |
                            ((octet >> tep->offset) & 0x0f));

         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         mfOctet = 0;
         break;
      case 3:
      case 4:
         tp32 = (TknU32 *) msgCtlp->dup1;
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
         if (!tp32->pres)
         {
            if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            else
               RETVALUE(MFROK);
         }
         val32 = (U32) tp32->val;
         if ( (tep->type == TET_BITS) && (msgCtlp->validate) )
         {
            if ((val32 < (U32) tep->minVal) || (val32 > (U32) tep->maxVal))
               MSGRET(msgCtlp, MFCCINVINFOEL);
         }
         else if ( (tep->type == TET_BITS_ENUM) && (msgCtlp->validate) )
         {
            if ((ret = mfChkEnum((U32)val32, tep, msgCtlp->swtch)) != MFROK)
               MSGRET(msgCtlp, ret);
         }
         /* if there is a user function, execute it */
         if (tep->func)
            if ((ret = (*tep->func)(msgCtlp, (PTR) &tp32->val)) 
                  != MFROK)
               MSGRET(msgCtlp, ret);

         mfOctet = (U8)GetLoByte(GetLoWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         mfOctet = (U8)GetHiByte(GetLoWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         mfOctet = (U8)GetLoByte(GetHiWord(val32));
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }

         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->elen += 1;

         if (tep->maxLen == 4)
         {
            mfOctet = (U8)GetHiByte(GetHiWord(val32));
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg(mfOctet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }

            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;
            msgCtlp->elen += 1;
         }
         mfOctet = 0;
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         MSGRET(msgCtlp, MFDEBUGERR);
#endif
   }
   RETVALUE(MFROK);
} /* end of mfEncBits */

  
/*
*
*       Fun:   mfDecU16
*
*       Desc:  message function - decode unsigned 16 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU16
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecU16(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                  /* token length */
   TknU16 *tp;
   U16 val;

   TRC2(mfDecU16)

   /* if token present based on last ext flag and not extended */
   tp = (TknU16 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 2;

   if (*tep->flagp & TF_OPT5)
   {
     if (tep->func)
       if ((ret = (*tep->func)(msgCtlp, (PTR) &len)) != MFROK)
         MSGRET(msgCtlp, ret);
   }

   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
     if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
       MSGRET(msgCtlp, MFCCINVMSG);
     if (!(*tep->flagp & TF_OPT5))
     {
        val = (U16 )((val << 8) | c);
     }
     else
     {
        /* In case of OPT5, this is an extended Integer as in ISDN */
        /* The extension Bit needs to be removed thus AND with 0x7F */
        val = (U16 )((val << 7) | (c & 0x7f));
     }
     msgCtlp->octIdx += 1;
     msgCtlp->elen -= 1;
   }


   if (tep->mask)
      val &= (U16) tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (!(*tep->flagp & TF_OPT5))
     if (tep->func)
       if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of mfDecU16 */

  
/*
*
*       Fun:   mfDecU16Ext
*
*       Desc:  message function - decode unsigned 16 bit extended
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU16Ext
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecU16Ext(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                 /* maximum length */
   U8 shf;
   TknU16 *tp;
   U16 val;

   TRC2(mfDecU16Ext)

   /* if token present based on last ext flag and not extended */
   tp = (TknU16 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 3;
   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);

      /* RG: either the shf values are wrong or val should 
       * be computed as val = (c << shf) | val;
       */

      if (i == 0)
      {
         shf = 0;
         c &= 0x3;
      }
      else if (i == 1)
      {
         shf = 2;
         c &= 0x7f;
      }
      else
      {
         shf = 7;
         c &= 0x7f;
      }
      val = (U16 )((val << shf) | c);
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of mfDecU16Ext */

  
/*
*
*       Fun:   mfEncU16
*
*       Desc:  message function - encode unsigned 16 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU16
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU16(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 val;
   U16 shf;
   U16 len;
   TknU16 *tp;
   U8 shftVal;

   TRC2(mfEncU16)
   /* check mandatory dependencies */
   tp = (TknU16 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   len = 2;
   val = tp->val;  
    
   mfLength = FALSE;

   if (*tep->flagp & TF_OPT5)
   {
     if (tep->func)
       if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);
   }

   if (mfLength)
   {
     len = 1;
     shftVal = 0;
   }
   else
     shftVal=8;

   if (msgCtlp->validate)
   {
     if ((len < tep->minLen) || (len > tep->maxLen))
       MSGRET(msgCtlp, MFCCINVINFOEL);
     if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
       MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   
   for (i = 0, shf = shftVal; i < len; i++)
   {
     if (msgCtlp->encode)
     {
       ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
       if (ret != ROK)
         MSGRET(msgCtlp, MFRESFAILURE);
#endif
     }

     if (shf != 0)
       shf -= 8;
     msgCtlp->octIdx += 1;
     msgCtlp->elen += 1;
   }
   
   /* if there is a user function, execute it */
   if (!(*tep->flagp & TF_OPT5))
     if (tep->func)
       if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);
   
   RETVALUE(MFROK);
} /* end of mfEncU16 */




  
/*
*
*       Fun:   mfEncU16Ext
*
*       Desc:  message function - encode unsigned 16 bit extended
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU16Ext
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU16Ext(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 val;
   U16 shf;
   U16 len;
   TknU16 *tp;

   TRC2(mfEncU16Ext)
   /* check mandatory dependencies */
   tp = (TknU16 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU16));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   /* KRP - len = 2 - Error value originally here */
   len = 3;
   val = tp->val;      
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U16) tep->minVal) || (val > (U16) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0, shf = 14; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 7;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   RETVALUE(MFROK);
} /* end of mfEncU16Ext */

  
/*
*
*       Fun:   mfDecU24
*
*       Desc:  message function - decode unsigned 24 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU24
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecU24(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U8 len;                  /* token length */
   TknU32 *tp;
   U32 val;

   TRC2(mfDecU24)

   /* if token present based on last ext flag and not extended */
   tp = (TknU32 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);

   /* Check if this Token present only if Additional Extension is set */
   if ((*tep->flagp & TF_PADDEXTN) && (mfAddExt != 1))
   {
      RETVALUE(ROK);
   }

   /* token must be present, check it */
   val = 0;
#ifdef SS7
#ifdef SP
   if (msgCtlp->elen == 3)
      len = 3;
   else
#endif /* SP */
#endif /* SS7 */
#ifdef V5X
   if (msgCtlp->elen == 3)
      len = 3;
   else
#endif /* V5X */
   if ((msgCtlp->elen == 3) || (msgCtlp->elen == 6))
/* modified len to 3 to decode BusGrp IE for NT SPRINT */
      len = 3;
   else if ((msgCtlp->elen == 7) || (msgCtlp->elen == 4))
      len = 3;
   else 
     /* modified length to 3 to decode Private Network Identifier in facility 
        message for NTDMS100P */
      len = 3;
   
   if (*tep->flagp & TF_EXTINT)
   {  /* Extended Integer */
     /* Set to the biggest Length possible for a U24, actual octets shall 
        depend on extension bits */
     len = 3;
     val = 0;
     for (i = 0; (i < len) && msgCtlp->elen; i++)
     {
       if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
       val |= ((c & 0x7f) << (i * 7));
       msgCtlp->octIdx += 1;
       msgCtlp->elen -= 1;
       if (c & 0x80)
       {
         /* If Extension Flag Set, break */
         break;
       }
     }
     /* if the Ext Bit not set in last octet */
     if (!(c & 0x80))
     {
       MSGRET(msgCtlp, MFCCINVMSG);
     }
   }
   else
     for (i = 0; (i < len) && msgCtlp->elen; i++)
     {
       if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
       val = (val << 8) | c;
       msgCtlp->octIdx += 1;
       msgCtlp->elen -= 1;
     }

   if (tep->mask)
      c &= tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of mfDecU24 */

  
/*
*
*       Fun:   mfEncU24
*
*       Desc:  message function - encode unsigned 24 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU24
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU24(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 shf;
   U16 len;
   TknU32 *tp;
   U32 val;
   U8 octet;

   TRC2(mfEncU24);

   len = 0;

   /* check mandatory dependencies */
   tp = (TknU32 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   val = 0;
#ifdef SS7
#ifdef SP
   if (msgCtlp->cfgp->flags & MF_SCCP)
      len = 3;
#endif /* SP */
#endif /* SS7 */
#ifdef V5X
   len = tep->minLen;
#endif /* V5X */
   if (tep->func)
      len = (*tep->func)(msgCtlp, (U32) 0);

   len = tep->minLen; /* added to encode business group IE for NTSPRINT */

   val = tp->val;      
   
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   if (*tep->flagp & TF_EXTINT)
   {
     if (msgCtlp->encode)
     {
       for (i = 0; i < len; i++)
       {
         octet = (val & 0x7F);
         val = val >> (i * 7);
         if (val == 0) 
         {
           /* Code the last Octet, with Extesion Bit set to 1 */
           ret = SAddPstMsg((octet & 0x80), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
           if (ret != ROK)
             MSGRET(msgCtlp, MFRESFAILURE);
#endif
           msgCtlp->bitIdx += 8;
           msgCtlp->octIdx += 1;
           msgCtlp->elen += 1;
               
           break;
         } /* if Last Octet to be coded in this U24 */
         else
         {
           ret = SAddPstMsg(octet, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
           if (ret != ROK)
             MSGRET(msgCtlp, MFRESFAILURE);
#endif
           msgCtlp->bitIdx += 8;
           msgCtlp->octIdx += 1;
           msgCtlp->elen += 1;
         } /* if not the Last Octet to be coded */
       } /* For maximum Octets in U24 */
     } /* if Encode */
     RETVALUE(MFROK);
   } /* If Code Extended Integral */
   
   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   shf = 8 * (len - 1);
   for (i = 0; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 8;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   RETVALUE(MFROK);
} /* end of mfEncU24 */

  
/*
*
*       Fun:   mfDecU32
*
*       Desc:  message function - decode unsigned 32 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecU32
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecU32(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;                   /* counter */
   Data c;                  /* data character */
   U16 len;                 /* token length */
   TknU32 *tp;
   U32 val;

   TRC2(mfDecU32)

   /* if token present based on last ext flag and not extended */
   tp = (TknU32 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag(tep->reg))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag(tep->reg) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
      RETVALUE(MFROK);

   /* token must be present, check it */
   val = 0;
   if (*tep->flagp & TF_EREM)
      len = msgCtlp->elen;
   else len = 4;
   for (i = 0; (i < len) && msgCtlp->elen; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      val = (val << 8) | c;
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
   }

   if (tep->mask)
      c &= tep->mask;

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* if last token in octet */
   if (*tep->flagp & TF_EXT)
   {
      mfExt = (U8)(c & 0x80);
   }

   /* if its a push flag, push it */
   if (*tep->flagp & TF_PUSHF) 
   {
      if (val)
         mfPushFlag(1);
      else mfPushFlag(0);      
   }

   /* save token info in msg struct */
   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = val;
   }

   RETVALUE(MFROK);
} /* end of mfDecU32 */

  
/*
*
*       Fun:   mfEncU32
*
*       Desc:  message function - encode unsigned 32 bit
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncU32
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncU32(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 i;
   U16 shf;
   U16 len;
   TknU32 *tp;
   U32 val;

   TRC2(mfEncU32)
   /* check mandatory dependencies */
   tp = (TknU32 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU32));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag(tep->reg, mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
      }
   }

   /* token is present, check it */
   len = 4;
   val = tp->val;      
   if (msgCtlp->validate)
   {
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if ((val < (U32) tep->minVal) || (val > (U32) tep->maxVal))
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* add octets to message */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0, shf = 24; i < len; i++)
   {
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg((U8) (val >> shf), mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      shf -= 8;
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) &val)) != MFROK)
         MSGRET(msgCtlp, ret);

   RETVALUE(MFROK);
} /* end of mfEncU32 */

  
/*
*
*       Fun:   mfDecStr
*
*       Desc:  message function - decode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecStr
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecStr(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;
   U16 len;
   TknStr *tp;
   U16 i;
   U16 size;
   U8 length;

   TRC2(mfDecStr);


   size = 0;
   length = 0;

   /* if token present based on last ext flag and not extended */
   tp = (TknStr *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   switch (tep->type)
   {
      case TET_STRS:
      case TET_STRS_IA5:
         size = sizeof(TknStrS);
         length = MF_SIZE_TKNSTRS;
         break;
      case TET_STRM:
         size = sizeof(TknStrM);
         length = MF_SIZE_TKNSTRM;
         break;
      case TET_STR:
      case TET_STR_IA5:
         size = sizeof(TknStr);
         length = MF_SIZE_TKNSTR;
         break;
      case TET_STRL:
         size = sizeof(TknStrE);
         length = MF_SIZE_TKNSTRE;
         break;

   }
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) size);
   tp->len = 0;
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (*tep->flagp & TF_PEXTN) 
      {
         if (mfChkFlag((U8)(tep->reg & 0xf)))
            MSGRET(msgCtlp, MFCCINVINFOEL);
      }
      else if ((*tep->flagp & TF_PEXT) && (mfExt == 0))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      RETVALUE(MFROK);
   }

   if (*tep->flagp & TF_PEXTN) 
   {
      if (mfChkFlag((U8)(tep->reg & 0xf)) == 0)
         RETVALUE(MFROK);
   }
   else if ((*tep->flagp & TF_PEXT) && (mfExt))
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
     if (!((*tep->flagp & TF_EREM) && ((msgCtlp->swtch == 20) ||
                                       (msgCtlp->swtch == 21))))
#endif /* QN */
       RETVALUE(MFROK);

   /* if there is a user function, execute it */
   if (!(*tep->flagp & TF_OPT5))
     if (tep->func)
       if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* token must be present, check it */
   if (*tep->flagp & TF_PLEN)
   {
      len = mfLen;
      mfLen = 0;
      if (len < 1)
         RETVALUE(ROK);
   }
   else
      len = msgCtlp->elen;
   
   if (msgCtlp->validate)
      if ((len < tep->minLen) || (len > tep->maxLen) || (len > length))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* read in bytes */
   for (i = 0; i < len; i++)
   {
      if (SExamMsg(&c, mp, msgCtlp->octIdx) != ROK)
         MSGRET(msgCtlp, MFCCINVMSG);
      mfExt = 0;
      if (*tep->flagp & TF_PEXTN0)
      {
         if (mfChkFlag((U8)(tep->reg >> 4)) == 0)
         {
            mfExt = (U8)(c & 0x80);
            c &= 0x7f;
         }
      }
      if ((msgCtlp->validate) && ((tep->type == TET_STR_IA5) || 
              (tep->type == TET_STRS_IA5)) && (c > (U8)0x7f)) 
         MSGRET(msgCtlp, MFCCINVINFOEL);
      if (msgCtlp->decode)
         tp->val[i] = c;
      msgCtlp->octIdx += 1;
      msgCtlp->elen -= 1;
      if (mfExt)
         break;
   }

   msgCtlp->bitIdx += (U16 )(len << 3);

   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->len = (U8) len;
   }

   if (*tep->flagp & TF_OPT5)
   {
     if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);
   }

   RETVALUE(MFROK);
} /* end of mfDecStr */




  
/*
*
*       Fun:   mfEncStr
*
*       Desc:  message function - encode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncStr
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncStr(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Data c;
   TknStr *tp;
   U16 i;                   /* counter */
   U16 len;
   U16 size;
   U8 length;

   TRC2(mfEncStr);

   size = 0;
   length = 0;
   /* check mandatory dependencies */
   tp = (TknStr *) msgCtlp->dup1;
   switch (tep->type)
   {
      case TET_STRS:
      case TET_STRS_IA5:
         size = sizeof(TknStrS);
         length = MF_SIZE_TKNSTRS;
         break;
      case TET_STRM:
         size = sizeof(TknStrM);
         length = MF_SIZE_TKNSTRM;
         break;
      case TET_STR:
      case TET_STR_IA5:
         size = sizeof(TknStr);
         length = MF_SIZE_TKNSTR;
         break;
      case TET_STRL:
         size = sizeof(TknStrE);
         length = MF_SIZE_TKNSTRE;
         break;

   }
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) size);
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
         RETVALUE(MFROK);
   }

   /* token is present, check dependencies */
   if (*tep->flagp & TF_PEXTN)
   {
      if (msgCtlp->encode)
         mfSetFlag((U8)(tep->reg & 0xf), mp);
   }
   else if (*tep->flagp & TF_PEXT)
   {
      if (msgCtlp->encode)
      {
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
        if ((*tep->flagp & TF_EREM) && (msgCtlp->swtch != 20) && 
            (msgCtlp->swtch != 21))
        {
#endif /* IN */
         mfExt = 0;
         ret = mfSetExt(mp, mfExt);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret)
            MSGRET(msgCtlp, ret);
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
        }
#endif /* QN */
      }
   }

   if (*tep->flagp & TF_OPT5)
   {
     if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);
   }

   /* token is present, check it */
   len = tp->len;
   if (msgCtlp->validate)
      if ((len < tep->minLen) || (len > tep->maxLen) || (len > length))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* write octets to msg */
   msgCtlp->bitIdx += (U16 )(len << 3);
   for (i = 0; i < len; i++)
   {
      c = tp->val[i];
      if ((msgCtlp->validate) && ((tep->type == TET_STR_IA5)  ||
                (tep->type == TET_STRS_IA5)) && ((U8)c  > (U8)0x7f)) 
          MSGRET(msgCtlp, MFCCINVINFOEL);

      mfExt = 0;
      if (*tep->flagp & TF_PEXTN0)
      {
         if (mfChkFlag((U8)(tep->reg >> 4)) == 0)
         {
            if ((i == (len - 1)) && (len == 1))
               mfExt = 0x80;
         }
      }
      c |= mfExt;
      if (msgCtlp->encode)
      {
         ret = SAddPstMsg(c, mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      msgCtlp->octIdx += 1;
      msgCtlp->elen += 1;
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);
   
   RETVALUE(MFROK);
} /* end of mfEncStr */

  
/*
*
*       Fun:   mfInitTkns
*
*       Desc:  message function - init tokens
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfInitTkns
(
TknHdr **cmsp1,
TknHdr **cmsp2,
CONSTANT TknElmtDef *CONSTANT *telp,
U8 mode,
Swtch swtch,
U32 *flags 
)
#else
PRIVATE S16 mfInitTkns(cmsp1, cmsp2, telp, mode, swtch, flags)
TknHdr **cmsp1;
TknHdr **cmsp2;
CONSTANT TknElmtDef *CONSTANT *telp;
U8 mode;
Swtch swtch;
U32 *flags;
#endif
{
   CONSTANT TknElmtDef *tep;         /* token element definition pointer */
   TknU8 *tpu8s;
   TknU8 *tpu8d;
   TknU16 *tpu16s;
   TknU16 *tpu16d;
   TknU32 *tpu32s;
   TknU32 *tpu32d;
   TknStr *tpstrs;
   TknStr *tpstrd;
   TknStrE *tpstrsE;
   TknStrE *tpstrdE;
   TknStrS *tpstrsS;
   TknStrS *tpstrdS;
   TknStrM *tpstrsM;
   TknStrM *tpstrdM;


   TRC2(mfInitTkns);


   UNUSED(flags);

   /* loop thru token elements and init to done or error */
   while (*telp)
   {
      tep = *telp;

      telp += 1;

      switch (tep->type)
      {
         case TET_U8:
         case TET_U8_ENUM:
            tpu8d = (TknU8 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu8d->pres = PRSNT_DEF;
                  tpu8d->val = (U8) tep->defs[swtch];
               }
               else 
                  tpu8d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu8s = (TknU8 *) *cmsp1;

               /* validate present flag */
               if ( ((tpu8s->pres != NOTPRSNT) && (tpu8s->pres != PRSNT_NODEF) 
                  && (tpu8s->pres != PRSNT_DEF)) )
               {
                  tpu8d->pres = NOTPRSNT;
               }
               else
               {
                  tpu8d->pres = tpu8s->pres;
                  tpu8d->val = tpu8s->val;
               }
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknU8));
            } 
            else
               tpu8d->pres = NOTPRSNT;

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknU8));
            break;

         case TET_BITS:
            switch(tep->maxLen)
            {
               case 2:
                  tpu16d = (TknU16 *) *cmsp2;
                  if (mode == PRSNT_DEF)
                  {
                     /* copy from database default to token */
                     if (tep->defs != NULLP)
                     {
                        tpu16d->pres = PRSNT_DEF;
                        tpu16d->val = (U16) tep->defs[swtch];
                     }
                     else 
                        tpu16d->pres = NOTPRSNT;
                  }
                  else if (mode == PRSNT_NODEF)
                  {
                     /* copy from src to dst token */
                     tpu16s = (TknU16 *) *cmsp1;
                     tpu16d->pres = tpu16s->pres;
                     tpu16d->val = tpu16s->val;
                     fpAdd((PTR *) cmsp1, (U32) sizeof(TknU16));
                  } 
                  else
                     tpu16d->pres = NOTPRSNT;

                  fpAdd((PTR *) cmsp2, (U32) sizeof(TknU16));
                  break;
            case 3:
            case 4:
               tpu32d = (TknU32 *) *cmsp2;
               if (mode == PRSNT_DEF)
               {
                  /* copy from database default to token */
                  if (tep->defs != NULLP)
                  {
                     tpu32d->pres = PRSNT_DEF;
                     tpu32d->val = (U32) tep->defs[swtch];
                  }
                  else 
                     tpu32d->pres = NOTPRSNT;
               }
               else if (mode == PRSNT_NODEF)
               {
                  /* copy from src to dst token */
                  tpu32s = (TknU32 *) *cmsp1;
                  tpu32d->pres = tpu32s->pres;
                  tpu32d->val = tpu32s->val;
                  fpAdd((PTR *) cmsp1, (U32) sizeof(TknU32));
               } 
               else
                  tpu32d->pres = NOTPRSNT;

               fpAdd((PTR *) cmsp2, (U32) sizeof(TknU32));
               break;
            }
            break;

         case TET_U16:
         case TET_U16_EXT:
            tpu16d = (TknU16 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu16d->pres = PRSNT_DEF;
                  tpu16d->val = (U16) tep->defs[swtch];
               }
               else 
                  tpu16d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu16s = (TknU16 *) *cmsp1;
               tpu16d->pres = tpu16s->pres;
               tpu16d->val = tpu16s->val;
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknU16));
            } 
            else
               tpu16d->pres = NOTPRSNT;

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknU16));
            break;

         case TET_U24:
         case TET_U32:
            tpu32d = (TknU32 *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  tpu32d->pres = PRSNT_DEF;
                  tpu32d->val = (U32) tep->defs[swtch];
               }
               else 
                  tpu32d->pres = NOTPRSNT;
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpu32s = (TknU32 *) *cmsp1;
               tpu32d->pres = tpu32s->pres;
               tpu32d->val = tpu32s->val;
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknU32));
            } 
            else
               tpu32d->pres = NOTPRSNT;

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknU32));
            break;

         case TET_STR:
         case TET_STR_IA5:
            tpstrd = (TknStr *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrd->pres = NOTPRSNT;
                     tpstrd->len = 0;
                  }
                  else
                  {
                     tpstrd->pres = PRSNT_DEF;
                     tpstrd->len = (U8) mfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrd->len > 0)
                        mfBcopy((U8 *)tep->defs[swtch], tpstrd->val, 
                                (U32) tpstrd->len);
                     else 
                        tpstrd->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrd->pres = NOTPRSNT;
                  tpstrd->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrs = (TknStr *) *cmsp1;
               tpstrd->pres = tpstrs->pres;
               /* if present, copy */
               if (tpstrs->pres)
               {
                  mfBcopy(tpstrs->val, tpstrd->val, (U32) tpstrs->len);
                  tpstrd->len = tpstrs->len;
               }
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknStr));
            } 
            else 
            {
               tpstrd->pres = NOTPRSNT;
               tpstrd->len = 0;
            }
            switch (tep->type)
            {
            }
            fpAdd((PTR *) cmsp2, (U32) sizeof(TknStr));
            break;

         case TET_STRL:
            tpstrdE = (TknStrE *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdE->pres = NOTPRSNT;
                     tpstrdE->len = 0;
                  }
                  else
                  {
                     tpstrdE->pres = PRSNT_DEF;
                     tpstrdE->len = (U8) mfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdE->len > 0)
                        mfBcopy((U8 *)tep->defs[swtch], tpstrdE->val, 
                                (U32) tpstrdE->len);
                     else 
                        tpstrdE->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdE->pres = NOTPRSNT;
                  tpstrdE->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsE = (TknStrE *) *cmsp1;
               tpstrdE->pres = tpstrsE->pres;
               /* if present, copy */
               if (tpstrsE->pres)
               {
                  mfBcopy(tpstrsE->val, tpstrdE->val, (U32) tpstrsE->len);
                  tpstrdE->len = tpstrsE->len;
               }
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknStrE));
            } 
            else 
            {
               tpstrdE->pres = NOTPRSNT;
               tpstrdE->len = 0;
            }

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknStrE));
            break;

         case TET_STRM:
            tpstrdM = (TknStrM *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdM->pres = NOTPRSNT;
                     tpstrdM->len = 0;
                  }
                  else
                  {
                     tpstrdM->pres = PRSNT_DEF;
                     tpstrdM->len = (U8) mfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdM->len > 0)
                        mfBcopy((U8 *)tep->defs[swtch], tpstrdM->val, 
                                (U32) tpstrdM->len);
                     else 
                        tpstrdM->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdM->pres = NOTPRSNT;
                  tpstrdM->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsM = (TknStrM *) *cmsp1;
               tpstrdM->pres = tpstrsM->pres;
               /* if present, copy */
               if (tpstrsM->pres)
               {
                  mfBcopy(tpstrsM->val, tpstrdM->val, (U32) tpstrsM->len);
                  tpstrdM->len = tpstrsM->len;
               }
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknStrM));
            } 
            else 
            {
               tpstrdM->pres = NOTPRSNT;
               tpstrdM->len = 0;
            }

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknStrM));
            break;

         case TET_STRS:
         case TET_STRS_IA5:
            tpstrdS = (TknStrS *) *cmsp2;
            if (mode == PRSNT_DEF)
            {
               /* copy from database default to token */
               if (tep->defs != NULLP)
               {
                  if (!(U8 *)tep->defs[swtch] )
                  {
                     tpstrdS->pres = NOTPRSNT;
                     tpstrdS->len = 0;
                  }
                  else
                  {
                     tpstrdS->pres = PRSNT_DEF;
                     tpstrdS->len = (U8) mfStrlen((U8 *)tep->defs[swtch]);
                     if (tpstrdS->len > 0)
                        mfBcopy((U8 *)tep->defs[swtch], tpstrdS->val, 
                                (U32) tpstrdS->len);
                     else 
                        tpstrdS->pres = NOTPRSNT;
                  }
               }
               else
               {
                  tpstrdS->pres = NOTPRSNT;
                  tpstrdS->len = 0;
               }
            }
            else if (mode == PRSNT_NODEF)
            {
               /* copy from src to dst token */
               tpstrsS = (TknStrS *) *cmsp1;
               tpstrdS->pres = tpstrsS->pres;
               /* if present, copy */
               if (tpstrsS->pres)
               {
                  mfBcopy(tpstrsS->val, tpstrdS->val, (U32) tpstrsS->len);
                  tpstrdS->len = tpstrsS->len;
               }
               fpAdd((PTR *) cmsp1, (U32) sizeof(TknStrS));
            } 
            else 
            {
               tpstrdS->pres = NOTPRSNT;
               tpstrdS->len = 0;
            }

            fpAdd((PTR *) cmsp2, (U32) sizeof(TknStrS));
            break;
      }
   }
   RETVALUE(MFROK);
} /* end of mfInitTkns */

  
/*
*
*       Fun:   mfDecTkns
*
*       Desc:  message function - decode tokens
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecTkns
(
Buffer *mp,
CONSTANT TknElmtDef *CONSTANT *telp,
MfMsgCtl *msgCtlp              /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecTkns(mp, telp, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *CONSTANT *telp;
MfMsgCtl *msgCtlp;             /* pointer to message control structure */
#endif
{
   S16 ret;                    /* return code */
   U16 errCnt;                 /* error count */
   CONSTANT TknElmtDef *tep;   /* token element definition pointer */

   TRC2(mfDecTkns)
   /* initialize control variables */
   ret = MFROK;
   mfExt = 1;
   mfOctet = 0;
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
   /* begin in001.31 */
   /* clear mfStk */
   for (mfSp = 0; mfSp < MF_STKSIZE; mfSp++)
      mfStk[mfSp] = 0;
   /* end of in001.31 */
#endif
   mfSp = MF_STKSIZE;
   mfSaveMultiRate = 0;
   errCnt = msgCtlp->errCnt;
   msgCtlp->ee[errCnt].tknIdx = 0;

   /* loop thru token elements and decode to done or error */
   while (*telp != NULLP) 
   {
      tep = *telp;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!tep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif

      telp += 1;
      switch (tep->type)
      {
         case TET_U8:
            ret = mfDecU8(mp, tep, msgCtlp);
            break;

         case TET_U8_ENUM:
            ret = mfDecU8Enum(mp, tep, msgCtlp);
            break;

         case TET_BITS:
         case TET_BITS_ENUM:
            ret = mfDecBits(mp, tep, msgCtlp);
            break;

         case TET_U16:
            ret = mfDecU16(mp, tep, msgCtlp);
            break;

         case TET_U16_EXT:
            ret = mfDecU16Ext(mp, tep, msgCtlp);
            break;

         case TET_U24:
            ret = mfDecU24(mp, tep, msgCtlp);
            break;

         case TET_U32:
            ret = mfDecU32(mp, tep, msgCtlp);
            break;

         case TET_STR:
         case TET_STR_IA5:
         case TET_STRS:
         case TET_STRS_IA5:
         case TET_STRM:
         case TET_STRL:
            ret = mfDecStr(mp, tep, msgCtlp);
            break;
#ifdef SS7
#ifdef SP
         case TET_DATA:
            ret = mfDecData(mp, tep, msgCtlp);
            break;
#endif /* SP */
#endif /* SS7 */
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            MSGRET(msgCtlp, MFDEBUGERR);
#endif
      }

      if (ret != ROK)
         break;

      msgCtlp->ee[errCnt].tknIdx++;
   }

   if (ret != ROK)
   {
      mfSkipTkns((TknHdr **) &msgCtlp->dup1, 
                 (CONSTANT TknElmtDef * CONSTANT*)telp);
      RETVALUE(ret);
   }

   RETVALUE(MFROK);
} /* end of mfDecTkns */

  
/*
*
*       Fun:   mfEncTkns
*
*       Desc:  message function - encode tokens
*
*       Ret:   MFROK      - ok
* 
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncTkns
(
Buffer *mp,
CONSTANT TknElmtDef *CONSTANT *telp,
MfMsgCtl *msgCtlp              /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncTkns(mp, telp, msgCtlp)
Buffer *mp;
CONSTANT TknElmtDef *CONSTANT *telp;
MfMsgCtl *msgCtlp;             /* pointer to message control structure */
#endif
{
   S16 ret;                    /* return code */
   U16 errCnt;                 /* error count */
   CONSTANT TknElmtDef *tep;   /* token element definition pointer */
   TknHdr *tp;                 /* token header pointer */

   TRC2(mfEncTkns)
   /* initialize control variables */
   mfExt = 1;
   mfAddExt = 0;

/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
   /* begin in001.31 */
   /* clear mfStk */
   for (mfSp = 0; mfSp < MF_STKSIZE; mfSp++)
      mfStk[mfSp] = 0;
   /* end of in001.31 */
#endif
   mfSp = MF_STKSIZE;
   errCnt = msgCtlp->errCnt;
   msgCtlp->ee[errCnt].tknIdx = 0;

   /* loop thru token elements and encode to done or error */
   while (*telp != NULLP)
   {
      tp = (TknHdr *) msgCtlp->dup1;
      if ( ((tp->pres != NOTPRSNT) && (tp->pres != PRSNT_NODEF) 
         && (tp->pres != PRSNT_DEF)) )
      {
         MSGRET(msgCtlp, MFCCINVINFOEL);
      }

      tep = *telp;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!tep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif

      telp += 1;
      switch (tep->type)
      {
         case TET_U8:
            if ((ret = mfEncU8(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U8_ENUM:
            if ((ret = mfEncU8Enum(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_BITS:
         case TET_BITS_ENUM:
            if ((ret = mfEncBits(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U16:
            if ((ret = mfEncU16(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U16_EXT:
            if ((ret = mfEncU16Ext(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U24:
            if ((ret = mfEncU24(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;

         case TET_U32:
            if ((ret = mfEncU32(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;
         case TET_STRL:
         case TET_STR:
         case TET_STR_IA5:
         case TET_STRS:
         case TET_STRM:
         case TET_STRS_IA5:
            if ((ret = ret = mfEncStr(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret); 
            break;
#ifdef SS7
#ifdef SP
         case TET_DATA:
            if ((ret = mfEncData(mp, tep, msgCtlp)) != MFROK)
               RETVALUE(ret);
            break;
#endif /* SP */
#endif /* SS7 */

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            MSGRET(msgCtlp, MFDEBUGERR);
#endif
      }
      msgCtlp->ee[errCnt].tknIdx++;
   }
   RETVALUE(MFROK);
} /* end of mfEncTkns */


  
/*
*
*       Fun:   mfInitElmts
*
*       Desc:  message function - init elements
*
*       Ret:   MFROK      - ok
*
*       Notes: This is optimized for subset-to-superset initialization.
*              Superset to subset can also be optimized in this or another
*              similar function.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfInitElmts
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfInitElmts(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   CONSTANT MsgElmtDef *CONSTANT *melp1;
   CONSTANT MsgElmtDef *CONSTANT *sav_melp1;
   CONSTANT MsgElmtDef *CONSTANT *melp2;
   CONSTANT MsgElmtDef *mep1;
   CONSTANT MsgElmtDef *mep2;
   CONSTANT MsgElmtDef *CONSTANT *tmp_melp1;
   ElmtHdr *cmsp1;          /* beginning source element header */
   ElmtHdr *cmsp2;          /* beginning destination element header */
   ElmtHdr *dep;            /* current destination element header */
   U8 mode;
   Swtch swtch;
   U32  flags;
   
   TRC2(mfInitElmts);


   /* initialize control variables */
   cmsp1 = msgCtlp->dup1;
   cmsp2 = msgCtlp->dup2;
   melp1 = tmp_melp1 = msgCtlp->melp1;
   melp2 = msgCtlp->melp2;
   swtch = msgCtlp->swtch;
   mode  = msgCtlp->mode;
   flags = msgCtlp->flags;
   sav_melp1 = NULLP;

   mep1 = NULLP;

   if(mode == NOTPRSNT)
   {
      while(*melp2 != NULLP)
      {
         mep2 = *melp2;
         dep = (ElmtHdr *)cmsp2;
         fpAdd((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));
         dep->pres = NOTPRSNT;
         mfSkipTkns((TknHdr **) &cmsp2, mep2->telp); 
         melp2++;
      }
      RETVALUE(MFROK);
   }
   if(cmsp1)
      mep1 = *melp1;
   /* loop thru message elements and init to done */
#if (ERRCLASS & ERRCLS_DEBUG)
   if ((((cmsp1 == NULLP) || (*melp1 == NULLP)) 
        && (msgCtlp->mode == PRSNT_NODEF)) )
      MSGRET(msgCtlp, MFDEBUGERR);

   if (((cmsp1 != NULLP) && (msgCtlp->mode != PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);
#endif

   while(*melp2 != NULLP)
   {
      mep2 = *melp2;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!(mep2->flagp))
         MSGRET(msgCtlp, MFDEBUGERR);
#endif
      dep = (ElmtHdr *)cmsp2;
      fpAdd((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));

      /* If the element is not applicable in the Destination skip it */
      if(mep2->flagp[swtch] & EF_NA)
      {
         dep->pres = NOTPRSNT;
         melp2++;
         mfSkipTkns((TknHdr **) &cmsp2, mep2->telp); 
         continue;
      }
      if(mode == PRSNT_DEF)
      {
         /* If the mode is PRSNT_DEF then we need to init from the DB
          * and ignore the source(assumption is that source passed will
          * be NULLP)
          */
         if(!(mep2->flagp[swtch] & EF_MAND)) 
         {
            /* If non mandatory element then set it to NOTPRSNT and skip 
             * over it. No need to check for the mode.
             */
            dep->pres = NOTPRSNT;
            mfSkipTkns((TknHdr **)&cmsp2, mep2->telp); 
         }
         else
         {
            dep->pres = mode;
            mfInitTkns(NULLP, (TknHdr **) &cmsp2, mep2->telp, 
                       mode, swtch, &flags); 
         }
         melp2++;
         continue;
      }
      else   /* PRSNT_NODEF mode */
      {
         /* Here we need to find an element in the source with the same
          * index as the destination. If found we init the destination
          * with the contents of the source. Else we skip that element
          * in the destination setting it to NOTPRSNT.
          */
         /* 
          * Here "sav_melp1" is the last element we encountered in the
          * source. We initialise it to NULLP and set it to the current
          * element in the source we are checking in this case.  If this 
          * element is not applicable we skip it and go on to check the
          * next element.  If we reach the last element in the source
          * we just wrapback to the first element.  We get out of the
          * loop either when there is a match or we have gone thru. all
          * the source elements once.  If there is no match then set the
          * element we were checking for in the destination to NOTPRSNT.
          * Skip the tokens in the source and reset the "sav_melp1" to
          * NULLP. This ensures that we start with the same element 
          * which did not match  in the source. 
          * If there is a match set the mode of the destination to that
          * of the matching source element.  If the mode is NOTPRSNT then
          * skip the element in both the source and destination.  Otherwise
          * initialise the destination from the tokens in the source element.
          * Also increment the source element pointer to the next element
          * (to take care of multiple elements with same index) after 
          * setting the sav_melp1 to the current element.
          *
          */
         while(melp1 != sav_melp1)
         {
            if(sav_melp1 == NULLP)
               sav_melp1 = melp1;
            mep1 = *melp1;
            if(mep1->flagp[swtch] & EF_NA)
            {
               fpAdd((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
               mfSkipTkns((TknHdr **) &cmsp1, mep1->telp);
            }
            else 
            {
               if(mep1->idx == mep2->idx)
               {
                  melp1++;
                  break;
               }
               else
               {
                  fpAdd((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
                  mfSkipTkns((TknHdr **) &cmsp1, mep1->telp);
               }
            }
            melp1++;
            if(*melp1 == NULLP)
            {
               melp1 = tmp_melp1;
               cmsp1 = msgCtlp->dup1;
            }
         }
         if(melp1 == sav_melp1)
         {
            /* This means that the element was not found in the source.
             * So skip the tokens in the destination *
             */
            dep->pres = NOTPRSNT;
            mfSkipTkns((TknHdr **)&cmsp2, mep2->telp);
            melp2++;
            sav_melp1 = NULLP;
         }
         else 
         {
            /* Initialise tokens */
            dep->pres = ((ElmtHdr *)cmsp1)->pres;
            fpAdd((PTR *)&cmsp1, (U32) sizeof(ElmtHdr));
            if(dep->pres == NOTPRSNT)
            {
               mfSkipTkns((TknHdr **) &cmsp2, mep2->telp);
               mfSkipTkns((TknHdr **) &cmsp1, mep1->telp);
            }
            else
               mfInitTkns((TknHdr **) &cmsp1, (TknHdr **) &cmsp2, 
                     mep2->telp, mode, swtch, &flags); 
            melp2++;
            sav_melp1 = NULLP;
            if(*melp1 == NULLP)
            {
               melp1 = tmp_melp1;
               cmsp1 = msgCtlp->dup1;
            }
         }
      }  
   }
   RETVALUE(MFROK);
} /* end of mfInitElmts */

  
/*
*
*       Fun:   mfInitElmt
*
*       Desc:  message function - init element
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize one specif information element.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInitElmt
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfInitElmt(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
 
   CONSTANT MsgElmtDef *mep;
   ElmtHdr *cmsp1;
   ElmtHdr *cmsp2;
   ElmtHdr *sep;            /* source element header */
   ElmtHdr *dep;            /* destination element header */
   
   TRC2(mfInitElmt)

   /* initialize control variables */
   mfBackOut = 0;
   cmsp1 = msgCtlp->dup1;
   cmsp2 = msgCtlp->dup2;
   mep = msgCtlp->mep;

   /* init one message element */
#if (ERRCLASS & ERRCLS_DEBUG)
   if (((cmsp1) && (msgCtlp->mode != PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);

   if (((!cmsp1) && (msgCtlp->mode == PRSNT_NODEF)))
      MSGRET(msgCtlp, MFDEBUGERR);

   if (!mep )
      MSGRET(msgCtlp, MFDEBUGERR);
#endif

   sep = (ElmtHdr *) cmsp1;
   dep = (ElmtHdr *) cmsp2;
   

   if (cmsp1)
   {
      dep->pres = sep->pres;
      fpAdd((PTR *) &cmsp1, (U32) sizeof(ElmtHdr));
   }
   else
   {
      dep->pres = msgCtlp->mode;
   }

   fpAdd((PTR *) &cmsp2, (U32) sizeof(ElmtHdr));

   /* not present, init */
   if (mep->type != MET_SINGLE2)
   {
      mfInitTkns((TknHdr **) &cmsp1, (TknHdr **) &cmsp2, mep->telp, 
         msgCtlp->mode, msgCtlp->swtch, &msgCtlp->flags);
   }
   RETVALUE(MFROK);
} /* end of mfInitElmt */

  
/*
*
*       Fun:   mfDecElmts
*
*       Desc:  message function - decode elements
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
#define MAX_HOLD 20 
#ifdef ANSI
PRIVATE S16 mfDecElmts
(
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecElmts(msgCtlp)
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   Swtch swtch;             /* switch index */
   CONSTANT MsgElmtDef *mep; /* element definition pointer */
   CONSTANT MsgElmtDef *CONSTANT *sp; /* starting element definition pointer */
   ElmtHdr *ep;             /* element structure pointer */
   ElmtHdr *saveEp;         /* element structure pointer */
   ElmtHdr *cmsp1;          /* current memory structure pointer */
   U8 etype;                /* element type */
   U8 read;                 /* read flag */
   U8 eid;                  /* element id */
   Data c;                  /* message character */
   U8 newShift;             /* new shift flag */
   Bool lckShift;           /* lock shift flag */
   S16 tmpCodeSet;          /* temporary code set */
   S16 saveSet;             /* temporary code set */
   MsgLen msgLen;           /* message length */
   Bool meTwoSkp;           /* me-2 skip flag */
   S16 optAct;              /* action for optional elements decode errors */
   Bool mandElmt;           /* mandatory element flag */
   /* in001.32 */
   U8 saveIdx;              /* saved octet index to beggining of the message */
   U8 indx1;                 /* index */
   U8 savedMandElmt;        /* Saved mandatory element. */
   U8 tmp_elen = 0;         /* Temporary stored element length. */
   
   TRC2(mfDecElmts);


   saveEp = NULLP;
   etype = 0;
   eid = 0;
   mandElmt = FALSE;
   /* initialize control variables */
   if (*msgCtlp->melp1 == NULLP)
      RETVALUE(MFROK);
   swtch = msgCtlp->swtch;
   if (mfDecCont == FALSE)
      mfCodeSet  = 0;
   mfShftLock = FALSE;
   meTwoSkp = FALSE;
   newShift = FALSE;
   lckShift = FALSE;
   saveSet = 0;
   tmpCodeSet = 0;
   savedMandElmt = 0;
   /* in002.31 */
   saveIdx = msgCtlp->octIdx;
   /* get pointer to element definitions in the structure */
   cmsp1 = msgCtlp->dup1;
   /* get pointer to element definitions in the database */
   sp = msgCtlp->melp1;
   read = TRUE;
   optAct = 0;

   mfSaveLyr1ProtVal = 0xFF;
   mfSaveLyrIdent = 0x00;
   mfSaveOctet = 0x00;
   mfLength = FALSE;

   /* loop thru message elements and decode to done or error */
   for (;;)
   {
      /* get pointer to element definitions in the database */
      mep = *msgCtlp->melp1;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!mep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif
      /* save pointer to element definitions in the database */
      msgCtlp->mep = mep;
      /* get pointer to element definitions in the structure */
      ep = (ElmtHdr *) msgCtlp->dup1;
      if (!meTwoSkp)
         /* skip element header except unexpected SINGLE2 */
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));

      if (msgCtlp->firstPass == TRUE)
      {
         /* set NOT PRESENT flag in the structure */
         ep->pres = NOTPRSNT;
         mandElmt = FALSE;

         if (mep->flagp[swtch] & EF_NA)
         {
            msgCtlp->melp1++;
            if (*msgCtlp->melp1 == NULLP)
            {
               msgCtlp->melp1 = msgCtlp->smelp1;
               msgCtlp->dup1 = cmsp1;
               msgCtlp->firstPass = FALSE;
            }
            else 
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
            continue;
         }
         if ((mep->flagp[swtch] & EF_MAND) || (mep->id == 0x18))
         {
            /* increment mandatory count */
            if (msgCtlp->flags & MF_NET)
            {
               if ((mep->flagp[swtch] & EF_UN) && (!meTwoSkp) && 
                   (mep->flagp[swtch] & EF_MAND)) 
               {
                  mandElmt = TRUE;
                  if (savedMandElmt != mep->id)
                  {
                     msgCtlp->exMandCnt++;
                     savedMandElmt =  mep->id;
                  }
               }
            }
            else if (msgCtlp->flags & MF_USR)
            {
               if (((mep->flagp[swtch] & EF_NU) && (!meTwoSkp) &&
                    (mep->flagp[swtch] & EF_MAND)) ||
                   ((mep->id == 0x18) && (msgCtlp->msgIdx == 5)))
                  /* setup message in q.931 from the network has to have 
                     channel id */
               {
                  mandElmt = TRUE;
                  if (savedMandElmt != mep->id)
                  {
                     msgCtlp->exMandCnt++;
                     savedMandElmt = mep->id;
                  }
               }
            }
         }

         /* check for fixed type elements */
         if ((mep->type == MET_FIXED) || (mep->type == MET_FIXED_REM)
            || (mep->type == MET_FIXED_PTR))
         {
            /* save element index and id from the database */
            msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
            msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

            if (mep->type == MET_FIXED_REM)
            { 
               if (mep->flagp[swtch] & EF_NA)
               {
                  msgCtlp->melp1 += 1;  
                  if (*msgCtlp->melp1 == NULLP)
                  {
                     msgCtlp->melp1 = msgCtlp->smelp1;
                     msgCtlp->dup1 = cmsp1;
                     msgCtlp->firstPass = FALSE;
                  }
                  else 
                     mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                  continue;
               }
               if ((!mfCodeSet) && (!lckShift))
               {
                  ep->pres = NOTPRSNT;
                  /* reset database sp pointer to point to the last element
                     that has been processed */
                  sp = msgCtlp->melp1;
                  /* to point to the next element in the database */
                  msgCtlp->melp1 += 1;
                  /* if the last element in the database definition */
                  if (*msgCtlp->melp1 == NULLP)
                  {
                     if ((msgCtlp->validate) && (msgCtlp->acMandCnt 
                                                 < msgCtlp->exMandCnt))
                        /* pdudhr error - return error code */
                        MSGRET(msgCtlp, MFCCINFOELMSSG);
                     if (optAct)
                        RETVALUE(optAct);
                     else
                        RETVALUE(MFROK);
                  }
                  continue;
               }

               SFndLenMsg(msgCtlp->mp, &msgLen);

               if ((MsgLen)(msgLen - msgCtlp->octIdx) > MF_SIZE_TKNSTR)
                  /* codeset specific element - is disallowed in AUS */
               {
                  if (mandElmt)
                     MSGRET(msgCtlp, MFCCINVMSG);
                  else
                  {
                     ep->pres = NOTPRSNT;
                     RETVALUE(MFREOM);
                  }
               }

               msgCtlp->elen = (U8) (msgLen - msgCtlp->octIdx);

               if (msgCtlp->mdbp->func)
                  if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                  {
                      if ((mandElmt) ||
                         ((msgCtlp->cfgp->flags & MF_IGNORE) == 0))
                           /* codeset specific element - is disallwd in AUS */
                           MSGRET(msgCtlp, ret);
                     else
                     {
                        /* reset database sp pointer to point to the last elmnt
                           that has been processed */
                        sp = msgCtlp->melp1;
                        /* to point to the next element in the database */
                        msgCtlp->melp1 += 1;  
                        if (*msgCtlp->melp1 == NULLP)
                        {
                           msgCtlp->melp1 = msgCtlp->smelp1;
                           msgCtlp->dup1 = cmsp1;
                           msgCtlp->firstPass = FALSE;
                        }
                        else 
                           mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                     }
                     continue;
                  }
            }
            else msgCtlp->elen = mep->maxLen;

            /* call token decode procedure */
            if ((ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp)) != MFROK)
            {
               if (mandElmt)
                  RETVALUE(ret);
               else
               {
                  ep->pres = NOTPRSNT;
                  RETVALUE(MFREOM);
               }
            }

            if ((MsgLen )msgCtlp->elen > (MsgLen )(mep->maxLen - mep->minLen))
               /* pdudhr len error - return error code */
               MSGRET(msgCtlp, MFCCINVINFOEL);

            ep->pres = PRSNT_NODEF;

            if (mandElmt)
                msgCtlp->acMandCnt++;
               
            /* reset database sp pointer to point to the last element
            that has been processed */
            sp = msgCtlp->melp1;
            /* to point to the next element in the database */
            msgCtlp->melp1 += 1;
            /* if the last element in the database definition */
            if (*msgCtlp->melp1 == NULLP)
            {
               if ((msgCtlp->validate) && (msgCtlp->acMandCnt 
                     < msgCtlp->exMandCnt))
                  /* pdudhr error - return error code */
                  MSGRET(msgCtlp, MFCCINFOELMSSG);
               if (optAct)
                  RETVALUE(optAct);
               else
                  RETVALUE(MFROK);
            }
            continue;
         }

         /* begin in002.31 */
         /* check for single type 2 elements */
         if (mep->type == MET_SINGLE2)
         {
            indx1 = saveIdx;
            /* skan through the message and see if it is there */
            while (SExamMsg(&c, msgCtlp->mp, indx1) == ROK)
            {
               /* check element type */
               if (!(c & 0x80))
               {
                  if (SExamMsg(&c, msgCtlp->mp, ++indx1) == ROK)
                     indx1 += (U16) (c + 1);
               }
               else
               {
                  if ((c & 0x70) != 0x20)
                     /* single type 1 */
                     indx1++;
                  else
                  {
                     /* single type 2, check is same as searched */
                     if (mep->id == (U8)(c & MF_EID_MASK))
                     {
                        ep->pres = PRSNT_NODEF;
                        if (msgCtlp->octIdx == indx1)
                        {
                           msgCtlp->octIdx+= 1;
                           msgCtlp->bitIdx+= 8;
                        }
                        break;
                     }
                     else
                     {
                        if (mep->flagp[swtch] & EF_MAND)
                        {
                           MSGRET(msgCtlp, MFCCINFOELMSSG);
                        }
                        else
                        {
#if (MF_IN || MF_NV)
                           mfInitErr(msgCtlp, (U8) mep->id, 
                                     (U8) MFCCINVINFOEL);
#endif /* MF_IN || MF_NV */
                           break;
                        }
                     }
                  } /* (c & 0x70) == 0x20 */
               } /* (c & 0x80) */
            } /* while (SExamMsg(&c, msgCtlp->mp, indx1) == ROK) */
            msgCtlp->melp1 += 1;  
            if (*msgCtlp->melp1 == NULLP)
            {
               msgCtlp->melp1 = msgCtlp->smelp1;
               msgCtlp->dup1 = cmsp1;
               msgCtlp->firstPass = FALSE;
            }
            else 
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
            continue;
         }/* end of  in002.31 */
      }

      /* check read next octet flag, exit if all done */
      if (read == TRUE)
      {
         if (SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx) != ROK)
         {
            if (msgCtlp->firstPass == TRUE)
            {
               /* check for current element */
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
               if (mandElmt)
               {
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/

                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINFOELMSSG);
                     RETVALUE(optAct);
                  }
#else
;
#endif

               }
#endif
               for (;;)
               {
                  /* skip the element in the structure */
                  mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                  /* to point to the next element in the database */
                  msgCtlp->melp1 += 1;  
                  if (*msgCtlp->melp1 == NULLP)
                     break;
                  mep = *msgCtlp->melp1;
                  ep = (ElmtHdr *) msgCtlp->dup1;
                  ep->pres = NOTPRSNT;
                  fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                  if (mep->flagp[swtch] & EF_MAND)
                  {
                     if (msgCtlp->flags & MF_NET)
                     {
                        if (mep->flagp[swtch] & EF_UN)
                        {
                           if (savedMandElmt != mep->id)
                           {
                              msgCtlp->exMandCnt++;
                              savedMandElmt = mep->id;
                           }
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                           if(msgCtlp->cfgp->flags & FN_MF) 
                           {
                              /* do FN specific processing here */
                              fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                              RETVALUE(MFCCINFOELMSSG);
                           }
                           else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                           if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) !=
                               ROK)
                           {
                              mfInitErr(msgCtlp, (U8) mep->id, 
                                        (U8) MFCCINFOELMSSG);
                              RETVALUE(optAct);
                           }
#else
;
#endif
#endif
                        }

                     }
                     else if (msgCtlp->flags & MF_USR)
                     {
                        if (mep->flagp[swtch] & EF_NU)
                        {
                           if (savedMandElmt != mep->id)
                           {
                              msgCtlp->exMandCnt++;
                              savedMandElmt = mep->id;
                           }
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                           if(msgCtlp->cfgp->flags & FN_MF) 
                           {
                              /* do FN specific processing here */
                              fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                              RETVALUE(MFCCINFOELMSSG);
                           }
                           else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                           if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) !=
                               ROK)
                           {
                              mfInitErr(msgCtlp, (U8) mep->id, 
                                        (U8) MFCCINFOELMSSG);
                              RETVALUE(optAct);
                           }
#else
;
#endif
#endif
                        }
                     }
                  }
               }
            }
            if ((msgCtlp->validate) && (msgCtlp->acMandCnt 
                  < msgCtlp->exMandCnt))
            {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
               if(msgCtlp->cfgp->flags & FN_MF) 
               {
                  /* do FN specific processing here */
                  fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                  RETVALUE(MFCCINFOELMSSG);
               }
               else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
               if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
               {
                  mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINFOELMSSG);
                  RETVALUE(optAct);
               }
               else
#endif
#endif
                  MSGRET(msgCtlp, MFCCINFOELMSSG);
            }
            if (optAct)
               RETVALUE(optAct);
            else
               RETVALUE(MFREOM);
         }

         /* check element type */
         if (c & 0x80)
         {
            msgCtlp->elen = 1;
#ifdef V5X
            if (mep->flagp[swtch] & EF_V5X)
            {
               if ((c & 0x70) == 0x40)
               {
                  /* single octet, type 1 */
                  etype = MET_SINGLE2;
                  eid   = (U8)(c & MF_EID_MASK);
               }
               else
               {
                  /* single octet, type 2 */            
                  etype = MET_SINGLE1;
                  meTwoSkp = FALSE;
                  eid   = (U8)(c & 0x70);
               }
            }
            else
#endif
            {
               if ((c & 0x70) != 0x20)
               {
                  /* single octet, type 1 */
                  etype = MET_SINGLE1;
                  /* if shift - non-locking */
                  if ((U8) (c & 0x08))
                     eid   = (U8)(c & 0x70);
                  else /* locking shift */
                     if (((c & 0x70) != 0x30) && ((c & 0x70) != 0x50))
                     {                   
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                        if (c > 0x97)
                        {
                           read = TRUE;
                           msgCtlp->octIdx += 1;
                           msgCtlp->bitIdx += 8;
                           msgCtlp->dup1 = ep;
                           if (mep->flagp[swtch] & EF_MAND)
                           {
                              if (msgCtlp->exMandCnt)
                                 msgCtlp->exMandCnt--;
                           }
                           continue;
                        }
                        
#ifdef INTR6
                        if ((msgCtlp->swtch == 9) || 
                            (msgCtlp->swtch == 10))
                           eid   = (U8)(c & 0x70);
                        else
#endif
#ifdef QSIG
                           if (msgCtlp->swtch == 19)
                              eid   = (U8)(c & 0x70);
                           else
#endif
#endif
                     eid   = (U8)(c & 0x77);
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN || MF_NV)
                     if (!eid)
                     {
                        read = TRUE;
                        msgCtlp->octIdx += 1;
                        msgCtlp->bitIdx += 8;
                        msgCtlp->dup1 = ep;
#ifdef FN
                        if(msgCtlp->cfgp->flags & FN_MF) 
                        {
                           /* Do FN specific stuff */
                           fnInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
                        }
                        else    
#endif
#if (MF_IN || MF_NV)
                        mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#else
;
#endif
                        optAct = ACTNSTATPRC;
                        if (mep->flagp[swtch] & EF_MAND)
                        {
                           if (msgCtlp->exMandCnt)
                              msgCtlp->exMandCnt--;
                        }
                        continue;
                     }
#endif
                     saveSet = mfCodeSet;
                     mfCodeSet = 0;
                     lckShift = TRUE;
                  }
                  else
                      eid   = (U8)(c & 0x70);
               }
               else
               {
                  /* single octet, type 2 */            
                  etype = MET_SINGLE2;
                  eid   = (U8)(c & MF_EID_MASK);
                  meTwoSkp = FALSE;
               }
            }
         }
         else
         {
            /* variable length, type 3 */
            etype = MET_VARIABLE;
            eid   = (U8)(c & MF_EID_MASK);
         }
         read = FALSE;
      }

      /* if element is already present, skip to next */
      if ((msgCtlp->firstPass == FALSE) && (ep->pres != NOTPRSNT))
      {
         msgCtlp->melp1 += 1;  
         if (*msgCtlp->melp1 == NULLP)
         {
            msgCtlp->melp1 = msgCtlp->smelp1;
            msgCtlp->dup1 = cmsp1;
         }
         else 
            mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);

         if (sp == msgCtlp->melp1)
         {
            RETVALUE(optAct);
         }

         continue;
      }

      /* in014.31 */
      /* check if expected message element */    
      if ((((U16)(mfCodeSet | eid) == mep->id) &&
           (etype == mep->type) &&
           (!(mep->flagp[swtch] & EF_NA))) ||
          (((msgCtlp->swtch == 9) ||
            (msgCtlp->swtch == 10)) &&
           ((eid == MFME_SHIFT) &&
            (eid == mep->id))))
      {
         msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
         msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mfCodeSet | (U16) eid;

         read = TRUE;
         sp = msgCtlp->melp1;
         meTwoSkp = FALSE;

         if (newShift)
         {
            if (mfShftLock == FALSE)
               mfCodeSet = tmpCodeSet;
         }

         if (etype == MET_SINGLE2)
         {
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;

            /* reset database and structure pointers */
            msgCtlp->melp1 += 1;  
            if (*msgCtlp->melp1 == NULLP)
            {
               msgCtlp->melp1 = msgCtlp->smelp1;
               msgCtlp->dup1 = cmsp1;
               msgCtlp->firstPass = FALSE;
            }

            ep->pres = PRSNT_NODEF;

            if (mep->flagp[swtch] & EF_MAND)
               msgCtlp->acMandCnt++;

            continue;
         }
         else if (etype == MET_VARIABLE)
         {
            /* check element length */
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;
            if (SExamMsg((Data *) &tmp_elen, msgCtlp->mp, msgCtlp->octIdx)
                != ROK)
            {
               if (mandElmt)
               {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVINFOEL);
                     RETVALUE(optAct);
                  }
                  else
#endif
#endif
                     MSGRET(msgCtlp, MFCCINVINFOEL);
               }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
               else
                  if ((optAct = inChkOptElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     if (optAct < ACTNSTATPRC)
                        RETVALUE(optAct);
                  }
#endif
               if (msgCtlp->firstPass == TRUE)
               {
                  for (;;)
                  {
                     mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                     msgCtlp->melp1 += 1;  
                     if (*msgCtlp->melp1 == NULLP)
                        break;
                     mep = *msgCtlp->melp1;
                     ep = (ElmtHdr *) msgCtlp->dup1;
                     ep->pres = NOTPRSNT;
                     fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                     if (mandElmt)
                     {
                        if (savedMandElmt != mep->id)
                        {
                           msgCtlp->exMandCnt++;
                           savedMandElmt = mep->id;
                        }
                     }
                  }
               }
               if ((msgCtlp->validate) && (msgCtlp->exMandCnt 
                     < msgCtlp->acMandCnt))
                  /* should never get here for AUS */
                  MSGRET(msgCtlp, MFCCINFOELMSSG);
               if (optAct < ACTNPRCESS)
                  RETVALUE(optAct);
               else
                  RETVALUE(MFREOM);
            }

            msgCtlp->elen = PutLoByte (msgCtlp->elen, tmp_elen);

            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;

            /* if element length is 0 */
            if (!msgCtlp->elen)
            {
               if (mandElmt)
               {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(optAct);
                  }   
                  else
#endif
#endif
                     if (optAct < ACTNSTATPRC)
                        MSGRET(msgCtlp, MFCCINVINFOEL);
                     else
                     {
                        /* reset database and structure pointers */ 
                        msgCtlp->melp1 += 1;  
                        if (*msgCtlp->melp1 == NULLP)
                        {
                           msgCtlp->melp1 = msgCtlp->smelp1;
                           msgCtlp->dup1 = cmsp1;
                           msgCtlp->firstPass = FALSE;
                        }
                        else 
                           mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                        continue;
                     }
               }
               else
               {
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkOptLenErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     if (optAct < ACTNSTATPRC)
                        RETVALUE(optAct);
                  }   
#endif
                  /* reset database and structure pointers */ 
                  msgCtlp->melp1 += 1;  
                  if (*msgCtlp->melp1 == NULLP)
                  {
                     msgCtlp->melp1 = msgCtlp->smelp1;
                     msgCtlp->dup1 = cmsp1;
                     msgCtlp->firstPass = FALSE;
                  }
                  else 
                     mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
                  continue;
               }
            }
            /* check element length */
            if ((msgCtlp->validate) && ((msgCtlp->elen < mep->minLen) 
               || (msgCtlp->elen > mep->maxLen))) 
            {
               if (mandElmt)
               {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                    if ((msgCtlp->swtch != 11) && (msgCtlp->swtch != 12))
                    {
                      mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVINFOEL);
                    }
                    else
                    {
                      mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                    }
                     RETVALUE(optAct);
                  }   
                  else
#endif
#endif
                     MSGRET(msgCtlp, MFCCINVINFOEL);
               }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
               else
                  if ((optAct = inChkOptElmErr(msgCtlp, mep->id)) != ROK)
                  {
                    if ((msgCtlp->swtch == 21) || (msgCtlp->swtch == 6)
                        || (msgCtlp->swtch == 17))
                      mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVINFOEL);
                    else
                      mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                    if (optAct < ACTNSTATPRC)
                      RETVALUE(optAct);

                    if ((msgCtlp->swtch == 21) || (msgCtlp->swtch == 6)
                        || (msgCtlp->swtch == 17) || (msgCtlp->swtch == 20))
                    {
                        msgCtlp->ee[(U8)msgCtlp->errCnt].mfCauseDgn.eh.pres
                           = PRSNT_NODEF;
                        optAct = ROK;
                    }                    
                  }
#endif
               /* reset database and structure pointers */ 
               msgCtlp->melp1 += 1;  
               if (*msgCtlp->melp1 == NULLP)
               {
                  msgCtlp->melp1 = msgCtlp->smelp1;
                  msgCtlp->dup1 = cmsp1;
                  msgCtlp->firstPass = FALSE;
               }
               else 
                  mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);

               if (sp == msgCtlp->melp1)
               {
                  RETVALUE(optAct);
               }

               msgCtlp->octIdx += msgCtlp->elen;
               msgCtlp->bitIdx += (U16 )(msgCtlp->elen << 3);
               continue;
            }
         }

         if ((etype == MET_SINGLE1) && (eid == MFME_SHIFT))
            msgCtlp->elen = 1;
         /* call token decode procedure */
         if ((ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp)) != MFROK)
         {
            if ((mandElmt) || 
               ((msgCtlp->cfgp->flags & MF_IGNORE) == 0))
               {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                    if ((msgCtlp->swtch == 19)
                        && (msgCtlp->msgType == 0x6e)
                        && (mep->id == 0x27))
                    {
                      mfInitErr(msgCtlp, (U8) mep->id, (U8)MFCCINVINFOEL);
                      RETVALUE(ACTNSTATPRC);
                    }
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) ret);
                     RETVALUE(optAct);
                  }
                  else
#endif
#endif
                     MSGRET(msgCtlp, ret);
               }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
            else
               if ((optAct = inChkOptElmErr(msgCtlp, mep->id)) != ROK)
               {
                 if ((msgCtlp->swtch == 19)
                        && (mep->id == 0x27))
                    {
                      mfInitErr(msgCtlp, (U8) mep->id, (U8)MFCCINVINFOEL);
                    }
                 else
                  mfInitErr(msgCtlp, (U8) mep->id, (U8) ret);
                  if (optAct < ACTNSTATPRC)
                     RETVALUE(optAct);
               }
#endif
            msgCtlp->errCnt = 0;
            mfBackOut = 0;
            msgCtlp->octIdx += msgCtlp->elen;
            msgCtlp->bitIdx += (U16 )(msgCtlp->elen << 3);
            msgCtlp->melp1 += 1;
            if (*msgCtlp->melp1 == NULLP)
            {
               msgCtlp->melp1 = msgCtlp->smelp1;
               msgCtlp->dup1 = cmsp1;
               msgCtlp->firstPass = FALSE;
            }
            continue;
         }
         else
            if (msgCtlp->elen > 0)
            {
               if ((mandElmt) || 
                   ((msgCtlp->cfgp->flags & MF_IGNORE) == 0))
               {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                  if(msgCtlp->cfgp->flags & FN_MF) 
                  {
                     /* do FN specific processing here */
                     fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                     RETVALUE(MFCCINFOELMSSG);
                  }
                  else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                  if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVINFOEL);
                     RETVALUE(optAct);
                  }
                  else
#endif
#endif
                     MSGRET(msgCtlp, MFCCINVINFOEL);
               }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
               else
                  if ((optAct = inChkOptElmErr(msgCtlp, mep->id)) != ROK)
                  {
                     mfInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVINFOEL);
                     if (optAct < ACTNSTATPRC)
                        RETVALUE(optAct);
                  }
#endif
               msgCtlp->errCnt = 0;
               mfBackOut = 0;
               msgCtlp->octIdx += msgCtlp->elen;
               msgCtlp->bitIdx += (U16 )(msgCtlp->elen << 3);
               msgCtlp->melp1 += 1;
               if (*msgCtlp->melp1 == NULLP)
               {
                  msgCtlp->melp1 = msgCtlp->smelp1;
                  msgCtlp->dup1 = cmsp1;
                  msgCtlp->firstPass = FALSE;
               }
               continue;
            }
            /* if there is a user function, execute it */
            else if (msgCtlp->mdbp->func)
            {
               if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
               {
                  if ((mandElmt) || 
                     ((msgCtlp->cfgp->flags & MF_IGNORE) == 0))
                  {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                     if(msgCtlp->cfgp->flags & FN_MF) 
                     {
                        /* do FN specific processing here */
                        fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                        RETVALUE(MFCCINFOELMSSG);
                     }
                     else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                     if ((optAct = inChkMandElmErr(msgCtlp, mep->id)) != ROK)
                     {
                        mfInitErr(msgCtlp, (U8) mep->id, (U8) ret);
                        RETVALUE(optAct);
                     }   
                     else
#endif
#endif
                        MSGRET(msgCtlp, ret);
                  }

                  if ((etype == MET_SINGLE1) && (eid == MFME_SHIFT))
                  {
                     /* reset database and structure pointers */
                     sp = msgCtlp->melp1;
                     msgCtlp->melp1 += 1;
                     msgCtlp->octIdx -= 1;
                     read = FALSE;
                     continue;
                  }
                  msgCtlp->octIdx += msgCtlp->elen;
                  msgCtlp->bitIdx += (U16 )(msgCtlp->elen << 3);
               }
               else ep->pres = PRSNT_NODEF;
            }
            else ep->pres = PRSNT_NODEF;
#ifndef V5X
            /* locking/non-locking shift, move to user defined function */
            if ((etype == MET_SINGLE1) && ((eid & 0x70) == MFME_SHIFT))
            {
               newShift = TRUE;
               tmpCodeSet = saveSet;
               mfCodeSet = (S16 )((c & 0x7) << 8);
               if (c & 0x8)
               {
                  mfShftLock = FALSE;
                  saveEp = ep;
               }
               else mfShftLock = TRUE;
               if ((mfShftLock) && (mfCodeSet <= tmpCodeSet) &&
                   ((msgCtlp->swtch != 9) && (msgCtlp->swtch != 10)))
                  /* will never reach here for AUS */
                  MSGRET(msgCtlp, MFCCINVINFOEL);
            }
#endif /* V5X */

            if (mandElmt)
               msgCtlp->acMandCnt++;

            /* if element break flag set, exit ok */
            if (mep->flagp[swtch] & EF_BREAK)
            {
               if (mep->flagp[swtch] & EF_REP)
                  msgCtlp->dup1 = cmsp1;
               else
               {
                  msgCtlp->melp1 += 1;  
                  if (*msgCtlp->melp1 == NULLP)
                  {
                     msgCtlp->melp1 = msgCtlp->smelp1;
                     msgCtlp->dup1 = cmsp1;
                  }
               }
               if (optAct < ACTNPRCESS)
                  RETVALUE(optAct);
               RETVALUE(MFROK);
            }
   
         /* reset database and structure pointers */
         sp = msgCtlp->melp1;
         msgCtlp->melp1 += 1;  
         if (*msgCtlp->melp1 == NULLP)
         {
            msgCtlp->melp1 = msgCtlp->smelp1;
            msgCtlp->dup1 = cmsp1;
            msgCtlp->firstPass = FALSE;
         }
      }
      else
      {   
         /* not found, exit or ignore if element id not found */
         if (meTwoSkp == FALSE)
         {
            /* check for ordered message elements */    
            if (msgCtlp->flags & MF_NET)
            {
               if (mep->flagp[swtch] & EF_UN)
               {
                  if ((mep->type == MET_VARIABLE) && 
                       (msgCtlp->cfgp->flags & MF_ORDERED) && 
                       (etype == MET_VARIABLE) && 
                       (mep->flagp[swtch] & EF_MAND) && 
                       (((mfCodeSet) && ((U16)(mfCodeSet | eid) > mep->id)) ||
                       ((!mfCodeSet) && (eid > (U8)(mep->id & 0xff)))))
                  {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                        if(msgCtlp->cfgp->flags & FN_MF) 
                        {
                           /* do FN specific processing here */
                           fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                           RETVALUE(MFCCINFOELMSSG);
                        }
                        else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                        if ((optAct = inChkMandElmErr(msgCtlp,mep->id)) != ROK)
                        {
                           mfInitErr(msgCtlp, (U8)mep->id, (U8)MFCCINFOELMSSG);
                           RETVALUE(optAct);
                        }   
                        else
#endif
#endif
                           MSGRET(msgCtlp, MFCCINFOELMSSG);
                  }
                  if ((mep->type == MET_VARIABLE) && 
                      (msgCtlp->cfgp->flags & MF_ORDERED) && 
                      (etype == MET_VARIABLE) && (((mfCodeSet) &&
                      ((U16)(mfCodeSet | eid) < mep->id)) ||
                      ((!mfCodeSet) && (eid < (U8)(mep->id & 0xff)))))
                  {
                     if (SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                                  ++msgCtlp->octIdx) != ROK)
                     {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                        if(msgCtlp->cfgp->flags & FN_MF) 
                        {
                           /* do FN specific processing here */
                           fnInitErr(msgCtlp, (U8) c, (U8) MFCCINVMSG);
                        }
                        else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                            mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#else
;
#endif
#endif
                        RETVALUE(ACTNSTATPRC);
                     }
                     msgCtlp->elen = PutLoByte (msgCtlp->elen, tmp_elen);
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
/* in036.31 */
                     if (msgCtlp->swtch == 14)
                     {
                        /***
                        if (!((U8) c & 0xf0))
                        {                        
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINFOELMSSG);
                           RETVALUE(ACTNSTATPRC);
                        }
                        ***/
                        if (inChkComprehension ((U8) c) == ROK)
                        {
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINFOELMSSG);
                           RETVALUE(ACTNSTATPRC);
                        }
                     }
/* in036.31 */
#endif
                     /* in006.31 */        
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN || MF_NV)
#ifdef FN
                     if(msgCtlp->cfgp->flags & FN_MF) 
                     {
                        /* do FN specific processing here */
                        fnInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
                     }
                     else
#endif
#if (MF_IN || MF_NV)
                     mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#else
;
#endif
#endif
                     optAct = ACTNSTATPRC;
                     msgCtlp->octIdx += (U8) (msgCtlp->elen + 1);
                     msgCtlp->bitIdx += (U16 )((msgCtlp->elen + 1) << 3);
                     read = TRUE;
                     msgCtlp->dup1 = ep;
                     if (mep->flagp[swtch] & EF_MAND)
                     {
                        if (msgCtlp->exMandCnt)
                           msgCtlp->exMandCnt--;
                     }
                    continue;
                  }
                  else
                     if (mep->flagp[swtch] & EF_MAND)
                     {
                        if (msgCtlp->exMandCnt)
                           msgCtlp->exMandCnt--;
                     }
               }
            }
            else if (msgCtlp->flags & MF_USR)
            {
               if (mep->flagp[swtch] & EF_NU)
               {
                  if ((mep->type == MET_VARIABLE) && 
                        (msgCtlp->cfgp->flags & MF_ORDERED) && 
                         (etype == MET_VARIABLE) && 
                         (mep->flagp[swtch] & EF_MAND) && 
                         (((mfCodeSet) && ((U16) (mfCodeSet | eid) > mep->id))
                         || ((!mfCodeSet) && (eid > (U8)(mep->id & 0xff)))))
                  {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                        if(msgCtlp->cfgp->flags & FN_MF) 
                        {
                           /* do FN specific processing here */
                           fnInitErr(msgCtlp, (U8) mep->id, (U8) MFCCINVMSG);
                           RETVALUE(MFCCINFOELMSSG);
                        }
                        else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                        if ((optAct = inChkMandElmErr(msgCtlp,mep->id)) != ROK)
                        {
                           mfInitErr(msgCtlp, (U8)mep->id, (U8)MFCCINFOELMSSG);
                           RETVALUE(optAct);
                        }   
                        else
#endif
#endif
                           MSGRET(msgCtlp, MFCCINFOELMSSG); 
                  }
                  if ((mep->type == MET_VARIABLE) && 
                       (msgCtlp->cfgp->flags & MF_ORDERED) && 
                       (etype == MET_VARIABLE) &&(((mfCodeSet) &&
                       ((U16)(mfCodeSet | eid) < mep->id)) || 
                       ((!mfCodeSet) && (eid < (U8)(mep->id & 0xff)))))
                  {
                     if (SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                                  ++msgCtlp->octIdx) != ROK)
                     {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN)
#ifdef FN
                        if(msgCtlp->cfgp->flags & FN_MF) 
                        {
                           /* do FN specific processing here */
                           fnInitErr(msgCtlp, (U8) c, (U8) MFCCINVMSG);
                        }
                        else
#endif
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
                          if (msgCtlp->elen == 0)
                          {
                            mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
                          }
                          else
                            mfInitErr(msgCtlp, (U8) c, (U8) MFCCINVMSG);
#else
;
#endif
#endif
                        RETVALUE(ACTNSTATPRC);
                     }
                     msgCtlp->elen = PutLoByte (msgCtlp->elen, tmp_elen);
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
/* in036.31 */
                     if (msgCtlp->swtch == 14)
                     {
                        /****
                        if (!((U8) c & 0xf0))
                        {                        
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINFOELMSSG);
                           RETVALUE(ACTNSTATPRC);
                        }
                        if (inChkComprehension ((U8) c) == ROK)
                        {
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINFOELMSSG);
                           RETVALUE(ACTNSTATPRC);
                        }                       ****/

                     }
/* in036.31 */
                     /* in006.31 */        
                     mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#endif
                        

                     optAct = ACTNSTATPRC;
                     msgCtlp->octIdx += (U8) (msgCtlp->elen + 1);
                     msgCtlp->bitIdx += (U16 )((msgCtlp->elen + 1) << 3);
                     read = TRUE;
                     msgCtlp->dup1 = ep;
                     if (mep->flagp[swtch] & EF_MAND)
                     {
                        if (msgCtlp->exMandCnt)
                           msgCtlp->exMandCnt--;
                     }
                     continue;
                  }
                  else
                     if (mep->flagp[swtch] & EF_MAND)
                     {
                        if (msgCtlp->exMandCnt)
                           msgCtlp->exMandCnt--;
                     }
#ifdef QN /*old is IN, xqc for avoid conflict with winsock2.h*/
#ifdef INTR6
                  if ((msgCtlp->swtch == 9) || (msgCtlp->swtch == 10))
                     if ((mep->type == MET_SINGLE1) && 
                         (mep->flagp[swtch] & EF_MAND) &&
                         (msgCtlp->cfgp->flags & MF_ORDERED) && 
                         (etype == MET_VARIABLE))
                     {
                        if (SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                                 ++msgCtlp->octIdx) != ROK)
                        {
                           /*in006.31 */        
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINVMSG);
                           RETVALUE(ACTNSTATPRC);
                        }
                        msgCtlp->elen = PutLoByte (msgCtlp->elen , tmp_elen);
                        

                        if (!msgCtlp->elen)
                           msgCtlp->elen = 1;


                        msgCtlp->octIdx += (U8) (msgCtlp->elen + 1);
                        msgCtlp->bitIdx += (U16 )((msgCtlp->elen + 1) << 3);
                        read = TRUE;
                        msgCtlp->dup1 = ep;
                        if (mep->flagp[swtch] & EF_MAND)
                        {
                           if (msgCtlp->exMandCnt)
                              msgCtlp->exMandCnt--;
                        }
                        continue;
                     }
#endif
#endif
               }
            }
            if ((newShift) && (mfShftLock == FALSE) && (tmpCodeSet))
            {
               mfCodeSet = tmpCodeSet;
               newShift = FALSE;
               saveEp->pres = FALSE;
               read = TRUE;
               msgCtlp->octIdx -= 1;
               msgCtlp->bitIdx -= 8;
            }

            /* reset database and structure pointers */
            msgCtlp->melp1 += 1;  
            if (*msgCtlp->melp1 == NULLP)
            {
               msgCtlp->melp1 = msgCtlp->smelp1;
               msgCtlp->dup1 = cmsp1;
               msgCtlp->firstPass = FALSE;
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN || MF_NV)
#ifdef FN
               if(msgCtlp->cfgp->flags & FN_MF) 
               {
                  /* do FN specific processing here */
                  fnInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
               }
               else
#endif
#if (MF_IN || MF_NV)
               /* in006.31 */        
               mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#else
;
#endif
#endif
               optAct = ACTNSTATPRC;
            }

            else if (etype == MET_SINGLE2)
            {   
               read = TRUE;
               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;
               msgCtlp->melp1 -= 1;  
               msgCtlp->dup1 = ep;
               if (mep->flagp[swtch] & EF_MAND)
               {
                  if (msgCtlp->exMandCnt)
                     msgCtlp->exMandCnt--;
               }
            }
            else
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);

            if (!((etype == MET_SINGLE2) && (mep->flagp[swtch] & EF_MAND)))
               if (sp == msgCtlp->melp1)
               {
                  if (msgCtlp->cfgp->flags & MF_IGNORE)
                  {
                     read = TRUE;
                     msgCtlp->octIdx += 1;
                     msgCtlp->bitIdx += 8;
                     if (etype == MET_VARIABLE)
                     {
                        if (SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                                     msgCtlp->octIdx) != ROK)
                        {
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN || MF_NV)
#ifdef FN
                           if(msgCtlp->cfgp->flags & FN_MF) 
                           {
                              /* do FN specific processing here */
                              fnInitErr(msgCtlp, (U8) c, 
                                        (U8) MFCCINVMSG);
                           }
                           else
#endif
#if (MF_IN || MF_NV)
                           /* in006.31 */        
                           mfInitErr(msgCtlp, (U8) c, (U8) MFCCINVMSG);
#else
;
#endif
#endif
                           RETVALUE(ACTNSTATPRC);
                        }
                        msgCtlp->elen = PutLoByte (msgCtlp->elen, tmp_elen);
                        msgCtlp->octIdx += (U8) (msgCtlp->elen + 1);
                        msgCtlp->bitIdx += (U16 )((msgCtlp->elen + 1) << 3);
                     }  
/* Replaced for FN - #ifdef IN */
#if (MF_IN || MF_FN || MF_NV )
#ifdef FN
                     if(msgCtlp->cfgp->flags & FN_MF) 
                     {
                        /* do FN specific processing here */
                        fnInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
                     }
                     else
#endif
#if (MF_IN || MF_NV)
                     /* in006.31 */        
                     mfInitErr(msgCtlp, (U8) c, (U8) MFCCNOINFOEL);
#else
;
#endif
#endif
                     optAct = ACTNSTATPRC;
                  }
                  else 
                     /* will not reach here if configured with MF_IGNORE flag*/
                     MSGRET(msgCtlp, MFCCNOINFOEL);
               }
         }
      }
   }
} /* end of mfDecElmts */

  
/*
*
*       Fun:   mfEncElmts
*
*       Desc:  message function - encode elements
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncElmts
(
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncElmts(msgCtlp)
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   U16 elenIdx;
   CONSTANT MsgElmtDef *mep;
   ElmtHdr *ep;
   ElmtHdr *cmsp1;
   U8 etype, eid;
   U16 tmpCodeSet;
   Swtch swtch;
   Data d;
   
   TRC2(mfEncElmts);


   /* initialize control variables */
   elenIdx = 0;
   swtch = msgCtlp->swtch;
   mfCodeSet  = 0;
   mfShftLock = FALSE;
   cmsp1 = msgCtlp->dup1;

   /* loop thru message elements and encode to done or error */
   while (*msgCtlp->melp1 != NULLP)
   {
      mep = *msgCtlp->melp1;
#if (ERRCLASS & ERRCLS_DEBUG)
      if (!mep->flagp)
         MSGRET(msgCtlp, MFDEBUGERR);
#endif

      msgCtlp->mep = mep;
      ep = (ElmtHdr *) msgCtlp->dup1;
      fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
      eid = (U8) mep->id;
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = eid;
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
      if (mep->flagp[swtch] & EF_NA)
         ep->pres = NOTPRSNT;

      /* check if message element present */    
      if (ep->pres == NOTPRSNT)
      {   
         if (mep->flagp[swtch] & EF_MAND)
         {
            if (msgCtlp->flags & MF_NET)
            {
               if (mep->flagp[swtch] & EF_NU)
                  MSGRET(msgCtlp, MFCCINFOELMSSG);
            }
            else if (msgCtlp->flags & MF_USR)
            {
               if (mep->flagp[swtch] & EF_UN)
                  MSGRET(msgCtlp, MFCCINFOELMSSG);
            }
         }
         if ((mep->type == MET_FIXED) || (mep->type == MET_FIXED_PTR))
            MSGRET(msgCtlp, MFCCINFOELMSSG);
         else
         {
            /* not present, skip over */
            mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
            msgCtlp->melp1 += 1;  
            continue;
         }
      }
      else 
        if ((ep->pres != PRSNT_NODEF) && (ep->pres != PRSNT_DEF))
        {
#if (ERRCLASS & ERRCLS_DEBUG)
           MSGRET(msgCtlp, MFDEBUGERR);
#else
           /* not present, skip over */
           mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
           msgCtlp->melp1 += 1;  
           continue;
#endif
        }

      /* check for fixed type elements */
      if ((mep->type == MET_FIXED) || (mep->type == MET_FIXED_REM)
         || (mep->type == MET_FIXED_PTR))
      {
         /* call token encode procedure */
         msgCtlp->elen = 0;
         if ((ret = mfEncTkns(msgCtlp->mp, mep->telp, msgCtlp)) 
            != MFROK) RETVALUE(ret);
         if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
            MSGRET(msgCtlp, MFCCINVINFOEL);
         msgCtlp->melp1 += 1;  
         continue;
      }

      /* if there is a user function, execute it */
      if (msgCtlp->mdbp->func)
         if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
         {
            if ((mep->flagp[swtch] & EF_MAND) || 
               ((msgCtlp->cfgp->flags & MF_IGNORE) == 0))
               MSGRET(msgCtlp, ret);
            ep->pres = NOTPRSNT;
            mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
            msgCtlp->melp1 += 1;  
            continue;
         }

      swtch = msgCtlp->swtch;

      /* check element type */
      etype = mep->type;
      if (mfCodeSet != (S16) (mep->id >> 8))
      {
         /* locking/non-locking shift */
         tmpCodeSet = mfCodeSet;
         mfCodeSet = (U8) (mep->id >> 8);
         if (mep->flagp[swtch] & EF_NONLOCK)
         {
            mfShftLock = FALSE;
            mfCodeSet = tmpCodeSet;
         }
         else mfShftLock = TRUE;
      }

      if (etype == MET_SINGLE1)
      {
         mfOctet = (U8)(eid | 0x80);
      }
      else if (etype == MET_SINGLE2)
      {
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg((U8)(eid | 0x80), msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }
         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         msgCtlp->melp1 += 1;  
         continue;
      }
      else
      {
         mfOctet = 0;
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(eid, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }
         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
         elenIdx = msgCtlp->octIdx + msgCtlp->baseIdx;
         if (msgCtlp->encode)
         {
            ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }
         msgCtlp->octIdx += 1;
         msgCtlp->bitIdx += 8;
      }

      /* call token encode procedure */
      msgCtlp->elen = 0;
      ret = mfEncTkns(msgCtlp->mp, mep->telp, msgCtlp);

      if (ret != MFROK)
      {
         if ((ret == MFRESFAILURE) || (ret == MFDEBUGERR))
            RETVALUE(ret);
         if ((mep->flagp[swtch] & EF_MAND) && 
            ((msgCtlp->cfgp->flags & MF_IGNORE) != 0))
            RETVALUE(ret);
         msgCtlp->errCnt = 0;
         mfBackOut = 0;
         ep->pres = NOTPRSNT;
         msgCtlp->dup1 = ep;
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
         mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
         msgCtlp->melp1 += 1;  
         if (msgCtlp->encode == TRUE)
         {
           /* Remove the additional octets only if the function
              is called in context of ENCODE, not in context of
              CHK DU.
           */
           msgCtlp->elen+=2;
           while (msgCtlp->elen)
           {
             ret = SRemPstMsg(&d, msgCtlp->mp);
             msgCtlp->elen--;
             msgCtlp->octIdx -= 1;
             msgCtlp->bitIdx -= 8;
           }
         }
         continue;
      }

      if (mep->type == MET_VARIABLE)
      {
         if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
            MSGRET(msgCtlp, MFCCINVINFOEL);
         if (msgCtlp->encode)
         {
            ret = SRepMsg((Data) msgCtlp->elen, msgCtlp->mp, (MsgLen) elenIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
         }
         /* if element break flag set, exit ok */
         if (mep->flagp[swtch] & EF_BREAK)
         {
            if (mep->flagp[swtch] & EF_REP)
               msgCtlp->dup1 = cmsp1;
            else msgCtlp->melp1 += 1;  
            RETVALUE(MFROK);
         }
      }
      msgCtlp->melp1 += 1;  
   }
   RETVALUE(MFROK);
} /* end of mfEncElmts */

  
/*
*
*       Fun:   mfInitSdu
*
*       Desc:  message function - initialize data unit
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize a sdu structure
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInitSdu
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfInitSdu(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */
   CONSTANT MsgDef *allPduDefs;
   CONSTANT MsgDef *allSduDefs; 
   U8 numPdus;            /* number of pdu messages in database */

   TRC2(mfInitSdu)
   /* init message du structure */
   allPduDefs = msgCtlp->cfgp->pduDefs;
   allSduDefs = msgCtlp->cfgp->sduDefs;
   numPdus = msgCtlp->cfgp->numPdus;

   if (!msgCtlp->dup1)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->melp1 = NULLP;
   }
   else
   {
      if (msgCtlp->smsgIdx < numPdus)
      {
         msgCtlp->mdbp = &allPduDefs[msgCtlp->smsgIdx];
         msgCtlp->melp1 = allPduDefs[msgCtlp->smsgIdx].melp;
      }
      else
      {
         msgCtlp->mdbp = &allSduDefs[msgCtlp->smsgIdx - numPdus];
         msgCtlp->melp1 = allSduDefs[msgCtlp->smsgIdx - numPdus].melp;
      }
   }
   msgCtlp->melp2 = allSduDefs[msgCtlp->dmsgIdx - numPdus].melp;
   msgCtlp->decode = FALSE; 
   ret = mfInitElmts(msgCtlp);
   RETVALUE(ret);
} /* end of mfInitSdu */

  
/*
*
*       Fun:   mfInitPdu
*
*       Desc:  message function - initialize data unit
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to initialize a pdu structure.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfInitPdu
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfInitPdu(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */
   CONSTANT MsgDef *allPduDefs;
   CONSTANT MsgDef *allSduDefs;
   U8 numPdus;            /* number of pdu messages in database */

   TRC2(mfInitPdu)
   /* init message du structure */
   allPduDefs = msgCtlp->cfgp->pduDefs;
   allSduDefs = msgCtlp->cfgp->sduDefs;
   numPdus = msgCtlp->cfgp->numPdus;

   if (!msgCtlp->dup1)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->melp1 = NULLP;
   }
   else
   {
      if (msgCtlp->smsgIdx < msgCtlp->cfgp->numPdus)
      {
         msgCtlp->mdbp = &allPduDefs[msgCtlp->smsgIdx];
         msgCtlp->melp1 = allPduDefs[msgCtlp->smsgIdx].melp;
      }
      else
      {
         msgCtlp->mdbp = &allSduDefs[msgCtlp->smsgIdx - numPdus];
         msgCtlp->melp1 = allSduDefs[msgCtlp->smsgIdx - numPdus].melp;
      }
   }
   msgCtlp->melp2 = allPduDefs[msgCtlp->dmsgIdx].melp;
   msgCtlp->decode = FALSE; 
   ret = mfInitElmts(msgCtlp);
   RETVALUE(ret);
} /* end of mfInitPdu */

  
/*
*
*       Fun:   mfDecPduHdr
*
*       Desc:  message function - decode pdu header
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to decode a pdu header from a Buffer structure.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfDecPduHdr
(
MfMsgCtl *msgCtlp           /* pointer to message control structure */
)
#else
PUBLIC S16 mfDecPduHdr(msgCtlp)
MfMsgCtl *msgCtlp;          /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */

   TRC2(mfDecPduHdr)
   /* decode message header */
   mfReinitMsgCtl(msgCtlp);
   SFndLenMsg(msgCtlp->mp, &msgCtlp->baseIdx);

   msgCtlp->dir = MF_DECODE;

#ifdef SS7
   if (msgCtlp->cfgp->flags & MF_ISUP)
       ret = mfDecSS7Elmts(msgCtlp);
   else if (msgCtlp->cfgp->flags & MF_TUP)
       ret = mfDecSS7Elmts(msgCtlp);
   else if (msgCtlp->cfgp->flags & MF_SCCP)
       ret = mfDecSS7Elmts(msgCtlp);
   else
#endif /* SS7 */
      ret = mfDecElmts(msgCtlp);

   msgCtlp->melp1 = msgCtlp->smelp1;
   RETVALUE(ret);
} /* end of mfDecPduHdr */

  
/*
*
*       Fun:   mfDecPdu
*
*       Desc:  message function - decode pdu body
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to decode the rest of a pdu after header decoded.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfDecPdu
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfDecPdu(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(mfDecPdu)
   /* decode message body */
   msgCtlp->smelp1 = msgCtlp->melp1;
   msgCtlp->dir = MF_DECODE;
#ifdef SS7
   if (msgCtlp->cfgp->flags & MF_ISUP)
   {
       mfInitSS7Elmts(msgCtlp);
       ret = mfDecSS7Elmts(msgCtlp);
   }
#ifdef TP
   else if (msgCtlp->cfgp->flags & MF_TUP)
   {
       mfInitSS7Elmts(msgCtlp);
       ret = mfDecSS7Elmts(msgCtlp);
   }
#endif /* TP */
#ifdef SP
   else if (msgCtlp->cfgp->flags & MF_SCCP)
   {
       mfInitSS7Elmts(msgCtlp);
       ret = mfDecSS7Elmts(msgCtlp);
   }
#endif /* SP */
   else
#endif /* SS7 */
       ret = mfDecElmts(msgCtlp);

   RETVALUE(ret);
} /* end of mfDecPdu */

  
/*
*
*       Fun:   mfEncPduHdr
*
*       Desc:  message function - encode pdu header
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode a pdu from a message structure.
*
*       File:  mf.c
*
*/

#ifdef ANSI
PUBLIC S16 mfEncPduHdr
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfEncPduHdr(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(mfEncPduHdr)
   /* encode message header */
   mfReinitMsgCtl(msgCtlp);
   mfOctet = 0;
   SFndLenMsg(msgCtlp->mp, &msgCtlp->baseIdx);

   msgCtlp->dir = MF_ENCODE;

#ifdef SS7
   if (msgCtlp->cfgp->flags & MF_ISUP)
       ret = mfEncSS7Elmts(msgCtlp);
#ifdef TP
   else if (msgCtlp->cfgp->flags & MF_TUP)
       ret = mfEncSS7Elmts(msgCtlp);
#endif /* TP */
#ifdef SP
   else if (msgCtlp->cfgp->flags & MF_SCCP)
       ret = mfEncSS7Elmts(msgCtlp);
#endif /* SP */
   else
#endif /* SS7 */
       ret = mfEncElmts(msgCtlp);

   msgCtlp->melp1 = msgCtlp->smelp1;
   RETVALUE(ret);
} /* end of mfEncPduHdr */
 
  
/*
*
*       Fun:   mfEncPdu
*
*       Desc:  message function - encode pdu body
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode a pdu from a message structure.
*
*       File:  mf.c
*
*/

#ifdef ANSI
PUBLIC S16 mfEncPdu
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfEncPdu(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */

   TRC2(mfEncPdu)
   /* encode message body */
   msgCtlp->smelp1 = msgCtlp->melp1;
   msgCtlp->decode = FALSE; 
   msgCtlp->dir = MF_ENCODE;
#ifdef SS7
   if (msgCtlp->cfgp->flags & MF_ISUP)
      ret = mfEncSS7Elmts(msgCtlp);
#ifdef TP
   else if (msgCtlp->cfgp->flags & MF_TUP)
      ret = mfEncSS7Elmts(msgCtlp);
#endif /* TP */
#ifdef SP
   else if (msgCtlp->cfgp->flags & MF_SCCP)
      ret = mfEncSS7Elmts(msgCtlp);
#endif /* SP */
   else
#endif /* SS7 */
      ret = mfEncElmts(msgCtlp);

   RETVALUE(ret);
} /* end of mfEncPdu */
 
  
/*
*
*       Fun:   mfChkDu
*
*       Desc:  message function - check data unit
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to validate a pdu/sdu structure.
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfChkDu
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PUBLIC S16 mfChkDu(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;               /* return code */
   Bool encode;
   CONSTANT MsgDef *allPduDefs;
   CONSTANT MsgDef *allSduDefs;
   U8 numPdus;            /* number of pdu messages in database */

   TRC2(mfChkDu)
   /* encode message header */
   mfReinitMsgCtl(msgCtlp);
   allPduDefs = msgCtlp->cfgp->pduDefs;
   allSduDefs = msgCtlp->cfgp->sduDefs;
   numPdus = msgCtlp->cfgp->numPdus;

   if (!msgCtlp->dup1)
   {
      msgCtlp->mdbp = NULLP;
      msgCtlp->melp1 = NULLP;
   }
   else
   {
      if (msgCtlp->smsgIdx < msgCtlp->cfgp->numPdus)
      {
         msgCtlp->mdbp = &allPduDefs[msgCtlp->smsgIdx];
         msgCtlp->melp1 = allPduDefs[msgCtlp->smsgIdx].melp;
      }
      else
      {
         msgCtlp->mdbp = &allSduDefs[msgCtlp->smsgIdx - numPdus];
         msgCtlp->melp1 = allSduDefs[msgCtlp->smsgIdx - numPdus].melp;
      }
   }
   msgCtlp->melp2 = NULLP;
   encode = msgCtlp->encode;
   msgCtlp->decode = FALSE; 
   msgCtlp->encode = FALSE; 
   msgCtlp->validate = TRUE; 
   msgCtlp->dir = MF_ENCODE;
   ret = mfEncElmts(msgCtlp);
   msgCtlp->encode = encode;
   RETVALUE(ret);
} /* end of mfChkDu */


  
/*
*
*       Fun:   mfBcopy
*
*       Desc:  copy a block from src to dest 
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/

#ifdef ANSI
PRIVATE S16 mfBcopy
(
REG1 U8 *src,               /* source */
REG2 U8 *dst,               /* destination */
REG3 U32 count              /* count */
)
#else
PRIVATE S16 mfBcopy(src, dst, count)
REG1 U8 *src;               /* source */
REG2 U8 *dst;               /* destination */
REG3 U32 count;             /* count */
#endif
{
   REG4 U8 rem;

   TRC2(mfBcopy)

   /* do 32 bit copies if src and dst are aligned on 4-byte boundarys */
   if ((((PTR) src & 3) == 0) && (((PTR) dst & 3) == 0))
   {
      rem = (U8)(count & 3);
      count >>= 2;
      while (count--)
      {
         *(U32 *) (dst) = *(U32 *) (src);
         src += 4; dst += 4;
      }
      while (rem--)
         *dst++ = *src++;
   }

   /* do 16 bit copies if src and dst are aligned on 2-byte boundarys */
   else if ((((PTR) src & 1) == 0) && (((PTR) dst & 1) == 0))
   {
      rem = (U8)(count & 1);
      count >>= 1;
      while (count--)
      {
         *(U16 *) (dst) = *(U16 *) (src);
         src += 2; dst += 2;
      }
      if (rem)
         *dst++ = *src++;
   }

   /* else just do 8 bit copies */
   else while (count--)
      *dst++ = *src++;

   RETVALUE(ROK);
} /* end of mfBcopy */
 

/*
*
*       Fun:   mfStrlen
*
*       Desc:  Search for length of a null terminated string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/

#ifdef ANSI
PRIVATE U32 mfStrlen
(
REG1 U8 *srcp               /* source pointer */
)
#else
PRIVATE U32 mfStrlen(srcp)
REG1 U8 *srcp;              /* source pointer */
#endif
{
   REG2 U8 *endp;           /* end pointer */

   TRC2(mfStrlen)

   endp = srcp;
   while (*endp++ != 0);
   RETVALUE((endp - srcp) - 1);
} /* end of mfStrlen */

#ifdef DBG4

/*
*
*       Fun:   mfPrntErr
*
*       Desc:  print decode or encode error
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/

#ifdef ANSI
PUBLIC S16 mfPrntErr
(
MfMsgCtl *m                 /* pointer to message control structure */
)
#else
PUBLIC S16 mfPrntErr(m)
MfMsgCtl *m;                /* pointer to message control structure */
#endif
{
   S16 i;                   /* counter */
   Txt prntBuf[PRNTSZE];    /* print buffer */

   TRC2(mfPrntErr)
   sprintf(prntBuf,"\nmfPrntErr: errCnt  0x%02x,   mandCnt:  0x%02x\n",
      m->errCnt,m->acMandCnt);
   SPrint(prntBuf);
   sprintf(prntBuf,"mfPrntErr: msgType 0x%02x,   msgIdx:   0x%02x\n",
      m->msgType,m->msgIdx);
   SPrint(prntBuf);
   sprintf(prntBuf,"mfPrntErr: octIdx: 0x%02x\n", m->octIdx);
   SPrint(prntBuf);
   /* print entire error structure array */
   for (i = 0; i < MF_MAX_ERRORS; i++)
   {
      sprintf(prntBuf,"mfPrntErr: elmtId: 0x%02x,   elmtIdx:  0x%02x\n",
         m->ee[i].elmtId, m->ee[i].elmtIdx);
      SPrint(prntBuf);
      sprintf(prntBuf,"mfPrntErr: tknId:    ??,   tknIdx:   0x%02x\n", 
         m->ee[i].tknIdx);
      SPrint(prntBuf);
      sprintf(prntBuf,"mfPrntErr: mfCauseDgn.eh.pres:       0x%02x\n", 
         m->ee[i].mfCauseDgn.eh.pres);
      SPrint(prntBuf);
      if (m->ee[i].mfCauseDgn.eh.pres)
      {
         sprintf(prntBuf,"mfPrntErr: mfCauseDgn.causeVal.pres: 0x%02x\n", 
            m->ee[i].mfCauseDgn.causeVal.pres);
         SPrint(prntBuf);
         if (m->ee[i].mfCauseDgn.causeVal.pres)
         {
            sprintf(prntBuf,"mfPrntErr: mfCauseDgn.causeVal.val:  0x%02x\n", 
               m->ee[i].mfCauseDgn.causeVal.val);
            SPrint(prntBuf);
         }
         sprintf(prntBuf,"mfPrntErr: mfCauseDgn.dgnVal.pres:   0x%02x\n", 
            m->ee[i].mfCauseDgn.dgnVal.pres);
         SPrint(prntBuf);
         if (m->ee[i].mfCauseDgn.dgnVal.pres)
         {
            sprintf(prntBuf,"mfPrntErr: mfCauseDgn.dgnVal.len:    0x%02x\n", 
               m->ee[i].mfCauseDgn.dgnVal.len);
            SPrint(prntBuf);
            sprintf(prntBuf,"mfPrntErr: mfCauseDgn.dgnVal.val[0]: 0x%02x\n", 
               m->ee[i].mfCauseDgn.dgnVal.val[0]);
            SPrint(prntBuf);
         }
      }
   }
   sprintf(prntBuf,"\n");
   SPrint(prntBuf);

   RETVALUE(MFROK);
} /* end of mfPrntErr */
#endif

#ifdef SS7

#define VALIDATE(mc) if (mc->validate && (mc->acMandCnt < mc->exMandCnt)) \
        MSGRET(mc, MFCCINVINFOEL)


/*
*
*       Fun:   mfDecSS7Elmts
*
*       Desc:  message function - decode elements for ISUP
*
*       Ret:   MFROK      - ok
*
*       Notes: mfDecSS7Elmts is called instead of mfDecElmts when
*             we are dealing with SS7 message elements. These two routines 
*             can not be integrated gracefully because some of the parameters
*             ids used for SS7 have the 8th bit set which makes them
*             indistinguishable from MET_SINGLE1, or MET_SINGLE2
*             parameters used in ISDN.
*            
*       File:  mf.c
*
*/

#ifdef ANSI
PRIVATE S16 mfDecSS7Elmts
(
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecSS7Elmts(msgCtlp)
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
    S16 ret;                /* return value */
    Swtch swtch;            /* Protocol Standard switch */
    CONSTANT MsgElmtDef *mep;   /* pointer to message element */
    ElmtHdr *ehp;           /* pointer to element header */
    ElmtHdr *fehp;          /* pointer to first element header */
    Data c;                 /* one octet of data */
#ifdef SI
    Data d;                 /* Temporary octet of data */
    MsgLen uLen;             /* counter */
#endif /* SI */

    MsgLen mlen;            /* message length */
    Bool opFlag;            /* optional parameter flag */
    U16 MFPSize;
    Bool fxdPres;

    TRC2(mfDecSS7Elmts)

    /* msgCtlp->melp1 = message element defintion list (db)
     * msgCtlp->smelp1 = first message element defintion (db)
     * msgCtlp->dup1 = current element header tokens (storage/destination)
     * fehp = first element header (storage/destination)
     * ehp = current element header.
     * mep = current message element defintion.
     */

    /* RG: should remove this check to catch unrecognized elements; in that 
     * case, some logic will need to be changed to deal with null mep
     */
    /* make sure we have something to do */
    if (*msgCtlp->melp1 == NULLP)
      RETVALUE(MFROK);

    /* Intialize */

    /* Set the switch */
    swtch = msgCtlp->swtch;

    /* set optional parameter flag to false */
    opFlag = FALSE;

    /* set fehp to first element storage location */
    fehp = msgCtlp->dup1;

    MFPSize = 0;
    fxdPres = FALSE;

    /* set mep to first message element defintion */

    /* mlen is the length of the message in octets */

   SFndLenMsg(msgCtlp->mp, &mlen);

    mep = *msgCtlp->melp1;
    ehp = msgCtlp->dup1;

    /* we loop continuously, however, there is one iteration
     * per message element
     */
    while (TRUE)      
    {
      /* Check if this element is applicable */
      if ( mep->flagp[swtch] & EF_NA )
      {
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
         mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);
         msgCtlp->melp1++;
         mep = *msgCtlp->melp1;
         ehp = msgCtlp->dup1;
         if (mep == (MsgElmtDef *)NULLP)
            /* nothing to decode */
            RETVALUE(MFROK);
         continue;
      }

       /* First check the database defintions */
       if (mep->flagp[swtch] & EF_MAND)
          msgCtlp->exMandCnt++;

       /* if this element is mandatory, increment expected mandatory count */
       switch(mep->type)
       {
          case MET_OPT:                /* TUP */
          {
#ifdef TP
             U32 offset;
#endif /* TP */

             /* ehp points to the element header (storage) */ 
             ehp = msgCtlp->dup1;

             /* dup1 now points to the tokens */
             fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* set the length */
             msgCtlp->elen = mep->maxLen;

#ifdef TP
             /* check indicators */
             offset = msgCtlp->tupInfo.decIdx;

             if (!(msgCtlp->tupInfo.optInds & (0x01 << offset)))
             {
                /* skip the tokens */
                mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);

                /* increment message element list */
                msgCtlp->melp1++;

                /* Check that it's valid */
                if (*msgCtlp->melp1 == NULLP)
                {
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* prepare for next iteration */
                msgCtlp->tupInfo.decIdx++;
                mep = *msgCtlp->melp1;
                break;
             }
#endif /* TP */

             /* decode the tokens */
             if ((ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp)) != MFROK)
             { 
                /* decode failed */

                /* If this element is mandatory, return with error code */
                if (mep->flagp[swtch] & EF_MAND)
                    MSGRET(msgCtlp, MFCCINVINFOEL);

                /* increment message element list */
                msgCtlp->melp1++;

                /* Check that it's valid */
                if (*msgCtlp->melp1 == NULLP)
                {
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                break;
             }

             /* decode succeeded */

             /* check the length */
             if (!(mep->flagp[swtch] & EF_VARLEN))
                if (msgCtlp->elen > 0)
                   MSGRET(msgCtlp, MFCCINVINFOEL);
                 
             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* We don't mark the * "End of Optional Parameters" (id == 0) */
             ehp->pres = PRSNT_NODEF;

             /* increment actual mandatory count */
             if (mep->flagp[swtch] & EF_MAND)
                msgCtlp->acMandCnt++;
 
             /* increment message element list */
             msgCtlp->melp1++;

             /*  Is next available? */
             if (*msgCtlp->melp1 == NULLP)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* If mlen == msgCtlp->elen, nothing left to read */
             if (mlen == (MsgLen)msgCtlp->octIdx)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* prepare for next iteration */
#ifdef TP
             msgCtlp->tupInfo.decIdx++;
#endif /* TP */
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             break;
          } 
          case MET_FIXED:
          {
             /* ehp points to the element header (storage) */ 
             ehp = msgCtlp->dup1;

             /* dup1 now points to the tokens */
             fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* set the length */
             msgCtlp->elen = mep->maxLen;

             /* decode the tokens */
             if ((ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp)) != MFROK)
             { 
                /* decode failed */

                /* If this element is mandatory, return with error code */
                if (mep->flagp[swtch] & EF_MAND)
                    MSGRET(msgCtlp, MFCCINVINFOEL);

                /* increment message element list */
                msgCtlp->melp1++;

                /* check if we have reached the end of list */
                if (*msgCtlp->melp1 == NULLP)
                {
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                break;
             }

             /* decode succeeded */

             /* check the length */
             if (!(mep->flagp[swtch] & EF_VARLEN))
                if (msgCtlp->elen > 0)
                   MSGRET(msgCtlp, MFCCINVINFOEL);
                 
             /* call user function, if available */
             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* We don't mark the * "End of Optional Parameters" (id == 0) */
             ehp->pres = PRSNT_NODEF;

             /* increment actual mandatory count */
             if (mep->flagp[swtch] & EF_MAND)
                msgCtlp->acMandCnt++;
 
             /* increment message element list pointer */
             msgCtlp->melp1++;

             /* check if we have reached the end of list */
             if (*msgCtlp->melp1 == NULLP)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* check if we have reached the end of the buffer */
             if (mlen == (MsgLen)msgCtlp->octIdx)
             {
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* prepare for next iteration */
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             break;
          } 
          case MET_VARIABLE:            
          {
             CONSTANT MsgElmtDef *hold_mep; /* place holder message element */
             ElmtHdr *hold_ehp;          /* place holder element header */
             Bool hold_flag;             /* flag; are we holding? */
             U8 tmp_elen = 0;

             /* mf_c_004.main_71 - addition - Initialization of Local 
              * Variables 
              */   
             hold_mep = NULLP;
             hold_ehp = NULLP;

             hold_flag = FALSE;

             /* ehp points to the element header (storage) */
             ehp = msgCtlp->dup1;

             /* if no FIXED_PTR, adjust octet index for pointer here */
             if (fxdPres == FALSE)
             {
                fxdPres = TRUE;
                /* increment the indices for the element id */
                msgCtlp->octIdx += 1;
                msgCtlp->bitIdx += 8;
             }

             /*  if it's already present, we skip it */
             if ((ehp->pres == PRSNT_NODEF) || (ehp->pres == PRSNT_DEF))
             {
                /* increment message element list */
                msgCtlp->melp1++;

                if (*msgCtlp->melp1 == NULLP)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }

                /* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }

                /* okay, next mep is good */

                /* skip the header */
                fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

                /* skip the tokens */
                mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);

                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                ehp = msgCtlp->dup1;
                break;
             }

             /* check the first octet */
             if (SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx) != ROK)
             {
                /* This may simply be it */
                VALIDATE(msgCtlp);
                RETVALUE(MFROK);
             }

             /* check if this octet = the current message element id */

             /* For Q.763, Optional Parameters may be in ANY order.
              * So, we look through the whole list of message elements
              * to try and find this message id; 
              */
             if (mep->id != c)
             { 
                CONSTANT MsgElmtDef *CONSTANT *tmp_melp;
                CONSTANT MsgElmtDef *tmp_mep;
                ElmtHdr *tmp_ehp;
                S16 found;

                found = FALSE;
                hold_mep = mep; 
                hold_ehp = ehp; 

                /*  set tmps to their head pointers */
                tmp_melp = msgCtlp->smelp1;
                tmp_mep = *msgCtlp->smelp1;
                tmp_ehp = fehp; 

                while ( tmp_mep != NULLP)
                {
                   /* id must match, and storage must be empty
                     and element must be aplicable */
                   if ((tmp_mep->id == c) && (tmp_ehp->pres == NOTPRSNT)
                       && !(tmp_mep->flagp[swtch] & EF_NA))
                   {
                      found = TRUE;
                      break;
                   }
                   /* Skip Tokens */
                   /* skip the header */
                   fpAdd((PTR *)&tmp_ehp, (U32) sizeof(ElmtHdr));
                   /* skip the tokens */
                   mfSkipTkns((TknHdr **)&tmp_ehp, tmp_mep->telp);
                   tmp_melp++;
                   tmp_mep = *tmp_melp; /* next message element */
                }

                /* If we don't find it, something
                 * is wrong with the the pdu defintion,
                 * or this parameter doesn't exist in our db.
                 * record the error, but continue.
                 */
                if (!found) 
                {
#ifdef SI
                  /* Check if we already have a buffer with unrecognized
                     parameters */
                  if (msgCtlp->uBuf == NULLP)
                  {
                     /* if not allocate one */
                     ret = SGetMsg(msgCtlp->mem.region, msgCtlp->mem.pool, 
                                   &(msgCtlp->uBuf));
                     if (ret != ROK)
                     {
                        /* If allocation of a buffer fails we drop this 
                           parameter */
                        msgCtlp->uBuf = NULLP;
                     }

                  }
                  if (msgCtlp->uBuf != NULLP)
                  {
                     /* Add the unrecognized parameter */
                     ret = SAddPstMsg(c, msgCtlp->uBuf);
                     if (ret != ROK)
                     {
                        SPutMsg(msgCtlp->uBuf);
                        msgCtlp->uBuf = NULLP;
                     }
                  }
#endif /* SI */
                  msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = c;
                  msgCtlp->octIdx+= 1;
                  msgCtlp->bitIdx+= 8;
                  ret = SExamMsg(&c, msgCtlp->mp, msgCtlp->octIdx);
                  if (ret != MFROK)
                     MSGRET(msgCtlp, ret);
#ifdef SI
                  /* copy the unrecognized parameter */
                  if (msgCtlp->uBuf != NULLP)
                  {
                     /* Add the length */
                     ret = SAddPstMsg(c, msgCtlp->uBuf);
                     if (ret == ROK)
                     {
                        for (uLen=1; uLen<=c; uLen++)
                        {
                           ret = SExamMsg(&d,msgCtlp->mp,msgCtlp->octIdx+uLen);
                           if (ret != ROK)
                           {
                               /* remove the parameter form the uBuffer */
                               uLen++;
 
                               /* also remove id and length but incrementing
                                  here only by one, because uLen was already
                                  incremented in the for loop but the byte has
                                  not been added to the message yet */
 
                               while (uLen)
                               {
                                  ret = SRemPstMsg(&d, msgCtlp->uBuf);
                                  uLen--;
                               }
                               break;
                           }
                           ret = SAddPstMsg(d, msgCtlp->uBuf);
                           if (ret != ROK)
                           {
                              /* remove the parameter form the uBuffer */
                              uLen++;
 
                              /* also remove id and length but incrementing
                                 here only by one, because uLen was already
                                 incremented in the for loop but the byte has
                                 not been added to the message yet */

                              while (uLen)
                              {
                                 ret = SRemPstMsg(&d, msgCtlp->uBuf);
                                 uLen--;
                              }
                              break;
                           }
                        }
                     }
                     else
                     {
                        /* Remove element id and keep the rest of the buffer */
                        ret = SRemPstMsg(&d, msgCtlp->uBuf);
                     }
                  } 
#endif /* SI */
                  msgCtlp->octIdx+= c + 1;
                  msgCtlp->bitIdx+= ((c + 1) * 8);
                  break;
                }

                mep = tmp_mep;
                ehp = tmp_ehp;

                /* Check for the "End of Optional Parameters" Element */
                if (c == 0x00) /* We handle this in MET_FIXED case */
                {
                   msgCtlp->dup1 = ehp;
                   break;
                }

                hold_flag = TRUE;
             }

             /* increment the indices for the element id */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* get the element length */
             if ((ret = SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                        msgCtlp->octIdx)) != ROK)
                RETVALUE(ret);
             msgCtlp->elen = PutLoByte (msgCtlp->elen, tmp_elen);

             /* increment the indices for the element length */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* set dup1 to current element definition */
             msgCtlp->dup1 = ehp;

             /* dup1 now points to the tokens */
             fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* try to decode the tokens */
             ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp); 
             if (ret != MFROK)
                mfMsgRet(msgCtlp, MFCCNOINFOEL, __LINE__);

             if (msgCtlp->elen > 0)            /* elen should be zero */
             {
                msgCtlp->octIdx += msgCtlp->elen;
                msgCtlp->bitIdx = (U16)(msgCtlp->octIdx << 0x8);
 
                /* increment message element list */
                msgCtlp->melp1++;
 
                if (*msgCtlp->melp1 == NULLP)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* One last check */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                  VALIDATE(msgCtlp);
                  RETVALUE(MFROK);
                }
 
                /* okay, next mep is good */
 
                /* skip the header */
                fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));
 
                /* prepare for next iteration */
                mep = *msgCtlp->melp1;
                ehp = msgCtlp->dup1;
                break;
             }
 

             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                ret = (*msgCtlp->mdbp->func)(msgCtlp);
                if (ret != ROK)
                {
                   msgCtlp->octIdx += msgCtlp->elen;
                   msgCtlp->bitIdx = (U16)(msgCtlp->octIdx << 0x8);
                   
                   /* increment message element list */
                   msgCtlp->melp1++;
                   
                   if (*msgCtlp->melp1 == NULLP)
                   {
                      VALIDATE(msgCtlp);
                      RETVALUE(MFROK);
                   }
                   
                   /* One last check */
                   if (mlen == (MsgLen)msgCtlp->octIdx)
                   {
                      VALIDATE(msgCtlp);
                      RETVALUE(MFROK);
                   }
                   
                   /* okay, next mep is good */
                   
                   /* skip the header */
                   fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                   
                   /* prepare for next iteration */
                   mep = *msgCtlp->melp1;
                   ehp = msgCtlp->dup1;
                   break;
                }
 
             }

             /* mark the header as present */
             ehp->pres = PRSNT_NODEF;
             opFlag = TRUE;

             /* check if we're holding */
             if (hold_flag)                   
             {
                /* have we exhausted the message buffer? */
                if (mlen == (MsgLen)msgCtlp->octIdx )
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* otherwise,  reset the pointers */
                msgCtlp->dup1 = hold_ehp;
                ehp = hold_ehp;
                mep = hold_mep;

                /* unset hold flag */
                hold_flag = FALSE; 
             }
             else                        /* we're not holding */
             {
                /* increment list */
                msgCtlp->melp1++; 

                /* Check that it's valid */
                if (*msgCtlp->melp1  == NULLP)
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* have we exhausted the message buffer? */
                if (mlen == (MsgLen)msgCtlp->octIdx)
                {
                   /* if opFlag, and ISUP, there must be
                    * an end of optional parameter element which
                    * is type MET_FIXED. Therefore, this is an
                    * error. 
                    */
                   VALIDATE(msgCtlp);
                   RETVALUE(MFROK);
                }

                /* otherwise, prepare for next iteration */
                mep =*msgCtlp->melp1;
                ehp = msgCtlp->dup1;
             }
             break;
          }
          case MET_FIXED_PTR:
          {
             U8 offset = (U8)0;
             U8 hold_idx = (U8)0;
             U8 opPtr = (U8)0;
             U8 tmp_elen = (U8)0;

             fxdPres = TRUE;

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* Get the offset */
             ret = SExamMsg(&offset, msgCtlp->mp, msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);

             /* increment indexes */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* Save the current position */
             hold_idx = (U8)msgCtlp->octIdx;

             /* Validate */
             if (mlen < (MsgLen)(msgCtlp->octIdx + (offset -1)))
                MSGRET(msgCtlp, MFCCINVINFOEL);

             /* temporarily bump octIdx */
             msgCtlp->octIdx += (U8)(offset -1);
                
             /* get the element length */
             msgCtlp->elen = 0;
             ret = SExamMsg((Data *) &tmp_elen, msgCtlp->mp, 
                            msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);
             msgCtlp->elen = PutLoByte(msgCtlp->elen , tmp_elen);

             /* Keep tracking the Size */
             MFPSize += (msgCtlp->elen +1);

             /* increment the indices */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             /* validate the length if required */
             if ((msgCtlp->validate) && ((msgCtlp->elen < mep->minLen) || 
                (msgCtlp->elen > mep->maxLen)))
                if (mep->flagp[swtch] & EF_MAND) 
                   MSGRET(msgCtlp, MFCCINVINFOEL);


             /* set dup1 to current element definition */
             msgCtlp->dup1 = ehp;

             /* dup1 now points to the tokens */
             fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* try to decode the tokens */
             ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp); 
             if (ret != MFROK)
                RETVALUE(ret);

             if (msgCtlp->elen > 0)      /* validate length */
                MSGRET(msgCtlp, MFCCINVINFOEL);

             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* mark the header as present */
             ehp->pres = PRSNT_NODEF;

             /* All MET_FIXED_PTR elements are mandatory */
             msgCtlp->acMandCnt++;

             /* reset the index to the position of the pointers */
             msgCtlp->octIdx = hold_idx;

             /* point to next message element pointer */
             msgCtlp->melp1++; 

             /* Check if we've exhausted the message buffer */
             mep =*msgCtlp->melp1;
             ehp = msgCtlp->dup1;

             /* Check if we're done with mand. variables parameters */
             if ((mep != NULLP) && (mep->type != MET_FIXED_PTR))
             {
                /* Grab the Pointer to Optional Parameters */
                ret = SExamMsg(&opPtr, msgCtlp->mp, msgCtlp->octIdx);
                msgCtlp->octIdx++;
                msgCtlp->bitIdx += 8;
                if (opPtr == 0)
                {
                   if ((MsgLen)(msgCtlp->octIdx + MFPSize) != mlen)
                      MSGRET(msgCtlp, MFCCINFOELMSSG);
                   else
                      RETVALUE(MFROK);
                }
                else
                {
                   msgCtlp->octIdx += (opPtr -1);                      
                   msgCtlp->bitIdx += (opPtr -1) * 8;
                }
             }
             else 
                if (mep == NULLP)
                   RETVALUE(MFROK);

             /* If we're at the end of the message element poiters, ERROR */
             if (*msgCtlp->melp1  == NULLP)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* If we're at the end of the message, ERROR */
             if (mlen == (MsgLen)msgCtlp->octIdx)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* prepare for next iteration */
             break;
          }
          case MET_FIXED_PTR2:
          {
             U16 offset = (U16)0;
             U8 hold_idx = (U8)0;
             U16 opPtr = (U16)0;
             U8 tmp_offset = (U8)0;
             U8 tmp_opPtr = (U8)0;
             U8 tmp_elen = (U8)0;

             fxdPres = TRUE;

             /* set error indices */
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;
             msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;

             /* Get the lower byte of the offset */
             ret = SExamMsg(&tmp_offset, msgCtlp->mp, msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);
             offset = PutLoByte(offset, tmp_offset);

             /* Get the hi byte of the offset */
             ret = SExamMsg(&tmp_offset, msgCtlp->mp, msgCtlp->octIdx + 1);
             if (ret != ROK)
                RETVALUE(ret);
             offset = PutHiByte(offset, tmp_offset);

             /* increment indexes */
             msgCtlp->octIdx += 2;
             msgCtlp->bitIdx += 16;

             /* Save the current position */
             hold_idx = (U8)msgCtlp->octIdx;

             /* Validate */
             if (mlen < (MsgLen)(msgCtlp->octIdx + (offset -1)))
                MSGRET(msgCtlp, MFCCINVINFOEL);

             /* temporarily bump octIdx */
             msgCtlp->octIdx += (U16)(offset -1);
                
             /* get the element length */
             ret = SExamMsg(&tmp_elen, msgCtlp->mp, msgCtlp->octIdx);
             if (ret != ROK)
                RETVALUE(ret);
             msgCtlp->elen = PutLoByte(msgCtlp->elen, tmp_elen);

             /* increment the indices */
             msgCtlp->octIdx += 1;
             msgCtlp->bitIdx += 8;

             if ((mep->maxLen) > 0xff)
             {
                ret = SExamMsg(&tmp_elen, msgCtlp->mp, msgCtlp->octIdx);
                if (ret != ROK)
                   RETVALUE(ret);
                msgCtlp->elen = PutHiByte(msgCtlp->elen, tmp_elen);

                /* increment the indices */
                msgCtlp->octIdx += 1;
                msgCtlp->bitIdx += 8;
             }

             /* Keep tracking the Size */
             MFPSize += (msgCtlp->elen +1);

             /* validate the length if required */
             if ((msgCtlp->validate) && ((msgCtlp->elen < mep->minLen) || 
                (msgCtlp->elen > mep->maxLen)))
                if (mep->flagp[swtch] & EF_MAND) 
                   MSGRET(msgCtlp, MFCCINVINFOEL);


             /* set dup1 to current element definition */
             msgCtlp->dup1 = ehp;

             /* dup1 now points to the tokens */
             fpAdd((PTR *)&msgCtlp->dup1, (U32) sizeof(ElmtHdr));

             /* try to decode the tokens */
             ret = mfDecTkns(msgCtlp->mp, mep->telp, msgCtlp); 
             if (ret != MFROK)
                RETVALUE(ret);

             if (msgCtlp->elen > 0)      /* validate length */
                MSGRET(msgCtlp, MFCCINVINFOEL);

             if (msgCtlp->mdbp->func)   /* call user func if avail. */
             {
                if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
                   MSGRET(msgCtlp, ret);
             }

             /* mark the header as present */
             ehp->pres = PRSNT_NODEF;

             /* All MET_FIXED_PTR elements are mandatory */
             msgCtlp->acMandCnt++;

             /* reset the index to the position of the pointers */
             msgCtlp->octIdx = hold_idx;

             /* point to next message element pointer */
             msgCtlp->melp1++; 

             /* Check if we've exhausted the message buffer */
             mep =*msgCtlp->melp1;
             ehp = msgCtlp->dup1;

             /* Check if we're done with mand. variables parameters */
             if ((mep != NULLP) && (mep->type != MET_FIXED_PTR2))
             {
                /* Grab the Pointer to Optional Parameters */
                ret = SExamMsg(&tmp_opPtr, msgCtlp->mp, msgCtlp->octIdx);
                opPtr = PutLoByte (opPtr, tmp_opPtr);
                ret = SExamMsg(&tmp_opPtr, msgCtlp->mp, msgCtlp->octIdx + 1);
                opPtr = PutHiByte (opPtr, tmp_opPtr);

                msgCtlp->octIdx += 2;
                msgCtlp->bitIdx += 16;
                if (opPtr == 0)
                {
                   /* mf_c_001.main_71 - modification - add 1 to MFPSize to
                    * take care two octets of data length in LUDT/LUDTS,
                    * before comparing for message length
                    */
                   if ((MsgLen)(msgCtlp->octIdx + MFPSize + 1) != mlen)
                      MSGRET(msgCtlp, MFCCINFOELMSSG);
                   else
                      RETVALUE(MFROK);
                }
                else
                {
                   msgCtlp->octIdx += (opPtr -1);                      
                   msgCtlp->bitIdx += (opPtr -1) * 8;
                }
             }
             else 
                if (mep == NULLP)
                   RETVALUE(MFROK);

             /* If we're at the end of the message element poiters, ERROR */
             if (*msgCtlp->melp1  == NULLP)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* If we're at the end of the message, ERROR */
             if (mlen == (MsgLen)msgCtlp->octIdx)
                MSGRET(msgCtlp, MFCCINFOELMSSG);

             /* prepare for next iteration */
             break;
          }
          default:
             MSGRET(msgCtlp, MFCCINVMSG);
       }  /* end of switch */
    } /* end of while */
} /* end of mfDecSS7Elmts */


/*
*
*       Fun:   mfEncSS7Elmts
*
*       Desc:  message function - encode elements
*
*       Ret:   MFROK      - ok
*
*       Notes: Called to encode ISUP elements...
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncSS7Elmts
(
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncSS7Elmts(msgCtlp)
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
    S16 ret;                /* return value */
    Swtch swtch;            /* Protocol Standard switch */
    CONSTANT MsgElmtDef *mep;   /* pointer to message element */
    ElmtHdr *ehp;           /* pointer to element header */
    ElmtHdr *fehp;          /* pointer to first element header */
    Bool MFPFlag;           /* flag for MET_FIXED_PTR */
    Bool MFPF2Flag;         /* mf_c_001.main_71 - flag for MET_FIXED_PTR2 */
    Bool MVFlag;            /* flag for MET_VARIABLE */
    U8 opPtrIdx;            /* index for the  OptionalPointer */
    Bool firstVar;          /* first variable element flag */
    Bool optPres;           /* optional elements present flag */
#ifdef SI
    MsgLen uLen;
    Data   data;
    MsgLen uIdx;
#endif /* SI */

    TRC2(mfEncSS7Elmts)

    /* Initialize */
    swtch = msgCtlp->swtch; /* set protocol switch */
    mep = *msgCtlp->melp1;  /* mep = first message element pointer */
    fehp = msgCtlp->dup1;   /* fehp = first element header */
    ehp = msgCtlp->dup1;    /* ehp = first element header */
    MFPFlag = FALSE;        /* Initialize to false */
    MFPF2Flag = FALSE;      /* mf_c_001.main_71 - Initialize to false */
    MVFlag = FALSE;         /* Initialize to false */
    opPtrIdx = 0;           /* Initialize to 0 */
    firstVar = TRUE;        /* Initialize to true */
    optPres = FALSE;

   /* One iteration per element to be encoded, except for
   * MET_FIXED_PTRS which must be handled all at once 
   */
   while (mep != NULLP)
   {
      /* Check if this Element is applicable */
      if (mep->flagp[swtch] & EF_NA)
      {
         fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
         mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);
         msgCtlp->melp1++;
         mep = *msgCtlp->melp1;
         ehp = msgCtlp->dup1;
         continue;
      }
      /* increment past element header */
      fpAdd((PTR *)&msgCtlp->dup1, (U32)sizeof(ElmtHdr));

      /* update error indices */
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtId  = mep->id;
      msgCtlp->ee[(S16)msgCtlp->errCnt].elmtIdx = mep->idx;

      /* Deal with Elements that are not present */
      if (ehp->pres == NOTPRSNT)
      {
         /* All mandatory elements must be present */
         if (mep->flagp[swtch] & EF_MAND)       
            MSGRET(msgCtlp, MFCCINFOELMSSG);
         else 
         {   /* Element not mandatory, and not present, skip */
             mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);   
             if (mep->type == MET_VARIABLE)
                optPres = TRUE; 
             msgCtlp->melp1++;
             mep = *msgCtlp->melp1;
             ehp = msgCtlp->dup1;
             continue;
         }      
      }  
      else      /* make sure pres value is valid */
      {
         if((ehp->pres != PRSNT_NODEF) && (ehp->pres != PRSNT_DEF))
         {
            if (mep->flagp[swtch] & EF_MAND)       
               MSGRET(msgCtlp, MFCCINFOELMSSG);
            else
            {   /* Element not mandatory, and not present, skip */
               ehp->pres = NOTPRSNT;
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);   
               if (mep->type == MET_VARIABLE)
                  optPres = TRUE; 
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               continue;
            }
         }
      }
      /* User Functions are called before encoding... */
      if (msgCtlp->mdbp)
         if (msgCtlp->mdbp->func)
            if ((ret = (*msgCtlp->mdbp->func)(msgCtlp)) != MFROK)
            {
               if ((mep->flagp[swtch] & EF_MAND) || 
                   !(msgCtlp->cfgp->flags & MF_IGNORE))
                  MSGRET(msgCtlp, ret);
               ehp->pres = NOTPRSNT;
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp);
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               continue; /* next iteration */
            }

      /*  If we're here, we need to encode this element */
      switch(mep->type)
      {
         case MET_OPT:
         case MET_FIXED:
         {
            if (mep->id == 0)      /* If EndOp */
            {
               /* Skip */
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               /* mf_c_002.main_71 - addition - initialize optPres to
                * encode null ptr for the endOp
                */
               optPres = TRUE;
               break;
            }
            msgCtlp->elen = 0;
            if ((ret = mfEncTkns(msgCtlp->mp, 
                (CONSTANT TknElmtDef* CONSTANT*)mep->telp, msgCtlp)) != MFROK) 
               RETVALUE(ret);
            if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            /* increment melp1 */
            msgCtlp->melp1++;
            mep = *msgCtlp->melp1;
            ehp = msgCtlp->dup1;
            break;  /* next iteration... */
         }
         case MET_VARIABLE:
         {
            U16 holdIdx;         /* holder for element length index */
            MVFlag = TRUE;       /* We have Parameters of type MET_VARIABLE */
            optPres = TRUE;
            mfOctet = 0;
            /* if no mandatory elements */
            if ((MFPFlag == FALSE) && (firstVar))
            {
               firstVar = FALSE;

               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;
               if (msgCtlp->encode)
               {
                  ret = SAddPstMsg((U8)1, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
               }
            }

            /* encode element id */
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg((U8)mep->id, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;
            /* save the element length index */
            holdIdx = msgCtlp->octIdx + msgCtlp->baseIdx;
            /* encode a zero into the element length */
            if (msgCtlp->encode)
            {
               ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            msgCtlp->octIdx += 1;
            msgCtlp->bitIdx += 8;

            /* encode the tokens */
            msgCtlp->elen = 0;
            ret = mfEncTkns(msgCtlp->mp, 
                   (CONSTANT TknElmtDef * CONSTANT*) mep->telp, msgCtlp);
            if (ret != MFROK)
            {
               Data foo[MF_SIZE_TKNSTR];
               if ((ret == MFRESFAILURE) || (ret == MFDEBUGERR))
                  RETVALUE(ret);
               if ((mep->flagp[swtch] & EF_MAND) &&
                      (!msgCtlp->cfgp->flags & MF_IGNORE))
                  RETVALUE(ret);
               /* else skip */
               msgCtlp->errCnt = 0;
               mfBackOut = 0;
               ehp->pres = NOTPRSNT;

               msgCtlp->octIdx -= 2;
               msgCtlp->bitIdx -= 16;
               msgCtlp->dup1 = ehp;
               if ((ret = SRemPstMsgMult(foo, (MsgLen)(msgCtlp->elen + 2) , 
                          msgCtlp->mp))!= ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
               fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
               mfSkipTkns((TknHdr **) &msgCtlp->dup1, mep->telp); 
               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
               break;  /* next iteration... */
            }

            /* encode was successfull */
            if ((msgCtlp->elen < mep->minLen) || (msgCtlp->elen > mep->maxLen))
               MSGRET(msgCtlp, MFCCINVINFOEL);
            /* replace the element zero with the correct 
             * element length
             */
            if (msgCtlp->encode)
            {
               if (msgCtlp->elen != 0)
               {
                  ret = SRepMsg(msgCtlp->elen, msgCtlp->mp, holdIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
               }
            }

            /* if element break flag set, exit ok */
            if (mep->flagp[swtch] & EF_BREAK)
            {
               if (mep->flagp[swtch] & EF_REP)
                  msgCtlp->dup1 = fehp;
               else 
                  msgCtlp->melp1++;
               RETVALUE(MFROK);
            }
            msgCtlp->melp1++;
            mep = *msgCtlp->melp1;
            ehp = msgCtlp->dup1;
            break;
         }
         case MET_FIXED_PTR:
         {
            /* MET_FIXED_PTRs must be encoded all at once,
             * this is the one exception to the one iteration, one 
             * element comment above
             */
            U8 cnt;           /* counter */
            U8 nElmts;        /* number of elements */
            U8 nmbElmts;      /* number of elements */
            U8 strtIdx;       /* the octIdx where we start */
            U8 opPtrVal;      /* value of optional Pointer */

            CONSTANT MsgElmtDef *CONSTANT *tmp_melp;
            CONSTANT MsgElmtDef *tmp_mep;
            ElmtHdr   *tmp_ehp;

            /* Initialize from where we are */
            MFPFlag = TRUE;      /* we have MET_FIXED_PTR variables */
            nElmts = 0;
            nmbElmts = 0;
            opPtrVal = 0;
            tmp_melp = msgCtlp->melp1;
            tmp_mep = mep;
            tmp_ehp = ehp;

            /* First look ahead */
            while ((tmp_mep != NULLP) && (tmp_mep->type == MET_FIXED_PTR))
            {
               if (!(tmp_mep->flagp[swtch] & EF_NA))
                  nElmts++;
               tmp_melp++;
               tmp_mep = *tmp_melp;
            }
            /* Okay, we have the number of elements */

            /* preserve some important indices */  

            /* where we start */
            strtIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);      

            /* where the OpPtr goes */
            opPtrIdx = strtIdx + nElmts;      

            if ((tmp_mep != NULLP) && ((tmp_mep->type == MET_VARIABLE) ||
                 (tmp_mep->type == MET_FIXED)))
            /* where the OpPtr goes */
            {
               optPres = TRUE;
               nmbElmts = (nElmts + 1);
               opPtrVal = (U8) (nElmts + 1);
            }
            else 
            {
               opPtrVal = nElmts;
               nmbElmts = nElmts;
            }

            /* make room for the pointers */
            for ( cnt = 0; cnt < nmbElmts; cnt++)
            {
               /* we put zeros the pointers, 
                * and the optional pointer for now 
                */
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
               /* increment the message control indices */
               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;
            }

            /* reset the pointers */

            /* now we encode  */
            mep = *msgCtlp->melp1;
            for ( cnt = 0; cnt < nElmts; cnt++)
            {
               U8 elenIdx; /* index of element length */
               /* Check if this Element is applicable */
               if (mep->flagp[swtch] & EF_NA)
               {
                  fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                  mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);
                  msgCtlp->melp1++;
                  mep = *msgCtlp->melp1;
                  ehp = msgCtlp->dup1;
                  cnt--;
                  continue;
               }
               if (cnt != 0)
                  fpAdd((PTR *)&msgCtlp->dup1, (U32)sizeof(ElmtHdr));
               elenIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);

               /* put a zero in the place of the of the element length */
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;

               msgCtlp->elen = 0;
               ret = mfEncTkns(msgCtlp->mp, mep->telp, msgCtlp);
               if (ret != MFROK)
                  RETVALUE(ret);

               /* encode was successfull */

               /* check the length */
               if ((msgCtlp->elen < mep->minLen) || 
                   (msgCtlp->elen > mep->maxLen))
                  MSGRET(msgCtlp, MFCCINVINFOEL);

               /* replace the element length of zero with the correct 
                * element length
                */

               ret = SRepMsg(msgCtlp->elen, msgCtlp->mp, elenIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               /* set the ptr val */
               ret = SRepMsg(opPtrVal, msgCtlp->mp, (strtIdx + cnt));
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               /* increment the Optional Pointer Val 
                * by the length plus the element length 
                */
               opPtrVal += msgCtlp->elen; 

               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
            }
            /* We're done with the pointers, now set OpPtr */
            if (optPres)
            {
               ret = SRepMsg(opPtrVal, msgCtlp->mp, opPtrIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            break;
         }
         case MET_FIXED_PTR2:
         {
            /* MET_FIXED_PTR2s must be encoded all at once,
             * this is the one exception to the one iteration, one 
             * element comment above
             */
            U8 cnt;           /* counter */
            U8 nElmts;        /* number of elements */
            U8 nmbElmts;      /* number of elements */
            U8 strtIdx;       /* the octIdx where we start */
            U16 opPtrVal;     /* value of optional Pointer */

            CONSTANT MsgElmtDef *CONSTANT *tmp_melp;
            CONSTANT MsgElmtDef *tmp_mep;
            ElmtHdr   *tmp_ehp;

            /* Initialize from where we are */
            MFPFlag = TRUE;      /* we have MET_FIXED_PTR variables */
            MFPF2Flag = TRUE;    /* mf_c_001.main_71 - for MET_FIXED_PTR2 */
            nElmts = 0;
            nmbElmts = 0;
            opPtrVal = 0;
            tmp_melp = msgCtlp->melp1;
            tmp_mep = mep;
            tmp_ehp = ehp;

            /* First look ahead */
            while ((tmp_mep != NULLP) && (tmp_mep->type == MET_FIXED_PTR2))
            {
               if (!(tmp_mep->flagp[swtch] & EF_NA))
                  nElmts++;
               tmp_melp++;
               tmp_mep = *tmp_melp;
            }
            /* Okay, we have the number of elements */

            /* preserve some important indices */  

            /* where we start */
            strtIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);      

            /* where the OpPtr goes */
            opPtrIdx = strtIdx + (2 * nElmts);      

            if ((tmp_mep != NULLP) && ((tmp_mep->type == MET_VARIABLE) ||
                 (tmp_mep->type == MET_FIXED)))
            /* where the OpPtr goes */
            {
               optPres = TRUE;
               nmbElmts = (nElmts + 1);
               opPtrVal = (U8) ((2 * (nmbElmts - 1)) + 1);
            }
            else 
            {
               nmbElmts = nElmts;
               opPtrVal = (2 * (nmbElmts - 1)) + 1;
            }

            /* make room for the pointers */
            for ( cnt = 0; cnt < nmbElmts; cnt++)
            {
               /* we put zeros the pointers, 
                * and the optional pointer for now 
                */
               ret = SAddPstMsg(0, msgCtlp->mp);
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
               /* increment the message control indices */
               msgCtlp->octIdx += 2;
               msgCtlp->bitIdx += 16;
            }

            /* reset the pointers */

            /* now we encode  */
            mep = *msgCtlp->melp1;
            for ( cnt = 0; cnt < nElmts; cnt++)
            {
               U8 elenIdx; /* index of element length */
               /* Check if this Element is applicable */
               if (mep->flagp[swtch] & EF_NA)
               {
                  fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(ElmtHdr));
                  mfSkipTkns((TknHdr **)&msgCtlp->dup1, mep->telp);
                  msgCtlp->melp1++;
                  mep = *msgCtlp->melp1;
                  ehp = msgCtlp->dup1;
                  cnt--;
                  continue;
               }
               if (cnt != 0)
                  fpAdd((PTR *)&msgCtlp->dup1, (U32)sizeof(ElmtHdr));
               elenIdx = (U8)(msgCtlp->octIdx + msgCtlp->baseIdx);

               /* put a zero in the place of the of the element length */
               ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
               msgCtlp->octIdx += 1;
               msgCtlp->bitIdx += 8;

               if(mep->maxLen > 0xff)
               {
                  ret = SAddPstMsg(0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
                  msgCtlp->octIdx += 1;
                  msgCtlp->bitIdx += 8;
               }

               msgCtlp->elen = 0;
               ret = mfEncTkns(msgCtlp->mp, mep->telp, msgCtlp);
               if (ret != MFROK)
                  RETVALUE(ret);

               /* encode was successfull */

               /* check the length */
               if ((msgCtlp->elen < mep->minLen) || 
                   (msgCtlp->elen > mep->maxLen))
                  MSGRET(msgCtlp, MFCCINVINFOEL);

               /* replace the element length of zero with the correct 
                * element length
                */

               ret = SRepMsg(GetLoByte(msgCtlp->elen), msgCtlp->mp, elenIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
               if(mep->maxLen > 0xff)
               {
                  ret = SRepMsg(GetHiByte(msgCtlp->elen), msgCtlp->mp, 
                                elenIdx + 1);
#if (ERRCLASS & ERRCLS_ADD_RES)
                  if (ret != ROK)
                     MSGRET(msgCtlp, MFRESFAILURE);
#endif
               }

               /* set the ptr val */
               ret = SRepMsg((U8)GetLoByte(opPtrVal), msgCtlp->mp, 
                             (strtIdx + (2 * cnt)));
               ret = SRepMsg((U8)GetHiByte(opPtrVal), msgCtlp->mp, 
                             (strtIdx + (2 * cnt) + 1));

               if(mep->maxLen > 0xff)
               {
                  /* Update the opPtrVal as well */
                  opPtrVal += 1;
               }
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif

               /* increment the Optional Pointer Val 
                * by the length plus the element length 
                */
               opPtrVal = opPtrVal + msgCtlp->elen - 1; 

               msgCtlp->melp1++;
               mep = *msgCtlp->melp1;
               ehp = msgCtlp->dup1;
            }
            /* We're done with the pointers, now set OpPtr */
            if (optPres)
            {
               ret = SRepMsg((U8)GetLoByte(opPtrVal), msgCtlp->mp, opPtrIdx);
               ret = SRepMsg((U8)GetHiByte(opPtrVal), msgCtlp->mp, opPtrIdx + 1);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
            break;
         }
      } /* end of switch */
   } /* end of while */

   /* deal with our flags */
#ifdef SI
   if (msgCtlp->uBuf != NULLP)
   {
      ret = ROK;
      if ((MFPFlag == FALSE) && (firstVar == TRUE))
      {
         firstVar = FALSE;
         ret = SAddPstMsg((U8)1, msgCtlp->mp);
      }
      if (ret == ROK)
      {
         ret = SFndLenMsg( msgCtlp->uBuf, &uLen);
         if (ret == ROK)
         {
            for (uIdx=0; uIdx<uLen; uIdx++)
            {
               ret = SExamMsg(&data, msgCtlp->uBuf, uIdx);
               if (ret != ROK)
               {
                  /* remove the parameter form the uBuffer */
                  uLen++;
 
                  /* also remove id and length but incrementing
                     here only by one, because uLen was already
                     incremented in the for loop but the byte has
                     not been added to the message yet */
 
                  while (uLen)
                  {
                     ret = SRemPstMsg(&data, msgCtlp->uBuf);
                     uLen--;
                  }
                  break;
               }
               ret = SAddPstMsg(data, msgCtlp->mp);
               if (ret != ROK)
               {
                  /* remove the parameter form the uBuffer */
                  uLen++;
                  /* also remove id and length but incrementing
                     here only by one, because uLen was already
                     incremented in the for loop but the byte has
                     not been added to the message yet */

                  while (uIdx)
                  {
                     ret = SRemPstMsg(&data, msgCtlp->uBuf);
                     uIdx--;
                  }
                  break;
               }
            }
            MVFlag = TRUE;
         }
      }
   }
#endif /* SI */
   if ((MFPFlag == TRUE))            /* we have MET_FIXED_PTRs */
   {
      if (MVFlag == TRUE)            /* we have MET_VARIABLE */
      {
         ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
      if (ret != ROK)
         MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
      else
      {
         if (optPres)
         {
            ret = SRepMsg((U8) 0, msgCtlp->mp, opPtrIdx);
#if (ERRCLASS & ERRCLS_ADD_RES)
            if (ret != ROK)
               MSGRET(msgCtlp, MFRESFAILURE);
#endif
            /* mf_c_001.main_71 - addition - for the case of LUDT/LUDTS,
             * fill zero in the second octet of optional parameter ptr
             */
            if (MFPF2Flag == TRUE)
            {
               ret = SRepMsg((U8) 0, msgCtlp->mp, opPtrIdx + 1);
#if (ERRCLASS & ERRCLS_ADD_RES)
               if (ret != ROK)
                  MSGRET(msgCtlp, MFRESFAILURE);
#endif
            }
         }
      }
   }
   else /* No MET_FIXED_PTRs */
   {
      if (optPres == TRUE)                 /* we have MET_VARIABLE */
      {
         ret = SAddPstMsg((U8)0, msgCtlp->mp);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (ret != ROK)
            MSGRET(msgCtlp, MFRESFAILURE);
#endif
      }
   }
   RETVALUE(MFROK);
} /* end of mfEncSS7Elmts */


/*
*
*       Fun:   mfInitSS7Elmts
*
*       Desc:  message function - init elements for isup
*
*       Ret:   MFROK      - ok
*
*       Notes: initialize all the element headers...
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfInitSS7Elmts
(
MfMsgCtl *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfInitSS7Elmts(msgCtlp)
MfMsgCtl *msgCtlp;        /* pointer to message control structure */
#endif
{
    CONSTANT MsgElmtDef *CONSTANT *tmp_melp;
    CONSTANT MsgElmtDef *tmp_mep;
    ElmtHdr *tmp_ehp;
    ElmtHdr *fehp;

    TRC2(mfInitSS7Elmts)

    /*  set tmps to their head pointers */
    tmp_melp = msgCtlp->smelp1; 
    tmp_mep = *msgCtlp->smelp1; 
    tmp_ehp = msgCtlp->dup1; 
    fehp = msgCtlp->dup1; 

#ifdef TP
    msgCtlp->tupInfo.optInds = 0;
    msgCtlp->tupInfo.nmbInds = 0;
    msgCtlp->tupInfo.decIdx = 0;
#endif /* TP */
#ifdef SP
    msgCtlp->sccpInfo.dlrPres = FALSE;
    msgCtlp->sccpInfo.slrPres = FALSE;
    msgCtlp->sccpInfo.data = NULLP;
#endif /* SP */

    while ( tmp_mep != NULLP)
    {
      /* initialize structure to NOTPRSNT */
      tmp_ehp->pres = NOTPRSNT;
      /* Skip Tokens */
      /* skip the header */
      fpAdd((PTR *)&tmp_ehp, (U32) sizeof(ElmtHdr));

      /* mf_c_003.main_71 - addition - initialize tkn to NOTPRSNT */
      tmp_ehp->pres = NOTPRSNT;

      /* skip the tokens */
      mfSkipTkns((TknHdr **)&tmp_ehp, tmp_mep->telp);
      tmp_melp++;
      tmp_mep = *tmp_melp; /* next message element */
    }

    msgCtlp->dup1 = fehp;

    RETVALUE(MFROK);
} /* mfInitSS7Elmts */


/*
*
*       Fun:   mfSetMfLen
*
*       Desc:  message function - sets mfLen value based on token dependencies
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC Void mfSetMfLen
(
U8 len
)
#else
PUBLIC Void mfSetMfLen(len)
U8 len;
#endif
{
   TRC2(mfSetMfLen)

   mfLen = len;
   RETVOID;
} /* mfSetMfLen */


/*
*
*       Fun:   mfGetMfLen
*
*       Desc:  message function - sets mfLen value based on token dependencies
*
*       Ret:   MFROK      - ok
*
*       Notes: 
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PUBLIC S16 mfGetMfLen
(
void
)
#else
PUBLIC S16 mfGetMfLen()
#endif
{
   TRC2(mfGetMfLen)

  RETVALUE(mfLen);
} /* mfGetMfLen */
#ifdef SP
  
/*
*
*       Fun:   mfEncData
*
*       Desc:  message function - encode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfEncData
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfEncData(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */

   MsgLen mLen;
   CONSTANT MsgElmtDef *mep = *msgCtlp->melp1;
   TknU8 *tp;

   TRC2(mfEncData)

   /* check mandatory dependencies */
   tp = (TknU8 *) msgCtlp->dup1;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (!tp->pres)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      else
      {
         msgCtlp->sccpInfo.data = (Buffer*)NULLP;
         RETVALUE(MFROK);
      }
   }

   /* this is a special token type for sccp data parts */
   if (msgCtlp->sccpInfo.data == (Buffer*)NULLP)
   {
      if (mep->type == MET_FIXED_PTR)
      {
         /* remove the element length octet */
         Data foo;
         if ((ret = SRemPstMsg(&foo, mp)) != ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
         RETVALUE(MFROK);
      }
      else
      {
         /* remove the element id, and the element length octet */
         Data foo[2];
         if ((ret = SRemPstMsgMult(foo, 2, mp))!= ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
      }
      RETVALUE(MFROK);
   }

   /* otherwise calc the data length */
   SFndLenMsg(msgCtlp->sccpInfo.data, &mLen);
   if (mLen == 0)
   {
      if (mep->type == MET_FIXED_PTR)
      {
         /* remove the element length octet */
         Data foo;
         if ((ret = SRemPstMsg(&foo, mp)) != ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
         if ((ret = SPutMsg(msgCtlp->sccpInfo.data)) != ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
         msgCtlp->sccpInfo.data = (Buffer*)NULLP;
         msgCtlp->octIdx -=1;
         msgCtlp->bitIdx -=8;
      }
      else
      {
         /* remove the element id, and the element length octet */
         Data foo[2];
         if ((ret = SRemPstMsgMult(foo, 2, mp))!= ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
         if ((ret = SPutMsg(msgCtlp->sccpInfo.data))!= ROK)
            MSGRET(msgCtlp, MFCCNOINFOEL);
         msgCtlp->sccpInfo.data = (Buffer*)NULLP;
         msgCtlp->octIdx -=2;
         msgCtlp->bitIdx -=16;
      }
      RETVALUE(MFROK);
   }

   /* okay we have data, cat it onto the message here. */
   SCatMsg(mp, msgCtlp->sccpInfo.data, 0);
   SPutMsg(msgCtlp->sccpInfo.data); /* return message buffer */
   msgCtlp->sccpInfo.data = (Buffer*)NULLP;
   msgCtlp->elen = mLen;
   msgCtlp->octIdx += mLen;
   msgCtlp->bitIdx += 8*mLen;

   RETVALUE(MFROK);
} /* end of mfEncData */
  
/*
*
*       Fun:   mfDecData
*
*       Desc:  message function - decode string
*
*       Ret:   MFROK      - ok
*
*       Notes: None
*
*       File:  mf.c
*
*/
 
#ifdef ANSI
PRIVATE S16 mfDecData
(
Buffer     *mp,
CONSTANT TknElmtDef *tep,   /* token element definition pointer */
MfMsgCtl   *msgCtlp         /* pointer to message control structure */
)
#else
PRIVATE S16 mfDecData(mp, tep, msgCtlp)
Buffer     *mp;
CONSTANT TknElmtDef *tep;   /* token element definition pointer */
MfMsgCtl   *msgCtlp;        /* pointer to message control structure */
#endif
{
   S16 ret;                 /* return code */
   TknU8 *tp;
   U8 len;
   Bool noOp;
   Buffer *tmp,*tmp1;

   TRC2(mfDecData)

   UNUSED(mp);
   noOp = FALSE;

   /* if token present based on last ext flag and not extended */
   tp = (TknU8 *) msgCtlp->dup1;
   tp->pres = NOTPRSNT;
   /* bump message structure ptr */
   fpAdd((PTR *) &msgCtlp->dup1, (U32) sizeof(TknU8));
   if (msgCtlp->elen == 0)
   {
      if ((msgCtlp->validate) && (*tep->flagp & TF_MAND))
         MSGRET(msgCtlp, MFCCINVINFOEL);
      msgCtlp->sccpInfo.data = (Buffer*)NULLP;
      RETVALUE(MFROK);
   }

   /* if there is a user function, execute it */
   if (tep->func)
      if ((ret = (*tep->func)(msgCtlp, (PTR) tp)) != MFROK)
         MSGRET(msgCtlp, ret);

   /* token must be present, check it */
   len = tep->maxLen;
   
   if (msgCtlp->validate)
      if ((len < tep->minLen) || (len > tep->maxLen))
         MSGRET(msgCtlp, MFCCINVINFOEL);

   /* read in bytes */

   /* split the buffer at the current index */
   ret = SSegMsg(msgCtlp->mp, msgCtlp->octIdx, &tmp1);
   if (ret != ROK)
      MSGRET(msgCtlp, MFCCINVINFOEL);

   /* now split the buffer at the end of the data portion */

   /* split the buffer at the data index */
   ret = SSegMsg(tmp1, msgCtlp->elen, &tmp);
   if (ret == ROKDNA)
      noOp = TRUE;
   else if (ret != ROK)
      MSGRET(msgCtlp, MFCCINVINFOEL);

   /* make a copy of the data portion */

   /*
    * When MOS is the system service provider, region and pool
    * have no meaning. With some other system service provider they
    * may be meaningful and therefore different from the below 
    * defaults. If so, this will need to be changed
    */
   ret =
      SCpyMsgMsg(tmp1, SGETBUFREGION(tmp1), SGETBUFPOOL(tmp1), 
                 &msgCtlp->sccpInfo.data);


   if (ret != ROK)
      MSGRET(msgCtlp, MFCCINVINFOEL);

   /* put data portion back into original message */
   ret =
      SCatMsg(msgCtlp->mp, tmp1, M1M2);
   if (ret != ROK)
      MSGRET(msgCtlp, MFCCINVINFOEL);
   /* return the temp buffer */
   ret =
      SPutMsg(tmp1);
   if (ret != ROK)
      MSGRET(msgCtlp, MFCCINVINFOEL);

   /* cat the end back onto the original buffer */
   if (!noOp)
   {
      ret =
         SCatMsg(msgCtlp->mp, tmp, M1M2);
      if (ret != ROK)
         MSGRET(msgCtlp, MFCCINVINFOEL);

      /* return the temp buffer */
      ret =
         SPutMsg(tmp);
      if (ret != ROK)
         MSGRET(msgCtlp, MFCCINVINFOEL);
   }

   /* move up the octIdx */
   msgCtlp->octIdx += msgCtlp->elen;
   msgCtlp->bitIdx += msgCtlp->elen * 8; 

   msgCtlp->elen = 0;

   if (msgCtlp->decode)
   {
      tp->pres = PRSNT_NODEF;
      tp->val = 1;
   }


   RETVALUE(MFROK);
} /* end of mfDecData */
#endif /* SP */
#endif /* SS7 */



/********************************************************************30**
  
         End of file:     mf.c@@/main/71 - Tue Jan 22 15:19:15 2002
    
*********************************************************************31*/


/********************************************************************40**

   Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

   Revision history:

*********************************************************************61*/

/********************************************************************70**

  version    initials         description
-----------  ---------  ------------------------------------------------
1.1.0.0         jkm     1. initial release.

1.2             jrl     1. trillium development system checkpoint (dvs)
                           at version: 1.1.0.0

1.3             ma      1. corrections for ANSI compiler
                        2. added TRC2 where missing
                        3. functions mfBcmp, mfBcopy, mfStrlen are now
                           private

1.4             gp      1. comments added

1.5             bn      1. added case TET_U16_EXT: to mfInitTkns and
                           mfSkipTkns
                        2. add ARGS macro to fpAdd function prototype
                        3. cast some statements to U16
                        4. text changes
                        5. add function prototype for sprintf

1.6             bn      1. change funcion mfDecElmts to enhance support 
                           of multiple shift elements and multiple elements 
                           with locking and nonlocking shift to diff codesets.
                           
1.7             rk      1. added functionality for TET_U24 and functions
                           mfEncU24 and mfDecU24.

1.8             lc      1. added bits functions

1.9             bn      1. added a check for message Index value in mfDecMsgType
                        2. added switch to mfChkEnum.

1.10            bn      1. added support for decoding single-type-2 elements.
                        2. initialized mfOctet to 0 before encoding PduHeader.
                        3. added support of certain errors in optional elemnts.

*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.11         ---  jrl   1. text changes

1.12         ---  lc    1. added encoding and decoding functionality
                           for isup
             ---  jrl   2. move initialization of mfDecCont into mfInit

1.13         ---  jrl   1. add S16 ret for error checking to mfSetExt
             ---  jrl   2. add ) to if in mfEncISUPElmts

1.14         ---  bn    1. add ifdef IN to compile out references
                           for q.930 as necessary

1.15         ---  bn    1. add support of message default values per switch.

1.16         ---  rk    1. add logic to skip n/a elements in mfInitElmts.
             ---  jrl   2. remove PRIVATE from MFPSize declaration in
                           mfDecISUPElmts

1.17         ---  lc    1. changed mfDecStr to validate bit 8 for ascii strings
                        2. added a check for mandatory elmts errors in DecElmts
             ---  rg    3. in decode token functions, if message ends before
                           decoding is complete, returned cause code is 
                           changed from MFCCINVINFOEL to MFCCINVMSG.
                           (change affects mfDecU8, mfDecU8Enum, mfDecU16Ext, 
                            mfDecU16, mfDecU24, mfDecU32, mfDecBits)
             ---  rg    4. Changed mfMeCuaseDgn minVal from 1 to 2.
             ---  rg    5. changed mfInitElmt to allow init to NOTPRSNT mode.
             ---  jrl   6. text changes

1.18         ---  bn    1. added ifdef IN around calls to inInitErr

1.19         ---  rhk   1. fixed Enc and Dec U24 for frame relay
                        2. fixed mfEncISUPElmts to handle fixed 
                           pointers correctly

1.20         ---  rg    1. added support for facility message

1.21         ---  fmg   1. change ISUP routines to SS7 routines 
                        2. added support for TUP
                        3. added support for SCCP

1.22         ---  bn    1. cast error code and id in inInitErr to U8

1.23         ---  bn    1. change to mfInitElements to avoid overwriting
                           of initialized elements
             ---  bn    2. adjust expected mandatory count in
                           mfDecodeElements

1.24         ---  bn    1. text changes.

1.25         ---  bn    1. text changes

1.26         ---  bn    1. add local variables saveSet and mandElmt in 
                           mfDecElmt to handle unexpexcted shift elements and
                           to improve efficiency.
             ---  bn    2. change decode of ISUP elements not to exit with 
                           error in case of missing End of Opt Par element.

1.27         ---  rg    1. added support for Q.93B.
             ---  rg    2. added functions mfDecATMElmts, mfEncATMElmts,
                           mfInitATMElmts and mfChkMssgMand.
             ---  rg    3. modified mfDecU24 and mfEncU24 for Q.93B.
             ---  rg    4. changed output format for mfPrntErr.

1.28         ---  bn    1. zero out global variables in mfInit.
             ---  bn    2. text changes
             ---  bn    3. change to continue decoding if unexpected optional
                           element detected for mfDecSS7Elmts
             ---  bn    4. insert pointer to optional elements when no
                           mandatory elements are present in SS7 message
             ---  bn    5. add logic to decode pointer to optional elements
                           when no mandatory elements are present in SS7
                           message

1.29         ---  fmg   1. fix logic to decode pointer to optional elements
                           when no mandatory variable elements are present in 
                           SS7 message

1.30         ---  rg    1. added typecast (Data *) to &msgCtlp->elen when
                           used as the first parameter of SExamMsg.
             ---  rg    2. added code for mfBackOut for decoding ATM elements.
             ---  rg    3. corrected code for returning MFCCINVMSGLEN code
                           while decoding ATM elements.
             ---  rg    4. changed mfPrntErr to print entire ee[] array instead
                           of errCnt entries, since errCnt is often 0, even
                           though an (optional) error has been recorded.
             ---  rg    5. corrected mfMsgRet to keep index, errCnt, within
                           bounds if multiple errors are recorded.

1.31         ---  rg    1. removed unused local variables from mfEncATMElmts.
             ---  rg    2. added explicit typecasts in many places.
             ---  rg    3. changed local variable, len, from U8 to U16 in
                           mfDecU16, mfDecU16Ext, mfDecU32 and mfDecStr.
             ---  rg    4. added initialization, val=0, to case 4 of mfDecBits.
             ---  rg    5. change return( to RETVALUE(

1.32         ---  rg    1. change return ( to RETVALUE(
             ---  rg    2. text changes

1.33         ---  bn    1. changed encoding of isup msgs not to insert pointer
                           to optional params when none are allowed in the msg.

1.34         ---  bn    1. corrected pointer insersion in encoding isup 
                           messages.
             ---  bn    2. added mfEncStrL and mfDecStrL.

1.35         ---  rg    1. corrected mfEncATMElmts to skip tokens correctly 
                           when mfEncTkns returns with error.
             ---  fmg   2. change == to = for sccpInfo.data

1.36         ---  bn    1. incremented octInx and bitIdx when encountered 
                           unrecognized variable len element in mfDecSS7Elmts.

1.37         ---  bn    1. miscellaneous changes

1.38         ---  bn    1. changed eid initialization for tr 6 single1 elmts.
             ---  bn    2. added test for MET_FIXED in encoding ss7 elements
                           for case MET_FIXED_PTR: 

1.39         ---  bn    1. text changes.

1.40         ---  bn    1. changed mfDecElmts to ignore empty  MET_SINGLE1
                           elements.

1.41         ---  bn    1. remove ret
             ---  bn    2. replace ss_??.? with ssi.?

1.42         ---  bn    1. changed mfDecElmts to handle certain message errors.

1.43         ---  lc    1. change prototype for fpAdd for adrp from U32 to PTR

1.44         ---  fmg   1. fixed bug in mfDecData for non-errchk case

1.45         ---  scc   1. fixed bug in mfEncData for not incrementing
                           mfCtlp->octidx and mfCtlp->bitidx
             ---  bn    2. set len to 3 in mfDecU24 for SCCP
             ---  bn    3. added case for BC303 for a specific element to
                           satisfy requirement.

1.46         ---  bn    1. changed CONSTANT usage

1.47         ---  fmg   2. fixed CONSTANT usage one more time...

1.48         ---  bn    1. in001.31, in002.31, in006.31, in014.31, in036.35

1.49         ---  krp   1. Rewrote mfInitElmts and mfSkipTkns routines to
                           improve performance.
             ---  krp   2. Modification to mfEncU8Enum to take care of
                           requirement for ATT Restart element.

1.50         ---  bn    1. removed EMF056.

1.51         ---  fmg   1. removed sprintf prototype (already in envdep.h)
1.52         ---  bn    1. added additional check for network mand EI's 
                           prior to incrementing exMandCnt.

1.53         ---  bn    1. corrected initialization of MVFlag in mfEncSS7Elmts.
             ---  fmg   2. corrected meData encoding...

1.54         ---  krp   1. Included processing code for FN error handling.
             ---  krp   2. Modified EncU8 for FN.
             ---  bn    3. Modified functions for V51

1.55         ---  bn    1. corrected encoding of the optional EI's for ISUP.

1.56         ---  aa    1. Removed the compilation warning in function 
                           mfDecElmts

1.57         ---  bn    1. corrected encoding of ss7 elements.

1.58         ---  bn    1. added a function mfInitErr for IN and NV.
             ---  bn    2. added new compile flag FM_NV.

1.59         ---  bn    1. corrected compile errors.

1.60         ---  bn    1. corrected encode SS7 elements.

1.61         ---  bn    1. corrected encode SS7 elements.

1.62         ---  bn    1. correction in mfDEcMsgType.
             ---  bn    2. added support for V5.X Control Protocol.

*********************************************************************81*/
/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.63         ---      sb   1. Added additional checks while incrementing
                              and decrementing exMandCnt in mfDecElmts.
             ---           2. Removed codeset check for V5X in mfDecElmts.
             ---           3. Modified mfEncU24 to initialize len for V5X.

1.64         ---      av   1. miscellaneous changes.

1.65         ---      ao   1. Added support of unrecognized parameters
                              for ISUP.

1.66         in012.38 pk   1. Added additional checks in mfDecU8Enum.
             in013.38 pk   2. Added check for Qsig Notification Ind IE
                              extension bit in mfDecU8Enum.
                      pk   3. Changed U8 to U16 for index in function
                               mfDecElmts.
                      pk   4. Changed action taken in case of mandatory
                              element error for QSIG , notify message-
                              notification ind IE.
                      pk   5. Changed error value returned for non
                              mandatory elemnt error in case of QSIG,
                      sam  6. Modified mfEncU24 and mfDecU24 to enable
                              encoding and decoding of business grp IE.
             in014.38 pk   7. Added additional checks for bearcap tkns
                              in mfDecU8Enum and mfDecU8.
                           8. Changed cause value from MFCCINVMSG to
                              MFCCNOINFOEL for messages with unrecognized
                              IEs in mfDecElmts.
                      sam  9. Text changes                           
1.67         ---      ash  1. UNUSED(mp) in mfDecData function to avoid 
                              g++ compiler warning

1.68         ---      pk   1. Modified error value returned for length IE 
                              error in case of BC303TMC.
                           2. Added mfSaveOctet, to store the mfOctet value
                              during encoding, in mfDecU8Enum.
                           3. Added Initialization for mfSaveOctet in
                              mfDecElmts. 

/main/68         ---      vb   1. Added encoding for another message element 
                              type MET_FIXED_PTR2 in mfEncSS7Elmts. This 
                              is the mandatory variable portion with two
                              octet pointers and in case max possible
                              length is > 0xff, two-octet length field.
                           2. Added decoding for MET_FIXED_PTR2 in 
                              mfDecSS7Elmts
/main/70     ---      cy   1. Updated for new release.
/main/71     ---      rc   1. local variable index is replaced with indx1 to
                              remove vxWorks compilation warnings.
     mf_c_001.main_71 rc   1. boolean MFPF2Flag introduced to fill optional
                              parameter filed with zero in LUDT/LUDTS if no any
                              optional parameter is present in LUDT/LUDTS.
                           2. When decoding LUDT/LUDTS, one added in MFPSize
                              before comparing for total message length to take
                              care the two octets of data length in LUDT(S)
     mf_c_002.main_71 rc   1. initializing optPres to encode null ptr for the
                              endOp
     mf_c_003.main_71 rc   1. In function mfInitSS7Elmts, initialize all the 
                              tkn within msg element to not present.
     mf_c_004.main_71 sm   1. Initialization of Local Variables.
*********************************************************************91*/
