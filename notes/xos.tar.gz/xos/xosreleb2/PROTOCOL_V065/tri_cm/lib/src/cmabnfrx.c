/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     common ABNF regular expression  
  
     Type:     C Source file
  
     Desc:     Definition for common regular exprssion function.
  
     File:     cmabnfrx.c
  
     Sid:      cmabnfrx.c@@/main/9 - Wed Mar 30 08:42:56 2005
  
     Prg:      rm
  
*********************************************************************21*/
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_abnf.h"       /* ABNF header file */
#include "cm_mblk.h"       /*  Event memory managemnt header file */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_mblk.x"       /* Event memory managemnt header file */
#include "cm_abnf.x"       /* ABNF header file */
#include "cm_abndb.x"      /*  Prototype definition for common reg exp */ 


/*
*
*       Fun:   cmAbnfRegExpDgt 
*
*       Desc:  Description for the regular expression for dgt
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpDgt 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpDgt (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rdgtyych;
   S16  rdgtyyret = -1;
   U16 rdgtyydecode = 0;

   TRC2(cmAbnfRegExpDgt)

   rdgtyych = cmAbnfGetChar(decCp->offset);

   switch(rdgtyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto rdgtyy3;
   default:   goto rdgtyyErr;
   }
rdgtyy3:
   if(CM_ABNF_DEC_CHKLEN(len, rdgtyydecode))
      goto rdgtyyErr;
   CM_ABNF_DEC_CHCPY(memPtr, rdgtyych);

   rdgtyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rdgtyydecode);

   switch(rdgtyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto rdgtyy3;
   default:   goto rdgtyyDef;
   }
rdgtyyDef:
   rdgtyyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, memPtr, len, rdgtyydecode);

rdgtyyErr:
   CM_ABNF_DECRET(decCp, rdgtyyret, rdgtyydecode, tknCons, len);
} /* cmAbnfRegExpDgt */


/*
*
*       Fun:   cmAbnfRegExpSDgt
*
*       Desc:  Description for the regular expression SDgt
*              
*                  [-]?[0-9]+    {return(1);}
*               
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSDgt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpSDgt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(cmAbnfRegExpSDgt)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '-':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy4;
   default:   goto yyErr;
   }
yy3:   
   if (CM_ABNF_DEC_CHKLEN(len, yydecode))
      goto yyErr;
   CM_ABNF_DEC_CHCPY(mem, yych);
   (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy4;
   default:   goto yyErr;
   }
yy4:
   if (CM_ABNF_DEC_CHKLEN(len, yydecode))
      goto yyErr;
   CM_ABNF_DEC_CHCPY(mem, yych);
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto yy4;
   default:   goto yy6;
   }
yy6:
   {
      yyret = 1;
      goto yyReturn;
   }




yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* cmAbnfRegExpSDgt */

/*
*
*       Fun:   cmAbnfRegExpSXDgt
*
*       Desc:  Description for the regular expression SXDgt
*              
*                  [-]?[0-9a-fA-F]+    {return(1);}
*               
*              
*              
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSXDgt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpSXDgt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(cmAbnfRegExpSXDgt)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '-':   goto yy3;
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy3:   
   if (CM_ABNF_DEC_CHKLEN(len, yydecode))
      goto yyErr;
   CM_ABNF_DEC_CHCPY(mem, yych);
   (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto yy4;
   default:   goto yyErr;
   }
yy4:
   if (CM_ABNF_DEC_CHKLEN(len, yydecode))
      goto yyErr;
   CM_ABNF_DEC_CHCPY(mem, yych);
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto yy4;
   default:   goto yy6;
   }
yy6:
   {
      yyret = 1;
      goto yyReturn;
   }




yyReturn:
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, yydecode);

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* cmAbnfRegExpSXDgt */


/*
*
*       Fun:   cmAbnfRegExpPosDgt 
*
*       Desc:  Description for the regular expression for dgt
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpPosDgt 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpPosDgt (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rposyych;
   S16  rposyyret = -1;
   U16 rposyydecode = 0;

   TRC2(cmAbnfRegExpPosDgt)

   rposyych = cmAbnfGetChar(decCp->offset);

   switch(rposyych)
   {
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':  goto rposyy3;
   default :   goto rposyyErr;
   }
rposyy3:
   if(CM_ABNF_DEC_CHKLEN(len, rposyydecode))
      goto rposyyErr;
   CM_ABNF_DEC_CHCPY(memPtr, rposyych);

   rposyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rposyydecode);

   switch(rposyych)
   {
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   goto rposyy3;
   default :   goto rposyyDef;
   }
rposyyDef:
   rposyyret = 0;

rposyyErr:
   CM_ABNF_DECRET(decCp, rposyyret, rposyydecode, tknCons, len);
} /* cmAbnfRegExpPosDgt */


/*
*
*       Fun:   cmAbnfRegExpXDgt
*
*       Desc:  Description for the regular expression XDgt
*                hexpref      = "0"[xX];
*                hexdig       = [0-9A-Fa-f];
*                hexint       = (hexpref)?(hexdig)+;
*              
*                hexint       {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  cmabnfrx.c
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpXDgt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpXDgt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 cmAbnfXDgtyych;
   S16 cmAbnfXDgtyyret = -1;
   U16 cmAbnfXDgtyydecode = 0;
   S16 cmAbnfXDgtyyaccept = -1;

   TRC2(cmAbnfRegExpXDgt)

   cmAbnfXDgtyych = cmAbnfGetChar(decCp->offset);
   switch(cmAbnfXDgtyych)
   {
   case '0':   goto cmAbnfXDgtyy3;
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto cmAbnfXDgtyy5;
   default:   goto cmAbnfXDgtyyErr;
   }
cmAbnfXDgtyy3:   cmAbnfXDgtyyaccept = 0;

   if (CM_ABNF_DEC_CHKLEN(len, cmAbnfXDgtyydecode))
      goto cmAbnfXDgtyyErr;
   CM_ABNF_DEC_CHCPY(mem, cmAbnfXDgtyych);
   (++cmAbnfXDgtyydecode);
   cmAbnfXDgtyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(cmAbnfXDgtyych)
   {
   case 'X':   case 'x':   goto cmAbnfXDgtyy7;
   default:   goto cmAbnfXDgtyy6;
   }
cmAbnfXDgtyy4:
   {
      cmAbnfXDgtyyret = 1;
      goto cmAbnfXDgtyyReturn;
   }
cmAbnfXDgtyy5:
   if (CM_ABNF_DEC_CHKLEN(len, cmAbnfXDgtyydecode))
      goto cmAbnfXDgtyyErr;
   CM_ABNF_DEC_CHCPY(mem, cmAbnfXDgtyych);
   (++cmAbnfXDgtyydecode);
   cmAbnfXDgtyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
cmAbnfXDgtyy6:   switch(cmAbnfXDgtyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto cmAbnfXDgtyy5;
   default:   goto cmAbnfXDgtyy4;
   }
cmAbnfXDgtyy7:   
   if (CM_ABNF_DEC_CHKLEN(len, cmAbnfXDgtyydecode))
      goto cmAbnfXDgtyyErr;
   CM_ABNF_DEC_CHCPY(mem, cmAbnfXDgtyych);
   (++cmAbnfXDgtyydecode);

   cmAbnfXDgtyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(cmAbnfXDgtyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':   goto cmAbnfXDgtyy5;
   default:   goto cmAbnfXDgtyyErr;
   }



cmAbnfXDgtyyReturn:
   cmAbnfXDgtyyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, mem, len, cmAbnfXDgtyydecode);

cmAbnfXDgtyyErr:
   CM_ABNF_DECRET(decCp, cmAbnfXDgtyyret, cmAbnfXDgtyydecode, tknCons, len);
} /* cmAbnfRegExpXDgt */

/*
*
*       Fun:   cmAbnfRegExpDollar 
*
*       Desc:  Description for the regular expression for dollar sign
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpDollar 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpDollar (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rdypyych;

   TRC2(cmAbnfRegExpDollar)

   rdypyych = cmAbnfGetChar(decCp->offset);

   switch(rdypyych)
   {
   case '$':  goto rdypyyReturn;
   default:   goto rdypyyErr;
   }
rdypyyReturn:
   if (tknCons)
      rdypyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rdypyyErr:  
   return(-1);
} /* cmAbnfRegExpDollar */

/*
*
*       Fun:   cmAbnfRegExpStar 
*
*       Desc:  Description for the regular expression for asterisk sign
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpStar 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpStar (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rstaryych;

   TRC2(cmAbnfRegExpStar)

   rstaryych = cmAbnfGetChar(decCp->offset);

   switch(rstaryych)
   {
   case '*':  goto rstaryyReturn;
   default:   goto rstaryyErr;
   }
rstaryyReturn:
   if (tknCons)
      rstaryych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rstaryyErr:  
   return(-1);
} /* cmAbnfRegExpStar */

/*
*
*       Fun:   cmAbnfRegExpHyphen 
*
*       Desc:  Description for the regular expression for dash
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpHyphen 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpHyphen (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rhypyych;

   TRC2(cmAbnfRegExpHyphen)

   rhypyych = cmAbnfGetChar(decCp->offset);

   switch(rhypyych)
   {
   case '-':  goto rhypyyReturn;
   default:   goto rhypyyErr;
   }
rhypyyReturn:
   if (tknCons)
      rhypyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rhypyyErr:  
   return(-1);
} /* cmAbnfRegExpHyphen */


/*
*
*       Fun:   cmAbnfRegExpComma 
*
*       Desc:  Description for the regular expression for Comma
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File:  cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpComma 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpComma (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rcommayych;

   TRC2(cmAbnfRegExpComma)

   rcommayych = cmAbnfGetChar(decCp->offset);

   switch(rcommayych)
   {
   case ',':   goto rcommayyReturn;
   default :   goto rcommayyErr;
   }
rcommayyReturn:
   if (tknCons)
      rcommayych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rcommayyErr:  
   return(-1);
} /* cmAbnfRegExpComma */


/*
*
*       Fun:   cmAbnfRegExpSutblChar 
*
*       Desc:  Description for the regular expression for suitable character
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSutblChar 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpSutblChar (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rstblyych;
   S16  rstblyyret = -1;
   U16 rstblyydecode = 0;

   TRC2(cmAbnfRegExpSutblChar)

   rstblyych = cmAbnfGetChar(decCp->offset);

   switch(rstblyych)
   {
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case ';':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto rstblyy3;
   default :   goto rstblyyErr;
   }
rstblyy3:
   if(CM_ABNF_DEC_CHKLEN(len, rstblyydecode))
      goto rstblyyErr;
   CM_ABNF_DEC_CHCPY(memPtr, rstblyych);

   rstblyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rstblyydecode);

   switch(rstblyych)
   {
   case '\r':   goto rstblyy5;
   case '!':   case '#':
   case '$':   case '&':
   case '\'':   case '*':
   case '+':   case '-':
   case '.':
   case '/':
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case ';':   case '=':   case '?':
   case '@':
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':
   case '[':   case ']':
   case '^':
   case '_':
   case '`':
   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':
   case '{':
   case '|':
   case '}':
   case '~':   goto rstblyy3;
   default :   goto rstblyyDef;
   }

rstblyy5:
rstblyyDef:
   rstblyyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, memPtr, len, rstblyydecode);

rstblyyErr:
   CM_ABNF_DECRET(decCp, rstblyyret, rstblyydecode, tknCons, len);
} /* cmAbnfRegExpSutblChar */

/* 001.main_3;Regular exp cmAbnfRegExpEOL changed to accept optional space 
 * before EOl (\r ,\n  or \r\n ); */

/*
*
*       Fun:   cmAbnfRegExpEOL
*
*       Desc:  Description for the regular expression EOL
*              
*                       space       = " ";
*                       optSpace    = (space)+;
*                       eol         = "\r" | "\n" | "\r\n";
*                       eol1        = optSpace "\r";
*                       eol2        = optSpace "\n";
*                       eol3        = optSpace "\r\n";
*                       eol | eol1 | eol2 | eol3           {return(0);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  {FileName}
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpEOL
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpEOL(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif

{
   S16 yych;
   S16 yyret = -1;
   U16 yydecode = 0;
   

   TRC2(cmAbnfRegExpEOL)

   yych = cmAbnfGetChar(decCp->offset);
   switch(yych)
   {
   case '\n':   goto yy3;
   case '\r':   goto yy5;
   case ' ':   goto yy6;
   default:   goto yyErr;
   }
yy3:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
yy4:
   {
      yyret = 0;
      goto yyReturn;
   }
yy5:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy3;
   default:   goto yy4;
   }
yy6:
   (++yydecode);
   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy3;
   case '\r':   goto yy8;
   case ' ':   goto yy6;
   default:   goto yyErr;
   }
yy8:      (++yydecode);

   yych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   switch(yych)
   {
   case '\n':   goto yy3;
   default:   goto yy4;
   }



yyReturn:

yyErr:
   CM_ABNF_DECRET(decCp, yyret, yydecode, tknCons, len);
} /* cmAbnfRegExpEOL */


/*
*
*       Fun:   cmAbnfRegExpCRLF 
*
*       Desc:  Description for the regular expression for CRLF
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpCRLF 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpCRLF (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rcrlfyych;
   S16  rcrlfyyret = -1;
   U16 rcrlfyydecode = 0;

   TRC2(cmAbnfRegExpCRLF)

   rcrlfyych = cmAbnfGetChar(decCp->offset);

   switch(rcrlfyych)
   {
   case '\r':   goto rcrlfyy3;
   default:   goto rcrlfyyErr;
   }
rcrlfyy3:
   rcrlfyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rcrlfyydecode);

   switch(rcrlfyych)
   {
   case '\n':   goto rcrlfyy4;
   default:   goto rcrlfyyErr;
   }
rcrlfyy4:   
   rcrlfyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rcrlfyydecode);
   rcrlfyyret = 0;

rcrlfyyErr:
   CM_ABNF_DECRET(decCp, rcrlfyyret, rcrlfyydecode, tknCons, len);
   
} /* cmAbnfRegExpEOL */

/*
*
*       Fun:   cmAbnfRegExpOpenBrace 
*
*       Desc:  Description for the regular expression for Open Brace
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpOpenBrace 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpOpenBrace (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 robrcyych;

   TRC2(cmAbnfRegExpOpenBrace)

   robrcyych = cmAbnfGetChar(decCp->offset);

   switch(robrcyych)
   {
   case '(':   goto robrcyyReturn;
   default :   goto robrcyyErr;
   }
robrcyyReturn:
   if (tknCons)
      robrcyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

robrcyyErr:  
   return(-1);
} /* cmAbnfRegExpOpenBrace */


/*
*
*       Fun:   cmAbnfRegExpCloseBrace 
*
*       Desc:  Description for the regular expression for Close Brace
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpCloseBrace 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpCloseBrace (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rcbrcch;   /* 002.main_6 : change */

   TRC2(cmAbnfRegExpCloseBrace)

   rcbrcch = cmAbnfGetChar(decCp->offset);

   switch(rcbrcch)
   {
   case ')':       goto rcbrcReturn;
   default:   goto rcbrcErr;
   }
rcbrcReturn:
   if (tknCons)
      rcbrcch = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rcbrcErr:  
   return(-1);
} /* cmAbnfRegExpCloseBrace */


/*
*
*       Fun:   cmAbnfRegExpSlash 
*
*       Desc:  Description for the regular expression for Slash
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSlash 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpSlash (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rslhyych;

   TRC2(cmAbnfRegExpSlash)

   rslhyych = cmAbnfGetChar(decCp->offset);

   switch(rslhyych)
   {
   case '/':       goto rslhyyReturn;
   default:   goto rslhyyErr;
   }
rslhyyReturn:
   if (tknCons)
      rslhyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rslhyyErr:  
   return(-1);
} /* cmAbnfRegExpSlash */


/*
*
*       Fun:   cmAbnfRegExpSemiColon 
*
*       Desc:  Description for the regular expression for Semicolon
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSemiColon 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpSemiColon (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rsmicyych;

   TRC2(cmAbnfRegExpSemiColon)

   rsmicyych = cmAbnfGetChar(decCp->offset);

   switch(rsmicyych)
   {
   case ';':  goto rsmicyyReturn;
   default:   goto rsmicyyErr;
   }

rsmicyyReturn:
   if (tknCons)
      rsmicyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rsmicyyErr:  
   return(-1);
} /* cmAbnfRegExpSemiColon */


/*
*
*       Fun:   cmAbnfRegExpEqual 
*
*       Desc:  Description for the regular expression for Equal
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpEqual 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpEqual (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 reqyych;

   TRC2(cmAbnfRegExpEqual)

   reqyych = cmAbnfGetChar(decCp->offset);

   switch(reqyych)
   {
   case '=':       goto reqyyReturn;
   default:   goto reqyyErr;
   }
reqyyReturn:
   if (tknCons)
      reqyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

reqyyErr:  
   return(-1);
} /* cmAbnfRegExpEqual */


/*
*
*       Fun:   cmAbnfRegExpSpace 
*
*       Desc:  Description for the regular expression for Space
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpSpace 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpSpace (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rspcyych;
   S16  rspcyyret = -1;
   U16 rspcyydecode = 0;

   TRC2(cmAbnfRegExpSpace)

   rspcyych = cmAbnfGetChar(decCp->offset);
   switch(rspcyych)
   {
   case '\t':   case ' ':   goto rspcyy3;
   default:   goto rspcyyErr;
   }
rspcyy3:
   rspcyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rspcyydecode);

   switch(rspcyych)
   {
   case '\t':   case ' ':   goto rspcyy3;
   default:   goto rspcyyDef;
   }

rspcyyDef:
   rspcyyret = 0;

rspcyyErr:
   CM_ABNF_DECRET(decCp, rspcyyret, rspcyydecode, tknCons, len);
} /* cmAbnfRegExpSpace */


/*
*
*       Fun:   cmAbnfRegExpAt 
*
*       Desc:  Description for the regular expression for "@" 
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpAt 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpAt (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 ratyych;

   TRC2(cmAbnfRegExpAt)

   ratyych = cmAbnfGetChar(decCp->offset);

   switch(ratyych)
   {
   case '@':       goto ratyyReturn;
   default:   goto ratyyErr;
   }
ratyyReturn:
   if (tknCons)
      ratyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

ratyyErr:  
   return(-1);
} /* cmAbnfRegExpAt */


/*
*
*       Fun:   cmAbnfRegExpDot 
*
*       Desc:  Description for the regular expression for "."
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpDot 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpDot (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rdotyych;

   TRC2(cmAbnfRegExpDot)

   rdotyych = cmAbnfGetChar(decCp->offset);

   switch(rdotyych)
   {
   case '.':  goto rdotyyReturn;
   default:   goto rdotyyErr;
   }
rdotyyReturn:
   if (tknCons)
      rdotyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rdotyyErr:  
   return(-1);
} /* cmAbnfRegExpDot */


/*
*
*       Fun:   cmAbnfRegExpDquote 
*
*       Desc:  Description for the regular expression for double quote
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpDquote 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpDquote (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rqdqtyych;

   TRC2(cmAbnfRegExpDquote)

   rqdqtyych = cmAbnfGetChar(decCp->offset);

   switch(rqdqtyych)
   {
   case '"':       goto rqdqtyyReturn;
   default:   goto rqdqtyyErr;
   }
rqdqtyyReturn:
   if (tknCons)
      rqdqtyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rqdqtyyErr:  
   return(-1);
} /* cmAbnfRegExpDquote */


/*
*
*       Fun:   cmAbnfRegExpQuoteEsc 
*
*       Desc:  Description for the regular expression for escape quote sequence
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpQuoteEsc 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpQuoteEsc (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rqtescyych;
   S16  rqtescyyret = -1;
   U16 rqtescyydecode = 0;

   TRC2(cmAbnfRegExpQuoteEsc)

   rqtescyych = cmAbnfGetChar(decCp->offset);

   switch(rqtescyych)
   {
   case '"':       goto rqtescyy2;
   default:   goto rqtescyyErr;
   }
rqtescyy2:
   rqtescyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rqtescyydecode);

   switch(rqtescyych)
   {
   case '"':       goto rqtescyyReturn;
   default:   goto rqtescyyErr;
   }

rqtescyyReturn:
   rqtescyyret = 0;
   rqtescyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rqtescyydecode);

rqtescyyErr:  
   CM_ABNF_DECRET(decCp, rqtescyyret, rqtescyydecode, tknCons, len);
} /* cmAbnfRegExpQuoteEsc */

/*
*
*       Fun:   cmAbnfRegExpPipe 
*
*       Desc:  Description for the regular expression for Open Brace
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpPipe 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpPipe (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rpipeyych;

   TRC2(cmAbnfRegExpPipe)

   rpipeyych = cmAbnfGetChar(decCp->offset);

   switch(rpipeyych)
   {
   case '|':       goto rpipeyyReturn;
   default:   goto rpipeyyErr;
   }
rpipeyyReturn:
   if (tknCons)
      rpipeyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rpipeyyErr:  
   return(-1);
} /* cmAbnfRegExpPipe */


/*
*
*       Fun:   cmAbnfRegExpColon 
*
*       Desc:  Description for the regular expression for Colon
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpColon 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpColon (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rcolyych;

   TRC2(cmAbnfRegExpColon)

   rcolyych = cmAbnfGetChar(decCp->offset);

   switch(rcolyych)
   {
   case ':':  goto rcolyyReturn;
   default:   goto rcolyyErr;
   }
rcolyyReturn:
   if (tknCons)
      rcolyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   return(0);

rcolyyErr:  
   return(-1);
} /* cmAbnfRegExpColon */


/*
*
*       Fun:   cmAbnfRegExpAlpha 
*
*       Desc:  Description for the regular expression for alpha
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpAlpha 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpAlpha (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 ralphayych;
   S16  ralphayyret = -1;
   U16 ralphayydecode = 0;

   TRC2(cmAbnfRegExpAlpha)

   ralphayych = cmAbnfGetChar(decCp->offset);

   switch(ralphayych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':  goto ralphayy3;
   default:   goto ralphayyErr;
   }
ralphayy3:
   if(CM_ABNF_DEC_CHKLEN(len, ralphayydecode))
      goto ralphayyErr;
   CM_ABNF_DEC_CHCPY(memPtr, ralphayych);

   ralphayych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++ralphayydecode);

   switch(ralphayych)
   {
   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto ralphayy3;
   default :   goto ralphayyDef;
   }

ralphayyDef:
   ralphayyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, memPtr, len, ralphayydecode);

ralphayyErr:
   CM_ABNF_DECRET(decCp, ralphayyret, ralphayydecode, tknCons, len);

} /* cmAbnfRegExpAlpha */


/*
*
*       Fun:   cmAbnfRegExpStrChar 
*
*       Desc:  Description for the regular expression for string character
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpStrChar 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpStrChar (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 rstryych;
   S16  rstryyret = -1;
   U16 rstryydecode = 0;

   TRC2(cmAbnfRegExpStrChar)

   rstryych = cmAbnfGetChar(decCp->offset);

   if ((rstryych >= 0x20) && (rstryych <= 0x7e))
      goto rstryy3;
   else
      goto rstryyErr;
rstryy3:
   if(CM_ABNF_DEC_CHKLEN(len, rstryydecode))
      goto rstryyErr;
   CM_ABNF_DEC_CHCPY(memPtr, rstryych);

   rstryych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++rstryydecode);

   if ((rstryych >= 0x20) && (rstryych <= 0x7e))
      goto rstryy3;
   else
      goto rstryyDef;

rstryyDef:
   rstryyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, memPtr, len, rstryydecode);

rstryyErr:
   CM_ABNF_DECRET(decCp, rstryyret, rstryydecode, tknCons, len);

} /* cmAbnfRegExpStrChar */


/*
*
*       Fun:   cmAbnfRegExpAlDgChar 
*
*       Desc:  Description for the regular expression fora alpha digit 
*
*       Ret:   < 0 failure
               > 0  success 
*
*       Notes: None 
*
*       File: cmabnfrx.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmAbnfRegExpAlDgChar 
(
CmAbnfDecCp *decCp,             /* Decode control point */
Bool        tknCons,            /* Token to be consumed */
U8          **memPtr,           /* memory pointer */
U16         *len                /* length of the string returned */ 
)
#else
PUBLIC S16 cmAbnfRegExpAlDgChar (decCp, tknCons, memPtr, len)
CmAbnfDecCp *decCp;             /* Decode control point */
Bool        tknCons;            /* Token to be consumed */
U8          **memPtr;           /* memory pointer */
U16         *len;               /* length of the string returned */ 
#endif
{
   S16 raldgyych;
   S16  raldgyyret = -1;
   U16 raldgyydecode = 0;
   
   TRC2(cmAbnfRegExpAlDgChar)

   raldgyych = cmAbnfGetChar(decCp->offset);

   switch(raldgyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto raldgyy3;
   default :   goto raldgyyErr;
   }
raldgyy3:
   if(CM_ABNF_DEC_CHKLEN(len, raldgyydecode))
      goto raldgyyErr;
   CM_ABNF_DEC_CHCPY(memPtr, raldgyych);

   raldgyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++raldgyydecode);

   switch(raldgyych)
   {
   case '0':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':   case 'A':
   case 'B':
   case 'C':
   case 'D':
   case 'E':
   case 'F':
   case 'G':
   case 'H':
   case 'I':
   case 'J':
   case 'K':
   case 'L':
   case 'M':
   case 'N':
   case 'O':
   case 'P':
   case 'Q':
   case 'R':
   case 'S':
   case 'T':
   case 'U':
   case 'V':
   case 'W':
   case 'X':
   case 'Y':
   case 'Z':   case 'a':
   case 'b':
   case 'c':
   case 'd':
   case 'e':
   case 'f':
   case 'g':
   case 'h':
   case 'i':
   case 'j':
   case 'k':
   case 'l':
   case 'm':
   case 'n':
   case 'o':
   case 'p':
   case 'q':
   case 'r':
   case 's':
   case 't':
   case 'u':
   case 'v':
   case 'w':
   case 'x':
   case 'y':
   case 'z':   goto raldgyy3;
   default :   goto raldgyyDef;
   }

raldgyyDef:
   raldgyyret = 0;
   CM_ABNF_DEC_CSPSTRXL(decCp, memPtr, len, raldgyydecode);

raldgyyErr:
   CM_ABNF_DECRET(decCp, raldgyyret, raldgyydecode, tknCons, len);
} /* cmAbnfRegExpAlDgChar */ 


/*
*
*       Fun:   cmAbnfRegExpOpenAngleBrkt
*
*       Desc:  Description for the regular expression OpenAngleBrkt
*                "<"       {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  cmabnfrx.c
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpOpenAngleBrkt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpOpenAngleBrkt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 cmAbnfOpenAngleBrktyych;
   S16 cmAbnfOpenAngleBrktyyret = -1;
   U16 cmAbnfOpenAngleBrktyydecode = 0;

   TRC2(cmAbnfRegExpOpenAngleBrkt)

   cmAbnfOpenAngleBrktyych = cmAbnfGetChar(decCp->offset);
   switch(cmAbnfOpenAngleBrktyych)
   {
   case '<':   goto cmAbnfOpenAngleBrktyy3;
   default:   goto cmAbnfOpenAngleBrktyyErr;
   }
cmAbnfOpenAngleBrktyy3:   
   cmAbnfOpenAngleBrktyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++cmAbnfOpenAngleBrktyydecode);
   {
      cmAbnfOpenAngleBrktyyret = 1;
      goto cmAbnfOpenAngleBrktyyReturn;
   }


cmAbnfOpenAngleBrktyyReturn:

cmAbnfOpenAngleBrktyyErr:
   CM_ABNF_DECRET(decCp, cmAbnfOpenAngleBrktyyret, cmAbnfOpenAngleBrktyydecode, tknCons, len);
} /* cmAbnfRegExpOpenAngleBrkt */

/*
*
*       Fun:   cmAbnfRegExpCloseAngleBrkt
*
*       Desc:  Description for the regular expression CloseAngleBrkt
*                ">"       {return(1);}
*       Ret:  < 0 failure
*             > 0 success
*
*       Notes: none
*
*       File:  cmabnfrx.c
*
*/

#ifdef ANSI
PUBLIC S16 cmAbnfRegExpCloseAngleBrkt
(
CmAbnfDecCp *decCp,       /* Decode control point */
Bool        tknCons,      /* Token to be consumed? */
U8          **mem,        /* Memory pointer */
U16         *len          /* Length of the string returned */
)
#else
PUBLIC S16 cmAbnfRegExpCloseAngleBrkt(decCp, tknCons, mem, len)
CmAbnfDecCp *decCp;       /* Decode control point */
Bool        tknCons;      /* Token to be consumed? */
U8          **mem;        /* Memory pointer */
U16         *len;         /* Length of the string returned */
#endif
{
   S16 cmAbnfCloseAngleBrktyych;
   S16 cmAbnfCloseAngleBrktyyret = -1;
   U16 cmAbnfCloseAngleBrktyydecode = 0;

   TRC2(cmAbnfRegExpCloseAngleBrkt)

   cmAbnfCloseAngleBrktyych = cmAbnfGetChar(decCp->offset);
   switch(cmAbnfCloseAngleBrktyych)
   {
   case '>':   goto cmAbnfCloseAngleBrktyy3;
   default:   goto cmAbnfCloseAngleBrktyyErr;
   }
cmAbnfCloseAngleBrktyy3:   
   cmAbnfCloseAngleBrktyych = cmAbnfGetNxtChar(decCp->offset, decCp->numBytes);
   (++cmAbnfCloseAngleBrktyydecode);
   {
      cmAbnfCloseAngleBrktyyret = 1;
      goto cmAbnfCloseAngleBrktyyReturn;
   }


cmAbnfCloseAngleBrktyyReturn:

cmAbnfCloseAngleBrktyyErr:
   CM_ABNF_DECRET(decCp, cmAbnfCloseAngleBrktyyret, cmAbnfCloseAngleBrktyydecode, tknCons, len);
} /* cmAbnfRegExpCloseAngleBrkt */
  
/********************************************************************30**
  
         End of file:     cmabnfrx.c@@/main/9 - Wed Mar 30 08:42:56 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************80**
 
 
*********************************************************************81*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rm   1. initial release.

1.2          ---      kr   1. removed C++ compilation warnings
1.2+         001.102  bbk  1. Made cmAbnfRegExpXDgt case insensitive 
                              for hex-digits
1.2+         002.102  nct  1. EOL now accepts Cr, LF or CRLF.
/main/3      ---      nct  1. New release with GCp 1.2.
/main/4      ---      sk   1. RegExp cmAbnfRegExpEOL now accepts optional space
                              before "\r" | "\r\n" | "\n". 
/main/5      ---      ra   1. Added a new func - cmAbnfRegExpSDgt which eats up
                              signed integers
                           2. Added a new func - cmAbnfRegExpSXDgt which eats up
                              signed hexadecimal integers
/main/6      ---      ra   1. Fix for regular expression cmAbnfRegExpQuoteEsc
/main/7  001.main_6   ra   1. Changed ALL function definations to return S16
                              instead of S8. Changed the type of yyret type
                              variables to S16.
/main/8      ---      ra   1. Changed the type of stack var to return S16.
/main/9      ---      pk   1. GCP 1.5 release
*********************************************************************91*/
