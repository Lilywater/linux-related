/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP Convergence Layer (TUCL)
  
     Type:     C include file
  
     Desc:     Defines required at layer management interface (LHI)
  
     File:     lhi.h
  
     Sid:      lhi.h@@/main/4 - Thu Jun 28 13:31:22 2001
  
     Prg:      asa
  
*********************************************************************21*/
  
#ifndef __LHIH__
#define __LHIH__

/* hi009.104 - defining LHI interface version */
#ifdef LHIV1     /* LHI interface version 1 */
#ifdef LHIIFVER
#undef LHIIFVER
#endif
#define LHIIFVER   0x0100
#endif /* LHIV1 */

/***********************************************************************
           defines for "reason" in LhiStaInd
 ***********************************************************************/
#define  LHI_REASON_SOCKLIB_INIT_FAIL (LCM_REASON_LYR_SPECIFIC + 1)
#define  LHI_REASON_NO_SAP_FOUND      (LCM_REASON_LYR_SPECIFIC + 2)
#define  LHI_REASON_SOCK_FAIL         (LCM_REASON_LYR_SPECIFIC + 3)
#define  LHI_REASON_INV_SPID          (LCM_REASON_LYR_SPECIFIC + 4)
#define  LHI_REASON_INST0_NTREG       (LCM_REASON_LYR_SPECIFIC + 5)
#define  LHI_REASON_CREATE_RECVTSKS_FAILED (LCM_REASON_LYR_SPECIFIC + 6)
#define  LHI_REASON_LOCK_INIT_FAILED  (LCM_REASON_LYR_SPECIFIC + 7)
#define  LHI_REASON_NO_PENDOP         (LCM_REASON_LYR_SPECIFIC + 8)
#define  LHI_REASON_OPINPROG          (LCM_REASON_LYR_SPECIFIC + 9)
#define  LHI_REASON_INT_ERROR         (LCM_REASON_LYR_SPECIFIC + 10)
#define  LHI_REASON_WRONG_INST        (LCM_REASON_LYR_SPECIFIC + 11)
#define  LHI_REASON_DIFF_OPINPROG     (LCM_REASON_LYR_SPECIFIC + 12)

/***********************************************************************
           defines for "event" in LhiStaInd
 ***********************************************************************/
#define  LHI_EVENT_INET_ERR           (LCM_EVENT_LYR_SPECIFIC + 1) 
#define  LHI_EVENT_BNDREQ             (LCM_EVENT_LYR_SPECIFIC + 2) 
#define  LHI_EVENT_UBNDREQ            (LCM_EVENT_LYR_SPECIFIC + 3) 
#define  LHI_EVENT_SERVOPENREQ        (LCM_EVENT_LYR_SPECIFIC + 4) 
#define  LHI_EVENT_CONREQ             (LCM_EVENT_LYR_SPECIFIC + 5) 
#define  LHI_EVENT_CONRSP             (LCM_EVENT_LYR_SPECIFIC + 6) 
#define  LHI_EVENT_DATREQ             (LCM_EVENT_LYR_SPECIFIC + 7) 
#define  LHI_EVENT_UDATREQ            (LCM_EVENT_LYR_SPECIFIC + 8) 
#define  LHI_EVENT_DISCREQ            (LCM_EVENT_LYR_SPECIFIC + 10) 
#define  LHI_EVENT_TXQ_CONG_ON        (LCM_EVENT_LYR_SPECIFIC + 11) 
#define  LHI_EVENT_TXQ_CONG_DATA_DROP (LCM_EVENT_LYR_SPECIFIC + 12) 
#define  LHI_EVENT_TXQ_CONG_OFF       (LCM_EVENT_LYR_SPECIFIC + 13) 
#define  LHI_EVENT_INTERNAL_ERR       (LCM_EVENT_LYR_SPECIFIC + 14) 
#define  LHI_EVENT_RES_CONG_STRT      (LCM_EVENT_LYR_SPECIFIC + 15) 
#define  LHI_EVENT_RES_CONG_DROP      (LCM_EVENT_LYR_SPECIFIC + 16) 
#define  LHI_EVENT_RES_CONG_STOP      (LCM_EVENT_LYR_SPECIFIC + 17) 
#define  LHI_EVENT_RECVTHR_CLOSED     (LCM_EVENT_LYR_SPECIFIC + 18)
#define  LHI_EVENT_CNTRLREQ           (LCM_EVENT_LYR_SPECIFIC + 19)
#define  LHI_EVENT_GRPCNTRLREQ        (LCM_EVENT_LYR_SPECIFIC + 20)
#define  LHI_EVENT_SHTDWNREQ          (LCM_EVENT_LYR_SPECIFIC + 21)

/***********************************************************************
           defines for "cause" in LhiStaInd
 ***********************************************************************/
/* socket related errors */
#define  LHI_CAUSE_SOCK_ACPT_ERR      (LCM_CAUSE_LYR_SPECIFIC + 1)
#define  LHI_CAUSE_SOCK_RECV_ERR      (LCM_CAUSE_LYR_SPECIFIC + 2)
#define  LHI_CAUSE_SOCK_SEND_ERR      (LCM_CAUSE_LYR_SPECIFIC + 3)
#define  LHI_CAUSE_SOCK_CONN_ERR      (LCM_CAUSE_LYR_SPECIFIC + 4)
#define  LHI_CAUSE_SOCK_SLCT_ERR      (LCM_CAUSE_LYR_SPECIFIC + 5)
#define  LHI_CAUSE_INV_CON_STATE      (LCM_CAUSE_LYR_SPECIFIC + 6)
#define  LHI_CAUSE_CONID_NOT_AVAIL    (LCM_CAUSE_LYR_SPECIFIC + 7)
#define  LHI_CAUSE_INITLOCK_ERR       (LCM_CAUSE_LYR_SPECIFIC + 8)
#define  LHI_CAUSE_LOCK_ERR           (LCM_CAUSE_LYR_SPECIFIC + 9)
#define  LHI_CAUSE_UNLOCK_ERR         (LCM_CAUSE_LYR_SPECIFIC + 10)
#define  LHI_CAUSE_INTPRIM_ERR        (LCM_CAUSE_LYR_SPECIFIC + 11)


/***********************************************************************
        defines related to events across the management interface
 ***********************************************************************/

#define  EVTLHICFGREQ                 1
#define  EVTLHISTSREQ                 2
#define  EVTLHICNTRLREQ               3
#define  EVTLHISTAREQ                 4
#define  EVTLHICFGCFM                 5
#define  EVTLHISTSCFM                 6
#define  EVTLHICNTRLCFM               7
#define  EVTLHISTACFM                 8
#define  EVTLHISTAIND                 9
#define  EVTLHITRCIND                 10

#define LHI_TCP_TXED                  0
#define LHI_UDP_TXED                  1
#define LHI_TCP_RXED                  2
#define LHI_UDP_RXED                  3
#define LHI_RAW_TXED                  4
#define LHI_RAW_RXED                  5


/***********************************************************************
           defines related to events in LhiTrcInd primitive 
 ***********************************************************************/
/* alarmInfo.type */
#define LHI_ALARMINFO_TYPE_NTPRSNT    0  /* alarmInfo is not present */
#define LHI_ALARMINFO_SAP_STATE       1  /* SAP state */
#define LHI_ALARMINFO_CON_STATE       2  /* connection state */
#define LHI_ALARMINFO_MEM_ID          3  /* memory id */
#define LHI_ALARMINFO_PAR_TYPE        4  /* parameter type */
/* hi009.104 - added new define for RUG when interface is invalid */
#define LHI_ALARMINFO_TYPE_INFVER     5  /* invalid interface version */

/* parType values in LhiStaInd */
#define LHI_INV_MBUF                  1  /* invalid message buffer */
#define LHI_INV_SRVC_TYPE             2  /* invalid service type */
#define LHI_INV_TPT_ADDR              3  /* invalid transport address */
#define LHI_INV_TPT_PARAM             4  /* invalid transport parameters */
#define LHI_INV_ACTION                5  /* invalid action */
#ifdef HI_REL_1_3
#define LHI_INV_FILTER_TYPE_COMB      6  /* invalid filter/type/ combination 
                                          */
#ifdef IPV4_OPTS_SUPPORTED
#define LHI_INV_HDR_PARAM             7  /* invalid header parameters */
#endif /* IPV4_OPTS_SUPPORTED */
#endif /* HI_REL_1_3 */

/* selector values for lmPst.selector */
#define LHI_LC                        0   /* loosely coupled Layer Manager */
#define LHI_TC                        1   /* tightly coupled Layer Manager */

/* sap.state : sap states values */
#define HI_ST_UBND      0x1     /* state after SAP configuration */
#define HI_ST_BND       0x2     /* state after configuration and binding */

#define LHI_MAX_HDR_TYPE  5               /* maximum types of TCP application 
                                           * headers  supported on a TSAP */

/* hash defines for flag field in HiHdrinfo */
#define LHI_LEN_INCL_HDR    0x00000001    /* length in the header includes
                                           * pdu and header both
                                           */

#ifndef HI_REL_1_2
/* default values for numFdsPerSet and numFdBins */
#define LHI_NUM_FDS_PER_SET   1024
#define LHI_NUM_FD_BINS       4
#endif /* HI_REL_1_2 */

/* Error macro for TUCL management interface */
#define LHILOGERROR(pst, errCode, errVal, errDesc)            \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,  \
                  __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,   \
                  (ErrCode)errCode, (ErrVal)errVal,           \
                  (Txt*)errDesc)

/* hi009.104 - added for Rolling upgrade to zero out a buffer in lhi files */
#define LHI_ZERO(_str,_len)                              \
   cmMemset((U8 *)_str, 0, _len);
   
/* Error codes */
#define   ELHIBASE     0             /* reserved */
#define   ELHIXXX      (ELHIBASE)    /* reserved */
#define   ERRLHI       (ELHIBASE)

#define   ELHI001      (ERRLHI +    1)    /*        lhi.c: 180 */
#define   ELHI002      (ERRLHI +    2)    /*        lhi.c: 181 */
#define   ELHI003      (ERRLHI +    3)    /*        lhi.c: 182 */
#define   ELHI004      (ERRLHI +    4)    /*        lhi.c: 183 */
#define   ELHI005      (ERRLHI +    5)    /*        lhi.c: 184 */
#define   ELHI006      (ERRLHI +    6)    /*        lhi.c: 185 */
#define   ELHI007      (ERRLHI +    7)    /*        lhi.c: 186 */
#define   ELHI008      (ERRLHI +    8)    /*        lhi.c: 188 */
#define   ELHI009      (ERRLHI +    9)    /*        lhi.c: 189 */
#define   ELHI010      (ERRLHI +   10)    /*        lhi.c: 191 */
#define   ELHI011      (ERRLHI +   11)    /*        lhi.c: 193 */
#define   ELHI012      (ERRLHI +   12)    /*        lhi.c: 196 */
#define   ELHI013      (ERRLHI +   13)    /*        lhi.c: 197 */
#define   ELHI014      (ERRLHI +   14)    /*        lhi.c: 199 */
#define   ELHI015      (ERRLHI +   15)    /*        lhi.c: 200 */
#define   ELHI016      (ERRLHI +   16)    /*        lhi.c: 210 */
#define   ELHI017      (ERRLHI +   17)    /*        lhi.c: 211 */
#define   ELHI018      (ERRLHI +   18)    /*        lhi.c: 212 */
#define   ELHI019      (ERRLHI +   19)    /*        lhi.c: 213 */
#define   ELHI020      (ERRLHI +   20)    /*        lhi.c: 216 */
#define   ELHI021      (ERRLHI +   21)    /*        lhi.c: 217 */
#define   ELHI022      (ERRLHI +   22)    /*        lhi.c: 218 */
#define   ELHI023      (ERRLHI +   23)    /*        lhi.c: 219 */
#define   ELHI024      (ERRLHI +   24)    /*        lhi.c: 220 */
#define   ELHI025      (ERRLHI +   25)    /*        lhi.c: 221 */
#define   ELHI026      (ERRLHI +   26)    /*        lhi.c: 222 */
#define   ELHI027      (ERRLHI +   27)    /*        lhi.c: 223 */
#define   ELHI028      (ERRLHI +   28)    /*        lhi.c: 224 */
#define   ELHI029      (ERRLHI +   29)    /*        lhi.c: 225 */
#define   ELHI030      (ERRLHI +   30)    /*        lhi.c: 232 */
#define   ELHI031      (ERRLHI +   31)    /*        lhi.c: 239 */
#define   ELHI032      (ERRLHI +   32)    /*        lhi.c: 240 */
#define   ELHI033      (ERRLHI +   33)    /*        lhi.c: 280 */
#define   ELHI034      (ERRLHI +   34)    /*        lhi.c: 281 */
#define   ELHI035      (ERRLHI +   35)    /*        lhi.c: 330 */
#define   ELHI036      (ERRLHI +   36)    /*        lhi.c: 339 */
#define   ELHI037      (ERRLHI +   37)    /*        lhi.c: 341 */
#define   ELHI038      (ERRLHI +   38)    /*        lhi.c: 346 */
#define   ELHI039      (ERRLHI +   39)    /*        lhi.c: 351 */
#define   ELHI040      (ERRLHI +   40)    /*        lhi.c: 363 */
#define   ELHI041      (ERRLHI +   41)    /*        lhi.c: 368 */
#define   ELHI042      (ERRLHI +   42)    /*        lhi.c: 373 */
#define   ELHI043      (ERRLHI +   43)    /*        lhi.c: 378 */
#define   ELHI044      (ERRLHI +   44)    /*        lhi.c: 388 */
#define   ELHI045      (ERRLHI +   45)    /*        lhi.c: 395 */
#define   ELHI046      (ERRLHI +   46)    /*        lhi.c: 396 */
#define   ELHI047      (ERRLHI +   47)    /*        lhi.c: 397 */
#define   ELHI048      (ERRLHI +   48)    /*        lhi.c: 399 */
#define   ELHI049      (ERRLHI +   49)    /*        lhi.c: 400 */
#define   ELHI050      (ERRLHI +   50)    /*        lhi.c: 441 */
#define   ELHI051      (ERRLHI +   51)    /*        lhi.c: 444 */
#define   ELHI052      (ERRLHI +   52)    /*        lhi.c: 496 */
#define   ELHI053      (ERRLHI +   53)    /*        lhi.c: 501 */
#define   ELHI054      (ERRLHI +   54)    /*        lhi.c: 507 */
#define   ELHI055      (ERRLHI +   55)    /*        lhi.c: 508 */
#define   ELHI056      (ERRLHI +   56)    /*        lhi.c: 509 */
#define   ELHI057      (ERRLHI +   57)    /*        lhi.c: 557 */
#define   ELHI058      (ERRLHI +   58)    /*        lhi.c: 558 */
#define   ELHI059      (ERRLHI +   59)    /*        lhi.c: 560 */
#define   ELHI060      (ERRLHI +   60)    /*        lhi.c: 561 */
#define   ELHI061      (ERRLHI +   61)    /*        lhi.c: 562 */
#define   ELHI062      (ERRLHI +   62)    /*        lhi.c: 563 */
#define   ELHI063      (ERRLHI +   63)    /*        lhi.c: 564 */
#define   ELHI064      (ERRLHI +   64)    /*        lhi.c: 565 */
#define   ELHI065      (ERRLHI +   65)    /*        lhi.c: 566 */
#define   ELHI066      (ERRLHI +   66)    /*        lhi.c: 567 */
#define   ELHI067      (ERRLHI +   67)    /*        lhi.c: 568 */
#define   ELHI068      (ERRLHI +   68)    /*        lhi.c: 569 */
#define   ELHI069      (ERRLHI +   69)    /*        lhi.c: 570 */
#define   ELHI070      (ERRLHI +   70)    /*        lhi.c: 571 */
#define   ELHI071      (ERRLHI +   71)    /*        lhi.c: 572 */
#define   ELHI072      (ERRLHI +   72)    /*        lhi.c: 573 */
#define   ELHI073      (ERRLHI +   73)    /*        lhi.c: 574 */
#define   ELHI074      (ERRLHI +   74)    /*        lhi.c: 575 */
#define   ELHI075      (ERRLHI +   75)    /*        lhi.c: 576 */
#define   ELHI076      (ERRLHI +   76)    /*        lhi.c: 577 */
#define   ELHI077      (ERRLHI +   77)    /*        lhi.c: 584 */
#define   ELHI078      (ERRLHI +   78)    /*        lhi.c: 585 */
#define   ELHI079      (ERRLHI +   79)    /*        lhi.c: 587 */
#define   ELHI080      (ERRLHI +   80)    /*        lhi.c: 588 */
#define   ELHI081      (ERRLHI +   81)    /*        lhi.c: 589 */
#define   ELHI082      (ERRLHI +   82)    /*        lhi.c: 590 */
#define   ELHI083      (ERRLHI +   83)    /*        lhi.c: 591 */
#define   ELHI084      (ERRLHI +   84)    /*        lhi.c: 592 */
#define   ELHI085      (ERRLHI +   85)    /*        lhi.c: 593 */
#define   ELHI086      (ERRLHI +   86)    /*        lhi.c: 594 */
#define   ELHI087      (ERRLHI +   87)    /*        lhi.c: 599 */
#define   ELHI088      (ERRLHI +   88)    /*        lhi.c: 606 */
#define   ELHI089      (ERRLHI +   89)    /*        lhi.c: 607 */
#define   ELHI090      (ERRLHI +   90)    /*        lhi.c: 609 */
#define   ELHI091      (ERRLHI +   91)    /*        lhi.c: 610 */
#define   ELHI092      (ERRLHI +   92)    /*        lhi.c: 656 */
#define   ELHI093      (ERRLHI +   93)    /*        lhi.c: 660 */
#define   ELHI094      (ERRLHI +   94)    /*        lhi.c: 667 */
#define   ELHI095      (ERRLHI +   95)    /*        lhi.c: 668 */
#define   ELHI096      (ERRLHI +   96)    /*        lhi.c: 712 */
#define   ELHI097      (ERRLHI +   97)    /*        lhi.c: 719 */
#define   ELHI098      (ERRLHI +   98)    /*        lhi.c: 720 */
#define   ELHI099      (ERRLHI +   99)    /*        lhi.c: 725 */
#define   ELHI100      (ERRLHI +  100)    /*        lhi.c: 733 */
#define   ELHI101      (ERRLHI +  101)    /*        lhi.c: 735 */
#define   ELHI102      (ERRLHI +  102)    /*        lhi.c: 736 */
#define   ELHI103      (ERRLHI +  103)    /*        lhi.c: 784 */
#define   ELHI104      (ERRLHI +  104)    /*        lhi.c: 790 */
#define   ELHI105      (ERRLHI +  105)    /*        lhi.c: 792 */
#define   ELHI106      (ERRLHI +  106)    /*        lhi.c: 797 */
#define   ELHI107      (ERRLHI +  107)    /*        lhi.c: 802 */
#define   ELHI108      (ERRLHI +  108)    /*        lhi.c: 807 */
#define   ELHI109      (ERRLHI +  109)    /*        lhi.c: 814 */
#define   ELHI110      (ERRLHI +  110)    /*        lhi.c: 815 */
#define   ELHI111      (ERRLHI +  111)    /*        lhi.c: 816 */
#define   ELHI112      (ERRLHI +  112)    /*        lhi.c: 818 */
#define   ELHI113      (ERRLHI +  113)    /*        lhi.c: 819 */
#define   ELHI114      (ERRLHI +  114)    /*        lhi.c: 865 */
#define   ELHI115      (ERRLHI +  115)    /*        lhi.c: 866 */
#define   ELHI116      (ERRLHI +  116)    /*        lhi.c: 868 */
#define   ELHI117      (ERRLHI +  117)    /*        lhi.c: 869 */
#define   ELHI118      (ERRLHI +  118)    /*        lhi.c: 915 */
#define   ELHI119      (ERRLHI +  119)    /*        lhi.c: 916 */
#define   ELHI120      (ERRLHI +  120)    /*        lhi.c: 924 */
#define   ELHI121      (ERRLHI +  121)    /*        lhi.c: 925 */
#define   ELHI122      (ERRLHI +  122)    /*        lhi.c: 927 */
#define   ELHI123      (ERRLHI +  123)    /*        lhi.c: 928 */
#define   ELHI124      (ERRLHI +  124)    /*        lhi.c: 931 */
#define   ELHI125      (ERRLHI +  125)    /*        lhi.c: 933 */
#define   ELHI126      (ERRLHI +  126)    /*        lhi.c: 935 */
#define   ELHI127      (ERRLHI +  127)    /*        lhi.c: 936 */
#define   ELHI128      (ERRLHI +  128)    /*        lhi.c: 938 */
#define   ELHI129      (ERRLHI +  129)    /*        lhi.c: 939 */
#define   ELHI130      (ERRLHI +  130)    /*        lhi.c: 940 */
#define   ELHI131      (ERRLHI +  131)    /*        lhi.c: 941 */
#define   ELHI132      (ERRLHI +  132)    /*        lhi.c: 942 */
#define   ELHI133      (ERRLHI +  133)    /*        lhi.c: 943 */
#define   ELHI134      (ERRLHI +  134)    /*        lhi.c: 944 */
#define   ELHI135      (ERRLHI +  135)    /*        lhi.c: 952 */
#define   ELHI136      (ERRLHI +  136)    /*        lhi.c: 953 */
#define   ELHI137      (ERRLHI +  137)    /*        lhi.c: 954 */
#define   ELHI138      (ERRLHI +  138)    /*        lhi.c: 955 */
#define   ELHI139      (ERRLHI +  139)    /*        lhi.c: 956 */
#define   ELHI140      (ERRLHI +  140)    /*        lhi.c: 957 */
#define   ELHI141      (ERRLHI +  141)    /*        lhi.c: 958 */
#define   ELHI142      (ERRLHI +  142)    /*        lhi.c: 959 */
#define   ELHI143      (ERRLHI +  143)    /*        lhi.c: 960 */
#define   ELHI144      (ERRLHI +  144)    /*        lhi.c: 961 */
#define   ELHI145      (ERRLHI +  145)    /*        lhi.c: 965 */
#define   ELHI146      (ERRLHI +  146)    /*        lhi.c: 967 */
#define   ELHI147      (ERRLHI +  147)    /*        lhi.c: 969 */
#define   ELHI148      (ERRLHI +  148)    /*        lhi.c: 971 */
#define   ELHI149      (ERRLHI +  149)    /*        lhi.c: 978 */
#define   ELHI150      (ERRLHI +  150)    /*        lhi.c:1026 */
#define   ELHI151      (ERRLHI +  151)    /*        lhi.c:1027 */
#define   ELHI152      (ERRLHI +  152)    /*        lhi.c:1069 */
#define   ELHI153      (ERRLHI +  153)    /*        lhi.c:1070 */
#define   ELHI154      (ERRLHI +  154)    /*        lhi.c:1072 */
#define   ELHI155      (ERRLHI +  155)    /*        lhi.c:1073 */
#define   ELHI156      (ERRLHI +  156)    /*        lhi.c:1074 */
#define   ELHI157      (ERRLHI +  157)    /*        lhi.c:1083 */
#define   ELHI158      (ERRLHI +  158)    /*        lhi.c:1092 */
#define   ELHI159      (ERRLHI +  159)    /*        lhi.c:1097 */
#define   ELHI160      (ERRLHI +  160)    /*        lhi.c:1099 */
#define   ELHI161      (ERRLHI +  161)    /*        lhi.c:1104 */
#define   ELHI162      (ERRLHI +  162)    /*        lhi.c:1116 */
#define   ELHI163      (ERRLHI +  163)    /*        lhi.c:1121 */
#define   ELHI164      (ERRLHI +  164)    /*        lhi.c:1126 */
#define   ELHI165      (ERRLHI +  165)    /*        lhi.c:1131 */
#define   ELHI166      (ERRLHI +  166)    /*        lhi.c:1141 */
#define   ELHI167      (ERRLHI +  167)    /*        lhi.c:1187 */
#define   ELHI168      (ERRLHI +  168)    /*        lhi.c:1188 */
#define   ELHI169      (ERRLHI +  169)    /*        lhi.c:1232 */
#define   ELHI170      (ERRLHI +  170)    /*        lhi.c:1233 */
#define   ELHI171      (ERRLHI +  171)    /*        lhi.c:1234 */
#define   ELHI172      (ERRLHI +  172)    /*        lhi.c:1242 */
#define   ELHI173      (ERRLHI +  173)    /*        lhi.c:1248 */
#define   ELHI174      (ERRLHI +  174)    /*        lhi.c:1295 */
#define   ELHI175      (ERRLHI +  175)    /*        lhi.c:1296 */
#define   ELHI176      (ERRLHI +  176)    /*        lhi.c:1298 */
#define   ELHI177      (ERRLHI +  177)    /*        lhi.c:1299 */
#define   ELHI178      (ERRLHI +  178)    /*        lhi.c:1307 */
#define   ELHI179      (ERRLHI +  179)    /*        lhi.c:1308 */
#define   ELHI180      (ERRLHI +  180)    /*        lhi.c:1309 */
#define   ELHI181      (ERRLHI +  181)    /*        lhi.c:1310 */
#define   ELHI182      (ERRLHI +  182)    /*        lhi.c:1311 */
#define   ELHI183      (ERRLHI +  183)    /*        lhi.c:1312 */
#define   ELHI184      (ERRLHI +  184)    /*        lhi.c:1313 */
#define   ELHI185      (ERRLHI +  185)    /*        lhi.c:1314 */
#define   ELHI186      (ERRLHI +  186)    /*        lhi.c:1315 */
#define   ELHI187      (ERRLHI +  187)    /*        lhi.c:1316 */
#define   ELHI188      (ERRLHI +  188)    /*        lhi.c:1317 */
#define   ELHI189      (ERRLHI +  189)    /*        lhi.c:1318 */
#define   ELHI190      (ERRLHI +  190)    /*        lhi.c:1319 */
#define   ELHI191      (ERRLHI +  191)    /*        lhi.c:1320 */
#define   ELHI192      (ERRLHI +  192)    /*        lhi.c:1321 */
#define   ELHI193      (ERRLHI +  193)    /*        lhi.c:1322 */
#define   ELHI194      (ERRLHI +  194)    /*        lhi.c:1323 */
#define   ELHI195      (ERRLHI +  195)    /*        lhi.c:1324 */
#define   ELHI196      (ERRLHI +  196)    /*        lhi.c:1326 */
#define   ELHI197      (ERRLHI +  197)    /*        lhi.c:1327 */
#define   ELHI198      (ERRLHI +  198)    /*        lhi.c:1335 */
#define   ELHI199      (ERRLHI +  199)    /*        lhi.c:1336 */
#define   ELHI200      (ERRLHI +  200)    /*        lhi.c:1337 */
#define   ELHI201      (ERRLHI +  201)    /*        lhi.c:1338 */
#define   ELHI202      (ERRLHI +  202)    /*        lhi.c:1339 */
#define   ELHI203      (ERRLHI +  203)    /*        lhi.c:1340 */
#define   ELHI204      (ERRLHI +  204)    /*        lhi.c:1341 */
#define   ELHI205      (ERRLHI +  205)    /*        lhi.c:1342 */
#define   ELHI206      (ERRLHI +  206)    /*        lhi.c:1344 */
#define   ELHI207      (ERRLHI +  207)    /*        lhi.c:1345 */
#define   ELHI208      (ERRLHI +  208)    /*        lhi.c:1351 */
#define   ELHI209      (ERRLHI +  209)    /*        lhi.c:1397 */
#define   ELHI210      (ERRLHI +  210)    /*        lhi.c:1398 */
#define   ELHI211      (ERRLHI +  211)    /*        lhi.c:1406 */
#define   ELHI212      (ERRLHI +  212)    /*        lhi.c:1410 */
#define   ELHI213      (ERRLHI +  213)    /*        lhi.c:1458 */
#define   ELHI214      (ERRLHI +  214)    /*        lhi.c:1459 */
#define   ELHI215      (ERRLHI +  215)    /*        lhi.c:1460 */
#define   ELHI216      (ERRLHI +  216)    /*        lhi.c:1468 */
#define   ELHI217      (ERRLHI +  217)    /*        lhi.c:1475 */
#define   ELHI218      (ERRLHI +  218)    /*        lhi.c:1476 */
#define   ELHI219      (ERRLHI +  219)    /*        lhi.c:1481 */
#define   ELHI220      (ERRLHI +  220)    /*        lhi.c:1528 */
#define   ELHI221      (ERRLHI +  221)    /*        lhi.c:1529 */
#define   ELHI222      (ERRLHI +  222)    /*        lhi.c:1531 */
#define   ELHI223      (ERRLHI +  223)    /*        lhi.c:1532 */
#define   ELHI224      (ERRLHI +  224)    /*        lhi.c:1533 */
#define   ELHI225      (ERRLHI +  225)    /*        lhi.c:1541 */
#define   ELHI226      (ERRLHI +  226)    /*        lhi.c:1546 */
#define   ELHI227      (ERRLHI +  227)    /*        lhi.c:1551 */
#define   ELHI228      (ERRLHI +  228)    /*        lhi.c:1553 */
#define   ELHI229      (ERRLHI +  229)    /*        lhi.c:1558 */
#define   ELHI230      (ERRLHI +  230)    /*        lhi.c:1563 */
#define   ELHI231      (ERRLHI +  231)    /*        lhi.c:1612 */
#define   ELHI232      (ERRLHI +  232)    /*        lhi.c:1613 */
#define   ELHI233      (ERRLHI +  233)    /*        lhi.c:1615 */
#define   ELHI234      (ERRLHI +  234)    /*        lhi.c:1616 */

#endif /* __LHIH__ */
 

/********************************************************************30**
 
         End of file:     lhi.h@@/main/4 - Thu Jun 28 13:31:22 2001
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. added LHI_MAX_HDR_TYPE define.
/main/2       ---      cvp   1. added defines LHI_NUM_FDS_PER_SET and
                              LHI_NUM_FD_BINS.
                           2. changed the copyright header.
/main/4      ---      cvp  1. Updated error values.
/main/4      ---      cvp  1. Updated error values.
                           2. Multi-threaded TUCL related defines.
                           3. Changed the copyright header.
/main/4+   hi009.104  mmh  1. Rolling upgrade changes as per tcr0020.txt:
                              - LHI interface version info added under
                                compile flag LHIV1.
                              - added new alarm type for Invalid Interface 
                                version.
                              - added a new Macro LHI_ZERO similar to HI_ZERO
                                to initialize memory to all zeros.
*********************************************************************91*/

