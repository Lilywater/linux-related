/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     mtp 3 layer

     Type:     C include file

     Desc:     Defines required by the mtp 3 layer service user.

     File:     snt.h
  
     Sid:      snt.h@@/main/17 - Mon Nov  5 17:02:16 2001
 
     Prg:      na

*********************************************************************21*/

#ifndef __SNTH__
#define __SNTH__


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000028       SS7 - MTP Level 3
*
*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000029      SS7 - ISUP
*     1000030      SS7 - SCCP
*/



/* defines */
#ifdef SNTV1
/* define for interface version number */
#ifdef SNTIFVER
#undef SNTIFVER
#endif
#define SNTIFVER 0x0100 
#endif /* SNTV1 */


/* define for opc code */

#define SNT_OPC_NULL    0xffff   /* ignore the opc */

/* action for SnUiSntFlcReq and SnUiSntFlcInd */

#define SN_STARTFLC     0     /* Start Flow Control */
#define SN_ENDFLC       1     /* End Flow Control */

/* status for SnUiSntStaInd */

#define SN_PAUSE        1     /* Pause */
#define SN_RESUME       2     /* Resume */
#define SN_CONG         3     /* Network Congested */
#define SN_RMTUSRUNAV   4     /* Remote User Unavailable */
#define SN_RSTBEG       5     /* Restart Begins */
#define SN_RSTEND       6     /* Restart Ends */
#define SN_STPCONG      7     /* Stop Network Congestion */
#define SN_RESTRICT     8     /* Restrict */

/* event code for task to task header */

#define EVTSNTBNDREQ       0x04             /* Bind request */
 
#define EVTSNTUDATREQ      0x18             /* Unit data request */
#define EVTSNTUDATIND      0x1A             /* Unit data indication */

#define EVTSNTFLCREQ       0x28             /* Flow control request */
#define EVTSNTFLCIND       0x2A             /* Flow control indication */
                     
#define EVTSNTSTAIND       0x7A             /* Status indication */
#ifdef SNT2
#define EVTSNTSTAREQ       0x80             /* Status request */
#define EVTSNTSTACFM       0x81             /* Status confirmation */
#define EVTSNTBNDCFM       0x90             /* Bind confirmation */
#endif /* SNT2 */

/* Events for Interworking primitives in a Signaling Gateway */
#ifdef SNTIWF
#define EVTSNTSTAAPYREQ    0x91             /* Status Apply Request */
#define EVTSNTSTAAPYIND    0x92             /* Status Apply Indication */
#define EVTSNTSTAQRYREQ    0x93             /* Status Query Request */
#define EVTSNTSTAQRYIND    0x94             /* Status Query Indication */
#define EVTSNTSTAQRYRSP    0x95             /* Status Query Response */
#define EVTSNTSTAQRYCFM    0x96             /* Status Query Confirm */
#endif /* SNTIWF */

#ifdef SNT2
/* congLevel for status confirm */
#define SNT_CONG0              0            /* congestion level 0 */
#define SNT_CONG1              1            /* congestion level 1 */
#define SNT_CONG2              2            /* congestion level 2 */
#define SNT_CONG3              3            /* congestion level 3 */
#endif /* SNT2 */   

#define SNT_USR_UNKNOWN        0            /* remote user part unknown  */
#define SNT_USR_UNEQUIPPED     1            /* remote user part unequipped  */
#define SNT_USR_INACC          2            /* remote user part inaccessible  */

/* Macro for Error Logging */

#define SNTLOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, \
                   __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

#define ESNTBASE   0
#define ESNTXXX    (ESNTBASE)


#define   ESNT001      (ESNTBASE +    1)    /*        snt.c: 151 */
#define   ESNT002      (ESNTBASE +    2)    /*        snt.c: 157 */
#define   ESNT003      (ESNTBASE +    3)    /*        snt.c: 158 */
#define   ESNT004      (ESNTBASE +    4)    /*        snt.c: 159 */
#define   ESNT005      (ESNTBASE +    5)    /*        snt.c: 166 */
#define   ESNT006      (ESNTBASE +    6)    /*        snt.c: 216 */
#define   ESNT007      (ESNTBASE +    7)    /*        snt.c: 217 */
#define   ESNT008      (ESNTBASE +    8)    /*        snt.c: 218 */
#define   ESNT009      (ESNTBASE +    9)    /*        snt.c: 219 */
#define   ESNT010      (ESNTBASE +   10)    /*        snt.c: 220 */
#define   ESNT011      (ESNTBASE +   11)    /*        snt.c: 221 */
#define   ESNT012      (ESNTBASE +   12)    /*        snt.c: 231 */
#define   ESNT013      (ESNTBASE +   13)    /*        snt.c: 277 */
#define   ESNT014      (ESNTBASE +   14)    /*        snt.c: 280 */
#define   ESNT015      (ESNTBASE +   15)    /*        snt.c: 281 */
#define   ESNT016      (ESNTBASE +   16)    /*        snt.c: 291 */
#define   ESNT017      (ESNTBASE +   17)    /*        snt.c: 346 */
#define   ESNT018      (ESNTBASE +   18)    /*        snt.c: 347 */
#define   ESNT019      (ESNTBASE +   19)    /*        snt.c: 348 */
#define   ESNT020      (ESNTBASE +   20)    /*        snt.c: 349 */
#define   ESNT021      (ESNTBASE +   21)    /*        snt.c: 350 */
#define   ESNT022      (ESNTBASE +   22)    /*        snt.c: 389 */
#define   ESNT023      (ESNTBASE +   23)    /*        snt.c: 390 */
#define   ESNT024      (ESNTBASE +   24)    /*        snt.c: 432 */
#define   ESNT025      (ESNTBASE +   25)    /*        snt.c: 433 */
#define   ESNT026      (ESNTBASE +   26)    /*        snt.c: 434 */
#define   ESNT027      (ESNTBASE +   27)    /*        snt.c: 435 */
#define   ESNT028      (ESNTBASE +   28)    /*        snt.c: 478 */
#define   ESNT029      (ESNTBASE +   29)    /*        snt.c: 479 */
#define   ESNT030      (ESNTBASE +   30)    /*        snt.c: 480 */
#define   ESNT031      (ESNTBASE +   31)    /*        snt.c: 481 */
#define   ESNT032      (ESNTBASE +   32)    /*        snt.c: 521 */
#define   ESNT033      (ESNTBASE +   33)    /*        snt.c: 522 */
#define   ESNT034      (ESNTBASE +   34)    /*        snt.c: 573 */
#define   ESNT035      (ESNTBASE +   35)    /*        snt.c: 574 */
#define   ESNT036      (ESNTBASE +   36)    /*        snt.c: 575 */
#define   ESNT037      (ESNTBASE +   37)    /*        snt.c: 576 */
#define   ESNT038      (ESNTBASE +   38)    /*        snt.c: 577 */
#define   ESNT039      (ESNTBASE +   39)    /*        snt.c: 624 */
#define   ESNT040      (ESNTBASE +   40)    /*        snt.c: 627 */
#define   ESNT041      (ESNTBASE +   41)    /*        snt.c: 628 */
#define   ESNT042      (ESNTBASE +   42)    /*        snt.c: 629 */
#define   ESNT043      (ESNTBASE +   43)    /*        snt.c: 630 */
#define   ESNT044      (ESNTBASE +   44)    /*        snt.c: 674 */
#define   ESNT045      (ESNTBASE +   45)    /*        snt.c: 677 */
#define   ESNT046      (ESNTBASE +   46)    /*        snt.c: 678 */
#define   ESNT047      (ESNTBASE +   47)    /*        snt.c: 721 */
#define   ESNT048      (ESNTBASE +   48)    /*        snt.c: 724 */
#define   ESNT049      (ESNTBASE +   49)    /*        snt.c: 725 */
#define   ESNT050      (ESNTBASE +   50)    /*        snt.c: 774 */
#define   ESNT051      (ESNTBASE +   51)    /*        snt.c: 777 */
#define   ESNT052      (ESNTBASE +   52)    /*        snt.c: 778 */
#define   ESNT053      (ESNTBASE +   53)    /*        snt.c: 779 */
#define   ESNT054      (ESNTBASE +   54)    /*        snt.c: 780 */
#define   ESNT055      (ESNTBASE +   55)    /*        snt.c: 822 */
#define   ESNT056      (ESNTBASE +   56)    /*        snt.c: 825 */
#define   ESNT057      (ESNTBASE +   57)    /*        snt.c: 826 */
#define   ESNT058      (ESNTBASE +   58)    /*        snt.c: 876 */
#define   ESNT059      (ESNTBASE +   59)    /*        snt.c: 877 */
#define   ESNT060      (ESNTBASE +   60)    /*        snt.c: 878 */
#define   ESNT061      (ESNTBASE +   61)    /*        snt.c: 881 */
#define   ESNT062      (ESNTBASE +   62)    /*        snt.c: 882 */
#define   ESNT063      (ESNTBASE +   63)    /*        snt.c: 884 */
#define   ESNT064      (ESNTBASE +   64)    /*        snt.c: 885 */
#define   ESNT065      (ESNTBASE +   65)    /*        snt.c: 888 */
#define   ESNT066      (ESNTBASE +   66)    /*        snt.c: 890 */
#define   ESNT067      (ESNTBASE +   67)    /*        snt.c: 891 */
#define   ESNT068      (ESNTBASE +   68)    /*        snt.c: 892 */
#define   ESNT069      (ESNTBASE +   69)    /*        snt.c: 893 */
#define   ESNT070      (ESNTBASE +   70)    /*        snt.c: 894 */
#define   ESNT071      (ESNTBASE +   71)    /*        snt.c: 895 */
#define   ESNT072      (ESNTBASE +   72)    /*        snt.c: 941 */
#define   ESNT073      (ESNTBASE +   73)    /*        snt.c: 942 */
#define   ESNT074      (ESNTBASE +   74)    /*        snt.c: 943 */
#define   ESNT075      (ESNTBASE +   75)    /*        snt.c: 944 */
#define   ESNT076      (ESNTBASE +   76)    /*        snt.c: 945 */
#define   ESNT077      (ESNTBASE +   77)    /*        snt.c: 946 */
#define   ESNT078      (ESNTBASE +   78)    /*        snt.c: 986 */
#define   ESNT079      (ESNTBASE +   79)    /*        snt.c: 987 */
#define   ESNT080      (ESNTBASE +   80)    /*        snt.c:1027 */
#define   ESNT081      (ESNTBASE +   81)    /*        snt.c:1028 */

#endif /* _SNTH_ */

  
/********************************************************************30**
  
         End of file:     snt.h@@/main/17 - Mon Nov  5 17:02:16 2001
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
1.1             lc      1. initial release.
                jrl     2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

*********************************************************************71*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.2          ---  jrl   1. text changes

1.3          ---  bn    2. added define for SN_STPCONG for StaInd.

1.4          ---  bn    1. move MAXSNUI and MAXSNLI from sn.h

1.5          ---  jrl   1. text changes

1.6          ---  mc    1. move SN_PRI* from sn.h
             ---  jrl   2. text changes

1.7          ---  bn    1. changed MAXSNUI to 4.

1.8          ---  mc    1. removed MAXSNUI and MAXSNLI defines.

2.1          ---  mc    1. new interface
             ---  mc    2. define event codes for snt interface.
 
2.2          ---  mc    1. added SNT_OPC_NULL define.

2.3          ---  pm    1. moved SN_PRI* to cm_ss7.h

*********************************************************************81*/


/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
2.4          ---      pm   1. added defines for EVTSNTSTAREQ and EVTSNTSTACFM.
                           2. added defines for SNT_BND_OK and SNT_BND_NOK.
                           3. added defines for SNT_CONG0 to SBT_CONG3.
                           4. added SNTLOGERROR macro.
                      ash  5. SNT_BND_OK and SNT_BND_NOK are moved to
                              gen.h as CM_BND_OK and CM_BND_NOK
                           6. added error codes

2.5          ---      bn   1. added new defines for StaInd.
             ---      bn   2. changed header.

/main/15     ---      nj   1. Added defines for new primitive events at the SNT
                              interface for Signaling Gateway
/main/16     ---      nb   1. Rolling upgrade changes
/main/17     ---      nbh  1. Change for restriction support.
*********************************************************************91*/

