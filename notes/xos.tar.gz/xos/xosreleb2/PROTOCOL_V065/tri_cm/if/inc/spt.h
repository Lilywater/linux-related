/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**
  
     Name:     sccp layer
  
     Type:     C include file
  
     Desc:     Defines required by the sccp layer service user.
  
     File:     spt.h
  
     Sid:      spt.h@@/main/15 - Tue Jan 22 15:18:36 2002
     
     Prg:      fmg
  
*********************************************************************21*/

#ifndef __SPTH__
#define __SPTH__


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000030      SS7 - SCCP
*
*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------     ----------------------------------------------
*     1000029      SS7 - ISUP
*     1000031      SS7 - TCAP
*     1000180      SS7 - RANAP
*
*/


/* defining SPT interface version */
#ifdef SPTV1     /* SPT interface version 1 */
#ifdef SPTIFVER
#undef SPTIFVER
#endif
#define SPTIFVER   0x0100
#endif /* SPTV1 */

#ifdef SPTV2     /* SPT interface version 2 */
#ifdef SPTIFVER
#undef SPTIFVER
#endif
#define SPTIFVER   0x0200
#endif /* SPTV2 */

/*  spt_h_001.main_15  - addition - added interface version flag
 *  SPTV2_1.
 */
#ifdef SPTV2_1     /* SPT interface version 2_1 */

/* spt_h_002.main_15 - Addition - If SPTV2_1 is enabled enable all the lower
 * interface versions.
 */

#ifdef SPTV2
#undef SPTV2
#endif
#define SPTV2


#ifdef SPTIFVER
#undef SPTIFVER
#endif
#define SPTIFVER   0x0201
#endif /* SPTV2_1 */
/* if none of SPTV1 or SPTV2 is enabled, define
 * SPTIFVER as base version 0x0100
 */
#ifndef SPTIFVER
#define SPTIFVER 0x0100
#endif /* SPTIFVER */

/* defines */


/* return causes */

#define   RTC_NTBADADDR     0x00    /* No translation, address of such nature */
#define   RTC_NTSPECADDR    0x01    /* No translation, specific address */
#define   RTC_SSCONG        0x02    /* subsystem congestion */
#define   RTC_SSFAIL        0x03    /* subsystem failure */
#define   RTC_UNEQUIP       0x04    /* Unequiped User */
#define   RTC_NETFAIL       0x05    /* Network Failure */
#define   RTC_MTPFAIL       RTC_NETFAIL  /* MTP Failure */
#define   RTC_NETCONG       0x06    /* Network Congestion */
#define   RTC_UNQUAL        0x07    /* Unqualified */
#define   RTC_HOPVIOLATE    0x08    /* Hop counter violation (ANS92) */
#define   RTC_ERRMSGTPRT    0x08    /* Error in message transport (ITU92 
                                       & ANS96) */
#define   RTC_ERRLCLPROC    0x09    /* Error in local processing (ITU92 &
                                       ANS96 */
#define   RTC_NOREASSEMB    0x0a    /* Destination cannot perform reassembly
                                       (ITU92 & ANS96) */
#define   RTC_SCCPFAIL      0x0b    /* SCCP failure (ITU92) */
#define   RTC_HOPVIOLATE2   0x0c    /* Hop counter violation */
#define   RTC_NOSEGSPRT     0x0d    /* Segmentation not supported */
#define   RTC_SEGFAILURE    0x0e    /* Segmentation failure */
#define   RTC_MSGCHGFAIL    0xf7    /* Message change failure */
#define   RTC_INVINSRTREQ   0xf8    /* Invalid INS routing request */
#define   RTC_INVISNIRTREQ  0xf9    /* Invalid ISNI routing request */
#define   RTC_UNAUTHMSG     0xfa    /* Unauthorized message */
#define   RTC_INCOMPMSG     0xfb    /* Message incompatability */
#define   RTC_ISNICONRTFL   0xfc    /* Cannot perform ISNI constrained 
                                       routing */
#define   RTC_REDISNICONRT  0xfd    /* Redundant ISNI constrained routing
                                       information */
#define   RTC_UNISNIID      0xfe    /* Unable to perform ISNI identification */

/* Message return option */

#define   REC_NSO       0x00      /* No Special Options */
#define   REC_ROE       0x08      /* Return on Error */

/* GT, PC and SSN presence indicator */

#define   GT_PRES       0x01      /* global title present */
#define   GT_NPRES      0x00      /* global title not present */
#define   PC_PRES       0x01      /* Destination point code present */
#define   PC_NPRES      0x00      /* Destination point code not present */
#define   SSN_PRES      0x01      /* Subsystem number present */
#define   SSN_NPRES     0x00      /* Subsystem number not present */

/* Protocol Classes */

#define PCLASS0          0x00      /* Connectionless non-sequenced */
#define PCLASS1          0x01      /* Connectionless sequenced */
#define PCLASS2          0x02      /* Connection Oriented - basic */
#define PCLASS3          0x03      /* Connection Oriented - with flow control */

/* Release Causes */

#define RLC_EUORIG       0x00      /* end user originated */
#define RLC_EUCONG       0x01      /* end user congestion */
#define RLC_EUFAIL       0x02      /* end user failure */
#define RLC_SUFAIL       0x03      /* SCCP user failure */
#define RLC_REMPROC      0x04      /* Remote Procedure Error */
#define RLC_INCONDT      0x05      /* Inconnsistent Connection Data */
#define RLC_ACCFAIL      0x06      /* Access Failure */
#define RLC_ACCCONG      0x07      /* Access Congestion */
#define RLC_SSFAIL       0x08      /* Subsystem Failure */
#define RLC_SSCONG       0x09      /* Subsystem Congestion */
#define RLC_NETFAIL      0x0a      /* Network Failure */
#define RLC_MTPFAIL      RLC_NETFAIL    /* MTP Failure */
#define RLC_NETCONG      0x0b      /* Network Congestion */
#define RLC_EXRSTTMR     0x0c      /* Expiration of Reset Timer */
#define RLC_EXRIATMR     0x0d      /* Expiration of Receive Inactivity Timer */
#define RLC_NOTOBTN      0x0e      /* Not Obtainable */
#define RLC_UNQUAL       0x0f      /* Unqualified */
#define RLC_FAILSCCP     0x10      /* SCCP failure (ITU92) */

/* Reset Causes */

#define RSC_EUORIG       0x00  /* end user originated */
#define RSC_SUFAIL       0x01  /* SCCP user failure */
#define RSC_MOOINCPS     0x02  /* Message Out of Order, Incorrect P(S) */
#define RSC_MOOINCPR     0x03  /* Message Out of Order, Incorrect P(R) */
#define RSC_RPEMOW       0x04  /* Remote Procedure Error, Msg. out of Wdw */
#define RSC_RPEIPSR      0x05  /* Remote Procedure Error, Incorrect P(S) RI */
#define RSC_RPEGEN       0x06  /* Remote Procedure Error, General */
#define RSC_REUOP        0x07  /* Remote end User Operational */
#define RSC_NETOP        0x08  /* Network Operational */
#define RSC_ACCOP        0x09  /* Access Operational */
#define RSC_NETCONG      0x0a  /* Network Congestion */
#define RSC_NOTOBTN      0x0b  /* Not Obtainable */
#define RSC_UNQUAL       0x0c  /* Unqualified */

/* Error Causes */

#define ERR_LRNUD        0x00  /* LRN Unassigned Destination LRN */
#define ERR_LRNIS        0x01  /* LRN Inconsistent Source LRN */
#define ERR_PCMM         0x02  /* Point Code Mismatch */
#define ERR_SCMM         0x03  /* Service Class Mismatch */
#define ERR_UNQUAL       0x04  /* Unqualified */

/* Refusal  Causes */

#define RFC_EUORIG       0x00      /* end user originated */
#define RFC_EUCONG       0x01      /* end user congestion */
#define RFC_EUFAIL       0x02      /* end user failure */
#define RFC_SUFAIL       0x03      /* SCCP user failure */
#define RFC_DSTADRUK     0x04      /* Destination Address Unknown */
#define RFC_DSTADRIN     0x05      /* Destination Address Inaccessible */
#define RFC_NRQOSNT      0x06      /* Network Resouces QOS NA, non-transient */
#define RFC_NRQOST       0x07      /* Network Resouces QOS NA, transient */
#define RFC_ACCFAIL      0x08      /* Access Failure */
#define RFC_ACCCONG      0x09      /* Access Congestion */
#define RFC_SSFAIL       0x0a      /* Subsystem Failure */
#define RFC_SSCONG       0x0b      /* Subsystem Congestion */
#define RFC_EXCETMR      0x0c      /* Expiration Conn. Estab. Timer */
#define RFC_INCUDT       0x0d      /* Incompatible User Data */
#define RFC_NOTOBTN      0x0e      /* Not Obtainable */
#define RFC_UNQUAL       0x0f      /* Unqualified */
#define RFC_HOPVIOLATE   0x10      /* Hop counter violation */
#define RFC_SCCPFAIL     0x11      /* SCCP failure */
#define RFC_NTBADADDR    0x12      /* no translation for address */
#define RFC_UNEQUIP      0x13      /* unequipped user */

/* N-INFORM reasons */

#define INF_NSPFAIL      0x01      /* network service provider failure */
#define INF_NSPCONG      0x02      /* network service provider congestion */
#define INF_NSPQOS       0x03      /* network service provider QOS change */
#define INF_NSUFAIL      0x04      /* network service user failure */
#define INF_NSUCONG      0x05      /* network service user congestion */
#define INF_NSUQOS       0x06      /* network service user QOS change */
#define INF_UNSPEC       0x07      /* reason unspecified */

#define ORIG_NET         0x00      /* Network Originatied */
#define ORIG_USR         0x01      /* User Originatied */

/* "type" of information in the connection event structure */

#define CE_REQ0        0x00      /* type 0 (normal) */
#define CE_REQ1        0x01      /* type 1 ISUP  */
#define CE_REQ2        0x02      /* type 2 ISUP  */
#define CE_IND         0x03      /* connection indication */
#define CE_RESP        0x04      /* connection response */
#define CE_CFM         0x05      /* connection confirm */
#define CE_REP         0x06      /* reply (ISUP) */

/* Maximum allowable value of importance for SCCP messages */
#define MAXUDATIMP   6           /* maximum importance of UDT/XUDT/LUDT */
#ifdef SPCO
#define MAXCRIMP     4           /* maximum importance of CR */
#define MAXCCIMP     4           /* maximum importance of CC */
#define MAXCREFIMP   4           /* maximum importance of CREF */
#define MAXRLSDIMP   6           /* maximum importance of RLSD */
#define MAXDT1IMP    6           /* maximum importance of DT1 */
#define MAXDT2IMP    6           /* maximum importance of DT2 */
#endif /* SPCO */

/*
 * SPT Event Codes
 */

/*
 * Event codes 0xa? are unused in old products, so there
 * is no chance of overlap
 */
#define EVTSPTBNDREQ        0xa1     /* bind Request */
#define EVTSPTUBNDREQ       0xa2     /* unbind request */

#define EVTSPTUDATREQ       0xa3     /* unit data request */
#define EVTSPTUDATIND       0xb1     /* unit data indication */

#define EVTSPTSTAIND        0xb2     /* status indication */

#define EVTSPTCRDREQ        0xa4     /* coordinated request */
#define EVTSPTCRDIND        0xb3     /* coordinated indication */
#define EVTSPTCRDRSP        0xa5     /* coordinated response */
#define EVTSPTCRDCFM        0xb4     /* coordinated confirmation */

#define EVTSPTSTEREQ        0xa6     /* state request */
#define EVTSPTSTEIND        0xb5     /* state indication */

#define EVTSPTPCSTEIND      0xb6     /* pc state indication */

#ifdef SPCO
#define EVTSPTCONREQ        0xa7     /* connect request */
#define EVTSPTCONIND        0xb7     /* connection indication */
#define EVTSPTCONRSP        0xa8     /* connect response */
#define EVTSPTCONCFM        0xb8     /* connect confirm */

#define EVTSPTDATREQ        0xa9     /* data request */
#define EVTSPTDATIND        0xb9     /* data indication */

#define EVTSPTEDATREQ       0xaa     /* expedited data request */
#define EVTSPTEDATIND       0xba     /* expedited data indication */

#define EVTSPTRSTREQ        0xab     /* reset request */
#define EVTSPTRSTIND        0xbb     /* reset indication */
#define EVTSPTRSTRSP        0xac     /* reset response */
#define EVTSPTRSTCFM        0xbc     /* reset confirm */

#define EVTSPTDATACKREQ     0xad     /* data acknowledgement request */
#define EVTSPTDATACKIND     0xbd     /* data ack. ind. */

#define EVTSPTDISREQ        0xae     /* disconnect request */
#define EVTSPTDISIND        0xbe     /* disconnect indication */

#define EVTSPTCNSTREQ       0xaf     /* information request */
#define EVTSPTCNSTIND       0xbf     /* information indication */
#endif /* SPCO */

#ifdef SPT2
#define EVTSPTBNDCFM        0xc0     /* bind confirmation */
#define EVTSPTSTAREQ        0xc1     /* status request */
#define EVTSPTSTACFM        0xc2     /* status confirm */
#define EVTSPTSTECFM        0xc3     /* state confirm */
#endif /* SPT2 */

#define EVTSPTSTEAPYREQ     0xc4     /* sub-system state apply request */
#define EVTSPTSTEAPYIND     0xc5     /* sub-system state apply indication */
#define EVTSPTSTEAPYRSP     0xc6     /* sub-system state apply response */
#define EVTSPTSTEAPYCFM     0xc7     /* sub-system state apply confirmation */

#define EVTSPTSTEQRYREQ     0xc8     /* sub-system state query request */
#define EVTSPTSTEQRYIND     0xc9     /* sub-system state query indication */
#define EVTSPTSTEQRYRSP     0xca     /* sub-system state query response */
#define EVTSPTSTEQRYCFM     0xcb     /* sub-system state query confirmation */

#define EVTSPTPCSTEAPYREQ   0xcf     /* point code state apply request */
#define EVTSPTPCSTEAPYIND   0xd0     /* point code state apply indication */
#define EVTSPTPCSTEAPYRSP   0xd1     /* point code state apply response */
#define EVTSPTPCSTEAPYCFM   0xd2     /* point code state apply confirmation */

#define EVTSPTPCSTEQRYREQ   0xd3     /* point code state query request */
#define EVTSPTPCSTEQRYIND   0xd4     /* point code state query indication */
#define EVTSPTPCSTEQRYRSP   0xd5     /* point code state query response */
#define EVTSPTPCSTEQRYCFM   0xd6     /* point code state query confirmation */

#ifdef SPCO
#ifdef SPTV2
/* events for audit of signalling connection */
#define EVTSPTAUDREQ        0xd7     /* audit request */
#define EVTSPTAUDIND        0xd8     /* audit request */
#define EVTSPTAUDRSP        0xd9     /* audit request */
#define EVTSPTAUDCFM        0xda     /* audit confirm */
#endif /* SPTV2 */
#endif /* SPCO */
/* spt_h_001.main_15 - Addition - Event added for UDatSrvReq */
#ifdef SPTV2_1
#define EVTSPTUDATSRVREQ    0xdb     /* Unit Data Service Request */
#endif /* SPTV2_1 */

#ifdef SPCO
/* connection status - for audit of connections */
#define CON_STATE_INV   0xff              /* connection status: Non-existent */
#define CON_STATE_CON   0x01              /* connection status: connecting */
#define CON_STATE_DTX   0x02              /* connection status: data transfer */
#define CON_STATE_RLS   0x03              /* connection status: releasing */
#endif /* SPCO */

#ifdef SPT2
#define SPT_STATUS_PC  0x1               /* pointcode status */
#define SPT_STATUS_SS  0x2               /* subsystem status */
#endif /* SPT2 */


/* bits for compile flags */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#define SPT_SS7_ANS96_BIT   0x01      /* bit for compile flag SS7_ANS96 */
#define SPT_SS7_BELL05_BIT  0x02      /* bit for compile flag SS7_BELL05 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* default values of the primitive parameters introduced in SPTV2 */
#define SPTIF_VER2_STEIND_DEF_SCCPSTATE_VAL   0x00  /* remote sccp available */
#define SPTIF_VER2_STEIND_DEF_RIL_VAL         0     /* default RIL */


/* Macro for Error Logging */

#define SPTLOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, \
                  __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

#define SPT_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        SPTLOGERROR(ERRCLS_ADD_RES, e, (ErrVal) ret,"SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

#define ESPTBASE   0
#define ESPTXXX    (ESPTBASE)
#define ERRSPT     (ESPTBASE + 0)

#define   ESPT001      (ERRSPT +    1)    /*        spt.c: 895 */
#define   ESPT002      (ERRSPT +    2)    /*        spt.c: 896 */
#define   ESPT003      (ERRSPT +    3)    /*        spt.c: 897 */
#define   ESPT004      (ERRSPT +    4)    /*        spt.c: 945 */
#define   ESPT005      (ERRSPT +    5)    /*        spt.c: 948 */
#define   ESPT006      (ERRSPT +    6)    /*        spt.c: 949 */
#define   ESPT007      (ERRSPT +    7)    /*        spt.c: 950 */
#define   ESPT008      (ERRSPT +    8)    /*        spt.c: 951 */
#define   ESPT009      (ERRSPT +    9)    /*        spt.c: 992 */
#define   ESPT010      (ERRSPT +   10)    /*        spt.c: 994 */
#define   ESPT011      (ERRSPT +   11)    /*        spt.c: 995 */
#define   ESPT012      (ERRSPT +   12)    /*        spt.c: 996 */
#define   ESPT013      (ERRSPT +   13)    /*        spt.c:1038 */
#define   ESPT014      (ERRSPT +   14)    /*        spt.c:1040 */
#define   ESPT015      (ERRSPT +   15)    /*        spt.c:1041 */
#define   ESPT016      (ERRSPT +   16)    /*        spt.c:1042 */
#define   ESPT017      (ERRSPT +   17)    /*        spt.c:1088 */
#define   ESPT018      (ERRSPT +   18)    /*        spt.c:1090 */
#define   ESPT019      (ERRSPT +   19)    /*        spt.c:1091 */
#define   ESPT020      (ERRSPT +   20)    /*        spt.c:1092 */
#define   ESPT021      (ERRSPT +   21)    /*        spt.c:1093 */
#define   ESPT022      (ERRSPT +   22)    /*        spt.c:1094 */
#define   ESPT023      (ERRSPT +   23)    /*        spt.c:1149 */
#define   ESPT024      (ERRSPT +   24)    /*        spt.c:1164 */
#define   ESPT025      (ERRSPT +   25)    /*        spt.c:1165 */
#define   ESPT026      (ERRSPT +   26)    /*        spt.c:1166 */
#define   ESPT027      (ERRSPT +   27)    /*        spt.c:1171 */
#define   ESPT028      (ERRSPT +   28)    /*        spt.c:1172 */
#define   ESPT029      (ERRSPT +   29)    /*        spt.c:1174 */
#define   ESPT030      (ERRSPT +   30)    /*        spt.c:1175 */
#define   ESPT031      (ERRSPT +   31)    /*        spt.c:1176 */
#define   ESPT032      (ERRSPT +   32)    /*        spt.c:1223 */
#define   ESPT033      (ERRSPT +   33)    /*        spt.c:1225 */
#define   ESPT034      (ERRSPT +   34)    /*        spt.c:1226 */
#define   ESPT035      (ERRSPT +   35)    /*        spt.c:1264 */
#define   ESPT036      (ERRSPT +   36)    /*        spt.c:1266 */
#define   ESPT037      (ERRSPT +   37)    /*        spt.c:1267 */
#define   ESPT038      (ERRSPT +   38)    /*        spt.c:1327 */
#define   ESPT039      (ERRSPT +   39)    /*        spt.c:1342 */
#define   ESPT040      (ERRSPT +   40)    /*        spt.c:1343 */
#define   ESPT041      (ERRSPT +   41)    /*        spt.c:1344 */
#define   ESPT042      (ERRSPT +   42)    /*        spt.c:1345 */
#define   ESPT043      (ERRSPT +   43)    /*        spt.c:1346 */
#define   ESPT044      (ERRSPT +   44)    /*        spt.c:1347 */
#define   ESPT045      (ERRSPT +   45)    /*        spt.c:1352 */
#define   ESPT046      (ERRSPT +   46)    /*        spt.c:1353 */
#define   ESPT047      (ERRSPT +   47)    /*        spt.c:1355 */
#define   ESPT048      (ERRSPT +   48)    /*        spt.c:1356 */
#define   ESPT049      (ERRSPT +   49)    /*        spt.c:1357 */
#define   ESPT050      (ERRSPT +   50)    /*        spt.c:1358 */
#define   ESPT051      (ERRSPT +   51)    /*        spt.c:1359 */
#define   ESPT052      (ERRSPT +   52)    /*        spt.c:1360 */
#define   ESPT053      (ERRSPT +   53)    /*        spt.c:1411 */
#define   ESPT054      (ERRSPT +   54)    /*        spt.c:1415 */
#define   ESPT055      (ERRSPT +   55)    /*        spt.c:1455 */
#define   ESPT056      (ERRSPT +   56)    /*        spt.c:1460 */
#define   ESPT057      (ERRSPT +   57)    /*        spt.c:1513 */
#define   ESPT058      (ERRSPT +   58)    /*        spt.c:1514 */
#define   ESPT059      (ERRSPT +   59)    /*        spt.c:1525 */
#define   ESPT060      (ERRSPT +   60)    /*        spt.c:1526 */
#define   ESPT061      (ERRSPT +   61)    /*        spt.c:1571 */
#define   ESPT062      (ERRSPT +   62)    /*        spt.c:1610 */
#define   ESPT063      (ERRSPT +   63)    /*        spt.c:1612 */
#define   ESPT064      (ERRSPT +   64)    /*        spt.c:1651 */
#define   ESPT065      (ERRSPT +   65)    /*        spt.c:1653 */
#define   ESPT066      (ERRSPT +   66)    /*        spt.c:1654 */
#define   ESPT067      (ERRSPT +   67)    /*        spt.c:1655 */
#define   ESPT068      (ERRSPT +   68)    /*        spt.c:1693 */
#define   ESPT069      (ERRSPT +   69)    /*        spt.c:1695 */
#define   ESPT070      (ERRSPT +   70)    /*        spt.c:1696 */
#define   ESPT071      (ERRSPT +   71)    /*        spt.c:1697 */
#define   ESPT072      (ERRSPT +   72)    /*        spt.c:1750 */
#define   ESPT073      (ERRSPT +   73)    /*        spt.c:1757 */
#define   ESPT074      (ERRSPT +   74)    /*        spt.c:1758 */
#define   ESPT075      (ERRSPT +   75)    /*        spt.c:1763 */
#define   ESPT076      (ERRSPT +   76)    /*        spt.c:1767 */
#define   ESPT077      (ERRSPT +   77)    /*        spt.c:1779 */
#define   ESPT078      (ERRSPT +   78)    /*        spt.c:1780 */
#define   ESPT079      (ERRSPT +   79)    /*        spt.c:1785 */
#define   ESPT080      (ERRSPT +   80)    /*        spt.c:1789 */
#define   ESPT081      (ERRSPT +   81)    /*        spt.c:1833 */
#define   ESPT082      (ERRSPT +   82)    /*        spt.c:1835 */
#define   ESPT083      (ERRSPT +   83)    /*        spt.c:1836 */
#define   ESPT084      (ERRSPT +   84)    /*        spt.c:1837 */
#define   ESPT085      (ERRSPT +   85)    /*        spt.c:1890 */
#define   ESPT086      (ERRSPT +   86)    /*        spt.c:1891 */
#define   ESPT087      (ERRSPT +   87)    /*        spt.c:1892 */
#define   ESPT088      (ERRSPT +   88)    /*        spt.c:1931 */
#define   ESPT089      (ERRSPT +   89)    /*        spt.c:1932 */
#define   ESPT090      (ERRSPT +   90)    /*        spt.c:1973 */
#define   ESPT091      (ERRSPT +   91)    /*        spt.c:1974 */
#define   ESPT092      (ERRSPT +   92)    /*        spt.c:2014 */
#define   ESPT093      (ERRSPT +   93)    /*        spt.c:2015 */
#define   ESPT094      (ERRSPT +   94)    /*        spt.c:2056 */
#define   ESPT095      (ERRSPT +   95)    /*        spt.c:2057 */
#define   ESPT096      (ERRSPT +   96)    /*        spt.c:2098 */
#define   ESPT097      (ERRSPT +   97)    /*        spt.c:2099 */
#define   ESPT098      (ERRSPT +   98)    /*        spt.c:2100 */
#define   ESPT099      (ERRSPT +   99)    /*        spt.c:2143 */
#define   ESPT100      (ERRSPT +  100)    /*        spt.c:2144 */
#define   ESPT101      (ERRSPT +  101)    /*        spt.c:2145 */
#define   ESPT102      (ERRSPT +  102)    /*        spt.c:2146 */
#define   ESPT103      (ERRSPT +  103)    /*        spt.c:2188 */
#define   ESPT104      (ERRSPT +  104)    /*        spt.c:2236 */
#define   ESPT105      (ERRSPT +  105)    /*        spt.c:2296 */
#define   ESPT106      (ERRSPT +  106)    /*        spt.c:2297 */
#define   ESPT107      (ERRSPT +  107)    /*        spt.c:2305 */
#define   ESPT108      (ERRSPT +  108)    /*        spt.c:2306 */
#define   ESPT109      (ERRSPT +  109)    /*        spt.c:2359 */
#define   ESPT110      (ERRSPT +  110)    /*        spt.c:2398 */
#define   ESPT111      (ERRSPT +  111)    /*        spt.c:2437 */
#define   ESPT112      (ERRSPT +  112)    /*        spt.c:2438 */
#define   ESPT113      (ERRSPT +  113)    /*        spt.c:2439 */
#define   ESPT114      (ERRSPT +  114)    /*        spt.c:2480 */
#define   ESPT115      (ERRSPT +  115)    /*        spt.c:2481 */
#define   ESPT116      (ERRSPT +  116)    /*        spt.c:2482 */
#define   ESPT117      (ERRSPT +  117)    /*        spt.c:2537 */
#define   ESPT118      (ERRSPT +  118)    /*        spt.c:2538 */
#define   ESPT119      (ERRSPT +  119)    /*        spt.c:2539 */
#define   ESPT120      (ERRSPT +  120)    /*        spt.c:2540 */
#define   ESPT121      (ERRSPT +  121)    /*        spt.c:2548 */
#define   ESPT122      (ERRSPT +  122)    /*        spt.c:2549 */
#define   ESPT123      (ERRSPT +  123)    /*        spt.c:2550 */
#define   ESPT124      (ERRSPT +  124)    /*        spt.c:2551 */
#define   ESPT125      (ERRSPT +  125)    /*        spt.c:2611 */
#define   ESPT126      (ERRSPT +  126)    /*        spt.c:2612 */
#define   ESPT127      (ERRSPT +  127)    /*        spt.c:2613 */
#define   ESPT128      (ERRSPT +  128)    /*        spt.c:2655 */
#define   ESPT129      (ERRSPT +  129)    /*        spt.c:2657 */
#define   ESPT130      (ERRSPT +  130)    /*        spt.c:2658 */
#define   ESPT131      (ERRSPT +  131)    /*        spt.c:2659 */
#define   ESPT132      (ERRSPT +  132)    /*        spt.c:2700 */
#define   ESPT133      (ERRSPT +  133)    /*        spt.c:2702 */
#define   ESPT134      (ERRSPT +  134)    /*        spt.c:2703 */
#define   ESPT135      (ERRSPT +  135)    /*        spt.c:2745 */
#define   ESPT136      (ERRSPT +  136)    /*        spt.c:2746 */
#define   ESPT137      (ERRSPT +  137)    /*        spt.c:2787 */
#define   ESPT138      (ERRSPT +  138)    /*        spt.c:2789 */
#define   ESPT139      (ERRSPT +  139)    /*        spt.c:2790 */
#define   ESPT140      (ERRSPT +  140)    /*        spt.c:2831 */
#define   ESPT141      (ERRSPT +  141)    /*        spt.c:2833 */
#define   ESPT142      (ERRSPT +  142)    /*        spt.c:2834 */
#define   ESPT143      (ERRSPT +  143)    /*        spt.c:2877 */
#define   ESPT144      (ERRSPT +  144)    /*        spt.c:2879 */
#define   ESPT145      (ERRSPT +  145)    /*        spt.c:2880 */
#define   ESPT146      (ERRSPT +  146)    /*        spt.c:2881 */
#define   ESPT147      (ERRSPT +  147)    /*        spt.c:2928 */
#define   ESPT148      (ERRSPT +  148)    /*        spt.c:2930 */
#define   ESPT149      (ERRSPT +  149)    /*        spt.c:2931 */
#define   ESPT150      (ERRSPT +  150)    /*        spt.c:2932 */
#define   ESPT151      (ERRSPT +  151)    /*        spt.c:2933 */
#define   ESPT152      (ERRSPT +  152)    /*        spt.c:2976 */
#define   ESPT153      (ERRSPT +  153)    /*        spt.c:2977 */
#define   ESPT154      (ERRSPT +  154)    /*        spt.c:2978 */
#define   ESPT155      (ERRSPT +  155)    /*        spt.c:3020 */
#define   ESPT156      (ERRSPT +  156)    /*        spt.c:3021 */
#define   ESPT157      (ERRSPT +  157)    /*        spt.c:3022 */
#define   ESPT158      (ERRSPT +  158)    /*        spt.c:3023 */
#define   ESPT159      (ERRSPT +  159)    /*        spt.c:3064 */
#define   ESPT160      (ERRSPT +  160)    /*        spt.c:3065 */
#define   ESPT161      (ERRSPT +  161)    /*        spt.c:3066 */
#define   ESPT162      (ERRSPT +  162)    /*        spt.c:3109 */
#define   ESPT163      (ERRSPT +  163)    /*        spt.c:3110 */
#define   ESPT164      (ERRSPT +  164)    /*        spt.c:3111 */
#define   ESPT165      (ERRSPT +  165)    /*        spt.c:3156 */
#define   ESPT166      (ERRSPT +  166)    /*        spt.c:3157 */
#define   ESPT167      (ERRSPT +  167)    /*        spt.c:3158 */
#define   ESPT168      (ERRSPT +  168)    /*        spt.c:3159 */
#define   ESPT169      (ERRSPT +  169)    /*        spt.c:3160 */
#define   ESPT170      (ERRSPT +  170)    /*        spt.c:3221 */
#define   ESPT171      (ERRSPT +  171)    /*        spt.c:3222 */
#define   ESPT172      (ERRSPT +  172)    /*        spt.c:3223 */
#define   ESPT173      (ERRSPT +  173)    /*        spt.c:3232 */
#define   ESPT174      (ERRSPT +  174)    /*        spt.c:3233 */
#define   ESPT175      (ERRSPT +  175)    /*        spt.c:3234 */
#define   ESPT176      (ERRSPT +  176)    /*        spt.c:3236 */
#define   ESPT177      (ERRSPT +  177)    /*        spt.c:3237 */
#define   ESPT178      (ERRSPT +  178)    /*        spt.c:3291 */
#define   ESPT179      (ERRSPT +  179)    /*        spt.c:3292 */
#define   ESPT180      (ERRSPT +  180)    /*        spt.c:3334 */
#define   ESPT181      (ERRSPT +  181)    /*        spt.c:3335 */
#define   ESPT182      (ERRSPT +  182)    /*        spt.c:3399 */
#define   ESPT183      (ERRSPT +  183)    /*        spt.c:3400 */
#define   ESPT184      (ERRSPT +  184)    /*        spt.c:3401 */
#define   ESPT185      (ERRSPT +  185)    /*        spt.c:3402 */
#define   ESPT186      (ERRSPT +  186)    /*        spt.c:3403 */
#define   ESPT187      (ERRSPT +  187)    /*        spt.c:3404 */
#define   ESPT188      (ERRSPT +  188)    /*        spt.c:3413 */
#define   ESPT189      (ERRSPT +  189)    /*        spt.c:3414 */
#define   ESPT190      (ERRSPT +  190)    /*        spt.c:3415 */
#define   ESPT191      (ERRSPT +  191)    /*        spt.c:3416 */
#define   ESPT192      (ERRSPT +  192)    /*        spt.c:3417 */
#define   ESPT193      (ERRSPT +  193)    /*        spt.c:3418 */
#define   ESPT194      (ERRSPT +  194)    /*        spt.c:3420 */
#define   ESPT195      (ERRSPT +  195)    /*        spt.c:3421 */
#define   ESPT196      (ERRSPT +  196)    /*        spt.c:3476 */
#define   ESPT197      (ERRSPT +  197)    /*        spt.c:3479 */
#define   ESPT198      (ERRSPT +  198)    /*        spt.c:3520 */
#define   ESPT199      (ERRSPT +  199)    /*        spt.c:3523 */
#define   ESPT200      (ERRSPT +  200)    /*        spt.c:3575 */
#define   ESPT201      (ERRSPT +  201)    /*        spt.c:3576 */
#define   ESPT202      (ERRSPT +  202)    /*        spt.c:3587 */
#define   ESPT203      (ERRSPT +  203)    /*        spt.c:3588 */
#define   ESPT204      (ERRSPT +  204)    /*        spt.c:3633 */
#define   ESPT205      (ERRSPT +  205)    /*        spt.c:3672 */
#define   ESPT206      (ERRSPT +  206)    /*        spt.c:3674 */
#define   ESPT207      (ERRSPT +  207)    /*        spt.c:3711 */
#define   ESPT208      (ERRSPT +  208)    /*        spt.c:3713 */
#define   ESPT209      (ERRSPT +  209)    /*        spt.c:3714 */
#define   ESPT210      (ERRSPT +  210)    /*        spt.c:3715 */
#define   ESPT211      (ERRSPT +  211)    /*        spt.c:3752 */
#define   ESPT212      (ERRSPT +  212)    /*        spt.c:3754 */
#define   ESPT213      (ERRSPT +  213)    /*        spt.c:3755 */
#define   ESPT214      (ERRSPT +  214)    /*        spt.c:3756 */
#define   ESPT215      (ERRSPT +  215)    /*        spt.c:3808 */
#define   ESPT216      (ERRSPT +  216)    /*        spt.c:3815 */
#define   ESPT217      (ERRSPT +  217)    /*        spt.c:3816 */
#define   ESPT218      (ERRSPT +  218)    /*        spt.c:3818 */
#define   ESPT219      (ERRSPT +  219)    /*        spt.c:3830 */
#define   ESPT220      (ERRSPT +  220)    /*        spt.c:3831 */
#define   ESPT221      (ERRSPT +  221)    /*        spt.c:3833 */
#define   ESPT222      (ERRSPT +  222)    /*        spt.c:3878 */
#define   ESPT223      (ERRSPT +  223)    /*        spt.c:3880 */
#define   ESPT224      (ERRSPT +  224)    /*        spt.c:3881 */
#define   ESPT225      (ERRSPT +  225)    /*        spt.c:3882 */
#define   ESPT226      (ERRSPT +  226)    /*        spt.c:3921 */
#define   ESPT227      (ERRSPT +  227)    /*        spt.c:3923 */
#define   ESPT228      (ERRSPT +  228)    /*        spt.c:3924 */
#define   ESPT229      (ERRSPT +  229)    /*        spt.c:3963 */
#define   ESPT230      (ERRSPT +  230)    /*        spt.c:3964 */
#define   ESPT231      (ERRSPT +  231)    /*        spt.c:4003 */
#define   ESPT232      (ERRSPT +  232)    /*        spt.c:4005 */
#define   ESPT233      (ERRSPT +  233)    /*        spt.c:4006 */
#define   ESPT234      (ERRSPT +  234)    /*        spt.c:4045 */
#define   ESPT235      (ERRSPT +  235)    /*        spt.c:4046 */
#define   ESPT236      (ERRSPT +  236)    /*        spt.c:4085 */
#define   ESPT237      (ERRSPT +  237)    /*        spt.c:4087 */
#define   ESPT238      (ERRSPT +  238)    /*        spt.c:4088 */
#define   ESPT239      (ERRSPT +  239)    /*        spt.c:4128 */
#define   ESPT240      (ERRSPT +  240)    /*        spt.c:4129 */
#define   ESPT241      (ERRSPT +  241)    /*        spt.c:4168 */
#define   ESPT242      (ERRSPT +  242)    /*        spt.c:4170 */
#define   ESPT243      (ERRSPT +  243)    /*        spt.c:4171 */
#define   ESPT244      (ERRSPT +  244)    /*        spt.c:4210 */
#define   ESPT245      (ERRSPT +  245)    /*        spt.c:4211 */
#define   ESPT246      (ERRSPT +  246)    /*        spt.c:4253 */
#define   ESPT247      (ERRSPT +  247)    /*        spt.c:4299 */
#define   ESPT248      (ERRSPT +  248)    /*        spt.c:4358 */
#define   ESPT249      (ERRSPT +  249)    /*        spt.c:4359 */
#define   ESPT250      (ERRSPT +  250)    /*        spt.c:4367 */
#define   ESPT251      (ERRSPT +  251)    /*        spt.c:4368 */
#define   ESPT252      (ERRSPT +  252)    /*        spt.c:4418 */
#define   ESPT253      (ERRSPT +  253)    /*        spt.c:4456 */
#define   ESPT254      (ERRSPT +  254)    /*        spt.c:4495 */
#define   ESPT255      (ERRSPT +  255)    /*        spt.c:4496 */
#define   ESPT256      (ERRSPT +  256)    /*        spt.c:4497 */
#define   ESPT257      (ERRSPT +  257)    /*        spt.c:4536 */
#define   ESPT258      (ERRSPT +  258)    /*        spt.c:4537 */
#define   ESPT259      (ERRSPT +  259)    /*        spt.c:4538 */
#define   ESPT260      (ERRSPT +  260)    /*        spt.c:4593 */
#define   ESPT261      (ERRSPT +  261)    /*        spt.c:4594 */
#define   ESPT262      (ERRSPT +  262)    /*        spt.c:4595 */
#define   ESPT263      (ERRSPT +  263)    /*        spt.c:4596 */
#define   ESPT264      (ERRSPT +  264)    /*        spt.c:4604 */
#define   ESPT265      (ERRSPT +  265)    /*        spt.c:4605 */
#define   ESPT266      (ERRSPT +  266)    /*        spt.c:4606 */
#define   ESPT267      (ERRSPT +  267)    /*        spt.c:4607 */
#define   ESPT268      (ERRSPT +  268)    /*        spt.c:4666 */
#define   ESPT269      (ERRSPT +  269)    /*        spt.c:4667 */
#define   ESPT270      (ERRSPT +  270)    /*        spt.c:4668 */
#define   ESPT271      (ERRSPT +  271)    /*        spt.c:4715 */
#define   ESPT272      (ERRSPT +  272)    /*        spt.c:4717 */
#define   ESPT273      (ERRSPT +  273)    /*        spt.c:4718 */
#define   ESPT274      (ERRSPT +  274)    /*        spt.c:4719 */
#define   ESPT275      (ERRSPT +  275)    /*        spt.c:4720 */
#define   ESPT276      (ERRSPT +  276)    /*        spt.c:4764 */
#define   ESPT277      (ERRSPT +  277)    /*        spt.c:4766 */
#define   ESPT278      (ERRSPT +  278)    /*        spt.c:4767 */
#define   ESPT279      (ERRSPT +  279)    /*        spt.c:4768 */
#define   ESPT280      (ERRSPT +  280)    /*        spt.c:4769 */
#define   ESPT281      (ERRSPT +  281)    /*        spt.c:4815 */
#define   ESPT282      (ERRSPT +  282)    /*        spt.c:4817 */
#define   ESPT283      (ERRSPT +  283)    /*        spt.c:4818 */
#define   ESPT284      (ERRSPT +  284)    /*        spt.c:4819 */
#define   ESPT285      (ERRSPT +  285)    /*        spt.c:4820 */
#define   ESPT286      (ERRSPT +  286)    /*        spt.c:4821 */
#define   ESPT287      (ERRSPT +  287)    /*        spt.c:4867 */
#define   ESPT288      (ERRSPT +  288)    /*        spt.c:4869 */
#define   ESPT289      (ERRSPT +  289)    /*        spt.c:4870 */
#define   ESPT290      (ERRSPT +  290)    /*        spt.c:4871 */
#define   ESPT291      (ERRSPT +  291)    /*        spt.c:4872 */
#define   ESPT292      (ERRSPT +  292)    /*        spt.c:4873 */
#define   ESPT293      (ERRSPT +  293)    /*        spt.c:4915 */
#define   ESPT294      (ERRSPT +  294)    /*        spt.c:4917 */
#define   ESPT295      (ERRSPT +  295)    /*        spt.c:4918 */
#define   ESPT296      (ERRSPT +  296)    /*        spt.c:4919 */
#define   ESPT297      (ERRSPT +  297)    /*        spt.c:4961 */
#define   ESPT298      (ERRSPT +  298)    /*        spt.c:4963 */
#define   ESPT299      (ERRSPT +  299)    /*        spt.c:4964 */
#define   ESPT300      (ERRSPT +  300)    /*        spt.c:4965 */
#define   ESPT301      (ERRSPT +  301)    /*        spt.c:5011 */
#define   ESPT302      (ERRSPT +  302)    /*        spt.c:5013 */
#define   ESPT303      (ERRSPT +  303)    /*        spt.c:5014 */
#define   ESPT304      (ERRSPT +  304)    /*        spt.c:5015 */
#define   ESPT305      (ERRSPT +  305)    /*        spt.c:5016 */
#define   ESPT306      (ERRSPT +  306)    /*        spt.c:5017 */
#define   ESPT307      (ERRSPT +  307)    /*        spt.c:5063 */
#define   ESPT308      (ERRSPT +  308)    /*        spt.c:5065 */
#define   ESPT309      (ERRSPT +  309)    /*        spt.c:5066 */
#define   ESPT310      (ERRSPT +  310)    /*        spt.c:5067 */
#define   ESPT311      (ERRSPT +  311)    /*        spt.c:5068 */
#define   ESPT312      (ERRSPT +  312)    /*        spt.c:5069 */
#define   ESPT313      (ERRSPT +  313)    /*        spt.c:5111 */
#define   ESPT314      (ERRSPT +  314)    /*        spt.c:5113 */
#define   ESPT315      (ERRSPT +  315)    /*        spt.c:5114 */
#define   ESPT316      (ERRSPT +  316)    /*        spt.c:5115 */
#define   ESPT317      (ERRSPT +  317)    /*        spt.c:5157 */
#define   ESPT318      (ERRSPT +  318)    /*        spt.c:5159 */
#define   ESPT319      (ERRSPT +  319)    /*        spt.c:5160 */
#define   ESPT320      (ERRSPT +  320)    /*        spt.c:5161 */
#define   ESPT321      (ERRSPT +  321)    /*        spt.c:5205 */
#define   ESPT322      (ERRSPT +  322)    /*        spt.c:5207 */
#define   ESPT323      (ERRSPT +  323)    /*        spt.c:5208 */
#define   ESPT324      (ERRSPT +  324)    /*        spt.c:5209 */
#define   ESPT325      (ERRSPT +  325)    /*        spt.c:5210 */
#define   ESPT326      (ERRSPT +  326)    /*        spt.c:5253 */
#define   ESPT327      (ERRSPT +  327)    /*        spt.c:5255 */
#define   ESPT328      (ERRSPT +  328)    /*        spt.c:5256 */
#define   ESPT329      (ERRSPT +  329)    /*        spt.c:5257 */
#define   ESPT330      (ERRSPT +  330)    /*        spt.c:5258 */
#define   ESPT331      (ERRSPT +  331)    /*        spt.c:5298 */
#define   ESPT332      (ERRSPT +  332)    /*        spt.c:5300 */
#define   ESPT333      (ERRSPT +  333)    /*        spt.c:5301 */
#define   ESPT334      (ERRSPT +  334)    /*        spt.c:5341 */
#define   ESPT335      (ERRSPT +  335)    /*        spt.c:5343 */
#define   ESPT336      (ERRSPT +  336)    /*        spt.c:5344 */
#define   ESPT337      (ERRSPT +  337)    /*        spt.c:5388 */
#define   ESPT338      (ERRSPT +  338)    /*        spt.c:5390 */
#define   ESPT339      (ERRSPT +  339)    /*        spt.c:5391 */
#define   ESPT340      (ERRSPT +  340)    /*        spt.c:5392 */
#define   ESPT341      (ERRSPT +  341)    /*        spt.c:5393 */
#define   ESPT342      (ERRSPT +  342)    /*        spt.c:5437 */
#define   ESPT343      (ERRSPT +  343)    /*        spt.c:5439 */
#define   ESPT344      (ERRSPT +  344)    /*        spt.c:5440 */
#define   ESPT345      (ERRSPT +  345)    /*        spt.c:5441 */
#define   ESPT346      (ERRSPT +  346)    /*        spt.c:5442 */
#define   ESPT347      (ERRSPT +  347)    /*        spt.c:5484 */
#define   ESPT348      (ERRSPT +  348)    /*        spt.c:5485 */
#define   ESPT349      (ERRSPT +  349)    /*        spt.c:5486 */
#define   ESPT350      (ERRSPT +  350)    /*        spt.c:5487 */
#define   ESPT351      (ERRSPT +  351)    /*        spt.c:5532 */
#define   ESPT352      (ERRSPT +  352)    /*        spt.c:5533 */
#define   ESPT353      (ERRSPT +  353)    /*        spt.c:5534 */
#define   ESPT354      (ERRSPT +  354)    /*        spt.c:5535 */
#define   ESPT355      (ERRSPT +  355)    /*        spt.c:5581 */
#define   ESPT356      (ERRSPT +  356)    /*        spt.c:5582 */
#define   ESPT357      (ERRSPT +  357)    /*        spt.c:5583 */
#define   ESPT358      (ERRSPT +  358)    /*        spt.c:5584 */
#define   ESPT359      (ERRSPT +  359)    /*        spt.c:5585 */
#define   ESPT360      (ERRSPT +  360)    /*        spt.c:5631 */
#define   ESPT361      (ERRSPT +  361)    /*        spt.c:5632 */
#define   ESPT362      (ERRSPT +  362)    /*        spt.c:5633 */
#define   ESPT363      (ERRSPT +  363)    /*        spt.c:5634 */
#define   ESPT364      (ERRSPT +  364)    /*        spt.c:5635 */
#define   ESPT365      (ERRSPT +  365)    /*        spt.c:5679 */
#define   ESPT366      (ERRSPT +  366)    /*        spt.c:5680 */
#define   ESPT367      (ERRSPT +  367)    /*        spt.c:5681 */
#define   ESPT368      (ERRSPT +  368)    /*        spt.c:5725 */
#define   ESPT369      (ERRSPT +  369)    /*        spt.c:5726 */
#define   ESPT370      (ERRSPT +  370)    /*        spt.c:5727 */
#define   ESPT371      (ERRSPT +  371)    /*        spt.c:5772 */
#define   ESPT372      (ERRSPT +  372)    /*        spt.c:5773 */
#define   ESPT373      (ERRSPT +  373)    /*        spt.c:5774 */
#define   ESPT374      (ERRSPT +  374)    /*        spt.c:5775 */
#define   ESPT375      (ERRSPT +  375)    /*        spt.c:5820 */
#define   ESPT376      (ERRSPT +  376)    /*        spt.c:5821 */
#define   ESPT377      (ERRSPT +  377)    /*        spt.c:5822 */
#define   ESPT378      (ERRSPT +  378)    /*        spt.c:5823 */
#define   ESPT379      (ERRSPT +  379)    /*        spt.c:5867 */
#define   ESPT380      (ERRSPT +  380)    /*        spt.c:5868 */
#define   ESPT381      (ERRSPT +  381)    /*        spt.c:5869 */
#define   ESPT382      (ERRSPT +  382)    /*        spt.c:5913 */
#define   ESPT383      (ERRSPT +  383)    /*        spt.c:5914 */
#define   ESPT384      (ERRSPT +  384)    /*        spt.c:5915 */
#define   ESPT385      (ERRSPT +  385)    /*        spt.c:5961 */
#define   ESPT386      (ERRSPT +  386)    /*        spt.c:5962 */
#define   ESPT387      (ERRSPT +  387)    /*        spt.c:5963 */
#define   ESPT388      (ERRSPT +  388)    /*        spt.c:5964 */
#define   ESPT389      (ERRSPT +  389)    /*        spt.c:5965 */
#define   ESPT390      (ERRSPT +  390)    /*        spt.c:6011 */
#define   ESPT391      (ERRSPT +  391)    /*        spt.c:6012 */
#define   ESPT392      (ERRSPT +  392)    /*        spt.c:6013 */
#define   ESPT393      (ERRSPT +  393)    /*        spt.c:6014 */
#define   ESPT394      (ERRSPT +  394)    /*        spt.c:6015 */
#define   ESPT395      (ERRSPT +  395)    /*        spt.c:6058 */
#define   ESPT396      (ERRSPT +  396)    /*        spt.c:6059 */
#define   ESPT397      (ERRSPT +  397)    /*        spt.c:6102 */
#define   ESPT398      (ERRSPT +  398)    /*        spt.c:6103 */
#define   ESPT399      (ERRSPT +  399)    /*        spt.c:6148 */
#define   ESPT400      (ERRSPT +  400)    /*        spt.c:6149 */
#define   ESPT401      (ERRSPT +  401)    /*        spt.c:6150 */
#define   ESPT402      (ERRSPT +  402)    /*        spt.c:6151 */
#define   ESPT403      (ERRSPT +  403)    /*        spt.c:6196 */
#define   ESPT404      (ERRSPT +  404)    /*        spt.c:6197 */
#define   ESPT405      (ERRSPT +  405)    /*        spt.c:6198 */
#define   ESPT406      (ERRSPT +  406)    /*        spt.c:6199 */

#endif /* __SPTH__ */

  
/********************************************************************30**
  
         End of file:     spt.h@@/main/15 - Tue Jan 22 15:18:36 2002
    
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  fmg   1. miscellaneous changes

1.3          ---  fmg   1. miscellaneous changes

1.4          ---  fmg   1. added support for CCITT Connection Oriented
                           Control

2.1          ---  fmg   1. new interface
             ---  fmg   2. changed event codes

2.2          ---  fmg   1. add GT_FRMT defines

2.3          ---  scc   1. add new defines for ANSI 92 and CCITT 92

2.4          ---  aa    1. moved the defines for SMI to cm_ss7.h
             ---  aa    2. moved the defines for PC and SubSystem status to 
                           gen.h

2.5          ---  mjp   1. moved the defines for priority to cm_ss7.h

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
2.6          ---      ash  1. defining new events for SPT2 
                      cp   1. added macro SPTLOGERROR  
                      ash  1. SPT_BND_OK and SPT_BND_NOK are moved to
                              gen.h as CM_BND_OK and CM_BND_NOK
/main/11          ---      vb   1. Added the new return and refusal cause 
                              value defines
/main/13     ---      nt  1. New events added for SUA-NIF interface.
/main/14     ---      rc  1. Rolling upgrade changes, as per tcr0020.txt:
                             SPT interface version defined under SPTV1.
/main/15     ---      rc  1. Addition for sccp release 3.2:
                             - defining interface version SPTV2.
                             - hash defs for audit event and connection states.
                             - bits for compile flags SS7_ANS96 and SS7_BELL05.
                             - New return cause and release cause.
                             - maximum allowable importance for sccp messages.
                             - removing compile flag SS7_ITU96 and defines under
                               this flag made available unconditionally.
  spt_h_001.main_15   sm  1. Addition of event for UDatSrvReq.
  spt_h_002.main_15   sm  1. Enabled the lower interface versions
                             if higher interface version is enabled.
*********************************************************************91*/
