/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SS7 TCAP
  
     Type:     C include file
  
     Desc:     Defines required by SS7 TCAP user.
 
     File:     stu.h

     Sid:      stu.h@@/main/21 - Fri Sep 16 02:51:57 2005

     Prg:      nj

*********************************************************************21*/

#ifndef __STUH__
#define __STUH__


/* Added for STUV3 */
#ifdef STUV3
#ifndef STUV2
#define STUV2
#endif
#endif

 /* Rolling Upgrade feature */
 /* Add interface version defines for Rolling Upgrade */
/* Interface version number  */
#ifdef STUV1
#ifdef STUIFVER
#undef STUIFVER
#endif  /* STUIFVER */
#define STUIFVER 0x0100
#endif  /* STUV1 */

/* defines for STU interface version 2 */
#ifdef STUV2
#ifdef STUIFVER
#undef STUIFVER
#endif  /* STUIFVER */
#define STUIFVER 0x0200
#endif  /* STUV2 */

/* Added for STUV3 */
#ifdef STUV3
#ifdef STUIFVER
#undef STUIFVER
#endif  /* STUIFVER */
#define STUIFVER 0x0300
#endif  /* STUV2 */

/* assume a base version if none of STUV1 or STUV2 is 
 * defined */
#ifndef STUIFVER
#define STUIFVER 0x0100
#endif /* STUIFVER */

/* bits for compile flags */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#define STU_SS7_ANS96_BIT   0x01      /* bit for compile flag SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* Default values for ril and sccpState */ 
#ifdef STUV2
#define STUIF_VER2_STEIND_DEF_RIL_VAL       0x00
#define STUIF_VER2_STECFM_DEF_RIL_VAL       0x00
#define STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL 0x05
#define STUIF_VER2_STECFM_DEF_SCCPSTATE_VAL 0x05
#endif /* STUV2 */
/* defines */

/* TCAP message types */

#define STU_BEGIN        1   /* begin message */
#define STU_CONTINUE     2   /* continue message */
#define STU_END          3   /* end message */
#define STU_U_ABORT      4   /* CCITT user abort message */
#define STU_ABORT        STU_U_ABORT

#define STU_UNI          5   /* unidirectional */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
#define STU_QRY_PRM      6   /* query with permission message */
#define STU_QRY_NO_PRM   7   /* query without permission message */
#define STU_RESPONSE     8   /* response message */
#define STU_CNV_PRM      9   /* conversation with permission message */
#define STU_CNV_NO_PRM  10   /* conversation without permission message */
#define STU_ANSI_UABORT 11   /* TCAP ANSI User abort message */
#define STU_ANSI_ABORT  STU_ANSI_UABORT
#define STU_ANSI_PABORT 12   /* TCAP ANSI Protocol abort message */
#endif /* SS7_ANSXX */

#define STU_P_ABORT     13   /* CCITT protocol abort message */

/* TCAP Operation Class */
#define STU_OPRCLASS1    1       /* Operation Class */
#define STU_OPRCLASS2    2       /* Operation Class */
#define STU_OPRCLASS3    3       /* Operation Class */
#define STU_OPRCLASS4    4       /* Operation Class */

/* TCAP component types */
#define STU_UNKNOWN     0   /* unknown component */
#define STU_INVOKE      1   /* invoke */
#define STU_RET_RES_L   2   /* return result last */
#define STU_RET_ERR     3   /* return error */
#define STU_REJECT      4   /* reject */
#define STU_RET_RES_NL  5   /* return result not last */

#define STU_TMR_RESET   8   /* ITU-96 Reset invoke timer */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
#define STU_INVOKE_L    6   /* invoke last */
#define STU_INVOKE_NL   7   /* invoke not last */
#endif /* SS7_ANSXX */

/* TCAP component indications */

#define STU_COMP_NONE        0   /* unknown indication */
#define STU_COMP_INVOKE      1   /* TC Invoke */
#define STU_COMP_RRL         2   /* TC Result last */
#define STU_COMP_RRNL        3   /* TC Result not last */
#define STU_COMP_ERROR       4   /* TC error */
#define STU_COMP_CANCEL      5   /* TC cancel */
#define STU_COMP_REJ_USR     6   /* TC user reject component */
#define STU_COMP_REJ_LOCAL   7   /* local reject component */
#define STU_COMP_REJ_REMOTE  8   /* remote reject component */
#define STU_COMP_REJ_QLOCAL  9   /* local reject component - reject queued in TCAP */

/* CCITT - 92, dialogue portion types */
#define STU_DLGP_NONE   0    /* unknown dialog portion type */
#define STU_DLGP_UNI    1    /* unidirectional dialog portion type */
#define STU_DLGP_REQ    2    /* request dialog portion type */
#define STU_DLGP_RSP    3    /* response dialog portion type */
#define STU_DLGP_ABT    4    /* abort dialog portion type */

/* parameter flags */

#define STU_NO_SET_SEQ  0   /* no set or sequence flag */
#define STU_SEQUENCE    1   /* sequence flag desired */
#define STU_SET         2   /* set flag desired */

/* error/operation code flags */

#define STU_NONE        0   /* no operation code flag */
#define STU_LOCAL       1   /* local error/operation code flag desired */
#define STU_GLOBAL      2   /* global error/operation code flag desired */
#define STU_NATIONAL    3   /* National TCAP */
#define STU_PRIVATE     4   /* Private TCAP */

/* result source tags for dialog portion */
#define ST_DLG_SU_TAG      0xA1     /* dialog service user tag */
#define ST_DLG_SP_TAG      0xA2     /* dialog service provider tag */

/* Abort source for dialogue abort */
#define STU_DLG_USR_ABRT   0x00     /* Service user */
#define STU_DLG_PRV_ABRT   0x01     /* Service provider */

/* dialog portion result codes */
#define ST_DLG_ACCEPTED    0x00     /* dialog has been accepted */
#define ST_DLG_REJ_PERM    0x01     /* dialog was rejected permanently */

#define ST_DLG_RSD_NULL    0x00     /* result source diagnostic: null */
#define ST_DLG_RSD_NORSN   0x01     /* result source diagnostic: no reason */
#define ST_DLG_RSD_NOACN   0x02     /* result source diagnostic: user: no acn*/
#define ST_DLG_RSD_NCDLG   0x02     /* result source diagnostic: prov: 
                                       no common dialog portion */
#define ST_DLG_REFUSED     0x03     /* Dialogue refused */

#if (SS7_ETSI)
#define ST_ETS_DLG_REFUSED 0x03     /* Dialogue refused */
#endif

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/* Ansi-96 Dialogue portion defines */

/* Ansi dialogue portion Application context/security context encoding types */
#define ST_ANS_ENC_TYP_INT  1
#define ST_ANS_ENC_TYP_OID  2
#endif /* SS7_ANSXX */

/* problem code flags */

#define STU_PROB_NONE    0x00   /* no problem code flag */
#define STU_PROB_GENERAL 0x80   /* general problem code flag */
#define STU_PROB_INVOKE  0x81   /* invoke problem code flag */
#define STU_PROB_RET_RES 0x82   /* return result problem code flag */
#define STU_PROB_RET_ERR 0x83   /* return error problem code flag */

/* TC Problem Codes */

/* General Problems */
#define STU_UNREC_COMP      0   /* Unrecognized component */
#define STU_MISTYPED_COMP   1   /* Mistyped parameter */
#define STU_BAD_STRUC_COMP  2   /* Badly structured component */

/* Invoke problems */
#define STU_DUP_INVOKE      0   /* Duplicate Invoke Id */
#define STU_UNREC_OPR       1   /* Unrecognized invoke Id */
#define STU_MISTYPED_PARAM  2   /* Mistyped parameter */
#define STU_RESOURCE_LIMIT  3   /* Resource limitation */
#define STU_INIT_RELEASE    4   /* Initiating Release */
#define STU_UNREC_LINKED_ID 5   /* Unrecognized linked Id */
#define STU_LINKED_RESP_UNX 6   /* Linked response unexpected */
#define STU_UNX_LINKED_OP   7   /* Unexpected linked operation */
#define STU_INVOKE_TIMEOUT  8   /* Invoke timeout added by xingzhou.xu --2006/09/13 */

/* Return result problem */
#define STU_RR_UNREC_INVKID 0   /* Unrecognized invoke Id */
#define STU_UNX_RETRSLT     1   /* Return result unexpected */
#define STU_RR_MISTYPED_PAR 2   /* Return result mistyped parameter */

/* Return Error problems */
#define STU_RE_UNREC_INVKID 0   /* return error unerecognized invoke id */
#define STU_RE_UNX_RETERR   1   /* Unexpected return error */
#define STU_UNREC_ERROR     2   /* Unrecgnized error */
#define STU_UNX_ERR         3   /* Unexpected error */
#define STU_RE_MISTYPED_PAR 4   /* Mistyped parameter */ 

/* The following reject problem codes are defined for the local Reject
   component which is generated to take care of the local protocol errors */
#define STU_RSRC_UNAVAIL   0x10 /* General - Resource not available */
#define STU_ENC_FAILURE    0x11 /* General - Component encoding failure */
#define STU_UNREC_OPCLASS  0x12 /* Invoke  - Invalid Operation class */

/* P-Abort Causes */
#define STU_ABORT_UNREC_MSG 0x00
#define STU_ABORT_UNREC_TRS 0x01
#define STU_ABORT_BAD_FRMT  0x02
#define STU_ABORT_INC_TRANS 0x03
#define STU_ABORT_RESOURCE  0x04
#define STU_ABORT_ABNML_DLG  0x05   /* trillium proprietary value */
#define STU_ABORT_NO_CMN_DLG 0x06   /* trillium proprietary value */

/* The following abort causes are defined for the local P-Abort message
   which is generated to take care of the local protocol errors */
#define STU_ABORT_UNEXP_MSG  0x10   /* Unexpected message type */
#define STU_ABORT_MISC_ERR   0x11   /* Misc. Errors */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)

/* ANSI P-Abort Causes */
#define STU_ANSI_ABORT_UP    0x01  /* unrecognized package type */
#define STU_ANSI_ABORT_IN    0x02  /* incorrect transaction portion */
#define STU_ANSI_ABORT_BD    0x03  /* badly structured transaction portion */
#define STU_ANSI_ABORT_UT    0x04  /* unrecognized transaction ID */
#define STU_ANSI_ABORT_PR    0x05  /* Permission to release problem */
#define STU_ANSI_ABORT_RN    0x06  /* resource not available */

#define ST_ANS_PABT_UR_DPID  0x07  /* Unrecognized dialogue portion id */
#define ST_ANS_PABT_BD_DLGP  0x08  /* Badly structured Dialogue portion */
#define ST_ANS_PABT_MS_DLGP  0x09  /* Missing dialogue portion */
#define ST_ANS_PABT_IC_DLGP  0x0A  /* Inconsistent dialogue portion */

#define STU_ANSI_PRB_NU     0x00   /* not used */
#define STU_ANSI_PRB_GEN    0x01   /* general */
#define STU_ANSI_PRB_INV    0x02   /* invoke */
#define STU_ANSI_PRB_RR     0x03   /* return result */
#define STU_ANSI_PRB_RE     0x04   /* return error */
#define STU_ANSI_PRB_TRANS  0x05   /* transaction portion */
#define STU_ANSI_PRB_RSRVD  0xFF   /* all families - reserved */




#if (SS7_ANS88 ||SS7_ANS92 || SS7_ANS96)
#define STU_ANSI_PRB_NU     0x00   /* not used */
#endif

#define STU_ANSI_PRB_UR_CMP 0x01   /* general - unrecognized component */
#define STU_ANSI_PRB_IN_CMP 0x02   /* general - incorrect component portion */
#define STU_ANSI_PRB_BD_CMP 0x03   /* general - badly structured component portion */
#define STU_ANSI_PRB_IN_ENC 0x04   /* general - incorrect component encoding */
#define STU_ANSI_PRB_DUP_ID 0x01   /* invoke - duplicate invoke ID */
#define STU_ANSI_PRB_UR_OP  0x02   /* invoke - unrecognized operation code */
#define STU_ANSI_PRB_IN_PRM 0x03   /* invoke - incorrect parameter  */
#define STU_ANSI_PRB_IUR_ID 0x04   /* invoke - unrecognized correlation ID */
#define STU_ANSI_PRB_RUR_ID 0x01   /* return result - unrecognized correlation ID */
#define STU_ANSI_PRB_UX_RES 0x02   /* return result - unexpected return result */
/* defines for invoke - incorrect parameter */
#define STU_ANSI_PRB_INV_IN_PRM 0x03 /* return result - incorrect parameter  */
#define STU_ANSI_PRB_EUR_ID 0x01   /* return error - unrecognized correlation ID */
#define STU_ANSI_PRB_UX_RER 0x02   /* return error - unexpected return error */
#define STU_ANSI_PRB_UR_ERR 0x03   /* return error - unrecognized error */
#define STU_ANSI_PRB_UX_ERR 0x04   /* return error - unexpected error */
#define STU_ANSI_PRB_EN_PRM 0x05   /* return error - incorrect parameter */
#define STU_ANSI_PRB_UR_PKG 0x01   /* transaction portion - unrecognized package type */
#define STU_ANSI_PRB_IN_TRN 0x02   /* transaction portion - incorrect transaction portion */
#define STU_ANSI_PRB_BD_TRN 0x03   /* transaction portion - badly structured transaction portion */
#define STU_ANSI_PRB_UR_TRN 0x04   /* transaction portion - unrecognized transaction ID */
#define STU_ANSI_PRB_PR_TRN 0x05   /* transaction portion - permission to release */
#define STU_ANSI_PRB_RU_TRN 0x06   /* transaction portion - resource unavailable */
/* defines for Bellcore problem code */
#define STU_BELL_INV_MM_PARM 0x05   /* Missing Mandatory parameter */
#define STU_BELL_RES_MM_PARM 0x04   /* Missing Mandatory parameter */
#define STU_BELL_ERR_MM_PARM 0x06   /* Missing Mandatory parameter */

/* National Operation Family (NOF) */
#define STU_ANSI_NOF_NU     0x00   /* not used */
#define STU_ANSI_NOF_PARAM  0x01   /* parameter */
#define STU_ANSI_NOF_CHGING 0x02   /* charging */
#define STU_ANSI_NOF_PR_INS 0x03   /* provide instructions */
#define STU_ANSI_NOF_CN_CTL 0x04   /* connection control */
#define STU_ANSI_NOF_CL_INT 0x05   /* caller interaction */
#define STU_ANSI_NOF_SND_NO 0x06   /* send notification */
#define STU_ANSI_NOF_NET_MN 0x07   /* network management */
#define STU_ANSI_NOF_PROC   0x08   /* procedural */




#if (SS7_ANS88 ||SS7_ANS92 || SS7_ANS96)
#define STU_ANSI_NOF_OP_CTL 0x09   /* Operation Control Family */
#define STU_ANSI_NOF_RP_EVT 0x0A   /* Report Event Family */
#endif

#define STU_ANSI_NOF_MISC   0x7E   /* miscellaneous */
#define STU_ANSI_NOF_RSRVD  0x7F   /* reserved */
#define STU_ANSI_NOF_RP_REQ 0x80   /* reply required */

/* Operation Specifiers */
#define STU_ANSI_OS_RSRVD   0xFF   /* all families - reserved */
#define STU_ANSI_OS_NU      0x00   /* all families - not used */
#define STU_ANSI_OS_PRV_VAL 0x01   /* parameter - provide value */
#define STU_ANSI_OS_SET_VAL 0x02   /* parameter - set value */
#define STU_ANSI_OS_BL_CALL 0x01   /* charging - bill call */
#define STU_ANSI_OS_START   0x01   /* provide instruction - start */
#define STU_ANSI_OS_ASSIST  0x02   /* provide instruction - assist */
#define STU_ANSI_OS_CONNECT 0x01   /* connection control - connect */
#define STU_ANSI_OS_TMP_CON 0x02   /* connection control - temporary connect */
#define STU_ANSI_OS_DISC    0x03   /* connection control - disconnect */
#define STU_ANSI_OS_FWD_DIS 0x04   /* connection control - forward disconnect */
#define STU_ANSI_OS_PLY_ANN 0x01   /* caller interaction - play announcement */
#define STU_ANSI_OS_COL_DIG 0x02   /* cllr intrctn - play ann & coll digits */




#if (SS7_ANS88 ||SS7_ANS92 || SS7_ANS96)
#define STU_ANSI_OS_INF_WTG 0x03   /* caller interaction - info. waiting */
#define STU_ANSI_OS_INF_PVD 0x03   /* caller interaction - info. provided */
#define STU_ANSI_OS_PTY_FRE 0x01   /* send notification - when party free */
#define STU_ANSI_OS_RAS_TRM 0x01   /* procedural - report assist termination */
#define STU_ANSI_OS_CANCEL  0x01   /* Operation Control - Cancel */
#define STU_ANSI_OS_VM_AVL  0x01   /* Report Event - Voice Message Available */
#define STU_ANSI_OS_VM_RTVD 0x02   /* Report Event - Voice Message Retrieved */
#define STU_ANSI_OS_Q_CALL  0x02   /* Miscellaneous - Queue Call */
#define STU_ANSI_OS_DQ_CALL 0x02   /* Miscellaneous - Dequeue Call */
#endif

#define STU_ANSI_OS_CAL_GAP 0x01   /* network management - call gap */
#define STU_ANSI_OS_TMP_HDN 0x01   /* procedural - temporary handover */

#define STU_ANSI_ERR_NU     0x00   /* not used */
#define STU_ANSI_ERR_UX_CMP 0x01   /* unexpected component sequence */
#define STU_ANSI_ERR_UX_DAT 0x02   /* unexpected data value */
#define STU_ANSI_ERR_UA_NET 0x03   /* unavailable network resource */
#define STU_ANSI_ERR_MSG_RC 0x04   /* missing customer record */




#if (SS7_ANS88 ||SS7_ANS92 || SS7_ANS96)
#define STU_ANSI_ERR_REP_OD 0x05   /* reply overdue */
#else
#define STU_ANSI_ERR_REP_SC 0x05   /* spare code */
#endif

#define STU_ANSI_ERR_DAT_UA 0x06   /* data unavailable */




#if (SS7_ANS88 ||SS7_ANS92 || SS7_ANS96)
#define STU_ANSI_ERR_TSK_RE 0x07   /* Task refused */
#define STU_ANSI_ERR_Q_FULL 0x08   /* Queue Full */
#define STU_ANSI_ERR_NO_Q   0x09   /* No Queue */
#define STU_ANSI_ERR_TMR_EX 0x0A   /* Timer Expired */
#define STU_ANSI_ERR_DAT_EX 0x0B   /* Data already exists */
#define STU_ANSI_ERR_UNAUTH 0x0C   /* Unauthorized Request */
#define STU_ANSI_ERR_NOT_QD 0x0D   /* Not Queued */
#define STU_ANSI_ERR_UAS_DN 0x0E   /* Unassigned DN */
#define STU_ANSI_ERR_SPARE  0x0F   /* Spare */
#define STU_ANSI_ERR_NOT_AV 0x10   /* Notification Available on dest DN */
#define STU_ANSI_ERR_VMSR_E 0x11   /* VMSR sys. ID does not match user prof. */
#endif

#endif /* SS7_ANSXX */

/* user interface return codes */

#define STU_RETURN_OK     0  /* good return */

/* return code in status indication */
#define STU_R_EVT_INAPP   1  /* received event in inappropriate state */
#define STU_MSNG_ELE      2   /* missing mandatory element */
#define STU_DUP_INV_ID    3  /* duplicate invoke ID given to CC */
#define STU_INV_REJ       4  /* received REJECT with syntax error */

/* tcap-tcapuser events */
#define EVTSTUBNDREQ       0x04             /* Bind request */
#define EVTSTUUBNDREQ      0x08             /* Unbind request */

#define EVTSTUDATREQ       0x14             /* Data request */
#define EVTSTUDATIND       0x16             /* Data indication */

#define EVTSTUUDATREQ      0x18             /* Unit data request */
#define EVTSTUUDATIND      0x1A  
   
#define EVTSTUCMPREQ       0x20             /* component request */
#define EVTSTUCMPIND       0x21             /* component indication */
#define EVTSTUCMPCFM       0x22             /* component confirm */

#define EVTSTUNOTIND       0x72             /* Notice indication */

#define EVTSTUSTAREQ       0x78             /* Status request */
#define EVTSTUSTACFM       0x79             /* Status confirm */
#define EVTSTUSTAIND       0x7A             /* Status indication */

#define EVTSTUSTEREQ       0x7E             /* state Request */
#define EVTSTUSTEIND       0x7B             /* state indication */
#define EVTSTUSTERSP       0x7C             /* state Response */
#define EVTSTUSTECFM       0x7D             /* state Confirm */

#define EVTSTUBNDCFM       0x80             /* Bind Confirm */

/* Macro for Error Logging */
#define STULOGERROR(errCls, errCode, errVal, errDesc)         \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,  \
                   __FILE__, __LINE__,                        \
                  (ErrCls)errCls, (ErrCode)errCode, (ErrVal)errVal, errDesc)

#if (ERRCLASS & ERRCLS_DEBUG)
/* Add - unpkUInfoFlag field */
#define STCHKUNPKLOG(func, val, mBuf, unpkUInfoFlag, errCode, pst) \
   { \
      S16 ret; \
      if ((ret = func(val, mBuf, unpkUInfoFlag)) != ROK) \
      { \
         SPutMsg(*mBuf); \
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__, \
                   __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)errCode, (ErrVal)ret, \
                   "Unpacking failure"); \
          RETVALUE(ret); \
       } \
   }

#else
/* Add - unpkUInfoFlag field */
#define STCHKUNPKLOG(func, val, mBuf, unpkUInfoFlag, errCode, pst) \
   func(val, mBuf, unpkUInfoFlag);
#endif

#define STU_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        STULOGERROR(ERRCLS_ADD_RES, e, (ErrVal) ret,"SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

#define   ESTUBASE      000    
#define   ESTUXXX      (ESTUBASE)         /* reserved */

#define   ESTU001      (ESTUBASE +    1)    /*        stu.c: 852 */
#define   ESTU002      (ESTUBASE +    2)    /*        stu.c: 853 */
#define   ESTU003      (ESTUBASE +    3)    /*        stu.c: 854 */
#define   ESTU004      (ESTUBASE +    4)    /*        stu.c: 897 */
#define   ESTU005      (ESTUBASE +    5)    /*        stu.c: 898 */
#define   ESTU006      (ESTUBASE +    6)    /*        stu.c: 957 */
#define   ESTU007      (ESTUBASE +    7)    /*        stu.c: 964 */
#define   ESTU008      (ESTUBASE +    8)    /*        stu.c: 965 */
#define   ESTU009      (ESTUBASE +    9)    /*        stu.c: 966 */
#define   ESTU010      (ESTUBASE +   10)    /*        stu.c: 967 */
#define   ESTU011      (ESTUBASE +   11)    /*        stu.c:1038 */
#define   ESTU012      (ESTUBASE +   12)    /*        stu.c:1047 */
#define   ESTU013      (ESTUBASE +   13)    /*        stu.c:1054 */
#define   ESTU014      (ESTUBASE +   14)    /*        stu.c:1056 */
#define   ESTU015      (ESTUBASE +   15)    /*        stu.c:1057 */
#define   ESTU016      (ESTUBASE +   16)    /*        stu.c:1065 */
#define   ESTU017      (ESTUBASE +   17)    /*        stu.c:1076 */
#define   ESTU018      (ESTUBASE +   18)    /*        stu.c:1081 */
#define   ESTU019      (ESTUBASE +   19)    /*        stu.c:1082 */
#define   ESTU020      (ESTUBASE +   20)    /*        stu.c:1083 */
#define   ESTU021      (ESTUBASE +   21)    /*        stu.c:1084 */
#define   ESTU022      (ESTUBASE +   22)    /*        stu.c:1151 */
#define   ESTU023      (ESTUBASE +   23)    /*        stu.c:1160 */
#define   ESTU024      (ESTUBASE +   24)    /*        stu.c:1167 */
#define   ESTU025      (ESTUBASE +   25)    /*        stu.c:1169 */
#define   ESTU026      (ESTUBASE +   26)    /*        stu.c:1177 */
#define   ESTU027      (ESTUBASE +   27)    /*        stu.c:1188 */
#define   ESTU028      (ESTUBASE +   28)    /*        stu.c:1193 */
#define   ESTU029      (ESTUBASE +   29)    /*        stu.c:1194 */
#define   ESTU030      (ESTUBASE +   30)    /*        stu.c:1195 */
#define   ESTU031      (ESTUBASE +   31)    /*        stu.c:1238 */
#define   ESTU032      (ESTUBASE +   32)    /*        stu.c:1239 */
#define   ESTU033      (ESTUBASE +   33)    /*        stu.c:1282 */
#define   ESTU034      (ESTUBASE +   34)    /*        stu.c:1283 */
#define   ESTU035      (ESTUBASE +   35)    /*        stu.c:1336 */
#define   ESTU036      (ESTUBASE +   36)    /*        stu.c:1337 */
#define   ESTU037      (ESTUBASE +   37)    /*        stu.c:1338 */
#define   ESTU038      (ESTUBASE +   38)    /*        stu.c:1339 */
#define   ESTU039      (ESTUBASE +   39)    /*        stu.c:1340 */
#define   ESTU040      (ESTUBASE +   40)    /*        stu.c:1341 */
#define   ESTU041      (ESTUBASE +   41)    /*        stu.c:1401 */
#define   ESTU042      (ESTUBASE +   42)    /*        stu.c:1402 */
#define   ESTU043      (ESTUBASE +   43)    /*        stu.c:1403 */
#define   ESTU044      (ESTUBASE +   44)    /*        stu.c:1404 */
#define   ESTU045      (ESTUBASE +   45)    /*        stu.c:1405 */
#define   ESTU046      (ESTUBASE +   46)    /*        stu.c:1406 */
#define   ESTU047      (ESTUBASE +   47)    /*        stu.c:1407 */
#define   ESTU048      (ESTUBASE +   48)    /*        stu.c:1408 */
#define   ESTU049      (ESTUBASE +   49)    /*        stu.c:1409 */
#define   ESTU050      (ESTUBASE +   50)    /*        stu.c:1410 */
#define   ESTU051      (ESTUBASE +   51)    /*        stu.c:1411 */
#define   ESTU052      (ESTUBASE +   52)    /*        stu.c:1470 */
#define   ESTU053      (ESTUBASE +   53)    /*        stu.c:1471 */
#define   ESTU054      (ESTUBASE +   54)    /*        stu.c:1472 */
#define   ESTU055      (ESTUBASE +   55)    /*        stu.c:1473 */
#define   ESTU056      (ESTUBASE +   56)    /*        stu.c:1474 */
#define   ESTU057      (ESTUBASE +   57)    /*        stu.c:1475 */
#define   ESTU058      (ESTUBASE +   58)    /*        stu.c:1523 */
#define   ESTU059      (ESTUBASE +   59)    /*        stu.c:1524 */
#define   ESTU060      (ESTUBASE +   60)    /*        stu.c:1525 */
#define   ESTU061      (ESTUBASE +   61)    /*        stu.c:1570 */
#define   ESTU062      (ESTUBASE +   62)    /*        stu.c:1571 */
#define   ESTU063      (ESTUBASE +   63)    /*        stu.c:1572 */
#define   ESTU064      (ESTUBASE +   64)    /*        stu.c:1573 */
#define   ESTU065      (ESTUBASE +   65)    /*        stu.c:1574 */
#define   ESTU066      (ESTUBASE +   66)    /*        stu.c:1575 */
#define   ESTU067      (ESTUBASE +   67)    /*        stu.c:1617 */
#define   ESTU068      (ESTUBASE +   68)    /*        stu.c:1618 */
#define   ESTU069      (ESTUBASE +   69)    /*        stu.c:1660 */
#define   ESTU070      (ESTUBASE +   70)    /*        stu.c:1661 */
#define   ESTU071      (ESTUBASE +   71)    /*        stu.c:1702 */
#define   ESTU072      (ESTUBASE +   72)    /*        stu.c:1703 */
#define   ESTU073      (ESTUBASE +   73)    /*        stu.c:1745 */
#define   ESTU074      (ESTUBASE +   74)    /*        stu.c:1746 */
#define   ESTU075      (ESTUBASE +   75)    /*        stu.c:1817 */
#define   ESTU076      (ESTUBASE +   76)    /*        stu.c:1826 */
#define   ESTU077      (ESTUBASE +   77)    /*        stu.c:1833 */
#define   ESTU078      (ESTUBASE +   78)    /*        stu.c:1835 */
#define   ESTU079      (ESTUBASE +   79)    /*        stu.c:1836 */
#define   ESTU080      (ESTUBASE +   80)    /*        stu.c:1844 */
#define   ESTU081      (ESTUBASE +   81)    /*        stu.c:1855 */
#define   ESTU082      (ESTUBASE +   82)    /*        stu.c:1860 */
#define   ESTU083      (ESTUBASE +   83)    /*        stu.c:1937 */
#define   ESTU084      (ESTUBASE +   84)    /*        stu.c:1946 */
#define   ESTU085      (ESTUBASE +   85)    /*        stu.c:1953 */
#define   ESTU086      (ESTUBASE +   86)    /*        stu.c:1955 */
#define   ESTU087      (ESTUBASE +   87)    /*        stu.c:1956 */
#define   ESTU088      (ESTUBASE +   88)    /*        stu.c:1960 */
#define   ESTU089      (ESTUBASE +   89)    /*        stu.c:1967 */
#define   ESTU090      (ESTUBASE +   90)    /*        stu.c:1969 */
#define   ESTU091      (ESTUBASE +   91)    /*        stu.c:1977 */
#define   ESTU092      (ESTUBASE +   92)    /*        stu.c:1988 */
#define   ESTU093      (ESTUBASE +   93)    /*        stu.c:1993 */
#define   ESTU094      (ESTUBASE +   94)    /*        stu.c:1994 */
#define   ESTU095      (ESTUBASE +   95)    /*        stu.c:1995 */
#define   ESTU096      (ESTUBASE +   96)    /*        stu.c:1996 */
#define   ESTU097      (ESTUBASE +   97)    /*        stu.c:2061 */
#define   ESTU098      (ESTUBASE +   98)    /*        stu.c:2068 */
#define   ESTU099      (ESTUBASE +   99)    /*        stu.c:2069 */
#define   ESTU100      (ESTUBASE +  100)    /*        stu.c:2070 */
#define   ESTU101      (ESTUBASE +  101)    /*        stu.c:2071 */
#define   ESTU102      (ESTUBASE +  102)    /*        stu.c:2072 */
#define   ESTU103      (ESTUBASE +  103)    /*        stu.c:2073 */
#define   ESTU104      (ESTUBASE +  104)    /*        stu.c:2119 */
#define   ESTU105      (ESTUBASE +  105)    /*        stu.c:2120 */
#define   ESTU106      (ESTUBASE +  106)    /*        stu.c:2121 */
#define   ESTU107      (ESTUBASE +  107)    /*        stu.c:2176 */
#define   ESTU108      (ESTUBASE +  108)    /*        stu.c:2184 */
#define   ESTU109      (ESTUBASE +  109)    /*        stu.c:2195 */
#define   ESTU110      (ESTUBASE +  110)    /*        stu.c:2200 */
#define   ESTU111      (ESTUBASE +  111)    /*        stu.c:2201 */
#define   ESTU112      (ESTUBASE +  112)    /*        stu.c:2202 */
#define   ESTU113      (ESTUBASE +  113)    /*        stu.c:2246 */
#define   ESTU114      (ESTUBASE +  114)    /*        stu.c:2247 */
#define   ESTU115      (ESTUBASE +  115)    /*        stu.c:2291 */
#define   ESTU116      (ESTUBASE +  116)    /*        stu.c:2292 */
#define   ESTU117      (ESTUBASE +  117)    /*        stu.c:2336 */
#define   ESTU118      (ESTUBASE +  118)    /*        stu.c:2337 */
#define   ESTU119      (ESTUBASE +  119)    /*        stu.c:2382 */
#define   ESTU120      (ESTUBASE +  120)    /*        stu.c:2383 */
#define   ESTU121      (ESTUBASE +  121)    /*        stu.c:2433 */
#define   ESTU122      (ESTUBASE +  122)    /*        stu.c:2434 */
#define   ESTU123      (ESTUBASE +  123)    /*        stu.c:2435 */
#define   ESTU124      (ESTUBASE +  124)    /*        stu.c:2477 */
#define   ESTU125      (ESTUBASE +  125)    /*        stu.c:2478 */
#define   ESTU126      (ESTUBASE +  126)    /*        stu.c:2528 */
#define   ESTU127      (ESTUBASE +  127)    /*        stu.c:2529 */
#define   ESTU128      (ESTUBASE +  128)    /*        stu.c:2530 */
#define   ESTU129      (ESTUBASE +  129)    /*        stu.c:2531 */
#define   ESTU130      (ESTUBASE +  130)    /*        stu.c:2532 */
#define   ESTU131      (ESTUBASE +  131)    /*        stu.c:2533 */
#define   ESTU132      (ESTUBASE +  132)    /*        stu.c:2534 */
#define   ESTU133      (ESTUBASE +  133)    /*        stu.c:2535 */
#define   ESTU134      (ESTUBASE +  134)    /*        stu.c:2536 */
#define   ESTU135      (ESTUBASE +  135)    /*        stu.c:2593 */
#define   ESTU136      (ESTUBASE +  136)    /*        stu.c:2594 */
#define   ESTU137      (ESTUBASE +  137)    /*        stu.c:2595 */
#define   ESTU138      (ESTUBASE +  138)    /*        stu.c:2596 */
#define   ESTU139      (ESTUBASE +  139)    /*        stu.c:2597 */
#define   ESTU140      (ESTUBASE +  140)    /*        stu.c:2598 */
#define   ESTU141      (ESTUBASE +  141)    /*        stu.c:2599 */
#define   ESTU142      (ESTUBASE +  142)    /*        stu.c:2657 */
#define   ESTU143      (ESTUBASE +  143)    /*        stu.c:2658 */
#define   ESTU144      (ESTUBASE +  144)    /*        stu.c:2659 */
#define   ESTU145      (ESTUBASE +  145)    /*        stu.c:2660 */
#define   ESTU146      (ESTUBASE +  146)    /*        stu.c:2710 */
#define   ESTU147      (ESTUBASE +  147)    /*        stu.c:2711 */
#define   ESTU148      (ESTUBASE +  148)    /*        stu.c:2754 */
#define   ESTU149      (ESTUBASE +  149)    /*        stu.c:2755 */

#endif /* __STUH__ */


/********************************************************************30**
  
         End of file:     stu.h@@/main/21 - Fri Sep 16 02:51:57 2005
    
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mma   1. initial release
 
1.2          ---  mma   1. move MAX_ST_STR from st.h to stu.h
 
1.3          ---  mma   1. change MAX_ST_STR from 40 to 100
 
2.1          ---  ak    1. new interface
             ---  ak    2. changed event codes
 
2.2          --   ak    1. moved MAX_ST_STRING to gen.h
 
2.3          ---  ak    1. added dialog portion types.
             ---  ak    2. changed service indication to notice indication.
             ---  ak    3. split STU_ABORT into _U_ABORT and _P_ABORT
             ---  ak    4. added ANSI_PABORT and ANSI_UABORT
             ---  ak    5. Added CMPxxx defines and.
             ---  ak    6. added status code for Status indications.
             ---  ak    7. new status codes for local/remote rejects.
 
2.4          ---  aa    1. add defines
 
2.5          ---  aa    1. add defines
 
2.6          ---  aa    1. moved defines from st.h to stu.h which are used
                           at interface.
 
2.7          ---  aa    1. Added the defines for new primitives

*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
2.8          ---      aa   1. change the define for EVTSTUSTEREQ from 0x7A to 7E
                               as 0x7A is used for EVTSTUSTAIND as well.
 
             ---      aa   2. Change the define of ST_DLG_SU_TAG and ST_DLG_SP_TAG
                               from 0x21 and 0x22 to 0xA1 and 0xA2 respectively
 
2.9          ---      nj   1. Reorganized the file and added defines for
                              ANSI-96 and ETSI.

2.10         ---      nj   1. Added one more define (STU_TMR_RESET) for
                              component type to allow TC-user to reset
                              an invoke timer.
                           2. Added one more result source diag. value 
                              ST_DLG_REFUSED for ITU-96.

2.11         ---      nj   1. Added a macro STCHKUNPKLOG to pack.
                           2. Regenerated the error codes.

/main/15     ---      nj   1. Added a reject status define to differentiate 
                              the case when TCAP has queued the Reject 
                              component and is waiting for a DatReq from the 
                              user.

/main/15                     zr   1. Rolling Upgrade Feature

                              zr   1. STU version 2 related defines added.
                                     - Version defines
                                     - default values for sccpState, ril
                                  2. Added define for SSTU_SS7_ANS96_BIT
                                  3. STCHKUNPKLOG macro modified to pass
                                     flag for indicating whether to 
                                     unpack user information.
                             jz   1. Added hash defines for Bellcore problem 
                                     code.
                             yk   1. STUV3 related defines added.
/main/21     ---      st   1. Update for MAP 2.3
*********************************************************************91*/
