/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Session Initiation Protocol (SIP)

     Type:     C include file

     Desc:     Defines required by SIP and SIP-User

     File:     sot.h

     Sid:      sot.h@@/main/10 - Tue Apr 20 00:23:27 2004

     Prg:      wvdl

*********************************************************************21*/

#ifndef __SOTH__
#define __SOTH__

/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000156     SIP
*
*/


/* defines */

/* Invalid connId */
#define SOT_CONNID_NOTUSED  0

/* Transaction context ranges for SIP itself */
#define SOT_TRANCTXT_NOTUSED  0x00000000
#define SOT_TRANCTXT_MIN      0x00000001
#define SOT_TRANCTXT_MAX      0x7fffffff
#define SOT_TRANCTXT_LCS_MIN  0x70000000

/* Call leg ranges for SIP, rest used by CC  */
#define SOT_CLEGID_NOTUSED  0x00000000
#define SOT_CLEGID_MIN      0x00000001
#define SOT_CLEGID_MAX      0x7fffffff

/* Protocol response codes */
#define SOT_RSP_NONE                      0
#define SOT_RSP_ERROR                     1
#define SOT_RSP_100_TRYING                100
#define SOT_RSP_180_RINGING               180
#define SOT_RSP_181_FORWARDED             181
#define SOT_RSP_182_QUEUED                182
#define SOT_RSP_183_SESSION_PROGRESS      183
#define SOT_RSP_200_OK                    200
#define SOT_RSP_202_ACCEPTED              202
#define SOT_RSP_300_MULT_CHOICES          300
#define SOT_RSP_301_MOVED_PERM            301
#define SOT_RSP_302_MOVED_TEMP            302
#define SOT_RSP_305_USE_PROXY             305
#define SOT_RSP_380_ALT_SERVICE           380
#define SOT_RSP_400_BAD_REQUEST           400
#define SOT_RSP_401_UNAUTHORIZED          401
#define SOT_RSP_402_PAYMENT_REQD          402
#define SOT_RSP_403_FORBIDDEN             403
#define SOT_RSP_404_NOT_FOUND             404
#define SOT_RSP_405_METHOD_NOT_ALLOWED    405
#define SOT_RSP_406_NOT_ACCEPTABLE        406
#define SOT_RSP_407_PROXY_AUTH_REQD       407
#define SOT_RSP_408_REQ_TIMEOUT           408
#define SOT_RSP_409_CONFLICT              409
#define SOT_RSP_410_GONE                  410
#define SOT_RSP_413_REQ_ENTITY_TOO_LARGE  413
#define SOT_RSP_414_REQ_URI_TOO_LONG      414
#define SOT_RSP_415_UNSPRTD_MEDIA         415
#define SOT_RSP_416_UNSPRTD_URI_SCHEME    416
#define SOT_RSP_420_BAD_EXTENSION         420
#define SOT_RSP_421_EXTENSION_REQUIRED    421
#define SOT_RSP_422_SESSTIMER_TOO_SMALL   422
#define SOT_RSP_429_REFERRER_IDENTITY_ERROR   429
#define SOT_RSP_480_TEMP_UNAVAIL          480
#define SOT_RSP_481_CLEG_TRAN_NOT_EXIST   481
#define SOT_RSP_482_LOOP_DETECTED         482
#define SOT_RSP_483_TOO_MANY_HOPS         483
#define SOT_RSP_484_ADDR_INCOMPLETE       484
#define SOT_RSP_485_AMBIGUOUS             485
#define SOT_RSP_486_BUSY_HERE             486
#define SOT_RSP_487_REQ_TERMINATED        487
#define SOT_RSP_488_NOT_ACCEPTBLE_HERE    488
#define SOT_RSP_489_BAD_EVENT             489
#define SOT_RSP_491_RETRY_AFTER           491
#define SOT_RSP_500_SRV_INT_ERROR         500
#define SOT_RSP_501_NOT_IMPLEMENTED       501
#define SOT_RSP_502_BAD_GATEWAY           502
#define SOT_RSP_503_SERVICE_UNAVAIL       503
#define SOT_RSP_504_SERVER_TIMEOUT        504
#define SOT_RSP_505_VERSION_UNSUPPORTED   505
#define SOT_RSP_600_BUSY_EVERYWHERE       600
#define SOT_RSP_603_DECLINE               603
#define SOT_RSP_604_NOT_EXIST_ANYWHERE    604
#define SOT_RSP_606_NOT_ACCEPTABLE        606


#define SOT_PROTOCOL_VERSION     "2.0"

/* Error codes for functions at the SCT Interface */
#define   ESOTBASE     0
#define   ESOTXXX      (ESOTBASE) 
#define   ERRSOT       (ESOTBASE)         /* reserved */


#define   ESOT001      (ERRSOT +    1)    /*        sot.c:7636 */
#define   ESOT002      (ERRSOT +    2)    /*        sot.c:7641 */
#define   ESOT003      (ERRSOT +    3)    /*        sot.c:7642 */
#define   ESOT004      (ERRSOT +    4)    /*        sot.c:7686 */
#define   ESOT005      (ERRSOT +    5)    /*        sot.c:7691 */
#define   ESOT006      (ERRSOT +    6)    /*        sot.c:7692 */
#define   ESOT007      (ERRSOT +    7)    /*        sot.c:7738 */
#define   ESOT008      (ERRSOT +    8)    /*        sot.c:7754 */
#define   ESOT009      (ERRSOT +    9)    /*        sot.c:7763 */
#define   ESOT010      (ERRSOT +   10)    /*        sot.c:7767 */
#define   ESOT011      (ERRSOT +   11)    /*        sot.c:7768 */
#define   ESOT012      (ERRSOT +   12)    /*        sot.c:7816 */
#define   ESOT013      (ERRSOT +   13)    /*        sot.c:7832 */
#define   ESOT014      (ERRSOT +   14)    /*        sot.c:7841 */
#define   ESOT015      (ERRSOT +   15)    /*        sot.c:7845 */
#define   ESOT016      (ERRSOT +   16)    /*        sot.c:7846 */
#define   ESOT017      (ERRSOT +   17)    /*        sot.c:7847 */
#define   ESOT018      (ERRSOT +   18)    /*        sot.c:7895 */
#define   ESOT019      (ERRSOT +   19)    /*        sot.c:7911 */
#define   ESOT020      (ERRSOT +   20)    /*        sot.c:7920 */
#define   ESOT021      (ERRSOT +   21)    /*        sot.c:7924 */
#define   ESOT022      (ERRSOT +   22)    /*        sot.c:7925 */
#define   ESOT023      (ERRSOT +   23)    /*        sot.c:7926 */
#define   ESOT024      (ERRSOT +   24)    /*        sot.c:7975 */
#define   ESOT025      (ERRSOT +   25)    /*        sot.c:7991 */
#define   ESOT026      (ERRSOT +   26)    /*        sot.c:8000 */
#define   ESOT027      (ERRSOT +   27)    /*        sot.c:8004 */
#define   ESOT028      (ERRSOT +   28)    /*        sot.c:8005 */
#define   ESOT029      (ERRSOT +   29)    /*        sot.c:8006 */
#define   ESOT030      (ERRSOT +   30)    /*        sot.c:8054 */
#define   ESOT031      (ERRSOT +   31)    /*        sot.c:8070 */
#define   ESOT032      (ERRSOT +   32)    /*        sot.c:8079 */
#define   ESOT033      (ERRSOT +   33)    /*        sot.c:8083 */
#define   ESOT034      (ERRSOT +   34)    /*        sot.c:8084 */
#define   ESOT035      (ERRSOT +   35)    /*        sot.c:8085 */
#define   ESOT036      (ERRSOT +   36)    /*        sot.c:8134 */
#define   ESOT037      (ERRSOT +   37)    /*        sot.c:8150 */
#define   ESOT038      (ERRSOT +   38)    /*        sot.c:8159 */
#define   ESOT039      (ERRSOT +   39)    /*        sot.c:8163 */
#define   ESOT040      (ERRSOT +   40)    /*        sot.c:8164 */
#define   ESOT041      (ERRSOT +   41)    /*        sot.c:8165 */
#define   ESOT042      (ERRSOT +   42)    /*        sot.c:8213 */
#define   ESOT043      (ERRSOT +   43)    /*        sot.c:8229 */
#define   ESOT044      (ERRSOT +   44)    /*        sot.c:8238 */
#define   ESOT045      (ERRSOT +   45)    /*        sot.c:8242 */
#define   ESOT046      (ERRSOT +   46)    /*        sot.c:8243 */
#define   ESOT047      (ERRSOT +   47)    /*        sot.c:8244 */
#define   ESOT048      (ERRSOT +   48)    /*        sot.c:8292 */
#define   ESOT049      (ERRSOT +   49)    /*        sot.c:8308 */
#define   ESOT050      (ERRSOT +   50)    /*        sot.c:8317 */
#define   ESOT051      (ERRSOT +   51)    /*        sot.c:8321 */
#define   ESOT052      (ERRSOT +   52)    /*        sot.c:8322 */
#define   ESOT053      (ERRSOT +   53)    /*        sot.c:8323 */
#define   ESOT054      (ERRSOT +   54)    /*        sot.c:8371 */
#define   ESOT055      (ERRSOT +   55)    /*        sot.c:8387 */
#define   ESOT056      (ERRSOT +   56)    /*        sot.c:8396 */
#define   ESOT057      (ERRSOT +   57)    /*        sot.c:8400 */
#define   ESOT058      (ERRSOT +   58)    /*        sot.c:8401 */
#define   ESOT059      (ERRSOT +   59)    /*        sot.c:8402 */
#define   ESOT060      (ERRSOT +   60)    /*        sot.c:8450 */
#define   ESOT061      (ERRSOT +   61)    /*        sot.c:8466 */
#define   ESOT062      (ERRSOT +   62)    /*        sot.c:8475 */
#define   ESOT063      (ERRSOT +   63)    /*        sot.c:8479 */
#define   ESOT064      (ERRSOT +   64)    /*        sot.c:8480 */
#define   ESOT065      (ERRSOT +   65)    /*        sot.c:8481 */
#define   ESOT066      (ERRSOT +   66)    /*        sot.c:8529 */
#define   ESOT067      (ERRSOT +   67)    /*        sot.c:8545 */
#define   ESOT068      (ERRSOT +   68)    /*        sot.c:8554 */
#define   ESOT069      (ERRSOT +   69)    /*        sot.c:8558 */
#define   ESOT070      (ERRSOT +   70)    /*        sot.c:8559 */
#define   ESOT071      (ERRSOT +   71)    /*        sot.c:8560 */
#define   ESOT072      (ERRSOT +   72)    /*        sot.c:8605 */
#define   ESOT073      (ERRSOT +   73)    /*        sot.c:8621 */
#define   ESOT074      (ERRSOT +   74)    /*        sot.c:8630 */
#define   ESOT075      (ERRSOT +   75)    /*        sot.c:8634 */
#define   ESOT076      (ERRSOT +   76)    /*        sot.c:8678 */
#define   ESOT077      (ERRSOT +   77)    /*        sot.c:8694 */
#define   ESOT078      (ERRSOT +   78)    /*        sot.c:8703 */
#define   ESOT079      (ERRSOT +   79)    /*        sot.c:8707 */
#define   ESOT080      (ERRSOT +   80)    /*        sot.c:8756 */
#define   ESOT081      (ERRSOT +   81)    /*        sot.c:8772 */
#define   ESOT082      (ERRSOT +   82)    /*        sot.c:8781 */
#define   ESOT083      (ERRSOT +   83)    /*        sot.c:8785 */
#define   ESOT084      (ERRSOT +   84)    /*        sot.c:8786 */
#define   ESOT085      (ERRSOT +   85)    /*        sot.c:8787 */
#define   ESOT086      (ERRSOT +   86)    /*        sot.c:8835 */
#define   ESOT087      (ERRSOT +   87)    /*        sot.c:8851 */
#define   ESOT088      (ERRSOT +   88)    /*        sot.c:8860 */
#define   ESOT089      (ERRSOT +   89)    /*        sot.c:8864 */
#define   ESOT090      (ERRSOT +   90)    /*        sot.c:8865 */
#define   ESOT091      (ERRSOT +   91)    /*        sot.c:8866 */
#define   ESOT092      (ERRSOT +   92)    /*        sot.c:8913 */
#define   ESOT093      (ERRSOT +   93)    /*        sot.c:8929 */
#define   ESOT094      (ERRSOT +   94)    /*        sot.c:8938 */
#define   ESOT095      (ERRSOT +   95)    /*        sot.c:8942 */
#define   ESOT096      (ERRSOT +   96)    /*        sot.c:8988 */
#define   ESOT097      (ERRSOT +   97)    /*        sot.c:8993 */
#define   ESOT098      (ERRSOT +   98)    /*        sot.c:8994 */
#define   ESOT099      (ERRSOT +   99)    /*        sot.c:9040 */
#define   ESOT100      (ERRSOT +  100)    /*        sot.c:9056 */
#define   ESOT101      (ERRSOT +  101)    /*        sot.c:9065 */
#define   ESOT102      (ERRSOT +  102)    /*        sot.c:9069 */
#define   ESOT103      (ERRSOT +  103)    /*        sot.c:9070 */
#define   ESOT104      (ERRSOT +  104)    /*        sot.c:9118 */
#define   ESOT105      (ERRSOT +  105)    /*        sot.c:9134 */
#define   ESOT106      (ERRSOT +  106)    /*        sot.c:9143 */
#define   ESOT107      (ERRSOT +  107)    /*        sot.c:9147 */
#define   ESOT108      (ERRSOT +  108)    /*        sot.c:9148 */
#define   ESOT109      (ERRSOT +  109)    /*        sot.c:9149 */
#define   ESOT110      (ERRSOT +  110)    /*        sot.c:9197 */
#define   ESOT111      (ERRSOT +  111)    /*        sot.c:9213 */
#define   ESOT112      (ERRSOT +  112)    /*        sot.c:9222 */
#define   ESOT113      (ERRSOT +  113)    /*        sot.c:9226 */
#define   ESOT114      (ERRSOT +  114)    /*        sot.c:9227 */
#define   ESOT115      (ERRSOT +  115)    /*        sot.c:9228 */
#define   ESOT116      (ERRSOT +  116)    /*        sot.c:9276 */
#define   ESOT117      (ERRSOT +  117)    /*        sot.c:9292 */
#define   ESOT118      (ERRSOT +  118)    /*        sot.c:9301 */
#define   ESOT119      (ERRSOT +  119)    /*        sot.c:9305 */
#define   ESOT120      (ERRSOT +  120)    /*        sot.c:9306 */
#define   ESOT121      (ERRSOT +  121)    /*        sot.c:9307 */
#define   ESOT122      (ERRSOT +  122)    /*        sot.c:9355 */
#define   ESOT123      (ERRSOT +  123)    /*        sot.c:9371 */
#define   ESOT124      (ERRSOT +  124)    /*        sot.c:9380 */
#define   ESOT125      (ERRSOT +  125)    /*        sot.c:9384 */
#define   ESOT126      (ERRSOT +  126)    /*        sot.c:9385 */
#define   ESOT127      (ERRSOT +  127)    /*        sot.c:9386 */
#define   ESOT128      (ERRSOT +  128)    /*        sot.c:9434 */
#define   ESOT129      (ERRSOT +  129)    /*        sot.c:9450 */
#define   ESOT130      (ERRSOT +  130)    /*        sot.c:9459 */
#define   ESOT131      (ERRSOT +  131)    /*        sot.c:9463 */
#define   ESOT132      (ERRSOT +  132)    /*        sot.c:9464 */
#define   ESOT133      (ERRSOT +  133)    /*        sot.c:9465 */
#define   ESOT134      (ERRSOT +  134)    /*        sot.c:9513 */
#define   ESOT135      (ERRSOT +  135)    /*        sot.c:9529 */
#define   ESOT136      (ERRSOT +  136)    /*        sot.c:9538 */
#define   ESOT137      (ERRSOT +  137)    /*        sot.c:9542 */
#define   ESOT138      (ERRSOT +  138)    /*        sot.c:9543 */
#define   ESOT139      (ERRSOT +  139)    /*        sot.c:9544 */
#define   ESOT140      (ERRSOT +  140)    /*        sot.c:9592 */
#define   ESOT141      (ERRSOT +  141)    /*        sot.c:9608 */
#define   ESOT142      (ERRSOT +  142)    /*        sot.c:9617 */
#define   ESOT143      (ERRSOT +  143)    /*        sot.c:9621 */
#define   ESOT144      (ERRSOT +  144)    /*        sot.c:9622 */
#define   ESOT145      (ERRSOT +  145)    /*        sot.c:9623 */
#define   ESOT146      (ERRSOT +  146)    /*        sot.c:9674 */
#define   ESOT147      (ERRSOT +  147)    /*        sot.c:9690 */
#define   ESOT148      (ERRSOT +  148)    /*        sot.c:9699 */
#define   ESOT149      (ERRSOT +  149)    /*        sot.c:9703 */
#define   ESOT150      (ERRSOT +  150)    /*        sot.c:9704 */
#define   ESOT151      (ERRSOT +  151)    /*        sot.c:9705 */
#define   ESOT152      (ERRSOT +  152)    /*        sot.c:9706 */
#define   ESOT153      (ERRSOT +  153)    /*        sot.c:9750 */
#define   ESOT154      (ERRSOT +  154)    /*        sot.c:9766 */
#define   ESOT155      (ERRSOT +  155)    /*        sot.c:9775 */
#define   ESOT156      (ERRSOT +  156)    /*        sot.c:9779 */
#define   ESOT157      (ERRSOT +  157)    /*        sot.c:9823 */
#define   ESOT158      (ERRSOT +  158)    /*        sot.c:9839 */
#define   ESOT159      (ERRSOT +  159)    /*        sot.c:9848 */
#define   ESOT160      (ERRSOT +  160)    /*        sot.c:9852 */
#define   ESOT161      (ERRSOT +  161)    /*        sot.c:9901 */
#define   ESOT162      (ERRSOT +  162)    /*        sot.c:9917 */
#define   ESOT163      (ERRSOT +  163)    /*        sot.c:9926 */
#define   ESOT164      (ERRSOT +  164)    /*        sot.c:9930 */
#define   ESOT165      (ERRSOT +  165)    /*        sot.c:9931 */
#define   ESOT166      (ERRSOT +  166)    /*        sot.c:9932 */
#define   ESOT167      (ERRSOT +  167)    /*        sot.c:9980 */
#define   ESOT168      (ERRSOT +  168)    /*        sot.c:9996 */
#define   ESOT169      (ERRSOT +  169)    /*        sot.c:10005 */
#define   ESOT170      (ERRSOT +  170)    /*        sot.c:10009 */
#define   ESOT171      (ERRSOT +  171)    /*        sot.c:10010 */
#define   ESOT172      (ERRSOT +  172)    /*        sot.c:10011 */
#define   ESOT173      (ERRSOT +  173)    /*        sot.c:10059 */
#define   ESOT174      (ERRSOT +  174)    /*        sot.c:10075 */
#define   ESOT175      (ERRSOT +  175)    /*        sot.c:10084 */
#define   ESOT176      (ERRSOT +  176)    /*        sot.c:10088 */
#define   ESOT177      (ERRSOT +  177)    /*        sot.c:10089 */
#define   ESOT178      (ERRSOT +  178)    /*        sot.c:10090 */
#define   ESOT179      (ERRSOT +  179)    /*        sot.c:10140 */
#define   ESOT180      (ERRSOT +  180)    /*        sot.c:10156 */
#define   ESOT181      (ERRSOT +  181)    /*        sot.c:10165 */
#define   ESOT182      (ERRSOT +  182)    /*        sot.c:10169 */
#define   ESOT183      (ERRSOT +  183)    /*        sot.c:10170 */
#define   ESOT184      (ERRSOT +  184)    /*        sot.c:10171 */
#define   ESOT185      (ERRSOT +  185)    /*        sot.c:10219 */
#define   ESOT186      (ERRSOT +  186)    /*        sot.c:10235 */
#define   ESOT187      (ERRSOT +  187)    /*        sot.c:10244 */
#define   ESOT188      (ERRSOT +  188)    /*        sot.c:10248 */
#define   ESOT189      (ERRSOT +  189)    /*        sot.c:10249 */
#define   ESOT190      (ERRSOT +  190)    /*        sot.c:10250 */
#define   ESOT191      (ERRSOT +  191)    /*        sot.c:10296 */
#define   ESOT192      (ERRSOT +  192)    /*        sot.c:10312 */
#define   ESOT193      (ERRSOT +  193)    /*        sot.c:10321 */
#define   ESOT194      (ERRSOT +  194)    /*        sot.c:10325 */
#define   ESOT195      (ERRSOT +  195)    /*        sot.c:10375 */
#define   ESOT196      (ERRSOT +  196)    /*        sot.c:10391 */
#define   ESOT197      (ERRSOT +  197)    /*        sot.c:10400 */
#define   ESOT198      (ERRSOT +  198)    /*        sot.c:10404 */
#define   ESOT199      (ERRSOT +  199)    /*        sot.c:10405 */
#define   ESOT200      (ERRSOT +  200)    /*        sot.c:10406 */
#define   ESOT201      (ERRSOT +  201)    /*        sot.c:10454 */
#define   ESOT202      (ERRSOT +  202)    /*        sot.c:10470 */
#define   ESOT203      (ERRSOT +  203)    /*        sot.c:10479 */
#define   ESOT204      (ERRSOT +  204)    /*        sot.c:10483 */
#define   ESOT205      (ERRSOT +  205)    /*        sot.c:10484 */
#define   ESOT206      (ERRSOT +  206)    /*        sot.c:10485 */
#define   ESOT207      (ERRSOT +  207)    /*        sot.c:18382 */
#define   ESOT208      (ERRSOT +  208)    /*        sot.c:18383 */
#define   ESOT209      (ERRSOT +  209)    /*        sot.c:18420 */
#define   ESOT210      (ERRSOT +  210)    /*        sot.c:18421 */
#define   ESOT211      (ERRSOT +  211)    /*        sot.c:18466 */
#define   ESOT212      (ERRSOT +  212)    /*        sot.c:18467 */
#define   ESOT213      (ERRSOT +  213)    /*        sot.c:18484 */
#define   ESOT214      (ERRSOT +  214)    /*        sot.c:18492 */
#define   ESOT215      (ERRSOT +  215)    /*        sot.c:18541 */
#define   ESOT216      (ERRSOT +  216)    /*        sot.c:18542 */
#define   ESOT217      (ERRSOT +  217)    /*        sot.c:18543 */
#define   ESOT218      (ERRSOT +  218)    /*        sot.c:18560 */
#define   ESOT219      (ERRSOT +  219)    /*        sot.c:18568 */
#define   ESOT220      (ERRSOT +  220)    /*        sot.c:18617 */
#define   ESOT221      (ERRSOT +  221)    /*        sot.c:18618 */
#define   ESOT222      (ERRSOT +  222)    /*        sot.c:18619 */
#define   ESOT223      (ERRSOT +  223)    /*        sot.c:18636 */
#define   ESOT224      (ERRSOT +  224)    /*        sot.c:18644 */
#define   ESOT225      (ERRSOT +  225)    /*        sot.c:18694 */
#define   ESOT226      (ERRSOT +  226)    /*        sot.c:18695 */
#define   ESOT227      (ERRSOT +  227)    /*        sot.c:18696 */
#define   ESOT228      (ERRSOT +  228)    /*        sot.c:18713 */
#define   ESOT229      (ERRSOT +  229)    /*        sot.c:18721 */
#define   ESOT230      (ERRSOT +  230)    /*        sot.c:18770 */
#define   ESOT231      (ERRSOT +  231)    /*        sot.c:18771 */
#define   ESOT232      (ERRSOT +  232)    /*        sot.c:18772 */
#define   ESOT233      (ERRSOT +  233)    /*        sot.c:18789 */
#define   ESOT234      (ERRSOT +  234)    /*        sot.c:18797 */
#define   ESOT235      (ERRSOT +  235)    /*        sot.c:18847 */
#define   ESOT236      (ERRSOT +  236)    /*        sot.c:18848 */
#define   ESOT237      (ERRSOT +  237)    /*        sot.c:18849 */
#define   ESOT238      (ERRSOT +  238)    /*        sot.c:18866 */
#define   ESOT239      (ERRSOT +  239)    /*        sot.c:18874 */
#define   ESOT240      (ERRSOT +  240)    /*        sot.c:18923 */
#define   ESOT241      (ERRSOT +  241)    /*        sot.c:18924 */
#define   ESOT242      (ERRSOT +  242)    /*        sot.c:18925 */
#define   ESOT243      (ERRSOT +  243)    /*        sot.c:18942 */
#define   ESOT244      (ERRSOT +  244)    /*        sot.c:18950 */
#define   ESOT245      (ERRSOT +  245)    /*        sot.c:18999 */
#define   ESOT246      (ERRSOT +  246)    /*        sot.c:19000 */
#define   ESOT247      (ERRSOT +  247)    /*        sot.c:19001 */
#define   ESOT248      (ERRSOT +  248)    /*        sot.c:19018 */
#define   ESOT249      (ERRSOT +  249)    /*        sot.c:19026 */
#define   ESOT250      (ERRSOT +  250)    /*        sot.c:19075 */
#define   ESOT251      (ERRSOT +  251)    /*        sot.c:19076 */
#define   ESOT252      (ERRSOT +  252)    /*        sot.c:19077 */
#define   ESOT253      (ERRSOT +  253)    /*        sot.c:19094 */
#define   ESOT254      (ERRSOT +  254)    /*        sot.c:19102 */
#define   ESOT255      (ERRSOT +  255)    /*        sot.c:19151 */
#define   ESOT256      (ERRSOT +  256)    /*        sot.c:19152 */
#define   ESOT257      (ERRSOT +  257)    /*        sot.c:19153 */
#define   ESOT258      (ERRSOT +  258)    /*        sot.c:19170 */
#define   ESOT259      (ERRSOT +  259)    /*        sot.c:19178 */
#define   ESOT260      (ERRSOT +  260)    /*        sot.c:19227 */
#define   ESOT261      (ERRSOT +  261)    /*        sot.c:19228 */
#define   ESOT262      (ERRSOT +  262)    /*        sot.c:19229 */
#define   ESOT263      (ERRSOT +  263)    /*        sot.c:19246 */
#define   ESOT264      (ERRSOT +  264)    /*        sot.c:19254 */
#define   ESOT265      (ERRSOT +  265)    /*        sot.c:19302 */
#define   ESOT266      (ERRSOT +  266)    /*        sot.c:19319 */
#define   ESOT267      (ERRSOT +  267)    /*        sot.c:19327 */
#define   ESOT268      (ERRSOT +  268)    /*        sot.c:19374 */
#define   ESOT269      (ERRSOT +  269)    /*        sot.c:19391 */
#define   ESOT270      (ERRSOT +  270)    /*        sot.c:19399 */
#define   ESOT271      (ERRSOT +  271)    /*        sot.c:19449 */
#define   ESOT272      (ERRSOT +  272)    /*        sot.c:19450 */
#define   ESOT273      (ERRSOT +  273)    /*        sot.c:19451 */
#define   ESOT274      (ERRSOT +  274)    /*        sot.c:19468 */
#define   ESOT275      (ERRSOT +  275)    /*        sot.c:19476 */
#define   ESOT276      (ERRSOT +  276)    /*        sot.c:19525 */
#define   ESOT277      (ERRSOT +  277)    /*        sot.c:19526 */
#define   ESOT278      (ERRSOT +  278)    /*        sot.c:19527 */
#define   ESOT279      (ERRSOT +  279)    /*        sot.c:19544 */
#define   ESOT280      (ERRSOT +  280)    /*        sot.c:19552 */
#define   ESOT281      (ERRSOT +  281)    /*        sot.c:19602 */
#define   ESOT282      (ERRSOT +  282)    /*        sot.c:19619 */
#define   ESOT283      (ERRSOT +  283)    /*        sot.c:19627 */
#define   ESOT284      (ERRSOT +  284)    /*        sot.c:19669 */
#define   ESOT285      (ERRSOT +  285)    /*        sot.c:19670 */
#define   ESOT286      (ERRSOT +  286)    /*        sot.c:19715 */
#define   ESOT287      (ERRSOT +  287)    /*        sot.c:19716 */
#define   ESOT288      (ERRSOT +  288)    /*        sot.c:19733 */
#define   ESOT289      (ERRSOT +  289)    /*        sot.c:19741 */
#define   ESOT290      (ERRSOT +  290)    /*        sot.c:19790 */
#define   ESOT291      (ERRSOT +  291)    /*        sot.c:19791 */
#define   ESOT292      (ERRSOT +  292)    /*        sot.c:19792 */
#define   ESOT293      (ERRSOT +  293)    /*        sot.c:19809 */
#define   ESOT294      (ERRSOT +  294)    /*        sot.c:19817 */
#define   ESOT295      (ERRSOT +  295)    /*        sot.c:19866 */
#define   ESOT296      (ERRSOT +  296)    /*        sot.c:19867 */
#define   ESOT297      (ERRSOT +  297)    /*        sot.c:19868 */
#define   ESOT298      (ERRSOT +  298)    /*        sot.c:19885 */
#define   ESOT299      (ERRSOT +  299)    /*        sot.c:19893 */
#define   ESOT300      (ERRSOT +  300)    /*        sot.c:19942 */
#define   ESOT301      (ERRSOT +  301)    /*        sot.c:19943 */
#define   ESOT302      (ERRSOT +  302)    /*        sot.c:19944 */
#define   ESOT303      (ERRSOT +  303)    /*        sot.c:19961 */
#define   ESOT304      (ERRSOT +  304)    /*        sot.c:19969 */
#define   ESOT305      (ERRSOT +  305)    /*        sot.c:20018 */
#define   ESOT306      (ERRSOT +  306)    /*        sot.c:20019 */
#define   ESOT307      (ERRSOT +  307)    /*        sot.c:20020 */
#define   ESOT308      (ERRSOT +  308)    /*        sot.c:20037 */
#define   ESOT309      (ERRSOT +  309)    /*        sot.c:20045 */
#define   ESOT310      (ERRSOT +  310)    /*        sot.c:20094 */
#define   ESOT311      (ERRSOT +  311)    /*        sot.c:20095 */
#define   ESOT312      (ERRSOT +  312)    /*        sot.c:20096 */
#define   ESOT313      (ERRSOT +  313)    /*        sot.c:20113 */
#define   ESOT314      (ERRSOT +  314)    /*        sot.c:20121 */
#define   ESOT315      (ERRSOT +  315)    /*        sot.c:20170 */
#define   ESOT316      (ERRSOT +  316)    /*        sot.c:20171 */
#define   ESOT317      (ERRSOT +  317)    /*        sot.c:20172 */
#define   ESOT318      (ERRSOT +  318)    /*        sot.c:20189 */
#define   ESOT319      (ERRSOT +  319)    /*        sot.c:20197 */
#define   ESOT320      (ERRSOT +  320)    /*        sot.c:20246 */
#define   ESOT321      (ERRSOT +  321)    /*        sot.c:20247 */
#define   ESOT322      (ERRSOT +  322)    /*        sot.c:20248 */
#define   ESOT323      (ERRSOT +  323)    /*        sot.c:20265 */
#define   ESOT324      (ERRSOT +  324)    /*        sot.c:20273 */
#define   ESOT325      (ERRSOT +  325)    /*        sot.c:20324 */
#define   ESOT326      (ERRSOT +  326)    /*        sot.c:20325 */
#define   ESOT327      (ERRSOT +  327)    /*        sot.c:20326 */
#define   ESOT328      (ERRSOT +  328)    /*        sot.c:20327 */
#define   ESOT329      (ERRSOT +  329)    /*        sot.c:20344 */
#define   ESOT330      (ERRSOT +  330)    /*        sot.c:20352 */
#define   ESOT331      (ERRSOT +  331)    /*        sot.c:20399 */
#define   ESOT332      (ERRSOT +  332)    /*        sot.c:20416 */
#define   ESOT333      (ERRSOT +  333)    /*        sot.c:20424 */
#define   ESOT334      (ERRSOT +  334)    /*        sot.c:20471 */
#define   ESOT335      (ERRSOT +  335)    /*        sot.c:20488 */
#define   ESOT336      (ERRSOT +  336)    /*        sot.c:20496 */
#define   ESOT337      (ERRSOT +  337)    /*        sot.c:20546 */
#define   ESOT338      (ERRSOT +  338)    /*        sot.c:20547 */
#define   ESOT339      (ERRSOT +  339)    /*        sot.c:20548 */
#define   ESOT340      (ERRSOT +  340)    /*        sot.c:20565 */
#define   ESOT341      (ERRSOT +  341)    /*        sot.c:20573 */
#define   ESOT342      (ERRSOT +  342)    /*        sot.c:20622 */
#define   ESOT343      (ERRSOT +  343)    /*        sot.c:20623 */
#define   ESOT344      (ERRSOT +  344)    /*        sot.c:20624 */
#define   ESOT345      (ERRSOT +  345)    /*        sot.c:20641 */
#define   ESOT346      (ERRSOT +  346)    /*        sot.c:20649 */
#define   ESOT347      (ERRSOT +  347)    /*        sot.c:20698 */
#define   ESOT348      (ERRSOT +  348)    /*        sot.c:20699 */
#define   ESOT349      (ERRSOT +  349)    /*        sot.c:20700 */
#define   ESOT350      (ERRSOT +  350)    /*        sot.c:20717 */
#define   ESOT351      (ERRSOT +  351)    /*        sot.c:20725 */
#define   ESOT352      (ERRSOT +  352)    /*        sot.c:20776 */
#define   ESOT353      (ERRSOT +  353)    /*        sot.c:20777 */
#define   ESOT354      (ERRSOT +  354)    /*        sot.c:20778 */
#define   ESOT355      (ERRSOT +  355)    /*        sot.c:20795 */
#define   ESOT356      (ERRSOT +  356)    /*        sot.c:20803 */
#define   ESOT357      (ERRSOT +  357)    /*        sot.c:20852 */
#define   ESOT358      (ERRSOT +  358)    /*        sot.c:20853 */
#define   ESOT359      (ERRSOT +  359)    /*        sot.c:20854 */
#define   ESOT360      (ERRSOT +  360)    /*        sot.c:20871 */
#define   ESOT361      (ERRSOT +  361)    /*        sot.c:20879 */
#define   ESOT362      (ERRSOT +  362)    /*        sot.c:20927 */
#define   ESOT363      (ERRSOT +  363)    /*        sot.c:20944 */
#define   ESOT364      (ERRSOT +  364)    /*        sot.c:20952 */
#define   ESOT365      (ERRSOT +  365)    /*        sot.c:21002 */
#define   ESOT366      (ERRSOT +  366)    /*        sot.c:21003 */
#define   ESOT367      (ERRSOT +  367)    /*        sot.c:21004 */
#define   ESOT368      (ERRSOT +  368)    /*        sot.c:21021 */
#define   ESOT369      (ERRSOT +  369)    /*        sot.c:21029 */
#define   ESOT370      (ERRSOT +  370)    /*        sot.c:21078 */
#define   ESOT371      (ERRSOT +  371)    /*        sot.c:21079 */
#define   ESOT372      (ERRSOT +  372)    /*        sot.c:21080 */
#define   ESOT373      (ERRSOT +  373)    /*        sot.c:21097 */
#define   ESOT374      (ERRSOT +  374)    /*        sot.c:21105 */




/* Error codes used with SOT_ET_ERROR */
/* Returned in event->sipMsg.t.errEvnt.errCode */
/* NB: Update corresponding soSOTErrorDescrip in po_ui.c */

#define SOT_ERR_NOERR                 ROK /* no error  */

#define SOT_ERR_UNKNOWN               255 /* Unspecified error. 
                                           * The last er number reserved 
                                           * for unknown error */

#define SOT_ERR_TIMEOUT               1 /* Timeout error     */
#define SOT_ERR_ENC                   2 /* Encoding error    */
#define SOT_ERR_RSRC                  3 /* Resource error    */
#define SOT_ERR_ENT_INVALID           4 /* Invalid Entity for request */
#define SOT_ERR_INV_REQUEST           5 /* Invalid request for this primitive */
#define SOT_ERR_INV_ETYPE             6 /* Invalid eventType for primitive */
#define SOT_ERR_NONIP_NODNS           7 /* Non-IP address - no DNS available */
#define SOT_ERR_INVITE_EXPECTED       8 /* INVITE request expected */
#define SOT_ERR_USER_LOC_REG_REQD     9 /* User must be locally registered */
#define SOT_ERR_USER_UNAVAIL         10 /* User unavailable at the moment */
#define SOT_ERR_NO_REG_SVR_CFG       11 /* No Registrar Addr cfg  */
#define SOT_ERR_INVITE_REQ_FAILED    12 /* Invite Request build failed */
#define SOT_ERR_REGISTER_REQ_FAILED  13 /* Register Request build failed */
#define SOT_ERR_TPTSRVR_SELECT       14 /* Transport server selection failed */
#define SOT_ERR_DNS_FAILED           15 /* DNS Lookup has failed */
#define SOT_ERR_ADD_HDR_FAILED       16 /* Error while adding a SIP header */
#define SOT_ERR_CALL_NOTFOUND        17 /* CALL not found for this Call-Id */
#define SOT_ERR_CLEG_EXISTS          18 /* Call Leg already exists */
#define SOT_ERR_CLEG_NOTFOUND        19 /* Call Leg not found */
#define SOT_ERR_TRAN_NOTFOUND        20 /* Transaction not found */
#define SOT_ERR_TRAN_LOCATE          21 /* could not locate Tran */
#define SOT_ERR_REQUIRE_FAIL         22 /* Require header add failed */
#define SOT_ERR_RSEQ_FAIL            23 /* RSEQ could not be added to msg */
#define SOT_ERR_LOCREG_INV           24 /* Local Reg is for 3rd Party */
#define SOT_ERR_LOCREG_FAILED        25 /* Local Reg has failed */
#define SOT_ERR_SSAP_DIS             26 /* Disable/Delete SSAP */
#define SOT_ERR_ENT_DIS              27 /* Disable/Delete Entity */
#define SOT_ERR_SENDING              28 /* Error in sending SIP message */
#define SOT_ERR_ADDING_RROUTE_HDR    29 /* Error while adding Record-Route header */
#define SOT_ERR_REG_CONTACT_STAR     30 /* REGISTER with Contact *, no expires */
#define SOT_ERR_CLEGSTATE_INVALID    31 /* Primitive not allowed in this state */
#define SOT_ERR_CONTENTTYPE_NOTFOUND 32 /* CONTENTTYPE header not found */
#define SOT_ERR_MIMEBNDRY_NOTFOUND   33 /* MIME Boundary value not found */
#define SOT_ERR_CALLID_NOTSPECIFIED  34 /* CallId not specified  */
#define SOT_ERR_VIA_INVALID          35 /* Via header not matching with correct transport server*/
#define SOT_ERR_REG_IN_PROGRESS      36 /* There is already a registration in
                                           progress in the system sent to 
                                           the same Registrar */
#define SOT_ERR_CSEQ_UNACCEPTABLE    37 /* CSeq nnumber is not acceptable  */
#define SOT_ERR_REL_PROVRSP_NOTALLWD 38 /* Reliable prov rsp not supported  */
#define SOT_ERR_INV_EVNT             39 /* Invalid event */
#define SOT_ERR_INV_SSAP             40 /* Invalid event */
#define SOT_ERR_INV_ENT              41 /* Invalid event */
#define SOT_ERR_ENT_STATE            42 /* Invalid event */
#define SOT_ERR_SSAP_STATE           43 /* Invalid event */
#define SOT_ERR_SUBSC_TMO            44 /* Subscribe timeout */
#define SOT_ERR_REFER_TMO            45 /* Refer timeout */
#define SOT_ERR_INVALID_CALLID       46 /* Invalid callid */
#define SOT_ERR_INVALID_HDR          47 /* Invalid callid */
#define SOT_ERR_METHOD_NOTSUPP       48 /* Unsuported method */
#define SOT_ERR_MULTRSP_CLEG         49 /* Additional call legs for a forked call being cleared */
#define SOT_ERR_EXPIRES_TIMEOUT      50 /* Expires Timer timeout */
#define SOT_ERR_CANCEL_TIMEOUT       51 /* Cancel Timer Expiry */
#define SOT_ERR_ANSWER_PENDING       52 /* Answer pending for offer sent earlier */
#define SOT_ERR_OFFER_REQUIRED       53 /* Offer Required */
#define SOT_ERR_MAND_HDR             54 /* Error adding Mandatory Headers */

#define SOT_ERR_MAX                  55 /* Maximum value of error code  */


/* union type in error event */
#define SOT_ERREVNT_UNION_TYPE_REFER 0   /* refer union type */
#define SOT_ERREVNT_UNION_TYPE_SUBSC 1   /* refer union type */

/* call created by */
#define   SOT_REGISTER   1    /* internal recurse ends */
#define   SOT_CIM        2    /* internal recurse ends */

/* Connection release types */
#define   SOT_RELTYPE_LOCAL     1    /* local    */
#define   SOT_RELTYPE_REMOTE    2    /* remote   */
#define   SOT_RELTYPE_REDIRECT  3    /* redirect */
#define   SOT_RELTYPE_RECURSE   4    /* internal recurse starts */
#define   SOT_RELTYPE_RECSEND   5    /* internal recurse ends */

/* Selectors for loosely coupled */
#define   SO_SSAP_LC            0   /* Loosely coupled */
#define   SO_SSAP_LWLC          2   /* Lightweight loosely coupled */
#define   SO_SSAP_LC_SS         3   /* Loosely coupled to SS chendh */
#define   SO_SSAP_LWLC_SS       4   /* Lightweight loosely coupled to SS chendh*/

/* Event types for loosely coupled */
#define   EVTSOTBNDREQ         1
#define   EVTSOTUBNDREQ        2
#define   EVTSOTCONREQ         3
#define   EVTSOTCONRSP         4
#define   EVTSOTCNSTREQ        5
#define   EVTSOTRELREQ         6
#define   EVTSOTRELRSP         7
#define   EVTSOTMODREQ         8
#define   EVTSOTMODRSP         9
#define   EVTSOTCIMREQ        10
#define   EVTSOTCIMRSP        11
#define   EVTSOTBNDCFM        12
#define   EVTSOTCIMIND        13
#define   EVTSOTCIMCFM        14
#define   EVTSOTCONIND        15
#define   EVTSOTCONCFM        16
#define   EVTSOTRELCFM        17
#define   EVTSOTMODIND        18
#define   EVTSOTMODCFM        19
#define   EVTSOTCNSTIND       20
#define   EVTSOTRELIND        21
#define   EVTSOTCAMREQ        22
#define   EVTSOTCAMCFM        23
#define   EVTSOTCAMIND        24
#define   EVTSOTCAMRSP        25

#define   EVTSOTACKREQ        26
#define   EVTSOTACKIND        27
#define   EVTSOTCANCELREQ     28
#define   EVTSOTCANCELIND     29
#define   EVTSOTAUDITREQ      30
#define   EVTSOTAUDITCFM      31
#define   EVTSOTERRIND        32
#define   EVTSOTREFRESHIND    33

/*- sot_h_002.main_10 : Packing/Unpacking for Lawful Call Intercept -*/
#define   EVTSOTRAWMSG        34

#define SO_EXTVAL_STD                     1  /* soExtVal Parameter: std */
#define SO_EXTVAL_NONSTD                  2  /* soExtVal Parameter: nonStd */

/*----------- SIP SCeq Methods ----------*/
#define SO_METHOD_METHODSTD               SO_EXTVAL_STD    /* Method: Standard Method */
#define SO_METHOD_EXTENSIONMETHOD         SO_EXTVAL_NONSTD /* Method: Extension */

#define SO_METHODSTD_INVALID              0  /* Non-std method: Internal use */
#define SO_METHODSTD_INVITE               1  /* Standard Method Invite */
#define SO_METHODSTD_ACK                  2  /* Standard Method Acknowledge */
#define SO_METHODSTD_OPTIONS              3  /* Standard Method Options */
#define SO_METHODSTD_BYE                  4  /* Standard Method Bye */
#define SO_METHODSTD_CANCEL               5  /* Standard Method Cancel */
#define SO_METHODSTD_REGISTER             6  /* Standard Method Register */
#define SO_METHODSTD_INFO                 7  /* Standard Method Infor */
#define SO_METHODSTD_COMET                8  /* Standard Method Comet */
#define SO_METHODSTD_PRACK                9  /* Standard Method PRAck */
#define SO_METHODSTD_REFER                10 /* Standard Method REFER */
#define SO_METHODSTD_SUBSCRIBE            11 /* Standard Method SUBSCRIBE */
#define SO_METHODSTD_NOTIFY               12 /* Standard Method NOTIFY */
#define SO_METHODSTD_MESSAGE              13 /* Standard Method MESSAGE */
#define SO_METHODSTD_UPDATE               14 /* Standard Method MESSAGE */
#define SO_METHODSTD_MAX                  15 /* Total number of Methods */




/*--------- ALL SIP Event types ---------*/

#define SOT_ET_INVALID    SO_METHODSTD_INVALID
#define SOT_ET_INVITE     SO_METHODSTD_INVITE    
#define SOT_ET_ACK        SO_METHODSTD_ACK       
#define SOT_ET_OPTIONS    SO_METHODSTD_OPTIONS   
#define SOT_ET_BYE        SO_METHODSTD_BYE       
#define SOT_ET_CANCEL     SO_METHODSTD_CANCEL    
#define SOT_ET_REGISTER   SO_METHODSTD_REGISTER  
#define SOT_ET_INFO       SO_METHODSTD_INFO      
#define SOT_ET_PRECON_MET SO_METHODSTD_COMET     
#define SOT_ET_PRACK      SO_METHODSTD_PRACK     
#define SOT_ET_REFER      SO_METHODSTD_REFER     
#define SOT_ET_SUBSCRIBE  SO_METHODSTD_SUBSCRIBE 
#define SOT_ET_NOTIFY     SO_METHODSTD_NOTIFY    
#define SOT_ET_MESSAGE    SO_METHODSTD_MESSAGE   
#define SOT_ET_UPDATE     SO_METHODSTD_UPDATE   

#define SOT_ET_PROGRESS              SO_METHODSTD_MAX + 0  /* SIP PROGRESS status message   */
#define SOT_ET_TRYING                SO_METHODSTD_MAX + 1   /* SIP TRYING status message     */
#define SOT_ET_RINGING               SO_METHODSTD_MAX + 2   /* SIP RINGING status message    */
#define SOT_ET_FORWARDING            SO_METHODSTD_MAX + 3   /* SIP FORWARDING status message */
#define SOT_ET_QUEUED                SO_METHODSTD_MAX + 4   /* SIP QUEUED status message     */
#define SOT_ET_REDIRECT              SO_METHODSTD_MAX + 5   /* SIP REDIRECT status message   */
#define SOT_ET_ERROR                 SO_METHODSTD_MAX + 6   /* SIP ERROR status message      */
#define SOT_ET_OK                    SO_METHODSTD_MAX + 7   /* SIP OK status message         */
#define SOT_ET_REG_TMO               SO_METHODSTD_MAX + 8   /* SIP REGISTER time out         */
#define SOT_ET_LRQ                   SO_METHODSTD_MAX + 9    /* SIP Location Request         */
#define SOT_ET_MODIFY                SO_METHODSTD_MAX + 10   /* SIP MODIFY message           */
#define SOT_ET_STATUS                SO_METHODSTD_MAX + 11   /* SIP status message           */
#define SOT_ET_UNKNOWN               SO_METHODSTD_MAX + 12   /* SIP UNKNOWN message          */
#define SOT_ET_REGISTER_LOC          SO_METHODSTD_MAX + 13   /* SIP Register Locally message */
#define SOT_ET_SIP_ERROR             SO_METHODSTD_MAX + 14   /* SIP error message            */
#define SOT_ET_INT_REFRESHTMR_EXPD   SO_METHODSTD_MAX + 15  /* Refresh timer expd.   */
#define SOT_ET_INT_SESSTIMER_EXPD    SO_METHODSTD_MAX + 16  /* Session timer expd.   */
#define SOT_ET_SUBSC_TMO             SO_METHODSTD_MAX + 17   /* SIP SUBSCRIBE time out       */
#define SOT_ET_AUDIT                 SO_METHODSTD_MAX + 18   /* Audit request */
#define SOT_ET_REFRESH               SO_METHODSTD_MAX + 19   /* Refresh request */
#define SOT_ET_LOCAL_REL             SO_METHODSTD_MAX + 20   /* Used for locally deleting call context    */
#define SOT_ET_MAXIMUM               SO_METHODSTD_MAX + 21   /* Used for range checking      */

/* audit type */
#define SOT_AUDIT_CALL            1
#define SOT_AUDIT_SSAP            2

/* SIP Body Types */
#define SOT_BODYTYPE_SINGLEPART     1    /* Single-part body */
#define SOT_BODYTYPE_MULTIPART      2    /* Multi-part body  */

#define SOT_BODYSINGLEPART_STR      1    /* Single-part string */
#define SOT_BODYSINGLEPART_SDP      2    /* Single-part SDP    */


/* so Common Constant Definitions */
#define SO_WKDAY_MON                      1  /* Monday */
#define SO_WKDAY_TUE                      2  /* Tuesday */
#define SO_WKDAY_WED                      3  /* Wednesday */
#define SO_WKDAY_THU                      4  /* Thursday */
#define SO_WKDAY_FRI                      5  /* Friday */
#define SO_WKDAY_SAT                      6  /* Saturday */
#define SO_WKDAY_SUN                      7  /* Sunday */
#define SO_MONTH_JAN                      1  /* January */
#define SO_MONTH_FEB                      2  /* February */
#define SO_MONTH_MAR                      3  /* March */
#define SO_MONTH_APR                      4  /* April */
#define SO_MONTH_MAY                      5  /* May */
#define SO_MONTH_JUN                      6  /* June */
#define SO_MONTH_JUL                      7  /* July */
#define SO_MONTH_AUG                      8  /* August */
#define SO_MONTH_SEP                      9  /* September */
#define SO_MONTH_OCT                      10 /* October */
#define SO_MONTH_NOV                      11 /* November */
#define SO_MONTH_DEC                      12 /* December */

#define SO_VALUE_TOKEN                          1
#define SO_VALUE_QUOTEDSTR                      2

#ifdef SO_SESSTIMER

#define SO_MAX_SESSEXPPARS                0xFFFF  /* Max Params */

/* sot_h_001.main_10: New define */
#define SO_REFRESHER_NONE                 0  /* refresher - none */
#define SO_REFRESHER_UAC                  1  /* refresher - uac */
#define SO_REFRESHER_UAS                  2  /* refresher - uac */

#define SO_SESSION_EXP_REFRESHER          1  /* refresher */
#define SO_SESSION_EXP_EXTN               2  /* generic param */

#endif /* SO_SESSTIMER */


#define SO_REPLACES_PARAMTYPE_TOTAG       1
#define SO_REPLACES_PARAMTYPE_FROMTAG     2
#define SO_REPLACES_PARAMTYPE_EARLYONLY   3
#define SO_REPLACES_GENERIC_PARAMS        4
#define SO_MAX_REPLACEPARAM               0xFFFF

/* These values should match the values in lso.h */
#define SO_TRANSPORT_UDP                  1  /* Transport Parameter UDP */
#define SO_TRANSPORT_TCP                  2  /* Transport Parameter TCP */
#define SO_TRANSPORT_SCTP                 3  /* Transport Parameter SCTP */
#define SO_TRANSPORT_TLS                  4  /* Transport Parameter TLS */
#define SO_TRANSPORT_EXTN                 5  /* Transport Parameter:
                                                Other Transport */
#define SO_USERPARAM_PHONE                1  /* User Parameter Phone */
#define SO_USERPARAM_IP                   2  /* User Parameter IP */
#define SO_USERPARAM_OTHERUSER            3  /* User Parameter: Other User */
#define SO_USERTYPE_USER                  1  /* User Type: User */
#define SO_USERTYPE_TELEPHONESUBSCRIBER   2  /* User Type:
                                                Telephonesubscriber */

#define SO_URLPARAMETER_TRANSPORTPARAM    1  /* URL Parameter: Transport */
#define SO_URLPARAMETER_USERPARAM         2  /* URL Parameter: User */
#define SO_URLPARAMETER_METHOD            3  /* URL Parameter: Method */
#define SO_URLPARAMETER_TTLPARAM          4  /* URL Parameter: Ttl */
#define SO_URLPARAMETER_MADDRHOST         5  /* URL Parameter: Maddr */
#define SO_URLPARAMETER_LRPARAM           6  /* URL Parameter: lr */

#define SO_URLPARAMETER_TSPDOMAIN         7  /* URL Parameter: tsp; */
#define SO_URLPARAMETER_PHONECONTEXT      8  /* URL Parameter: Phone Context */
#define SO_URLPARAMETER_ISUB              9  /* URL Parameter:ISDN subaddress*/
#define SO_URLPARAMETER_POSTD            10  /* URL Parameter: Post dial */
#define SO_URLPARAMETER_COMP             11  /* URL Parameter: Compression */
#define SO_URLPARAMETER_OTHERPARAM       12  /* URL Parameter:Other Parameter*/


/* RFC 2806 : Tel Url */ 
#ifdef SO_ENUM

#define    SO_MAX_TELNUMPARS       0xFFFF

#define    SO_TEL_ISUB             1
#define    SO_TEL_POSTD            2
#define    SO_TEL_PHONE_CONTEXT    3
#define    SO_TEL_TSP              4
#define    SO_TEL_RN               5
#define    SO_TEL_NPDI             6
#define    SO_TEL_CIC              7
#define    SO_TEL_EXTN             8

#define    SO_TEL_GLOBAL           1
#define    SO_TEL_LOCAL            2

#endif /* SO_ENUM */

#define SO_VIAPARAM_VIATTL                1  /* Via Parameter: Ttl */
#define SO_VIAPARAM_MADDR                 2  /* Via Parameter: Maddr */
#define SO_VIAPARAM_RECEIVED              3  /* Via Parameter: Received */
#define SO_VIAPARAM_VIABRANCH             4  /* Via Parameter: Branch */
#define SO_VIAPARAM_VIARPORT              5  /* Via Parameter: Rport (NAT)*/
#define SO_VIAPARAM_VIACOMP               6  /* Via Parameter: Rport (NAT)*/
#define SO_VIAPARAM_GENERICPARAM          7  /* Via Parameters: Via Extension*/

#define SO_HOST_HOSTNAME                  1  /* Host: Host name */
#define SO_HOST_IPV4ADDRESS               2  /* Host: IP version 4 address */
#define SO_HOST_IPV6REFERENCE             3  /* Host: IP version 6 adrress */

#define SO_ACTION_PROXY                   1  /* Action: Proxy */
#define SO_ACTION_REDIRECT                2  /* Action: Redirect */

#define SO_PARAMVAL_TOKEN                 SO_VALUE_TOKEN  /* Generic Parameter: Token */        
#define SO_PARAMVAL_QUOTEDSTR             SO_VALUE_QUOTEDSTR  /* Generic Parameter: Quoted String */

#define SO_CONTACTPARAMSTD_Q              1  /* Standard Contact Parameter: Q */
#define SO_CONTACTPARAMSTD_ACTION         2  /* Standard Contact Parameter: Action */
#define SO_CONTACTPARAMSTD_EXPIRES        3  /* Standard Contact Parameter: Expires */

#define SO_RETRYPARAM_DURATION            1  /* Retry Parameter: Duration */
#define SO_RETRYPARAM_EXTN                2  /* Retry Parameter: Extn */

#define SO_CALLINFOPURPOSE_ICON           1  /* Call-Info Purpose: Icon */
#define SO_CALLINFOPURPOSE_INFO           2  /* Call-Info Purpose:
                                                Information */
#define SO_CALLINFOPURPOSE_CARD           3  /* Call-Info Purpose: Card */
#define SO_CALLINFOPURPOSE_EXTN           4

#define SO_INFOPARAM_PURPOSE              1  /* Information Parameter: Purpose */
#define SO_INFOPARAM_EXTN                 2  /* Information Parameter: Extn */


#define SO_CONTACTPARAM_STD               1  /* Generic contact parameters */
#define SO_CONTACTPARAM_FEAT              2  /* Generic contact parameters */
#define SO_CONTACTPARAM_EXTN              3  /* cp-params contact parameters */

#define    SO_FEAT_PAR_AUDIO           1
#define    SO_FEAT_PAR_AUTOMATA        2
#define    SO_FEAT_PAR_CLASS           3
#define    SO_FEAT_PAR_DUPLEX          4
#define    SO_FEAT_PAR_DATA            5
#define    SO_FEAT_PAR_CONTROL         6
#define    SO_FEAT_PAR_MOBILITY        7
#define    SO_FEAT_PAR_DESCRIPTION     8
#define    SO_FEAT_PAR_EVENTS          9
#define    SO_FEAT_PAR_PRIORITY        10
#define    SO_FEAT_PAR_METHODS         11
#define    SO_FEAT_PAR_SCHEMES         12
#define    SO_FEAT_PAR_APPLICATION     13
#define    SO_FEAT_PAR_VIDEO           14
#define    SO_FEAT_PAR_LANGUAGE        15
#define    SO_FEAT_PAR_TYPE            16
#define    SO_FEAT_PAR_ISFOCUS         17
#define    SO_FEAT_PAR_ACTOR           18
#define    SO_FEAT_PAR_TEXT            19
#define    SO_FEAT_PAR_EXTN            20

#ifdef SO_CALLERPREF

#define SO_REQUESTDISP_PROXY_FEATURE      1  /* proxy-feature */
#define SO_REQUESTDISP_CANCEL_FEATURE     2  /* cancel-feature */
#define SO_REQUESTDISP_FORK_FEATURE       3  /* fork-feature */
#define SO_REQUESTDISP_RECURSE_FEATURE    4  /* recurse-feature */
#define SO_REQUESTDISP_PARALLEL_FEATURE   5  /* parallel-feature */
#define SO_REQUESTDISP_QUEUE_FEATURE      6  /* queue-feature */

#define SO_REQUESTDISP_CANCEL_CANCEL      1  /* cancel-feature = cancel */
#define SO_REQUESTDISP_CANCEL_NOCANCEL    2  /* cancel-feature = no-cancel */

#define SO_REQUESTDISP_FORK_FORK          1  /* fork-feature = fork */
#define SO_REQUESTDISP_FORK_NOFORK        2  /* fork-feature = no-fork */

#define SO_REQUESTDISP_RECURSE_RECURSE    1  /* recurse-feature = recurse */
#define SO_REQUESTDISP_RECURSE_NORECURSE  2  /* recurse-feature = no-recurse */

#define SO_REQUESTDISP_PARALLEL_PARALLEL  1  /* parallel-feature = parallel */
#define SO_REQUESTDISP_PARALLEL_SEQUENTIAL 2 /* parallel-feature = sequential */

#define SO_REQUESTDISP_QUEUE_QUEUE        1  /* queue-feature = queue */
#define SO_REQUESTDISP_QUEUE_NOQUEUE      2  /* queue-feature = no-queue */

#define SO_MAX_NUM_REQUEST_DISPOSITION    6 /* Max request-disposition params */

#define SO_MAX_ACPARAM                   0xFFFF /* Max RC Params */

#define SO_ACCEPTCONTACT_PAR_FP           1  /* feature param */
#define SO_ACCEPTCONTACT_PAR_REQUIRE      2  /* require param */
#define SO_ACCEPTCONTACT_PAR_EXPLICIT     3  /* explicit */
#define SO_ACCEPTCONTACT_PAR_EXTN         4  /* extn */

#define SO_MAX_RCPARAM                   0xFFFF /* Max RC Params */

#define SO_REJECTCONTACT_PAR_FP          1  /* cp-params */
#define SO_REJECTCONTACT_PAR_EXTN        2  /* rc-extn */

#endif /* SO_CALLERPREF */

#ifdef SO_EVENT

#define SO_SUBS_EXP_REASON_MIGRATION      1  /* Subscription-Expires Reason: 
                                                migration */
#define SO_SUBS_EXP_REASON_MAINT          2  /* Subscription-Expires Reason: 
                                                maintenance */
#define SO_SUBS_EXP_REASON_REFUSED        3  /* Subscription-Expires Reason: 
                                                refused */
#define SO_SUBS_EXP_REASON_TIMEOUT        4  /* Subscription-Expires Reason: 
                                                timeout */
/* sot_h_001.main_3: add define */
#define SO_SUBS_EXP_REASON_EXTENSION      5  /* Subscription-Expires Reason: 
                                                Extension */
#define SO_SUBS_EXP_REASON                1  /* Subscription-Expires Parameter:
                                                Reason */
#define SO_SUBS_EXP_GENERIC_PARAM         2  /* Subscription-Expires Generic 
                                               Parameter */
#endif /* SO_EVENT */

#define SO_CONTACTDESC_METASTAR           1  /* Contact Descriptor: Meta star */
#define SO_CONTACTDESC_CONTACTITEMS       2  /* Contact-Descriptor:
                                                Contact Items */

#define SO_MEDIA_TYPE_TEXT                 1
#define SO_MEDIA_TYPE_IMAGE                2
#define SO_MEDIA_TYPE_AUDIO                3
#define SO_MEDIA_TYPE_VIDEO                4
#define SO_MEDIA_TYPE_APPLICATION          5
#define SO_MEDIA_TYPE_MESSAGE              6
#define SO_MEDIA_TYPE_MULTIPART            7
#define SO_MEDIA_TYPE_EXTN                 8

#define SO_MEDIA_SUBTYPE_MIXED            1
#define SO_MEDIA_SUBTYPE_SDP              2
#define SO_MEDIA_SUBTYPE_ISUP             3
#define SO_MEDIA_SUBTYPE_QSIG             4
#define SO_MEDIA_SUBTYPE_SIPFRAG          5
#define SO_MEDIA_SUBTYPE_SMS              6
#define SO_MEDIA_SUBTYPE_EXTN             7

/* The following #defines should reflect values from the database (values 
   returned by rx function). The values returned in the database depends on
   the combination of defines: SO_ENUM and SO_INSTMSG */

#define SO_ADDRSPEC_SIPURL                1  /* SIP URL */
#define SO_ADDRSPEC_SIPSURL               2  /* SIPS URL */
#define SO_ADDRSPEC_TELURL                3  /* TEL URL */
#define SO_ADDRSPEC_IMURL                 4  /* IM URL */
#define SO_ADDRSPEC_ABSOLUTEURI           5  /* Absolute URI */

#define SO_PROTOCOLNAME_SIP               1  /* Protocol Name: SIP */
#define SO_PROTOCOLNAME_PROTOCOLEXT       2  /* Protocol Name:
                                                Protocol Extension */

#define SO_MEDIARANGEVAL_ALLSTAR          1  /* Media Range Value: All Star */
#define SO_MEDIARANGEVAL_TYPESTAR         2  /* Media Range Value: Type Star */
#define SO_MEDIARANGEVAL_TYPESUB          3  /* Media Range Value: Type Sub */

#define SO_ADDRCH_NAMEADDR                1  /* Address Choice: Name Address */
#define SO_ADDRCH_ADDRSPEC                2  /* Address Choice: Address Specification */

#define SO_TRANSPORT_TRANSPORTSTD         SO_EXTVAL_STD    /* Transport: Standard Transport */
#define SO_TRANSPORT_TRANSPORTEXT         SO_EXTVAL_NONSTD /* Transport: Transport Extension */

#define SO_CODINGS_METASTAR               2  /* Codings: Meta star */
#define SO_CODINGS_CONTENTCODING          1  /* Codings: Content Coding */
#define SO_CONTENTCODINGCH_GZIP           1  /* Content Coding Choice: GZIP */
#define SO_CONTENTCODINGCH_COMPRESS       2  /* Content Coding Choice:
                                                Compress */
#define SO_CONTENTCODINGCH_DEFLATE        3  /* Content Coding Choice:
                                                Deflate */
#define SO_CONTENTCODINGCH_IDENTITY       4  /* Content Coding Choice:
                                                Identity */

#define SO_CONTENTCODING_CONTENTCODINGCH  SO_EXTVAL_STD
#define SO_CONTENTCODING_EXTENSION        SO_EXTVAL_NONSTD

#define SO_ADDRPARAM_TAGPARAM             1  /* Address Parameter: Tag */
#define SO_ADDRPARAM_GENERICPARAM         2

#define SO_HOSTPORTTYPE_HOSTPORT          1  /* Host and/or Port */ 
#define SO_HOSTPORTTYPE_HOST              2  /* Host */ 

#define SO_SENTBY_HOSTPORT                (SO_HOSTPORTTYPE_HOSTPORT)
#define SO_SENTBY_CONCEALEDHOST           (SO_HOSTPORTTYPE_HOST)

#define SO_DISP_PARAM_HANDLING            1  /* Handling */
#define SO_DISP_PARAM_EXTN                2  /* Extn Parameter */

#define SO_DISP_PARAM_HANDLING_STD        SO_EXTVAL_STD    /* Handling Std */
#define SO_DISP_PARAM_HANDLING_NONSTD     SO_EXTVAL_NONSTD /* Handling NonStd */


#define SO_PRODCOM_PRODUCT                1  /* Product Comment Choice:
                                                Product */
#define SO_PRODCOM_COMMENT                2  /* Product Comment Choice:
                                                Comment */

#define SO_PRIORITY_EMERGENCY             1  /* Priority: Emergency */
#define SO_PRIORITY_URGENT                2  /* Priority: Urgent */
#define SO_PRIORITY_NORMAL                3  /* Priority: Normal */
#define SO_PRIORITY_NONURGENT             4  /* Priority: Non-Urgent */
#define SO_PRIORITY_OTHERPRIORITY         5  /* Priority: Other Priority */

#define SO_DISP_TYPE_SESSION              1  /* Content Function: Session */
#define SO_DISP_TYPE_RENDER               2  /* Content Function: Render */
#define SO_DISP_TYPE_ICON                 3  /* Dispositiontype : Icon */
#define SO_DISP_TYPE_ALERT                4  /* Dispositiontype : Alert */
#define SO_DISP_TYPE_EXTN                 5  /* Dispositiontype : Alert */

#define SO_DISP_PARAM_HANDLING      1  /* Handling */
#define SO_DISP_PARAM_EXTN          2  /* Extn Parameter */

#define SO_DISP_PARAM_HANDLING_STD        SO_EXTVAL_STD    /* Handling Std */
#define SO_DISP_PARAM_HANDLING_NONSTD     SO_EXTVAL_NONSTD /* Handling NonStd */

#define SO_HANDLINGPARMVALSTD_OPTIONAL 1  /* Handling Optional */
#define SO_HANDLINGPARMVALSTD_REQUIRED 2  /* Handling Required */



/* Unitialized header */
/* Standard header fields according to RFC */
#define SO_HEADER_GEN_ACCEPT               1
#define SO_HEADER_GEN_ACCEPTENCODING       2
#define SO_HEADER_GEN_ACCEPTLANGUAGE       3
#define SO_HEADER_GEN_ALERTINFO            4
#define SO_HEADER_GEN_ALLOW                5
#define SO_HEADER_REQ_ALSO                 6
#define SO_HEADER_REQ_AUTHORIZATION        7
#define SO_HEADER_REQ_AUTHENTICATIONINFO   8
#define SO_HEADER_GEN_CALLID               9
#define SO_HEADER_GEN_CALLIDI             10
#define SO_HEADER_GEN_CALLINFO            11
#define SO_HEADER_GEN_CONTACT             12
#define SO_HEADER_GEN_CONTACTM            13
#define SO_HEADER_ENT_CONTENTDISPOSITION  14
#define SO_HEADER_ENT_CONTENTENCODING     15
#define SO_HEADER_ENT_CONTENTENCODINGE    16
#define SO_HEADER_ENT_CONTENTLANGUAGE     17
#define SO_HEADER_ENT_CONTENTLENGTH       18
#define SO_HEADER_ENT_CONTENTLENGTHL      19
#define SO_HEADER_ENT_CONTENTTYPE         20
#define SO_HEADER_ENT_CONTENTTYPEC        21
#define SO_HEADER_GEN_CSEQ                22
#define SO_HEADER_GEN_DATE                23
#define SO_HEADER_GEN_ENCRYPTION          24
#define SO_HEADER_RSP_ERRORINFO           25
#define SO_HEADER_GEN_EXPIRES             26
#define SO_HEADER_GEN_FROM                27
#define SO_HEADER_GEN_FROMF               28
#define SO_HEADER_REQ_INREPLYTO           29
#define SO_HEADER_REQ_MAXFORWARDS         30
#define SO_HEADER_ENT_MIMEVERSION         31
#define SO_HEADER_GEN_MINEXPIRES          32
#define SO_HEADER_GEN_ORGANIZATION        33
#define SO_HEADER_REQ_PRIORITY            34
#define SO_HEADER_RSP_PROXYAUTHENTICATE   35
#define SO_HEADER_REQ_PROXYAUTHORIZATION  36
#define SO_HEADER_GEN_PROXYREQUIRE        37
#define SO_HEADER_GEN_RECORDROUTE         38
#define SO_HEADER_GEN_REPLYTO             39
#define SO_HEADER_GEN_REQUIRE             40
#define SO_HEADER_REQ_RESPONSEKEY         41
#define SO_HEADER_RSP_RETRYAFTER          42
#define SO_HEADER_REQ_ROUTE               43
#define SO_HEADER_RSP_SERVER              44
#define SO_HEADER_GEN_SUBJECT             45
#define SO_HEADER_GEN_SUBJECTS            46
#define SO_HEADER_GEN_SUPPORTED           47
#define SO_HEADER_GEN_SUPPORTEDK          48
#define SO_HEADER_GEN_TIMESTAMP           49
#define SO_HEADER_GEN_TO                  50
#define SO_HEADER_GEN_TOT                 51
#define SO_HEADER_RSP_UNSUPPORTED         52
#define SO_HEADER_GEN_USERAGENT           53
#define SO_HEADER_GEN_VIA                 54
#define SO_HEADER_GEN_VIAV                55
/* Headers required for reliable provisional responses */
#define SO_HEADER_GEN_RACK                56
#define SO_HEADER_GEN_RSEQ                57
#define SO_HEADER_GEN_WARNING             58
#define SO_HEADER_GEN_WWWAUTHENTICATE     59
/* Headers required for events(Subscribe/Notify) */
#define SO_HEADER_REQ_EVENT               60
#define SO_HEADER_REQ_EVENTO              61
#define SO_HEADER_GEN_ALLOW_EVENTS        62
#define SO_HEADER_GEN_ALLOW_EVENTSU       63
#define SO_HEADER_REQ_REFERTO             64
#define SO_HEADER_REQ_REFERBY             65
#define SO_HEADER_REQ_REFERTOR            66
#define SO_HEADER_REQ_REFERBYB            67

#define SO_HEADER_REQ_REPLACES            68

#define SO_HEADER_GEN_SESSION_EXPIRES     69
#define SO_HEADER_GEN_SESSION_EXPIRESX    70
#define SO_HEADER_GEN_MINSE               71

#define SO_HEADER_REQ_REQUESTDISPOSITION  72
#define SO_HEADER_REQ_REQUESTDISPOSITIOND 73
#define SO_HEADER_REQ_ACCEPT_CONTACT      74
#define SO_HEADER_REQ_ACCEPT_CONTACTA     75
#define SO_HEADER_REQ_REJECT_CONTACT      76
#define SO_HEADER_REQ_REJECT_CONTACTJ     77

#define SO_HEADER_ANONMY                  78    
#define SO_HEADER_RPID_PRIV               79
#define SO_HEADER_REM_PARTY_ID            80 

#define SO_HEADER_SUBSC_STATE             81    

/* RFC 3329 : Security Mechanism */ 
#define SO_HEADER_SEC_CLIENT              82      
#define SO_HEADER_SEC_SERVER              83      
#define SO_HEADER_SEC_VERIFY              84      

/* RFC 3326 : Reason Header */ 
#define SO_HEADER_GEN_REASON              85      

/* RFC 3313 : P-Media Authorizaton */
#define SO_HEADER_GEN_PMEDIAAUTHORIZATION 86      

/* RFC 3323 : Privacy Header */
#define SO_HEADER_GEN_PRIVACY             87      

/* RFC 3325 : P-Asserted-Identity & P-Preferred-Identity Header */
#define SO_HEADER_GEN_PASSERTEDID         88      
#define SO_HEADER_GEN_PPREFERREDID        89      

/* RFC 3608 : Service-Route Header */
#define SO_HEADER_GEN_SERVICEROUTE        90      

/* RFC 3327 : Path Header */
#define SO_HEADER_GEN_PATH                91      

/* General-purpose extension header (unrecognized) */
#define SO_HEADER_GEN_EXTENSION           92
/* Used for range checking */
#define SO_HEADER_MAXIMUM                 93


/* used in rx exp for the generalized hdr compare func */
#define SO_MAX_KEYWORD_LEN                32

#define SO_SIPMESSAGE_REQUEST             1  /* SIP Message: Request */
#define SO_SIPMESSAGE_RESPONSE            2  /* SIP Message: Response */
#define SO_SIPMESSAGE_ERROR               3  /* SIP error message */
#define SO_SIPMESSAGE_AUDIT               4  /* SIP audit message */
#define SO_SIPMESSAGE_REFRESH             5  /* SIP refresh message */

#define SO_DATETIME_SIPDATE                     1
#define SO_DATETIME_DELTASECONDS                2
#define SOT_MAX_MIME_ELM                        6

#define SO_MAX_HEADEREXT                  0xFFFF
#define SO_MAX_URLPARAMETERS              0xFFFF
#define SO_MAX_SUBSC_EXP_PARAMETERS       0xFFFF
#define SO_MAX_DISPLAYNAMEREP             0xFFFF
#define SO_MAX_GENERICPARAMS              0xFFFF
#define SO_MAX_CONTACTPARAMS              0xFFFF
#define SO_MAX_PARAMETERS                 0xFFFF
#define SO_MAX_CALLINFOSEQ                0xFFFF
#define SO_MAX_VIAPARAMS                  0xFFFF
#define SO_MAX_CHALLENGEAUTHPARAMS        0xFFFF
#define SO_MAX_ACCEPTLIST                 0xFFFF
#define SO_MAX_CALLINFOLIST               0xFFFF
#define SO_MAX_ERRORINFOLIST              0xFFFF
#define SO_MAX_CONTACTITEMS               0xFFFF
#define SO_MAX_ACCEPTENCODINGREPLIST      0xFFFF
#define SO_MAX_ACCEPTLANGUAGE             0xFFFF
#define SO_MAX_ADDRPARAMS                 0xFFFF
#define SO_MAX_RECORDROUTELIST            0xFFFF
#define SO_MAX_OPTIONTAG                  0xFFFF
#define SO_MAX_VIA                        0xFFFF
#define SO_MAX_INREPLYTO                  0xFFFF
#define SO_MAX_ALLOW                      0xFFFF
#define SO_MAX_DISPOSITIONPARAMS          0xFFFF
#define SO_MAX_CONTENTENCODING            0xFFFF
#define SO_MAX_CONTENTLANGUAGE            0xFFFF
#define SO_MAX_PROXYAUTHENTICATE          0xFFFF
#define SO_MAX_RETRYPARAMS                0xFFFF
#define SO_MAX_SERVER                     0xFFFF
#define SO_MAX_WARNING                    0xFFFF
#define SO_MAX_HEADER                     0xFFFF
#define SO_MAX_ALSOADDR                   0xFFFF

#define RNOK -1

#define SO_QVALUE_TYPE                    1
#define SO_GENERIC_PARAM_TYPE             2
#define SO_MAX_ACCEPT_PARAMS              20

#define    SO_RPI_SCREEN_NO           1
#define    SO_RPI_SCREEN_YES          2

#define    SO_RPI_PTY_TYPE_CALLING    1
#define    SO_RPI_PTY_TYPE_CALLED     2
#define    SO_RPI_PTY_TYPE_TOKEN      3

#define    SO_RPI_ID_TYPE_SUBS        1
#define    SO_RPI_ID_TYPE_USER        2
#define    SO_RPI_ID_TYPE_TERM        3
#define    SO_RPI_ID_TYPE_TOKEN       4

#define    SO_RPI_PRV_ELM_TYP_FULL    1
#define    SO_RPI_PRV_ELM_TYP_NAME    2
#define    SO_RPI_PRV_ELM_TYP_URI     3
#define    SO_RPI_PRV_ELM_TYP_OFF     4
#define    SO_RPI_PRV_ELM_TYP_TOKEN   5

#define    SO_RPI_PRV_ELM_VAL_NW      1
#define    SO_RPI_PRV_ELM_VAL_TOKEN   2

#define    SO_OTHER_RPI_TOK_TYP_NP       1
#define    SO_OTHER_RPI_TOK_TYP_HYP_TOK  2
#define    SO_OTHER_RPI_TOK_TYP_TOKEN    3

#define    SO_OTHER_RPI_TOK_VAL_ORD                 3
#define    SO_OTHER_RPI_TOK_VAL_RES                 4
#define    SO_OTHER_RPI_TOK_VAL_BUS                 5
#define    SO_OTHER_RPI_TOK_VAL_PRI                 6
#define    SO_OTHER_RPI_TOK_VAL_HOT                 7
#define    SO_OTHER_RPI_TOK_VAL_FAIL                8
#define    SO_OTHER_RPI_TOK_VAL_HOSP                9
#define    SO_OTHER_RPI_TOK_VAL_PRISON              10
#define    SO_OTHER_RPI_TOK_VAL_POL                 11
#define    SO_OTHER_RPI_TOK_VAL_TST                 12
#define    SO_OTHER_RPI_TOK_VAL_PAY_PH              13
#define    SO_OTHER_RPI_TOK_VAL_COIN                14
#define    SO_OTHER_RPI_TOK_VAL_PUB_PAY_PH          15
#define    SO_OTHER_RPI_TOK_VAL_PRIV_PAY_PH         16
#define    SO_OTHER_RPI_TOK_VAL_COINLESS            17
#define    SO_OTHER_RPI_TOK_VAL_RESTRCT             18
#define    SO_OTHER_RPI_TOK_VAL_COIN_RESTRCT        19
#define    SO_OTHER_RPI_TOK_VAL_COINLESS_RESTRCT    20
#define    SO_OTHER_RPI_TOK_VAL_RESERVE             21
#define    SO_OTHER_RPI_TOK_VAL_OPR                 22
#define    SO_OTHER_RPI_TOK_VAL_FREE_PH             23
#define    SO_OTHER_RPI_TOK_VAL_ISDN_RES            24
#define    SO_OTHER_RPI_TOK_VAL_ISDN_BUS            25
#define    SO_OTHER_RPI_TOK_VAL_UNK                 26
#define    SO_OTHER_RPI_TOK_VAL_EMG                 27
#define    SO_OTHER_RPI_TOK_VAL_NON_APP             28
#define    SO_OTHER_RPI_TOK_VAL_CELL_ORD            29
#define    SO_OTHER_RPI_TOK_VAL_CELL_ROAM           30

#define    SO_RPI_SCREEN            1
#define    SO_RPI_PTY_TYPE          2
#define    SO_RPI_ID_TYPE           3
#define    SO_RPI_PRIVACY           4
#define    SO_RPI_OTHER_RPI_TOKEN   5

#define    SO_PRIVACY_TAG_IP_ADDR   1
#define    SO_PRIVACY_TAG_OFF       2
#define    SO_PRIVACY_TAG_TOKEN     3

#define SO_MAX_RPI_PRIV_LST         20
#define SO_MAX_RPI_LST              20
#define SO_MAX_RPID_LST             20
#define SO_MAX_RPID_PRIV_TOK        20
#define SO_MAX_RPID_PRIV_LST        20

#define SO_MAX_SUBEXP_PARAMS        20
#define SO_MAX_REFERD_BY_PARAMS     20

#define    SO_SUB_STATE_ACT       1
#define    SO_SUB_STATE_PEND      2
#define    SO_SUB_STATE_TERM      3
#define    SO_SUB_STATE_TOKEN     4

#define    SO_SB_EX_REAS_DEACT    1
#define    SO_SB_EX_REAS_PROBAT   2
#define    SO_SB_EX_REAS_REJCT    3
#define    SO_SB_EX_REAS_TMOUT    4
#define    SO_SB_EX_REAS_GIVEUP   5
#define    SO_SB_EX_REAS_NO_RES   6
#define    SO_SB_EX_REAS_TOKEN    7

#define    SO_SUB_EXP_PAR_REASON           1
#define    SO_SUB_EXP_PAR_EXPIRES          2
#define    SO_SUB_EXP_PAR_RETRY_AFT        3
#define    SO_SUB_EXP_PAR_GENERIC_PARAM    4


#define    SO_RF_BY_ID_PAR           1
#define    SO_RF_BY_GENERIC_PARAM    2

/* RFC 3329 : Security Mechanism */ 
#define    SO_MAX_SECMECH           0xFFFF
#define    SO_MAX_MECHPARS          0xFFFF

#define    SO_MECH_PAR_PREF         1
#define    SO_MECH_PAR_DG_ALG       2
#define    SO_MECH_PAR_DG_QOP       3
#define    SO_MECH_PAR_DG_VERIFY    4
#define    SO_MECH_PAR_EXTN         5

#define    SO_MECH_NAME_DIGEST      1
#define    SO_MECH_NAME_TLS         2
#define    SO_MECH_NAME_IPSEC_IKE   3
#define    SO_MECH_NAME_IPSEC_MAN   4
#define    SO_MECH_NAME_TOKEN       5

/* RFC 3326 : Reason Header */ 
#define    SO_MAX_REASONPARS        0xFFFF
#define    SO_MAX_REASONVAL         0xFFFF

#define    SO_REASON_CAUSE          1
#define    SO_REASON_TEXT           2
#define    SO_REASON_EXTN           3

/* RFC 3313 : P-Media Authorizaton */
#define    SO_MAX_PMEDIAAUTHVAL     0xFFFF

/* RFC 3323 : Privacy Header */ 
#define    SO_MAX_PRIVVAL           0xFFFF

#define    SO_PRIV_VAL_HEADER       1
#define    SO_PRIV_VAL_SESSON       2
#define    SO_PRIV_VAL_USER         3
#define    SO_PRIV_VAL_NONE         4
#define    SO_PRIV_VAL_CRITICAL     5
#define    SO_PRIV_VAL_ID           6
#define    SO_PRIV_VAL_TOKEN        7

/* RFC 3325 : P-Asserted-Identity & P-Preferred-Identity Header */
#define    SO_MAX_PASSERTEDIDVAL    0xFFFF
#define    SO_MAX_PPREFFEREDIDVAL   0xFFFF

#define    SO_MAX_AUTHINFOPARAMS    0xFFFF

#define SO_MAX_CLEGS   10
#define SO_MAX_CALLS   10

/* RFC 3486 : SIP Compression */
#define    SO_COMP_SIGCOMP          1
#define    SO_COMP_EXTN             2


#endif /* __SOTH__ */


/********************************************************************30**

         End of file:     sot.h@@/main/10 - Tue Apr 20 00:23:27 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---       ms  1. initial release.
/main/2      ---       ms  1. Changes for SIP Enhancements
/main/1+    so008.101  ak  1. Added a new error code for a case when Via 
                              does not match with correct tpt server.
/main/1+    so011.101  hd  1. Increase max MIME element
/main/1+    002.main_1 bdu 1. Add define for Quoted URL.
/main/1+    so021.101  pk  1. Added define SO_MAX_KEYWORD_LEN 
/main/1+    003.main_1 hd  1. Add a new error code for ModReq collision.
/main/1+    004.main_1 pk  1. Added 2 new defines 
                              SO_VIAPARAM_VIARPORT, SOT_ERR_REG_IN_PROGRESS
/main/3      ---       cvp 1. added session timer, refer and 
                              caller preferences header 
                       us  2. TEL URL handling related changes added.
                       cy  3. Changed copyright header.
/main/4      ---       bdu 1. Added new defines.
/main/5      ---       bdu 1. Change for lr parameter
/main/6      ---       bdu 1. Change the duplication define of err code.
/main/7      ---       hd  1. Add new defines.
/main/10     ---      wh   1. release 2.1
/main/10+  001.main_10 up  1. Added new define SO_REFRESHER_NONE
/main/10+  sot_h_002.main_10 ng  1. Added changes for lawful intercept(ps)
*********************************************************************91*/
