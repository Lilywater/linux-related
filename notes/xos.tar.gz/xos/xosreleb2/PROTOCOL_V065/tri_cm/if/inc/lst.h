/********************************************************************16**


        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     TCAP - layer management interface
  
     Type:     C include file
  
     Desc:     Defines required by the layer management service user.
  
     File:     lst.h
  
     Sid:      lst.h@@/main/10 - Fri Nov 17 10:33:53 2000
     
     Prg:      nj
  
*********************************************************************21*/

#ifndef __LSTH__
#define __LSTH__  


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000031     SS7 - TCAP
*
*/
 
/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000031     SS7 - TCAP
*
*/


/* defines */

 /* st005.301 - Added - Rolling Upgrade feature */
/* Interface version number  */
#ifdef LSTV1
#ifdef LSTIFVER
#undef LSTIFVER
#endif  /* LSTIFVER */
#define LSTIFVER 0x0100
#endif  /* LSTV1 */

/* lst_h_001.main_10-Added- New version for RUG feature */
/* Interface version number  */
#ifdef LSTV2
#ifdef LSTIFVER
#undef LSTIFVER
#endif  /* LSTIFVER */
#define LSTIFVER 0x0200
#endif  /* LSTV2 */

#ifndef LSTIFVER
#define LSTIFVER 0x0100
#endif
/* End of st013.301 */

/* number of Layer manager interfaces allowed */
#define MAXSTMI              2     /* layer manager interface */

/* Unsolicited status indication (alarm) Event codes */

 /* Message buffer allocation failure */
#define LST_EVENT_MSG_FAIL         (LCM_EVENT_LYR_SPECIFIC + 1)

 /* Static Memory allocation failed */
#define LST_EVENT_ALOC_FAIL        (LCM_EVENT_LYR_SPECIFIC + 2)

 /* Duplicate Invoke Id */
#define LST_EVENT_DUP_INVID        (LCM_EVENT_LYR_SPECIFIC + 3)

 /* Mandatory element missing */
#define LST_EVENT_MAND_MIS         (LCM_EVENT_LYR_SPECIFIC + 4)

 /* Unexpected message received */
#define LST_EVENT_UX_MSG           (LCM_EVENT_LYR_SPECIFIC + 5)

 /* Unrecognized message type received */
#define LST_EVENT_UNKN_MSG         (LCM_EVENT_LYR_SPECIFIC + 6)

 /* Invalid dialogue Id range */
#define LST_EVENT_INV_DLGID        (LCM_EVENT_LYR_SPECIFIC + 7)

 /* Unrecognized Invoke Id */
#define LST_EVENT_UR_INVID         (LCM_EVENT_LYR_SPECIFIC + 8)

 /* Dialogue id allocation failure */
#define LST_EVENT_ALOC_DLGID_FAIL  (LCM_EVENT_LYR_SPECIFIC + 9)

 /* Hashing failure */
#define LST_EVENT_HASH_FAIL        (LCM_EVENT_LYR_SPECIFIC + 10)

 /* Max configuration reached */
#define LST_EVENT_MAX_CFG          (LCM_EVENT_LYR_SPECIFIC + 11)

 /* Invalid component event structure values in CmpReq primitive */
#define LST_EVENT_INV_COMPEV       (LCM_EVENT_LYR_SPECIFIC + 12)

  /* General Unconfiguration OK */
#define LST_EVENT_GEN_UCFGOK       (LCM_EVENT_LYR_SPECIFIC + 13)

/* Event defines to support old STU, SPT and LM interfaces */

  /* Bind Ok */
#define LST_EVENT_BND_OK           (LCM_EVENT_LYR_SPECIFIC + 20)

  /* General configuration OK */
#define LST_EVENT_GENCFG_OK        (LCM_EVENT_LYR_SPECIFIC + 21)

  /* SAP configuration OK */
#define LST_EVENT_SAPCFG_OK        (LCM_EVENT_LYR_SPECIFIC + 22)

  /* General configuration Not OK */
#define LST_EVENT_GENCFG_NOK       (LCM_EVENT_LYR_SPECIFIC + 23)

  /* SAP configuration Not OK */
#define LST_EVENT_SAPCFG_NOK       (LCM_EVENT_LYR_SPECIFIC + 24)

/* Unsolicited status indication (alarm) Cause codes */

  /* Upper/lower SAP Unbounded */
#define LST_CAUSE_SAP_UBND         (LCM_CAUSE_LYR_SPECIFIC + 2)

  /* Dialogue alloc failure */
#define LST_CAUSE_DLG_ALOC         (LCM_CAUSE_LYR_SPECIFIC + 3)

  /* Invoke Alloc Failure */
#define LST_CAUSE_INV_ALOC         (LCM_CAUSE_LYR_SPECIFIC + 4)

  /* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
  /* Association from upper SAP to lower SAP failure */
#define LST_CAUSE_TUSAP_ASSOC_FAIL (LCM_CAUSE_LYR_SPECIFIC + 5)

  /* Association from lower SAP to upper SAP failure */
#define LST_CAUSE_SPSAP_ASSOC_FAIL (LCM_CAUSE_LYR_SPECIFIC + 6)
#endif /* ST_TC_USER_DIST */

/* LM Confirm Reason codes */

  /* Inavlid number of saps */
#define LST_REASON_INVALID_NMBSAPS  (LCM_REASON_LYR_SPECIFIC + 1)

  /* Inavlid Timer resolution */
#define LST_REASON_INVALID_TMRRES   (LCM_REASON_LYR_SPECIFIC + 2)

  /* Inavlid hiDlgId/loDlgId */
#define LST_REASON_INVALID_DLGRANGE (LCM_REASON_LYR_SPECIFIC + 3)

/* st007.301 - Added - TC-User Distribution Feature */
#ifdef ST_TC_USER_DIST
/* SSN Absent */
#define LST_REASON_SSN_ABSENT       (LCM_REASON_LYR_SPECIFIC + 4)

  /* Duplicate SSN in lower SAP */
#define LST_REASON_DUPLICATE_SSN    (LCM_REASON_LYR_SPECIFIC + 5)
#endif /* ST_TC_USER_DIST */

#define STGRSPSAP          100       /* Group of TCAP lower SAPs */
#define STGRTCUSAP         101       /* Group of TCAP upper SAPs */

/* number of hash list bins in a dialogue and invoke */
/* lst_h_002.main_10  - Increasing bins for Dialogue Hast List */
#define LST_NMB_BIN_DLG   8000    /* hash list bins in dialogue HL */
#define LST_NMB_BIN_INV   5       /* hash list bins in Invoke HL */

/* Trace Indication events */

#define LST_MAX_TRC_LEN   256        /* Maximum trace length */
#define LST_MSG_RECVD       1        /* Message received */
#define LST_MSG_TXED        2        /* Message transmitted */

/* Audit control block types */
#define LST_AUDIT_ALL_DLG   1        /* Delete all unused dialogues */
#define LST_AUDIT_ALL_INV   2        /* Delete all unused Invokes */
#define LST_AUDIT_PAR_DLG   3        /* Delete some of the unused Dialogues */
#define LST_AUDIT_PAR_INV   4        /* Delete some of the unused Invokes */
#define LST_AUDIT_PAR_CB    5        /* Delete some of the unused Dlgs/Invs */
#define LST_AUDIT_ALL_CB    6        /* Delete All unused Dlgs/Invs */

/* define for TCAP switches */
#define LST_SW_ITU88        1        /* ITU  88 */
#define LST_SW_ITU92        2        /* ITU  92 */
#define LST_SW_ANS88        3        /* ANSI 88 */
#define LST_SW_ANS92        4        /* ANSI 92 */
#define LST_SW_ANS96        5        /* ANSI 96 */
#define LST_SW_ETS96        6        /* ETSI 96 */
#define LST_SW_ITU96        7        /* ITU  96 */


/* Event codes */

#define EVTLSTCFGREQ     0x3C        /* Configuration request */
#define EVTLSTUCFGREQ    0x3D        /* Unconfiguration Request */
#define EVTLSTSTAREQ     0x40        /* Status request */
#define EVTLSTSTAIND     0x42        /* Status indication */
#define EVTLSTSTACFM     0x41        /* Status confirm */
#define EVTLSTSTSREQ     0x44        /* Statistics request */
#define EVTLSTSTSCFM     0x45        /* Statistics confirm */
#define EVTLSTTRCIND     0x48        /* Trace indication */
#define EVTLSTCNTRLREQ   0x4C        /* Control request */

#ifdef LST_LMINT3
#define EVTLSTCFGCFM     0x50        /* Configuration Conform */
#define EVTLSTCNTRLCFM   0x51        /* Control Conform */
#endif /* LST_LMINT3 */

#ifdef DEBUGP
/* Masks for TCAP Debug classes */
#define ST_DBGMASK_GEN		(DBGMASK_LYR << 0)   /* General */
#define ST_DBGMASK_ENCODE	(DBGMASK_LYR << 1)   /* Message encode */
#define ST_DBGMASK_DECODE	(DBGMASK_LYR << 2)   /* Message decode */
#define ST_DBGMASK_SM		(DBGMASK_LYR << 3)   /* Message to SM - add by xingzhou.xu */
#define ST_DBGMASK_NORMAL	(DBGMASK_LYR << 4)   /* Normal Tx/Rx */
#endif /* DEBUGP */

/* Macro for Error Logging */
#define LSTLOGERROR(errCls, errCode, errVal, errDesc)         \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,  \
                   __FILE__, __LINE__,                        \
                  (ErrCls)errCls, (ErrCode)errCode, (ErrVal)errVal, errDesc)

#define LST_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        LSTLOGERROR(ERRCLS_ADD_RES, e, (ErrVal)ret, "SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

#define   ELSTBASE      000
#define   ELSTXXX      (ELSTBASE)         /* reserved */

#define   ELST001      (ELSTBASE +    1)    /*        lst.c: 236 */
#define   ELST002      (ELSTBASE +    2)    /*        lst.c: 244 */
#define   ELST003      (ELSTBASE +    3)    /*        lst.c: 245 */
#define   ELST004      (ELSTBASE +    4)    /*        lst.c: 246 */
#define   ELST005      (ELSTBASE +    5)    /*        lst.c: 247 */
#define   ELST006      (ELSTBASE +    6)    /*        lst.c: 248 */
#define   ELST007      (ELSTBASE +    7)    /*        lst.c: 249 */
#define   ELST008      (ELSTBASE +    8)    /*        lst.c: 250 */
#define   ELST009      (ELSTBASE +    9)    /*        lst.c: 251 */
#define   ELST010      (ELSTBASE +   10)    /*        lst.c: 252 */
#define   ELST011      (ELSTBASE +   11)    /*        lst.c: 253 */
#define   ELST012      (ELSTBASE +   12)    /*        lst.c: 254 */
#define   ELST013      (ELSTBASE +   13)    /*        lst.c: 261 */
#define   ELST014      (ELSTBASE +   14)    /*        lst.c: 262 */
#define   ELST015      (ELSTBASE +   15)    /*        lst.c: 263 */
#define   ELST016      (ELSTBASE +   16)    /*        lst.c: 264 */
#define   ELST017      (ELSTBASE +   17)    /*        lst.c: 265 */
#define   ELST018      (ELSTBASE +   18)    /*        lst.c: 266 */
#define   ELST019      (ELSTBASE +   19)    /*        lst.c: 267 */
#define   ELST020      (ELSTBASE +   20)    /*        lst.c: 268 */
#define   ELST021      (ELSTBASE +   21)    /*        lst.c: 269 */
#define   ELST022      (ELSTBASE +   22)    /*        lst.c: 270 */
#define   ELST023      (ELSTBASE +   23)    /*        lst.c: 271 */
#define   ELST024      (ELSTBASE +   24)    /*        lst.c: 272 */
#define   ELST025      (ELSTBASE +   25)    /*        lst.c: 280 */
#define   ELST026      (ELSTBASE +   26)    /*        lst.c: 282 */
#define   ELST027      (ELSTBASE +   27)    /*        lst.c: 283 */
#define   ELST028      (ELSTBASE +   28)    /*        lst.c: 284 */
#define   ELST029      (ELSTBASE +   29)    /*        lst.c: 285 */
#define   ELST030      (ELSTBASE +   30)    /*        lst.c: 286 */
#define   ELST031      (ELSTBASE +   31)    /*        lst.c: 287 */
#define   ELST032      (ELSTBASE +   32)    /*        lst.c: 288 */
#define   ELST033      (ELSTBASE +   33)    /*        lst.c: 289 */
#define   ELST034      (ELSTBASE +   34)    /*        lst.c: 290 */
#define   ELST035      (ELSTBASE +   35)    /*        lst.c: 291 */
#define   ELST036      (ELSTBASE +   36)    /*        lst.c: 292 */
#define   ELST037      (ELSTBASE +   37)    /*        lst.c: 298 */
#define   ELST038      (ELSTBASE +   38)    /*        lst.c: 302 */
#define   ELST039      (ELSTBASE +   39)    /*        lst.c: 350 */
#define   ELST040      (ELSTBASE +   40)    /*        lst.c: 356 */
#define   ELST041      (ELSTBASE +   41)    /*        lst.c: 357 */
#define   ELST042      (ELSTBASE +   42)    /*        lst.c: 358 */
#define   ELST043      (ELSTBASE +   43)    /*        lst.c: 359 */
#define   ELST044      (ELSTBASE +   44)    /*        lst.c: 360 */
#define   ELST045      (ELSTBASE +   45)    /*        lst.c: 361 */
#define   ELST046      (ELSTBASE +   46)    /*        lst.c: 362 */
#define   ELST047      (ELSTBASE +   47)    /*        lst.c: 363 */
#define   ELST048      (ELSTBASE +   48)    /*        lst.c: 364 */
#define   ELST049      (ELSTBASE +   49)    /*        lst.c: 365 */
#define   ELST050      (ELSTBASE +   50)    /*        lst.c: 366 */
#define   ELST051      (ELSTBASE +   51)    /*        lst.c: 371 */
#define   ELST052      (ELSTBASE +   52)    /*        lst.c: 372 */
#define   ELST053      (ELSTBASE +   53)    /*        lst.c: 373 */
#define   ELST054      (ELSTBASE +   54)    /*        lst.c: 374 */
#define   ELST055      (ELSTBASE +   55)    /*        lst.c: 375 */
#define   ELST056      (ELSTBASE +   56)    /*        lst.c: 376 */
#define   ELST057      (ELSTBASE +   57)    /*        lst.c: 377 */
#define   ELST058      (ELSTBASE +   58)    /*        lst.c: 378 */
#define   ELST059      (ELSTBASE +   59)    /*        lst.c: 379 */
#define   ELST060      (ELSTBASE +   60)    /*        lst.c: 380 */
#define   ELST061      (ELSTBASE +   61)    /*        lst.c: 381 */
#define   ELST062      (ELSTBASE +   62)    /*        lst.c: 382 */
#define   ELST063      (ELSTBASE +   63)    /*        lst.c: 386 */
#define   ELST064      (ELSTBASE +   64)    /*        lst.c: 387 */
#define   ELST065      (ELSTBASE +   65)    /*        lst.c: 388 */
#define   ELST066      (ELSTBASE +   66)    /*        lst.c: 389 */
#define   ELST067      (ELSTBASE +   67)    /*        lst.c: 390 */
#define   ELST068      (ELSTBASE +   68)    /*        lst.c: 391 */
#define   ELST069      (ELSTBASE +   69)    /*        lst.c: 392 */
#define   ELST070      (ELSTBASE +   70)    /*        lst.c: 393 */
#define   ELST071      (ELSTBASE +   71)    /*        lst.c: 394 */
#define   ELST072      (ELSTBASE +   72)    /*        lst.c: 395 */
#define   ELST073      (ELSTBASE +   73)    /*        lst.c: 396 */
#define   ELST074      (ELSTBASE +   74)    /*        lst.c: 398 */
#define   ELST075      (ELSTBASE +   75)    /*        lst.c: 405 */
#define   ELST076      (ELSTBASE +   76)    /*        lst.c: 445 */
#define   ELST077      (ELSTBASE +   77)    /*        lst.c: 447 */
#define   ELST078      (ELSTBASE +   78)    /*        lst.c: 488 */
#define   ELST079      (ELSTBASE +   79)    /*        lst.c: 526 */
#define   ELST080      (ELSTBASE +   80)    /*        lst.c: 528 */
#define   ELST081      (ELSTBASE +   81)    /*        lst.c: 569 */
#define   ELST082      (ELSTBASE +   82)    /*        lst.c: 609 */
#define   ELST083      (ELSTBASE +   83)    /*        lst.c: 612 */
#define   ELST084      (ELSTBASE +   84)    /*        lst.c: 613 */
#define   ELST085      (ELSTBASE +   85)    /*        lst.c: 655 */
#define   ELST086      (ELSTBASE +   86)    /*        lst.c: 656 */
#define   ELST087      (ELSTBASE +   87)    /*        lst.c: 694 */
#define   ELST088      (ELSTBASE +   88)    /*        lst.c: 697 */
#define   ELST089      (ELSTBASE +   89)    /*        lst.c: 698 */
#define   ELST090      (ELSTBASE +   90)    /*        lst.c: 699 */
#define   ELST091      (ELSTBASE +   91)    /*        lst.c: 701 */
#define   ELST092      (ELSTBASE +   92)    /*        lst.c: 703 */
#define   ELST093      (ELSTBASE +   93)    /*        lst.c: 705 */
#define   ELST094      (ELSTBASE +   94)    /*        lst.c: 706 */
#define   ELST095      (ELSTBASE +   95)    /*        lst.c: 707 */
#define   ELST096      (ELSTBASE +   96)    /*        lst.c: 708 */
#define   ELST097      (ELSTBASE +   97)    /*        lst.c: 749 */
#define   ELST098      (ELSTBASE +   98)    /*        lst.c: 750 */
#define   ELST099      (ELSTBASE +   99)    /*        lst.c: 751 */
#define   ELST100      (ELSTBASE +  100)    /*        lst.c: 752 */
#define   ELST101      (ELSTBASE +  101)    /*        lst.c: 754 */
#define   ELST102      (ELSTBASE +  102)    /*        lst.c: 756 */
#define   ELST103      (ELSTBASE +  103)    /*        lst.c: 758 */
#define   ELST104      (ELSTBASE +  104)    /*        lst.c: 759 */
#define   ELST105      (ELSTBASE +  105)    /*        lst.c: 760 */
#define   ELST106      (ELSTBASE +  106)    /*        lst.c: 799 */
#define   ELST107      (ELSTBASE +  107)    /*        lst.c: 806 */
#define   ELST108      (ELSTBASE +  108)    /*        lst.c: 807 */
#define   ELST109      (ELSTBASE +  109)    /*        lst.c: 811 */
#define   ELST110      (ELSTBASE +  110)    /*        lst.c: 815 */
#define   ELST111      (ELSTBASE +  111)    /*        lst.c: 818 */
#define   ELST112      (ELSTBASE +  112)    /*        lst.c: 821 */
#define   ELST113      (ELSTBASE +  113)    /*        lst.c: 864 */
#define   ELST114      (ELSTBASE +  114)    /*        lst.c: 867 */
#define   ELST115      (ELSTBASE +  115)    /*        lst.c: 870 */
#define   ELST116      (ELSTBASE +  116)    /*        lst.c: 877 */
#define   ELST117      (ELSTBASE +  117)    /*        lst.c: 878 */
#define   ELST118      (ELSTBASE +  118)    /*        lst.c: 883 */
#define   ELST119      (ELSTBASE +  119)    /*        lst.c: 922 */
#define   ELST120      (ELSTBASE +  120)    /*        lst.c: 925 */
#define   ELST121      (ELSTBASE +  121)    /*        lst.c: 926 */
#define   ELST122      (ELSTBASE +  122)    /*        lst.c: 927 */
#define   ELST123      (ELSTBASE +  123)    /*        lst.c: 929 */
#define   ELST124      (ELSTBASE +  124)    /*        lst.c: 930 */
#define   ELST125      (ELSTBASE +  125)    /*        lst.c: 931 */
#define   ELST126      (ELSTBASE +  126)    /*        lst.c: 934 */
#define   ELST127      (ELSTBASE +  127)    /*        lst.c: 976 */
#define   ELST128      (ELSTBASE +  128)    /*        lst.c: 979 */
#define   ELST129      (ELSTBASE +  129)    /*        lst.c: 980 */
#define   ELST130      (ELSTBASE +  130)    /*        lst.c: 981 */
#define   ELST131      (ELSTBASE +  131)    /*        lst.c: 983 */
#define   ELST132      (ELSTBASE +  132)    /*        lst.c: 984 */
#define   ELST133      (ELSTBASE +  133)    /*        lst.c: 985 */
#define   ELST134      (ELSTBASE +  134)    /*        lst.c:1026 */
#define   ELST135      (ELSTBASE +  135)    /*        lst.c:1047 */
#define   ELST136      (ELSTBASE +  136)    /*        lst.c:1048 */
#define   ELST137      (ELSTBASE +  137)    /*        lst.c:1049 */
#define   ELST138      (ELSTBASE +  138)    /*        lst.c:1050 */
#define   ELST139      (ELSTBASE +  139)    /*        lst.c:1054 */
#define   ELST140      (ELSTBASE +  140)    /*        lst.c:1055 */
#define   ELST141      (ELSTBASE +  141)    /*        lst.c:1056 */
#define   ELST142      (ELSTBASE +  142)    /*        lst.c:1057 */
#define   ELST143      (ELSTBASE +  143)    /*        lst.c:1059 */
#define   ELST144      (ELSTBASE +  144)    /*        lst.c:1060 */
#define   ELST145      (ELSTBASE +  145)    /*        lst.c:1061 */
#define   ELST146      (ELSTBASE +  146)    /*        lst.c:1066 */
#define   ELST147      (ELSTBASE +  147)    /*        lst.c:1069 */
#define   ELST148      (ELSTBASE +  148)    /*        lst.c:1070 */
#define   ELST149      (ELSTBASE +  149)    /*        lst.c:1071 */
#define   ELST150      (ELSTBASE +  150)    /*        lst.c:1072 */
#define   ELST151      (ELSTBASE +  151)    /*        lst.c:1073 */
#define   ELST152      (ELSTBASE +  152)    /*        lst.c:1074 */
#define   ELST153      (ELSTBASE +  153)    /*        lst.c:1075 */
#define   ELST154      (ELSTBASE +  154)    /*        lst.c:1076 */
#define   ELST155      (ELSTBASE +  155)    /*        lst.c:1081 */
#define   ELST156      (ELSTBASE +  156)    /*        lst.c:1082 */
#define   ELST157      (ELSTBASE +  157)    /*        lst.c:1083 */
#define   ELST158      (ELSTBASE +  158)    /*        lst.c:1084 */
#define   ELST159      (ELSTBASE +  159)    /*        lst.c:1085 */
#define   ELST160      (ELSTBASE +  160)    /*        lst.c:1088 */
#define   ELST161      (ELSTBASE +  161)    /*        lst.c:1089 */
#define   ELST162      (ELSTBASE +  162)    /*        lst.c:1090 */
#define   ELST163      (ELSTBASE +  163)    /*        lst.c:1091 */
#define   ELST164      (ELSTBASE +  164)    /*        lst.c:1092 */
#define   ELST165      (ELSTBASE +  165)    /*        lst.c:1094 */
#define   ELST166      (ELSTBASE +  166)    /*        lst.c:1095 */
#define   ELST167      (ELSTBASE +  167)    /*        lst.c:1096 */
#define   ELST168      (ELSTBASE +  168)    /*        lst.c:1097 */
#define   ELST169      (ELSTBASE +  169)    /*        lst.c:1101 */
#define   ELST170      (ELSTBASE +  170)    /*        lst.c:1102 */
#define   ELST171      (ELSTBASE +  171)    /*        lst.c:1103 */
#define   ELST172      (ELSTBASE +  172)    /*        lst.c:1104 */
#define   ELST173      (ELSTBASE +  173)    /*        lst.c:1106 */
#define   ELST174      (ELSTBASE +  174)    /*        lst.c:1107 */
#define   ELST175      (ELSTBASE +  175)    /*        lst.c:1108 */
#define   ELST176      (ELSTBASE +  176)    /*        lst.c:1113 */
#define   ELST177      (ELSTBASE +  177)    /*        lst.c:1116 */
#define   ELST178      (ELSTBASE +  178)    /*        lst.c:1117 */
#define   ELST179      (ELSTBASE +  179)    /*        lst.c:1118 */
#define   ELST180      (ELSTBASE +  180)    /*        lst.c:1119 */
#define   ELST181      (ELSTBASE +  181)    /*        lst.c:1120 */
#define   ELST182      (ELSTBASE +  182)    /*        lst.c:1121 */
#define   ELST183      (ELSTBASE +  183)    /*        lst.c:1122 */
#define   ELST184      (ELSTBASE +  184)    /*        lst.c:1123 */
#define   ELST185      (ELSTBASE +  185)    /*        lst.c:1128 */
#define   ELST186      (ELSTBASE +  186)    /*        lst.c:1129 */
#define   ELST187      (ELSTBASE +  187)    /*        lst.c:1130 */
#define   ELST188      (ELSTBASE +  188)    /*        lst.c:1131 */
#define   ELST189      (ELSTBASE +  189)    /*        lst.c:1132 */
#define   ELST190      (ELSTBASE +  190)    /*        lst.c:1135 */
#define   ELST191      (ELSTBASE +  191)    /*        lst.c:1136 */
#define   ELST192      (ELSTBASE +  192)    /*        lst.c:1137 */
#define   ELST193      (ELSTBASE +  193)    /*        lst.c:1138 */
#define   ELST194      (ELSTBASE +  194)    /*        lst.c:1139 */
#define   ELST195      (ELSTBASE +  195)    /*        lst.c:1141 */
#define   ELST196      (ELSTBASE +  196)    /*        lst.c:1143 */
#define   ELST197      (ELSTBASE +  197)    /*        lst.c:1144 */
#define   ELST198      (ELSTBASE +  198)    /*        lst.c:1145 */
#define   ELST199      (ELSTBASE +  199)    /*        lst.c:1147 */
#define   ELST200      (ELSTBASE +  200)    /*        lst.c:1148 */
#define   ELST201      (ELSTBASE +  201)    /*        lst.c:1149 */
#define   ELST202      (ELSTBASE +  202)    /*        lst.c:1150 */
#define   ELST203      (ELSTBASE +  203)    /*        lst.c:1151 */
#define   ELST204      (ELSTBASE +  204)    /*        lst.c:1153 */
#define   ELST205      (ELSTBASE +  205)    /*        lst.c:1154 */
#define   ELST206      (ELSTBASE +  206)    /*        lst.c:1155 */
#define   ELST207      (ELSTBASE +  207)    /*        lst.c:1156 */
#define   ELST208      (ELSTBASE +  208)    /*        lst.c:1157 */
#define   ELST209      (ELSTBASE +  209)    /*        lst.c:1162 */
#define   ELST210      (ELSTBASE +  210)    /*        lst.c:1163 */
#define   ELST211      (ELSTBASE +  211)    /*        lst.c:1164 */
#define   ELST212      (ELSTBASE +  212)    /*        lst.c:1165 */
#define   ELST213      (ELSTBASE +  213)    /*        lst.c:1166 */
#define   ELST214      (ELSTBASE +  214)    /*        lst.c:1168 */
#define   ELST215      (ELSTBASE +  215)    /*        lst.c:1169 */
#define   ELST216      (ELSTBASE +  216)    /*        lst.c:1170 */
#define   ELST217      (ELSTBASE +  217)    /*        lst.c:1171 */
#define   ELST218      (ELSTBASE +  218)    /*        lst.c:1172 */
#define   ELST219      (ELSTBASE +  219)    /*        lst.c:1178 */
#define   ELST220      (ELSTBASE +  220)    /*        lst.c:1179 */
#define   ELST221      (ELSTBASE +  221)    /*        lst.c:1180 */
#define   ELST222      (ELSTBASE +  222)    /*        lst.c:1182 */
#define   ELST223      (ELSTBASE +  223)    /*        lst.c:1183 */
#define   ELST224      (ELSTBASE +  224)    /*        lst.c:1184 */
#define   ELST225      (ELSTBASE +  225)    /*        lst.c:1186 */
#define   ELST226      (ELSTBASE +  226)    /*        lst.c:1187 */
#define   ELST227      (ELSTBASE +  227)    /*        lst.c:1188 */
#define   ELST228      (ELSTBASE +  228)    /*        lst.c:1189 */
#define   ELST229      (ELSTBASE +  229)    /*        lst.c:1191 */
#define   ELST230      (ELSTBASE +  230)    /*        lst.c:1192 */
#define   ELST231      (ELSTBASE +  231)    /*        lst.c:1194 */
#define   ELST232      (ELSTBASE +  232)    /*        lst.c:1195 */
#define   ELST233      (ELSTBASE +  233)    /*        lst.c:1196 */
#define   ELST234      (ELSTBASE +  234)    /*        lst.c:1198 */
#define   ELST235      (ELSTBASE +  235)    /*        lst.c:1199 */
#define   ELST236      (ELSTBASE +  236)    /*        lst.c:1200 */
#define   ELST237      (ELSTBASE +  237)    /*        lst.c:1201 */
#define   ELST238      (ELSTBASE +  238)    /*        lst.c:1204 */
#define   ELST239      (ELSTBASE +  239)    /*        lst.c:1207 */
#define   ELST240      (ELSTBASE +  240)    /*        lst.c:1256 */
#define   ELST241      (ELSTBASE +  241)    /*        lst.c:1259 */
#define   ELST242      (ELSTBASE +  242)    /*        lst.c:1262 */
#define   ELST243      (ELSTBASE +  243)    /*        lst.c:1263 */
#define   ELST244      (ELSTBASE +  244)    /*        lst.c:1264 */
#define   ELST245      (ELSTBASE +  245)    /*        lst.c:1265 */
#define   ELST246      (ELSTBASE +  246)    /*        lst.c:1268 */
#define   ELST247      (ELSTBASE +  247)    /*        lst.c:1269 */
#define   ELST248      (ELSTBASE +  248)    /*        lst.c:1270 */
#define   ELST249      (ELSTBASE +  249)    /*        lst.c:1288 */
#define   ELST250      (ELSTBASE +  250)    /*        lst.c:1289 */
#define   ELST251      (ELSTBASE +  251)    /*        lst.c:1291 */
#define   ELST252      (ELSTBASE +  252)    /*        lst.c:1292 */
#define   ELST253      (ELSTBASE +  253)    /*        lst.c:1293 */
#define   ELST254      (ELSTBASE +  254)    /*        lst.c:1294 */
#define   ELST255      (ELSTBASE +  255)    /*        lst.c:1298 */
#define   ELST256      (ELSTBASE +  256)    /*        lst.c:1299 */
#define   ELST257      (ELSTBASE +  257)    /*        lst.c:1300 */
#define   ELST258      (ELSTBASE +  258)    /*        lst.c:1302 */
#define   ELST259      (ELSTBASE +  259)    /*        lst.c:1303 */
#define   ELST260      (ELSTBASE +  260)    /*        lst.c:1304 */
#define   ELST261      (ELSTBASE +  261)    /*        lst.c:1309 */
#define   ELST262      (ELSTBASE +  262)    /*        lst.c:1310 */
#define   ELST263      (ELSTBASE +  263)    /*        lst.c:1311 */
#define   ELST264      (ELSTBASE +  264)    /*        lst.c:1312 */
#define   ELST265      (ELSTBASE +  265)    /*        lst.c:1313 */
#define   ELST266      (ELSTBASE +  266)    /*        lst.c:1315 */
#define   ELST267      (ELSTBASE +  267)    /*        lst.c:1316 */
#define   ELST268      (ELSTBASE +  268)    /*        lst.c:1317 */
#define   ELST269      (ELSTBASE +  269)    /*        lst.c:1318 */
#define   ELST270      (ELSTBASE +  270)    /*        lst.c:1319 */
#define   ELST271      (ELSTBASE +  271)    /*        lst.c:1322 */
#define   ELST272      (ELSTBASE +  272)    /*        lst.c:1323 */
#define   ELST273      (ELSTBASE +  273)    /*        lst.c:1324 */
#define   ELST274      (ELSTBASE +  274)    /*        lst.c:1325 */
#define   ELST275      (ELSTBASE +  275)    /*        lst.c:1326 */
#define   ELST276      (ELSTBASE +  276)    /*        lst.c:1328 */
#define   ELST277      (ELSTBASE +  277)    /*        lst.c:1329 */
#define   ELST278      (ELSTBASE +  278)    /*        lst.c:1330 */
#define   ELST279      (ELSTBASE +  279)    /*        lst.c:1331 */
#define   ELST280      (ELSTBASE +  280)    /*        lst.c:1332 */
#define   ELST281      (ELSTBASE +  281)    /*        lst.c:1334 */
#define   ELST282      (ELSTBASE +  282)    /*        lst.c:1335 */
#define   ELST283      (ELSTBASE +  283)    /*        lst.c:1336 */
#define   ELST284      (ELSTBASE +  284)    /*        lst.c:1337 */
#define   ELST285      (ELSTBASE +  285)    /*        lst.c:1339 */
#define   ELST286      (ELSTBASE +  286)    /*        lst.c:1340 */
#define   ELST287      (ELSTBASE +  287)    /*        lst.c:1341 */
#define   ELST288      (ELSTBASE +  288)    /*        lst.c:1342 */
#define   ELST289      (ELSTBASE +  289)    /*        lst.c:1343 */
#define   ELST290      (ELSTBASE +  290)    /*        lst.c:1348 */
#define   ELST291      (ELSTBASE +  291)    /*        lst.c:1349 */
#define   ELST292      (ELSTBASE +  292)    /*        lst.c:1350 */
#define   ELST293      (ELSTBASE +  293)    /*        lst.c:1351 */
#define   ELST294      (ELSTBASE +  294)    /*        lst.c:1352 */
#define   ELST295      (ELSTBASE +  295)    /*        lst.c:1355 */
#define   ELST296      (ELSTBASE +  296)    /*        lst.c:1356 */
#define   ELST297      (ELSTBASE +  297)    /*        lst.c:1357 */
#define   ELST298      (ELSTBASE +  298)    /*        lst.c:1358 */
#define   ELST299      (ELSTBASE +  299)    /*        lst.c:1359 */
#define   ELST300      (ELSTBASE +  300)    /*        lst.c:1360 */
#define   ELST301      (ELSTBASE +  301)    /*        lst.c:1361 */
#define   ELST302      (ELSTBASE +  302)    /*        lst.c:1362 */
#define   ELST303      (ELSTBASE +  303)    /*        lst.c:1367 */
#define   ELST304      (ELSTBASE +  304)    /*        lst.c:1370 */
#define   ELST305      (ELSTBASE +  305)    /*        lst.c:1371 */
#define   ELST306      (ELSTBASE +  306)    /*        lst.c:1372 */
#define   ELST307      (ELSTBASE +  307)    /*        lst.c:1376 */
#define   ELST308      (ELSTBASE +  308)    /*        lst.c:1377 */
#define   ELST309      (ELSTBASE +  309)    /*        lst.c:1378 */
#define   ELST310      (ELSTBASE +  310)    /*        lst.c:1379 */
#define   ELST311      (ELSTBASE +  311)    /*        lst.c:1381 */
#define   ELST312      (ELSTBASE +  312)    /*        lst.c:1382 */
#define   ELST313      (ELSTBASE +  313)    /*        lst.c:1383 */
#define   ELST314      (ELSTBASE +  314)    /*        lst.c:1384 */
#define   ELST315      (ELSTBASE +  315)    /*        lst.c:1386 */
#define   ELST316      (ELSTBASE +  316)    /*        lst.c:1387 */
#define   ELST317      (ELSTBASE +  317)    /*        lst.c:1388 */
#define   ELST318      (ELSTBASE +  318)    /*        lst.c:1389 */
#define   ELST319      (ELSTBASE +  319)    /*        lst.c:1390 */
#define   ELST320      (ELSTBASE +  320)    /*        lst.c:1395 */
#define   ELST321      (ELSTBASE +  321)    /*        lst.c:1396 */
#define   ELST322      (ELSTBASE +  322)    /*        lst.c:1397 */
#define   ELST323      (ELSTBASE +  323)    /*        lst.c:1398 */
#define   ELST324      (ELSTBASE +  324)    /*        lst.c:1399 */
#define   ELST325      (ELSTBASE +  325)    /*        lst.c:1402 */
#define   ELST326      (ELSTBASE +  326)    /*        lst.c:1403 */
#define   ELST327      (ELSTBASE +  327)    /*        lst.c:1404 */
#define   ELST328      (ELSTBASE +  328)    /*        lst.c:1405 */
#define   ELST329      (ELSTBASE +  329)    /*        lst.c:1406 */
#define   ELST330      (ELSTBASE +  330)    /*        lst.c:1407 */
#define   ELST331      (ELSTBASE +  331)    /*        lst.c:1408 */
#define   ELST332      (ELSTBASE +  332)    /*        lst.c:1409 */
#define   ELST333      (ELSTBASE +  333)    /*        lst.c:1414 */
#define   ELST334      (ELSTBASE +  334)    /*        lst.c:1417 */
#define   ELST335      (ELSTBASE +  335)    /*        lst.c:1418 */
#define   ELST336      (ELSTBASE +  336)    /*        lst.c:1419 */
#define   ELST337      (ELSTBASE +  337)    /*        lst.c:1423 */
#define   ELST338      (ELSTBASE +  338)    /*        lst.c:1424 */
#define   ELST339      (ELSTBASE +  339)    /*        lst.c:1425 */
#define   ELST340      (ELSTBASE +  340)    /*        lst.c:1426 */
#define   ELST341      (ELSTBASE +  341)    /*        lst.c:1428 */
#define   ELST342      (ELSTBASE +  342)    /*        lst.c:1429 */
#define   ELST343      (ELSTBASE +  343)    /*        lst.c:1430 */
#define   ELST344      (ELSTBASE +  344)    /*        lst.c:1431 */
#define   ELST345      (ELSTBASE +  345)    /*        lst.c:1471 */
#define   ELST346      (ELSTBASE +  346)    /*        lst.c:1477 */
#define   ELST347      (ELSTBASE +  347)    /*        lst.c:1479 */
#define   ELST348      (ELSTBASE +  348)    /*        lst.c:1480 */
#define   ELST349      (ELSTBASE +  349)    /*        lst.c:1481 */
#define   ELST350      (ELSTBASE +  350)    /*        lst.c:1482 */
#define   ELST351      (ELSTBASE +  351)    /*        lst.c:1525 */
#define   ELST352      (ELSTBASE +  352)    /*        lst.c:1526 */
#define   ELST353      (ELSTBASE +  353)    /*        lst.c:1527 */
#define   ELST354      (ELSTBASE +  354)    /*        lst.c:1528 */
#define   ELST355      (ELSTBASE +  355)    /*        lst.c:1531 */
#define   ELST356      (ELSTBASE +  356)    /*        lst.c:1571 */
#define   ELST357      (ELSTBASE +  357)    /*        lst.c:1573 */
#define   ELST358      (ELSTBASE +  358)    /*        lst.c:1574 */
#define   ELST359      (ELSTBASE +  359)    /*        lst.c:1616 */
#define   ELST360      (ELSTBASE +  360)    /*        lst.c:1617 */
#define   ELST361      (ELSTBASE +  361)    /*        lst.c:1655 */
#define   ELST362      (ELSTBASE +  362)    /*        lst.c:1657 */
#define   ELST363      (ELSTBASE +  363)    /*        lst.c:1658 */
#define   ELST364      (ELSTBASE +  364)    /*        lst.c:1700 */
#define   ELST365      (ELSTBASE +  365)    /*        lst.c:1701 */

#endif /* __LSTH__ */


/********************************************************************30**
  
         End of file:     lst.h@@/main/10 - Fri Nov 17 10:33:53 2000
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  ak    1. initial release
 
1.2          ---  ak    1. added codes for unsolicited status indication.
 
1.3          ---  ak    1. add defines
 
1.4          ---  ak    1. add defines
 
1.5          ---  aa    1. Removed the hash defines not used by TCAP
             ---  aa    1. Moved MAXSTMI from st.h to lst.h
 
1.6          ---  aa    1. Changed the defines for Lxx_SW_ITU
 
1.7          ---  aa    1. Added new defines

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.8          ---      nj   1. Rewrote the file.
  
1.9          ---      nj   1. Added defines for LST_LMINT3

1.10         ---      nj   1. Added defines for group SAPs
/main/10     ---      nj   1. Changes related to DFTHA
3.1+      st005.301   zr   1. Rolling Upgrade Feature
                           - Interface version defines added
3.1+      st007.301   zr   1. Changes for  TC-User Distribution Feature
                           - Added new defines,
                             LST_CAUSE_SPSAP_ASSOC_FAIL
                             LST_CAUSE_TUSAP_ASSOC_FAIL
                             LST_REASON_SSN_ABSENT
                             LST_REASON_DUPLICATE_SSN
    lst_h_010.main_10 akp  1. Added new version LSTV2 to maintain 
                           increase in datatype storages of some
                           fields in genCfg & TUSapCfg structures. 
3.1+   002.main_10    mkm  1. Increase bins in Dialogue Hash List.
*********************************************************************91*/
