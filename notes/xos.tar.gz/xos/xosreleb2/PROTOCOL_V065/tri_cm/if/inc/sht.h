/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SHT Interface
  
     Type:     C include file
  
     Desc:     Constant Defines and Macros used on the SHT Interface.
               SHT Interface is defined between Distributed FTHA Core
               component system agent and other Trillium portable products.
   
     File:     sht.h
  
     Sid:      sht.h@@/main/6 - Fri Sep 16 02:51:07 2005
   
     Prg:      ash
  
*********************************************************************21*/

#ifndef __SHTH__
#define __SHTH__

/* SHT Primitive events         */
#define EVTSHTCNTRLREQ    0xE0    /* system agent control request */  
#define EVTSHTCNTRLCFM    0xE1    /* system agent control confirm */ 

/* control request type */
#define SHT_REQTYPE_BND_ENA      1    /*  bind enable */
#define SHT_REQTYPE_UBND_DIS     2    /*  unbind disble */
#define SHT_REQTYPE_GETVER       3    /*  Get i/f ver */
#define SHT_REQTYPE_SETVER       4    /*  Set i/f ver */

/* bind and unbind operation - grp types */
#define SHT_GRPTYPE_ALL  1      /* use all other fields for grouping *
                                 * protocol layer must use dstProcId,*
                                 * dstEnt and dstInst value to       *
                                 * identify the saps                 */  
  
#define SHT_GRPTYPE_ENT  2        /* use dstEnt + dstInst fields for *
                                   * grouping                        *
                                   * protocol layer must use         *
                                   * dstEnt and dstInst value to     *
                                   * identify the saps               */  

/* System error logging macro   */
#define SHTLOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,\
                  __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

/* SHT Error codes base value    */
#define ESHTXXX           0
#define ESHTBASE          0



#endif /* __SHTH__ */

/********************************************************************30**
  
         End of file:     sht.h@@/main/6 - Fri Sep 16 02:51:07 2005

*********************************************************************31*/
   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      ash  1. Initial release
               ---      ark  2. Added SH_MAX_SH_ENTS
               ---      ark  1. Removed SH_MAX_SH_ENTS
/main/4      ---     cvp   1. changed the copyright header.
/main/5      ---     ns    1. changes for rolling upgrade feature. New hash
                              defines added for get and set interface version
/main/6      ---      st   1. Update for MAP Release 2.3
*********************************************************************91*/
