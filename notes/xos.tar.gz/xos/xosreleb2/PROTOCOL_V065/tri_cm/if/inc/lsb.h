/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

     Name:     Signaling Control Transport Protocol (SCTP)

     Type:     C include file

     Desc:     Defines required by SCTP and Layer Manager

     File:     lsb.h

     Sid:      lsb.h@@/main/2 - Wed Jan 10 16:24:08 2001

     Prg:      wvdl

*********************************************************************21*/

#ifndef __LSBH__
#define __LSBH__


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000191     SIGTRAN - SCTP
*
*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000xxx     SIGTRAN - Adaptation Layers
*
*/


/* defines */

/* sb042.102, ADDED: introduce the interface version number */
#ifdef LSBV1
#ifdef LSBIFVER
#undef LSBIFVER
#endif
#define LSBIFVER 0x0100
#endif /* LSBV1 */

/* defines for element management */
#define STSBGEN               1     /* General */
#define STSBSCTSAP            2     /* Lower layer SAP */
#define STSBTSAP              3     /* Upper layer SAP */
#define STSBSID               4     /* System ID */
#define STSBASSOC             5     /* SCTP association */
#define STSBDTA               6     /* Destination Transport Address */
#define STSBTMR               7     /* Timer */

/* M3UA specific Mngmt.t.cntrl.action defines */
#define ASBBND                256   /* Bind and Enable */
#define ASBUBND               257   /* Unbind and Disable */
#define ASBINH                258   /* Inhibit */
#define ASBUNINH              259   /* Uninhibit */
#define ASBDEL                260   /* Delete */
#define ASBESTABLISH          261   /* establish */
#define ASBTERMINATE          262   /* terminate */
#define ASBENA                263   /* Enable */
#define ASBDISIMM             264   /* Disable */

/* protocol switch */
#define LSB_SW_RFC_REL0      1

/* number of Layer manager interfaces allowed */
#define MAXSBMI              2     /* layer manager interface */

/* Unsolicited status indication (alarm) Event codes */

 /* Message buffer allocation failure */
#define LSB_EVENT_MSG_FAIL         (LCM_EVENT_LYR_SPECIFIC + 1)

 /* Static Memory allocation failed */
#define LSB_EVENT_ALLOC_FAIL       (LCM_EVENT_LYR_SPECIFIC + 2)

 /* Hashing failure */
#define LSB_EVENT_HASH_FAIL        (LCM_EVENT_LYR_SPECIFIC + 10)

 /* Bind Request */
#define LSB_EVENT_BNDREQ           (LCM_EVENT_LYR_SPECIFIC + 11)

 /* Unbind Request */
#define LSB_EVENT_UBNDREQ          (LCM_EVENT_LYR_SPECIFIC + 12)

/* sb044.102: TUCL Connect Retries failed */
#define LSB_EVENT_TUCLCONNECT_FAIL (LCM_EVENT_LYR_SPECIFIC + 13)

/* lsb_h_001.main_2: Number of Address exceed SCT_MAX_NET_ADDR.
                     Discard the extra addresses
 */
#define LSB_EVENT_ADDR_DISCARD (LCM_EVENT_LYR_SPECIFIC + 14)

/* Unsolicited status indication (alarm) Cause codes */

  /* Configuration maximum reached */
#define LSB_CAUSE_EXCEED_CONF_VAL  (LCM_CAUSE_LYR_SPECIFIC + 1)

  /* Upper/lower SAP Unbounded */
#define LSB_CAUSE_SAP_UBND         (LCM_CAUSE_LYR_SPECIFIC + 2)

  /* Association identifier not present in the SCT SAP */
#define LSB_CAUSE_INV_ASSOCID      (LCM_CAUSE_LYR_SPECIFIC + 3)

  /* Primary address is not valid */
#define LSB_CAUSE_INV_PRIADDR      (LCM_CAUSE_LYR_SPECIFIC + 4)

  /* Destination address list is not valid */
#define LSB_CAUSE_INV_DSTADDR      (LCM_CAUSE_LYR_SPECIFIC + 5)

  /* Source address list is not valid */
#define LSB_CAUSE_INV_SRCADDR      (LCM_CAUSE_LYR_SPECIFIC + 6)

  /* Requested stream is not valid */
#define LSB_CAUSE_INV_STREAMS      (LCM_CAUSE_LYR_SPECIFIC + 7)

  /* Requested service provider endpoint ID is not valid */
#define LSB_CAUSE_INV_ENDPID       (LCM_CAUSE_LYR_SPECIFIC + 8)

  /* SB_VER13 If the system is not able to resolve hostname
   * from DNS Server */
#define LSB_CAUSE_UNRSLVD_ADDR     (LCM_CAUSE_LYR_SPECIFIC + 9)

/* lsb_h_001.main_2 : Number of Address exceed SCT_MAX_NET_ADDR.
                      Discard the extra addresses
 */
#define LSB_CAUSE_NUM_ADDR_EXCEED     (LCM_CAUSE_LYR_SPECIFIC + 10)

/* LM Confirm Reason codes */

  /* Invalid association identifier */
#define LSB_REASON_INV_ASSOC        (LCM_REASON_LYR_SPECIFIC + 1)

  /* Invalid DTA */
#define LSB_REASON_INV_DTA          (LCM_REASON_LYR_SPECIFIC + 2)

  /* Maximum bind retries reached */
#define LSB_REASON_MAX_BND_TRY      (LCM_REASON_LYR_SPECIFIC + 3)

  /* Layer Manager Request busy */
#define LSB_REASON_LMI_BUSY         (LCM_REASON_LYR_SPECIFIC + 4)

  /* Own hostname can not be resolved */
#define LSB_REASON_INVALID_HOSTNAME     (LCM_REASON_LYR_SPECIFIC + 5)


  /* Trace Indication events */
#define LSB_MAX_TRC_LEN   1500       /* Maximum trace length */
#define LSB_MSG_RECVD       1        /* Message received */
#define LSB_MSG_TXED        2        /* Message transmitted */

/* Event codes */

#define LSB_EVTCFGREQ     0x01        /* Configuration request */
#define LSB_EVTCFGCFM     0x02        /* Configuration Conform */
#define LSB_EVTCNTRLREQ   0x03        /* Control request */
#define LSB_EVTCNTRLCFM   0x04        /* Control Conform */
#define LSB_EVTSTAREQ     0x05        /* Status request */
#define LSB_EVTSTACFM     0x06        /* Status confirm */
#define LSB_EVTSTSREQ     0x07        /* Statistics request */
#define LSB_EVTSTSCFM     0x08        /* Statistics confirm */
#define LSB_EVTSTAIND     0x09        /* Status indication */
#define LSB_EVTTRCIND     0x0A        /* Trace indication */

/* Masks for SCTP Debug classes */

#ifdef DEBUGP
#define SB_DBGMASK_GEN      (DBGMASK_LYR << 0)   /* General */
#define SB_DBGMASK_SQ       (DBGMASK_LYR << 1)   /* Sequenced Deliviery */
#define SB_DBGMASK_SG       (DBGMASK_LYR << 2)   /* Segmentation */
#define SB_DBGMASK_DB       (DBGMASK_LYR << 3)   /* Database */
#define SB_DBGMASK_AC       (DBGMASK_LYR << 4)   /* Ackn. and Congestion */
#define SB_DBGMASK_AS       (DBGMASK_LYR << 5)   /* Association Control */
#define SB_DBGMASK_VA       (DBGMASK_LYR << 6)   /* Validation */
#define SB_DBGMASK_PM       (DBGMASK_LYR << 7)   /* Path Management */
#define SB_DBGMASK_CM       (DBGMASK_LYR << 8)   /* Chunk Multiplexing */
#define SB_DBGMASK_MTU      (DBGMASK_LYR << 9)   /* MTU Path Discovery */
#endif /* DEBUGP */

/* Macro for Error Logging */
#define LSBLOGERROR(errCls, errCode, errDesc)         \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,  \
                   __FILE__, __LINE__,                        \
                  (ErrCls)errCls, (ErrCode)errCode, (ErrVal)0, errDesc)

#define LSB_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        LSBLOGERROR(ERRCLS_ADD_RES, e, "SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

/* Error Codes for functions at LSB Interface */

#define   ELSBBASE      000
#define   ELSBXXX      (ELSBBASE)         /* reserved */

#define   ELSB001      (ELSBBASE +    1)    /*        lsb.c: 485 */
#define   ELSB002      (ELSBBASE +    2)    /*        lsb.c: 490 */
#define   ELSB003      (ELSBBASE +    3)    /*        lsb.c: 494 */
#define   ELSB004      (ELSBBASE +    4)    /*        lsb.c: 498 */
#define   ELSB005      (ELSBBASE +    5)    /*        lsb.c: 504 */
#define   ELSB006      (ELSBBASE +    6)    /*        lsb.c: 509 */
#define   ELSB007      (ELSBBASE +    7)    /*        lsb.c: 820 */
#define   ELSB008      (ELSBBASE +    8)    /*        lsb.c: 825 */
#define   ELSB009      (ELSBBASE +    9)    /*        lsb.c: 829 */
#define   ELSB010      (ELSBBASE +   10)    /*        lsb.c: 833 */
#define   ELSB011      (ELSBBASE +   11)    /*        lsb.c: 839 */
#define   ELSB012      (ELSBBASE +   12)    /*        lsb.c: 886 */
#define   ELSB013      (ELSBBASE +   13)    /*        lsb.c: 888 */
#define   ELSB014      (ELSBBASE +   14)    /*        lsb.c: 889 */
#define   ELSB015      (ELSBBASE +   15)    /*        lsb.c: 937 */
#define   ELSB016      (ELSBBASE +   16)    /*        lsb.c: 938 */
#define   ELSB017      (ELSBBASE +   17)    /*        lsb.c: 982 */
#define   ELSB018      (ELSBBASE +   18)    /*        lsb.c: 985 */
#define   ELSB019      (ELSBBASE +   19)    /*        lsb.c: 988 */
#define   ELSB020      (ELSBBASE +   20)    /*        lsb.c: 989 */
#define   ELSB021      (ELSBBASE +   21)    /*        lsb.c: 990 */
#define   ELSB022      (ELSBBASE +   22)    /*        lsb.c: 991 */
#define   ELSB023      (ELSBBASE +   23)    /*        lsb.c: 992 */
#define   ELSB024      (ELSBBASE +   24)    /*        lsb.c:1040 */
#define   ELSB025      (ELSBBASE +   25)    /*        lsb.c:1041 */
#define   ELSB026      (ELSBBASE +   26)    /*        lsb.c:1042 */
#define   ELSB027      (ELSBBASE +   27)    /*        lsb.c:1043 */
#define   ELSB028      (ELSBBASE +   28)    /*        lsb.c:1044 */
#define   ELSB029      (ELSBBASE +   29)    /*        lsb.c:1047 */
#define   ELSB030      (ELSBBASE +   30)    /*        lsb.c:1092 */
#define   ELSB031      (ELSBBASE +   31)    /*        lsb.c:1094 */
#define   ELSB032      (ELSBBASE +   32)    /*        lsb.c:1095 */
#define   ELSB033      (ELSBBASE +   33)    /*        lsb.c:1143 */
#define   ELSB034      (ELSBBASE +   34)    /*        lsb.c:1144 */
#define   ELSB035      (ELSBBASE +   35)    /*        lsb.c:1381 */
#define   ELSB036      (ELSBBASE +   36)    /*        lsb.c:1394 */
#define   ELSB037      (ELSBBASE +   37)    /*        lsb.c:1398 */
#define   ELSB038      (ELSBBASE +   38)    /*        lsb.c:1403 */
#define   ELSB039      (ELSBBASE +   39)    /*        lsb.c:1410 */
#define   ELSB040      (ELSBBASE +   40)    /*        lsb.c:1415 */
#define   ELSB041      (ELSBBASE +   41)    /*        lsb.c:1416 */
#define   ELSB042      (ELSBBASE +   42)    /*        lsb.c:1417 */
#define   ELSB043      (ELSBBASE +   43)    /*        lsb.c:1657 */
#define   ELSB044      (ELSBBASE +   44)    /*        lsb.c:1658 */
#define   ELSB045      (ELSBBASE +   45)    /*        lsb.c:1659 */
#define   ELSB046      (ELSBBASE +   46)    /*        lsb.c:1672 */
#define   ELSB047      (ELSBBASE +   47)    /*        lsb.c:1676 */
#define   ELSB048      (ELSBBASE +   48)    /*        lsb.c:1681 */
#define   ELSB049      (ELSBBASE +   49)    /*        lsb.c:1688 */
#define   ELSB050      (ELSBBASE +   50)    /*        lsb.c:1736 */
#define   ELSB051      (ELSBBASE +   51)    /*        lsb.c:1741 */
#define   ELSB052      (ELSBBASE +   52)    /*        lsb.c:1745 */
#define   ELSB053      (ELSBBASE +   53)    /*        lsb.c:1750 */
#define   ELSB054      (ELSBBASE +   54)    /*        lsb.c:1754 */
#define   ELSB055      (ELSBBASE +   55)    /*        lsb.c:1758 */
#define   ELSB056      (ELSBBASE +   56)    /*        lsb.c:1763 */
#define   ELSB057      (ELSBBASE +   57)    /*        lsb.c:1770 */
#define   ELSB058      (ELSBBASE +   58)    /*        lsb.c:1775 */
#define   ELSB059      (ELSBBASE +   59)    /*        lsb.c:1776 */
#define   ELSB060      (ELSBBASE +   60)    /*        lsb.c:1777 */
#define   ELSB061      (ELSBBASE +   61)    /*        lsb.c:1778 */
#define   ELSB062      (ELSBBASE +   62)    /*        lsb.c:1827 */
#define   ELSB063      (ELSBBASE +   63)    /*        lsb.c:1828 */
#define   ELSB064      (ELSBBASE +   64)    /*        lsb.c:1829 */
#define   ELSB065      (ELSBBASE +   65)    /*        lsb.c:1830 */
#define   ELSB066      (ELSBBASE +   66)    /*        lsb.c:1835 */
#define   ELSB067      (ELSBBASE +   67)    /*        lsb.c:1840 */
#define   ELSB068      (ELSBBASE +   68)    /*        lsb.c:1845 */
#define   ELSB069      (ELSBBASE +   69)    /*        lsb.c:1849 */
#define   ELSB070      (ELSBBASE +   70)    /*        lsb.c:1853 */
#define   ELSB071      (ELSBBASE +   71)    /*        lsb.c:1858 */
#define   ELSB072      (ELSBBASE +   72)    /*        lsb.c:1865 */
#define   ELSB073      (ELSBBASE +   73)    /*        lsb.c:2111 */
#define   ELSB074      (ELSBBASE +   74)    /*        lsb.c:2123 */
#define   ELSB075      (ELSBBASE +   75)    /*        lsb.c:2128 */
#define   ELSB076      (ELSBBASE +   76)    /*        lsb.c:2129 */
#define   ELSB077      (ELSBBASE +   77)    /*        lsb.c:2130 */
#define   ELSB078      (ELSBBASE +   78)    /*        lsb.c:2176 */
#define   ELSB079      (ELSBBASE +   79)    /*        lsb.c:2181 */
#define   ELSB080      (ELSBBASE +   80)    /*        lsb.c:2185 */
#define   ELSB081      (ELSBBASE +   81)    /*        lsb.c:2189 */
#define   ELSB082      (ELSBBASE +   82)    /*        lsb.c:2195 */
#define   ELSB083      (ELSBBASE +   83)    /*        lsb.c:2200 */
#define   ELSB084      (ELSBBASE +   84)    /*        lsb.c:2201 */
#define   ELSB085      (ELSBBASE +   85)    /*        lsb.c:2202 */
#define   ELSB086      (ELSBBASE +   86)    /*        lsb.c:2203 */
#define   ELSB087      (ELSBBASE +   87)    /*        lsb.c:2204 */
#define   ELSB088      (ELSBBASE +   88)    /*        lsb.c:2451 */
#define   ELSB089      (ELSBBASE +   89)    /*        lsb.c:2452 */
#define   ELSB090      (ELSBBASE +   90)    /*        lsb.c:2453 */
#define   ELSB091      (ELSBBASE +   91)    /*        lsb.c:2465 */
#define   ELSB092      (ELSBBASE +   92)    /*        lsb.c:2514 */
#define   ELSB093      (ELSBBASE +   93)    /*        lsb.c:2515 */
#define   ELSB094      (ELSBBASE +   94)    /*        lsb.c:2516 */
#define   ELSB095      (ELSBBASE +   95)    /*        lsb.c:2517 */
#define   ELSB096      (ELSBBASE +   96)    /*        lsb.c:2518 */
#define   ELSB097      (ELSBBASE +   97)    /*        lsb.c:2523 */
#define   ELSB098      (ELSBBASE +   98)    /*        lsb.c:2527 */
#define   ELSB099      (ELSBBASE +   99)    /*        lsb.c:2531 */
#define   ELSB100      (ELSBBASE +  100)    /*        lsb.c:2537 */
#define   ELSB101      (ELSBBASE +  101)    /*        lsb.c:2584 */
#define   ELSB102      (ELSBBASE +  102)    /*        lsb.c:2586 */
#define   ELSB103      (ELSBBASE +  103)    /*        lsb.c:2587 */
#define   ELSB104      (ELSBBASE +  104)    /*        lsb.c:2588 */
#define   ELSB105      (ELSBBASE +  105)    /*        lsb.c:2589 */
#define   ELSB106      (ELSBBASE +  106)    /*        lsb.c:2637 */
#define   ELSB107      (ELSBBASE +  107)    /*        lsb.c:2638 */
#define   ELSB108      (ELSBBASE +  108)    /*        lsb.c:2639 */
#define   ELSB109      (ELSBBASE +  109)    /*        lsb.c:2640 */
#define   ELSB110      (ELSBBASE +  110)    /*        lsb.c:2685 */
#define   ELSB111      (ELSBBASE +  111)    /*        lsb.c:2694 */
#define   ELSB112      (ELSBBASE +  112)    /*        lsb.c:2697 */
#define   ELSB113      (ELSBBASE +  113)    /*        lsb.c:2698 */
#define   ELSB114      (ELSBBASE +  114)    /*        lsb.c:2699 */
#define   ELSB115      (ELSBBASE +  115)    /*        lsb.c:2700 */
#define   ELSB116      (ELSBBASE +  116)    /*        lsb.c:2701 */
#define   ELSB117      (ELSBBASE +  117)    /*        lsb.c:2750 */
#define   ELSB118      (ELSBBASE +  118)    /*        lsb.c:2751 */
#define   ELSB119      (ELSBBASE +  119)    /*        lsb.c:2752 */
#define   ELSB120      (ELSBBASE +  120)    /*        lsb.c:2753 */
#define   ELSB121      (ELSBBASE +  121)    /*        lsb.c:2754 */
#define   ELSB122      (ELSBBASE +  122)    /*        lsb.c:2758 */



#endif /* __LSBH__ */


/********************************************************************30**

         End of file:     lsb.h@@/main/2 - Wed Jan 10 16:24:08 2001

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---      nj        1. initial release.
 /main/2     ---      sb        1. Modified for SCTP release based on 
                                   RFC-2960 'Oct 2000.
            sb042.102 hl        1. Added change for rolling upgrade change.
            sb044.102 rs        1. TUCL reconnect fail reasons.
     lsb_h_001.main_2 rk        1. If number of address received in 
                                   address list are more than 
                                   SCT_MAX_NET_ADDRS, discard the 
                                   additional addresses. New event 
                                   LSB_EVENT_ADDR_DISCARD and new 
                                   cause LSB_CAUSE_NUM_ADDR_EXCEED
                                   added.
*********************************************************************91*/
