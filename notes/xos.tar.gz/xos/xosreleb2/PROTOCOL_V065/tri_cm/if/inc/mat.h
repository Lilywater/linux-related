/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C include file
  
     Desc:     Defines rqeuired by MAP user.
  
     File:     mat.h
  
     Sid:      mat.h@@/main/13 - Fri Sep 16 02:50:13 2005
  
     Prg:      ssk
  
*********************************************************************21*/
  
#ifndef __MATH__
#define __MATH__

#ifdef __cplusplus
extern "C" {
#endif

   
/* defines for interface matrix */

/* Interface version number  */
#ifdef MATV1                       /* SPT interface version 1 */
#ifdef MATIFVER
#undef MATIFVER
#endif  /* MATIFVER */
#define MATIFVER        0x0100
#endif  /* MATV1 */


#ifdef MATV2                       /* SPT interface version 2 */
#ifdef MATIFVER
#undef MATIFVER
#endif  /* MATIFVER */
#define MATIFVER        0x0200
#endif  /* MATV2 */

#ifdef MATV3                       /* MAT interface version 3 */
#ifdef MATIFVER
#undef MATIFVER
#endif  /* MATIFVER */
#define MATIFVER        0x0300
#endif  /* MATV3 */

/* if none of MATV1 or MATV2 is enabled, define
 * MATIFVER as base version 0x0100
 */
#ifndef MATIFVER
#define MATIFVER 0x0100
#endif 

/* Change to 3 due to LLC */
#define MAXAULI         3               /* MAP user interface */
#define MAXMAUI         5               /* old is 3,change to 4 for AU, Upper interfaces */

/* upper interface selector */
#define MALCSEL         0               /* loosely coupled */
#define MALWLCSEL       2               /* light weight loosely coupled */

/* MAP own define extra large size token string */
#define MAT_SIZE_TKNSTRUL 2560 /* token string size - extra large */

/* TCAP Operation Class */
#define    MAT_OPRCLASS1   STU_OPRCLASS1   /* Operation Class */
#define    MAT_OPRCLASS2   STU_OPRCLASS2   /* Operation Class */
#define    MAT_OPRCLASS3   STU_OPRCLASS3   /* Operation Class */
#define    MAT_OPRCLASS4   STU_OPRCLASS4   /* Operation Class */

#define    MAT_SS_REQ           0        /* Service specific req/indication */
#define    MAT_SS_RSP           1        /* Service specific rsp/confirm */
#define    MAT_SS_RETERR        2        /* Service specific error rsp */

/* defines */
#define MAT_MAX_VBSSUBSDATA        5 /* 50 Maximum Vbs Subscription Data */
#define MAT_MAX_VGCSSUBSDATA       5 /* 50 Maximum Vgcs Subscription Data */
#define MAT_MAX_OBCSMCAMEL_TDPDATA 5 /* 10 Maximum o-bcsm camel TDP */
#define MAT_MAX_DESTNMB            10 /* Max. Destination Number list */
#define MAT_MAX_DESTNMB_LEN        3  /* Max. Destination Number length list */
#define MAT_MAX_BASIC_SER_CRIT     5  /* Max. Basic Service Criteria         */
#define MAT_MAX_SS_EVENT_LST       10 /* Max. SS. Evt. Lst */
#define MAT_MAX_AUTHSET            5  /* Maximum Authintication SET */ 
#define MAT_MAX_HLRID              50 /* Maximum HLR Id */ 
#define MAT_MAX_BASIC_SERV         13 /* Maximum Basic Service list */ 
#define MAT_MAX_EXT_BASIC_SERV     32 /* Maximum Ext. Basic Service list */ 
#define MAT_MAX_NMB_BASIC_SERV     32 /* Maximum Nmb. Basic Service list */ 
#define MAT_MAX_CUG                10 /* Maximum CUG Info */ 
#define MAT_MAX_BEARSERV           50 /* Maximum Bearer Service list */ 
#define MAT_MAX_TELESERV           20 /* Maximum Tele Service list */ 
#define MAT_MAX_SS                 25 /*old is 10, 30 Maximum SS list */ 
#define MAT_MAX_SS_LIST            30 /* Maximum SS list */ 
#define MAT_MAX_SS_CODE            30 /* Maximum SS Code list */ 
#define MAT_MAX_ZONES              10 /* Maximum Zone list */ 
#define MAT_MAX_SNDPARAM           1  /* 6 Maximum Send parameter */
#define MAT_MAX_REQPARAM           2  /* Maximum Requested param. */
#define MAT_MAX_SSEVTSPECS         2  /* Maximum Event Specs */
#define MAT_MAX_CCBSREQ            5  /* Maximum Requested param. */
#define MAT_MAX_ISDN_ADDR_LEN      9  /* Max Isdn Address Digits */
#define MAT_MAX_ISDN_ADDR_DIGITS   15 /* Max Isdn Address Digits */
#define MAT_MAX_CAMEL_DEST_NMB     10 /* max number of camel dest. nmb */
#define MAT_MAX_CAMEL_DEST_NMB_LEN 3  /* max number of camel dest. nmb length */
#define MAT_MAX_EVT_SPEC           2  /* max event specification       */
#define MAT_MAX_BASSERVGRPS        13 /* max no. of Bas Serv Grps */
#define MAT_MAXNUMOF_CAMTDPDATA    10 /* Maximum o-bcsm camel TDP */
#define MAT_MAXNUMOFPDP_CONTEXT    50 /* Max no of Pdp Contexts */

/* MAP_REL98 || MAP_REL99 */
#define MAT_MAX_NMB_LSA            20 /* Max no. of LSA's */
#define MAT_MAX_NMB_GMLC           5  /* Max no. of GMLC */
#define MAT_MAX_NMB_PRIVACYCLASS   4  /* Max no. of Privacy class */
#define MAT_MAX_NMB_EXT_CLIENT     5  /* Max no. of External clients */
#define MAT_MAX_NMB_PLMN_CLIENT    5  /* Max no. of PLMN clients */
#define MAT_MAX_NMB_MOLR_CLASS     3  /* Max no. of MOLR class */
#define MAT_MAX_NAME_STRING_LEN    63 /* Max name string length */
#define MAT_MAX_EXT_GEOG_INFO      20 /* Max ext geographical Information */   

/* MAP_REL99 */
#define MAT_MAXNMB_CAM_OCAUSEVALCRIT   5 /* Max no. of OCause Value Criteria */
#define MAT_MAXNMB_CAM_TCAUSEVALCRIT   5 /* Max no. of T Cause Value Criteria */
#define MAT_MAX_NMB_MOBILITY_TRIGGERS 10 /* Max no. of Mobility triggers */
#define MAT_MAX_FTN_ADDRESS_LEN       15 /* Max no. of FTN Address Length */
#define MAT_MAX_ISDN_ADDRESSDIGITS    15 /* Max no. of ISDN address digits */
#define MAT_MAX_NMB_DP_ANALYZEDINFO_CRIT 10 /* Max no. of PDP analyzed info criteria */ 
#define MAT_MAX_NMB_INTEGRITY_INFO    100 /* Max No of Integrity Info */
#define MAT_MAX_NMB_ENCRYPTION_INFO   100 /* Max No of Encryption Info */
#define MAT_MAX_NMB_RELOCATION_NMB    7   /* Max No of Relocation Nmb */

#define MAT_MAX_NMB_PRI_EXT           1 /*10, Max. no. of Private extensions */ 
#define MAT_MAX_NMB_RADIO_RES         7  /* Max No of radio resources */
#define MAT_MIN_NMB_RADIO_RES         1  /* Min No of radio resources */

#define MAT_MAX_NMB_BSSMAP_SERV_HO_INFO   7  /* Max No of radio resources */
#define MAT_MIN_NMB_BSSMAP_SERV_HO_INFO   1  /* Min No of radio resources */

/* Addition - upgrade for MAP release 4 */
/* MAP_REL4 */
#define MAT_MAX_NMB_EXT_EXT_CLIENT    35 /* Max no. of ext-External clients */

/* Addition - upgrade for MAP release 5 */
/* MAP_REL5 */
#define MAT_MAX_NMB_SERV_HO           7  /* Max No of service handovers */
#define MAT_MAX_NMB_TPDU_TYPE         5  /* Max No of TPDU types */
#define MAT_MAX_NMB
#define MAT_MAX_SERV_TYPE             32 /* MAX No of service type */
#define MAT_MAX_CODE_WORD_STRING_LEN  20 /* Max code word string length */
#define MAT_MAX_REQ_ID_STRING_LEN     63 /* Max requestor ID string length */
#define MAT_MAX_POSI_DATA_INFO        10 /* MAX positioning data info */
#define MAT_MAX_UTR_POSI_DATA_INFO    11 /* UTRAN MAX positioning data info */
/* mat_h_001.main_13 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
#define MAT_MAX_NLR_NMB_STR_LEN       15 /* MAX NLR Nmb String Length */
#define MA_MAX_NLR_NMB_STR_LEN        MAT_MAX_NLR_NMB_STR_LEN 
#endif

/* Addition -  upgrade for MAP release 6 */

#define MAT_MAX_NMB_AREAS             10 /* Max Number of Areas */
#define MAT_MIN_NMB_AREAS             1  /* Min Number of Areas */

/* MAP user events */

#define MAT_EVTBNDREQ            1          /* Bind request */
#define MAT_EVTBNDCFM            100        /* Bind confirm */
#define MAT_EVTUBNDREQ           2          /* Unbind request */

#define MAT_EVTOPENREQ           3          /* Open Request */
#define MAT_EVTOPENIND           4          /* Open Indication */
#define MAT_EVTOPENRSP           5          /* Open Response */
#define MAT_EVTOPENCFM           6          /* Open Confirm */

#define MAT_EVTCLOSEREQ          7          /* Close Request */
#define MAT_EVTCLOSEIND          8          /* Close Indication */

#define MAT_EVTDELIMREQ          9          /* Delimeter Indication */
#define MAT_EVTDELIMIND          10         /* Delimeter Indication */

#define MAT_EVTABRTREQ           11         /* Abort Request */
#define MAT_EVTABRTIND           12         /* Abort Indication */

#define MAT_EVTNOTICEIND         13         /* Notice Indication */
#define MAT_EVTSTATIND           14         /* Status Indication */

#define MAT_EVTDLGCFM            15         /* Dialogue Confirm */

#define MAT_EVTSTEREQ            16     /* State Request */
#define MAT_EVTSTEIND            17         /* State Indication */
#define MAT_EVTSTERSP            18         /* State Response */
#define MAT_EVTSTECFM            19         /* State Confirm */


#define MAT_EVTHOMGMTREQ         222        /* Handover Management Request */
#define MAT_EVTHOMGMTIND         23         /* Handover Management Indication */
#define MAT_EVTHOMGMTRSP         24         /* Handover Management Response */
#define MAT_EVTHOMGMTCFM         25         /* Handover Management Confirm */

#define MAT_EVTAUTHMGMTREQ       26         /* Auth. Management Request */
#define MAT_EVTAUTHMGMTIND       27         /* Auth. Management Indication */
#define MAT_EVTAUTHMGMTRSP       28         /* Auth. Management Response */
#define MAT_EVTAUTHMGMTCFM       29         /* Auth. Management Confirm */

#define MAT_EVTIMEIMGMTREQ       30         /* IMEI Management Request */
#define MAT_EVTIMEIMGMTIND       31         /* IMEI Management Indication */
#define MAT_EVTIMEIMGMTRSP       32         /* IMEI Management Request */
#define MAT_EVTIMEIMGMTCFM       33         /* IMEI Management Indication */

#define MAT_EVTSUBMGMTREQ        234        /* Subs. Management Request */
#define MAT_EVTSUBMGMTIND        35         /* Subs. Management Indication */
#define MAT_EVTSUBMGMTRSP        36         /* Subs. Management Response */
#define MAT_EVTSUBMGMTCFM        37         /* Subs. Management Confirm */

#define MAT_EVTFRMGMTREQ         38         /* Fault & Rec. Management Req. */
#define MAT_EVTFRMGMTIND         39         /* Fault & Rec. Management Ind. */
#define MAT_EVTFRMGMTRSP         40         /* Fault & Rec. Management Resp. */
#define MAT_EVTFRMGMTCFM         41         /* Fault & Rec. Management Conf. */

#define MAT_EVTOAMMGMTREQ        42         /* OAM Management Request */
#define MAT_EVTOAMMGMTIND        43         /* OAM Management Indication */
#define MAT_EVTOAMMGMTRSP        44         /* OAM Management Response */
#define MAT_EVTOAMMGMTCFM        45         /* OAM Management Confirm */

#define MAT_EVTCALLMGMTREQ       46         /* Call Management Request */
#define MAT_EVTCALLMGMTIND       47         /* Call Management Indication */
#define MAT_EVTCALLMGMTRSP       48         /* Call Management Response */
#define MAT_EVTCALLMGMTCFM       49         /* Call Management Confirm */

#define MAT_EVTSSMGMTREQ         50         /* SS Management Request */
#define MAT_EVTSSMGMTIND         51         /* SS Management Indication */
#define MAT_EVTSSMGMTRSP         52         /* SS Management Response */
#define MAT_EVTSSMGMTCFM         53         /* SS Management Confirm */

#define MAT_EVTSMMGMTREQ         54         /* SM Management Request */
#define MAT_EVTSMMGMTIND         55         /* SM Management Indication */
#define MAT_EVTSMMGMTRSP         56         /* SM Management Response */
#define MAT_EVTSMMGMTCFM         57         /* SM Management Confirm */

#define MAT_EVTPDPACTVREQ        58         /* PDP ACTV Management Request */
#define MAT_EVTPDPACTVIND        59         /* PDP ACTV Management Indication */
#define MAT_EVTPDPACTVRSP        200        /* PDP ACTV Management Response */
#define MAT_EVTPDPACTVCFM        61         /* PDP ACTV Management Confirm */

#define MAT_EVTLOCMGMTREQ        62         /* Location Management Request */
#define MAT_EVTLOCMGMTIND        63         /* Location Management Indication */
#define MAT_EVTLOCMGMTRSP        201        /* Location Management Response */
#define MAT_EVTLOCMGMTCFM        65         /* Location Management Confirm */

/* MAP_REL98 || MAP_REL99 */
#define MAT_EVTLOCSERVREQ      166    /* Loc. Services Management Request */
#define MAT_EVTLOCSERVIND      167    /* Loc. Services Management Indication */
#define MAT_EVTLOCSERVRSP      168    /* Loc. Services Management Response */
#define MAT_EVTLOCSERVCFM      169    /* Loc. Services Management Confirm */

/* MAP XINWEI Custom activity definition --xingzhou.xu 2006/10/16 */
#define MAT_EVTDETCTREQ       250    /* Paging detect Management Request */
#define MAT_EVTDETCTIND       251    /* Paging detect Management Indication */
#define MAT_EVTDETCTRSP       252    /* Paging detect Management Response */
#define MAT_EVTDETCTCFM       253    /* Paging detect Management Confirm */

/* define for closing a dialogue */
#define MAT_PREARRANGED_RELEASE  1
#define MAT_NORMAL_RELEASE       2

/* Defines for Dialogue refuse reason */

#define MAT_NO_REASON           0   /* No reason given */
#define MAT_INV_DEST_REF        1   /* Invalid destination reference */
#define MAT_INV_ORG_REF         2   /* Invalid orignating reference */

#if MAP_SEC
#define MAT_ENCACN_NOT_SUPPORTED 3    /* Encapsulated ACN not supported */
#define MAT_TRANS_PROTE_NOT_ADEQ 4    /* Transported protection not adequate */

#define MAT_ACN_NOT_SUPPORTED    0x83 /* ACN not supported */
#define MAT_POT_VER_INCOMP       0x84 /* Potential version compataibility */
#define MAT_BAD_OPENREQ          0x85 /* Bad Open Request */
#define MAT_NODE_NOT_REACHABLE   0x86 /* Dialogue refused */
#define MAT_SEC_TRANS_NOT_PBLE   0x87 /* secure transport not possible */

#else /* MAP_SEC */

#define MAT_ACN_NOT_SUPPORTED    3    /* ACN not supported */
#define MAT_POT_VER_INCOMP       4    /* Potential version compataibility */
#define MAT_BAD_OPENREQ          5    /* Bad Open Request */
#define MAT_NODE_NOT_REACHABLE   6    /* Dialogue refused */
#endif

/* defines for operation codes */

/********  Location Management *********************/
#define MAT_UPLOC                   2  /* (ALL),Update location      */
#define MAT_CANCELLOC           3  /* (ALL),Cancel Location      */
#define MAT_PURGE              67  /* (2)Purge MS             */
#define MAT_SNDID                  55  /* (2)Send Identification  */
#define MAT_GPRS_UPLOC         23  /* (NEW)GPRS Update Location */
/* Detach IMSI is a B interface operation, to be removed, */
/* 105 is a dummy value */
#define MAT_DET_IMSI                105  /* (1),Detach IMSI          */

/* MAP_REL99 */
#define MAT_NOTE_MMEVT         89  /* Note MM event */

/********  Handover Management *********************/
#define MAT_PRE_HO             68  /* (2)Prepare Handover */
#define MAT_PRE_SUBSHO         69  /* (2)prep. subs. handover */ 
#define MAT_PER_HO             28  /* (1),Perform handover */
#define MAT_PER_SUBSHO         30  /* (1),Perform subsequent handover */
#define MAT_SNDENDSIG          29  /* (ALL)Send End Signal  */
#define MAT_PROCACCSIG         33  /* (ALL),Process Access Signalling */
#define MAT_FWDACCSIG          34  /* (ALL),Forward Access Signalling */

/********  Authentication Management *********************/
#define MAT_AUTHINFO           56  /* (2)Authintication info */
/* MAP_REL99 */
#define MAT_AUTHFAILRPT        15  /* Authentication Failure Report */
#define MAT_PAGING_DETECT      99  /* detect if pirated or not */


/********  Identification management ***************/
#define MAT_CHKIMEI                43  /* (ALL),Check IMEI */

/********  Fault & recovery management**************/
#define MAT_RESET                  37  /* (ALL),Reset */
#define MAT_RESTOREDATA        57  /* (2)Restore Data */ 
#define MAT_FWDCHKSSIND        38  /* (ALL),Forward Check SS Indication */

/********  OAM Management **************************/

#define MAT_ACTVTRACE          50  /* (ALL),Activate trace */
#define MAT_DACTVTRACE         51  /* (ALL),Deactivate trace mode */
#define MAT_SNDIMSI            58  /* (2)Send IMSI */
#define MAT_TRACESUBSACTV      52  /* (1),Trace subscriber activity */
#define MAT_NOTEINTERHO        35  /* (1),Not Internal Handover */

/********  Call Management **************************/
#define MAT_ROUTINFO               22  /* (ALL)Send Routing Info */
#define MAT_PROVROAMNMB         4  /* (ALL), Provide Roaming Number */
#define MAT_PROV_SIWFS_NMB      31  /* (NEW)Provide SIWFS Number */
#define MAT_SIWFS_SIGMOD       32  /* (NEW)SIWFS Signalling modify */
#define MAT_RESCALLHANDL        6  /* (NEW)Resume call handling   */
#define MAT_SETRPTSTATE        73  /* (NEW)Set Reporting State    */
#define MAT_STARPT             74  /* (NEW)Status Report          */
#define MAT_RMTUSRFREE         75  /* (NEW)Remote user free       */
#define MAT_PREP_GRPCALL       39  /* (NEW)Prepare Group call             */
#define MAT_SND_GRPCALLENDSIG  40  /* (NEW)Send Group Call End Signalling */
#define MAT_PRO_GRPCALLSIG     41  /* (NEW)Process Group Call Signalling  */
#define MAT_FWD_GRPCALLSIG     42  /* (NEW)Forward Group Call Signalling  */
/* MAP_REL99 */
#define MAT_IST_ALERT          87  /* IST Alert */
#define MAT_IST_COMMAND        88  /* IST Command */
/* MAP_REL6 */
#define MAT_REL_RES            20  /* Release Resources */

/********  SS Management *********************/
#define MAT_REGSS                  10  /* (ALL),Register SS */
#define MAT_ERASESS            11  /* (ALL),Erase SS */
#define MAT_ACTVSS             12  /* (ALL),Activate SS */
#define MAT_DACTVSS            13  /* (ALL),Deactivate SS */
#define MAT_INTERSS                14  /* (ALL),Interogate SS */
#define MAT_PROCUSSREQ         59  /* (2),Process unstruc. SS Req */
#define MAT_USSREQ                 60  /* (2),Unstructured SS Request */
#define MAT_USSNOTIFY          61  /* (2),Unstructured SS Notify */
#define MAT_REGPASSWD          17  /* (ALL),Register password */
#define MAT_GETPASSWD          18  /* (ALL),Get password */
#define MAT_REGCCENT           76  /* (NEW)Register CC  Entry */
#define MAT_ERASECCENT         77  /* (NEW)ERASE CC Entry */
#define MAT_BEGIN_SUBS_ACTV    54  /* (1),begin subscriber activity */    
#define MAT_PROCUSSDATA        19  /* (1),Process unstructured SS Data */
#define MAT_SSINV_NOTIFY       72  /* SS Invocation Notify  */

/********  SMS  Management *********************/
#define MAT_MO_FWDSM           46  /* (ALL),Forward short message */
#define MAT_FWDSM              46
#define MAT_MT_FWDSM           44  /* (NEW)MT-Fwd SM */
#define MAT_ROUTINFOSM         45  /* (ALL),Routing Info for SM */
#define MAT_SMDEL              47  /* ( 2),Report SM Delivery Status */
#define MAT_INFSC              63  /* ( 2),Inform Service Center */
#define MAT_ALRTSC             64  /* (2),Alert Service center */
#define MAT_SMRDY              66  /* (2),SM Ready */
#define MAT_NOTSUBPRES         48  /* (1)Note Subscriber present */
#define MAT_ALRTSCWRSLT        49  /* (1)Alert SC Without Result */

/********  Subscriber  Management *********************/
#define MAT_INSSUBSDATA         7  /* (ALL),Insert Subscriber Data */
#define MAT_DELSUBSDATA         8  /* (ALL),Delete Subscriber Data */
#define MAT_PROVSUBSINFO       70  /* (NEW)Provide Subscriber Info */
#define MAT_ANY_INTER          71  /* (NEW)Any time interrogation  */
#define MAT_SNDPARAM                9  /* (1),Send Parameters */
/* MAP_REL99 */
#define MAT_ANY_SUBSDATA_INTER 62  /* Any time subscriber info interrogation */
#define MAT_ANY_MOD            65  /* Any time modification */
#define MAT_NOTE_SUBSDATA_MOD  5   /* Note subscriber data modified */

/********  Pdp Active Management ***************/

#define MAT_GPRS_ROUTINFO      24  /* (NEW)Rout Info  for GPRS   */
#define MAT_FAILRPT            25  /* (NEW)Failure Report */
#define MAT_GPRS_NOTEMSPRES    26  /* (NEW)GPRS NoteMs Present */

/* MAP_REL98 || MAP_REL99 */
/********  Location Service  ***************/

#define MAT_PROVSUBSLOC        83  /* Provide Subscriber Location */
#define MAT_SENDROUTINFOFORLCS 85  /* Send Routing Info For LCS */
#define MAT_SUBSLOCRPT         86  /* Subscriber Location Report */

/* MAP_SEC */
#define MAT_SEC_TRANS_CLASS1   78  /* Secure transport class 1 */
#define MAT_SEC_TRANS_CLASS2   79  /* Secure transport class 2 */
#define MAT_SEC_TRANS_CLASS3   80  /* Secure transport class 3 */
#define MAT_SEC_TRANS_CLASS4   81  /* Secure transport class 4 */

/* return code in status indication */

#define  MAT_BAD_SPDLGID         1
#define  MAT_BAD_INVKID          2
#define  MAT_BAD_DLG_STATE       3
#define  MAT_BAD_USRERR_PARAM    4
#define  MAT_BAD_RSP_PARAM       5
#define  MAT_BAD_USR_PARAM       6 
/* MAP_SEC */
#define  MAT_BAD_RSP_SEC_PARAM   7
#define  MAT_DST_PLMNID_MISSING  8
#define  MAT_BAD_DST_PLMNID      9
#define  MAT_SA_EXPIRED          10

/* mat_h_002.main_13: Addition. Adding the macro value */
/* MAP_SEG */
#define  MAT_BAD_RSP_SEG_PARAM   11
/* mat_h_003.main_13: MAT_LSAP_DEL is added */
#define  MAT_LSAP_DEL            12

/* defines for MAP dialogue response */
#define MAT_DLG_OK              0     /* Dialogue accepted */
#define MAT_DLG_REFUSED         1     /* Dialogue refused */

#define MAT_DLG_OVERLOADED  0x40     /* User Overload check failed*/

/* defines for user abort reasons */

#define MAT_ABRT_USR_SPECIFIC   0x80   /* user specific abort */
#define MAT_ABRT_RESLIMIT       0x81   /* resources limitation */
#define MAT_ABRT_RESUNAVAIL     0x82   /* resources unavailable */
#define MAT_ABRT_APC            0x83   /* Application procedure cancellation */

/* defines for provider abort reasons */

#define MAT_P_ABNORMAL_DLG        0     /* MA Abnormal dialogue */
#define MAT_P_INVALID_PDU         1     /* MA Invalid PDU */
#define MAT_P_VER_INCOMP          2     /* Version incompatibilty */

#define MAT_PROV_MALFUNC       0x81     /* Provider malfunction */
#define MAT_SUP_DLG_RLS        0x82     /* Supporting dialogue released */
#define MAT_RSRS_LIMIT         0x03     /* Resource limitation */
#define MAT_VER_INCOMP         0x04     /* Version incompatibility */
 
/* Defines for provider abort source */
#define MAT_PABRT_MAP             1     /* MAP Abort */
#define MAT_PABRT_TC              2     /* TC Abort */
#define MAT_PABRT_NET             3     /* Network Abort */

/* Abort source */

#define MAT_USR_ABRT            0    /* Abort by peer user */
#define MAT_PROV_ABRT           1    /* Provider abort */

/* MAP Diagnostics parameter */
#define    MAT_ABEVT_RCVD_PEER        0x00
#define    MAT_ABEVT_DET_PEER         0x01
#define    MAT_EVT_REJ_PEER           0x02
#define    MAT_INV_RSP_PEER           0x03
#define    MAT_MAX_INVOKE_RCHD        0x05 /* Max. Invoke Reached */

#define MAT_GAURD_TMR_EXPIRED         0x1f /* gaurd timer expiry */

#define    MAT_DLG_NOT_EXIST          0x04
#define    MAT_SPCAUSE_MASK          0x20

/* return causes */
#define   MAT_RTC_NTBADADDR   0x20  /* No translation, address of such nature */
#define   MAT_RTC_NTSPECADDR  0x21  /* No translation, specific address */
#define   MAT_RTC_SSCONG      0x22  /* subsystem congestion */
#define   MAT_RTC_SSFAIL      0x23  /* subsystem failure */
#define   MAT_RTC_UNEQUIP     0x24  /* Unequiped User */
#define   MAT_RTC_NETFAIL     0x25  /* Network Failure */
#define   MAT_RTC_NETCONG     0x26  /* Network Congestion */
#define   MAT_RTC_UNQUAL      0x27  /* Unqualified */
#define   MAT_RTC_HOPVIOLATE  0x28  /* Hop counter violation (ANS92) */
#define   MAT_RTC_ERRMSGTPRT  0x28  /* Error in message transport (CCITT92) */
#define   MAT_RTC_ERRLCLPROC  0x29  /* Error in local processing (CCITT92) */
#define   MAT_RTC_NOREASSEMB  0x2a  /* Dest. cannot perform reass.  (CCITT92) */
#define   MAT_RTC_SCCPFAIL    0x2b  /* SCCP failure (CCITT92) */
#define   MAT_RTC_HOPVIOLATE2 0x2c  /* Hop counter violation (ITU 96) */
#define   MAT_RTC_NOSEGSPRT   0x2d  /* Segmentation not supported */
#define   MAT_RTC_SEGFAILURE  0x2e  /* Segmentation failure */

/* MAP provider error source */
#define     MAT_REMOTE_PRV_ERR        0x01 /* provider error because of bad 
                                           * response/noresponse from peer
                                           */
      
#define     MAT_LOCAL_PRV_ERR         0x02 /* provider error because of error
                                           * in the local request primitive */ 
                                              

/* MAP Provider error for component probelms */
#define    MAT_PROV_ERR_NONE       0x00  /* No provider error */
#define    MAT_INVRSP_RCVD         0x01  /* Invalid reponse received */
#define    MAT_SERV_NOT_SUPP       0x02  /* Service not supported */
#define    MAT_MISTYPE_PARAM       0x03  /* Mistyped parameter */
#define    MAT_DUP_INVOKE_ID       0x04  /* Duplicate invoke Id */
#define    MAT_UNX_RSP_PEER        0x05  /* Unexpected response from peer */
#define    MAT_NO_RSP_PEER         0x06  /* No response from peer */
#define    MAT_SERV_COMP_FAILURE   0x07  /* Service completion failure */
#define    MAT_ABNORMAL_EVT_PEER   0x08  /* Unexpected response from peer */
#define    MAT_LINKED_RSP_UNX      0x09  /* Linked response unexpected */
#define    MAT_UNX_LINKED_OP       0x0A  /* unexpected linked operation */

/* MAP provider error for local reasons */

#define   MAT_INVALID_DLGID       0x01   /* Dialogue Id is bad */
#define   MAT_DUP_INVKID          0x02   /* Duplicate Invoke Id */
#define   MAT_OPR_NOT_SUPP        0x03   /* Operation code not supported */
#define   MAT_OUT_OF_RSRS         0x04   /* Out of resources */
#define   MAT_INCORRECT_PARAM     0x05   /* parameters of evnt structure in error */
#define   MAT_INVALID_LNKID       0x06   /* Invalid linked Id */
#define   MAT_INVALID_LNK_OPR     0x07   /* Invalid linked operation */
#define   MAT_INVOKE_LIMIT_RCHD   0x08   /* Max Invoke reached.      */
#if MAP_SEC
#define   MAT_MESS_PROT_FAILED    0x09   /* message protection failed */
#endif


/* Error codes */
/* defines for user Error codes */

/* General  error */
#define MAT_MISTYPED_PARAM       MAT_MISTYPE_PARAM  /* Mistyped param */
#define MAT_INV_USR_ERRVAL       255  /* Mistyped param */

/* User error */
#define MAT_USR_INIT_RLS          1      /* Initiating release */
#define MAT_USR_RSRS_LIMIT            2  /* Resource limitation */

/* Generic error codes */
#define MAT_SYS_FAILURE              34  /* System Failure */
#define MAT_DATA_MISSING             35  /* Data missing */
#define MAT_UNX_DATA_VALUE           36  /* Unexpected data value */
#define MAT_FACILITY_NOT_SUPP    21  /* Facility not supported */
#define MAT_INCMPTBL_TERM        28  /* incompatible terminal */
#define MAT_RSRC_LMT             51  /* Resource Limitation */

/* Identification and numbering code */
#define MAT_UNK_SUBS                  1  /* Unknown subscriber */
#define MAT_NMB_CHNGD            44      /* Number changed */
#define MAT_UNK_BASE_STAT         2      /* Unknown base station */
#define MAT_UNK_MSC               3      /* Unknown MSC */
#define MAT_UNID_SUBS             5      /* Unidentified subscriber */
#define MAT_UNK_EQP                   7  /* Unknwon equipment */

/* Handover error codes */
#define MAT_INV_TARG_BSTAT       23      /* Invalid target base station */
#define MAT_NO_RADIO_RSRS_AVAIL  24      /* No radio resource available */
#define MAT_NO_HONMB_AVAIL       25      /* No handover number available */
#define MAT_SUBS_HO_FAIL         26      /* Subsequent handover failure */
/* MAP_REL99 */
#define MAT_TARG_COUT_GCAREA     42      /* Target cell outside grp call area */

/* operation and maintenance */
#define MAT_TRC_BUFF_FULL        40      /* Tracing buffer full */

/* subscription error */
#define MAT_ROAM_NOTALLOWED      8       /* Roaming not allowed */
#define MAT_ILLEGAL_SUBS         9       /* Illegal Subscriber */
#define MAT_ILLEGAL_EQP          12      /* Illegal equipment */
#define MAT_BEAR_NOT_PROV        10      /* Bearer service not provisioned */
#define MAT_TELE_NOT_PROV        11      /* Tele service not provisioned */

/* call handling */
#define MAT_NO_ROAM_AVAIL        39      /* No roaming number available */  
#define MAT_ABSENT_SUBS          27      /* Absent Subscriber */
#define MAT_BUSY_SUBS            45      /* Busy Subscriber   */
#define MAT_NOSUBS_REPLY         46      /* No Subscriber Reply */
#define MAT_CALL_BARRED          13      /* call barred */
#define MAT_FWD_FAIL             47      /* Forwarding Failed */
#define MAT_OR_NOTALLOWED        48      /* Or Not Allowed    */
#define MAT_FWD_VIOL             14      /* call barred */
#define MAT_CUG_REJECT           15      /* CUG Reject */

/* supplementry services */
#define MAT_ILLEGAL_SS_OPR       16      /* Illegal SS operation */
#define MAT_SS_STATUS_ERR        17      /* SS Error status */
#define MAT_SS_NOT_AVAIL         18      /* SS Not available */
#define MAT_SS_SUBSVIOL_ERR      19      /* SS Subscription violation error */
#define MAT_SS_INCOMP_ERR        20      /* SS Incompability */
#define MAT_UNK_ALPHABET         71      /* Unknown alphabet */
#define MAT_USSD_BUSY            72      /* USSD Busy */
#define MAT_PASSWD_REG_ERR       37      /* PW registration failure */
#define MAT_NEG_PWCHK            38      /* Negative password check */
#define MAT_NMB_PW_VIOL          43      /* Number of password attempt violation */
#define MAT_SHRTTERM_DENIAL      29      /* Short Term Denial */
#define MAT_LONGTERM_DENIAL      30      /* Long Term Denial */

/* short message services */
#define MAT_MSG_WAIT_LISTFULL    33      /* Message waiting list full */
#define MAT_SM_DEL_FAIL          32      /* Message waiting list full */
#define MAT_SUBS_BUSY_MTMS       31      /* Subscriber Busy for MT-MS */
#define MAT_ABS_SUBS_SM           6      /* Absent Subscriber SM      */

/* Any Time Interrogation Error codes */
#define MAT_ATI_NOTALLOWED       49      /* ATI Not Allowed */

/* MAP_REL99 */
/* Any Time Informaiton Handling Error codes */
#define MAT_ATSI_NOTALLOWED      60      /* ATSI Not Allowed */
#define MAT_ATM_NOTALLOWED       61      /* ATM Not Allowed */
#define MAT_INFO_NOT_AVAIL       62      /* Information not available */

/* Mobility Management Error codes */
#define MAT_MMEVT_NOTSUPPORTED   59      /* MM event not supported */

/* Group Call Error Codes             */
#define MAT_NOGRPCALLNMB_AVAIL   50  /* No Group Call Number Avail*/

/* MAP_REL98 || MAP_REL99 */
/* Location service error codes */
#define MAT_UNAUTH_REQ_NET       52  /* Unauthorized requesting network */
#define MAT_UNAUTH_LCSCLIENT     53  /* Unauthorized LCS client */
#define MAT_POSITION_METH_FAIL   54  /* Position method failure */
#define MAT_UNKNOWN_OR_UNREACH   58  /* Unknown or unreachable LCS client */

/* MAP_SEC */
#define MAT_SEC_TRANS_ERROR      4   /* Secure transport error */

/* Defines for Enumerated values for error data types */

/* Roaming not allowed cause */
#define MAT_PLMN_ROAM_NOTALLOWED  0      /* PLMN Romaing not allowed */
#define MAT_OPR_DET_BARRING       3      /* Operator determined barring */

/* Call Barring cause */
#define MAT_BARRING_SERV_ACTV     0      /* Barring service Active */
#define MAT_OPR_BARRING           1      /* Operator barring */
#ifdef XWEXT /* xingzhou.xu: pirated reason 2006/10/13 */
#define MAT_PIRATED_BARRING       2      /* Pirated Barring */
#endif
/* CUG Reject cause */
#define MAT_INCALL_BARR_CUG       0      /* Incoming call Barred within CUG */
#define MAT_SUBS_NOT_MEM_CUG      1      /* Subscriber not member of CUG */
#define MAT_RBS_VIOL_CUG          5      /* Requested Basic service violates CUG
                                         * CUG Constraints */
#define MAT_CPTY_INTER_VIOL       7      /* Called party SS interaction viol */

/* Password Registration Failure cause */
#define MAT_UNDETERMINED          0      /* undetermined */
#define MAT_INV_FRMT              1      /* Invalid format */
#define MAT_NEW_PASSWD_MISMATCH   2      /* New register password mismatch */

/* SM Delivery cause failure */

#define MAT_MEM_EXCEEDED          0      /* Memory capacity exceeded */
#define MAT_EQP_PROT_ERR          1      /* Equipment protocol error */
#define MAT_EQP_NOTSM_EQUIPPED    2      /* Equipment not SM equipped */
#define MAT_UNK_SC                3      /* Unknown SC */
#define MAT_SC_CONGESTION         4      /* SC congestion */
#define MAT_INV_SME_ADDR          5      /* Invalid SME Address */
#define MAT_SUBS_NOT_SC_SUBS      6      /* Subscriber not SC subscriber */

/* Unknown Subscriber Diagnostic */
#define  MAT_IMSI_UNKNOWN             0  /* IMSI Unknown */
#define  MAT_GPRS_SUBSCRIPTION_OPTION 1  /* Gprs Subscription Option */
/* MAP_REL99 */
#define  MAT_NPDB_MISMATCH            2  /* NPDB mismatch */
#ifdef XWEXT /* xingzhou.xu: pirated reason 2006/10/13 */
#define  MAT_DIA_PIRATED_REASON       3  /* pirated reason */
#endif

/* Absent Subscriber Reason */
#define  MAT_IMSI_DETACH          0 /* IMSI Detach      */
#define  MAT_ASR_RESTRICTED_AREA  1 /* Restricted Area  */
#define  MAT_NO_PAGE_RESPONSE     2 /* No Page Response */
/* MAP_REL99 */
#define  MAT_PURGED_MS            3 /* Purged MS */


/* Defines for Enumerated values */

/* Network Access Modes */

#define MAT_BOTH_MSC_SGSN       0
#define MAT_ONLY_MSC            1
#define MAT_ONLY_SGSN           2

/* Network Resources */

#define MAT_NETRSRS_PLMN        0
#define MAT_NETRSRS_HLR         1
#define MAT_NETRSRS_VLR         2
#define MAT_NETRSRS_PVLR        3
#define MAT_NETRSRS_CONTR_MSC   4 
#define MAT_NETRSRS_VMSC        5 
#define MAT_NETRSRS_EIR         6 
#define MAT_NETRSRS_RSS         7 

/* Protocol Id */

#define MAT_GSM_0408            1
#define MAT_GSM_0806            2 
#define MAT_GSM_BSSMAP          3  
#define MAT_ETS300102_1         4

/* Equipment Status */

#define MAT_WHITE_LISTED        0
#define MAT_BLACK_LISTED        1
#define MAT_GREY_LISTED         2

/* Handover Type */
#define MAT_INTERBSS            0 
#define MAT_INTRABSS            1

/* Intra Cug Options */
#define MAT_NOCUG_RESTRICTIONS  0
#define MAT_CUGIC_CALLBARRED    1
#define MAT_CUGOG_CALLBARRED    2

/* Client Restriction Options */

#define MAT_PERMANENT_REST         0
#define MAT_TEMP_DEFAULT_REST     1
#define MAT_TEMP_DEFAULT_ALLOWED  2

/* Override Category */
#define MAT_OVRRIDE_ENABLED       0
#define MAT_OVRRIDE_DISABLED      1 

/* Hunt Group Access Selection Order*/
#define MAT_RANDOM               0
#define MAT_SEQUENTIAL           1

/* Regiter Subscriber Response */
#define MAT_MSC_AREA_REST           0
#define MAT_TOOMANY_ZONE_CODES      1
#define MAT_ZONE_CODE_CONFLICT      2
#define MAT_REG_SUBS_NOTSUPPORTED   3 

/* Delivery SM Outcome */ 
#define MAT_MEM_EXCEEDED            0
#define MAT_ABS_SUBS                1
#define MAT_SUCCESSFUL_TRANSFER     2

/* Alert Reason */
#define MAT_MS_PRESENT              0
#define MAT_MEM_AVAIL               1

/* Subscriber Status */
#define MAT_SERV_GRANTED            0
#define MAT_OPR_DETERMINED_BARRING  1

/* Guidance Info */
#define MAT_ENTER_PW                0
#define MAT_ENTER_NEW_PW            1
#define MAT_ENTER_NEW_PW_AGAIN      2
#define MAT_BAD_PW_TRY_AGAIN        3
#define MAT_BAD_PWFORMAT_TRY_AGAIN  4

/* Requested parameters */

#define MAT_REQ_IMSI             0
#define MAT_REQ_AUTHSET          1
#define MAT_REQ_SUBSDATA         2
#define MAT_REQ_KI               4


/* SS Info Type */
#define MAT_SSINFO_NONE             0
#define MAT_FWD_INFO                1
#define MAT_CBARR_INFO              2
#define MAT_CUG_INFO                3
#define MAT_SSDATA                  4

/* Send Parameter Type */
#define MAT_SNDPARAM_NONE                   0
#define MAT_SNDPARAM_IMSI                   1
#define MAT_SNDPARAM_AUTHSET                2
#define MAT_SNDPARAM_SUBDATA                3
#define MAT_SNDPARAM_KI                     4

/* OBCSM Trigger Detection Point enumerations */
#define MAT_COLLECTED_INFO 2
/* MAP_REL99 */
#define MAT_ROUTE_SELECT_FAILURE  4

/* TBCSM Trigger Detection Point enumerations */
#define MAT_TERM_ATTEMPT_AUTH       12
/* MAP_REL99 */
#define MAT_T_BUSY                  13
#define MAT_T_NO_ANSWER             14

/* Match Type */
#define MAT_INHIBITING 0
#define MAT_ENABLING   1

/* Call Type Criteria */
#define MAT_FORWARDED 0
#define MAT_NOT_FORWARDED 1

/* Cell Id or LAI Choice flag */
#define MAT_CELLID_FIX_LEN 0
#define MAT_LAI_FIX_LEN    1

/* Subscriber State Choice Flag */
#define MAT_ASSUMED_IDLE 0
#define MAT_CAMEL_BUSY   1
#define MAT_NETDET_NOT_REACHABLE 2
#define MAT_NOT_PROV_FROM_VLR 3

/* Enumerations For Not Reachable Reasons */
#define MAT_MS_PURGED       0
#define MAT_IMSI_DETACHED   1
#define MAT_RESTRICTED_AREA 2
#define MAT_NOT_REGISTERED  3

/* Enumerations for Additional SM Delivery Outcome */
#define MAT_MEMORY_CAP_EXCEEDED 0
#define MAT_ABSENT_SUBSCRIBER   1
#define MAT_SUCCESSFUL_TRANSFER    2

/* Enumerations for Cancellation Type              */
#define MAT_UPDATE_PROC     0
#define MAT_SUBS_WITHDRAW   1
#ifdef XWEXT /* xingzhou.xu: pirated reason 2006/10/13 */
#define MAT_PIRATED_CANCEL  2      /* Pirated cause cancel */
#endif

/* Enumerations for Interrogation Type */
#define MAT_BASIC_CALL 0   /* Basic Call */
#define MAT_FORWARDING 1   /* Forwarding */
#ifdef XWEXT 
#define MAT_HANDOVER 2     /* Handover */
#endif
/* mat_h_001.main_13 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
#define MAT_NLR_INTERRO 30   /* NLR Interrogation */
#endif

/* mat_h_001.main_13 : Addition: Additional elmnts */
/* Enumerations for Operate Type */
#ifdef MAP_CH_PLUS
#define MAT_REDIRECTION             0  /* redirection   */
#define MAT_INS_PREFIX              1  /* Insert Prefix   */
#define MAT_ORIG_CALLED_NMB_EMPTY   2  /* Orig call nmb empty  */
#define MAT_ORG_CLD_AND_CLD_NMB_EMPTY   3  /* Orig called and called nmb empty
*/
#endif


/* Enumerations for Forwarding Reason */
#define MAT_NOT_REACHABLE 0  /* Not Reachable */
#define MAT_BUSY          1  /* Busy */
#define MAT_NO_REPLY      2  /* No Reply */

/* Enumerations for Default Call Handling */
#define MAT_CONTINUE_CALL 0 /* continue call */
#define MAT_RELEASE_CALL  1 /* release call  */

/* Enumerations for Reporting State Enums */
#define MAT_STOP_MONITORING  0 /* stop monitoring */
#define MAT_START_MONITORING 1 /* Start Monitoring */

/* Enumerations for CCBS Subscriber Status */
#define MAT_CCBS_NOT_IDLE 0  /* ccbs not idle */
#define MAT_CCBS_IDLE     1  /* ccbs idle */
#define MAT_CCBS_NOT_REACHABLE 2 /* ccbs not reachable */


/* Enumerations for Mointoring Mode       */
#define MAT_A_SIDE        0  /* a-side        */
#define MAT_B_SIDE        1  /* b-side   */

/* Enumerations for Call Outcome          */
#define MAT_CALL_SUCCESS       0  /* success   */
#define MAT_CALL_FAILURE       1  /* failure   */
#define MAT_CALL_BUSY          2  /* busy       */


/* Enumerations for ruf Outcome          */
#define MAT_ACCEPTED             0 /* success   */
#define MAT_REJECTED             1 /* failure   */
#define MAT_NO_RESP_FROM_BUSY_MS 2 /* no response from busy Ms */
#define MAT_NO_RESP_FROM_FREE_MS 3 /* no response from free Ms */
#define MAT_UDUB_FROM_FREE_MS    4 /* success   */
#define MAT_UDUB_FROM_BUSY_MS    5 /* failure   */

/* MAP_REL98 || MAP_REL99 */
/* Number portability status */
#define MAT_NOT_KNOWN_TO_BE_PORTED         0
#define MAT_OWN_NMB_PORTED_OUT             1
#define MAT_FRGN_NMB_PORTED_TO_FRGN_NET    2

#define MAT_OWN_NMB_NOT_PORTED_OUT         4
#define MAT_FRGN_NMB_PORTED_IN             5

/* External Protocol ID */
#define MAT_ETS_300356                     1

/* LCS Event */
#define MAT_EMERG_CALL_OR_ORIG             0
#define MAT_EMERG_CALL_RELEASE             1
#define MAT_MO_LR                          2
/* new value for MAP_REL4 */
#define MAT_DEFER_MT_RES                   3

/* Unauthorized LCS Client Diagnostic */
#define MAT_NO_ADDI_INFO                   0
#define MAT_CLIENT_NOT_IN_MS_PRIV_EXCEP    1
#define MAT_CALL_TO_CLIENT_NOT_SETUP       2
#define MAT_PRIV_OVERRIDE_NOT_APP          3
#define MAT_DISALLOWED_BY_LOCAL_REG_REQ    4
/* MAP_REL5 */
#define MAT_UNAUTH_PRIVACY_CLASS           5
#define MAT_UNAUTH_CALL_SESSION_UNRELATED_EXT_CLIENT 6
#define MAT_UNAUTH_CALL_SESSION_RELATED_EXT_CLIENT   7

/* Position Method Failure Diagnostic */
#define MAT_CONGESTION                     0
#define MAT_INSUFFICIENT_RESOUSES          1
#define MAT_INSUFFICIENT_MEAS_DATA         2
#define MAT_INCONSISTENT_MEAS_DATA         3
#define MAT_LOC_PROC_NOT_COMPLETED         4
#define MAT_LOC_PROC_NOT_SUP_BY_TARGT_MS   5
#define MAT_QOS_NOT_ATTAINABLE             6
#define MAT_POSI_METH_NOT_AVAI_NET         7
#define MAT_POSI_METH_NOT_AVAI_IN_LOC_AREA 8

/* Response time category */
#define MAT_LOW_DELAY                      0 
#define MAT_DELAY_TOLERANT                 1

/* LCS client type */
#define MAT_EMERGENCY_SERVICES             0
#define MAT_VALUE_ADDED_SERVICE            1
#define MAT_PLMN_OPERATOR_SERVICE          2
#define MAT_LAWFUL_INTERCEPT_SERVICES      3

/* Location estimate type */
#define MAT_CURRENT_LOCATION               0
#define MAT_CURRENT_OR_LAST_KNOWN_LOCATION 1
#define MAT_INITIA_LOCATION                2
/* upgrade for MAP release 4 */
/* new value for MAP_REL4 */
#define MAT_ACTV_DEFER_LOCATION            3
#define MAT_CANCEL_DEFER_LOCATION          4

/* LSA only access indicator */
#define MAT_ACCESS_OUTSIDE_LSA_ALLOWED     0
#define MAT_ACCESS_OUTSIDE_LSA_RESTRICTED  1

/* GMLC Restriction */
#define MAT_GMLC_LIST      0  /* GMLC List */
#define MAT_HOME_COUNTRY   1  /* Home-Country */

/* LCS client internal id */
#define MAT_BROADCAST_SERVICE    0  /* Broadcast service */
#define MAT_O_AND_M_HPLMN        1  /* o-andM-HPLMN */
#define MAT_O_AND_M_VPLMN        2  /* 0-andM-HPLMN */
#define MAT_ANONYMOUS_LOC        3  /* anonymous Location */
#define MAT_TARGT_MS_SUBS_SERV   4  /* target MS Subscribed service */

/* Notification to MS User */
#define MAT_NOTIFY_LOC_ALLOW                    0 /* Notify location allowed */
#define MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP     1 /* Notify & verify allowed if no resp. */
#define MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP 2 /* Notify & verify location not allowed */
/* Addition - upgrade for MAP release 4 */
/* new value for MAP_REL4 */
#define MAT_LOC_NOT_ALLOWED                     3 /* Location not allowed */


/* MAP_REL99 */
/* Access network protocol Id */
#define MAT_ACC_GSM_0806                       1
#define MAT_TS3G_25413                     2
#define MAT_TS3G_48006             MAT_ACC_GSM_0806

/* Key Status */
#define MAT_OLD                            0
#define MAT_NEW                            1

/* CCBS Requested State */
#define MAT_REQUEST                        0
#define MAT_RECALL                         1
#define MAT_ACTIVE                         2
#define MAT_COMPLETED                      3
#define MAT_SUSPENDED                      4
#define MAT_FROZEN                         5
#define MAT_DELETED                        6

/* IST support indicator */
#define MAT_BASIC_IST_SUPPORTED            0
#define MAT_IST_COMMAND_SUPPORTED          1

/* Modification Instruction */
#define MAT_DEACTIVATE                     0
#define MAT_ACTIVATE                       1

/* Default SMS handling */
#define MAT_CONTINUE_TRANSACTION  0
#define MAT_RELEASE_TRANSACTION   1

/* SMS trigger detection point */
#define MAT_SMS_COLLECTED_INFO    1
/* MAP_REL5 */
#define MAT_SMS_DELIVERY_REQUEST  2

/* Default GPRS handling */
#define MAT_GPRS_CONTINUE_TRANSACTION   0
#define MAT_GPRS_RELEASE_TRANSACTION    1

/* GPRS trigger detection point */
#define MAT_ATTACH                             1
#define MAT_ATTACH_CHANGE_OF_POSITION          2
#define MAT_PDP_CONTEXT_ESTABLISHMENT         11
#define MAT_PDP_CONTEXT_ESTABLISHMENT_ACK     12
#define MAT_PDP_CONTEXT_CHANGE_OF_POSITION    14

/* Requested CAMEL subscription Info */
#define MAT_O_CSI                0
#define MAT_T_CSI                1
#define MAT_VT_CSI               2
#define MAT_TIF_CSI              3
#define MAT_GPRS_CSI             4
#define MAT_SMS_CSI              5
#define MAT_SS_CSI               6
#define MAT_M_CSI                7
#define MAT_D_CSI                8

/* Call Termination Indicator */
#define MAT_TERM_CALL_ACTV_REF   0
#define MAT_TERM_ALL_ACTV        1

/* Enumerations for Authentication Failure Cause */
#define MAT_WRONG_RSP           0   /* Wrong Response */
#define MAT_WRONG_NET_SIG       1   /* Wrong Network Sginal */

/* Addition - upgrade for MAP release 4 */
/* MAP_REL4 */
/* Requesting node type */
#define MAT_VLR                 0   /* Wrong Response */
#define MAT_SGSN                1   /* Wrong Network Sginal */

/* MAP_REL4 */
/* Termination Cause */
#define MAT_NORMAL              0
#define MAT_ERROR_UNDEFINED     1
#define MAT_INTERNAL_TIMEOUT    2
#define MAT_TC_CONGESTION       3
#define MAT_MT_LR_RESTART       4
#define MAT_PRIVACY_VIOLATION   5
#define MAT_SHAPE_OF_LOC_ESTI_NOT_SUPP 6

/* MAP_REL4 */
/* Access type */
#define MAT_CALL                      0
#define MAT_EMERGENCY_CALL            1
#define MAT_LOCATION_UPDATING         2
#define MAT_SUPPLEMENTARY_SERVICE     3
#define MAT_SHORT_MESSAGE             4
/* The four value were introduced in 29.002 v4.5.0, 2001-09 */
#define MAT_GPRS_ATTACH               5
#define MAT_ROUTING_AREA_UPDATING     6
#define MAT_SERVICE_REQUEST           7
#define MAT_PDP_CONTEXT_ACTIVATION    8
#define MAT_PDP_CONTEXT_DEACTIVATION  9
#define MAT_GPRS_DETACH               10

/* MAP_REL5 */
/* MT SMS TPDU type */
#define MAT_SMS_DELIVER               0
#define MAT_SMS_SUBMIT_REPORT         1
#define MAT_SMS_STATUS_REPORT         2

/* Domain type */
#define MAT_CS_DOMAIN                 0
#define MAT_PS_DOMAIN                 1

/* Additional requested CAMEL subscription info */
#define MAT_MT_SMS_CSI                0
#define MAT_MG_CSI                    1
#define MAT_O_IM_CSI                  2
#define MAT_D_IM_CSI                  3
#define MAT_VT_IM_CSI                 4

/* MAP_REL6 */

/* LCS Format Indicator */
#define  MAT_LOGICAL_NAME             0
#define  MAT_EML_ADDRES               1
#define  MAT_MS_ISDN                  2
#define  MAT_URL                      3
#define  MAP_SIP_URL                  4

/* Privacy Check Related Action */
#define  MAT_ALLOWED_WITHOUT_NOTIFICATION 0
#define  MAT_ALLOWED_WITH_NOTIFICATION    1
#define  MAT_ALLOWED_IF_NO_RSP            2
#define  MAT_RST_IF_NO_RSP                3
#define  MAT_NOT_ALLOWED                  4

/* Areaa Type */
#define  MAT_CNT_CODE               0
#define  MAT_PLMN_ID                1
#define  MAT_LOCA_ID                2
#define  MAT_ROUT_AREA_ID           3
#define MAT_CELL_GLOB_ID            4


/* Occurance Info */
#define MAT_ONE_TIME_EVNT          0
#define MAP_MULTI_TIME_EVNT        1

/* Additional Network Resources */
#define MAT_SQSN                  0
#define MAT_QQSN                  1
#define MAT_QMLC                  2
#define MAT_QSM_SCF               3
#define MAT_NPLR                  4
#define MAT_AUC                   5


/* MAP_REL99 */
/* MAP own define extra large size token string */
#define MA_SIZE_TKNSTRUL                           MAT_SIZE_TKNSTRUL /* token string size - extra large */

/* TCAP Operation Class */
#define MA_OPRCLASS1                               MAT_OPRCLASS1 /* Operation Class */
#define MA_OPRCLASS2                               MAT_OPRCLASS2 /* Operation Class */
#define MA_OPRCLASS3                               MAT_OPRCLASS3 /* Operation Class */
#define MA_OPRCLASS4                               MAT_OPRCLASS4 /* Operation Class */

#define MA_SS_REQ                                  MAT_SS_REQ /* Service specific req/indication */
#define MA_SS_RSP                                  MAT_SS_RSP /* Service specific rsp/confirm */
#define MA_SS_RETERR                               MAT_SS_RETERR /* Service specific error rsp */

/* defines */
#define MA_MAX_VBSSUBSDATA                         MAT_MAX_VBSSUBSDATA /* 50 Maximum Vbs Subscription Data */
#define MA_MAX_VGCSSUBSDATA                        MAT_MAX_VGCSSUBSDATA /* 50 Maximum Vgcs Subscription Data */
#define MA_MAX_OBCSMCAMEL_TDPDATA                  MAT_MAX_OBCSMCAMEL_TDPDATA /* 10 Maximum o-bcsm camel TDP */
#define MA_MAX_DESTNMB                             MAT_MAX_DESTNMB /* Max. Destination Number list */
#define MA_MAX_DESTNMB_LEN                         MAT_MAX_DESTNMB_LEN /* Max. Destination Number length list */
#define MA_MAX_BASIC_SER_CRIT                      MAT_MAX_BASIC_SER_CRIT /* Max. Basic Service Criteria         */
#define MA_MAX_SS_EVENT_LST                        MAT_MAX_SS_EVENT_LST /* Max. SS. Evt. Lst */
#define MA_MAX_AUTHSET                             MAT_MAX_AUTHSET /* Maximum Authintication SET */ 
#define MA_MAX_HLRID                               MAT_MAX_HLRID /* Maximum HLR Id */ 
#define MA_MAX_BASIC_SERV                          MAT_MAX_BASIC_SERV /* Maximum Basic Service list */ 
#define MA_MAX_EXT_BASIC_SERV                      MAT_MAX_EXT_BASIC_SERV /* Maximum Basic Service list */ 
#define MA_MAX_CUG                                 MAT_MAX_CUG /* Maximum CUG Info */ 
#define MA_MAX_BEARSERV                            MAT_MAX_BEARSERV /* Maximum Bearer Service list */ 
#define MA_MAX_TELESERV                            MAT_MAX_TELESERV /* Maximum Tele Service list */ 
#define MA_MAX_SS                                  MAT_MAX_SS /* 30 Maximum SS list */ 
#define MA_MAX_SS_LIST                             MAT_MAX_SS_LIST /* Maximum SS list */ 
#define MA_MAX_SS_CODE                             MAT_MAX_SS_CODE /* Maximum SS Code list */ 
#define MA_MAX_ZONES                               MAT_MAX_ZONES /* Maximum Zone list */ 
#define MA_MAX_SNDPARAM                            MAT_MAX_SNDPARAM /* 6 Maximum Send parameter */
#define MA_MAX_REQPARAM                            MAT_MAX_REQPARAM /* Maximum Requested param. */
#define MA_MAX_SSEVTSPECS                          MAT_MAX_SSEVTSPECS /* Maximum Event Specs */
#define MA_MAX_CCBSREQ                             MAT_MAX_CCBSREQ /* Maximum Requested param. */
#define MA_MAX_ISDN_ADDR_LEN                       MAT_MAX_ISDN_ADDR_LEN /* Max Isdn Address Length */
#define MA_MAX_CAMEL_DEST_NMB                      MAT_MAX_CAMEL_DEST_NMB /* max number of camel dest. nmb */
#define MA_MAX_CAMEL_DEST_NMB_LEN                  MAT_MAX_CAMEL_DEST_NMB_LEN  /* max number of camel dest. nmb length */
#define MA_MAX_EVT_SPEC                            MAT_MAX_EVT_SPEC  /* max event specification       */
#define MA_MAX_BASSERVGRPS                         MAT_MAX_BASSERVGRPS /* max no. of Bas Serv Grps */
#define MA_MAXNUMOF_CAMTDPDATA                     MAT_MAXNUMOF_CAMTDPDATA /* Maximum o-bcsm camel TDP */
#define MA_MAXNUMOFPDP_CONTEXT                     MAT_MAXNUMOFPDP_CONTEXT /* Max no of Pdp Contexts */

/* MAP_REL98 || MAP_REL99 */
#define MA_MAX_NMB_LSA                             MAT_MAX_NMB_LSA /* Max no. of LSA's */
#define MA_MAX_NMB_GMLC                            MAT_MAX_NMB_GMLC /* Max no. of GMLC */
#define MA_MAX_NMB_PRIVACYCLASS                    MAT_MAX_NMB_PRIVACYCLASS /* Max no. of Privacy class */
#define MA_MAX_NMB_EXT_CLIENT                      MAT_MAX_NMB_EXT_CLIENT /* Max no. of External clients */
#define MA_MAX_NMB_PLMN_CLIENT                     MAT_MAX_NMB_PLMN_CLIENT /* Max no. of PLMN clients */
#define MA_MAX_NMB_MOLR_CLASS                      MAT_MAX_NMB_MOLR_CLASS /* Max no. of MOLR class */
#define MA_MAX_NAME_STRING_LEN                     MAT_MAX_NAME_STRING_LEN /* Max name string length */
#define MA_MAX_EXT_GEOG_INFO                       MAT_MAX_EXT_GEOG_INFO /* Max ext geographical Information */   


/* MAP_REL99 */
#define MA_MAXNMB_CAM_OCAUSEVALCRIT                MAT_MAXNMB_CAM_OCAUSEVALCRIT /* Max no. of OCause Value Criteria */
#define MA_MAXNMB_CAM_TCAUSEVALCRIT                MAT_MAXNMB_CAM_TCAUSEVALCRIT /* Max no. of T Cause Value Criteria */
#define MA_MAX_NMB_MOBILITY_TRIGGERS               MAT_MAX_NMB_MOBILITY_TRIGGERS /* Max no. of Mobility triggers */
#define MA_MAX_FTN_ADDRESS_LEN                     MAT_MAX_FTN_ADDRESS_LEN /* Max no. of FTN Address Length */
#define MA_MAX_ISDN_ADDRESSDIGITS                  MAT_MAX_ISDN_ADDRESSDIGITS /* Max no. of ISDN address digits */
#define MA_MAX_NMB_DP_ANALYZEDINFO_CRIT            MAT_MAX_NMB_DP_ANALYZEDINFO_CRIT /* Max no. of PDP analyzed info criteria */ 
#define MA_MAX_NMB_INTEGRITY_INFO                  MAT_MAX_NMB_INTEGRITY_INFO /* Max No of Integrity Info */
#define MA_MAX_NMB_ENCRYPTION_INFO                 MAT_MAX_NMB_ENCRYPTION_INFO /* Max No of Encryption Info */
#define MA_MAX_NMB_RELOCATION_NMB                  MAT_MAX_NMB_RELOCATION_NMB /* Max No of Relocation Nmb */


#define MA_MAX_NMB_PRI_EXT                         MAT_MAX_NMB_PRI_EXT /* Max. no. of Private extensions */ 


/* MAP user events */

#define MA_EVTBNDREQ                               MAT_EVTBNDREQ /* Bind request */
#define MA_EVTBNDCFM                               MAT_EVTBNDCFM /* Bind confirm */
#define MA_EVTUBNDREQ                              MAT_EVTUBNDREQ /* Unbind request */

#define MA_EVTOPENREQ                              MAT_EVTOPENREQ /* Open Request */
#define MA_EVTOPENIND                              MAT_EVTOPENIND /* Open Indication */
#define MA_EVTOPENRSP                              MAT_EVTOPENRSP /* Open Response */
#define MA_EVTOPENCFM                              MAT_EVTOPENCFM /* Open Confirm */

#define MA_EVTCLOSEREQ                             MAT_EVTCLOSEREQ /* Close Request */
#define MA_EVTCLOSEIND                             MAT_EVTCLOSEIND /* Close Indication */

#define MA_EVTDELIMREQ                             MAT_EVTDELIMREQ /* Delimeter Indication */
#define MA_EVTDELIMIND                             MAT_EVTDELIMIND /* Delimeter Indication */

#define MA_EVTABRTREQ                              MAT_EVTABRTREQ /* Abort Request */
#define MA_EVTABRTIND                              MAT_EVTABRTIND /* Abort Indication */

#define MA_EVTNOTICEIND                            MAT_EVTNOTICEIND /* Notice Indication */
#define MA_EVTSTATIND                              MAT_EVTSTATIND /* Status Indication */

#define MA_EVTDLGCFM                               MAT_EVTDLGCFM /* Dialogue Confirm */

#define MA_EVTSTEREQ                               MAT_EVTSTEREQ /* State Request */
#define MA_EVTSTEIND                               MAT_EVTSTEIND /* State Indication */
#define MA_EVTSTERSP                               MAT_EVTSTERSP /* State Response */
#define MA_EVTSTECFM                               MAT_EVTSTECFM /* State Confirm */


#define MA_EVTHOMGMTREQ                            MAT_EVTHOMGMTREQ /* Handover Management Request */
#define MA_EVTHOMGMTIND                            MAT_EVTHOMGMTIND /* Handover Management Indication */
#define MA_EVTHOMGMTRSP                            MAT_EVTHOMGMTRSP /* Handover Management Response */
#define MA_EVTHOMGMTCFM                            MAT_EVTHOMGMTCFM /* Handover Management Confirm */

#define MA_EVTAUTHMGMTREQ                          MAT_EVTAUTHMGMTREQ /* Auth. Management Request */
#define MA_EVTAUTHMGMTIND                          MAT_EVTAUTHMGMTIND /* Auth. Management Indication */
#define MA_EVTAUTHMGMTRSP                          MAT_EVTAUTHMGMTRSP /* Auth. Management Response */
#define MA_EVTAUTHMGMTCFM                          MAT_EVTAUTHMGMTCFM /* Auth. Management Confirm */

#define MA_EVTIMEIMGMTREQ                          MAT_EVTIMEIMGMTREQ /* IMEI Management Request */
#define MA_EVTIMEIMGMTIND                          MAT_EVTIMEIMGMTIND /* IMEI Management Indication */
#define MA_EVTIMEIMGMTRSP                          MAT_EVTIMEIMGMTRSP /* IMEI Management Request */
#define MA_EVTIMEIMGMTCFM                          MAT_EVTIMEIMGMTCFM /* IMEI Management Indication */

#define MA_EVTSUBMGMTREQ                           MAT_EVTSUBMGMTREQ /* Subs. Management Request */
#define MA_EVTSUBMGMTIND                           MAT_EVTSUBMGMTIND /* Subs. Management Indication */
#define MA_EVTSUBMGMTRSP                           MAT_EVTSUBMGMTRSP /* Subs. Management Response */
#define MA_EVTSUBMGMTCFM                           MAT_EVTSUBMGMTCFM /* Subs. Management Confirm */

#define MA_EVTFRMGMTREQ                            MAT_EVTFRMGMTREQ /* Fault & Rec. Management Req. */
#define MA_EVTFRMGMTIND                            MAT_EVTFRMGMTIND /* Fault & Rec. Management Ind. */
#define MA_EVTFRMGMTRSP                            MAT_EVTFRMGMTRSP /* Fault & Rec. Management Resp. */
#define MA_EVTFRMGMTCFM                            MAT_EVTFRMGMTCFM /* Fault & Rec. Management Conf. */

#define MA_EVTOAMMGMTREQ                           MAT_EVTOAMMGMTREQ /* OAM Management Request */
#define MA_EVTOAMMGMTIND                           MAT_EVTOAMMGMTIND /* OAM Management Indication */
#define MA_EVTOAMMGMTRSP                           MAT_EVTOAMMGMTRSP /* OAM Management Response */
#define MA_EVTOAMMGMTCFM                           MAT_EVTOAMMGMTCFM /* OAM Management Confirm */

#define MA_EVTCALLMGMTREQ                          MAT_EVTCALLMGMTREQ /* Call Management Request */
#define MA_EVTCALLMGMTIND                          MAT_EVTCALLMGMTIND /* Call Management Indication */
#define MA_EVTCALLMGMTRSP                          MAT_EVTCALLMGMTRSP /* Call Management Response */
#define MA_EVTCALLMGMTCFM                          MAT_EVTCALLMGMTCFM /* Call Management Confirm */

#define MA_EVTSSMGMTREQ                            MAT_EVTSSMGMTREQ /* SS Management Request */
#define MA_EVTSSMGMTIND                            MAT_EVTSSMGMTIND /* SS Management Indication */
#define MA_EVTSSMGMTRSP                            MAT_EVTSSMGMTRSP /* SS Management Response */
#define MA_EVTSSMGMTCFM                            MAT_EVTSSMGMTCFM /* SS Management Confirm */

#define MA_EVTSMMGMTREQ                            MAT_EVTSMMGMTREQ /* SM Management Request */
#define MA_EVTSMMGMTIND                            MAT_EVTSMMGMTIND /* SM Management Indication */
#define MA_EVTSMMGMTRSP                            MAT_EVTSMMGMTRSP /* SM Management Response */
#define MA_EVTSMMGMTCFM                            MAT_EVTSMMGMTCFM /* SM Management Confirm */

#define MA_EVTPDPACTVREQ                           MAT_EVTPDPACTVREQ /* PDP ACTV Management Request */
#define MA_EVTPDPACTVIND                           MAT_EVTPDPACTVIND /* PDP ACTV Management Indication */
#define MA_EVTPDPACTVRSP                           MAT_EVTPDPACTVRSP /* PDP ACTV Management Response */
#define MA_EVTPDPACTVCFM                           MAT_EVTPDPACTVCFM /* PDP ACTV Management Confirm */

#define MA_EVTLOCMGMTREQ                           MAT_EVTLOCMGMTREQ /* Location Management Request */
#define MA_EVTLOCMGMTIND                           MAT_EVTLOCMGMTIND /* Location Management Indication */
#define MA_EVTLOCMGMTRSP                           MAT_EVTLOCMGMTRSP /* Location Management Response */
#define MA_EVTLOCMGMTCFM                           MAT_EVTLOCMGMTCFM /* Location Management Confirm */

/* MAP_REL98 || MAP_REL99 */
#define MA_EVTLOCSERVREQ                           MAT_EVTLOCSERVREQ /* Loc. Services Management Request */
#define MA_EVTLOCSERVIND                           MAT_EVTLOCSERVIND /* Loc. Services Management Indication */
#define MA_EVTLOCSERVRSP                           MAT_EVTLOCSERVRSP /* Loc. Services Management Response */
#define MA_EVTLOCSERVCFM                           MAT_EVTLOCSERVCFM /* Loc. Services Management Confirm */


/* define for closing a dialogue */
#define MA_PREARRANGED_RELEASE                     MAT_PREARRANGED_RELEASE  
#define MA_NORMAL_RELEASE                          MAT_NORMAL_RELEASE       

/* Defines for Dialogue refuse reason */

#define MA_NO_REASON                               MAT_NO_REASON /* No reason given */
#define MA_INV_DEST_REF                            MAT_INV_DEST_REF /* Invalid destination reference */
#define MA_INV_ORG_REF                             MAT_INV_ORG_REF /* Invalid orignating reference */
#define MA_ACN_NOT_SUPPORTED                       MAT_ACN_NOT_SUPPORTED /* Application context name not supported */
#define MA_POT_VER_INCOMP                          MAT_POT_VER_INCOMP /* Potential version compataibility */
#define MA_BAD_OPENREQ                             MAT_BAD_OPENREQ /* Bad Open Request */
#define MA_NODE_NOT_REACHABLE                      MAT_NODE_NOT_REACHABLE /* Dialogue refused */

/* defines for operation codes */

/********  Location Management *********************/
#define MA_UPLOC                                   MAT_UPLOC /* (ALL),Update location      */
#define MA_CANCELLOC                               MAT_CANCELLOC /* (ALL),Cancel Location      */
#define MA_PURGE                                   MAT_PURGE /* (2)Purge MS             */
#define MA_SNDID                                   MAT_SNDID /* (2)Send Identification  */
#define MA_GPRS_UPLOC                              MAT_GPRS_UPLOC /* (NEW)GPRS Update Location */
  /* TO DO: to be decided, is it 5 */
#define MA_DET_IMSI                                MAT_DET_IMSI /* (1),Detach IMSI          */
/* MAP_REL99 */
#define MA_NOTE_MMEVT                              MAT_NOTE_MMEVT /* Note MM event */


/********  Handover Management *********************/
#define MA_PRE_HO                                  MAT_PRE_HO /* (2)Prepare Handover */
#define MA_PRE_SUBSHO                              MAT_PRE_SUBSHO /* (2)prep. subs. handover */ 
#define MA_PER_HO                                  MAT_PER_HO /* (1),Perform handover */
#define MA_PER_SUBSHO                              MAT_PER_SUBSHO /* (1),Perform subsequent handover */
#define MA_SNDENDSIG                               MAT_SNDENDSIG /* (ALL)Send End Signal  */
#define MA_PROCACCSIG                              MAT_PROCACCSIG /* (ALL),Process Access Signalling */
#define MA_FWDACCSIG                               MAT_FWDACCSIG /* (ALL),Forward Access Signalling */

/********  Authentication Management *********************/
#define MA_AUTHINFO                                MAT_AUTHINFO /* (2)Authintication info */
/* MAP_REL99 */
#define MA_AUTHFAILRPT                             MAT_AUTHFAILRPT /* Authentication Failure Report */
#define MA_PAGING_DETECT                           MAT_PAGING_DETECT /* detect if pirated or not */


/********  Identification management ***************/
#define MA_CHKIMEI                                 MAT_CHKIMEI /* (ALL),Check IMEI */

/********  Fault & recovery management**************/
#define MA_RESET                                   MAT_RESET /* (ALL),Reset */
#define MA_RESTOREDATA                             MAT_RESTOREDATA /* (2)Restore Data */ 
#define MA_FWDCHKSSIND                             MAT_FWDCHKSSIND /* (ALL),Forward Check SS Indication */

/********  OAM Management **************************/

#define MA_ACTVTRACE                               MAT_ACTVTRACE /* (ALL),Activate trace */
#define MA_DACTVTRACE                              MAT_DACTVTRACE /* (ALL),Deactivate trace mode */
#define MA_SNDIMSI                                 MAT_SNDIMSI /* (2)Send IMSI */
#define MA_TRACESUBSACTV                           MAT_TRACESUBSACTV /* (1),Trace subscriber activity */
#define MA_NOTEINTERHO                             MAT_NOTEINTERHO /* (1),Not Internal Handover */

/********  Call Management **************************/
#define MA_ROUTINFO                                MAT_ROUTINFO /* (ALL)Send Routing Info */
#define MA_PROVROAMNMB                             MAT_PROVROAMNMB /* (ALL), Provide Roaming Number */
#define MA_PROV_SIWFS_NMB                          MAT_PROV_SIWFS_NMB /* (NEW)Provide SIWFS Number */
#define MA_SIWFS_SIGMOD                            MAT_SIWFS_SIGMOD /* (NEW)SIWFS Signalling modify */
#define MA_RESCALLHANDL                            MAT_RESCALLHANDL /* (NEW)Resume call handling   */
#define MA_SETRPTSTATE                             MAT_SETRPTSTATE /* (NEW)Set Reporting State    */
#define MA_STARPT                                  MAT_STARPT /* (NEW)Status Report          */
#define MA_RMTUSRFREE                              MAT_RMTUSRFREE /* (NEW)Remote user free       */
#define MA_PREP_GRPCALL                            MAT_PREP_GRPCALL /* (NEW)Prepare Group call             */
#define MA_SND_GRPCALLENDSIG                       MAT_SND_GRPCALLENDSIG /* (NEW)Send Group Call End Signalling */
#define MA_PRO_GRPCALLSIG                          MAT_PRO_GRPCALLSIG /* (NEW)Process Group Call Signalling  */
#define MA_FWD_GRPCALLSIG                          MAT_FWD_GRPCALLSIG /* (NEW)Forward Group Call Signalling  */
/* MAP_REL99 */
#define MA_IST_ALERT                               MAT_IST_ALERT /* IST Alert */
#define MA_IST_COMMAND                             MAT_IST_COMMAND /* IST Command */
/* MAP_REL6 */
#define MA_REL_RES                                 MAT_REL_RES /* Release
Resources */

/********  SS Management *********************/
#define MA_REGSS                                   MAT_REGSS /* (ALL),Register SS */
#define MA_ERASESS                                 MAT_ERASESS /* (ALL),Erase SS */
#define MA_ACTVSS                                  MAT_ACTVSS /* (ALL),Activate SS */
#define MA_DACTVSS                                 MAT_DACTVSS /* (ALL),Deactivate SS */
#define MA_INTERSS                                 MAT_INTERSS /* (ALL),Interogate SS */
#define MA_PROCUSSREQ                              MAT_PROCUSSREQ /* (2),Process unstruc. SS Req */
#define MA_USSREQ                                  MAT_USSREQ /* (2),Unstructured SS Request */
#define MA_USSNOTIFY                               MAT_USSNOTIFY /* (2),Unstructured SS Notify */
#define MA_REGPASSWD                               MAT_REGPASSWD /* (ALL),Register password */
#define MA_GETPASSWD                               MAT_GETPASSWD /* (ALL),Get password */
#define MA_REGCCENT                                MAT_REGCCENT /* (NEW)Register CC  Entry */
#define MA_ERASECCENT                              MAT_ERASECCENT /* (NEW)ERASE CC Entry */
#define MA_BEGIN_SUBS_ACTV                         MAT_BEGIN_SUBS_ACTV /* (1),begin subscriber activity */    
#define MA_PROCUSSDATA                             MAT_PROCUSSDATA /* (1),Process unstructured SS Data */
#define MA_SSINV_NOTIFY                            MAT_SSINV_NOTIFY /* SS Invocation Notify  */

/********  SMS  Management *********************/
#define MA_MO_FWDSM                                MAT_MO_FWDSM /* (ALL),Forward short message */
#define MA_FWDSM                                   MAT_FWDSM /* (NEW)MT-Fwd SM */
#define MA_MT_FWDSM                                MAT_MT_FWDSM /* (NEW)MT-Fwd SM */
#define MA_ROUTINFOSM                              MAT_ROUTINFOSM /* (ALL),Routing Info for SM */
#define MA_SMDEL                                   MAT_SMDEL /* ( 2),Report SM Delivery Status */
#define MA_INFSC                                   MAT_INFSC /* ( 2),Inform Service Center */
#define MA_ALRTSC                                  MAT_ALRTSC /* (2),Alert Service center */
#define MA_SMRDY                                   MAT_SMRDY /* (2),SM Ready */
#define MA_NOTSUBPRES                              MAT_NOTSUBPRES /* (1)Note Subscriber present */
#define MA_ALRTSCWRSLT                             MAT_ALRTSCWRSLT /* (1)Alert SC Without Result */

/********  Subscriber  Management *********************/
#define MA_INSSUBSDATA                             MAT_INSSUBSDATA /* (ALL),Insert Subscriber Data */
#define MA_DELSUBSDATA                             MAT_DELSUBSDATA /* (ALL),Delete Subscriber Data */
#define MA_PROVSUBSINFO                            MAT_PROVSUBSINFO /* (NEW)Provide Subscriber Info */
#define MA_ANY_INTER                               MAT_ANY_INTER /* (NEW)Any time interrogation  */
#define MA_SNDPARAM                                MAT_SNDPARAM /* (1),Send Parameters */
/* MAP_REL99 */
#define MA_ANY_SUBSDATA_INTER                      MAT_ANY_SUBSDATA_INTER /* Any time subscriber info interrogation */
#define MA_ANY_MOD                                 MAT_ANY_MOD /* Any time modification */
#define MA_NOTE_SUBSDATA_MOD                       MAT_NOTE_SUBSDATA_MOD /* Note subscriber data modified */


/********  Pdp Active Management ***************/

#define MA_GPRS_ROUTINFO                           MAT_GPRS_ROUTINFO /* (NEW)Rout Info  for GPRS   */
#define MA_FAILRPT                                 MAT_FAILRPT /* (NEW)Failure Report */
#define MA_GPRS_NOTEMSPRES                         MAT_GPRS_NOTEMSPRES /* (NEW)GPRS NoteMs Present */

/* MAP_REL98 || MAP_REL99 */
/********  Location Service  ***************/

#define MA_PROVSUBSLOC                             MAT_PROVSUBSLOC /* Provide Subscriber Location */
#define MA_SENDROUTINFOFORLCS                      MAT_SENDROUTINFOFORLCS /* Send Routing Info For LCS */
#define MA_SUBSLOCRPT                              MAT_SUBSLOCRPT /* Subscriber Location Report */


/* return code in status indication */

#define MA_BAD_SPDLGID                             MAT_BAD_SPDLGID 
#define MA_BAD_INVKID                              MAT_BAD_INVKID 
#define MA_BAD_DLG_STATE                           MAT_BAD_DLG_STATE 
#define MA_BAD_USRERR_PARAM                        MAT_BAD_USRERR_PARAM 
#define MA_BAD_RSP_PARAM                           MAT_BAD_RSP_PARAM 
/* ma001.203 : Addition. Adding the value reqd in MAP_SEG */
#define MA_BAD_RSP_SEG_PARAM                       MAT_BAD_RSP_SEG_PARAM
/* mat_h_003.main_13: MA_LSAP_DEL is added */
#define MA_LSAP_DEL                               MAT_LSAP_DEL

/* defines for MAP dialogue response */
#define MA_DLG_OK                                  MAT_DLG_OK /* Dialogue accepted */
#define MA_DLG_REFUSED                             MAT_DLG_REFUSED /* Dialogue refused */

#define MA_DLG_OVERLOADED                          MAT_DLG_OVERLOADED /* User Overload check failed*/

/* defines for user abort reasons */

#define MA_ABRT_USR_SPECIFIC                       MAT_ABRT_USR_SPECIFIC /* user specific abort */
#define MA_ABRT_RESLIMIT                           MAT_ABRT_RESLIMIT /* resources limitation */
#define MA_ABRT_RESUNAVAIL                         MAT_ABRT_RESUNAVAIL /* resources unavailable */
#define MA_ABRT_APC                                MAT_ABRT_APC /* Application procedure cancellation */

/* defines for provider abort reasons */

#define MA_P_ABNORMAL_DLG                          MAT_P_ABNORMAL_DLG /* MA Abnormal dialogue */
#define MA_P_INVALID_PDU                           MAT_P_INVALID_PDU /* MA Invalid PDU */
#define MA_P_VER_INCOMP                            MAT_P_VER_INCOMP /* Version incompatibilty */
#define MA_PROV_MALFUNC                            MAT_PROV_MALFUNC /* Provider malfunction */
#define MA_SUP_DLG_RLS                             MAT_SUP_DLG_RLS /* Supporting dialogue released */
#define MA_RSRS_LIMIT                              MAT_RSRS_LIMIT /* Resource limitation */
#define MA_VER_INCOMP                              MAT_VER_INCOMP /* Version incompatibility */

/* Defines for provider abort source */
#define MA_PABRT_MAP                               MAT_PABRT_MAP /* MAP Abort */
#define MA_PABRT_TC                                MAT_PABRT_TC /* TC Abort */
#define MA_PABRT_NET                               MAT_PABRT_NET /* Network Abort */

/* Abort source */

#define MA_USR_ABRT                                MAT_USR_ABRT /* Abort by peer user */
#define MA_PROV_ABRT                               MAT_PROV_ABRT /* Provider abort */

/* MAP Diagnostics parameter */
#define MA_ABEVT_RCVD_PEER                         MAT_ABEVT_RCVD_PEER /* Max. Invoke Reached */
#define MA_ABEVT_DET_PEER                          MAT_ABEVT_DET_PEER
#define MA_EVT_REJ_PEER                            MAT_EVT_REJ_PEER 
#define MA_INV_RSP_PEER                            MAT_INV_RSP_PEER
#define MA_MAX_INVOKE_RCHD                         MAT_MAX_INVOKE_RCHD

#define MA_GAURD_TMR_EXPIRED                       MAT_GAURD_TMR_EXPIRED /* gaurd timer expiry */

#define MA_DLG_NOT_EXIST                           MAT_DLG_NOT_EXIST 
#define MA_SPCAUSE_MASK                            MAT_SPCAUSE_MASK 

/* return causes */
#define MA_RTC_NTBADADDR                           MAT_RTC_NTBADADDR /* No translation, address of such nature */
#define MA_RTC_NTSPECADDR                          MAT_RTC_NTSPECADDR /* No translation, specific address */
#define MA_RTC_SSCONG                              MAT_RTC_SSCONG /* subsystem congestion */
#define MA_RTC_SSFAIL                              MAT_RTC_SSFAIL /* subsystem failure */
#define MA_RTC_UNEQUIP                             MAT_RTC_UNEQUIP /* Unequiped User */
#define MA_RTC_NETFAIL                             MAT_RTC_NETFAIL /* Network Failure */
#define MA_RTC_NETCONG                             MAT_RTC_NETCONG /* Network Congestion */
#define MA_RTC_UNQUAL                              MAT_RTC_UNQUAL /* Unqualified */
#define MA_RTC_HOPVIOLATE                          MAT_RTC_HOPVIOLATE /* Hop counter violation (ANS92) */
#define MA_RTC_ERRMSGTPRT                          MAT_RTC_ERRMSGTPRT /* Error in message transport (CCITT92) */
#define MA_RTC_ERRLCLPROC                          MAT_RTC_ERRLCLPROC /* Error in local processing (CCITT92) */
#define MA_RTC_NOREASSEMB                          MAT_RTC_NOREASSEMB /* Dest. cannot perform reass.  (CCITT92) */
#define MA_RTC_SCCPFAIL                            MAT_RTC_SCCPFAIL /* SCCP failure (CCITT92) */
#define MA_RTC_HOPVIOLATE2                         MAT_RTC_HOPVIOLATE2 /* Hop counter violation (ITU 96) */
#define MA_RTC_NOSEGSPRT                           MAT_RTC_NOSEGSPRT /* Segmentation not supported */
#define MA_RTC_SEGFAILURE                          MAT_RTC_SEGFAILURE /* Segmentation failure */

/* MAP provider error source */
#define MA_REMOTE_PRV_ERR                          MAT_REMOTE_PRV_ERR /* provider error because of bad 
                                           * response/noresponse from peer
                                           */
      
#define MA_LOCAL_PRV_ERR                           MAT_LOCAL_PRV_ERR /* provider error because of error
                                           * in the local request primitive */ 
                                              

/* MAP Provider error for component probelms */
#define MA_PROV_ERR_NONE                           MAT_PROV_ERR_NONE /* No provider error */
#define MA_INVRSP_RCVD                             MAT_INVRSP_RCVD /* Invalid reponse received */
#define MA_SERV_NOT_SUPP                           MAT_SERV_NOT_SUPP /* Service not supported */
#define MA_MISTYPE_PARAM                           MAT_MISTYPE_PARAM /* Mistyped parameter */
#define MA_DUP_INVOKE_ID                           MAT_DUP_INVOKE_ID /* Duplicate invoke Id */
#define MA_UNX_RSP_PEER                            MAT_UNX_RSP_PEER /* Unexpected response from peer */
#define MA_NO_RSP_PEER                             MAT_NO_RSP_PEER /* No response from peer */
#define MA_SERV_COMP_FAILURE                       MAT_SERV_COMP_FAILURE /* Service completion failure */
#define MA_ABNORMAL_EVT_PEER                       MAT_ABNORMAL_EVT_PEER /* Unexpected response from peer */
#define MA_LINKED_RSP_UNX                          MAT_LINKED_RSP_UNX /* Linked response unexpected */
#define MA_UNX_LINKED_OP                           MAT_UNX_LINKED_OP /* unexpected linked operation */

/* MAP provider error for local reasons */

#define MA_INVALID_DLGID                           MAT_INVALID_DLGID /* Dialogue Id is bad */
#define MA_DUP_INVKID                              MAT_DUP_INVKID /* Duplicate Invoke Id */
#define MA_OPR_NOT_SUPP                            MAT_OPR_NOT_SUPP /* Operation code not supported */
#define MA_OUT_OF_RSRS                             MAT_OUT_OF_RSRS /* Out of resources */
#define MA_INCORRECT_PARAM                         MAT_INCORRECT_PARAM /* parameters of evnt structure in error */
#define MA_INVALID_LNKID                           MAT_INVALID_LNKID /* Invalid linked Id */
#define MA_INVALID_LNK_OPR                         MAT_INVALID_LNK_OPR /* Invalid linked operation */
#define MA_INVOKE_LIMIT_RCHD                       MAT_INVOKE_LIMIT_RCHD /* Max Invoke reached.      */


/* Error codes */
/* defines for user Error codes */

/* General  error */
#define MA_MISTYPED_PARAM                          MAT_MISTYPED_PARAM /* Mistyped param */
#define MA_INV_USR_ERRVAL                          MAT_INV_USR_ERRVAL /* Mistyped param */

/* User error */
#define MA_USR_INIT_RLS                            MAT_USR_INIT_RLS /* Initiating release */
#define MA_USR_RSRS_LIMIT                          MAT_USR_RSRS_LIMIT /* Resource limitation */

/* Generic error codes */
#define MA_SYS_FAILURE                             MAT_SYS_FAILURE /* System Failure */
#define MA_DATA_MISSING                            MAT_DATA_MISSING /* Data missing */
#define MA_UNX_DATA_VALUE                          MAT_UNX_DATA_VALUE /* Unexpected data value */
#define MA_FACILITY_NOT_SUPP                       MAT_FACILITY_NOT_SUPP /* Facility not supported */
#define MA_INCMPTBL_TERM                           MAT_INCMPTBL_TERM /* incompatible terminal */
#define MA_RSRC_LMT                                MAT_RSRC_LMT /* Resource Limitation */

/* Identification and numbering code */
#define MA_UNK_SUBS                                MAT_UNK_SUBS /* Unknown subscriber */
#define MA_NMB_CHNGD                               MAT_NMB_CHNGD /* Number changed */
#define MA_UNK_BASE_STAT                           MAT_UNK_BASE_STAT /* Unknown base station */
#define MA_UNK_MSC                                 MAT_UNK_MSC /* Unknown MSC */
#define MA_UNID_SUBS                               MAT_UNID_SUBS /* Unidentified subscriber */
#define MA_UNK_EQP                                 MAT_UNK_EQP /* Unknwon equipment */

/* Handover error codes */
#define MA_INV_TARG_BSTAT                          MAT_INV_TARG_BSTAT /* Invalid target base station */
#define MA_NO_RADIO_RSRS_AVAIL                     MAT_NO_RADIO_RSRS_AVAIL /* No radio resource available */
#define MA_NO_HONMB_AVAIL                          MAT_NO_HONMB_AVAIL /* No handover number available */
#define MA_SUBS_HO_FAIL                            MAT_SUBS_HO_FAIL /* Subsequent handover failure */
/* MAP_REL99 */
#define MA_TARG_COUT_GCAREA                        MAT_TARG_COUT_GCAREA /* Target cell outside grp call area */


/* operation and maintenance */
#define MA_TRC_BUFF_FULL                           MAT_TRC_BUFF_FULL /* Tracing buffer full */

/* subscription error */
#define MA_ROAM_NOTALLOWED                         MAT_ROAM_NOTALLOWED /* Roaming not allowed */
#define MA_ILLEGAL_SUBS                            MAT_ILLEGAL_SUBS /* Illegal Subscriber */
#define MA_ILLEGAL_EQP                             MAT_ILLEGAL_EQP /* Illegal equipment */
#define MA_BEAR_NOT_PROV                           MAT_BEAR_NOT_PROV /* Bearer service not provisioned */
#define MA_TELE_NOT_PROV                           MAT_TELE_NOT_PROV /* Tele service not provisioned */

/* call handling */
#define MA_NO_ROAM_AVAIL                           MAT_NO_ROAM_AVAIL /* No roaming number available */  
#define MA_ABSENT_SUBS                             MAT_ABSENT_SUBS /* Absent Subscriber */
#define MA_BUSY_SUBS                               MAT_BUSY_SUBS /* Busy Subscriber   */
#define MA_NOSUBS_REPLY                            MAT_NOSUBS_REPLY /* No Subscriber Reply */
#define MA_CALL_BARRED                             MAT_CALL_BARRED /* call barred */
#define MA_FWD_FAIL                                MAT_FWD_FAIL /* Forwarding Failed */
#define MA_OR_NOTALLOWED                           MAT_OR_NOTALLOWED /* Or Not Allowed    */
#define MA_FWD_VIOL                                MAT_FWD_VIOL /* call barred */
#define MA_CUG_REJECT                              MAT_CUG_REJECT /* CUG Reject */

/* supplementry services */
#define MA_ILLEGAL_SS_OPR                          MAT_ILLEGAL_SS_OPR /* Illegal SS operation */
#define MA_SS_STATUS_ERR                           MAT_SS_STATUS_ERR /* SS Error status */
#define MA_SS_NOT_AVAIL                            MAT_SS_NOT_AVAIL /* SS Not available */
#define MA_SS_SUBSVIOL_ERR                         MAT_SS_SUBSVIOL_ERR /* SS Subscription violation error */
#define MA_SS_INCOMP_ERR                           MAT_SS_INCOMP_ERR /* SS Incompability */
#define MA_UNK_ALPHABET                            MAT_UNK_ALPHABET /* Unknown alphabet */
#define MA_USSD_BUSY                               MAT_USSD_BUSY /* USSD Busy */
#define MA_PASSWD_REG_ERR                          MAT_PASSWD_REG_ERR /* PW registration failure */
#define MA_NEG_PWCHK                               MAT_NEG_PWCHK /* Negative password check */
#define MA_NMB_PW_VIOL                             MAT_NMB_PW_VIOL /* Number of password attempt violation */
#define MA_SHRTTERM_DENIAL                         MAT_SHRTTERM_DENIAL /* Short Term Denial */
#define MA_LONGTERM_DENIAL                         MAT_LONGTERM_DENIAL /* Long Term Denial */

/* short message services */
#define MA_MSG_WAIT_LISTFULL                       MAT_MSG_WAIT_LISTFULL /* Message waiting list full */
#define MA_SM_DEL_FAIL                             MAT_SM_DEL_FAIL /* Message waiting list full */
#define MA_SUBS_BUSY_MTMS                          MAT_SUBS_BUSY_MTMS /* Subscriber Busy for MT-MS */
#define MA_ABS_SUBS_SM                             MAT_ABS_SUBS_SM /* Absent Subscriber SM      */

/* Any Time Interrogation Error codes */
#define MA_ATI_NOTALLOWED                          MAT_ATI_NOTALLOWED /* ATI Not Allowed */

/* MAP_REL99 */

/* Any Time Informaiton Handling Error codes */
#define MA_ATSI_NOTALLOWED                         MAT_ATSI_NOTALLOWED /* ATSI Not Allowed */
#define MA_ATM_NOTALLOWED                          MAT_ATM_NOTALLOWED /* ATM Not Allowed */
#define MA_INFO_NOT_AVAIL                          MAT_INFO_NOT_AVAIL /* Information not available */

/* Mobility Management Error codes */
#define MA_MMEVT_NOTSUPPORTED                      MAT_MMEVT_NOTSUPPORTED /* MM event not supported */



/* Group Call Error Codes             */
#define MA_NOGRPCALLNMB_AVAIL                      MAT_NOGRPCALLNMB_AVAIL /* No Group Call Number Avail*/

/* MAP_REL98 || MAP_REL99 */
/* Location service error codes */
#define MA_UNAUTH_REQ_NET                          MAT_UNAUTH_REQ_NET /* Unauthorized requesting network */
#define MA_UNAUTH_LCSCLIENT                        MAT_UNAUTH_LCSCLIENT /* Unauthorized LCS client */
#define MA_POSITION_METH_FAIL                      MAT_POSITION_METH_FAIL /* Position method failure */
#define MA_UNKNOWN_OR_UNREACH                      MAT_UNKNOWN_OR_UNREACH /* Unknown or unreachable LCS client */


/* Defines for Enumerated values for error data types */

/* Roaming not allowed cause */
#define MA_PLMN_ROAM_NOTALLOWED                    MAT_PLMN_ROAM_NOTALLOWED /* PLMN Romaing not allowed */
#define MA_OPR_DET_BARRING                         MAT_OPR_DET_BARRING /* Operator determined barring */

/* Call Barring cause */
#define MA_BARRING_SERV_ACTV                       MAT_BARRING_SERV_ACTV /* Barring service Active */
#define MA_OPR_BARRING                             MAT_OPR_BARRING /* Operator barring */
#ifdef XWEXT /* xingzhou.xu: pirated reason */   
#define MA_PIRATED_BARRING                         MAT_PIRATED_BARRING /* Pirated barring */
#endif

/* CUG Reject cause */
#define MA_INCALL_BARR_CUG                         MAT_INCALL_BARR_CUG /* Incoming call Barred within CUG */
#define MA_SUBS_NOT_MEM_CUG                        MAT_SUBS_NOT_MEM_CUG /* Subscriber not member of CUG */
#define MA_RBS_VIOL_CUG                            MAT_RBS_VIOL_CUG /* Requested Basic service violates CUG
                                         * CUG Constraints */
#define MA_CPTY_INTER_VIOL                         MAT_CPTY_INTER_VIOL /* Called party SS interaction viol */

/* Password Registration Failure cause */
#define MA_UNDETERMINED                            MAT_UNDETERMINED /* undetermined */
#define MA_INV_FRMT                                MAT_INV_FRMT /* Invalid format */
#define MA_NEW_PASSWD_MISMACH                      MAT_NEW_PASSWD_MISMATCH /* New register password mismatch */

/* SM Delivery cause failure */

#define MA_MEM_EXCEEDED                            MAT_MEM_EXCEEDED /* Memory capacity exceeded */
#define MA_EQP_PROT_ERR                            MAT_EQP_PROT_ERR /* Equipment protocol error */
#define MA_EQP_NOTSM_EQUIPPED                      MAT_EQP_NOTSM_EQUIPPED /* Equipment not SM equipped */
#define MA_UNK_SC                                  MAT_UNK_SC /* Unknown SC */
#define MA_SC_CONGESTION                           MAT_SC_CONGESTION /* SC congestion */
#define MA_INV_SME_ADDR                            MAT_INV_SME_ADDR /* Invalid SME Address */
#define MA_SUBS_NOT_SC_SUBS                        MAT_SUBS_NOT_SC_SUBS /* Subscriber not SC subscriber */

/* Unknown Subscriber Diagnostic */
#define MA_IMSI_UNKNOWN                            MAT_IMSI_UNKNOWN /* IMSI Unknown */
#define MA_GPRS_SUBSCRIPTION_OPTION                MAT_GPRS_SUBSCRIPTION_OPTION /* Gprs Subscription Option */
/* MAP_REL99 */
#define MA_NPDB_MISMACH                            MAT_NPDB_MISMATCH /* NPDB mismatch */
#define MA_DIA_PIRATED_REASON                      MAT_DIA_PIRATED_REASON /* Pirated */


/* Absent Subscriber Reason */
#define MA_IMSI_DETACH                             MAT_IMSI_DETACH /* IMSI Detach      */
#define MA_ASR_RESTRICTED_AREA                     MAT_ASR_RESTRICTED_AREA /* Restricted Area  */
#define MA_NO_PAGE_RESPONSE                        MAT_NO_PAGE_RESPONSE /* No Page Response */
/* MAP_REL99 */
#define MA_PURGED_MS                               MAT_PURGED_MS /* Purged MS */


/* Defines for Enumerated values */

/* Network Access Modes */

#define MA_BOTH_MSC_SGSN                           MAT_BOTH_MSC_SGSN 
#define MA_ONLY_MSC                                MAT_ONLY_MSC 
#define MA_ONLY_SGSN                               MAT_ONLY_SGSN 

/* Network Resources */

#define MA_NETRSRS_PLMN                            MAT_NETRSRS_PLMN 
#define MA_NETRSRS_HLR                             MAT_NETRSRS_HLR 
#define MA_NETRSRS_VLR                             MAT_NETRSRS_VLR 
#define MA_NETRSRS_PVLR                            MAT_NETRSRS_PVLR 
#define MA_NETRSRS_CONTR_MSC                       MAT_NETRSRS_CONTR_MSC 
#define MA_NETRSRS_VMSC                            MAT_NETRSRS_VMSC 
#define MA_NETRSRS_EIR                             MAT_NETRSRS_EIR 
#define MA_NETRSRS_RSS                             MAT_NETRSRS_RSS 

/* Protocol Id */

#define MA_GSM_0408                                MAT_GSM_0408 
#define MA_GSM_0806                                MAT_GSM_0806 
#define MA_GSM_BSSMAP                              MAT_GSM_BSSMAP 
#define MA_ETS300102_1                             MAT_ETS300102_1 

/* Equipment Status */

#define MA_WHITE_LISTED                            MAT_WHITE_LISTED 
#define MA_BLACK_LISTED                            MAT_BLACK_LISTED 
#define MA_GREY_LISTED                             MAT_GREY_LISTED 

/* Handover Type */
#define MA_INTERBSS                                MAT_INTERBSS 
#define MA_INTRABSS                                MAT_INTRABSS 

/* Intra Cug Options */
#define MA_NOCUG_RESTRICTIONS                      MAT_NOCUG_RESTRICTIONS 
#define MA_CUGIC_CALLBARRED                        MAT_CUGIC_CALLBARRED 
#define MA_CUGOG_CALLBARRED                        MAT_CUGOG_CALLBARRED 

/* Client Restriction Options */

#define MA_PERMANENT_REST                          MAT_PERMANENT_REST 
#define MA_TEMP_DEFAULT_REST                       MAT_TEMP_DEFAULT_REST 
#define MA_TEMP_DEFAULT_ALLOWED                    MAT_TEMP_DEFAULT_ALLOWED 

/* Override Category */
#define MA_OVRRIDE_ENABLED                         MAT_OVRRIDE_ENABLED 
#define MA_OVRRIDE_DISABLED                        MAT_OVRRIDE_DISABLED 

/* Regiter Subscriber Response */
#define MA_MSC_AREA_REST                           MAT_MSC_AREA_REST 
#define MA_TOOMANY_ZONE_CODES                      MAT_TOOMANY_ZONE_CODES 
#define MA_ZONE_CODE_CONFLICT                      MAT_ZONE_CODE_CONFLICT 
#define MA_REG_SUBS_NOTSUPPORTED                   MAT_REG_SUBS_NOTSUPPORTED 

/* Delivery SM Outcome */ 
#define MA_MEM_EXCEEDED                            MAT_MEM_EXCEEDED 
#define MA_ABS_SUBS                                MAT_ABS_SUBS 
#define MA_SUCCESSFUL_TRANSFER                     MAT_SUCCESSFUL_TRANSFER 

/* Alert Reason */
#define MA_MS_PRESENT                              MAT_MS_PRESENT 
#define MA_MEM_AVAIL                               MAT_MEM_AVAIL 

/* Subscriber Status */
#define MA_SERV_GRANTED                            MAT_SERV_GRANTED 
#define MA_OPR_DETERMINED_BARRING                  MAT_OPR_DETERMINED_BARRING 

/* Guidance Info */
#define MA_ENTER_PW                                MAT_ENTER_PW 
#define MA_ENTER_NEW_PW                            MAT_ENTER_NEW_PW 
#define MA_ENTER_NEW_PW_AGAIN                      MAT_ENTER_NEW_PW_AGAIN 
#define MA_BAD_PW_TRY_AGAIN                        MAT_BAD_PW_TRY_AGAIN 
#define MA_BAD_PWFORMA_TRY_AGAIN                   MAT_BAD_PWFORMAT_TRY_AGAIN 

/* Requested parameters */

#define MA_REQ_IMSI                                MAT_REQ_IMSI 
#define MA_REQ_AUTHSET                             MAT_REQ_AUTHSET 
#define MA_REQ_SUBSDATA                            MAT_REQ_SUBSDATA 
#define MA_REQ_KI                                  MAT_REQ_KI 


/* SS Info Type */
#define MA_SSINFO_NONE                             MAT_SSINFO_NONE 
#define MA_FWD_INFO                                MAT_FWD_INFO 
#define MA_CBARR_INFO                              MAT_CBARR_INFO 
#define MA_CUG_INFO                                MAT_CUG_INFO 
#define MA_SSDATA                                  MAT_SSDATA 

/* Send Parameter Type */
#define MA_SNDPARAM_NONE                           MAT_SNDPARAM_NONE 
#define MA_SNDPARAM_IMSI                           MAT_SNDPARAM_IMSI 
#define MA_SNDPARAM_AUTHSET                        MAT_SNDPARAM_AUTHSET 
#define MA_SNDPARAM_SUBDATA                        MAT_SNDPARAM_SUBDATA 
#define MA_SNDPARAM_KI                             MAT_SNDPARAM_KI 

/* OBCSM Trigger Detection Point enumerations */
#define MA_COLLECTED_INFO                          MAT_COLLECTED_INFO 
/* MAP_REL99 */
#define MA_ROUTE_SELECT_FAILURE                    MAT_ROUTE_SELECT_FAILURE 


/* TBCSM Trigger Detection Point enumerations */
#define MA_TERM_ATTEMPT_AUTH                       MAT_TERM_ATTEMPT_AUTH 
/* MAP_REL99 */
#define MA_T_BUSY                                  MAT_T_BUSY 
#define MA_T_NO_ANSWER                             MAT_T_NO_ANSWER 


/* Match Type */
#define MA_INHIBITING                              MAT_INHIBITING 
#define MA_ENABLING                                MAT_ENABLING 

/* Call Type Criteria */
#define MA_FORWARDED                               MAT_FORWARDED 
#define MA_NOT_FORWARDED                           MAT_NOT_FORWARDED 

/* Cell Id or LAI Choice flag */
#define MA_CELLID_FIX_LEN                          MAT_CELLID_FIX_LEN 
#define MA_LAI_FIX_LEN                             MAT_LAI_FIX_LEN 

/* Subscriber State Choice Flag */
#define MA_ASSUMED_IDLE                            MAT_ASSUMED_IDLE 
#define MA_CAMEL_BUSY                              MAT_CAMEL_BUSY 
#define MA_NETDET_NOT_REACHABLE                    MAT_NETDET_NOT_REACHABLE 
#define MA_NOT_PROV_FROM_VLR                       MAT_NOT_PROV_FROM_VLR 

/* Enumerations For Not Reachable Reasons */
#define MA_MS_PURGED                               MAT_MS_PURGED 
#define MA_IMSI_DETACHED                           MAT_IMSI_DETACHED 
#define MA_RESTRICTED_AREA                         MAT_RESTRICTED_AREA 
#define MA_NOT_REGISTERED                          MAT_NOT_REGISTERED 

/* Enumerations for Additional SM Delivery Outcome */
#define MA_MEMORY_CAP_EXCEEDED                     MAT_MEMORY_CAP_EXCEEDED 
#define MA_ABSENT_SUBSCRIBER                       MAT_ABSENT_SUBSCRIBER 
#define MA_SUCCESSFUL_TRANSFER                     MAT_SUCCESSFUL_TRANSFER 

/* Enumerations for Cancellation Type              */
#define MA_UPDATE_PROC                             MAT_UPDATE_PROC 
#define MA_SUBS_WITHDRAW                           MAT_SUBS_WITHDRAW 
#ifdef XWEXT /* xingzhou.xu: pirated reason */   
#define MA_PIRATED_CANCEL                          MAT_PIRATED_CANCEL 
#endif

/* Enumerations for Interrogation Type */
#define MA_BASIC_CALL                              MAT_BASIC_CALL /* Basic Call */ 
#define MA_FORWARDING                              MAT_FORWARDING /* Forwarding */ 
/* mat_h_001.main_13 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
#define MA_NLR_INTERRO                             MAT_NLR_INTERRO /* NLR Interrogation */

/* Enumerations for Operate  Type */
#define MA_REDIRECTION                 MAT_REDIRECTION /* Redirection*/
#define MA_INS_PREFIX                  MAT_INS_PREFIX /* Insert Prefix*/
#define MA_ORIG_CALLED_NMB_EMPTY       MAT_ORIG_CALLED_NMB_EMPTY /* Org called party empty */
#define MA_ORG_CLD_AND_CLD_NMB_EMPTY  MAT_ORG_CLD_AND_CLD_NMB_EMPTY /* Org called and called party empty */
#endif

/* Enumerations for Forwarding Reason */
#define MA_NOT_REACHABLE                           MAT_NOT_REACHABLE /* Not Reachable */ 
#define MA_BUSY                                    MAT_BUSY /* Busy */ 
#define MA_NO_REPLY                                MAT_NO_REPLY /* No Reply */ 

/* Enumerations for Default Call Handling */
#define MA_CONTINUE_CALL                           MAT_CONTINUE_CALL /* continue call */ 
#define MAP_RELCALL                            MAT_RELEASE_CALL /* release call  */ 

/* Enumerations for Reporting State Enums */
#define MA_STOP_MONITORING                         MAT_STOP_MONITORING /* stop monitoring */ 
#define MA_START_MONITORING                        MAT_START_MONITORING /* Start Monitoring */ 

/* Enumerations for CCBS Subscriber Status */
#define MA_CCBS_NOT_IDLE                           MAT_CCBS_NOT_IDLE /* ccbs not idle */ 
#define MA_CCBS_IDLE                               MAT_CCBS_IDLE /* ccbs idle */ 
#define MA_CCBS_NOT_REACHABLE                      MAT_CCBS_NOT_REACHABLE /* ccbs not reachable */ 


/* Enumerations for Mointoring Mode       */
#define MA_A_SIDE                                  MAT_A_SIDE /* a-side        */ 
#define MA_B_SIDE                                  MAT_B_SIDE /* b-side   */ 

/* Enumerations for Call Outcome          */
#define MA_CALL_SUCCESS                            MAT_CALL_SUCCESS /* success   */ 
#define MA_CALL_FAILURE                            MAT_CALL_FAILURE /* failure   */ 
#define MA_CALL_BUSY                               MAT_CALL_BUSY /* busy       */ 


/* Enumerations for ruf Outcome          */
#define MA_ACCEPTED                                MAT_ACCEPTED /* success   */ 
#define MA_REJECTED                                MAT_REJECTED /* failure   */ 
#define MA_NO_RESP_FROM_BUSY_MS                    MAT_NO_RESP_FROM_BUSY_MS /* no response from busy Ms */ 
#define MA_NO_RESP_FROM_FREE_MS                    MAT_NO_RESP_FROM_FREE_MS /* no response from free Ms */ 
#define MA_UDUB_FROM_FREE_MS                       MAT_UDUB_FROM_FREE_MS /* success   */ 
#define MA_UDUB_FROM_BUSY_MS                       MAT_UDUB_FROM_BUSY_MS /* failure   */ 

/* MAP_REL98 || MAP_REL99 */
/* Number portability status */
#define MA_NOT_KNOWN_TO_BE_PORTED                  MAT_NOT_KNOWN_TO_BE_PORTED 
#define MA_OWN_NMB_PORTED_OUT                      MAT_OWN_NMB_PORTED_OUT 
#define MA_FRGN_NMB_PORTED_TO_FRGN_NET             MAT_FRGN_NMB_PORTED_TO_FRGN_NET 

/* External Protocol ID */
#define MA_ETS_300356                              MAT_ETS_300356 

/* LCS Event */
#define MA_EMERG_CALL_OR_ORIG                      MAT_EMERG_CALL_OR_ORIG 
#define MA_EMERG_CALL_RELEASE                      MAT_EMERG_CALL_RELEASE 
#define MA_MO_LR                                   MAT_MO_LR 

/* Unauthorized LCS Client Diagnostic */
#define MA_NO_ADDI_INFO                            MAT_NO_ADDI_INFO 
#define MA_CLIENT_NOT_IN_MS_PRIV_EXCEP             MAT_CLIENT_NOT_IN_MS_PRIV_EXCEP 
#define MA_CALL_TO_CLIENT_NOT_SETUP                MAT_CALL_TO_CLIENT_NOT_SETUP 
#define MA_PRIV_OVERRIDE_NOT_APP                   MAT_PRIV_OVERRIDE_NOT_APP 
#define MA_DISALLOWED_BY_LOCAL_REG_REQ             MAT_DISALLOWED_BY_LOCAL_REG_REQ 

/* Position Method Failure Diagnostic */
#define MA_CONGESTION                              MAT_CONGESTION 
#define MA_INSUFFICIENT_RESOUSES                   MAT_INSUFFICIENT_RESOUSES 
#define MA_INSUFFICIENT_MEAS_DATA                  MAT_INSUFFICIENT_MEAS_DATA 
#define MA_INCONSISTENT_MEAS_DATA                  MAT_INCONSISTENT_MEAS_DATA 
#define MA_LOC_PROC_NOT_COMPLETED                  MAT_LOC_PROC_NOT_COMPLETED 
#define MA_LOC_PROC_NOT_SUP_BY_TARGT_MS            MAT_LOC_PROC_NOT_SUP_BY_TARGT_MS 
#define MA_QOS_NOT_ATTAINABLE                      MAT_QOS_NOT_ATTAINABLE 
#define MA_POSI_METH_NOT_AVAI_NET                  MAT_POSI_METH_NOT_AVAI_NET 
#define MA_POSI_METH_NOT_AVAI_IN_LOC_AREA          MAT_POSI_METH_NOT_AVAI_IN_LOC_AREA 

/* Response time category */
#define MA_LOW_DELAY                               MAT_LOW_DELAY 
#define MA_DELAY_TOLERANT                          MAT_DELAY_TOLERANT 

/* LCS client type */
#define MA_EMERGENCY_SERVICES                      MAT_EMERGENCY_SERVICES 
#define MA_VALUE_ADDED_SERVICE                     MAT_VALUE_ADDED_SERVICE 
#define MA_PLMN_OPERATOR_SERVICE                   MAT_PLMN_OPERATOR_SERVICE 
#define MA_LAWFUL_INTERCEPT_SERVICES               MAT_LAWFUL_INTERCEPT_SERVICES 

/* Location estimate type */
#define MA_CURRENT_LOCATION                        MAT_CURRENT_LOCATION 
#define MA_CURRENT_OR_LAST_KNOWN_LOCATION          MAT_CURRENT_OR_LAST_KNOWN_LOCATION 
#define MA_INITIA_LOCATION                         MAT_INITIA_LOCATION 

/* LSA only access indicator */
#define MA_ACCESS_OUTSIDE_LSA_ALLOWED              MAT_ACCESS_OUTSIDE_LSA_ALLOWED 
#define MA_ACCESS_OUTSIDE_LSA_RESTRICTED           MAT_ACCESS_OUTSIDE_LSA_RESTRICTED 

/* GMLC Restriction */
#define MA_GMLC_LIST                               MAT_GMLC_LIST /* GMLC List */ 
#define MA_HOME_COUNTRY                            MAT_HOME_COUNTRY /* Home-Country */ 

/* LCS client internal id */
#define MA_BROADCAST_SERVICE                       MAT_BROADCAST_SERVICE /* Broadcast service */ 
#define MA_O_AND_M_HPLMN                           MAT_O_AND_M_HPLMN /* o-andM-HPLMN */ 
#define MA_O_AND_M_VPLMN                           MAT_O_AND_M_VPLMN /* 0-andM-HPLMN */ 
#define MA_ANONYMOUS_LOC                           MAT_ANONYMOUS_LOC /* anonymous Location */ 
#define MA_TARGT_MS_SUBS_SERV                      MAT_TARGT_MS_SUBS_SERV /* target MS Subscribed service */ 

/* Notification to MS User */
#define MA_NOTIFY_LOC_ALLOW                        MAT_NOTIFY_LOC_ALLOW /* Notify location allowed */ 
#define MA_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP         MAT_NOTIFY_VERIFY_LOC_ALLOW_NO_RESP /* Notify & verify allowed if no resp. */ 
#define MA_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP     MAT_NOTIFY_VERIFY_LOC_NOT_ALLOW_NO_RESP /* Notify & verify location not allowed */ 


/* MAP_REL99 */
/* Access network protocol Id */
#define MA_ACC_GSM_0806                            MAT_ACC_GSM_0806 
#define MA_TS3G_25413                              MAT_TS3G_25413 

/* Key Status */
#define MA_OLD                                     MAT_OLD 
#define MA_NEW                                     MAT_NEW 

/* CCBS Requested State */
#define MA_REQUEST                                 MAT_REQUEST 
#define MA_RECALL                                  MAT_RECALL 
#define MA_ACTIVE                                  MAT_ACTIVE 
#define MA_COMPLETED                               MAT_COMPLETED 
#define MA_SUSPENDED                               MAT_SUSPENDED 
#define MA_FROZEN                                  MAT_FROZEN 
#define MA_DELETED                                 MAT_DELETED 

/* IST support indicator */
#define MA_BASIC_IST_SUPPORTED                     MAT_BASIC_IST_SUPPORTED 
#define MA_IST_COMMAND_SUPPORTED                   MAT_IST_COMMAND_SUPPORTED 

/* Modification Instruction */
#define MA_DEACTIVATE                              MAT_DEACTIVATE 
#define MA_ACTIVATE_M                              MAT_ACTIVATE 

/* Default SMS handling */
#define MA_CONTINUE_TRANSACTION                    MAT_CONTINUE_TRANSACTION 
#define MA_RELEASE_TRANSACTION                     MAT_RELEASE_TRANSACTION 

/* SMS trigger detection point */
#define MA_SMS_COLLECTED_INFO                      MAT_SMS_COLLECTED_INFO 

/* Default GPRS handling */
#define MA_GPRS_CONTINUE_TRANSACTION               MAT_GPRS_CONTINUE_TRANSACTION 
#define MA_GPRS_RELEASE_TRANSACTION                MAT_GPRS_RELEASE_TRANSACTION 

/* GPRS trigger detection point */
#define MA_ATTACH                                  MAT_ATTACH 
#define MA_ATTACH_CHANGE_OF_POSITION               MAT_ATTACH_CHANGE_OF_POSITION 
#define MA_PDP_CONTEXT_ESTABLISHMENT               MAT_PDP_CONTEXT_ESTABLISHMENT 
#define MA_PDP_CONTEXT_ESTABLISHMENT_ACK           MAT_PDP_CONTEXT_ESTABLISHMENT_ACK 
#define MA_PDP_CONTEXT_CHANGE_OF_POSITION          MAT_PDP_CONTEXT_CHANGE_OF_POSITION 

/* Requested CAMEL subscription Info */
#define MA_O_CSI                                   MAT_O_CSI 
#define MA_T_CSI                                   MAT_T_CSI 
#define MA_VT_CSI                                  MAT_VT_CSI 
#define MA_TIF_CSI                                 MAT_TIF_CSI 
#define MA_GPRS_CSI                                MAT_GPRS_CSI 
#define MA_SMS_CSI                                 MAT_SMS_CSI 
#define MA_SS_CSI                                  MAT_SS_CSI 
#define MA_M_CSI                                   MAT_M_CSI 
#define MA_D_CSI                                   MAT_D_CSI 

/* Call Termination Indicator */
#define MA_TERM_CALL_ACTV_REF                      MAT_TERM_CALL_ACTV_REF 
#define MA_TERM_ALL_ACTV                           MAT_TERM_ALL_ACTV 

/* Enumerations for Authentication Failure Cause */
#define MA_WRONG_RSP                               MAT_WRONG_RSP /* Wrong Response */ 
#define MA_WRONG_NET_SIG                           MAT_WRONG_NET_SIG /* Wrong Network Sginal */ 

/******************************/
/*      MATV2 additions       */
/******************************/

/* importance values */
#define MAT_IMP_VAL_0  0
#define MAT_IMP_VAL_1  1
#define MAT_IMP_VAL_2  2
#define MAT_IMP_VAL_3  3
#define MAT_IMP_VAL_4  4
#define MAT_IMP_VAL_5  5
#define MAT_IMP_VAL_6  6
#define MAT_IMP_VAL_7  7

/* default RIL and SCCP state */
#define MAT_DEF_RIL         0    /* default ril */
#define MAT_DEF_SCCP_STATE  5    /* default sccp state */

#ifdef XWEXT
/*for xinwei*/
/*extension type id*/
#define XWEXT_OID1 "1"
#define XWEXT_OID2 "2"
#define XWEXT_OID3 "3"
#define XWEXT_OID4 "4"
#define XWEXT_OID5 "5"
#define XWEXT_OID6 "6"
#define XWEXT_OID7 "7"
#define XWEXT_OID8 "8"
#define XWEXT_OID9 "9"
#define XWEXT_OID10 "10"
#define XWEXT_OID11 "11"
#define XWEXT_OID12 "12"
#define XWEXT_OID13 "13"
#define XWEXT_OID14 "14"
#define XWEXT_OID15 "15"
#define XWEXT_OID16 "16"
#define XWEXT_OID17 "17"
#define XWEXT_OID18 "18"
#define XWEXT_OID19 "19"
#define XWEXT_OID20 "20"
#define XWEXT_OID21 "21"

/*upde location type*/
#define MA_XINWEI_POWER_ON_UD 1 /*power on update*/
#define MA_XINWEI_OVER_AREA_UD 2 /*over area update*/
#define MA_XINWEI_HANDOFF_UD 3 /* handoff update*/
#define MA_XINWEI_IMPLICITED_UD 4 /*implicited update*/
#define MA_XINWEI_POWER_OFF_UD 5 /* power off update*/

/*call out right */
#define MA_XINWEI_ALLOUT_PER 0 /*all out call permission*/
#define MA_XINWEI_ALLOUT_RES 1 /*all out call restrict*/
#define MA_XINWEI_LONGCALL_RES 2 /*long out call restrict*/
#define MA_XINWEI_INTCALL_RES 3 /*international out call restrict*/
#define MA_XINWEI_IPCALL_RES 4 /*ip out call restrict*/

/* paging detect mode */
#define MA_XINWEI_DETECT_RESERVED1  1  /* reserved */
#define MA_XINWEI_DETECT_ALL_AREA   2  /* detect all area */
#define MA_XINWEI_DETECT_RESERVED3  3  /* reserved */
#define MA_XINWEI_DETECT_RESERVED4  4  /* reserved */

/* paging detect result */
#define MA_XINWEI_DETECT_SUCC    1  /* succeeded */
#define MA_XINWEI_DETECT_FAIL    2  /* failed */

#endif /*XWEXT*/

#define cmPkMaRepBNmb       cmPkTknU8  /* Replace B Number */
#define cmPkMaRufOut        cmPkTknU8  /* Network Access Mode */
#define cmPkMaCcbsSubsStat  cmPkTknU8  /* Network Access Mode */
#define cmPkMaMonMode       cmPkTknU8  /* Monitoring Mode     */
#define cmPkMaCallOut       cmPkTknU8  /* Call Outcome        */
#define cmPkMaRptState      cmPkTknU8  /* Reporting State     */
#define cmPkMaNetAccMode    cmPkTknU8  /* Network Access Mode */
#define cmPkMaDefCallHandl  cmPkTknU8  /* Default Call Handling */
#define cmPkMaHoPri         cmPkTknU8  /* Handover priority */
#define cmPkMaEqupStatus    cmPkTknU8  /* Equp status       */
#define cmPkMaHoNotReq      cmPkTknU8  /* Handover Not required */
#define cmPkMaCiMode        cmPkTknU8  /* Ciphering Mode */
#define cmPkMaCKSN          cmPkTknU8  /* Ciphering Key Sequence Number */
#define cmPkMaMsNotReach    cmPkTknU8  /* MS not reachable */
#define cmPkMaNetRsrs       cmPkTknU8  /* Network resources */
#define cmPkMaHoType        cmPkTknU8  /* Handover type */
#define cmPkMaFwdOpt        cmPkTknU8  /* Forwarding Option */
#define cmPkMaIntraCugOpt   cmPkTknU8  /* Intra CUG Options */
#define cmPkMaIntCugRest    cmPkTknU8  /* Inter CUG Restrictions */
#define cmPkMaCugOAccess    cmPkTknU8  /* CUG Outgoing Access */
#define cmPkMaUssdDatCodSch cmPkTknU8  /* ussd Data Coding scheme */
#define cmPkMaSSCode        cmPkTknU8  /* Suplementry Services Code */
#define cmPkMaBearServ      cmPkTknU8  /* Bearer Service */
#define cmPkMaTeleServ      cmPkTknU8  /* Teleservice */
#define cmPkMaSSStatus      cmPkTknU8  /* SS Status */
#define cmPkMaCliRestOpt    cmPkTknU8  /* cli Restriction Option */
#define cmPkMaOvrRideCat    cmPkTknU8  /* OvrRide Category */
#define cmPkMaPerCallBas    cmPkTknU8  /* Per Call Basis*/
#define cmPkMaNotToHldRetPty cmPkTknU8 /* Notification to Held Ret Pty*/
#define cmPkMaUtoUServInd   cmPkTknU8  /* Usr to Usr Service Ind.*/
#define cmPkMaMaxConfNum    cmPkTknStrS /* Max Conf Num*/
#define cmPkMaHntGrpAccSelOdr cmPkTknU8 /* Hunt Grp acc Selection
                                          order */        
#define cmPkMaMsgToSnd      cmPkTknU8   /* more message to send */
#define cmPkMaNoSMRPDA      cmPkTknU8   /* SM SP DA */
#define cmPkMaNoSMRPOA      cmPkTknU8   /* SM RP OA */
#define cmPkMaSMDelRslt     cmPkTknU8   /* SM Delivery outcome */
#define cmPkMaAlrtReason    cmPkTknU8   /* Alert Reason */
#define cmPkMaSMPRI         cmPkTknU8   /* SM Priority */
#define cmPkMaRoamRestUF    cmPkTknU8   /*Roam.Rest. due to 
                                          Unsupported Feat */
#define cmPkMaFrzTMSI       cmPkTknU8   /* FreezeTMSI   */
#define cmPkMaFrzPTMSI      cmPkTknU8   /* FreezeP-TMSI */
#define cmPkMaMsSubsCat     cmPkTknU8   /* Subscriber Category */
#define cmPkMaMsSubsStat    cmPkTknU8   /* Subscriber Status */
#define cmPkMaMaxEntPri     cmPkTknStrS /* Max. Entitled Priority */
#define cmPkMaSuppTCSI      cmPkTknU8   /* Suppress TCSI */
#define cmPkMaAlrtPat       cmPkTknU8   /* Alerting Pattern */
#define cmPkMaSuppOfAncmt   cmPkTknU8  /* Suppression of Announcement */
#define cmPkMaCugSubsFlg    cmPkTknU8  /* CUG Subscription Flag */
#define cmPkMaSSLstElmnt    cmPkTknU8  /* SS List */
#define cmPkMaFwdIntReq     cmPkTknU8  /* Forwarding Interro Req. */
#define cmPkMaAssIdle       cmPkTknU8  /* Assumed Idle */
#define cmPkMaCamBusy       cmPkTknU8  /* Camel Busy */
#define cmPkMaNetDetNotRch  cmPkTknU8  /* NetDetNotReachable */ 
#define cmPkMaNotPrvFrVlr   cmPkTknU8  /* Not Provided From Vlr */
#define cmPkMaOrInterro     cmPkTknU8  /* or-Interrogation */
#define cmPkMaAbsSubsDiagSM cmPkTknStrS /* Absent Subscriber
                                            Diagnostic SM */
#define cmPkMaGprsSuppInd   cmPkTknU8  /* GPRS Support Indicator */
#define cmPkMaAddSMDelOut   cmPkTknU8  /* Additional SM Delivery 
                                           Outcome */
#define cmPkMaAddAbsSubsDiagSM  cmPkTknStrS /* Add. Absent Subscriber 
                                               Diag SM */
#define cmPkMaAlrtReasonInd cmPkTknU8  /* Alert Reason Indicator */ 
#define cmPkMaGprsNodeInd   cmPkTknU8  /* GPRS Node Indicator */
#define cmPkMaRegSubsRsp    cmPkTknU8  /* Regional Subscription 
                                           Response */
#define cmPkMaBroadInitEntitle   cmPkTknU8 /* broadcast Init 
                                             Entitlement */
#define cmPkMaOBcsmTrgDetPoint   cmPkTknU8 /* OBCSM Trigger 
                                              Detection Point */
#define cmPkMaTBcsmTrgDetPoint   cmPkTknU8 /* TBCSM Trigger  
                                              Detection Point */
#define cmPkMaMatchType          cmPkTknU8  /* Match Type */
#define cmPkMaDstNmbLenLstElmnt  cmPkTknStrS /* Destination Number 
                                                Length LIst */
#define cmPkMaCallTypeCrit       cmPkTknU8    /* Call Type Criteria */
#define cmPkMaCamCapHan          cmPkTknStrS  /* Camel Capability 
                                                 Handling */
#define cmPkMaSSEvtLstElmnt      cmPkTknU8  /* SS Event List */
#define cmPkMaVplmnAddrAll       cmPkTknU8  /* vplmn Address allowed */
#define cmPkMaRoamRestInSgsnUF   cmPkTknU8  /* Roam Restriction 
                                                in Sgsn */
#define cmPkMaVbsGrpInd          cmPkTknU8   /* vbs Group Indication */
#define cmPkMaVgcsGrpInd         cmPkTknU8   /* vgcs Group Indication */
#define cmPkMaCamSubsInfoWithDraw  cmPkTknU8 /* Camel Subs. 
                                                Info Withdraw */
#define cmPkMaReqPar             cmPkTknU8   /* Requested Parameter */
#define cmPkMaCallDir            cmPkTknU8   /* Call direction */
#define cmPkMaLocInformation     cmPkTknU8   /* Location Information */
#define cmPkMaSubsSta            cmPkTknU8   /* Subscriber State */
#define cmPkMaGrpKeyNmb          cmPkTknStrS /* Group Key Number    */
#define cmPkMaPri                cmPkTknStrS /* Priority            */
#define cmPkMaUpLnkFree          cmPkTknU8   /* Uplink free */
#define cmPkMaUpLnkReq           cmPkTknU8   /* Uplink Request */
#define cmPkMaUpLnkRlsInd        cmPkTknU8   /* Uplink Release 
                                                Indication */
#define cmPkMaRlsGrpCall         cmPkTknU8   /* Release Group Call */
#define cmPkMaUpLnkReqAck        cmPkTknU8   /* Uplink Request Ack */
#define cmPkMaUpLnkRejCmd        cmPkTknU8   /* Uplink Reject Command */
#define cmPkMaUpLnkSzeCmd        cmPkTknU8   /* Uplink Seize Command */
#define cmPkMaUpLnkRlsCmd        cmPkTknU8   /* Uplink Rls command */
#define cmPkMaMblNotRchRsn       cmPkTknStrS /* MobileNot Reach Reason*/
#define cmPkMaCanType            cmPkTknU8   /* Cancellation 
                                                 type enumeration */
#define cmPkMaInterroType        cmPkTknU8   /* Interrogation Type */
#define cmPkMaFwdReason          cmPkTknU8   /* Forwarding Reason  */
#define cmPkMaOrPhase            cmPkTknStrS /* OR-Phase */
#define cmPkMaCcbsCall           cmPkTknU8   /* CCBS Call */
#define cmPkMaSupCcbsPhase       cmPkTknStrS /* Supported CCBS Phase  */
#define cmPkMaMwdSet             cmPkTknU8   /* Mwd Set */
#define cmPkMaCcbsPsbl           cmPkTknU8   /* ccbs - possible */
#define cmPkMaDelOutInd          cmPkTknU8  /* Delivery Out Indicator */
#define cmPkMaExtCont            cmPkMaExtContSeq
#define cmPkMaODBGenData         cmPkTknStrE  /* ODB General Data */
#define cmPkMaODBHPLMNData       cmPkTknStrE  /* ODB HPLMN Data */
#define cmPkMaServInd            cmPkTknStrE  /* Service Indicator */
#ifdef XWEXT
 #define cmPkMaPriExtLst          cmPkTknStr4  /*Private ExtensionList*/
 #else
#define cmPkMaPriExtLst          cmPkTknStrE  /* Private ExtensionList*/
 #endif
#define cmPkMaSSEvtSpec          cmPkTknStrS  /* SS Event Spec */
#define cmPkMaSerKey             cmPkTknStrS  /* Service Key  */
#define cmPkMaTransBNmb          cmPkTknStrS  /* Translated B Number */
#define cmPkMaAgeOfLocInfo       cmPkTknStrS  /* Age of Location  
                                                 Information */
#define cmPkMaIMEI               cmPkTknStrS  /* International 
                                                 Mobile Equp Number */
#define cmPkMaIMSI               cmPkTknStrS  /* International MSI */
#define cmPkMaSgsnAddr           cmPkTknStrS  /* Sgsn Address      */
#define cmPkMaLMSI               cmPkTknStrS  /* Local MSI */ 
#define cmPkMaTMSI               cmPkTknStrS  /* Temporay MSI */ 
#define cmPkMaVlrNmb             cmPkTknStrS  /* VLR Number */
#define cmPkMaHlrNmb             cmPkTknStrS  /* HLR Number */
#define cmPkMaMscNmb             cmPkTknStrS  /* MSC Number */
#define cmPkMaHlrId              cmPkTknStrS  /* HLR Id */
#define cmPkMaMsISDN             cmPkTknStrS  /* MS ISDN Number */
#define cmPkMaRoamNmb            cmPkTknStrS  /* MS Roaming Number */
#define cmPkMaDialNmb            cmPkTknStrS  /* MS Dialled Number */
#define cmPkMaCellId             cmPkTknStrS  /* Global cell Id */
#define cmPkMaHoNmb              cmPkTknStrS  /* Handover number */
#define cmPkMaChanType           cmPkTknStrS  /* Channel type */
#define cmPkMaClassMarkInfo      cmPkTknStrS  /* class mark info */
#define cmPkMaAuthRand           cmPkTknStrS  /* Rand. nmb. used 
                                                 for Authentication */
#define cmPkMaAuthSRes           cmPkTknStrS  /* Authentication 
                                                 Set response */
#define cmPkMaAuthKey            cmPkTknStrS  /* Auth. key used 
                                                 for ciphering */
#define cmPkMaTrType             cmPkTknStrS  /* Trace type */
#define cmPkMaTrRef              cmPkTknStrS  /* Trace reference */
#define cmPkMaOMCId              cmPkTknStrS  /* OMS Id */
#define cmPkMaCallRef            cmPkTknStrS  /* Call Reference */
#define cmPkMaNmbOfFwd           cmPkTknStrS
#define cmPkMaFwdToNmb           cmPkTknStrS   /* Forward to Number */
#define cmPkMaFwdToSubAddr       cmPkTknStrS   /* Forward to 
                                                   SubAddress */
#define cmPkMaCugInd             cmPkTknStrS   /* CUG Index */
#define cmPkMaCugIntLock         cmPkTknStrS   /* CUG Inter lock */
#define cmPkMaCugOpt             cmPkTknU8
#define cmPkMaCugFacilities      cmPkTknU8
#define cmPkMaNoRplyCondTime     cmPkTknStrS   /* No reply codition 
                                                   time */
#define cmPkMaPasswd             cmPkTknStrS   /* Password */
#define cmPkMaGuidInfo           cmPkTknU8     /* Guidance Info */
#define cmPkMaSmRpMti            cmPkTknStrS   /* SM RP MTI */
#define cmPkMaSmRpSmea           cmPkTknStrS   /* SM RP SMEA */
#define cmPkMaMWDStat            cmPkTknStrS   /* MWD Status */
#define cmPkMaZoneCode           cmPkTknStrS   /* Zone code */
#define cmPkMaSCAddr             cmPkTknStrS   /* SC Address */
#define cmPkMaKi                 cmPkTknStrS   /* Key */
#define cmPkMaDefPri             cmPkTknStrS   /* Default Priority */
#define cmPkMaSupCamPhase        cmPkTknStrS   /* Supported Camel 
                                                   Phases */
#define cmPkMaVmscAddr           cmPkTknStrS   /* Vmsc Addr */
#define cmPkMaGeogInfo           cmPkTknStrS   /* Geographical 
                                                   Information */
#define cmPkMaLocNmb             cmPkTknStrS   /* Location Number */
#define cmPkMaCellIdFixLen       cmPkTknStrS   /* Cell Id Fixed Length*/
#define cmPkMaLaiFixLen          cmPkTknStrS   /* lai Fixed Length */
#define cmPkMaGmscAddr           cmPkTknStrS   /* GMSC Addr */
#define cmPkMaCallRefNmb         cmPkTknStrS   /* Call Reference 
                                                   Number */
#define cmPkMaNwNodeNmb          cmPkTknStrS   /* Network Node Number */
#define cmPkMaGroupId            cmPkTknStrS   /* Group Identifier */
#define cmPkMaGsmScfAddr         cmPkTknStrS   /* GSM SCF Address  */
#define cmPkMaDstNmbLstElmnt     cmPkTknStrS   /* Destination Number
                                                   LIst */
#define cmPkMaNaeaPrefCIC        cmPkTknStrS   /* Naea Preferred CIC */
#define cmPkMaPdpType            cmPkTknStrS   /* Pdp Type */
#define cmPkMaPdpAddr            cmPkTknStrS   /* Pdp Address */
#define cmPkMaQosSubs            cmPkTknStrS   /* qos subscribed */
#define cmPkMaBSubsAddr          cmPkTknStrS  /* B-Subscriber Address */ 
#define cmPkMaSIWFSNmb           cmPkTknStrS   /* SIWFS Number */ 
#define cmPkMaAsciCallRef        cmPkTknStrS   /* Asci Call Reference */
#define cmPkMaCodecInfo          cmPkTknStrS   /* Codec Information   */
#define cmPkMaCipherAlgo         cmPkTknU8     /* Ciphering Algorithm */
#define cmPkMaSgsnNmb            cmPkTknStrS   /* SGSN Number */
#define cmPkMaGgsnNmb            cmPkTknStrS   /* GGSN Number */
#define cmPkMaGgsnAddr           cmPkTknStrS   /* SGSN Address */
#define cmPkMaGrpCallNmb         cmPkTknStrS   /* Group Call Number   */
#define cmPkMaGrpKey             cmPkTknStrS   /* Group Key     */
#define cmPkMaCcbsIndex          cmPkTknStrS   /* CCBS Index  */
#define cmPkMaBSubsNmb           cmPkTknStrS   /* B-Subscriber Number */
#define cmPkMaBSubsSubAddr       cmPkTknStrS   /* B-Subscriber Number */
#define cmPkMaNetNodeNmb         cmPkTknStrS   /* Network Node Number */
#define cmPkMaExtBearServ        cmPkTknStrS   /* extended bearer 
                                                   service */
#define cmPkMaExtTeleServ        cmPkTknStrS   /*extended tel service */
#define cmPkMaContextId          cmPkTknStrS   /* Context Identifier  */
#define cmPkMaUssdStr            cmPkTknStrE   /* ussd String */
#define cmPkMaApn                cmPkTknStrE   /* ussd String */
#define cmPkMaSSUsrDat           cmPkTknStrE   /* SS User data */
#define cmPkMaSMRPUI             cmPkTknStrE   /* SM RP UI */
#define cmPkMaExtSSStatus        cmPkTknStrS   /* Ext. SS Status */
#define cmPkMaExtFwdOpt          cmPkTknStrS   /* Forwarding 
                                                   options(ext.) */
#define cmPkMaExtNoRplyCondTime  cmPkTknStrS   /* No reply codition 
                                                   time(ext.) */
#define cmPkMaCamCapHanl         cmPkTknStrS   /* Camel Capability 
                                                   Handling */

#if (MAP_REL98 || MAP_REL99)
#define cmPkMaSolsaSupInd        cmPkTknU8   /* Solsa Support 
                                                indicator */
#define cmPkMaLsaIdentity        cmPkTknStrS /* LSA Identifier */
#define cmPkMaLsaActvModeSupInd  cmPkTknU8   /*  LSA act mode Sup Ind */
#define cmPkMaLsaAttributes      cmPkTknU8   /* LSA Attributes */
#define cmPkMaGmlcListWithdraw   cmPkTknU8   /* Gmlc list withdraw */
#define cmPkMaLmuInd             cmPkTknU8   /* LMU Indicator */
#define cmPkMaCompletDataListIncl cmPkTknU8  /* Complete Data List 
                                               Included */
#define cmPkMaLsaOnlyAccessInd    cmPkTknU8   /* LSA Only Access
                                               Indicator */
#define cmPkMaLsaPriority         cmPkTknU8   /* LSA Attributes */
#define cmPkMaLsaActvModeInd      cmPkTknU8   /*  LSA act mode Ind. */
#define cmPkMaGmlcList            cmPkTknStrS /* GMLC List */
#define cmPkMaExtAddr             cmPkTknStrS /* Extension Address */
#define cmPkMaGmlcRest            cmPkTknU8   /* GMLC Restrictions */
#define cmPkMaNotifToMsUsr        cmPkTknU8   /* Notification to MS  
                                                  User*/
#define cmPkMaLcsClientIntId      cmPkTknU8   /* PLMN Client List */
#define cmPkMaOrNotSupInGmsc      cmPkTknU8   /* Or Not support In 
                                                  GMSC */
#define cmPkMaTifCsi              cmPkTknU8   /* tif-CSI */
#define cmPkMaMlcNmb              cmPkTknStrS /* MLC Number */
#define cmPkMaExtAddr             cmPkTknStrS /* Ext address */
#define cmPkMaLcsClientDiaByMs    cmPkTknStrS /* LCS client dialed
                                                 by MS */
#define cmPkMaLcsClientIntId      cmPkTknU8 /* LCS client internal Id */
#define cmPkMaUssdDatCodSch       cmPkTknU8 /* data coding scheme */
#define cmPkMaUssdStr             cmPkTknStrE /* LCS client name 
                                                 string */
#define cmPkMaLcsPriority         cmPkTknU8   /* LCS priority */
#define cmPkMaHoriAccuracy        cmPkTknU8   /* Horizontal accuracy */
#define cmPkMaVertAccuracy        cmPkTknU8   /* Vertical accuracy */
#define cmPkMaExtGeogInfo         cmPkTknStrS /* Location estimate */
#define cmPkMaNaEsrd              cmPkTknStrS /* NA-ESRD */
#define cmPkMaNaEsrk              cmPkTknStrS /* NA-ESRk */
#define cmPkMaUuInd               cmPkTknU8   /* UU indicator */
#define cmPkMaUui                 cmPkTknStrE   
#define cmPkMaUusCFInter          cmPkTknU8   /* UUS CF interaction */
#define cmPkMaAllInfoSent         cmPkTknU8   /* All Information Sent */
#define cmPkMaNmbPortStatus       cmPkTknU8   /* Number portability 
                                                  status */
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#define cmPkMaFailureCause      cmPkTknU8   /* Failure Cause */
#define cmPkMaSendSubsData      cmPkTknU8   /* Send Subscriber data */
#define cmPkMaSubsDataStored    cmPkTknStrS /* Subscriber data stored */
#define cmPkMaGprsEnhSupInd     cmPkTknU8   /* Gprs Enh. Support Ind */
#define cmPkMaIstAlertTmr       cmPkTknStrS /* IST Alert Timer */
#define cmPkMaSuperChargerSuppInHlr cmPkTknStrS /* Super Charg Supp 
                                                     In HLR */
#define cmPkMaMaxMcBear         cmPkTknStrS  /* Nbr Sb  */
#define cmPkMaMcBear            cmPkTknStrS  /* Nbr Usr */
#define cmPkMaCsAllocRetenPriority cmPkTknU8 /* CS-Alloc Reten 
                                                     priority */
#define cmPkMaGprsTrgDetPoint    cmPkTknU8   /* GPRS Trig. det. point */
#define cmPkMaDefGprsHand        cmPkTknU8   /* Default GPRS Handling */
#define cmPkMaNotificationToCse  cmPkTknU8   /* Notifi. to CSE */
#define cmPkMaCsiActive          cmPkTknU8   /* CSI Active */
#define cmPkMaSmsTrgDetPoint     cmPkTknU8   /* SMS Triger det point */
#define cmPkMaSmsHandl           cmPkTknU8   /* SMS Handling */
#define cmPkMaChargingChar       cmPkTknStrS /* Charging 
                                                characteristics */
#define cmPkMaIstInfoWithdraw    cmPkTknU8   /* Ist Info. withdraw */
#define cmPkMaSpecCsiWithdraw    cmPkTknStrE /* Specific CSI.withdraw */
#define cmPkMaNmbReqVectors      cmPkTknStrS /* Number of Requested 
                                                  Vectors */
#define cmPkMaSegProhibited      cmPkTknU8 /* Segmentation Prohibited */
#define cmPkMaImmResPreferred    cmPkTknU8 /* Immediate response 
                                                preferred */
#define cmPkMaAuthAuts           cmPkTknStrS  /* Auts */
#define cmPkMaAuthXres           cmPkTknStrS  /* Xres */
#define cmPkMaAuthCk             cmPkTknStrS  /* Ck */
#define cmPkMaAuthIk             cmPkTknStrS  /* Ik */
#define cmPkMaAuthAutn           cmPkTknStrS  /* Autn */
#define cmPkMaCauseValue         cmPkTknU8    /* O Cause Val Crit */
#define cmPkMaDialledNmb         cmPkTknStrS  /* Dialled Number */
#define cmPkMaPrePagingSup       cmPkTknU8    /* Pre-paging supported */
#define cmPkMaLongFtnSup         cmPkTknU8    /* Long FTN supported */
#define cmPkMaMmCode             cmPkTknU8     /* Event Met */
#define cmPkMaOdb                cmPkTknU8     /* Odb */
#define cmPkMaReqCamSubsInfo     cmPkTknU8     /* Requested CAMEL Subs 
                                                  Info */
#define cmPkMaSupVlrCamPhase     cmPkTknU8   /* Supported VLR-CAMEL
                                                  Phase */
#define cmPkMaSupSgsnCamPhase   cmPkTknU8    /* Supported SGSN-CAMEL
                                                  Phase */
#define cmPkMaLongFwdedToNmb    cmPkTknStrS  /* Long forward toNumber */
#define cmPkMaWngPwdAtmCntr    cmPkTknStrS   /* Wrong password attempts
                                                  Counter */
#define cmPkMaModInstr         cmPkTknU8     /* Modification Instruction */
#define cmPkMaIstSupInd        cmPkTknU8     /* IST support indicator */
#define cmPkMaCKSN             cmPkTknU8     /* CKSN */
#define cmPkMaKsi              cmPkTknU8     /* KSI */
#define cmPkMaIntegProteInfo   cmPkTknStrE   /* Integrity protection Info */
#define cmPkMaEncrInfo         cmPkTknStrE   /* Encryption Info */
#define cmPkMaKeyStatus        cmPkTknU8     /* Key status */
#define cmPkMaRNCId            cmPkTknStrS   /* RNC ID */
#define cmPkMaMultiBearReq     cmPkTknU8     /* Multiple Bearer Requested */
#define cmPkMaRadioResInfo     cmPkTknStrS   /* Radio resource information */ 
#define cmPkMaRabId            cmPkTknStrS   /* RAB ID */
#define cmPkMaMultiBearInfo    cmPkTknStrS   /* Multiple Bearer Info. */
#define cmPkMaMultiBearNotsup  cmPkTknU8     /* Multiple Bearer not Support */
#define cmPkMaDnLnkAtta        cmPkTknU8     /* Downlink attached */
#define cmPkMaUpLnkAtta        cmPkTknU8     /* Uplink attached */
#define cmPkMaDualCommu        cmPkTknU8     /* Dual communication */
#define cmPkMaCallOrig         cmPkTknU8     /* Call originator */
#define cmPkMaCurLoc           cmPkTknU8     /* Current location */
#define cmPkMaGeoDetInfo       cmPkTknStrS   /* Geodetic information */
#define cmPkMaCurLocRetr       cmPkTknU8     /* Current location retrieved */
#define cmPkMaSaiPres          cmPkTknU8     /* Sai present */
#define cmPkMaCallDivTreInd    cmPkTknU8     /* Call Diversion treatment ind */
/* Addition - New data type introduced for 3.9.0 rel_99 */
#define cmPkMaSeleGsmAlgo        cmPkTknU8   /* Selected GSM algorithms */
#define cmPkMaAlloGsmAlgo        cmPkTknU8   /* Allowed GSM algorithms */
#define cmPkMaChoIntegProteAlgo  cmPkTknU8   /* Chosen integ protection algo*/
#define cmPkMaChoEncrAlgo        cmPkTknU8   /* Chosen Encryption algorithms */
#define cmPkMaChoChanInfo        cmPkTknStrS /* Chosen channel info */
#define cmPkMaChoSpeechVer       cmPkTknStrS /* Chosen speech version */
#define cmPkMaSupGADShape        cmPkTknStrS /* Supported GAD shapes */
#define cmPkMaPermIntegProteAlgo cmPkTknStrS /* Permitted integ prote algo*/
#define cmPkMaPermEncrAlgo       cmPkTknStrS /* Permitted Encryption algo */
#define cmPkMaAddGeogInfo        cmPkTknStrE /* Add Geographical Information */
#define cmPkMaBSSMAPServHo       cmPkTknU8   /* BSSMAP service handover */
#define cmPkMaRANAPServHo        cmPkTknU8   /* RANAP service handover */
#define cmPkMaExtQosSubs         cmPkTknStrS /* Ext QOS subscribed*/
#define cmPkMaExt2QosSubs        cmPkTknStrS /* Ext2 QOS subscribed*/
#define cmPkMaSlrArgExtCont      cmPkMaSlrArgExtContSeq   /* Slr Arg Extension
Container */
#define cmPkMaNaEsrkReq          cmPkTknU8   /* NA-ESRk */

/* Addition - upgrade for MAP release 4 */
#if MAP_REL4
#define cmPkMaSuppLcsCapSets     cmPkTknStrS /* Supported LCS Capability sets */
#define cmPkMaDefLocEventType    cmPkTknStrS /* Deferred location event type */
#define cmPkMaCurrMscNum         cmPkTknStrS /* Current MSC number */
#define cmPkMaCurrSgsnNum        cmPkTknStrS /* Current SGSN number */
#define cmPkMaLCSRefNmb          cmPkTknU8   /* LCS reference number */

#if MAP_REL5
#define cmPkMaOffCam4CSIs        cmPkTknStrS /* Offered CAMEL 4 CSI */
#define cmPkMaCodec              cmPkTknStrS /* Codec */ 
#define cmPkMaGERANClassMark     cmPkTknStrE /* ussd String */
#define cmPkMaMtSmsTpduType      cmPkTknU8   /* MT SMS TPDU type */
#define cmPkMaLcsServTypeId      cmPkTknStrS /* LCS service type ID */
#define cmPkMaOffCam4funcs       cmPkTknStrE /* Offered CAM4 functionalities*/
#define cmPkMaDomainType         cmPkTknU8   /* Domain type */
#define cmPkMaRaIdentity         cmPkTknStrS /* RAI Identity */
#define cmPkMaNsApi              cmPkTknStrS /* NSAPI */
#define cmPkMaTEID               cmPkTknStrS /* tunnel endpoint identifier */
#define cmPkMaTransId            cmPkTknStrS /* Transaction ID */
#define cmPkMaGprsChargId        cmPkTknStrS /* GPRS charging ID */
#define cmPkMaMsClassMark2       cmPkTknStrS /* MS class mark 2 */
#define cmPkMaMsNetCap           cmPkTknStrS /* MS network capability */
#define cmPkMaMsRadioAccCap      cmPkTknStrE /* MS radio access capability */
#define cmPkMaAddReqCamSubsInfo  cmPkTknU8   /* Additional requested CAMEL */
#define cmPkMaUESBIIuA           cmPkTknStrE  /* UESBI */
#define cmPkMaUESBIIuB           cmPkTknStrE  /* UESBI */
#define cmPkMaRoutNmb            cmPkTknStrS /* Routeing Number */
#define cmPkMaAllowedServ        cmPkTknStrS /* Allowed Services */
#define cmPkMaUnavailCause       cmPkTknU8   /* Unavailable Cause */
#define cmPkMaPosiDatInfo        cmPkTknStrS /* Positioning Data information */
#define cmPkMaReqEqpInfo         cmPkTknStrS /* Request equipment info */
#define cmPkMaUtrPosiDatInfo     cmPkTknStrS /* Positioning Data information */
#define cmPkMaNaEsrkReq          cmPkTknU8   /* NA-ESRk */

/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
#define cmPkMaFormatIndc         cmPkTknU8   /* LCS Format Indicator */
#define cmPkMaVgmlcAddr          cmPkTknStrS /* v-gmlc address */
#define cmPkMaImeiSv             cmPkTknStrS /* IMEI Software Version Number */
#define cmPkMaSsdUp              cmPkTknU8   /* Sub Scriber Data Update */
#define cmPkMaHgmlcAddr          cmPkTknStrS /* h-gmlc address */
#define cmPkMaPprAddr            cmPkTknStrS /* ppr address */
#define cmPkMaAvgmlcAddr         cmPkTknStrS /* Additional v-gmlc address */
#define cmPkMaSmsCbsi            cmPkTknU8   /* SMS Call Barring Support
                                                 Indicator */
#define cmPkMaPrivChkRelAct      cmPkTknU8   /* Privacy Check Rleated Action */
#define cmPkMaOccrInfo           cmPkTknU8   /* Occurance Info */
#define cmPkMaIntrValTime        cmPkTknStrS /* Interval Time */
#define cmPkMaAreaType           cmPkTknU8   /* Area Type */
#define cmPkMaAreaId            cmPkTknStrS /* Area Identification */
#define cmPkMaAddNetRsrs         cmPkTknU8   /* Additional Network Resource */
#define cmPkMaReqPlmnId          cmPkTknStrS /* Requested PLMN id */
#define cmPkMaAccRestData        cmPkTknStrS /* Access Restriction Data */
#define cmPkMaAddCap             cmPkTknU8   /* Additional capability */
#define cmPkMaRelResSup          cmPkTknU8   /* Release Resources supported */
#define cmPkMaVstkRand           cmPkTknStrS /* Vstk Rand */ 
#define cmPkMaVstk               cmPkTknStrS /* Vstk */
#endif /* MAP_REL6 */
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
#endif /* MAP_REL99 */

#ifdef MAP_PHASE2_EXT_MARK
#define cmPkMaExtMark            cmPkTknStrE  /* Extension Marker */
#endif

/* mat_h_001.main_13 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
#define cmPkMaRedirLrn        cmPkTknStrS  /* Redir LRN */
#define cmPkMaCallingLrn      cmPkTknStrS  /* Calling LRN */
#define cmPkMaClgOrRedirDn    cmPkTknStrS  /* Calling/Redir DN */
#define cmPkMaCalledLrn       cmPkTknStrS  /* Called LRN */
#define cmPkMaCallingDn       cmPkTknStrS  /* Calling DN */
#define cmPkMaFlgForSpl       cmPkTknU8    /* Flag for Special */
#define cmPkMaOperationType   cmPkTknU8    /* Operation Type */
#endif

#define cmUnpkMaRepBNmb       cmUnpkTknU8      /* Replace B Number */
#define cmUnpkMaRufOut        cmUnpkTknU8       /* Network Access Mode */
#define cmUnpkMaCcbsSubsStat  cmUnpkTknU8 /* Network Access Mode */
#define cmUnpkMaMonMode       cmUnpkTknU8      /* Monitoring Mode     */
#define cmUnpkMaCallOut       cmUnpkTknU8      /* Call Outcome        */
#define cmUnpkMaRptState      cmUnpkTknU8   /* Reporting State     */
#define cmUnpkMaNetAccMode    cmUnpkTknU8   /* Network Access Mode */
#define cmUnpkMaDefCallHandl  cmUnpkTknU8 /* Default Call Handling */
#define cmUnpkMaHoPri         cmUnpkTknU8        /* Handover priority */
#define cmUnpkMaEqupStatus    cmUnpkTknU8   /* Equp status       */
#define cmUnpkMaHoNotReq      cmUnpkTknU8     /* Handover Not required */
#define cmUnpkMaCiMode       cmUnpkTknU8       /* Ciphering Mode */
#define cmUnpkMaCKSN         cmUnpkTknU8         /* Ciphering Key Sequence Number */
#define cmUnpkMaMsNotReach   cmUnpkTknU8  /* MS not reachable */
#define cmUnpkMaNetRsrs      cmUnpkTknU8      /* Network resources */
#define cmUnpkMaHoType       cmUnpkTknU8       /* Handover type */
#define cmUnpkMaFwdOpt       cmUnpkTknU8       /* Forwarding Option */
#define cmUnpkMaIntraCugOpt  cmUnpkTknU8  /* Intra CUG Options */
#define cmUnpkMaIntCugRest   cmUnpkTknU8   /* Inter CUG Restrictions */
#define cmUnpkMaCugOAccess   cmUnpkTknU8   /* CUG Outgoing Access */
#define cmUnpkMaUssdDatCodSch  cmUnpkTknU8 /* ussd Data Coding scheme */
#define cmUnpkMaSSCode       cmUnpkTknU8        /* Suplementry Services Code */
#define cmUnpkMaBearServ     cmUnpkTknU8     /* Bearer Service */
#define cmUnpkMaTeleServ     cmUnpkTknU8     /* Teleservice */
#define cmUnpkMaSSStatus     cmUnpkTknU8     /* SS Status */
#define cmUnpkMaCliRestOpt   cmUnpkTknU8   /* cli Restriction Option */
#define cmUnpkMaOvrRideCat   cmUnpkTknU8   /* OvrRide Category */
#define cmUnpkMaPerCallBas   cmUnpkTknU8   /* Per Call Basis*/
#define cmUnpkMaNotToHldRetPty cmUnpkTknU8   /* Notification to Held Ret Pty*/
#define cmUnpkMaUtoUServInd   cmUnpkTknU8   /* Usr to Usr Service Ind.*/
#define cmUnpkMaMaxConfNum    cmUnpkTknStrS   /* Max Conf Num*/
#define cmUnpkMaHntGrpAccSelOdr cmUnpkTknU8   /*Hunt Grp acc Selection order */        
#define cmUnpkMaMsgToSnd      cmUnpkTknU8     /* more message to send */
#define cmUnpkMaNoSMRPDA      cmUnpkTknU8     /* SM RP DA */
#define cmUnpkMaNoSMRPOA      cmUnpkTknU8     /* SM RP OA */
#define cmUnpkMaSMDelRslt     cmUnpkTknU8    /* SM Delivery outcome */
#define cmUnpkMaAlrtReason    cmUnpkTknU8  /* Alert Reason */
#define cmUnpkMaSMPRI         cmUnpkTknU8        /* SM Priority */
#define cmUnpkMaRoamRestUF    cmUnpkTknU8   /*Roam.Rest. due to Unsupported Feat */
#define cmUnpkMaDelOutInd     cmUnpkTknU8     /* Del. Out Indicator   */
#define cmUnpkMaFrzTMSI       cmUnpkTknU8     /* FreezeTMSI   */
#define cmUnpkMaFrzPTMSI      cmUnpkTknU8     /* FreezeP-TMSI */
#define cmUnpkMaMsSubsCat     cmUnpkTknU8    /* Subscriber Category */
#define cmUnpkMaMsSubsStat    cmUnpkTknU8   /* Subscriber Status */
#define cmUnpkMaMaxEntPri     cmUnpkTknStrS    /* Max. Entitled Priority */
#define cmUnpkMaSuppTCSI      cmUnpkTknU8    /* Suppress TCSI */
#define cmUnpkMaAlrtPat       cmUnpkTknU8      /* Alerting Pattern */
#define cmUnpkMaSuppOfAncmt   cmUnpkTknU8  /* Suppression of Announcement */
#define cmUnpkMaCugSubsFlg    cmUnpkTknU8   /* CUG Subscription Flag */
#define cmUnpkMaSSLstElmnt    cmUnpkTknU8   /* SS List */
#define cmUnpkMaFwdIntReq     cmUnpkTknU8    /* Forwarding Interro Req. */
#define cmUnpkMaAssIdle       cmUnpkTknU8     /* Assumed Idle */
#define cmUnpkMaCamBusy       cmUnpkTknU8      /* Camel Busy */
#define cmUnpkMaNetDetNotRch  cmUnpkTknU8 /* NetDetNotReachable */ 
#define cmUnpkMaNotPrvFrVlr   cmUnpkTknU8  /* Not Provided From Vlr */
#define cmUnpkMaOrInterro     cmUnpkTknU8    /* or-Interrogation */
#define cmUnpkMaAbsSubsDiagSM cmUnpkTknStrS /* Absent Subscriber Diagnostic SM */
#define cmUnpkMaGprsSuppInd   cmUnpkTknU8   /* GPRS Support Indicator */
#define cmUnpkMaAddSMDelOut   cmUnpkTknU8  /* Additional SM Delivery Outcome */
#define cmUnpkMaAddAbsSubsDiagSM  cmUnpkTknStrS /* Add. Absent Subscriber Diag SM */
#define cmUnpkMaAlrtReasonInd  cmUnpkTknU8 /* Alert Reason Indicator */ 
#define cmUnpkMaGprsNodeInd    cmUnpkTknU8  /* GPRS Node Indicator */
#define cmUnpkMaRegSubsRsp     cmUnpkTknU8   /* Regional Subscription Response */
#define cmUnpkMaBroadInitEntitle  cmUnpkTknU8 /* broadcast Init Entitlement */
#define cmUnpkMaOBcsmTrgDetPoint  cmUnpkTknU8 /* OBCSM Trigger Detection Point */
#define cmUnpkMaTBcsmTrgDetPoint  cmUnpkTknU8 /* TBCSM Trigger Detection Point */
#define cmUnpkMaMatchType      cmUnpkTknU8    /* Match Type */
#define cmUnpkMaDstNmbLenLstElmnt  cmUnpkTknStrS /* Destination Number Length LIst */
#define cmUnpkMaCallTypeCrit   cmUnpkTknU8 /* Call Type Criteria */
#define cmUnpkMaCamCapHan      cmUnpkTknStrS    /* Camel Capability Handling */
#define cmUnpkMaSSEvtLstElmnt  cmUnpkTknU8/* SS Event List */
#define cmUnpkMaVplmnAddrAll  cmUnpkTknU8 /* vplmn Address allowed */
#define cmUnpkMaRoamRestInSgsnUF   cmUnpkTknU8 /* Roam Restriction in Sgsn */
#define cmUnpkMaVbsGrpInd  cmUnpkTknU8    /* vbs Group Indication */
#define cmUnpkMaVgcsGrpInd  cmUnpkTknU8   /* vgcs Group Indication */
#define cmUnpkMaCamSubsInfoWithDraw  cmUnpkTknU8 /* Camel Subs. Info Withdraw */
#define cmUnpkMaReqPar      cmUnpkTknU8       /* Requested Parameter */
#define cmUnpkMaCallDir     cmUnpkTknU8     /* Call direction */
#define cmUnpkMaLocInformation   cmUnpkTknU8 /* Location Information */
#define cmUnpkMaSubsSta     cmUnpkTknU8    /* Subscriber State */
#define cmUnpkMaGrpKeyNmb   cmUnpkTknStrS  /* Group Key Number    */
#define cmUnpkMaPri         cmUnpkTknStrS  /* Priority            */
#define cmUnpkMaUpLnkFree   cmUnpkTknU8    /* Uplink free */
#define cmUnpkMaUpLnkReq    cmUnpkTknU8    /* Uplink Request */
#define cmUnpkMaUpLnkRlsInd cmUnpkTknU8  /* Uplink Release Indication */
#define cmUnpkMaRlsGrpCall  cmUnpkTknU8  /* Release Group Call */
#define cmUnpkMaUpLnkReqAck cmUnpkTknU8  /* Uplink Request Ack */
#define cmUnpkMaUpLnkRejCmd   cmUnpkTknU8 /* Uplink Reject Command     */
#define cmUnpkMaUpLnkSzeCmd   cmUnpkTknU8 /* Uplink Seize Command      */
#define cmUnpkMaUpLnkRlsCmd   cmUnpkTknU8 /* Uplink Rls command        */
#define cmUnpkMaMblNotRchRsn  cmUnpkTknStrS /* Mobile Not Reach Reason */
#define cmUnpkMaCanType  cmUnpkTknU8      /* Cancellation type enumeration */
#define cmUnpkMaInterroType  cmUnpkTknU8  /* Interrogation Type */
#define cmUnpkMaFwdReason    cmUnpkTknU8  /* Forwarding Reason  */
#define cmUnpkMaOrPhase      cmUnpkTknStrS  /* OR-Phase */
#define cmUnpkMaCcbsCall     cmUnpkTknU8    /* CCBS Call */
#define cmUnpkMaSupCcbsPhase cmUnpkTknStrS  /* Supported CCBS Phase  */
#define cmUnpkMaMwdSet       cmUnpkTknU8    /* Mwd Set */
#define cmUnpkMaCcbsPsbl     cmUnpkTknU8    /* ccbs - possible */

#define cmUnpkMaExtCont      cmUnpkMaExtContSeq
#define cmUnpkMaODBGenData   cmUnpkTknStrE   /* ODB General Data */
#define cmUnpkMaODBHPLMNData cmUnpkTknStrE /* ODB HPLMN Data */
#define cmUnpkMaServInd      cmUnpkTknStrE  /* Service Indicator */
#ifdef XWEXT
 #define cmUnpkMaPriExtLst    cmUnpkTknStr4  /* Private Extension List */
#else
#define cmUnpkMaPriExtLst    cmUnpkTknStrE  /* Private Extension List */
#endif

#define cmUnpkMaSSEvtSpec    cmUnpkTknStrS  /* SS Event Spec  */
#define cmUnpkMaSerKey       cmUnpkTknStrS  /* Service Key   */
#define cmUnpkMaTransBNmb    cmUnpkTknStrS  /* Translated B Number */
#define cmUnpkMaAgeOfLocInfo cmUnpkTknStrS  /* Age of Location 
                                               Information */
#define cmUnpkMaIMEI         cmUnpkTknStrS  /* International Mobile 
                                               Equp Number */
#define cmUnpkMaIMSI         cmUnpkTknStrS  /* International MSI */
#define cmUnpkMaSgsnAddr     cmUnpkTknStrS  /* Sgsn Address      */
#define cmUnpkMaLMSI         cmUnpkTknStrS  /* Local MSI */ 
#define cmUnpkMaTMSI         cmUnpkTknStrS  /* Temporay MSI */ 
#define cmUnpkMaVlrNmb       cmUnpkTknStrS  /* VLR Number */
#define cmUnpkMaHlrNmb       cmUnpkTknStrS  /* HLR Number */
#define cmUnpkMaMscNmb       cmUnpkTknStrS  /* MSC Number */
#define cmUnpkMaHlrId        cmUnpkTknStrS  /* HLR Id */
#define cmUnpkMaMsISDN       cmUnpkTknStrS  /* MS ISDN Number */
#define cmUnpkMaRoamNmb      cmUnpkTknStrS  /* MS Roaming Number */
#define cmUnpkMaDialNmb      cmUnpkTknStrS  /* MS Dialled Number */
#define cmUnpkMaCellId       cmUnpkTknStrS  /* Global cell Id */
#define cmUnpkMaHoNmb        cmUnpkTknStrS  /* Handover number */
#define cmUnpkMaChanType     cmUnpkTknStrS  /* Channel type */
#define cmUnpkMaClassMarkInfo cmUnpkTknStrS /* class mark info */
#define cmUnpkMaAuthRand     cmUnpkTknStrS  /* Rand. nmb. used for 
                                               Authentication */
#define cmUnpkMaAuthSRes     cmUnpkTknStrS  /* Authentication Set 
                                               response */
#define cmUnpkMaAuthKey      cmUnpkTknStrS  /* Auth. key used for
                                               ciphering */
#define cmUnpkMaTrType       cmUnpkTknStrS  /* Trace type */
#define cmUnpkMaTrRef        cmUnpkTknStrS  /* Trace reference */
#define cmUnpkMaOMCId        cmUnpkTknStrS  /* OMS Id */
#define cmUnpkMaCallRef      cmUnpkTknStrS  /* Call Reference */
#define cmUnpkMaNmbOfFwd     cmUnpkTknStrS
#define cmUnpkMaFwdToNmb     cmUnpkTknStrS  /* Forward to Number */
#define cmUnpkMaFwdToSubAddr cmUnpkTknStrS  /* Forward to SubAddress */
#define cmUnpkMaCugInd       cmUnpkTknStrS  /* CUG Index */
#define cmUnpkMaCugIntLock   cmUnpkTknStrS  /* CUG Inter lock */
#define cmUnpkMaCugOpt       cmUnpkTknU8
#define cmUnpkMaCugFacilities  cmUnpkTknU8
#define cmUnpkMaNoRplyCondTime cmUnpkTknStrS/* No reply codition time */
#define cmUnpkMaPasswd       cmUnpkTknStrS  /* Password */
#define cmUnpkMaGuidInfo     cmUnpkTknU8    /* Guidance Info */
#define cmUnpkMaSmRpMti      cmUnpkTknStrS  /* SM RP MTI */
#define cmUnpkMaSmRpSmea     cmUnpkTknStrS  /* SM RP SMEA */
#define cmUnpkMaMWDStat      cmUnpkTknStrS  /* MWD Status */
#define cmUnpkMaZoneCode     cmUnpkTknStrS  /* Zone code */
#define cmUnpkMaSCAddr       cmUnpkTknStrS  /* SC Address */
#define cmUnpkMaKi           cmUnpkTknStrS  /* Key */
#define cmUnpkMaDefPri       cmUnpkTknStrS  /* Default Priority */
#define cmUnpkMaSupCamPhase  cmUnpkTknStrS  /* Supported Camel Phases */
#define cmUnpkMaVmscAddr     cmUnpkTknStrS  /* Vmsc Addr */
#define cmUnpkMaGeogInfo     cmUnpkTknStrS  /* Geographical 
                                               Information */
#define cmUnpkMaLocNmb       cmUnpkTknStrS  /* Location Number */
#define cmUnpkMaCellIdFixLen cmUnpkTknStrS  /* Cell Id Fixed Length */
#define cmUnpkMaLaiFixLen    cmUnpkTknStrS  /* lai Fixed Length */
#define cmUnpkMaGmscAddr     cmUnpkTknStrS  /* GMSC Addr */
#define cmUnpkMaCallRefNmb   cmUnpkTknStrS  /* Call Reference Number */
#define cmUnpkMaNwNodeNmb    cmUnpkTknStrS  /* Network Node Number */
#define cmUnpkMaGroupId      cmUnpkTknStrS  /* Group Identifier */
#define cmUnpkMaGsmScfAddr   cmUnpkTknStrS  /* GSM SCF Address  */
#define cmUnpkMaDstNmbLstElmnt cmUnpkTknStrS /* Destination Number LIs*/
#define cmUnpkMaNaeaPrefCIC  cmUnpkTknStrS  /* Naea Preferred CIC */
#define cmUnpkMaPdpType      cmUnpkTknStrS  /* Pdp Type */
#define cmUnpkMaPdpAddr      cmUnpkTknStrS  /* Pdp Address */
#define cmUnpkMaQosSubs      cmUnpkTknStrS  /* qos subscribed */
#define cmUnpkMaBSubsAddr    cmUnpkTknStrS  /* B- Subscriber Address */ 
#define cmUnpkMaSIWFSNmb     cmUnpkTknStrS  /* SIWFS Number */ 
#define cmUnpkMaAsciCallRef  cmUnpkTknStrS  /* Asci Call Reference */
#define cmUnpkMaCodecInfo    cmUnpkTknStrS  /* Codec Information   */
#define cmUnpkMaCipherAlgo   cmUnpkTknU8    /* Ciphering Algorithm */
#define cmUnpkMaSgsnNmb      cmUnpkTknStrS  /* SGSN Number */
#define cmUnpkMaGgsnNmb      cmUnpkTknStrS  /* GGSN Number */
#define cmUnpkMaGgsnAddr     cmUnpkTknStrS  /* SGSN Address */
#define cmUnpkMaGrpCallNmb   cmUnpkTknStrS  /* Group Call Number   */
#define cmUnpkMaGrpKey       cmUnpkTknStrS  /* Group Key     */
#define cmUnpkMaCcbsIndex    cmUnpkTknStrS  /* CCBS Index  */
#define cmUnpkMaBSubsNmb     cmUnpkTknStrS   /* B-Subscriber Number */
#define cmUnpkMaBSubsSubAddr cmUnpkTknStrS  /* B-Subscriber Number */
#define cmUnpkMaNetNodeNmb   cmUnpkTknStrS  /* Network Node Number */
#define cmUnpkMaExtBearServ  cmUnpkTknStrS  /* extended bearerservice */
#define cmUnpkMaExtTeleServ  cmUnpkTknStrS  /* extended tele service  */
#define cmUnpkMaContextId    cmUnpkTknStrS  /* Context Identifier */
#define cmUnpkMaUssdStr      cmUnpkTknStrE  /* ussd String */
#define cmUnpkMaApn          cmUnpkTknStrE  /* ussd String */
#define cmUnpkMaSSUsrDat     cmUnpkTknStrE  /* SS User data */
#define cmUnpkMaSMRPUI       cmUnpkTknStrE  /* SM RP UI */
#define cmUnpkMaExtSSStatus  cmUnpkTknStrS  /* Ext. SS Status */
#define cmUnpkMaExtFwdOpt    cmUnpkTknStrS  /* Forwarding options(ext.*/
#define cmUnpkMaExtNoRplyCondTime cmUnpkTknStrS  /* No reply codition 
                                                  time(ext.) */
#define cmUnpkMaCamCapHanl  cmUnpkTknStrS   /* Camel Capability 
                                                  Handling */

#ifdef MAP_PHASE2_EXT_MARK
#define cmUnpkMaExtMark            cmUnpkTknStrE  /* Extension Marker */
#endif

#if (MAP_REL98 || MAP_REL99)
#define cmUnpkMaSolsaSupInd      cmUnpkTknU8 /* Solsa Support indicator */
#define cmUnpkMaLsaIdentity      cmUnpkTknStrS   /* LSA Identifier */
#define cmUnpkMaLsaActvModeSupInd  cmUnpkTknU8   /*  LSA act mode Sup Ind. */
#define cmUnpkMaLsaAttributes    cmUnpkTknU8     /* LSA Attributes */
#define cmUnpkMaGmlcListWithdraw cmUnpkTknU8     /* Gmlc list withdraw */
#define cmUnpkMaLmuInd         cmUnpkTknU8 /* LMU Indicator */
#define cmUnpkMaCompletDataListIncl cmUnpkTknU8  /* Complete Data List Included */
#define cmUnpkMaLsaOnlyAccessInd cmUnpkTknU8    /* LSA Only Access Indicator */
#define cmUnpkMaLsaActvModeInd   cmUnpkTknU8     /*  LSA act mode Ind. */
#define cmUnpkMaGmlcList         cmUnpkTknStrS   /* GMLC List */
#define cmUnpkMaExtAddr          cmUnpkTknStrS    /* Extension Address */
#define cmUnpkMaGmlcRest         cmUnpkTknU8     /* GMLC Restrictions */
#define cmUnpkMaNotifToMsUsr     cmUnpkTknU8     /* Notification to MS User*/
#define cmUnpkMaLcsClientIntId   cmUnpkTknU8     /* PLMN Client List */
#define cmUnpkMaOrNotSupInGmsc   cmUnpkTknU8     /* Or Not support In GMSC */

#define cmUnpkMaMlcNmb           cmUnpkTknStrS   /* MLC Number */
#define cmUnpkMaExtAddr          cmUnpkTknStrS   /* Ext address */
#define cmUnpkMaLcsClientDiaByMs cmUnpkTknStrS   /* LCS client dialed by MS */
#define cmUnpkMaLcsClientIntId   cmUnpkTknU8     /* LCS client internal Id */
#define cmUnpkMaUssdDatCodSch    cmUnpkTknU8     /* data coding scheme */
#define cmUnpkMaUssdStr          cmUnpkTknStrE   /* LCS client name string */
#define cmUnpkMaLcsPriority      cmUnpkTknU8     /* LCS priority */
#define cmUnpkMaHoriAccuracy     cmUnpkTknU8     /* Horizontal accuracy */
#define cmUnpkMaVertAccuracy     cmUnpkTknU8     /* Vertical accuracy */
#define cmUnpkMaExtGeogInfo      cmUnpkTknStrS   /* Location estimate */
#define cmUnpkMaNaEsrd           cmUnpkTknStrS   /* NA-ESRD */
#define cmUnpkMaNaEsrk           cmUnpkTknStrS   /* NA-ESRk */
#define cmUnpkMaNmbPortStatus    cmUnpkTknU8     /* Number portability status */
#define cmUnpkMaAllInfoSent      cmUnpkTknU8     /* All Information Sent */
#define cmUnpkMaTifCsi           cmUnpkTknU8     /* tif-CSI */
#define cmUnpkMaUuInd            cmUnpkTknU8     /* UU indicator */
#define cmUnpkMaUui              cmUnpkTknStrE   
#define cmUnpkMaUusCFInter       cmUnpkTknU8     /* UUS CF interaction */
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99
#define cmUnpkMaFailureCause     cmUnpkTknU8     /* Failure Cause */
#define cmUnpkMaSendSubsData     cmUnpkTknU8     /* Send Subscriber data */
#define cmUnpkMaSubsDataStored   cmUnpkTknStrS   /* Subscriber data stored */
#define cmUnpkMaGprsEnhSupInd    cmUnpkTknU8     /* Gprs Enh. Support Ind */

#define cmUnpkMaIstAlertTmr      cmUnpkTknStrS   /* IST Alert Timer */
#define cmUnpkMaSuperChargerSuppInHlr cmUnpkTknStrS /* Super Charg Supp In HLR */
#define cmUnpkMaMaxMcBear        cmUnpkTknStrS   /* Nbr Sb  */
#define cmUnpkMaMcBear           cmUnpkTknStrS   /* Nbr Usr */
#define cmUnpkMaCsAllocRetenPriority cmUnpkTknU8 /* CS-Alloc Reten priority */
#define cmUnpkMaGprsTrgDetPoint  cmUnpkTknU8     /* GPRS Trig. det. point */
#define cmUnpkMaDefGprsHand      cmUnpkTknU8     /* Default GPRS Handling */
#define cmUnpkMaNotificationToCse cmUnpkTknU8     /* Notifi. to CSE */
#define cmUnpkMaCsiActive        cmUnpkTknU8     /* CSI Active */
#define cmUnpkMaSmsTrgDetPoint   cmUnpkTknU8     /* SMS Triger det point */
#define cmUnpkMaSmsHandl         cmUnpkTknU8     /* SMS Handling */
#define cmUnpkMaChargingChar     cmUnpkTknStrS   /* Charging characteristics */
#define cmUnpkMaIstInfoWithdraw  cmUnpkTknU8     /* Ist Info. withdraw */
#define cmUnpkMaSpecCsiWithdraw  cmUnpkTknStrE   /* Specific CSI. withdraw */
#define cmUnpkMaNmbReqVectors    cmUnpkTknStrS   /* Number of Requested Vectors */
#define cmUnpkMaSegProhibited    cmUnpkTknU8     /* Segmentation Prohibited */
#define cmUnpkMaImmResPreferred  cmUnpkTknU8     /* Immediate response preferred */
#define cmUnpkMaAuthAuts         cmUnpkTknStrS   /* Auts */
#define cmUnpkMaAuthXres         cmUnpkTknStrS   /* Xres */
#define cmUnpkMaAuthCk           cmUnpkTknStrS   /* Ck */
#define cmUnpkMaAuthIk           cmUnpkTknStrS   /* Ik */
#define cmUnpkMaAuthAutn         cmUnpkTknStrS   /* Autn */
#define cmUnpkMaCauseValue       cmUnpkTknU8     /* O Cause Val Crit */
#define cmUnpkMaDialledNmb       cmUnpkTknStrS   /* Dialled Number */
#define cmUnpkMaPrePagingSup     cmUnpkTknU8     /* Pre-paging supported */
#define cmUnpkMaLongFtnSup       cmUnpkTknU8     /* Long FTN supported */
#define cmUnpkMaMmCode           cmUnpkTknU8     /* Event Met */

#define cmUnpkMaOdb              cmUnpkTknU8     /* Odb */
#define cmUnpkMaReqCamSubsInfo   cmUnpkTknU8     /* Requested CAMEL Subs Info */
#define cmUnpkMaSupVlrCamPhase   cmUnpkTknU8     /* Supported VLR-CAMEL Phase */
#define cmUnpkMaSupSgsnCamPhase  cmUnpkTknU8     /* Supported SGSN-CAMEL Phase*/
#define cmUnpkMaLongFwdedToNmb   cmUnpkTknStrS   /* Long forward to Number */
#define cmUnpkMaWngPwdAtmCntr    cmUnpkTknStrS   /* Wrong password attempts Counter */
#define cmUnpkMaModInstr         cmUnpkTknU8     /* Modification Instruction */
#define cmUnpkMaIstSupInd        cmUnpkTknU8     /* IST support indicator */
#define cmUnpkMaCKSN             cmUnpkTknU8     /* CKSN */
#define cmUnpkMaKsi              cmUnpkTknU8     /* KSI */
#define cmUnpkMaIntegProteInfo   cmUnpkTknStrE   /* Integrity protection Info*/
#define cmUnpkMaEncrInfo         cmUnpkTknStrE   /* Encryption Info */
#define cmUnpkMaKeyStatus        cmUnpkTknU8     /* Key status */
#define cmUnpkMaRNCId            cmUnpkTknStrS   /* RNC ID */
#define cmUnpkMaMultiBearReq     cmUnpkTknU8     /* Multiple Bearer Requested*/
#define cmUnpkMaRadioResInfo     cmUnpkTknStrS   /* Radio resource info. */ 
#define cmUnpkMaRabId            cmUnpkTknStrS   /* RAB ID */
#define cmUnpkMaMultiBearInfo    cmUnpkTknStrS   /* Multiple Bearer Info. */
#define cmUnpkMaMultiBearNotsup  cmUnpkTknU8     /* Multiple Bearer not Sup. */
#define cmUnpkMaDnLnkAtta        cmUnpkTknU8     /* Downlink attached */
#define cmUnpkMaUpLnkAtta        cmUnpkTknU8     /* Uplink attached */
#define cmUnpkMaDualCommu        cmUnpkTknU8     /* Dual communication */
#define cmUnpkMaCallOrig         cmUnpkTknU8     /* Call originator */
#define cmUnpkMaCurLoc           cmUnpkTknU8     /* Current location */
#define cmUnpkMaGeoDetInfo       cmUnpkTknStrS   /* Geodetic information */
#define cmUnpkMaCurLocRetr       cmUnpkTknU8     /* Current loc. retrieved */
#define cmUnpkMaSaiPres          cmUnpkTknU8     /* Sai present */
#define cmUnpkMaCallDivTreInd    cmUnpkTknU8     /* Call Diversion treatment ind */
/* Addition - New data type introduced for 3.9.0 rel_99 */
#define cmUnpkMaSeleGsmAlgo        cmUnpkTknU8   /* Selected GSM algorithms */
#define cmUnpkMaAlloGsmAlgo        cmUnpkTknU8   /* Allowed GSM algorithms */
#define cmUnpkMaChoIntegProteAlgo  cmUnpkTknU8   /* Chosen integ prote algo */
#define cmUnpkMaChoEncrAlgo        cmUnpkTknU8   /* Chosen Encryption algo */
#define cmUnpkMaChoChanInfo        cmUnpkTknStrS /* Chosen channel info */
#define cmUnpkMaChoSpeechVer       cmUnpkTknStrS /* Chosen speech version */
#define cmUnpkMaSupGADShape        cmUnpkTknStrS /* Supported GAD shapes */
#define cmUnpkMaPermIntegProteAlgo cmUnpkTknStrS /* Perm integ prote algo*/
#define cmUnpkMaPermEncrAlgo       cmUnpkTknStrS /* Perm Encryption algo */
#define cmUnpkMaAddGeogInfo        cmUnpkTknStrE /* Add Geographical Info */
#define cmUnpkMaBSSMAPServHo       cmUnpkTknU8   /* BSSMAP service handover */
#define cmUnpkMaRANAPServHo        cmUnpkTknU8   /* RANAP service handover */
#define cmUnpkMaExtQosSubs         cmUnpkTknStrS /* Ext QOS subscribed*/
#define cmUnpkMaExt2QosSubs        cmUnpkTknStrS /* Ext2 QOS subscribed*/
#define cmUnpkMaNaEsrkReq          cmUnpkTknU8   /* NA-ESRk */
#define cmUnpkMaSlrArgExtCont      cmUnpkMaSlrArgExtContSeq  /* Slr Arg Ext */

#if MAP_REL4
#define cmUnpkMaSuppLcsCapSets     cmUnpkTknStrS /* Supported LCS Capability sets */
#define cmUnpkMaDefLocEventType    cmUnpkTknStrS /* Deferred location event type */
#define cmUnpkMaCurrMscNum         cmUnpkTknStrS /* Current MSC number */
#define cmUnpkMaCurrSgsnNum        cmUnpkTknStrS /* Current SGSN number */
#define cmUnpkMaLCSRefNmb          cmUnpkTknU8   /* LCS reference number */
#if MAP_REL5
#define cmUnpkMaOffCam4CSIs        cmUnpkTknStrS /* Offered CAMEL 4 CSI */
#define cmUnpkMaCodec              cmUnpkTknStrS /* Codec */ 
#define cmUnpkMaGERANClassMark     cmUnpkTknStrE /* ussd String */
#define cmUnpkMaMtSmsTpduType      cmUnpkTknU8   /* MT SMS TPDU type */
#define cmUnpkMaLcsServTypeId      cmUnpkTknStrS /* LCS service type ID */
#define cmUnpkMaOffCam4funcs       cmUnpkTknStrE /* Offered CAM4 functionalities*/
#define cmUnpkMaDomainType         cmUnpkTknU8   /* Domain type */
#define cmUnpkMaRaIdentity         cmUnpkTknStrS /* RAI Identity */
#define cmUnpkMaNsApi              cmUnpkTknStrS /* NSAPI */
#define cmUnpkMaTEID               cmUnpkTknStrS /* tunnel endpoint identifier */
#define cmUnpkMaTransId            cmUnpkTknStrS /* Transaction ID */
#define cmUnpkMaGprsChargId        cmUnpkTknStrS /* GPRS charging ID */
#define cmUnpkMaMsClassMark2       cmUnpkTknStrS /* MS class mark 2 */
#define cmUnpkMaMsNetCap           cmUnpkTknStrS /* MS network capability */
#define cmUnpkMaMsRadioAccCap      cmUnpkTknStrE /* MS radio access capability */
#define cmUnpkMaAddReqCamSubsInfo  cmUnpkTknU8   /* Additional requested CAMEL */
#define cmUnpkMaUESBIIuA          cmUnpkTknStrE /* UESBI */
#define cmUnpkMaUESBIIuB          cmUnpkTknStrE /* UESBI */
#define cmUnpkMaRoutNmb           cmUnpkTknStrS /* Routeing Number */
#define cmUnpkMaUnavailCause      cmUnpkTknU8    /* Unavailable Cause */
#define cmUnpkMaAllowedServ       cmUnpkTknStrS /* Allowed Services */
#define cmUnpkMaPosiDatInfo       cmUnpkTknStrS /* Positioning Data info */
#define cmUnpkMaReqEqpInfo        cmUnpkTknStrS /* Request equipment info */
#define cmUnpkMaUtrPosiDatInfo    cmUnpkTknStrS /* Utran Positioning Data info */
#define cmUnpkMaNaEsrkReq         cmUnpkTknU8   /* NA-ESRk */

/* Addition: upgrade for MAP release 6 */
#if MAP_REL6
#define cmUnpkMaFormatIndc         cmUnpkTknU8   /* LCS Format Indicator */
#define cmUnpkMaVgmlcAddr          cmUnpkTknStrS /* v-gmlc address */
#define cmUnpkMaImeiSv             cmUnpkTknStrS /* IMEI Software Version Number */
#define cmUnpkMaSsdUp              cmUnpkTknU8   /* Sub Scriber Data Update */
#define cmUnpkMaHgmlcAddr          cmUnpkTknStrS /* h-gmlc address */
#define cmUnpkMaPprAddr            cmUnpkTknStrS /* ppr address */
#define cmUnpkMaAvgmlcAddr         cmUnpkTknStrS /* Additional v-gmlc address */
#define cmUnpkMaSmsCbsi            cmUnpkTknU8   /* SMS Call Barring Support
  Indicator */
#define cmUnpkMaPrivChkRelAct      cmUnpkTknU8    /* Privacy Check Rleated Action */
#define cmUnpkMaOccrInfo           cmUnpkTknU8   /* Occurance Info */
#define cmUnpkMaIntrValTime        cmUnpkTknStrS  /* Interval Time */
#define cmUnpkMaAreaType           cmUnpkTknU8   /* Area Type */
#define cmUnpkMaAreaId            cmUnpkTknStrS /* Area Identification */
#define cmUnpkMaAddNetRsrs         cmUnpkTknU8   /* Additional Network Resource */
#define cmUnpkMaReqPlmnId          cmUnpkTknStrS /* Requested PLMN id */
#define cmUnpkMaAccRestData        cmUnpkTknStrS /* Access Restriction Data */
#define cmUnpkMaAddCap             cmUnpkTknU8   /* Additional capability */
#define cmUnpkMaRelResSup          cmUnpkTknU8  /* Release Resources supported
  */
#define cmUnpkMaVstkRand           cmUnpkTknStrS /* Vstk Rand */ 
#define cmUnpkMaVstk               cmUnpkTknStrS /* Vstk */
#endif /* MAP_REL6 */  
#endif /* MAP_REL5 */
#endif /* MAP_REL4 */
/* mat_h_001.main_13 : Addition: Additional elmnts */
#ifdef MAP_CH_PLUS
#define cmUnpkMaRedirLrn        cmUnpkTknStrS  /* Redir LRN */
#define cmUnpkMaCallingLrn      cmUnpkTknStrS  /* Calling LRN */
#define cmUnpkMaClgOrRedirDn    cmUnpkTknStrS  /* Calling/Redir DN */
#define cmUnpkMaCalledLrn       cmUnpkTknStrS  /* Called LRN */
#define cmUnpkMaCallingDn       cmUnpkTknStrS  /* Calling DN */
#define cmUnpkMaFlgForSpl       cmUnpkTknU8    /* Flag for Special */
#define cmUnpkMaOperationType   cmUnpkTknU8    /* Operation Type */
#endif
#endif /* MAP_REL99 */

/* MACROS */

#define MAT_CHK_FOR_NULLP(ptr, mBuf) \
{\
   if ((ptr) == NULLP)\
   {\
      SPutMsg(mBuf); \
      RETVALUE (RFAILED); \
   }\
}

/* error codes */
#define   ERRMAT       0

#define   EMAT001      (ERRMAT +    1)    /*        mat.c:28225 */
#define   EMAT002      (ERRMAT +    2)    /*        mat.c:28226 */
#define   EMAT003      (ERRMAT +    3)    /*        mat.c:28227 */
#define   EMAT004      (ERRMAT +    4)    /*        mat.c:28228 */
#define   EMAT005      (ERRMAT +    5)    /*        mat.c:28277 */
#define   EMAT006      (ERRMAT +    6)    /*        mat.c:28278 */
#define   EMAT007      (ERRMAT +    7)    /*        mat.c:28279 */
#define   EMAT008      (ERRMAT +    8)    /*        mat.c:28280 */
#define   EMAT009      (ERRMAT +    9)    /*        mat.c:28328 */
#define   EMAT010      (ERRMAT +   10)    /*        mat.c:28329 */
#define   EMAT011      (ERRMAT +   11)    /*        mat.c:28330 */
#define   EMAT012      (ERRMAT +   12)    /*        mat.c:28331 */
#define   EMAT013      (ERRMAT +   13)    /*        mat.c:28378 */
#define   EMAT014      (ERRMAT +   14)    /*        mat.c:28379 */
#define   EMAT015      (ERRMAT +   15)    /*        mat.c:28380 */
#define   EMAT016      (ERRMAT +   16)    /*        mat.c:28428 */
#define   EMAT017      (ERRMAT +   17)    /*        mat.c:28429 */
#define   EMAT018      (ERRMAT +   18)    /*        mat.c:28430 */
#define   EMAT019      (ERRMAT +   19)    /*        mat.c:28431 */
#define   EMAT020      (ERRMAT +   20)    /*        mat.c:28480 */
#define   EMAT021      (ERRMAT +   21)    /*        mat.c:28481 */
#define   EMAT022      (ERRMAT +   22)    /*        mat.c:28482 */
#define   EMAT023      (ERRMAT +   23)    /*        mat.c:28483 */
#define   EMAT024      (ERRMAT +   24)    /*        mat.c:28530 */
#define   EMAT025      (ERRMAT +   25)    /*        mat.c:28531 */
#define   EMAT026      (ERRMAT +   26)    /*        mat.c:28532 */
#define   EMAT027      (ERRMAT +   27)    /*        mat.c:28584 */
#define   EMAT028      (ERRMAT +   28)    /*        mat.c:28585 */
#define   EMAT029      (ERRMAT +   29)    /*        mat.c:28586 */
#define   EMAT030      (ERRMAT +   30)    /*        mat.c:28587 */
#define   EMAT031      (ERRMAT +   31)    /*        mat.c:28588 */
#define   EMAT032      (ERRMAT +   32)    /*        mat.c:28659 */
#define   EMAT033      (ERRMAT +   33)    /*        mat.c:28660 */
#define   EMAT034      (ERRMAT +   34)    /*        mat.c:28668 */
#define   EMAT035      (ERRMAT +   35)    /*        mat.c:28669 */
#define   EMAT036      (ERRMAT +   36)    /*        mat.c:28740 */
#define   EMAT037      (ERRMAT +   37)    /*        mat.c:28741 */
#define   EMAT038      (ERRMAT +   38)    /*        mat.c:28749 */
#define   EMAT039      (ERRMAT +   39)    /*        mat.c:28750 */
#define   EMAT040      (ERRMAT +   40)    /*        mat.c:28800 */
#define   EMAT041      (ERRMAT +   41)    /*        mat.c:28801 */
#define   EMAT042      (ERRMAT +   42)    /*        mat.c:28844 */
#define   EMAT043      (ERRMAT +   43)    /*        mat.c:28845 */
#define   EMAT044      (ERRMAT +   44)    /*        mat.c:28894 */
#define   EMAT045      (ERRMAT +   45)    /*        mat.c:28895 */
#define   EMAT046      (ERRMAT +   46)    /*        mat.c:28896 */
#define   EMAT047      (ERRMAT +   47)    /*        mat.c:28897 */
#define   EMAT048      (ERRMAT +   48)    /*        mat.c:28946 */
#define   EMAT049      (ERRMAT +   49)    /*        mat.c:28947 */
#define   EMAT050      (ERRMAT +   50)    /*        mat.c:28948 */
#define   EMAT051      (ERRMAT +   51)    /*        mat.c:28949 */
#define   EMAT052      (ERRMAT +   52)    /*        mat.c:28997 */
#define   EMAT053      (ERRMAT +   53)    /*        mat.c:28998 */
#define   EMAT054      (ERRMAT +   54)    /*        mat.c:28999 */
#define   EMAT055      (ERRMAT +   55)    /*        mat.c:29000 */
#define   EMAT056      (ERRMAT +   56)    /*        mat.c:29074 */
#define   EMAT057      (ERRMAT +   57)    /*        mat.c:29083 */
#define   EMAT058      (ERRMAT +   58)    /*        mat.c:29092 */
#define   EMAT059      (ERRMAT +   59)    /*        mat.c:29093 */
#define   EMAT060      (ERRMAT +   60)    /*        mat.c:29094 */
#define   EMAT061      (ERRMAT +   61)    /*        mat.c:29142 */
#define   EMAT062      (ERRMAT +   62)    /*        mat.c:29143 */
#define   EMAT063      (ERRMAT +   63)    /*        mat.c:29144 */
#define   EMAT064      (ERRMAT +   64)    /*        mat.c:29145 */
#define   EMAT065      (ERRMAT +   65)    /*        mat.c:29189 */
#define   EMAT066      (ERRMAT +   66)    /*        mat.c:29190 */
#define   EMAT067      (ERRMAT +   67)    /*        mat.c:29233 */
#define   EMAT068      (ERRMAT +   68)    /*        mat.c:29234 */
#define   EMAT069      (ERRMAT +   69)    /*        mat.c:29310 */
#define   EMAT070      (ERRMAT +   70)    /*        mat.c:29322 */
#define   EMAT071      (ERRMAT +   71)    /*        mat.c:29332 */
#define   EMAT072      (ERRMAT +   72)    /*        mat.c:29333 */
#define   EMAT073      (ERRMAT +   73)    /*        mat.c:29334 */
#define   EMAT074      (ERRMAT +   74)    /*        mat.c:29335 */
#define   EMAT075      (ERRMAT +   75)    /*        mat.c:29336 */
#define   EMAT076      (ERRMAT +   76)    /*        mat.c:29404 */
#define   EMAT077      (ERRMAT +   77)    /*        mat.c:29414 */
#define   EMAT078      (ERRMAT +   78)    /*        mat.c:29421 */
#define   EMAT079      (ERRMAT +   79)    /*        mat.c:29422 */
#define   EMAT080      (ERRMAT +   80)    /*        mat.c:29423 */
#define   EMAT081      (ERRMAT +   81)    /*        mat.c:29424 */
#define   EMAT082      (ERRMAT +   82)    /*        mat.c:29425 */
#define   EMAT083      (ERRMAT +   83)    /*        mat.c:29426 */
#define   EMAT084      (ERRMAT +   84)    /*        mat.c:29427 */
#define   EMAT085      (ERRMAT +   85)    /*        mat.c:29491 */
#define   EMAT086      (ERRMAT +   86)    /*        mat.c:29503 */
#define   EMAT087      (ERRMAT +   87)    /*        mat.c:29513 */
#define   EMAT088      (ERRMAT +   88)    /*        mat.c:29514 */
#define   EMAT089      (ERRMAT +   89)    /*        mat.c:29515 */
#define   EMAT090      (ERRMAT +   90)    /*        mat.c:29516 */
#define   EMAT091      (ERRMAT +   91)    /*        mat.c:29517 */
#define   EMAT092      (ERRMAT +   92)    /*        mat.c:29584 */
#define   EMAT093      (ERRMAT +   93)    /*        mat.c:29596 */
#define   EMAT094      (ERRMAT +   94)    /*        mat.c:29606 */
#define   EMAT095      (ERRMAT +   95)    /*        mat.c:29607 */
#define   EMAT096      (ERRMAT +   96)    /*        mat.c:29608 */
#define   EMAT097      (ERRMAT +   97)    /*        mat.c:29609 */
#define   EMAT098      (ERRMAT +   98)    /*        mat.c:29610 */
#define   EMAT099      (ERRMAT +   99)    /*        mat.c:29611 */
#define   EMAT100      (ERRMAT +  100)    /*        mat.c:29684 */
#define   EMAT101      (ERRMAT +  101)    /*        mat.c:29696 */
#define   EMAT102      (ERRMAT +  102)    /*        mat.c:29706 */
#define   EMAT103      (ERRMAT +  103)    /*        mat.c:29707 */
#define   EMAT104      (ERRMAT +  104)    /*        mat.c:29708 */
#define   EMAT105      (ERRMAT +  105)    /*        mat.c:29709 */
#define   EMAT106      (ERRMAT +  106)    /*        mat.c:29710 */
#define   EMAT107      (ERRMAT +  107)    /*        mat.c:29777 */
#define   EMAT108      (ERRMAT +  108)    /*        mat.c:29787 */
#define   EMAT109      (ERRMAT +  109)    /*        mat.c:29796 */
#define   EMAT110      (ERRMAT +  110)    /*        mat.c:29797 */
#define   EMAT111      (ERRMAT +  111)    /*        mat.c:29798 */
#define   EMAT112      (ERRMAT +  112)    /*        mat.c:29799 */
#define   EMAT113      (ERRMAT +  113)    /*        mat.c:29800 */
#define   EMAT114      (ERRMAT +  114)    /*        mat.c:29801 */
#define   EMAT115      (ERRMAT +  115)    /*        mat.c:29802 */
#define   EMAT116      (ERRMAT +  116)    /*        mat.c:29869 */
#define   EMAT117      (ERRMAT +  117)    /*        mat.c:29881 */
#define   EMAT118      (ERRMAT +  118)    /*        mat.c:29891 */
#define   EMAT119      (ERRMAT +  119)    /*        mat.c:29892 */
#define   EMAT120      (ERRMAT +  120)    /*        mat.c:29893 */
#define   EMAT121      (ERRMAT +  121)    /*        mat.c:29894 */
#define   EMAT122      (ERRMAT +  122)    /*        mat.c:29895 */
#define   EMAT123      (ERRMAT +  123)    /*        mat.c:29960 */
#define   EMAT124      (ERRMAT +  124)    /*        mat.c:29972 */
#define   EMAT125      (ERRMAT +  125)    /*        mat.c:29982 */
#define   EMAT126      (ERRMAT +  126)    /*        mat.c:29983 */
#define   EMAT127      (ERRMAT +  127)    /*        mat.c:29984 */
#define   EMAT128      (ERRMAT +  128)    /*        mat.c:29985 */
#define   EMAT129      (ERRMAT +  129)    /*        mat.c:29986 */
#define   EMAT130      (ERRMAT +  130)    /*        mat.c:29987 */
#define   EMAT131      (ERRMAT +  131)    /*        mat.c:30061 */
#define   EMAT132      (ERRMAT +  132)    /*        mat.c:30073 */
#define   EMAT133      (ERRMAT +  133)    /*        mat.c:30083 */
#define   EMAT134      (ERRMAT +  134)    /*        mat.c:30084 */
#define   EMAT135      (ERRMAT +  135)    /*        mat.c:30085 */
#define   EMAT136      (ERRMAT +  136)    /*        mat.c:30086 */
#define   EMAT137      (ERRMAT +  137)    /*        mat.c:30087 */
#define   EMAT138      (ERRMAT +  138)    /*        mat.c:30156 */
#define   EMAT139      (ERRMAT +  139)    /*        mat.c:30166 */
#define   EMAT140      (ERRMAT +  140)    /*        mat.c:30174 */
#define   EMAT141      (ERRMAT +  141)    /*        mat.c:30175 */
#define   EMAT142      (ERRMAT +  142)    /*        mat.c:30176 */
#define   EMAT143      (ERRMAT +  143)    /*        mat.c:30177 */
#define   EMAT144      (ERRMAT +  144)    /*        mat.c:30178 */
#define   EMAT145      (ERRMAT +  145)    /*        mat.c:30179 */
#define   EMAT146      (ERRMAT +  146)    /*        mat.c:30180 */
#define   EMAT147      (ERRMAT +  147)    /*        mat.c:30250 */
#define   EMAT148      (ERRMAT +  148)    /*        mat.c:30262 */
#define   EMAT149      (ERRMAT +  149)    /*        mat.c:30271 */
#define   EMAT150      (ERRMAT +  150)    /*        mat.c:30272 */
#define   EMAT151      (ERRMAT +  151)    /*        mat.c:30273 */
#define   EMAT152      (ERRMAT +  152)    /*        mat.c:30274 */
#define   EMAT153      (ERRMAT +  153)    /*        mat.c:30275 */
#define   EMAT154      (ERRMAT +  154)    /*        mat.c:30342 */
#define   EMAT155      (ERRMAT +  155)    /*        mat.c:30354 */
#define   EMAT156      (ERRMAT +  156)    /*        mat.c:30363 */
#define   EMAT157      (ERRMAT +  157)    /*        mat.c:30364 */
#define   EMAT158      (ERRMAT +  158)    /*        mat.c:30365 */
#define   EMAT159      (ERRMAT +  159)    /*        mat.c:30366 */
#define   EMAT160      (ERRMAT +  160)    /*        mat.c:30367 */
#define   EMAT161      (ERRMAT +  161)    /*        mat.c:30368 */
#define   EMAT162      (ERRMAT +  162)    /*        mat.c:30441 */
#define   EMAT163      (ERRMAT +  163)    /*        mat.c:30453 */
#define   EMAT164      (ERRMAT +  164)    /*        mat.c:30463 */
#define   EMAT165      (ERRMAT +  165)    /*        mat.c:30464 */
#define   EMAT166      (ERRMAT +  166)    /*        mat.c:30465 */
#define   EMAT167      (ERRMAT +  167)    /*        mat.c:30466 */
#define   EMAT168      (ERRMAT +  168)    /*        mat.c:30467 */
#define   EMAT169      (ERRMAT +  169)    /*        mat.c:30537 */
#define   EMAT170      (ERRMAT +  170)    /*        mat.c:30547 */
#define   EMAT171      (ERRMAT +  171)    /*        mat.c:30556 */
#define   EMAT172      (ERRMAT +  172)    /*        mat.c:30557 */
#define   EMAT173      (ERRMAT +  173)    /*        mat.c:30558 */
#define   EMAT174      (ERRMAT +  174)    /*        mat.c:30559 */
#define   EMAT175      (ERRMAT +  175)    /*        mat.c:30560 */
#define   EMAT176      (ERRMAT +  176)    /*        mat.c:30561 */
#define   EMAT177      (ERRMAT +  177)    /*        mat.c:30562 */
#define   EMAT178      (ERRMAT +  178)    /*        mat.c:30631 */
#define   EMAT179      (ERRMAT +  179)    /*        mat.c:30643 */
#define   EMAT180      (ERRMAT +  180)    /*        mat.c:30653 */
#define   EMAT181      (ERRMAT +  181)    /*        mat.c:30654 */
#define   EMAT182      (ERRMAT +  182)    /*        mat.c:30655 */
#define   EMAT183      (ERRMAT +  183)    /*        mat.c:30656 */
#define   EMAT184      (ERRMAT +  184)    /*        mat.c:30657 */
#define   EMAT185      (ERRMAT +  185)    /*        mat.c:30725 */
#define   EMAT186      (ERRMAT +  186)    /*        mat.c:30737 */
#define   EMAT187      (ERRMAT +  187)    /*        mat.c:30747 */
#define   EMAT188      (ERRMAT +  188)    /*        mat.c:30748 */
#define   EMAT189      (ERRMAT +  189)    /*        mat.c:30749 */
#define   EMAT190      (ERRMAT +  190)    /*        mat.c:30750 */
#define   EMAT191      (ERRMAT +  191)    /*        mat.c:30751 */
#define   EMAT192      (ERRMAT +  192)    /*        mat.c:30752 */
#define   EMAT193      (ERRMAT +  193)    /*        mat.c:30826 */
#define   EMAT194      (ERRMAT +  194)    /*        mat.c:30838 */
#define   EMAT195      (ERRMAT +  195)    /*        mat.c:30848 */
#define   EMAT196      (ERRMAT +  196)    /*        mat.c:30849 */
#define   EMAT197      (ERRMAT +  197)    /*        mat.c:30850 */
#define   EMAT198      (ERRMAT +  198)    /*        mat.c:30851 */
#define   EMAT199      (ERRMAT +  199)    /*        mat.c:30852 */
#define   EMAT200      (ERRMAT +  200)    /*        mat.c:30922 */
#define   EMAT201      (ERRMAT +  201)    /*        mat.c:30932 */
#define   EMAT202      (ERRMAT +  202)    /*        mat.c:30941 */
#define   EMAT203      (ERRMAT +  203)    /*        mat.c:30942 */
#define   EMAT204      (ERRMAT +  204)    /*        mat.c:30943 */
#define   EMAT205      (ERRMAT +  205)    /*        mat.c:30944 */
#define   EMAT206      (ERRMAT +  206)    /*        mat.c:30945 */
#define   EMAT207      (ERRMAT +  207)    /*        mat.c:30946 */
#define   EMAT208      (ERRMAT +  208)    /*        mat.c:30947 */
#define   EMAT209      (ERRMAT +  209)    /*        mat.c:31018 */
#define   EMAT210      (ERRMAT +  210)    /*        mat.c:31030 */
#define   EMAT211      (ERRMAT +  211)    /*        mat.c:31040 */
#define   EMAT212      (ERRMAT +  212)    /*        mat.c:31041 */
#define   EMAT213      (ERRMAT +  213)    /*        mat.c:31042 */
#define   EMAT214      (ERRMAT +  214)    /*        mat.c:31043 */
#define   EMAT215      (ERRMAT +  215)    /*        mat.c:31044 */
#define   EMAT216      (ERRMAT +  216)    /*        mat.c:31112 */
#define   EMAT217      (ERRMAT +  217)    /*        mat.c:31124 */
#define   EMAT218      (ERRMAT +  218)    /*        mat.c:31134 */
#define   EMAT219      (ERRMAT +  219)    /*        mat.c:31135 */
#define   EMAT220      (ERRMAT +  220)    /*        mat.c:31136 */
#define   EMAT221      (ERRMAT +  221)    /*        mat.c:31137 */
#define   EMAT222      (ERRMAT +  222)    /*        mat.c:31138 */
#define   EMAT223      (ERRMAT +  223)    /*        mat.c:31139 */
#define   EMAT224      (ERRMAT +  224)    /*        mat.c:31213 */
#define   EMAT225      (ERRMAT +  225)    /*        mat.c:31225 */
#define   EMAT226      (ERRMAT +  226)    /*        mat.c:31235 */
#define   EMAT227      (ERRMAT +  227)    /*        mat.c:31236 */
#define   EMAT228      (ERRMAT +  228)    /*        mat.c:31237 */
#define   EMAT229      (ERRMAT +  229)    /*        mat.c:31238 */
#define   EMAT230      (ERRMAT +  230)    /*        mat.c:31239 */
#define   EMAT231      (ERRMAT +  231)    /*        mat.c:31309 */
#define   EMAT232      (ERRMAT +  232)    /*        mat.c:31319 */
#define   EMAT233      (ERRMAT +  233)    /*        mat.c:31328 */
#define   EMAT234      (ERRMAT +  234)    /*        mat.c:31329 */
#define   EMAT235      (ERRMAT +  235)    /*        mat.c:31330 */
#define   EMAT236      (ERRMAT +  236)    /*        mat.c:31331 */
#define   EMAT237      (ERRMAT +  237)    /*        mat.c:31332 */
#define   EMAT238      (ERRMAT +  238)    /*        mat.c:31333 */
#define   EMAT239      (ERRMAT +  239)    /*        mat.c:31334 */
#define   EMAT240      (ERRMAT +  240)    /*        mat.c:31405 */
#define   EMAT241      (ERRMAT +  241)    /*        mat.c:31417 */
#define   EMAT242      (ERRMAT +  242)    /*        mat.c:31427 */
#define   EMAT243      (ERRMAT +  243)    /*        mat.c:31428 */
#define   EMAT244      (ERRMAT +  244)    /*        mat.c:31429 */
#define   EMAT245      (ERRMAT +  245)    /*        mat.c:31430 */
#define   EMAT246      (ERRMAT +  246)    /*        mat.c:31431 */
#define   EMAT247      (ERRMAT +  247)    /*        mat.c:31499 */
#define   EMAT248      (ERRMAT +  248)    /*        mat.c:31511 */
#define   EMAT249      (ERRMAT +  249)    /*        mat.c:31521 */
#define   EMAT250      (ERRMAT +  250)    /*        mat.c:31522 */
#define   EMAT251      (ERRMAT +  251)    /*        mat.c:31523 */
#define   EMAT252      (ERRMAT +  252)    /*        mat.c:31524 */
#define   EMAT253      (ERRMAT +  253)    /*        mat.c:31525 */
#define   EMAT254      (ERRMAT +  254)    /*        mat.c:31526 */
#define   EMAT255      (ERRMAT +  255)    /*        mat.c:31600 */
#define   EMAT256      (ERRMAT +  256)    /*        mat.c:31612 */
#define   EMAT257      (ERRMAT +  257)    /*        mat.c:31622 */
#define   EMAT258      (ERRMAT +  258)    /*        mat.c:31623 */
#define   EMAT259      (ERRMAT +  259)    /*        mat.c:31624 */
#define   EMAT260      (ERRMAT +  260)    /*        mat.c:31625 */
#define   EMAT261      (ERRMAT +  261)    /*        mat.c:31626 */
#define   EMAT262      (ERRMAT +  262)    /*        mat.c:31696 */
#define   EMAT263      (ERRMAT +  263)    /*        mat.c:31706 */
#define   EMAT264      (ERRMAT +  264)    /*        mat.c:31715 */
#define   EMAT265      (ERRMAT +  265)    /*        mat.c:31716 */
#define   EMAT266      (ERRMAT +  266)    /*        mat.c:31717 */
#define   EMAT267      (ERRMAT +  267)    /*        mat.c:31718 */
#define   EMAT268      (ERRMAT +  268)    /*        mat.c:31719 */
#define   EMAT269      (ERRMAT +  269)    /*        mat.c:31720 */
#define   EMAT270      (ERRMAT +  270)    /*        mat.c:31721 */
#define   EMAT271      (ERRMAT +  271)    /*        mat.c:31784 */
#define   EMAT272      (ERRMAT +  272)    /*        mat.c:31796 */
#define   EMAT273      (ERRMAT +  273)    /*        mat.c:31806 */
#define   EMAT274      (ERRMAT +  274)    /*        mat.c:31807 */
#define   EMAT275      (ERRMAT +  275)    /*        mat.c:31808 */
#define   EMAT276      (ERRMAT +  276)    /*        mat.c:31809 */
#define   EMAT277      (ERRMAT +  277)    /*        mat.c:31810 */
#define   EMAT278      (ERRMAT +  278)    /*        mat.c:31878 */
#define   EMAT279      (ERRMAT +  279)    /*        mat.c:31890 */
#define   EMAT280      (ERRMAT +  280)    /*        mat.c:31900 */
#define   EMAT281      (ERRMAT +  281)    /*        mat.c:31901 */
#define   EMAT282      (ERRMAT +  282)    /*        mat.c:31902 */
#define   EMAT283      (ERRMAT +  283)    /*        mat.c:31903 */
#define   EMAT284      (ERRMAT +  284)    /*        mat.c:31904 */
#define   EMAT285      (ERRMAT +  285)    /*        mat.c:31905 */
#define   EMAT286      (ERRMAT +  286)    /*        mat.c:31981 */
#define   EMAT287      (ERRMAT +  287)    /*        mat.c:31993 */
#define   EMAT288      (ERRMAT +  288)    /*        mat.c:32003 */
#define   EMAT289      (ERRMAT +  289)    /*        mat.c:32004 */
#define   EMAT290      (ERRMAT +  290)    /*        mat.c:32005 */
#define   EMAT291      (ERRMAT +  291)    /*        mat.c:32006 */
#define   EMAT292      (ERRMAT +  292)    /*        mat.c:32007 */
#define   EMAT293      (ERRMAT +  293)    /*        mat.c:32008 */
#define   EMAT294      (ERRMAT +  294)    /*        mat.c:32078 */
#define   EMAT295      (ERRMAT +  295)    /*        mat.c:32088 */
#define   EMAT296      (ERRMAT +  296)    /*        mat.c:32097 */
#define   EMAT297      (ERRMAT +  297)    /*        mat.c:32098 */
#define   EMAT298      (ERRMAT +  298)    /*        mat.c:32099 */
#define   EMAT299      (ERRMAT +  299)    /*        mat.c:32100 */
#define   EMAT300      (ERRMAT +  300)    /*        mat.c:32101 */
#define   EMAT301      (ERRMAT +  301)    /*        mat.c:32102 */
#define   EMAT302      (ERRMAT +  302)    /*        mat.c:32103 */
#define   EMAT303      (ERRMAT +  303)    /*        mat.c:32174 */
#define   EMAT304      (ERRMAT +  304)    /*        mat.c:32186 */
#define   EMAT305      (ERRMAT +  305)    /*        mat.c:32196 */
#define   EMAT306      (ERRMAT +  306)    /*        mat.c:32197 */
#define   EMAT307      (ERRMAT +  307)    /*        mat.c:32198 */
#define   EMAT308      (ERRMAT +  308)    /*        mat.c:32199 */
#define   EMAT309      (ERRMAT +  309)    /*        mat.c:32200 */
#define   EMAT310      (ERRMAT +  310)    /*        mat.c:32201 */
#define   EMAT311      (ERRMAT +  311)    /*        mat.c:32269 */
#define   EMAT312      (ERRMAT +  312)    /*        mat.c:32281 */
#define   EMAT313      (ERRMAT +  313)    /*        mat.c:32291 */
#define   EMAT314      (ERRMAT +  314)    /*        mat.c:32292 */
#define   EMAT315      (ERRMAT +  315)    /*        mat.c:32293 */
#define   EMAT316      (ERRMAT +  316)    /*        mat.c:32294 */
#define   EMAT317      (ERRMAT +  317)    /*        mat.c:32295 */
#define   EMAT318      (ERRMAT +  318)    /*        mat.c:32296 */
#define   EMAT319      (ERRMAT +  319)    /*        mat.c:32370 */
#define   EMAT320      (ERRMAT +  320)    /*        mat.c:32382 */
#define   EMAT321      (ERRMAT +  321)    /*        mat.c:32392 */
#define   EMAT322      (ERRMAT +  322)    /*        mat.c:32393 */
#define   EMAT323      (ERRMAT +  323)    /*        mat.c:32394 */
#define   EMAT324      (ERRMAT +  324)    /*        mat.c:32395 */
#define   EMAT325      (ERRMAT +  325)    /*        mat.c:32396 */
#define   EMAT326      (ERRMAT +  326)    /*        mat.c:32466 */
#define   EMAT327      (ERRMAT +  327)    /*        mat.c:32476 */
#define   EMAT328      (ERRMAT +  328)    /*        mat.c:32485 */
#define   EMAT329      (ERRMAT +  329)    /*        mat.c:32486 */
#define   EMAT330      (ERRMAT +  330)    /*        mat.c:32487 */
#define   EMAT331      (ERRMAT +  331)    /*        mat.c:32488 */
#define   EMAT332      (ERRMAT +  332)    /*        mat.c:32489 */
#define   EMAT333      (ERRMAT +  333)    /*        mat.c:32490 */
#define   EMAT334      (ERRMAT +  334)    /*        mat.c:32491 */
#define   EMAT335      (ERRMAT +  335)    /*        mat.c:32562 */
#define   EMAT336      (ERRMAT +  336)    /*        mat.c:32574 */
#define   EMAT337      (ERRMAT +  337)    /*        mat.c:32584 */
#define   EMAT338      (ERRMAT +  338)    /*        mat.c:32585 */
#define   EMAT339      (ERRMAT +  339)    /*        mat.c:32586 */
#define   EMAT340      (ERRMAT +  340)    /*        mat.c:32587 */
#define   EMAT341      (ERRMAT +  341)    /*        mat.c:32588 */
#define   EMAT342      (ERRMAT +  342)    /*        mat.c:32656 */
#define   EMAT343      (ERRMAT +  343)    /*        mat.c:32668 */
#define   EMAT344      (ERRMAT +  344)    /*        mat.c:32678 */
#define   EMAT345      (ERRMAT +  345)    /*        mat.c:32679 */
#define   EMAT346      (ERRMAT +  346)    /*        mat.c:32680 */
#define   EMAT347      (ERRMAT +  347)    /*        mat.c:32681 */
#define   EMAT348      (ERRMAT +  348)    /*        mat.c:32682 */
#define   EMAT349      (ERRMAT +  349)    /*        mat.c:32683 */
#define   EMAT350      (ERRMAT +  350)    /*        mat.c:32757 */
#define   EMAT351      (ERRMAT +  351)    /*        mat.c:32769 */
#define   EMAT352      (ERRMAT +  352)    /*        mat.c:32779 */
#define   EMAT353      (ERRMAT +  353)    /*        mat.c:32780 */
#define   EMAT354      (ERRMAT +  354)    /*        mat.c:32781 */
#define   EMAT355      (ERRMAT +  355)    /*        mat.c:32782 */
#define   EMAT356      (ERRMAT +  356)    /*        mat.c:32783 */
#define   EMAT357      (ERRMAT +  357)    /*        mat.c:32853 */
#define   EMAT358      (ERRMAT +  358)    /*        mat.c:32863 */
#define   EMAT359      (ERRMAT +  359)    /*        mat.c:32872 */
#define   EMAT360      (ERRMAT +  360)    /*        mat.c:32873 */
#define   EMAT361      (ERRMAT +  361)    /*        mat.c:32874 */
#define   EMAT362      (ERRMAT +  362)    /*        mat.c:32875 */
#define   EMAT363      (ERRMAT +  363)    /*        mat.c:32876 */
#define   EMAT364      (ERRMAT +  364)    /*        mat.c:32877 */
#define   EMAT365      (ERRMAT +  365)    /*        mat.c:32878 */
#define   EMAT366      (ERRMAT +  366)    /*        mat.c:32947 */
#define   EMAT367      (ERRMAT +  367)    /*        mat.c:32959 */
#define   EMAT368      (ERRMAT +  368)    /*        mat.c:32969 */
#define   EMAT369      (ERRMAT +  369)    /*        mat.c:32970 */
#define   EMAT370      (ERRMAT +  370)    /*        mat.c:32971 */
#define   EMAT371      (ERRMAT +  371)    /*        mat.c:32972 */
#define   EMAT372      (ERRMAT +  372)    /*        mat.c:32973 */
#define   EMAT373      (ERRMAT +  373)    /*        mat.c:33041 */
#define   EMAT374      (ERRMAT +  374)    /*        mat.c:33053 */
#define   EMAT375      (ERRMAT +  375)    /*        mat.c:33063 */
#define   EMAT376      (ERRMAT +  376)    /*        mat.c:33064 */
#define   EMAT377      (ERRMAT +  377)    /*        mat.c:33065 */
#define   EMAT378      (ERRMAT +  378)    /*        mat.c:33066 */
#define   EMAT379      (ERRMAT +  379)    /*        mat.c:33067 */
#define   EMAT380      (ERRMAT +  380)    /*        mat.c:33068 */
#define   EMAT381      (ERRMAT +  381)    /*        mat.c:33142 */
#define   EMAT382      (ERRMAT +  382)    /*        mat.c:33154 */
#define   EMAT383      (ERRMAT +  383)    /*        mat.c:33164 */
#define   EMAT384      (ERRMAT +  384)    /*        mat.c:33165 */
#define   EMAT385      (ERRMAT +  385)    /*        mat.c:33166 */
#define   EMAT386      (ERRMAT +  386)    /*        mat.c:33167 */
#define   EMAT387      (ERRMAT +  387)    /*        mat.c:33168 */
#define   EMAT388      (ERRMAT +  388)    /*        mat.c:33238 */
#define   EMAT389      (ERRMAT +  389)    /*        mat.c:33248 */
#define   EMAT390      (ERRMAT +  390)    /*        mat.c:33257 */
#define   EMAT391      (ERRMAT +  391)    /*        mat.c:33258 */
#define   EMAT392      (ERRMAT +  392)    /*        mat.c:33259 */
#define   EMAT393      (ERRMAT +  393)    /*        mat.c:33260 */
#define   EMAT394      (ERRMAT +  394)    /*        mat.c:33261 */
#define   EMAT395      (ERRMAT +  395)    /*        mat.c:33262 */
#define   EMAT396      (ERRMAT +  396)    /*        mat.c:33263 */
#define   EMAT397      (ERRMAT +  397)    /*        mat.c:33326 */
#define   EMAT398      (ERRMAT +  398)    /*        mat.c:33338 */
#define   EMAT399      (ERRMAT +  399)    /*        mat.c:33348 */
#define   EMAT400      (ERRMAT +  400)    /*        mat.c:33349 */
#define   EMAT401      (ERRMAT +  401)    /*        mat.c:33350 */
#define   EMAT402      (ERRMAT +  402)    /*        mat.c:33351 */
#define   EMAT403      (ERRMAT +  403)    /*        mat.c:33352 */
#define   EMAT404      (ERRMAT +  404)    /*        mat.c:33420 */
#define   EMAT405      (ERRMAT +  405)    /*        mat.c:33432 */
#define   EMAT406      (ERRMAT +  406)    /*        mat.c:33442 */
#define   EMAT407      (ERRMAT +  407)    /*        mat.c:33443 */
#define   EMAT408      (ERRMAT +  408)    /*        mat.c:33444 */
#define   EMAT409      (ERRMAT +  409)    /*        mat.c:33445 */
#define   EMAT410      (ERRMAT +  410)    /*        mat.c:33446 */
#define   EMAT411      (ERRMAT +  411)    /*        mat.c:33447 */
#define   EMAT412      (ERRMAT +  412)    /*        mat.c:33523 */
#define   EMAT413      (ERRMAT +  413)    /*        mat.c:33535 */
#define   EMAT414      (ERRMAT +  414)    /*        mat.c:33545 */
#define   EMAT415      (ERRMAT +  415)    /*        mat.c:33546 */
#define   EMAT416      (ERRMAT +  416)    /*        mat.c:33547 */
#define   EMAT417      (ERRMAT +  417)    /*        mat.c:33548 */
#define   EMAT418      (ERRMAT +  418)    /*        mat.c:33549 */
#define   EMAT419      (ERRMAT +  419)    /*        mat.c:33619 */
#define   EMAT420      (ERRMAT +  420)    /*        mat.c:33629 */
#define   EMAT421      (ERRMAT +  421)    /*        mat.c:33638 */
#define   EMAT422      (ERRMAT +  422)    /*        mat.c:33639 */
#define   EMAT423      (ERRMAT +  423)    /*        mat.c:33640 */
#define   EMAT424      (ERRMAT +  424)    /*        mat.c:33641 */
#define   EMAT425      (ERRMAT +  425)    /*        mat.c:33642 */
#define   EMAT426      (ERRMAT +  426)    /*        mat.c:33643 */
#define   EMAT427      (ERRMAT +  427)    /*        mat.c:33644 */
#define   EMAT428      (ERRMAT +  428)    /*        mat.c:33713 */
#define   EMAT429      (ERRMAT +  429)    /*        mat.c:33725 */
#define   EMAT430      (ERRMAT +  430)    /*        mat.c:33735 */
#define   EMAT431      (ERRMAT +  431)    /*        mat.c:33736 */
#define   EMAT432      (ERRMAT +  432)    /*        mat.c:33737 */
#define   EMAT433      (ERRMAT +  433)    /*        mat.c:33738 */
#define   EMAT434      (ERRMAT +  434)    /*        mat.c:33739 */
#define   EMAT435      (ERRMAT +  435)    /*        mat.c:33807 */
#define   EMAT436      (ERRMAT +  436)    /*        mat.c:33819 */
#define   EMAT437      (ERRMAT +  437)    /*        mat.c:33829 */
#define   EMAT438      (ERRMAT +  438)    /*        mat.c:33830 */
#define   EMAT439      (ERRMAT +  439)    /*        mat.c:33831 */
#define   EMAT440      (ERRMAT +  440)    /*        mat.c:33832 */
#define   EMAT441      (ERRMAT +  441)    /*        mat.c:33833 */
#define   EMAT442      (ERRMAT +  442)    /*        mat.c:33834 */
#define   EMAT443      (ERRMAT +  443)    /*        mat.c:33881 */
#define   EMAT444      (ERRMAT +  444)    /*        mat.c:33882 */
#define   EMAT445      (ERRMAT +  445)    /*        mat.c:33921 */
#define   EMAT446      (ERRMAT +  446)    /*        mat.c:33922 */
#define   EMAT447      (ERRMAT +  447)    /*        mat.c:33963 */
#define   EMAT448      (ERRMAT +  448)    /*        mat.c:33964 */
#define   EMAT449      (ERRMAT +  449)    /*        mat.c:33965 */
#define   EMAT450      (ERRMAT +  450)    /*        mat.c:33966 */
#define   EMAT451      (ERRMAT +  451)    /*        mat.c:34008 */
#define   EMAT452      (ERRMAT +  452)    /*        mat.c:34009 */
#define   EMAT453      (ERRMAT +  453)    /*        mat.c:34010 */
#define   EMAT454      (ERRMAT +  454)    /*        mat.c:34011 */
#define   EMAT455      (ERRMAT +  455)    /*        mat.c:34053 */
#define   EMAT456      (ERRMAT +  456)    /*        mat.c:34054 */
#define   EMAT457      (ERRMAT +  457)    /*        mat.c:34055 */
#define   EMAT458      (ERRMAT +  458)    /*        mat.c:34056 */
#define   EMAT459      (ERRMAT +  459)    /*        mat.c:34114 */
#define   EMAT460      (ERRMAT +  460)    /*        mat.c:34115 */
#define   EMAT461      (ERRMAT +  461)    /*        mat.c:34116 */
#define   EMAT462      (ERRMAT +  462)    /*        mat.c:34125 */
#define   EMAT463      (ERRMAT +  463)    /*        mat.c:34130 */
#define   EMAT464      (ERRMAT +  464)    /*        mat.c:34187 */
#define   EMAT465      (ERRMAT +  465)    /*        mat.c:34188 */
#define   EMAT466      (ERRMAT +  466)    /*        mat.c:34189 */
#define   EMAT467      (ERRMAT +  467)    /*        mat.c:34190 */
#define   EMAT468      (ERRMAT +  468)    /*        mat.c:34248 */
#define   EMAT469      (ERRMAT +  469)    /*        mat.c:34249 */
#define   EMAT470      (ERRMAT +  470)    /*        mat.c:34250 */
#define   EMAT471      (ERRMAT +  471)    /*        mat.c:34251 */
#define   EMAT472      (ERRMAT +  472)    /*        mat.c:34252 */
#define   EMAT473      (ERRMAT +  473)    /*        mat.c:34267 */
#define   EMAT474      (ERRMAT +  474)    /*        mat.c:34283 */
#define   EMAT475      (ERRMAT +  475)    /*        mat.c:34298 */
#define   EMAT476      (ERRMAT +  476)    /*        mat.c:34367 */
#define   EMAT477      (ERRMAT +  477)    /*        mat.c:34368 */
#define   EMAT478      (ERRMAT +  478)    /*        mat.c:34369 */
#define   EMAT479      (ERRMAT +  479)    /*        mat.c:34370 */
#define   EMAT480      (ERRMAT +  480)    /*        mat.c:34371 */
#define   EMAT481      (ERRMAT +  481)    /*        mat.c:34372 */
#define   EMAT482      (ERRMAT +  482)    /*        mat.c:34373 */
#define   EMAT483      (ERRMAT +  483)    /*        mat.c:34384 */
#define   EMAT484      (ERRMAT +  484)    /*        mat.c:34396 */
#define   EMAT485      (ERRMAT +  485)    /*        mat.c:34412 */
#define   EMAT486      (ERRMAT +  486)    /*        mat.c:34478 */
#define   EMAT487      (ERRMAT +  487)    /*        mat.c:34479 */
#define   EMAT488      (ERRMAT +  488)    /*        mat.c:34480 */
#define   EMAT489      (ERRMAT +  489)    /*        mat.c:34481 */
#define   EMAT490      (ERRMAT +  490)    /*        mat.c:34482 */
#define   EMAT491      (ERRMAT +  491)    /*        mat.c:34483 */
#define   EMAT492      (ERRMAT +  492)    /*        mat.c:34495 */
#define   EMAT493      (ERRMAT +  493)    /*        mat.c:34512 */
#define   EMAT494      (ERRMAT +  494)    /*        mat.c:34528 */
#define   EMAT495      (ERRMAT +  495)    /*        mat.c:34589 */
#define   EMAT496      (ERRMAT +  496)    /*        mat.c:34590 */
#define   EMAT497      (ERRMAT +  497)    /*        mat.c:34591 */
#define   EMAT498      (ERRMAT +  498)    /*        mat.c:34592 */
#define   EMAT499      (ERRMAT +  499)    /*        mat.c:34593 */
#define   EMAT500      (ERRMAT +  500)    /*        mat.c:34603 */
#define   EMAT501      (ERRMAT +  501)    /*        mat.c:34616 */
#define   EMAT502      (ERRMAT +  502)    /*        mat.c:34632 */
#define   EMAT503      (ERRMAT +  503)    /*        mat.c:34702 */
#define   EMAT504      (ERRMAT +  504)    /*        mat.c:34703 */
#define   EMAT505      (ERRMAT +  505)    /*        mat.c:34704 */
#define   EMAT506      (ERRMAT +  506)    /*        mat.c:34705 */
#define   EMAT507      (ERRMAT +  507)    /*        mat.c:34706 */
#define   EMAT508      (ERRMAT +  508)    /*        mat.c:34721 */
#define   EMAT509      (ERRMAT +  509)    /*        mat.c:34737 */
#define   EMAT510      (ERRMAT +  510)    /*        mat.c:34752 */
#define   EMAT511      (ERRMAT +  511)    /*        mat.c:34819 */
#define   EMAT512      (ERRMAT +  512)    /*        mat.c:34820 */
#define   EMAT513      (ERRMAT +  513)    /*        mat.c:34821 */
#define   EMAT514      (ERRMAT +  514)    /*        mat.c:34822 */
#define   EMAT515      (ERRMAT +  515)    /*        mat.c:34823 */
#define   EMAT516      (ERRMAT +  516)    /*        mat.c:34824 */
#define   EMAT517      (ERRMAT +  517)    /*        mat.c:34825 */
#define   EMAT518      (ERRMAT +  518)    /*        mat.c:34836 */
#define   EMAT519      (ERRMAT +  519)    /*        mat.c:34848 */
#define   EMAT520      (ERRMAT +  520)    /*        mat.c:34864 */
#define   EMAT521      (ERRMAT +  521)    /*        mat.c:34931 */
#define   EMAT522      (ERRMAT +  522)    /*        mat.c:34932 */
#define   EMAT523      (ERRMAT +  523)    /*        mat.c:34933 */
#define   EMAT524      (ERRMAT +  524)    /*        mat.c:34934 */
#define   EMAT525      (ERRMAT +  525)    /*        mat.c:34935 */
#define   EMAT526      (ERRMAT +  526)    /*        mat.c:34946 */
#define   EMAT527      (ERRMAT +  527)    /*        mat.c:34959 */
#define   EMAT528      (ERRMAT +  528)    /*        mat.c:34975 */
#define   EMAT529      (ERRMAT +  529)    /*        mat.c:35041 */
#define   EMAT530      (ERRMAT +  530)    /*        mat.c:35042 */
#define   EMAT531      (ERRMAT +  531)    /*        mat.c:35043 */
#define   EMAT532      (ERRMAT +  532)    /*        mat.c:35044 */
#define   EMAT533      (ERRMAT +  533)    /*        mat.c:35045 */
#define   EMAT534      (ERRMAT +  534)    /*        mat.c:35046 */
#define   EMAT535      (ERRMAT +  535)    /*        mat.c:35058 */
#define   EMAT536      (ERRMAT +  536)    /*        mat.c:35075 */
#define   EMAT537      (ERRMAT +  537)    /*        mat.c:35091 */
#define   EMAT538      (ERRMAT +  538)    /*        mat.c:35158 */
#define   EMAT539      (ERRMAT +  539)    /*        mat.c:35159 */
#define   EMAT540      (ERRMAT +  540)    /*        mat.c:35160 */
#define   EMAT541      (ERRMAT +  541)    /*        mat.c:35161 */
#define   EMAT542      (ERRMAT +  542)    /*        mat.c:35162 */
#define   EMAT543      (ERRMAT +  543)    /*        mat.c:35178 */
#define   EMAT544      (ERRMAT +  544)    /*        mat.c:35194 */
#define   EMAT545      (ERRMAT +  545)    /*        mat.c:35209 */
#define   EMAT546      (ERRMAT +  546)    /*        mat.c:35279 */
#define   EMAT547      (ERRMAT +  547)    /*        mat.c:35280 */
#define   EMAT548      (ERRMAT +  548)    /*        mat.c:35281 */
#define   EMAT549      (ERRMAT +  549)    /*        mat.c:35282 */
#define   EMAT550      (ERRMAT +  550)    /*        mat.c:35283 */
#define   EMAT551      (ERRMAT +  551)    /*        mat.c:35284 */
#define   EMAT552      (ERRMAT +  552)    /*        mat.c:35285 */
#define   EMAT553      (ERRMAT +  553)    /*        mat.c:35296 */
#define   EMAT554      (ERRMAT +  554)    /*        mat.c:35308 */
#define   EMAT555      (ERRMAT +  555)    /*        mat.c:35324 */
#define   EMAT556      (ERRMAT +  556)    /*        mat.c:35396 */
#define   EMAT557      (ERRMAT +  557)    /*        mat.c:35397 */
#define   EMAT558      (ERRMAT +  558)    /*        mat.c:35398 */
#define   EMAT559      (ERRMAT +  559)    /*        mat.c:35399 */
#define   EMAT560      (ERRMAT +  560)    /*        mat.c:35400 */
#define   EMAT561      (ERRMAT +  561)    /*        mat.c:35411 */
#define   EMAT562      (ERRMAT +  562)    /*        mat.c:35424 */
#define   EMAT563      (ERRMAT +  563)    /*        mat.c:35440 */
#define   EMAT564      (ERRMAT +  564)    /*        mat.c:35506 */
#define   EMAT565      (ERRMAT +  565)    /*        mat.c:35507 */
#define   EMAT566      (ERRMAT +  566)    /*        mat.c:35508 */
#define   EMAT567      (ERRMAT +  567)    /*        mat.c:35509 */
#define   EMAT568      (ERRMAT +  568)    /*        mat.c:35510 */
#define   EMAT569      (ERRMAT +  569)    /*        mat.c:35511 */
#define   EMAT570      (ERRMAT +  570)    /*        mat.c:35523 */
#define   EMAT571      (ERRMAT +  571)    /*        mat.c:35540 */
#define   EMAT572      (ERRMAT +  572)    /*        mat.c:35556 */
#define   EMAT573      (ERRMAT +  573)    /*        mat.c:35623 */
#define   EMAT574      (ERRMAT +  574)    /*        mat.c:35624 */
#define   EMAT575      (ERRMAT +  575)    /*        mat.c:35625 */
#define   EMAT576      (ERRMAT +  576)    /*        mat.c:35626 */
#define   EMAT577      (ERRMAT +  577)    /*        mat.c:35627 */
#define   EMAT578      (ERRMAT +  578)    /*        mat.c:35642 */
#define   EMAT579      (ERRMAT +  579)    /*        mat.c:35658 */
#define   EMAT580      (ERRMAT +  580)    /*        mat.c:35673 */
#define   EMAT581      (ERRMAT +  581)    /*        mat.c:35742 */
#define   EMAT582      (ERRMAT +  582)    /*        mat.c:35743 */
#define   EMAT583      (ERRMAT +  583)    /*        mat.c:35744 */
#define   EMAT584      (ERRMAT +  584)    /*        mat.c:35745 */
#define   EMAT585      (ERRMAT +  585)    /*        mat.c:35746 */
#define   EMAT586      (ERRMAT +  586)    /*        mat.c:35747 */
#define   EMAT587      (ERRMAT +  587)    /*        mat.c:35748 */
#define   EMAT588      (ERRMAT +  588)    /*        mat.c:35759 */
#define   EMAT589      (ERRMAT +  589)    /*        mat.c:35771 */
#define   EMAT590      (ERRMAT +  590)    /*        mat.c:35787 */
#define   EMAT591      (ERRMAT +  591)    /*        mat.c:35857 */
#define   EMAT592      (ERRMAT +  592)    /*        mat.c:35858 */
#define   EMAT593      (ERRMAT +  593)    /*        mat.c:35859 */
#define   EMAT594      (ERRMAT +  594)    /*        mat.c:35860 */
#define   EMAT595      (ERRMAT +  595)    /*        mat.c:35861 */
#define   EMAT596      (ERRMAT +  596)    /*        mat.c:35871 */
#define   EMAT597      (ERRMAT +  597)    /*        mat.c:35884 */
#define   EMAT598      (ERRMAT +  598)    /*        mat.c:35900 */
#define   EMAT599      (ERRMAT +  599)    /*        mat.c:35965 */
#define   EMAT600      (ERRMAT +  600)    /*        mat.c:35966 */
#define   EMAT601      (ERRMAT +  601)    /*        mat.c:35967 */
#define   EMAT602      (ERRMAT +  602)    /*        mat.c:35968 */
#define   EMAT603      (ERRMAT +  603)    /*        mat.c:35969 */
#define   EMAT604      (ERRMAT +  604)    /*        mat.c:35970 */
#define   EMAT605      (ERRMAT +  605)    /*        mat.c:35982 */
#define   EMAT606      (ERRMAT +  606)    /*        mat.c:35999 */
#define   EMAT607      (ERRMAT +  607)    /*        mat.c:36015 */
#define   EMAT608      (ERRMAT +  608)    /*        mat.c:36084 */
#define   EMAT609      (ERRMAT +  609)    /*        mat.c:36085 */
#define   EMAT610      (ERRMAT +  610)    /*        mat.c:36086 */
#define   EMAT611      (ERRMAT +  611)    /*        mat.c:36087 */
#define   EMAT612      (ERRMAT +  612)    /*        mat.c:36088 */
#define   EMAT613      (ERRMAT +  613)    /*        mat.c:36102 */
#define   EMAT614      (ERRMAT +  614)    /*        mat.c:36118 */
#define   EMAT615      (ERRMAT +  615)    /*        mat.c:36133 */
#define   EMAT616      (ERRMAT +  616)    /*        mat.c:36202 */
#define   EMAT617      (ERRMAT +  617)    /*        mat.c:36203 */
#define   EMAT618      (ERRMAT +  618)    /*        mat.c:36204 */
#define   EMAT619      (ERRMAT +  619)    /*        mat.c:36205 */
#define   EMAT620      (ERRMAT +  620)    /*        mat.c:36206 */
#define   EMAT621      (ERRMAT +  621)    /*        mat.c:36207 */
#define   EMAT622      (ERRMAT +  622)    /*        mat.c:36208 */
#define   EMAT623      (ERRMAT +  623)    /*        mat.c:36219 */
#define   EMAT624      (ERRMAT +  624)    /*        mat.c:36231 */
#define   EMAT625      (ERRMAT +  625)    /*        mat.c:36247 */
#define   EMAT626      (ERRMAT +  626)    /*        mat.c:36320 */
#define   EMAT627      (ERRMAT +  627)    /*        mat.c:36321 */
#define   EMAT628      (ERRMAT +  628)    /*        mat.c:36322 */
#define   EMAT629      (ERRMAT +  629)    /*        mat.c:36323 */
#define   EMAT630      (ERRMAT +  630)    /*        mat.c:36324 */
#define   EMAT631      (ERRMAT +  631)    /*        mat.c:36334 */
#define   EMAT632      (ERRMAT +  632)    /*        mat.c:36347 */
#define   EMAT633      (ERRMAT +  633)    /*        mat.c:36363 */
#define   EMAT634      (ERRMAT +  634)    /*        mat.c:36429 */
#define   EMAT635      (ERRMAT +  635)    /*        mat.c:36430 */
#define   EMAT636      (ERRMAT +  636)    /*        mat.c:36431 */
#define   EMAT637      (ERRMAT +  637)    /*        mat.c:36432 */
#define   EMAT638      (ERRMAT +  638)    /*        mat.c:36433 */
#define   EMAT639      (ERRMAT +  639)    /*        mat.c:36434 */
#define   EMAT640      (ERRMAT +  640)    /*        mat.c:36445 */
#define   EMAT641      (ERRMAT +  641)    /*        mat.c:36462 */
#define   EMAT642      (ERRMAT +  642)    /*        mat.c:36478 */
#define   EMAT643      (ERRMAT +  643)    /*        mat.c:36546 */
#define   EMAT644      (ERRMAT +  644)    /*        mat.c:36547 */
#define   EMAT645      (ERRMAT +  645)    /*        mat.c:36548 */
#define   EMAT646      (ERRMAT +  646)    /*        mat.c:36549 */
#define   EMAT647      (ERRMAT +  647)    /*        mat.c:36550 */
#define   EMAT648      (ERRMAT +  648)    /*        mat.c:36565 */
#define   EMAT649      (ERRMAT +  649)    /*        mat.c:36581 */
#define   EMAT650      (ERRMAT +  650)    /*        mat.c:36596 */
#define   EMAT651      (ERRMAT +  651)    /*        mat.c:36664 */
#define   EMAT652      (ERRMAT +  652)    /*        mat.c:36665 */
#define   EMAT653      (ERRMAT +  653)    /*        mat.c:36666 */
#define   EMAT654      (ERRMAT +  654)    /*        mat.c:36667 */
#define   EMAT655      (ERRMAT +  655)    /*        mat.c:36668 */
#define   EMAT656      (ERRMAT +  656)    /*        mat.c:36669 */
#define   EMAT657      (ERRMAT +  657)    /*        mat.c:36670 */
#define   EMAT658      (ERRMAT +  658)    /*        mat.c:36681 */
#define   EMAT659      (ERRMAT +  659)    /*        mat.c:36693 */
#define   EMAT660      (ERRMAT +  660)    /*        mat.c:36709 */
#define   EMAT661      (ERRMAT +  661)    /*        mat.c:36781 */
#define   EMAT662      (ERRMAT +  662)    /*        mat.c:36782 */
#define   EMAT663      (ERRMAT +  663)    /*        mat.c:36783 */
#define   EMAT664      (ERRMAT +  664)    /*        mat.c:36784 */
#define   EMAT665      (ERRMAT +  665)    /*        mat.c:36785 */
#define   EMAT666      (ERRMAT +  666)    /*        mat.c:36796 */
#define   EMAT667      (ERRMAT +  667)    /*        mat.c:36809 */
#define   EMAT668      (ERRMAT +  668)    /*        mat.c:36825 */
#define   EMAT669      (ERRMAT +  669)    /*        mat.c:36891 */
#define   EMAT670      (ERRMAT +  670)    /*        mat.c:36892 */
#define   EMAT671      (ERRMAT +  671)    /*        mat.c:36893 */
#define   EMAT672      (ERRMAT +  672)    /*        mat.c:36894 */
#define   EMAT673      (ERRMAT +  673)    /*        mat.c:36895 */
#define   EMAT674      (ERRMAT +  674)    /*        mat.c:36896 */
#define   EMAT675      (ERRMAT +  675)    /*        mat.c:36908 */
#define   EMAT676      (ERRMAT +  676)    /*        mat.c:36925 */
#define   EMAT677      (ERRMAT +  677)    /*        mat.c:36941 */
#define   EMAT678      (ERRMAT +  678)    /*        mat.c:37011 */
#define   EMAT679      (ERRMAT +  679)    /*        mat.c:37012 */
#define   EMAT680      (ERRMAT +  680)    /*        mat.c:37013 */
#define   EMAT681      (ERRMAT +  681)    /*        mat.c:37014 */
#define   EMAT682      (ERRMAT +  682)    /*        mat.c:37015 */
#define   EMAT683      (ERRMAT +  683)    /*        mat.c:37031 */
#define   EMAT684      (ERRMAT +  684)    /*        mat.c:37047 */
#define   EMAT685      (ERRMAT +  685)    /*        mat.c:37062 */
#define   EMAT686      (ERRMAT +  686)    /*        mat.c:37131 */
#define   EMAT687      (ERRMAT +  687)    /*        mat.c:37132 */
#define   EMAT688      (ERRMAT +  688)    /*        mat.c:37133 */
#define   EMAT689      (ERRMAT +  689)    /*        mat.c:37134 */
#define   EMAT690      (ERRMAT +  690)    /*        mat.c:37135 */
#define   EMAT691      (ERRMAT +  691)    /*        mat.c:37136 */
#define   EMAT692      (ERRMAT +  692)    /*        mat.c:37137 */
#define   EMAT693      (ERRMAT +  693)    /*        mat.c:37148 */
#define   EMAT694      (ERRMAT +  694)    /*        mat.c:37160 */
#define   EMAT695      (ERRMAT +  695)    /*        mat.c:37176 */
#define   EMAT696      (ERRMAT +  696)    /*        mat.c:37240 */
#define   EMAT697      (ERRMAT +  697)    /*        mat.c:37241 */
#define   EMAT698      (ERRMAT +  698)    /*        mat.c:37242 */
#define   EMAT699      (ERRMAT +  699)    /*        mat.c:37243 */
#define   EMAT700      (ERRMAT +  700)    /*        mat.c:37244 */
#define   EMAT701      (ERRMAT +  701)    /*        mat.c:37255 */
#define   EMAT702      (ERRMAT +  702)    /*        mat.c:37268 */
#define   EMAT703      (ERRMAT +  703)    /*        mat.c:37284 */
#define   EMAT704      (ERRMAT +  704)    /*        mat.c:37349 */
#define   EMAT705      (ERRMAT +  705)    /*        mat.c:37350 */
#define   EMAT706      (ERRMAT +  706)    /*        mat.c:37351 */
#define   EMAT707      (ERRMAT +  707)    /*        mat.c:37352 */
#define   EMAT708      (ERRMAT +  708)    /*        mat.c:37353 */
#define   EMAT709      (ERRMAT +  709)    /*        mat.c:37354 */
#define   EMAT710      (ERRMAT +  710)    /*        mat.c:37366 */
#define   EMAT711      (ERRMAT +  711)    /*        mat.c:37383 */
#define   EMAT712      (ERRMAT +  712)    /*        mat.c:37399 */
#define   EMAT713      (ERRMAT +  713)    /*        mat.c:37467 */
#define   EMAT714      (ERRMAT +  714)    /*        mat.c:37468 */
#define   EMAT715      (ERRMAT +  715)    /*        mat.c:37469 */
#define   EMAT716      (ERRMAT +  716)    /*        mat.c:37470 */
#define   EMAT717      (ERRMAT +  717)    /*        mat.c:37471 */
#define   EMAT718      (ERRMAT +  718)    /*        mat.c:37472 */
#define   EMAT719      (ERRMAT +  719)    /*        mat.c:37487 */
#define   EMAT720      (ERRMAT +  720)    /*        mat.c:37503 */
#define   EMAT721      (ERRMAT +  721)    /*        mat.c:37518 */
#define   EMAT722      (ERRMAT +  722)    /*        mat.c:37588 */
#define   EMAT723      (ERRMAT +  723)    /*        mat.c:37589 */
#define   EMAT724      (ERRMAT +  724)    /*        mat.c:37590 */
#define   EMAT725      (ERRMAT +  725)    /*        mat.c:37591 */
#define   EMAT726      (ERRMAT +  726)    /*        mat.c:37592 */
#define   EMAT727      (ERRMAT +  727)    /*        mat.c:37593 */
#define   EMAT728      (ERRMAT +  728)    /*        mat.c:37594 */
#define   EMAT729      (ERRMAT +  729)    /*        mat.c:37605 */
#define   EMAT730      (ERRMAT +  730)    /*        mat.c:37617 */
#define   EMAT731      (ERRMAT +  731)    /*        mat.c:37633 */
#define   EMAT732      (ERRMAT +  732)    /*        mat.c:37704 */
#define   EMAT733      (ERRMAT +  733)    /*        mat.c:37705 */
#define   EMAT734      (ERRMAT +  734)    /*        mat.c:37706 */
#define   EMAT735      (ERRMAT +  735)    /*        mat.c:37707 */
#define   EMAT736      (ERRMAT +  736)    /*        mat.c:37708 */
#define   EMAT737      (ERRMAT +  737)    /*        mat.c:37709 */
#define   EMAT738      (ERRMAT +  738)    /*        mat.c:37720 */
#define   EMAT739      (ERRMAT +  739)    /*        mat.c:37733 */
#define   EMAT740      (ERRMAT +  740)    /*        mat.c:37749 */
#define   EMAT741      (ERRMAT +  741)    /*        mat.c:37815 */
#define   EMAT742      (ERRMAT +  742)    /*        mat.c:37816 */
#define   EMAT743      (ERRMAT +  743)    /*        mat.c:37817 */
#define   EMAT744      (ERRMAT +  744)    /*        mat.c:37818 */
#define   EMAT745      (ERRMAT +  745)    /*        mat.c:37819 */
#define   EMAT746      (ERRMAT +  746)    /*        mat.c:37820 */
#define   EMAT747      (ERRMAT +  747)    /*        mat.c:37832 */
#define   EMAT748      (ERRMAT +  748)    /*        mat.c:37849 */
#define   EMAT749      (ERRMAT +  749)    /*        mat.c:37865 */
#define   EMAT750      (ERRMAT +  750)    /*        mat.c:37932 */
#define   EMAT751      (ERRMAT +  751)    /*        mat.c:37933 */
#define   EMAT752      (ERRMAT +  752)    /*        mat.c:37934 */
#define   EMAT753      (ERRMAT +  753)    /*        mat.c:37935 */
#define   EMAT754      (ERRMAT +  754)    /*        mat.c:37936 */
#define   EMAT755      (ERRMAT +  755)    /*        mat.c:37951 */
#define   EMAT756      (ERRMAT +  756)    /*        mat.c:37967 */
#define   EMAT757      (ERRMAT +  757)    /*        mat.c:37982 */
#define   EMAT758      (ERRMAT +  758)    /*        mat.c:38050 */
#define   EMAT759      (ERRMAT +  759)    /*        mat.c:38051 */
#define   EMAT760      (ERRMAT +  760)    /*        mat.c:38052 */
#define   EMAT761      (ERRMAT +  761)    /*        mat.c:38053 */
#define   EMAT762      (ERRMAT +  762)    /*        mat.c:38054 */
#define   EMAT763      (ERRMAT +  763)    /*        mat.c:38055 */
#define   EMAT764      (ERRMAT +  764)    /*        mat.c:38056 */
#define   EMAT765      (ERRMAT +  765)    /*        mat.c:38066 */
#define   EMAT766      (ERRMAT +  766)    /*        mat.c:38078 */
#define   EMAT767      (ERRMAT +  767)    /*        mat.c:38094 */
#define   EMAT768      (ERRMAT +  768)    /*        mat.c:38165 */
#define   EMAT769      (ERRMAT +  769)    /*        mat.c:38166 */
#define   EMAT770      (ERRMAT +  770)    /*        mat.c:38167 */
#define   EMAT771      (ERRMAT +  771)    /*        mat.c:38168 */
#define   EMAT772      (ERRMAT +  772)    /*        mat.c:38169 */
#define   EMAT773      (ERRMAT +  773)    /*        mat.c:38180 */
#define   EMAT774      (ERRMAT +  774)    /*        mat.c:38193 */
#define   EMAT775      (ERRMAT +  775)    /*        mat.c:38209 */
#define   EMAT776      (ERRMAT +  776)    /*        mat.c:38274 */
#define   EMAT777      (ERRMAT +  777)    /*        mat.c:38275 */
#define   EMAT778      (ERRMAT +  778)    /*        mat.c:38276 */
#define   EMAT779      (ERRMAT +  779)    /*        mat.c:38277 */
#define   EMAT780      (ERRMAT +  780)    /*        mat.c:38278 */
#define   EMAT781      (ERRMAT +  781)    /*        mat.c:38279 */
#define   EMAT782      (ERRMAT +  782)    /*        mat.c:38291 */
#define   EMAT783      (ERRMAT +  783)    /*        mat.c:38308 */
#define   EMAT784      (ERRMAT +  784)    /*        mat.c:38324 */
#define   EMAT785      (ERRMAT +  785)    /*        mat.c:38393 */
#define   EMAT786      (ERRMAT +  786)    /*        mat.c:38394 */
#define   EMAT787      (ERRMAT +  787)    /*        mat.c:38395 */
#define   EMAT788      (ERRMAT +  788)    /*        mat.c:38396 */
#define   EMAT789      (ERRMAT +  789)    /*        mat.c:38397 */
#define   EMAT790      (ERRMAT +  790)    /*        mat.c:38412 */
#define   EMAT791      (ERRMAT +  791)    /*        mat.c:38428 */
#define   EMAT792      (ERRMAT +  792)    /*        mat.c:38443 */
#define   EMAT793      (ERRMAT +  793)    /*        mat.c:38512 */
#define   EMAT794      (ERRMAT +  794)    /*        mat.c:38513 */
#define   EMAT795      (ERRMAT +  795)    /*        mat.c:38514 */
#define   EMAT796      (ERRMAT +  796)    /*        mat.c:38515 */
#define   EMAT797      (ERRMAT +  797)    /*        mat.c:38516 */
#define   EMAT798      (ERRMAT +  798)    /*        mat.c:38517 */
#define   EMAT799      (ERRMAT +  799)    /*        mat.c:38518 */
#define   EMAT800      (ERRMAT +  800)    /*        mat.c:38529 */
#define   EMAT801      (ERRMAT +  801)    /*        mat.c:38541 */
#define   EMAT802      (ERRMAT +  802)    /*        mat.c:38557 */
#define   EMAT803      (ERRMAT +  803)    /*        mat.c:38627 */
#define   EMAT804      (ERRMAT +  804)    /*        mat.c:38628 */
#define   EMAT805      (ERRMAT +  805)    /*        mat.c:38629 */
#define   EMAT806      (ERRMAT +  806)    /*        mat.c:38630 */
#define   EMAT807      (ERRMAT +  807)    /*        mat.c:38631 */
#define   EMAT808      (ERRMAT +  808)    /*        mat.c:38642 */
#define   EMAT809      (ERRMAT +  809)    /*        mat.c:38655 */
#define   EMAT810      (ERRMAT +  810)    /*        mat.c:38671 */
#define   EMAT811      (ERRMAT +  811)    /*        mat.c:38736 */
#define   EMAT812      (ERRMAT +  812)    /*        mat.c:38737 */
#define   EMAT813      (ERRMAT +  813)    /*        mat.c:38738 */
#define   EMAT814      (ERRMAT +  814)    /*        mat.c:38739 */
#define   EMAT815      (ERRMAT +  815)    /*        mat.c:38740 */
#define   EMAT816      (ERRMAT +  816)    /*        mat.c:38741 */
#define   EMAT817      (ERRMAT +  817)    /*        mat.c:38753 */
#define   EMAT818      (ERRMAT +  818)    /*        mat.c:38770 */
#define   EMAT819      (ERRMAT +  819)    /*        mat.c:38786 */
#define   EMAT820      (ERRMAT +  820)    /*        mat.c:38854 */
#define   EMAT821      (ERRMAT +  821)    /*        mat.c:38855 */
#define   EMAT822      (ERRMAT +  822)    /*        mat.c:38856 */
#define   EMAT823      (ERRMAT +  823)    /*        mat.c:38857 */
#define   EMAT824      (ERRMAT +  824)    /*        mat.c:38858 */
#define   EMAT825      (ERRMAT +  825)    /*        mat.c:38874 */
#define   EMAT826      (ERRMAT +  826)    /*        mat.c:38890 */
#define   EMAT827      (ERRMAT +  827)    /*        mat.c:38905 */
#define   EMAT828      (ERRMAT +  828)    /*        mat.c:38973 */
#define   EMAT829      (ERRMAT +  829)    /*        mat.c:38974 */
#define   EMAT830      (ERRMAT +  830)    /*        mat.c:38975 */
#define   EMAT831      (ERRMAT +  831)    /*        mat.c:38976 */
#define   EMAT832      (ERRMAT +  832)    /*        mat.c:38977 */
#define   EMAT833      (ERRMAT +  833)    /*        mat.c:38978 */
#define   EMAT834      (ERRMAT +  834)    /*        mat.c:38979 */
#define   EMAT835      (ERRMAT +  835)    /*        mat.c:38990 */
#define   EMAT836      (ERRMAT +  836)    /*        mat.c:39002 */
#define   EMAT837      (ERRMAT +  837)    /*        mat.c:39018 */
#define   EMAT838      (ERRMAT +  838)    /*        mat.c:39081 */
#define   EMAT839      (ERRMAT +  839)    /*        mat.c:39082 */
#define   EMAT840      (ERRMAT +  840)    /*        mat.c:39083 */
#define   EMAT841      (ERRMAT +  841)    /*        mat.c:39084 */
#define   EMAT842      (ERRMAT +  842)    /*        mat.c:39085 */
#define   EMAT843      (ERRMAT +  843)    /*        mat.c:39096 */
#define   EMAT844      (ERRMAT +  844)    /*        mat.c:39109 */
#define   EMAT845      (ERRMAT +  845)    /*        mat.c:39125 */
#define   EMAT846      (ERRMAT +  846)    /*        mat.c:39190 */
#define   EMAT847      (ERRMAT +  847)    /*        mat.c:39191 */
#define   EMAT848      (ERRMAT +  848)    /*        mat.c:39192 */
#define   EMAT849      (ERRMAT +  849)    /*        mat.c:39193 */
#define   EMAT850      (ERRMAT +  850)    /*        mat.c:39194 */
#define   EMAT851      (ERRMAT +  851)    /*        mat.c:39195 */
#define   EMAT852      (ERRMAT +  852)    /*        mat.c:39207 */
#define   EMAT853      (ERRMAT +  853)    /*        mat.c:39224 */
#define   EMAT854      (ERRMAT +  854)    /*        mat.c:39240 */
#define   EMAT855      (ERRMAT +  855)    /*        mat.c:39313 */
#define   EMAT856      (ERRMAT +  856)    /*        mat.c:39314 */
#define   EMAT857      (ERRMAT +  857)    /*        mat.c:39315 */
#define   EMAT858      (ERRMAT +  858)    /*        mat.c:39316 */
#define   EMAT859      (ERRMAT +  859)    /*        mat.c:39317 */
#define   EMAT860      (ERRMAT +  860)    /*        mat.c:39332 */
#define   EMAT861      (ERRMAT +  861)    /*        mat.c:39348 */
#define   EMAT862      (ERRMAT +  862)    /*        mat.c:39363 */
#define   EMAT863      (ERRMAT +  863)    /*        mat.c:39433 */
#define   EMAT864      (ERRMAT +  864)    /*        mat.c:39434 */
#define   EMAT865      (ERRMAT +  865)    /*        mat.c:39435 */
#define   EMAT866      (ERRMAT +  866)    /*        mat.c:39436 */
#define   EMAT867      (ERRMAT +  867)    /*        mat.c:39437 */
#define   EMAT868      (ERRMAT +  868)    /*        mat.c:39438 */
#define   EMAT869      (ERRMAT +  869)    /*        mat.c:39439 */
#define   EMAT870      (ERRMAT +  870)    /*        mat.c:39450 */
#define   EMAT871      (ERRMAT +  871)    /*        mat.c:39462 */
#define   EMAT872      (ERRMAT +  872)    /*        mat.c:39478 */
#define   EMAT873      (ERRMAT +  873)    /*        mat.c:39549 */
#define   EMAT874      (ERRMAT +  874)    /*        mat.c:39550 */
#define   EMAT875      (ERRMAT +  875)    /*        mat.c:39551 */
#define   EMAT876      (ERRMAT +  876)    /*        mat.c:39552 */
#define   EMAT877      (ERRMAT +  877)    /*        mat.c:39553 */
#define   EMAT878      (ERRMAT +  878)    /*        mat.c:39564 */
#define   EMAT879      (ERRMAT +  879)    /*        mat.c:39577 */
#define   EMAT880      (ERRMAT +  880)    /*        mat.c:39593 */
#define   EMAT881      (ERRMAT +  881)    /*        mat.c:39660 */
#define   EMAT882      (ERRMAT +  882)    /*        mat.c:39661 */
#define   EMAT883      (ERRMAT +  883)    /*        mat.c:39662 */
#define   EMAT884      (ERRMAT +  884)    /*        mat.c:39663 */
#define   EMAT885      (ERRMAT +  885)    /*        mat.c:39664 */
#define   EMAT886      (ERRMAT +  886)    /*        mat.c:39665 */
#define   EMAT887      (ERRMAT +  887)    /*        mat.c:39677 */
#define   EMAT888      (ERRMAT +  888)    /*        mat.c:39694 */
#define   EMAT889      (ERRMAT +  889)    /*        mat.c:39710 */
#define   EMAT890      (ERRMAT +  890)    /*        mat.c:39776 */
#define   EMAT891      (ERRMAT +  891)    /*        mat.c:39777 */
#define   EMAT892      (ERRMAT +  892)    /*        mat.c:39778 */
#define   EMAT893      (ERRMAT +  893)    /*        mat.c:39779 */
#define   EMAT894      (ERRMAT +  894)    /*        mat.c:39821 */
#define   EMAT895      (ERRMAT +  895)    /*        mat.c:39822 */
#define   EMAT896      (ERRMAT +  896)    /*        mat.c:39823 */
#define   EMAT897      (ERRMAT +  897)    /*        mat.c:39824 */
#define   EMAT898      (ERRMAT +  898)    /*        mat.c:39866 */
#define   EMAT899      (ERRMAT +  899)    /*        mat.c:39867 */
#define   EMAT900      (ERRMAT +  900)    /*        mat.c:39868 */
#define   EMAT901      (ERRMAT +  901)    /*        mat.c:39869 */
#define   EMAT902      (ERRMAT +  902)    /*        mat.c:39910 */
#define   EMAT903      (ERRMAT +  903)    /*        mat.c:39911 */
#define   EMAT904      (ERRMAT +  904)    /*        mat.c:39912 */
#define   EMAT905      (ERRMAT +  905)    /*        mat.c:39954 */
#define   EMAT906      (ERRMAT +  906)    /*        mat.c:39955 */
#define   EMAT907      (ERRMAT +  907)    /*        mat.c:39956 */
#define   EMAT908      (ERRMAT +  908)    /*        mat.c:39957 */
#define   EMAT909      (ERRMAT +  909)    /*        mat.c:39998 */
#define   EMAT910      (ERRMAT +  910)    /*        mat.c:39999 */
#define   EMAT911      (ERRMAT +  911)    /*        mat.c:40000 */
#define   EMAT912      (ERRMAT +  912)    /*        mat.c:40043 */
#define   EMAT913      (ERRMAT +  913)    /*        mat.c:40044 */
#define   EMAT914      (ERRMAT +  914)    /*        mat.c:40045 */
#define   EMAT915      (ERRMAT +  915)    /*        mat.c:40046 */
#define   EMAT916      (ERRMAT +  916)    /*        mat.c:40047 */
#define   EMAT917      (ERRMAT +  917)    /*        mat.c:40089 */
#define   EMAT918      (ERRMAT +  918)    /*        mat.c:40090 */
#define   EMAT919      (ERRMAT +  919)    /*        mat.c:40091 */
#define   EMAT920      (ERRMAT +  920)    /*        mat.c:40092 */
#define   EMAT921      (ERRMAT +  921)    /*        mat.c:40134 */
#define   EMAT922      (ERRMAT +  922)    /*        mat.c:40135 */
#define   EMAT923      (ERRMAT +  923)    /*        mat.c:40177 */
#define   EMAT924      (ERRMAT +  924)    /*        mat.c:40178 */
#define   EMAT925      (ERRMAT +  925)    /*        mat.c:40239 */
#define   EMAT926      (ERRMAT +  926)    /*        mat.c:40240 */
#define   EMAT927      (ERRMAT +  927)    /*        mat.c:40250 */
#define   EMAT928      (ERRMAT +  928)    /*        mat.c:40251 */
#define   EMAT929      (ERRMAT +  929)    /*        mat.c:40322 */
#define   EMAT930      (ERRMAT +  930)    /*        mat.c:40323 */
#define   EMAT931      (ERRMAT +  931)    /*        mat.c:40333 */
#define   EMAT932      (ERRMAT +  932)    /*        mat.c:40334 */
#define   EMAT933      (ERRMAT +  933)    /*        mat.c:40388 */
#define   EMAT934      (ERRMAT +  934)    /*        mat.c:40389 */
#define   EMAT935      (ERRMAT +  935)    /*        mat.c:40439 */
#define   EMAT936      (ERRMAT +  936)    /*        mat.c:40440 */


/*for XINWEI*/
#define GRP_MAX_NUM 10
#define MAX_SHRINK_DIAL 			 100  /*the max number of group shrink dial number*/
#define MAT_XW_MAX_NMB_PRI_EXT           12
#define AU_SEL_SS_LC 3
#define AU_SEL_HLR_LC 4

#ifdef __cplusplus
}
#endif

#endif /* __MATH_ */

   
/********************************************************************30**

         End of file:     mat.h@@/main/13 - Fri Sep 16 02:50:13 2005

*********************************************************************31*/

   
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  aa    1. initial release

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.2          ---      sg   1. Added a mask for TCAP indicated error codes.
             ---      ssk  2. Added MAP Phase 2+ variant. Added Bind Confirm.

1.3          ---      ssk  1. Adjusted the sizes of the Lists.

1.4          ---      ssk  1. Adjusted the sizes of the Lists again.

1.5          ---      ssk  1. Phase 2+ Gpr release.                 

1.6          ---      ssk  1. TERM ATTEMPT AUTHORISED define        

             ---      ssk  2. User Over load check failed #define  
                              is defined along with other response codes.

             ---      ssk  2. Some of the integers were defined as U8.
                              they were defined as StrS with in the compile
                              time flag MAT_U8TOINT_CHANGE.

             ---      ssk  4. Added a new notice indication for the dialogue
                              allocation failure case.
 
             ---      ssk  5. Added a new notice indication for the gaurd   
                              expiry timer notification. 
 
             ---      ssk  6. Max. Invoke reched notice indication cause &  
                              Provider error are added.  
 
             ---      ssk  7. TCAP notice indication cause gives the cause  
                              For the message un-delivered in the SCCP 
                              layer. These causes are Or-ed with the 
                              SPCAUSE_MASK and sent in the MAT interface. 
                              New notice indication cause values for the 
                              message-not delivered causes are defined. 
   
             ---      jz   8. MA_MAX_CAMEL_DEST_NMB_LEN is added.
                           9. MA_MAX_INVOKE_RCHD value is corrected.

/main/7      ---      jie  1. update for MAP 1.5 release.
 
             ---      jie  2. changed conflicits values for dialogue
                              refuse reasons and provider abort reasons.

             ---      jie  3. Rolling Upgrade compliance.

             ---      jie  4. Change for 3.9.0 REL_99 support.

             ---      yz   5. Change MAT_MISTYPED_PARAM define.

             ---      jie  6. Change for MAP REL4 support without the MAPsec 
                              feature.

             ---      yz   7. Change for adding extCont in dlgPdu. 

/main/8      ---      jie  1. update for MAP 1.6 release.

             ---      yz   2. Change for adding phase 1 components in 
                              SubsOpt choice. 

             ---      jie  3. Change for 2002/09 rel99/rel4 release.

/main/9      ---      jie  Common file clearcase release.

/main/10     ---      jie  1. update for MAP 1.7 release.

             ---      jie  1. Phase-1 changes for June-03 specifications 
                              for release 4 & 5

             ---      jie  1. Phase-2 changes for June-03 specifications 
                              for release 4 & 5

             ---      ssk  4. Changes related to flexible scheme to  
                              tune the MTP3 priority and SCCP class.

/main/12     ---      cp   1. Removed MAT_INTF2 flag.
             ---      st   1. Macro for NULLP checks
                           2. CR688 for REL5
                           3. Code for PHAse 1 CUG
             ---      st   1. Added/Modified macro values required for
                              Rel5 Upgrade.
/main/13     ---     rbabu 1. update for MAP 2.3 release.
mat_h_001.main_13     st   1. Added new error code MAT_BAD_RSP_SEG_PARAM
           			        2. Added elemnts MAP+. 
         mat_h_002.main_13  dv   1. Corrected new error code MAT_BAD_RSP_SEG_PARAM
/main/13 mat_h_003.main_13  dm   1. New Error code MA_LSAP_DEL and MAT_LSAP_DEL
                                    is added. 
*********************************************************************91*/
