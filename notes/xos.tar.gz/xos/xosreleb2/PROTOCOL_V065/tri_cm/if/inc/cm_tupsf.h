/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     common TCAP user PSF module functions

     Type:     C include file

     Desc:     Defines required by common functions.

     File:     cm_tupsf.h
  
     Sid:      cm_tupsf.h@@/main/3 - Fri Dec 10 17:55:29 2004
 
     Prg:      jz

*********************************************************************21*/

#ifndef __CMTUPSFH__
#define __CMTUPSFH__ 

/* Cookie states */
#define CMTU_HAVE_COOKIE       1
#define CMTU_NO_COOKIE         2

/* Return types from ztWarmStart */
#define CMTU_OK           0x0    /* Everythign went fine                  */
#define CMTU_ERR          0x1    /* Error encountered                     */
#define CMTU_PEND         0x2    /* Operation is still not complete       */

/* Timer events */ 
#define CMTU_TMR_ACK      0x01   /* CS/WS ack timer                       */
#define CMTU_TMR_GRD      0x02   /* Guard Timer (for recovery)            */

/* Table types */

#define CMTU_NULL_TAB        0   /* reserved                              */ 
#define CMTU_UISAP_TAB       1   /* Upper SAP control block               */ 
#define CMTU_LISAP_TAB       2   /* Lower SAP control block               */
#define CMTU_ADDDLG_TAB      3   /* Dialogue control block                */
#define CMTU_MODDLG_TAB      4   /* Modifiy dialogue control block        */
#define CMTU_DELDLG_TAB      5   /* Delete dialogue control block         */
#define CMTU_CSWDLG_TAB      6   /* Controlled SwitchOver dlg control block */
#define CMTU_ADDINV_TAB      7   /* Invoke control block                  */
#define CMTU_MODINV_TAB      8   /* Delete Invoke control block           */
#define CMTU_DELINV_TAB      9   /* Delete Invoke control block           */
#define CMTU_CSWINV_TAB      10  /* Controlled SwitchOver inv control block */
#define CMTU_RTSEQ_TAB       11  /* Run Time Seq Number Control block     */
#define CMTU_RSET_TAB        12  /* RSET recovery control block           */
#define CMTU_PROTCB_TAB      13  /* Protocol control block                */
#define CMTU_PSFCB_TAB       14  /* Protocol control block                */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#define CMTU_VERINFO_TAB     15  /* Interface Version info                */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#define CMTU_WSDLG_TAB       16  /* dialogue control block at warmstart */
#define CMTU_WSINV_TAB       17  /* invoke control block at warmstart */

#define CMTU_MAXTABTYPE      18   /* Maximum number of table types         */

#define CMTU_INVLID_SIZE     0    /* Invild update structure size */

/* Control block types */
#define CMTU_PROT_CB    CMTU_PROTCB_TAB   /* Protocol control block    */ 
#define CMTU_PSF_CB     CMTU_PSFCB_TAB    /* PSF control block    */ 
#define CMTU_UISAP_CB   CMTU_UISAP_TAB    /* Upper SAP control block   */ 
#define CMTU_LISAP_CB   CMTU_LISAP_TAB    /* Lower SAP control block   */
#define CMTU_DLG_CB     CMTU_ADDDLG_TAB   /* Dialogue control block    */
#define CMTU_CSWDLG_CB  CMTU_CSWDLG_TAB   /* CS dialogue control block */
#define CMTU_INV_CB     CMTU_ADDINV_TAB   /* Invoke control block */
#define CMTU_CSWINV_CB  CMTU_CSWINV_TAB   /* CS invoke control block */
#define CMTU_RTSEQ_CB   CMTU_RTSEQ_TAB    /* Run Time SeqNumber Control block*/
#define CMTU_RSET_CB    CMTU_RSET_TAB     /* RSET recovery control block */
#define CMTU_WSDLG_CB   CMTU_WSDLG_TAB    /* WS dlg-cb */ 
#define CMTU_WSINV_CB   CMTU_WSINV_TAB    /* WS inv-cb */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#define CMTU_VERINFO_CB CMTU_VERINFO_TAB  /* Interface Version info */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */


/* Trace Message dicrection */
#define CMTU_BUF_TX         0x01    /* update message being tx by PSF     */
#define CMTU_BUF_RX         0x02    /* update message being rx by PSF     */

/* events from Layer Manager */

/* Event defines for update module must be different from portable MAP
 * defines, as portable MAP would pass the unknown events to update module.
 * At present 0xf0 - 0xff are kept reserved for MAP update module.
 */

#define EVTTUMILTUCFGREQ     0xF0    /* configuration request */ 
#define EVTTUMILTUCFGCFM     0xF1    /* configuration confirm */ 
#define EVTTUMILTUSTAREQ     0xF2    /* status request        */ 
#define EVTTUMILTUSTACFM     0xF3    /* status confirm        */ 
#define EVTTUMILTUCNTRLREQ   0xF4    /* control request       */ 
#define EVTTUMILTUCNTRLCFM   0xF5    /* control confirm       */ 
#define EVTTUMILTUSTAIND     0xF6    /* status indication     */ 
#define EVTTUMILTUSTSREQ     0xF7    /* statistics request    */ 
#define EVTTUMILTUSTSCFM     0xF8    /* statistics confirm    */ 
#define EVTTUMILTUTRCIND     0xF9    /* trace indication      */

/* events from peer PSF */

#define EVTZUPIDATREQ     0x10  /* peer data request       */
#define EVTZUPIDATCFM     0x11  /* peer data confirm       */
#define EVTZUSISCHREQ     0x30  /* self scheduling request */


#define MAXCMTUMI       2   /* Number of management interface */



/* Elmnt types */
#define CMTUGEN            0x41    /* General                               */
#define CMTUDIST           0x42    /* distribution parameter configuration  */
#define CMTURSET           0x43    /* Resource set specific                 */
#define CMTUSID            0x44    /* System Id                             */
#define CMTUGENCFG         0x45    /* General Configuration done */

/* Action types */
#define CMTU_AGO_ACT        0x00    /* Make resource set active              */
#define CMTU_AGO_SBY        0x01    /* Make resource set standby             */
#define CMTU_ADIS_PEER_SAP  0x02    /* Disable peer interface                */
#define CMTU_AWARMSTART     0x03    /* Start warmstart                       */
#define CMTU_ASYNCHRONIZE   0x04    /* Start peersync                        */
#define CMTU_ASHUTDOWN      0x05    /* Shutdown resource set                 */
#define CMTU_ARSET_STA      0x06    /* Resource set status                   */
#define CMTU_AENA           0x07    /* Enable                                */
#define CMTU_ADISIMM        0x08    /* Disable - immediately                 */
#define CMTU_AABORT         0x09    /* Abort ongoing operation               */
#define CMTU_ASTAT          0x0a    /* Status request                        */
#define CMTU_ADEL           0x0b    /* Delete element(keys for static dist.  */

/* Sub Action */
#define CMTU_SAUSTA         0x00    /* Enable unsolicited status ind         */
#define CMTU_SADBG          0x01    /* Debug prints                          */
#define CMTU_SATRC          0x02    /* Message trace                         */

#define CMTU_REASON_INT_FAILURE (LCM_REASON_LYR_SPECIFIC + 1)

#ifdef DEBUGP
#define CMTU_DBGMASK_PACK     (DBGMASK_LYR << 0)   /* pack mask   */
#define CMTU_DBGMASK_UNPACK   (DBGMASK_LYR << 1)   /* unpack mask */
#define CMTU_DBGMASK_INTERNAL (DBGMASK_LYR << 2)   /* internal mask */
#endif /* DEBUGP */

/* This is the size of the largest update structure. Modify if necessary */
#define CMTU_MAX_UPD_STRUCT_SIZE 1500 
/* status values for general configuration */
#define CMTU_GENCFG_DONE  1
#define CMTU_GENCFG_NDONE 0

/* Maximum control block entires in update structure */  
#define CMTU_MAX_SAP_UPD_ENT     8 /* Maximum number of SAPs entries      */
#define CMTU_MAX_DLG_UPD_ENT    16 /* Maximum number of dialogue entries  */
#define CMTU_MAX_INV_UPD_ENT    16 /* Maximum number of invoke entries    */

#define CMTU_MAX_RSET_TMRS   3   /* maximum numbers of rset timers        */


#define CMTU_FTHA_MAX_RSETS  1   /* Pure Fault Tolerant Max. Rsets        */ 
#define CMTUMAXTIMER         1   /* Maximum # of PSF timers               */
#define CMTUNUMENT           5   /* Timing queue elements                 */

/* debug macro */
#define CMTUDBGP(_msgClass, _arg) \
      DBGP(&tuCb->init, "CMTU", _msgClass, _arg)

/* error logging macro */

#define CMTULOGERRORPK(errCls, errCode, errVal, errDesc)                     \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,                \
                   __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

#define CMTULOGERRORUNPK(errCls, errCode, errVal, errDesc)                   \
        SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,                \
                   __FILE__, __LINE__, errCls, errCode, errVal, errDesc)

#define CMTU_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, (m)); \
    if (ret != ROK) \
    { \
        CMTULOGERRORPK(ERRCLS_ADD_RES, e, (ErrVal)ret, "SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

#define CMTU_IS_VALID_RSET(rsetId) \
 (((rsetId) ==  CMFTHA_RES_RSETID) && \
   (tuCb->rsetCbLst != NULLP)        && \
   (tuCb->rsetCbLst[(rsetId)] != NULLP))

#define CMTU_GET_DLGCB(_tuCbMap, _dlgCp) \
  {                           \
      _dlgCp   = ((PTR)_tuCbMap - (PTR)tuCb->offset); \
  }

#define CMTU_FREE_BUF(_mBuf) \
if (_mBuf != (Buffer *)NULLP) \
{\
   (Void)SPutMsg(_mBuf); \
/* cm_tupsf_h_001.main_3: Addition. Assignment to NULLP to prevent double deallocation scenarios. */	\
   _mBuf = NULLP;\
}

#ifndef TDS_FTHA_CUST_PKUNPK

/* point to trillum supplied function */
#define cmTuPkStructFn(tuCb, pst, tblType, size, cbPtr, mBuf) \
             cmTuPkStruct(tuCb, pst, size, (PTR)cbPtr, mBuf)
   /* point to trillum supplied function */

#define cmTuUnpkStructFn(tuCb, pst, tblType, size, cbPtr, mBuf) \
             cmTuUnpkStruct(tuCb, pst, size, (PTR)cbPtr, mBuf)

#endif /* TDS_FTHA_CUST_PKUNPK */

/* Error log */

#if (ERRCLASS & ERRCLS_DEBUG)
#define CMTULOGERROR_DEBUG(errCode, errVal, errDesc) \
        SLogError(tuCb->init.ent, tuCb->init.inst, \
                  tuCb->init.procId, \
                  __FILE__, __LINE__, ERRCLS_DEBUG, errCode, errVal, errDesc)
#else
#define CMTULOGERROR_DEBUG(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

#if (ERRCLASS & ERRCLS_INT_PAR)
#define CMTULOGERROR_INT_PAR(errCode, errVal, errDesc) \
        SLogError(tuCb->init.ent, tuCb->init.inst, \
                  tuCb->init.procId, \
                  __FILE__, __LINE__, ERRCLS_INT_PAR, errCode, errVal, errDesc)
#else
#define CMTULOGERROR_INT_PAR(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

#if (ERRCLASS & ERRCLS_ADD_RES)
#define CMTULOGERROR_ADD_RES(errCode, errVal, errDesc) \
        SLogError(tuCb->init.ent, tuCb->init.inst, \
                  tuCb->init.procId, \
                  __FILE__, __LINE__, ERRCLS_ADD_RES, errCode, errVal, errDesc)
#else
#define CMTULOGERROR_ADD_RES(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

#define   ECMTUBASE    000
#define   ECMTUXXX     (ECMTUBASE)

#define   ECMTU001      (ECMTUBASE +    1)    /*        cm_ptupsf.c: 265 */
#define   ECMTU002      (ECMTUBASE +    2)    /*        cm_ptupsf.c: 272 */
#define   ECMTU003      (ECMTUBASE +    3)    /*        cm_ptupsf.c: 279 */
#define   ECMTU004      (ECMTUBASE +    4)    /*        cm_ptupsf.c: 285 */
#define   ECMTU005      (ECMTUBASE +    5)    /*        cm_ptupsf.c: 291 */
#define   ECMTU006      (ECMTUBASE +    6)    /*        cm_ptupsf.c: 301 */
#define   ECMTU007      (ECMTUBASE +    7)    /*        cm_ptupsf.c: 342 */
#define   ECMTU008      (ECMTUBASE +    8)    /*        cm_ptupsf.c: 345 */
#define   ECMTU009      (ECMTUBASE +    9)    /*        cm_ptupsf.c: 348 */
#define   ECMTU010      (ECMTUBASE +   10)    /*        cm_ptupsf.c: 683 */
#define   ECMTU011      (ECMTUBASE +   11)    /*        cm_ptupsf.c: 688 */
#define   ECMTU012      (ECMTUBASE +   12)    /*        cm_ptupsf.c: 692 */
#define   ECMTU013      (ECMTUBASE +   13)    /*        cm_ptupsf.c: 696 */
#define   ECMTU014      (ECMTUBASE +   14)    /*        cm_ptupsf.c: 737 */
#define   ECMTU015      (ECMTUBASE +   15)    /*        cm_ptupsf.c: 746 */
#define   ECMTU016      (ECMTUBASE +   16)    /*        cm_ptupsf.c: 752 */
#define   ECMTU017      (ECMTUBASE +   17)    /*        cm_ptupsf.c: 755 */
#define   ECMTU018      (ECMTUBASE +   18)    /*        cm_ptupsf.c: 835 */
#define   ECMTU019      (ECMTUBASE +   19)    /*        cm_ptupsf.c: 844 */
#define   ECMTU020      (ECMTUBASE +   20)    /*        cm_ptupsf.c: 855 */
#define   ECMTU021      (ECMTUBASE +   21)    /*        cm_ptupsf.c: 898 */
#define   ECMTU022      (ECMTUBASE +   22)    /*        cm_ptupsf.c: 905 */
#define   ECMTU023      (ECMTUBASE +   23)    /*        cm_ptupsf.c: 907 */
#define   ECMTU024      (ECMTUBASE +   24)    /*        cm_ptupsf.c: 913 */
#define   ECMTU025      (ECMTUBASE +   25)    /*        cm_ptupsf.c: 918 */
#define   ECMTU026      (ECMTUBASE +   26)    /*        cm_ptupsf.c: 925 */
#define   ECMTU027      (ECMTUBASE +   27)    /*        cm_ptupsf.c: 928 */
#define   ECMTU028      (ECMTUBASE +   28)    /*        cm_ptupsf.c: 931 */
#define   ECMTU029      (ECMTUBASE +   29)    /*        cm_ptupsf.c: 976 */
#define   ECMTU030      (ECMTUBASE +   30)    /*        cm_ptupsf.c: 985 */
#define   ECMTU031      (ECMTUBASE +   31)    /*        cm_ptupsf.c: 991 */
#define   ECMTU032      (ECMTUBASE +   32)    /*        cm_ptupsf.c: 999 */
#define   ECMTU033      (ECMTUBASE +   33)    /*        cm_ptupsf.c:1002 */
#define   ECMTU034      (ECMTUBASE +   34)    /*        cm_ptupsf.c:1045 */
#define   ECMTU035      (ECMTUBASE +   35)    /*        cm_ptupsf.c:1051 */
#define   ECMTU036      (ECMTUBASE +   36)    /*        cm_ptupsf.c:1052 */
#define   ECMTU037      (ECMTUBASE +   37)    /*        cm_ptupsf.c:1053 */
#define   ECMTU038      (ECMTUBASE +   38)    /*        cm_ptupsf.c:1054 */
#define   ECMTU039      (ECMTUBASE +   39)    /*        cm_ptupsf.c:1055 */
#define   ECMTU040      (ECMTUBASE +   40)    /*        cm_ptupsf.c:1056 */
#define   ECMTU041      (ECMTUBASE +   41)    /*        cm_ptupsf.c:1057 */
#define   ECMTU042      (ECMTUBASE +   42)    /*        cm_ptupsf.c:1058 */
#define   ECMTU043      (ECMTUBASE +   43)    /*        cm_ptupsf.c:1059 */
#define   ECMTU044      (ECMTUBASE +   44)    /*        cm_ptupsf.c:1061 */
#define   ECMTU045      (ECMTUBASE +   45)    /*        cm_ptupsf.c:1067 */
#define   ECMTU046      (ECMTUBASE +   46)    /*        cm_ptupsf.c:1075 */
#define   ECMTU047      (ECMTUBASE +   47)    /*        cm_ptupsf.c:1078 */
#define   ECMTU048      (ECMTUBASE +   48)    /*        cm_ptupsf.c:1122 */
#define   ECMTU049      (ECMTUBASE +   49)    /*        cm_ptupsf.c:1125 */
#define   ECMTU050      (ECMTUBASE +   50)    /*        cm_ptupsf.c:1127 */
#define   ECMTU051      (ECMTUBASE +   51)    /*        cm_ptupsf.c:1130 */
#define   ECMTU052      (ECMTUBASE +   52)    /*        cm_ptupsf.c:1174 */
#define   ECMTU053      (ECMTUBASE +   53)    /*        cm_ptupsf.c:1185 */
#define   ECMTU054      (ECMTUBASE +   54)    /*        cm_ptupsf.c:1187 */
#define   ECMTU055      (ECMTUBASE +   55)    /*        cm_ptupsf.c:1189 */
#define   ECMTU056      (ECMTUBASE +   56)    /*        cm_ptupsf.c:1192 */
#define   ECMTU057      (ECMTUBASE +   57)    /*        cm_ptupsf.c:1239 */
#define   ECMTU058      (ECMTUBASE +   58)    /*        cm_ptupsf.c:1243 */
#define   ECMTU059      (ECMTUBASE +   59)    /*        cm_ptupsf.c:1244 */
#define   ECMTU060      (ECMTUBASE +   60)    /*        cm_ptupsf.c:1245 */
#define   ECMTU061      (ECMTUBASE +   61)    /*        cm_ptupsf.c:1246 */
#define   ECMTU062      (ECMTUBASE +   62)    /*        cm_ptupsf.c:1247 */
#define   ECMTU063      (ECMTUBASE +   63)    /*        cm_ptupsf.c:1248 */
#define   ECMTU064      (ECMTUBASE +   64)    /*        cm_ptupsf.c:1249 */
#define   ECMTU065      (ECMTUBASE +   65)    /*        cm_ptupsf.c:1250 */
#define   ECMTU066      (ECMTUBASE +   66)    /*        cm_ptupsf.c:1251 */
#define   ECMTU067      (ECMTUBASE +   67)    /*        cm_ptupsf.c:1253 */
#define   ECMTU068      (ECMTUBASE +   68)    /*        cm_ptupsf.c:1254 */
#define   ECMTU069      (ECMTUBASE +   69)    /*        cm_ptupsf.c:1255 */
#define   ECMTU070      (ECMTUBASE +   70)    /*        cm_ptupsf.c:1256 */
#define   ECMTU071      (ECMTUBASE +   71)    /*        cm_ptupsf.c:1257 */
#define   ECMTU072      (ECMTUBASE +   72)    /*        cm_ptupsf.c:1258 */
#define   ECMTU073      (ECMTUBASE +   73)    /*        cm_ptupsf.c:1259 */
#define   ECMTU074      (ECMTUBASE +   74)    /*        cm_ptupsf.c:1265 */
#define   ECMTU075      (ECMTUBASE +   75)    /*        cm_ptupsf.c:1269 */
#define   ECMTU076      (ECMTUBASE +   76)    /*        cm_ptupsf.c:1275 */
#define   ECMTU077      (ECMTUBASE +   77)    /*        cm_ptupsf.c:1325 */
#define   ECMTU078      (ECMTUBASE +   78)    /*        cm_ptupsf.c:1328 */
#define   ECMTU079      (ECMTUBASE +   79)    /*        cm_ptupsf.c:1458 */
#define   ECMTU080      (ECMTUBASE +   80)    /*        cm_ptupsf.c:1671 */
#define   ECMTU081      (ECMTUBASE +   81)    /*        cm_ptupsf.c:1675 */
#define   ECMTU082      (ECMTUBASE +   82)    /*        cm_ptupsf.c:1679 */
#define   ECMTU083      (ECMTUBASE +   83)    /*        cm_ptupsf.c:1725 */
#define   ECMTU084      (ECMTUBASE +   84)    /*        cm_ptupsf.c:1726 */
#define   ECMTU085      (ECMTUBASE +   85)    /*        cm_ptupsf.c:1732 */
#define   ECMTU086      (ECMTUBASE +   86)    /*        cm_ptupsf.c:1779 */
#define   ECMTU087      (ECMTUBASE +   87)    /*        cm_ptupsf.c:1788 */
#define   ECMTU088      (ECMTUBASE +   88)    /*        cm_ptupsf.c:1885 */
#define   ECMTU089      (ECMTUBASE +   89)    /*        cm_ptupsf.c:1888 */
#define   ECMTU090      (ECMTUBASE +   90)    /*        cm_ptupsf.c:1891 */
#define   ECMTU091      (ECMTUBASE +   91)    /*        cm_ptupsf.c:1898 */
#define   ECMTU092      (ECMTUBASE +   92)    /*        cm_ptupsf.c:1901 */
#define   ECMTU093      (ECMTUBASE +   93)    /*        cm_ptupsf.c:1908 */
#define   ECMTU094      (ECMTUBASE +   94)    /*        cm_ptupsf.c:1913 */
#define   ECMTU095      (ECMTUBASE +   95)    /*        cm_ptupsf.c:1964 */
#define   ECMTU096      (ECMTUBASE +   96)    /*        cm_ptupsf.c:1967 */
#define   ECMTU097      (ECMTUBASE +   97)    /*        cm_ptupsf.c:1976 */
#define   ECMTU098      (ECMTUBASE +   98)    /*        cm_ptupsf.c:1983 */
#define   ECMTU099      (ECMTUBASE +   99)    /*        cm_ptupsf.c:2034 */
#define   ECMTU100      (ECMTUBASE +  100)    /*        cm_ptupsf.c:2036 */
#define   ECMTU101      (ECMTUBASE +  101)    /*        cm_ptupsf.c:2043 */
#define   ECMTU102      (ECMTUBASE +  102)    /*        cm_ptupsf.c:2045 */
#define   ECMTU103      (ECMTUBASE +  103)    /*        cm_ptupsf.c:2046 */
#define   ECMTU104      (ECMTUBASE +  104)    /*        cm_ptupsf.c:2048 */
#define   ECMTU105      (ECMTUBASE +  105)    /*        cm_ptupsf.c:2050 */
#define   ECMTU106      (ECMTUBASE +  106)    /*        cm_ptupsf.c:2052 */
#define   ECMTU107      (ECMTUBASE +  107)    /*        cm_ptupsf.c:2054 */
#define   ECMTU108      (ECMTUBASE +  108)    /*        cm_ptupsf.c:2056 */
#define   ECMTU109      (ECMTUBASE +  109)    /*        cm_ptupsf.c:2058 */
#define   ECMTU110      (ECMTUBASE +  110)    /*        cm_ptupsf.c:2060 */
#define   ECMTU111      (ECMTUBASE +  111)    /*        cm_ptupsf.c:2066 */
#define   ECMTU112      (ECMTUBASE +  112)    /*        cm_ptupsf.c:2118 */
#define   ECMTU113      (ECMTUBASE +  113)    /*        cm_ptupsf.c:2120 */
#define   ECMTU114      (ECMTUBASE +  114)    /*        cm_ptupsf.c:2122 */
#define   ECMTU115      (ECMTUBASE +  115)    /*        cm_ptupsf.c:2171 */
#define   ECMTU116      (ECMTUBASE +  116)    /*        cm_ptupsf.c:2173 */
#define   ECMTU117      (ECMTUBASE +  117)    /*        cm_ptupsf.c:2175 */
#define   ECMTU118      (ECMTUBASE +  118)    /*        cm_ptupsf.c:2177 */

#endif /* __CMTUPSFH__ */


/********************************************************************30**
  
         End of file:     cm_tupsf.h@@/main/3 - Fri Dec 10 17:55:29 2004
   
*********************************************************************31*/


/********************************************************************40**

   Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

   Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      jz   1. initial release.
/main/3      ---      kk   1. updation for PSF-CAP  
cm_tupsf_h_001.main_3 st   1. Assignment of pointer to NULLP to avoid
                              double deallocation scnearios.
*********************************************************************91*/
