/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name     layer management interface - map     
  
     Type:    C Include file 
  
     Desc:    Defines required by the layer management service user.  
  
     File:    lma.h
  
     Sid:      lma.h@@/main/2 - Fri Sep 16 02:49:21 2005
  
     Prg:     ssk
  
*********************************************************************21*/

#ifndef __LMAH__
#define __LMAH__

#ifdef __cplusplus
extern "C" {
#endif


/* Interface version number  */
#ifdef LMAV1
#ifdef LMAIFVER
#undef LMAIFVER
#endif  /* LMAIFVER */
#define LMAIFVER               0x0100
#endif  /* LMAV1 */

/* Interface version number  */
#ifdef LMAV2
#ifdef LMAIFVER
#undef LMAIFVER
#endif  /* LMAIFVER */
#define LMAIFVER               0x0200
#endif  /* LMAV2 */

/* Interface version number  */
#ifdef LMAV3
#ifdef LMAIFVER
#undef LMAIFVER
#endif  /* LMAIFVER */
#define LMAIFVER               0x0300
#endif  /* LMAV2 */


#ifndef LMAIFVER
#define LMAIFVER 0x0100
#endif

/* number of interfaces allowed */
#define MAXMAMI         2               /* Management interface */

#define    MA_MAX_SWITCH       2       /* MAP switch */
#define    LMA_SW_GSM_0902     0       /* MAP for GSM 0902 */

/* MAP defines for SAP */
#define    STMATGEN            1       /* General configuration */
#define    STMATSAP            2       /* MAP SAP configuration */
#define    STGRSPSAP           100     /* Group of MAP-GSM lower SAPs */
#define    STGRSUSAP           101     /* Group of MAP-GSM upper SAPs */
#define    STMATPG             3       /* General configuration */
#define    STMATPP             4       /* MAP SAP configuration */
#define    STMATSA             5       /* General configuration */
/* ma001.203: Addition. Adding the macro value for lowerSap */
#define    STMATLSAP           6       /* MAP Lower Sap cntorl */

/* LMAV3 */
/* Audit control block types */
#define LMA_AUDIT_ALL_DLG   1        /* Delete all unused dialogues */
#define LMA_AUDIT_ALL_INV   2        /* Delete all unused Invokes */
#define LMA_AUDIT_PAR_DLG   3        /* Delete some of the unused Dialogues */
#define LMA_AUDIT_PAR_INV   4        /* Delete some of the unused Invokes */
#define LMA_AUDIT_PAR_CB    5        /* Delete some of the unused Dlgs/Invs */
#define LMA_AUDIT_ALL_CB    6        /* Delete All unused Dlgs/Invs */

/* Map Version */
#define    LMA_VER1             1         /* MAP version1 */
#define    LMA_VER2             2         /* MAP version 2 */
#define    LMA_VER2P            3         /* MAP version 2P */
#define    LMA_VER3             LMA_VER2P /* MAP version 3 */
#define    LMA_VER4             4         /* MAP version 4 */
#define    LMA_VER1AND2         16        /* MAP version 1 and 2 */
#define    LMA_VER1AND2P        32        /* MAP version 1 and 2P */
#define    LMA_VER2AND2P        64        /* MAP version 2 and 2P */
#define    LMA_VER1AND2AND2P    65        /* MAP version 1 and 2 and 2P */
#define    LMA_VER2PAND4        66        /* MAP version 2P and 4 */
#define    LMA_VER2AND2PAND4    67        /* MAP version 2 and 2P and 4 */
#define    LMA_VER_ALL          128       /* All versions */


#define IS_EQUAL_VER1(x)  ((x==LMA_VER1)         || \
                           (x==LMA_VER1AND2)     || \
                           (x==LMA_VER_ALL)      || \
                           (x==LMA_VER1AND2P)    || \
                           (x==LMA_VER1AND2AND2P)   \
                          )
 
#define IS_EQUAL_VER2(x)  ((x==LMA_VER2)           || \
                           (x==LMA_VER1AND2)       || \
                           (x==LMA_VER_ALL)        || \
                           (x==LMA_VER1AND2AND2P)  || \
                           (x==LMA_VER2AND2PAND4)  || \
                           (x==LMA_VER2AND2P)         \
                          )

#define IS_EQUAL_VER2P(x)  ((x==LMA_VER2P)         || \
                           (x==LMA_VER2AND2P)      || \
                           (x==LMA_VER_ALL)        || \
                           (x==LMA_VER2PAND4)      || \
                           (x==LMA_VER1AND2AND2P)  || \
                           (x==LMA_VER2AND2PAND4)  || \
                           (x==LMA_VER1AND2P)         \
                          )

#define IS_EQUAL_VER4(x)  ((x==LMA_VER4)           || \
                           (x==LMA_VER2PAND4)      || \
                           (x==LMA_VER2AND2PAND4)  || \
                           (x==LMA_VER_ALL)           \
                          )

/* Message priority used by MTP3 */
#define MA_PRIO              0x00     /* Priority 0 */
#define MA_PRI1              0x01     /* Priority 1 */
#define MA_PRI2              0x02     /* Priority 2 */
#define MA_PRI3              0x03     /* Priority 3 */

/* Return or error or drop on error */
#define LMA_REC_ROE          0x08      /* Return on Error */
#define LMA_REC_DOE          0x00      /* Drop on Error */

/* SCCP protocol class */
#define PCLASS0              0x00      /* 0 - no sequencing */
#define PCLASS1              0x01      /* 1 - sequencing */

/* size of Application Context name string */
#define MA_MAX_APPN_STRING      20
#define MA_MAX_OPR              100

/* unsolicited status status code */

#define LMA_BAD_SAPID           1       /* bad sap id */                
#define LMAT_OUT_OF_RSRS        2       /* out of resources */          
#define LMA_UBND_PROCESSED      3       /* Unbind request from upper user */
#define LMA_BAD_SAP_STATE       4       /* bad sap state */             
#define LMA_CFG_BAD_PARAM       5       /* Bad parameters */            
#define LMA_CFG_DUP             6       /* Duplicate configuration */   
#define LMA_CFG_OK              7       /* Configuartion Ok */          
#define LMA_BAD_PLMN_PARAM      8       /* Bad PLMN parameters */            
#define LMA_BND_PROCESSED       9       /* Bind request from upper user */
/* Configuration confirm reasons */

#define LMA_REASON_INV_PLMN            0x80 /* invalid PLMN Id */
#define LMA_REASON_INV_FB_IND          0x81 /* invalid Fall back indicator */
#define LMA_REASON_MAX_MAPSEC_OPR_CMPS 0x82 /* MAPsec opr comp exceeded */
#define LMA_REASON_INV_OPR_CMP_TYPE    0x82 /* Invalid opr Comp type */
#define LMA_REASON_INV_SEC_PLMN_ONLY   0x84 /* Invilid secPlmnsOnly parameter*/

#define LMA_REASON_PG_MEM_NOAVAIL      0x85 /* PG memory allocation fail */
#define LMA_REASON_PP_MEM_NOAVAIL      0x86 /* PP memory allocation fail */
#define LMA_REASON_SA_MEM_NOAVAIL      0x87 /* SA memory allocation fail */
#define LMA_REASON_PG_INIT_FAIL        0x88 /* PG table initialization fail */
#define LMA_REASON_PP_INIT_FAIL        0x89 /* PP table initialization fail */

#define LMA_REASON_INV_NEID_LENGTH     0x8A /* invalid NE-ID size */
#define LMA_REASON_INV_NEID            0x8B /* invalid NE-ID */
#define LMA_REASON_INV_PGI             0x8C /* invalid PGI */
#define LMA_REASON_INV_AC              0x8D /* invalid AC */
#define LMA_REASON_INV_AC_VERSION      0x8E /* invalid Ac version */
#define LMA_REASON_INV_PG_ENTRIES      0x8F /* invalid PG entry */
#define LMA_REASON_INV_OPERATION       0x90 /* invalid operation */
#define LMA_REASON_INV_AC_OPERATION    0x91 /* invalid operation within AC */
#define LMA_REASON_INV_PPID            0x92 /* invalid pp identifier */
#define LMA_REASON_INV_PPRI            0x93 /* invalid pp revision identifier*/
#define LMA_REASON_INV_PPI             0x94 /* invalid pp Indicator */

#define LMA_REASON_INV_MIA             0x95 /* invalid Sec MIA */
#define LMA_REASON_INV_MEA             0x96 /* invalid Sec MEA */
#define LMA_REASON_INV_MIK             0x97 /* invalid Sec MIK */
#define LMA_REASON_INV_MEK             0x98 /* invalid Sec MEK */
#define LMA_REASON_INV_PLMN_NMB        0x99 /* invalid plmn number */
#define LMA_REASON_INV_SPI             0x9A /* SPI mismatch */

#define LMA_REASON_PG_TABLE_EXCEEDED   0xA0 /* PG table full */
#define LMA_REASON_PP_TABLE_EXCEEDED   0xA1 /* PP table full */
#define LMA_REASON_SA_TABLE_EXCEEDED   0xA2 /* SA table full */
#define LMA_REASON_OPR_CMP_EXCEEDED    0xA3 /* operation comp table full */
#define LMA_REASON_OPR_CMPS_MISSING    0xA4 /* operation comp missing */
#define LMA_REASON_MAX_PLMN            LMA_REASON_SA_TABLE_EXCEEDED 
#define LMA_REASON_INV_PLMN_164        0xA5 /* invalid E.164 number */

/* Control confirm reasons */
#define LMA_REASON_SOFT_DEL_FAIL       0x9B /* soft deletion fail */
#define LMA_REASON_INV_PLMN_DEL_TYPE   0x9C /* Invalid PLMN deletion type */



/* defines for Trace indication */

#define LMA_MAX_TRC_LEN         256     /* Maximum trace length */
#define LMA_DATA_TXED           1       /* MAP Message transmitted */
#define LMA_CMP_TXED            2       /* MAP Message transmitted */
#define LMA_DATA_RECVD          3       /* MAP Message received */
#define LMA_CMP_RECVD           4       /* MAP Message received */


/* Event Codes */

#define MA_EVTLMACFGREQ     0x3c             /* Configuration request */
#define MA_EVTLMACFGCFM     0x3d             /* Configuration request */
#define MA_EVTLMASTAREQ     0x40             /* Status request */
#define MA_EVTLMASTACFM     0x41             /* Status confirm */
#define MA_EVTLMASTAIND     0x42             /* Status indication */
#define MA_EVTLMASTSREQ     0x44             /* Statistics request */
#define MA_EVTLMASTSCFM     0x45             /* Statistics confirm */
#define MA_EVTLMATRCIND     0x48             /* Trace indication */
#define MA_EVTLMACNTRLREQ   0x4c             /* Control request */
#define MA_EVTLMACNTRLCFM   0x4d             /* Control request */


/* debug masks - layer specific */
#define LMA_DBGMASK_GEN    (DBGMASK_LYR << 0)   /* General */
#define LMA_DBGMASK_UI     (DBGMASK_LYR << 1)   /* upper interface */
#define LMA_DBGMASK_LI     (DBGMASK_LYR << 2)   /* lower interface */
#define MA_DBGMASK_ENCODE  (DBGMASK_LYR << 3)   /* Element encode */
#define MA_DBGMASK_DECODE  (DBGMASK_LYR << 4)   /* Element decode */
#define MA_DBGMASK_SKIP    (DBGMASK_LYR << 5)   /* Element skip   */
/* MAPsec related debug masks */
#define MA_DBGMASK_SEC_INIT  (DBGMASK_LYR << 6)   /* Element encode */
#define MA_DBGMASK_SEC_RESP  (DBGMASK_LYR << 7)   /* Element decode */
#define MA_DBGMASK_SEC_PROT  (DBGMASK_LYR << 8)   /* Element skip   */
#define MA_DBGMASK_SEC_EXTR  (DBGMASK_LYR << 9)   /* Element skip   */

/* interface alarms */
#define LMA_EVENT_ALLOC_DLGID_FAIL  LCM_EVENT_LYR_SPECIFIC + 1
#define LMA_EVENT_UBND_PROCESSED    LCM_EVENT_LYR_SPECIFIC + 2
#define LMA_EVENT_DLGCB_ALLOC_FAIL  LCM_EVENT_LYR_SPECIFIC + 3
#define LMA_EVENT_INVCB_ALLOC_FAIL  LCM_EVENT_LYR_SPECIFIC + 4
#define LMA_EVENT_BND_PROCESSED     LCM_EVENT_LYR_SPECIFIC + 5


/* MAPsec specific alarm events */
#define LMA_EVENT_MAPSEC_INITIATOR  LCM_EVENT_LYR_SPECIFIC + 5
#define LMA_EVENT_MAPSEC_RESPONDER  LCM_EVENT_LYR_SPECIFIC + 6
#define LMA_EVENT_ALLOC_PLMNCB_FAIL LCM_EVENT_LYR_SPECIFIC + 7
#define LMA_EVENT_ALLOC_PPCB_FAIL   LCM_EVENT_LYR_SPECIFIC + 8

/* MAPsec specific alarm causes */
#define LMA_CAUSE_INV_DST_PLMN      LCM_CAUSE_LYR_SPECIFIC + 1
#define LMA_CAUSE_INV_SRC_PLMN      LCM_CAUSE_LYR_SPECIFIC + 2
#define LMA_CAUSE_INV_SPI_ATMPT     LCM_CAUSE_LYR_SPECIFIC + 3
#define LMA_CAUSE_INV_SEC_OPEN      LCM_CAUSE_LYR_SPECIFIC + 4
#define LMA_CAUSE_INV_UNSEC_OPEN    LCM_CAUSE_LYR_SPECIFIC + 5
#define LMA_CAUSE_PROT_FAIL         LCM_CAUSE_LYR_SPECIFIC + 6
#define LMA_CAUSE_EXTRACT_FAIL      LCM_CAUSE_LYR_SPECIFIC + 7
#define LMA_CAUSE_TVP_CHK_FAIL      LCM_CAUSE_LYR_SPECIFIC + 8
#define LMA_CAUSE_INV_SEC_OPR       LCM_CAUSE_LYR_SPECIFIC + 9
#define LMA_CAUSE_INV_UNSEC_OPR     LCM_CAUSE_LYR_SPECIFIC + 10
#define LMA_CAUSE_INV_ORIG_CMP      LCM_CAUSE_LYR_SPECIFIC + 11
#define LMA_CAUSE_INV_PROT_MODE     LCM_CAUSE_LYR_SPECIFIC + 12
#define LMA_CAUSE_INV_PROT_MODE     LCM_CAUSE_LYR_SPECIFIC + 12
#define LMA_CAUSE_SA_EXPIRED        LCM_CAUSE_LYR_SPECIFIC + 13


#define LMA_EVT_301       LMA_EVENT_ALLOC_DLGID_FAIL
#define LMA_EVT_304       LMA_EVENT_DLGCB_ALLOC_FAIL 
#define LMA_EVT_305       LMA_EVENT_INVCB_ALLOC_FAIL

#define  OLD   0
#define  NEW   1


#define MA_UNUSED 0

#define LMA_NEID_SIZE      6   /* bytes in NEID */
#define LMA_PLMNID_SIZE   6    /* bytes in PLMN */

#define LMA_MAX_SEC_COMPS 40   /* MAPsec operation components table */

#define LMA_MAX_PG_TUPLES 20   /* protection group tuple size */
#define LMA_MAX_SA_PLMNS  0x8f /* MAPsec plmn size */
#define LMA_SEC_MEK_SIZE  16   /* protection group tuple size */
#define LMA_SEC_MIK_SIZE  16   /* MAPsec plmn size */
/* Protection Profiles */
#define LMA_PP_A  1   /* Protection Profile A */
#define LMA_PP_B  2   /* Protection Profile B */
#define LMA_PP_C  3   /* Protection Profile C */
#define LMA_PP_D  4   /* Protection Profile D */
#define LMA_PP_E  5   /* Protection Profile E */



/* error codes */
#define   ERRLMA       0

#define   ELMA001      (ERRLMA +    1)    /*        lma.c:1407 */
#define   ELMA002      (ERRLMA +    2)    /*        lma.c:1408 */
#define   ELMA003      (ERRLMA +    3)    /*        lma.c:1409 */
#define   ELMA004      (ERRLMA +    4)    /*        lma.c:1410 */
#define   ELMA005      (ERRLMA +    5)    /*        lma.c:1411 */
#define   ELMA006      (ERRLMA +    6)    /*        lma.c:1412 */
#define   ELMA007      (ERRLMA +    7)    /*        lma.c:1414 */
#define   ELMA008      (ERRLMA +    8)    /*        lma.c:1415 */
#define   ELMA009      (ERRLMA +    9)    /*        lma.c:1418 */
#define   ELMA010      (ERRLMA +   10)    /*        lma.c:1421 */
#define   ELMA011      (ERRLMA +   11)    /*        lma.c:1423 */
#define   ELMA012      (ERRLMA +   12)    /*        lma.c:1425 */
#define   ELMA013      (ERRLMA +   13)    /*        lma.c:1466 */
#define   ELMA014      (ERRLMA +   14)    /*        lma.c:1467 */
#define   ELMA015      (ERRLMA +   15)    /*        lma.c:1470 */
#define   ELMA016      (ERRLMA +   16)    /*        lma.c:1474 */
#define   ELMA017      (ERRLMA +   17)    /*        lma.c:1476 */
#define   ELMA018      (ERRLMA +   18)    /*        lma.c:1477 */
#define   ELMA019      (ERRLMA +   19)    /*        lma.c:1478 */
#define   ELMA020      (ERRLMA +   20)    /*        lma.c:1479 */
#define   ELMA021      (ERRLMA +   21)    /*        lma.c:1481 */
#define   ELMA022      (ERRLMA +   22)    /*        lma.c:1482 */
#define   ELMA023      (ERRLMA +   23)    /*        lma.c:1483 */
#define   ELMA024      (ERRLMA +   24)    /*        lma.c:1484 */
#define   ELMA025      (ERRLMA +   25)    /*        lma.c:1485 */
#define   ELMA026      (ERRLMA +   26)    /*        lma.c:1486 */
#define   ELMA027      (ERRLMA +   27)    /*        lma.c:1487 */
#define   ELMA028      (ERRLMA +   28)    /*        lma.c:1488 */
#define   ELMA029      (ERRLMA +   29)    /*        lma.c:1489 */
#define   ELMA030      (ERRLMA +   30)    /*        lma.c:1549 */
#define   ELMA031      (ERRLMA +   31)    /*        lma.c:1550 */
#define   ELMA032      (ERRLMA +   32)    /*        lma.c:1558 */
#define   ELMA033      (ERRLMA +   33)    /*        lma.c:1559 */
#define   ELMA034      (ERRLMA +   34)    /*        lma.c:1562 */
#define   ELMA035      (ERRLMA +   35)    /*        lma.c:1563 */
#define   ELMA036      (ERRLMA +   36)    /*        lma.c:1565 */
#define   ELMA037      (ERRLMA +   37)    /*        lma.c:1567 */
#define   ELMA038      (ERRLMA +   38)    /*        lma.c:1568 */
#define   ELMA039      (ERRLMA +   39)    /*        lma.c:1620 */
#define   ELMA040      (ERRLMA +   40)    /*        lma.c:1621 */
#define   ELMA041      (ERRLMA +   41)    /*        lma.c:1622 */
#define   ELMA042      (ERRLMA +   42)    /*        lma.c:1625 */
#define   ELMA043      (ERRLMA +   43)    /*        lma.c:1628 */
#define   ELMA044      (ERRLMA +   44)    /*        lma.c:1679 */
#define   ELMA045      (ERRLMA +   45)    /*        lma.c:1683 */
#define   ELMA046      (ERRLMA +   46)    /*        lma.c:1684 */
#define   ELMA047      (ERRLMA +   47)    /*        lma.c:1685 */
#define   ELMA048      (ERRLMA +   48)    /*        lma.c:1686 */
#define   ELMA049      (ERRLMA +   49)    /*        lma.c:1687 */
#define   ELMA050      (ERRLMA +   50)    /*        lma.c:1695 */
#define   ELMA051      (ERRLMA +   51)    /*        lma.c:1696 */
#define   ELMA052      (ERRLMA +   52)    /*        lma.c:1697 */
#define   ELMA053      (ERRLMA +   53)    /*        lma.c:1698 */
#define   ELMA054      (ERRLMA +   54)    /*        lma.c:1700 */
#define   ELMA055      (ERRLMA +   55)    /*        lma.c:1701 */
#define   ELMA056      (ERRLMA +   56)    /*        lma.c:1702 */
#define   ELMA057      (ERRLMA +   57)    /*        lma.c:1703 */
#define   ELMA058      (ERRLMA +   58)    /*        lma.c:1705 */
#define   ELMA059      (ERRLMA +   59)    /*        lma.c:1706 */
#define   ELMA060      (ERRLMA +   60)    /*        lma.c:1707 */
#define   ELMA061      (ERRLMA +   61)    /*        lma.c:1708 */
#define   ELMA062      (ERRLMA +   62)    /*        lma.c:1709 */
#define   ELMA063      (ERRLMA +   63)    /*        lma.c:1710 */
#define   ELMA064      (ERRLMA +   64)    /*        lma.c:1721 */
#define   ELMA065      (ERRLMA +   65)    /*        lma.c:1724 */
#define   ELMA066      (ERRLMA +   66)    /*        lma.c:1728 */
#define   ELMA067      (ERRLMA +   67)    /*        lma.c:1730 */
#define   ELMA068      (ERRLMA +   68)    /*        lma.c:1732 */
#define   ELMA069      (ERRLMA +   69)    /*        lma.c:1733 */
#define   ELMA070      (ERRLMA +   70)    /*        lma.c:1735 */
#define   ELMA071      (ERRLMA +   71)    /*        lma.c:1736 */
#define   ELMA072      (ERRLMA +   72)    /*        lma.c:1737 */
#define   ELMA073      (ERRLMA +   73)    /*        lma.c:1738 */
#define   ELMA074      (ERRLMA +   74)    /*        lma.c:1739 */
#define   ELMA075      (ERRLMA +   75)    /*        lma.c:1740 */
#define   ELMA076      (ERRLMA +   76)    /*        lma.c:1741 */
#define   ELMA077      (ERRLMA +   77)    /*        lma.c:1742 */
#define   ELMA078      (ERRLMA +   78)    /*        lma.c:1743 */
#define   ELMA079      (ERRLMA +   79)    /*        lma.c:1744 */
#define   ELMA080      (ERRLMA +   80)    /*        lma.c:1745 */
#define   ELMA081      (ERRLMA +   81)    /*        lma.c:1747 */
#define   ELMA082      (ERRLMA +   82)    /*        lma.c:1748 */
#define   ELMA083      (ERRLMA +   83)    /*        lma.c:1755 */
#define   ELMA084      (ERRLMA +   84)    /*        lma.c:1757 */
#define   ELMA085      (ERRLMA +   85)    /*        lma.c:1760 */
#define   ELMA086      (ERRLMA +   86)    /*        lma.c:1762 */
#define   ELMA087      (ERRLMA +   87)    /*        lma.c:1766 */
#define   ELMA088      (ERRLMA +   88)    /*        lma.c:1768 */
#define   ELMA089      (ERRLMA +   89)    /*        lma.c:1770 */
#define   ELMA090      (ERRLMA +   90)    /*        lma.c:1771 */
#define   ELMA091      (ERRLMA +   91)    /*        lma.c:1772 */
#define   ELMA092      (ERRLMA +   92)    /*        lma.c:1774 */
#define   ELMA093      (ERRLMA +   93)    /*        lma.c:1776 */
#define   ELMA094      (ERRLMA +   94)    /*        lma.c:1777 */
#define   ELMA095      (ERRLMA +   95)    /*        lma.c:1778 */
#define   ELMA096      (ERRLMA +   96)    /*        lma.c:1779 */
#define   ELMA097      (ERRLMA +   97)    /*        lma.c:1780 */
#define   ELMA098      (ERRLMA +   98)    /*        lma.c:1781 */
#define   ELMA099      (ERRLMA +   99)    /*        lma.c:1782 */
#define   ELMA100      (ERRLMA +  100)    /*        lma.c:1783 */
#define   ELMA101      (ERRLMA +  101)    /*        lma.c:1784 */
#define   ELMA102      (ERRLMA +  102)    /*        lma.c:1795 */
#define   ELMA103      (ERRLMA +  103)    /*        lma.c:1796 */
#define   ELMA104      (ERRLMA +  104)    /*        lma.c:1797 */
#define   ELMA105      (ERRLMA +  105)    /*        lma.c:1799 */
#define   ELMA106      (ERRLMA +  106)    /*        lma.c:1800 */
#define   ELMA107      (ERRLMA +  107)    /*        lma.c:1801 */
#define   ELMA108      (ERRLMA +  108)    /*        lma.c:1806 */
#define   ELMA109      (ERRLMA +  109)    /*        lma.c:1807 */
#define   ELMA110      (ERRLMA +  110)    /*        lma.c:1808 */
#define   ELMA111      (ERRLMA +  111)    /*        lma.c:1820 */
#define   ELMA112      (ERRLMA +  112)    /*        lma.c:1821 */
#define   ELMA113      (ERRLMA +  113)    /*        lma.c:1829 */
#define   ELMA114      (ERRLMA +  114)    /*        lma.c:1831 */
#define   ELMA115      (ERRLMA +  115)    /*        lma.c:1832 */
#define   ELMA116      (ERRLMA +  116)    /*        lma.c:1840 */
#define   ELMA117      (ERRLMA +  117)    /*        lma.c:1842 */
#define   ELMA118      (ERRLMA +  118)    /*        lma.c:1843 */
#define   ELMA119      (ERRLMA +  119)    /*        lma.c:1844 */
#define   ELMA120      (ERRLMA +  120)    /*        lma.c:1845 */
#define   ELMA121      (ERRLMA +  121)    /*        lma.c:1846 */
#define   ELMA122      (ERRLMA +  122)    /*        lma.c:1848 */
#define   ELMA123      (ERRLMA +  123)    /*        lma.c:1849 */
#define   ELMA124      (ERRLMA +  124)    /*        lma.c:1851 */
#define   ELMA125      (ERRLMA +  125)    /*        lma.c:1852 */
#define   ELMA126      (ERRLMA +  126)    /*        lma.c:1854 */
#define   ELMA127      (ERRLMA +  127)    /*        lma.c:1862 */
#define   ELMA128      (ERRLMA +  128)    /*        lma.c:1868 */
#define   ELMA129      (ERRLMA +  129)    /*        lma.c:1915 */
#define   ELMA130      (ERRLMA +  130)    /*        lma.c:1916 */
#define   ELMA131      (ERRLMA +  131)    /*        lma.c:1917 */
#define   ELMA132      (ERRLMA +  132)    /*        lma.c:1923 */
#define   ELMA133      (ERRLMA +  133)    /*        lma.c:1924 */
#define   ELMA134      (ERRLMA +  134)    /*        lma.c:1925 */
#define   ELMA135      (ERRLMA +  135)    /*        lma.c:1926 */
#define   ELMA136      (ERRLMA +  136)    /*        lma.c:1931 */
#define   ELMA137      (ERRLMA +  137)    /*        lma.c:1937 */
#define   ELMA138      (ERRLMA +  138)    /*        lma.c:1940 */
#define   ELMA139      (ERRLMA +  139)    /*        lma.c:1941 */
#define   ELMA140      (ERRLMA +  140)    /*        lma.c:1942 */
#define   ELMA141      (ERRLMA +  141)    /*        lma.c:1943 */
#define   ELMA142      (ERRLMA +  142)    /*        lma.c:1991 */
#define   ELMA143      (ERRLMA +  143)    /*        lma.c:1995 */
#define   ELMA144      (ERRLMA +  144)    /*        lma.c:1996 */
#define   ELMA145      (ERRLMA +  145)    /*        lma.c:1997 */
#define   ELMA146      (ERRLMA +  146)    /*        lma.c:1998 */
#define   ELMA147      (ERRLMA +  147)    /*        lma.c:1999 */
#define   ELMA148      (ERRLMA +  148)    /*        lma.c:2000 */
#define   ELMA149      (ERRLMA +  149)    /*        lma.c:2001 */
#define   ELMA150      (ERRLMA +  150)    /*        lma.c:2002 */
#define   ELMA151      (ERRLMA +  151)    /*        lma.c:2003 */
#define   ELMA152      (ERRLMA +  152)    /*        lma.c:2006 */
#define   ELMA153      (ERRLMA +  153)    /*        lma.c:2009 */
#define   ELMA154      (ERRLMA +  154)    /*        lma.c:2010 */
#define   ELMA155      (ERRLMA +  155)    /*        lma.c:2011 */
#define   ELMA156      (ERRLMA +  156)    /*        lma.c:2012 */
#define   ELMA157      (ERRLMA +  157)    /*        lma.c:2015 */
#define   ELMA158      (ERRLMA +  158)    /*        lma.c:2017 */
#define   ELMA159      (ERRLMA +  159)    /*        lma.c:2020 */
#define   ELMA160      (ERRLMA +  160)    /*        lma.c:2023 */
#define   ELMA161      (ERRLMA +  161)    /*        lma.c:2025 */
#define   ELMA162      (ERRLMA +  162)    /*        lma.c:2031 */
#define   ELMA163      (ERRLMA +  163)    /*        lma.c:2032 */
#define   ELMA164      (ERRLMA +  164)    /*        lma.c:2035 */
#define   ELMA165      (ERRLMA +  165)    /*        lma.c:2036 */
#define   ELMA166      (ERRLMA +  166)    /*        lma.c:2037 */
#define   ELMA167      (ERRLMA +  167)    /*        lma.c:2038 */
#define   ELMA168      (ERRLMA +  168)    /*        lma.c:2039 */
#define   ELMA169      (ERRLMA +  169)    /*        lma.c:2040 */
#define   ELMA170      (ERRLMA +  170)    /*        lma.c:2041 */
#define   ELMA171      (ERRLMA +  171)    /*        lma.c:2042 */
#define   ELMA172      (ERRLMA +  172)    /*        lma.c:2043 */
#define   ELMA173      (ERRLMA +  173)    /*        lma.c:2044 */
#define   ELMA174      (ERRLMA +  174)    /*        lma.c:2046 */
#define   ELMA175      (ERRLMA +  175)    /*        lma.c:2047 */
#define   ELMA176      (ERRLMA +  176)    /*        lma.c:2048 */
#define   ELMA177      (ERRLMA +  177)    /*        lma.c:2050 */
#define   ELMA178      (ERRLMA +  178)    /*        lma.c:2051 */
#define   ELMA179      (ERRLMA +  179)    /*        lma.c:2054 */
#define   ELMA180      (ERRLMA +  180)    /*        lma.c:2059 */
#define   ELMA181      (ERRLMA +  181)    /*        lma.c:2066 */
#define   ELMA182      (ERRLMA +  182)    /*        lma.c:2073 */
#define   ELMA183      (ERRLMA +  183)    /*        lma.c:2074 */
#define   ELMA184      (ERRLMA +  184)    /*        lma.c:2075 */
#define   ELMA185      (ERRLMA +  185)    /*        lma.c:2076 */
#define   ELMA186      (ERRLMA +  186)    /*        lma.c:2077 */
#define   ELMA187      (ERRLMA +  187)    /*        lma.c:2078 */
#define   ELMA188      (ERRLMA +  188)    /*        lma.c:2080 */
#define   ELMA189      (ERRLMA +  189)    /*        lma.c:2081 */
#define   ELMA190      (ERRLMA +  190)    /*        lma.c:2083 */
#define   ELMA191      (ERRLMA +  191)    /*        lma.c:2086 */
#define   ELMA192      (ERRLMA +  192)    /*        lma.c:2090 */
#define   ELMA193      (ERRLMA +  193)    /*        lma.c:2091 */
#define   ELMA194      (ERRLMA +  194)    /*        lma.c:2093 */
#define   ELMA195      (ERRLMA +  195)    /*        lma.c:2094 */
#define   ELMA196      (ERRLMA +  196)    /*        lma.c:2097 */
#define   ELMA197      (ERRLMA +  197)    /*        lma.c:2098 */
#define   ELMA198      (ERRLMA +  198)    /*        lma.c:2099 */
#define   ELMA199      (ERRLMA +  199)    /*        lma.c:2100 */
#define   ELMA200      (ERRLMA +  200)    /*        lma.c:2101 */
#define   ELMA201      (ERRLMA +  201)    /*        lma.c:2104 */
#define   ELMA202      (ERRLMA +  202)    /*        lma.c:2111 */
#define   ELMA203      (ERRLMA +  203)    /*        lma.c:2112 */
#define   ELMA204      (ERRLMA +  204)    /*        lma.c:2113 */
#define   ELMA205      (ERRLMA +  205)    /*        lma.c:2117 */
#define   ELMA206      (ERRLMA +  206)    /*        lma.c:2118 */
#define   ELMA207      (ERRLMA +  207)    /*        lma.c:2120 */
#define   ELMA208      (ERRLMA +  208)    /*        lma.c:2126 */
#define   ELMA209      (ERRLMA +  209)    /*        lma.c:2127 */
#define   ELMA210      (ERRLMA +  210)    /*        lma.c:2128 */
#define   ELMA211      (ERRLMA +  211)    /*        lma.c:2133 */
#define   ELMA212      (ERRLMA +  212)    /*        lma.c:2137 */
#define   ELMA213      (ERRLMA +  213)    /*        lma.c:2138 */
#define   ELMA214      (ERRLMA +  214)    /*        lma.c:2139 */
#define   ELMA215      (ERRLMA +  215)    /*        lma.c:2140 */
#define   ELMA216      (ERRLMA +  216)    /*        lma.c:2141 */
#define   ELMA217      (ERRLMA +  217)    /*        lma.c:2142 */
#define   ELMA218      (ERRLMA +  218)    /*        lma.c:2143 */
#define   ELMA219      (ERRLMA +  219)    /*        lma.c:2144 */
#define   ELMA220      (ERRLMA +  220)    /*        lma.c:2145 */
#define   ELMA221      (ERRLMA +  221)    /*        lma.c:2149 */
#define   ELMA222      (ERRLMA +  222)    /*        lma.c:2151 */
#define   ELMA223      (ERRLMA +  223)    /*        lma.c:2153 */
#define   ELMA224      (ERRLMA +  224)    /*        lma.c:2157 */
#define   ELMA225      (ERRLMA +  225)    /*        lma.c:2159 */
#define   ELMA226      (ERRLMA +  226)    /*        lma.c:2161 */
#define   ELMA227      (ERRLMA +  227)    /*        lma.c:2171 */
#define   ELMA228      (ERRLMA +  228)    /*        lma.c:2227 */
#define   ELMA229      (ERRLMA +  229)    /*        lma.c:2286 */
#define   ELMA230      (ERRLMA +  230)    /*        lma.c:2287 */
#define   ELMA231      (ERRLMA +  231)    /*        lma.c:2328 */
#define   ELMA232      (ERRLMA +  232)    /*        lma.c:2374 */
#define   ELMA233      (ERRLMA +  233)    /*        lma.c:2375 */
#define   ELMA234      (ERRLMA +  234)    /*        lma.c:2421 */
#define   ELMA235      (ERRLMA +  235)    /*        lma.c:2422 */
#define   ELMA236      (ERRLMA +  236)    /*        lma.c:2423 */
#define   ELMA237      (ERRLMA +  237)    /*        lma.c:2424 */
#define   ELMA238      (ERRLMA +  238)    /*        lma.c:2428 */
#define   ELMA239      (ERRLMA +  239)    /*        lma.c:2436 */
#define   ELMA240      (ERRLMA +  240)    /*        lma.c:2437 */
#define   ELMA241      (ERRLMA +  241)    /*        lma.c:2438 */
#define   ELMA242      (ERRLMA +  242)    /*        lma.c:2440 */
#define   ELMA243      (ERRLMA +  243)    /*        lma.c:2446 */
#define   ELMA244      (ERRLMA +  244)    /*        lma.c:2450 */
#define   ELMA245      (ERRLMA +  245)    /*        lma.c:2451 */
#define   ELMA246      (ERRLMA +  246)    /*        lma.c:2452 */
#define   ELMA247      (ERRLMA +  247)    /*        lma.c:2495 */
#define   ELMA248      (ERRLMA +  248)    /*        lma.c:2496 */
#define   ELMA249      (ERRLMA +  249)    /*        lma.c:2499 */
#define   ELMA250      (ERRLMA +  250)    /*        lma.c:2505 */
#define   ELMA251      (ERRLMA +  251)    /*        lma.c:2510 */
#define   ELMA252      (ERRLMA +  252)    /*        lma.c:2511 */
#define   ELMA253      (ERRLMA +  253)    /*        lma.c:2513 */
#define   ELMA254      (ERRLMA +  254)    /*        lma.c:2514 */
#define   ELMA255      (ERRLMA +  255)    /*        lma.c:2515 */
#define   ELMA256      (ERRLMA +  256)    /*        lma.c:2516 */
#define   ELMA257      (ERRLMA +  257)    /*        lma.c:2517 */
#define   ELMA258      (ERRLMA +  258)    /*        lma.c:2518 */
#define   ELMA259      (ERRLMA +  259)    /*        lma.c:2561 */
#define   ELMA260      (ERRLMA +  260)    /*        lma.c:2562 */
#define   ELMA261      (ERRLMA +  261)    /*        lma.c:2563 */
#define   ELMA262      (ERRLMA +  262)    /*        lma.c:2566 */
#define   ELMA263      (ERRLMA +  263)    /*        lma.c:2567 */
#define   ELMA264      (ERRLMA +  264)    /*        lma.c:2573 */
#define   ELMA265      (ERRLMA +  265)    /*        lma.c:2574 */
#define   ELMA266      (ERRLMA +  266)    /*        lma.c:2582 */
#define   ELMA267      (ERRLMA +  267)    /*        lma.c:2583 */
#define   ELMA268      (ERRLMA +  268)    /*        lma.c:2638 */
#define   ELMA269      (ERRLMA +  269)    /*        lma.c:2639 */
#define   ELMA270      (ERRLMA +  270)    /*        lma.c:2640 */
#define   ELMA271      (ERRLMA +  271)    /*        lma.c:2641 */
#define   ELMA272      (ERRLMA +  272)    /*        lma.c:2642 */
#define   ELMA273      (ERRLMA +  273)    /*        lma.c:2643 */
#define   ELMA274      (ERRLMA +  274)    /*        lma.c:2644 */
#define   ELMA275      (ERRLMA +  275)    /*        lma.c:2645 */
#define   ELMA276      (ERRLMA +  276)    /*        lma.c:2646 */
#define   ELMA277      (ERRLMA +  277)    /*        lma.c:2648 */
#define   ELMA278      (ERRLMA +  278)    /*        lma.c:2649 */
#define   ELMA279      (ERRLMA +  279)    /*        lma.c:2650 */
#define   ELMA280      (ERRLMA +  280)    /*        lma.c:2652 */
#define   ELMA281      (ERRLMA +  281)    /*        lma.c:2656 */
#define   ELMA282      (ERRLMA +  282)    /*        lma.c:2660 */
#define   ELMA283      (ERRLMA +  283)    /*        lma.c:2662 */
#define   ELMA284      (ERRLMA +  284)    /*        lma.c:2663 */
#define   ELMA285      (ERRLMA +  285)    /*        lma.c:2705 */
#define   ELMA286      (ERRLMA +  286)    /*        lma.c:2708 */
#define   ELMA287      (ERRLMA +  287)    /*        lma.c:2710 */
#define   ELMA288      (ERRLMA +  288)    /*        lma.c:2711 */
#define   ELMA289      (ERRLMA +  289)    /*        lma.c:2712 */
#define   ELMA290      (ERRLMA +  290)    /*        lma.c:2752 */
#define   ELMA291      (ERRLMA +  291)    /*        lma.c:2753 */
#define   ELMA292      (ERRLMA +  292)    /*        lma.c:2795 */
#define   ELMA293      (ERRLMA +  293)    /*        lma.c:2796 */
#define   ELMA294      (ERRLMA +  294)    /*        lma.c:2838 */
#define   ELMA295      (ERRLMA +  295)    /*        lma.c:2839 */
#define   ELMA296      (ERRLMA +  296)    /*        lma.c:2882 */
#define   ELMA297      (ERRLMA +  297)    /*        lma.c:2883 */

#ifdef __cplusplus
}
#endif

#endif  /* __LMAH__ */

  
/********************************************************************30**
  
         End of file:     lma.h@@/main/2 - Fri Sep 16 02:49:21 2005
   
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
1.1             aa      1. initial release.

1.2             aa      1. Corrected the typo in #ifdef LMA_CFG_OK
                aa      2. removed the defines for SubSystem number as they
                           are defined in lma.h

*********************************************************************81*/
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.3          ---      ssk  1. Added MAP Phase 2+ Variant. Added LMINT3
  
1.4          ---      ssk  1. Phase 2+ gpr release.

             ---      ssk  2. LMA_VER2P is defined as 3.
                              The '#defines' for the combinations of 
                              versions are transported from ma_mf.h file .

             ---      ssk  3. Drop on error hash define is defined. 

             ---      jz   4. protocal class hash define is defined.

1.8          ---      jz   1. Added defines for group SAPs.

/main/5      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. Rolling Upgrade compliance.

             ---      yz   1. Adding define for LMA_VER3.

/main/6      ---      jie  1. update for MAP 1.6 release.

             ---      jie  1. Change for 2002/09 rel99/rel4 release.

/main/7      ---      jie  1. update for MAP 1.7 release.

/main/1      ---      cp  1. update for MAP 2.2 release.
/main/2      ---      rbabu 1. update for MAP 2.3 release.
ma001.203    ---     st   1.  Added defines for lower SAPs.
*********************************************************************91*/
