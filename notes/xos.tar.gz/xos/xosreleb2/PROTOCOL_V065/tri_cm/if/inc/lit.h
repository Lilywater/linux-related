/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     M3UA layer

     Type:     C header file

     Desc:     Header file for M3UA layer management

     File:     lit.h

     Sid:      lit.h@@/main/7 - Thu Apr  1 03:50:23 2004

     Prg:      mrw

*********************************************************************21*/
#ifndef __LITH__
#define __LITH__

#ifdef LITV1
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0100
#endif /* LITV1 */

/* it011.106 - New Interface version added */
#ifdef LITV2
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0200
#endif /* LITV2 */

/* lit_h_004.main_7 - New Interface version added */
#ifdef LITV3
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0300
#endif /* LITV3 */

/* lit_h_005.main_7 - New Interface version added */
#ifdef LITV4
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0400
#endif /* LITV4 */

/* lit_h_006.main_7 - New Interface version added */
#ifdef LITV5
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0500
#endif /* LITV5 */

/* lit_h_007.main_7 - New Interface version added */
#ifdef LITV6
#ifdef LITIFVER
#undef LITIFVER
#endif
#define LITIFVER 0x0600
#endif /* LITV6 */

/* If none of LITV? flags are enabled,
 * define LITIFVER as latest version */
#ifndef LITIFVER
#define LITIFVER   0x0600
#endif /* LITIFVER */

/* MSEP */
#ifndef LIT_MAX_SEP
#define LIT_MAX_SEP            1    /* Maximum number of Self End Points */
#endif

/* MSEP */
#ifndef LIT_MAX_ASSOC
#define LIT_MAX_ASSOC (LIT_MAX_SEP)*(LIT_MAX_PSP) /* Maximum number of assocs
                                      will be product of max Self End Points 
                                      and max remote PSP */
#endif

#ifndef LIT_MAX_PSP
#define LIT_MAX_PSP            20    /* Maximum number of PSPs */
#endif
#ifndef LIT_MAX_PSID

#define LIT_MAX_PSID           60    /* Maximum number of Routing Contexts */

#endif
#ifndef  LIT_MAX_STATIC_PSID
#define LIT_MAX_STATIC_PSID    LIT_MAX_PSID/2    /* Maximum number of
                                                    Static Ps This value
                                                    should be less than
                                                    LIT_MAX_PSID */
#endif
#ifndef  LIT_MAX_INFO
#define  LIT_MAX_INFO          255    /* Maximum size of INFO string */
#endif
#ifndef  LIT_MAX_ACT_PS

#define  LIT_MAX_ACT_PS        LIT_MAX_PSID /* Max no. of active PS per PSP */

#endif
#ifndef  LIT_MAX_TRC_LEN
#define  LIT_MAX_TRC_LEN       200   /* Maximum trace size */
#endif
#ifndef  LIT_MAX_RK_IN_DRKM
#define  LIT_MAX_RK_IN_DRKM    4     /* Maximum number of RKs in RKM msg */
#endif
#ifndef  LIT_MAX_RC_IN_DRKM
#define  LIT_MAX_RC_IN_DRKM    4     /* Maximum number of RCs in RKM msg */
#endif

#ifndef  LIT_MAX_REGRSLTS_IN_RKM
#define  LIT_MAX_REGRSLTS_IN_RKM     4 /* Maximum no of registration
                                         results in RKM msg */    
#endif
#ifndef  LIT_MAX_DEREGRSLTS_IN_RKM
#define  LIT_MAX_DEREGRSLTS_IN_RKM   4 /* Maximum no of De-registration
                                         results in RKM msg */
#endif
#ifndef  LIT_MAX_SIO_IN_DRKM
#define  LIT_MAX_SIO_IN_DRKM         4 /* Maximum no of Service Info 
                                         parameters allowed in RKM msg */
#endif
#ifndef  LIT_MAX_OPC_IN_DRKM
#define  LIT_MAX_OPC_IN_DRKM         4 /* Maximum no of Originating Point
                                         Code allowed in RKM msg */
#endif
#ifndef  LIT_MAX_CIC_IN_DRKM
#define  LIT_MAX_CIC_IN_DRKM         4 /* Maximum no of CIC ranges 
                                         allowed in RKM msg */
#endif

/* defines for element management */
#define STITSID               1     /* System ID */
#define STITGEN               2     /* General */
#define STITNSAP              3     /* Upper layer SAP */
#define STITSCTSAP            4     /* Lower layer SAP */
#define STITNWK               5     /* Network context */
#define STITROUT              6     /* Routing entry */
#define STITPS                7     /* Peer Server */
#define STITPSP               8     /* Peer Signalling Process */
#define STITADRTRAN           10    /* Address translation table */
#define STITGRNSAP            11    /* Group Upper layer SAP */
#define STITGRSCTSAP          12    /* Group Lower layer SAP */
#define STITAPC               13    /* Affected point code */
#define STITRK                14    /* Routing Key */
#define STITPSPRKID           15    /* PSP's RK */
#ifdef LIT_RTE_ALARMS
#ifdef SGVIEW
#define STITSG                16    /* SG's Id */
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */

/* M3UA specific Mngmt.t.cntrl.action defines */
#define AESTABLISH            256   /* establish */
#define ATERMINATE            257   /* terminate */
#define AASPAC                258   /* ASP active */
#define AASPIA                259   /* ASP inactive */
#define AASPUP                260   /* ASP up */
#define AASPDN                261   /* ASP down */
#define ASCON                 262   /* ASP congested */
#define AEOPENR               263   /* Endpoint open request */
#define ARKREG                264   /* RKM registration */
#define ARKDEREG              265   /* RKM de-registration */

/* nodeType in genCfg */
#define LIT_TYPE_SGP          1     /* Signaling Gateway */
#define LIT_TYPE_ASP          2     /* Application Server Proc */
/* slsLen in nwkCfg */
#define LIT_SLS4              4     /* SLS length 4 bits */
#define LIT_SLS5              5     /* SLS length 5 bits */
#define LIT_SLS8              8     /* SLS length 8 bits */

/* suType in nSapCfg */
#define LIT_SU_SCCP           3     /* SCCP user */
#define LIT_SU_TUP            4     /* TUP user */
#define LIT_SU_ISUP           5     /* ISUP user */
#define LIT_SU_DUP            6     /* DUP user */
#define LIT_SU_DUPF           7     /* DUPF user */
#define LIT_SU_MTUP           8     /* MTUP user */
#define LIT_SU_B_ISUP         9     /* B-ISUP user */
#define LIT_SU_S_ISUP         10    /* S-ISUP user */
#define LIT_SU_AAL2           12    /* AAL2 user */
#define LIT_SP_MTP3           0xf   /* MTP3  */
/* lit_h_001.main_7 - addition - MGCP service indicator */
#define LIT_SU_MGCP           0xe   /* MGCP  */
#ifdef SNT_BACK_COMP_MERGED_NIF
#define LIT_SU_NIF            LIT_SP_MTP3  /* NIF user  */
#endif
/* suSwtch in nwkCfg */
#define LIT_SW_ANS            1     /* link type ANSI */
#define LIT_SW_ITU            2     /* link type CCITT */
#define LIT_SW_CHINA          4     /* link type CHINA */
#define LIT_SW_BICI           5     /* link type BICI */
#define LIT_SW_ANS96          6     /* link type ANSI */
#define LIT_SW_TTC            10    /* link type TTC */
#define LIT_SW_NTT            11    /* link type NTT */

/* it005.106 - Added a new hash define for unused su2Swtch and changed the 
 * comment for su2Swtch in nwkCfg (not nSapCfg) */
/* su2Swtch in nwkCfg */
#define LIT_SW2_UNUSED        0     /* su2Swtch Unused */
#define LIT_SW2_ITU           1     /* TCAP type ITU */
#define LIT_SW2_ETS           4     /* TCAP type ETSI */
#define LIT_SW2_ANS           7     /* TCAP type ANSI */
#define LIT_SW2_TTC           8     /* TCAP type TTC */

/* rtType in rteCfg */
#define LIT_RTTYPE_NOTFOUND   0     /* No route found */
#define LIT_RTTYPE_LOCAL      1     /* Route to a local user */
#define LIT_RTTYPE_MTP3       2     /* Route to SS7 via the MTP3 */
#define LIT_RTTYPE_PS         3     /* Route to a Peer Server */

/* pspType in pspCfg */
#define LIT_PSPTYPE_LOCAL     0     /* special case for the local entity */
#define LIT_PSPTYPE_ASP       1     /* remote PSP is a ASP */
#define LIT_PSPTYPE_SGP       2     /* remote PSP is a SGP */
#define LIT_PSPTYPE_IPSP      3     /* remote PSP is a IPSP */
/* ipspType in pspCfg */
#define LIT_IPSPMODE_SE       1     /* Single ended mode IPSP */
#define LIT_IPSPMODE_DE       2     /* Double ended mode IPSP */

/* it011.106 - Default value for tos in ItAssocCfg */
#ifndef LITIF_VER2_CFGREQ_DEF_TOS_VAL
#define LITIF_VER2_CFGREQ_DEF_TOS_VAL 0
#endif

/* lit_h_006.main_7 - Default value for abrtFlag for PSP Deletion
 * control request.*/
#ifndef LITIF_VER5_CNTRLREQ_DEF_ABRTFLAG_VAL
#define LITIF_VER5_CNTRLREQ_DEF_ABRTFLAG_VAL FALSE
#endif

/* it011.106 - Bit for compile flag. This bit is used in the 
 * bit vector for interface primitives in LIT interface version 0x0200. */
/* lit_h_006.main_7 - Bit added for compile flag IT_ABORT_ASSOC */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#define LIT_SCT3_BIT          0x01   /* Bit for compile flag SCT3 */
#define LIT_ABORT_ASSOC_BIT   0x02   /* Bit for compile flag IT_ABORT_ASSOC */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* dpcMask/opcMask in rtFilter */
#define LIT_DPC_SPECIFIED     0xFFFFFF /* All bits set to 1 */

/* mode in psCfg */
#define LIT_MODE_ACTSTANDBY   1     /* Active/standby mode */
#define LIT_MODE_LOADSHARE    2     /* Loadsharing mode */
#define LIT_MODE_BROADCAST    3     /* Broadcast mode */

/* loadShareMode in psCfg */
#define LIT_LOADSH_RNDROBIN   1     /* Round robin */
#define LIT_LOADSH_SLS        2     /* By link selector */
#define LIT_LOADSH_CIC        3     /* By CIC */

/* rtEnt.indexType in cntrl */
#define LIT_RTINDEX_PSID      1     /* route index by PS ID */
#define LIT_RTINDEX_DPC       2     /* route index by DPC */
#define LIT_RTINDEX_NWKID     3     /* route indexes by nwkId */
#define LIT_RTINDEX_ROUTECFG  4     /* route index by fully specify rteCfg */

/* reqType in cntrl */
#define LIT_REG_REQ            1     /* Request type is Registration */
#define LIT_DEREG_REQ          2     /* Request type is De-Registration */

/* pspId in cntrl */
#define LIT_PSPID_LOCAL       0     /* the reserved local PSP */

/* aspm.type in cntrl */
#define LIT_ASP_TMTYPE_OVERRIDE           1 /* IT_M3UA_THM_OVERRIDE */
#define LIT_ASP_TMTYPE_LOADSHARE          2 /* IT_M3UA_THM_LOADSHARE */
#define LIT_ASP_TMTYPE_BROADCAST          3 /* IT_M3UA_THM_LOADSHARE */

/* hlSt in nSapSta and sctSapSta */
#define LIT_SAP_UNBOUND       1     /* SAP unbound */
#define LIT_SAP_WAIT_BNDCFM   2     /* expect the bind confirm */
#define LIT_SAP_BOUND         3     /* SAP bound */
#define LIT_SAP_WAIT_OPENCFM  4     /* expect the endpoint open confirm */
#define LIT_SAP_READY         5     /* SCT SAP ready for use */

/* asSt in psSta - also used in Notify message */
#define LIT_AS_UNKNOWN        0     /* AS state unknown */
#define LIT_AS_DOWN           1     /* AS-DOWN */
#define LIT_AS_INACTIVE       2     /* AS-INACTIVE */
#define LIT_AS_ACTIVE         3     /* AS-ACTIVE */
#define LIT_AS_PENDING        4     /* AS-PENDING */

/* aspSt in aspSta - also used in Notify message */
#define LIT_ASP_UNSUPP        0     /* unsupported */
#define LIT_ASP_DOWN          1     /* ASP-DOWN */
#define LIT_ASP_INACTIVE      2     /* ASP-INACTIVE */
#define LIT_ASP_ACTIVE        3     /* ASP-ACTIVE */

/* hlSt in assocSta */
#define LIT_ASSOC_DOWN        1     /* association is down */
#define LIT_ASSOC_ACTIVE      2     /* association is up */
#define LIT_ASSOC_CONGSTART   3     /* association has started flow control */
#define LIT_ASSOC_CONGDROP    4     /* association is dropping data */

/* msgType in sta.t.aspm - same as IT_ASPM_xxxx */
#define LIT_ASPM_ASPUP        0x0301 /* IT_ASPM_ASPUP */
#define LIT_ASPM_ASPDN        0x0302 /* IT_ASPM_ASPDN */
#define LIT_ASPM_ASPAC        0x0401 /* IT_ASPM_ASPAC */
#define LIT_ASPM_ASPIA        0x0402 /* IT_ASPM_ASPIA */
#define LIT_ASPM_ASPUP_ACK    0x0304 /* IT_ASPM_ASPUP_ACK */
#define LIT_ASPM_ASPDN_ACK    0x0305 /* IT_ASPM_ASPDN_ACK */
#define LIT_ASPM_ASPAC_ACK    0x0403 /* IT_ASPM_ASPAC_ACK */
#define LIT_ASPM_ASPIA_ACK    0x0404 /* IT_ASPM_ASPIA_ACK */

/* reason in sta.t.aspm */
#define LIT_ASPDN_REASON_UNSPEC        0 /* IT_M3UA_REASON_UNSPEC */
#define LIT_ASPDN_REASON_USER_UNAVAIL  1 /* IT_M3UA_REASON_USER_UNAVAIL */
#define LIT_ASPDN_REASON_MGMNTINH      2 /* IT_M3UA_REASON_MGMNTINH */

/* stType in sta.t.ntfy */
#define LIT_NTFY_TYPE_ASCHG   1 /* IT_M3UA_NTFY_TYPE_ASCHG - AS state change */
#define LIT_NTFY_TYPE_OTHER   2 /* IT_M3UA_NTFY_TYPE_OTHER - other */

/* stInfo in sta.t.ntfy */
#define LIT_NTFY_INFO_AS_INACTIVE         2 /* IT_M3UA_NTFY_INFO_AS_INACTIVE */
#define LIT_NTFY_INFO_AS_ACTIVE           3 /* IT_M3UA_NTFY_INFO_AS_ACTIVE */
#define LIT_NTFY_INFO_AS_PENDING          4 /* IT_M3UA_NTFY_INFO_AS_PENDING */
#define LIT_NTFY_INFO_OTHER_INSUF_RSRC    1 /* IT_M3UA_NTFY_INFO_INSUF_RSRC */
#define LIT_NTFY_INFO_OTHER_ALT_ASPACT    2 /* IT_M3UA_NTFY_INFO_ALT_ASPACT */
#define LIT_NTFY_INFO_OTHER_ASP_FLR       3 /* ASP Failure Notification */

/* evnt in trc */
#define LIT_MSG_RX       1     /* Trace for the message received */
#define LIT_MSG_TX       2     /* Trace for the message transmitted */
#define LIT_MGMT_RX      3     /* Trace for the MGMT msg received */
#define LIT_DATA_RX      4     /* Trace for the M3UA DATA msg received */
#define LIT_SSNM_RX      5     /* Trace for the M3UA SSNM msg received */
#define LIT_ASPSM_RX     6     /* Trace for the M3UA ASPSM msg received */
#define LIT_ASPTM_RX     7     /* Trace for the M3UA ASPTM msg received */
#define LIT_RKM_RX       8     /* Trace for the M3UA RKM msg received */

#define LIT_MGMT_TX      9    /* Trace for Management */
#define LIT_DATA_TX      10   /* Trace for M3UA data transfer message class */
#define LIT_SSNM_TX      11   /* Trace for SS7 network management msg class */
#define LIT_ASPSM_TX     12   /* Trace for ASP state maintenance msg class */
#define LIT_ASPTM_TX     13   /* Trace for ASP traffic maintenance msg class */
#define LIT_RKM_TX       14   /* Trace for Routing Key Mgmt message class */

/* Trace mask */
#define LIT_TRC_SSNM       0x00000001
#define LIT_TRC_ASPSM      0x00000002
#define LIT_TRC_ASPTM      0x00000004
#define LIT_TRC_M3UA_XFER  0x00000008
#define LIT_TRC_MGMT       0x00000010 
#define LIT_TRC_RKM        0x00000020  
#define LIT_TRC_ALL        (LIT_TRC_SSNM | LIT_TRC_ASPSM| LIT_TRC_ASPTM | \
                            LIT_TRC_M3UA_XFER | LIT_TRC_MGMT | LIT_TRC_RKM)
                                       
/* Return value of itAddnewRouteCb */
#define LIT_OVERLAP    10
#define LIT_CREATE     11
#define LIT_EXACTMATCH 12

/* dpcSta.dpcSt in usta , same as IT_DPC_ values */

#define LIT_DPC_UNKNOWN     0      /* DPC state is unknown */
#define LIT_DPC_AVAILABLE   1      /* DPC state is available */
#define LIT_DPC_CONGESTED   2      /* DPC state is congested */
#define LIT_DPC_UNAVAILABLE 3      /* DPC state is unavailable */
#define LIT_DPC_RESTRICTED  4      /* DPC state is restricted */

/*2006-10-19 chenning �޸�Ϊż����������*/
#define LIT_RDST_DEFAULT        0       /*m3ua ready auto setup state is default*/
#define LIT_RDST_ASPUP        1       /*m3ua ready auto setup state is ready send aspup*/
#define LIT_RDST_ASPAC        2       /*m3ua ready auto setup state is ready send aspac*/
#define LIT_RDST_OK        3       /*m3ua ready auto setup state is ready complete*/
/***********************************************************************
        defines related to events across the management interface
 ***********************************************************************/

#define EVTLITCFGREQ                    1   /* Configuration request */
#define EVTLITCFGCFM                    2   /* Configuration confirm */
#define EVTLITSTAREQ                    3   /* Status request */
#define EVTLITSTACFM                    4   /* Status confirm */
#define EVTLITSTAIND                    5   /* Status indication */
#define EVTLITSTSREQ                    6   /* Statistics request */
#define EVTLITSTSCFM                    7   /* Statistics confirm */
#define EVTLITTRCIND                    8   /* Trace indication */
#define EVTLITCNTRLREQ                  9   /* Control request */
#define EVTLITCNTRLCFM                  10  /* Control confirm */

/* Layer specific categories */
#define LIT_CATEGORY_CNTRL              (LCM_CATEGORY_LYR_SPECIFIC + 1)
#define LIT_CATEGORY_STATUS             (LCM_CATEGORY_LYR_SPECIFIC + 2)


/* Layer specific events */
#define LIT_EVENT_MSG_FAIL              (LCM_EVENT_LYR_SPECIFIC + 1)
#define LIT_EVENT_SHUTDOWN_OK           (LCM_EVENT_LYR_SPECIFIC + 2)
#define LIT_EVENT_ESTABLISH_FAIL        (LCM_EVENT_LYR_SPECIFIC + 3)
#define LIT_EVENT_ESTABLISH_OK          (LCM_EVENT_LYR_SPECIFIC + 4)
#define LIT_EVENT_ASPM                  (LCM_EVENT_LYR_SPECIFIC + 5)
#define LIT_EVENT_NOTIFY                (LCM_EVENT_LYR_SPECIFIC + 6)
#define LIT_EVENT_M3UA_PROTO_ERROR      (LCM_EVENT_LYR_SPECIFIC + 7)
#define LIT_EVENT_ASP_DOWN              (LCM_EVENT_LYR_SPECIFIC + 8)
#define LIT_EVENT_ASP_ACTIVE            (LCM_EVENT_LYR_SPECIFIC + 9)
#define LIT_EVENT_ASP_INACTIVE          (LCM_EVENT_LYR_SPECIFIC + 10)

#define LIT_EVENT_ASSOC_INHIBIT         (LCM_EVENT_LYR_SPECIFIC + 12)
#define LIT_EVENT_TERM_IND              (LCM_EVENT_LYR_SPECIFIC + 13)
#define LIT_EVENT_TERM_CONFIRM          (LCM_EVENT_LYR_SPECIFIC + 14)
#define LIT_EVENT_FLC_DROP              (LCM_EVENT_LYR_SPECIFIC + 15)
#define LIT_EVENT_LI_INV_PAR            (LCM_EVENT_LYR_SPECIFIC + 16)
#define LIT_EVENT_STATUS_IND            (LCM_EVENT_LYR_SPECIFIC + 17)
#define LIT_EVENT_SCT_SEND_FAIL         (LCM_EVENT_LYR_SPECIFIC + 18)
#define LIT_EVENT_HBEAT_LOST            (LCM_EVENT_LYR_SPECIFIC + 19)
#define LIT_EVENT_AS_INACTIVE           (LCM_EVENT_LYR_SPECIFIC + 20)
#define LIT_EVENT_AS_DOWN               (LCM_EVENT_LYR_SPECIFIC + 21)
#define LIT_EVENT_AS_ACTIVE             (LCM_EVENT_LYR_SPECIFIC + 22)
#define LIT_EVENT_AS_PENDING            (LCM_EVENT_LYR_SPECIFIC + 23)
#define LIT_EVENT_SCT_COMM_DOWN         (LCM_EVENT_LYR_SPECIFIC + 24)
#define LIT_EVENT_ASPAC_FAIL            (LCM_EVENT_LYR_SPECIFIC + 25)
#define LIT_EVENT_ASPIA_FAIL            (LCM_EVENT_LYR_SPECIFIC + 26)
#define LIT_EVENT_ASPUP_FAIL            (LCM_EVENT_LYR_SPECIFIC + 27)
#define LIT_EVENT_PC_UNAVAILABLE        (LCM_EVENT_LYR_SPECIFIC + 28)
#define LIT_EVENT_PC_CONGESTED          (LCM_EVENT_LYR_SPECIFIC + 29)
#define LIT_EVENT_PC_AVAILABLE          (LCM_EVENT_LYR_SPECIFIC + 30)
#define LIT_EVENT_PC_USER_PART_UNA      (LCM_EVENT_LYR_SPECIFIC + 31)
#define LIT_EVENT_NO_ROUTE_FOUND        (LCM_EVENT_LYR_SPECIFIC + 32)
#define LIT_EVENT_EOPEN_FAIL            (LCM_EVENT_LYR_SPECIFIC + 33)
#define LIT_EVENT_EOPEN_OK              (LCM_EVENT_LYR_SPECIFIC + 34)
#define LIT_EVENT_PC_RESTRICTED         (LCM_EVENT_LYR_SPECIFIC + 35)
#define LIT_EVENT_RK_TMOUT              (LCM_EVENT_LYR_SPECIFIC + 36)
#define LIT_EVENT_REG_FAILURE           (LCM_EVENT_LYR_SPECIFIC + 37)
#define LIT_EVENT_DEREG_FAILURE         (LCM_EVENT_LYR_SPECIFIC + 38)
#define LIT_EVENT_RK_REGISTERED         (LCM_EVENT_LYR_SPECIFIC + 39)
#define LIT_EVENT_RK_DEREGISTERED       (LCM_EVENT_LYR_SPECIFIC + 40)
#define LIT_EVENT_INV_LCLRKID           (LCM_EVENT_LYR_SPECIFIC + 41)
#define LIT_EVENT_PS_DELETED            (LCM_EVENT_LYR_SPECIFIC + 42)
#define LIT_EVENT_RC_GENERATED          (LCM_EVENT_LYR_SPECIFIC + 43)
#define LIT_EVENT_INV_MSG_RXD           (LCM_EVENT_LYR_SPECIFIC + 44)
#define LIT_EVENT_DAUD_RXD              (LCM_EVENT_LYR_SPECIFIC + 45)
#define LIT_EVENT_RC_DELETED            (LCM_EVENT_LYR_SPECIFIC + 46)
#define LIT_EVENT_PSP_REGD              (LCM_EVENT_LYR_SPECIFIC + 47)
#define LIT_EVENT_SRCADDRLST_CHG        (LCM_EVENT_LYR_SPECIFIC + 48)
#define LIT_EVENT_DSTADDRLST_CHG        (LCM_EVENT_LYR_SPECIFIC + 49)
#define LIT_EVENT_PRIDSTADDR_CHG        (LCM_EVENT_LYR_SPECIFIC + 50)
#ifdef LIT_RTE_ALARMS
#define LIT_EVENT_RTE_AVAIL             (LCM_EVENT_LYR_SPECIFIC + 51)
#define LIT_EVENT_RTE_UNAVAIL           (LCM_EVENT_LYR_SPECIFIC + 52)
#endif /* LIT_RTE_ALARMS */
/* it006.106 - New status indications added in ItLiSctEndpCloseCfm */
#define LIT_EVENT_ECLOSE_OK             (LCM_EVENT_LYR_SPECIFIC + 53)
#define LIT_EVENT_ECLOSE_NOK            (LCM_EVENT_LYR_SPECIFIC + 54)
/* lit_h_002.main_7 - New status indications added. */
#define LIT_EVENT_NWK_RSTBEG            (LCM_EVENT_LYR_SPECIFIC + 55)
#define LIT_EVENT_NWK_RSTEND            (LCM_EVENT_LYR_SPECIFIC + 56)

/* Layer specific causes */
#define LIT_CAUSE_INV_VERSION           (LCM_CAUSE_LYR_SPECIFIC + 1)
#define LIT_CAUSE_INV_NWK_APP           (LCM_CAUSE_LYR_SPECIFIC + 2)
#define LIT_CAUSE_UNSUP_MSG_CLASS       (LCM_CAUSE_LYR_SPECIFIC + 3)
#define LIT_CAUSE_UNSUP_MSG_TYPE        (LCM_CAUSE_LYR_SPECIFIC + 4)
#define LIT_CAUSE_INV_TRAFFIC_MODE      (LCM_CAUSE_LYR_SPECIFIC + 5)
#define LIT_CAUSE_UNEXP_MSG             (LCM_CAUSE_LYR_SPECIFIC + 6)
#define LIT_CAUSE_PROTO_ERR             (LCM_CAUSE_LYR_SPECIFIC + 7)
#define LIT_CAUSE_INV_RCTX              (LCM_CAUSE_LYR_SPECIFIC + 8)
#define LIT_CAUSE_INV_STRMID            (LCM_CAUSE_LYR_SPECIFIC + 9)
#define LIT_CAUSE_INV_M3UA_PARMVAL      (LCM_CAUSE_LYR_SPECIFIC + 10)
#define LIT_CAUSE_RETRY_EXCEED          (LCM_CAUSE_LYR_SPECIFIC + 11)
#define LIT_CAUSE_STATUS_CHANGE         (LCM_CAUSE_LYR_SPECIFIC + 12)
#define LIT_CAUSE_MSG_RECEIVED          (LCM_CAUSE_LYR_SPECIFIC + 13)
#define LIT_CAUSE_RFSD_MGMT_BLKD        (LCM_CAUSE_LYR_SPECIFIC + 14)

#define LIT_CAUSE_INV_DPC               (LCM_CAUSE_LYR_SPECIFIC + 16)
#define LIT_CAUSE_RKM_PER_DENIED        (LCM_CAUSE_LYR_SPECIFIC + 17)
#define LIT_CAUSE_OVERLAP_RK            (LCM_CAUSE_LYR_SPECIFIC + 18)
#define LIT_CAUSE_RK_NOT_PRVISONED      (LCM_CAUSE_LYR_SPECIFIC + 19)
#define LIT_CAUSE_INSF_RSRC             (LCM_CAUSE_LYR_SPECIFIC + 20)
#define LIT_CAUSE_UNSUPP_RK_PRMTR       (LCM_CAUSE_LYR_SPECIFIC + 21)
#define LIT_CAUSE_INV_RK                (LCM_CAUSE_LYR_SPECIFIC + 22)
#define LIT_CAUSE_RK_REG_NO_RESP        (LCM_CAUSE_LYR_SPECIFIC + 23)
#define LIT_CAUSE_RK_REG_PARTIAL_RESP   (LCM_CAUSE_LYR_SPECIFIC + 24)
#define LIT_CAUSE_RK_DEREG_NO_RESP      (LCM_CAUSE_LYR_SPECIFIC + 25)
#define LIT_CAUSE_RK_DEREG_PARTIAL_RESP (LCM_CAUSE_LYR_SPECIFIC + 26)
#define LIT_CAUSE_PSP_ACTIVE            (LCM_CAUSE_LYR_SPECIFIC + 27)
#define LIT_CAUSE_RCTX_UNREG            (LCM_CAUSE_LYR_SPECIFIC + 28)
#define LIT_CAUSE_PS_DELETED            (LCM_CAUSE_LYR_SPECIFIC + 29)
#define LIT_CAUSE_RK_REGISTERED         (LCM_CAUSE_LYR_SPECIFIC + 30)
#define LIT_CAUSE_DAUD_RXD              (LCM_CAUSE_LYR_SPECIFIC + 31)
#define LIT_CAUSE_SCT_TERM_IND          (LCM_CAUSE_LYR_SPECIFIC + 32)
#define LIT_CAUSE_RK_DEREGISTERED       (LCM_CAUSE_LYR_SPECIFIC + 33)
#define LIT_CAUSE_DPC_STATUS_UNKNOWN    (LCM_CAUSE_LYR_SPECIFIC + 34)
#define LIT_CAUSE_PARAM_FIELD_ERROR     (LCM_CAUSE_LYR_SPECIFIC + 35)
#define LIT_CAUSE_UNEXPECTED_PARAM      (LCM_CAUSE_LYR_SPECIFIC + 36)
#define LIT_CAUSE_NO_AS_FOR_ASP         (LCM_CAUSE_LYR_SPECIFIC + 37)

#define LIT_CAUSE_MISSING_PARAM         (LCM_CAUSE_LYR_SPECIFIC + 38)
#define LIT_CAUSE_ASPID_REQUIRED        (LCM_CAUSE_LYR_SPECIFIC + 39)
#define LIT_CAUSE_INVALID_ASPID         (LCM_CAUSE_LYR_SPECIFIC + 40)
#define LIT_CAUSE_PEER_ASSOC_PARAMS     (LCM_CAUSE_LYR_SPECIFIC + 41) 
#define LIT_CAUSE_REMOTE_SHUTDOWN     (LCM_CAUSE_LYR_SPECIFIC + 42) 
#define LIT_CAUSE_REMOTE_ABORT        (LCM_CAUSE_LYR_SPECIFIC + 43) 
#define LIT_CAUSE_COMM_LOST           (LCM_CAUSE_LYR_SPECIFIC + 44) 
#define LIT_CAUSE_SCT_RESTART         (LCM_CAUSE_LYR_SPECIFIC + 45) 
#define LIT_CAUSE_LOCAL_SCTP_PROCERR  (LCM_CAUSE_LYR_SPECIFIC + 46) 
#define LIT_CAUSE_ASSOC_INHIBIT       (LCM_CAUSE_LYR_SPECIFIC + 47) 
#define LIT_CAUSE_M3UA_HBEAT_LOST     (LCM_CAUSE_LYR_SPECIFIC + 48) 
#define LIT_CAUSE_LOCAL_SHUTDOWN      (LCM_CAUSE_LYR_SPECIFIC + 49) 
#ifdef LIT_RTE_ALARMS
#define LIT_CAUSE_RCV_DUNA              (LCM_CAUSE_LYR_SPECIFIC + 50)
#define LIT_CAUSE_RCV_ASPINACTVACK      (LCM_CAUSE_LYR_SPECIFIC + 51)
#define LIT_CAUSE_RCV_ASPDOWNACK        (LCM_CAUSE_LYR_SPECIFIC + 52)
#define LIT_CAUSE_RCV_DAVA              (LCM_CAUSE_LYR_SPECIFIC + 53)
#define LIT_CAUSE_RCV_ASPACTVACK        (LCM_CAUSE_LYR_SPECIFIC + 54)
#define LIT_CAUSE_RCV_ASPUPACK          (LCM_CAUSE_LYR_SPECIFIC + 55)
#define LIT_CAUSE_ASPDOWN               (LCM_CAUSE_LYR_SPECIFIC + 56)
#endif /* LIT_RTE_ALARMS */
#define LIT_CAUSE_SHUTDOWN_CMPLT        (LCM_CAUSE_LYR_SPECIFIC + 57) 
/* lit_h_003.main_7 - Add new cause value for status indication when M3UA 
 * receives SctStaInd with status as SCT_STATUS_SND_FAIL. */
#define LIT_CAUSE_SCT_SEND_FAIL         (LCM_CAUSE_LYR_SPECIFIC + 58) 

/* Layer specific reasons */
#define LIT_REASON_INVALID_PSID        (LCM_REASON_LYR_SPECIFIC + 1)
#define LIT_REASON_INVALID_PSPID       (LCM_REASON_LYR_SPECIFIC + 2)
#define LIT_REASON_INVALID_NWKID       (LCM_REASON_LYR_SPECIFIC + 3)
#define LIT_REASON_INVALID_NSAPID      (LCM_REASON_LYR_SPECIFIC + 4)
#define LIT_REASON_INVALID_RTENT       (LCM_REASON_LYR_SPECIFIC + 5)
#define LIT_REASON_SERVICE_IN_USE      (LCM_REASON_LYR_SPECIFIC + 6)
#define LIT_REASON_MNGMNT_INHIBIT      (LCM_REASON_LYR_SPECIFIC + 7)
#define LIT_REASON_INVALID_ASSOCID     (LCM_REASON_LYR_SPECIFIC + 8)
#define LIT_REASON_NO_RESPONSE         (LCM_REASON_LYR_SPECIFIC + 9)
#define LIT_REASON_INV_PEERTYPE        (LCM_REASON_LYR_SPECIFIC + 10)
#define LIT_REASON_INV_PEER_STATE      (LCM_REASON_LYR_SPECIFIC + 11)
#define LIT_REASON_MSG_NOT_SENT        (LCM_REASON_LYR_SPECIFIC + 12)
#define LIT_REASON_UNREG_RK            (LCM_REASON_LYR_SPECIFIC + 13)
#define LIT_REASON_INVALID_RK          (LCM_REASON_LYR_SPECIFIC + 14)
#define LIT_REASON_INVALID_RC          (LCM_REASON_LYR_SPECIFIC + 15)
#define LIT_REASON_PSID_ALREADY_USED   (LCM_REASON_LYR_SPECIFIC + 16)
#define LIT_REASON_RKREGREQ_PEND       (LCM_REASON_LYR_SPECIFIC + 17)
#define LIT_REASON_RKDEREGREQ_PEND     (LCM_REASON_LYR_SPECIFIC + 18)
#define LIT_REASON_DRKM_NOT_SUPP       (LCM_REASON_LYR_SPECIFIC + 19)
#define LIT_REASON_INVALID_THM         (LCM_REASON_LYR_SPECIFIC + 20)
#define LIT_REASON_INVALID_RTINDEX     (LCM_REASON_LYR_SPECIFIC + 21)
#define LIT_REASON_UNMATCH_NSAP        (LCM_REASON_LYR_SPECIFIC + 22)
#define LIT_REASON_UNMATCH_RTTYPE      (LCM_REASON_LYR_SPECIFIC + 23)
#define LIT_REASON_UNMATCH_NOSTATUS    (LCM_REASON_LYR_SPECIFIC + 24)
#define LIT_REASON_UNMATCH_RTFILTER    (LCM_REASON_LYR_SPECIFIC + 25)
#define LIT_REASON_OVERLAPPING_THM     (LCM_REASON_LYR_SPECIFIC + 26)
#define LIT_REASON_INVALID_CONG_LEVEL  (LCM_REASON_LYR_SPECIFIC + 27)
#define LIT_REASON_INVALID_DPC         (LCM_REASON_LYR_SPECIFIC + 28)
/* Failure reason for RK registration request */
#define LIT_REASON_PS_NOT_LOCAL        (LCM_REASON_LYR_SPECIFIC + 29)
#define LIT_REASON_NSAP_CFGED_LPS      (LCM_REASON_LYR_SPECIFIC + 30)

/* Packing and unpacking */
#define cmPkItTrid(x, mBuf)            SPkU32(x, mBuf)
#define cmUnpkItTrid(x, mBuf)          SUnpkU32(x, mBuf)
#define cmPkItNwkApp(x, mBuf)          SPkU32(x, mBuf)
#define cmUnpkItNwkApp(x, mBuf)        SUnpkU32(x, mBuf)
#define cmPkItPsId(x, mBuf)            SPkU32(x, mBuf)
#define cmUnpkItPsId(x, mBuf)          SUnpkU32(x, mBuf)
#define cmPkItPspId(x, mBuf)           SPkU16(x, mBuf)
#define cmUnpkItPspId(x, mBuf)         SUnpkU16(x, mBuf)
#define cmUnpkItSgId(x, mBuf)          SUnpkU16(x, mBuf)
#define cmPkItNwkId(x, mBuf)           SPkU8(x, mBuf)
#define cmUnpkItNwkId(x, mBuf)         SUnpkU8(x, mBuf)
#define cmPkItCongLevel(x, mBuf)       SPkU8(x, mBuf)
#define cmUnpkItCongLevel(x, mBuf)     SUnpkU8(x, mBuf)
#define cmPkItDpcSta(x, mBuf)          SPkU8(x, mBuf)
#define cmUnpkItDpcSta(x, mBuf)        SUnpkU8(x, mBuf)

/* Message and packing macros */
#define LITLOGERROR(errCls, errCode, errDesc)         \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,  \
                   __FILE__, __LINE__,                        \
                  (ErrCls)errCls, (ErrCode)errCode, (ErrVal)0, errDesc)

#define LIT_GETMSG(p, m, e) { \
    S16 ret; \
    ret = SGetMsg((p)->region, (p)->pool, &(m)); \
    if (ret != ROK) \
    { \
        LITLOGERROR(ERRCLS_ADD_RES, e, "SGetMsg failed"); \
        RETVALUE(ret); \
    } \
}

/* Error codes for functions at the LIT Interface */
#define   ELITBASE      000
#define   ELITXXX      (ELITBASE)         /* reserved */
#define   ERRLIT       (ELITBASE)         /* reserved */

#define   ELIT001      (ERRLIT +    1)    /*        lit.c: 675 */
#define   ELIT002      (ERRLIT +    2)    /*        lit.c: 680 */
#define   ELIT003      (ERRLIT +    3)    /*        lit.c: 684 */
#define   ELIT004      (ERRLIT +    4)    /*        lit.c: 688 */
#define   ELIT005      (ERRLIT +    5)    /*        lit.c: 692 */
#define   ELIT006      (ERRLIT +    6)    /*        lit.c: 696 */
#define   ELIT007      (ERRLIT +    7)    /*        lit.c: 700 */
#define   ELIT008      (ERRLIT +    8)    /*        lit.c: 704 */
#define   ELIT009      (ERRLIT +    9)    /*        lit.c: 710 */
#define   ELIT010      (ERRLIT +   10)    /*        lit.c: 715 */
#define   ELIT011      (ERRLIT +   11)    /*        lit.c:1250 */
#define   ELIT012      (ERRLIT +   12)    /*        lit.c:1255 */
#define   ELIT013      (ERRLIT +   13)    /*        lit.c:1259 */
#define   ELIT014      (ERRLIT +   14)    /*        lit.c:1263 */
#define   ELIT015      (ERRLIT +   15)    /*        lit.c:1267 */
#define   ELIT016      (ERRLIT +   16)    /*        lit.c:1271 */
#define   ELIT017      (ERRLIT +   17)    /*        lit.c:1275 */
#define   ELIT018      (ERRLIT +   18)    /*        lit.c:1279 */
#define   ELIT019      (ERRLIT +   19)    /*        lit.c:1285 */
#define   ELIT020      (ERRLIT +   20)    /*        lit.c:1333 */
#define   ELIT021      (ERRLIT +   21)    /*        lit.c:1342 */
#define   ELIT022      (ERRLIT +   22)    /*        lit.c:1348 */
#define   ELIT023      (ERRLIT +   23)    /*        lit.c:1358 */
#define   ELIT024      (ERRLIT +   24)    /*        lit.c:1365 */
#define   ELIT025      (ERRLIT +   25)    /*        lit.c:1369 */
#define   ELIT026      (ERRLIT +   26)    /*        lit.c:1376 */
#define   ELIT027      (ERRLIT +   27)    /*        lit.c:1384 */
#define   ELIT028      (ERRLIT +   28)    /*        lit.c:1386 */
#define   ELIT029      (ERRLIT +   29)    /*        lit.c:1398 */
#define   ELIT030      (ERRLIT +   30)    /*        lit.c:1405 */
#define   ELIT031      (ERRLIT +   31)    /*        lit.c:1408 */
#define   ELIT032      (ERRLIT +   32)    /*        lit.c:1409 */
#define   ELIT033      (ERRLIT +   33)    /*        lit.c:1410 */
#define   ELIT034      (ERRLIT +   34)    /*        lit.c:1412 */
#define   ELIT035      (ERRLIT +   35)    /*        lit.c:1416 */
#define   ELIT036      (ERRLIT +   36)    /*        lit.c:1418 */
#define   ELIT037      (ERRLIT +   37)    /*        lit.c:1419 */
#define   ELIT038      (ERRLIT +   38)    /*        lit.c:1421 */
#define   ELIT039      (ERRLIT +   39)    /*        lit.c:1422 */
#define   ELIT040      (ERRLIT +   40)    /*        lit.c:1423 */
#define   ELIT041      (ERRLIT +   41)    /*        lit.c:1430 */
#define   ELIT042      (ERRLIT +   42)    /*        lit.c:1434 */
#define   ELIT043      (ERRLIT +   43)    /*        lit.c:1442 */
#define   ELIT044      (ERRLIT +   44)    /*        lit.c:1447 */
#define   ELIT045      (ERRLIT +   45)    /*        lit.c:1451 */
#define   ELIT046      (ERRLIT +   46)    /*        lit.c:1458 */
#define   ELIT047      (ERRLIT +   47)    /*        lit.c:1462 */
#define   ELIT048      (ERRLIT +   48)    /*        lit.c:1466 */
#define   ELIT049      (ERRLIT +   49)    /*        lit.c:1470 */
#define   ELIT050      (ERRLIT +   50)    /*        lit.c:1475 */
#define   ELIT051      (ERRLIT +   51)    /*        lit.c:1493 */
#define   ELIT052      (ERRLIT +   52)    /*        lit.c:1496 */
#define   ELIT053      (ERRLIT +   53)    /*        lit.c:1499 */
#define   ELIT054      (ERRLIT +   54)    /*        lit.c:1502 */
#define   ELIT055      (ERRLIT +   55)    /*        lit.c:1504 */
#define   ELIT056      (ERRLIT +   56)    /*        lit.c:1506 */
#define   ELIT057      (ERRLIT +   57)    /*        lit.c:1508 */
#define   ELIT058      (ERRLIT +   58)    /*        lit.c:1513 */
#define   ELIT059      (ERRLIT +   59)    /*        lit.c:1532 */
#define   ELIT060      (ERRLIT +   60)    /*        lit.c:1535 */
#define   ELIT061      (ERRLIT +   61)    /*        lit.c:1537 */
#define   ELIT062      (ERRLIT +   62)    /*        lit.c:1539 */
#define   ELIT063      (ERRLIT +   63)    /*        lit.c:1541 */
#define   ELIT064      (ERRLIT +   64)    /*        lit.c:1546 */
#define   ELIT065      (ERRLIT +   65)    /*        lit.c:1558 */
#define   ELIT066      (ERRLIT +   66)    /*        lit.c:1567 */
#define   ELIT067      (ERRLIT +   67)    /*        lit.c:1570 */
#define   ELIT068      (ERRLIT +   68)    /*        lit.c:1571 */
#define   ELIT069      (ERRLIT +   69)    /*        lit.c:1572 */
#define   ELIT070      (ERRLIT +   70)    /*        lit.c:1573 */
#define   ELIT071      (ERRLIT +   71)    /*        lit.c:1672 */
#define   ELIT072      (ERRLIT +   72)    /*        lit.c:1673 */
#define   ELIT073      (ERRLIT +   73)    /*        lit.c:1674 */
#define   ELIT074      (ERRLIT +   74)    /*        lit.c:1675 */
#define   ELIT075      (ERRLIT +   75)    /*        lit.c:1680 */
#define   ELIT076      (ERRLIT +   76)    /*        lit.c:1691 */
#define   ELIT077      (ERRLIT +   77)    /*        lit.c:1697 */
#define   ELIT078      (ERRLIT +   78)    /*        lit.c:1706 */
#define   ELIT079      (ERRLIT +   79)    /*        lit.c:1713 */
#define   ELIT080      (ERRLIT +   80)    /*        lit.c:1718 */
#define   ELIT081      (ERRLIT +   81)    /*        lit.c:1733 */
#define   ELIT082      (ERRLIT +   82)    /*        lit.c:1735 */
#define   ELIT083      (ERRLIT +   83)    /*        lit.c:1744 */
#define   ELIT084      (ERRLIT +   84)    /*        lit.c:1746 */
#define   ELIT085      (ERRLIT +   85)    /*        lit.c:1749 */
#define   ELIT086      (ERRLIT +   86)    /*        lit.c:1762 */
#define   ELIT087      (ERRLIT +   87)    /*        lit.c:1764 */
#define   ELIT088      (ERRLIT +   88)    /*        lit.c:1766 */
#define   ELIT089      (ERRLIT +   89)    /*        lit.c:1768 */
#define   ELIT090      (ERRLIT +   90)    /*        lit.c:1774 */
#define   ELIT091      (ERRLIT +   91)    /*        lit.c:1780 */
#define   ELIT092      (ERRLIT +   92)    /*        lit.c:1785 */
#define   ELIT093      (ERRLIT +   93)    /*        lit.c:1787 */
#define   ELIT094      (ERRLIT +   94)    /*        lit.c:1789 */
#define   ELIT095      (ERRLIT +   95)    /*        lit.c:1791 */
#define   ELIT096      (ERRLIT +   96)    /*        lit.c:1793 */
#define   ELIT097      (ERRLIT +   97)    /*        lit.c:1801 */
#define   ELIT098      (ERRLIT +   98)    /*        lit.c:1805 */
#define   ELIT099      (ERRLIT +   99)    /*        lit.c:1809 */
#define   ELIT100      (ERRLIT +  100)    /*        lit.c:1817 */
#define   ELIT101      (ERRLIT +  101)    /*        lit.c:1823 */
#define   ELIT102      (ERRLIT +  102)    /*        lit.c:1827 */
#define   ELIT103      (ERRLIT +  103)    /*        lit.c:1831 */
#define   ELIT104      (ERRLIT +  104)    /*        lit.c:1837 */
#define   ELIT105      (ERRLIT +  105)    /*        lit.c:1841 */
#define   ELIT106      (ERRLIT +  106)    /*        lit.c:1845 */
#define   ELIT107      (ERRLIT +  107)    /*        lit.c:1855 */
#define   ELIT108      (ERRLIT +  108)    /*        lit.c:1858 */
#define   ELIT109      (ERRLIT +  109)    /*        lit.c:1860 */
#define   ELIT110      (ERRLIT +  110)    /*        lit.c:1862 */
#define   ELIT111      (ERRLIT +  111)    /*        lit.c:1867 */
#define   ELIT112      (ERRLIT +  112)    /*        lit.c:1870 */
#define   ELIT113      (ERRLIT +  113)    /*        lit.c:1873 */
#define   ELIT114      (ERRLIT +  114)    /*        lit.c:1879 */
#define   ELIT115      (ERRLIT +  115)    /*        lit.c:1882 */
#define   ELIT116      (ERRLIT +  116)    /*        lit.c:1884 */
#define   ELIT117      (ERRLIT +  117)    /*        lit.c:1887 */
#define   ELIT118      (ERRLIT +  118)    /*        lit.c:1893 */
#define   ELIT119      (ERRLIT +  119)    /*        lit.c:1900 */
#define   ELIT120      (ERRLIT +  120)    /*        lit.c:2353 */
#define   ELIT121      (ERRLIT +  121)    /*        lit.c:2366 */
#define   ELIT122      (ERRLIT +  122)    /*        lit.c:2370 */
#define   ELIT123      (ERRLIT +  123)    /*        lit.c:2375 */
#define   ELIT124      (ERRLIT +  124)    /*        lit.c:2380 */
#define   ELIT125      (ERRLIT +  125)    /*        lit.c:2385 */
#define   ELIT126      (ERRLIT +  126)    /*        lit.c:2389 */
#define   ELIT127      (ERRLIT +  127)    /*        lit.c:2393 */
#define   ELIT128      (ERRLIT +  128)    /*        lit.c:2394 */
#define   ELIT129      (ERRLIT +  129)    /*        lit.c:2398 */
#define   ELIT130      (ERRLIT +  130)    /*        lit.c:2404 */
#define   ELIT131      (ERRLIT +  131)    /*        lit.c:2409 */
#define   ELIT132      (ERRLIT +  132)    /*        lit.c:2410 */
#define   ELIT133      (ERRLIT +  133)    /*        lit.c:2863 */
#define   ELIT134      (ERRLIT +  134)    /*        lit.c:2864 */
#define   ELIT135      (ERRLIT +  135)    /*        lit.c:2878 */
#define   ELIT136      (ERRLIT +  136)    /*        lit.c:2883 */
#define   ELIT137      (ERRLIT +  137)    /*        lit.c:2888 */
#define   ELIT138      (ERRLIT +  138)    /*        lit.c:2893 */
#define   ELIT139      (ERRLIT +  139)    /*        lit.c:2898 */
#define   ELIT140      (ERRLIT +  140)    /*        lit.c:2902 */
#define   ELIT141      (ERRLIT +  141)    /*        lit.c:2906 */
#define   ELIT142      (ERRLIT +  142)    /*        lit.c:2907 */
#define   ELIT143      (ERRLIT +  143)    /*        lit.c:2911 */
#define   ELIT144      (ERRLIT +  144)    /*        lit.c:2918 */
#define   ELIT145      (ERRLIT +  145)    /*        lit.c:2966 */
#define   ELIT146      (ERRLIT +  146)    /*        lit.c:2971 */
#define   ELIT147      (ERRLIT +  147)    /*        lit.c:2975 */
#define   ELIT148      (ERRLIT +  148)    /*        lit.c:2979 */
#define   ELIT149      (ERRLIT +  149)    /*        lit.c:2983 */
#define   ELIT150      (ERRLIT +  150)    /*        lit.c:2987 */
#define   ELIT151      (ERRLIT +  151)    /*        lit.c:2991 */
#define   ELIT152      (ERRLIT +  152)    /*        lit.c:2995 */
#define   ELIT153      (ERRLIT +  153)    /*        lit.c:2999 */
#define   ELIT154      (ERRLIT +  154)    /*        lit.c:3004 */
#define   ELIT155      (ERRLIT +  155)    /*        lit.c:3008 */
#define   ELIT156      (ERRLIT +  156)    /*        lit.c:3012 */
#define   ELIT157      (ERRLIT +  157)    /*        lit.c:3013 */
#define   ELIT158      (ERRLIT +  158)    /*        lit.c:3014 */
#define   ELIT159      (ERRLIT +  159)    /*        lit.c:3015 */
#define   ELIT160      (ERRLIT +  160)    /*        lit.c:3019 */
#define   ELIT161      (ERRLIT +  161)    /*        lit.c:3025 */
#define   ELIT162      (ERRLIT +  162)    /*        lit.c:3030 */
#define   ELIT163      (ERRLIT +  163)    /*        lit.c:3031 */
#define   ELIT164      (ERRLIT +  164)    /*        lit.c:3032 */
#define   ELIT165      (ERRLIT +  165)    /*        lit.c:3081 */
#define   ELIT166      (ERRLIT +  166)    /*        lit.c:3082 */
#define   ELIT167      (ERRLIT +  167)    /*        lit.c:3083 */
#define   ELIT168      (ERRLIT +  168)    /*        lit.c:3088 */
#define   ELIT169      (ERRLIT +  169)    /*        lit.c:3093 */
#define   ELIT170      (ERRLIT +  170)    /*        lit.c:3097 */
#define   ELIT171      (ERRLIT +  171)    /*        lit.c:3101 */
#define   ELIT172      (ERRLIT +  172)    /*        lit.c:3105 */
#define   ELIT173      (ERRLIT +  173)    /*        lit.c:3109 */
#define   ELIT174      (ERRLIT +  174)    /*        lit.c:3113 */
#define   ELIT175      (ERRLIT +  175)    /*        lit.c:3117 */
#define   ELIT176      (ERRLIT +  176)    /*        lit.c:3122 */
#define   ELIT177      (ERRLIT +  177)    /*        lit.c:3125 */
#define   ELIT178      (ERRLIT +  178)    /*        lit.c:3129 */
#define   ELIT179      (ERRLIT +  179)    /*        lit.c:3130 */
#define   ELIT180      (ERRLIT +  180)    /*        lit.c:3131 */
#define   ELIT181      (ERRLIT +  181)    /*        lit.c:3132 */
#define   ELIT182      (ERRLIT +  182)    /*        lit.c:3136 */
#define   ELIT183      (ERRLIT +  183)    /*        lit.c:3141 */
#define   ELIT184      (ERRLIT +  184)    /*        lit.c:3521 */
#define   ELIT185      (ERRLIT +  185)    /*        lit.c:3529 */
#define   ELIT186      (ERRLIT +  186)    /*        lit.c:3533 */
#define   ELIT187      (ERRLIT +  187)    /*        lit.c:3537 */
#define   ELIT188      (ERRLIT +  188)    /*        lit.c:3543 */
#define   ELIT189      (ERRLIT +  189)    /*        lit.c:3548 */
#define   ELIT190      (ERRLIT +  190)    /*        lit.c:3549 */
#define   ELIT191      (ERRLIT +  191)    /*        lit.c:3550 */
#define   ELIT192      (ERRLIT +  192)    /*        lit.c:3551 */
#define   ELIT193      (ERRLIT +  193)    /*        lit.c:3597 */
#define   ELIT194      (ERRLIT +  194)    /*        lit.c:3602 */
#define   ELIT195      (ERRLIT +  195)    /*        lit.c:3606 */
#define   ELIT196      (ERRLIT +  196)    /*        lit.c:3610 */
#define   ELIT197      (ERRLIT +  197)    /*        lit.c:3614 */
#define   ELIT198      (ERRLIT +  198)    /*        lit.c:3620 */
#define   ELIT199      (ERRLIT +  199)    /*        lit.c:3625 */
#define   ELIT200      (ERRLIT +  200)    /*        lit.c:3626 */
#define   ELIT201      (ERRLIT +  201)    /*        lit.c:3627 */
#define   ELIT202      (ERRLIT +  202)    /*        lit.c:3628 */
#define   ELIT203      (ERRLIT +  203)    /*        lit.c:4005 */
#define   ELIT204      (ERRLIT +  204)    /*        lit.c:4006 */
#define   ELIT205      (ERRLIT +  205)    /*        lit.c:4007 */
#define   ELIT206      (ERRLIT +  206)    /*        lit.c:4008 */
#define   ELIT207      (ERRLIT +  207)    /*        lit.c:4016 */
#define   ELIT208      (ERRLIT +  208)    /*        lit.c:4020 */
#define   ELIT209      (ERRLIT +  209)    /*        lit.c:4024 */
#define   ELIT210      (ERRLIT +  210)    /*        lit.c:4030 */
#define   ELIT211      (ERRLIT +  211)    /*        lit.c:4079 */
#define   ELIT212      (ERRLIT +  212)    /*        lit.c:4080 */
#define   ELIT213      (ERRLIT +  213)    /*        lit.c:4081 */
#define   ELIT214      (ERRLIT +  214)    /*        lit.c:4082 */
#define   ELIT215      (ERRLIT +  215)    /*        lit.c:4087 */
#define   ELIT216      (ERRLIT +  216)    /*        lit.c:4091 */
#define   ELIT217      (ERRLIT +  217)    /*        lit.c:4095 */
#define   ELIT218      (ERRLIT +  218)    /*        lit.c:4099 */
#define   ELIT219      (ERRLIT +  219)    /*        lit.c:4105 */
#define   ELIT220      (ERRLIT +  220)    /*        lit.c:4152 */
#define   ELIT221      (ERRLIT +  221)    /*        lit.c:4154 */
#define   ELIT222      (ERRLIT +  222)    /*        lit.c:4155 */
#define   ELIT223      (ERRLIT +  223)    /*        lit.c:4203 */
#define   ELIT224      (ERRLIT +  224)    /*        lit.c:4204 */
#define   ELIT225      (ERRLIT +  225)    /*        lit.c:4249 */
#define   ELIT226      (ERRLIT +  226)    /*        lit.c:4255 */
#define   ELIT227      (ERRLIT +  227)    /*        lit.c:4256 */
#define   ELIT228      (ERRLIT +  228)    /*        lit.c:4258 */
#define   ELIT229      (ERRLIT +  229)    /*        lit.c:4260 */
#define   ELIT230      (ERRLIT +  230)    /*        lit.c:4262 */
#define   ELIT231      (ERRLIT +  231)    /*        lit.c:4263 */
#define   ELIT232      (ERRLIT +  232)    /*        lit.c:4312 */
#define   ELIT233      (ERRLIT +  233)    /*        lit.c:4313 */
#define   ELIT234      (ERRLIT +  234)    /*        lit.c:4315 */
#define   ELIT235      (ERRLIT +  235)    /*        lit.c:4319 */
#define   ELIT236      (ERRLIT +  236)    /*        lit.c:4322 */
#define   ELIT237      (ERRLIT +  237)    /*        lit.c:4323 */
#define   ELIT238      (ERRLIT +  238)    /*        lit.c:4370 */
#define   ELIT239      (ERRLIT +  239)    /*        lit.c:4378 */
#define   ELIT240      (ERRLIT +  240)    /*        lit.c:4380 */
#define   ELIT241      (ERRLIT +  241)    /*        lit.c:4383 */
#define   ELIT242      (ERRLIT +  242)    /*        lit.c:4385 */
#define   ELIT243      (ERRLIT +  243)    /*        lit.c:4386 */
#define   ELIT244      (ERRLIT +  244)    /*        lit.c:4389 */
#define   ELIT245      (ERRLIT +  245)    /*        lit.c:4393 */
#define   ELIT246      (ERRLIT +  246)    /*        lit.c:4394 */
#define   ELIT247      (ERRLIT +  247)    /*        lit.c:4396 */
#define   ELIT248      (ERRLIT +  248)    /*        lit.c:4399 */
#define   ELIT249      (ERRLIT +  249)    /*        lit.c:4401 */
#define   ELIT250      (ERRLIT +  250)    /*        lit.c:4404 */
#define   ELIT251      (ERRLIT +  251)    /*        lit.c:4406 */
#define   ELIT252      (ERRLIT +  252)    /*        lit.c:4407 */
#define   ELIT253      (ERRLIT +  253)    /*        lit.c:4414 */
#define   ELIT254      (ERRLIT +  254)    /*        lit.c:4416 */
#define   ELIT255      (ERRLIT +  255)    /*        lit.c:4417 */
#define   ELIT256      (ERRLIT +  256)    /*        lit.c:4421 */
#define   ELIT257      (ERRLIT +  257)    /*        lit.c:4422 */
#define   ELIT258      (ERRLIT +  258)    /*        lit.c:4423 */
#define   ELIT259      (ERRLIT +  259)    /*        lit.c:4432 */
#define   ELIT260      (ERRLIT +  260)    /*        lit.c:4435 */
#define   ELIT261      (ERRLIT +  261)    /*        lit.c:4443 */
#define   ELIT262      (ERRLIT +  262)    /*        lit.c:4446 */
#define   ELIT263      (ERRLIT +  263)    /*        lit.c:4451 */
#define   ELIT264      (ERRLIT +  264)    /*        lit.c:4454 */
#define   ELIT265      (ERRLIT +  265)    /*        lit.c:4456 */
#define   ELIT266      (ERRLIT +  266)    /*        lit.c:4458 */
#define   ELIT267      (ERRLIT +  267)    /*        lit.c:4460 */
#define   ELIT268      (ERRLIT +  268)    /*        lit.c:4465 */
#define   ELIT269      (ERRLIT +  269)    /*        lit.c:4468 */
#define   ELIT270      (ERRLIT +  270)    /*        lit.c:4470 */
#define   ELIT271      (ERRLIT +  271)    /*        lit.c:4475 */
#define   ELIT272      (ERRLIT +  272)    /*        lit.c:4478 */
#define   ELIT273      (ERRLIT +  273)    /*        lit.c:4488 */
#define   ELIT274      (ERRLIT +  274)    /*        lit.c:4498 */
#define   ELIT275      (ERRLIT +  275)    /*        lit.c:4507 */
#define   ELIT276      (ERRLIT +  276)    /*        lit.c:4511 */
#define   ELIT277      (ERRLIT +  277)    /*        lit.c:4515 */
#define   ELIT278      (ERRLIT +  278)    /*        lit.c:4519 */
#define   ELIT279      (ERRLIT +  279)    /*        lit.c:4524 */
#define   ELIT280      (ERRLIT +  280)    /*        lit.c:4530 */
#define   ELIT281      (ERRLIT +  281)    /*        lit.c:4538 */
#define   ELIT282      (ERRLIT +  282)    /*        lit.c:4539 */
#define   ELIT283      (ERRLIT +  283)    /*        lit.c:4588 */
#define   ELIT284      (ERRLIT +  284)    /*        lit.c:4589 */
#define   ELIT285      (ERRLIT +  285)    /*        lit.c:4594 */
#define   ELIT286      (ERRLIT +  286)    /*        lit.c:4598 */
#define   ELIT287      (ERRLIT +  287)    /*        lit.c:4602 */
#define   ELIT288      (ERRLIT +  288)    /*        lit.c:4606 */
#define   ELIT289      (ERRLIT +  289)    /*        lit.c:4611 */
#define   ELIT290      (ERRLIT +  290)    /*        lit.c:4616 */
#define   ELIT291      (ERRLIT +  291)    /*        lit.c:4625 */
#define   ELIT292      (ERRLIT +  292)    /*        lit.c:4627 */
#define   ELIT293      (ERRLIT +  293)    /*        lit.c:4629 */
#define   ELIT294      (ERRLIT +  294)    /*        lit.c:4633 */
#define   ELIT295      (ERRLIT +  295)    /*        lit.c:4637 */
#define   ELIT296      (ERRLIT +  296)    /*        lit.c:4642 */
#define   ELIT297      (ERRLIT +  297)    /*        lit.c:4648 */
#define   ELIT298      (ERRLIT +  298)    /*        lit.c:4649 */
#define   ELIT299      (ERRLIT +  299)    /*        lit.c:4653 */
#define   ELIT300      (ERRLIT +  300)    /*        lit.c:4657 */
#define   ELIT301      (ERRLIT +  301)    /*        lit.c:4662 */
#define   ELIT302      (ERRLIT +  302)    /*        lit.c:4665 */
#define   ELIT303      (ERRLIT +  303)    /*        lit.c:4666 */
#define   ELIT304      (ERRLIT +  304)    /*        lit.c:4667 */
#define   ELIT305      (ERRLIT +  305)    /*        lit.c:4675 */
#define   ELIT306      (ERRLIT +  306)    /*        lit.c:4676 */
#define   ELIT307      (ERRLIT +  307)    /*        lit.c:4678 */
#define   ELIT308      (ERRLIT +  308)    /*        lit.c:4683 */
#define   ELIT309      (ERRLIT +  309)    /*        lit.c:4684 */
#define   ELIT310      (ERRLIT +  310)    /*        lit.c:4686 */
#define   ELIT311      (ERRLIT +  311)    /*        lit.c:4697 */
#define   ELIT312      (ERRLIT +  312)    /*        lit.c:4699 */
#define   ELIT313      (ERRLIT +  313)    /*        lit.c:4709 */
#define   ELIT314      (ERRLIT +  314)    /*        lit.c:4711 */
#define   ELIT315      (ERRLIT +  315)    /*        lit.c:4717 */
#define   ELIT316      (ERRLIT +  316)    /*        lit.c:4719 */
#define   ELIT317      (ERRLIT +  317)    /*        lit.c:4721 */
#define   ELIT318      (ERRLIT +  318)    /*        lit.c:4723 */
#define   ELIT319      (ERRLIT +  319)    /*        lit.c:4725 */
#define   ELIT320      (ERRLIT +  320)    /*        lit.c:4731 */
#define   ELIT321      (ERRLIT +  321)    /*        lit.c:4733 */
#define   ELIT322      (ERRLIT +  322)    /*        lit.c:4735 */
#define   ELIT323      (ERRLIT +  323)    /*        lit.c:4741 */
#define   ELIT324      (ERRLIT +  324)    /*        lit.c:4743 */
#define   ELIT325      (ERRLIT +  325)    /*        lit.c:4754 */
#define   ELIT326      (ERRLIT +  326)    /*        lit.c:4764 */
#define   ELIT327      (ERRLIT +  327)    /*        lit.c:4813 */
#define   ELIT328      (ERRLIT +  328)    /*        lit.c:4822 */
#define   ELIT329      (ERRLIT +  329)    /*        lit.c:4825 */
#define   ELIT330      (ERRLIT +  330)    /*        lit.c:4826 */
#define   ELIT331      (ERRLIT +  331)    /*        lit.c:4827 */
#define   ELIT332      (ERRLIT +  332)    /*        lit.c:4828 */
#define   ELIT333      (ERRLIT +  333)    /*        lit.c:4829 */
#define   ELIT334      (ERRLIT +  334)    /*        lit.c:4830 */
#define   ELIT335      (ERRLIT +  335)    /*        lit.c:4879 */
#define   ELIT336      (ERRLIT +  336)    /*        lit.c:4880 */
#define   ELIT337      (ERRLIT +  337)    /*        lit.c:4881 */
#define   ELIT338      (ERRLIT +  338)    /*        lit.c:4882 */
#define   ELIT339      (ERRLIT +  339)    /*        lit.c:4883 */
#define   ELIT340      (ERRLIT +  340)    /*        lit.c:4884 */
#define   ELIT341      (ERRLIT +  341)    /*        lit.c:4888 */




/***********************************************************************
            defines to include/exclude packing/unpacking code
***********************************************************************/



/***********************************************************************
              error codes for packing/unpacking functions
***********************************************************************/



#endif /* not defined __LITH__ */

/********************************************************************30**

         End of file:     lit.h@@/main/7 - Thu Apr  1 03:50:23 2004

*********************************************************************31*/
/********************************************************************40**

        Notes:

*********************************************************************41*/
/********************************************************************50**

*********************************************************************51*/

/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      mrw  1. initial release
/main/3      ---      nt   1. LIT_MAX_SG and LIT_MAX_ASP changed to 20.
             ---      mrw  2. Updates to Release 1.2
/main/4      ---      sg   1. Routing and IPSP changes.
             ---      sg   2. Updated error codes.
             ---      sg   3. Update to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it001.104  sg   1. Changes for Outgoing Message Routing based on
                              Local PS status at ASP/IPSP.
           it001.104  vt   2. Patch propagation for 1.2
           it005.104  cg   1. Added define for Maximum Static PsId
           it007.104  cg   1. Added define for error code in packing/unpacking 
           it016.104  vt   1. Added new cause defines to be sent to LM
           it022.104  uv   1. Added new cause and event defines to be 
                              sent to LM for route alarms
                           2. New element for Signaling Gateway (SG)
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to release 1.6.
/main/7    it005.106  sg   1. Added new hash define for unused su2Swtch and 
                              change in an existing comment.
/main/7    it006.106  sg   1. Added new event hash defines for status 
                              indications in ItLiSctEndpCloseCfm.
/main/7    it011.106  sg   1. Added new LIT interface version.
                           2. Added a default value for tos in ItAssocCfg.
                           3. Added bit definition for compile flag SCT3. 
lit_h_001.main_7      sg   1. Support for MGCP added.
lit_h_002.main_7      sg   1. Added new event hash defines for status 
                              indications when M3UA at SGP receives SN_RSTBEG 
                              and SN_RSTEND indications from MTP3.
lit_h_003.main_7      sg   1. Added new cause hash define for status 
                              indication when M3UA receives SctStaInd with 
                              status as SCT_STATUS_SND_FAIL.
lit_h_004.main_7      sg   1. Added new LIT interface version.
lit_h_005.main_7      sg   1. Added new LIT interface version.
lit_h_006.main_7      sg   1. Added new LIT interface version to use abrtFlag 
                              in PSP deletion control request.
                           2. Added a default value for abrtFlag in PSP
                              deletion cntrlReq.
                           3. Added bit definition for compile flag 
                              IT_ABORT_ASSOC. 
lit_h_007.main_7      sg   1. Added new LIT interface version LITV6 for
                              PS based statistics.
*********************************************************************91*/
