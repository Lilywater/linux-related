/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     C Source Code.
  
     Desc:     Management Interface Include file
 
     File:     lns.h

     Sid:      lns.h 1.1  -  05/13/98 17:14:30
  
     Prg:      ag
  
*********************************************************************21*/

#ifndef __LNSH__
#define __LNSH__


/* NTSS Management Events */
 
#define EVTLNSCFGREQ          0x3c     /* Configuration request */
#define EVTLNSSTAREQ          0x40     /* Status request */
#define EVTLNSSTACFM          0x41     /* Status confirm */
#define EVTLNSSTAIND          0x42     /* Status indication */
#define EVTLNSSTSREQ          0x44     /* Statistics request */
#define EVTLNSSTSCFM          0x45     /* Statistics confirm */
#define EVTLNSTRCIND          0x48     /* Trace indication */
#define EVTLNSCNTRLREQ        0x4c     /* Control request */
#define EVTLNSCNTRLCFM        0x4d     /* Control confirm */


/* Cause codes for LnsStaInd */

#define LNS_STA_CFG_FAIL        1       /* config request failed */
#define LNS_STA_CFG_DATE_OK     2       /* date config okay */
#define LNS_STA_CFG_DATE_FAIL   3       /* date config failed */
#define LNS_STA_CNTRL_FAIL      4       /* cntrl request failed */
#define LNS_STA_CNTRL_PST_OK    5       /* management post struct cntrl okay */
#define LNS_STA_CNTRL_PST_FAIL  6       /* management post struct cntrl fail */

/* macro for logging errors */
#define LNSLOGERROR(ent, inst, procId, errCls, errCode, errVal, errDesc) \
        SLogError((Ent) ent, \
             (Inst)inst, \
             (ProcId)  procId, \
             (Txt *)   __FILE__, \
             (S32)     __LINE__, \
             (ErrCls)  errCls, \
             (ErrCode) errCode, \
             (ErrVal)  errVal, \
             (Txt *)   errDesc)


/* error codes */
#define  ELNSBASE     0                /* reserved */
#define  ELNSXXX      (ELNSBASE)       /* reserved */

#define   ELNS001      (ELNSBASE +    1)    /*        lns.c: 181 */
#define   ELNS002      (ELNSBASE +    2)    /*        lns.c: 185 */
#define   ELNS003      (ELNSBASE +    3)    /*        lns.c: 187 */
#define   ELNS004      (ELNSBASE +    4)    /*        lns.c: 189 */
#define   ELNS005      (ELNSBASE +    5)    /*        lns.c: 191 */
#define   ELNS006      (ELNSBASE +    6)    /*        lns.c: 195 */
#define   ELNS007      (ELNSBASE +    7)    /*        lns.c: 197 */
#define   ELNS008      (ELNSBASE +    8)    /*        lns.c: 199 */
#define   ELNS009      (ELNSBASE +    9)    /*        lns.c: 202 */
#define   ELNS010      (ELNSBASE +   10)    /*        lns.c: 205 */
#define   ELNS011      (ELNSBASE +   11)    /*        lns.c: 206 */
#define   ELNS012      (ELNSBASE +   12)    /*        lns.c: 213 */
#define   ELNS013      (ELNSBASE +   13)    /*        lns.c: 219 */
#define   ELNS014      (ELNSBASE +   14)    /*        lns.c: 220 */
#define   ELNS015      (ELNSBASE +   15)    /*        lns.c: 270 */
#define   ELNS016      (ELNSBASE +   16)    /*        lns.c: 272 */
#define   ELNS017      (ELNSBASE +   17)    /*        lns.c: 274 */
#define   ELNS018      (ELNSBASE +   18)    /*        lns.c: 276 */
#define   ELNS019      (ELNSBASE +   19)    /*        lns.c: 278 */
#define   ELNS020      (ELNSBASE +   20)    /*        lns.c: 282 */
#define   ELNS021      (ELNSBASE +   21)    /*        lns.c: 284 */
#define   ELNS022      (ELNSBASE +   22)    /*        lns.c: 288 */
#define   ELNS023      (ELNSBASE +   23)    /*        lns.c: 295 */
#define   ELNS024      (ELNSBASE +   24)    /*        lns.c: 301 */
#define   ELNS025      (ELNSBASE +   25)    /*        lns.c: 302 */
#define   ELNS026      (ELNSBASE +   26)    /*        lns.c: 303 */
#define   ELNS027      (ELNSBASE +   27)    /*        lns.c: 349 */
#define   ELNS028      (ELNSBASE +   28)    /*        lns.c: 352 */
#define   ELNS029      (ELNSBASE +   29)    /*        lns.c: 355 */
#define   ELNS030      (ELNSBASE +   30)    /*        lns.c: 356 */
#define   ELNS031      (ELNSBASE +   31)    /*        lns.c: 394 */
#define   ELNS032      (ELNSBASE +   32)    /*        lns.c: 433 */
#define   ELNS033      (ELNSBASE +   33)    /*        lns.c: 434 */
#define   ELNS034      (ELNSBASE +   34)    /*        lns.c: 435 */
#define   ELNS035      (ELNSBASE +   35)    /*        lns.c: 436 */
#define   ELNS036      (ELNSBASE +   36)    /*        lns.c: 437 */
#define   ELNS037      (ELNSBASE +   37)    /*        lns.c: 475 */
#define   ELNS038      (ELNSBASE +   38)    /*        lns.c: 476 */
#define   ELNS039      (ELNSBASE +   39)    /*        lns.c: 523 */
#define   ELNS040      (ELNSBASE +   40)    /*        lns.c: 566 */
#define   ELNS041      (ELNSBASE +   41)    /*        lns.c: 567 */
#define   ELNS042      (ELNSBASE +   42)    /*        lns.c: 568 */
#define   ELNS043      (ELNSBASE +   43)    /*        lns.c: 569 */
#define   ELNS044      (ELNSBASE +   44)    /*        lns.c: 570 */
#define   ELNS045      (ELNSBASE +   45)    /*        lns.c: 616 */
#define   ELNS046      (ELNSBASE +   46)    /*        lns.c: 617 */
#define   ELNS047      (ELNSBASE +   47)    /*        lns.c: 659 */
#define   ELNS048      (ELNSBASE +   48)    /*        lns.c: 660 */
#define   ELNS049      (ELNSBASE +   49)    /*        lns.c: 670 */
#define   ELNS050      (ELNSBASE +   50)    /*        lns.c: 675 */
#define   ELNS051      (ELNSBASE +   51)    /*        lns.c: 677 */
#define   ELNS052      (ELNSBASE +   52)    /*        lns.c: 679 */
#define   ELNS053      (ELNSBASE +   53)    /*        lns.c: 681 */
#define   ELNS054      (ELNSBASE +   54)    /*        lns.c: 686 */
#define   ELNS055      (ELNSBASE +   55)    /*        lns.c: 688 */
#define   ELNS056      (ELNSBASE +   56)    /*        lns.c: 690 */
#define   ELNS057      (ELNSBASE +   57)    /*        lns.c: 694 */
#define   ELNS058      (ELNSBASE +   58)    /*        lns.c: 699 */
#define   ELNS059      (ELNSBASE +   59)    /*        lns.c: 701 */
#define   ELNS060      (ELNSBASE +   60)    /*        lns.c: 708 */
#define   ELNS061      (ELNSBASE +   61)    /*        lns.c: 753 */
#define   ELNS062      (ELNSBASE +   62)    /*        lns.c: 754 */
#define   ELNS063      (ELNSBASE +   63)    /*        lns.c: 755 */
#define   ELNS064      (ELNSBASE +   64)    /*        lns.c: 760 */
#define   ELNS065      (ELNSBASE +   65)    /*        lns.c: 762 */
#define   ELNS066      (ELNSBASE +   66)    /*        lns.c: 764 */
#define   ELNS067      (ELNSBASE +   67)    /*        lns.c: 766 */
#define   ELNS068      (ELNSBASE +   68)    /*        lns.c: 768 */
#define   ELNS069      (ELNSBASE +   69)    /*        lns.c: 773 */
#define   ELNS070      (ELNSBASE +   70)    /*        lns.c: 775 */
#define   ELNS071      (ELNSBASE +   71)    /*        lns.c: 780 */
#define   ELNS072      (ELNSBASE +   72)    /*        lns.c: 786 */
#define   ELNS073      (ELNSBASE +   73)    /*        lns.c: 831 */
#define   ELNS074      (ELNSBASE +   74)    /*        lns.c: 832 */
#define   ELNS075      (ELNSBASE +   75)    /*        lns.c: 835 */
#define   ELNS076      (ELNSBASE +   76)    /*        lns.c: 837 */

#endif /* __LNSH__ */


/********************************************************************30**
  
         End of file: lns.h 1.1  -  05/13/98 17:14:30
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release.
  
*********************************************************************91*/
