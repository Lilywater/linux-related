/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Session Initiation Protocol (SIP)

     Type:     C include file

     Desc:     Defines required by SIP and Layer Manager

     File:     lso.h

     Sid:      lso.h@@/main/4 - Tue Apr 20 12:45:40 2004

     Prg:      wvdl

*********************************************************************21*/

#ifndef __LSOH__
#define __LSOH__

/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000156     SIP
*
*/


/* defines */

/* Layer MAnager REASON fields */
#define LSO_REASON_NO_TPTSERVERS   (LCM_REASON_LYR_SPECIFIC + 1)
/* remove LSO_REASON_TPTSRV_OVERLAP. But do not shift other values because
   the customer might have similar defines in his place */
/* #define LSO_REASON_TPTSRV_OVERLAP  (LCM_REASON_LYR_SPECIFIC + 2) */
#define LSO_REASON_INV_TPTSRV      (LCM_REASON_LYR_SPECIFIC + 3)
#define LSO_REASON_INVALID_ENTID   (LCM_REASON_LYR_SPECIFIC + 4)
#define LSO_REASON_MAX_BND_RETRY   (LCM_REASON_LYR_SPECIFIC + 5)
#define LSO_REASON_CACHE_EXT       (LCM_REASON_LYR_SPECIFIC + 6)
#define LSO_REASON_INV_CALLHDL     (LCM_REASON_LYR_SPECIFIC + 7)

/* Layer MAnager CAUSE fields */
/* cause - SAP bind, disabled */
#define LSO_CAUSE_SAP_BNDDIS        (LCM_CAUSE_LYR_SPECIFIC + 1)
/* cause - SAP bound, enabled */
#define LSO_CAUSE_SAP_BNDENA        (LCM_CAUSE_LYR_SPECIFIC + 2)
/* cause - SAP unbind, disabled */
#define LSO_CAUSE_SAP_UBNDDIS       (LCM_CAUSE_LYR_SPECIFIC + 3)
/* Alarm caused by indication from lower interface */
#define LSO_CAUSE_LI_INITIATED      (LCM_CAUSE_LYR_SPECIFIC + 4)
/* cause - invalid suConnId */
#define LSO_CAUSE_INV_SUCONNID      (LCM_CAUSE_LYR_SPECIFIC + 5)
/* cause - invalid spConnId */
#define LSO_CAUSE_INV_SPCONNID      (LCM_CAUSE_LYR_SPECIFIC + 6)
/* cause - invalid entId */
#define LSO_CAUSE_INV_ENTID         (LCM_CAUSE_LYR_SPECIFIC + 7)
/* cause - transport server going down */
#define LSO_CAUSE_TPT_FAIL          (LCM_CAUSE_LYR_SPECIFIC + 8)

/* maximums and minimums */
#define LSO_MAX_ADDRS             10     /* Max. number of transport addr. */
#define LSO_PROTVER_SZ             4     /* Max. prot. version string size */
#define LSO_NODEID_SZ              6     /* Max. nodeId string size */
#define LSO_TPTSRV_MIN_SSAP        1     /* Min. number of SSAP tpt addr. */
#define LSO_TPTSRV_MAX_SSAP       10     /* Max. number of SSAP tpt addr. */
#define LSO_HOSTNAME_MAX_SZ       80     /* Max. hostname string size */
#define LSO_TPTSRV_MIN             1     /* Min. number of tpt servers */
#define LSO_TPTSRV_MAX            10     /* Max. number of transport servers */
#define LSO_STR_SZ                30     /* Max. org, server, user agent,
                                            package name len */

/* so027.201: Changes to support SIP TLS */
#ifdef SO_TLS
#define LSO_TLS_DEFAULT_CTX       0      /* Default TLS Context */
#endif /* SO_TLS */

#define LSO_MAX_EVENT_PKG_LIST    10     /* Max. length of Std and nonStd event
                                            package list */
#define LSO_NUM_INT_PACKAGES       1     /* Number of event packages implemented
                                            inside the layer (e.g. REFER)     */
#define LSO_NUM_TOTAL_PKG  ( LSO_MAX_EVENT_PKG_LIST +  LSO_NUM_INT_PACKAGES)
#define LSO_MIN_PRX_THRESH         0     /* Min. resource thresh. for proxy */
#define LSO_MAX_PRX_THRESH       100     /* Max. resource thresh. for proxy */
#define LSO_THRESH_MIN             0     /* Min. local registry threshold */
#define LSO_MIN_FRKTM              1     /* Min. fork time out value */

#define LSO_MAX_SSAP_PER_ENTITY   100    /* Max SSAPs per entity */

/* Functional entity to which TSAP is bound */
#define LSO_UAC_ENTITY             1     /* UAC entity bound to TSAP */
#define LSO_UAS_ENTITY             2     /* UAS entity bound to TSAP */
#define LSO_REGISTRAR_ENTITY       3     /* Registrar entity bound to TSAP */
#define LSO_PROXY_ENTITY           4     /* Proxy entity bound to TSAP */
#define LSO_REDIRECT_ENTITY        5     /* Redirect entity bound to TSAP */
#define LSO_DNS_ENTITY             6     /* DNS entity bound to TSAP */

#define LSO_REDIRECT               7     /* proxy server action */
#define LSO_PROXY                  8     /* proxy server action */

/* Service provided by entity */
#define LSO_ENT_NONE               0     /* UA service */
#define LSO_ENT_UA                 1     /* UA service */
#define LSO_ENT_NS                 2     /* Network server service */

/* TSAP states */
#define LSO_TSAP_UBNDDIS           1     /* TSAP unbound and disabled */
#define LSO_TSAP_BNDENA            2     /* TSAP bound and enabled */
#define LSO_TSAP_BNDDIS            3     /* TSAP bound and disabled */
#define LSO_TSAP_WAIT_BNDDIS       4     /* TSAP awaiting bind confirm */
                                         /* before LSO_SAP_BND_DIS */
#define LSO_TSAP_WAIT_BNDENA       5     /* TSAP awaiting bind confirm */
                                         /* before LSO_SAP_BND_ENA */


/* Transport server states */
#define LSO_TPTSRV_ENA             1     /* Transport server is enabled */
#define LSO_TPTSRV_DIS             2     /* Disabled state */
#define LSO_TPTSRV_WAIT_ENA        3     /* Waiting to be enabled */

/* SSAP states */
#define LSO_SSAP_UBNDDIS           1     /* SSAP inbound and disabled */
#define LSO_SSAP_BNDENA            2     /* SSAP bound and enabled    */

/* Address control block transport protocol types */
/* These values should match with the values in sot.h */
#define LSO_TPTPROT_NULL           0     /* NULL TPT */
#define LSO_TPTPROT_UDP            1     /* UDP listening server */
#define LSO_TPTPROT_TCP            2     /* TCP listening server */
#define LSO_TPTPROT_SCTP           3     /* SCTP TPT */
#define LSO_TPTPROT_TLS_TCP        4     /* TLS TCP TPT */
#define LSO_TPTPROT_UDP_PRIOR      5     /* UDP Priority listening server */
#define LSO_TPTPROT_UNKNOWN        6     /* Unknown TPT */

/* State of entity */
#define LSO_ENT_ENABLED            1     /* Entity enabled */
#define LSO_ENT_DISABLED           2     /* Entity disabled */
#define LSO_ENT_WAIT_ENB           3     /* Entity waiting to be enabled */
#define LSO_ENT_WAIT_DIS           4     /* Entity waiting to be disabled */

#define LSO_NONE                   0     /* no multicast cache */

/* Multicast cache location */
#define LSO_INTERNAL               1     /* cache to be kept internally */
#define LSO_EXTERNAL               2     /* cache to be kept externally */

/* Cache/Registry Memory Sizes */
#define LSO_CACHE_DFLT_MEM_SIZE    16384 /* The default maximum cache
                                           memory size */
#define LSO_CACHE_MIN_MEM_SIZE     1024  /* The minimum size a cache can be */

/* Server type */
#define LSO_NO_REGISTER            0     /* No registration functionlaity is supported */
#define LSO_STAND_ALONE            1     /* Stand alone registrar server               */
#define LSO_COLOCATED              2     /* Registrar co-located with a NS             */

/* Type of statistics */
#define LSO_STS_DNS                1     /* DNS specific statistics */
#define LSO_STS_SUMM               2     /* Entity wide summary statistics */
#define LSO_STS_METH               3     /* Per-method summary statistics */
#define LSO_STS_RESP               4     /* Response status code statistics */
#define LSO_STS_OTHER              5     /* Other statistics */
#define LSO_STS_UA                 6     /* User agent specific statistics */
#define LSO_STS_NS                 7     /* Network server statistics */

/* State of proxy */
#define LSO_PRX_STATEFUL           0     /* Proxy stateful */
#define LSO_PRX_STATELESS          1     /* Proxy stateless */


/* Events which trigger alarms */
/* HIT bind confirm */
#define LSO_EVENT_HIT_BNDCFM    (LCM_EVENT_LYR_SPECIFIC + 1)
/* HIT connect confirm */
#define LSO_EVENT_HIT_CONCFM    (LCM_EVENT_LYR_SPECIFIC + 2)
/* HIT connect indicate */
#define LSO_EVENT_HIT_CONIND    (LCM_EVENT_LYR_SPECIFIC + 3)
/* HIT data indicate */
#define LSO_EVENT_HIT_DATIND    (LCM_EVENT_LYR_SPECIFIC + 4)
/* HIT disconnect indicate */
#define LSO_EVENT_HIT_DISCIND   (LCM_EVENT_LYR_SPECIFIC + 5)
/* HIT UDP data indicate */
#define LSO_EVENT_HIT_UDATIND   (LCM_EVENT_LYR_SPECIFIC + 6)
/* SOT bind request */
#define LSO_EVENT_SOT_BNDREQ    (LCM_EVENT_LYR_SPECIFIC + 7)
/* SOT unbind request */
#define LSO_EVENT_SOT_UBNDREQ   (LCM_EVENT_LYR_SPECIFIC + 8)
/* SOT connect request */
#define LSO_EVENT_SOT_CONREQ    (LCM_EVENT_LYR_SPECIFIC + 9)
/* SOT connect response */
#define LSO_EVENT_SOT_CONRSP    (LCM_EVENT_LYR_SPECIFIC + 10)
/* SOT CIM request */
#define LSO_EVENT_SOT_CIMREQ    (LCM_EVENT_LYR_SPECIFIC + 11)
/* SOT CIM response */
#define LSO_EVENT_SOT_CIMRSP    (LCM_EVENT_LYR_SPECIFIC + 12)
/* SOT Con status request */
#define LSO_EVENT_SOT_CNSTREQ   (LCM_EVENT_LYR_SPECIFIC + 13)
/* SOT REL request */
#define LSO_EVENT_SOT_RELREQ    (LCM_EVENT_LYR_SPECIFIC + 14)
/* SOT REL response */
#define LSO_EVENT_SOT_RELRSP    (LCM_EVENT_LYR_SPECIFIC + 15)
/* SOT MOD request */
#define LSO_EVENT_SOT_MODREQ    (LCM_EVENT_LYR_SPECIFIC + 16)
/* SOT MOD response */
#define LSO_EVENT_SOT_MODRSP    (LCM_EVENT_LYR_SPECIFIC + 17)

/* SOT ACK Req */
#define LSO_EVENT_SOT_ACKREQ    (LCM_EVENT_LYR_SPECIFIC + 18)

/* SOT CANCEL Req */
#define LSO_EVENT_SOT_CANCELREQ (LCM_EVENT_LYR_SPECIFIC + 19)

/* SOT Audit Req */
#define LSO_EVENT_SOT_AUDITREQ  (LCM_EVENT_LYR_SPECIFIC + 20)

/* CAM related primitives */
/* CAM Request */
#define LSO_EVENT_SOT_CAMREQ    (LCM_EVENT_LYR_SPECIFIC + 21)
/* CAM Response */
#define LSO_EVENT_SOT_CAMRSP    (LCM_EVENT_LYR_SPECIFIC + 22)

/* tpt server enable */
#define LSO_EVENT_TPTSRV_ENA    (LCM_EVENT_LYR_SPECIFIC + 23)
/* Entity enable */
#define LSO_EVENT_ENT_ENA       (LCM_EVENT_LYR_SPECIFIC + 24)
/* Entity disable */
#define LSO_EVENT_ENT_DIS       (LCM_EVENT_LYR_SPECIFIC + 25)
/* tpt server disable */
#define LSO_EVENT_TPTSRV_DIS    (LCM_EVENT_LYR_SPECIFIC + 26)
/* Unbind OK */
#define LSO_EVENT_UBND_OK       (LCM_EVENT_LYR_SPECIFIC + 27)

/* Resource Congestion entered */
#define LSO_EVENT_RES_CONG_STRT  (LCM_EVENT_LYR_SPECIFIC + 28)
/* Resource Congestion ended */
#define LSO_EVENT_RES_CONG_STOP  (LCM_EVENT_LYR_SPECIFIC + 29)
/* Proxy switches to stateless mode */
#define LSO_EVENT_RES_PRX_SWITCH (LCM_EVENT_LYR_SPECIFIC + 30)
/* Internal registry's usage exceeds threshUpper */
#define LSO_EVENT_REG_WARN_ON    (LCM_EVENT_LYR_SPECIFIC + 31)
/* Internal registry's usage falls below threshUpper */
#define LSO_EVENT_REG_WARN_OFF   (LCM_EVENT_LYR_SPECIFIC + 32)
/* Internal registry ahs used all available memory */
#define LSO_EVENT_REG_FULL       (LCM_EVENT_LYR_SPECIFIC + 33)



/* Type of alarm */
#define LSO_PAR_NONE               1     /* No alarm */
#define LSO_PAR_MEM                2     /* Memory alarm */
#define LSO_PAR_SAP                3     /* SAP alarm */
#define LSO_PAR_ENT                4     /* Entity alarm */
#define LSO_PAR_CONNID             5     /* Connection ID alarm */
#define LSO_PAR_TPTADDR            6     /* Transport address alarm */
#define LSO_PAR_STATUS             7     /* Status */
#define LSO_PAR_REASON             8     /* Reason */
#define LSO_PAR_CHOICE             9     /* Choice */
#define LSO_PAR_TPTSRV            10     /* Transport Server */
#define LSO_PAR_REG               11     /* Register alarm */
#define LSO_PAR_TSAP              12     /* TSAP alarm */
#define LSO_PAR_SSAP              13     /* SSAP alarm */
#define LSO_PAR_TPTPARM           14     /* Transport parameters */
#define LSO_PAR_VAL               15     /* 32-bit value */

/* Event codes used in smSoActvInit and soActvInit */
#define EVTLSOCFGREQ               0x01   /* Configuration Request */
#define EVTLSOCFGCFM               0x02   /* Configuration Confirm */
#define EVTLSOCNTRLREQ             0x03   /* Control Request */
#define EVTLSOCNTRLCFM             0x04   /* Control Confirm */
#define EVTLSOSTAREQ               0x05   /* Status Request */
#define EVTLSOSTACFM               0x06   /* Status Confirm */
#define EVTLSOSTSREQ               0x07   /* Statistics Request */
#define EVTLSOSTSCFM               0x08   /* Statistics Confirm */
#define EVTLSOSTAIND               0x09   /* Status Indication */
#define EVTLSOTRCIND               0x0A   /* Trace Indication */
#define EVTLSOACNTREQ              0x0B   /* Accounting Request */
#define EVTLSOACNTCFM              0x0C   /* Accounting Confirm */
#define EVTLSOACNTIND              0x0D   /* Accounting Indication */

#define SO_MAX_ADDRS       10              /* Max tpt servers per entity */

/* registry types */
#define LSO_LOC_USR_REG         1
#define LSO_REM_USR_REG         2

/* Cache defines for control requests */
#define LSO_DNS_A_CACHE          1
#define LSO_DNS_SRV_CACHE        2
#define LSO_MCAST_CACHE          3
#define LSO_LOCSRV_CACHE         4
#define LSO_DNS_NAPTR_CACHE      5

/* Accounting */
#ifdef LSO_ACNT

#define LSO_ACNT_EST               1
#define LSO_ACNT_REL               2
#define LSO_ACNT_MOD               3
#define LSO_ACNT_NOTAPPL           4

#define LSO_ORIGINATOR             1
#define LSO_RECEIVER               2

#define LSO_ACNT_MEDIA_NONE        0
#define LSO_ACNT_MEDIA_SDP         1
#define LSO_ACNT_MEDIA_SDP_DECODED 2
#define LSO_ACNT_MEDIA_OTHER       3

#define LSO_ACNT_NONE              0
#define LSO_ACNT_AUDIO             1
#define LSO_ACNT_VIDEO             2
#define LSO_ACNT_APPL              3
#define LSO_ACNT_DATA              4
#define LSO_ACNT_CONTROL           5

#endif /* LSO_ACNT */

#define LSO_DFLT_PRX_NONE          0
#define LSO_DFLT_PRX_TPT_ADDR      1
#define LSO_DFLT_PRX_DOMAIN_NAME   2

/* Tracing */
#define LSO_TRC_EVENT_TX         0x01
#define LSO_TRC_EVENT_RX         0x02

/* Error Codes for functions at LSB Interface */
#define   ELSOBASE     0                  /* Error base */
#define   ELSOXXX      (ELSOBASE) 
#define   ERRLSO       (ELSOBASE)         /* reserved */

#define   ELSO001      (ERRLSO +    1)    /*        lso.c:5697 */
#define   ELSO002      (ERRLSO +    2)    /*        lso.c:5743 */
#define   ELSO003      (ERRLSO +    3)    /*        lso.c:5789 */
#define   ELSO004      (ERRLSO +    4)    /*        lso.c:5835 */
#define   ELSO005      (ERRLSO +    5)    /*        lso.c:5881 */
#define   ELSO006      (ERRLSO +    6)    /*        lso.c:5930 */
#define   ELSO007      (ERRLSO +    7)    /*        lso.c:5976 */
#define   ELSO008      (ERRLSO +    8)    /*        lso.c:6016 */
#define   ELSO009      (ERRLSO +    9)    /*        lso.c:6024 */
#define   ELSO010      (ERRLSO +   10)    /*        lso.c:6070 */
#define   ELSO011      (ERRLSO +   11)    /*        lso.c:6116 */
#define   ELSO012      (ERRLSO +   12)    /*        lso.c:6169 */
#define   ELSO013      (ERRLSO +   13)    /*        lso.c:6226 */
#define   ELSO014      (ERRLSO +   14)    /*        lso.c:6284 */
#define   ELSO015      (ERRLSO +   15)    /*        lso.c:6331 */
#define   ELSO016      (ERRLSO +   16)    /*        lso.c:6342 */
#define   ELSO017      (ERRLSO +   17)    /*        lso.c:6385 */
#define   ELSO018      (ERRLSO +   18)    /*        lso.c:6396 */
#define   ELSO019      (ERRLSO +   19)    /*        lso.c:6439 */
#define   ELSO020      (ERRLSO +   20)    /*        lso.c:6450 */
#define   ELSO021      (ERRLSO +   21)    /*        lso.c:6493 */
#define   ELSO022      (ERRLSO +   22)    /*        lso.c:6504 */
#define   ELSO023      (ERRLSO +   23)    /*        lso.c:6549 */
#define   ELSO024      (ERRLSO +   24)    /*        lso.c:6561 */
#define   ELSO025      (ERRLSO +   25)    /*        lso.c:6606 */
#define   ELSO026      (ERRLSO +   26)    /*        lso.c:6618 */
#define   ELSO027      (ERRLSO +   27)    /*        lso.c:6663 */
#define   ELSO028      (ERRLSO +   28)    /*        lso.c:6675 */
#define   ELSO029      (ERRLSO +   29)    /*        lso.c:6722 */
#define   ELSO030      (ERRLSO +   30)    /*        lso.c:6734 */
#define   ELSO031      (ERRLSO +   31)    /*        lso.c:6738 */
#define   ELSO032      (ERRLSO +   32)    /*        lso.c:6780 */
#define   ELSO033      (ERRLSO +   33)    /*        lso.c:6792 */
#define   ELSO034      (ERRLSO +   34)    /*        lso.c:6839 */
#define   ELSO035      (ERRLSO +   35)    /*        lso.c:6852 */
#define   ELSO036      (ERRLSO +   36)    /*        lso.c:6897 */
#define   ELSO037      (ERRLSO +   37)    /*        lso.c:6909 */
#define   ELSO038      (ERRLSO +   38)    /*        lso.c:6954 */
#define   ELSO039      (ERRLSO +   39)    /*        lso.c:6966 */
#define   ELSO040      (ERRLSO +   40)    /*        lso.c:7011 */
#define   ELSO041      (ERRLSO +   41)    /*        lso.c:7023 */


#endif /* __LSOH__ */


/********************************************************************30**

         End of file:     lso.h@@/main/4 - Tue Apr 20 12:45:40 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---         pg    1. initial release.
/main/4      so027.201   ab    1. Changes to support SIP TLS
*********************************************************************91*/
