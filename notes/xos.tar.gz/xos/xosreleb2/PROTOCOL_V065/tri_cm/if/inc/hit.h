/********************************************************************16**

        (c) COPYRIGHT 1989-2002 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP Convergence Layer  
  
     Type:     C include file
  
     Desc:     Defines required by Upper Interface of TUCL.
  
     File:     hit.h
  
     Sid:      hit.h@@/main/10 - Mon Nov 24 15:14:36 2003
  
     Prg:      asa
  
*********************************************************************21*/
  
#ifndef __HITH__
#define __HITH__

/* defining HIT interface version */
#ifdef HITV1     /* HIT interface version 1 */
#ifdef HITIFVER
#undef HITIFVER
#endif
#define HITIFVER   0x0100
#endif /* HITV1 */

/* hash defines for "reason" field in DiscInd */
/* socket related errors */
#define   HI_SOCK_OPEN_ERR      1 /* error in socket open */
#define   HI_SOCK_SOPT_ERR      2 /* error in setting socket options */
#define   HI_SOCK_BIND_ERR      3 /* error in socket bind */
#define   HI_SOCK_LSTN_ERR      4 /* error in socket listen */
#define   HI_SOCK_CONN_ERR      5 /* error in socket connect */
#define   HI_SOCK_SEND_ERR      6 /* error in socket send */
#define   HI_SOCK_RECV_ERR      7 /* error in socket receive */
#define   HI_SOCK_NAME_ERR      8 /* error in socket getsockname call */


/* miscellaneous errors */
#define   HI_SMEM_ALLOC_ERR     9 /* error in static memory allocation */
#define   HI_INV_CON_STATE     10 /* invalid connection state */
#define   HI_INV_SAP_STATE     11 /* invalid SAP state */
#define   HI_INV_PAR_VAL       12 /* invalid input parameter value */
#define   HI_RECV_DATA_ERR     13 /* wrong data format */
#define   HI_INTERNAL_ERR      14 /* internal error */
#define   HI_OUTOF_RES         15 /* out of dynamic memory */          
#define   HI_CONID_NOT_AVAIL   16 /* reached maximum number of connections */
#define   HI_CON_CLOSED_BY_PEER 17 /* connection closed by peer */
#define   HI_DATREQ_INVALID_CONID  18 /* Invalid conId specified in DatReq
                                       * primitive */
#define   HI_UDATREQ_INVALID_CONID 19 /* Invalid conId specified in UDatReq
                                       * primitive */


/* Hashdefine for reason in DISCIND  */
#ifdef HI_REL_1_3  
#define   HI_SOCK_ICMP_RECV_ERR  20 /* Icmp Recv Error */
#endif  /* HI_REL_1_3 */ 

#define   HI_SELECT_ERR          21 /* select error */

/* hash defines for "choice" in disconnect primitives */
#define HI_USER_CON_ID          1 /* service user connection id */
#define HI_PROVIDER_CON_ID      2 /* service provider connection id */

/* defines for reason in UbndReq */
#define HI_UBNDREQ_MNGMT        1 /* stack manager directed ubind request */

/* flow control indication */
#define   HI_FLC_STRT           1 /* flow control started */
#define   HI_FLC_STOP           2 /* flow control stopped */
#define   HI_FLC_DROP           3 /* flow control - all data dropped */

/* "action" in HiUiHitDiscReq */
#define  HI_SHTDWN_RECV         1 /* shut receive half of socket */  
#define  HI_SHTDWN_SEND         2 /* shut transmit half of socket */
#define  HI_SHTDWN_BOTH         3 /* shut both halves of a socket */
#define  HI_CLOSE               4 /* close a socket */
#define  HI_LEAVE_MCAST_GROUP   5 /* leave multicast group */

/* "srvcType" values in HiUiHitServOpenReq and HiUiHitConReq */
#define HI_SRVC_UDP             0 /* UDP datagram service */
#define HI_SRVC_TCP_NO_HDR      1 /* TCP octet stream service */
#define HI_SRVC_TCP             1 /* TCP octet stream service */
#define HI_SRVC_TCP_TPKT_HDR    2 /* TCP RFC1006 TPKT service */
#define HI_SRVC_UDP_PRIOR       4 /* Priority UDP service */

#ifdef HI_REL_1_3  
#define HI_SRVC_UDP_TPKT_HDR       5 /* UDP datagram with TPKT header 
                                      * service */
#define HI_SRVC_RAW_RAW            6  
#define HI_SRVC_RAW_SCTP           7  
#define HI_SRVC_RAW_ICMP           8
#define HI_SRVC_RAW_SCTP_PRIOR     9
/* added new service type for RSVP */
#define HI_SRVC_RAW_RSVP           10

/* Note that the "srvcType" values from 0 to 16 are reserved for 
 * use with predefined TUCL service types and header types. This is in effect
 * from release 1.3 ,i.e. with flag HI_REL_1_3 defined. */
/* If the service user has to define new header profiles then the srvcType 
 * is the OR of the header profile number and the basic service type. 
 * For example, to define two header profiles for a TCP connection the service 
 * types woould be :
 * USR_SRVC_TYPE1_TCP   =  0x10 | HI_SRVC_TCP;
 * USR_SRVC_TYPE2_TCP   =  0x20 | HI_SRVC_TCP;
 * the header profile 1 can then be used for a UDP connection by specifying
 * the service to be : 
 * USER_SRVC_TYPE1_UDP = 0x10 | HI_SRVC_UDP;
 */
#endif /* HI_REL_1_3 */   

/* events for upper interface primitives */
#define  EVTHITBNDREQ           1 /* Bind  Request */
#define  EVTHITBNDCFM           2 /* Bind  Confirm */
#define  EVTHITUBNDREQ          3 /* Un - Bind  Request */
#define  EVTHITSRVOPENREQ       4 /* ServOpen Request */
#define  EVTHITCONREQ           5 /* Connect Request */
#define  EVTHITCONIND           6 /* Connect Indication */
#define  EVTHITCONRSP           7 /* Connect Response */
#define  EVTHITCONCFM           8 /* Connect Confirm*/
#define  EVTHITDATREQ           9 /* TCP Data Request */
#define  EVTHITDATIND           10/* TCP Data Indication */
#define  EVTHITUDATREQ          11/* UDP Data Request */
#define  EVTHITUDATIND          12/* UDP Data Indication */
#define  EVTHITDISCREQ          13/* Disconnect Request */
#define  EVTHITDISCIND          14/* Disconnect Indication */
#define  EVTHITDISCCFM          15/* Disconnect Confirm */
#define  EVTHITFLCIND           16/* Flow Control Indication */
#define  EVTHITPDULENRNGREQ     17/* PDU Range Request */

#ifdef HI_MULTI_THREADED
/* Internal primitives */
#define  EVTINTDISCIND          17/* Disconnect indication */
#define  EVTINTCONGOFF          18/* Congestion off */
#define  EVTINTSAPCONCBDEL      19/* All connections deleted on sap */ 
#define  EVTINTRECVTHRCLOSED    20/* Receive thread closed */
#define  EVTINTGOACTV           21/* Receive thread closed */
#define  EVTINTZEROSTS          22/* Zero the statistics */
#define  EVTINTSAPDISREQ        23/* Sap disable request */
#define  EVTINTSAPDISCFM        24/* Sap disable confirm */
#endif /* HI_MULTI_THREADED */

/* Error codes for HIT interfaces */
#define   EHITBASE     0             /* reserved */
#define   EHITXXX      (EHITBASE)    /* reserved */
#define   ERRHIT       (EHITBASE)

#define   EHIT001      (ERRHIT +    1)    /*        hit.c: 191 */
#define   EHIT002      (ERRHIT +    2)    /*        hit.c: 192 */
#define   EHIT003      (ERRHIT +    3)    /*        hit.c: 193 */
#define   EHIT004      (ERRHIT +    4)    /*        hit.c: 234 */
#define   EHIT005      (ERRHIT +    5)    /*        hit.c: 235 */
#define   EHIT006      (ERRHIT +    6)    /*        hit.c: 236 */
#define   EHIT007      (ERRHIT +    7)    /*        hit.c: 275 */
#define   EHIT008      (ERRHIT +    8)    /*        hit.c: 276 */
#define   EHIT009      (ERRHIT +    9)    /*        hit.c: 277 */
#define   EHIT010      (ERRHIT +   10)    /*        hit.c: 338 */
#define   EHIT011      (ERRHIT +   11)    /*        hit.c: 341 */
#define   EHIT012      (ERRHIT +   12)    /*        hit.c: 344 */
#define   EHIT013      (ERRHIT +   13)    /*        hit.c: 345 */
#define   EHIT014      (ERRHIT +   14)    /*        hit.c: 346 */
#define   EHIT015      (ERRHIT +   15)    /*        hit.c: 348 */
#define   EHIT016      (ERRHIT +   16)    /*        hit.c: 349 */
#define   EHIT017      (ERRHIT +   17)    /*        hit.c: 397 */
#define   EHIT018      (ERRHIT +   18)    /*        hit.c: 398 */
#define   EHIT019      (ERRHIT +   19)    /*        hit.c: 399 */
#define   EHIT020      (ERRHIT +   20)    /*        hit.c: 400 */
#define   EHIT021      (ERRHIT +   21)    /*        hit.c: 401 */
#define   EHIT022      (ERRHIT +   22)    /*        hit.c: 403 */
#define   EHIT023      (ERRHIT +   23)    /*        hit.c: 404 */
#define   EHIT024      (ERRHIT +   24)    /*        hit.c: 448 */
#define   EHIT025      (ERRHIT +   25)    /*        hit.c: 449 */
#define   EHIT026      (ERRHIT +   26)    /*        hit.c: 450 */
#define   EHIT027      (ERRHIT +   27)    /*        hit.c: 451 */
#define   EHIT028      (ERRHIT +   28)    /*        hit.c: 452 */
#define   EHIT029      (ERRHIT +   29)    /*        hit.c: 493 */
#define   EHIT030      (ERRHIT +   30)    /*        hit.c: 494 */
#define   EHIT031      (ERRHIT +   31)    /*        hit.c: 495 */
#define   EHIT032      (ERRHIT +   32)    /*        hit.c: 496 */
#define   EHIT033      (ERRHIT +   33)    /*        hit.c: 540 */
#define   EHIT034      (ERRHIT +   34)    /*        hit.c: 541 */
#define   EHIT035      (ERRHIT +   35)    /*        hit.c: 542 */
#define   EHIT036      (ERRHIT +   36)    /*        hit.c: 543 */
#define   EHIT037      (ERRHIT +   37)    /*        hit.c: 544 */
#define   EHIT038      (ERRHIT +   38)    /*        hit.c: 587 */
#define   EHIT039      (ERRHIT +   39)    /*        hit.c: 590 */
#define   EHIT040      (ERRHIT +   40)    /*        hit.c: 591 */
#define   EHIT041      (ERRHIT +   41)    /*        hit.c: 633 */
#define   EHIT042      (ERRHIT +   42)    /*        hit.c: 635 */
#define   EHIT043      (ERRHIT +   43)    /*        hit.c: 636 */
#define   EHIT044      (ERRHIT +   44)    /*        hit.c: 711 */
#define   EHIT045      (ERRHIT +   45)    /*        hit.c: 716 */
#define   EHIT046      (ERRHIT +   46)    /*        hit.c: 718 */
#define   EHIT047      (ERRHIT +   47)    /*        hit.c: 725 */
#define   EHIT048      (ERRHIT +   48)    /*        hit.c: 728 */
#define   EHIT049      (ERRHIT +   49)    /*        hit.c: 729 */
#define   EHIT050      (ERRHIT +   50)    /*        hit.c: 730 */
#define   EHIT051      (ERRHIT +   51)    /*        hit.c: 809 */
#define   EHIT052      (ERRHIT +   52)    /*        hit.c: 815 */
#define   EHIT053      (ERRHIT +   53)    /*        hit.c: 817 */
#define   EHIT054      (ERRHIT +   54)    /*        hit.c: 824 */
#define   EHIT055      (ERRHIT +   55)    /*        hit.c: 827 */
#define   EHIT056      (ERRHIT +   56)    /*        hit.c: 828 */
#define   EHIT057      (ERRHIT +   57)    /*        hit.c: 829 */
#define   EHIT058      (ERRHIT +   58)    /*        hit.c: 873 */
#define   EHIT059      (ERRHIT +   59)    /*        hit.c: 874 */
#define   EHIT060      (ERRHIT +   60)    /*        hit.c: 875 */
#define   EHIT061      (ERRHIT +   61)    /*        hit.c: 876 */
#define   EHIT062      (ERRHIT +   62)    /*        hit.c: 877 */
#define   EHIT063      (ERRHIT +   63)    /*        hit.c: 878 */
#define   EHIT064      (ERRHIT +   64)    /*        hit.c: 922 */
#define   EHIT065      (ERRHIT +   65)    /*        hit.c: 923 */
#define   EHIT066      (ERRHIT +   66)    /*        hit.c: 924 */
#define   EHIT067      (ERRHIT +   67)    /*        hit.c: 925 */
#define   EHIT068      (ERRHIT +   68)    /*        hit.c: 926 */
#define   EHIT069      (ERRHIT +   69)    /*        hit.c: 970 */
#define   EHIT070      (ERRHIT +   70)    /*        hit.c: 972 */
#define   EHIT071      (ERRHIT +   71)    /*        hit.c: 973 */
#define   EHIT072      (ERRHIT +   72)    /*        hit.c: 974 */
#define   EHIT073      (ERRHIT +   73)    /*        hit.c: 975 */
#define   EHIT074      (ERRHIT +   74)    /*        hit.c:1026 */
#define   EHIT075      (ERRHIT +   75)    /*        hit.c:1028 */
#define   EHIT076      (ERRHIT +   76)    /*        hit.c:1030 */
#define   EHIT077      (ERRHIT +   77)    /*        hit.c:1032 */
#define   EHIT078      (ERRHIT +   78)    /*        hit.c:1076 */
#define   EHIT079      (ERRHIT +   79)    /*        hit.c:1078 */
#define   EHIT080      (ERRHIT +   80)    /*        hit.c:1079 */
#define   EHIT081      (ERRHIT +   81)    /*        hit.c:1080 */
#define   EHIT082      (ERRHIT +   82)    /*        hit.c:1081 */
#define   EHIT083      (ERRHIT +   83)    /*        hit.c:1128 */
#define   EHIT084      (ERRHIT +   84)    /*        hit.c:1129 */
#define   EHIT085      (ERRHIT +   85)    /*        hit.c:1173 */
#define   EHIT086      (ERRHIT +   86)    /*        hit.c:1174 */
#define   EHIT087      (ERRHIT +   87)    /*        hit.c:1217 */
#define   EHIT088      (ERRHIT +   88)    /*        hit.c:1218 */
#define   EHIT089      (ERRHIT +   89)    /*        hit.c:1269 */
#define   EHIT090      (ERRHIT +   90)    /*        hit.c:1270 */
#define   EHIT091      (ERRHIT +   91)    /*        hit.c:1271 */
#define   EHIT092      (ERRHIT +   92)    /*        hit.c:1272 */
#define   EHIT093      (ERRHIT +   93)    /*        hit.c:1273 */
#define   EHIT094      (ERRHIT +   94)    /*        hit.c:1276 */
#define   EHIT095      (ERRHIT +   95)    /*        hit.c:1330 */
#define   EHIT096      (ERRHIT +   96)    /*        hit.c:1331 */
#define   EHIT097      (ERRHIT +   97)    /*        hit.c:1332 */
#define   EHIT098      (ERRHIT +   98)    /*        hit.c:1333 */
#define   EHIT099      (ERRHIT +   99)    /*        hit.c:1334 */
#define   EHIT100      (ERRHIT +  100)    /*        hit.c:1335 */
#define   EHIT101      (ERRHIT +  101)    /*        hit.c:1382 */
#define   EHIT102      (ERRHIT +  102)    /*        hit.c:1383 */
#define   EHIT103      (ERRHIT +  103)    /*        hit.c:1384 */
#define   EHIT104      (ERRHIT +  104)    /*        hit.c:1385 */
#define   EHIT105      (ERRHIT +  105)    /*        hit.c:1430 */
#define   EHIT106      (ERRHIT +  106)    /*        hit.c:1431 */
#define   EHIT107      (ERRHIT +  107)    /*        hit.c:1432 */
#define   EHIT108      (ERRHIT +  108)    /*        hit.c:1479 */
#define   EHIT109      (ERRHIT +  109)    /*        hit.c:1480 */
#define   EHIT110      (ERRHIT +  110)    /*        hit.c:1481 */
#define   EHIT111      (ERRHIT +  111)    /*        hit.c:1482 */
#define   EHIT112      (ERRHIT +  112)    /*        hit.c:1527 */
#define   EHIT113      (ERRHIT +  113)    /*        hit.c:1528 */
#define   EHIT114      (ERRHIT +  114)    /*        hit.c:1570 */
#define   EHIT115      (ERRHIT +  115)    /*        hit.c:1571 */
#define   EHIT116      (ERRHIT +  116)    /*        hit.c:1650 */
#define   EHIT117      (ERRHIT +  117)    /*        hit.c:1651 */
#define   EHIT118      (ERRHIT +  118)    /*        hit.c:1652 */
#define   EHIT119      (ERRHIT +  119)    /*        hit.c:1655 */
#define   EHIT120      (ERRHIT +  120)    /*        hit.c:1663 */
#define   EHIT121      (ERRHIT +  121)    /*        hit.c:1668 */
#define   EHIT122      (ERRHIT +  122)    /*        hit.c:1672 */
#define   EHIT123      (ERRHIT +  123)    /*        hit.c:1760 */
#define   EHIT124      (ERRHIT +  124)    /*        hit.c:1761 */
#define   EHIT125      (ERRHIT +  125)    /*        hit.c:1762 */
#define   EHIT126      (ERRHIT +  126)    /*        hit.c:1765 */
#define   EHIT127      (ERRHIT +  127)    /*        hit.c:1777 */
#define   EHIT128      (ERRHIT +  128)    /*        hit.c:1782 */
#define   EHIT129      (ERRHIT +  129)    /*        hit.c:1789 */
#define   EHIT130      (ERRHIT +  130)    /*        hit.c:1845 */
#define   EHIT131      (ERRHIT +  131)    /*        hit.c:1846 */
#define   EHIT132      (ERRHIT +  132)    /*        hit.c:1847 */
#define   EHIT133      (ERRHIT +  133)    /*        hit.c:1848 */
#define   EHIT134      (ERRHIT +  134)    /*        hit.c:1849 */
#define   EHIT135      (ERRHIT +  135)    /*        hit.c:1896 */
#define   EHIT136      (ERRHIT +  136)    /*        hit.c:1897 */
#define   EHIT137      (ERRHIT +  137)    /*        hit.c:1898 */
#define   EHIT138      (ERRHIT +  138)    /*        hit.c:1899 */
#define   EHIT139      (ERRHIT +  139)    /*        hit.c:1947 */
#define   EHIT140      (ERRHIT +  140)    /*        hit.c:1948 */
#define   EHIT141      (ERRHIT +  141)    /*        hit.c:1949 */
#define   EHIT142      (ERRHIT +  142)    /*        hit.c:1950 */
#define   EHIT143      (ERRHIT +  143)    /*        hit.c:1998 */
#define   EHIT144      (ERRHIT +  144)    /*        hit.c:2000 */
#define   EHIT145      (ERRHIT +  145)    /*        hit.c:2002 */
#define   EHIT146      (ERRHIT +  146)    /*        hit.c:2053 */
#define   EHIT147      (ERRHIT +  147)    /*        hit.c:2054 */
#define   EHIT148      (ERRHIT +  148)    /*        hit.c:2055 */
#define   EHIT149      (ERRHIT +  149)    /*        hit.c:2056 */

#endif /* __HITH__ */
 

/********************************************************************30**
 
         End of file:     hit.h@@/main/10 - Mon Nov 24 15:14:36 2003
 
*********************************************************************31*/
 

/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. changed the value of HI_SRVC_UDP.
/main/3                cvp   1. changed copyright header.
/main/5      ---      sb    1. updated error codes.
                           2. added support for Raw sockets.
                     cvp   1. added UDP TPKT service type.
/main/5      ---     cvp  1. added two new service types
                              HI_SRVC_UDP_PRIOR and 
                              HI_SRVC_RAW_SCTP_PRIOR.
/main/6      ---      dvs  1. ClearCase release
/main/7      ---     cvp  1. changed the copyright header.
                          2. updated error codes
                          3. multi-threaded TUCL related changes.
/main/8      ---     mmm  1. added new service type HI_SRVC_RAW_RSVP
                          2. added defines for Rolling Upgrade
/main/9      ---    cv309 1. Added MPLS 1.2 changes
/main/9              zmc  1. added a new error code for select error
/main/10     ---     zmc  1. New file release due to tucl patch
*********************************************************************91*/
