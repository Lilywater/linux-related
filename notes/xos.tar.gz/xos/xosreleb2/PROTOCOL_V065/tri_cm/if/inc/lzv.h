/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
     Name:     M3UA PSF interface file with layer manager

     Type:     C include file

     Desc:     Defines required by the Stack Manager System Manager for
               the distributed and/or fault tolerant M3UA.

     File:     lzv.h
  
     Sid:      lzv.h@@/main/2 - Mon Apr  5 09:48:47 2004
 
     Prg:      vt 

*********************************************************************21*/

#ifndef __LZVH__
#define __LZVH__

#ifdef LZVV1
#ifdef LZVIFVER
#undef LZVIFVER
#endif
#define LZVIFVER 0x0100         /* LZV interface version 1 */
#endif /* LZVV1 */

#define MAXZVMI  0x2
/***********************************************************************
 * Elmnt types (to be used by both SH and SM).                         *
 ***********************************************************************/

#define STZVGEN    0x41       /* General */
#define STZVRSET   0x22       /* Resource Set Specific */
#define STZVSID    0x43       /* System Id */
#define STZVGENCFG 0x44       /* General Config*/

/***********************************************************************
 * Action types to be used by SM.                                      *
 ***********************************************************************/
#define LZV_ASHUTDOWN  0x01      /* Shutdown PSF */
#define LZV_AENA       0x02      /* Enable */
#define LZV_ADISIMM    0x03      /* Disable - immediately */
#define LZV_ADEL       0x04      /* Delete */

/***********************************************************************
 * Sub Action types to be used by SM.                                  *
 ***********************************************************************/
#define LZV_SAUSTA   0x01          /* Enable unsolicited status ind */
#define LZV_SADBG    0x02          /* Debug prints */
#define LZV_SATRC    0x03          /* Message trace */
#define LZV_SAELMNT  0x04 


/***********************************************************************
 * Action types to be used by SH.                                      *
 ***********************************************************************/
#define LZV_INVALID_ACTION 0x00  /* Invalid Action */
#define LZV_AGO_ACT        0x04  /* Make resource set active */
#define LZV_AGO_SBY        0x05  /* Make resource set standby */
#define LZV_ADIS_PEER_SAP  0x06  /* Disable peer interface */
#define LZV_AWARMSTART     0x07  /* Start warmstart */
#define LZV_ASYNCHRONIZE   0x08  /* Start peersync */
#define LZV_ASHUTDOWN_RSET 0x09  /* Shutdown resource set */
#define LZV_AABORT         0x0a  /* Abort ongoing operation */
#define LZV_ASTAT          0x0b  /* Status request */

/***********************************************************************
 * Delete Element Indicators For Cntrl Request                         *
 ***********************************************************************/

#ifdef ZV_DFTHA
#define LZV_ELMNT_NWK   1  /* Element is Network */
#define LZV_ELMNT_SSF   2  /* Element is SSF */
#define LZV_ELMNT_SI    3  /* Element is SI  */
#define LZV_ELMNT_DPC   4  /* Element is DPC */
#define LZV_ELMNT_OPC   5  /* Element is OPC */
#endif

/***********************************************************************
 * Reasons for failure. LZV specifici reasons start after Common (LCM)
 * reasons and CM_ZVDV (library for LDF and PSF). General ranges as of now:
 * LCM -      0 to 255  (common to all products - found in gen.h)
 * CMZVDV - 256 to 511  (common to PSF-LDF - found in cmZVDVlb.h)
 * LZV    - 512 to 767  (PSF specific reasons - found below)
 ***********************************************************************/
#ifdef ZV_DFTHA
#define LZV_SPECIFIC_REASON (LCM_REASON_LYR_SPECIFIC + CMZVDV_MAX_REASON)
#else
#define LZV_SPECIFIC_REASON LCM_REASON_LYR_SPECIFIC 
#endif

#define LZV_REASON_INVALID_KEY   LZV_SPECIFIC_REASON+1   /* Invalid Key */
#define LZV_REASON_INVALID_RSET  LZV_SPECIFIC_REASON+2   /* Invalid rset */
#define LZV_REASON_INV_INTERFACE LZV_SPECIFIC_REASON+3  /* Invalid interface */ 
#define LZV_REASON_INT_FAILURE   LZV_SPECIFIC_REASON+4  /* Internal Failure */ 
#define LZV_REASON_RSET_PREV_CFG LZV_SPECIFIC_REASON+5  /* Already configured*/ 
#define LZV_REASON_DEL_HASH_FAILED LZV_SPECIFIC_REASON+6 /* Hash deletion fail*/ 
#define LZV_REASON_INV_DIST_ATTR LZV_SPECIFIC_REASON+7   /* Invalid Distribution */ 



/***********************************************************************
 * ZV Management interface events.                                     *
 ***********************************************************************/
#define EVTZVMILZVCFGREQ   0x80   /* configuration request */
#define EVTZVMILZVCFGCFM   0x81   /* configuration confirm */
#define EVTZVMILZVSTAREQ   0x82   /* status request */
#define EVTZVMILZVSTACFM   0x83   /* status confirm */
#define EVTZVMILZVCNTRLREQ 0x84   /* control request */
#define EVTZVMILZVCNTRLCFM 0x85   /* control confirm */
#define EVTZVMILZVSTSREQ   0x86   /* statistics request */
#define EVTZVMILZVSTSCFM   0x87   /* statistics confirm */
#define EVTZVMILZVSTAIND   0x89   /* status indication */
#define EVTZVMILZVTRCIND   0x8a   /* trace indication */



/***********************************************************************
 * Defines for error handling.                                         *
 ***********************************************************************/
#define   ELZVBASE     0
#define   ELZVXXX      (ELZVBASE)

#define   ERRLZV       (ELZVBASE)
#define   ELZV001      (ERRLZV +    1)    /*        lzv.c:1257 */
#define   ELZV002      (ERRLZV +    2)    /*        lzv.c:2469 */
#define   ELZV003      (ERRLZV +    3)    /*     zv_cfn.c: 290 */
 
#if (ERRCLASS & ERRCLS_DEBUG)
#define LZVLOGERROR_DEBUG(errCode, errVal, errDesc) \
        SLogError(0, 0, 0, \
                   __FILE__, __LINE__, ERRCLS_DEBUG, errCode, errVal, errDesc)
#else
#define LZVLOGERROR_DEBUG(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
 
#if (ERRCLASS & ERRCLS_INT_PAR)
#define LZVLOGERROR_INT_PAR(errCode, errVal, errDesc) \
        SLogError(0, 0, 0, \
                 __FILE__, __LINE__, ERRCLS_INT_PAR, errCode, errVal, errDesc)
#else
#define LZVLOGERROR_INT_PAR(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
 
#if (ERRCLASS & ERRCLS_ADD_RES)
#define LZVLOGERROR_ADD_RES(errCode, errVal, errDesc) \
        SLogError(0, 0, 0, \
                 __FILE__, __LINE__, ERRCLS_ADD_RES, errCode, errVal, errDesc)
#else
#define LZVLOGERROR_ADD_RES(errCode, errVal, errDesc)
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */


/***********************************************************************
 * Other misc. hash defines.                                           *
 ***********************************************************************/

/* Debug mask hash defines. */
#define LZV_DBGMASK_INTERNAL  (DBGMASK_LYR << 0)           /* layer specific */
#define LZV_DBGMASK_PACK      (LZV_DBGMASK_INTERNAL << 0)  /* Message Pack */
#define LZV_DBGMASK_UNPACK    (LZV_DBGMASK_INTERNAL << 1)  /* Message Unpack */

/* Trace Message direction (for SM, part of TrcInd) */
#define LZV_BUF_TX  0x01      /* update message being tx by PSF */
#define LZV_BUF_RX  0x02      /* update message being rx by PSF */

#define LZV_MIN_UPD_MSG_SZ    300 

#define LZV_GENCFG_DONE       1
#define LZV_GENCFG_NDONE      0

#endif /* __LZVH__ */


/********************************************************************30**
  
         End of file:     lzv.h@@/main/2 - Mon Apr  5 09:48:47 2004
   
*********************************************************************31*/


/********************************************************************40**

   Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

   Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      vt   1. Initial release.
/main/2      ---      vt   2. General Public Release
*********************************************************************91*/

