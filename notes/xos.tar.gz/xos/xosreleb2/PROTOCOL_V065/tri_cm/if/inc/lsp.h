/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     layer management interface - sccp
  
     Type:     C include file
  
     Desc:     Defines required by the layer management service user.
 
     File:     lsp.h

     Sid:      lsp.h@@/main/12_1 - Tue Jan 22 15:14:35 2002
  
     Prg:      fmg
  
*********************************************************************21*/

#ifndef __LSPH__
#define __LSPH__


/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000030     SS7 - SCCP
*
*/
 
/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      
*     --------    ----------------------------------------------
*     1000030     SS7 - SCCP
*
*/

/* conditionally defining interface version number for LSP interface */
#ifdef LSPV1       /* LSP interface version 1 */

#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0100

#endif /* LSPV1 */

#ifdef LSPV2       /* LSP interface version 2 */

#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0200

#endif /* LSPV2 */

/* sp020.302 - addition - LSPV2_1 interface version created */
#ifdef LSPV2_1       /* LSP interface version 3 */

#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0201

#endif /* LSPV2_1 */

/* sp028.302 - addition - LSPV2_2 interface version created */
#ifdef LSPV2_2       /* LSP interface version 2_2 */

/* In this interface version, define flag LSPV2_1 also to include all
 * features of 2_1. But LSPIFVER will be defined as of LSPV2_2 only.
 */
#ifdef LSPV2_1
#undef LSPV2_1
#endif
#define LSPV2_1

/* now define LSPIFVER */
#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0202

#endif /* LSPV2_2 */

/* sp032.302 - addition - LSPV2_3 interface version created */
#ifdef LSPV2_3       /* LSP interface version 2_3 */

/* In this interface version, define flag LSPV2_2 also to include all
 * features of 2_2. But LSPIFVER will be defined as of LSPV2_3 only.
 */
#ifdef LSPV2_2
#undef LSPV2_2
#endif
#define LSPV2_2

#ifdef LSPV2_1
#undef LSPV2_1
#endif
#define LSPV2_1


/* now define LSPIFVER */
#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0203

#endif /* LSPV2_3 */

/* lsp_h_001.main_12_1 - addition - LSPV2_4 interface version created */
#ifdef LSPV2_4       /* LSP interface version 2_4 */

/* In this interface version, define flag LSPV2_3 also to include all
 * features of 2_3. all previous versions are enabled if LSPV2_4 is enabled.
 */
#ifdef LSPV2_3
#undef LSPV2_3
#endif
#define LSPV2_3

#ifdef LSPV2_2
#undef LSPV2_2
#endif
#define LSPV2_2

#ifdef LSPV2_1
#undef LSPV2_1
#endif
#define LSPV2_1


/* now define LSPIFVER */
#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0204

#endif /* LSPV2_4 */

/* lsp_h_002.main_12_1 - addition - LSPV2_5 interface version created */
#ifdef LSPV2_5       /* LSP interface version 2_5 */

/* In this interface version, define flag LSPV2_4 also to include all
 * features of 2_4 and all previous versions are enabled if LSPV2_4 is enabled.
 */
#ifdef LSPV2_4
#undef LSPV2_4
#endif
#define LSPV2_4

#ifdef LSPV2_3
#undef LSPV2_3
#endif
#define LSPV2_3

#ifdef LSPV2_2
#undef LSPV2_2
#endif
#define LSPV2_2

#ifdef LSPV2_1
#undef LSPV2_1
#endif
#define LSPV2_1


/* now define LSPIFVER */
#ifdef LSPIFVER
#undef LSPIFVER
#endif
#define LSPIFVER   0x0205

#endif /* LSPV2_5 */

/* sp001.302 - modification - if none of LSPV1 or LSPV2 is enabled,
 * define LSPIFVER as latest version i.e. 0x0200
 */
/* sp020.302 - modification - define LSPIFVER as latest version 0x0201 */
/* sp028.302 - modification - define LSPIFVER as latest version 0x0202 */
/* sp032.302 - modification - define LSPIFVER as latest version 0x0203 */
/* lsp_h_002.main_12_1 - modification - define LSPIFVER as latest version 0x0205 */
#ifndef LSPIFVER
#define LSPIFVER   0x0205
#endif /* LSPIFVER */

/* defines */

#define ELSPBASE   0
#define ELSPXXX    (ELSPBASE)
#define ERRLSP     (ELSPBASE + 0)

/* sp027.302 - modification - defines for SAP status moved from sp.h file.
 * SAP status values will be reported to LM in LspStaCfm in bitMask format.
 */
/****************************************************
 * Status of SAP and NSAP                           *
 ****************************************************/
#define SP_BND       0x01      /* bind - SAP and NSAP*/
#define SP_SNRST     0x02      /* MTP3 is perf the restart procedure - NSAP */
#define SP_BRT       0x08      /* Backup Routed - SAP */
#define SP_GRNT      0x10      /* waiting for grant - SAP */
#define SP_IGNR      0x20      /* ignore - SAP */
#define SP_PROH      0x40      /* prohibited - SAP */
#define SP_WAIT_BNDCFM  0x80   /* wait for bind confirmation (SNT2) - NSAP */

/* USTA Mask */
#define LSP_USTAALARM   0x00000001  /* mask for alarm indication */
#define LSP_USTAREPORT  0x00000002  /* mask for SCCP error performance and
                                       subsystem availability report - Q.752 */

#define SP_ONLINE    0x01       /* Signalling point is online */
#define SP_OFFLINE  ~0x01       /* Signalling point is offline */
/* #define SP_CONG   0x02          Signalling point is congested is defined
                                   in gen.h as it is used by upper interface
                                   and layer manager
*/
#define SP_UNCONG   ~0x02       /* Signalling point is uncongested */
#define SP_TRANS     0x04       /* Signalling point is a translator node */
#define SP_ADJACENT  0x08       /* Signalling point is adjacent */
#define SP_INSCAPABLE 0x10      /* signalling point is INS capable */

/* subsystem point status */

#define SS_ACC       0x01       /* subsystem status - accessible */ 
#define SS_INACC    ~0x01       /* subsystem status - inaccessible */ 

#define SS_SNR       0x10       /* subsystem normal routed */
#define SS_SBR      ~0x10       /* subsystem backup routed */

/* Route flag values */
#define LSP_NW_BROADBAND   0x01 /* route supports broadband data */
#define LSP_NW_NARROWBAND ~0x01 /* route does not support broadband data */

/* protocol specific reasons */
#define LSP_REASON_NO_ROUTES        (LCM_REASON_LYR_SPECIFIC + 0)
                                     /* no routes configures; nmbRtes is 0 */

#define LSP_REASON_MAXSAP_CFG       (LCM_REASON_LYR_SPECIFIC + 2) 
                                     /* max sap already configured  */
#define LSP_REASON_INVALID_SWTCH    (LCM_REASON_LYR_SPECIFIC + 3) 
                                     /* invalid swtch parameter  */
#define LSP_REASON_MFINIT_FAIL      (LCM_REASON_LYR_SPECIFIC + 4)  
                                     /* MF initialization failed  */
#define LSP_REASON_NSAPBND_FAIL     (LCM_REASON_LYR_SPECIFIC + 5) 
                                     /* network sap bind failure  */
#define LSP_REASON_GTT_NOTPRSNT     (LCM_REASON_LYR_SPECIFIC + 6)  
                                     /* global title not present  */
#define LSP_REASON_CONV_FAIL        (LCM_REASON_LYR_SPECIFIC + 7) 
                                     /* conversion hex to bcd etc failed  */
#define LSP_REASON_ALREADY_CFG      (LCM_REASON_LYR_SPECIFIC + 8) 
                                     /* alredy configured */
#define LSP_REASON_NSAP_NOTCFG      (LCM_REASON_LYR_SPECIFIC + 9) 
                                     /* network sap not configured */
/* Rule already exists */
#define LSP_REASON_RULE_NOTPRSNT    (LCM_REASON_LYR_SPECIFIC + 10) 
/* GTT addition failed */
#define LSP_REASON_ADD_FAIL         (LCM_REASON_LYR_SPECIFIC + 11) 
/* GTT deletion failed */
#define LSP_REASON_DEL_FAIL         (LCM_REASON_LYR_SPECIFIC + 12) 
/* GTT Initialization failed. */
#define LSP_REASON_INIT_FAIL        (LCM_REASON_LYR_SPECIFIC + 13) 
/* Association Configuration exceeds limits*/
#define LSP_REASON_MAXASSO_CFG       (LCM_REASON_LYR_SPECIFIC + 14) 
/* Address Configuration exceeds limits*/
#define LSP_REASON_MAXADDR_CFG       (LCM_REASON_LYR_SPECIFIC + 15) 
/* Address Configuration exceeds limits*/
#define LSP_REASON_MAXACTNS_CFG       (LCM_REASON_LYR_SPECIFIC + 16) 
/* Association Not Configured */
#define LSP_REASON_ASSO_NOT_CFG      (LCM_REASON_LYR_SPECIFIC + 17) 

/* Maximum Networks already configured */
#define LSP_REASON_MAXNW_CFG         (LCM_REASON_LYR_SPECIFIC + 18)

/* The associated network as indicated by nwId is not configured */
#define LSP_REASON_NW_NOTCFG         (LCM_REASON_LYR_SPECIFIC + 19)

/* The maximum subsystems already configured */
#define LSP_REASON_MAXSSN_CFG        (LCM_REASON_LYR_SPECIFIC + 20)

/* Invalid value of switch */
#define LSP_REASON_INV_SWITCH        (LCM_REASON_LYR_SPECIFIC + 21)

/* Invalid mode of opearation for replicated nodes/subsystems */
#define LSP_REASON_INV_REPL_MODE     (LCM_REASON_LYR_SPECIFIC + 22)

/* Invalid SIO priority to Importance of message configuration */
#define LSP_REASON_INV_SIOPRIO_IMP   (LCM_REASON_LYR_SPECIFIC + 23)

/* Invalid SCCP congestion level in control request */
#define LSP_REASON_INVALID_CONGLVL   (LCM_REASON_LYR_SPECIFIC + 24)

/* Invalid sscThreshold in control request */
#define LSP_REASON_INVALID_SSCTHRESH  (LCM_REASON_LYR_SPECIFIC + 25)

/* Traffic limitation data not configured */
#define LSP_REASON_TRFLIM_NOT_CFG    (LCM_REASON_LYR_SPECIFIC + 26)

/* Maximum SCCP entities in GTT database already configured */
#define LSP_REASON_MAX_SCCP_ENT_CFG  (LCM_REASON_LYR_SPECIFIC + 27)

/* Invalid route in route statistics request */
#define LSP_REASON_INVALID_ROUTE     (LCM_REASON_LYR_SPECIFIC + 28)

/* Invalid number of sccp entities */
#define LSP_REASON_INVALID_NUMENTITIES  (LCM_REASON_LYR_SPECIFIC + 29)

/* Invalid number of Nids */
#define LSP_REASON_INVALID_NUMNIDS  (LCM_REASON_LYR_SPECIFIC + 30)

/* sp001.302 - addition - failure reasons */
/* Overlapping rule */
#define LSP_REASON_OVERLAPPING_RULE  (LCM_REASON_LYR_SPECIFIC + 31)

/* maximum routes already configured */
#define LSP_REASON_MAXROUTE_CFG  (LCM_REASON_LYR_SPECIFIC + 32)

/* maximum routes ssn already configured */
#define LSP_REASON_MAXRTESSN_CFG  (LCM_REASON_LYR_SPECIFIC + 33)


/* protocol specific events */
#define LSP_EVENT_USER_INS          (LCM_EVENT_LYR_SPECIFIC + 0)   
                                     /* SCCP user going inservice */
#define LSP_EVENT_USER_OOS          (LCM_EVENT_LYR_SPECIFIC + 1) 
                                     /* user going out of service */
#define LSP_EVENT_ROUTING_ERR       (LCM_EVENT_LYR_SPECIFIC + 2) 
                                     /* routing error  */
#define LSP_EVENT_BND_ON_BND        (LCM_EVENT_LYR_SPECIFIC + 3)  
                                     /* bind on bind  */
#define LSP_EVENT_SYN_ERROR         (LCM_EVENT_LYR_SPECIFIC + 4)  
                                     /* syntax error  */
#define LSP_EVENT_HOP_VIOLATION     (LCM_EVENT_LYR_SPECIFIC + 5)  
                                     /* hop counter violation  */
#define LSP_EVENT_ERROR_PERFORMANCE  (LCM_EVENT_LYR_SPECIFIC + 6)
                                     /* SCCP Error Performance as per Q.752 */
#define LSP_EVENT_SUBSYS_AVAILABILITY   (LCM_EVENT_LYR_SPECIFIC + 7)
                                  /* SCCP subsystem availability as per Q.752 */
#define LSP_EVENT_RMT_SCCP_UNEQUIP   (LCM_EVENT_LYR_SPECIFIC + 8)
                                  /* Remote sccp unequipped */

/* sp028.302 - addition- event to generate alarm when LclRef cannot be added
 * due to exceeding the limits of SCCP connections
 */
#define LSP_EVENT_ADD_LCLREF_ERR   (LCM_EVENT_LYR_SPECIFIC + 9)
                                  /* Error in adding LclRef */

/* sp028.302 - addition - event to generate alarm when conThresh reached */
#define LSP_EVENT_CONREQ_FAILURE   (LCM_EVENT_LYR_SPECIFIC + 10)
                                  /* Failure in establishing connection */

/* sp028.302 - addition - event to generate alarm when queThresh reached */
#define LSP_EVENT_DT2_QUE_FAILURE   (LCM_EVENT_LYR_SPECIFIC + 11)
                                  /* Failure in queing DT2 msg */


/* protocol specific causes */
#define LSP_CAUSE_INV_ROUTE         (LCM_CAUSE_LYR_SPECIFIC + 5) 
                                     /* route not exist */
/* routing failure - no translation for address of such nature */
#define LSP_CAUSE_RTF_NTBADADDR     (LCM_CAUSE_LYR_SPECIFIC + 6)

/* routing failure - no translation for this specific address */
#define LSP_CAUSE_RTF_NTSPECADDR     (LCM_CAUSE_LYR_SPECIFIC + 7)

/* routing failure - network failure, point code not available */
#define LSP_CAUSE_RTF_NETFAIL     (LCM_CAUSE_LYR_SPECIFIC + 8)

/* routing failure - network congestion */
#define LSP_CAUSE_RTF_NETCONG     (LCM_CAUSE_LYR_SPECIFIC + 9)

/* routing failure - subsystem failure */
#define LSP_CAUSE_RTF_SSFAIL     (LCM_CAUSE_LYR_SPECIFIC + 10)

/* routing failure - subsystem congestion */
#define LSP_CAUSE_RTF_SSCONG     (LCM_CAUSE_LYR_SPECIFIC + 11)

/* routing failure - unequipped user (subsystem) */
#define LSP_CAUSE_RTF_UNEQUIP     (LCM_CAUSE_LYR_SPECIFIC + 12)

/* Syntax error detected */
#define LSP_CAUSE_SYNTAX_ERROR     (LCM_CAUSE_LYR_SPECIFIC + 13)

/* routing failure - unqualified */
#define LSP_CAUSE_RTF_UNQUAL     (LCM_CAUSE_LYR_SPECIFIC + 14)

/* reassembly error - Timer T(reas) expiry */
#define LSP_CAUSE_REASM_TIMEREXP     (LCM_CAUSE_LYR_SPECIFIC + 15)

/* reassembly error - out of sequence segment, duplicate segment,
 * non-first segment for which no reassembly process existing
 */
#define LSP_CAUSE_REASM_OUTSEQ     (LCM_CAUSE_LYR_SPECIFIC + 16)

/* reassembly error - no reassembly space */
#define LSP_CAUSE_REASM_NOSPACE    (LCM_CAUSE_LYR_SPECIFIC + 17)

/* Hop Counter violation ( XUDT(S)/LUDT(S)/CR ) */
#define LSP_CAUSE_HOP_VIOLATE    (LCM_CAUSE_LYR_SPECIFIC + 18)

/* message too large for segmentation */
#define LSP_CAUSE_SEGFAIL_LARGE     (LCM_CAUSE_LYR_SPECIFIC + 19)

/* Failure of release complete supervision */
#define LSP_CAUSE_RLSCOMP_FAIL     (LCM_CAUSE_LYR_SPECIFIC + 20)

/* inactivity receive timer expiry */
#define LSP_CAUSE_ITRECV_EXP       (LCM_CAUSE_LYR_SPECIFIC + 21)

/* Provider initiated reset of connection */
#define LSP_CAUSE_NSP_RESET    (LCM_CAUSE_LYR_SPECIFIC + 22)

/* Provider initiated release of connection */
#define LSP_CAUSE_NSP_RELEASE    (LCM_CAUSE_LYR_SPECIFIC + 23)

/* Segmentation error - segmentation not supported */
#define LSP_CAUSE_SEG_NOSUPPORT  (LCM_CAUSE_LYR_SPECIFIC + 24)

/* Segmentation error - segmentation failed */
#define LSP_CAUSE_SEG_FAILED  (LCM_CAUSE_LYR_SPECIFIC + 25)

/* SCCP/Subsystem congested message received */
#define LSP_CAUSE_SSC_RECVD    (LCM_CAUSE_LYR_SPECIFIC + 26)

/* Subsystem prohibited message received */
#define LSP_CAUSE_SSP_RECVD    (LCM_CAUSE_LYR_SPECIFIC + 27)

/* Status indication from MTP3 for remote sccp unequipped */
#define LSP_CAUSE_RMT_SCCP_UNEQUIP  (LCM_CAUSE_LYR_SPECIFIC + 28)

/* sp028.302 - addition- cause to generate alarm when LclRef cannot be added
 * due to exceeding the limits of SCCP connections
 */
#define LSP_CAUSE_MAXCON_EXCEEDED  (LCM_CAUSE_LYR_SPECIFIC + 29)
#define LSP_CAUSE_MAXCON_PER_RSET_EXCEEDED  (LCM_CAUSE_LYR_SPECIFIC + 30)

/* sp028.302 - addition - cause for exceeding conthresh and queThresh */
#define LSP_CAUSE_CONN_THRESH_EXCEEDED  (LCM_CAUSE_LYR_SPECIFIC + 31)
#define LSP_CAUSE_QUE_THRESH_EXCEEDED  (LCM_CAUSE_LYR_SPECIFIC + 32)

/* sp032.302 - addition - generate alarm when number of connection reaches nmbConThresh */
#define LSP_CAUSE_MAXCON_THRESH_REACHED  (LCM_CAUSE_LYR_SPECIFIC + 33)

/* sp035.302 - addition - generate SCCP report for SSA received and SP
 * inaccessible and accessible. 
 */

/* Subsystem allowed message received */
#define LSP_CAUSE_SSA_RECVD    (LCM_CAUSE_LYR_SPECIFIC + 34)
/* Status indication from MTP3 for remote sp inaccesible and sp accessible*/
#define LSP_CAUSE_RMT_SP_INACC  (LCM_CAUSE_LYR_SPECIFIC + 35)
#define LSP_CAUSE_RMT_SP_ACC (LCM_CAUSE_LYR_SPECIFIC + 36)

#define SPSTA_RE              LSP_EVENT_ROUTING_ERR   /* Routing Error */
#define SPSTA_UOS             LSP_EVENT_USER_OOS      /* User out of service */
#define SPSTA_UIS             LSP_EVENT_USER_INS      /* User in service */
#define LSP_USTA_CFG_OK       0x03      /* configuration request ok*/ 
#define LSP_USTA_CFG_NOK      0x04      /* configuration request not ok*/ 
#define LSP_USTA_CNTRL_OK     0x05      /* control request ok*/ 
#define LSP_USTA_CNTRL_NOK    0x06      /* control request not ok*/ 
#define LSP_USTA_STA_OK       0x07      /* status request ok*/ 
#define LSP_USTA_STA_NOK      0x08      /* status request not ok*/ 
#define LSP_USTA_STS_OK       0x09      /* statistics request ok*/ 
#define LSP_USTA_STS_NOK      0x0A      /* statistics request not ok*/ 
#define LSP_USTA_SPT_INV      LCM_EVENT_UI_INV_EVT /* invalid event at SPT interface */ 
#define LSP_USTA_SNT_INV      LCM_EVENT_LI_INV_EVT /* invalid event at SNT interface */ 

#define LSP_USTA_INV_EVNT     LCM_EVENT_INV_EVT      /* invalid event */ 

#define LSP_USTA_BND_ON_BND   LSP_EVENT_BND_ON_BND   /* bind on bound sap */ 
#define LSP_USTA_SYN_ERROR    LSP_EVENT_SYN_ERROR    /* syntax error */

/* Unsolicited Status Event Parameter size */
#define LSP_USTA_EP_MAX  0x08     /* size of evntParm in usta */

/* The following flags are dependent on the specific 
 * environment of a given port. They should be adjusted to
 * reasonable values for the destination environment.
 */
#define MAXNUMSSN         5        /* Max Subsystems allowed per Dpc */
#define MAXCONPC          2        /* Max Concerned Point Code per Dpc */

#if (SS7_ANS96 || SS7_BELL05)
#define MAXNUMBPC         5        /* Maximum number of backip point codes */
#else                              /* only one backup pc is allowed in ITU */
#define MAXNUMBPC         1        /* Maximum number of backip point codes */
#endif /* (SS7_ANS96 || SS7_BELL05) */

#if (SS7_ANS96 || SS7_BELL05)
#define MAXNUMNID         10       /* maximum number of NIDs for which NID to 
                                      PC as well as NW Specific NID to SS7-NID 
                                      mappings can be configured */
#endif /* (SS7_ANS96 || SS7_BELL05) */

#define MAXRL    8   /* Maximum Restriction level : RL(M) */
#define MAXRSL   4   /* Maximum Restriction Sub-level : RSL(M) */
#define MAXCL    8   /* Maximum SCCP Congestion level : CL(S) */

#define MAXENTITIES   2    /* Maximum number of SCCP entities in a entity set */

#define MAXSIOPRIO        4        /* maximum SIO priority */

/* modes of opeartion of Replicated nodes/subsystems */
#define DOMINANT             1  /* Dominant mode */
#define LOADSHARE            2  /* Loadshare mode */
#define DOMINANT_ALTERNATE   3  /* Dominant mode with option of alternate
                                   routing of class 0 traffic in case of 
                                   congestion */
#define LOADSHARE_ALTERNATE  4  /* Loadshare mode with option of alternate
                                   routing of class 0 traffic in case of 
                                   congestion */

/* Sp Management Events */
/* Note that events 0xf0 to 0xff are kept reserved for SCCP Update module */

#define EVTLSPCFGREQ     0x3c             /* Configuration request */
#define EVTLSPSTAREQ     0x40             /* Status request */
#define EVTLSPSTACFM     0x41             /* Status confirm */
#define EVTLSPSTAIND     0x42             /* Status indication */
#define EVTLSPSTSREQ     0x44             /* Statistics request */
#define EVTLSPSTSCFM     0x45             /* Statistics confirm */
#define EVTLSPTRCIND     0x48             /* Trace indication */
#define EVTLSPCNTRLREQ   0x4c             /* Control request */
#define EVTLSPCNTRLCFM   0x4d             /* Control confirm */
#define EVTLSPCFGCFM     0x4e             /* config confirm */

/*
 * The reason we are mapping LSP_SW_XXX to SW_XXX is because we use it internally 
 * use it in GTT. Please refer to the code before changing these defines.
 */ 
#define LSP_SW_ITU   SW_ITU
#define LSP_SW_ANS   SW_ANSI
#define LSP_SW_CHINA SW_CHINA
#define LSP_SW_JAPAN SW_JAPAN

#define LSP_SW_ITU88   11
#define LSP_SW_ITU92   12
#define LSP_SW_ANS88   13
#define LSP_SW_ANS92   14
#define LSP_SW_ITU96   15
#define LSP_SW_ANS96   16
#define LSP_SW_BELL05  17
#define LSP_SW_GSM0806 18

#define SP_DBGMASK_INTERNAL    (DBGMASK_LYR << 0)    /* All internal events */   
#define SP_DBGMASK_DATA_MSG    (DBGMASK_LYR << 1)    /* All data message,added by wanglijun */   


/* Macro for Error Logging */

#if ERRCLASS
#define LSPLOGERROR(errCls, errCode, errVal, errDesc) \
   if (ERRCLASS & errCls) \
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, \
                __FILE__, __LINE__, errCls, errCode, errVal, errDesc)
#else
#define LSPLOGERROR(errCls, errCode, errVal, errDesc)
#endif /* ERRCLASS */


/* Trace Indication events */
/* 100 Seems to be a reasonable number for the maximum SCCP hdr size */
#define SP_TRACE_LEN   100        /* Maximum trace length */
#define SP_MSG_RECVD   1          /* Message received */
#define SP_MSG_TXED    2          /* Message transmitted */

#define SP_MAX_ACTNS 7
#define SP_MAX_ACTN_PARAMS 10

/* Defines for the function sets */
#define SP_T_FUNC 1  /* Trillium Functions */
#define SP_C_FUNC 2  /* Customer Functions */

/* Defines for GTT actions */
#define SP_ACTN_FIX         1   /* Fixed range */
#define SP_ACTN_VAR_ASC     2   /* Var range, ascending */
#define SP_ACTN_VAR_DES     3   /* Var range, descending */
#define SP_ACTN_CONST       4   /* Constant outAddr */
#define SP_ACTN_GT_TO_PC    5   /* GT goes into outgoing PC */
#define SP_ACTN_INSERT_PC   6   /* Insert PC in the beginning of GTAI -
                                   for Generic Numbering Plan */
#define SP_ACTN_STRIP_PC    7   /* Strip off PC from the beginning of GTAI -
                                   for Generic Numbering Plan */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* bits for compile flags */
#define LSP_SS7_ANS96_BIT   0x01      /* bit for compile flag SS7_ANS96 */
#define LSP_SS7_BELL05_BIT  0x02      /* bit for compile flag SS7_BELL05 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* default importance of SCCP messages as per ITU-T 1996 */
#define DEFUDTIMP    4   /* default importance of UDT */
#define DEFUDTSIMP   3   /* default importance of UDTS */
#define DEFXUDTIMP   4   /* default importance of XUDT */
#define DEFXUDTSIMP  3   /* default importance of XUDTS */
#define DEFLUDTIMP   4   /* default importance of LUDT */
#define DEFLUDTSIMP  3   /* default importance of LUDTS */
#define DEFCRIMP     2   /* default importance of CR */
#define DEFCCIMP     3   /* default importance of CC */
#define DEFCREFIMP   2   /* default importance of CREF */
#define DEFDT1IMP    4   /* default importance of DT1 */
#define DEFDT2IMP    4   /* default importance of DT2 */
#define DEFAKIMP     6   /* default importance of AK */
#define DEFITIMP     6   /* default importance of IT */
#define DEFEDIMP     7   /* default importance of ED */
#define DEFEAIMP     7   /* default importance of EA */
#define DEFRSRIMP    6   /* default importance of RSR */
#define DEFRSCIMP    6   /* default importance of RSC */
#define DEFERRIMP    7   /* default importance of ERR */
#define DEFRLSDIMP   6   /* default importance of RLSD */
#define DEFRLCIMP    4   /* default importance of RLC */

/* Error defines */
#define   ELSP001      (ERRLSP +    1)    /*        lsp.c: 224 */
#define   ELSP002      (ERRLSP +    2)    /*        lsp.c: 225 */
#define   ELSP003      (ERRLSP +    3)    /*        lsp.c: 226 */
#define   ELSP004      (ERRLSP +    4)    /*        lsp.c: 227 */
#define   ELSP005      (ERRLSP +    5)    /*        lsp.c: 237 */
#define   ELSP006      (ERRLSP +    6)    /*        lsp.c: 247 */
#define   ELSP007      (ERRLSP +    7)    /*        lsp.c: 259 */
#define   ELSP008      (ERRLSP +    8)    /*        lsp.c: 264 */
#define   ELSP009      (ERRLSP +    9)    /*        lsp.c: 266 */
#define   ELSP010      (ERRLSP +   10)    /*        lsp.c: 280 */
#define   ELSP011      (ERRLSP +   11)    /*        lsp.c: 286 */
#define   ELSP012      (ERRLSP +   12)    /*        lsp.c: 292 */
#define   ELSP013      (ERRLSP +   13)    /*        lsp.c: 297 */
#define   ELSP014      (ERRLSP +   14)    /*        lsp.c: 298 */
#define   ELSP015      (ERRLSP +   15)    /*        lsp.c: 301 */
#define   ELSP016      (ERRLSP +   16)    /*        lsp.c: 346 */
#define   ELSP017      (ERRLSP +   17)    /*        lsp.c: 347 */
#define   ELSP018      (ERRLSP +   18)    /*        lsp.c: 360 */
#define   ELSP019      (ERRLSP +   19)    /*        lsp.c: 362 */
#define   ELSP020      (ERRLSP +   20)    /*        lsp.c: 366 */
#define   ELSP021      (ERRLSP +   21)    /*        lsp.c: 405 */
#define   ELSP022      (ERRLSP +   22)    /*        lsp.c: 418 */
#define   ELSP023      (ERRLSP +   23)    /*        lsp.c: 421 */
#define   ELSP024      (ERRLSP +   24)    /*        lsp.c: 470 */
#define   ELSP025      (ERRLSP +   25)    /*        lsp.c: 483 */
#define   ELSP026      (ERRLSP +   26)    /*        lsp.c: 488 */
#define   ELSP027      (ERRLSP +   27)    /*        lsp.c: 493 */
#define   ELSP028      (ERRLSP +   28)    /*        lsp.c: 499 */
#define   ELSP029      (ERRLSP +   29)    /*        lsp.c: 503 */
#define   ELSP030      (ERRLSP +   30)    /*        lsp.c: 510 */
#define   ELSP031      (ERRLSP +   31)    /*        lsp.c: 517 */
#define   ELSP032      (ERRLSP +   32)    /*        lsp.c: 523 */
#define   ELSP033      (ERRLSP +   33)    /*        lsp.c: 528 */
#define   ELSP034      (ERRLSP +   34)    /*        lsp.c: 576 */
#define   ELSP035      (ERRLSP +   35)    /*        lsp.c: 580 */
#define   ELSP036      (ERRLSP +   36)    /*        lsp.c: 584 */
#define   ELSP037      (ERRLSP +   37)    /*        lsp.c: 588 */
#define   ELSP038      (ERRLSP +   38)    /*        lsp.c: 592 */
#define   ELSP039      (ERRLSP +   39)    /*        lsp.c: 596 */
#define   ELSP040      (ERRLSP +   40)    /*        lsp.c: 601 */
#define   ELSP041      (ERRLSP +   41)    /*        lsp.c: 606 */
#define   ELSP042      (ERRLSP +   42)    /*        lsp.c: 614 */
#define   ELSP043      (ERRLSP +   43)    /*        lsp.c: 619 */
#define   ELSP044      (ERRLSP +   44)    /*        lsp.c: 624 */
#define   ELSP045      (ERRLSP +   45)    /*        lsp.c: 629 */
#define   ELSP046      (ERRLSP +   46)    /*        lsp.c: 634 */
#define   ELSP047      (ERRLSP +   47)    /*        lsp.c: 688 */
#define   ELSP048      (ERRLSP +   48)    /*        lsp.c: 691 */
#define   ELSP049      (ERRLSP +   49)    /*        lsp.c: 700 */
#define   ELSP050      (ERRLSP +   50)    /*        lsp.c: 747 */
#define   ELSP051      (ERRLSP +   51)    /*        lsp.c: 760 */
#define   ELSP052      (ERRLSP +   52)    /*        lsp.c: 762 */
#define   ELSP053      (ERRLSP +   53)    /*        lsp.c: 770 */
#define   ELSP054      (ERRLSP +   54)    /*        lsp.c: 771 */
#define   ELSP055      (ERRLSP +   55)    /*        lsp.c: 823 */
#define   ELSP056      (ERRLSP +   56)    /*        lsp.c: 830 */
#define   ELSP057      (ERRLSP +   57)    /*        lsp.c: 835 */
#define   ELSP058      (ERRLSP +   58)    /*        lsp.c: 837 */
#define   ELSP059      (ERRLSP +   59)    /*        lsp.c: 844 */
#define   ELSP060      (ERRLSP +   60)    /*        lsp.c: 850 */
#define   ELSP061      (ERRLSP +   61)    /*        lsp.c: 856 */
#define   ELSP062      (ERRLSP +   62)    /*        lsp.c: 860 */
#define   ELSP063      (ERRLSP +   63)    /*        lsp.c: 862 */
#define   ELSP064      (ERRLSP +   64)    /*        lsp.c: 864 */
#define   ELSP065      (ERRLSP +   65)    /*        lsp.c: 869 */
#define   ELSP066      (ERRLSP +   66)    /*        lsp.c: 870 */
#define   ELSP067      (ERRLSP +   67)    /*        lsp.c: 871 */
#define   ELSP068      (ERRLSP +   68)    /*        lsp.c: 872 */
#define   ELSP069      (ERRLSP +   69)    /*        lsp.c: 918 */
#define   ELSP070      (ERRLSP +   70)    /*        lsp.c: 919 */
#define   ELSP071      (ERRLSP +   71)    /*        lsp.c: 920 */
#define   ELSP072      (ERRLSP +   72)    /*        lsp.c: 921 */
#define   ELSP073      (ERRLSP +   73)    /*        lsp.c: 923 */
#define   ELSP074      (ERRLSP +   74)    /*        lsp.c: 978 */
#define   ELSP075      (ERRLSP +   75)    /*        lsp.c: 980 */
#define   ELSP076      (ERRLSP +   76)    /*        lsp.c: 982 */
#define   ELSP077      (ERRLSP +   77)    /*        lsp.c: 988 */
#define   ELSP078      (ERRLSP +   78)    /*        lsp.c: 992 */
#define   ELSP079      (ERRLSP +   79)    /*        lsp.c: 994 */
#define   ELSP080      (ERRLSP +   80)    /*        lsp.c: 996 */
#define   ELSP081      (ERRLSP +   81)    /*        lsp.c:1002 */
#define   ELSP082      (ERRLSP +   82)    /*        lsp.c:1011 */
#define   ELSP083      (ERRLSP +   83)    /*        lsp.c:1013 */
#define   ELSP084      (ERRLSP +   84)    /*        lsp.c:1015 */
#define   ELSP085      (ERRLSP +   85)    /*        lsp.c:1017 */
#define   ELSP086      (ERRLSP +   86)    /*        lsp.c:1019 */
#define   ELSP087      (ERRLSP +   87)    /*        lsp.c:1023 */
#define   ELSP088      (ERRLSP +   88)    /*        lsp.c:1025 */
#define   ELSP089      (ERRLSP +   89)    /*        lsp.c:1027 */
#define   ELSP090      (ERRLSP +   90)    /*        lsp.c:1035 */
#define   ELSP091      (ERRLSP +   91)    /*        lsp.c:1037 */
#define   ELSP092      (ERRLSP +   92)    /*        lsp.c:1039 */
#define   ELSP093      (ERRLSP +   93)    /*        lsp.c:1041 */
#define   ELSP094      (ERRLSP +   94)    /*        lsp.c:1043 */
#define   ELSP095      (ERRLSP +   95)    /*        lsp.c:1045 */
#define   ELSP096      (ERRLSP +   96)    /*        lsp.c:1047 */
#define   ELSP097      (ERRLSP +   97)    /*        lsp.c:1049 */
#define   ELSP098      (ERRLSP +   98)    /*        lsp.c:1051 */
#define   ELSP099      (ERRLSP +   99)    /*        lsp.c:1053 */
#define   ELSP100      (ERRLSP +  100)    /*        lsp.c:1057 */
#define   ELSP101      (ERRLSP +  101)    /*        lsp.c:1059 */
#define   ELSP102      (ERRLSP +  102)    /*        lsp.c:1061 */
#define   ELSP103      (ERRLSP +  103)    /*        lsp.c:1119 */
#define   ELSP104      (ERRLSP +  104)    /*        lsp.c:1122 */
#define   ELSP105      (ERRLSP +  105)    /*        lsp.c:1125 */
#define   ELSP106      (ERRLSP +  106)    /*        lsp.c:1126 */
#define   ELSP107      (ERRLSP +  107)    /*        lsp.c:1132 */
#define   ELSP108      (ERRLSP +  108)    /*        lsp.c:1138 */
#define   ELSP109      (ERRLSP +  109)    /*        lsp.c:1143 */
#define   ELSP110      (ERRLSP +  110)    /*        lsp.c:1148 */
#define   ELSP111      (ERRLSP +  111)    /*        lsp.c:1207 */
#define   ELSP112      (ERRLSP +  112)    /*        lsp.c:1210 */
#define   ELSP113      (ERRLSP +  113)    /*        lsp.c:1212 */
#define   ELSP114      (ERRLSP +  114)    /*        lsp.c:1213 */
#define   ELSP115      (ERRLSP +  115)    /*        lsp.c:1222 */
#define   ELSP116      (ERRLSP +  116)    /*        lsp.c:1231 */
#define   ELSP117      (ERRLSP +  117)    /*        lsp.c:1233 */
#define   ELSP118      (ERRLSP +  118)    /*        lsp.c:1240 */
#define   ELSP119      (ERRLSP +  119)    /*        lsp.c:1242 */
#define   ELSP120      (ERRLSP +  120)    /*        lsp.c:1245 */
#define   ELSP121      (ERRLSP +  121)    /*        lsp.c:1247 */
#define   ELSP122      (ERRLSP +  122)    /*        lsp.c:1249 */
#define   ELSP123      (ERRLSP +  123)    /*        lsp.c:1257 */
#define   ELSP124      (ERRLSP +  124)    /*        lsp.c:1310 */
#define   ELSP125      (ERRLSP +  125)    /*        lsp.c:1313 */
#define   ELSP126      (ERRLSP +  126)    /*        lsp.c:1357 */
#define   ELSP127      (ERRLSP +  127)    /*        lsp.c:1360 */
#define   ELSP128      (ERRLSP +  128)    /*        lsp.c:1422 */
#define   ELSP129      (ERRLSP +  129)    /*        lsp.c:1430 */
#define   ELSP130      (ERRLSP +  130)    /*        lsp.c:1439 */
#define   ELSP131      (ERRLSP +  131)    /*        lsp.c:1441 */
#define   ELSP132      (ERRLSP +  132)    /*        lsp.c:1443 */
#define   ELSP133      (ERRLSP +  133)    /*        lsp.c:1445 */
#define   ELSP134      (ERRLSP +  134)    /*        lsp.c:1447 */
#define   ELSP135      (ERRLSP +  135)    /*        lsp.c:1449 */
#define   ELSP136      (ERRLSP +  136)    /*        lsp.c:1457 */
#define   ELSP137      (ERRLSP +  137)    /*        lsp.c:1459 */
#define   ELSP138      (ERRLSP +  138)    /*        lsp.c:1467 */
#define   ELSP139      (ERRLSP +  139)    /*        lsp.c:1478 */
#define   ELSP140      (ERRLSP +  140)    /*        lsp.c:1480 */
#define   ELSP141      (ERRLSP +  141)    /*        lsp.c:1481 */
#define   ELSP142      (ERRLSP +  142)    /*        lsp.c:1484 */
#define   ELSP143      (ERRLSP +  143)    /*        lsp.c:1493 */
#define   ELSP144      (ERRLSP +  144)    /*        lsp.c:1549 */
#define   ELSP145      (ERRLSP +  145)    /*        lsp.c:1558 */
#define   ELSP146      (ERRLSP +  146)    /*        lsp.c:1560 */
#define   ELSP147      (ERRLSP +  147)    /*        lsp.c:1562 */
#define   ELSP148      (ERRLSP +  148)    /*        lsp.c:1566 */
#define   ELSP149      (ERRLSP +  149)    /*        lsp.c:1570 */
#define   ELSP150      (ERRLSP +  150)    /*        lsp.c:1581 */
#define   ELSP151      (ERRLSP +  151)    /*        lsp.c:1583 */
#define   ELSP152      (ERRLSP +  152)    /*        lsp.c:1585 */
#define   ELSP153      (ERRLSP +  153)    /*        lsp.c:1587 */
#define   ELSP154      (ERRLSP +  154)    /*        lsp.c:1590 */
#define   ELSP155      (ERRLSP +  155)    /*        lsp.c:1592 */
#define   ELSP156      (ERRLSP +  156)    /*        lsp.c:1594 */
#define   ELSP157      (ERRLSP +  157)    /*        lsp.c:1596 */
#define   ELSP158      (ERRLSP +  158)    /*        lsp.c:1605 */
#define   ELSP159      (ERRLSP +  159)    /*        lsp.c:1607 */
#define   ELSP160      (ERRLSP +  160)    /*        lsp.c:1609 */
#define   ELSP161      (ERRLSP +  161)    /*        lsp.c:1611 */
#define   ELSP162      (ERRLSP +  162)    /*        lsp.c:1614 */
#define   ELSP163      (ERRLSP +  163)    /*        lsp.c:1616 */
#define   ELSP164      (ERRLSP +  164)    /*        lsp.c:1618 */
#define   ELSP165      (ERRLSP +  165)    /*        lsp.c:1620 */
#define   ELSP166      (ERRLSP +  166)    /*        lsp.c:1622 */
#define   ELSP167      (ERRLSP +  167)    /*        lsp.c:1624 */
#define   ELSP168      (ERRLSP +  168)    /*        lsp.c:1626 */
#define   ELSP169      (ERRLSP +  169)    /*        lsp.c:1628 */
#define   ELSP170      (ERRLSP +  170)    /*        lsp.c:1630 */
#define   ELSP171      (ERRLSP +  171)    /*        lsp.c:1644 */
#define   ELSP172      (ERRLSP +  172)    /*        lsp.c:1646 */
#define   ELSP173      (ERRLSP +  173)    /*        lsp.c:1648 */
#define   ELSP174      (ERRLSP +  174)    /*        lsp.c:1657 */
#define   ELSP175      (ERRLSP +  175)    /*        lsp.c:1702 */
#define   ELSP176      (ERRLSP +  176)    /*        lsp.c:1708 */
#define   ELSP177      (ERRLSP +  177)    /*        lsp.c:1709 */
#define   ELSP178      (ERRLSP +  178)    /*        lsp.c:1710 */
#define   ELSP179      (ERRLSP +  179)    /*        lsp.c:1711 */
#define   ELSP180      (ERRLSP +  180)    /*        lsp.c:1712 */
#define   ELSP181      (ERRLSP +  181)    /*        lsp.c:1760 */
#define   ELSP182      (ERRLSP +  182)    /*        lsp.c:1767 */
#define   ELSP183      (ERRLSP +  183)    /*        lsp.c:1772 */
#define   ELSP184      (ERRLSP +  184)    /*        lsp.c:1777 */
#define   ELSP185      (ERRLSP +  185)    /*        lsp.c:1782 */
#define   ELSP186      (ERRLSP +  186)    /*        lsp.c:1790 */
#define   ELSP187      (ERRLSP +  187)    /*        lsp.c:1791 */
#define   ELSP188      (ERRLSP +  188)    /*        lsp.c:1794 */
#define   ELSP189      (ERRLSP +  189)    /*        lsp.c:1797 */
#define   ELSP190      (ERRLSP +  190)    /*        lsp.c:1805 */
#define   ELSP191      (ERRLSP +  191)    /*        lsp.c:1850 */
#define   ELSP192      (ERRLSP +  192)    /*        lsp.c:1855 */
#define   ELSP193      (ERRLSP +  193)    /*        lsp.c:1858 */
#define   ELSP194      (ERRLSP +  194)    /*        lsp.c:1901 */
#define   ELSP195      (ERRLSP +  195)    /*        lsp.c:1906 */
#define   ELSP196      (ERRLSP +  196)    /*        lsp.c:1909 */
#define   ELSP197      (ERRLSP +  197)    /*        lsp.c:3087 */
#define   ELSP198      (ERRLSP +  198)    /*        lsp.c:3207 */
#define   ELSP199      (ERRLSP +  199)    /*        lsp.c:3337 */
#define   ELSP200      (ERRLSP +  200)    /*        lsp.c:3467 */

#endif /* __LSPH_ */


/********************************************************************30**
  
         End of file:     lsp.h@@/main/12_1 - Tue Jan 22 15:14:35 2002
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release

1.2          ---  fmg   1. remove GT_FRMT defines

1.3          ---  fmg   1. added GTFRM_? defines

1.4          ---  fmg   1. moved RTE_GT,RTE_SSN,RTE_DPC and GTFRMT_? 
                           defines to gen.h (Change Log Id: LSPH1_3ID000)
1.5          ---  fmg   1. corrected nature of address defines.

1.6          ---  fmg   1. added LSP_SW_{ITU,ANS}[88,92]
             ---  fmg   2. moved defines to cm_ss7.h
1.7          ---  fmg   1. moved SSN_PRES/NOTPRES and I/NAT_IND defines
                           to gen.h

1.8          ---  mjp   1. add unsolicited status events
             ---  mjp   2. add LSP_USTA_EP_MAX
             ---  mjp   3. moved SP_CONG to gen.h                     

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.9          ---      ash  1. Changes for LMINT3
                           2. Chnages for debug TCO
             sp010.27      3. patch for generating usta for syntax error
                      cp   4. added define for ELSPXXX.
                           5. Added define for internal messages for 
                              TCR0003.
                           6. Added Trace Ind events and SP_GEN_TRC 
                              macro.
                           7. SP_GEN_TRC moved to sp.h file

/main/10     sp005.28 cp   1. Added defines for the new GTT framework.
             ---      vb   2. Clean up of the patches
                      cp   3. Modified defines LSP_SW_ITU and LSP_SW_ANSI.
             ---      vb   1. Added defines for new switch and route flag

/main/12     ---      cp   1. DFTHA changes.
                           2. CHINA defines
            sp014.301 rc   3. Rolling upgrade changes as per tcr0020.txt:
                           -  LSP interface version number defined under 
                              compile flag LSPV1.
/main/12_1   ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
            sp001.302 rc   1. Sid correction
                           2. Changes to implement TCR21:
                              - new reasons of failure
                           3. if neither of LSPV1 or LSPV2 is defined, define
                              LSPIFVER as latest version (0x0200)
            sp020.302 rc   1. LSPV2_1 interface version created. Defining
                              LSPIFVER as the latest version 0x0201 if none of
                              LSPV1, LSPV2 or LSPV2_1 is defined.
            sp027.302 rc   1. Defines for SAP status moved from sp.h file to 
                              lsp.h file to report sap status in bitMask format
                              in LspStaCfm primitive to LM. 
            sp028.302 rc   1. New event and cause added for alarm when LclRef
                              can not be added for a new connection due to
                              exceeding the limit of max connections and when
                              connection could not be established due to 
                              exceeding conThresh value.
                           2. New event and cause added for alarm when DT2 msg
                              can nto be queued due to exceeding queThresh.
                           3. Defining LSPV2_2 interface version to report
                              number of connection in GLB sts. If LSPV2_2 is
                              defined then we define LSPV2_1 also to enable
                              all features of 2_1 in 2_2, but the intfVer
                              LSPIFVER is defined as of 2_2.
                           4. Defining LSPIFVER as the latest version 0x0202 if 
                              none of LSPV1, LSPV2, LSPV2_1 or LSPV2_2 defined
            sp032.302 cg   1. Defining LSPV2_3 interface version to add nmbConThresh
                              in Gen Cfg. If LSPV2_3 is defined then we define LSPV2_2
                              also to enable all features of 2_1 and 2_2 in 2_3, 
                              but the intfVer LSPIFVER is defined as of 2_3.
                           2. Defining LSPIFVER as the latest version 0x0203 if 
                              none of LSPV1, LSPV2, LSPV2_1 or LSPV2_2 defined
            sp035.302 mc   1. LSP_CAUSE_SSA_RECVD defined for generationg sccp
                              report on receiving SSA.  LSP_CAUSE_RMT_SP_INACC
                              and LSP_CAUSE_RMT_SP_ACC defined for remote SP 
                              inaccessble and accessible  indication from MTP3.
  lsp_h_001.main_12_1 mc   1. New interface LSVP2_4 introduced to add network id
                              in Association and AddressMap configuration.
                           2. Defining LSPV2_4 interface version to add
                              network id in associatoin and addressMap
                              configuration. also out network id is added in 
                              AddressMap configuration.If LSPV2_4 is defined
                              then we define LSPV2_3 
                              also to enable all features of 2_1 and 2_2 in 2_3,
                              but the intfVer LSPIFVER is defined as of 2_4.
                           3. Defining LSPIFVER as the latest version 0x0204 if 
                              none of LSPV1, LSPV2, LSPV2_1, LSPV2_2 or 
                              LSPV2_3 defined
  lsp_h_002.main_12_1 sm   1. Defining LSPV2_5 interface version to add
                              msgInterceptEnabled flag in upper SAP 
                              configuration.
*********************************************************************91*/
