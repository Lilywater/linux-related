/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     layer management interface - mtp level 3
  
     Type:     C include file
  
     Desc:     Defines required by the layer management service user.
  
     File:     lsn.h
  
     Sid:      lsn.h@@/main/16 - Mon Apr  9 13:48:21 2001
     
     Prg:      mc
  
*********************************************************************21*/
  
#ifndef __LSNH_
#define __LSNH_
 

/*
*     The defines declared in this file correspond to defines
*     used by the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - MTP Level 3
*
*/
 
/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000028     SS7 - MTP Level 3
*
*/
    

/* defines */

#define LSN_MAXADJSP        16       /* maximum number of adjacent SPs */
#define LSN_MAXCMBLNK       16       /* maximum combined link sets */
#ifdef SN_SG
#define LSN_MAXIPSP         16       /* maximum number if IP SPs */
#endif

/* link states */
 
#define LSN_LST_INACTIVE     0   /* link inactive state */
#define LSN_LST_CON          1   /* link is connecting */
#define LSN_LST_ACTIVE       2   /* link active state */
#define LSN_LST_FAILED       3   /* link failed state */
#define LSN_LST_WAITCON      4   /* waiting for connection */
#define LSN_LST_SUSPEND      5   /* link restoration suspended */
 
#define SN_LNKST             6   /* number of link states */

/* Sap bind states */

#define LSN_UNBND            1   /* sap is unbound */
#define LSN_BND              2   /* sap is bound */
#define LSN_WAIT_BNDCFM      3   /* bind procedure is going on */

/* link set states */
 
#define LSN_SET_ACTIVE        0       /* link set active state */
#define LSN_SET_INACTIVE      1       /* link set inactive state */
 
/* route states */
 
#define LSN_RTE_UNAVAIL       0       /* route is unavailable */
#define LSN_RTE_AVAIL         1       /* route is available */
 
/* routing directions */
 
#define LSN_RTE_DN            1       /* down / outbound route */
#define LSN_RTE_UP            2       /* up / inbound route  */
#ifdef SN_SG
#define LSN_RTE_IP            3       /* IP / route towards IP network  */
#endif
 
#define LSN_TYPE_SP           0       /* signalling point without transfer function */
#define LSN_TYPE_STP          1       /* signalling transfer point */
#define LSN_LNKTSTMAX         15       /* maximum length of link test pattern */
 
#define LSN_SW_ANS            1       /* link type ANSI */
#define LSN_SW_ITU            2       /* link type CCITT */
#define LSN_SW_CHINA          4       /* link type CHINA */
#define LSN_SW_BICI           5       /* link type BICI */
#define LSN_SW_ANS96          6       /* link type ANSI */
#define LSN_SW_TTC            7       /* link type Japan */
#define LSN_SW_NTT            8       /* link type Japan */

#define LNK_DEFAULT           0       /* link type for management message */
#define LNK_ANSI              1       /* link type ANSI */
#define LNK_CCITT             2       /* link type CCITT */
#define LNK_ANSI88            3       /* link type ANSI 88 */
#define LNK_CHINA             4       /* link type CHINA */
#define LNK_BICI              5       /* link type BICI */
#define LNK_SINGAPORE         6       /* link type SINGAPORE */

#define UP_DEFAULT            0       /* default user part */ 
/* values of l2Type for ANSI version */
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
#define LSN_MTP2_56KBPS       0
#define LSN_MTP2_1536KBPS     1
#define LSN_QSAAL             2
#endif

/* message / congestion priorities */
 
#define LSN_MGMPRI            3       /* mtp 3 management priority highest */
#define LSN_PRIORITY3         3
#define LSN_PRIORITY2         2
#define LSN_PRIORITY1         1
#define LSN_PRIORITY0         0

#define LSN_INVALID_DPC 0xffffffff

/* SLS ranges */
#define LSN_ITU_SLS_RANGE        16
#define LSN_ANSI_5BIT_SLS_RANGE  32
#define LSN_ANSI_8BIT_SLS_RANGE 256
#define LSN_NTT_SLS_RANGE        32

/* Linkset selector */
#define LSN_LSET_SEL_BIT1     0x1
#define LSN_LSET_SEL_BIT2     0x2
#define LSN_LSET_SEL_BIT3     0x4
#define LSN_LSET_SEL_BIT4     0x8

/* Lsn interface events for all alarms LsnStaInd */
#define LSN_EVENT_PROT_ST_UP       LCM_EVENT_LYR_SPECIFIC + 0 /* event - link up */
#define LSN_EVENT_PROT_ST_DN       LCM_EVENT_LYR_SPECIFIC + 1 /* event - link down */
#define LSN_EVENT_INH_DEN          LCM_EVENT_LYR_SPECIFIC + 2 /* event - link inhibit denied */
#define LSN_EVENT_UNINH_DEN        LCM_EVENT_LYR_SPECIFIC + 3 /* event - link uninhibit denied */
#define LSN_EVENT_LOC_INH_ACK      LCM_EVENT_LYR_SPECIFIC + 4 /* event - link inhibited locally */
#define LSN_EVENT_REM_INH_ACK      LCM_EVENT_LYR_SPECIFIC + 5 /* event - link inhibited remotely */
#define LSN_EVENT_LOC_UNINHED      LCM_EVENT_LYR_SPECIFIC + 6 /* event - link uninhibited locally */
#define LSN_EVENT_REM_UNINHED      LCM_EVENT_LYR_SPECIFIC + 7 /* event - link uninhibited remotely */
#define LSN_EVENT_LOC_FORCE_UNINH_DEN    LCM_EVENT_LYR_SPECIFIC + 8  
#define LSN_EVENT_RMT_FORCE_UNINH_DEN    LCM_EVENT_LYR_SPECIFIC + 9 
#define LSN_EVENT_LOC_RTE_MGMT_UNINH_DEN LCM_EVENT_LYR_SPECIFIC + 10
#define LSN_EVENT_RMT_BLKD         LCM_EVENT_LYR_SPECIFIC + 11 /* event - link remotely blocked */
#define LSN_EVENT_RMT_UNBLKD       LCM_EVENT_LYR_SPECIFIC + 12 /* event - link remotely unblocked */
#define LSN_EVENT_LOC_BLKD         LCM_EVENT_LYR_SPECIFIC + 13 /* event - link locally blocked */
#define LSN_EVENT_LOC_UNBLKD       LCM_EVENT_LYR_SPECIFIC + 14 /* event - link locally unblocked */
#define LSN_EVENT_PAUSE            LCM_EVENT_LYR_SPECIFIC + 15 /* event - concerned dpc pause */
#define LSN_EVENT_RESUME           LCM_EVENT_LYR_SPECIFIC + 16 /* event - concerned dpc resume */
#define LSN_EVENT_CONG             LCM_EVENT_LYR_SPECIFIC + 17 /* event - concerned dpc network congested */
#define LSN_EVENT_STPCONG          LCM_EVENT_LYR_SPECIFIC + 18 /* event - concerned dpc stop network congestion */
#define LSN_EVENT_RMTUSRUNAV       LCM_EVENT_LYR_SPECIFIC + 19 /* event - concerned dpc remote user unavailable */
#define LSN_EVENT_SDT_INV_DATA_CFM LCM_EVENT_LYR_SPECIFIC + 20 /* event - Invalid data confirm from SDT */
#define LSN_EVENT_SDT_INV_DATA_DRP LCM_EVENT_LYR_SPECIFIC + 21 /* event - concerned dpc remote user unavailable */
#define LSN_EVENT_SNT_INV          LCM_EVENT_LYR_SPECIFIC + 22 /* event - event received from SNT interface */
#define LSN_EVENT_SDT_INV          LCM_EVENT_LYR_SPECIFIC + 23 /* event - event received from SDT interface */
#define LSN_EVENT_LSNCFGREQ_OK     LCM_EVENT_LYR_SPECIFIC + 24 /* event - config request OK */
#define LSN_EVENT_LSNCFGREQ_NOK    LCM_EVENT_LYR_SPECIFIC + 25 /* event - config request not OK */
#define LSN_EVENT_LSNSTAREQ_OK     LCM_EVENT_LYR_SPECIFIC + 26 /* event - status request OK */
#define LSN_EVENT_LSNSTAREQ_NOK    LCM_EVENT_LYR_SPECIFIC + 27 /* event - status request not OK */
#define LSN_EVENT_LSNSTSREQ_OK     LCM_EVENT_LYR_SPECIFIC + 28 /* event - statistics request OK */
#define LSN_EVENT_LSNSTSREQ_NOK    LCM_EVENT_LYR_SPECIFIC + 29 /* event - statistics request not OK */
#define LSN_EVENT_LSNCNTRLREQ_OK   LCM_EVENT_LYR_SPECIFIC + 30 /* event - control request OK */
#define LSN_EVENT_LSNCNTRLREQ_NOK  LCM_EVENT_LYR_SPECIFIC + 31 /* event - control request not OK */
#define LSN_EVENT_INV_SRCENT       LCM_EVENT_LYR_SPECIFIC + 32 /* event - invalid source entity */

#define LSN_EVENT_INV_OPC_OTHER_END      LCM_EVENT_LYR_SPECIFIC + 33 /* event - invalid OPC */
#define LSN_EVENT_INV_SLC_OTHER_END LCM_EVENT_LYR_SPECIFIC + 34 /* event - slc on the other end of the link is wrong */  
#define LSN_EVENT_CRE_HMAP_FLR           LCM_EVENT_LYR_SPECIFIC + 35
#define LSN_EVENT_SLT                    LCM_EVENT_LYR_SPECIFIC + 36
#define LSN_EVENT_PERIODIC_SLT           LCM_EVENT_LYR_SPECIFIC + 37
#define LSN_EVENT_SRTEST           LCM_EVENT_LYR_SPECIFIC + 38 /* event - SRT result */

#define LSN_EVENT_DATA_DRP       LCM_EVENT_LYR_SPECIFIC + 39 /* event - invalid dpc */


/* Lsn interface events for trace indication LsnTrcInd */

#define LSN_MSG_RX           0        /* event - message received */
#define LSN_MSG_TX           1        /* event - message transmitted */

/* the rstReq field values for general config */
#define LSN_NO_RST           0        /* restart procedure disabled */
#define LSN_ITU88_RST        1        /* ITU'88 compliant restart procedure */
#define LSN_ITU92_RST        2        /* ITU'92 compliant restart procedure */
#define LSN_ANS_RST          3        /* ANSI compliant restart procedure */

/* Sn Management Events */

#define EVTLSNCFGREQ     0x3c         /* Configuration request */
#define EVTLSNSTAREQ     0x40         /* Status request */
#define EVTLSNSTACFM     0x41         /* Status confirm */
#define EVTLSNSTAIND     0x42         /* Status indication */
#define EVTLSNSTSREQ     0x44         /* Statistics request */
#define EVTLSNSTSCFM     0x45         /* Statistics confirm */
#define EVTLSNTRCIND     0x48         /* Trace indication */
#define EVTLSNCNTRLREQ   0x4c         /* Control request */

#define EVTLSNCFGCFM     0x4d         /* Configuration confirm */
#define EVTLSNCNTRLCFM   0x4e         /* Control confirm */

/* MTP3 specific reason in cfm structure */
#define LSN_REASON_NMBDLSAP_NOK    LCM_REASON_LYR_SPECIFIC + 0   
                                      /* number of DLSAP in gen cfg is more 
                                       * than NUMPHLNKS */
#define LSN_REASON_INV_LNKTYPE     LCM_REASON_LYR_SPECIFIC + 1
                                      /* Invalid link type */
#define LSN_REASON_INV_QLEN        LCM_REASON_LYR_SPECIFIC + 2
                                      /* Invalid queue length thresholds */
#define LSN_REASON_INV_LNKTSTSLC   LCM_REASON_LYR_SPECIFIC + 3
                                      /* Invalid lnkTstSLC in DLSAP cfg */
#define LSN_REASON_INV_CMBLNKSETID LCM_REASON_LYR_SPECIFIC + 4
                                      /* Invalid cmbLnkSetId in route cfg */
#define LSN_REASON_INV_DEL_PRIOR   LCM_REASON_LYR_SPECIFIC + 5
                                      /* Invalid prior of the element to 
                                       * be deleted */
#define LSN_REASON_INV_BNDSTATE    LCM_REASON_LYR_SPECIFIC + 6
                                      /* Invalid bndState of the link */
#define LSN_REASON_INV_LNKNUM      LCM_REASON_LYR_SPECIFIC + 7
#define LSN_REASON_EXCESS_RTECFG   LCM_REASON_LYR_SPECIFIC + 8
#define LSN_REASON_SRT_INPROG      LCM_REASON_LYR_SPECIFIC + 9 

/* MTP3 specific CAUSE defines in CmAlarm structure */  
#define LSN_CAUSE_T17_EXPIRED     LCM_CAUSE_LYR_SPECIFIC + 0  /* link deactivated */
#define LSN_CAUSE_LNK_DEACT       LCM_CAUSE_LYR_SPECIFIC + 1  /* link deactivated */
#define LSN_CAUSE_INV_OPC         LCM_CAUSE_LYR_SPECIFIC + 2  /* Invalid opc */
#define LSN_CAUSE_DPC_UNAVAIL     LCM_CAUSE_LYR_SPECIFIC + 3  /* DPC becomes unavailble */
#define LSN_CAUSE_RMT_NEG_ACK     LCM_CAUSE_LYR_SPECIFIC + 4  /* remote end nacked */
#define LSN_CAUSE_INV_TST_PTRN    LCM_CAUSE_LYR_SPECIFIC + 5 /* invalid test
pattern in SRT message. Only for TTC */
#define LSN_CAUSE_SELF_RST        LCM_CAUSE_LYR_SPECIFIC + 6  /* self restart */
#define LSN_CAUSE_ADJ_RST         LCM_CAUSE_LYR_SPECIFIC + 7  /* adlacent DPC restart */
#define LSN_CAUSE_INVALID_DPC        LCM_CAUSE_LYR_SPECIFIC + 8
#define LSN_CAUSE_DPC_CONG           LCM_CAUSE_LYR_SPECIFIC + 9
#define LSN_CAUSE_DPC_RMVD           LCM_CAUSE_LYR_SPECIFIC + 10
#define LSN_CAUSE_LNK_INACTV         LCM_CAUSE_LYR_SPECIFIC + 11
#define LSN_CAUSE_NO_LSETS_AVAIL     LCM_CAUSE_LYR_SPECIFIC + 12
#define LSN_CAUSE_LNK_RSTR_FAILED    LCM_CAUSE_LYR_SPECIFIC + 13 /* link
restoration failed */
#define LSN_CAUSE_INH_IN_PROG        LCM_CAUSE_LYR_SPECIFIC + 14
#define LSN_CAUSE_UNINH_IN_PROG      LCM_CAUSE_LYR_SPECIFIC + 15
#define LSN_CAUSE_PATH_UNAVAIL       LCM_CAUSE_LYR_SPECIFIC + 16
#define LSN_CAUSE_NO_RMT_ACK         LCM_CAUSE_LYR_SPECIFIC + 17
#define LSN_CAUSE_RMT_INIT           LCM_CAUSE_LYR_SPECIFIC + 18 
#define LSN_CAUSE_LOC_RTE_MGMT_INIT  LCM_CAUSE_LYR_SPECIFIC + 19 
#define LSN_CAUSE_DPC_FAILED         LCM_CAUSE_LYR_SPECIFIC + 20 
#define LSN_CAUSE_T32_EXPIRED        LCM_CAUSE_LYR_SPECIFIC + 21 
#define LSN_CAUSE_NULL_NIFOPC        LCM_CAUSE_LYR_SPECIFIC + 22
#define LSN_CAUSE_SP_ROUTING         LCM_CAUSE_LYR_SPECIFIC + 23


#define LSN_LSET_FULL_NORMAL  0
#define LSN_LSET_NORMAL       1
#define LSN_LSET_HALF_NORMAL  2
#define LSN_LSET_ABNORMAL     3
#define MAX_LSET_STATES 4

/* layer specific actions */
/* Note, currently the actions in gen.h are defined upto 52 and there is no 
   provisioning for layer specific actions. In MTP-3 ASRTEST is introduced 
   as a layer specific action. It's value is choosen to be 101. However if the
   general action values are defined upto this value, this value has to be
   changed */
#define ASRTEST     101    /* Perform SRT */


#if (SS7_TTC || SS7_NTT)
/* New hash defines for SRT related alarms */
#define LSN_SRT_FAILED 0
#define LSN_SRT_PASSED 1
#define LSN_SRT_TIMEOUT 2
#define LSN_SRT_LNK_INACTIVE 3
#define LSN_SRT_LNKSET_INACTIVE 4
#define LSN_SRT_ROUT_UNAVAIL 5
#define LSN_SRT_INV_TST_PTRN 6
#define LSN_SRT_INV_SLC 7
#define LSN_SRT_FLC_ON 8
#if (SS7_NTT)
#define LSN_USN_MAIN_SIG_DOM 9
#define LSN_USN_SUB_SIG_DOM 10
#define LSN_USN_SIG_PT_NUM  11
#endif
#endif 

/* user part bits for Signalling Gateway NIF SAP */
#ifdef SN_SG
#define SI_SCCP_BIT  0x1
#define SI_TUP_BIT   0x2 
#define SI_ISUP_BIT  0x4 
#define SI_DUP_BIT   0x8 
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
#define SI_DUPF_BIT  0x10 
#endif
#define SI_MTUP_BIT  0x20
#define SI_BISUP_BIT 0x40 
#define SI_SISUP_BIT 0x80 
#define SI_AAL2_BIT  0x100
#define SI_ALLUSERS_BIT 0x1FF
#endif
#define ERRLSN 0                  /* reserved */
#define ELSNXXX       (ERRLSN)    /* reserved */

#define   ELSN001      (ERRLSN +    1)    /*        lsn.c: 179 */
#define   ELSN002      (ERRLSN +    2)    /*        lsn.c: 184 */
#define   ELSN003      (ERRLSN +    3)    /*        lsn.c: 187 */
#define   ELSN004      (ERRLSN +    4)    /*        lsn.c: 231 */
#define   ELSN005      (ERRLSN +    5)    /*        lsn.c: 236 */
#define   ELSN006      (ERRLSN +    6)    /*        lsn.c: 239 */
#define   ELSN007      (ERRLSN +    7)    /*        lsn.c: 282 */
#define   ELSN008      (ERRLSN +    8)    /*        lsn.c: 288 */
#define   ELSN009      (ERRLSN +    9)    /*        lsn.c: 291 */
#define   ELSN010      (ERRLSN +   10)    /*        lsn.c: 292 */
#define   ELSN011      (ERRLSN +   11)    /*        lsn.c: 293 */
#define   ELSN012      (ERRLSN +   12)    /*        lsn.c: 294 */
#define   ELSN013      (ERRLSN +   13)    /*        lsn.c: 295 */
#define   ELSN014      (ERRLSN +   14)    /*        lsn.c: 296 */
#define   ELSN015      (ERRLSN +   15)    /*        lsn.c: 297 */
#define   ELSN016      (ERRLSN +   16)    /*        lsn.c: 298 */
#define   ELSN017      (ERRLSN +   17)    /*        lsn.c: 299 */
#define   ELSN018      (ERRLSN +   18)    /*        lsn.c: 300 */
#define   ELSN019      (ERRLSN +   19)    /*        lsn.c: 301 */
#define   ELSN020      (ERRLSN +   20)    /*        lsn.c: 302 */
#define   ELSN021      (ERRLSN +   21)    /*        lsn.c: 303 */
#define   ELSN022      (ERRLSN +   22)    /*        lsn.c: 304 */
#define   ELSN023      (ERRLSN +   23)    /*        lsn.c: 307 */
#define   ELSN024      (ERRLSN +   24)    /*        lsn.c: 308 */
#define   ELSN025      (ERRLSN +   25)    /*        lsn.c: 309 */
#define   ELSN026      (ERRLSN +   26)    /*        lsn.c: 310 */
#define   ELSN027      (ERRLSN +   27)    /*        lsn.c: 312 */
#define   ELSN028      (ERRLSN +   28)    /*        lsn.c: 316 */
#define   ELSN029      (ERRLSN +   29)    /*        lsn.c: 317 */
#define   ELSN030      (ERRLSN +   30)    /*        lsn.c: 318 */
#define   ELSN031      (ERRLSN +   31)    /*        lsn.c: 319 */
#define   ELSN032      (ERRLSN +   32)    /*        lsn.c: 320 */
#define   ELSN033      (ERRLSN +   33)    /*        lsn.c: 321 */
#define   ELSN034      (ERRLSN +   34)    /*        lsn.c: 322 */
#define   ELSN035      (ERRLSN +   35)    /*        lsn.c: 325 */
#define   ELSN036      (ERRLSN +   36)    /*        lsn.c: 329 */
#define   ELSN037      (ERRLSN +   37)    /*        lsn.c: 334 */
#define   ELSN038      (ERRLSN +   38)    /*        lsn.c: 336 */
#define   ELSN039      (ERRLSN +   39)    /*        lsn.c: 338 */
#define   ELSN040      (ERRLSN +   40)    /*        lsn.c: 381 */
#define   ELSN041      (ERRLSN +   41)    /*        lsn.c: 387 */
#define   ELSN042      (ERRLSN +   42)    /*        lsn.c: 389 */
#define   ELSN043      (ERRLSN +   43)    /*        lsn.c: 391 */
#define   ELSN044      (ERRLSN +   44)    /*        lsn.c: 394 */
#define   ELSN045      (ERRLSN +   45)    /*        lsn.c: 396 */
#define   ELSN046      (ERRLSN +   46)    /*        lsn.c: 399 */
#define   ELSN047      (ERRLSN +   47)    /*        lsn.c: 442 */
#define   ELSN048      (ERRLSN +   48)    /*        lsn.c: 445 */
#define   ELSN049      (ERRLSN +   49)    /*        lsn.c: 446 */
#define   ELSN050      (ERRLSN +   50)    /*        lsn.c: 447 */
#define   ELSN051      (ERRLSN +   51)    /*        lsn.c: 448 */
#define   ELSN052      (ERRLSN +   52)    /*        lsn.c: 449 */
#define   ELSN053      (ERRLSN +   53)    /*        lsn.c: 453 */
#define   ELSN054      (ERRLSN +   54)    /*        lsn.c: 454 */
#define   ELSN055      (ERRLSN +   55)    /*        lsn.c: 455 */
#define   ELSN056      (ERRLSN +   56)    /*        lsn.c: 456 */
#define   ELSN057      (ERRLSN +   57)    /*        lsn.c: 458 */
#define   ELSN058      (ERRLSN +   58)    /*        lsn.c: 459 */
#define   ELSN059      (ERRLSN +   59)    /*        lsn.c: 461 */
#define   ELSN060      (ERRLSN +   60)    /*        lsn.c: 464 */
#define   ELSN061      (ERRLSN +   61)    /*        lsn.c: 465 */
#define   ELSN062      (ERRLSN +   62)    /*        lsn.c: 466 */
#define   ELSN063      (ERRLSN +   63)    /*        lsn.c: 467 */
#define   ELSN064      (ERRLSN +   64)    /*        lsn.c: 468 */
#define   ELSN065      (ERRLSN +   65)    /*        lsn.c: 469 */
#define   ELSN066      (ERRLSN +   66)    /*        lsn.c: 470 */
#define   ELSN067      (ERRLSN +   67)    /*        lsn.c: 471 */
#define   ELSN068      (ERRLSN +   68)    /*        lsn.c: 472 */
#define   ELSN069      (ERRLSN +   69)    /*        lsn.c: 473 */
#define   ELSN070      (ERRLSN +   70)    /*        lsn.c: 474 */
#define   ELSN071      (ERRLSN +   71)    /*        lsn.c: 475 */
#define   ELSN072      (ERRLSN +   72)    /*        lsn.c: 476 */
#define   ELSN073      (ERRLSN +   73)    /*        lsn.c: 477 */
#define   ELSN074      (ERRLSN +   74)    /*        lsn.c: 478 */
#define   ELSN075      (ERRLSN +   75)    /*        lsn.c: 479 */
#define   ELSN076      (ERRLSN +   76)    /*        lsn.c: 480 */
#define   ELSN077      (ERRLSN +   77)    /*        lsn.c: 481 */
#define   ELSN078      (ERRLSN +   78)    /*        lsn.c: 482 */
#define   ELSN079      (ERRLSN +   79)    /*        lsn.c: 483 */
#define   ELSN080      (ERRLSN +   80)    /*        lsn.c: 484 */
#define   ELSN081      (ERRLSN +   81)    /*        lsn.c: 485 */
#define   ELSN082      (ERRLSN +   82)    /*        lsn.c: 486 */
#define   ELSN083      (ERRLSN +   83)    /*        lsn.c: 487 */
#define   ELSN084      (ERRLSN +   84)    /*        lsn.c: 488 */
#define   ELSN085      (ERRLSN +   85)    /*        lsn.c: 489 */
#define   ELSN086      (ERRLSN +   86)    /*        lsn.c: 490 */
#define   ELSN087      (ERRLSN +   87)    /*        lsn.c: 491 */
#define   ELSN088      (ERRLSN +   88)    /*        lsn.c: 492 */
#define   ELSN089      (ERRLSN +   89)    /*        lsn.c: 493 */
#define   ELSN090      (ERRLSN +   90)    /*        lsn.c: 494 */
#define   ELSN091      (ERRLSN +   91)    /*        lsn.c: 495 */
#define   ELSN092      (ERRLSN +   92)    /*        lsn.c: 496 */
#define   ELSN093      (ERRLSN +   93)    /*        lsn.c: 497 */
#define   ELSN094      (ERRLSN +   94)    /*        lsn.c: 498 */
#define   ELSN095      (ERRLSN +   95)    /*        lsn.c: 499 */
#define   ELSN096      (ERRLSN +   96)    /*        lsn.c: 500 */
#define   ELSN097      (ERRLSN +   97)    /*        lsn.c: 501 */
#define   ELSN098      (ERRLSN +   98)    /*        lsn.c: 502 */
#define   ELSN099      (ERRLSN +   99)    /*        lsn.c: 503 */
#define   ELSN100      (ERRLSN +  100)    /*        lsn.c: 504 */
#define   ELSN101      (ERRLSN +  101)    /*        lsn.c: 505 */
#define   ELSN102      (ERRLSN +  102)    /*        lsn.c: 506 */
#define   ELSN103      (ERRLSN +  103)    /*        lsn.c: 507 */
#define   ELSN104      (ERRLSN +  104)    /*        lsn.c: 508 */
#define   ELSN105      (ERRLSN +  105)    /*        lsn.c: 509 */
#define   ELSN106      (ERRLSN +  106)    /*        lsn.c: 510 */
#define   ELSN107      (ERRLSN +  107)    /*        lsn.c: 511 */
#define   ELSN108      (ERRLSN +  108)    /*        lsn.c: 512 */
#define   ELSN109      (ERRLSN +  109)    /*        lsn.c: 513 */
#define   ELSN110      (ERRLSN +  110)    /*        lsn.c: 516 */
#define   ELSN111      (ERRLSN +  111)    /*        lsn.c: 517 */
#define   ELSN112      (ERRLSN +  112)    /*        lsn.c: 518 */
#define   ELSN113      (ERRLSN +  113)    /*        lsn.c: 519 */
#define   ELSN114      (ERRLSN +  114)    /*        lsn.c: 520 */
#define   ELSN115      (ERRLSN +  115)    /*        lsn.c: 521 */
#define   ELSN116      (ERRLSN +  116)    /*        lsn.c: 522 */
#define   ELSN117      (ERRLSN +  117)    /*        lsn.c: 523 */
#define   ELSN118      (ERRLSN +  118)    /*        lsn.c: 524 */
#define   ELSN119      (ERRLSN +  119)    /*        lsn.c: 525 */
#define   ELSN120      (ERRLSN +  120)    /*        lsn.c: 526 */
#define   ELSN121      (ERRLSN +  121)    /*        lsn.c: 527 */
#define   ELSN122      (ERRLSN +  122)    /*        lsn.c: 528 */
#define   ELSN123      (ERRLSN +  123)    /*        lsn.c: 529 */
#define   ELSN124      (ERRLSN +  124)    /*        lsn.c: 530 */
#define   ELSN125      (ERRLSN +  125)    /*        lsn.c: 531 */
#define   ELSN126      (ERRLSN +  126)    /*        lsn.c: 532 */
#define   ELSN127      (ERRLSN +  127)    /*        lsn.c: 533 */
#define   ELSN128      (ERRLSN +  128)    /*        lsn.c: 535 */
#define   ELSN129      (ERRLSN +  129)    /*        lsn.c: 539 */
#define   ELSN130      (ERRLSN +  130)    /*        lsn.c: 540 */
#define   ELSN131      (ERRLSN +  131)    /*        lsn.c: 541 */
#define   ELSN132      (ERRLSN +  132)    /*        lsn.c: 546 */
#define   ELSN133      (ERRLSN +  133)    /*        lsn.c: 547 */
#define   ELSN134      (ERRLSN +  134)    /*        lsn.c: 549 */
#define   ELSN135      (ERRLSN +  135)    /*        lsn.c: 551 */
#define   ELSN136      (ERRLSN +  136)    /*        lsn.c: 593 */
#define   ELSN137      (ERRLSN +  137)    /*        lsn.c: 596 */
#define   ELSN138      (ERRLSN +  138)    /*        lsn.c: 599 */
#define   ELSN139      (ERRLSN +  139)    /*        lsn.c: 601 */
#define   ELSN140      (ERRLSN +  140)    /*        lsn.c: 602 */
#define   ELSN141      (ERRLSN +  141)    /*        lsn.c: 642 */
#define   ELSN142      (ERRLSN +  142)    /*        lsn.c: 643 */
#define   ELSN143      (ERRLSN +  143)    /*        lsn.c: 644 */
#define   ELSN144      (ERRLSN +  144)    /*        lsn.c: 645 */
#define   ELSN145      (ERRLSN +  145)    /*        lsn.c: 649 */
#define   ELSN146      (ERRLSN +  146)    /*        lsn.c: 653 */
#define   ELSN147      (ERRLSN +  147)    /*        lsn.c: 654 */
#define   ELSN148      (ERRLSN +  148)    /*        lsn.c: 659 */
#define   ELSN149      (ERRLSN +  149)    /*        lsn.c: 665 */
#define   ELSN150      (ERRLSN +  150)    /*        lsn.c: 709 */
#define   ELSN151      (ERRLSN +  151)    /*        lsn.c: 710 */
#define   ELSN152      (ERRLSN +  152)    /*        lsn.c: 711 */
#define   ELSN153      (ERRLSN +  153)    /*        lsn.c: 719 */
#define   ELSN154      (ERRLSN +  154)    /*        lsn.c: 720 */
#define   ELSN155      (ERRLSN +  155)    /*        lsn.c: 761 */
#define   ELSN156      (ERRLSN +  156)    /*        lsn.c: 762 */
#define   ELSN157      (ERRLSN +  157)    /*        lsn.c: 772 */
#define   ELSN158      (ERRLSN +  158)    /*        lsn.c: 773 */
#define   ELSN159      (ERRLSN +  159)    /*        lsn.c: 816 */
#define   ELSN160      (ERRLSN +  160)    /*        lsn.c: 821 */
#define   ELSN161      (ERRLSN +  161)    /*        lsn.c: 822 */
#define   ELSN162      (ERRLSN +  162)    /*        lsn.c: 823 */
#define   ELSN163      (ERRLSN +  163)    /*        lsn.c: 825 */
#define   ELSN164      (ERRLSN +  164)    /*        lsn.c: 826 */
#define   ELSN165      (ERRLSN +  165)    /*        lsn.c: 827 */
#define   ELSN166      (ERRLSN +  166)    /*        lsn.c: 828 */
#define   ELSN167      (ERRLSN +  167)    /*        lsn.c: 829 */
#define   ELSN168      (ERRLSN +  168)    /*        lsn.c: 830 */
#define   ELSN169      (ERRLSN +  169)    /*        lsn.c: 831 */
#define   ELSN170      (ERRLSN +  170)    /*        lsn.c: 832 */
#define   ELSN171      (ERRLSN +  171)    /*        lsn.c: 834 */
#define   ELSN172      (ERRLSN +  172)    /*        lsn.c: 836 */
#define   ELSN173      (ERRLSN +  173)    /*        lsn.c: 837 */
#define   ELSN174      (ERRLSN +  174)    /*        lsn.c: 838 */
#define   ELSN175      (ERRLSN +  175)    /*        lsn.c: 839 */
#define   ELSN176      (ERRLSN +  176)    /*        lsn.c: 840 */
#define   ELSN177      (ERRLSN +  177)    /*        lsn.c: 841 */
#define   ELSN178      (ERRLSN +  178)    /*        lsn.c: 842 */
#define   ELSN179      (ERRLSN +  179)    /*        lsn.c: 843 */
#define   ELSN180      (ERRLSN +  180)    /*        lsn.c: 844 */
#define   ELSN181      (ERRLSN +  181)    /*        lsn.c: 845 */
#define   ELSN182      (ERRLSN +  182)    /*        lsn.c: 846 */
#define   ELSN183      (ERRLSN +  183)    /*        lsn.c: 847 */
#define   ELSN184      (ERRLSN +  184)    /*        lsn.c: 848 */
#define   ELSN185      (ERRLSN +  185)    /*        lsn.c: 849 */
#define   ELSN186      (ERRLSN +  186)    /*        lsn.c: 850 */
#define   ELSN187      (ERRLSN +  187)    /*        lsn.c: 851 */
#define   ELSN188      (ERRLSN +  188)    /*        lsn.c: 853 */
#define   ELSN189      (ERRLSN +  189)    /*        lsn.c: 855 */
#define   ELSN190      (ERRLSN +  190)    /*        lsn.c: 856 */
#define   ELSN191      (ERRLSN +  191)    /*        lsn.c: 860 */
#define   ELSN192      (ERRLSN +  192)    /*        lsn.c: 862 */
#define   ELSN193      (ERRLSN +  193)    /*        lsn.c: 863 */
#define   ELSN194      (ERRLSN +  194)    /*        lsn.c: 864 */
#define   ELSN195      (ERRLSN +  195)    /*        lsn.c: 865 */
#define   ELSN196      (ERRLSN +  196)    /*        lsn.c: 866 */
#define   ELSN197      (ERRLSN +  197)    /*        lsn.c: 867 */
#define   ELSN198      (ERRLSN +  198)    /*        lsn.c: 868 */
#define   ELSN199      (ERRLSN +  199)    /*        lsn.c: 869 */
#define   ELSN200      (ERRLSN +  200)    /*        lsn.c: 870 */
#define   ELSN201      (ERRLSN +  201)    /*        lsn.c: 874 */
#define   ELSN202      (ERRLSN +  202)    /*        lsn.c: 875 */
#define   ELSN203      (ERRLSN +  203)    /*        lsn.c: 876 */
#define   ELSN204      (ERRLSN +  204)    /*        lsn.c: 877 */
#define   ELSN205      (ERRLSN +  205)    /*        lsn.c: 878 */
#define   ELSN206      (ERRLSN +  206)    /*        lsn.c: 879 */
#define   ELSN207      (ERRLSN +  207)    /*        lsn.c: 880 */
#define   ELSN208      (ERRLSN +  208)    /*        lsn.c: 881 */
#define   ELSN209      (ERRLSN +  209)    /*        lsn.c: 882 */
#define   ELSN210      (ERRLSN +  210)    /*        lsn.c: 883 */
#define   ELSN211      (ERRLSN +  211)    /*        lsn.c: 884 */
#define   ELSN212      (ERRLSN +  212)    /*        lsn.c: 886 */
#define   ELSN213      (ERRLSN +  213)    /*        lsn.c: 887 */
#define   ELSN214      (ERRLSN +  214)    /*        lsn.c: 890 */
#define   ELSN215      (ERRLSN +  215)    /*        lsn.c: 891 */
#define   ELSN216      (ERRLSN +  216)    /*        lsn.c: 892 */
#define   ELSN217      (ERRLSN +  217)    /*        lsn.c: 893 */
#define   ELSN218      (ERRLSN +  218)    /*        lsn.c: 895 */
#define   ELSN219      (ERRLSN +  219)    /*        lsn.c: 896 */
#define   ELSN220      (ERRLSN +  220)    /*        lsn.c: 897 */
#define   ELSN221      (ERRLSN +  221)    /*        lsn.c: 898 */
#define   ELSN222      (ERRLSN +  222)    /*        lsn.c: 899 */
#define   ELSN223      (ERRLSN +  223)    /*        lsn.c: 900 */
#define   ELSN224      (ERRLSN +  224)    /*        lsn.c: 901 */
#define   ELSN225      (ERRLSN +  225)    /*        lsn.c: 902 */
#define   ELSN226      (ERRLSN +  226)    /*        lsn.c: 903 */
#define   ELSN227      (ERRLSN +  227)    /*        lsn.c: 904 */
#define   ELSN228      (ERRLSN +  228)    /*        lsn.c: 905 */
#define   ELSN229      (ERRLSN +  229)    /*        lsn.c: 906 */
#define   ELSN230      (ERRLSN +  230)    /*        lsn.c: 907 */
#define   ELSN231      (ERRLSN +  231)    /*        lsn.c: 908 */
#define   ELSN232      (ERRLSN +  232)    /*        lsn.c: 909 */
#define   ELSN233      (ERRLSN +  233)    /*        lsn.c: 910 */
#define   ELSN234      (ERRLSN +  234)    /*        lsn.c: 911 */
#define   ELSN235      (ERRLSN +  235)    /*        lsn.c: 912 */
#define   ELSN236      (ERRLSN +  236)    /*        lsn.c: 915 */
#define   ELSN237      (ERRLSN +  237)    /*        lsn.c: 917 */
#define   ELSN238      (ERRLSN +  238)    /*        lsn.c: 918 */
#define   ELSN239      (ERRLSN +  239)    /*        lsn.c: 919 */
#define   ELSN240      (ERRLSN +  240)    /*        lsn.c: 921 */
#define   ELSN241      (ERRLSN +  241)    /*        lsn.c: 923 */
#define   ELSN242      (ERRLSN +  242)    /*        lsn.c: 924 */
#define   ELSN243      (ERRLSN +  243)    /*        lsn.c: 925 */
#define   ELSN244      (ERRLSN +  244)    /*        lsn.c: 926 */
#define   ELSN245      (ERRLSN +  245)    /*        lsn.c: 927 */
#define   ELSN246      (ERRLSN +  246)    /*        lsn.c: 929 */
#define   ELSN247      (ERRLSN +  247)    /*        lsn.c: 930 */
#define   ELSN248      (ERRLSN +  248)    /*        lsn.c: 932 */
#define   ELSN249      (ERRLSN +  249)    /*        lsn.c: 933 */
#define   ELSN250      (ERRLSN +  250)    /*        lsn.c: 934 */
#define   ELSN251      (ERRLSN +  251)    /*        lsn.c: 935 */
#define   ELSN252      (ERRLSN +  252)    /*        lsn.c: 936 */
#define   ELSN253      (ERRLSN +  253)    /*        lsn.c: 937 */
#define   ELSN254      (ERRLSN +  254)    /*        lsn.c: 938 */
#define   ELSN255      (ERRLSN +  255)    /*        lsn.c: 939 */
#define   ELSN256      (ERRLSN +  256)    /*        lsn.c: 942 */
#define   ELSN257      (ERRLSN +  257)    /*        lsn.c: 943 */
#define   ELSN258      (ERRLSN +  258)    /*        lsn.c: 944 */
#define   ELSN259      (ERRLSN +  259)    /*        lsn.c: 945 */
#define   ELSN260      (ERRLSN +  260)    /*        lsn.c: 946 */
#define   ELSN261      (ERRLSN +  261)    /*        lsn.c: 947 */
#define   ELSN262      (ERRLSN +  262)    /*        lsn.c: 948 */
#define   ELSN263      (ERRLSN +  263)    /*        lsn.c: 949 */
#define   ELSN264      (ERRLSN +  264)    /*        lsn.c: 950 */
#define   ELSN265      (ERRLSN +  265)    /*        lsn.c: 951 */
#define   ELSN266      (ERRLSN +  266)    /*        lsn.c: 952 */
#define   ELSN267      (ERRLSN +  267)    /*        lsn.c: 953 */
#define   ELSN268      (ERRLSN +  268)    /*        lsn.c: 954 */
#define   ELSN269      (ERRLSN +  269)    /*        lsn.c: 955 */
#define   ELSN270      (ERRLSN +  270)    /*        lsn.c: 957 */
#define   ELSN271      (ERRLSN +  271)    /*        lsn.c: 958 */
#define   ELSN272      (ERRLSN +  272)    /*        lsn.c: 961 */
#define   ELSN273      (ERRLSN +  273)    /*        lsn.c: 964 */
#define   ELSN274      (ERRLSN +  274)    /*        lsn.c: 966 */
#define   ELSN275      (ERRLSN +  275)    /*        lsn.c: 967 */
#define   ELSN276      (ERRLSN +  276)    /*        lsn.c: 968 */
#define   ELSN277      (ERRLSN +  277)    /*        lsn.c: 969 */
#define   ELSN278      (ERRLSN +  278)    /*        lsn.c: 970 */
#define   ELSN279      (ERRLSN +  279)    /*        lsn.c: 971 */
#define   ELSN280      (ERRLSN +  280)    /*        lsn.c: 976 */
#define   ELSN281      (ERRLSN +  281)    /*        lsn.c: 977 */
#define   ELSN282      (ERRLSN +  282)    /*        lsn.c: 979 */
#define   ELSN283      (ERRLSN +  283)    /*        lsn.c: 980 */
#define   ELSN284      (ERRLSN +  284)    /*        lsn.c: 981 */
#define   ELSN285      (ERRLSN +  285)    /*        lsn.c: 982 */
#define   ELSN286      (ERRLSN +  286)    /*        lsn.c:1411 */
#define   ELSN287      (ERRLSN +  287)    /*        lsn.c:1413 */
#define   ELSN288      (ERRLSN +  288)    /*        lsn.c:1415 */
#define   ELSN289      (ERRLSN +  289)    /*        lsn.c:1419 */
#define   ELSN290      (ERRLSN +  290)    /*        lsn.c:1422 */
#define   ELSN291      (ERRLSN +  291)    /*        lsn.c:1423 */
#define   ELSN292      (ERRLSN +  292)    /*        lsn.c:1424 */
#define   ELSN293      (ERRLSN +  293)    /*        lsn.c:1425 */
#define   ELSN294      (ERRLSN +  294)    /*        lsn.c:1426 */
#define   ELSN295      (ERRLSN +  295)    /*        lsn.c:1427 */
#define   ELSN296      (ERRLSN +  296)    /*        lsn.c:1428 */
#define   ELSN297      (ERRLSN +  297)    /*        lsn.c:1429 */
#define   ELSN298      (ERRLSN +  298)    /*        lsn.c:1430 */
#define   ELSN299      (ERRLSN +  299)    /*        lsn.c:1431 */
#define   ELSN300      (ERRLSN +  300)    /*        lsn.c:1432 */
#define   ELSN301      (ERRLSN +  301)    /*        lsn.c:1433 */
#define   ELSN302      (ERRLSN +  302)    /*        lsn.c:1434 */
#define   ELSN303      (ERRLSN +  303)    /*        lsn.c:1435 */
#define   ELSN304      (ERRLSN +  304)    /*        lsn.c:1439 */
#define   ELSN305      (ERRLSN +  305)    /*        lsn.c:1441 */
#define   ELSN306      (ERRLSN +  306)    /*        lsn.c:1442 */
#define   ELSN307      (ERRLSN +  307)    /*        lsn.c:1443 */
#define   ELSN308      (ERRLSN +  308)    /*        lsn.c:1444 */
#define   ELSN309      (ERRLSN +  309)    /*        lsn.c:1447 */
#define   ELSN310      (ERRLSN +  310)    /*        lsn.c:1448 */
#define   ELSN311      (ERRLSN +  311)    /*        lsn.c:1449 */
#define   ELSN312      (ERRLSN +  312)    /*        lsn.c:1450 */
#define   ELSN313      (ERRLSN +  313)    /*        lsn.c:1451 */
#define   ELSN314      (ERRLSN +  314)    /*        lsn.c:1452 */
#define   ELSN315      (ERRLSN +  315)    /*        lsn.c:1453 */
#define   ELSN316      (ERRLSN +  316)    /*        lsn.c:1456 */
#define   ELSN317      (ERRLSN +  317)    /*        lsn.c:1461 */
#define   ELSN318      (ERRLSN +  318)    /*        lsn.c:1504 */
#define   ELSN319      (ERRLSN +  319)    /*        lsn.c:1506 */
#define   ELSN320      (ERRLSN +  320)    /*        lsn.c:1508 */
#define   ELSN321      (ERRLSN +  321)    /*        lsn.c:1509 */
#define   ELSN322      (ERRLSN +  322)    /*        lsn.c:1513 */
#define   ELSN323      (ERRLSN +  323)    /*        lsn.c:1515 */
#define   ELSN324      (ERRLSN +  324)    /*        lsn.c:1516 */
#define   ELSN325      (ERRLSN +  325)    /*        lsn.c:1518 */
#define   ELSN326      (ERRLSN +  326)    /*        lsn.c:1519 */
#define   ELSN327      (ERRLSN +  327)    /*        lsn.c:1520 */
#define   ELSN328      (ERRLSN +  328)    /*        lsn.c:1521 */
#define   ELSN329      (ERRLSN +  329)    /*        lsn.c:1524 */
#define   ELSN330      (ERRLSN +  330)    /*        lsn.c:1525 */
#define   ELSN331      (ERRLSN +  331)    /*        lsn.c:1526 */
#define   ELSN332      (ERRLSN +  332)    /*        lsn.c:1527 */
#define   ELSN333      (ERRLSN +  333)    /*        lsn.c:1528 */
#define   ELSN334      (ERRLSN +  334)    /*        lsn.c:1529 */
#define   ELSN335      (ERRLSN +  335)    /*        lsn.c:1530 */
#define   ELSN336      (ERRLSN +  336)    /*        lsn.c:1531 */
#define   ELSN337      (ERRLSN +  337)    /*        lsn.c:1532 */
#define   ELSN338      (ERRLSN +  338)    /*        lsn.c:1533 */
#define   ELSN339      (ERRLSN +  339)    /*        lsn.c:1534 */
#define   ELSN340      (ERRLSN +  340)    /*        lsn.c:1535 */
#define   ELSN341      (ERRLSN +  341)    /*        lsn.c:1536 */
#define   ELSN342      (ERRLSN +  342)    /*        lsn.c:1537 */
#define   ELSN343      (ERRLSN +  343)    /*        lsn.c:1538 */
#define   ELSN344      (ERRLSN +  344)    /*        lsn.c:1539 */
#define   ELSN345      (ERRLSN +  345)    /*        lsn.c:1540 */
#define   ELSN346      (ERRLSN +  346)    /*        lsn.c:1541 */
#define   ELSN347      (ERRLSN +  347)    /*        lsn.c:1542 */
#define   ELSN348      (ERRLSN +  348)    /*        lsn.c:1543 */
#define   ELSN349      (ERRLSN +  349)    /*        lsn.c:1544 */
#define   ELSN350      (ERRLSN +  350)    /*        lsn.c:1545 */
#define   ELSN351      (ERRLSN +  351)    /*        lsn.c:1546 */
#define   ELSN352      (ERRLSN +  352)    /*        lsn.c:1547 */
#define   ELSN353      (ERRLSN +  353)    /*        lsn.c:1548 */
#define   ELSN354      (ERRLSN +  354)    /*        lsn.c:1549 */
#define   ELSN355      (ERRLSN +  355)    /*        lsn.c:1550 */
#define   ELSN356      (ERRLSN +  356)    /*        lsn.c:1551 */
#define   ELSN357      (ERRLSN +  357)    /*        lsn.c:1552 */
#define   ELSN358      (ERRLSN +  358)    /*        lsn.c:1553 */
#define   ELSN359      (ERRLSN +  359)    /*        lsn.c:1554 */
#define   ELSN360      (ERRLSN +  360)    /*        lsn.c:1555 */
#define   ELSN361      (ERRLSN +  361)    /*        lsn.c:1556 */
#define   ELSN362      (ERRLSN +  362)    /*        lsn.c:1557 */
#define   ELSN363      (ERRLSN +  363)    /*        lsn.c:1558 */
#define   ELSN364      (ERRLSN +  364)    /*        lsn.c:1559 */
#define   ELSN365      (ERRLSN +  365)    /*        lsn.c:1560 */
#define   ELSN366      (ERRLSN +  366)    /*        lsn.c:1561 */
#define   ELSN367      (ERRLSN +  367)    /*        lsn.c:1562 */
#define   ELSN368      (ERRLSN +  368)    /*        lsn.c:1563 */
#define   ELSN369      (ERRLSN +  369)    /*        lsn.c:1564 */
#define   ELSN370      (ERRLSN +  370)    /*        lsn.c:1565 */
#define   ELSN371      (ERRLSN +  371)    /*        lsn.c:1566 */
#define   ELSN372      (ERRLSN +  372)    /*        lsn.c:1567 */
#define   ELSN373      (ERRLSN +  373)    /*        lsn.c:1568 */
#define   ELSN374      (ERRLSN +  374)    /*        lsn.c:1569 */
#define   ELSN375      (ERRLSN +  375)    /*        lsn.c:1570 */
#define   ELSN376      (ERRLSN +  376)    /*        lsn.c:1571 */
#define   ELSN377      (ERRLSN +  377)    /*        lsn.c:1572 */
#define   ELSN378      (ERRLSN +  378)    /*        lsn.c:1573 */
#define   ELSN379      (ERRLSN +  379)    /*        lsn.c:1577 */
#define   ELSN380      (ERRLSN +  380)    /*        lsn.c:1579 */
#define   ELSN381      (ERRLSN +  381)    /*        lsn.c:1580 */
#define   ELSN382      (ERRLSN +  382)    /*        lsn.c:1581 */
#define   ELSN383      (ERRLSN +  383)    /*        lsn.c:1582 */
#define   ELSN384      (ERRLSN +  384)    /*        lsn.c:1583 */
#define   ELSN385      (ERRLSN +  385)    /*        lsn.c:1584 */
#define   ELSN386      (ERRLSN +  386)    /*        lsn.c:1585 */
#define   ELSN387      (ERRLSN +  387)    /*        lsn.c:1586 */
#define   ELSN388      (ERRLSN +  388)    /*        lsn.c:1587 */
#define   ELSN389      (ERRLSN +  389)    /*        lsn.c:1588 */
#define   ELSN390      (ERRLSN +  390)    /*        lsn.c:1589 */
#define   ELSN391      (ERRLSN +  391)    /*        lsn.c:1590 */
#define   ELSN392      (ERRLSN +  392)    /*        lsn.c:1591 */
#define   ELSN393      (ERRLSN +  393)    /*        lsn.c:1592 */
#define   ELSN394      (ERRLSN +  394)    /*        lsn.c:1593 */
#define   ELSN395      (ERRLSN +  395)    /*        lsn.c:1594 */
#define   ELSN396      (ERRLSN +  396)    /*        lsn.c:1595 */
#define   ELSN397      (ERRLSN +  397)    /*        lsn.c:1596 */
#define   ELSN398      (ERRLSN +  398)    /*        lsn.c:1599 */
#define   ELSN399      (ERRLSN +  399)    /*        lsn.c:1600 */
#define   ELSN400      (ERRLSN +  400)    /*        lsn.c:1601 */
#define   ELSN401      (ERRLSN +  401)    /*        lsn.c:1606 */
#define   ELSN402      (ERRLSN +  402)    /*        lsn.c:1607 */
#define   ELSN403      (ERRLSN +  403)    /*        lsn.c:1608 */
#define   ELSN404      (ERRLSN +  404)    /*        lsn.c:1609 */
#define   ELSN405      (ERRLSN +  405)    /*        lsn.c:1610 */
#define   ELSN406      (ERRLSN +  406)    /*        lsn.c:1650 */
#define   ELSN407      (ERRLSN +  407)    /*        lsn.c:1653 */
#define   ELSN408      (ERRLSN +  408)    /*        lsn.c:1656 */
#define   ELSN409      (ERRLSN +  409)    /*        lsn.c:1659 */
#define   ELSN410      (ERRLSN +  410)    /*        lsn.c:1662 */
#define   ELSN411      (ERRLSN +  411)    /*        lsn.c:1664 */
#define   ELSN412      (ERRLSN +  412)    /*        lsn.c:1707 */
#define   ELSN413      (ERRLSN +  413)    /*        lsn.c:1708 */
#define   ELSN414      (ERRLSN +  414)    /*        lsn.c:1711 */
#define   ELSN415      (ERRLSN +  415)    /*        lsn.c:1713 */
#define   ELSN416      (ERRLSN +  416)    /*        lsn.c:1756 */
#define   ELSN417      (ERRLSN +  417)    /*        lsn.c:1759 */
#define   ELSN418      (ERRLSN +  418)    /*        lsn.c:1803 */
#define   ELSN419      (ERRLSN +  419)    /*        lsn.c:1806 */


#define LSNLOGERROR(errCls, errCode, errVal, errDesc) \
        SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, __LINE__, \
                  errCls, errCode, errVal, errDesc)
 
#endif /* __LSNH_ */
 

/********************************************************************30**
  
         End of file:     lsn.h@@/main/16 - Mon Apr  9 13:48:21 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  mc    1. initial release

1.2          ---  mc    1. removed EVTLSNTRCIND define.
             ---  mc    2. moved ssf defines from sn.h to lsn.h.

1.3          ---  mc    1. add LNK_BICI define.

1.4          ---  mc    1. add LNK_SINGAPORE define.

1.5          ---  mc    1. add Lsn alarm defines.

1.6          ---  mc    1. add LSN_SW_XXX defines for link, switch types.

1.7          ---  mc    1. replaced LSN_SW_CCITT with LSN_SW_ITU.

1.8          ---  mc    1. replaced LSN_SW_ANSI with LSN_SW_ANS.

1.9          ---  mc    1. added events for LsnTrcInd.
             ---  mc    2. added EVTLSNTRCIND define.
             ---  mc    3. added more events for LsnStaInd.

1.10         ---  pm    1. moved subservice field values (SSF_*) to
                           cm_ss7.h
             ---  pm    2. removed LSN_SW_SINGAPORE and LNK_SINGAPORE.
             ---  pm    3. added UP_DEFAULT.

**********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.11         ---      pm   1. addd LSN_SW_ANS96 define.
             ---      pm   2. added LSN_MTP2_56KBPS, LSN_MTP2_1536KBPS 
                              and LSN_QSAAL defines.
             ---      pm   3. added LSN_INV_SLC_OTHER_END  and LSN_LSNCNTRLREQ_OK
                              defines.
             ---      pm   4. moved link state defines from sn.h
             ---      pm   5. renamed SN_SET_* to LSN_SET* as these are used
                              at layer managament interface.
             ---      pm   6. renamed SN_RTE_* to LSN_RTE* as these are used
                              at layer managament interface.
             ---      pm   7. renamed TYPE_SP and TYPE_STP as LSN_TYPE_SP
                              and LSN_TYPE_STP respectively.
             ---      pm   8. renamed MAXCMBLNK as LSN_MAXCMBLNK, LNKTSTMAX
                              as LSN_LNKTSTMAX and SN_MGMPRI as LSN_MGMPRI.
1.12         ---      pm   1. added defines for EVTLSNCFGCFM and EVTLSNCNTRLCFM.
                           2. added defines for SN_LMINT3.
                           3. added LSN_INV_SRCENT and LSN_SDT_BND_FAIL events.
                           4. added layer specific reasons.
             ---      sr   5. error codes for common pack/unpack functions
                           6. LSNLOGERROR macro.
             ---      pm   7. added defines for rstReq field of general config.

1.13         ---      sr   1. new link type LSN_SW_TTC added
1.14         ---      sr   1. hash defines added for local/remote 
                              inhibit/uninhibit
             ---      sr   2. hash defines related to NTT
/main/15     ---      pm   1. added LSN_CAUSE_SELF_RST and LSN_CAUSE_ADJ_RST
                              defines.
             ---      sr   1. New hash defines introduced for SRT/SRA.
             ---      vk   1. New alarm event LSN_EVENT_INV_OPC_OTHER_END added.
             ---      nb   1. new events and causes for inhibition alarms
             ---      sr   1. Modified copyright header, dependencies
             /main/16      sn001.301  nbh  1. Added LSN_CAUSE_INVLD_DPC and LSN_EVENT_DATA_DRP
                              for sending alarm when message comes to
                              SP for routing.
             ---      nb   1. New error codes for lsn.c
*********************************************************************91*/

