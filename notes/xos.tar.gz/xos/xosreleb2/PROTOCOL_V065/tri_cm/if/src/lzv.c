/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
     Name:     LZV mgmt packing/unpacking functions
 
     Type:     C source file

     Desc:     This file contains all the incoming primitives.

     File:     lzv.c

     Sid:      lzv.c@@/main/2 - Mon Apr  5 09:48:43 2004

     Prg:      vt

*********************************************************************21*/
/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "cm_tpt.h"        /* common transport defines */
#include "cm_hash.h"       /* common hash */
#include "cm_llist.h"      /* common linked list */
#include "cm_ftha.h"       /* common PSF */
#include "mrs.h"           /* Message router interface */
#include "cm_psfft.h"      /* common PSF */
#ifdef ZV_DFTHA
#include "cmzvdv.h"        /* common betn PSF and LDF */
#include "cmzvdvlb.h"        /* common betn PSF and LDF */
#endif /* ZV_DFTHA */
#include "mrs.h"       /* The common LDF defines */
#include "sht.h"          /* common PSF */
#include "snt.h"          /* common PSF */
#include "lit.h"           /* M3UA layer mgmt interface */
#include "sct.h"           /* SCT interface */
#include "lzv.h"           /* M3UA PSF management */
/* zv001.102 removed inclusion of it.?, zv.?, zv_err.? files
   These files should not be included in layer manager common
   files */

/* header/extern include files (.x) */
#include "gen.x"           /* general */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common ss7 */
#include "cm_tpt.x"        /* common transport defines */
#include "cm_hash.x"       /* common hash */
#include "cm_llist.x"      /* common linked list */
#include "cm5.x"           /* common timer */
#include "cm_lib.x"        /* common library */
#include "cm_ftha.x"       /* common ftha */
#include "mrs.x"           /* Message router interface */
#include "cm_psfft.x"      /* common protocol FTHA */
#ifdef ZV_DFTHA
#include "cmzvdv.x"        /* common betn PSF and LDF */
#include "cmzvdvlb.x"        /* common betn PSF and LDF */
#endif /* ZV_DFTHA */
#include "sht.x"
#include "sct.x"           /* SCT interface */
#include "lit.x"           /* M3UA layer mgmt interface */
#include "snt.x"           /* SNT interface */
#include "lzv.x"           /* mtp3 PSF management */
/* zv001.102 removed inclusion of it.?, zv.?, zv_err.? files
   These files should not be included in layer manager common
   files */

#ifdef LCLZV

/*
*
*    Fun:    cmPkZvGenCfg
*
*    Desc:    pack the structure ZvGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvGenCfg
(
ZvGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvGenCfg(param ,mBuf)
ZvGenCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvGenCfg)

#ifdef ZV_DFTHA
    CMCHKPK(SPkU8, param->priorNonCrit,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->tSync,mBuf);
    CMCHKPK(cmPkCmZvDvRsetGenCfg, &param->rsetGenCfg,mBuf);
#endif
    CMCHKPK(SPkU8, param->distEnv,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->rxHeartbeat,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->txHeartbeat,mBuf);
    CMCHKPK(SPkU8, param->priorCrit,mBuf);
    CMCHKPK(SPkU16, param->maxUpdMsgs,mBuf);
    CMCHKPK(SPkU32, param->maxUpdMsgSize,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->tUpdCompAck,mBuf);
    CMCHKPK(cmPkPst, &param->smPst,mBuf);
    CMCHKPK(cmPkMemoryId, &param->mem,mBuf);
    CMCHKPK(SPkS16, param->timeRes,mBuf);
    return(ROK);
} /*end of function cmPkZvGenCfg*/

/*
*
*    Fun:    cmPkZvCfg
*
*    Desc:    pack the structure ZvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvCfg
(
ZvCfg *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvCfg(param ,elmnt, mBuf)
ZvCfg *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvCfg)

    switch( elmnt )
    {
       case  STZVGEN :
          CMCHKPK(cmPkZvGenCfg, &param->s.genCfg,mBuf);
          break;
       case  STZVRSET :
#ifdef ZV_DFTHA
          CMCHKPK(cmPkCmZvDvRsetMapCfg, &param->s.rsetMapCfg, mBuf);
#endif
          break;
       default:
          RETVALUE(RFAILED);
    }
    return(ROK);
} /*end of function cmPkZvCfg*/

/*
*
*    Fun:    cmPkZvStatus
*
*    Desc:    pack the structure ZvStatus
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvStatus
(
ZvStatus *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvStatus(param ,mBuf)
ZvStatus *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvStatus)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(cmPkIntfVer, param->peerIntfVer,mBuf);
    CMCHKPK(cmPkIntfVer, param->selfIntfVer,mBuf);
#endif
    CMCHKPK(SPkU16, param->csSeqNum,mBuf);
    CMCHKPK(SPkU16, param->wsSeqNum,mBuf);
    CMCHKPK(SPkU16, param->rtSeqNum,mBuf);
    CMCHKPK(SPkU8, param->peerState,mBuf);
    CMCHKPK(SPkU8, param->updState,mBuf);
    CMCHKPK(SPkU8, param->state,mBuf);
    return(ROK);
} /*end of function cmPkZvStatus*/

/*
*
*    Fun:    cmPkZvSta
*
*    Desc:    pack the structure ZvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvSta
(
ZvSta *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvSta(param ,elmnt, mBuf)
ZvSta *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvSta)

    switch( elmnt )
    {
       case  STZVSID :
          CMCHKPK(cmPkSystemId, &param->cfm.s.sysId,mBuf);
          break;
       case  STZVGEN :
          CMCHKPK(cmPkZvStatus, &param->cfm.s.status,mBuf);
          break;
#ifdef ZV_DFTHA
       case  STZVRSET :
          CMCHKPK(cmPkZvStatus, &param->cfm.s.status,mBuf);
          break;
#endif
       case STZVGENCFG:
          CMCHKPK(SPkU8, param->cfm.s.genCfgDone,mBuf);
          break;
     
       default:
          break;
    }
    CMCHKPK(cmPkDateTime, &param->cfm.dt,mBuf);
#ifdef ZV_DFTHA
    /* zv001.102 removed the check for distenv field in zvCb.
       we cannot access zvCb as this is an inter psf structure
       and this file may be used with where there is no
       M3UA PSF code to resolve the datastructure. */
    CMCHKPK(SPkU16, param->rsetId, mBuf);
#endif
    return(ROK);
} /*end of function cmPkZvSta*/

/*
*
*    Fun:    cmPkZvStatistics
*
*    Desc:    pack the structure ZvStatistics
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvStatistics
(
ZvStatistics *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvStatistics(param ,mBuf)
ZvStatistics *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvStatistics)

#ifdef ZV_DFTHA              
    CMCHKPK(cmPkStsCntr, param->txRev,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxRev,mBuf);
    CMCHKPK(cmPkStsCntr, param->txSyncMsgs,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxSyncMsgs,mBuf);
#endif /* ZV_DFTHA */        
    CMCHKPK(cmPkStsCntr, param->txHtBt,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxHtBt,mBuf);
    CMCHKPK(cmPkStsCntr, param->txCS,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxCS,mBuf);
    CMCHKPK(cmPkStsCntr, param->txWS,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxWS,mBuf);
    CMCHKPK(cmPkStsCntr, param->txRT,mBuf);
    CMCHKPK(cmPkStsCntr, param->rxRT,mBuf);
    return(ROK);
} /*end of function cmPkZvStatistics*/

/*
*
*    Fun:    cmPkZvSts
*
*    Desc:    pack the structure ZvSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvSts
(
ZvSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvSts(param ,mBuf)
ZvSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvSts)

    CMCHKPK(cmPkZvStatistics, &param->cfm.sts,mBuf);
    CMCHKPK(cmPkDateTime, &param->cfm.dt,mBuf);
#ifdef ZV_DFTHA
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif
    return(ROK);
} /*end of function cmPkZvSts*/

/*
*
*    Fun:    cmPkZvDbgCntrl
*
*    Desc:    pack the structure ZvDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvDbgCntrl
(
ZvDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvDbgCntrl(param ,mBuf)
ZvDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvDbgCntrl)

    CMCHKPK(SPkU32, param->mask,mBuf);
    return(ROK);
} /*end of function cmPkZvDbgCntrl*/

/*
*
*    Fun:    cmPkZvTrcCntrl
*
*    Desc:    pack the structure ZvTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvTrcCntrl
(
ZvTrcCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvTrcCntrl(param ,mBuf)
ZvTrcCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvTrcCntrl)

    CMCHKPK(SPkU16, param->rsetId,mBuf);
    return(ROK);
} /*end of function cmPkZvTrcCntrl*/

#ifdef ZV_DFTHA
/*
*
*    Fun:    cmPkZvCntrlElmnt
*
*    Desc:    pack the structure ZvCntrlElmnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvCntrlElmnt
(
ZvCntrlElmnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvCntrlElmnt(param ,mBuf)
ZvCntrlElmnt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvCntrlElmnt)
    switch(param->elmntType)
    {
       case LZV_ELMNT_DPC:
       case LZV_ELMNT_OPC:
           CMCHKPK(cmPkDpc, param->u.dpc, mBuf);
           break;
       case LZV_ELMNT_NWK:
           CMCHKPK(SPkU8,  param->u.nwkId, mBuf);
           break;
       case LZV_ELMNT_SSF:
           CMCHKPK(SPkU8,  param->u.ssf, mBuf);
           break;
       case LZV_ELMNT_SI:
           CMCHKPK(SPkU8,  param->u.si, mBuf);
           break;
       default:
           break;
    }   
    CMCHKPK(SPkU8,  param->elmntType, mBuf);

    return(ROK);
} /*end of function cmPkZvCntrlElmnt*/
#endif /*ZV_DFTHA*/
/*
*
*    Fun:    cmPkZvCntrl
*
*    Desc:    pack the structure ZvCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvCntrl
(
ZvCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvCntrl(param ,mBuf)
ZvCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvCntrl)

    switch( param->subAction )
    {
       case  LZV_SADBG :
          CMCHKPK(cmPkZvDbgCntrl, &param->t.dbg,mBuf);
          break;
       case  LZV_SATRC :
          CMCHKPK(cmPkZvTrcCntrl, &param->t.trc,mBuf);
          break;
       case  LZV_SAUSTA :
          break;
       case LZV_SAELMNT:
#ifdef ZV_DFTHA
          CMCHKPK(cmPkZvCntrlElmnt, &param->t.elmnt, mBuf);
#endif
          break;
       default:
         break; 
       }
       CMCHKPK(SPkU8, param->subAction,mBuf);
       CMCHKPK(SPkU8, param->action,mBuf);
    return(ROK);
} /*end of function cmPkZvCntrl*/

/*
*
*    Fun:    cmPkZvRsetPar
*
*    Desc:    pack the structure ZvRsetPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvRsetPar
(
ZvRsetPar *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvRsetPar(param ,action, mBuf)
ZvRsetPar *param;
U8 action;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvRsetPar)

    switch( action )
    {
       case  LZV_AGO_ACT :
          CMCHKPK(cmPkFthaGoActPar, &param->t.ga,mBuf);
          break;
       case  LZV_AGO_SBY :
          CMCHKPK(cmPkFthaGoSbyPar, &param->t.gs,mBuf);
          break;
       case  LZV_ASTAT :
#ifdef ZV_DFTHA
          CMCHKPK(cmPkFthaStaPar, &param->t.sp,mBuf);
#endif
          break;
       default:
          break;
    }
    CMCHKPK(SPkU16, param->rsetId,mBuf);
    return(ROK);
} /*end of function cmPkZvRsetPar*/

/*
*
*    Fun:    cmPkZvAbortPar
*
*    Desc:    pack the structure ZvAbortPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvAbortPar
(
ZvAbortPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvAbortPar(param ,mBuf)
ZvAbortPar *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvAbortPar)

    CMCHKPK(cmPkTranId, param->transId,mBuf);
    return(ROK);
} /*end of function cmPkZvAbortPar*/

/*
*
*    Fun:    cmPkZvRsetOp
*
*    Desc:    pack the structure ZvRsetOp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvRsetOp
(
ZvRsetOp *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvRsetOp(param ,action, mBuf)
ZvRsetOp *param;
U8 action;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkZvRsetOp)

    for (i = (param->numRset) - 1; i >= 0; i--)
    {
       ret1 = cmPkZvRsetPar(&param->rsetPar[i], action , mBuf);
       if (ret1 == RFAILED)
       {
          RETVALUE(RFAILED);
       }    
    }
    CMCHKPK(SPkU16, param->numRset,mBuf);
    return(ROK);
} /*end of function cmPkZvRsetOp*/

/*
*
*    Fun:    cmPkZvShCntrl
*
*    Desc:    pack the structure ZvShCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvShCntrl
(
ZvShCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvShCntrl(param ,mBuf)
ZvShCntrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkZvShCntrl)

    switch( param->action )
    {
       case  LZV_AABORT :
          CMCHKPK(cmPkZvAbortPar, &param->t.abort,mBuf);
          break;
       default:
          ret1 = cmPkZvRsetOp(&param->t.rsetOp, param->action , mBuf);
          if (ret1 == RFAILED)
          {
             RETVALUE(RFAILED);
          }
          break;
    }
    CMCHKPK(SPkU8, param->subAction,mBuf);
    CMCHKPK(SPkU8, param->action,mBuf);
    return(ROK);
} /*end of function cmPkZvShCntrl*/

/*
*
*    Fun:    cmPkZvUsta
*
*    Desc:    pack the structure ZvUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvUsta
(
ZvUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvUsta(param ,mBuf)
ZvUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvUsta)

#ifdef ZV_DFTHA
    CMCHKPK(SPkU16, param->rsetId, mBuf);
#endif
    CMCHKPK(cmPkCmAlarm, &param->alarm, mBuf);
    return(ROK);
} /*end of function cmPkZvUsta*/

/*
*
*    Fun:    cmPkZvTrc
*
*    Desc:    pack the structure ZvTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvTrc
(
ZvTrc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvTrc(param ,mBuf)
ZvTrc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkZvTrc)

    CMCHKPK(SPkU8, param->dir,mBuf);
#ifdef ZV_DFTHA
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    return(ROK);
} /*end of function cmPkZvTrc*/

/*
*
*    Fun:    cmPkZvMngmt
*
*    Desc:    pack the structure ZvMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkZvMngmt
(
ZvMngmt *param,
S16 eventType,
Ent entity,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkZvMngmt(param ,eventType, entity, mBuf)
ZvMngmt *param;
S16 eventType;
Ent entity;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkZvMngmt)

    switch( eventType )
    {
       case  EVTZVMILZVCFGREQ :
          ret1 = cmPkZvCfg(&param->t.cfg, param->hdr.elmId.elmnt , mBuf);
          if (ret1 == RFAILED)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTZVMILZVCNTRLREQ :
          if( entity == ENTSH )
          {
             CMCHKPK(cmPkZvShCntrl, &param->t.shCntrl,mBuf);
          }
          else if( entity == ENTSM )
          {
             CMCHKPK(cmPkZvCntrl, &param->t.cntrl,mBuf);
          }
          break;
       case  EVTZVMILZVSTAIND :
          CMCHKPK(cmPkZvUsta, &param->t.usta,mBuf);
          break;
#ifdef ZV_DFTHA
       case  EVTZVMILZVSTAREQ :
          if (param->hdr.elmId.elmnt == STZVRSET)
          {
             CMCHKPK(SPkU16, param->t.sta.rsetId, mBuf);
          }
          break;

       case  EVTZVMILZVSTSREQ :
          if (param->hdr.elmId.elmnt == STZVRSET)
          {
             CMCHKPK(SPkU16, param->t.sts.rsetId, mBuf);
          }
          break;
#endif
       case  EVTZVMILZVSTACFM :
          /* Pack Status Field only if status is available */
          if (param->cfm.status == LCM_PRIM_OK)
          {
             ret1 = cmPkZvSta(&param->t.sta, param->hdr.elmId.elmnt , mBuf);
             if (ret1 == RFAILED)
             {
                RETVALUE(RFAILED);
             }
          }
          break;
       case  EVTZVMILZVSTSCFM :
          /* Pack only if there are really some statistics to be sent */
          if (param->cfm.status == LCM_PRIM_OK)
          {
             CMCHKPK(cmPkZvSts, &param->t.sts,mBuf);
          }
          break;
       case  EVTZVMILZVTRCIND :
          CMCHKPK(cmPkZvTrc, &param->t.trc,mBuf);
          break;
       case EVTZVMILZVCNTRLCFM:
#ifdef ZV_DFTHA
          if (param->cfm.status == LCM_PRIM_OK)
          {
             if ((entity == ENTSH) && (param->t.shCntrl.action == LZV_ASTAT))
             {
                CMCHKPK(cmPkZvShCntrl, &param->t.shCntrl,mBuf);
             }
             
             CMCHKPK(SPkU8, param->t.shCntrl.action, mBuf);
          }
#endif
          break;
       default:
          break;
    }
    /* Code for packing of confirm structure */
    if((eventType != EVTZVMILZVSTAIND) && (eventType != EVTZVMILZVTRCIND) && 
       (eventType != EVTZVMILZVCFGREQ) && (eventType != EVTZVMILZVSTAREQ) && 
       (eventType != EVTZVMILZVSTSREQ) && (eventType != EVTZVMILZVCNTRLREQ))
    {
       CMCHKPK(cmPkCmStatus, &param->cfm,mBuf);
    }

    CMCHKPK(cmPkHeader, &param->hdr,mBuf);

    return(ROK);
} /*end of function cmPkZvMngmt*/

/*
*
*    Fun:    cmPkLzvCfgReq
*
*    Desc:    pack the primitive LzvCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvCfgReq
(
Pst *pst,
ZvMngmt *cfg
)
#else
PUBLIC S16 cmPkLzvCfgReq(pst, cfg)
Pst *pst;
ZvMngmt *cfg;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvCfgReq)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       {
          RETVALUE(ret1);
       }
    }
    ret1 = cmPkZvMngmt(cfg, EVTZVMILZVCFGREQ , pst->srcEnt , mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVCFGREQ;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) LZVIFVER;
#endif

    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvCfgReq*/

/*
*
*    Fun:    cmPkLzvCfgCfm
*
*    Desc:    pack the primitive LzvCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvCfgCfm
(
Pst *pst,
ZvMngmt *cfm
)
#else
PUBLIC S16 cmPkLzvCfgCfm(pst, cfm)
Pst *pst;
ZvMngmt *cfm;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvCfgCfm)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(cfm, EVTZVMILZVCFGCFM , pst->dstEnt, mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVCFGCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvCfgCfm*/

/*
*
*    Fun:    cmPkLzvStaReq
*
*    Desc:    pack the primitive LzvStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvStaReq
(
Pst *pst,
ZvMngmt *sta
)
#else
PUBLIC S16 cmPkLzvStaReq(pst, sta)
Pst *pst;
ZvMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvStaReq)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(sta, EVTZVMILZVSTAREQ , pst->srcEnt , mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVSTAREQ;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) LZVIFVER;
#endif

    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvStaReq*/

/*
*
*    Fun:    cmPkLzvStaCfm
*
*    Desc:    pack the primitive LzvStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvStaCfm
(
Pst *pst,
ZvMngmt *sta
)
#else
PUBLIC S16 cmPkLzvStaCfm(pst, sta)
Pst *pst;
ZvMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvStaCfm)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(sta, EVTZVMILZVSTACFM , pst->dstEnt, mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVSTACFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvStaCfm*/

/*
*
*    Fun:    cmPkLzvCntrlReq
*
*    Desc:    pack the primitive LzvCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvCntrlReq
(
Pst *pst,
ZvMngmt *cntrl
)
#else
PUBLIC S16 cmPkLzvCntrlReq(pst, cntrl)
Pst *pst;
ZvMngmt *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvCntrlReq)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(cntrl, EVTZVMILZVCNTRLREQ , pst->srcEnt , mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVCNTRLREQ;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) LZVIFVER;
#endif

    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvCntrlReq*/

/*
*
*    Fun:    cmPkLzvCntrlCfm
*
*    Desc:    pack the primitive LzvCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvCntrlCfm
(
Pst *pst,
ZvMngmt *cfm
)
#else
PUBLIC S16 cmPkLzvCntrlCfm(pst, cfm)
Pst *pst;
ZvMngmt *cfm;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvCntrlCfm)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(cfm, EVTZVMILZVCNTRLCFM , pst->dstEnt, mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVCNTRLCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvCntrlCfm*/

/*
*
*    Fun:    cmPkLzvStsReq
*
*    Desc:    pack the primitive LzvStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvStsReq
(
Pst *pst,
Action action,
ZvMngmt *sts
)
#else
PUBLIC S16 cmPkLzvStsReq(pst, action, sts)
Pst *pst;
Action action;
ZvMngmt *sts;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvStsReq)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(sts, EVTZVMILZVSTSREQ , pst->srcEnt , mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    CMCHKPKLOG(SPkS16, action, mBuf, ELZV001, pst);
    pst->event = (Event)  EVTZVMILZVSTSREQ;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) LZVIFVER;
#endif

    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvStsReq*/

/*
*
*    Fun:    cmPkLzvStsCfm
*
*    Desc:    pack the primitive LzvStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvStsCfm
(
Pst *pst,
ZvMngmt *cfm
)
#else
PUBLIC S16 cmPkLzvStsCfm(pst, cfm)
Pst *pst;
ZvMngmt *cfm;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvStsCfm)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(cfm, EVTZVMILZVSTSCFM , pst->dstEnt, mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVSTSCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvStsCfm*/

/*
*
*    Fun:    cmPkLzvStaInd
*
*    Desc:    pack the primitive LzvStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvStaInd
(
Pst *pst,
ZvMngmt *usta
)
#else
PUBLIC S16 cmPkLzvStaInd(pst, usta)
Pst *pst;
ZvMngmt *usta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLzvStaInd)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       RETVALUE(ret1);
    }
    ret1 = cmPkZvMngmt(usta, EVTZVMILZVSTAIND , pst->dstEnt, mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVSTAIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLzvStaInd*/

/*
*
*    Fun:    cmPkLzvTrcInd
*
*    Desc:    pack the primitive LzvTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLzvTrcInd
(
Pst *pst,
ZvMngmt *trc
)
#else
PUBLIC S16 cmPkLzvTrcInd(pst, trc)
Pst *pst;
ZvMngmt *trc;
#endif
{
    S16 ret1;

    TRC3(cmPkLzvTrcInd)
    
    ret1 = cmPkZvMngmt(trc, EVTZVMILZVTRCIND , pst->dstEnt, trc->t.trc.mBuf);
    if (ret1 == RFAILED)
    {
       SPutMsg(trc->t.trc.mBuf);
       RETVALUE(RFAILED);
    }
    pst->event = (Event)  EVTZVMILZVTRCIND;
    RETVALUE(SPstTsk(pst,trc->t.trc.mBuf));
} /*end of function cmPkLzvTrcInd*/

/*
*
*    Fun:    cmUnpkZvGenCfg
*
*    Desc:    unpack the structure zvGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvGenCfg
(
ZvGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvGenCfg(param ,mBuf)
ZvGenCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvGenCfg)

    CMCHKUNPK(SUnpkS16, &param->timeRes,mBuf);
    CMCHKUNPK(cmUnpkMemoryId, &param->mem,mBuf);
    CMCHKUNPK(cmUnpkPst, &param->smPst,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->tUpdCompAck,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxUpdMsgSize,mBuf);
    CMCHKUNPK(SUnpkU16, &param->maxUpdMsgs,mBuf);
    CMCHKUNPK(SUnpkU8, &param->priorCrit,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->txHeartbeat,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->rxHeartbeat,mBuf);
    CMCHKUNPK(SUnpkU8, &param->distEnv,mBuf);
#ifdef ZV_DFTHA
    CMCHKUNPK(cmUnpkCmZvDvRsetGenCfg, &param->rsetGenCfg,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->tSync,mBuf);
    CMCHKUNPK(SUnpkU8, &param->priorNonCrit,mBuf);
#endif
    return(ROK);
} /*end of function cmUnpkZvGenCfg*/

/*
*
*    Fun:    cmUnpkZvCfg
*
*    Desc:    unpack the structure ZvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvCfg
(
ZvCfg *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvCfg(param ,elmnt, mBuf)
ZvCfg *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvCfg)

    switch( elmnt )
    {
       case  STZVGEN :
          CMCHKUNPK(cmUnpkZvGenCfg, &param->s.genCfg,mBuf);
          break;
       case  STZVRSET :
#ifdef ZV_DFTHA
          CMCHKUNPK(cmUnpkCmZvDvRsetMapCfg, &param->s.rsetMapCfg,mBuf);
#endif
          break;
       default:
          RETVALUE(RFAILED);
    }
    return(ROK);
} /*end of function cmUnpkZvCfg*/

/*
*
*    Fun:    cmUnpkZvStatus
*
*    Desc:    unpack the structure zvStatus
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvStatus
(
ZvStatus *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvStatus(param ,mBuf)
ZvStatus *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvStatus)

    CMCHKUNPK(SUnpkU8, &param->state,mBuf);
    CMCHKUNPK(SUnpkU8, &param->updState,mBuf);
    CMCHKUNPK(SUnpkU8, &param->peerState,mBuf);
    CMCHKUNPK(SUnpkU16, &param->rtSeqNum,mBuf);
    CMCHKUNPK(SUnpkU16, &param->wsSeqNum,mBuf);
    CMCHKUNPK(SUnpkU16, &param->csSeqNum,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(cmUnpkIntfVer, &param->selfIntfVer,mBuf);
    CMCHKUNPK(cmUnpkIntfVer, &param->peerIntfVer,mBuf);
#endif
    return(ROK);
} /*end of function cmUnpkZvStatus*/

/*
*
*    Fun:    cmUnpkZvSta
*
*    Desc:    unpack the structure ZvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvSta
(
ZvSta *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvSta(param ,elmnt, mBuf)
ZvSta *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvSta)

#ifdef ZV_DFTHA
    /* zv001.102 removed the check for distenv field in zvCb.
       we cannot access zvCb as this is an inter psf structure
       and this file may be used with where there is no
       M3UA PSF code to resolve the datastructure. */
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif
    CMCHKUNPK(cmUnpkDateTime, &param->cfm.dt,mBuf);
    switch( elmnt )
    {
       case  STZVSID :
          CMCHKUNPK(cmUnpkSystemId, &param->cfm.s.sysId,mBuf);
          break;
       case  STZVGEN :
          CMCHKUNPK(cmUnpkZvStatus, &param->cfm.s.status,mBuf);
          break;
       case  STZVRSET :
          CMCHKUNPK(cmUnpkZvStatus, &param->cfm.s.status,mBuf);
          break;
       case STZVGENCFG:
          CMCHKUNPK(SUnpkU8, &param->cfm.s.genCfgDone,mBuf);
          break;
       default:
          break;
    }
    return(ROK);
} /*end of function cmUnpkZvSta*/

/*
*
*    Fun:    cmUnpkZvStatistics
*
*    Desc:    unpack the structure zvStatistics
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvStatistics
(
ZvStatistics *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvStatistics(param ,mBuf)
ZvStatistics *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvStatistics)

    CMCHKUNPK(cmUnpkStsCntr, &param->rxRT,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txRT,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->rxWS,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txWS,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->rxCS,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txCS,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->rxHtBt,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txHtBt,mBuf);
#ifdef ZV_DFTHA              
    CMCHKUNPK(cmUnpkStsCntr, &param->rxSyncMsgs,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txSyncMsgs,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->rxRev,mBuf);
    CMCHKUNPK(cmUnpkStsCntr, &param->txRev,mBuf);
#endif /* ZV_DFTHA */        
    return(ROK);
} /*end of function cmUnpkZvStatistics*/

/*
*
*    Fun:    cmUnpkZvSts
*
*    Desc:    unpack the structure zvSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvSts
(
ZvSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvSts(param ,mBuf)
ZvSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvSts)

#ifdef ZV_DFTHA
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif
    CMCHKUNPK(cmUnpkDateTime, &param->cfm.dt,mBuf);
    CMCHKUNPK(cmUnpkZvStatistics, &param->cfm.sts,mBuf);
    return(ROK);
} /*end of function cmUnpkZvSts*/

/*
*
*    Fun:    cmUnpkZvDbgCntrl
*
*    Desc:    unpack the structure zvDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvDbgCntrl
(
ZvDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvDbgCntrl(param ,mBuf)
ZvDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvDbgCntrl)

    CMCHKUNPK(SUnpkU32, &param->mask,mBuf);
    return(ROK);
} /*end of function cmUnpkZvDbgCntrl*/
#ifdef ZV_DFTHA

/*
*
*    Fun:    cmUnpkZvTrcCntrl
*
*    Desc:    unpack the structure zvTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvTrcCntrl
(
ZvTrcCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvTrcCntrl(param ,mBuf)
ZvTrcCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvTrcCntrl)

    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
    return(ROK);
} /*end of function cmUnpkZvTrcCntrl*/
/*
*
*    Fun:    cmUnpkZvCntrlElmnt
*
*    Desc:    unpack the structure zvCntrlElmnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvCntrlElmnt
(
ZvCntrlElmnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvCntrlElmnt(param ,mBuf)
ZvCntrlElmnt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvCntrlElmnt)

    CMCHKUNPK(SUnpkU8,  &param->elmntType, mBuf);
    switch(param->elmntType)
    {
       case LZV_ELMNT_DPC:
       case LZV_ELMNT_OPC:
          CMCHKUNPK(cmUnpkDpc,  &param->u.dpc, mBuf);
          break;
       case LZV_ELMNT_NWK:
          CMCHKUNPK(SUnpkU8,  &param->u.nwkId, mBuf);
          break;
       case LZV_ELMNT_SSF:
          CMCHKUNPK(SUnpkU8,  &param->u.ssf, mBuf);
          break;
       case LZV_ELMNT_SI :
          CMCHKUNPK(SUnpkU8,  &param->u.si, mBuf);
          break;
        default:
          break;
     }
    return(ROK);
} /*end of function cmUnpkZvCntrlElmnt*/
#endif

/*
*
*    Fun:    cmUnpkZvCntrl
*
*    Desc:    unpack the structure zvCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvCntrl
(
ZvCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvCntrl(param ,mBuf)
ZvCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvCntrl)

    CMCHKUNPK(SUnpkU8, &param->action,mBuf);
    CMCHKUNPK(SUnpkU8, &param->subAction,mBuf);
    switch( param->subAction )
    {
       case  LZV_SADBG :
          CMCHKUNPK(cmUnpkZvDbgCntrl, &param->t.dbg,mBuf);
          break;
       case  LZV_SATRC :
#ifdef ZV_DFTHA
          CMCHKUNPK(cmUnpkZvTrcCntrl, &param->t.trc,mBuf);
#endif
          break;
       case  LZV_SAUSTA :
          break;
       case LZV_SAELMNT:
#ifdef ZV_DFTHA
         CMCHKUNPK(cmUnpkZvCntrlElmnt, &param->t.elmnt, mBuf);
#endif
          break;
       default:
          break;
    }
    return(ROK);
} /*end of function cmUnpkZvCntrl*/

/*
*
*    Fun:    cmUnpkZvRsetPar
*
*    Desc:    unpack the structure ZvRsetPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvRsetPar
(
ZvRsetPar *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvRsetPar(param ,action, mBuf)
ZvRsetPar *param;
U8 action;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvRsetPar)

    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
    switch( action )
    {
       case  LZV_AGO_ACT :
          CMCHKUNPK(cmUnpkFthaGoActPar, &param->t.ga,mBuf);
          break;
       case  LZV_AGO_SBY :
          CMCHKUNPK(cmUnpkFthaGoSbyPar, &param->t.gs,mBuf);
          break;
       case  LZV_ASTAT :
#ifdef ZV_DFTHA
          CMCHKUNPK(cmUnpkFthaStaPar, &param->t.sp,mBuf);
#endif
          break;
       default:
          break;
    }
    return(ROK);
} /*end of function cmUnpkZvRsetPar*/

/*
*
*    Fun:    cmUnpkZvAbortPar
*
*    Desc:    unpack the structure zvAbortPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvAbortPar
(
ZvAbortPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvAbortPar(param ,mBuf)
ZvAbortPar *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvAbortPar)

    CMCHKUNPK(cmUnpkTranId, &param->transId,mBuf);
    return(ROK);
} /*end of function cmUnpkZvAbortPar*/

/*
*
*    Fun:    cmUnpkZvRsetOp
*
*    Desc:    unpack the structure ZvRsetOp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvRsetOp
(
ZvRsetOp *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvRsetOp(param ,action, mBuf)
ZvRsetOp *param;
U8 action;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;

    TRC3(cmUnpkZvRsetOp)

    CMCHKUNPK(SUnpkU16, &param->numRset,mBuf);
    for (i = 0; i < (param->numRset); i++)
    {
        ret1 = cmUnpkZvRsetPar(&param->rsetPar[i], action , mBuf);
        if (ret1 == RFAILED)
        {
           RETVALUE(RFAILED);
        }
    }
    return(ROK);
} /*end of function cmUnpkZvRsetOp*/

/*
*
*    Fun:    cmUnpkZvShCntrl
*
*    Desc:    unpack the structure zvShCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvShCntrl
(
ZvShCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvShCntrl(param ,mBuf)
ZvShCntrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkZvShCntrl)

    CMCHKUNPK(SUnpkU8, &param->action,mBuf);
    CMCHKUNPK(SUnpkU8, &param->subAction,mBuf);
    switch( param->action )
    {
       case  LZV_AABORT :
          CMCHKUNPK(cmUnpkZvAbortPar, &param->t.abort,mBuf);
          break;
       default:
          ret1 = cmUnpkZvRsetOp(&param->t.rsetOp, param->action , mBuf);
          if (ret1 == RFAILED)
          {
             RETVALUE(RFAILED);
          }
          break;
    }
    return(ROK);
} /*end of function cmUnpkZvShCntrl*/

/*
*
*    Fun:    cmUnpkZvUsta
*
*    Desc:    unpack the structure zvUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvUsta
(
ZvUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvUsta(param ,mBuf)
ZvUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvUsta)

    CMCHKUNPK(cmUnpkCmAlarm, &param->alarm,mBuf);
#ifdef ZV_DFTHA
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif
    return(ROK);
} /*end of function cmUnpkZvUsta*/

/*
*
*    Fun:    cmUnpkZvTrc
*
*    Desc:    unpack the structure zvTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvTrc
(
ZvTrc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvTrc(param ,mBuf)
ZvTrc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkZvTrc)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
#ifdef ZV_DFTHA
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif
    CMCHKUNPK(SUnpkU8, &param->dir,mBuf);
    return(ROK);
} /*end of function cmUnpkZvTrc*/

/*
*
*    Fun:    cmUnpkZvMngmt
*
*    Desc:    unpack the structure ZvMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkZvMngmt
(
ZvMngmt *param,
S16 eventType,
Ent entity,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkZvMngmt(param ,eventType, entity, mBuf)
ZvMngmt *param;
S16 eventType;
Ent entity;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkZvMngmt)

    CMCHKUNPK(cmUnpkHeader, &param->hdr,mBuf);

    if((eventType != EVTZVMILZVSTAIND) && (eventType != EVTZVMILZVTRCIND) && 
       (eventType != EVTZVMILZVCFGREQ) && (eventType != EVTZVMILZVSTAREQ) && 
       (eventType != EVTZVMILZVSTSREQ) && (eventType != EVTZVMILZVCNTRLREQ))
    {
       CMCHKUNPK(cmUnpkCmStatus, &param->cfm,mBuf);
    }
    switch( eventType )
    {
       case  EVTZVMILZVCFGREQ :
          ret1 = cmUnpkZvCfg(&param->t.cfg, param->hdr.elmId.elmnt , mBuf);
          if (ret1 == RFAILED)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTZVMILZVCNTRLREQ :
          if( entity == ENTSH )
          {
             CMCHKUNPK(cmUnpkZvShCntrl, &param->t.shCntrl,mBuf);
          }
          else if( entity == ENTSM )
          {
             CMCHKUNPK(cmUnpkZvCntrl, &param->t.cntrl,mBuf);
          }
          break;
       case  EVTZVMILZVSTAIND :
          CMCHKUNPK(cmUnpkZvUsta, &param->t.usta,mBuf);
          break;
       case  EVTZVMILZVSTACFM :
          /* No Status is available if confirm is not OK */
          if (param->cfm.status == LCM_PRIM_OK)
          {
             ret1 = cmUnpkZvSta(&param->t.sta, param->hdr.elmId.elmnt , mBuf);
             if (ret1 == RFAILED)
             {
                RETVALUE(RFAILED);
             }
          }
          break;
#ifdef ZV_DFTHA
       case  EVTZVMILZVSTAREQ :
          if (param->hdr.elmId.elmnt == STZVRSET)
          {
             CMCHKUNPK(SUnpkU16, &param->t.sta.rsetId, mBuf);
          }
          break;

       case  EVTZVMILZVSTSREQ :
          if (param->hdr.elmId.elmnt == STZVRSET)
          {
             CMCHKUNPK(SUnpkU16, &param->t.sta.rsetId, mBuf);
          }
          break;
#endif
       case  EVTZVMILZVSTSCFM :
          /* Statics are available only if status is OK */
          if (param->cfm.status == LCM_PRIM_OK)
          {
             CMCHKUNPK(cmUnpkZvSts, &param->t.sts,mBuf);
          }
          break;
       case  EVTZVMILZVTRCIND :
          CMCHKUNPK(cmUnpkZvTrc, &param->t.trc,mBuf);
          break;
       case EVTZVMILZVCNTRLCFM:
#ifdef ZV_DFTHA
          if (param->cfm.status == LCM_PRIM_OK)
          {
             CMCHKUNPK(SUnpkU8, &param->t.shCntrl.action, mBuf);
  
             if ((entity == ENTSH) && (param->t.shCntrl.action == LZV_ASTAT))
             {
                CMCHKUNPK(cmUnpkZvShCntrl, &param->t.shCntrl,mBuf);
             }
          }
#endif
          break;
       default:
          break;
    }
    return(ROK);
} /*end of function cmUnpkZvMngmt*/

/*
*
*    Fun:    cmUnpkLzvCfgReq
*
*    Desc:    unpack the primitive LzvCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvCfgReq
(
LzvCfgReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvCfgReq(func, pst, mBuf)
LzvCfgReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt cfg;
    
    TRC3(cmUnpkLzvCfgReq)

    ret1 = cmUnpkZvMngmt(&cfg, EVTZVMILZVCFGREQ , pst->srcEnt , mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &cfg));
} /*end of function cmUnpkLzvCfgReq*/

/*
*
*    Fun:    cmUnpkLzvCfgCfm
*
*    Desc:    unpack the primitive LzvCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvCfgCfm
(
LzvCfgCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvCfgCfm(func, pst, mBuf)
LzvCfgCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt cfm;
    
    TRC3(cmUnpkLzvCfgCfm)

    ret1 = cmUnpkZvMngmt(&cfm, EVTZVMILZVCFGCFM , pst->dstEnt, mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &cfm));
} /*end of function cmUnpkLzvCfgCfm*/

/*
*
*    Fun:    cmUnpkLzvStaReq
*
*    Desc:    unpack the primitive LzvStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvStaReq
(
LzvStaReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvStaReq(func, pst, mBuf)
LzvStaReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt sta;
    
    TRC3(cmUnpkLzvStaReq)

    /* Initialize the structure , inorder to avoid uninitialized values  */
    cmMemset((U8 *)&sta, 0, sizeof(ZvMngmt));

    ret1 = cmUnpkZvMngmt(&sta, EVTZVMILZVSTAREQ , pst->srcEnt , mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLzvStaReq*/

/*
*
*    Fun:    cmUnpkLzvStaCfm
*
*    Desc:    unpack the primitive LzvStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvStaCfm
(
LzvStaCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvStaCfm(func, pst, mBuf)
LzvStaCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt sta;
    Txt ptNmb[32];         /* part number */
    
    TRC3(cmUnpkLzvStaCfm)

    /* initialize the pointer to part number properly */
    sta.t.sta.cfm.s.sysId.ptNmb = &ptNmb[0];
    ret1 = cmUnpkZvMngmt(&sta, EVTZVMILZVSTACFM , pst->dstEnt, mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLzvStaCfm*/

/*
*
*    Fun:    cmUnpkLzvCntrlReq
*
*    Desc:    unpack the primitive LzvCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvCntrlReq
(
LzvCntrlReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvCntrlReq(func, pst, mBuf)
LzvCntrlReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt cntrl;
    
    TRC3(cmUnpkLzvCntrlReq)

    ret1 = cmUnpkZvMngmt(&cntrl, EVTZVMILZVCNTRLREQ , pst->srcEnt , mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &cntrl));
} /*end of function cmUnpkLzvCntrlReq*/

/*
*
*    Fun:    cmUnpkLzvCntrlCfm
*
*    Desc:    unpack the primitive LzvCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvCntrlCfm
(
LzvCntrlCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvCntrlCfm(func, pst, mBuf)
LzvCntrlCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt cfm;
    
    TRC3(cmUnpkLzvCntrlCfm)

    ret1 = cmUnpkZvMngmt(&cfm, EVTZVMILZVCNTRLCFM , pst->dstEnt, mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &cfm));
} /*end of function cmUnpkLzvCntrlCfm*/

/*
*
*    Fun:    cmUnpkLzvStsReq
*
*    Desc:    unpack the primitive LzvStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvStsReq
(
LzvStsReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvStsReq(func, pst, mBuf)
LzvStsReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Action action;
    ZvMngmt sts;
    
    TRC3(cmUnpkLzvStsReq)

    /* Initialize the structure , inorder to avoid uninitialized values  */
    cmMemset((U8 *)&sts, 0, sizeof(ZvMngmt));

    CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ELZV002, pst);
    ret1 = cmUnpkZvMngmt(&sts, EVTZVMILZVSTSREQ , pst->srcEnt , mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, action, &sts));
} /*end of function cmUnpkLzvStsReq*/

/*
*
*    Fun:    cmUnpkLzvStsCfm
*
*    Desc:    unpack the primitive LzvStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvStsCfm
(
LzvStsCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvStsCfm(func, pst, mBuf)
LzvStsCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt cfm;
    
    TRC3(cmUnpkLzvStsCfm)

    ret1 = cmUnpkZvMngmt(&cfm, EVTZVMILZVSTSCFM , pst->dstEnt, mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &cfm));
} /*end of function cmUnpkLzvStsCfm*/

/*
*
*    Fun:    cmUnpkLzvStaInd
*
*    Desc:    unpack the primitive LzvStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvStaInd
(
LzvStaInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvStaInd(func, pst, mBuf)
LzvStaInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt usta;
    
    TRC3(cmUnpkLzvStaInd)

    ret1 = cmUnpkZvMngmt(&usta, EVTZVMILZVSTAIND , pst->dstEnt, mBuf);
    SPutMsg(mBuf);
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &usta));
} /*end of function cmUnpkLzvStaInd*/

/*
*
*    Fun:    cmUnpkLzvTrcInd
*
*    Desc:    unpack the primitive LzvTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lzv.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLzvTrcInd
(
LzvTrcInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLzvTrcInd(func, pst, mBuf)
LzvTrcInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    ZvMngmt trc;
    
    TRC3(cmUnpkLzvTrcInd)

    ret1 = cmUnpkZvMngmt(&trc, EVTZVMILZVTRCIND , pst->dstEnt, mBuf);
    trc.t.trc.mBuf = mBuf;
    if (ret1 == RFAILED)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE((*func)(pst, &trc));
} /*end of function cmUnpkLzvTrcInd*/
#endif /* LCLZV */
/*  userFunction Section */
/********************************************************************30**
  
         End of file:     lzv.c@@/main/2 - Mon Apr  5 09:48:43 2004
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      vt   1. initial release.
/main/2      ---      vt   2. General Public Release
/main/2   zv001.102   vt   1. removed inclusion of it.?, zv.?,
                              zv_err.? files 
                           2. removed the check for distenv 
                              field in zvCb.
*********************************************************************91*/
