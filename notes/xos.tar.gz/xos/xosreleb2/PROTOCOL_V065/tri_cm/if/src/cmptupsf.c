/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
        Name:     Common TCAP User PSF
    
        Type:     C source file
  
        Desc:     This file consists of all pk/unpk functions.
 
        File:     cmptupsf.c

        Sid:      cmptupsf.c@@/main/2 - Fri Dec 10 17:55:35 2004
  
        Prg:      jz
  
*********************************************************************21*/

/*
 *      This software may be combined with the following TRILLIUM
 *      software:
 *
 *      part no.                      description
 *      --------    ----------------------------------------------
 *      1000032     GSM Mobile Application Part - MAP
 */
 
  

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm5.h"
#include "cm_ss7.h"        /* common ss7 */
#include "cm_err.h"        /* common error */
#include "cm_ftha.h"
#include "mrs.h"
#include "sht.h"
#include "cm_pftha.h"      /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#include "cm_tupsf.h"      /* common PSF */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_ftha.x"
#include "mrs.x"
#include "sht.x"
#include "cm_pftha.x"      /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#include "cm_tupsf.x"      /* common PSF */


/* local defines */

/* local externs */
PRIVATE S16 cmPkCmtuGenCfg ARGS(( CmTuGenCfg *genCfg, Buffer *mBuf ));
PRIVATE S16 cmPkCmtuDbgCntrl ARGS(( CmTuDbgCntrl *pkParam0, Buffer *mBuf));
PRIVATE S16 cmPkCmtuCntrl ARGS(( CmTuCntrl *pkParam0, Buffer *mBuf));
PRIVATE S16 cmPkCmtuRsetPar ARGS(( CmTuRsetPar *pkParam0, Action action, 
                                Buffer *mBuf));
PRIVATE S16 cmPkCmtuAbortPar ARGS(( CmTuAbortPar *pkParam0, Buffer *mBuf));
PRIVATE S16 cmPkCmtuShCntrl ARGS(( CmTuShCntrl *pkParam0, Buffer *mBuf));
PRIVATE S16 cmPkCmtuRsetSta ARGS (( CmTuRsetSta *pkParam0, Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuDbgCntrl ARGS(( CmTuDbgCntrl *unpkParam0, Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuCntrl ARGS(( CmTuCntrl *unpkParam0, Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuRsetPar ARGS(( CmTuRsetPar *unpkParam0, Action action, 
                             Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuAbortPar ARGS(( CmTuAbortPar *unpkParam0, Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuShCntrl ARGS(( CmTuShCntrl *unpkParam0, Buffer *mBuf));
PRIVATE S16 cmUnpkCmtuRsetSta ARGS (( CmTuRsetSta *unpkParam0, Buffer *mBuf));

/*      CONFIGURATION 
*/


/*
 *
 *       Fun:   cmPkCmtuGenCfg
 *
 *       Desc:  This function packs the General Configuration
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuGenCfg
(
CmTuGenCfg *genCfg,                          /* General Configuration */
Buffer     *mBuf                             /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuGenCfg (genCfg, mBuf)
CmTuGenCfg *genCfg;                          /* General Configuration */
Buffer     *mBuf;                            /* message buffer */
#endif
{
   TRC3(cmPkCmtuGenCfg);

   CMCHKPK(SPkU8, genCfg->updAllDlg, mBuf);
   CMCHKPK(SPkU16, genCfg->maxUpdMsgs, mBuf);
   CMCHKPK(SPkU32, genCfg->maxUpdMsgSize, mBuf);
   CMCHKPK(cmPkTmrCfg, &genCfg->tRecovery, mBuf);
   CMCHKPK(cmPkTmrCfg, &genCfg->tUpdCompAck, mBuf);
   CMCHKPK(cmPkPst, &genCfg->smPst, mBuf);
   CMCHKPK(cmPkMemoryId, &genCfg->mem, mBuf);
   CMCHKPK(SPkS16, genCfg->timeRes, mBuf);

   RETVALUE(ROK);
} /* cmPkCmtuGenCfg */


/*
 *
 *      Fun:   cmPkCmTuCfgReq
 *
 *      Desc:  This function packs PSF's configuration request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuCfgReq
(
Pst         *pst,               /* post structure         */
CmTuMngmt   *cfg,               /* management structure   */
CmIntfVer   intfVer             /* layer interface version */
)
#else
PUBLIC S16 cmPkCmTuCfgReq(pst, cfg, intfVer)
Pst         *pst;               /* post structure         */
CmTuMngmt   *cfg;               /* management structure   */
CmIntfVer   intfVer;            /* layer interface version */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkCmTuCfgReq)

   CMTU_GETMSG(pst, &mBuf, ECMTU001);

   switch (cfg->hdr.elmId.elmnt)
   {
      case CMTUGEN:   /* general configuration */
         CMCHKPKLOG(cmPkCmtuGenCfg, &cfg->t.cfg.s.genCfg, mBuf, ECMTU002, pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORPK(ERRCLS_INT_PAR, ECMTU005, (ErrVal)cfg->hdr.elmId.elmnt,
                        "cmPkCmTuCfgReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         if(mBuf != (Buffer *)NULLP)
         {
            SPutMsg(mBuf);
         }
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG (cmPkHeader, &cfg->hdr, mBuf, ECMTU006, pst);

   pst->event = EVTTUMILTUCFGREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = (CmIntfVer) intfVer;
#else
   UNUSED(intfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuCfgReq */


/*
 *
 *      Fun:   cmPkCmTuCfgCfm
 *
 *      Desc:  This function packs PSF's configuration confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuCfgCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkCmTuCfgCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt   *cfm;               /* management structure */
#endif
{
   Buffer *mBuf; /* Message Buffer */

   TRC2(cmPkCmTuCfgCfm)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU007);

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ECMTU008, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ECMTU009, pst);

   pst->event = EVTTUMILTUCFGCFM;

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuCfgCfm */

/*      CONTROL 
*/


/*
 *
 *       Fun:   cmPkCmtuDbgCntrl
 *
 *       Desc:  This function packs the Mod debug mask
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuDbgCntrl
(
CmTuDbgCntrl *pkParam0,                        /* Mod debug mask */
Buffer *mBuf                                 /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuDbgCntrl (pkParam0, mBuf)
CmTuDbgCntrl *pkParam0;                        /* Mod debug mask */
Buffer *mBuf;                                /* message buffer */
#endif
{
   TRC3(cmPkCmtuDbgCntrl);

   CMCHKPK(SPkU32, pkParam0->mask, mBuf);

   RETVALUE(ROK);
} /* cmPkCmtuDbgCntrl */



/*
 *
 *       Fun:   cmPkCmtuCntrl
 *
 *       Desc:  This function packs the Control request from the SM
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuCntrl
(
CmTuCntrl *pkParam0,           /* Control request from the SM */
Buffer    *mBuf                /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuCntrl (pkParam0, mBuf)
CmTuCntrl *pkParam0;           /* Control request from the SM */
Buffer    *mBuf;               /* message buffer */
#endif
{
   TRC3(cmPkCmtuCntrl);

   if ((pkParam0->action == CMTU_ADISIMM) || (pkParam0->action == CMTU_AENA))
   {
      switch (pkParam0->subAction)
      {
         case CMTU_SAUSTA :
            break;
         
         case CMTU_SADBG :         
            CMCHKPK(cmPkCmtuDbgCntrl, &pkParam0->t.dbg, mBuf);
            break;
            
         case CMTU_SATRC:
            break;
            
         default:
            break;
      }
   }

   CMCHKPK(SPkU8, pkParam0->action, mBuf);
   CMCHKPK(SPkU8, pkParam0->subAction, mBuf);

   RETVALUE(ROK);

} /* cmPkCmtuCntrl */


/*
 *
 *       Fun:   cmPkCmtuRsetPar
 *
 *       Desc:  This function packs the Resource set params
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuRsetPar
(
CmTuRsetPar *pkParam0,             /* Resource set params */
Action      action,                /* Action */
Buffer      *mBuf                  /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuRsetPar (pkParam0, action, mBuf)
CmTuRsetPar *pkParam0;             /* Resource set params */
Action      action;                /* Action */
Buffer      *mBuf;                 /* message buffer */
#endif
{
   TRC3(cmPkCmtuRsetPar);

   CMCHKPK(cmPkFthaRsetId, pkParam0->rsetId, mBuf);
   switch (action)
   {
      case CMTU_AGO_ACT :
         CMCHKPK(cmPkFthaGoActPar, &pkParam0->t.ga, mBuf);
         break;
      case CMTU_AGO_SBY :         
         CMCHKPK(cmPkFthaGoSbyPar, &pkParam0->t.gs, mBuf);
         break;
   }
   RETVALUE(ROK);
} /* cmPkCmtuRsetPar */


/*
 *
 *       Fun:   cmPkCmtuAbortPar
 *
 *       Desc:  This function packs the Specfies the operation to be aborted
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuAbortPar
(
CmTuAbortPar *pkParam0,         /* Specfies the operation to be aborted */
Buffer       *mBuf              /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuAbortPar (pkParam0, mBuf)
CmTuAbortPar *pkParam0;         /* Specfies the operation to be aborted */
Buffer       *mBuf;             /* message buffer */
#endif
{
   TRC3(cmPkCmtuAbortPar);

   CMCHKPK(cmPkTranId, pkParam0->transId, mBuf);

   RETVALUE(ROK);
} /* cmPkCmtuAbortPar */


/*
 *
 *       Fun:   cmPkCmtuShCntrl
 *
 *       Desc:  This function packs the Control request from the SH
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuShCntrl
(
CmTuShCntrl *pkParam0,                         /* Control request from the SH */
Buffer *mBuf                                 /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuShCntrl (pkParam0, mBuf)
CmTuShCntrl *pkParam0;                         /* Control request from the SH */
Buffer *mBuf;                                /* message buffer */
#endif
{
   TRC3(cmPkCmtuShCntrl);

   switch (pkParam0->action)
   {
      case CMTU_AABORT :
         CMCHKPK(cmPkCmtuAbortPar, &pkParam0->t.abort, mBuf);
         break;
         
      default:
         cmPkCmtuRsetPar(&pkParam0->t.rsetPar, pkParam0->action, mBuf);
         break;
   }

   CMCHKPK(SPkU8, pkParam0->action, mBuf);
   CMCHKPK(SPkU8, pkParam0->subAction, mBuf);

   RETVALUE(ROK);
} /* cmPkCmtuShCntrl */


/*
 *
 *       Fun:   Pack the control Request
 *
 *       Desc:  This function is used to pack the control request
 *              primitive to PSF-MAP.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
  
#ifdef ANSI
PUBLIC S16 cmPkCmTuCntrlReq
(
Pst       *pst,                /* post structure */    
CmTuMngmt *cntrl,              /* control request */
CmIntfVer intfVer              /* layer interface version */
)
#else
PUBLIC S16 cmPkCmTuCntrlReq(pst, cntrl, intfVer)
Pst       *pst;                /* post structure */    
CmTuMngmt *cntrl;              /* control request */
CmIntfVer intfVer;             /* layer interface version */
#endif
{
   Buffer *mBuf;
 
   TRC3(cmPkCmTuCntrlReq);

   CMTU_GETMSG(pst, &mBuf, ECMTU010);
   
   switch (pst->srcEnt)
   {
      case ENTSH :
         CMCHKPKLOG (cmPkCmtuShCntrl, &cntrl->t.shCntrl, mBuf, ECMTU011, pst);
         break;

      default:
         CMCHKPKLOG (cmPkCmtuCntrl, &cntrl->t.cntrl, mBuf, ECMTU012, pst);
         break;
   }

   CMCHKPKLOG (cmPkHeader, &cntrl->hdr, mBuf, ECMTU013, pst);

   pst->event = EVTTUMILTUCNTRLREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) intfVer;
#else
   UNUSED(intfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* cmPkCmTuCntrlReq */


/*
 *
 *      Fun:   cmPkCmTuCntrlCfm
 *
 *      Desc:  This function packs PSF's control confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuCntrlCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt     *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkCmTuCntrlCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt     *cfm;               /* management structure */
#endif
{
   Buffer *mBuf; /* Message Buffer */

   TRC2(cmPkCmTuCntrlCfm)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU014);

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ECMTU016, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ECMTU017, pst);

   pst->event = EVTTUMILTUCNTRLCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuCntrlCfm */


/*
 *
 *       Fun:   cmPkCmtuRsetSta
 *
 *       Desc:  This function packs the Resource Set Status (part of CmTuSta)
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmPkCmtuRsetSta
(
CmTuRsetSta *pkParam0,  /* Resource Set Status (part of CmTuSta) */
Buffer    *mBuf       /* message buffer */
)
#else
PRIVATE S16 cmPkCmtuRsetSta (pkParam0, mBuf)
CmTuRsetSta *pkParam0;  /* Resource Set Status (part of CmTuSta) */
Buffer    *mBuf;      /* message buffer */
#endif
{
   TRC3(cmPkCmtuRsetSta);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, pkParam0->remPifVerNum,mBuf);
   CMCHKPK(cmPkIntfVer, pkParam0->selfPifVerNum,mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKPK(cmPkFthaSeqNum, pkParam0->wsSeqNmb, mBuf);
   CMCHKPK(cmPkFthaSeqNum, pkParam0->csSeqNmb, mBuf);
   CMCHKPK(cmPkFthaSeqNum, pkParam0->rtUpdSeqNmb, mBuf);
   CMCHKPK(SPkU8, pkParam0->peerState, mBuf);
   CMCHKPK(SPkU8, pkParam0->updState, mBuf);
   CMCHKPK(SPkU8, pkParam0->state, mBuf);
   CMCHKPK(cmPkFthaRsetId, pkParam0->rsetId, mBuf);

   RETVALUE(ROK);
} /* cmPkCmtuRsetSta */


/*
 *
 *      Fun:   cmPkCmTuStaReq
 *
 *      Desc:  This function packs PSF'solicited status request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuStaReq
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *sta,               /* management structure */
CmIntfVer   intfVer             /* layer interface version */
)
#else
PUBLIC S16 cmPkCmTuStaReq(pst, sta, intfVer)
Pst         *pst;               /* post structure       */
CmTuMngmt   *sta;               /* management structure */
CmIntfVer   intfVer;            /* layer interface version */
#endif
{
   Buffer *mBuf; /* message buffer */
   TRC2(cmPkCmTuStaReq)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU018);
      
   switch (sta->hdr.elmId.elmnt)
   {
      case CMTUGEN :
         break;

      case CMTUSID :
         break;
         
      default:
         break;
   }
   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ECMTU020, pst);

   /* post buffer */
   pst->event = EVTTUMILTUSTAREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer = (CmIntfVer) intfVer;
#else
   UNUSED(intfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuStaReq */


/*
 *
 *      Fun:   cmPkCmTuStaCfm
 *
 *      Desc:  This function packs PSF'solicited status confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuStaCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *sta                /* management structure */
)
#else
PUBLIC S16 cmPkCmTuStaCfm(pst, sta)
Pst         *pst;               /* post structure       */
CmTuMngmt   *sta;               /* management structure */
#endif
{
   Buffer       *mBuf; /* Message Buffer */
   
   TRC2(cmPkCmTuStaCfm)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU021);
   
   switch(sta->hdr.elmId.elmnt)
   {
      case CMTUGEN:     
         CMCHKPKLOG(cmPkCmtuRsetSta,&sta->t.sta.cfm.s.rsetSta,mBuf,ECMTU023, pst);
         break;
 
      case CMTUSID:  
         CMCHKPKLOG(cmPkSystemId, &sta->t.sta.cfm.s.sysId, mBuf, ECMTU024, pst);
         break;

      case CMTUGENCFG:
         CMCHKPKLOG(SPkU8,sta->t.sta.cfm.s.genCfgDone,mBuf,ECMTUXXX,pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORPK(ERRCLS_INT_PAR, ECMTU025, (ErrVal)sta->hdr.elmId.elmnt,
                              "cmPkCmTuStaCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;
   }

   /* Pack data and time structure */
   CMCHKPKLOG(cmPkDateTime, &sta->t.sta.cfm.dt, mBuf, ECMTU026, pst);

   /* pack status structure */
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ECMTU027, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ECMTU028, pst);

   pst->event = EVTTUMILTUSTACFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuStaCfm */



/*
 *
 *      Fun:   cmPkCmTuStsReq
 *
 *      Desc:  This function packs PSF'statistics request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuStsReq
(
Pst         *pst,               /* post structure       */
Action      action,             /* action               */
CmTuMngmt   *sts,               /* management structure */
CmIntfVer   intfVer             /* layer interface version */
)
#else
PUBLIC S16 cmPkCmTuStsReq(pst, action, sts, intfVer)
Pst         *pst;               /* post structure       */
Action      action;             /* action               */
CmTuMngmt   *sts;               /* management structure */
CmIntfVer   intfVer;            /* layer interface version */
#endif
{

   Buffer *mBuf;  /* Message Buffer */
   TRC2(cmPkCmTuStsReq)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU029);
      
   switch (sts->hdr.elmId.elmnt)
   {
      case CMTUGEN:
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORPK(ERRCLS_INT_PAR, ECMTU031, (ErrVal)sts->hdr.elmId.elmnt,
                              "cmPkCmTuStsReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */                              
         RETVALUE(RFAILED);
         break;         
   }
      
   /* pack action */
   CMCHKPKLOG(cmPkAction, action, mBuf, ECMTU032, pst);     
      
   /* pack header */
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ECMTU033, pst);

   pst->event = EVTTUMILTUSTSREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = (CmIntfVer) intfVer;
#else
   UNUSED(intfVer);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuStsReq */



/*
 *
 *      Fun:   cmPkCmTuStsCfm
 *
 *      Desc:  This function packs PSF'statistics confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuStsCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt     *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkCmTuStsCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt     *cfm;               /* management structure */
#endif
{
   
   Buffer      *mBuf;             /* message buffer       */
   TRC2(cmPkCmTuStsCfm)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU034);
   
   switch (cfm->hdr.elmId.elmnt)
   {
      case CMTUGEN :
      case CMTURSET :
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.txCS,   mBuf, ECMTU037, pst);
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.rxCS,   mBuf, ECMTU038, pst);
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.txWS,   mBuf, ECMTU039, pst);
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.rxWS,   mBuf, ECMTU040, pst);
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.txRT,   mBuf, ECMTU041, pst);
         CMCHKPKLOG(cmPkStsCntr, cfm->t.sts.cfm.sts.rxRT,   mBuf, ECMTU042, pst);
         CMCHKPKLOG(cmPkDateTime, &cfm->t.sts.cfm.dt, mBuf, ECMTU043, pst);

         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORPK(ERRCLS_INT_PAR, ECMTU045, (ErrVal)cfm->hdr.elmId.elmnt,
                              "cmPkCmTuStsCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         break;         
   }   

   /* pack status structure */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ECMTU046, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ECMTU047, pst);   

   pst->event = EVTTUMILTUSTSCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuStsCfm */



/*
 *
 *      Fun:   cmPkCmTuStaInd
 *
 *      Desc:  This function packs PSF's unsolicited status
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuStaInd
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *usta               /* management structure */
)
#else
PUBLIC S16 cmPkCmTuStaInd(pst, usta)
Pst         *pst;               /* post structure       */
CmTuMngmt   *usta;              /* management structure */
#endif
{

   Buffer      *mBuf;             /* message buffer       */

   TRC2(cmPkCmTuStaInd)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU048);
      
   CMCHKPKLOG(cmPkCmAlarm, &usta->t.usta.alarm, mBuf, ECMTU050, pst); 

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &usta->hdr, mBuf, ECMTU051, pst);

   pst->event = EVTTUMILTUSTAIND;

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuStaInd */



/*
 *
 *      Fun:   cmPkCmTuTrcInd
 *
 *      Desc:  This function packs PSF's trace indication
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkCmTuTrcInd
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *trc                /* management structure */
)
#else
PUBLIC S16 cmPkCmTuTrcInd(pst, trc)
Pst         *pst;               /* post structure       */
CmTuMngmt   *trc;               /* management structure */
#endif
{

   Buffer      *mBuf;             /* message buffer       */

   TRC2(cmPkCmTuTrcInd)

   /* get a buffer for packing */
   CMTU_GETMSG(pst, &mBuf, ECMTU052);
   
   /* This is the first thing to be packed...else we are in trouble
    * while unpacking */
   SCatMsg (mBuf, trc->t.trc.mBuf, M1M2);

   if(trc->t.trc.mBuf != (Buffer *)NULLP)
   {
      SPutMsg (trc->t.trc.mBuf);
   }

   CMCHKPKLOG(SPkU8, trc->t.trc.dir, mBuf, ECMTU053, pst);
   CMCHKPKLOG(cmPkDateTime, &trc->t.trc.dt, mBuf, ECMTU055, pst);
   
   /* pack header */
   CMCHKPKLOG(cmPkHeader, &trc->hdr, mBuf, ECMTU056, pst);

   pst->event = EVTTUMILTUTRCIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkCmTuTrcInd */


/* unpacking functions */


/*
 *
 *      Fun:   cmUnpkCmTuCfgReq
 *
 *      Desc:  This function unpacks configuration request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuCfgReq
(
CmTuCfgReq    func,             /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkCmTuCfgReq(func, pst, mBuf)
CmTuCfgReq    func;             /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   CmTuMngmt          cfg;        /* management strcuture */

   TRC2(cmUnpkCmTuCfgReq)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ECMTU057, pst);
   switch(cfg.hdr.elmId.elmnt)
   {
      case CMTUGEN:   /* general configuration */
         CMCHKUNPKLOG(SUnpkS16, &cfg.t.cfg.s.genCfg.timeRes, mBuf, ECMTU058, pst);
         CMCHKUNPKLOG(cmUnpkMemoryId, &cfg.t.cfg.s.genCfg.mem, mBuf, ECMTU059, pst);
         CMCHKUNPKLOG(cmUnpkPst, &cfg.t.cfg.s.genCfg.smPst, mBuf, ECMTU060, pst);
         CMCHKUNPKLOG(cmUnpkTmrCfg, &cfg.t.cfg.s.genCfg.tUpdCompAck, mBuf, ECMTU061, pst);
         CMCHKUNPKLOG(cmUnpkTmrCfg, &cfg.t.cfg.s.genCfg.tRecovery, mBuf, ECMTU062, pst);
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.genCfg.maxUpdMsgSize, mBuf, ECMTU063, pst);
         CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.genCfg.maxUpdMsgs, mBuf, ECMTU064, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.genCfg.updAllDlg, mBuf, ECMTU064, pst);

         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORUNPK(ERRCLS_INT_PAR, ECMTU076, (ErrVal)cfg.hdr.elmId.elmnt,
                              "cmUnpkCmTuCfgReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */
         SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfg));

} /* end of cmUnpkCmTuCfgReq */


/*
 *
 *      Fun:   cmUnpkCmTuCfgCfm
 *
 *      Desc:  This function unpacks configuration confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuCfgCfm
(
CmTuCfgCfm   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuCfgCfm(func, pst, mBuf)
CmTuCfgCfm   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt   cfm;

   TRC2(cmUnpkCmTuCfgCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ECMTU077, pst);

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ECMTU078, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfm));

} /* end of cmUnpkCmTuCfgCfm */


/*
 *
 *       Fun:   cmUnpkCmtuDbgCntrl
 *
 *       Desc:  This function unpacks the Mod debug mask
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuDbgCntrl
(
CmTuDbgCntrl *unpkParam0,             /* Mod debug mask */
Buffer       *mBuf                    /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuDbgCntrl (unpkParam0, mBuf)
CmTuDbgCntrl *unpkParam0;             /* Mod debug mask */
Buffer       *mBuf;                   /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuDbgCntrl);

   CMCHKUNPK(SUnpkU32, &unpkParam0->mask, mBuf);

   RETVALUE(ROK);
} /* cmUnpkCmtuDbgCntrl */


/*
 *
 *       Fun:   cmUnpkCmtuCntrl
 *
 *       Desc:  This function unpacks the Control request from the SM
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuCntrl
(
CmTuCntrl *unpkParam0,     /* Control request from the SM */
Buffer    *mBuf            /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuCntrl (unpkParam0, mBuf)
CmTuCntrl *unpkParam0;     /* Control request from the SM */
Buffer    *mBuf;           /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuCntrl);

   CMCHKUNPK(SUnpkU8, &unpkParam0->subAction, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam0->action, mBuf);

   if ((unpkParam0->action == CMTU_ADISIMM) ||
       (unpkParam0->action == CMTU_AENA))
   {
      switch (unpkParam0->subAction)
      {
         case CMTU_SAUSTA :
            break;
         
         case CMTU_SADBG :         
            CMCHKUNPK(cmUnpkCmtuDbgCntrl, &unpkParam0->t.dbg, mBuf);
            break;
            
         case CMTU_SATRC:
            break;
            
         default:
            break;
      }
   }
   else
      ;/* CMTU_ASHUTDOWN */

   RETVALUE(ROK);
} /* cmUnpkCmtuCntrl */


/*
 *
 *       Fun:   cmUnpkCmtuRsetPar
 *
 *       Desc:  This function unpacks the Resource set params
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuRsetPar
(
CmTuRsetPar *unpkParam0,       /* Resource set params */
Action      action,            /* Action */
Buffer      *mBuf              /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuRsetPar (unpkParam0, action, mBuf)
CmTuRsetPar *unpkParam0;       /* Resource set params */
Action      action;            /* Action */
Buffer      *mBuf;             /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuRsetPar);

   switch (action)
   {
      case CMTU_AGO_ACT :
         CMCHKUNPK(cmUnpkFthaGoActPar, &unpkParam0->t.ga, mBuf);
         break;
      case CMTU_AGO_SBY :         
         CMCHKUNPK(cmUnpkFthaGoSbyPar, &unpkParam0->t.gs, mBuf);
         break;
   }
   CMCHKUNPK(cmUnpkFthaRsetId, &unpkParam0->rsetId, mBuf);

   RETVALUE(ROK);
} /* cmUnpkCmtuRsetPar */


/*
 *
 *       Fun:   cmUnpkCmtuAbortPar
 *
 *       Desc:  This function unpacks the Specfies the operation to be aborted
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuAbortPar
(
CmTuAbortPar *unpkParam0,      /* Specfies the operation to be aborted */
Buffer       *mBuf             /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuAbortPar (unpkParam0, mBuf)
CmTuAbortPar *unpkParam0;      /* Specfies the operation to be aborted */
Buffer       *mBuf;            /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuAbortPar);

   CMCHKUNPK(cmUnpkTranId, &unpkParam0->transId, mBuf);

   RETVALUE(ROK);
} /* cmUnpkCmtuAbortPar */



/*
 *
 *       Fun:   cmUnpkCmtuShCntrl
 *
 *       Desc:  This function unpacks the Control request from the SH
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuShCntrl
(
CmTuShCntrl *unpkParam0,    /* Control request from the SH */
Buffer      *mBuf           /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuShCntrl (unpkParam0, mBuf)
CmTuShCntrl *unpkParam0;    /* Control request from the SH */
Buffer      *mBuf;          /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuShCntrl);

   CMCHKUNPK(SUnpkU8, &unpkParam0->subAction, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam0->action, mBuf);
   switch (unpkParam0->action)
   {
      case CMTU_AABORT :
         CMCHKUNPK(cmUnpkCmtuAbortPar, &unpkParam0->t.abort, mBuf);
         break;
         
      default:
         cmUnpkCmtuRsetPar(&unpkParam0->t.rsetPar, unpkParam0->action, mBuf);
         break;
   }
   RETVALUE(ROK);
} /* cmUnpkCmtuShCntrl */


/*
 *
 *      Fun:   cmUnpkCmTuCntrlReq
 *
 *      Desc:  This function unpacks control request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuCntrlReq
(
CmTuCntrlReq  func,             /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuCntrlReq(func, pst, mBuf)
CmTuCntrlReq  func;             /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt   cntrl;      /* management structure            */

   TRC2(cmUnpkCmTuCntrlReq)

   /* unpack parameters */
   CMCHKUNPKLOG (cmUnpkHeader, &cntrl.hdr, mBuf, ECMTU080, pst);   
   switch (pst->srcEnt)
   {
      case ENTSH :
         CMCHKUNPKLOG (cmUnpkCmtuShCntrl, &cntrl.t.shCntrl, mBuf, ECMTU081, pst);
         break;

      default:
         CMCHKUNPKLOG (cmUnpkCmtuCntrl, &cntrl.t.cntrl, mBuf, ECMTU082, pst);
         break;
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cntrl));

} /* end of cmUnpkCmTuCntrlReq */


/*
 *
 *      Fun:   cmUnpkCmTuCntrlCfm
 *
 *      Desc:  This function unpacks control confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuCntrlCfm
(
CmTuCntrlCfm    func,           /* primtive to call */
Pst            *pst,            /* post             */
Buffer         *mBuf            /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuCntrlCfm(func, pst, mBuf)
CmTuCntrlCfm    func;           /* primtive to call */
Pst            *pst;            /* post             */
Buffer         *mBuf;           /* message buffer   */
#endif
{
   CmTuMngmt cfm;

   TRC2(cmUnpkCmTuCntrlCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ECMTU083, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ECMTU084, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &cfm));

} /* end of cmUnpkCmTuCntrlCfm */


/*
 *
 *      Fun:   cmUnpkCmTuStaReq
 *
 *      Desc:  This function unpacks status request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuStaReq
(
CmTuStaReq    func,             /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuStaReq(func, pst, mBuf)
CmTuStaReq    func;             /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt sta;      /* management structure */

   TRC2(cmUnpkCmTuStaReq)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ECMTU086, pst);
   
   switch (sta.hdr.elmId.elmnt)
   {
      case CMTUGEN :
         break;

      case CMTURSET :
         break;

      case CMTUSID :
         break;
         
      default:
         break;         
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sta));

} /* end of cmUnpkCmTuStaReq */


/*
 *
 *       Fun:   cmUnpkCmtuRsetSta
 *
 *       Desc:  This function unpacks the Resource Set Status (part of CmTuSta)
 *
 *       Ret:   ROK
 *
 *       Notes: None
 *
 *       File:  cmptupsf.c
 *
 */
#ifdef ANSI
PRIVATE S16 cmUnpkCmtuRsetSta
(
CmTuRsetSta *unpkParam0,     /* Resource Set Status (part of CmTuSta) */
Buffer      *mBuf            /* message buffer */
)
#else
PRIVATE S16 cmUnpkCmtuRsetSta (unpkParam0, mBuf)
CmTuRsetSta *unpkParam0;     /* Resource Set Status (part of CmTuSta) */
Buffer      *mBuf;           /* message buffer */
#endif
{
   TRC3(cmUnpkCmtuRsetSta);

   CMCHKUNPK(cmUnpkFthaRsetId, &unpkParam0->rsetId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam0->state, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam0->updState, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam0->peerState, mBuf);
   CMCHKUNPK(cmUnpkFthaSeqNum, &unpkParam0->rtUpdSeqNmb, mBuf);
   CMCHKUNPK(cmUnpkFthaSeqNum, &unpkParam0->csSeqNmb, mBuf);
   CMCHKUNPK(cmUnpkFthaSeqNum, &unpkParam0->wsSeqNmb, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(cmUnpkIntfVer, &unpkParam0->selfPifVerNum,mBuf);
   CMCHKUNPK(cmUnpkIntfVer, &unpkParam0->remPifVerNum,mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
} /* cmUnpkCmtuRsetSta */


/*
 *
 *      Fun:   cmUnpkCmTuStaCfm
 *
 *      Desc:  This function unpacks status confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuStaCfm
(
CmTuStaCfm    func,             /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuStaCfm(func, pst, mBuf)
CmTuStaCfm    func;             /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt    sta;           /* management structure     */
   Txt          ptNmb[32];     /* part number              */

   TRC2(cmUnpkCmTuStaCfm)

   /* initialize the system id parameter in the status confirm */
   sta.t.sta.cfm.s.sysId.ptNmb = (Txt *)NULLP;

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ECMTU088, pst);

   /* unpack confirm structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ECMTU089, pst);

   /* Unpack date and time structure */
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.sta.cfm.dt, mBuf, ECMTU090, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case CMTUGEN :
      case CMTURSET :
         CMCHKUNPKLOG(cmUnpkCmtuRsetSta,&sta.t.sta.cfm.s.rsetSta,mBuf,
                            ECMTU091,pst);
         break;

      case CMTUSID :
         sta.t.sta.cfm.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.sta.cfm.s.sysId, mBuf, 
                            ECMTU093, pst);
         break;

      case CMTUGENCFG:
         /* Unpack genCfgDone field */
         CMCHKUNPKLOG(SUnpkU8, &sta.t.sta.cfm.s.genCfgDone, mBuf,ECMTUXXX, 
                      pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORUNPK(ERRCLS_INT_PAR, ECMTU094,(ErrVal)sta.hdr.elmId.elmnt,
                          "cmUnpkCmTuStaCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
         break;
   }

   
   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sta));

} /* end of cmUnpkCmTuStaCfm */


/*
 *
 *      Fun:   cmUnpkCmTuStsReq
 *
 *      Desc:  This function unpacks statistics request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuStsReq
(
CmTuStsReq   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuStsReq(func, pst, mBuf)
CmTuStsReq   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt     sts;
   Action      action;
   
   TRC2(cmUnpkCmTuStsReq)
   
   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ECMTU095, pst);

   /* pack action */
   CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ECMTU096, pst);
   
   switch (sts.hdr.elmId.elmnt)
   {
      case CMTUGEN:
         break;

      case CMTURSET :
         break;

      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORUNPK(ERRCLS_INT_PAR, ECMTU098,(ErrVal)sts.hdr.elmId.elmnt,
                              "cmUnpkCmTuStsReq(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */                              
         RETVALUE(RFAILED);
         break;         
   }   

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, action, &sts));

} /* end of cmUnpkCmTuStsReq */



/*
 *
 *      Fun:   cmUnpkCmTuStsCfm
 *
 *      Desc:  This function unpacks statistics confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuStsCfm
(
CmTuStsCfm   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuStsCfm(func, pst, mBuf)
CmTuStsCfm   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt      sts;           /* management structure     */

   TRC2(cmUnpkCmTuStsCfm)
   
   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ECMTU099, pst);
   /* unpack confirm structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm, mBuf, ECMTU100, pst);
   
   switch (sts.hdr.elmId.elmnt)
   {
      case CMTUGEN:
      case CMTURSET:
         CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sta.cfm.dt, mBuf, ECMTU102, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.rxRT, mBuf, ECMTU103, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.txRT, mBuf, ECMTU104, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.rxWS, mBuf, ECMTU105, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.txWS, mBuf, ECMTU106, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.rxCS, mBuf, ECMTU107, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sts.t.sts.cfm.sts.txCS, mBuf, ECMTU108, pst);
         break;
         
      default:
#if (ERRCLASS & ERRCLS_INT_PAR)
         CMTULOGERRORUNPK(ERRCLS_INT_PAR, ECMTU111, (ErrVal)sts.hdr.elmId.elmnt,
                              "cmUnpkCmTuStsCfm(). Invalid elmnt");
#endif /* (ERRCLASS & ERRCLS_DEBUG) */                              
         RETVALUE(RFAILED);      
         break;
   }

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &sts));

} /* end of cmUnpkCmTuStsCfm */



/*
 *
 *      Fun:   cmUnpkCmTuStaInd
 *
 *      Desc:  This function unpacks unsolicited status indication from 
 *             PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuStaInd
(
CmTuStaInd   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuStaInd(func, pst, mBuf)
CmTuStaInd   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt   usta;      /* management structure */

   TRC2(cmUnpkCmTuStaInd)

   /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &usta.hdr, mBuf, ECMTU112, pst);
   
   CMCHKUNPKLOG(cmUnpkCmAlarm, &usta.t.usta.alarm, mBuf, ECMTU113, pst);

   /* return message buffer */
   (Void) SPutMsg(mBuf);

   /* call primitive */
   RETVALUE((*func)(pst, &usta));

} /* end of cmUnpkCmTuStaInd */



/*
 *
 *      Fun:   cmUnpkCmTuTrcInd
 *
 *      Desc:  This function unpacks PSF's trace indication
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmptupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkCmTuTrcInd
(
CmTuStaInd   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkCmTuTrcInd(func, pst, mBuf)
CmTuStaInd   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   CmTuMngmt  trc;  /* Management structure */
   MsgLen     len;  /* Message length */   

   TRC2(cmUnpkCmTuTrcInd)

  /* unpack parameters */
   CMCHKUNPKLOG(cmUnpkHeader, &trc.hdr, mBuf, ECMTU115, pst);
   
   CMCHKUNPKLOG(cmUnpkDateTime, &trc.t.trc.dt, mBuf, ECMTU116, pst);
   CMCHKUNPKLOG(SUnpkU8, &trc.t.trc.dir, mBuf, ECMTU118, pst);
   

   trc.t.trc.mBuf = (Buffer *)NULLP;
   if((SFndLenMsg(mBuf,&len) == ROK) && (len > 0))
   {
      trc.t.trc.mBuf = mBuf;  
   }
   else
   {
      SPutMsg(mBuf);
   }

   /* call primitive */
   RETVALUE((*func)(pst, &trc));

} /* end of cmUnpkCmTuTrcInd */

  
/********************************************************************30**
  
         End of file:     cmptupsf.c@@/main/2 - Fri Dec 10 17:55:35 2004
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/2      ---      jz   1. initial release.

*********************************************************************91*/
