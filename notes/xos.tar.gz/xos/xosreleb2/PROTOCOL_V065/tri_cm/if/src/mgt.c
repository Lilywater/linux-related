/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/
/********************************************************************20**
  
     Name:     MGT Interface
  
     Type:     C file
  
     Desc:     This file contains the packing/unpacking functions for
               MGT interface of MGCP

     File:     mgt.c

     Sid:      mgt.c@@/main/14 - Wed Mar 30 08:39:00 2005
  
     Prg:      rrp
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_tkns.h"       /* common tokens */

#include "cm_inet.h"       /* common sockets */
#include "cm_tpt.h"        /* common transport */
#include "cm_dns.h"        /* common DNS library */
#include "cm_mblk.h"       /* common mblk alloc */
#include "cm_sdp.h"        /* common sdp defines */

#ifdef DG
#include "cm_ftha.h"       /* Common FTHA Defines */
#endif /* DG */

#ifdef ZG_DFTHA
#include "cm_ftha.h"       /* Common FTHA Defines */
#include "cm_psfft.h"      /* Common PSF Related Defines */
#endif /* ZG_DFTHA */

#include "mgt.h"           /* mgt interface defines */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_tkns.x"       /* common tokens */

#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport */
#include "cm_mblk.x"       /* common mem block alloc */
#include "cm_sdp.x"        /* common sdp types */
#include "cm_lib.x"        /* Common library functions */

#ifdef DG
#include "cm_ftha.x"       /* Common FTHA typedefs */
#endif /* DG */

#ifdef ZG_DFTHA
#include "cm_ftha.x"       /* Common FTHA typedefs */
#include "cm_psfft.x"      /* Common PSF Typedefs */
#endif /* ZG_DFTHA */

#include "mgt.x"           /* mgt interface types */

#ifdef GCP_MGCP
#define cmPkMgCallId cmPkTknStr32
#define cmUnpkMgCallId cmUnpkTknStr32
#define cmPkMgConnId cmPkTknStr32
#define cmUnpkMgConnId cmUnpkTknStr32
#define cmPkMgRqstId cmPkTknStr32
#define cmUnpkMgRqstId cmUnpkTknStr32
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 
#else
#define cmPkMgConnMode cmPkTknU8
#define cmUnpkMgConnMode cmUnpkTknU8
#endif
#define cmPkMgScndConnId cmPkTknStr32
#define cmUnpkMgScndConnId cmUnpkTknStr32
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 
#define cmPkMgMgcpExtVal cmPkMgEvntParamType
#define cmUnpkMgMgcpExtVal cmUnpkMgEvntParamType
#endif
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCP_PARSE_DIG_MAP) 
#define cmPkMgDgtMap cmPkMacroTknStrOSXL
#define cmUnpkMgDgtMap cmUnpkMacroTknStrOSXL
#endif
#define cmPkMgObsEvntSet cmPkMgSignalRqstSet
#define cmUnpkMgObsEvntSet cmUnpkMgSignalRqstSet
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
#define cmPkMgMgcoVersion cmPkTknU8
#define cmUnpkMgMgcoVersion cmUnpkTknU8
#define cmPkMgMgcoSecParmIndex cmPkTknU32
#define cmUnpkMgMgcoSecParmIndex cmUnpkTknU32
#define cmPkMgMgcoSequenceNum cmPkTknU32
#define cmUnpkMgMgcoSequenceNum cmUnpkTknU32
#define cmPkMgMgcoAuthData cmPkMacroTknStrOSXL
#define cmUnpkMgMgcoAuthData cmUnpkMacroTknStrOSXL
#define cmPkMgMgcoMtpAddr cmPkTknStr8
#define cmUnpkMgMgcoMtpAddr cmUnpkTknStr8
#define cmPkMgMgcoEvtBufCtl cmPkTknU8
#define cmUnpkMgMgcoEvtBufCtl cmUnpkTknU8
#define cmPkMgMgcoSvcState cmPkTknU8
#define cmUnpkMgMgcoSvcState cmUnpkTknU8
#ifdef MGT_MGCO_V2
#define cmPkMgMgcoIndAudStatistics cmPkMgMgcoSigName
#define cmUnpkMgMgcoIndAudStatistics cmUnpkMgMgcoSigName
#define cmPkMgMgcoIndAudPackages cmPkMgMgcoPkgsItem
#define cmUnpkMgMgcoIndAudPackages cmUnpkMgMgcoPkgsItem
#endif /* MGT_MGCO_V2 */
#ifndef MGT_MGCO_V2
#define cmPkMgMgcoAuditItem cmPkTknU8
#define cmUnpkMgMgcoAuditItem cmUnpkTknU8
#endif /* MGT_MGCO_V2 */
#define cmPkMgMgcoStreamId cmPkTknU16
#define cmUnpkMgMgcoStreamId cmUnpkTknU16
#define cmPkMgMgcoTransId cmPkTknU32
#define cmUnpkMgMgcoTransId cmUnpkTknU32
#define cmPkMgMgcoObjId cmPkMacroTknStrOSXL
#define cmUnpkMgMgcoObjId cmUnpkMacroTknStrOSXL
#define cmPkMgMgcoSvcChgReason cmPkMacroTknStrOSXL
#define cmUnpkMgMgcoSvcChgReason cmUnpkMacroTknStrOSXL
#define cmPkMgMgcoDevName cmPkMgMgcoPathName
#define cmUnpkMgMgcoDevName cmUnpkMgMgcoPathName
#define cmPkMgMgcoEvtName cmPkMgMgcoPkgdName
#define cmUnpkMgMgcoEvtName cmUnpkMgMgcoPkgdName
#define cmPkMgMgcoSvcChgAddr cmPkMgMgcoMid
#define cmUnpkMgMgcoSvcChgAddr cmUnpkMgMgcoMid
#define cmPkMgMgcoRemoteDesc cmPkMgMgcoLocalDesc
#define cmUnpkMgMgcoRemoteDesc cmUnpkMgMgcoLocalDesc
#define cmPkMgMgcoSigOther cmPkMgMgcoEvtOther
#define cmUnpkMgMgcoSigOther cmUnpkMgMgcoEvtOther
#define cmPkMgMgcoEmbNoSig cmPkMgMgcoEmbedFirst
#define cmUnpkMgMgcoEmbNoSig cmUnpkMgMgcoEmbedFirst
#define cmPkMgMgcoEvSpec cmPkMgMgcoReqEvt
#define cmUnpkMgMgcoEvSpec cmUnpkMgMgcoReqEvt
#endif /* GCP_MGCO */
/* Packing/Unpacking Macros */
#define cmPkMacroTknStrOSXL(tknStr, mBuf) cmPkTknStrOSXL(tknStr, mBuf)
#define cmUnpkMacroTknStrOSXL(tknStr, ptr, mBuf) cmUnpkTknStrOSXL(tknStr, mBuf, ptr)
#define cmPkMacroTknBuf(val, mBuf) cmPkTknBuf(val, mBuf)
#define cmUnpkMacroTknBuf(val, mBuf) cmUnpkTknBuf(val, &mBuf)

#ifdef CP_UA_IF_TYPE_SS
extern U32 g_megacoUaModId;
extern void XosToFrameCallBack(U32 mid, Pst *pPst, void * pvBuf);
#endif /* CP_UA_IF_TYPE_SS */

#if(defined(LCMGT) || defined(LWLCMGT) || defined(LCLMG) || defined(LWLCLMG)) 



/*
*
*    Fun:    cmPkMgDName
*
*    Desc:    pack the structure MgDName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDName
(
MgDName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDName(param ,mBuf)
MgDName *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgDName)

    if( param->namePres.pres != NOTPRSNT )
    {
       for (i=CM_DNS_DNAME_LEN -1;i>=0;i--)
       {
          CMCHKPK(SPkU8, param->name[i],mBuf);
       }
    }
    CMCHKPK(cmPkTknPres, &param->namePres,mBuf);
    CMCHKPK(cmPkCmNetAddr, &param->netAddr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDName*/

/*
*
*    Fun:    cmUnpkMgDName
*
*    Desc:    unpack the structure MgDName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDName
(
MgDName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDName(param ,mBuf)
MgDName *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgDName)

    CMCHKUNPK(cmUnpkCmNetAddr, &param->netAddr,mBuf);
    CMCHKUNPK(cmUnpkTknPres, &param->namePres,mBuf);
    if( param->namePres.pres != NOTPRSNT )
    {
       for (i=0;i<CM_DNS_DNAME_LEN ;i++)
       {
          CMCHKUNPK(SUnpkU8, &param->name[i], mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgDName*/
#endif
#if(defined(LCMGT) || defined(LWLCMGT) || defined(LCLMG) || defined(LWLCLMG)) 

/*
*
*    Fun:    cmPkMgPeerInfo
*
*    Desc:    pack the structure MgPeerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerInfo
(
MgPeerInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerInfo(param ,mBuf)
MgPeerInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPeerInfo)

    if(param->pres.pres != NOTPRSNT)
    {
#ifdef   GCP_PROV_MTP3       
       CMCHKPK(cmPkTknU32, &param->selfPc,mBuf);
#endif   /* GCP_PROV_MTP3 */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
     
       CMCHKPK(cmPkMgMgcoMidStr, &param->mid,mBuf);
#endif /*    */
       CMCHKPK(cmPkTknS32, &param->port,mBuf);
       CMCHKPK(cmPkMgDName, &param->dname,mBuf);
       CMCHKPK(cmPkTknU32, &param->id,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerInfo*/

/*
*
*    Fun:    cmUnpkMgPeerInfo
*
*    Desc:    unpack the structure MgPeerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerInfo
(
MgPeerInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerInfo(param ,mBuf)
MgPeerInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPeerInfo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->id,mBuf);
       CMCHKUNPK(cmUnpkMgDName, &param->dname,mBuf);
       CMCHKUNPK(cmUnpkTknS32, &param->port,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
       CMCHKUNPK(cmUnpkMgMgcoMidStr, &param->mid,mBuf);
     
#endif /*    */
#ifdef   GCP_PROV_MTP3
       CMCHKUNPK(cmUnpkTknU32, &param->selfPc,mBuf);
#endif   /* GCP_PROV_MTP3 */
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerInfo*/
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 

/*
*
*    Fun:    cmPkMgMgcoMidStr
*
*    Desc:    pack the structure MgMgcoMidStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMidStr
(
MgMgcoMidStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMidStr(param ,mBuf)
MgMgcoMidStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoMidStr)

    if( param->pres != NOTPRSNT )
    {
       for (i=MGT_MID_STR_LEN -1;i>=0;i--)
       {
          CMCHKPK(SPkU8, param->val[i],mBuf);
       }
    }
#ifdef ALIGN_64BIT
    CMCHKPK(SPkU32, param->spare2,mBuf);
#endif /*  ALIGN_64BIT  */
    CMCHKPK(SPkU16, param->len,mBuf);
    CMCHKPK(SPkU8, param->spare1,mBuf);
    CMCHKPK(SPkU8, param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMidStr*/
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */

#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 

/*
*
*    Fun:    cmUnpkMgMgcoMidStr
*
*    Desc:    unpack the structure mgMgcoMidStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMidStr
(
MgMgcoMidStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMidStr(param ,mBuf)
MgMgcoMidStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoMidStr)

    CMCHKUNPK(SUnpkU8, &param->pres,mBuf);
    CMCHKUNPK(SUnpkU8, &param->spare1,mBuf);
    CMCHKUNPK(SUnpkU16, &param->len,mBuf);
#ifdef ALIGN_64BIT
    CMCHKUNPK(SUnpkU32, &param->spare2,mBuf);
#endif /*  ALIGN_64BIT  */
    if( param->pres != NOTPRSNT )
    {
       for (i=0;i<MGT_MID_STR_LEN ;i++)
       {
          CMCHKUNPK(SUnpkU8, &param->val[i], mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMidStr*/
#endif /* GCP_MGCO || TDS_ROLL_UPGRADE_SUPPORT */


#endif

#if (defined(LCMGT) || defined(LWLCMGT))
/* mgt_c_003.main_14: Support for Package Id to U16 under
 * flag MGT_PROPR_PKG_SUPPORT */
/*
 *
 *      Fun:   cmPkTknPkgId
 *
 *      Desc:  This function packs a token U16
 *
 *      Ret:   ROK      - ok
 *
 *      Notes: None
 *
        File:  mgt.c
 *
 */
  
#ifdef ANSI
PUBLIC S16 cmPkTknPkgId
(
TknPkgId *tknPkgId,             /* token Package Id */
Buffer   *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmPkTknPkgId(tknPkgId, mBuf)
TknPkgId *tknPkgId;         /* token Package Id */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(cmPkTknPkgId)

#ifdef MGT_PROPR_PKG_SUPPORT
   CMCHKPK(cmPkTknU16, tknPkgId, mBuf);
#else
   CMCHKPK(cmPkTknU8, tknPkgId, mBuf);
#endif

   RETVALUE(ROK);
} /* end of cmPkTknPkgId */


/*
*
*    Fun:    cmPkMgLclErr
*
*    Desc:    pack the structure MgLclErr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgLclErr
(
MgLclErr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgLclErr(param ,mBuf)
MgLclErr *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgLclErr)

    CMCHKPK(cmPkTknU32, &param->trId,mBuf);
    CMCHKPK(cmPkTknU8, &param->errType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgLclErr*/

/*
*
*    Fun:    cmPkMgTransInfo
*
*    Desc:    pack the structure MgTransInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTransInfo
(
MgTransInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTransInfo(param ,mBuf)
MgTransInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTransInfo)

    CMCHKPK(cmPkTknU32, &param->lastTransId,mBuf);
    CMCHKPK(cmPkTknU32, &param->firstTransId,mBuf);
    CMCHKPK(SPkU8, param->transDir,mBuf);
    CMCHKPK(SPkU8, param->transType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTransInfo*/

/*
*
*    Fun:    cmPkMgMoveTransInfo
*
*    Desc:    pack the structure MgMoveTransInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMoveTransInfo
(
MgMoveTransInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMoveTransInfo(param ,mBuf)
MgMoveTransInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMoveTransInfo)

    CMCHKPK(cmPkMgTransInfo, &param->transInfo,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->newPeer,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMoveTransInfo*/

/*
*
*    Fun:    cmPkMgMgtCntrl
*
*    Desc:    pack the structure MgMgtCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgtCntrl
(
MgMgtCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgtCntrl(param ,mBuf)
MgMgtCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgtCntrl)

    switch( param->action )
    {
       case  MGT_CANCEL_RMV_ASSOC :
          break;
       case  MGT_MOVE_PEER :
          CMCHKPK(SPkS16, param->u.ssapId,mBuf);
          break;
       case  MGT_MOVE_TRANS :
          CMCHKPK(cmPkMgMoveTransInfo, &param->u.moveTransInfo,mBuf);
          break;
       case  MGT_RESET_RTO :
          break;
       case  MGT_RMV_ASSOC :
          CMCHKPK(SPkU16, param->u.dura,mBuf);
          break;
       case  MGT_RMV_TRANS :
          CMCHKPK(cmPkMgTransInfo, &param->u.transInfo,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKPK(SPkU8, param->action,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgMgtCntrl*/

/*
*
*    Fun:    cmPkMgTransStatus
*
*    Desc:    pack the structure MgTransStatus
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTransStatus
(
MgTransStatus *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTransStatus(param ,mBuf)
MgTransStatus *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTransStatus)

    CMCHKPK(SPkU8, param->transDir,mBuf);
    CMCHKPK(SPkU8, param->transStatus,mBuf);
    CMCHKPK(SPkU32, param->transId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTransStatus*/

/*
*
*    Fun:    cmPkMgAuditInfo
*
*    Desc:    pack the structure MgAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAuditInfo
(
MgAuditInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAuditInfo(param ,mBuf)
MgAuditInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgAuditInfo)

    for (i=param->numTxn -1;i>=0;i--)
    {
       CMCHKPK(cmPkMgTransStatus, &param->transStatus[i], mBuf);
    }
    CMCHKPK(SPkU8, param->moreTxn,mBuf);
    CMCHKPK(SPkU16, param->numTxn,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAuditInfo*/

/*
*
*    Fun:    cmPkMgMgtAudit
*
*    Desc:    pack the structure MgMgtAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgtAudit
(
MgMgtAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgtAudit(param ,mBuf)
MgMgtAudit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgtAudit)

    CMCHKPK(cmPkMgAuditInfo, &param->auditInfo,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgMgtAudit*/
#ifdef GCP_MGCP

/*
*
*    Fun:    cmPkMgPkgName
*
*    Desc:    pack the structure MgPkgName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPkgName
(
MgPkgName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPkgName(param ,mBuf)
MgPkgName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgPkgName)

    ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkgId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPkgName*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgConnModVal
*
*    Desc:    pack the structure MgConnModVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnModVal
(
MgConnModVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnModVal(param ,mBuf)
MgConnModVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnModVal)

    ret1 = cmPkMacroTknStrOSXL(&param->unKnownconnModVal,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->knownConnModVal,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnModVal*/

/*
*
*    Fun:    cmPkMgConnModeX
*
*    Desc:    pack the structure MgConnModeX
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnModeX
(
MgConnModeX *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnModeX(param ,mBuf)
MgConnModeX *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnModeX)

    ret1 = cmPkMgConnModVal(&param->connModVal,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgConnModeX*/

/*
*
*    Fun:    cmPkMgConnMode
*
*    Desc:    pack the structure MgConnMode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnMode
(
MgConnMode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnMode(param ,mBuf)
MgConnMode *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnMode)

    ret1 = cmPkMgConnModeX(&param->xMode,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->stdOrXion,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnMode*/
#endif

/*
*
*    Fun:    cmPkMgQuoteStr
*
*    Desc:    pack the structure MgQuoteStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgQuoteStr
(
MgQuoteStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgQuoteStr(param ,mBuf)
MgQuoteStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgQuoteStr)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->str[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgQuoteStr*/

/*
*
*    Fun:    cmPkMgEvntParamType
*
*    Desc:    pack the structure MgEvntParamType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntParamType
(
MgEvntParamType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntParamType(param ,mBuf)
MgEvntParamType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntParamType)

    if( param->eventParamType.pres != NOTPRSNT )
    {
       switch( param->eventParamType.val )
       {
          case  MGT_TYPE_QUOTED_STR :
             ret1 = cmPkMgQuoteStr(&param->t.quotedStr,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TYPE_STR :
             ret1 = cmPkMacroTknStrOSXL(&param->t.paramStr,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->eventParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntParamType*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpExtValSet
*
*    Desc:    pack the structure MgMgcpExtValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpExtValSet
(
MgMgcpExtValSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpExtValSet(param ,mBuf)
MgMgcpExtValSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcpExtValSet)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpExtVal,  (param->val[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpExtValSet*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgNonStdExtn
*
*    Desc:    pack the structure MgNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNonStdExtn
(
MgNonStdExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNonStdExtn(param ,mBuf)
MgNonStdExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNonStdExtn)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcpExtValSet(&param->val,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->extnName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNonStdExtn*/
#else

/*
*
*    Fun:    cmPkMgNonStdExtn
*
*    Desc:    pack the structure MgNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNonStdExtn
(
MgNonStdExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNonStdExtn(param ,mBuf)
MgNonStdExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNonStdExtn)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->extnVal,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->extnName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNonStdExtn*/
#endif

/*
*
*    Fun:    cmPkMgEPName
*
*    Desc:    pack the structure MgEPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEPName
(
MgEPName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEPName(param ,mBuf)
MgEPName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEPName)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->domainName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->lclName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEPName*/

/*
*
*    Fun:    cmPkMgMgcpVer
*
*    Desc:    pack the structure MgMgcpVer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpVer
(
MgMgcpVer *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpVer(param ,mBuf)
MgMgcpVer *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpVer)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->profName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->minor,mBuf);
       CMCHKPK(cmPkTknU16, &param->major,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpVer*/

/*
*
*    Fun:    cmPkMgMgcpVerSet
*
*    Desc:    pack the structure MgMgcpVerSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpVerSet
(
MgMgcpVerSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpVerSet(param ,mBuf)
MgMgcpVerSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcpVerSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpVer,  (param->versions[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpVerSet*/

/*
*
*    Fun:    cmPkMgMgcpCmdLine
*
*    Desc:    pack the structure MgMgcpCmdLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpCmdLine
(
MgMgcpCmdLine *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpCmdLine(param ,mBuf)
MgMgcpCmdLine *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpCmdLine)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcpVer(&param->mgcpVer,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgEPName(&param->epName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->trId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpCmdLine*/

/*
*
*    Fun:    cmPkMgRspAck
*
*    Desc:    pack the structure MgRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRspAck
(
MgRspAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRspAck(param ,mBuf)
MgRspAck *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgRspAck)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->upperBnd,mBuf);
       CMCHKPK(cmPkTknU32, &param->lowBnd,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRspAck*/

/*
*
*    Fun:    cmPkMgRspAckSet
*
*    Desc:    pack the structure MgRspAckSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRspAckSet
(
MgRspAckSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRspAckSet(param ,mBuf)
MgRspAckSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRspAckSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRspAck,  (param->rspAck[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRspAckSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgEvntParamTypeSet
*
*    Desc:    pack the structure MgEvntParamTypeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntParamTypeSet
(
MgEvntParamTypeSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntParamTypeSet(param ,mBuf)
MgEvntParamTypeSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgEvntParamTypeSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgEvntOneParamType,  (param->evntParam[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntParamTypeSet*/
#else

/*
*
*    Fun:    cmPkMgEvntParamTypeSet
*
*    Desc:    pack the structure MgEvntParamTypeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntParamTypeSet
(
MgEvntParamTypeSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntParamTypeSet(param ,mBuf)
MgEvntParamTypeSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgEvntParamTypeSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgEvntParamType,  (param->evntParam[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntParamTypeSet*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpName
*
*    Desc:    pack the structure MgMgcpName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpName
(
MgMgcpName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpName(param ,mBuf)
MgMgcpName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpName)

    ret1 = cmPkMacroTknStrOSXL(&param->str,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpName*/

/*
*
*    Fun:    cmPkMgEvntOneParamTypeVal
*
*    Desc:    pack the structure MgEvntOneParamTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntOneParamTypeVal
(
MgEvntOneParamTypeVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntOneParamTypeVal(param ,mBuf)
MgEvntOneParamTypeVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntOneParamTypeVal)

    ret1 = cmPkMgEvntParamType(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgEvntOneParamTypeVal*/

/*
*
*    Fun:    cmPkMgEvntParamTypeValSet
*
*    Desc:    pack the structure MgEvntParamTypeValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntParamTypeValSet
(
MgEvntParamTypeValSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntParamTypeValSet(param ,mBuf)
MgEvntParamTypeValSet *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntParamTypeValSet)

    ret1 = cmPkMgEvntParamTypeSet(&param->params,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgEvntParamTypeValSet*/

/*
*
*    Fun:    cmPkMgEvntOneParamType
*
*    Desc:    pack the structure MgEvntOneParamType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntOneParamType
(
MgEvntOneParamType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntOneParamType(param ,mBuf)
MgEvntOneParamType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntOneParamType)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVNT_PARAM_ONE_VAL :
             ret1 = cmPkMgEvntOneParamTypeVal(&param->t.oneParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVNT_PARAM_ONLY_VAL :
             ret1 = cmPkMgEvntParamType(&param->t.val,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVNT_PARAM_SET_VAL :
             ret1 = cmPkMgEvntParamTypeValSet(&param->t.paramSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntOneParamType*/

/*
*
*    Fun:    cmPkMgMgcpPkgSpcExtn
*
*    Desc:    pack the structure MgMgcpPkgSpcExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpPkgSpcExtn
(
MgMgcpPkgSpcExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpPkgSpcExtn(param ,mBuf)
MgMgcpPkgSpcExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpPkgSpcExtn)

    ret1 = cmPkMgMgcpExtValSet(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcpName(&param->extnName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkg,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpPkgSpcExtn*/

/*
*
*    Fun:    cmPkMgMgcpOthExtn
*
*    Desc:    pack the structure MgMgcpOthExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpOthExtn
(
MgMgcpOthExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpOthExtn(param ,mBuf)
MgMgcpOthExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpOthExtn)

    ret1 = cmPkMgMgcpExtValSet(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknStr32, &param->name,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpOthExtn*/

/*
*
*    Fun:    cmPkMgMgcpExtn
*
*    Desc:    pack the structure MgMgcpExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpExtn
(
MgMgcpExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpExtn(param ,mBuf)
MgMgcpExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpExtn)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_LCL_CONNOPT_OTHR_EXT :
             ret1 = cmPkMgMgcpOthExtn(&param->t.othrX,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_PKG_EXT :
             ret1 = cmPkMgMgcpPkgSpcExtn(&param->t.pkgX,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_VNDR_EXT :
             ret1 = cmPkMgNonStdExtn(&param->t.vndrX,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpExtn*/

/*
*
*    Fun:    cmPkMgMgcpPkgSpcExtnParam
*
*    Desc:    pack the structure MgMgcpPkgSpcExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpPkgSpcExtnParam
(
MgMgcpPkgSpcExtnParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpPkgSpcExtnParam(param ,mBuf)
MgMgcpPkgSpcExtnParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpPkgSpcExtnParam)

    ret1 = cmPkMgMgcpName(&param->extnName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkg,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpPkgSpcExtnParam*/

/*
*
*    Fun:    cmPkMgNonStdExtnParam
*
*    Desc:    pack the structure MgNonStdExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNonStdExtnParam
(
MgNonStdExtnParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNonStdExtnParam(param ,mBuf)
MgNonStdExtnParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNonStdExtnParam)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->extnName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNonStdExtnParam*/

/*
*
*    Fun:    cmPkMgMgcpExtnParam
*
*    Desc:    pack the structure MgMgcpExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpExtnParam
(
MgMgcpExtnParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpExtnParam(param ,mBuf)
MgMgcpExtnParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpExtnParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_EXTN_PARAM_OTHER :
             CMCHKPK(cmPkTknStr32, &param->t.othrXParam,mBuf);
             break;
          case  MGT_MGCP_EXTN_PARAM_PKG :
             ret1 = cmPkMgMgcpPkgSpcExtnParam(&param->t.pkgXParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_EXTN_PARAM_VNDR :
             ret1 = cmPkMgNonStdExtnParam(&param->t.vndrXParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpExtnParam*/

/*
*
*    Fun:    cmPkMgMgcpBrrAttr
*
*    Desc:    pack the structure MgMgcpBrrAttr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpBrrAttr
(
MgMgcpBrrAttr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpBrrAttr(param ,mBuf)
MgMgcpBrrAttr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpBrrAttr)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_BRR_ENCODING :
             CMCHKPK(cmPkTknU8, &param->t.brrEncd,mBuf);
             break;
          case  MGT_MGCP_BRR_EXTN :
             ret1 = cmPkMgMgcpPkgSpcExtn(&param->t.brrExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpBrrAttr*/

/*
*
*    Fun:    cmPkMgBearerInfo
*
*    Desc:    pack the structure MgBearerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgBearerInfo
(
MgBearerInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgBearerInfo(param ,mBuf)
MgBearerInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgBearerInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpBrrAttr,  (param->bearerEnc[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgBearerInfo*/
#else

/*
*
*    Fun:    cmPkMgBearerInfo
*
*    Desc:    pack the structure MgBearerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgBearerInfo
(
MgBearerInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgBearerInfo(param ,mBuf)
MgBearerInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgBearerInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->bearerEnc[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgBearerInfo*/
#endif

/*
*
*    Fun:    cmPkMgConnIdSet
*
*    Desc:    pack the structure MgConnIdSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnIdSet
(
MgConnIdSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnIdSet(param ,mBuf)
MgConnIdSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgConnIdSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgConnId,  (param->connId[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnIdSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgNtfiedEnt
*
*    Desc:    pack the structure MgNtfiedEnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNtfiedEnt
(
MgNtfiedEnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNtfiedEnt(param ,mBuf)
MgNtfiedEnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNtfiedEnt)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->port,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->domainName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->lclName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNtfiedEnt*/
#else

/*
*
*    Fun:    cmPkMgNtfiedEnt
*
*    Desc:    pack the structure MgNtfiedEnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNtfiedEnt
(
MgNtfiedEnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNtfiedEnt(param ,mBuf)
MgNtfiedEnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNtfiedEnt)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->port,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->domainName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStr32, &param->lclName,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNtfiedEnt*/
#endif

/*
*
*    Fun:    cmPkMgSuppPkgs
*
*    Desc:    pack the structure MgSuppPkgs
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSuppPkgs
(
MgSuppPkgs *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSuppPkgs(param ,mBuf)
MgSuppPkgs *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgSuppPkgs)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgPkgName,  (param->pkgName[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSuppPkgs*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgSuppModes
*
*    Desc:    pack the structure MgSuppModes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSuppModes
(
MgSuppModes *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSuppModes(param ,mBuf)
MgSuppModes *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgSuppModes)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkMgConnMode( (param->mode[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSuppModes*/
#else

/*
*
*    Fun:    cmPkMgSuppModes
*
*    Desc:    pack the structure MgSuppModes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSuppModes
(
MgSuppModes *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSuppModes(param ,mBuf)
MgSuppModes *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgSuppModes)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->mode[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSuppModes*/
#endif

/*
*
*    Fun:    cmPkMgEncryptInfo
*
*    Desc:    pack the structure MgEncryptInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEncryptInfo
(
MgEncryptInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEncryptInfo(param ,mBuf)
MgEncryptInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEncryptInfo)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->encryptKey,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->encryptMethod,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEncryptInfo*/

/*
*
*    Fun:    cmPkMgGainCtrl
*
*    Desc:    pack the structure MgGainCtrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgGainCtrl
(
MgGainCtrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgGainCtrl(param ,mBuf)
MgGainCtrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgGainCtrl)

    CMCHKPK(cmPkTknS16, &param->gainVal,mBuf);
    CMCHKPK(cmPkTknU8, &param->ctrlType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgGainCtrl*/
#ifdef MGT_GCP_VER_1_4

/*
*
*    Fun:    cmPkMgAlgoNameSet
*
*    Desc:    pack the structure MgAlgoNameSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAlgoNameSet
(
MgAlgoNameSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAlgoNameSet(param ,mBuf)
MgAlgoNameSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgAlgoNameSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->algoName[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAlgoNameSet*/
#else /* MGT_GCP_VER_1_4 */

/*
*
*    Fun:    cmPkMgAlgoNameSet
*
*    Desc:    pack the structure MgAlgoNameSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAlgoNameSet
(
MgAlgoNameSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAlgoNameSet(param ,mBuf)
MgAlgoNameSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgAlgoNameSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknStr32,  (param->algoName[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAlgoNameSet*/
#endif /* MGT_GCP_VER_1_4 */

/*
*
*    Fun:    cmPkMgBw
*
*    Desc:    pack the structure MgBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgBw
(
MgBw *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgBw(param ,mBuf)
MgBw *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgBw)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->upperBnd,mBuf);
       CMCHKPK(cmPkTknU16, &param->lowBnd,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgBw*/

/*
*
*    Fun:    cmPkMgPktzPeriod
*
*    Desc:    pack the structure MgPktzPeriod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPktzPeriod
(
MgPktzPeriod *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPktzPeriod(param ,mBuf)
MgPktzPeriod *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPktzPeriod)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->upperBnd,mBuf);
       CMCHKPK(cmPkTknU16, &param->lowBnd,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPktzPeriod*/

/*
*
*    Fun:    cmPkMgRsvDest
*
*    Desc:    pack the structure MgRsvDest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRsvDest
(
MgRsvDest *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRsvDest(param ,mBuf)
MgRsvDest *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRsvDest)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->port,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->domainName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRsvDest*/

/*
*
*    Fun:    cmPkMgSecret
*
*    Desc:    pack the structure MgSecret
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSecret
(
MgSecret *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSecret(param ,mBuf)
MgSecret *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgSecret)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->key,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->method,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSecret*/

/*
*
*    Fun:    cmPkMgAuthEncAlgoSet
*
*    Desc:    pack the structure MgAuthEncAlgoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAuthEncAlgoSet
(
MgAuthEncAlgoSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAuthEncAlgoSet(param ,mBuf)
MgAuthEncAlgoSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgAuthEncAlgoSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->suites[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAuthEncAlgoSet*/

/*
*
*    Fun:    cmPkMgCipherSuite
*
*    Desc:    pack the structure MgCipherSuite
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgCipherSuite
(
MgCipherSuite *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgCipherSuite(param ,mBuf)
MgCipherSuite *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgCipherSuite)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgAuthEncAlgoSet(&param->encAlgoSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgAuthEncAlgoSet(&param->authAlgoSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgCipherSuite*/

/*
*
*    Fun:    cmPkMgRsrcRsvSet
*
*    Desc:    pack the structure MgRsrcRsvSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRsrcRsvSet
(
MgRsrcRsvSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRsrcRsvSet(param ,mBuf)
MgRsrcRsvSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRsrcRsvSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->reservations[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRsrcRsvSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgTypNwSupp
*
*    Desc:    pack the structure MgTypNwSupp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTypNwSupp
(
MgTypNwSupp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTypNwSupp(param ,mBuf)
MgTypNwSupp *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgTypNwSupp)

    ret1 = cmPkMacroTknStrOSXL(&param->othrNwTyp,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->stdOrOthr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTypNwSupp*/

/*
*
*    Fun:    cmPkMgTypNwSuppSeq
*
*    Desc:    pack the structure MgTypNwSuppSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTypNwSuppSeq
(
MgTypNwSuppSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTypNwSuppSeq(param ,mBuf)
MgTypNwSuppSeq *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgTypNwSuppSeq)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgTypNwSupp,  (param->typeOfNetwork[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTypNwSuppSeq*/

/*
*
*    Fun:    cmPkMgNwTypeChc
*
*    Desc:    pack the structure MgNwTypeChc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNwTypeChc
(
MgNwTypeChc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNwTypeChc(param ,mBuf)
MgNwTypeChc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgNwTypeChc)

    if( param->oneOrmany.pres != NOTPRSNT )
    {
       switch( param->oneOrmany.val )
       {
          case  MGT_MGCP_SUPP_TONS :
             ret1 = cmPkMgTypNwSuppSeq(&param->u.typNwSuppSeq,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_TON :
             ret1 = cmPkMgTypNwSupp(&param->u.typNwSupp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->oneOrmany,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNwTypeChc*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmPkMgMgcpLclFmtpVal
*
*    Desc:    pack the structure MgMgcpLclFmtpVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpLclFmtpVal
(
MgMgcpLclFmtpVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpLclFmtpVal(param ,mBuf)
MgMgcpLclFmtpVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpLclFmtpVal)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->formatName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->codecInst,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->codecName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpLclFmtpVal*/

/*
*
*    Fun:    cmPkMgMgcpLclFmtpValSet
*
*    Desc:    pack the structure MgMgcpLclFmtpValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpLclFmtpValSet
(
MgMgcpLclFmtpValSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpLclFmtpValSet(param ,mBuf)
MgMgcpLclFmtpValSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcpLclFmtpValSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpLclFmtpVal,  (param->val[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpLclFmtpValSet*/

/*
*
*    Fun:    cmPkMgMgcpLclRsSh
*
*    Desc:    pack the structure MgMgcpLclRsSh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpLclRsSh
(
MgMgcpLclRsSh *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpLclRsSh(param ,mBuf)
MgMgcpLclRsSh *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcpLclRsSh)

    CMCHKPK(cmPkMgConnId, &param->connId,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpLclRsSh*/

/*
*
*    Fun:    cmPkMgLclConnOpts
*
*    Desc:    pack the structure MgLclConnOpts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgLclConnOpts
(
MgLclConnOpts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgLclConnOpts(param ,mBuf)
MgLclConnOpts *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgLclConnOpts)

    if( param->valType.pres != NOTPRSNT )
    {
       switch( param->valType.val )
       {
          case  MGT_LCL_CONNOPT_ALGO_NAME :
             ret1 = cmPkMgAlgoNameSet(&param->t.algoNameSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_BW :
             CMCHKPK(cmPkMgBw, &param->t.mgBw,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_GATEID :
             CMCHKPK(cmPkTknU32, &param->t.dqosGateId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCID :
             CMCHKPK(cmPkTknU32, &param->t.dqosRsrcId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCRSV :
             ret1 = cmPkMgRsrcRsvSet(&param->t.dqosRsrcRsv,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSVDEST :
             ret1 = cmPkMgRsvDest(&param->t.dqosRsvDest,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_ECHO_CAN :
             CMCHKPK(cmPkTknU8, &param->t.ecancel,mBuf);
             break;
          case  MGT_LCL_CONNOPT_ENCRYPT_INFO :
             ret1 = cmPkMgEncryptInfo(&param->t.encryptInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_GAIN_CTRL :
             CMCHKPK(cmPkMgGainCtrl, &param->t.gainCtrl,mBuf);
             break;
#ifdef GCP_2705BIS
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmPkMgMgcpExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS  */
#ifdef GCP_2705BIS
#else /* ,,,,,,,,,,,, */ 
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmPkMgNonStdExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS,#else  */
          case  MGT_LCL_CONNOPT_PKTZ_PERIOD :
             CMCHKPK(cmPkMgPktzPeriod, &param->t.pktzPeriod,mBuf);
             break;
          case  MGT_LCL_CONNOPT_RSRC_RESV :
             CMCHKPK(cmPkTknU8, &param->t.rsrcResv,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SEC_RTCPSUITE :
             ret1 = cmPkMgCipherSuite(&param->t.secRtcpSuite,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_RTPSUITE :
             ret1 = cmPkMgCipherSuite(&param->t.secRtpSuite,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_SECRET :
             ret1 = cmPkMgSecret(&param->t.secSecret,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SIL_SUPP :
             CMCHKPK(cmPkTknU8, &param->t.silSupp,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SUPP_MODES :
             ret1 = cmPkMgSuppModes(&param->t.suppModes,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SUPP_PKGS :
             ret1 = cmPkMgSuppPkgs(&param->t.suppPkgs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef GCP_2705BIS
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             ret1 = cmPkMgNwTypeChc(&param->t.typeOfNetwork,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS  */
#ifdef GCP_2705BIS
#else /* ,,,,,,,,,,,, */ 
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             CMCHKPK(cmPkTknU8, &param->t.typeOfNetwork,mBuf);
             break;
#endif /*  GCP_2705BIS,#else  */
          case  MGT_LCL_CONNOPT_TYPE_SRVC :
             CMCHKPK(cmPkTknU16, &param->t.typeOfSrvc,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_FMTP :
             ret1 = cmPkMgMgcpLclFmtpValSet(&param->t.fmtp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_OPT_FMTP :
             ret1 = cmPkMgMgcpLclFmtpValSet(&param->t.fmtp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_CNFM :
             CMCHKPK(cmPkTknU8, &param->t.rsCnf,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_DIR :
             CMCHKPK(cmPkTknU8, &param->t.rsDir,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_SHARE :
             CMCHKPK(cmPkMgMgcpLclRsSh, &param->t.rsSh,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->valType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgLclConnOpts*/
#else

/*
*
*    Fun:    cmPkMgLclConnOpts
*
*    Desc:    pack the structure MgLclConnOpts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgLclConnOpts
(
MgLclConnOpts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgLclConnOpts(param ,mBuf)
MgLclConnOpts *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgLclConnOpts)

    if( param->valType.pres != NOTPRSNT )
    {
       switch( param->valType.val )
       {
          case  MGT_LCL_CONNOPT_ALGO_NAME :
             ret1 = cmPkMgAlgoNameSet(&param->t.algoNameSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_BW :
             CMCHKPK(cmPkMgBw, &param->t.mgBw,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_GATEID :
             CMCHKPK(cmPkTknU32, &param->t.dqosGateId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCID :
             CMCHKPK(cmPkTknU32, &param->t.dqosRsrcId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCRSV :
             ret1 = cmPkMgRsrcRsvSet(&param->t.dqosRsrcRsv,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSVDEST :
             ret1 = cmPkMgRsvDest(&param->t.dqosRsvDest,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_ECHO_CAN :
             CMCHKPK(cmPkTknU8, &param->t.ecancel,mBuf);
             break;
          case  MGT_LCL_CONNOPT_ENCRYPT_INFO :
             ret1 = cmPkMgEncryptInfo(&param->t.encryptInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_GAIN_CTRL :
             CMCHKPK(cmPkMgGainCtrl, &param->t.gainCtrl,mBuf);
             break;
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmPkMgNonStdExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_PKTZ_PERIOD :
             CMCHKPK(cmPkMgPktzPeriod, &param->t.pktzPeriod,mBuf);
             break;
          case  MGT_LCL_CONNOPT_RSRC_RESV :
             CMCHKPK(cmPkTknU8, &param->t.rsrcResv,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SEC_RTCPSUITE :
             ret1 = cmPkMgCipherSuite(&param->t.secRtcpSuite,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_RTPSUITE :
             ret1 = cmPkMgCipherSuite(&param->t.secRtpSuite,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_SECRET :
             ret1 = cmPkMgSecret(&param->t.secSecret,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SIL_SUPP :
             CMCHKPK(cmPkTknU8, &param->t.silSupp,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SUPP_MODES :
             ret1 = cmPkMgSuppModes(&param->t.suppModes,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SUPP_PKGS :
             ret1 = cmPkMgSuppPkgs(&param->t.suppPkgs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             CMCHKPK(cmPkTknU8, &param->t.typeOfNetwork,mBuf);
             break;
          case  MGT_LCL_CONNOPT_TYPE_SRVC :
             CMCHKPK(cmPkTknU16, &param->t.typeOfSrvc,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->valType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgLclConnOpts*/
#endif

/*
*
*    Fun:    cmPkMgLclConnOptSet
*
*    Desc:    pack the structure MgLclConnOptSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgLclConnOptSet
(
MgLclConnOptSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgLclConnOptSet(param ,mBuf)
MgLclConnOptSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgLclConnOptSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgLclConnOpts,  (param->lclConnOpt[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgLclConnOptSet*/
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmPkMgEventDesc
*
*    Desc:    pack the structure MgEventDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEventDesc
(
MgEventDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEventDesc(param ,mBuf)
MgEventDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEventDesc)

    if( param->descType.pres != NOTPRSNT )
    {
       switch( param->descType.val )
       {
          case  MGT_DESC_EVENT_ALL :
             break;
          case  MGT_DESC_EVENT_DTMF_POUND :
             break;
          case  MGT_DESC_EVENT_DTMF_STAR :
             break;
          case  MGT_DESC_EVENT_ID :
             ret1 = cmPkMacroTknStrOSXL(&param->t.eventId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DESC_EVENT_KNOWN :
             CMCHKPK(cmPkTknU16, &param->t.eventKnown,mBuf);
             break;
          case  MGT_DESC_EVENT_RANGE :
             ret1 = cmPkMacroTknStrOSXL(&param->t.eventRange,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->descType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEventDesc*/
#else

/*
*
*    Fun:    cmPkMgEventDesc
*
*    Desc:    pack the structure MgEventDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEventDesc
(
MgEventDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEventDesc(param ,mBuf)
MgEventDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEventDesc)

    if( param->descType.pres != NOTPRSNT )
    {
       switch( param->descType.val )
       {
          case  MGT_DESC_EVENT_ALL :
             break;
          case  MGT_DESC_EVENT_ID :
             ret1 = cmPkMacroTknStrOSXL(&param->t.eventId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DESC_EVENT_KNOWN :
             CMCHKPK(cmPkTknU16, &param->t.eventKnown,mBuf);
             break;
          case  MGT_DESC_EVENT_RANGE :
             ret1 = cmPkMacroTknStrOSXL(&param->t.eventRange,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->descType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEventDesc*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmPkMgEvntName
*
*    Desc:    pack the structure MgEvntName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntName
(
MgEvntName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntName(param ,mBuf)
MgEvntName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntName)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStr32, &param->connId,mBuf);
       ret1 = cmPkMgEventDesc(&param->eventDesc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->pkgPres,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntName*/
#else

/*
*
*    Fun:    cmPkMgEvntName
*
*    Desc:    pack the structure MgEvntName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEvntName
(
MgEvntName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEvntName(param ,mBuf)
MgEvntName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgEvntName)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStr32, &param->connId,mBuf);
       ret1 = cmPkMgEventDesc(&param->eventDesc,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEvntName*/
#endif

/*
*
*    Fun:    cmPkMgSignalRqst
*
*    Desc:    pack the structure MgSignalRqst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSignalRqst
(
MgSignalRqst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSignalRqst(param ,mBuf)
MgSignalRqst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgSignalRqst)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgEvntParamTypeSet(&param->evntParamSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgEvntName(&param->evntName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSignalRqst*/

/*
*
*    Fun:    cmPkMgSignalRqstSet
*
*    Desc:    pack the structure MgSignalRqstSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSignalRqstSet
(
MgSignalRqstSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSignalRqstSet(param ,mBuf)
MgSignalRqstSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgSignalRqstSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgSignalRqst,  (param->signalRqst[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSignalRqstSet*/
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCP_PARSE_DIG_MAP) 
#else

/*
*
*    Fun:    cmPkMgDgtMap
*
*    Desc:    pack the structure MgDgtMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDgtMap
(
MgDgtMap *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDgtMap(param ,mBuf)
MgDgtMap *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgDgtMap)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMacroTknStrOSXL,  (param->dgtStr[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDgtMap*/
#endif

/*
*
*    Fun:    cmPkMgRqstdActnSet
*
*    Desc:    pack the structure MgRqstdActnSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdActnSet
(
MgRqstdActnSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdActnSet(param ,mBuf)
MgRqstdActnSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRqstdActnSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRqstdActn,  (param->rqstdActn[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdActnSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgRqstdEvntSeq
*
*    Desc:    pack the structure MgRqstdEvntSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdEvntSeq
(
MgRqstdEvntSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdEvntSeq(param ,mBuf)
MgRqstdEvntSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRqstdEvntSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgEvntParamTypeSet(&param->evntParamSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgRqstdActnSet(&param->rqstdActnSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgEvntName(&param->evntName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdEvntSeq*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgRqstdEvntSet
*
*    Desc:    pack the structure MgRqstdEvntSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdEvntSet
(
MgRqstdEvntSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdEvntSet(param ,mBuf)
MgRqstdEvntSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRqstdEvntSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRqstdEvntSeq,  (param->rqstdEvnt[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdEvntSet*/
#else

/*
*
*    Fun:    cmPkMgRqstdEvntSet
*
*    Desc:    pack the structure MgRqstdEvntSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdEvntSet
(
MgRqstdEvntSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdEvntSet(param ,mBuf)
MgRqstdEvntSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRqstdEvntSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRqstdEvnt,  (param->rqstdEvnt[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdEvntSet*/
#endif

/*
*
*    Fun:    cmPkMgRqstEmbedType
*
*    Desc:    pack the structure MgRqstEmbedType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstEmbedType
(
MgRqstEmbedType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstEmbedType(param ,mBuf)
MgRqstEmbedType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRqstEmbedType)

    if( param->embdRqstType.pres != NOTPRSNT )
    {
       switch( param->embdRqstType.val )
       {
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmPkMgDgtMap(&param->t.dgtMap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmPkMgRqstdEvntSet(&param->t.rqstdEvntSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmPkMgSignalRqstSet(&param->t.signalRqstSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->embdRqstType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstEmbedType*/

/*
*
*    Fun:    cmPkMgEmbedActn
*
*    Desc:    pack the structure MgEmbedActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEmbedActn
(
MgEmbedActn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEmbedActn(param ,mBuf)
MgEmbedActn *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgEmbedActn)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRqstEmbedType,  (param->rqstdEmbed[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEmbedActn*/

/*
*
*    Fun:    cmPkMgRqstEmbedMDCXMode
*
*    Desc:    pack the structure MgRqstEmbedMDCXMode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstEmbedMDCXMode
(
MgRqstEmbedMDCXMode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstEmbedMDCXMode(param ,mBuf)
MgRqstEmbedMDCXMode *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgRqstEmbedMDCXMode)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStr32, &param->connId,mBuf);
       CMCHKPK(cmPkTknU8, &param->connMode,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstEmbedMDCXMode*/

/*
*
*    Fun:    cmPkMgEmbedMDCX
*
*    Desc:    pack the structure MgEmbedMDCX
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEmbedMDCX
(
MgEmbedMDCX *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEmbedMDCX(param ,mBuf)
MgEmbedMDCX *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgEmbedMDCX)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgRqstEmbedMDCXMode,  (param->modes[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEmbedMDCX*/

/*
*
*    Fun:    cmPkMgAction
*
*    Desc:    pack the structure MgAction
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAction
(
MgAction *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAction(param ,mBuf)
MgAction *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgAction)

    ret1 = cmPkMacroTknStrOSXL(&param->unknownAction,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->knownAction,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAction*/

/*
*
*    Fun:    cmPkMgPkgXActn
*
*    Desc:    pack the structure MgPkgXActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPkgXActn
(
MgPkgXActn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPkgXActn(param ,mBuf)
MgPkgXActn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgPkgXActn)

    ret1 = cmPkMgEvntParamTypeSet(&param->actnparms,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgAction(&param->action,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgPkgXActn*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgRqstdActn
*
*    Desc:    pack the structure MgRqstdActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdActn
(
MgRqstdActn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdActn(param ,mBuf)
MgRqstdActn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRqstdActn)

    if( param->actionType.pres != NOTPRSNT )
    {
       switch( param->actionType.val )
       {
          case  MGT_RQSTD_ACTN_A :
             break;
          case  MGT_RQSTD_ACTN_D :
             break;
          case  MGT_RQSTD_ACTN_EMB :
             ret1 = cmPkMgEmbedActn(&param->u.embedActn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_EXTN :
             ret1 = cmPkMgPkgXActn(&param->u.Xactn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_I :
             break;
          case  MGT_RQSTD_ACTN_K :
             break;
          case  MGT_RQSTD_ACTN_MDCX :
             ret1 = cmPkMgEmbedMDCX(&param->u.mdcx,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_N :
             break;
          case  MGT_RQSTD_ACTN_S :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->actionType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdActn*/
#else

/*
*
*    Fun:    cmPkMgRqstdActn
*
*    Desc:    pack the structure MgRqstdActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdActn
(
MgRqstdActn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdActn(param ,mBuf)
MgRqstdActn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRqstdActn)

    if( param->actionType.pres != NOTPRSNT )
    {
       switch( param->actionType.val )
       {
          case  MGT_RQSTD_ACTN_A :
             break;
          case  MGT_RQSTD_ACTN_D :
             break;
          case  MGT_RQSTD_ACTN_EMB :
             ret1 = cmPkMgEmbedActn(&param->u.embedActn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_I :
             break;
          case  MGT_RQSTD_ACTN_K :
             break;
          case  MGT_RQSTD_ACTN_MDCX :
             ret1 = cmPkMgEmbedMDCX(&param->u.mdcx,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_N :
             break;
          case  MGT_RQSTD_ACTN_S :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->actionType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdActn*/
#endif

/*
*
*    Fun:    cmPkMgRqstdEvnt
*
*    Desc:    pack the structure MgRqstdEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdEvnt
(
MgRqstdEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdEvnt(param ,mBuf)
MgRqstdEvnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRqstdEvnt)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgRqstdActnSet(&param->rqstdActnSet,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgEvntName(&param->evntName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdEvnt*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgPkgCPName
*
*    Desc:    pack the structure MgPkgCPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPkgCPName
(
MgPkgCPName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPkgCPName(param ,mBuf)
MgPkgCPName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgPkgCPName)

    ret1 = cmPkMacroTknStrOSXL(&param->cpName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->knownCpName,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPkgCPName*/

/*
*
*    Fun:    cmPkMgPkgCPXNm
*
*    Desc:    pack the structure MgPkgCPXNm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPkgCPXNm
(
MgPkgCPXNm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPkgCPXNm(param ,mBuf)
MgPkgCPXNm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgPkgCPXNm)

    ret1 = cmPkMgPkgCPName(&param->cpName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgPkgCPXNm*/

/*
*
*    Fun:    cmPkMgCPName
*
*    Desc:    pack the structure MgCPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgCPName
(
MgCPName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgCPName(param ,mBuf)
MgCPName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgCPName)

    if( param->vndrOrPkg.pres != NOTPRSNT )
    {
       switch( param->vndrOrPkg.val )
       {
          case  MGT_MGCP_CONN_PAR_PKG_EXTN :
             ret1 = cmPkMgPkgCPXNm(&param->t.pkgXName,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_CONN_PAR_VNDR_EXTN :
             ret1 = cmPkMacroTknStrOSXL(&param->t.vndrXName,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->vndrOrPkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgCPName*/

/*
*
*    Fun:    cmPkMgConnParExtn
*
*    Desc:    pack the structure MgConnParExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnParExtn
(
MgConnParExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnParExtn(param ,mBuf)
MgConnParExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnParExtn)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->paramVal,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgCPName(&param->paramName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnParExtn*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgConnParam
*
*    Desc:    pack the structure MgConnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnParam
(
MgConnParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnParam(param ,mBuf)
MgConnParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnParam)

    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_CONN_PARAM_JI :
             CMCHKPK(cmPkTknU32, &param->t.jitter,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_LA :
             CMCHKPK(cmPkTknU32, &param->t.avgLatency,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_NONSTD :
             ret1 = cmPkMgConnParExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM_OR :
             CMCHKPK(cmPkTknU32, &param->t.octetsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_OS :
             CMCHKPK(cmPkTknU32, &param->t.octetsSent,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PL :
             CMCHKPK(cmPkTknU32, &param->t.pktsLost,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PR :
             CMCHKPK(cmPkTknU32, &param->t.pktsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PS :
             CMCHKPK(cmPkTknU32, &param->t.pktsSent,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->paramType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnParam*/
#else

/*
*
*    Fun:    cmPkMgConnParam
*
*    Desc:    pack the structure MgConnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnParam
(
MgConnParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnParam(param ,mBuf)
MgConnParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgConnParam)

    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_CONN_PARAM_JI :
             CMCHKPK(cmPkTknU32, &param->t.jitter,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_LA :
             CMCHKPK(cmPkTknU32, &param->t.avgLatency,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_NONSTD :
             ret1 = cmPkMgNonStdExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM_OR :
             CMCHKPK(cmPkTknU32, &param->t.octetsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_OS :
             CMCHKPK(cmPkTknU32, &param->t.octetsSent,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PL :
             CMCHKPK(cmPkTknU32, &param->t.pktsLost,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PR :
             CMCHKPK(cmPkTknU32, &param->t.pktsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PS :
             CMCHKPK(cmPkTknU32, &param->t.pktsSent,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->paramType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnParam*/
#endif

/*
*
*    Fun:    cmPkMgConnParamSet
*
*    Desc:    pack the structure MgConnParamSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgConnParamSet
(
MgConnParamSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgConnParamSet(param ,mBuf)
MgConnParamSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgConnParamSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgConnParam,  (param->connParam[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgConnParamSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgReasonCode
*
*    Desc:    pack the structure MgReasonCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgReasonCode
(
MgReasonCode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgReasonCode(param ,mBuf)
MgReasonCode *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgReasonCode)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->param,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->code,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgReasonCode*/
#else

/*
*
*    Fun:    cmPkMgReasonCode
*
*    Desc:    pack the structure MgReasonCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgReasonCode
(
MgReasonCode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgReasonCode(param ,mBuf)
MgReasonCode *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgReasonCode)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->param,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->code,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgReasonCode*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkInfoCode
*
*    Desc:    pack the structure InfoCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkInfoCode
(
InfoCode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkInfoCode(param ,mBuf)
InfoCode *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkInfoCode)

    ret1 = cmPkMgMgcpExtnParam(&param->xParam,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->codeType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkInfoCode*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgRqstdInfo
*
*    Desc:    pack the structure MgRqstdInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdInfo
(
MgRqstdInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdInfo(param ,mBuf)
MgRqstdInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgRqstdInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkInfoCode( (param->infoCode[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdInfo*/
#else

/*
*
*    Fun:    cmPkMgRqstdInfo
*
*    Desc:    pack the structure MgRqstdInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRqstdInfo
(
MgRqstdInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRqstdInfo(param ,mBuf)
MgRqstdInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgRqstdInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->infoCode[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRqstdInfo*/
#endif

/*
*
*    Fun:    cmPkMgQrntHandling
*
*    Desc:    pack the structure MgQrntHandling
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgQrntHandling
(
MgQrntHandling *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgQrntHandling(param ,mBuf)
MgQrntHandling *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgQrntHandling)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->ctrl[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgQrntHandling*/

/*
*
*    Fun:    cmPkMgDetectEvent
*
*    Desc:    pack the structure MgDetectEvent
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDetectEvent
(
MgDetectEvent *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDetectEvent(param ,mBuf)
MgDetectEvent *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgDetectEvent)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgEvntName,  (param->evnt[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDetectEvent*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgRsrtMethod
*
*    Desc:    pack the structure MgRsrtMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgRsrtMethod
(
MgRsrtMethod *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgRsrtMethod(param ,mBuf)
MgRsrtMethod *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgRsrtMethod)

    ret1 = cmPkMgMgcpPkgSpcExtnParam(&param->xRstrtMethod,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->stdOrXten,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgRsrtMethod*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpParamExtn
*
*    Desc:    pack the structure MgMgcpParamExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpParamExtn
(
MgMgcpParamExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpParamExtn(param ,mBuf)
MgMgcpParamExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpParamExtn)

    ret1 = cmPkMacroTknStrOSXL(&param->extnVal,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcpExtnParam(&param->extnParam,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpParamExtn*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpPkgNmVer
*
*    Desc:    pack the structure MgMgcpPkgNmVer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpPkgNmVer
(
MgMgcpPkgNmVer *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpPkgNmVer(param ,mBuf)
MgMgcpPkgNmVer *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpPkgNmVer)

    ret1 = cmPkMacroTknStrOSXL(&param->pkgVer,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpPkgNmVer*/

/*
*
*    Fun:    cmPkMgMgcpPkgList
*
*    Desc:    pack the structure MgMgcpPkgList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpPkgList
(
MgMgcpPkgList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpPkgList(param ,mBuf)
MgMgcpPkgList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcpPkgList)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpPkgNmVer,  (param->nameVer[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpPkgList*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpParam
*
*    Desc:    pack the structure MgMgcpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpParam
(
MgMgcpParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpParam(param ,mBuf)
MgMgcpParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpParam)

    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_BEAR_INFO :
             ret1 = cmPkMgBearerInfo(&param->t.bearerInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CALLID :
             CMCHKPK(cmPkMgCallId, &param->t.callId,mBuf);
             break;
          case  MGT_PARAM_CAPABILITIES :
             ret1 = cmPkMgLclConnOptSet(&param->t.capabilitySet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONNID :
             ret1 = cmPkMgConnIdSet(&param->t.connIdSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_MODE :
             ret1 = cmPkMgConnMode(&param->t.connMode,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM :
             ret1 = cmPkMgConnParamSet(&param->t.connParamSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DETECT_EVENT :
             ret1 = cmPkMgSignalRqstSet(&param->t.detectEvnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmPkMgDgtMap(&param->t.dgtMap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_EVNTSTATES :
             ret1 = cmPkMgSignalRqstSet(&param->t.eventStates,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_LCL_CONNOPTS :
             ret1 = cmPkMgLclConnOptSet(&param->t.lclConnOptSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_MAX_DATAGRAM :
             CMCHKPK(cmPkTknU32, &param->t.maxDatGram,mBuf);
             break;
          case  MGT_PARAM_MAX_ENDPT_IDS :
             CMCHKPK(cmPkTknU32, &param->t.maxEndPtIds,mBuf);
             break;
          case  MGT_PARAM_NON_STD :
             ret1 = cmPkMgMgcpParamExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NTFIED_ENT :
             ret1 = cmPkMgNtfiedEnt(&param->t.ntfiedEnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NUM_ENDPT_IDS :
             CMCHKPK(cmPkTknU32, &param->t.numEndPtIds,mBuf);
             break;
          case  MGT_PARAM_OBS_EVENT :
             ret1 = cmPkMgObsEvntSet(&param->t.obsEvntSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_PACKAGE_LIST :
             ret1 = cmPkMgMgcpPkgList(&param->t.pkgList,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_QRNT_HANDLING :
             ret1 = cmPkMgQrntHandling(&param->t.qrntHandling,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_REASON :
             ret1 = cmPkMgReasonCode(&param->t.reasonCode,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RESOURCE_ID :
             CMCHKPK(cmPkTknU32, &param->t.resourceId,mBuf);
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmPkMgRqstdEvntSet(&param->t.rqstdEvntSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_INFO :
             ret1 = cmPkMgRqstdInfo(&param->t.rqstdInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTID :
             CMCHKPK(cmPkMgRqstId, &param->t.rqstId,mBuf);
             break;
          case  MGT_PARAM_RSPACK :
             ret1 = cmPkMgRspAckSet(&param->t.rspAckSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RSTRT_DELAY :
             CMCHKPK(cmPkTknU32, &param->t.rstrtDelay,mBuf);
             break;
          case  MGT_PARAM_RSTRT_METHOD :
             ret1 = cmPkMgRsrtMethod(&param->t.rstrtMethod,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SCND_CONNID :
             ret1 = cmPkMgConnIdSet(&param->t.scndConnIdSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SECND_EPID :
             ret1 = cmPkMgEPName(&param->t.scndEpId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmPkMgSignalRqstSet(&param->t.sigRqstSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SPEC_EPID :
             ret1 = cmPkMgEPName(&param->t.specificEpId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_VERSN_SUPRTD :
             ret1 = cmPkMgMgcpVerSet(&param->t.versionsSupp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->paramType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpParam*/
#else

/*
*
*    Fun:    cmPkMgMgcpParam
*
*    Desc:    pack the structure MgMgcpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpParam
(
MgMgcpParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpParam(param ,mBuf)
MgMgcpParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpParam)

    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_BEAR_INFO :
             ret1 = cmPkMgBearerInfo(&param->t.bearerInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CALLID :
             CMCHKPK(cmPkMgCallId, &param->t.callId,mBuf);
             break;
          case  MGT_PARAM_CAPABILITIES :
             ret1 = cmPkMgLclConnOptSet(&param->t.capabilitySet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONNID :
             ret1 = cmPkMgConnIdSet(&param->t.connIdSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_MODE :
             CMCHKPK(cmPkMgConnMode, &param->t.connMode,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM :
             ret1 = cmPkMgConnParamSet(&param->t.connParamSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DETECT_EVENT :
             ret1 = cmPkMgDetectEvent(&param->t.detectEvnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmPkMgDgtMap(&param->t.dgtMap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_EVNTSTATES :
             ret1 = cmPkMgSignalRqstSet(&param->t.eventStates,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_LCL_CONNOPTS :
             ret1 = cmPkMgLclConnOptSet(&param->t.lclConnOptSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_MAX_ENDPT_IDS :
             CMCHKPK(cmPkTknU32, &param->t.maxEndPtIds,mBuf);
             break;
          case  MGT_PARAM_NON_STD :
             ret1 = cmPkMgNonStdExtn(&param->t.nonStdExtn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NTFIED_ENT :
             ret1 = cmPkMgNtfiedEnt(&param->t.ntfiedEnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NUM_ENDPT_IDS :
             CMCHKPK(cmPkTknU32, &param->t.numEndPtIds,mBuf);
             break;
          case  MGT_PARAM_OBS_EVENT :
             ret1 = cmPkMgObsEvntSet(&param->t.obsEvntSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_QRNT_HANDLING :
             ret1 = cmPkMgQrntHandling(&param->t.qrntHandling,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_REASON :
             ret1 = cmPkMgReasonCode(&param->t.reasonCode,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RESOURCE_ID :
             CMCHKPK(cmPkTknU32, &param->t.resourceId,mBuf);
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmPkMgRqstdEvntSet(&param->t.rqstdEvntSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_INFO :
             ret1 = cmPkMgRqstdInfo(&param->t.rqstdInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTID :
             CMCHKPK(cmPkMgRqstId, &param->t.rqstId,mBuf);
             break;
          case  MGT_PARAM_RSPACK :
             ret1 = cmPkMgRspAckSet(&param->t.rspAckSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RSTRT_DELAY :
             CMCHKPK(cmPkTknU32, &param->t.rstrtDelay,mBuf);
             break;
          case  MGT_PARAM_RSTRT_METHOD :
             CMCHKPK(cmPkTknU8, &param->t.rstrtMethod,mBuf);
             break;
          case  MGT_PARAM_SCND_CONNID :
             ret1 = cmPkMgConnIdSet(&param->t.scndConnIdSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SECND_EPID :
             ret1 = cmPkMgEPName(&param->t.scndEpId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmPkMgSignalRqstSet(&param->t.sigRqstSet,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SPEC_EPID :
             ret1 = cmPkMgEPName(&param->t.specificEpId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_VERSN_SUPRTD :
             ret1 = cmPkMgMgcpVerSet(&param->t.versionsSupp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->paramType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpParam*/
#endif

/*
*
*    Fun:    cmPkMgMgcpParamSet
*
*    Desc:    pack the structure MgMgcpParamSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpParamSet
(
MgMgcpParamSet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpParamSet(param ,mBuf)
MgMgcpParamSet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcpParamSet)

    if( param->numParam.pres != NOTPRSNT )
    {
       for (i=param->numParam.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcpParam,  (param->param[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numParam,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpParamSet*/

/*
*
*    Fun:    cmPkMgMgcpCmd
*
*    Desc:    pack the structure MgMgcpCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpCmd
(
MgMgcpCmd *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpCmd(param ,intfVer, mBuf)
MgMgcpCmd *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpCmd)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpInfoSet(&param->sdpInfo, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMacroTknBuf, &param->sdpStr,mBuf);
       ret1 = cmPkMgMgcpParamSet(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcpCmdLine(&param->cmdLine,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpCmd*/

/*
*
*    Fun:    cmPkMgMsgNonStd
*
*    Desc:    pack the structure MgMsgNonStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMsgNonStd
(
MgMsgNonStd *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMsgNonStd(param ,intfVer, mBuf)
MgMsgNonStd *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMsgNonStd)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcpCmd(&param->cmd, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStr8, &param->cmdName,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMsgNonStd*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmPkMgMgcpSdpInfo
*
*    Desc:    pack the structure MgMgcpSdpInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpSdpInfo
(
MgMgcpSdpInfo *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpSdpInfo(param ,intfVer, mBuf)
MgMgcpSdpInfo *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpSdpInfo)

    ret1 = cmPkCmSdpInfoSet(&param->sdpInfo, intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMacroTknBuf, &param->sdpStr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpSdpInfo*/

/*
*
*    Fun:    cmPkMgMgcpSdpInfoSet
*
*    Desc:    pack the structure MgMgcpSdpInfoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpSdpInfoSet
(
MgMgcpSdpInfoSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpSdpInfoSet(param ,intfVer, mBuf)
MgMgcpSdpInfoSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcpSdpInfoSet)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcpSdpInfo( (param->set[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpSdpInfoSet*/

/*
*
*    Fun:    cmPkMgMgcpRsp
*
*    Desc:    pack the structure MgMgcpRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpRsp
(
MgMgcpRsp *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpRsp(param ,intfVer, mBuf)
MgMgcpRsp *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpRsp)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcpSdpInfoSet(&param->sdpInfo, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcpParamSet(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->rspStr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgPkgName(&param->pkgName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->trId,mBuf);
       CMCHKPK(cmPkTknU32, &param->rspCode,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpRsp*/
#else

/*
*
*    Fun:    cmPkMgMgcpRsp
*
*    Desc:    pack the structure MgMgcpRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpRsp
(
MgMgcpRsp *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpRsp(param ,intfVer, mBuf)
MgMgcpRsp *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpRsp)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkCmSdpInfoSet(&param->sdpInfo, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMacroTknBuf, &param->sdpStr,mBuf);
       ret1 = cmPkMgMgcpParamSet(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->rspStr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->trId,mBuf);
       CMCHKPK(cmPkTknU32, &param->rspCode,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpRsp*/
#endif
#ifdef GCP_PKG_MGCP_BASE

/*
*
*    Fun:    cmPkMgMgcpMsg
*
*    Desc:    pack the structure MgMgcpMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpMsg
(
MgMgcpMsg *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpMsg(param ,intfVer, mBuf)
MgMgcpMsg *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpMsg)

#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif /*    */
    CMCHKPK(cmPkTknU8, &param->dupInfo,mBuf);
    CMCHKPK(cmPkMgLclErr, &param->mgLclErr,mBuf);
    if( param->msgType.pres != NOTPRSNT )
    {
       switch( param->msgType.val )
       {
          case  MGT_MSG_AUCX :
             ret1 = cmPkMgMgcpCmd(&param->t.aucxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_AUEP :
             ret1 = cmPkMgMgcpCmd(&param->t.auepCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_CRCX :
             ret1 = cmPkMgMgcpCmd(&param->t.crcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_DLCX :
             ret1 = cmPkMgMgcpCmd(&param->t.dlcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_EPCF :
             ret1 = cmPkMgMgcpCmd(&param->t.epcfCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MDCX :
             ret1 = cmPkMgMgcpCmd(&param->t.mdcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MESG :
             ret1 = cmPkMgMgcpCmd(&param->t.mesgCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NONE :
             break;
          case  MGT_MSG_NONSTD :
             ret1 = cmPkMgMsgNonStd(&param->t.nonStdCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NTFY :
             ret1 = cmPkMgMgcpCmd(&param->t.ntfyCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RQNT :
             ret1 = cmPkMgMgcpCmd(&param->t.rqntCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSIP :
             ret1 = cmPkMgMgcpCmd(&param->t.rsipCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSP :
             ret1 = cmPkMgMgcpRsp(&param->t.mgcpRsp, intfVer, mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->msgType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpMsg*/
#else /* GCP_PKG_MGCP_BASE */

/*
*
*    Fun:    cmPkMgMgcpMsg
*
*    Desc:    pack the structure MgMgcpMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpMsg
(
MgMgcpMsg *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpMsg(param ,intfVer, mBuf)
MgMgcpMsg *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcpMsg)

#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif /*    */
    CMCHKPK(cmPkTknU8, &param->dupInfo,mBuf);
    CMCHKPK(cmPkMgLclErr, &param->mgLclErr,mBuf);
    if( param->msgType.pres != NOTPRSNT )
    {
       switch( param->msgType.val )
       {
          case  MGT_MSG_AUCX :
             ret1 = cmPkMgMgcpCmd(&param->t.aucxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_AUEP :
             ret1 = cmPkMgMgcpCmd(&param->t.auepCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_CRCX :
             ret1 = cmPkMgMgcpCmd(&param->t.crcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_DLCX :
             ret1 = cmPkMgMgcpCmd(&param->t.dlcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_EPCF :
             ret1 = cmPkMgMgcpCmd(&param->t.epcfCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MDCX :
             ret1 = cmPkMgMgcpCmd(&param->t.mdcxCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NONE :
             break;
          case  MGT_MSG_NONSTD :
             ret1 = cmPkMgMsgNonStd(&param->t.nonStdCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NTFY :
             ret1 = cmPkMgMgcpCmd(&param->t.ntfyCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RQNT :
             ret1 = cmPkMgMgcpCmd(&param->t.rqntCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSIP :
             ret1 = cmPkMgMgcpCmd(&param->t.rsipCmd, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSP :
             ret1 = cmPkMgMgcpRsp(&param->t.mgcpRsp,intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->msgType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpMsg*/
#endif /* GCP_PKG_MGCP_BASE */

/*
*
*    Fun:    cmPkMgMgcpTxn
*
*    Desc:    pack the structure MgMgcpTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcpTxn
(
MgMgcpTxn *param,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcpTxn(param , pst, mBuf)
MgMgcpTxn *param;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcpTxn)

    for (i=param->numMsg-1;i>=0;i--)
    {
       ret1 = cmPkMgMgcpMsg( (param->mgcpMsg[i]), pst->intfVer ,mBuf);
       if(ret1 != ROK)
       {
          SPutMsg(mBuf );
          RETVALUE( ret1 );
       }
       cmFreeMem((Ptr)param->mgcpMsg[i]);
    }
    CMCHKPK(SPkU16, param->numMsg,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->mgLclInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcpTxn*/
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
#ifdef MGT_MGCO_V2

/*
*
*    Fun:    cmPkMgMgcoIndAudStreamParm
*
*    Desc:    pack the structure MgMgcoIndAudStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudStreamParm
(
MgMgcoIndAudStreamParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudStreamParm(param ,mBuf)
MgMgcoIndAudStreamParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudStreamParm)

    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudStreamParm*/

/*
*
*    Fun:    cmPkMgMgcoIndAudStreamDesc
*
*    Desc:    pack the structure MgMgcoIndAudStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudStreamDesc
(
MgMgcoIndAudStreamDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudStreamDesc(param ,mBuf)
MgMgcoIndAudStreamDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudStreamDesc)

    ret1 = cmPkMgMgcoIndAudStreamParm(&param->streamParm,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgMgcoStreamId, &param->streamId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudStreamDesc*/

/*
*
*    Fun:    cmPkMgMgcoIndAudTermStateDesc
*
*    Desc:    pack the structure MgMgcoIndAudTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudTermStateDesc
(
MgMgcoIndAudTermStateDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudTermStateDesc(param ,mBuf)
MgMgcoIndAudTermStateDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudTermStateDesc)

    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudTermStateDesc*/

/*
*
*    Fun:    cmPkMgMgcoIndAudMediaParm
*
*    Desc:    pack the structure MgMgcoIndAudMediaParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudMediaParm
(
MgMgcoIndAudMediaParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudMediaParm(param ,mBuf)
MgMgcoIndAudMediaParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudMediaParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_STPAR :
             ret1 = cmPkMgMgcoIndAudStreamParm(&param->u.streamParm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_STRDESC :
             ret1 = cmPkMgMgcoIndAudStreamDesc(&param->u.streamDesc,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_TERSTDESC :
             ret1 = cmPkMgMgcoIndAudTermStateDesc(&param->u.termStateDesc,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudMediaParm*/

/*
*
*    Fun:    cmPkMgMgcoIndAudEvents
*
*    Desc:    pack the structure MgMgcoIndAudEvents
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudEvents
(
MgMgcoIndAudEvents *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudEvents(param ,mBuf)
MgMgcoIndAudEvents *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudEvents)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
       CMCHKPK(cmPkMgMgcoRequestId, &param->request,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudEvents*/

/*
*
*    Fun:    cmPkMgMgcoIndAudSigLst
*
*    Desc:    pack the structure MgMgcoIndAudSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudSigLst
(
MgMgcoIndAudSigLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudSigLst(param ,mBuf)
MgMgcoIndAudSigLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudSigLst)

    ret1 = cmPkMgMgcoSigName(&param->sigName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU16, &param->sigLstId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudSigLst*/

/*
*
*    Fun:    cmPkMgMgcoIndAudSignals
*
*    Desc:    pack the structure MgMgcoIndAudSignals
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudSignals
(
MgMgcoIndAudSignals *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudSignals(param ,mBuf)
MgMgcoIndAudSignals *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudSignals)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_SIGLST :
             ret1 = cmPkMgMgcoIndAudSigLst(&param->u.sigList,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_SIGNAME :
             ret1 = cmPkMgMgcoSigName(&param->u.sigName,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudSignals*/

/*
*
*    Fun:    cmPkMgMgcoIndAudEventSpecParm
*
*    Desc:    pack the structure MgMgcoIndAudEventSpecParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudEventSpecParm
(
MgMgcoIndAudEventSpecParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudEventSpecParm(param ,mBuf)
MgMgcoIndAudEventSpecParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudEventSpecParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_EVPRM :
             ret1 = cmPkMgMgcoName(&param->u.evParmName,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_EVSTREAM :
             CMCHKPK(cmPkMgMgcoStreamId, &param->u.evStream,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudEventSpecParm*/

/*
*
*    Fun:    cmPkMgMgcoIndAudEventBuffer
*
*    Desc:    pack the structure MgMgcoIndAudEventBuffer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudEventBuffer
(
MgMgcoIndAudEventBuffer *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudEventBuffer(param ,mBuf)
MgMgcoIndAudEventBuffer *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudEventBuffer)

    ret1 = cmPkMgMgcoIndAudEventSpecParm(&param->evSpecParm,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudEventBuffer*/

/*
*
*    Fun:    cmPkMgMgcoIndAudAuditRetParm
*
*    Desc:    pack the structure MgMgcoIndAudAuditRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudAuditRetParm
(
MgMgcoIndAudAuditRetParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudAuditRetParm(param ,mBuf)
MgMgcoIndAudAuditRetParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoIndAudAuditRetParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_AUDDIGITMAP :
             ret1 = cmPkMgMgcoName(&param->u.audDigMap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDEVTBUF :
             ret1 = cmPkMgMgcoIndAudEventBuffer(&param->u.audEvtBuf,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDEVTS :
             ret1 = cmPkMgMgcoIndAudEvents(&param->u.audEvents,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDMEDIA :
             ret1 = cmPkMgMgcoIndAudMediaParm(&param->u.audMedia,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDPKG :
             ret1 = cmPkMgMgcoIndAudPackages(&param->u.audPkgs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDSIG :
             ret1 = cmPkMgMgcoIndAudSignals(&param->u.audSignals,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDSTAT :
             ret1 = cmPkMgMgcoIndAudStatistics(&param->u.audStats,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudAuditRetParm*/

/*
*
*    Fun:    cmPkMgMgcoIndAudTermAudit
*
*    Desc:    pack the structure MgMgcoIndAudTermAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIndAudTermAudit
(
MgMgcoIndAudTermAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIndAudTermAudit(param ,mBuf)
MgMgcoIndAudTermAudit *param;
Buffer *mBuf;
#endif
{
    S16  ret1;
    Cntr i;
    TRC3(cmPkMgMgcoIndAudTermAudit)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoIndAudAuditRetParm( (param->parm[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }    

    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIndAudTermAudit*/
#endif /* MGT_MGCO_V2 */
#ifdef MGT_MGCO_V2

/*
*
*    Fun:    cmPkMgMgcoAuditItem
*
*    Desc:    pack the structure MgMgcoAuditItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAuditItem
(
MgMgcoAuditItem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAuditItem(param ,mBuf)
MgMgcoAuditItem *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAuditItem)

    ret1 = cmPkMgMgcoIndAudTermAudit(&param->termAudit,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->auditItem,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAuditItem*/
#endif /* MGT_MGCO_V2 */

/*
*
*    Fun:    cmPkMgMgcoRequestId
*
*    Desc:    pack the structure MgMgcoRequestId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoRequestId
(
MgMgcoRequestId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoRequestId(param ,mBuf)
MgMgcoRequestId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoRequestId)

    CMCHKPK(cmPkTknU32, &param->id,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoRequestId*/

/*
*
*    Fun:    cmPkMgMgcoContextId
*
*    Desc:    pack the structure MgMgcoContextId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoContextId
(
MgMgcoContextId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoContextId(param ,mBuf)
MgMgcoContextId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoContextId)

    CMCHKPK(cmPkTknU32, &param->val,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoContextId*/

/*
*
*    Fun:    cmPkMgMgcoPathName
*
*    Desc:    pack the structure MgMgcoPathName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPathName
(
MgMgcoPathName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPathName(param ,mBuf)
MgMgcoPathName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPathName)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->dom,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->lcl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPathName*/

/* 002.main_14: Added wildcard support in Termination id for GCP_ASN */

#ifdef GCP_ASN
/*
*
*    Fun:    cmPkMgMgcoWildcard
*
*    Desc:    pack the structure MgMgcoWildcard
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoWildcard
(
MgMgcoWildcard *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoWildcard(param ,mBuf)
MgMgcoWildcard *param;
Buffer *mBuf;
#endif
{
    Cntr  i;
    TRC3(cmPkMgMgcoWildcard)

    if( param->num.pres == PRSNT_NODEF )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknStr4,  (param->wildcard[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);   

    RETVALUE(ROK);
} /*end of function cmPkMgMgcoWildcard*/
#endif /* GCP_ASN */

/*
*
*    Fun:    cmPkMgMgcoTermId
*
*    Desc:    pack the structure MgMgcoTermId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTermId
(
MgMgcoTermId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTermId(param ,mBuf)
MgMgcoTermId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTermId)
       
/* 002.main_14: Added wildcard support in Termination id for GCP_ASN */
#ifdef GCP_ASN       
    ret1 = cmPkMgMgcoWildcard(&param->wildcard,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#endif /* GCP_ASN */

    ret1 = cmPkMgMgcoPathName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTermId*/

/*
*
*    Fun:    cmPkMgMgcoTermIdLst
*
*    Desc:    pack the structure MgMgcoTermIdLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTermIdLst
(
MgMgcoTermIdLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTermIdLst(param ,mBuf)
MgMgcoTermIdLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoTermIdLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoTermId,  (param->terms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTermIdLst*/

/*
*
*    Fun:    cmPkMgMgcoTimeStamp
*
*    Desc:    pack the structure MgMgcoTimeStamp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTimeStamp
(
MgMgcoTimeStamp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTimeStamp(param ,mBuf)
MgMgcoTimeStamp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoTimeStamp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStr8, &param->time,mBuf);
       CMCHKPK(cmPkTknStr8, &param->date,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTimeStamp*/

/*
*
*    Fun:    cmPkMgMgcoName
*
*    Desc:    pack the structure MgMgcoName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoName
(
MgMgcoName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoName(param ,mBuf)
MgMgcoName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoName)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_GEN_TYPE_ALL :
             break;
          case  MGT_GEN_TYPE_KNOWN :
             CMCHKPK(cmPkTknU8, &param->u.val,mBuf);
             break;
          case  MGT_GEN_TYPE_UNKNOWN :
             ret1 = cmPkMacroTknStrOSXL(&param->u.str,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoName*/

/*
*
*    Fun:    cmPkMgMgcoPkgdName
*
*    Desc:    pack the structure MgMgcoPkgdName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPkgdName
(
MgMgcoPkgdName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPkgdName(param ,mBuf)
MgMgcoPkgdName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPkgdName)

    ret1 = cmPkMgMgcoName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMacroTknStrOSXL(&param->pkgName,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPkgdName*/

/*
*
*    Fun:    cmPkMgMgcoSigName
*
*    Desc:    pack the structure MgMgcoSigName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSigName
(
MgMgcoSigName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSigName(param ,mBuf)
MgMgcoSigName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSigName)

    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSigName*/

/*
*
*    Fun:    cmPkMgMgcoSigLst
*
*    Desc:    pack the structure MgMgcoSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSigLst
(
MgMgcoSigLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSigLst(param ,mBuf)
MgMgcoSigLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoSigLst)

    if( param->numSigs.pres != NOTPRSNT )
    {
       for (i=param->numSigs.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoSigName,  (param->sigs[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numSigs,mBuf);
    CMCHKPK(cmPkTknU16, &param->id,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSigLst*/
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 

/*
*
*    Fun:    cmPkMgMgcoFileUrl
*
*    Desc:    pack the structure MgMgcoFileUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoFileUrl
(
MgMgcoFileUrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoFileUrl(param ,mBuf)
MgMgcoFileUrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoFileUrl)

    ret1 = cmPkMacroTknStrOSXL(&param->fpath,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMacroTknStrOSXL(&param->host,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoFileUrl*/

/*
*
*    Fun:    cmPkMgMgcoHostPort
*
*    Desc:    pack the structure MgMgcoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoHostPort
(
MgMgcoHostPort *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoHostPort(param ,mBuf)
MgMgcoHostPort *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoHostPort)

    CMCHKPK(cmPkTknU32, &param->port,mBuf);
    ret1 = cmPkMacroTknStrOSXL(&param->host,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoHostPort*/

/*
*
*    Fun:    cmPkMgMgcoUsrPw
*
*    Desc:    pack the structure MgMgcoUsrPw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoUsrPw
(
MgMgcoUsrPw *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoUsrPw(param ,mBuf)
MgMgcoUsrPw *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoUsrPw)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->pswd,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->user,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoUsrPw*/

/*
*
*    Fun:    cmPkMgMgcoLogin
*
*    Desc:    pack the structure MgMgcoLogin
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoLogin
(
MgMgcoLogin *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoLogin(param ,mBuf)
MgMgcoLogin *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoLogin)

    ret1 = cmPkMgMgcoHostPort(&param->hp,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoUsrPw(&param->usrPw,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoLogin*/

/*
*
*    Fun:    cmPkMgMgcoPathType
*
*    Desc:    pack the structure MgMgcoPathType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPathType
(
MgMgcoPathType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPathType(param ,mBuf)
MgMgcoPathType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPathType)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->ftpType,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->fpath,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPathType*/

/*
*
*    Fun:    cmPkMgMgcoFtpUrl
*
*    Desc:    pack the structure MgMgcoFtpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoFtpUrl
(
MgMgcoFtpUrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoFtpUrl(param ,mBuf)
MgMgcoFtpUrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoFtpUrl)

    ret1 = cmPkMgMgcoPathType(&param->patTyp,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoLogin(&param->login,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoFtpUrl*/

/*
*
*    Fun:    cmPkMgMgcoPathSearch
*
*    Desc:    pack the structure MgMgcoPathSearch
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPathSearch
(
MgMgcoPathSearch *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPathSearch(param ,mBuf)
MgMgcoPathSearch *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPathSearch)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->search,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMacroTknStrOSXL(&param->hpath,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPathSearch*/

/*
*
*    Fun:    cmPkMgMgcoHttpUrl
*
*    Desc:    pack the structure MgMgcoHttpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoHttpUrl
(
MgMgcoHttpUrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoHttpUrl(param ,mBuf)
MgMgcoHttpUrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoHttpUrl)

    ret1 = cmPkMgMgcoPathSearch(&param->ps,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoHostPort(&param->hp,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoHttpUrl*/

/*
*
*    Fun:    cmPkMgMgcoProvSegSpec
*
*    Desc:    pack the structure MgMgcoProvSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoProvSegSpec
(
MgMgcoProvSegSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoProvSegSpec(param ,mBuf)
MgMgcoProvSegSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoProvSegSpec)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_FILE_URL :
             ret1 = cmPkMgMgcoFileUrl(&param->u.file,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_FTP_URL :
             ret1 = cmPkMgMgcoFtpUrl(&param->u.ftp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_HTTP_URL :
             ret1 = cmPkMgMgcoHttpUrl(&param->u.http,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_SIMPLE :
             ret1 = cmPkMacroTknStrOSXL(&param->u.simple,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoProvSegSpec*/

/*
*
*    Fun:    cmPkMgMgcoTodSpec
*
*    Desc:    pack the structure MgMgcoTodSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTodSpec
(
MgMgcoTodSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTodSpec(param ,mBuf)
MgMgcoTodSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoTodSpec)

    CMCHKPK(cmPkTknU16, &param->time,mBuf);
    CMCHKPK(cmPkTknU8, &param->subType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTodSpec*/

/*
*
*    Fun:    cmPkMgMgcoDateSpec
*
*    Desc:    pack the structure MgMgcoDateSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDateSpec
(
MgMgcoDateSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDateSpec(param ,mBuf)
MgMgcoDateSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoDateSpec)

    CMCHKPK(cmPkTknU32, &param->date,mBuf);
    CMCHKPK(cmPkTknU8, &param->dateOrder,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDateSpec*/

/*
*
*    Fun:    cmPkMgMgcoMoneySpec
*
*    Desc:    pack the structure MgMgcoMoneySpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMoneySpec
(
MgMgcoMoneySpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMoneySpec(param ,mBuf)
MgMgcoMoneySpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoMoneySpec)

    CMCHKPK(cmPkTknS32, &param->val,mBuf);
    CMCHKPK(cmPkTknStr8, &param->curType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMoneySpec*/

/*
*
*    Fun:    cmPkMgMgcoIntSpec
*
*    Desc:    pack the structure MgMgcoIntSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoIntSpec
(
MgMgcoIntSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoIntSpec(param ,mBuf)
MgMgcoIntSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoIntSpec)

    CMCHKPK(cmPkTknS32, &param->val,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoIntSpec*/

/*
*
*    Fun:    cmPkMgMgcoVvarSpec
*
*    Desc:    pack the structure MgMgcoVvarSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoVvarSpec
(
MgMgcoVvarSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoVvarSpec(param ,mBuf)
MgMgcoVvarSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoVvarSpec)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_CHAR_SPEC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.chr,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_DATE_SPEC :
             CMCHKPK(cmPkMgMgcoDateSpec, &param->u.date,mBuf);
             break;
          case  MGT_MGCO_DIG_SPEC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.dig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_DOW_SPEC :
             CMCHKPK(cmPkTknU8, &param->u.dow,mBuf);
             break;
          case  MGT_MGCO_DUR_SPEC :
             CMCHKPK(cmPkTknU32, &param->u.dur,mBuf);
             break;
          case  MGT_MGCO_HUSH_SPEC :
             CMCHKPK(cmPkTknU16, &param->u.hush,mBuf);
             break;
          case  MGT_MGCO_INT_SPEC :
             CMCHKPK(cmPkMgMgcoIntSpec, &param->u.integer,mBuf);
             break;
          case  MGT_MGCO_MONEY_SPEC :
             CMCHKPK(cmPkMgMgcoMoneySpec, &param->u.money,mBuf);
             break;
          case  MGT_MGCO_MONTH_SPEC :
             CMCHKPK(cmPkTknU8, &param->u.month,mBuf);
             break;
          case  MGT_MGCO_PHRASE_SPEC :
             ret1 = cmPkMacroTknStrOSXL(&param->u.phrase,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_TOD_SPEC :
             CMCHKPK(cmPkMgMgcoTodSpec, &param->u.tod,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoVvarSpec*/

/*
*
*    Fun:    cmPkMgMgcoSelType
*
*    Desc:    pack the structure MgMgcoSelType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSelType
(
MgMgcoSelType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSelType(param ,mBuf)
MgMgcoSelType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSelType)

    ret1 = cmPkMacroTknStrOSXL(&param->other,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSelType*/

/*
*
*    Fun:    cmPkMgMgcoSelSpecLst
*
*    Desc:    pack the structure MgMgcoSelSpecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSelSpecLst
(
MgMgcoSelSpecLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSelSpecLst(param ,mBuf)
MgMgcoSelSpecLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSelSpecLst)

    ret1 = cmPkMacroTknStrOSXL(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoSelType(&param->type,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSelSpecLst*/

/*
*
*    Fun:    cmPkMgMgcoSelList
*
*    Desc:    pack the structure MgMgcoSelList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSelList
(
MgMgcoSelList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSelList(param ,mBuf)
MgMgcoSelList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoSelList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoSelSpecLst,  (param->selSpec[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSelList*/

/*
*
*    Fun:    cmPkMgMgcoVarSegSpec
*
*    Desc:    pack the structure MgMgcoVarSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoVarSegSpec
(
MgMgcoVarSegSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoVarSegSpec(param ,mBuf)
MgMgcoVarSegSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoVarSegSpec)

    ret1 = cmPkMgMgcoSelList(&param->selList,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoVvarSpec(&param->vvarSpec,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoVarSegSpec*/

/*
*
*    Fun:    cmPkMgMgcoSpec
*
*    Desc:    pack the structure MgMgcoSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSpec
(
MgMgcoSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSpec(param ,mBuf)
MgMgcoSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSpec)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_PROV_SEG_SPEC :
             ret1 = cmPkMgMgcoProvSegSpec(&param->u.provSs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_VAR_SEG_SPEC :
             ret1 = cmPkMgMgcoVarSegSpec(&param->u.staSs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSpec*/

/*
*
*    Fun:    cmPkMgMgcoSegSpec
*
*    Desc:    pack the structure MgMgcoSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSegSpec
(
MgMgcoSegSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSegSpec(param ,mBuf)
MgMgcoSegSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSegSpec)

    ret1 = cmPkMgMgcoSpec(&param->spec,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->keyword,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSegSpec*/

/*
*
*    Fun:    cmPkMgMgcoAnncSpec
*
*    Desc:    pack the structure MgMgcoAnncSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAnncSpec
(
MgMgcoAnncSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAnncSpec(param ,mBuf)
MgMgcoAnncSpec *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoAnncSpec)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoSegSpec,  (param->segSpec[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAnncSpec*/
#endif

/*
*
*    Fun:    cmPkMgMgcoValue
*
*    Desc:    pack the structure MgMgcoValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoValue
(
MgMgcoValue *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoValue(param ,mBuf)
MgMgcoValue *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoValue)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 
          case  MGT_VALTYPE_ADV_AUD_PROVSEGSPEC :
             ret1 = cmPkMgMgcoProvSegSpec(&param->u.prSpec,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_ADV_AUD_SEGLST :
             ret1 = cmPkMgMgcoAnncSpec(&param->u.anSpec,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*    */
#ifdef GCP_ENUM_U32
          case  MGT_VALTYPE_ENUM :
             CMCHKPK(cmPkTknU32, &param->u.enume,mBuf);
             break;
#else
          case  MGT_VALTYPE_ENUM :
             CMCHKPK(cmPkTknU8, &param->u.enume,mBuf);
             break;
#endif
#ifdef GCP_ASN
         /* mgt_c_004.main_14: boolean field is added in MgMgcoValue union */
          case  MGT_VALTYPE_BOOL:
             CMCHKPK(cmPkTknU8, &param->u.boole,mBuf);
             break;
#endif
          case  MGT_VALTYPE_HEX_SINT32 :
             CMCHKPK(cmPkTknS32, &param->u.hexSint,mBuf);
             break;
          case  MGT_VALTYPE_HEX_UINT32 :
             CMCHKPK(cmPkTknU32, &param->u.hexInt,mBuf);
             break;
          case  MGT_VALTYPE_OCTSTRXL :
             ret1 = cmPkMacroTknStrOSXL(&param->u.osxl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SIGLST :
             ret1 = cmPkMgMgcoSigLst(&param->u.sigLst,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SIGNAME :
             ret1 = cmPkMgMgcoSigName(&param->u.sigName,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SINT32 :
             CMCHKPK(cmPkTknS32, &param->u.decSint,mBuf);
             break;
          case  MGT_VALTYPE_TERMID :
             ret1 = cmPkMgMgcoTermId(&param->u.termId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_TERMIDLST :
             ret1 = cmPkMgMgcoTermIdLst(&param->u.termIdLst,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_TKNBUF :
             CMCHKPK(cmPkMacroTknBuf, &param->u.mBuf,mBuf);
             break;
          case  MGT_VALTYPE_UINT32 :
             CMCHKPK(cmPkTknU32, &param->u.decInt,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoValue*/

/*
*
*    Fun:    cmPkMgMgcoAuthHdr
*
*    Desc:    pack the structure MgMgcoAuthHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAuthHdr
(
MgMgcoAuthHdr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAuthHdr(param ,mBuf)
MgMgcoAuthHdr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAuthHdr)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoAuthData(&param->aData,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoSequenceNum, &param->sn,mBuf);
       CMCHKPK(cmPkMgMgcoSecParmIndex, &param->spi,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAuthHdr*/

/*
*
*    Fun:    cmPkMgMgcoDomAddrPort
*
*    Desc:    pack the structure MgMgcoDomAddrPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDomAddrPort
(
MgMgcoDomAddrPort *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDomAddrPort(param ,mBuf)
MgMgcoDomAddrPort *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDomAddrPort)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->port,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_IPV4 :
                ret1 = cmPkMacroTknStrOSXL(&param->u.ipv4,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_IPV6 :
                ret1 = cmPkMacroTknStrOSXL(&param->u.ipv6,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDomAddrPort*/

/*
*
*    Fun:    cmPkMgMgcoDomNamePort
*
*    Desc:    pack the structure MgMgcoDomNamePort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDomNamePort
(
MgMgcoDomNamePort *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDomNamePort(param ,mBuf)
MgMgcoDomNamePort *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDomNamePort)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->port,mBuf);
       ret1 = cmPkMacroTknStrOSXL(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDomNamePort*/

/*
*
*    Fun:    cmPkMgMgcoMid
*
*    Desc:    pack the structure MgMgcoMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMid
(
MgMgcoMid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMid(param ,mBuf)
MgMgcoMid *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMid)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MID_DADDRPORT :
             ret1 = cmPkMgMgcoDomAddrPort(&param->u.dAddrPort,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_DEVICE :
             ret1 = cmPkMgMgcoDevName(&param->u.dev,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_DNAMEPORT :
             ret1 = cmPkMgMgcoDomNamePort(&param->u.dNamePort,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_MTPADDR :
             CMCHKPK(cmPkMgMgcoMtpAddr, &param->u.mtpAddr,mBuf);
             break;
          case  MGT_MID_PORT :
             CMCHKPK(cmPkTknU16, &param->u.port,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMid*/

/*
*
*    Fun:    cmPkMgMgcoErrDesc
*
*    Desc:    pack the structure MgMgcoErrDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoErrDesc
(
MgMgcoErrDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoErrDesc(param ,mBuf)
MgMgcoErrDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoErrDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->text,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->code,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoErrDesc*/

/*
*
*    Fun:    cmPkMgMgcoTopoDesc
*
*    Desc:    pack the structure MgMgcoTopoDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTopoDesc
(
MgMgcoTopoDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTopoDesc(param ,mBuf)
MgMgcoTopoDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTopoDesc)

    if(param->pres.pres != NOTPRSNT)
    {
#ifdef MGT_MGCO_V2
       CMCHKPK(cmPkMgMgcoStreamId, &param->streamId,mBuf);
#endif /*  MGT_MGCO_V2  */
       CMCHKPK(cmPkTknU8, &param->dir,mBuf);
       ret1 = cmPkMgMgcoTermId(&param->to,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->from,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTopoDesc*/

/*
*
*    Fun:    cmPkMgMgcoTopoDescLst
*
*    Desc:    pack the structure MgMgcoTopoDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTopoDescLst
(
MgMgcoTopoDescLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTopoDescLst(param ,mBuf)
MgMgcoTopoDescLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoTopoDescLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoTopoDesc,  (param->descs[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTopoDescLst*/

/*
*
*    Fun:    cmPkMgMgcoContextProps
*
*    Desc:    pack the structure MgMgcoContextProps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoContextProps
(
MgMgcoContextProps *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoContextProps(param ,mBuf)
MgMgcoContextProps *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoContextProps)

    if(param->pres.pres != NOTPRSNT)
    {
#ifdef    MGT_GCP_VER_1_4
       CMCHKPK(cmPkTknPres, &param->emergOff,mBuf);
#endif /* MGT_GCP_VER_1_4 */
       ret1 = cmPkMgMgcoTopoDescLst(&param->tl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknPres, &param->emerg,mBuf);
       CMCHKPK(cmPkTknU16, &param->pri,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoContextProps*/

/*
*
*    Fun:    cmPkMgMgcoContextAudit
*
*    Desc:    pack the structure MgMgcoContextAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoContextAudit
(
MgMgcoContextAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoContextAudit(param ,mBuf)
MgMgcoContextAudit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoContextAudit)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknPres, &param->pri,mBuf);
       CMCHKPK(cmPkTknPres, &param->emerg,mBuf);
       CMCHKPK(cmPkTknPres, &param->topo,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoContextAudit*/

/*
*
*    Fun:    cmPkMgMgcoValLst
*
*    Desc:    pack the structure MgMgcoValLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoValLst
(
MgMgcoValLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoValLst(param ,mBuf)
MgMgcoValLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoValLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoValue,  (param->vals[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoValLst*/

/*
*
*    Fun:    cmPkMgMgcoValRng
*
*    Desc:    pack the structure MgMgcoValRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoValRng
(
MgMgcoValRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoValRng(param ,mBuf)
MgMgcoValRng *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoValRng)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoValue(&param->up,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoValue(&param->low,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoValRng*/

/*
*
*    Fun:    cmPkMgMgcoParmValue
*
*    Desc:    pack the structure MgMgcoParmValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoParmValue
(
MgMgcoParmValue *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoParmValue(param ,mBuf)
MgMgcoParmValue *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoParmValue)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_VALUE_AND :
             ret1 = cmPkMgMgcoValLst(&param->u.and,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_EQUAL :
             ret1 = cmPkMgMgcoValue(&param->u.eq,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_GREATERTHAN :
             ret1 = cmPkMgMgcoValue(&param->u.gt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_LESSTHAN :
             ret1 = cmPkMgMgcoValue(&param->u.lt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_NOTEQUAL :
             ret1 = cmPkMgMgcoValue(&param->u.ne,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_OR :
             ret1 = cmPkMgMgcoValLst(&param->u.or,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_RANGE :
             ret1 = cmPkMgMgcoValRng(&param->u.rng,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoParmValue*/

/*
*
*    Fun:    cmPkMgMgcoPropParm
*
*    Desc:    pack the structure MgMgcoPropParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPropParm
(
MgMgcoPropParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPropParm(param ,mBuf)
MgMgcoPropParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPropParm)

    ret1 = cmPkMgMgcoParmValue(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPropParm*/

/*
*
*    Fun:    cmPkMgMgcoPropParmLst
*
*    Desc:    pack the structure MgMgcoPropParmLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPropParmLst
(
MgMgcoPropParmLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPropParmLst(param ,mBuf)
MgMgcoPropParmLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoPropParmLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoPropParm,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPropParmLst*/

/*
*
*    Fun:    cmPkMgMgcoLocalParm
*
*    Desc:    pack the structure MgMgcoLocalParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoLocalParm
(
MgMgcoLocalParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoLocalParm(param ,mBuf)
MgMgcoLocalParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoLocalParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_LCLCTL_MODE :
             CMCHKPK(cmPkTknU8, &param->u.mode,mBuf);
             break;
          case  MGT_LCLCTL_PROPPARM :
             ret1 = cmPkMgMgcoPropParm(&param->u.propParm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCLCTL_RESGRP :
             CMCHKPK(cmPkTknU8, &param->u.resGrp,mBuf);
             break;
          case  MGT_LCLCTL_RESVAL :
             CMCHKPK(cmPkTknU8, &param->u.resVal,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoLocalParm*/

/*
*
*    Fun:    cmPkMgMgcoLclCtlDesc
*
*    Desc:    pack the structure MgMgcoLclCtlDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoLclCtlDesc
(
MgMgcoLclCtlDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoLclCtlDesc(param ,mBuf)
MgMgcoLclCtlDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoLclCtlDesc)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoLocalParm,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoLclCtlDesc*/

/*
*
*    Fun:    cmPkMgMgcoPropGrpLst
*
*    Desc:    pack the structure MgMgcoPropGrpLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPropGrpLst
(
MgMgcoPropGrpLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPropGrpLst(param ,mBuf)
MgMgcoPropGrpLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoPropGrpLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoPropParmLst,  (param->grps[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPropGrpLst*/

/*
*
*    Fun:    cmPkMgMgcoLocalDesc
*
*    Desc:    pack the structure MgMgcoLocalDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoLocalDesc
(
MgMgcoLocalDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoLocalDesc(param ,intfVer, mBuf)
MgMgcoLocalDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoLocalDesc)

    if(param->pres.pres != NOTPRSNT)
    {
/* 002.main_14: Added Annex C support in GCP_ASN */
#ifdef GCP_ASN
       ret1 = cmPkMgMgcoPropGrpLst(&param->annexCParmLst, mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /* GCP_ASN */      
       ret1 = cmPkCmSdpInfoSet(&param->sdp, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMacroTknBuf, &param->sdpStr,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoLocalDesc*/

/*
*
*    Fun:    cmPkMgMgcoTermStateParm
*
*    Desc:    pack the structure MgMgcoTermStateParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTermStateParm
(
MgMgcoTermStateParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTermStateParm(param ,mBuf)
MgMgcoTermStateParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTermStateParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TERMST_EVTBUFCTL :
             CMCHKPK(cmPkMgMgcoEvtBufCtl, &param->u.evtBufCtl,mBuf);
             break;
          case  MGT_TERMST_PROPLST :
             ret1 = cmPkMgMgcoPropParm(&param->u.parm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TERMST_SVCST :
             CMCHKPK(cmPkMgMgcoSvcState, &param->u.svcState,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTermStateParm*/

/*
*
*    Fun:    cmPkMgMgcoTermStateDesc
*
*    Desc:    pack the structure MgMgcoTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTermStateDesc
(
MgMgcoTermStateDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTermStateDesc(param ,intfVer, mBuf)
MgMgcoTermStateDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Cntr i; 
    S16 ret1;
    TknPres locPres;
    CmIntfVer   verDelta;   
                                  
    TRC3(cmPkMgMgcoTermStateDesc)

     /*
     * 001.main_9 :- addition of a switch case statement based
     * on the remote interface version.
     */

#ifdef MG_RUG  /* 002.main_9 : now code is protocol independent */
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */

    switch(verDelta)
    {
       case 0 :
               /*
                * remote ver is same as ours (latest). So pack as latest.
                * this part is the generated code
                */                                            
    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoTermStateParm,  (param->trmStPar[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf); 
               break;

       case 1 :
               /*
                * 001.main_9 : pack occording to the lower version;
                * pack iff param->numComp has non zero array elements
                */
               if((param->numComp.pres == PRSNT_NODEF) && (param->numComp.val))
               {
                  U8                   parmIdx;
                  U8                   EvBfIdx;
                  U8                   SvStIdx;
                  Bool                 foundParm;
                  Bool                 foundEvBf;
                  Bool                 foundSvSt;

                  locPres.pres = PRSNT_NODEF;

                  foundParm = FALSE; /* found the MgMgcoPropParm parameter? */
                  foundEvBf = FALSE; /* found the MgMgcoEvtBufCtl parameter? */
                  foundSvSt = FALSE; /* found the MgMgcoSvcState parameter? */

                  /*
                   * There can be at most only one occurance of the
                   * following paramters -
                   * MgMgcoEvtBufCtl and MgMgcoSvcState
                   * but multiple occurances of MgMgcoPropParm parameter.
                   */
                  for (i=param->numComp.val-1;i>=0;i--)
                  {
                     if(param->trmStPar[i]->type.val
                              == MGT_TERMST_EVTBUFCTL)
                     {
                        EvBfIdx = i;
                        foundEvBf = TRUE;
                     }
                     else if(param->trmStPar[i]->type.val
                              == MGT_TERMST_SVCST)
                     {
                        SvStIdx = i;
                        foundSvSt = TRUE;
                     }
                     else if(param->trmStPar[i]->type.val
                              == MGT_TERMST_PROPLST)
                     {
                        if(foundParm == TRUE)
                        {
                        /*
                         * If we encountered a MgMgcoPropParm previously then
                         * this =>s that there are multiple MgMgcoPropParms;
                         * But the older MGT version supports only one such
                         * parameter. Therefore, we ignore the remaining
                         * MgMgcoPropParm type of parameters & pack the first
                         * MgMgcoPropParm only.
                         */
                           continue;
                        }
                        else
                        {
                           parmIdx = i;
                           foundParm = TRUE;
                        }

                     }

                  }

                  if(foundParm == TRUE)
                  {
                     ret1 = cmPkMgMgcoPropParm(&param->trmStPar\
                                       [parmIdx]->u.parm,mBuf);
                     if (ret1 != ROK)
                     {
                        RETVALUE(RFAILED);
                     }
                  }

                  if(foundSvSt == TRUE)
                  {
                     CMCHKPK(cmPkMgMgcoSvcState, &param->trmStPar\
                                      [SvStIdx]->u.svcState,mBuf);
                  }

                  if(foundEvBf == TRUE)
                  {
                     CMCHKPK(cmPkMgMgcoEvtBufCtl, &param->trmStPar\
                                      [EvBfIdx]->u.evtBufCtl,mBuf);
                  }

               }
               else
               {
                  locPres.pres = NOTPRSNT;
               }

               CMCHKPK(cmPkTknPres, &locPres,mBuf);
               break;

       default :
                RETVALUE(RFAILED);
               break;
    }                                                         
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTermStateDesc*/

/*
*
*    Fun:    cmPkMgMgcoStreamParm
*
*    Desc:    pack the structure MgMgcoStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoStreamParm
(
MgMgcoStreamParm *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoStreamParm(param ,intfVer, mBuf)
MgMgcoStreamParm *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoStreamParm)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoRemoteDesc(&param->remote, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoLocalDesc(&param->local, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoLclCtlDesc(&param->locCtl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoStreamParm*/

/*
*
*    Fun:    cmPkMgMgcoStreamDesc
*
*    Desc:    pack the structure MgMgcoStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoStreamDesc
(
MgMgcoStreamDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoStreamDesc(param ,intfVer, mBuf)
MgMgcoStreamDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoStreamDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoStreamParm(&param->sl, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoStreamId, &param->streamId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoStreamDesc*/

/*
*
*    Fun:    cmPkMgMgcoMediaPar
*
*    Desc:    pack the structure MgMgcoMediaPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMediaPar
(
MgMgcoMediaPar *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMediaPar(param ,intfVer, mBuf)
MgMgcoMediaPar *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMediaPar)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MEDIAPAR_LOCAL :
             ret1 = cmPkMgMgcoLocalDesc(&param->u.local, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_LOCCTL :
             ret1 = cmPkMgMgcoLclCtlDesc(&param->u.locCtl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_REMOTE :
             ret1 = cmPkMgMgcoRemoteDesc(&param->u.remote, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_STRPAR :
             ret1 = cmPkMgMgcoStreamDesc(&param->u.stream, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_TERMST :
             ret1 = cmPkMgMgcoTermStateDesc(&param->u.tstate, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMediaPar*/

/*
*
*    Fun:    cmPkMgMgcoMediaDesc
*
*    Desc:    pack the structure MgMgcoMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMediaDesc
(
MgMgcoMediaDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMediaDesc(param ,intfVer, mBuf)
MgMgcoMediaDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoMediaDesc)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoMediaPar( (param->parms[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMediaDesc*/

/*
*
*    Fun:    cmPkMgMgcoH221NonStd
*
*    Desc:    pack the structure MgMgcoH221NonStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoH221NonStd
(
MgMgcoH221NonStd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoH221NonStd(param ,mBuf)
MgMgcoH221NonStd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoH221NonStd)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->mfc,mBuf);
       CMCHKPK(cmPkTknU8, &param->t35ext,mBuf);
       CMCHKPK(cmPkTknU8, &param->t35cc2,mBuf);
       CMCHKPK(cmPkTknU8, &param->t35cc1,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoH221NonStd*/

/*
*
*    Fun:    cmPkMgMgcoNonStdId
*
*    Desc:    pack the structure MgMgcoNonStdId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoNonStdId
(
MgMgcoNonStdId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoNonStdId(param ,mBuf)
MgMgcoNonStdId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoNonStdId)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EXTNPARM_MAND :
             CMCHKPK(cmPkTknStr8, &param->u.extn,mBuf);
             break;
          case  MGT_EXTNPARM_OPT :
             CMCHKPK(cmPkTknStr8, &param->u.extn,mBuf);
             break;
          case  MGT_NONSTD_H221 :
             CMCHKPK(cmPkMgMgcoH221NonStd, &param->u.h221,mBuf);
             break;
          case  MGT_NONSTD_OBJID :
             ret1 = cmPkMgMgcoObjId(&param->u.objId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoNonStdId*/

/*
*
*    Fun:    cmPkMgMgcoModemType
*
*    Desc:    pack the structure MgMgcoModemType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoModemType
(
MgMgcoModemType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoModemType(param ,mBuf)
MgMgcoModemType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoModemType)

    ret1 = cmPkMgMgcoNonStdId(&param->extnId,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoModemType*/

/*
*
*    Fun:    cmPkMgMgcoModemTypeLst
*
*    Desc:    pack the structure MgMgcoModemTypeLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoModemTypeLst
(
MgMgcoModemTypeLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoModemTypeLst(param ,mBuf)
MgMgcoModemTypeLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoModemTypeLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoModemType,  (param->modems[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoModemTypeLst*/

/*
*
*    Fun:    cmPkMgMgcoNonStdExtn
*
*    Desc:    pack the structure MgMgcoNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoNonStdExtn
(
MgMgcoNonStdExtn *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoNonStdExtn(param ,mBuf)
MgMgcoNonStdExtn *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoNonStdExtn)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoParmValue(&param->val,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoNonStdId(&param->id,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoNonStdExtn*/

/*
*
*    Fun:    cmPkMgMgcoModemDesc
*
*    Desc:    pack the structure MgMgcoModemDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoModemDesc
(
MgMgcoModemDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoModemDesc(param ,mBuf)
MgMgcoModemDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoModemDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoNonStdExtn(&param->extn,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoPropParmLst(&param->mpl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoModemTypeLst(&param->mtl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoModemDesc*/

/*
*
*    Fun:    cmPkMgMgcoMuxDesc
*
*    Desc:    pack the structure MgMgcoMuxDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMuxDesc
(
MgMgcoMuxDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMuxDesc(param ,mBuf)
MgMgcoMuxDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMuxDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoTermIdLst(&param->tl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoNonStdId(&param->id,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMuxDesc*/

/*
*
*    Fun:    cmPkMgMgcoEvtOther
*
*    Desc:    pack the structure MgMgcoEvtOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtOther
(
MgMgcoEvtOther *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtOther(param ,mBuf)
MgMgcoEvtOther *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEvtOther)

    ret1 = cmPkMgMgcoParmValue(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtOther*/

/*
*
*    Fun:    cmPkMgMgcoNtfyCmpl
*
*    Desc:    pack the structure MgMgcoNtfyCmpl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoNtfyCmpl
(
MgMgcoNtfyCmpl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoNtfyCmpl(param ,mBuf)
MgMgcoNtfyCmpl *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoNtfyCmpl)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknU8,  (param->reasons[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoNtfyCmpl*/

/*
*
*    Fun:    cmPkMgMgcoSigPar
*
*    Desc:    pack the structure MgMgcoSigPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSigPar
(
MgMgcoSigPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSigPar(param ,mBuf)
MgMgcoSigPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSigPar)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_SIGPAR_DURATION :
             CMCHKPK(cmPkTknU16, &param->u.dura,mBuf);
             break;
          case  MGT_SIGPAR_KEEPACTIVE :
             break;
          case  MGT_SIGPAR_NTFYCMPL :
             ret1 = cmPkMgMgcoNtfyCmpl(&param->u.nc,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGPAR_OTHER :
             ret1 = cmPkMgMgcoSigOther(&param->u.other,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGPAR_STREAMID :
             CMCHKPK(cmPkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          case  MGT_SIGPAR_TYPE :
             CMCHKPK(cmPkTknU8, &param->u.type,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSigPar*/

/*
*
*    Fun:    cmPkMgMgcoSigParLst
*
*    Desc:    pack the structure MgMgcoSigParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSigParLst
(
MgMgcoSigParLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSigParLst(param ,mBuf)
MgMgcoSigParLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoSigParLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoSigPar,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSigParLst*/

/*
*
*    Fun:    cmPkMgMgcoSignalsReq
*
*    Desc:    pack the structure MgMgcoSignalsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSignalsReq
(
MgMgcoSignalsReq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSignalsReq(param ,mBuf)
MgMgcoSignalsReq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSignalsReq)

    ret1 = cmPkMgMgcoSigParLst(&param->pl,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSignalsReq*/

/*
*
*    Fun:    cmPkMgMgcoSignalsReqLst
*
*    Desc:    pack the structure MgMgcoSignalsReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSignalsReqLst
(
MgMgcoSignalsReqLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSignalsReqLst(param ,mBuf)
MgMgcoSignalsReqLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoSignalsReqLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoSignalsReq,  (param->reqs[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSignalsReqLst*/

/*
*
*    Fun:    cmPkMgMgcoSignalsLst
*
*    Desc:    pack the structure MgMgcoSignalsLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSignalsLst
(
MgMgcoSignalsLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSignalsLst(param ,mBuf)
MgMgcoSignalsLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSignalsLst)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoSignalsReqLst(&param->pl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU16, &param->id,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSignalsLst*/

/*
*
*    Fun:    cmPkMgMgcoSignalsParm
*
*    Desc:    pack the structure MgMgcoSignalsParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSignalsParm
(
MgMgcoSignalsParm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSignalsParm(param ,mBuf)
MgMgcoSignalsParm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSignalsParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_SIGSPAR_LST :
             ret1 = cmPkMgMgcoSignalsLst(&param->u.lst,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGSPAR_REQ :
             ret1 = cmPkMgMgcoSignalsReq(&param->u.req,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSignalsParm*/

/*
*
*    Fun:    cmPkMgMgcoSignalsDesc
*
*    Desc:    pack the structure MgMgcoSignalsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSignalsDesc
(
MgMgcoSignalsDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSignalsDesc(param ,mBuf)
MgMgcoSignalsDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoSignalsDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->num.pres != NOTPRSNT )
       {
          for (i=param->num.val-1;i>=0;i--)
          {
             CMCHKPK(cmPkMgMgcoSignalsParm,  (param->parms[i]), mBuf);
          }
       }
       CMCHKPK(cmPkTknU16, &param->num,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSignalsDesc*/

/*
*
*    Fun:    cmPkMgMgcoDigRng
*
*    Desc:    pack the structure MgMgcoDigRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigRng
(
MgMgcoDigRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigRng(param ,mBuf)
MgMgcoDigRng *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoDigRng)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->up,mBuf);
       CMCHKPK(cmPkTknU8, &param->low,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigRng*/

/*
*
*    Fun:    cmPkMgMgcoDigMapLet
*
*    Desc:    pack the structure MgMgcoDigMapLet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigMapLet
(
MgMgcoDigMapLet *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigMapLet(param ,mBuf)
MgMgcoDigMapLet *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoDigMapLet)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoDigRng,  (param->mapLets[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigMapLet*/

/*
*
*    Fun:    cmPkMgMgcoDigMapRng
*
*    Desc:    pack the structure MgMgcoDigMapRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigMapRng
(
MgMgcoDigMapRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigMapRng(param ,mBuf)
MgMgcoDigMapRng *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDigMapRng)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGMAP_LET :
             ret1 = cmPkMgMgcoDigMapLet(&param->u.let,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAP_X :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigMapRng*/

/*
*
*    Fun:    cmPkMgMgcoDigStrElem
*
*    Desc:    pack the structure MgMgcoDigStrElem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigStrElem
(
MgMgcoDigStrElem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigStrElem(param ,mBuf)
MgMgcoDigStrElem *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDigStrElem)

    CMCHKPK(cmPkTknPres, &param->dot,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGSTR_LET :
             CMCHKPK(cmPkTknU8, &param->u.let,mBuf);
             break;
          case  MGT_DIGSTR_RNG :
             ret1 = cmPkMgMgcoDigMapRng(&param->u.range,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigStrElem*/

/*
*
*    Fun:    cmPkMgMgcoDigStr
*
*    Desc:    pack the structure MgMgcoDigStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigStr
(
MgMgcoDigStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigStr(param ,mBuf)
MgMgcoDigStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoDigStr)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoDigStrElem,  (param->elems[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigStr*/

/*
*
*    Fun:    cmPkMgMgcoDigMap
*
*    Desc:    pack the structure MgMgcoDigMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigMap
(
MgMgcoDigMap *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigMap(param ,mBuf)
MgMgcoDigMap *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoDigMap)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoDigStr,  (param->ds[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigMap*/

/*
*
*    Fun:    cmPkMgMgcoDigMapVal
*
*    Desc:    pack the structure MgMgcoDigMapVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigMapVal
(
MgMgcoDigMapVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigMapVal(param ,mBuf)
MgMgcoDigMapVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDigMapVal)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMacroTknStrOSXL(&param->dmIn,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP) 
       ret1 = cmPkMacroTknStrOSXL(&param->dm,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#else /* ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, */ 
       ret1 = cmPkMgMgcoDigMap(&param->dm,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /*  ,#else  */

       /* 001.main_14[RA]: moved from above */
#ifdef MGT_MGCO_V2
       CMCHKPK(cmPkTknU8, &param->z,mBuf);
#endif /*  MGT_MGCO_V2  */

       CMCHKPK(cmPkTknU8, &param->l,mBuf);
       CMCHKPK(cmPkTknU8, &param->s,mBuf);
       CMCHKPK(cmPkTknU8, &param->t,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigMapVal*/

/*
*
*    Fun:    cmPkMgMgcoEvtDM
*
*    Desc:    pack the structure MgMgcoEvtDM
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtDM
(
MgMgcoEvtDM *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtDM(param ,mBuf)
MgMgcoEvtDM *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEvtDM)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGMAP_NAME :
             ret1 = cmPkMgMgcoName(&param->u.name,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAP_VAL :
             ret1 = cmPkMgMgcoDigMapVal(&param->u.val,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtDM*/

/*
*
*    Fun:    cmPkMgMgcoEvtParSec
*
*    Desc:    pack the structure MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtParSec
(
MgMgcoEvtParSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtParSec(param ,mBuf)
MgMgcoEvtParSec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEvtParSec)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVTPAR_DIGMAP :
             ret1 = cmPkMgMgcoEvtDM(&param->u.dm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDWITHSIG :
             ret1 = cmPkMgMgcoSignalsDesc(&param->u.embSig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_KEEPACTIVE :
             break;
          case  MGT_EVTPAR_OTHER :
             ret1 = cmPkMgMgcoEvtOther(&param->u.other,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_STREAMID :
             CMCHKPK(cmPkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtParSec*/

/*
*
*    Fun:    cmPkMgMgcoEvtParSecLst
*
*    Desc:    pack the structure MgMgcoEvtParSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtParSecLst
(
MgMgcoEvtParSecLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtParSecLst(param ,mBuf)
MgMgcoEvtParSecLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoEvtParSecLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoEvtParSec,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtParSecLst*/

/*
*
*    Fun:    cmPkMgMgcoEvtSec
*
*    Desc:    pack the structure MgMgcoEvtSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtSec
(
MgMgcoEvtSec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtSec(param ,mBuf)
MgMgcoEvtSec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEvtSec)

    ret1 = cmPkMgMgcoEvtParSecLst(&param->pl,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtSec*/

/*
*
*    Fun:    cmPkMgMgcoEvtSecLst
*
*    Desc:    pack the structure MgMgcoEvtSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtSecLst
(
MgMgcoEvtSecLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtSecLst(param ,mBuf)
MgMgcoEvtSecLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoEvtSecLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoEvtSec,  (param->evts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtSecLst*/

/*
*
*    Fun:    cmPkMgMgcoEmbedFirst
*
*    Desc:    pack the structure MgMgcoEmbedFirst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEmbedFirst
(
MgMgcoEmbedFirst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEmbedFirst(param ,mBuf)
MgMgcoEmbedFirst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEmbedFirst)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoEvtSecLst(&param->sl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoRequestId, &param->reqId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEmbedFirst*/

/*
*
*    Fun:    cmPkMgMgcoEmbWithSig
*
*    Desc:    pack the structure MgMgcoEmbWithSig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEmbWithSig
(
MgMgcoEmbWithSig *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEmbWithSig(param ,mBuf)
MgMgcoEmbWithSig *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEmbWithSig)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoEmbedFirst(&param->emb,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoSignalsDesc(&param->sig,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEmbWithSig*/

/*
*
*    Fun:    cmPkMgMgcoEvtPar
*
*    Desc:    pack the structure MgMgcoEvtPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtPar
(
MgMgcoEvtPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtPar(param ,mBuf)
MgMgcoEvtPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoEvtPar)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVTPAR_DIGMAP :
             ret1 = cmPkMgMgcoEvtDM(&param->u.dm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDNOSIG :
             ret1 = cmPkMgMgcoEmbNoSig(&param->u.embNoSig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDWITHSIG :
             ret1 = cmPkMgMgcoEmbWithSig(&param->u.embWithSig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_KEEPACTIVE :
             break;
          case  MGT_EVTPAR_OTHER :
             ret1 = cmPkMgMgcoEvtOther(&param->u.other,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_STREAMID :
             CMCHKPK(cmPkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtPar*/

/*
*
*    Fun:    cmPkMgMgcoEvtParLst
*
*    Desc:    pack the structure MgMgcoEvtParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtParLst
(
MgMgcoEvtParLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtParLst(param ,mBuf)
MgMgcoEvtParLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoEvtParLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoEvtPar,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtParLst*/

/*
*
*    Fun:    cmPkMgMgcoReqEvt
*
*    Desc:    pack the structure MgMgcoReqEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoReqEvt
(
MgMgcoReqEvt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoReqEvt(param ,mBuf)
MgMgcoReqEvt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoReqEvt)

    ret1 = cmPkMgMgcoEvtParLst(&param->pl,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoReqEvt*/

/*
*
*    Fun:    cmPkMgMgcoEvtLst
*
*    Desc:    pack the structure MgMgcoEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvtLst
(
MgMgcoEvtLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvtLst(param ,mBuf)
MgMgcoEvtLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoEvtLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoReqEvt,  (param->revts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvtLst*/

/*
*
*    Fun:    cmPkMgMgcoReqEvtDesc
*
*    Desc:    pack the structure MgMgcoReqEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoReqEvtDesc
(
MgMgcoReqEvtDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoReqEvtDesc(param ,mBuf)
MgMgcoReqEvtDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoReqEvtDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoEvtLst(&param->el,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoRequestId, &param->reqId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoReqEvtDesc*/

/*
*
*    Fun:    cmPkMgMgcoEvBufDesc
*
*    Desc:    pack the structure MgMgcoEvBufDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoEvBufDesc
(
MgMgcoEvBufDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoEvBufDesc(param ,mBuf)
MgMgcoEvBufDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoEvBufDesc)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoEvSpec,  (param->evts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoEvBufDesc*/

/*
*
*    Fun:    cmPkMgMgcoDigMapDesc
*
*    Desc:    pack the structure MgMgcoDigMapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoDigMapDesc
(
MgMgcoDigMapDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoDigMapDesc(param ,mBuf)
MgMgcoDigMapDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoDigMapDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoDigMapVal(&param->val,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoName(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoDigMapDesc*/

/*
*
*    Fun:    cmPkMgMgcoAuditDesc
*
*    Desc:    pack the structure MgMgcoAuditDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAuditDesc
(
MgMgcoAuditDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAuditDesc(param ,mBuf)
MgMgcoAuditDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoAuditDesc)

    if(param->pres.pres != NOTPRSNT)
    {  
/* 001.main_14: Changes for AG Team */
#ifdef MGT_MGCO_V2
       if( param->num.pres != NOTPRSNT )
       {
          for (i=param->num.val-1;i>=0;i--)
          {
             CMCHKPK(cmPkMgMgcoAuditItem,  (param->al[i]), mBuf);
          }
       }
#else /* ,,,,,,,,,,,, */ 
       if( param->num.pres != NOTPRSNT )
       {
          for (i=param->num.val-1;i>=0;i--)
          {
             CMCHKPK(cmPkTknU8,  (param->al[i]), mBuf);
          }
       }
#endif /*  MGT_MGCO_V2,#else  */
       CMCHKPK(cmPkTknU16, &param->num,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAuditDesc*/

/*
*
*    Fun:    cmPkMgMgcoAmmDesc
*
*    Desc:    pack the structure MgMgcoAmmDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAmmDesc
(
MgMgcoAmmDesc *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAmmDesc(param ,intfVer, mBuf)
MgMgcoAmmDesc *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAmmDesc)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_AUDITDESC :
             ret1 = cmPkMgMgcoAuditDesc(&param->u.audit,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAPDESC :
             ret1 = cmPkMgMgcoDigMapDesc(&param->u.dm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVBUFDESC :
             ret1 = cmPkMgMgcoEvBufDesc(&param->u.evBuf,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIADESC :
             ret1 = cmPkMgMgcoMediaDesc(&param->u.media, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODEMDESC :
             ret1 = cmPkMgMgcoModemDesc(&param->u.modem,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MUXDESC :
             ret1 = cmPkMgMgcoMuxDesc(&param->u.mux,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_REQEVTDESC :
             ret1 = cmPkMgMgcoReqEvtDesc(&param->u.evts,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGNALSDESC :
             ret1 = cmPkMgMgcoSignalsDesc(&param->u.sig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAmmDesc*/

/*
*
*    Fun:    cmPkMgMgcoAmmDescLst
*
*    Desc:    pack the structure MgMgcoAmmDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAmmDescLst
(
MgMgcoAmmDescLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAmmDescLst(param ,intfVer, mBuf)
MgMgcoAmmDescLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoAmmDescLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoAmmDesc( (param->descs[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAmmDescLst*/

/*
*
*    Fun:    cmPkMgMgcoAmmReq
*
*    Desc:    pack the structure MgMgcoAmmReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAmmReq
(
MgMgcoAmmReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAmmReq(param ,intfVer, mBuf)
MgMgcoAmmReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAmmReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoAmmDescLst(&param->dl, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAmmReq*/

/*
*
*    Fun:    cmPkMgMgcoSubAudReq
*
*    Desc:    pack the structure MgMgcoSubAudReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSubAudReq
(
MgMgcoSubAudReq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSubAudReq(param ,mBuf)
MgMgcoSubAudReq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSubAudReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoAuditDesc(&param->audit,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSubAudReq*/

/*
*
*    Fun:    cmPkMgMgcoObsEvt
*
*    Desc:    pack the structure MgMgcoObsEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoObsEvt
(
MgMgcoObsEvt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoObsEvt(param ,mBuf)
MgMgcoObsEvt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoObsEvt)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoEvtParLst(&param->pl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
       CMCHKPK(cmPkMgMgcoTimeStamp, &param->time,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoObsEvt*/

/*
*
*    Fun:    cmPkMgMgcoObsEvtLst
*
*    Desc:    pack the structure MgMgcoObsEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoObsEvtLst
(
MgMgcoObsEvtLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoObsEvtLst(param ,mBuf)
MgMgcoObsEvtLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoObsEvtLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoObsEvt,  (param->evts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoObsEvtLst*/

/*
*
*    Fun:    cmPkMgMgcoObsEvtDesc
*
*    Desc:    pack the structure MgMgcoObsEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoObsEvtDesc
(
MgMgcoObsEvtDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoObsEvtDesc(param ,mBuf)
MgMgcoObsEvtDesc *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoObsEvtDesc)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoObsEvtLst(&param->el,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoRequestId, &param->reqId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoObsEvtDesc*/

/*
*
*    Fun:    cmPkMgMgcoNtfyReq
*
*    Desc:    pack the structure MgMgcoNtfyReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoNtfyReq
(
MgMgcoNtfyReq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoNtfyReq(param ,mBuf)
MgMgcoNtfyReq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoNtfyReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoErrDesc(&param->err,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoObsEvtDesc(&param->obs,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoNtfyReq*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgMethod
*
*    Desc:    pack the structure MgMgcoSvcChgMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgMethod
(
MgMgcoSvcChgMethod *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgMethod(param ,mBuf)
MgMgcoSvcChgMethod *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgMethod)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoNonStdId(&param->extn,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgMethod*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgProf
*
*    Desc:    pack the structure MgMgcoSvcChgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgProf
(
MgMgcoSvcChgProf *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgProf(param ,mBuf)
MgMgcoSvcChgProf *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgProf)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->ver,mBuf);
       ret1 = cmPkMgMgcoName(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgProf*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgPar
*
*    Desc:    pack the structure MgMgcoSvcChgPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgPar
(
MgMgcoSvcChgPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgPar(param ,mBuf)
MgMgcoSvcChgPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgPar)

    if(param->pres.pres != NOTPRSNT)
    {
#ifdef MGT_MGCO_V2
       ret1 = cmPkMgMgcoAuditItem(&param->auditItem,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /*  MGT_MGCO_V2  */
       CMCHKPK(cmPkMgMgcoTimeStamp, &param->time,mBuf);
       ret1 = cmPkMgMgcoMid(&param->mgcId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->delay,mBuf);
       ret1 = cmPkMgMgcoSvcChgReason(&param->reason,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoSvcChgProf(&param->prof,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->ver,mBuf);
       ret1 = cmPkMgMgcoSvcChgAddr(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoSvcChgMethod(&param->meth,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoNonStdExtn(&param->extn,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgPar*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgReq
*
*    Desc:    pack the structure MgMgcoSvcChgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgReq
(
MgMgcoSvcChgReq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgReq(param ,mBuf)
MgMgcoSvcChgReq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoSvcChgPar(&param->parm,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgReq*/

/*
*
*    Fun:    cmPkMgMgcoCmd
*
*    Desc:    pack the structure MgMgcoCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmd
(
MgMgcoCmd *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmd(param ,intfVer, mBuf)
MgMgcoCmd *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCmd)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ADD :
             ret1 = cmPkMgMgcoAmmReq(&param->u.add, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_AUDITCAP :
             ret1 = cmPkMgMgcoSubAudReq(&param->u.acap,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_AUDITVAL :
             ret1 = cmPkMgMgcoSubAudReq(&param->u.aval,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODIFY :
             ret1 = cmPkMgMgcoAmmReq(&param->u.mod, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MOVE :
             ret1 = cmPkMgMgcoAmmReq(&param->u.move, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_NTFY :
             ret1 = cmPkMgMgcoNtfyReq(&param->u.ntfy,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SUB :
             ret1 = cmPkMgMgcoSubAudReq(&param->u.sub,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SVCCHG :
             ret1 = cmPkMgMgcoSvcChgReq(&param->u.svc,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmd*/
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoCommandReq
*
*    Desc:    pack the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCommandReq
(
MgMgcoCommandReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCommandReq(param ,intfVer, mBuf)
MgMgcoCommandReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCommandReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCmd(&param->cmd, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknPres, &param->wild,mBuf);
       CMCHKPK(cmPkTknPres, &param->opt,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCommandReq*/
#else

/*
*
*    Fun:    cmPkMgMgcoCommandReq
*
*    Desc:    pack the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCommandReq
(
MgMgcoCommandReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCommandReq(param ,intfVer, mBuf)
MgMgcoCommandReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCommandReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCmd(&param->cmd, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknPres, &param->wild,mBuf);
       CMCHKPK(cmPkTknPres, &param->opt,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCommandReq*/
#endif

#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoCmdReqLst
*
*    Desc:    pack the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReqLst(param ,intfVer, mBuf)
MgMgcoCmdReqLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoCmdReqLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoCommandReq( (param->cmds[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
          cmFreeMem((Ptr)param->cmds[i]);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReqLst*/
#else

/*
*
*    Fun:    cmPkMgMgcoCmdReqLst
*
*    Desc:    pack the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReqLst(param ,intfVer, mBuf)
MgMgcoCmdReqLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoCmdReqLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoCommandReq( (param->cmds[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReqLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoActionReq
*
*    Desc:    pack the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActionReq
(
MgMgcoActionReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActionReq(param ,intfVer, mBuf)
MgMgcoActionReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActionReq)

    ret1 = cmPkMgMgcoCmdReqLst(&param->cl, intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgMgcoContextAudit, &param->cxtAud,mBuf);
    ret1 = cmPkMgMgcoContextProps(&param->cxtProps,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActionReq*/
#else

/*
*
*    Fun:    cmPkMgMgcoActionReq
*
*    Desc:    pack the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActionReq
(
MgMgcoActionReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActionReq(param ,intfVer, mBuf)
MgMgcoActionReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActionReq)

    ret1 = cmPkMgMgcoCmdReqLst(&param->cl, intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgMgcoContextAudit, &param->cxtAud,mBuf);
    ret1 = cmPkMgMgcoContextProps(&param->cxtProps,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActionReq*/
#endif

#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoActionLst
*
*    Desc:    pack the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActionLst
(
MgMgcoActionLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActionLst(param ,intfVer, mBuf)
MgMgcoActionLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoActionLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoActionReq( (param->actns[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActionLst*/
#else

/*
*
*    Fun:    cmPkMgMgcoActionLst
*
*    Desc:    pack the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActionLst
(
MgMgcoActionLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActionLst(param ,intfVer, mBuf)
MgMgcoActionLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoActionLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoActionReq( (param->actns[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActionLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoTxnReq
*
*    Desc:    pack the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnReq
(
MgMgcoTxnReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnReq(param ,intfVer, mBuf)
MgMgcoTxnReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxnReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoActionLst(&param->al, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnReq*/
#else


/*
*
*    Fun:    cmPkMgMgcoTxnReq
*
*    Desc:    pack the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnReq
(
MgMgcoTxnReq *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnReq(param ,intfVer, mBuf)
MgMgcoTxnReq *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxnReq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoActionLst(&param->al, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnReq*/
#endif

/*
*
*    Fun:    cmPkMgMgcoStatsPar
*
*    Desc:    pack the structure MgMgcoStatsPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoStatsPar
(
MgMgcoStatsPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoStatsPar(param ,mBuf)
MgMgcoStatsPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoStatsPar)

    ret1 = cmPkMgMgcoValue(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkMgMgcoPkgdName(&param->name,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknPkgId, &param->pkg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoStatsPar*/

/*
*
*    Fun:    cmPkMgMgcoStatsDesc
*
*    Desc:    pack the structure MgMgcoStatsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoStatsDesc
(
MgMgcoStatsDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoStatsDesc(param ,mBuf)
MgMgcoStatsDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoStatsDesc)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoStatsPar,  (param->parms[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoStatsDesc*/

/*
*
*    Fun:    cmPkMgMgcoPkgsItem
*
*    Desc:    pack the structure MgMgcoPkgsItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPkgsItem
(
MgMgcoPkgsItem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPkgsItem(param ,mBuf)
MgMgcoPkgsItem *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoPkgsItem)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->ver,mBuf);
       ret1 = cmPkMgMgcoName(&param->name,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPkgsItem*/

/*
*
*    Fun:    cmPkMgMgcoPkgsDesc
*
*    Desc:    pack the structure MgMgcoPkgsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoPkgsDesc
(
MgMgcoPkgsDesc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoPkgsDesc(param ,mBuf)
MgMgcoPkgsDesc *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoPkgsDesc)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoPkgsItem,  (param->items[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoPkgsDesc*/

/*
*
*    Fun:    cmPkMgMgcoAudRetParm
*
*    Desc:    pack the structure MgMgcoAudRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAudRetParm
(
MgMgcoAudRetParm *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAudRetParm(param ,intfVer, mBuf)
MgMgcoAudRetParm *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAudRetParm)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_AUDITDESC :
#ifdef MGT_MGCO_V2
             ret1 = cmPkMgMgcoAuditItem (&param->u.item,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#else
             CMCHKPK(cmPkTknU8, &param->u.item,mBuf);
#endif /* MGT_MGCO_V2 */
             break;
          case  MGT_DIGMAPDESC :
             ret1 = cmPkMgMgcoDigMapDesc(&param->u.dm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_ERRDESC :
             ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVBUFDESC :
             ret1 = cmPkMgMgcoEvBufDesc(&param->u.evBuf,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIADESC :
             ret1 = cmPkMgMgcoMediaDesc(&param->u.media, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODEMDESC :
             ret1 = cmPkMgMgcoModemDesc(&param->u.modem,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MUXDESC :
             ret1 = cmPkMgMgcoMuxDesc(&param->u.mux,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_OBSEVTDESC :
             ret1 = cmPkMgMgcoObsEvtDesc(&param->u.obs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PKGSDESC :
             ret1 = cmPkMgMgcoPkgsDesc(&param->u.pkgs,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_REQEVTDESC :
             ret1 = cmPkMgMgcoReqEvtDesc(&param->u.evts,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGNALSDESC :
             ret1 = cmPkMgMgcoSignalsDesc(&param->u.sig,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_STATSDESC :
             ret1 = cmPkMgMgcoStatsDesc(&param->u.stats,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAudRetParm*/

/*
*
*    Fun:    cmPkMgMgcoTermAuditRes
*
*    Desc:    pack the structure MgMgcoTermAuditRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTermAuditRes
(
MgMgcoTermAuditRes *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTermAuditRes(param ,intfVer, mBuf)
MgMgcoTermAuditRes *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoTermAuditRes)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoAudRetParm( (param->parms[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTermAuditRes*/

/*
*
*    Fun:    cmPkMgMgcoAmmsReply
*
*    Desc:    pack the structure MgMgcoAmmsReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAmmsReply
(
MgMgcoAmmsReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAmmsReply(param ,intfVer, mBuf)
MgMgcoAmmsReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAmmsReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoTermAuditRes(&param->audit, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAmmsReply*/

/*
*
*    Fun:    cmPkMgMgcoAuditOther
*
*    Desc:    pack the structure MgMgcoAuditOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAuditOther
(
MgMgcoAuditOther *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAuditOther(param ,intfVer, mBuf)
MgMgcoAuditOther *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAuditOther)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoTermAuditRes(&param->audit, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAuditOther*/

/*
*
*    Fun:    cmPkMgMgcoAuditReply
*
*    Desc:    pack the structure MgMgcoAuditReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoAuditReply
(
MgMgcoAuditReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoAuditReply(param ,intfVer, mBuf)
MgMgcoAuditReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoAuditReply)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_CXTAUDIT :
             ret1 = cmPkMgMgcoTermIdLst(&param->u.cxt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_ERRDESC :
             ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TERMAUDIT :
             ret1 = cmPkMgMgcoAuditOther(&param->u.other, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoAuditReply*/

/*
*
*    Fun:    cmPkMgMgcoNtfyReply
*
*    Desc:    pack the structure MgMgcoNtfyReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoNtfyReply
(
MgMgcoNtfyReply *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoNtfyReply(param ,mBuf)
MgMgcoNtfyReply *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoNtfyReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoErrDesc(&param->err,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoNtfyReply*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgResPar
*
*    Desc:    pack the structure MgMgcoSvcChgResPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgResPar
(
MgMgcoSvcChgResPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgResPar(param ,mBuf)
MgMgcoSvcChgResPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgResPar)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkMgMgcoTimeStamp, &param->time,mBuf);
       ret1 = cmPkMgMgcoMid(&param->mgcId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoSvcChgProf(&param->prof,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->ver,mBuf);
       ret1 = cmPkMgMgcoSvcChgAddr(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgResPar*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgRes
*
*    Desc:    pack the structure MgMgcoSvcChgRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgRes
(
MgMgcoSvcChgRes *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgRes(param ,mBuf)
MgMgcoSvcChgRes *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgRes)

    if( ( param->type.pres != NOTPRSNT )&& ( param->type.pres != NOTPRSNT ))
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SVCCHGDESC :
             ret1 = cmPkMgMgcoSvcChgResPar(&param->u.parm,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgRes*/

/*
*
*    Fun:    cmPkMgMgcoSvcChgReply
*
*    Desc:    pack the structure MgMgcoSvcChgReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoSvcChgReply
(
MgMgcoSvcChgReply *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoSvcChgReply(param ,mBuf)
MgMgcoSvcChgReply *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoSvcChgReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoSvcChgRes(&param->res,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoTermId(&param->termId,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoSvcChgReply*/
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoCmdReply
*
*    Desc:    pack the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReply
(
MgMgcoCmdReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReply(param ,intfVer, mBuf)
MgMgcoCmdReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCmdReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ADD :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.add, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITCAP :
                ret1 = cmPkMgMgcoAuditReply(&param->u.acap, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITVAL :
                ret1 = cmPkMgMgcoAuditReply(&param->u.aval, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MODIFY :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.mod, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MOVE :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.move, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_NTFY :
                ret1 = cmPkMgMgcoNtfyReply(&param->u.ntfy,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SUB :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.sub, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SVCCHG :
                ret1 = cmPkMgMgcoSvcChgReply(&param->u.svc,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkTknPres, &param->wild,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReply*/
#else

/*
*
*    Fun:    cmPkMgMgcoCmdReply
*
*    Desc:    pack the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReply
(
MgMgcoCmdReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReply(param ,intfVer, mBuf)
MgMgcoCmdReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCmdReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ADD :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.add, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITCAP :
                ret1 = cmPkMgMgcoAuditReply(&param->u.acap, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITVAL :
                ret1 = cmPkMgMgcoAuditReply(&param->u.aval, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MODIFY :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.mod, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MOVE :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.move, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_NTFY :
                ret1 = cmPkMgMgcoNtfyReply(&param->u.ntfy,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SUB :
                ret1 = cmPkMgMgcoAmmsReply(&param->u.sub, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SVCCHG :
                ret1 = cmPkMgMgcoSvcChgReply(&param->u.svc,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkTknPres, &param->wild,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReply*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoCmdReplyLst
*
*    Desc:    pack the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReplyLst(param ,intfVer, mBuf)
MgMgcoCmdReplyLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoCmdReplyLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoCmdReply( (param->repl[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
          cmFreeMem((Ptr)param->repl[i]);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReplyLst*/
#else

/*
*
*    Fun:    cmPkMgMgcoCmdReplyLst
*
*    Desc:    pack the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCmdReplyLst(param ,intfVer, mBuf)
MgMgcoCmdReplyLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoCmdReplyLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoCmdReply( (param->repl[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCmdReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoCxtCmdReply
*
*    Desc:    pack the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCxtCmdReply(param ,intfVer, mBuf)
MgMgcoCxtCmdReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCxtCmdReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCmdReplyLst(&param->cl, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoContextProps(&param->cxt,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCxtCmdReply*/
#else


/*
*
*    Fun:    cmPkMgMgcoCxtCmdReply
*
*    Desc:    pack the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCxtCmdReply(param ,intfVer, mBuf)
MgMgcoCxtCmdReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoCxtCmdReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCmdReplyLst(&param->cl, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoContextProps(&param->cxt,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCxtCmdReply*/
#endif

#ifdef MGT_GCP_VER_1_4
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoErrCmdRepSet
*
*    Desc:    pack the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoErrCmdRepSet(param ,intfVer, mBuf)
MgMgcoErrCmdRepSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoErrCmdRepSet)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCxtCmdReply(&param->reply, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoErrDesc(&param->err,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoErrCmdRepSet*/
#else
/*
*
*    Fun:    cmPkMgMgcoErrCmdRepSet
*
*    Desc:    pack the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoErrCmdRepSet(param ,intfVer, mBuf)
MgMgcoErrCmdRepSet *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoErrCmdRepSet)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoCxtCmdReply(&param->reply, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkMgMgcoErrDesc(&param->err,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoErrCmdRepSet*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoActnReply
*
*    Desc:    pack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReply
(
MgMgcoActnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReply(param ,intfVer, mBuf)
MgMgcoActnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoErrCmdRepSet(&param->repErrSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReply*/
#else 

/*
*
*    Fun:    cmPkMgMgcoActnReply
*
*    Desc:    pack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReply
(
MgMgcoActnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReply(param ,intfVer, mBuf)
MgMgcoActnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkMgMgcoErrCmdRepSet(&param->repErrSet, intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReply*/
#endif
#else /* MGT_GCP_VER_1_4 */

#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoActnReply
*
*    Desc:    pack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReply
(
MgMgcoActnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReply(param ,intfVer, mBuf)
MgMgcoActnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_CXTCMDREPLY :
                ret1 = cmPkMgMgcoCxtCmdReply(&param->u.reply, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReply*/
#else 

/*
*
*    Fun:    cmPkMgMgcoActnReply
*
*    Desc:    pack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReply
(
MgMgcoActnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReply(param ,intfVer, mBuf)
MgMgcoActnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoActnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_CXTCMDREPLY :
                ret1 = cmPkMgMgcoCxtCmdReply(&param->u.reply, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkMgMgcoContextId, &param->cxtId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReply*/
#endif
#endif /* MGT_GCP_VER_1_4 */

#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoActnReplyLst
*
*    Desc:    pack the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReplyLst(param ,intfVer, mBuf)
MgMgcoActnReplyLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoActnReplyLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoActnReply( (param->repl[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReplyLst*/
#else

/*
*
*    Fun:    cmPkMgMgcoActnReplyLst
*
*    Desc:    pack the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoActnReplyLst(param ,intfVer, mBuf)
MgMgcoActnReplyLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoActnReplyLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoActnReply( (param->repl[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoActnReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoTxnReply
*
*    Desc:    pack the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnReply
(
MgMgcoTxnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnReply(param ,intfVer, mBuf)
MgMgcoTxnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ACTIONREPLY :
                ret1 = cmPkMgMgcoActnReplyLst(&param->u.arl, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkTknPres, &param->immAck,mBuf);
       CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnReply*/
#else

/*
*
*    Fun:    cmPkMgMgcoTxnReply
*
*    Desc:    pack the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnReply
(
MgMgcoTxnReply *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnReply(param ,intfVer, mBuf)
MgMgcoTxnReply *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxnReply)

    if(param->pres.pres != NOTPRSNT)
    {
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ACTIONREPLY :
                ret1 = cmPkMgMgcoActnReplyLst(&param->u.arl, intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKPK(cmPkTknU8, &param->type,mBuf);
       CMCHKPK(cmPkTknPres, &param->immAck,mBuf);
       CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnReply*/

#endif

/*
*
*    Fun:    cmPkMgMgcoTxnPend
*
*    Desc:    pack the structure MgMgcoTxnPend
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnPend
(
MgMgcoTxnPend *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnPend(param ,mBuf)
MgMgcoTxnPend *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoTxnPend)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnPend*/

/*
*
*    Fun:    cmPkMgMgcoTxnAck
*
*    Desc:    pack the structure MgMgcoTxnAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnAck
(
MgMgcoTxnAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnAck(param ,mBuf)
MgMgcoTxnAck *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgcoTxnAck)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkMgMgcoTransId, &param->last,mBuf);
       CMCHKPK(cmPkMgMgcoTransId, &param->first,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnAck*/

/*
*
*    Fun:    cmPkMgMgcoTxnRspAck
*
*    Desc:    pack the structure MgMgcoTxnRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnRspAck
(
MgMgcoTxnRspAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnRspAck(param ,mBuf)
MgMgcoTxnRspAck *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgMgcoTxnRspAck)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkMgMgcoTxnAck,  (param->acks[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnRspAck*/
#ifdef GCP_VER_1_3
#ifdef GCP_CH

/*
*
*    Fun:    cmPkMgMgcoTxn
*
*    Desc:    pack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxn
(
MgMgcoTxn *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxn(param ,intfVer, mBuf)
MgMgcoTxn *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxn)

#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif /*    */
    CMCHKPK(cmPkTknU8, &param->dupInfo,mBuf);
    CMCHKPK(cmPkMgLclErr, &param->mgLclErr,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKPK(cmPkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmPkMgMgcoTxnReply(&param->u.reply, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmPkMgMgcoTxnReq(&param->u.req, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmPkMgMgcoTxnRspAck(&param->u.rspAck,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxn*/
#else

/*
*
*    Fun:    cmPkMgMgcoTxn
*
*    Desc:    pack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxn
(
MgMgcoTxn *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxn(param ,intfVer, mBuf)
MgMgcoTxn *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxn)

#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKPK(SPkU16, param->rsetId,mBuf);
#endif /*    */
    CMCHKPK(cmPkTknU8, &param->dupInfo,mBuf);
    CMCHKPK(cmPkMgLclErr, &param->mgLclErr,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKPK(cmPkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmPkMgMgcoTxnReply(&param->u.reply, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmPkMgMgcoTxnReq(&param->u.req, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmPkMgMgcoTxnRspAck(&param->u.rspAck,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxn*/
#endif
#else

/*
*
*    Fun:    cmPkMgMgcoTxn
*
*    Desc:    pack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxn
(
MgMgcoTxn *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxn(param ,intfVer, mBuf)
MgMgcoTxn *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoTxn)

    CMCHKPK(cmPkTknU8, &param->dupInfo,mBuf);
    CMCHKPK(cmPkMgLclErr, &param->mgLclErr,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKPK(cmPkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmPkMgMgcoTxnReply(&param->u.reply, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmPkMgMgcoTxnReq(&param->u.req, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmPkMgMgcoTxnRspAck(&param->u.rspAck,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxn*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmPkMgMgcoTxnLst
*
*    Desc:    pack the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnLst
(
MgMgcoTxnLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnLst(param ,intfVer, mBuf)
MgMgcoTxnLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoTxnLst)

    for (i=param->num.val-1;i>=0;i--)
    {
       ret1 = cmPkMgMgcoTxn( (param->txns[i]), intfVer ,mBuf);
       if(ret1 != ROK)
       {
          SPutMsg(mBuf );
          RETVALUE( ret1 );
       }
       cmFreeMem((Ptr)param->txns[i]);
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnLst*/
#else

/*
*
*    Fun:    cmPkMgMgcoTxnLst
*
*    Desc:    pack the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoTxnLst
(
MgMgcoTxnLst *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoTxnLst(param ,intfVer, mBuf)
MgMgcoTxnLst *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoTxnLst)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          ret1 = cmPkMgMgcoTxn( (param->txns[i]), intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoTxnLst*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmPkMgMgcoMsgBody
*
*    Desc:    pack the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMsgBody
(
MgMgcoMsgBody *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMsgBody(param ,intfVer, mBuf)
MgMgcoMsgBody *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMsgBody)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXN :
             ret1 = cmPkMgMgcoTxnLst(&param->u.tl, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMsgBody*/
#else

/*
*
*    Fun:    cmPkMgMgcoMsgBody
*
*    Desc:    pack the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMsgBody
(
MgMgcoMsgBody *param,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMsgBody(param ,intfVer, mBuf)
MgMgcoMsgBody *param;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMsgBody)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmPkMgMgcoErrDesc(&param->u.err,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXN :
             ret1 = cmPkMgMgcoTxnLst(&param->u.tl, intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMsgBody*/
#endif

/*
*
*    Fun:    cmPkMgMgcoMsg
*
*    Desc:    pack the structure MgMgcoMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoMsg
(
MgMgcoMsg *param,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoMsg(param , pst, mBuf)
MgMgcoMsg *param;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoMsg)

#ifdef GCP_PROV_SCTP
    CMCHKPK(SPkU8, param->unorder,mBuf);
#endif /*  GCP_PROV_SCTP  */
    CMCHKPK(cmPkMgPeerInfo, &param->lcl,mBuf);
#ifdef GCP_VER_1_3
    ret1 = cmPkMgMgcoMsgBody(&param->body, pst->intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#else /* ,,,,,,,,,,,, */ 
    ret1 = cmPkMgMgcoMsgBody(&param->body, pst->intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#endif /*  GCP_VER_1_3,#else  */
    ret1 = cmPkMacroTknStrOSXL(&param->mid,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgMgcoVersion, &param->ver,mBuf);
    ret1 = cmPkMgMgcoAuthHdr(&param->ah,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    /*MAH_TODO */
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoMsg*/
#endif /* GCP_MGCO */

/*
*
*    Fun:    cmPkMgMgtSta
*
*    Desc:    pack the structure MgMgtSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgtSta
(
MgMgtSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgtSta(param ,mBuf)
MgMgtSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMgtSta)

    switch( param->type )
    {
       case  MGT_STATUS_FLOW :
          CMCHKPK(SPkU8, param->u.action,mBuf);
          break;
       case  MGT_STATUS_HANDOFF_FAILED :
          break;
#ifdef GCP_MGCO
       case  MGT_STATUS_MGCO_VER :
          CMCHKPK(cmPkTknU32, &param->u.mgcoVersion,mBuf);
          break;
#endif /*  GCP_MGCO  */
#ifdef GCP_MGCP
       case  MGT_STATUS_MGCP_VER :
          CMCHKPK(cmPkTknU32, &param->u.mgcpVersion,mBuf);
          break;
#endif /*  GCP_MGCP  */
       case  MGT_STATUS_PEER :
          CMCHKPK(SPkU8, param->u.reason,mBuf);
          break;
       case  MGT_STATUS_REDIRECTION_FAILED :
          break;
       case  MGT_STATUS_SAP_RECVRY_FAILED :
          break;
       case  MGT_STATUS_SAP_RECVRY_SUCCESS :
          break;
       case  MGT_STATUS_SRVC_PRVDR_FAILED :
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU8, param->type,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgMgtSta*/
#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 

/*
*
*    Fun:    cmPkMgMgcoCommand
*
*    Desc:    pack the structure MgMgcoCommand
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoCommand
(
MgMgcoCommand *param,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoCommand(param , pst, mBuf)
MgMgcoCommand *param;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkMgMgcoCommand)

    if( param->cmdType.pres != NOTPRSNT )
    {
       switch( param->cmdType.val )
       {
          case  CH_CMD_TYPE_CFM :
             for (i=MGT_ONE_CMD-1;i>=0;i--)
             {
                ret1 = cmPkMgMgcoCmdReply( (param->u.mgCmdCfm[i]), pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf );
                   RETVALUE( ret1 );
                }
                cmFreeMem((Ptr)param->u.mgCmdCfm[i]);
             }
             break;
          case  CH_CMD_TYPE_IND :
             for (i=MGT_ONE_CMD-1;i>=0;i--)
             {
                ret1 = cmPkMgMgcoCommandReq( (param->u.mgCmdInd[i]), pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf );
                   RETVALUE( ret1 );
                }
                cmFreeMem((Ptr)param->u.mgCmdInd[i]);
             }
             break;
          case  CH_CMD_TYPE_REQ :
             for (i=MGT_ONE_CMD-1;i>=0;i--)
             {
                ret1 = cmPkMgMgcoCommandReq( (param->u.mgCmdReq[i]), pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf );
                   RETVALUE( ret1 );
                }
                cmFreeMem((Ptr)param->u.mgCmdReq[i]);
             }
             break;
          case  CH_CMD_TYPE_RSP :
             for (i=MGT_ONE_CMD-1;i>=0;i--)
             {
                ret1 = cmPkMgMgcoCmdReply( (param->u.mgCmdRsp[i]), pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf );
                   RETVALUE( ret1 );
                }
                cmFreeMem((Ptr)param->u.mgCmdRsp[i]);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->cmdType,mBuf);
    CMCHKPK(cmPkTknU8, &param->cmdStatus,mBuf);
    CMCHKPK(cmPkTknU32, &param->peerId,mBuf);
    CMCHKPK(cmPkMgMgcoContextId, &param->contextId,mBuf);
    CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoCommand*/

/*
*
*    Fun:    cmPkMgMgcoChCntxt
*
*    Desc:    pack the structure MgMgcoChCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoChCntxt
(
MgMgcoChCntxt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoChCntxt(param ,mBuf)
MgMgcoChCntxt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoChCntxt)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkMgMgcoContextAudit, &param->cxtAudit,mBuf);
       ret1 = cmPkMgMgcoContextProps(&param->cxtProps,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoChCntxt*/

/*
*
*    Fun:    cmPkMgMgcoUpdateCntxt
*
*    Desc:    pack the structure MgMgcoUpdateCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoUpdateCntxt
(
MgMgcoUpdateCntxt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoUpdateCntxt(param ,mBuf)
MgMgcoUpdateCntxt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoUpdateCntxt)

    CMCHKPK(cmPkTknU8, &param->status,mBuf);
    ret1 = cmPkMgMgcoChCntxt(&param->contextProp,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU32, &param->peerId,mBuf);
    CMCHKPK(cmPkMgMgcoContextId, &param->contextId,mBuf);
    CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoUpdateCntxt*/

/*
*
*    Fun:    cmPkMgMgcoInd
*
*    Desc:    pack the structure MgMgcoInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMgcoInd
(
MgMgcoInd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMgcoInd(param ,mBuf)
MgMgcoInd *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMgcoInd)

    CMCHKPK(cmPkTknPres, &param->txnPending,mBuf);
    ret1 = cmPkMgMgcoErrDesc(&param->err,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU32, &param->peerId,mBuf);
    CMCHKPK(cmPkMgMgcoContextId, &param->cntxtId,mBuf);
    CMCHKPK(cmPkMgMgcoTransId, &param->transId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMgcoInd*/

/*
*
*    Fun:    cmPkMgtMgcoCmdReq
*
*    Desc:    pack the primitive MgtMgcoCmdReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoCmdReq
(
Pst *pst,
SpId spId,
MgMgcoCommand *chCmdReq
)
#else
PUBLIC S16 cmPkMgtMgcoCmdReq(pst, spId, chCmdReq)
Pst *pst;
SpId spId;
MgMgcoCommand *chCmdReq;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    U32 index;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoCmdReq)
     
    index = 0;  
    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT001, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT    
     case MGT_SEL_LC:
     ret1 = cmPkMgMgcoCommand(chCmdReq, pst ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)EMGT002, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    break;
#endif
    
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
      /*
      * Now you have packed the individual members, Now Unpack the 
      * member of the union
      */
      switch (chCmdReq->cmdType.val)
      {  
        case CH_CMD_TYPE_REQ:
        case CH_CMD_TYPE_IND:
          for (index=0;index < MGT_ONE_CMD;index++)
          {
            CMCHKPK(cmPkPtr,(PTR)(chCmdReq->u.mgCmdReq[index]),mBuf);
          }
          break;
        case CH_CMD_TYPE_RSP:
        case CH_CMD_TYPE_CFM:
          for (index=0;index < MGT_ONE_CMD;index++)
          {
            CMCHKPK(cmPkPtr,(PTR)(chCmdReq->u.mgCmdRsp[index]),mBuf);
          }
          break;
      }
      CMCHKPK(cmPkTknU8, &chCmdReq->cmdType,mBuf);
      CMCHKPK(cmPkTknU8, &chCmdReq->cmdStatus,mBuf);
      CMCHKPK(cmPkTknU32, &chCmdReq->peerId,mBuf);
      CMCHKPK(cmPkMgMgcoContextId, &chCmdReq->contextId,mBuf);
      CMCHKPK(cmPkMgMgcoTransId, &chCmdReq->transId,mBuf);
    break;
#endif
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT003, pst);
    pst->event = (Event) EVTMGTMGCOCMDREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtMgcoCmdReq*/
 
/*
*
*    Fun:    cmPkMgtMgcoCmdInd
*
*    Desc:    pack the primitive MgtMgcoCmdInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoCmdInd
(
Pst *pst,
SpId spId,
MgMgcoCommand *chCmdInd
)
#else
PUBLIC S16 cmPkMgtMgcoCmdInd(pst, spId, chCmdInd)
Pst *pst;
SpId spId;
MgMgcoCommand *chCmdInd;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    U32 index;
    mBuf = NULLP;
    
    TRC3(cmPkMgtMgcoCmdInd)

    index=0;
    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT004, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
    case MGT_SEL_LC:
	case MGT_SEL_LC_SS:
    ret1 = cmPkMgMgcoCommand(chCmdInd, pst ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)EMGT005, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */ 
    break;
#endif
#ifdef LWLCMGT
    case  MGT_SEL_LWLC:
	case MGT_SEL_LWLC_SS:
      /*First pack the members starting from top */
    /*
     * Now you have packed the individual members, Now pack the 
     * member of the union
     */
    switch (chCmdInd->cmdType.val)
    {  
      case CH_CMD_TYPE_REQ:
      case CH_CMD_TYPE_IND:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKPK(cmPkPtr, (PTR)(chCmdInd->u.mgCmdReq[index]),mBuf);
        } 
      case CH_CMD_TYPE_RSP:
      case CH_CMD_TYPE_CFM:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKPK(cmPkPtr, (PTR)(chCmdInd->u.mgCmdRsp[index]),mBuf);
        }
    }
    CMCHKPK(cmPkTknU8, &chCmdInd->cmdType,mBuf);
    CMCHKPK(cmPkTknU8, &chCmdInd->cmdStatus,mBuf);
    CMCHKPK(cmPkTknU32, &chCmdInd->peerId,mBuf);
    CMCHKPK(cmPkMgMgcoContextId,&chCmdInd->contextId,mBuf);
    CMCHKPK(cmPkMgMgcoTransId,&chCmdInd->transId,mBuf);
    break;
#endif
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT006, pst);
    pst->event = (Event) EVTMGTMGCOCMDIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:	
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
} /*end of function cmPkMgtMgcoCmdInd*/
                                          
/*
*
*    Fun:    cmPkMgtMgcoUpdCtxtReq
*
*    Desc:    pack the primitive MgtMgcoUpdCtxtReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoUpdCtxtReq
(
Pst *pst,
SpId spId,
MgMgcoUpdateCntxt *chCntxtReq
)
#else
PUBLIC S16 cmPkMgtMgcoUpdCtxtReq(pst, spId, chCntxtReq)
Pst *pst;
SpId spId;
MgMgcoUpdateCntxt *chCntxtReq;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoUpdCtxtReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT007, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          ret1 = cmPkMgMgcoUpdateCntxt( (chCntxtReq),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT008, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)chCntxtReq);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)chCntxtReq, mBuf, EMGT009, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT010, pst);
    pst->event = (Event) EVTMGTMGCOUPDCNTXTREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtMgcoUpdCtxtReq*/

/*
*
*    Fun:    cmPkMgtMgcoUpdCtxtInd
*
*    Desc:    pack the primitive MgtMgcoUpdCtxtInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoUpdCtxtInd
(
Pst *pst,
SpId spId,
MgMgcoUpdateCntxt *chCntxtInd
)
#else
PUBLIC S16 cmPkMgtMgcoUpdCtxtInd(pst, spId, chCntxtInd)
Pst *pst;
SpId spId;
MgMgcoUpdateCntxt *chCntxtInd;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoUpdCtxtInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT011, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          ret1 = cmPkMgMgcoUpdateCntxt( (chCntxtInd),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT012, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)chCntxtInd);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)chCntxtInd, mBuf, EMGT013, pst); 
          break;
#endif /* LWLCMGT */
    }	
    /* mgt_c_004.main_14: No code should be outside the switch case */
/* 001.main_14: Changes for AG Team */
/*    ret1 = cmPkMgMgcoUpdateCntxt(chCntxtInd,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)EMGT014, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif     ERRCLASS & ERRCLS_ADD_RES  */
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT015, pst);
 
    pst->event = (Event) EVTMGTMGCOUPDCNTXTIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:	
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);

} /*end of function cmPkMgtMgcoUpdCtxtInd*/

/*
*
*    Fun:    cmPkMgtMgcoErrReq
*
*    Desc:    pack the primitive MgtMgcoErrReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoErrReq
(
Pst *pst,
SpId spId,
MgMgcoInd *errRsp
)
#else
PUBLIC S16 cmPkMgtMgcoErrReq(pst, spId, errRsp)
Pst *pst;
SpId spId;
MgMgcoInd *errRsp;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoErrReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT016, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          ret1 = cmPkMgMgcoInd( (errRsp),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT017, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)errRsp);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)errRsp, mBuf, EMGT018, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT019, pst);
    pst->event = (Event) EVTMGTMGCOERRREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtMgcoErrReq*/

/*
*
*    Fun:    cmPkMgtMgcoTxnStaInd
*
*    Desc:    pack the primitive MgtMgcoTxnStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoTxnStaInd
(
Pst *pst,
SpId spId,
MgMgcoInd *chTxnStaInd
)
#else
PUBLIC S16 cmPkMgtMgcoTxnStaInd(pst, spId, chTxnStaInd)
Pst *pst;
SpId spId;
MgMgcoInd *chTxnStaInd;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoTxnStaInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT020, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          ret1 = cmPkMgMgcoInd( (chTxnStaInd),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT021, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)chTxnStaInd);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)chTxnStaInd, mBuf, EMGT022, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT023, pst);
    pst->event = (Event) EVTMGTMGCOTXNSTAIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
} /*end of function cmPkMgtMgcoTxnStaInd*/

#endif /* GCP_CH && GCP_VER_1_5 */

/*
*
*    Fun:    cmPkMgtBndReq
*
*    Desc:    pack the primitive MgtBndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtBndReq
(
Pst *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 cmPkMgtBndReq(pst, suId, spId)
Pst *pst;
SuId suId;
SpId spId;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtBndReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT024, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT025, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, EMGT026, pst);
    pst->event = (Event) EVTMGTBNDREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtBndReq*/

/*
*
*    Fun:    cmPkMgtUbndReq
*
*    Desc:    pack the primitive MgtUbndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtUbndReq
(
Pst *pst,
SpId spId,
Reason reason
)
#else
PUBLIC S16 cmPkMgtUbndReq(pst, spId, reason)
Pst *pst;
SpId spId;
Reason reason;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtUbndReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT027, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkS16, reason, mBuf, EMGT028, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT029, pst);
    pst->event = (Event) EVTMGTUBNDREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtUbndReq*/

/*
*
*    Fun:    cmPkMgtBndCfm
*
*    Desc:    pack the primitive MgtBndCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtBndCfm
(
Pst *pst,
SuId suId,
U8 status
)
#else
PUBLIC S16 cmPkMgtBndCfm(pst, suId, status)
Pst *pst;
SuId suId;
U8 status;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtBndCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT030, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU8, status, mBuf, EMGT031, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, EMGT032, pst);
    pst->event = (Event) EVTMGTBNDCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)		
	{						
	case MGT_SEL_LC:
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);			

} /*end of function cmPkMgtBndCfm*/

/*
*
*    Fun:    cmPkMgtCntrlReq
*
*    Desc:    pack the primitive MgtCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtCntrlReq
(
Pst *pst,
SpId spId,
MgMgtCntrl *cntrl
)
#else
PUBLIC S16 cmPkMgtCntrlReq(pst, spId, cntrl)
Pst *pst;
SpId spId;
MgMgtCntrl *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtCntrlReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT033, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkMgMgtCntrl,  (cntrl), mBuf, EMGT034, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT035, pst);
    pst->event = (Event) EVTMGTCNTRLREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtCntrlReq*/

/*
*
*    Fun:    cmPkMgtCntrlCfm
*
*    Desc:    pack the primitive MgtCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtCntrlCfm
(
Pst *pst,
SpId spId,
MgMgtCntrl *cntrl,
Reason reason
)
#else
PUBLIC S16 cmPkMgtCntrlCfm(pst, spId, cntrl, reason)
Pst *pst;
SpId spId;
MgMgtCntrl *cntrl;
Reason reason;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtCntrlCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT036, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkS16, reason, mBuf, EMGT037, pst);
    CMCHKPKLOG(cmPkMgMgtCntrl,  (cntrl), mBuf, EMGT038, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT039, pst);
    pst->event = (Event) EVTMGTCNTRLCFM;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:	
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
} /*end of function cmPkMgtCntrlCfm*/

/*
*
*    Fun:    cmPkMgtAuditReq
*
*    Desc:    pack the primitive MgtAuditReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtAuditReq
(
Pst *pst,
SpId spId,
MgMgtAudit *audit
)
#else
PUBLIC S16 cmPkMgtAuditReq(pst, spId, audit)
Pst *pst;
SpId spId;
MgMgtAudit *audit;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtAuditReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT040, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkMgMgtAudit,  (audit), mBuf, EMGT041, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT042, pst);
    pst->event = (Event) EVTMGTAUDREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtAuditReq*/

/*
*
*    Fun:    cmPkMgtAuditCfm
*
*    Desc:    pack the primitive MgtAuditCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtAuditCfm
(
Pst *pst,
SpId spId,
MgMgtAudit *audit,
Reason reason
)
#else
PUBLIC S16 cmPkMgtAuditCfm(pst, spId, audit, reason)
Pst *pst;
SpId spId;
MgMgtAudit *audit;
Reason reason;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtAuditCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT043, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkS16, reason, mBuf, EMGT044, pst);
    CMCHKPKLOG(cmPkMgMgtAudit,  (audit), mBuf, EMGT045, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT046, pst);
    pst->event = (Event) EVTMGTAUDCFM;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:	
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
} /*end of function cmPkMgtAuditCfm*/

/*
*
*    Fun:    cmPkMgtStaInd
*
*    Desc:    pack the primitive MgtStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtStaInd
(
Pst *pst,
SpId spId,
MgMgtSta *sta
)
#else
PUBLIC S16 cmPkMgtStaInd(pst, spId, sta)
Pst *pst;
SpId spId;
MgMgtSta *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtStaInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT047, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkMgMgtSta,  (sta), mBuf, EMGT048, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT049, pst);
    pst->event = (Event) EVTMGTSTAIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
    
} /*end of function cmPkMgtStaInd*/
#ifdef GCP_MGCP

/*
*
*    Fun:    cmPkMgtMgcpTxnReq
*
*    Desc:    pack the primitive MgtMgcpTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcpTxnReq
(
Pst *pst,
SpId spId,
MgMgcpTxn *mgTxn
)
#else
PUBLIC S16 cmPkMgtMgcpTxnReq(pst, spId, mgTxn)
Pst *pst;
SpId spId;
MgMgcpTxn *mgTxn;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcpTxnReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT050, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          ret1 = cmPkMgMgcpTxn( (mgTxn) ,pst ,mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT051, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)mgTxn);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)mgTxn, mBuf, EMGT052, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT053, pst);
    pst->event = (Event) EVTMGTMGCPTXNREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtMgcpTxnReq*/

/*
*
*    Fun:    cmPkMgtMgcpTxnInd
*
*    Desc:    pack the primitive MgtMgcpTxnInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcpTxnInd
(
Pst *pst,
SuId suId,
MgMgcpTxn *mgTxn
)
#else
PUBLIC S16 cmPkMgtMgcpTxnInd(pst, suId, mgTxn)
Pst *pst;
SuId suId;
MgMgcpTxn *mgTxn;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcpTxnInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT054, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          ret1 = cmPkMgMgcpTxn( (mgTxn) ,pst ,mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT055, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)mgTxn);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)mgTxn, mBuf, EMGT056, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, suId, mBuf, EMGT057, pst);
    pst->event = (Event) EVTMGTMGCPTXNIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
    
} /*end of function cmPkMgtMgcpTxnInd*/
#endif /* GCP_MGCP */
#ifdef GCP_MGCO

/*
*
*    Fun:    cmPkMgtMgcoTxnReq
*
*    Desc:    pack the primitive MgtMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoTxnReq
(
Pst *pst,
SpId spId,
MgMgcoMsg *mgTxn
)
#else
PUBLIC S16 cmPkMgtMgcoTxnReq(pst, spId, mgTxn)
Pst *pst;
SpId spId;
MgMgcoMsg *mgTxn;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoTxnReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT058, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          ret1 = cmPkMgMgcoMsg( (mgTxn) ,pst ,mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT059, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)mgTxn);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)mgTxn, mBuf, EMGT060, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, EMGT061, pst);
    pst->event = (Event) EVTMGTMGCOTXNREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  MGTIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkMgtMgcoTxnReq*/

/*
*
*    Fun:    cmPkMgtMgcoTxnInd
*
*    Desc:    pack the primitive MgtMgcoTxnInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgtMgcoTxnInd
(
Pst *pst,
SuId suId,
MgMgcoMsg *mgTxn
)
#else
PUBLIC S16 cmPkMgtMgcoTxnInd(pst, suId, mgTxn)
Pst *pst;
SuId suId;
MgMgcoMsg *mgTxn;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkMgtMgcoTxnInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)EMGT062, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:			
          ret1 = cmPkMgMgcoMsg( (mgTxn) ,pst ,mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)EMGT063, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)mgTxn);
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)mgTxn, mBuf, EMGT064, pst); 
          break;
#endif /* LWLCMGT */
    }
    CMCHKPKLOG(SPkS16, suId, mBuf, EMGT065, pst);
    pst->event = (Event) EVTMGTMGCOTXNIND;

	switch(pst->selector)		
	{						
	case MGT_SEL_LC:
	case MGT_SEL_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;				
#ifdef CP_UA_IF_TYPE_SS		
	case MGT_SEL_LC_SS:		
	case MGT_SEL_LWLC_SS:	
		XosToFrameCallBack(g_megacoUaModId, pst, mBuf);
		ret1 = ROK;
		break;				
#endif /* CP_UA_IF_TYPE_SS */
	default:				
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)EMGT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;		
		break;			
	}						
	RETVALUE(ret1);
    
} /*end of function cmPkMgtMgcoTxnInd*/
#endif /* GCP_MGCO */
/* mgt_c_003.main_14: Support for packages to U16 under 
 * flag MGT_PROPR_PKG_SUPPORT */

/*
*
*       Fun:   cmUnpkTknPkgId
*
*       Desc:  This function unpacks a token Package Id
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  mgt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkTknPkgId
(
TknPkgId *tknPkgId,             /* token Package Id */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkTknPkgId(tknPkgId, mBuf)
TknPkgId *tknPkgId;             /* token Package Id */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(cmUnpkTknPkgId)

#ifdef MGT_PROPR_PKG_SUPPORT
   CMCHKUNPK(cmUnpkTknU16, tknPkgId, mBuf);
#else
   CMCHKUNPK(cmUnpkTknU8, tknPkgId, mBuf);
#endif

   RETVALUE(ROK);
} /* end of cmUnpkTknPkgId */


/*
*
*    Fun:    cmUnpkMgLclErr
*
*    Desc:    unpack the structure mgLclErr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgLclErr
(
MgLclErr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgLclErr(param ,mBuf)
MgLclErr *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgLclErr)

    CMCHKUNPK(cmUnpkTknU8, &param->errType,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->trId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgLclErr*/

/*
*
*    Fun:    cmUnpkMgTransInfo
*
*    Desc:    unpack the structure mgTransInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTransInfo
(
MgTransInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTransInfo(param ,mBuf)
MgTransInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTransInfo)

    CMCHKUNPK(SUnpkU8, &param->transType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->transDir,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->firstTransId,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->lastTransId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTransInfo*/

/*
*
*    Fun:    cmUnpkMgMoveTransInfo
*
*    Desc:    unpack the structure mgMoveTransInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMoveTransInfo
(
MgMoveTransInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMoveTransInfo(param ,mBuf)
MgMoveTransInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMoveTransInfo)

    CMCHKUNPK(cmUnpkMgPeerInfo, &param->newPeer,mBuf);
    CMCHKUNPK(cmUnpkMgTransInfo, &param->transInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMoveTransInfo*/

/*
*
*    Fun:    cmUnpkMgMgtCntrl
*
*    Desc:    unpack the structure mgMgtCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgtCntrl
(
MgMgtCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgtCntrl(param ,mBuf)
MgMgtCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgtCntrl)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(SUnpkU8, &param->action,mBuf);
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    switch( param->action )
    {
       case  MGT_CANCEL_RMV_ASSOC :
          break;
       case  MGT_MOVE_PEER :
          CMCHKUNPK(SUnpkS16, &param->u.ssapId,mBuf);
          break;
       case  MGT_MOVE_TRANS :
          CMCHKUNPK(cmUnpkMgMoveTransInfo, &param->u.moveTransInfo,mBuf);
          break;
       case  MGT_RESET_RTO :
          break;
       case  MGT_RMV_ASSOC :
          CMCHKUNPK(SUnpkU16, &param->u.dura,mBuf);
          break;
       case  MGT_RMV_TRANS :
          CMCHKUNPK(cmUnpkMgTransInfo, &param->u.transInfo,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgtCntrl*/

/*
*
*    Fun:    cmUnpkMgTransStatus
*
*    Desc:    unpack the structure mgTransStatus
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTransStatus
(
MgTransStatus *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTransStatus(param ,mBuf)
MgTransStatus *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTransStatus)

    CMCHKUNPK(SUnpkU32, &param->transId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->transStatus,mBuf);
    CMCHKUNPK(SUnpkU8, &param->transDir,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTransStatus*/

/*
*
*    Fun:    cmUnpkMgAuditInfo
*
*    Desc:    unpack the structure mgAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAuditInfo
(
MgAuditInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAuditInfo(param ,mBuf)
MgAuditInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgAuditInfo)

    CMCHKUNPK(SUnpkU16, &param->numTxn,mBuf);
    CMCHKUNPK(SUnpkU8, &param->moreTxn,mBuf);
    for (i=0;i<param->numTxn ;i++)
    {
       CMCHKUNPK(cmUnpkMgTransStatus, &param->transStatus[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAuditInfo*/

/*
*
*    Fun:    cmUnpkMgMgtAudit
*
*    Desc:    unpack the structure mgMgtAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgtAudit
(
MgMgtAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgtAudit(param ,mBuf)
MgMgtAudit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgtAudit)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKUNPK(cmUnpkMgAuditInfo, &param->auditInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgtAudit*/
#ifdef GCP_MGCP

/*
*
*    Fun:    cmUnpkMgPkgName
*
*    Desc:    unpack the structure MgPkgName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPkgName
(
MgPkgName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPkgName(param ,ptr, mBuf)
MgPkgName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgPkgName)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkgId,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPkgName*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgConnModVal
*
*    Desc:    unpack the structure MgConnModVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnModVal
(
MgConnModVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnModVal(param ,ptr, mBuf)
MgConnModVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnModVal)

    CMCHKUNPK(cmUnpkTknU8, &param->knownConnModVal,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->unKnownconnModVal, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnModVal*/

/*
*
*    Fun:    cmUnpkMgConnModeX
*
*    Desc:    unpack the structure MgConnModeX
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnModeX
(
MgConnModeX *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnModeX(param ,ptr, mBuf)
MgConnModeX *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnModeX)

    ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgConnModVal(&param->connModVal, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnModeX*/

/*
*
*    Fun:    cmUnpkMgConnMode
*
*    Desc:    unpack the structure MgConnMode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnMode
(
MgConnMode *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnMode(param ,ptr, mBuf)
MgConnMode *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnMode)

    CMCHKUNPK(cmUnpkTknU8, &param->stdOrXion,mBuf);
    ret1 = cmUnpkMgConnModeX(&param->xMode, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnMode*/
#endif

/*
*
*    Fun:    cmUnpkMgQuoteStr
*
*    Desc:    unpack the structure MgQuoteStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgQuoteStr
(
MgQuoteStr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgQuoteStr(param ,ptr, mBuf)
MgQuoteStr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgQuoteStr)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->str));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->str[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->str[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgQuoteStr*/

/*
*
*    Fun:    cmUnpkMgEvntParamType
*
*    Desc:    unpack the structure MgEvntParamType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntParamType
(
MgEvntParamType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntParamType(param ,ptr, mBuf)
MgEvntParamType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntParamType)

    CMCHKUNPK(cmUnpkTknU8, &param->eventParamType,mBuf);
    if( param->eventParamType.pres != NOTPRSNT )
    {
       switch( param->eventParamType.val )
       {
          case  MGT_TYPE_QUOTED_STR :
             ret1 = cmUnpkMgQuoteStr(&param->t.quotedStr, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TYPE_STR :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.paramStr, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntParamType*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpExtValSet
*
*    Desc:    unpack the structure MgMgcpExtValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpExtValSet
(
MgMgcpExtValSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpExtValSet(param ,ptr, mBuf)
MgMgcpExtValSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcpExtValSet)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->val));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpExtVal), (Ptr*)&(param->val[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpExtVal,  (param->val[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpExtValSet*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgNonStdExtn
*
*    Desc:    unpack the structure MgNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNonStdExtn
(
MgNonStdExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNonStdExtn(param ,ptr, mBuf)
MgNonStdExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNonStdExtn)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->extnName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpExtValSet(&param->val, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNonStdExtn*/
#else

/*
*
*    Fun:    cmUnpkMgNonStdExtn
*
*    Desc:    unpack the structure MgNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNonStdExtn
(
MgNonStdExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNonStdExtn(param ,ptr, mBuf)
MgNonStdExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNonStdExtn)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->extnName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->extnVal, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNonStdExtn*/
#endif

/*
*
*    Fun:    cmUnpkMgEPName
*
*    Desc:    unpack the structure MgEPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEPName
(
MgEPName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEPName(param ,ptr, mBuf)
MgEPName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEPName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->lclName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->domainName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEPName*/

/*
*
*    Fun:    cmUnpkMgMgcpVer
*
*    Desc:    unpack the structure MgMgcpVer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpVer
(
MgMgcpVer *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpVer(param ,ptr, mBuf)
MgMgcpVer *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpVer)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->major,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->minor,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->profName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpVer*/

/*
*
*    Fun:    cmUnpkMgMgcpVerSet
*
*    Desc:    unpack the structure MgMgcpVerSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpVerSet
(
MgMgcpVerSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpVerSet(param ,ptr, mBuf)
MgMgcpVerSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcpVerSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->versions));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpVer), (Ptr*)&(param->versions[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpVer,  (param->versions[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpVerSet*/

/*
*
*    Fun:    cmUnpkMgMgcpCmdLine
*
*    Desc:    unpack the structure MgMgcpCmdLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpCmdLine
(
MgMgcpCmdLine *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpCmdLine(param ,ptr, mBuf)
MgMgcpCmdLine *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpCmdLine)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->trId,mBuf);
       ret1 = cmUnpkMgEPName(&param->epName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpVer(&param->mgcpVer, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpCmdLine*/

/*
*
*    Fun:    cmUnpkMgRspAck
*
*    Desc:    unpack the structure mgRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRspAck
(
MgRspAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRspAck(param ,mBuf)
MgRspAck *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgRspAck)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->lowBnd,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->upperBnd,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRspAck*/

/*
*
*    Fun:    cmUnpkMgRspAckSet
*
*    Desc:    unpack the structure MgRspAckSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRspAckSet
(
MgRspAckSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRspAckSet(param ,ptr, mBuf)
MgRspAckSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRspAckSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rspAck));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRspAck), (Ptr*)&(param->rspAck[i]));
          CMCHKUNPK(cmUnpkMgRspAck,  (param->rspAck[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRspAckSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgEvntParamTypeSet
*
*    Desc:    unpack the structure MgEvntParamTypeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntParamTypeSet
(
MgEvntParamTypeSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntParamTypeSet(param ,ptr, mBuf)
MgEvntParamTypeSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgEvntParamTypeSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->evntParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgEvntOneParamType), (Ptr*)&(param->evntParam[i]));
          CMCHKUNPKPTR(cmUnpkMgEvntOneParamType,  (param->evntParam[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntParamTypeSet*/
#else

/*
*
*    Fun:    cmUnpkMgEvntParamTypeSet
*
*    Desc:    unpack the structure MgEvntParamTypeSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntParamTypeSet
(
MgEvntParamTypeSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntParamTypeSet(param ,ptr, mBuf)
MgEvntParamTypeSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgEvntParamTypeSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->evntParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgEvntParamType), (Ptr*)&(param->evntParam[i]));
          CMCHKUNPKPTR(cmUnpkMgEvntParamType,  (param->evntParam[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntParamTypeSet*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpName
*
*    Desc:    unpack the structure MgMgcpName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpName
(
MgMgcpName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpName(param ,ptr, mBuf)
MgMgcpName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpName)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->str, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpName*/

/*
*
*    Fun:    cmUnpkMgEvntOneParamTypeVal
*
*    Desc:    unpack the structure MgEvntOneParamTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntOneParamTypeVal
(
MgEvntOneParamTypeVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntOneParamTypeVal(param ,ptr, mBuf)
MgEvntOneParamTypeVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntOneParamTypeVal)

    ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgEvntParamType(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntOneParamTypeVal*/

/*
*
*    Fun:    cmUnpkMgEvntParamTypeValSet
*
*    Desc:    unpack the structure MgEvntParamTypeValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntParamTypeValSet
(
MgEvntParamTypeValSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntParamTypeValSet(param ,ptr, mBuf)
MgEvntParamTypeValSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntParamTypeValSet)

    ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgEvntParamTypeSet(&param->params, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntParamTypeValSet*/

/*
*
*    Fun:    cmUnpkMgEvntOneParamType
*
*    Desc:    unpack the structure MgEvntOneParamType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntOneParamType
(
MgEvntOneParamType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntOneParamType(param ,ptr, mBuf)
MgEvntOneParamType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntOneParamType)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVNT_PARAM_ONE_VAL :
             ret1 = cmUnpkMgEvntOneParamTypeVal(&param->t.oneParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVNT_PARAM_ONLY_VAL :
             ret1 = cmUnpkMgEvntParamType(&param->t.val, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVNT_PARAM_SET_VAL :
             ret1 = cmUnpkMgEvntParamTypeValSet(&param->t.paramSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntOneParamType*/

/*
*
*    Fun:    cmUnpkMgMgcpPkgSpcExtn
*
*    Desc:    unpack the structure MgMgcpPkgSpcExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpPkgSpcExtn
(
MgMgcpPkgSpcExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpPkgSpcExtn(param ,ptr, mBuf)
MgMgcpPkgSpcExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpPkgSpcExtn)

    ret1 = cmUnpkMgPkgName(&param->pkg, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcpName(&param->extnName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcpExtValSet(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpPkgSpcExtn*/

/*
*
*    Fun:    cmUnpkMgMgcpOthExtn
*
*    Desc:    unpack the structure MgMgcpOthExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpOthExtn
(
MgMgcpOthExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpOthExtn(param ,ptr, mBuf)
MgMgcpOthExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpOthExtn)

    CMCHKUNPK(cmUnpkTknStr32, &param->name,mBuf);
    ret1 = cmUnpkMgMgcpExtValSet(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpOthExtn*/

/*
*
*    Fun:    cmUnpkMgMgcpExtn
*
*    Desc:    unpack the structure MgMgcpExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpExtn
(
MgMgcpExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpExtn(param ,ptr, mBuf)
MgMgcpExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpExtn)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_LCL_CONNOPT_OTHR_EXT :
             ret1 = cmUnpkMgMgcpOthExtn(&param->t.othrX, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_PKG_EXT :
             ret1 = cmUnpkMgMgcpPkgSpcExtn(&param->t.pkgX, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_VNDR_EXT :
             ret1 = cmUnpkMgNonStdExtn(&param->t.vndrX, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpExtn*/

/*
*
*    Fun:    cmUnpkMgMgcpPkgSpcExtnParam
*
*    Desc:    unpack the structure MgMgcpPkgSpcExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpPkgSpcExtnParam
(
MgMgcpPkgSpcExtnParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpPkgSpcExtnParam(param ,ptr, mBuf)
MgMgcpPkgSpcExtnParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpPkgSpcExtnParam)

    ret1 = cmUnpkMgPkgName(&param->pkg, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcpName(&param->extnName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpPkgSpcExtnParam*/

/*
*
*    Fun:    cmUnpkMgNonStdExtnParam
*
*    Desc:    unpack the structure MgNonStdExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNonStdExtnParam
(
MgNonStdExtnParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNonStdExtnParam(param ,ptr, mBuf)
MgNonStdExtnParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNonStdExtnParam)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->extnName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNonStdExtnParam*/

/*
*
*    Fun:    cmUnpkMgMgcpExtnParam
*
*    Desc:    unpack the structure MgMgcpExtnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpExtnParam
(
MgMgcpExtnParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpExtnParam(param ,ptr, mBuf)
MgMgcpExtnParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpExtnParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_EXTN_PARAM_OTHER :
             CMCHKUNPK(cmUnpkTknStr32, &param->t.othrXParam,mBuf);
             break;
          case  MGT_MGCP_EXTN_PARAM_PKG :
             ret1 = cmUnpkMgMgcpPkgSpcExtnParam(&param->t.pkgXParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_EXTN_PARAM_VNDR :
             ret1 = cmUnpkMgNonStdExtnParam(&param->t.vndrXParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpExtnParam*/

/*
*
*    Fun:    cmUnpkMgMgcpBrrAttr
*
*    Desc:    unpack the structure MgMgcpBrrAttr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpBrrAttr
(
MgMgcpBrrAttr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpBrrAttr(param ,ptr, mBuf)
MgMgcpBrrAttr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpBrrAttr)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCP_BRR_ENCODING :
             CMCHKUNPK(cmUnpkTknU8, &param->t.brrEncd,mBuf);
             break;
          case  MGT_MGCP_BRR_EXTN :
             ret1 = cmUnpkMgMgcpPkgSpcExtn(&param->t.brrExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpBrrAttr*/

/*
*
*    Fun:    cmUnpkMgBearerInfo
*
*    Desc:    unpack the structure MgBearerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgBearerInfo
(
MgBearerInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgBearerInfo(param ,ptr, mBuf)
MgBearerInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgBearerInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->bearerEnc));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpBrrAttr), (Ptr*)&(param->bearerEnc[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpBrrAttr,  (param->bearerEnc[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgBearerInfo*/
#else

/*
*
*    Fun:    cmUnpkMgBearerInfo
*
*    Desc:    unpack the structure MgBearerInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgBearerInfo
(
MgBearerInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgBearerInfo(param ,ptr, mBuf)
MgBearerInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgBearerInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->bearerEnc));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->bearerEnc[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->bearerEnc[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgBearerInfo*/
#endif

/*
*
*    Fun:    cmUnpkMgConnIdSet
*
*    Desc:    unpack the structure MgConnIdSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnIdSet
(
MgConnIdSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnIdSet(param ,ptr, mBuf)
MgConnIdSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgConnIdSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->connId));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgConnId), (Ptr*)&(param->connId[i]));
          CMCHKUNPK(cmUnpkMgConnId,  (param->connId[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnIdSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgNtfiedEnt
*
*    Desc:    unpack the structure MgNtfiedEnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNtfiedEnt
(
MgNtfiedEnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNtfiedEnt(param ,ptr, mBuf)
MgNtfiedEnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNtfiedEnt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->lclName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->domainName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNtfiedEnt*/
#else

/*
*
*    Fun:    cmUnpkMgNtfiedEnt
*
*    Desc:    unpack the structure MgNtfiedEnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNtfiedEnt
(
MgNtfiedEnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNtfiedEnt(param ,ptr, mBuf)
MgNtfiedEnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNtfiedEnt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr32, &param->lclName,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->domainName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNtfiedEnt*/
#endif

/*
*
*    Fun:    cmUnpkMgSuppPkgs
*
*    Desc:    unpack the structure MgSuppPkgs
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSuppPkgs
(
MgSuppPkgs *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSuppPkgs(param ,ptr, mBuf)
MgSuppPkgs *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgSuppPkgs)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->pkgName));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgPkgName), (Ptr*)&(param->pkgName[i]));
          CMCHKUNPKPTR(cmUnpkMgPkgName,  (param->pkgName[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSuppPkgs*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgSuppModes
*
*    Desc:    unpack the structure MgSuppModes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSuppModes
(
MgSuppModes *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSuppModes(param ,ptr, mBuf)
MgSuppModes *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgSuppModes)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->mode));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgConnMode), (Ptr*)&(param->mode[i]));
          ret1 = cmUnpkMgConnMode( (param->mode[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSuppModes*/
#else

/*
*
*    Fun:    cmUnpkMgSuppModes
*
*    Desc:    unpack the structure MgSuppModes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSuppModes
(
MgSuppModes *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSuppModes(param ,ptr, mBuf)
MgSuppModes *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgSuppModes)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->mode));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->mode[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->mode[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSuppModes*/
#endif

/*
*
*    Fun:    cmUnpkMgEncryptInfo
*
*    Desc:    unpack the structure MgEncryptInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEncryptInfo
(
MgEncryptInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEncryptInfo(param ,ptr, mBuf)
MgEncryptInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEncryptInfo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->encryptMethod,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->encryptKey, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEncryptInfo*/

/*
*
*    Fun:    cmUnpkMgGainCtrl
*
*    Desc:    unpack the structure mgGainCtrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgGainCtrl
(
MgGainCtrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgGainCtrl(param ,mBuf)
MgGainCtrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgGainCtrl)

    CMCHKUNPK(cmUnpkTknU8, &param->ctrlType,mBuf);
    CMCHKUNPK(cmUnpkTknS16, &param->gainVal,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgGainCtrl*/
#ifdef MGT_GCP_VER_1_4

/*
*
*    Fun:    cmUnpkMgAlgoNameSet
*
*    Desc:    unpack the structure MgAlgoNameSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAlgoNameSet
(
MgAlgoNameSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAlgoNameSet(param ,ptr, mBuf)
MgAlgoNameSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgAlgoNameSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->algoName));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->algoName[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->algoName[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAlgoNameSet*/
#else /* MGT_GCP_VER_1_4 */

/*
*
*    Fun:    cmUnpkMgAlgoNameSet
*
*    Desc:    unpack the structure MgAlgoNameSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAlgoNameSet
(
MgAlgoNameSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAlgoNameSet(param ,ptr, mBuf)
MgAlgoNameSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgAlgoNameSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->algoName));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStr32), (Ptr*)&(param->algoName[i]));
          CMCHKUNPK(cmUnpkTknStr32,  (param->algoName[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAlgoNameSet*/
#endif /* MGT_GCP_VER_1_4 */

/*
*
*    Fun:    cmUnpkMgBw
*
*    Desc:    unpack the structure mgBw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgBw
(
MgBw *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgBw(param ,mBuf)
MgBw *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgBw)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->lowBnd,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->upperBnd,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgBw*/

/*
*
*    Fun:    cmUnpkMgPktzPeriod
*
*    Desc:    unpack the structure mgPktzPeriod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPktzPeriod
(
MgPktzPeriod *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPktzPeriod(param ,mBuf)
MgPktzPeriod *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPktzPeriod)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->lowBnd,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->upperBnd,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPktzPeriod*/

/*
*
*    Fun:    cmUnpkMgRsvDest
*
*    Desc:    unpack the structure MgRsvDest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRsvDest
(
MgRsvDest *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRsvDest(param ,ptr, mBuf)
MgRsvDest *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRsvDest)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->domainName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRsvDest*/

/*
*
*    Fun:    cmUnpkMgSecret
*
*    Desc:    unpack the structure MgSecret
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSecret
(
MgSecret *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSecret(param ,ptr, mBuf)
MgSecret *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgSecret)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->method,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->key, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSecret*/

/*
*
*    Fun:    cmUnpkMgAuthEncAlgoSet
*
*    Desc:    unpack the structure MgAuthEncAlgoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAuthEncAlgoSet
(
MgAuthEncAlgoSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAuthEncAlgoSet(param ,ptr, mBuf)
MgAuthEncAlgoSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgAuthEncAlgoSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->suites));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->suites[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->suites[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAuthEncAlgoSet*/

/*
*
*    Fun:    cmUnpkMgCipherSuite
*
*    Desc:    unpack the structure MgCipherSuite
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgCipherSuite
(
MgCipherSuite *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgCipherSuite(param ,ptr, mBuf)
MgCipherSuite *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgCipherSuite)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgAuthEncAlgoSet(&param->authAlgoSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgAuthEncAlgoSet(&param->encAlgoSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgCipherSuite*/

/*
*
*    Fun:    cmUnpkMgRsrcRsvSet
*
*    Desc:    unpack the structure MgRsrcRsvSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRsrcRsvSet
(
MgRsrcRsvSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRsrcRsvSet(param ,ptr, mBuf)
MgRsrcRsvSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRsrcRsvSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->reservations));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->reservations[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->reservations[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRsrcRsvSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgTypNwSupp
*
*    Desc:    unpack the structure MgTypNwSupp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTypNwSupp
(
MgTypNwSupp *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTypNwSupp(param ,ptr, mBuf)
MgTypNwSupp *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgTypNwSupp)

    CMCHKUNPK(cmUnpkTknU8, &param->stdOrOthr,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->othrNwTyp, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgTypNwSupp*/

/*
*
*    Fun:    cmUnpkMgTypNwSuppSeq
*
*    Desc:    unpack the structure MgTypNwSuppSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTypNwSuppSeq
(
MgTypNwSuppSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTypNwSuppSeq(param ,ptr, mBuf)
MgTypNwSuppSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgTypNwSuppSeq)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->typeOfNetwork));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgTypNwSupp), (Ptr*)&(param->typeOfNetwork[i]));
          CMCHKUNPKPTR(cmUnpkMgTypNwSupp,  (param->typeOfNetwork[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgTypNwSuppSeq*/

/*
*
*    Fun:    cmUnpkMgNwTypeChc
*
*    Desc:    unpack the structure MgNwTypeChc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNwTypeChc
(
MgNwTypeChc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNwTypeChc(param ,ptr, mBuf)
MgNwTypeChc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgNwTypeChc)

    CMCHKUNPK(cmUnpkTknU8, &param->oneOrmany,mBuf);
    if( param->oneOrmany.pres != NOTPRSNT )
    {
       switch( param->oneOrmany.val )
       {
          case  MGT_MGCP_SUPP_TONS :
             ret1 = cmUnpkMgTypNwSuppSeq(&param->u.typNwSuppSeq, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_TON :
             ret1 = cmUnpkMgTypNwSupp(&param->u.typNwSupp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNwTypeChc*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmUnpkMgMgcpLclFmtpVal
*
*    Desc:    unpack the structure MgMgcpLclFmtpVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpLclFmtpVal
(
MgMgcpLclFmtpVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpLclFmtpVal(param ,ptr, mBuf)
MgMgcpLclFmtpVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpLclFmtpVal)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->codecName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->codecInst,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->formatName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpLclFmtpVal*/

/*
*
*    Fun:    cmUnpkMgMgcpLclFmtpValSet
*
*    Desc:    unpack the structure MgMgcpLclFmtpValSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpLclFmtpValSet
(
MgMgcpLclFmtpValSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpLclFmtpValSet(param ,ptr, mBuf)
MgMgcpLclFmtpValSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcpLclFmtpValSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->val));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpLclFmtpVal), (Ptr*)&(param->val[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpLclFmtpVal,  (param->val[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpLclFmtpValSet*/

/*
*
*    Fun:    cmUnpkMgMgcpLclRsSh
*
*    Desc:    unpack the structure mgMgcpLclRsSh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpLclRsSh
(
MgMgcpLclRsSh *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpLclRsSh(param ,mBuf)
MgMgcpLclRsSh *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcpLclRsSh)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkMgConnId, &param->connId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpLclRsSh*/

/*
*
*    Fun:    cmUnpkMgLclConnOpts
*
*    Desc:    unpack the structure MgLclConnOpts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgLclConnOpts
(
MgLclConnOpts *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgLclConnOpts(param ,ptr, mBuf)
MgLclConnOpts *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgLclConnOpts)

    CMCHKUNPK(cmUnpkTknU8, &param->valType,mBuf);
    if( param->valType.pres != NOTPRSNT )
    {
       switch( param->valType.val )
       {
          case  MGT_LCL_CONNOPT_ALGO_NAME :
             ret1 = cmUnpkMgAlgoNameSet(&param->t.algoNameSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_BW :
             CMCHKUNPK(cmUnpkMgBw, &param->t.mgBw,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_GATEID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.dqosGateId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.dqosRsrcId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCRSV :
             ret1 = cmUnpkMgRsrcRsvSet(&param->t.dqosRsrcRsv, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSVDEST :
             ret1 = cmUnpkMgRsvDest(&param->t.dqosRsvDest, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_ECHO_CAN :
             CMCHKUNPK(cmUnpkTknU8, &param->t.ecancel,mBuf);
             break;
          case  MGT_LCL_CONNOPT_ENCRYPT_INFO :
             ret1 = cmUnpkMgEncryptInfo(&param->t.encryptInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_GAIN_CTRL :
             CMCHKUNPK(cmUnpkMgGainCtrl, &param->t.gainCtrl,mBuf);
             break;
#ifdef GCP_2705BIS
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmUnpkMgMgcpExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS  */
#ifdef GCP_2705BIS
#else /* ,,,,,,,,,,,, */ 
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmUnpkMgNonStdExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS,#else  */
          case  MGT_LCL_CONNOPT_PKTZ_PERIOD :
             CMCHKUNPK(cmUnpkMgPktzPeriod, &param->t.pktzPeriod,mBuf);
             break;
          case  MGT_LCL_CONNOPT_RSRC_RESV :
             CMCHKUNPK(cmUnpkTknU8, &param->t.rsrcResv,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SEC_RTCPSUITE :
             ret1 = cmUnpkMgCipherSuite(&param->t.secRtcpSuite, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_RTPSUITE :
             ret1 = cmUnpkMgCipherSuite(&param->t.secRtpSuite, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_SECRET :
             ret1 = cmUnpkMgSecret(&param->t.secSecret, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SIL_SUPP :
             CMCHKUNPK(cmUnpkTknU8, &param->t.silSupp,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SUPP_MODES :
             ret1 = cmUnpkMgSuppModes(&param->t.suppModes, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SUPP_PKGS :
             ret1 = cmUnpkMgSuppPkgs(&param->t.suppPkgs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#ifdef GCP_2705BIS
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             ret1 = cmUnpkMgNwTypeChc(&param->t.typeOfNetwork, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*  GCP_2705BIS  */
#ifdef GCP_2705BIS
#else /* ,,,,,,,,,,,, */ 
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             CMCHKUNPK(cmUnpkTknU8, &param->t.typeOfNetwork,mBuf);
             break;
#endif /*  GCP_2705BIS,#else  */
          case  MGT_LCL_CONNOPT_TYPE_SRVC :
             CMCHKUNPK(cmUnpkTknU16, &param->t.typeOfSrvc,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_FMTP :
             ret1 = cmUnpkMgMgcpLclFmtpValSet(&param->t.fmtp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_OPT_FMTP :
             ret1 = cmUnpkMgMgcpLclFmtpValSet(&param->t.fmtp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_CNFM :
             CMCHKUNPK(cmUnpkTknU8, &param->t.rsCnf,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_DIR :
             CMCHKUNPK(cmUnpkTknU8, &param->t.rsDir,mBuf);
             break;
          case  MGT_MGCP_LCL_CONNOPT_RES_SHARE :
             CMCHKUNPK(cmUnpkMgMgcpLclRsSh, &param->t.rsSh,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgLclConnOpts*/
#else

/*
*
*    Fun:    cmUnpkMgLclConnOpts
*
*    Desc:    unpack the structure MgLclConnOpts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgLclConnOpts
(
MgLclConnOpts *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgLclConnOpts(param ,ptr, mBuf)
MgLclConnOpts *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgLclConnOpts)

    CMCHKUNPK(cmUnpkTknU8, &param->valType,mBuf);
    if( param->valType.pres != NOTPRSNT )
    {
       switch( param->valType.val )
       {
          case  MGT_LCL_CONNOPT_ALGO_NAME :
             ret1 = cmUnpkMgAlgoNameSet(&param->t.algoNameSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_BW :
             CMCHKUNPK(cmUnpkMgBw, &param->t.mgBw,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_GATEID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.dqosGateId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.dqosRsrcId,mBuf);
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSRCRSV :
             ret1 = cmUnpkMgRsrcRsvSet(&param->t.dqosRsrcRsv, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_DQOS_RSVDEST :
             ret1 = cmUnpkMgRsvDest(&param->t.dqosRsvDest, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_ECHO_CAN :
             CMCHKUNPK(cmUnpkTknU8, &param->t.ecancel,mBuf);
             break;
          case  MGT_LCL_CONNOPT_ENCRYPT_INFO :
             ret1 = cmUnpkMgEncryptInfo(&param->t.encryptInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_GAIN_CTRL :
             CMCHKUNPK(cmUnpkMgGainCtrl, &param->t.gainCtrl,mBuf);
             break;
          case  MGT_LCL_CONNOPT_NON_STD :
             ret1 = cmUnpkMgNonStdExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_PKTZ_PERIOD :
             CMCHKUNPK(cmUnpkMgPktzPeriod, &param->t.pktzPeriod,mBuf);
             break;
          case  MGT_LCL_CONNOPT_RSRC_RESV :
             CMCHKUNPK(cmUnpkTknU8, &param->t.rsrcResv,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SEC_RTCPSUITE :
             ret1 = cmUnpkMgCipherSuite(&param->t.secRtcpSuite, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_RTPSUITE :
             ret1 = cmUnpkMgCipherSuite(&param->t.secRtpSuite, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SEC_SECRET :
             ret1 = cmUnpkMgSecret(&param->t.secSecret, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SIL_SUPP :
             CMCHKUNPK(cmUnpkTknU8, &param->t.silSupp,mBuf);
             break;
          case  MGT_LCL_CONNOPT_SUPP_MODES :
             ret1 = cmUnpkMgSuppModes(&param->t.suppModes, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_SUPP_PKGS :
             ret1 = cmUnpkMgSuppPkgs(&param->t.suppPkgs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCL_CONNOPT_TYPE_OF_NET :
             CMCHKUNPK(cmUnpkTknU8, &param->t.typeOfNetwork,mBuf);
             break;
          case  MGT_LCL_CONNOPT_TYPE_SRVC :
             CMCHKUNPK(cmUnpkTknU16, &param->t.typeOfSrvc,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgLclConnOpts*/
#endif

/*
*
*    Fun:    cmUnpkMgLclConnOptSet
*
*    Desc:    unpack the structure MgLclConnOptSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgLclConnOptSet
(
MgLclConnOptSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgLclConnOptSet(param ,ptr, mBuf)
MgLclConnOptSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgLclConnOptSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->lclConnOpt));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgLclConnOpts), (Ptr*)&(param->lclConnOpt[i]));
          CMCHKUNPKPTR(cmUnpkMgLclConnOpts,  (param->lclConnOpt[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgLclConnOptSet*/
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmUnpkMgEventDesc
*
*    Desc:    unpack the structure MgEventDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEventDesc
(
MgEventDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEventDesc(param ,ptr, mBuf)
MgEventDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEventDesc)

    CMCHKUNPK(cmUnpkTknU8, &param->descType,mBuf);
    if( param->descType.pres != NOTPRSNT )
    {
       switch( param->descType.val )
       {
          case  MGT_DESC_EVENT_ALL :
             break;
          case  MGT_DESC_EVENT_DTMF_POUND :
             break;
          case  MGT_DESC_EVENT_DTMF_STAR :
             break;
          case  MGT_DESC_EVENT_ID :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.eventId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DESC_EVENT_KNOWN :
             CMCHKUNPK(cmUnpkTknU16, &param->t.eventKnown,mBuf);
             break;
          case  MGT_DESC_EVENT_RANGE :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.eventRange, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEventDesc*/
#else

/*
*
*    Fun:    cmUnpkMgEventDesc
*
*    Desc:    unpack the structure MgEventDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEventDesc
(
MgEventDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEventDesc(param ,ptr, mBuf)
MgEventDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEventDesc)

    CMCHKUNPK(cmUnpkTknU8, &param->descType,mBuf);
    if( param->descType.pres != NOTPRSNT )
    {
       switch( param->descType.val )
       {
          case  MGT_DESC_EVENT_ALL :
             break;
          case  MGT_DESC_EVENT_ID :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.eventId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DESC_EVENT_KNOWN :
             CMCHKUNPK(cmUnpkTknU16, &param->t.eventKnown,mBuf);
             break;
          case  MGT_DESC_EVENT_RANGE :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.eventRange, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEventDesc*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmUnpkMgEvntName
*
*    Desc:    unpack the structure MgEvntName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntName
(
MgEvntName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntName(param ,ptr, mBuf)
MgEvntName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->pkgPres,mBuf);
       ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgEventDesc(&param->eventDesc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknStr32, &param->connId,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntName*/
#else

/*
*
*    Fun:    cmUnpkMgEvntName
*
*    Desc:    unpack the structure MgEvntName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEvntName
(
MgEvntName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEvntName(param ,ptr, mBuf)
MgEvntName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgEvntName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgEventDesc(&param->eventDesc, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknStr32, &param->connId,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEvntName*/
#endif

/*
*
*    Fun:    cmUnpkMgSignalRqst
*
*    Desc:    unpack the structure MgSignalRqst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSignalRqst
(
MgSignalRqst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSignalRqst(param ,ptr, mBuf)
MgSignalRqst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgSignalRqst)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgEvntName(&param->evntName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgEvntParamTypeSet(&param->evntParamSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSignalRqst*/

/*
*
*    Fun:    cmUnpkMgSignalRqstSet
*
*    Desc:    unpack the structure MgSignalRqstSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSignalRqstSet
(
MgSignalRqstSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSignalRqstSet(param ,ptr, mBuf)
MgSignalRqstSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgSignalRqstSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->signalRqst));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgSignalRqst), (Ptr*)&(param->signalRqst[i]));
          CMCHKUNPKPTR(cmUnpkMgSignalRqst,  (param->signalRqst[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSignalRqstSet*/
#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCP_PARSE_DIG_MAP) 
#else

/*
*
*    Fun:    cmUnpkMgDgtMap
*
*    Desc:    unpack the structure MgDgtMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDgtMap
(
MgDgtMap *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDgtMap(param ,ptr, mBuf)
MgDgtMap *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgDgtMap)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->dgtStr));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->dgtStr[i]));
          CMCHKUNPKPTR(cmUnpkMacroTknStrOSXL,  (param->dgtStr[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgDgtMap*/
#endif

/*
*
*    Fun:    cmUnpkMgRqstdActnSet
*
*    Desc:    unpack the structure MgRqstdActnSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdActnSet
(
MgRqstdActnSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdActnSet(param ,ptr, mBuf)
MgRqstdActnSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRqstdActnSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rqstdActn));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRqstdActn), (Ptr*)&(param->rqstdActn[i]));
          CMCHKUNPKPTR(cmUnpkMgRqstdActn,  (param->rqstdActn[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdActnSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgRqstdEvntSeq
*
*    Desc:    unpack the structure MgRqstdEvntSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdEvntSeq
(
MgRqstdEvntSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdEvntSeq(param ,ptr, mBuf)
MgRqstdEvntSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRqstdEvntSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgEvntName(&param->evntName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgRqstdActnSet(&param->rqstdActnSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgEvntParamTypeSet(&param->evntParamSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdEvntSeq*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgRqstdEvntSet
*
*    Desc:    unpack the structure MgRqstdEvntSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdEvntSet
(
MgRqstdEvntSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdEvntSet(param ,ptr, mBuf)
MgRqstdEvntSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRqstdEvntSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rqstdEvnt));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRqstdEvntSeq), (Ptr*)&(param->rqstdEvnt[i]));
          CMCHKUNPKPTR(cmUnpkMgRqstdEvntSeq,  (param->rqstdEvnt[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdEvntSet*/
#else

/*
*
*    Fun:    cmUnpkMgRqstdEvntSet
*
*    Desc:    unpack the structure MgRqstdEvntSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdEvntSet
(
MgRqstdEvntSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdEvntSet(param ,ptr, mBuf)
MgRqstdEvntSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRqstdEvntSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rqstdEvnt));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRqstdEvnt), (Ptr*)&(param->rqstdEvnt[i]));
          CMCHKUNPKPTR(cmUnpkMgRqstdEvnt,  (param->rqstdEvnt[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdEvntSet*/
#endif

/*
*
*    Fun:    cmUnpkMgRqstEmbedType
*
*    Desc:    unpack the structure MgRqstEmbedType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstEmbedType
(
MgRqstEmbedType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstEmbedType(param ,ptr, mBuf)
MgRqstEmbedType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRqstEmbedType)

    CMCHKUNPK(cmUnpkTknU8, &param->embdRqstType,mBuf);
    if( param->embdRqstType.pres != NOTPRSNT )
    {
       switch( param->embdRqstType.val )
       {
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmUnpkMgDgtMap(&param->t.dgtMap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmUnpkMgRqstdEvntSet(&param->t.rqstdEvntSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.signalRqstSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstEmbedType*/

/*
*
*    Fun:    cmUnpkMgEmbedActn
*
*    Desc:    unpack the structure MgEmbedActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEmbedActn
(
MgEmbedActn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEmbedActn(param ,ptr, mBuf)
MgEmbedActn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgEmbedActn)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rqstdEmbed));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRqstEmbedType), (Ptr*)&(param->rqstdEmbed[i]));
          CMCHKUNPKPTR(cmUnpkMgRqstEmbedType,  (param->rqstdEmbed[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEmbedActn*/

/*
*
*    Fun:    cmUnpkMgRqstEmbedMDCXMode
*
*    Desc:    unpack the structure mgRqstEmbedMDCXMode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstEmbedMDCXMode
(
MgRqstEmbedMDCXMode *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstEmbedMDCXMode(param ,mBuf)
MgRqstEmbedMDCXMode *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgRqstEmbedMDCXMode)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->connMode,mBuf);
       CMCHKUNPK(cmUnpkTknStr32, &param->connId,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstEmbedMDCXMode*/

/*
*
*    Fun:    cmUnpkMgEmbedMDCX
*
*    Desc:    unpack the structure MgEmbedMDCX
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEmbedMDCX
(
MgEmbedMDCX *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEmbedMDCX(param ,ptr, mBuf)
MgEmbedMDCX *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgEmbedMDCX)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->modes));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgRqstEmbedMDCXMode), (Ptr*)&(param->modes[i]));
          CMCHKUNPK(cmUnpkMgRqstEmbedMDCXMode,  (param->modes[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgEmbedMDCX*/

/*
*
*    Fun:    cmUnpkMgAction
*
*    Desc:    unpack the structure MgAction
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAction
(
MgAction *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAction(param ,ptr, mBuf)
MgAction *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgAction)

    CMCHKUNPK(cmUnpkTknU8, &param->knownAction,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->unknownAction, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAction*/

/*
*
*    Fun:    cmUnpkMgPkgXActn
*
*    Desc:    unpack the structure MgPkgXActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPkgXActn
(
MgPkgXActn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPkgXActn(param ,ptr, mBuf)
MgPkgXActn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgPkgXActn)

    ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgAction(&param->action, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgEvntParamTypeSet(&param->actnparms, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPkgXActn*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgRqstdActn
*
*    Desc:    unpack the structure MgRqstdActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdActn
(
MgRqstdActn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdActn(param ,ptr, mBuf)
MgRqstdActn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRqstdActn)

    CMCHKUNPK(cmUnpkTknU8, &param->actionType,mBuf);
    if( param->actionType.pres != NOTPRSNT )
    {
       switch( param->actionType.val )
       {
          case  MGT_RQSTD_ACTN_A :
             break;
          case  MGT_RQSTD_ACTN_D :
             break;
          case  MGT_RQSTD_ACTN_EMB :
             ret1 = cmUnpkMgEmbedActn(&param->u.embedActn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_EXTN :
             ret1 = cmUnpkMgPkgXActn(&param->u.Xactn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_I :
             break;
          case  MGT_RQSTD_ACTN_K :
             break;
          case  MGT_RQSTD_ACTN_MDCX :
             ret1 = cmUnpkMgEmbedMDCX(&param->u.mdcx, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_N :
             break;
          case  MGT_RQSTD_ACTN_S :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdActn*/
#else

/*
*
*    Fun:    cmUnpkMgRqstdActn
*
*    Desc:    unpack the structure MgRqstdActn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdActn
(
MgRqstdActn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdActn(param ,ptr, mBuf)
MgRqstdActn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRqstdActn)

    CMCHKUNPK(cmUnpkTknU8, &param->actionType,mBuf);
    if( param->actionType.pres != NOTPRSNT )
    {
       switch( param->actionType.val )
       {
          case  MGT_RQSTD_ACTN_A :
             break;
          case  MGT_RQSTD_ACTN_D :
             break;
          case  MGT_RQSTD_ACTN_EMB :
             ret1 = cmUnpkMgEmbedActn(&param->u.embedActn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_I :
             break;
          case  MGT_RQSTD_ACTN_K :
             break;
          case  MGT_RQSTD_ACTN_MDCX :
             ret1 = cmUnpkMgEmbedMDCX(&param->u.mdcx, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_RQSTD_ACTN_N :
             break;
          case  MGT_RQSTD_ACTN_S :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdActn*/
#endif

/*
*
*    Fun:    cmUnpkMgRqstdEvnt
*
*    Desc:    unpack the structure MgRqstdEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdEvnt
(
MgRqstdEvnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdEvnt(param ,ptr, mBuf)
MgRqstdEvnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRqstdEvnt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgEvntName(&param->evntName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgRqstdActnSet(&param->rqstdActnSet, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdEvnt*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgPkgCPName
*
*    Desc:    unpack the structure MgPkgCPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPkgCPName
(
MgPkgCPName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPkgCPName(param ,ptr, mBuf)
MgPkgCPName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgPkgCPName)

    CMCHKUNPK(cmUnpkTknU8, &param->knownCpName,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->cpName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPkgCPName*/

/*
*
*    Fun:    cmUnpkMgPkgCPXNm
*
*    Desc:    unpack the structure MgPkgCPXNm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPkgCPXNm
(
MgPkgCPXNm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPkgCPXNm(param ,ptr, mBuf)
MgPkgCPXNm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgPkgCPXNm)

    ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgPkgCPName(&param->cpName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPkgCPXNm*/

/*
*
*    Fun:    cmUnpkMgCPName
*
*    Desc:    unpack the structure MgCPName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgCPName
(
MgCPName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgCPName(param ,ptr, mBuf)
MgCPName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgCPName)

    CMCHKUNPK(cmUnpkTknU8, &param->vndrOrPkg,mBuf);
    if( param->vndrOrPkg.pres != NOTPRSNT )
    {
       switch( param->vndrOrPkg.val )
       {
          case  MGT_MGCP_CONN_PAR_PKG_EXTN :
             ret1 = cmUnpkMgPkgCPXNm(&param->t.pkgXName, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCP_CONN_PAR_VNDR_EXTN :
             ret1 = cmUnpkMacroTknStrOSXL(&param->t.vndrXName, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgCPName*/

/*
*
*    Fun:    cmUnpkMgConnParExtn
*
*    Desc:    unpack the structure MgConnParExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnParExtn
(
MgConnParExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnParExtn(param ,ptr, mBuf)
MgConnParExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnParExtn)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgCPName(&param->paramName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->paramVal, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnParExtn*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgConnParam
*
*    Desc:    unpack the structure MgConnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnParam
(
MgConnParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnParam(param ,ptr, mBuf)
MgConnParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnParam)

    CMCHKUNPK(cmUnpkTknU8, &param->paramType,mBuf);
    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_CONN_PARAM_JI :
             CMCHKUNPK(cmUnpkTknU32, &param->t.jitter,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_LA :
             CMCHKUNPK(cmUnpkTknU32, &param->t.avgLatency,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_NONSTD :
             ret1 = cmUnpkMgConnParExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM_OR :
             CMCHKUNPK(cmUnpkTknU32, &param->t.octetsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_OS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.octetsSent,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PL :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsLost,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PR :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsSent,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnParam*/
#else

/*
*
*    Fun:    cmUnpkMgConnParam
*
*    Desc:    unpack the structure MgConnParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnParam
(
MgConnParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnParam(param ,ptr, mBuf)
MgConnParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgConnParam)

    CMCHKUNPK(cmUnpkTknU8, &param->paramType,mBuf);
    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_CONN_PARAM_JI :
             CMCHKUNPK(cmUnpkTknU32, &param->t.jitter,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_LA :
             CMCHKUNPK(cmUnpkTknU32, &param->t.avgLatency,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_NONSTD :
             ret1 = cmUnpkMgNonStdExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM_OR :
             CMCHKUNPK(cmUnpkTknU32, &param->t.octetsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_OS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.octetsSent,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PL :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsLost,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PR :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsRcvd,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM_PS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.pktsSent,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnParam*/
#endif

/*
*
*    Fun:    cmUnpkMgConnParamSet
*
*    Desc:    unpack the structure MgConnParamSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgConnParamSet
(
MgConnParamSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgConnParamSet(param ,ptr, mBuf)
MgConnParamSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgConnParamSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->connParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgConnParam), (Ptr*)&(param->connParam[i]));
          CMCHKUNPKPTR(cmUnpkMgConnParam,  (param->connParam[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgConnParamSet*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgReasonCode
*
*    Desc:    unpack the structure MgReasonCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgReasonCode
(
MgReasonCode *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgReasonCode(param ,ptr, mBuf)
MgReasonCode *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgReasonCode)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->code,mBuf);
       ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->param, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgReasonCode*/
#else

/*
*
*    Fun:    cmUnpkMgReasonCode
*
*    Desc:    unpack the structure MgReasonCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgReasonCode
(
MgReasonCode *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgReasonCode(param ,ptr, mBuf)
MgReasonCode *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgReasonCode)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->code,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->param, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgReasonCode*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkInfoCode
*
*    Desc:    unpack the structure InfoCode
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkInfoCode
(
InfoCode *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkInfoCode(param ,ptr, mBuf)
InfoCode *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkInfoCode)

    CMCHKUNPK(cmUnpkTknU8, &param->codeType,mBuf);
    ret1 = cmUnpkMgMgcpExtnParam(&param->xParam, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkInfoCode*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgRqstdInfo
*
*    Desc:    unpack the structure MgRqstdInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdInfo
(
MgRqstdInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdInfo(param ,ptr, mBuf)
MgRqstdInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgRqstdInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->infoCode));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(InfoCode), (Ptr*)&(param->infoCode[i]));
          ret1 = cmUnpkInfoCode( (param->infoCode[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdInfo*/
#else

/*
*
*    Fun:    cmUnpkMgRqstdInfo
*
*    Desc:    unpack the structure MgRqstdInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRqstdInfo
(
MgRqstdInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRqstdInfo(param ,ptr, mBuf)
MgRqstdInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgRqstdInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->infoCode));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->infoCode[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->infoCode[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRqstdInfo*/
#endif

/*
*
*    Fun:    cmUnpkMgQrntHandling
*
*    Desc:    unpack the structure MgQrntHandling
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgQrntHandling
(
MgQrntHandling *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgQrntHandling(param ,ptr, mBuf)
MgQrntHandling *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgQrntHandling)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->ctrl));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->ctrl[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->ctrl[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgQrntHandling*/

/*
*
*    Fun:    cmUnpkMgDetectEvent
*
*    Desc:    unpack the structure MgDetectEvent
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDetectEvent
(
MgDetectEvent *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDetectEvent(param ,ptr, mBuf)
MgDetectEvent *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgDetectEvent)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->evnt));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgEvntName), (Ptr*)&(param->evnt[i]));
          CMCHKUNPKPTR(cmUnpkMgEvntName,  (param->evnt[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgDetectEvent*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgRsrtMethod
*
*    Desc:    unpack the structure MgRsrtMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgRsrtMethod
(
MgRsrtMethod *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgRsrtMethod(param ,ptr, mBuf)
MgRsrtMethod *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgRsrtMethod)

    CMCHKUNPK(cmUnpkTknU8, &param->stdOrXten,mBuf);
    ret1 = cmUnpkMgMgcpPkgSpcExtnParam(&param->xRstrtMethod, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgRsrtMethod*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpParamExtn
*
*    Desc:    unpack the structure MgMgcpParamExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpParamExtn
(
MgMgcpParamExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpParamExtn(param ,ptr, mBuf)
MgMgcpParamExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpParamExtn)

    ret1 = cmUnpkMgMgcpExtnParam(&param->extnParam, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMacroTknStrOSXL(&param->extnVal, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpParamExtn*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpPkgNmVer
*
*    Desc:    unpack the structure MgMgcpPkgNmVer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpPkgNmVer
(
MgMgcpPkgNmVer *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpPkgNmVer(param ,ptr, mBuf)
MgMgcpPkgNmVer *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpPkgNmVer)

    ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMacroTknStrOSXL(&param->pkgVer, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpPkgNmVer*/

/*
*
*    Fun:    cmUnpkMgMgcpPkgList
*
*    Desc:    unpack the structure MgMgcpPkgList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpPkgList
(
MgMgcpPkgList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpPkgList(param ,ptr, mBuf)
MgMgcpPkgList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcpPkgList)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->nameVer));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpPkgNmVer), (Ptr*)&(param->nameVer[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpPkgNmVer,  (param->nameVer[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpPkgList*/
#endif
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpParam
*
*    Desc:    unpack the structure MgMgcpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpParam
(
MgMgcpParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpParam(param ,ptr, mBuf)
MgMgcpParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpParam)

    CMCHKUNPK(cmUnpkTknU8, &param->paramType,mBuf);
    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_BEAR_INFO :
             ret1 = cmUnpkMgBearerInfo(&param->t.bearerInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CALLID :
             CMCHKUNPK(cmUnpkMgCallId, &param->t.callId,mBuf);
             break;
          case  MGT_PARAM_CAPABILITIES :
             ret1 = cmUnpkMgLclConnOptSet(&param->t.capabilitySet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONNID :
             ret1 = cmUnpkMgConnIdSet(&param->t.connIdSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_MODE :
             ret1 = cmUnpkMgConnMode(&param->t.connMode, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_PARAM :
             ret1 = cmUnpkMgConnParamSet(&param->t.connParamSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DETECT_EVENT :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.detectEvnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmUnpkMgDgtMap(&param->t.dgtMap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_EVNTSTATES :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.eventStates, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_LCL_CONNOPTS :
             ret1 = cmUnpkMgLclConnOptSet(&param->t.lclConnOptSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_MAX_DATAGRAM :
             CMCHKUNPK(cmUnpkTknU32, &param->t.maxDatGram,mBuf);
             break;
          case  MGT_PARAM_MAX_ENDPT_IDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.maxEndPtIds,mBuf);
             break;
          case  MGT_PARAM_NON_STD :
             ret1 = cmUnpkMgMgcpParamExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NTFIED_ENT :
             ret1 = cmUnpkMgNtfiedEnt(&param->t.ntfiedEnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NUM_ENDPT_IDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.numEndPtIds,mBuf);
             break;
          case  MGT_PARAM_OBS_EVENT :
             ret1 = cmUnpkMgObsEvntSet(&param->t.obsEvntSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_PACKAGE_LIST :
             ret1 = cmUnpkMgMgcpPkgList(&param->t.pkgList, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_QRNT_HANDLING :
             ret1 = cmUnpkMgQrntHandling(&param->t.qrntHandling, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_REASON :
             ret1 = cmUnpkMgReasonCode(&param->t.reasonCode, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RESOURCE_ID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.resourceId,mBuf);
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmUnpkMgRqstdEvntSet(&param->t.rqstdEvntSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_INFO :
             ret1 = cmUnpkMgRqstdInfo(&param->t.rqstdInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTID :
             CMCHKUNPK(cmUnpkMgRqstId, &param->t.rqstId,mBuf);
             break;
          case  MGT_PARAM_RSPACK :
             ret1 = cmUnpkMgRspAckSet(&param->t.rspAckSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RSTRT_DELAY :
             CMCHKUNPK(cmUnpkTknU32, &param->t.rstrtDelay,mBuf);
             break;
          case  MGT_PARAM_RSTRT_METHOD :
             ret1 = cmUnpkMgRsrtMethod(&param->t.rstrtMethod, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SCND_CONNID :
             ret1 = cmUnpkMgConnIdSet(&param->t.scndConnIdSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SECND_EPID :
             ret1 = cmUnpkMgEPName(&param->t.scndEpId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.sigRqstSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SPEC_EPID :
             ret1 = cmUnpkMgEPName(&param->t.specificEpId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_VERSN_SUPRTD :
             ret1 = cmUnpkMgMgcpVerSet(&param->t.versionsSupp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpParam*/
#else

/*
*
*    Fun:    cmUnpkMgMgcpParam
*
*    Desc:    unpack the structure MgMgcpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpParam
(
MgMgcpParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpParam(param ,ptr, mBuf)
MgMgcpParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpParam)

    CMCHKUNPK(cmUnpkTknU8, &param->paramType,mBuf);
    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  MGT_PARAM_BEAR_INFO :
             ret1 = cmUnpkMgBearerInfo(&param->t.bearerInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CALLID :
             CMCHKUNPK(cmUnpkMgCallId, &param->t.callId,mBuf);
             break;
          case  MGT_PARAM_CAPABILITIES :
             ret1 = cmUnpkMgLclConnOptSet(&param->t.capabilitySet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONNID :
             ret1 = cmUnpkMgConnIdSet(&param->t.connIdSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_CONN_MODE :
             CMCHKUNPK(cmUnpkMgConnMode, &param->t.connMode,mBuf);
             break;
          case  MGT_PARAM_CONN_PARAM :
             ret1 = cmUnpkMgConnParamSet(&param->t.connParamSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DETECT_EVENT :
             ret1 = cmUnpkMgDetectEvent(&param->t.detectEvnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_DGT_MAP :
             ret1 = cmUnpkMgDgtMap(&param->t.dgtMap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_EVNTSTATES :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.eventStates, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_LCL_CONNOPTS :
             ret1 = cmUnpkMgLclConnOptSet(&param->t.lclConnOptSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_MAX_ENDPT_IDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.maxEndPtIds,mBuf);
             break;
          case  MGT_PARAM_NON_STD :
             ret1 = cmUnpkMgNonStdExtn(&param->t.nonStdExtn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NTFIED_ENT :
             ret1 = cmUnpkMgNtfiedEnt(&param->t.ntfiedEnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_NUM_ENDPT_IDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.numEndPtIds,mBuf);
             break;
          case  MGT_PARAM_OBS_EVENT :
             ret1 = cmUnpkMgObsEvntSet(&param->t.obsEvntSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_QRNT_HANDLING :
             ret1 = cmUnpkMgQrntHandling(&param->t.qrntHandling, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_REASON :
             ret1 = cmUnpkMgReasonCode(&param->t.reasonCode, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RESOURCE_ID :
             CMCHKUNPK(cmUnpkTknU32, &param->t.resourceId,mBuf);
             break;
          case  MGT_PARAM_RQSTD_EVENT :
             ret1 = cmUnpkMgRqstdEvntSet(&param->t.rqstdEvntSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTD_INFO :
             ret1 = cmUnpkMgRqstdInfo(&param->t.rqstdInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RQSTID :
             CMCHKUNPK(cmUnpkMgRqstId, &param->t.rqstId,mBuf);
             break;
          case  MGT_PARAM_RSPACK :
             ret1 = cmUnpkMgRspAckSet(&param->t.rspAckSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_RSTRT_DELAY :
             CMCHKUNPK(cmUnpkTknU32, &param->t.rstrtDelay,mBuf);
             break;
          case  MGT_PARAM_RSTRT_METHOD :
             CMCHKUNPK(cmUnpkTknU8, &param->t.rstrtMethod,mBuf);
             break;
          case  MGT_PARAM_SCND_CONNID :
             ret1 = cmUnpkMgConnIdSet(&param->t.scndConnIdSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SECND_EPID :
             ret1 = cmUnpkMgEPName(&param->t.scndEpId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SIG_RQST :
             ret1 = cmUnpkMgSignalRqstSet(&param->t.sigRqstSet, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_SPEC_EPID :
             ret1 = cmUnpkMgEPName(&param->t.specificEpId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PARAM_VERSN_SUPRTD :
             ret1 = cmUnpkMgMgcpVerSet(&param->t.versionsSupp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpParam*/
#endif

/*
*
*    Fun:    cmUnpkMgMgcpParamSet
*
*    Desc:    unpack the structure MgMgcpParamSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpParamSet
(
MgMgcpParamSet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpParamSet(param ,ptr, mBuf)
MgMgcpParamSet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcpParamSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numParam,mBuf);
    if( param->numParam.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numParam.val), (Ptr*)&(param->param));
       for (i=0;i<param->numParam.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpParam), (Ptr*)&(param->param[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcpParam,  (param->param[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpParamSet*/

/*
*
*    Fun:    cmUnpkMgMgcpCmd
*
*    Desc:    unpack the structure MgMgcpCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpCmd
(
MgMgcpCmd *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpCmd(param ,ptr, intfVer, mBuf)
MgMgcpCmd *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpCmd)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcpCmdLine(&param->cmdLine, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpParamSet(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkMacroTknBuf, &param->sdpStr,mBuf);
       ret1 = cmUnpkCmSdpInfoSet(&param->sdpInfo, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpCmd*/

/*
*
*    Fun:    cmUnpkMgMsgNonStd
*
*    Desc:    unpack the structure MgMsgNonStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMsgNonStd
(
MgMsgNonStd *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMsgNonStd(param ,ptr, intfVer, mBuf)
MgMsgNonStd *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMsgNonStd)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr8, &param->cmdName,mBuf);
       ret1 = cmUnpkMgMgcpCmd(&param->cmd, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMsgNonStd*/
#if(  defined(  GCP_VER_1_3)  && defined(  GCP_2705BIS) ) 

/*
*
*    Fun:    cmUnpkMgMgcpSdpInfo
*
*    Desc:    unpack the structure MgMgcpSdpInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpSdpInfo
(
MgMgcpSdpInfo *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpSdpInfo(param ,ptr, intfVer, mBuf)
MgMgcpSdpInfo *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpSdpInfo)

    CMCHKUNPK(cmUnpkMacroTknBuf, &param->sdpStr,mBuf);
    ret1 = cmUnpkCmSdpInfoSet(&param->sdpInfo, ptr , intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpSdpInfo*/

/*
*
*    Fun:    cmUnpkMgMgcpSdpInfoSet
*
*    Desc:    unpack the structure MgMgcpSdpInfoSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpSdpInfoSet
(
MgMgcpSdpInfoSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpSdpInfoSet(param ,ptr, intfVer, mBuf)
MgMgcpSdpInfoSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcpSdpInfoSet)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->set));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcpSdpInfo), (Ptr*)&(param->set[i]));
          ret1 = cmUnpkMgMgcpSdpInfo( (param->set[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpSdpInfoSet*/

/*
*
*    Fun:    cmUnpkMgMgcpRsp
*
*    Desc:    unpack the structure MgMgcpRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpRsp
(
MgMgcpRsp *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpRsp(param ,ptr, intfVer, mBuf)
MgMgcpRsp *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpRsp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->rspCode,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->trId,mBuf);
       ret1 = cmUnpkMgPkgName(&param->pkgName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->rspStr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpParamSet(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpSdpInfoSet(&param->sdpInfo, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpRsp*/
#else

/*
*
*    Fun:    cmUnpkMgMgcpRsp
*
*    Desc:    unpack the structure MgMgcpRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpRsp
(
MgMgcpRsp *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpRsp(param ,ptr, intfVer, mBuf)
MgMgcpRsp *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcpRsp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->rspCode,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->trId,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->rspStr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpParamSet(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkMacroTknBuf, &param->sdpStr,mBuf);
       ret1 = cmUnpkCmSdpInfoSet(&param->sdpInfo, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpRsp*/
#endif
#ifdef GCP_PKG_MGCP_BASE

/*
*
*    Fun:    cmUnpkMgMgcpMsg
*
*    Desc:    unpack the structure MgMgcpMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpMsg
(
MgMgcpMsg *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpMsg(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcpMsg *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcpMsg)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknU8, &param->msgType,mBuf);
    if( param->msgType.pres != NOTPRSNT )
    {
       switch( param->msgType.val )
       {
          case  MGT_MSG_AUCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.aucxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_AUEP :
             ret1 = cmUnpkMgMgcpCmd(&param->t.auepCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_CRCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.crcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_DLCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.dlcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_EPCF :
             ret1 = cmUnpkMgMgcpCmd(&param->t.epcfCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MDCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.mdcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MESG :
             ret1 = cmUnpkMgMgcpCmd(&param->t.mesgCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NONE :
             break;
          case  MGT_MSG_NONSTD :
             ret1 = cmUnpkMgMsgNonStd(&param->t.nonStdCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NTFY :
             ret1 = cmUnpkMgMgcpCmd(&param->t.ntfyCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RQNT :
             ret1 = cmUnpkMgMgcpCmd(&param->t.rqntCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSIP :
             ret1 = cmUnpkMgMgcpCmd(&param->t.rsipCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSP :
             ret1 = cmUnpkMgMgcpRsp(&param->t.mgcpRsp, ptr , intfVer, mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkMgLclErr, &param->mgLclErr,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dupInfo,mBuf);
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpMsg*/
#else /* GCP_PKG_MGCP_BASE */

/*
*
*    Fun:    cmUnpkMgMgcpMsg
*
*    Desc:    unpack the structure MgMgcpMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpMsg
(
MgMgcpMsg *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpMsg(param , sMem, maxBlkSize,intfVer, mBuf)
MgMgcpMsg *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcpMsg)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknU8, &param->msgType,mBuf);
    if( param->msgType.pres != NOTPRSNT )
    {
       switch( param->msgType.val )
       {
          case  MGT_MSG_AUCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.aucxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_AUEP :
             ret1 = cmUnpkMgMgcpCmd(&param->t.auepCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_CRCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.crcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_DLCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.dlcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_EPCF :
             ret1 = cmUnpkMgMgcpCmd(&param->t.epcfCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_MDCX :
             ret1 = cmUnpkMgMgcpCmd(&param->t.mdcxCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NONE :
             break;
          case  MGT_MSG_NONSTD :
             ret1 = cmUnpkMgMsgNonStd(&param->t.nonStdCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_NTFY :
             ret1 = cmUnpkMgMgcpCmd(&param->t.ntfyCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RQNT :
             ret1 = cmUnpkMgMgcpCmd(&param->t.rqntCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSIP :
             ret1 = cmUnpkMgMgcpCmd(&param->t.rsipCmd, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MSG_RSP :
             ret1 = cmUnpkMgMgcpRsp(&param->t.mgcpRsp, ptr ,intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkMgLclErr, &param->mgLclErr,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dupInfo,mBuf);
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpMsg*/
#endif /* GCP_PKG_MGCP_BASE */

/*
*
*    Fun:    cmUnpkMgMgcpTxn
*
*    Desc:    unpack the structure MgMgcpTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcpTxn
(
MgMgcpTxn *param,
Mem *sMem,
Size maxBlkSize,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcpTxn(param , sMem, maxBlkSize,  pst, mBuf)
MgMgcpTxn *param;
Mem *sMem;
Size maxBlkSize;
Pst *pst;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcpTxn)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkMgPeerInfo, &param->mgLclInfo,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numMsg,mBuf);
    for (i=0;i<param->numMsg;i++)
    {
       if(cmAllocEvnt(sizeof(MgMgcpMsg), maxBlkSize, sMem,
         (Ptr*)&(param->mgcpMsg[i])) != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcpMsg( (param->mgcpMsg[i]), sMem , maxBlkSize , pst->intfVer ,mBuf);
       if(ret1 != ROK)
       {
          SPutMsg(mBuf);
          RETVALUE( ret1 );
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcpTxn*/
#endif /* GCP_MGCP */
#ifdef GCP_MGCO
#ifdef MGT_MGCO_V2

/*
*
*    Fun:    cmUnpkMgMgcoIndAudStreamParm
*
*    Desc:    unpack the structure MgMgcoIndAudStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudStreamParm
(
MgMgcoIndAudStreamParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudStreamParm(param ,ptr, mBuf)
MgMgcoIndAudStreamParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudStreamParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudStreamParm*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudStreamDesc
*
*    Desc:    unpack the structure MgMgcoIndAudStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudStreamDesc
(
MgMgcoIndAudStreamDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudStreamDesc(param ,ptr, mBuf)
MgMgcoIndAudStreamDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudStreamDesc)

    CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->streamId,mBuf);
    ret1 = cmUnpkMgMgcoIndAudStreamParm(&param->streamParm, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudStreamDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudTermStateDesc
*
*    Desc:    unpack the structure MgMgcoIndAudTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudTermStateDesc
(
MgMgcoIndAudTermStateDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudTermStateDesc(param ,ptr, mBuf)
MgMgcoIndAudTermStateDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudTermStateDesc)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudTermStateDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudMediaParm
*
*    Desc:    unpack the structure MgMgcoIndAudMediaParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudMediaParm
(
MgMgcoIndAudMediaParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudMediaParm(param ,ptr, mBuf)
MgMgcoIndAudMediaParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudMediaParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_STPAR :
             ret1 = cmUnpkMgMgcoIndAudStreamParm(&param->u.streamParm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_STRDESC :
             ret1 = cmUnpkMgMgcoIndAudStreamDesc(&param->u.streamDesc, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_TERSTDESC :
             ret1 = cmUnpkMgMgcoIndAudTermStateDesc(&param->u.termStateDesc, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudMediaParm*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudEvents
*
*    Desc:    unpack the structure MgMgcoIndAudEvents
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudEvents
(
MgMgcoIndAudEvents *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudEvents(param ,ptr, mBuf)
MgMgcoIndAudEvents *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudEvents)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoRequestId, &param->request,mBuf);
       CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
       ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudEvents*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudSigLst
*
*    Desc:    unpack the structure MgMgcoIndAudSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudSigLst
(
MgMgcoIndAudSigLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudSigLst(param ,ptr, mBuf)
MgMgcoIndAudSigLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudSigLst)

    CMCHKUNPK(cmUnpkTknU16, &param->sigLstId,mBuf);
    ret1 = cmUnpkMgMgcoSigName(&param->sigName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudSigLst*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudSignals
*
*    Desc:    unpack the structure MgMgcoIndAudSignals
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudSignals
(
MgMgcoIndAudSignals *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudSignals(param ,ptr, mBuf)
MgMgcoIndAudSignals *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudSignals)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_SIGLST :
             ret1 = cmUnpkMgMgcoIndAudSigLst(&param->u.sigList, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_SIGNAME :
             ret1 = cmUnpkMgMgcoSigName(&param->u.sigName, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudSignals*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudEventSpecParm
*
*    Desc:    unpack the structure MgMgcoIndAudEventSpecParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudEventSpecParm
(
MgMgcoIndAudEventSpecParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudEventSpecParm(param ,ptr, mBuf)
MgMgcoIndAudEventSpecParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudEventSpecParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_EVPRM :
             ret1 = cmUnpkMgMgcoName(&param->u.evParmName, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_EVSTREAM :
             CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->u.evStream,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudEventSpecParm*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudEventBuffer
*
*    Desc:    unpack the structure MgMgcoIndAudEventBuffer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudEventBuffer
(
MgMgcoIndAudEventBuffer *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudEventBuffer(param ,ptr, mBuf)
MgMgcoIndAudEventBuffer *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudEventBuffer)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoIndAudEventSpecParm(&param->evSpecParm, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudEventBuffer*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudAuditRetParm
*
*    Desc:    unpack the structure MgMgcoIndAudAuditRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudAuditRetParm
(
MgMgcoIndAudAuditRetParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudAuditRetParm(param ,ptr, mBuf)
MgMgcoIndAudAuditRetParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoIndAudAuditRetParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_INDAUD_AUDDIGITMAP :
             ret1 = cmUnpkMgMgcoName(&param->u.audDigMap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDEVTBUF :
             ret1 = cmUnpkMgMgcoIndAudEventBuffer(&param->u.audEvtBuf, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDEVTS :
             ret1 = cmUnpkMgMgcoIndAudEvents(&param->u.audEvents, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDMEDIA :
             ret1 = cmUnpkMgMgcoIndAudMediaParm(&param->u.audMedia, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDPKG :
             ret1 = cmUnpkMgMgcoIndAudPackages(&param->u.audPkgs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDSIG :
             ret1 = cmUnpkMgMgcoIndAudSignals(&param->u.audSignals, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_INDAUD_AUDSTAT :
             ret1 = cmUnpkMgMgcoIndAudStatistics(&param->u.audStats, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudAuditRetParm*/

/*
*
*    Fun:    cmUnpkMgMgcoIndAudTermAudit
*
*    Desc:    unpack the structure MgMgcoIndAudTermAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIndAudTermAudit
(
MgMgcoIndAudTermAudit *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIndAudTermAudit(param ,ptr, mBuf)
MgMgcoIndAudTermAudit *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
       Cntr i;
    TRC3(cmUnpkMgMgcoIndAudTermAudit)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parm));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoIndAudAuditRetParm), (Ptr*)&(param->parm[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoIndAudAuditRetParm,  (param->parm[i]), ptr, mBuf);
       }  
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIndAudTermAudit*/
#endif /* MGT_MGCO_V2 */
#ifdef MGT_MGCO_V2

/*
*
*    Fun:    cmUnpkMgMgcoAuditItem
*
*    Desc:    unpack the structure MgMgcoAuditItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAuditItem
(
MgMgcoAuditItem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAuditItem(param ,ptr, mBuf)
MgMgcoAuditItem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAuditItem)

    CMCHKUNPK(cmUnpkTknU8, &param->auditItem,mBuf);
    ret1 = cmUnpkMgMgcoIndAudTermAudit(&param->termAudit, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAuditItem*/
#endif /* MGT_MGCO_V2 */

/*
*
*    Fun:    cmUnpkMgMgcoRequestId
*
*    Desc:    unpack the structure mgMgcoRequestId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoRequestId
(
MgMgcoRequestId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoRequestId(param ,mBuf)
MgMgcoRequestId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoRequestId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->id,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoRequestId*/

/*
*
*    Fun:    cmUnpkMgMgcoContextId
*
*    Desc:    unpack the structure mgMgcoContextId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoContextId
(
MgMgcoContextId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoContextId(param ,mBuf)
MgMgcoContextId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoContextId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoContextId*/

/*
*
*    Fun:    cmUnpkMgMgcoPathName
*
*    Desc:    unpack the structure MgMgcoPathName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPathName
(
MgMgcoPathName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPathName(param ,ptr, mBuf)
MgMgcoPathName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPathName)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->lcl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->dom, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPathName*/


/* 002.main_14: Added wildcard support in Termination id for GCP_ASN */
#ifdef GCP_ASN
/*
*
*    Fun:    cmUnpkMgMgcoWildcard
*
*    Desc:    unpack the structure MgMgcoWildcard
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoWildcard
(
MgMgcoWildcard *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoWildcard(param ,ptr, mBuf)
MgMgcoWildcard *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    S16 ret1;
    TRC3(cmUnpkMgMgcoWildcard)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->wildcard));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoWildcardField), (Ptr*)&(param->wildcard[i]));
          ret1 = cmUnpkTknStr4(param->wildcard[i], mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
       }
    }   
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoWildcard*/
#endif /* GCP_ASN */


/*
*
*    Fun:    cmUnpkMgMgcoTermId
*
*    Desc:    unpack the structure MgMgcoTermId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTermId
(
MgMgcoTermId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTermId(param ,ptr, mBuf)
MgMgcoTermId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTermId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMgMgcoPathName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
/* 002.main_14: Added wildcard support in Termination id for GCP_ASN */
#ifdef GCP_ASN
    ret1 = cmUnpkMgMgcoWildcard(&param->wildcard, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#endif /* GCP_ASN */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTermId*/

/*
*
*    Fun:    cmUnpkMgMgcoTermIdLst
*
*    Desc:    unpack the structure MgMgcoTermIdLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTermIdLst
(
MgMgcoTermIdLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTermIdLst(param ,ptr, mBuf)
MgMgcoTermIdLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoTermIdLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->terms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoTermId), (Ptr*)&(param->terms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoTermId,  (param->terms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTermIdLst*/

/*
*
*    Fun:    cmUnpkMgMgcoTimeStamp
*
*    Desc:    unpack the structure mgMgcoTimeStamp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTimeStamp
(
MgMgcoTimeStamp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTimeStamp(param ,mBuf)
MgMgcoTimeStamp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoTimeStamp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknStr8, &param->date,mBuf);
       CMCHKUNPK(cmUnpkTknStr8, &param->time,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTimeStamp*/

/*
*
*    Fun:    cmUnpkMgMgcoName
*
*    Desc:    unpack the structure MgMgcoName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoName
(
MgMgcoName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoName(param ,ptr, mBuf)
MgMgcoName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoName)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_GEN_TYPE_ALL :
             break;
          case  MGT_GEN_TYPE_KNOWN :
             CMCHKUNPK(cmUnpkTknU8, &param->u.val,mBuf);
             break;
          case  MGT_GEN_TYPE_UNKNOWN :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.str, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoName*/

/*
*
*    Fun:    cmUnpkMgMgcoPkgdName
*
*    Desc:    unpack the structure MgMgcoPkgdName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPkgdName
(
MgMgcoPkgdName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPkgdName(param ,ptr, mBuf)
MgMgcoPkgdName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPkgdName)

    ret1 = cmUnpkMacroTknStrOSXL(&param->pkgName, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPkgdName*/

/*
*
*    Fun:    cmUnpkMgMgcoSigName
*
*    Desc:    unpack the structure MgMgcoSigName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSigName
(
MgMgcoSigName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSigName(param ,ptr, mBuf)
MgMgcoSigName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSigName)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSigName*/

/*
*
*    Fun:    cmUnpkMgMgcoSigLst
*
*    Desc:    unpack the structure MgMgcoSigLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSigLst
(
MgMgcoSigLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSigLst(param ,ptr, mBuf)
MgMgcoSigLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoSigLst)

    CMCHKUNPK(cmUnpkTknU16, &param->id,mBuf);
    CMCHKUNPK(cmUnpkTknU16, &param->numSigs,mBuf);
    if( param->numSigs.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numSigs.val), (Ptr*)&(param->sigs));
       for (i=0;i<param->numSigs.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoSigName), (Ptr*)&(param->sigs[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoSigName,  (param->sigs[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSigLst*/
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 

/*
*
*    Fun:    cmUnpkMgMgcoFileUrl
*
*    Desc:    unpack the structure MgMgcoFileUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoFileUrl
(
MgMgcoFileUrl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoFileUrl(param ,ptr, mBuf)
MgMgcoFileUrl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoFileUrl)

    ret1 = cmUnpkMacroTknStrOSXL(&param->host, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMacroTknStrOSXL(&param->fpath, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoFileUrl*/

/*
*
*    Fun:    cmUnpkMgMgcoHostPort
*
*    Desc:    unpack the structure MgMgcoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoHostPort
(
MgMgcoHostPort *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoHostPort(param ,ptr, mBuf)
MgMgcoHostPort *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoHostPort)

    ret1 = cmUnpkMacroTknStrOSXL(&param->host, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkTknU32, &param->port,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoHostPort*/

/*
*
*    Fun:    cmUnpkMgMgcoUsrPw
*
*    Desc:    unpack the structure MgMgcoUsrPw
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoUsrPw
(
MgMgcoUsrPw *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoUsrPw(param ,ptr, mBuf)
MgMgcoUsrPw *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoUsrPw)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->user, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->pswd, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoUsrPw*/

/*
*
*    Fun:    cmUnpkMgMgcoLogin
*
*    Desc:    unpack the structure MgMgcoLogin
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoLogin
(
MgMgcoLogin *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoLogin(param ,ptr, mBuf)
MgMgcoLogin *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoLogin)

    ret1 = cmUnpkMgMgcoUsrPw(&param->usrPw, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoHostPort(&param->hp, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoLogin*/

/*
*
*    Fun:    cmUnpkMgMgcoPathType
*
*    Desc:    unpack the structure MgMgcoPathType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPathType
(
MgMgcoPathType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPathType(param ,ptr, mBuf)
MgMgcoPathType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPathType)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->fpath, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->ftpType,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPathType*/

/*
*
*    Fun:    cmUnpkMgMgcoFtpUrl
*
*    Desc:    unpack the structure MgMgcoFtpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoFtpUrl
(
MgMgcoFtpUrl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoFtpUrl(param ,ptr, mBuf)
MgMgcoFtpUrl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoFtpUrl)

    ret1 = cmUnpkMgMgcoLogin(&param->login, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoPathType(&param->patTyp, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoFtpUrl*/

/*
*
*    Fun:    cmUnpkMgMgcoPathSearch
*
*    Desc:    unpack the structure MgMgcoPathSearch
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPathSearch
(
MgMgcoPathSearch *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPathSearch(param ,ptr, mBuf)
MgMgcoPathSearch *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPathSearch)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->hpath, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMacroTknStrOSXL(&param->search, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPathSearch*/

/*
*
*    Fun:    cmUnpkMgMgcoHttpUrl
*
*    Desc:    unpack the structure MgMgcoHttpUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoHttpUrl
(
MgMgcoHttpUrl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoHttpUrl(param ,ptr, mBuf)
MgMgcoHttpUrl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoHttpUrl)

    ret1 = cmUnpkMgMgcoHostPort(&param->hp, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoPathSearch(&param->ps, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoHttpUrl*/

/*
*
*    Fun:    cmUnpkMgMgcoProvSegSpec
*
*    Desc:    unpack the structure MgMgcoProvSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoProvSegSpec
(
MgMgcoProvSegSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoProvSegSpec(param ,ptr, mBuf)
MgMgcoProvSegSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoProvSegSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_FILE_URL :
             ret1 = cmUnpkMgMgcoFileUrl(&param->u.file, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_FTP_URL :
             ret1 = cmUnpkMgMgcoFtpUrl(&param->u.ftp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_HTTP_URL :
             ret1 = cmUnpkMgMgcoHttpUrl(&param->u.http, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_SIMPLE :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.simple, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoProvSegSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoTodSpec
*
*    Desc:    unpack the structure mgMgcoTodSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTodSpec
(
MgMgcoTodSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTodSpec(param ,mBuf)
MgMgcoTodSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoTodSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->subType,mBuf);
    CMCHKUNPK(cmUnpkTknU16, &param->time,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTodSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoDateSpec
*
*    Desc:    unpack the structure mgMgcoDateSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDateSpec
(
MgMgcoDateSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDateSpec(param ,mBuf)
MgMgcoDateSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoDateSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->dateOrder,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->date,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDateSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoMoneySpec
*
*    Desc:    unpack the structure mgMgcoMoneySpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMoneySpec
(
MgMgcoMoneySpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMoneySpec(param ,mBuf)
MgMgcoMoneySpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoMoneySpec)

    CMCHKUNPK(cmUnpkTknStr8, &param->curType,mBuf);
    CMCHKUNPK(cmUnpkTknS32, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMoneySpec*/

/*
*
*    Fun:    cmUnpkMgMgcoIntSpec
*
*    Desc:    unpack the structure mgMgcoIntSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoIntSpec
(
MgMgcoIntSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoIntSpec(param ,mBuf)
MgMgcoIntSpec *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoIntSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPK(cmUnpkTknS32, &param->val,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoIntSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoVvarSpec
*
*    Desc:    unpack the structure MgMgcoVvarSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoVvarSpec
(
MgMgcoVvarSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoVvarSpec(param ,ptr, mBuf)
MgMgcoVvarSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoVvarSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_CHAR_SPEC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.chr, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_DATE_SPEC :
             CMCHKUNPK(cmUnpkMgMgcoDateSpec, &param->u.date,mBuf);
             break;
          case  MGT_MGCO_DIG_SPEC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.dig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_DOW_SPEC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.dow,mBuf);
             break;
          case  MGT_MGCO_DUR_SPEC :
             CMCHKUNPK(cmUnpkTknU32, &param->u.dur,mBuf);
             break;
          case  MGT_MGCO_HUSH_SPEC :
             CMCHKUNPK(cmUnpkTknU16, &param->u.hush,mBuf);
             break;
          case  MGT_MGCO_INT_SPEC :
             CMCHKUNPK(cmUnpkMgMgcoIntSpec, &param->u.integer,mBuf);
             break;
          case  MGT_MGCO_MONEY_SPEC :
             CMCHKUNPK(cmUnpkMgMgcoMoneySpec, &param->u.money,mBuf);
             break;
          case  MGT_MGCO_MONTH_SPEC :
             CMCHKUNPK(cmUnpkTknU8, &param->u.month,mBuf);
             break;
          case  MGT_MGCO_PHRASE_SPEC :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.phrase, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_TOD_SPEC :
             CMCHKUNPK(cmUnpkMgMgcoTodSpec, &param->u.tod,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoVvarSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoSelType
*
*    Desc:    unpack the structure MgMgcoSelType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSelType
(
MgMgcoSelType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSelType(param ,ptr, mBuf)
MgMgcoSelType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSelType)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->other, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSelType*/

/*
*
*    Fun:    cmUnpkMgMgcoSelSpecLst
*
*    Desc:    unpack the structure MgMgcoSelSpecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSelSpecLst
(
MgMgcoSelSpecLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSelSpecLst(param ,ptr, mBuf)
MgMgcoSelSpecLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSelSpecLst)

    ret1 = cmUnpkMgMgcoSelType(&param->type, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMacroTknStrOSXL(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSelSpecLst*/

/*
*
*    Fun:    cmUnpkMgMgcoSelList
*
*    Desc:    unpack the structure MgMgcoSelList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSelList
(
MgMgcoSelList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSelList(param ,ptr, mBuf)
MgMgcoSelList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoSelList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->selSpec));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoSelSpecLst), (Ptr*)&(param->selSpec[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoSelSpecLst,  (param->selSpec[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSelList*/

/*
*
*    Fun:    cmUnpkMgMgcoVarSegSpec
*
*    Desc:    unpack the structure MgMgcoVarSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoVarSegSpec
(
MgMgcoVarSegSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoVarSegSpec(param ,ptr, mBuf)
MgMgcoVarSegSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoVarSegSpec)

    ret1 = cmUnpkMgMgcoVvarSpec(&param->vvarSpec, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoSelList(&param->selList, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoVarSegSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoSpec
*
*    Desc:    unpack the structure MgMgcoSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSpec
(
MgMgcoSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSpec(param ,ptr, mBuf)
MgMgcoSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MGCO_PROV_SEG_SPEC :
             ret1 = cmUnpkMgMgcoProvSegSpec(&param->u.provSs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MGCO_VAR_SEG_SPEC :
             ret1 = cmUnpkMgMgcoVarSegSpec(&param->u.staSs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoSegSpec
*
*    Desc:    unpack the structure MgMgcoSegSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSegSpec
(
MgMgcoSegSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSegSpec(param ,ptr, mBuf)
MgMgcoSegSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSegSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->keyword,mBuf);
    ret1 = cmUnpkMgMgcoSpec(&param->spec, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSegSpec*/

/*
*
*    Fun:    cmUnpkMgMgcoAnncSpec
*
*    Desc:    unpack the structure MgMgcoAnncSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAnncSpec
(
MgMgcoAnncSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAnncSpec(param ,ptr, mBuf)
MgMgcoAnncSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoAnncSpec)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->segSpec));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoSegSpec), (Ptr*)&(param->segSpec[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoSegSpec,  (param->segSpec[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAnncSpec*/
#endif

/*
*
*    Fun:    cmUnpkMgMgcoValue
*
*    Desc:    unpack the structure MgMgcoValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoValue
(
MgMgcoValue *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoValue(param ,ptr, mBuf)
MgMgcoValue *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoValue)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
#if(  defined(  GCP_PKG_MGCO_ADVAUSRVRBASE)  || defined(  GCP_PKG_MGCO_AASDIGCOLLECT)  || defined(  GCP_PKG_MGCO_AASRECODING)  || defined(  GCP_PKG_MGCO_ADVAUSRVRSEGMNGMT) ) 
          case  MGT_VALTYPE_ADV_AUD_PROVSEGSPEC :
             ret1 = cmUnpkMgMgcoProvSegSpec(&param->u.prSpec, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_ADV_AUD_SEGLST :
             ret1 = cmUnpkMgMgcoAnncSpec(&param->u.anSpec, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
#endif /*    */
#ifdef GCP_ENUM_U32
          case  MGT_VALTYPE_ENUM :
             CMCHKUNPK(cmUnpkTknU32, &param->u.enume,mBuf);
             break;
#else
          case  MGT_VALTYPE_ENUM :
             CMCHKUNPK(cmUnpkTknU8, &param->u.enume,mBuf);
             break;
#endif
#ifdef GCP_ASN
         /* mgt_c_004.main_14: boolean field is added in MgMgcoValue union */
          case  MGT_VALTYPE_BOOL:
             CMCHKUNPK(cmUnpkTknU8, &param->u.boole,mBuf);
             break;
#endif
          case  MGT_VALTYPE_HEX_SINT32 :
             CMCHKUNPK(cmUnpkTknS32, &param->u.hexSint,mBuf);
             break;
          case  MGT_VALTYPE_HEX_UINT32 :
             CMCHKUNPK(cmUnpkTknU32, &param->u.hexInt,mBuf);
             break;
          case  MGT_VALTYPE_OCTSTRXL :
             ret1 = cmUnpkMacroTknStrOSXL(&param->u.osxl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SIGLST :
             ret1 = cmUnpkMgMgcoSigLst(&param->u.sigLst, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SIGNAME :
             ret1 = cmUnpkMgMgcoSigName(&param->u.sigName, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_SINT32 :
             CMCHKUNPK(cmUnpkTknS32, &param->u.decSint,mBuf);
             break;
          case  MGT_VALTYPE_TERMID :
             ret1 = cmUnpkMgMgcoTermId(&param->u.termId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_TERMIDLST :
             ret1 = cmUnpkMgMgcoTermIdLst(&param->u.termIdLst, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALTYPE_TKNBUF :
             CMCHKUNPK(cmUnpkMacroTknBuf, &param->u.mBuf,mBuf);
             break;
          case  MGT_VALTYPE_UINT32 :
             CMCHKUNPK(cmUnpkTknU32, &param->u.decInt,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoValue*/

/*
*
*    Fun:    cmUnpkMgMgcoAuthHdr
*
*    Desc:    unpack the structure MgMgcoAuthHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAuthHdr
(
MgMgcoAuthHdr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAuthHdr(param ,ptr, mBuf)
MgMgcoAuthHdr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAuthHdr)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoSecParmIndex, &param->spi,mBuf);
       CMCHKUNPK(cmUnpkMgMgcoSequenceNum, &param->sn,mBuf);
       ret1 = cmUnpkMgMgcoAuthData(&param->aData, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAuthHdr*/

/*
*
*    Fun:    cmUnpkMgMgcoDomAddrPort
*
*    Desc:    unpack the structure MgMgcoDomAddrPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDomAddrPort
(
MgMgcoDomAddrPort *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDomAddrPort(param ,ptr, mBuf)
MgMgcoDomAddrPort *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDomAddrPort)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_IPV4 :
                ret1 = cmUnpkMacroTknStrOSXL(&param->u.ipv4, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_IPV6 :
                ret1 = cmUnpkMacroTknStrOSXL(&param->u.ipv6, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
       CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDomAddrPort*/

/*
*
*    Fun:    cmUnpkMgMgcoDomNamePort
*
*    Desc:    unpack the structure MgMgcoDomNamePort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDomNamePort
(
MgMgcoDomNamePort *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDomNamePort(param ,ptr, mBuf)
MgMgcoDomNamePort *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDomNamePort)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMacroTknStrOSXL(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDomNamePort*/

/*
*
*    Fun:    cmUnpkMgMgcoMid
*
*    Desc:    unpack the structure MgMgcoMid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMid
(
MgMgcoMid *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMid(param ,ptr, mBuf)
MgMgcoMid *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoMid)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MID_DADDRPORT :
             ret1 = cmUnpkMgMgcoDomAddrPort(&param->u.dAddrPort, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_DEVICE :
             ret1 = cmUnpkMgMgcoDevName(&param->u.dev, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_DNAMEPORT :
             ret1 = cmUnpkMgMgcoDomNamePort(&param->u.dNamePort, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MID_MTPADDR :
             CMCHKUNPK(cmUnpkMgMgcoMtpAddr, &param->u.mtpAddr,mBuf);
             break;
          case  MGT_MID_PORT :
             CMCHKUNPK(cmUnpkTknU16, &param->u.port,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMid*/

/*
*
*    Fun:    cmUnpkMgMgcoErrDesc
*
*    Desc:    unpack the structure MgMgcoErrDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoErrDesc
(
MgMgcoErrDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoErrDesc(param ,ptr, mBuf)
MgMgcoErrDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoErrDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->code,mBuf);
       ret1 = cmUnpkMacroTknStrOSXL(&param->text, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoErrDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoTopoDesc
*
*    Desc:    unpack the structure MgMgcoTopoDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTopoDesc
(
MgMgcoTopoDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTopoDesc(param ,ptr, mBuf)
MgMgcoTopoDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTopoDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->from, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoTermId(&param->to, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->dir,mBuf);
#ifdef MGT_MGCO_V2
       CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->streamId,mBuf);
#endif /*  MGT_MGCO_V2  */
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTopoDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoTopoDescLst
*
*    Desc:    unpack the structure MgMgcoTopoDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTopoDescLst
(
MgMgcoTopoDescLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTopoDescLst(param ,ptr, mBuf)
MgMgcoTopoDescLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoTopoDescLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->descs));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoTopoDesc), (Ptr*)&(param->descs[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoTopoDesc,  (param->descs[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTopoDescLst*/

/*
*
*    Fun:    cmUnpkMgMgcoContextProps
*
*    Desc:    unpack the structure MgMgcoContextProps
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoContextProps
(
MgMgcoContextProps *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoContextProps(param ,ptr, mBuf)
MgMgcoContextProps *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoContextProps)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->pri,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->emerg,mBuf);
       ret1 = cmUnpkMgMgcoTopoDescLst(&param->tl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#ifdef    MGT_GCP_VER_1_4
       CMCHKUNPK(cmUnpkTknPres, &param->emergOff,mBuf);
#endif /* MGT_GCP_VER_1_4 */
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoContextProps*/

/*
*
*    Fun:    cmUnpkMgMgcoContextAudit
*
*    Desc:    unpack the structure mgMgcoContextAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoContextAudit
(
MgMgcoContextAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoContextAudit(param ,mBuf)
MgMgcoContextAudit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoContextAudit)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknPres, &param->topo,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->emerg,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->pri,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoContextAudit*/

/*
*
*    Fun:    cmUnpkMgMgcoValLst
*
*    Desc:    unpack the structure MgMgcoValLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoValLst
(
MgMgcoValLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoValLst(param ,ptr, mBuf)
MgMgcoValLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoValLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->vals));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoValue), (Ptr*)&(param->vals[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoValue,  (param->vals[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoValLst*/

/*
*
*    Fun:    cmUnpkMgMgcoValRng
*
*    Desc:    unpack the structure MgMgcoValRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoValRng
(
MgMgcoValRng *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoValRng(param ,ptr, mBuf)
MgMgcoValRng *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoValRng)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoValue(&param->low, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoValue(&param->up, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoValRng*/

/*
*
*    Fun:    cmUnpkMgMgcoParmValue
*
*    Desc:    unpack the structure MgMgcoParmValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoParmValue
(
MgMgcoParmValue *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoParmValue(param ,ptr, mBuf)
MgMgcoParmValue *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoParmValue)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_VALUE_AND :
             ret1 = cmUnpkMgMgcoValLst(&param->u.and, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_EQUAL :
             ret1 = cmUnpkMgMgcoValue(&param->u.eq, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_GREATERTHAN :
             ret1 = cmUnpkMgMgcoValue(&param->u.gt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_LESSTHAN :
             ret1 = cmUnpkMgMgcoValue(&param->u.lt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_NOTEQUAL :
             ret1 = cmUnpkMgMgcoValue(&param->u.ne, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_OR :
             ret1 = cmUnpkMgMgcoValLst(&param->u.or, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_VALUE_RANGE :
             ret1 = cmUnpkMgMgcoValRng(&param->u.rng, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoParmValue*/

/*
*
*    Fun:    cmUnpkMgMgcoPropParm
*
*    Desc:    unpack the structure MgMgcoPropParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPropParm
(
MgMgcoPropParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPropParm(param ,ptr, mBuf)
MgMgcoPropParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPropParm)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoParmValue(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPropParm*/

/*
*
*    Fun:    cmUnpkMgMgcoPropParmLst
*
*    Desc:    unpack the structure MgMgcoPropParmLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPropParmLst
(
MgMgcoPropParmLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPropParmLst(param ,ptr, mBuf)
MgMgcoPropParmLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoPropParmLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoPropParm), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoPropParm,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPropParmLst*/

/*
*
*    Fun:    cmUnpkMgMgcoLocalParm
*
*    Desc:    unpack the structure MgMgcoLocalParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoLocalParm
(
MgMgcoLocalParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoLocalParm(param ,ptr, mBuf)
MgMgcoLocalParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoLocalParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_LCLCTL_MODE :
             CMCHKUNPK(cmUnpkTknU8, &param->u.mode,mBuf);
             break;
          case  MGT_LCLCTL_PROPPARM :
             ret1 = cmUnpkMgMgcoPropParm(&param->u.propParm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_LCLCTL_RESGRP :
             CMCHKUNPK(cmUnpkTknU8, &param->u.resGrp,mBuf);
             break;
          case  MGT_LCLCTL_RESVAL :
             CMCHKUNPK(cmUnpkTknU8, &param->u.resVal,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoLocalParm*/

/*
*
*    Fun:    cmUnpkMgMgcoLclCtlDesc
*
*    Desc:    unpack the structure MgMgcoLclCtlDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoLclCtlDesc
(
MgMgcoLclCtlDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoLclCtlDesc(param ,ptr, mBuf)
MgMgcoLclCtlDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoLclCtlDesc)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoLocalParm), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoLocalParm,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoLclCtlDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoPropGrpLst
*
*    Desc:    unpack the structure MgMgcoPropGrpLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPropGrpLst
(
MgMgcoPropGrpLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPropGrpLst(param ,ptr, mBuf)
MgMgcoPropGrpLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoPropGrpLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->grps));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoPropParmLst), (Ptr*)&(param->grps[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoPropParmLst,  (param->grps[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPropGrpLst*/

/*
*
*    Fun:    cmUnpkMgMgcoLocalDesc
*
*    Desc:    unpack the structure MgMgcoLocalDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoLocalDesc
(
MgMgcoLocalDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoLocalDesc(param ,ptr, intfVer, mBuf)
MgMgcoLocalDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoLocalDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMacroTknBuf, &param->sdpStr,mBuf);
       ret1 = cmUnpkCmSdpInfoSet(&param->sdp, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }

/* 002.main_14: Added Annex C support in GCP_ASN */
#ifdef GCP_ASN       
       ret1 = cmUnpkMgMgcoPropGrpLst(&param->annexCParmLst, ptr, mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /* GCP_ASN */      
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoLocalDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoTermStateParm
*
*    Desc:    unpack the structure MgMgcoTermStateParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTermStateParm
(
MgMgcoTermStateParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTermStateParm(param ,ptr, mBuf)
MgMgcoTermStateParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTermStateParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TERMST_EVTBUFCTL :
             CMCHKUNPK(cmUnpkMgMgcoEvtBufCtl, &param->u.evtBufCtl,mBuf);
             break;
          case  MGT_TERMST_PROPLST :
             ret1 = cmUnpkMgMgcoPropParm(&param->u.parm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TERMST_SVCST :
             CMCHKUNPK(cmUnpkMgMgcoSvcState, &param->u.svcState,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTermStateParm*/

/*
*
*    Fun:    cmUnpkMgMgcoTermStateDesc
*
*    Desc:    unpack the structure MgMgcoTermStateDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTermStateDesc
(
MgMgcoTermStateDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTermStateDesc(param ,ptr, intfVer, mBuf)
MgMgcoTermStateDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Cntr i;
    CmIntfVer   verDelta;                 
    TRC3(cmUnpkMgMgcoTermStateDesc)

    /*
     * 001.main_9 :- addition of a switch case statement based
     * on the remote interface version.
     */

#ifdef MG_RUG  /* 002.main_9 : now code is protocol independent */
   verDelta = (MGTIFVER - intfVer);
#else
   verDelta = 0;
#endif /* MG_RUG */

    switch(verDelta)
    {
       case 0 :
               /* unpack occording to the latest generated code */
               CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
               if( param->numComp.pres != NOTPRSNT )
               {
                  CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val),
                                         (Ptr*)&(param->trmStPar));
                  for (i=0;i<param->numComp.val;i++)
                  {
                     CMGETMBLK(ptr, sizeof(MgMgcoTermStateParm),
                                      (Ptr*)&(param->trmStPar[i]));
                     CMCHKUNPKPTR(cmUnpkMgMgcoTermStateParm,
                                  (param->trmStPar[i]), ptr, mBuf);
                  }
               }
               break;

       case 1 :
               /* 001.main_9 : unpack occording to the previous MGT version */
               {
                  S16 ret1;
               /*
                * We have to unpack occording to the previous version;
                * So we unpack in the order of the previous version
                * using stack variables;
                * After that we fill in the values of the new interface
                * version based on the values in the stack variables
                */
                  TknPres              locPres;
                  MgMgcoEvtBufCtl      locEvtBufCtl;
                  MgMgcoSvcState       locSvcState;
                  MgMgcoPropParm       locParm;    

                  CMCHKUNPK(cmUnpkTknPres, &locPres,mBuf);
                  if(locPres.pres != NOTPRSNT)
                  {
                   /*
                    * unpack in order -
                    * MgMgcoEvtBufCtl, MgMgcoSvcState, MgMgcoPropParm.pkg
                    * The first 2 structures are simple types while
                    * MgMgcoPropParm is a constructed type, so we unpack
                    * only the package name part of MgMgcoPropParm to
                    * determine if that parameter is present or not. The
                    * actual unpacking of the remaining elements of
                    * MgMgcoPropParm is done later.
                    */
                     CMCHKUNPK(cmUnpkMgMgcoEvtBufCtl, &locEvtBufCtl,mBuf);
                     CMCHKUNPK(cmUnpkMgMgcoSvcState, &locSvcState,mBuf);
                     CMCHKUNPK(cmUnpkTknPkgId, &locParm.pkg,mBuf);

                     param->numComp.val = 0;

                     if(locEvtBufCtl.pres == PRSNT_NODEF)
                        ++(param->numComp.val);

                     if(locSvcState.pres == PRSNT_NODEF)
                        ++(param->numComp.val);

                     if(locParm.pkg.pres == PRSNT_NODEF)
                        ++(param->numComp.val);

                     if(param->numComp.val)
                     {
                      /*
                       * only if atleast one parameter is present do
                       * we set the numComp as present
                       */
                        param->numComp.pres = PRSNT_NODEF;
                     }
                     else
                     {
                      /*
                       * else we set numComp as not present
                       */
                        param->numComp.pres = NOTPRSNT;
                        break;
                     }

                     /*
                      * Now get memories for the parameters & for the array
                      */
                     CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val),
                                            (Ptr*)&(param->trmStPar));

                     for (i=0;i<param->numComp.val;i++)
                     {
                        CMGETMBLK(ptr, sizeof(MgMgcoTermStateParm),
                                      (Ptr*)&(param->trmStPar[i]));
                     }

                     /*
                      * reset the numComp to zero
                      */
                     param->numComp.val = 0;

                     if(locEvtBufCtl.pres == PRSNT_NODEF)
                     {
                        param->trmStPar[param->numComp.val]->type.pres
                                   = PRSNT_NODEF;

                        param->trmStPar[param->numComp.val]->type.val
                                   = MGT_TERMST_EVTBUFCTL;

                        /* structure copy the already unpacked evtBufCtl */
                        param->trmStPar[param->numComp.val]->u.evtBufCtl
                                   = locEvtBufCtl;

                        ++(param->numComp.val);
                     }

                     if(locSvcState.pres == PRSNT_NODEF)
                     {
                        param->trmStPar[param->numComp.val]->type.pres
                                   = PRSNT_NODEF;

                        param->trmStPar[param->numComp.val]->type.val
                                   = MGT_TERMST_SVCST;

                        /* structure copy the already unpacked SvcState */
                        param->trmStPar[param->numComp.val]->u.svcState
                                   = locSvcState;

                        ++(param->numComp.val);
                     }

                     if(locParm.pkg.pres == PRSNT_NODEF)
                     {
                        param->trmStPar[param->numComp.val]->type.pres
                                    = PRSNT_NODEF;

                        param->trmStPar[param->numComp.val]->type.val
                                    = MGT_TERMST_PROPLST;

                        /* Copy the already unpacked pkg information */
                        param->trmStPar[param->numComp.val]->u.parm.pkg
                                    = locParm.pkg;

                        /*
                         * Now unpack the remaining elements of MgMgcoPropParm
                         * i.e. MgMgcoPkgdName & MgMgcoParmValue as pkg (the
                         * first element of MgMgcoPropParm) has already been
                         * unpacked
                         */
                        ret1 = cmUnpkMgMgcoPkgdName(&param->trmStPar\
                               [param->numComp.val]->u.parm.name, ptr ,mBuf);
                        if (ret1 != ROK)
                        {
                           RETVALUE(RFAILED);
                        }

                        ret1 = cmUnpkMgMgcoParmValue(&param->trmStPar\
                               [param->numComp.val]->u.parm.val, ptr ,mBuf);
                        if (ret1 != ROK)
                        {
                           RETVALUE(RFAILED);
                        }

                        ++(param->numComp.val);
                     }

                  }
                  else
                  {
                     param->numComp.pres = NOTPRSNT;
                  }

               }
               break;

       default :
                RETVALUE(RFAILED);
                break;
    }

    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTermStateDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoStreamParm
*
*    Desc:    unpack the structure MgMgcoStreamParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoStreamParm
(
MgMgcoStreamParm *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoStreamParm(param ,ptr, intfVer, mBuf)
MgMgcoStreamParm *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoStreamParm)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoLclCtlDesc(&param->locCtl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoLocalDesc(&param->local, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoRemoteDesc(&param->remote, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoStreamParm*/

/*
*
*    Fun:    cmUnpkMgMgcoStreamDesc
*
*    Desc:    unpack the structure MgMgcoStreamDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoStreamDesc
(
MgMgcoStreamDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoStreamDesc(param ,ptr, intfVer, mBuf)
MgMgcoStreamDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoStreamDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->streamId,mBuf);
       ret1 = cmUnpkMgMgcoStreamParm(&param->sl, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoStreamDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoMediaPar
*
*    Desc:    unpack the structure MgMgcoMediaPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMediaPar
(
MgMgcoMediaPar *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMediaPar(param ,ptr, intfVer, mBuf)
MgMgcoMediaPar *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoMediaPar)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_MEDIAPAR_LOCAL :
             ret1 = cmUnpkMgMgcoLocalDesc(&param->u.local, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_LOCCTL :
             ret1 = cmUnpkMgMgcoLclCtlDesc(&param->u.locCtl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_REMOTE :
             ret1 = cmUnpkMgMgcoRemoteDesc(&param->u.remote, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_STRPAR :
             ret1 = cmUnpkMgMgcoStreamDesc(&param->u.stream, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIAPAR_TERMST :
             ret1 = cmUnpkMgMgcoTermStateDesc(&param->u.tstate, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMediaPar*/

/*
*
*    Fun:    cmUnpkMgMgcoMediaDesc
*
*    Desc:    unpack the structure MgMgcoMediaDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMediaDesc
(
MgMgcoMediaDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMediaDesc(param ,ptr, intfVer, mBuf)
MgMgcoMediaDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoMediaDesc)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoMediaPar), (Ptr*)&(param->parms[i]));
          ret1 = cmUnpkMgMgcoMediaPar( (param->parms[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMediaDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoH221NonStd
*
*    Desc:    unpack the structure mgMgcoH221NonStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoH221NonStd
(
MgMgcoH221NonStd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoH221NonStd(param ,mBuf)
MgMgcoH221NonStd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoH221NonStd)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->t35cc1,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->t35cc2,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->t35ext,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->mfc,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoH221NonStd*/

/*
*
*    Fun:    cmUnpkMgMgcoNonStdId
*
*    Desc:    unpack the structure MgMgcoNonStdId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoNonStdId
(
MgMgcoNonStdId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoNonStdId(param ,ptr, mBuf)
MgMgcoNonStdId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoNonStdId)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EXTNPARM_MAND :
             CMCHKUNPK(cmUnpkTknStr8, &param->u.extn,mBuf);
             break;
          case  MGT_EXTNPARM_OPT :
             CMCHKUNPK(cmUnpkTknStr8, &param->u.extn,mBuf);
             break;
          case  MGT_NONSTD_H221 :
             CMCHKUNPK(cmUnpkMgMgcoH221NonStd, &param->u.h221,mBuf);
             break;
          case  MGT_NONSTD_OBJID :
             ret1 = cmUnpkMgMgcoObjId(&param->u.objId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoNonStdId*/

/*
*
*    Fun:    cmUnpkMgMgcoModemType
*
*    Desc:    unpack the structure MgMgcoModemType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoModemType
(
MgMgcoModemType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoModemType(param ,ptr, mBuf)
MgMgcoModemType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoModemType)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    ret1 = cmUnpkMgMgcoNonStdId(&param->extnId, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoModemType*/

/*
*
*    Fun:    cmUnpkMgMgcoModemTypeLst
*
*    Desc:    unpack the structure MgMgcoModemTypeLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoModemTypeLst
(
MgMgcoModemTypeLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoModemTypeLst(param ,ptr, mBuf)
MgMgcoModemTypeLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoModemTypeLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->modems));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoModemType), (Ptr*)&(param->modems[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoModemType,  (param->modems[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoModemTypeLst*/

/*
*
*    Fun:    cmUnpkMgMgcoNonStdExtn
*
*    Desc:    unpack the structure MgMgcoNonStdExtn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoNonStdExtn
(
MgMgcoNonStdExtn *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoNonStdExtn(param ,ptr, mBuf)
MgMgcoNonStdExtn *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoNonStdExtn)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoNonStdId(&param->id, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoParmValue(&param->val, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoNonStdExtn*/

/*
*
*    Fun:    cmUnpkMgMgcoModemDesc
*
*    Desc:    unpack the structure MgMgcoModemDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoModemDesc
(
MgMgcoModemDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoModemDesc(param ,ptr, mBuf)
MgMgcoModemDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoModemDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoModemTypeLst(&param->mtl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoPropParmLst(&param->mpl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoNonStdExtn(&param->extn, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoModemDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoMuxDesc
*
*    Desc:    unpack the structure MgMgcoMuxDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMuxDesc
(
MgMgcoMuxDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMuxDesc(param ,ptr, mBuf)
MgMgcoMuxDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoMuxDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       ret1 = cmUnpkMgMgcoNonStdId(&param->id, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoTermIdLst(&param->tl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMuxDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtOther
*
*    Desc:    unpack the structure MgMgcoEvtOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtOther
(
MgMgcoEvtOther *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtOther(param ,ptr, mBuf)
MgMgcoEvtOther *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEvtOther)

    ret1 = cmUnpkMgMgcoName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoParmValue(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtOther*/

/*
*
*    Fun:    cmUnpkMgMgcoNtfyCmpl
*
*    Desc:    unpack the structure MgMgcoNtfyCmpl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoNtfyCmpl
(
MgMgcoNtfyCmpl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoNtfyCmpl(param ,ptr, mBuf)
MgMgcoNtfyCmpl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoNtfyCmpl)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->reasons));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->reasons[i]));
          CMCHKUNPK(cmUnpkTknU8,  (param->reasons[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoNtfyCmpl*/

/*
*
*    Fun:    cmUnpkMgMgcoSigPar
*
*    Desc:    unpack the structure MgMgcoSigPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSigPar
(
MgMgcoSigPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSigPar(param ,ptr, mBuf)
MgMgcoSigPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSigPar)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_SIGPAR_DURATION :
             CMCHKUNPK(cmUnpkTknU16, &param->u.dura,mBuf);
             break;
          case  MGT_SIGPAR_KEEPACTIVE :
             break;
          case  MGT_SIGPAR_NTFYCMPL :
             ret1 = cmUnpkMgMgcoNtfyCmpl(&param->u.nc, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGPAR_OTHER :
             ret1 = cmUnpkMgMgcoSigOther(&param->u.other, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGPAR_STREAMID :
             CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          case  MGT_SIGPAR_TYPE :
             CMCHKUNPK(cmUnpkTknU8, &param->u.type,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSigPar*/

/*
*
*    Fun:    cmUnpkMgMgcoSigParLst
*
*    Desc:    unpack the structure MgMgcoSigParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSigParLst
(
MgMgcoSigParLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSigParLst(param ,ptr, mBuf)
MgMgcoSigParLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoSigParLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoSigPar), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoSigPar,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSigParLst*/

/*
*
*    Fun:    cmUnpkMgMgcoSignalsReq
*
*    Desc:    unpack the structure MgMgcoSignalsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSignalsReq
(
MgMgcoSignalsReq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSignalsReq(param ,ptr, mBuf)
MgMgcoSignalsReq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSignalsReq)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoSigParLst(&param->pl, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSignalsReq*/

/*
*
*    Fun:    cmUnpkMgMgcoSignalsReqLst
*
*    Desc:    unpack the structure MgMgcoSignalsReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSignalsReqLst
(
MgMgcoSignalsReqLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSignalsReqLst(param ,ptr, mBuf)
MgMgcoSignalsReqLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoSignalsReqLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->reqs));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoSignalsReq), (Ptr*)&(param->reqs[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoSignalsReq,  (param->reqs[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSignalsReqLst*/

/*
*
*    Fun:    cmUnpkMgMgcoSignalsLst
*
*    Desc:    unpack the structure MgMgcoSignalsLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSignalsLst
(
MgMgcoSignalsLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSignalsLst(param ,ptr, mBuf)
MgMgcoSignalsLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSignalsLst)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->id,mBuf);
       ret1 = cmUnpkMgMgcoSignalsReqLst(&param->pl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSignalsLst*/

/*
*
*    Fun:    cmUnpkMgMgcoSignalsParm
*
*    Desc:    unpack the structure MgMgcoSignalsParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSignalsParm
(
MgMgcoSignalsParm *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSignalsParm(param ,ptr, mBuf)
MgMgcoSignalsParm *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSignalsParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_SIGSPAR_LST :
             ret1 = cmUnpkMgMgcoSignalsLst(&param->u.lst, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGSPAR_REQ :
             ret1 = cmUnpkMgMgcoSignalsReq(&param->u.req, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSignalsParm*/

/*
*
*    Fun:    cmUnpkMgMgcoSignalsDesc
*
*    Desc:    unpack the structure MgMgcoSignalsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSignalsDesc
(
MgMgcoSignalsDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSignalsDesc(param ,ptr, mBuf)
MgMgcoSignalsDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoSignalsDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
       if( param->num.pres != NOTPRSNT )
       {
          CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
          for (i=0;i<param->num.val;i++)
          {
             CMGETMBLK(ptr, sizeof(MgMgcoSignalsParm), (Ptr*)&(param->parms[i]));
             CMCHKUNPKPTR(cmUnpkMgMgcoSignalsParm,  (param->parms[i]), ptr, mBuf);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSignalsDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoDigRng
*
*    Desc:    unpack the structure mgMgcoDigRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigRng
(
MgMgcoDigRng *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigRng(param ,mBuf)
MgMgcoDigRng *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoDigRng)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->low,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->up,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigRng*/

/*
*
*    Fun:    cmUnpkMgMgcoDigMapLet
*
*    Desc:    unpack the structure MgMgcoDigMapLet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigMapLet
(
MgMgcoDigMapLet *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigMapLet(param ,ptr, mBuf)
MgMgcoDigMapLet *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoDigMapLet)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->mapLets));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoDigRng), (Ptr*)&(param->mapLets[i]));
          CMCHKUNPK(cmUnpkMgMgcoDigRng,  (param->mapLets[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigMapLet*/

/*
*
*    Fun:    cmUnpkMgMgcoDigMapRng
*
*    Desc:    unpack the structure MgMgcoDigMapRng
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigMapRng
(
MgMgcoDigMapRng *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigMapRng(param ,ptr, mBuf)
MgMgcoDigMapRng *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDigMapRng)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGMAP_LET :
             ret1 = cmUnpkMgMgcoDigMapLet(&param->u.let, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAP_X :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigMapRng*/

/*
*
*    Fun:    cmUnpkMgMgcoDigStrElem
*
*    Desc:    unpack the structure MgMgcoDigStrElem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigStrElem
(
MgMgcoDigStrElem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigStrElem(param ,ptr, mBuf)
MgMgcoDigStrElem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDigStrElem)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGSTR_LET :
             CMCHKUNPK(cmUnpkTknU8, &param->u.let,mBuf);
             break;
          case  MGT_DIGSTR_RNG :
             ret1 = cmUnpkMgMgcoDigMapRng(&param->u.range, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkTknPres, &param->dot,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigStrElem*/

/*
*
*    Fun:    cmUnpkMgMgcoDigStr
*
*    Desc:    unpack the structure MgMgcoDigStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigStr
(
MgMgcoDigStr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigStr(param ,ptr, mBuf)
MgMgcoDigStr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoDigStr)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->elems));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoDigStrElem), (Ptr*)&(param->elems[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoDigStrElem,  (param->elems[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigStr*/

/*
*
*    Fun:    cmUnpkMgMgcoDigMap
*
*    Desc:    unpack the structure MgMgcoDigMap
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigMap
(
MgMgcoDigMap *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigMap(param ,ptr, mBuf)
MgMgcoDigMap *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoDigMap)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->ds));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoDigStr), (Ptr*)&(param->ds[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoDigStr,  (param->ds[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigMap*/

/*
*
*    Fun:    cmUnpkMgMgcoDigMapVal
*
*    Desc:    unpack the structure MgMgcoDigMapVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigMapVal
(
MgMgcoDigMapVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigMapVal(param ,ptr, mBuf)
MgMgcoDigMapVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDigMapVal)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->t,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->s,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->l,mBuf);

       /* 001.main_14 [RA]: moved from below */
#ifdef MGT_MGCO_V2
       CMCHKUNPK(cmUnpkTknU8, &param->z,mBuf);
#endif /*  MGT_MGCO_V2  */

#if defined(  GCP_VER_1_3)  && defined(  GCP_MGCO_PARSE_DIG_MAP) 
       ret1 = cmUnpkMacroTknStrOSXL(&param->dm, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#else /* ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,, */ 
       ret1 = cmUnpkMgMgcoDigMap(&param->dm, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /*  ,#else  */
       ret1 = cmUnpkMacroTknStrOSXL(&param->dmIn, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigMapVal*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtDM
*
*    Desc:    unpack the structure MgMgcoEvtDM
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtDM
(
MgMgcoEvtDM *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtDM(param ,ptr, mBuf)
MgMgcoEvtDM *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEvtDM)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_DIGMAP_NAME :
             ret1 = cmUnpkMgMgcoName(&param->u.name, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAP_VAL :
             ret1 = cmUnpkMgMgcoDigMapVal(&param->u.val, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtDM*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtParSec
*
*    Desc:    unpack the structure MgMgcoEvtParSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtParSec
(
MgMgcoEvtParSec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtParSec(param ,ptr, mBuf)
MgMgcoEvtParSec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEvtParSec)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVTPAR_DIGMAP :
             ret1 = cmUnpkMgMgcoEvtDM(&param->u.dm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDWITHSIG :
             ret1 = cmUnpkMgMgcoSignalsDesc(&param->u.embSig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_KEEPACTIVE :
             break;
          case  MGT_EVTPAR_OTHER :
             ret1 = cmUnpkMgMgcoEvtOther(&param->u.other, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_STREAMID :
             CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtParSec*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtParSecLst
*
*    Desc:    unpack the structure MgMgcoEvtParSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtParSecLst
(
MgMgcoEvtParSecLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtParSecLst(param ,ptr, mBuf)
MgMgcoEvtParSecLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoEvtParSecLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoEvtParSec), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoEvtParSec,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtParSecLst*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtSec
*
*    Desc:    unpack the structure MgMgcoEvtSec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtSec
(
MgMgcoEvtSec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtSec(param ,ptr, mBuf)
MgMgcoEvtSec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEvtSec)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoEvtParSecLst(&param->pl, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtSec*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtSecLst
*
*    Desc:    unpack the structure MgMgcoEvtSecLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtSecLst
(
MgMgcoEvtSecLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtSecLst(param ,ptr, mBuf)
MgMgcoEvtSecLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoEvtSecLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->evts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoEvtSec), (Ptr*)&(param->evts[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoEvtSec,  (param->evts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtSecLst*/

/*
*
*    Fun:    cmUnpkMgMgcoEmbedFirst
*
*    Desc:    unpack the structure MgMgcoEmbedFirst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEmbedFirst
(
MgMgcoEmbedFirst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEmbedFirst(param ,ptr, mBuf)
MgMgcoEmbedFirst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEmbedFirst)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoRequestId, &param->reqId,mBuf);
       ret1 = cmUnpkMgMgcoEvtSecLst(&param->sl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEmbedFirst*/

/*
*
*    Fun:    cmUnpkMgMgcoEmbWithSig
*
*    Desc:    unpack the structure MgMgcoEmbWithSig
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEmbWithSig
(
MgMgcoEmbWithSig *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEmbWithSig(param ,ptr, mBuf)
MgMgcoEmbWithSig *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEmbWithSig)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoSignalsDesc(&param->sig, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoEmbedFirst(&param->emb, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEmbWithSig*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtPar
*
*    Desc:    unpack the structure MgMgcoEvtPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtPar
(
MgMgcoEvtPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtPar(param ,ptr, mBuf)
MgMgcoEvtPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoEvtPar)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_EVTPAR_DIGMAP :
             ret1 = cmUnpkMgMgcoEvtDM(&param->u.dm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDNOSIG :
             ret1 = cmUnpkMgMgcoEmbNoSig(&param->u.embNoSig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_EMBEDWITHSIG :
             ret1 = cmUnpkMgMgcoEmbWithSig(&param->u.embWithSig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_KEEPACTIVE :
             break;
          case  MGT_EVTPAR_OTHER :
             ret1 = cmUnpkMgMgcoEvtOther(&param->u.other, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVTPAR_STREAMID :
             CMCHKUNPK(cmUnpkMgMgcoStreamId, &param->u.streamId,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtPar*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtParLst
*
*    Desc:    unpack the structure MgMgcoEvtParLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtParLst
(
MgMgcoEvtParLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtParLst(param ,ptr, mBuf)
MgMgcoEvtParLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoEvtParLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoEvtPar), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoEvtPar,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtParLst*/

/*
*
*    Fun:    cmUnpkMgMgcoReqEvt
*
*    Desc:    unpack the structure MgMgcoReqEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoReqEvt
(
MgMgcoReqEvt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoReqEvt(param ,ptr, mBuf)
MgMgcoReqEvt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoReqEvt)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoEvtParLst(&param->pl, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoReqEvt*/

/*
*
*    Fun:    cmUnpkMgMgcoEvtLst
*
*    Desc:    unpack the structure MgMgcoEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvtLst
(
MgMgcoEvtLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvtLst(param ,ptr, mBuf)
MgMgcoEvtLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoEvtLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->revts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoReqEvt), (Ptr*)&(param->revts[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoReqEvt,  (param->revts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvtLst*/

/*
*
*    Fun:    cmUnpkMgMgcoReqEvtDesc
*
*    Desc:    unpack the structure MgMgcoReqEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoReqEvtDesc
(
MgMgcoReqEvtDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoReqEvtDesc(param ,ptr, mBuf)
MgMgcoReqEvtDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoReqEvtDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoRequestId, &param->reqId,mBuf);
       ret1 = cmUnpkMgMgcoEvtLst(&param->el, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoReqEvtDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoEvBufDesc
*
*    Desc:    unpack the structure MgMgcoEvBufDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoEvBufDesc
(
MgMgcoEvBufDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoEvBufDesc(param ,ptr, mBuf)
MgMgcoEvBufDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoEvBufDesc)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->evts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoEvSpec), (Ptr*)&(param->evts[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoEvSpec,  (param->evts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoEvBufDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoDigMapDesc
*
*    Desc:    unpack the structure MgMgcoDigMapDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoDigMapDesc
(
MgMgcoDigMapDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoDigMapDesc(param ,ptr, mBuf)
MgMgcoDigMapDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoDigMapDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoName(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoDigMapVal(&param->val, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoDigMapDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoAuditDesc
*
*    Desc:    unpack the structure MgMgcoAuditDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAuditDesc
(
MgMgcoAuditDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAuditDesc(param ,ptr, mBuf)
MgMgcoAuditDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
#ifdef MGT_MGCO_V2
    S16  ret1;
#endif /* MGT_MGCO_V2  */

    TRC3(cmUnpkMgMgcoAuditDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
       if( param->num.pres != NOTPRSNT )
       {
          CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->al));
          for (i=0;i<param->num.val;i++)
          {
#ifdef MGT_MGCO_V2
/* 001.main_14: Changes for AG Team */
             CMGETMBLK(ptr, sizeof(MgMgcoAuditItem), (Ptr*)&(param->al[i]));
             ret1 = cmUnpkMgMgcoAuditItem((param->al[i]), ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#else	 
/* 001.main_14: Changes for AG Team */
             CMGETMBLK(ptr, sizeof(TknU8), (Ptr*)&(param->al[i]));
             CMCHKUNPK(cmUnpkTknU8,  (param->al[i]), mBuf);
#endif /* MGT_MGCO_V2  */
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAuditDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoAmmDesc
*
*    Desc:    unpack the structure MgMgcoAmmDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAmmDesc
(
MgMgcoAmmDesc *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAmmDesc(param ,ptr, intfVer, mBuf)
MgMgcoAmmDesc *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAmmDesc)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_AUDITDESC :
             ret1 = cmUnpkMgMgcoAuditDesc(&param->u.audit, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_DIGMAPDESC :
             ret1 = cmUnpkMgMgcoDigMapDesc(&param->u.dm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVBUFDESC :
             ret1 = cmUnpkMgMgcoEvBufDesc(&param->u.evBuf, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIADESC :
             ret1 = cmUnpkMgMgcoMediaDesc(&param->u.media, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODEMDESC :
             ret1 = cmUnpkMgMgcoModemDesc(&param->u.modem, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MUXDESC :
             ret1 = cmUnpkMgMgcoMuxDesc(&param->u.mux, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_REQEVTDESC :
             ret1 = cmUnpkMgMgcoReqEvtDesc(&param->u.evts, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGNALSDESC :
             ret1 = cmUnpkMgMgcoSignalsDesc(&param->u.sig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAmmDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoAmmDescLst
*
*    Desc:    unpack the structure MgMgcoAmmDescLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAmmDescLst
(
MgMgcoAmmDescLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAmmDescLst(param ,ptr, intfVer, mBuf)
MgMgcoAmmDescLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoAmmDescLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->descs));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoAmmDesc), (Ptr*)&(param->descs[i]));
          ret1 = cmUnpkMgMgcoAmmDesc( (param->descs[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAmmDescLst*/

/*
*
*    Fun:    cmUnpkMgMgcoAmmReq
*
*    Desc:    unpack the structure MgMgcoAmmReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAmmReq
(
MgMgcoAmmReq *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAmmReq(param ,ptr, intfVer, mBuf)
MgMgcoAmmReq *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAmmReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoAmmDescLst(&param->dl, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAmmReq*/

/*
*
*    Fun:    cmUnpkMgMgcoSubAudReq
*
*    Desc:    unpack the structure MgMgcoSubAudReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSubAudReq
(
MgMgcoSubAudReq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSubAudReq(param ,ptr, mBuf)
MgMgcoSubAudReq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSubAudReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoAuditDesc(&param->audit, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSubAudReq*/

/*
*
*    Fun:    cmUnpkMgMgcoObsEvt
*
*    Desc:    unpack the structure MgMgcoObsEvt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoObsEvt
(
MgMgcoObsEvt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoObsEvt(param ,ptr, mBuf)
MgMgcoObsEvt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoObsEvt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTimeStamp, &param->time,mBuf);
       CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
       ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoEvtParLst(&param->pl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoObsEvt*/

/*
*
*    Fun:    cmUnpkMgMgcoObsEvtLst
*
*    Desc:    unpack the structure MgMgcoObsEvtLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoObsEvtLst
(
MgMgcoObsEvtLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoObsEvtLst(param ,ptr, mBuf)
MgMgcoObsEvtLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoObsEvtLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->evts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoObsEvt), (Ptr*)&(param->evts[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoObsEvt,  (param->evts[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoObsEvtLst*/

/*
*
*    Fun:    cmUnpkMgMgcoObsEvtDesc
*
*    Desc:    unpack the structure MgMgcoObsEvtDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoObsEvtDesc
(
MgMgcoObsEvtDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoObsEvtDesc(param ,ptr, mBuf)
MgMgcoObsEvtDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoObsEvtDesc)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoRequestId, &param->reqId,mBuf);
       ret1 = cmUnpkMgMgcoObsEvtLst(&param->el, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoObsEvtDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoNtfyReq
*
*    Desc:    unpack the structure MgMgcoNtfyReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoNtfyReq
(
MgMgcoNtfyReq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoNtfyReq(param ,ptr, mBuf)
MgMgcoNtfyReq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoNtfyReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoObsEvtDesc(&param->obs, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoErrDesc(&param->err, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoNtfyReq*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgMethod
*
*    Desc:    unpack the structure MgMgcoSvcChgMethod
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgMethod
(
MgMgcoSvcChgMethod *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgMethod(param ,ptr, mBuf)
MgMgcoSvcChgMethod *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgMethod)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       ret1 = cmUnpkMgMgcoNonStdId(&param->extn, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgMethod*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgProf
*
*    Desc:    unpack the structure MgMgcoSvcChgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgProf
(
MgMgcoSvcChgProf *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgProf(param ,ptr, mBuf)
MgMgcoSvcChgProf *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgProf)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoName(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->ver,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgProf*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgPar
*
*    Desc:    unpack the structure MgMgcoSvcChgPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgPar
(
MgMgcoSvcChgPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgPar(param ,ptr, mBuf)
MgMgcoSvcChgPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgPar)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoNonStdExtn(&param->extn, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoSvcChgMethod(&param->meth, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoSvcChgAddr(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->ver,mBuf);
       ret1 = cmUnpkMgMgcoSvcChgProf(&param->prof, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoSvcChgReason(&param->reason, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU32, &param->delay,mBuf);
       ret1 = cmUnpkMgMgcoMid(&param->mgcId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkMgMgcoTimeStamp, &param->time,mBuf);
#ifdef MGT_MGCO_V2
       ret1 = cmUnpkMgMgcoAuditItem(&param->auditItem, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
#endif /*  MGT_MGCO_V2  */
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgPar*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgReq
*
*    Desc:    unpack the structure MgMgcoSvcChgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgReq
(
MgMgcoSvcChgReq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgReq(param ,ptr, mBuf)
MgMgcoSvcChgReq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoSvcChgPar(&param->parm, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgReq*/

/*
*
*    Fun:    cmUnpkMgMgcoCmd
*
*    Desc:    unpack the structure MgMgcoCmd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmd
(
MgMgcoCmd *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmd(param ,ptr, intfVer, mBuf)
MgMgcoCmd *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoCmd)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ADD :
             ret1 = cmUnpkMgMgcoAmmReq(&param->u.add, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_AUDITCAP :
             ret1 = cmUnpkMgMgcoSubAudReq(&param->u.acap, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_AUDITVAL :
             ret1 = cmUnpkMgMgcoSubAudReq(&param->u.aval, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODIFY :
             ret1 = cmUnpkMgMgcoAmmReq(&param->u.mod, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MOVE :
             ret1 = cmUnpkMgMgcoAmmReq(&param->u.move, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_NTFY :
             ret1 = cmUnpkMgMgcoNtfyReq(&param->u.ntfy, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SUB :
             ret1 = cmUnpkMgMgcoSubAudReq(&param->u.sub, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SVCCHG :
             ret1 = cmUnpkMgMgcoSvcChgReq(&param->u.svc, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmd*/
#ifdef GCP_CH


/*
*
*    Fun:    cmUnpkMgMgcoCommandReq
*
*    Desc:    unpack the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCommandReq
(
MgMgcoCommandReq *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCommandReq(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoCommandReq *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoCommandReq)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknPres, &param->opt,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->wild,mBuf);
       ret1 = cmUnpkMgMgcoCmd(&param->cmd, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCommandReq*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoCommandReq
*
*    Desc:    unpack the structure MgMgcoCommandReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCommandReq
(
MgMgcoCommandReq *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCommandReq(param ,ptr, intfVer, mBuf)
MgMgcoCommandReq *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoCommandReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknPres, &param->opt,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->wild,mBuf);
       ret1 = cmUnpkMgMgcoCmd(&param->cmd, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCommandReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoCmdReqLst
*
*    Desc:    unpack the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReqLst(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoCmdReqLst *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoCmdReqLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       for (i=0;i<param->num.val;i++)
       {
          if(cmAllocEvnt(sizeof(MgMgcoCommandReq), maxBlkSize, sMem,
            (Ptr*)&(param->cmds[i])) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoCommandReq( (param->cmds[i]), sMem , maxBlkSize , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReqLst*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoCmdReqLst
*
*    Desc:    unpack the structure MgMgcoCmdReqLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReqLst
(
MgMgcoCmdReqLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReqLst(param ,ptr, intfVer, mBuf)
MgMgcoCmdReqLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoCmdReqLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->cmds));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoCommandReq), (Ptr*)&(param->cmds[i]));
          ret1 = cmUnpkMgMgcoCommandReq( (param->cmds[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReqLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoActionReq
*
*    Desc:    unpack the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActionReq
(
MgMgcoActionReq *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActionReq(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoActionReq *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActionReq)

    CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    ret1 = cmUnpkMgMgcoContextProps(&param->cxtProps, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkMgMgcoContextAudit, &param->cxtAud,mBuf);
    ret1 = cmUnpkMgMgcoCmdReqLst(&param->cl, sMem , maxBlkSize , intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActionReq*/
#else 
/*
*
*    Fun:    cmUnpkMgMgcoActionReq
*
*    Desc:    unpack the structure MgMgcoActionReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActionReq
(
MgMgcoActionReq *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActionReq(param ,ptr, intfVer, mBuf)
MgMgcoActionReq *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActionReq)

    CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    ret1 = cmUnpkMgMgcoContextProps(&param->cxtProps, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkMgMgcoContextAudit, &param->cxtAud,mBuf);
    ret1 = cmUnpkMgMgcoCmdReqLst(&param->cl, ptr , intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActionReq*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoActionLst
*
*    Desc:    unpack the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActionLst
(
MgMgcoActionLst *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActionLst(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoActionLst *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoActionLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->actns));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoActionReq), (Ptr*)&(param->actns[i]));
          ret1 = cmUnpkMgMgcoActionReq( (param->actns[i]), ptr , sMem , maxBlkSize , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActionLst*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoActionLst
*
*    Desc:    unpack the structure MgMgcoActionLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActionLst
(
MgMgcoActionLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActionLst(param ,ptr, intfVer, mBuf)
MgMgcoActionLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoActionLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->actns));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoActionReq), (Ptr*)&(param->actns[i]));
          ret1 = cmUnpkMgMgcoActionReq( (param->actns[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActionLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoTxnReq
*
*    Desc:    unpack the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnReq
(
MgMgcoTxnReq *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnReq(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoTxnReq *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxnReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
       ret1 = cmUnpkMgMgcoActionLst(&param->al, ptr , sMem , maxBlkSize , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnReq*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoTxnReq
*
*    Desc:    unpack the structure MgMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnReq
(
MgMgcoTxnReq *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnReq(param ,ptr, intfVer, mBuf)
MgMgcoTxnReq *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxnReq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
       ret1 = cmUnpkMgMgcoActionLst(&param->al, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnReq*/
#endif  

/*
*
*    Fun:    cmUnpkMgMgcoStatsPar
*
*    Desc:    unpack the structure MgMgcoStatsPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoStatsPar
(
MgMgcoStatsPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoStatsPar(param ,ptr, mBuf)
MgMgcoStatsPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoStatsPar)

    CMCHKUNPK(cmUnpkTknPkgId, &param->pkg,mBuf);
    ret1 = cmUnpkMgMgcoPkgdName(&param->name, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkMgMgcoValue(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoStatsPar*/

/*
*
*    Fun:    cmUnpkMgMgcoStatsDesc
*
*    Desc:    unpack the structure MgMgcoStatsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoStatsDesc
(
MgMgcoStatsDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoStatsDesc(param ,ptr, mBuf)
MgMgcoStatsDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoStatsDesc)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoStatsPar), (Ptr*)&(param->parms[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoStatsPar,  (param->parms[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoStatsDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoPkgsItem
*
*    Desc:    unpack the structure MgMgcoPkgsItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPkgsItem
(
MgMgcoPkgsItem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPkgsItem(param ,ptr, mBuf)
MgMgcoPkgsItem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoPkgsItem)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoName(&param->name, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU16, &param->ver,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPkgsItem*/

/*
*
*    Fun:    cmUnpkMgMgcoPkgsDesc
*
*    Desc:    unpack the structure MgMgcoPkgsDesc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoPkgsDesc
(
MgMgcoPkgsDesc *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoPkgsDesc(param ,ptr, mBuf)
MgMgcoPkgsDesc *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoPkgsDesc)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->items));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoPkgsItem), (Ptr*)&(param->items[i]));
          CMCHKUNPKPTR(cmUnpkMgMgcoPkgsItem,  (param->items[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoPkgsDesc*/

/*
*
*    Fun:    cmUnpkMgMgcoAudRetParm
*
*    Desc:    unpack the structure MgMgcoAudRetParm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAudRetParm
(
MgMgcoAudRetParm *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAudRetParm(param ,ptr, intfVer, mBuf)
MgMgcoAudRetParm *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAudRetParm)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_AUDITDESC :
#ifdef MGT_MGCO_V2
             ret1 = cmUnpkMgMgcoAuditItem (&param->u.item, ptr, mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#else
             CMCHKUNPK(cmUnpkTknU8, &param->u.item,mBuf);
#endif /* MGT_MGCO_V2 */
             break;
          case  MGT_DIGMAPDESC :
             ret1 = cmUnpkMgMgcoDigMapDesc(&param->u.dm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_ERRDESC :
             ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_EVBUFDESC :
             ret1 = cmUnpkMgMgcoEvBufDesc(&param->u.evBuf, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MEDIADESC :
             ret1 = cmUnpkMgMgcoMediaDesc(&param->u.media, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MODEMDESC :
             ret1 = cmUnpkMgMgcoModemDesc(&param->u.modem, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_MUXDESC :
             ret1 = cmUnpkMgMgcoMuxDesc(&param->u.mux, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_OBSEVTDESC :
             ret1 = cmUnpkMgMgcoObsEvtDesc(&param->u.obs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_PKGSDESC :
             ret1 = cmUnpkMgMgcoPkgsDesc(&param->u.pkgs, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_REQEVTDESC :
             ret1 = cmUnpkMgMgcoReqEvtDesc(&param->u.evts, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SIGNALSDESC :
             ret1 = cmUnpkMgMgcoSignalsDesc(&param->u.sig, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_STATSDESC :
             ret1 = cmUnpkMgMgcoStatsDesc(&param->u.stats, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAudRetParm*/

/*
*
*    Fun:    cmUnpkMgMgcoTermAuditRes
*
*    Desc:    unpack the structure MgMgcoTermAuditRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTermAuditRes
(
MgMgcoTermAuditRes *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTermAuditRes(param ,ptr, intfVer, mBuf)
MgMgcoTermAuditRes *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoTermAuditRes)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->parms));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoAudRetParm), (Ptr*)&(param->parms[i]));
          ret1 = cmUnpkMgMgcoAudRetParm( (param->parms[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTermAuditRes*/

/*
*
*    Fun:    cmUnpkMgMgcoAmmsReply
*
*    Desc:    unpack the structure MgMgcoAmmsReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAmmsReply
(
MgMgcoAmmsReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAmmsReply(param ,ptr, intfVer, mBuf)
MgMgcoAmmsReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAmmsReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoTermAuditRes(&param->audit, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAmmsReply*/

/*
*
*    Fun:    cmUnpkMgMgcoAuditOther
*
*    Desc:    unpack the structure MgMgcoAuditOther
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAuditOther
(
MgMgcoAuditOther *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAuditOther(param ,ptr, intfVer, mBuf)
MgMgcoAuditOther *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAuditOther)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoTermAuditRes(&param->audit, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAuditOther*/

/*
*
*    Fun:    cmUnpkMgMgcoAuditReply
*
*    Desc:    unpack the structure MgMgcoAuditReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoAuditReply
(
MgMgcoAuditReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoAuditReply(param ,ptr, intfVer, mBuf)
MgMgcoAuditReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoAuditReply)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_CXTAUDIT :
             ret1 = cmUnpkMgMgcoTermIdLst(&param->u.cxt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_ERRDESC :
             ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TERMAUDIT :
             ret1 = cmUnpkMgMgcoAuditOther(&param->u.other, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoAuditReply*/

/*
*
*    Fun:    cmUnpkMgMgcoNtfyReply
*
*    Desc:    unpack the structure MgMgcoNtfyReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoNtfyReply
(
MgMgcoNtfyReply *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoNtfyReply(param ,ptr, mBuf)
MgMgcoNtfyReply *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoNtfyReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoErrDesc(&param->err, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoNtfyReply*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgResPar
*
*    Desc:    unpack the structure MgMgcoSvcChgResPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgResPar
(
MgMgcoSvcChgResPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgResPar(param ,ptr, mBuf)
MgMgcoSvcChgResPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgResPar)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoSvcChgAddr(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU8, &param->ver,mBuf);
       ret1 = cmUnpkMgMgcoSvcChgProf(&param->prof, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoMid(&param->mgcId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkMgMgcoTimeStamp, &param->time,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgResPar*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgRes
*
*    Desc:    unpack the structure MgMgcoSvcChgRes
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgRes
(
MgMgcoSvcChgRes *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgRes(param ,ptr, mBuf)
MgMgcoSvcChgRes *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgRes)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( ( param->type.pres != NOTPRSNT )&& ( param->type.pres != NOTPRSNT ))
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_SVCCHGDESC :
             ret1 = cmUnpkMgMgcoSvcChgResPar(&param->u.parm, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgRes*/

/*
*
*    Fun:    cmUnpkMgMgcoSvcChgReply
*
*    Desc:    unpack the structure MgMgcoSvcChgReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoSvcChgReply
(
MgMgcoSvcChgReply *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoSvcChgReply(param ,ptr, mBuf)
MgMgcoSvcChgReply *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoSvcChgReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoTermId(&param->termId, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoSvcChgRes(&param->res, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoSvcChgReply*/
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoCmdReply
*
*    Desc:    unpack the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReply
(
MgMgcoCmdReply *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReply(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoCmdReply *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoCmdReply)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknPres, &param->wild,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ADD :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.add, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITCAP :
                ret1 = cmUnpkMgMgcoAuditReply(&param->u.acap, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITVAL :
                ret1 = cmUnpkMgMgcoAuditReply(&param->u.aval, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MODIFY :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.mod, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MOVE :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.move, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_NTFY :
                ret1 = cmUnpkMgMgcoNtfyReply(&param->u.ntfy, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SUB :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.sub, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SVCCHG :
                ret1 = cmUnpkMgMgcoSvcChgReply(&param->u.svc, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReply*/
#else


/*
*
*    Fun:    cmUnpkMgMgcoCmdReply
*
*    Desc:    unpack the structure MgMgcoCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReply
(
MgMgcoCmdReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReply(param ,ptr, intfVer, mBuf)
MgMgcoCmdReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoCmdReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknPres, &param->wild,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ADD :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.add, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITCAP :
                ret1 = cmUnpkMgMgcoAuditReply(&param->u.acap, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_AUDITVAL :
                ret1 = cmUnpkMgMgcoAuditReply(&param->u.aval, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MODIFY :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.mod, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_MOVE :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.move, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_NTFY :
                ret1 = cmUnpkMgMgcoNtfyReply(&param->u.ntfy, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SUB :
                ret1 = cmUnpkMgMgcoAmmsReply(&param->u.sub, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_SVCCHG :
                ret1 = cmUnpkMgMgcoSvcChgReply(&param->u.svc, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReply*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoCmdReplyLst
*
*    Desc:    unpack the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReplyLst(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoCmdReplyLst *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoCmdReplyLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       for (i=0;i<param->num.val;i++)
       {
          if(cmAllocEvnt(sizeof(MgMgcoCmdReply), maxBlkSize, sMem,
            (Ptr*)&(param->repl[i])) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoCmdReply( (param->repl[i]), sMem , maxBlkSize , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReplyLst*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoCmdReplyLst
*
*    Desc:    unpack the structure MgMgcoCmdReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCmdReplyLst
(
MgMgcoCmdReplyLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCmdReplyLst(param ,ptr, intfVer, mBuf)
MgMgcoCmdReplyLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoCmdReplyLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->repl));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoCmdReply), (Ptr*)&(param->repl[i]));
          ret1 = cmUnpkMgMgcoCmdReply( (param->repl[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCmdReplyLst*/

#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoCxtCmdReply
*
*    Desc:    unpack the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCxtCmdReply(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoCxtCmdReply *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoCxtCmdReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoContextProps(&param->cxt, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoCmdReplyLst(&param->cl, sMem , maxBlkSize , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCxtCmdReply*/
#else
/*
*
*    Fun:    cmUnpkMgMgcoCxtCmdReply
*
*    Desc:    unpack the structure MgMgcoCxtCmdReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCxtCmdReply
(
MgMgcoCxtCmdReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCxtCmdReply(param ,ptr, intfVer, mBuf)
MgMgcoCxtCmdReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoCxtCmdReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoContextProps(&param->cxt, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoCmdReplyLst(&param->cl, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCxtCmdReply*/ 
#endif
#ifdef MGT_GCP_VER_1_4
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoErrCmdRepSet
*
*    Desc:    unpack the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoErrCmdRepSet(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoErrCmdRepSet *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoErrCmdRepSet)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoErrDesc(&param->err, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoCxtCmdReply(&param->reply, ptr , sMem , maxBlkSize , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoErrCmdRepSet*/
#else


/*
*
*    Fun:    cmUnpkMgMgcoErrCmdRepSet
*
*    Desc:    unpack the structure MgMgcoErrCmdRepSet
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoErrCmdRepSet
(
MgMgcoErrCmdRepSet *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoErrCmdRepSet(param ,ptr, intfVer, mBuf)
MgMgcoErrCmdRepSet *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoErrCmdRepSet)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoErrDesc(&param->err, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoCxtCmdReply(&param->reply, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoErrCmdRepSet*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoActnReply
*
*    Desc:    unpack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReply
(
MgMgcoActnReply *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReply(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoActnReply *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
       ret1 = cmUnpkMgMgcoErrCmdRepSet(&param->repErrSet, ptr , sMem , maxBlkSize , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReply*/
#else


/*
*
*    Fun:    cmUnpkMgMgcoActnReply
*
*    Desc:    unpack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReply
(
MgMgcoActnReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReply(param ,ptr, intfVer, mBuf)
MgMgcoActnReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
       ret1 = cmUnpkMgMgcoErrCmdRepSet(&param->repErrSet, ptr , intfVer ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReply*/   
#endif
#else /* MGT_GCP_VER_1_4 */
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoActnReply
*
*    Desc:    unpack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReply
(
MgMgcoActnReply *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReply(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoActnReply *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_CXTCMDREPLY :
                ret1 = cmUnpkMgMgcoCxtCmdReply(&param->u.reply, ptr , sMem , maxBlkSize , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReply*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoActnReply
*
*    Desc:    unpack the structure MgMgcoActnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReply
(
MgMgcoActnReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReply(param ,ptr, intfVer, mBuf)
MgMgcoActnReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoActnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cxtId,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_CXTCMDREPLY :
                ret1 = cmUnpkMgMgcoCxtCmdReply(&param->u.reply, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReply*/ 
#endif
#endif /* MGT_GCP_VER_1_4 */

#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoActnReplyLst
*
*    Desc:    unpack the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReplyLst(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoActnReplyLst *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoActnReplyLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->repl));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoActnReply), (Ptr*)&(param->repl[i]));
          ret1 = cmUnpkMgMgcoActnReply( (param->repl[i]), ptr , sMem , maxBlkSize , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReplyLst*/
#else
/*
*
*    Fun:    cmUnpkMgMgcoActnReplyLst
*
*    Desc:    unpack the structure MgMgcoActnReplyLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoActnReplyLst
(
MgMgcoActnReplyLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoActnReplyLst(param ,ptr, intfVer, mBuf)
MgMgcoActnReplyLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoActnReplyLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->repl));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoActnReply), (Ptr*)&(param->repl[i]));
          ret1 = cmUnpkMgMgcoActnReply( (param->repl[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoActnReplyLst*/
#endif
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoTxnReply
*
*    Desc:    unpack the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnReply
(
MgMgcoTxnReply *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnReply(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoTxnReply *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->immAck,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ACTIONREPLY :
                ret1 = cmUnpkMgMgcoActnReplyLst(&param->u.arl, ptr , sMem , maxBlkSize , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnReply*/
#else        
/*
*
*    Fun:    cmUnpkMgMgcoTxnReply
*
*    Desc:    unpack the structure MgMgcoTxnReply
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnReply
(
MgMgcoTxnReply *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnReply(param ,ptr, intfVer, mBuf)
MgMgcoTxnReply *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxnReply)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
       CMCHKUNPK(cmUnpkTknPres, &param->immAck,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
       if( param->type.pres != NOTPRSNT )
       {
          switch( param->type.val )
          {
             case  MGT_ACTIONREPLY :
                ret1 = cmUnpkMgMgcoActnReplyLst(&param->u.arl, ptr , intfVer ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             case  MGT_ERRDESC :
                ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnReply*/
#endif

/*
*
*    Fun:    cmUnpkMgMgcoTxnPend
*
*    Desc:    unpack the structure mgMgcoTxnPend
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnPend
(
MgMgcoTxnPend *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnPend(param ,mBuf)
MgMgcoTxnPend *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoTxnPend)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnPend*/

/*
*
*    Fun:    cmUnpkMgMgcoTxnAck
*
*    Desc:    unpack the structure mgMgcoTxnAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnAck
(
MgMgcoTxnAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnAck(param ,mBuf)
MgMgcoTxnAck *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgcoTxnAck)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->first,mBuf);
       CMCHKUNPK(cmUnpkMgMgcoTransId, &param->last,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnAck*/

/*
*
*    Fun:    cmUnpkMgMgcoTxnRspAck
*
*    Desc:    unpack the structure MgMgcoTxnRspAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnRspAck
(
MgMgcoTxnRspAck *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnRspAck(param ,ptr, mBuf)
MgMgcoTxnRspAck *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgMgcoTxnRspAck)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->acks));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoTxnAck), (Ptr*)&(param->acks[i]));
          CMCHKUNPK(cmUnpkMgMgcoTxnAck,  (param->acks[i]), mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnRspAck*/
#ifdef GCP_VER_1_3
#ifdef GCP_CH

/*
*
*    Fun:    cmUnpkMgMgcoTxn
*
*    Desc:    unpack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxn
(
MgMgcoTxn *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxn(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoTxn *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxn)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKUNPK(cmUnpkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmUnpkMgMgcoTxnReply(&param->u.reply, ptr , sMem , maxBlkSize , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmUnpkMgMgcoTxnReq(&param->u.req, ptr , sMem , maxBlkSize , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmUnpkMgMgcoTxnRspAck(&param->u.rspAck, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkMgLclErr, &param->mgLclErr,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dupInfo,mBuf);
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxn*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoTxn
*
*    Desc:    unpack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxn
(
MgMgcoTxn *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxn(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoTxn *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxn)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKUNPK(cmUnpkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmUnpkMgMgcoTxnReply(&param->u.reply, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmUnpkMgMgcoTxnReq(&param->u.req, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmUnpkMgMgcoTxnRspAck(&param->u.rspAck, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkMgLclErr, &param->mgLclErr,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dupInfo,mBuf);
#if(  defined(  ZG_DFTHA)  || defined(  DG) ) 
    CMCHKUNPK(SUnpkU16, &param->rsetId,mBuf);
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxn*/  
#endif
#else

/*
*
*    Fun:    cmUnpkMgMgcoTxn
*
*    Desc:    unpack the structure MgMgcoTxn
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxn
(
MgMgcoTxn *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxn(param ,ptr, intfVer, mBuf)
MgMgcoTxn *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoTxn)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_TXNLOCAL_ERR :
             break;
          case  MGT_TXNPEND :
             CMCHKUNPK(cmUnpkMgMgcoTxnPend, &param->u.pend,mBuf);
             break;
          case  MGT_TXNREPLY :
             ret1 = cmUnpkMgMgcoTxnReply(&param->u.reply, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNREQ :
             ret1 = cmUnpkMgMgcoTxnReq(&param->u.req, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXNRSPACK :
             ret1 = cmUnpkMgMgcoTxnRspAck(&param->u.rspAck, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKUNPK(cmUnpkMgLclErr, &param->mgLclErr,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dupInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxn*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmUnpkMgMgcoTxnLst
*
*    Desc:    unpack the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnLst
(
MgMgcoTxnLst *param,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnLst(param , sMem, maxBlkSize, intfVer, mBuf)
MgMgcoTxnLst *param;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoTxnLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    for (i=0;i<param->num.val;i++)
    {
       if(cmAllocEvnt(sizeof(MgMgcoTxn), maxBlkSize, sMem,
         (Ptr*)&(param->txns[i])) != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkMgMgcoTxn( (param->txns[i]), sMem , maxBlkSize , intfVer ,mBuf);
       if(ret1 != ROK)
       {
          SPutMsg(mBuf);
          RETVALUE( ret1 );
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnLst*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoTxnLst
*
*    Desc:    unpack the structure MgMgcoTxnLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoTxnLst
(
MgMgcoTxnLst *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoTxnLst(param ,ptr, intfVer, mBuf)
MgMgcoTxnLst *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoTxnLst)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->txns));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(MgMgcoTxn), (Ptr*)&(param->txns[i]));
          ret1 = cmUnpkMgMgcoTxn( (param->txns[i]), ptr , intfVer ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoTxnLst*/
#endif
#ifdef GCP_VER_1_3

/*
*
*    Fun:    cmUnpkMgMgcoMsgBody
*
*    Desc:    unpack the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMsgBody
(
MgMgcoMsgBody *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMsgBody(param ,ptr,  sMem, maxBlkSize, intfVer, mBuf)
MgMgcoMsgBody *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoMsgBody)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXN :
             ret1 = cmUnpkMgMgcoTxnLst(&param->u.tl, sMem , maxBlkSize , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMsgBody*/
#else

/*
*
*    Fun:    cmUnpkMgMgcoMsgBody
*
*    Desc:    unpack the structure MgMgcoMsgBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMsgBody
(
MgMgcoMsgBody *param,
Ptr ptr,
CmIntfVer intfVer,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMsgBody(param ,ptr, intfVer, mBuf)
MgMgcoMsgBody *param;
Ptr ptr;
CmIntfVer intfVer;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoMsgBody)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  MGT_ERRDESC :
             ret1 = cmUnpkMgMgcoErrDesc(&param->u.err, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  MGT_TXN :
             ret1 = cmUnpkMgMgcoTxnLst(&param->u.tl, ptr , intfVer ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMsgBody*/
#endif

/*
*
*    Fun:    cmUnpkMgMgcoMsg
*
*    Desc:    unpack the structure MgMgcoMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoMsg
(
MgMgcoMsg *param,
Mem *sMem,
Size maxBlkSize,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoMsg(param , sMem, maxBlkSize,  pst, mBuf)
MgMgcoMsg *param;
Mem *sMem;
Size maxBlkSize;
Pst *pst;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoMsg)

    ptr =(Ptr)param;
   /*MAH_TODO */
    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    ret1 = cmUnpkMgMgcoAuthHdr(&param->ah, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkMgMgcoVersion, &param->ver,mBuf);
    ret1 = cmUnpkMacroTknStrOSXL(&param->mid, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#ifdef GCP_VER_1_3
    ret1 = cmUnpkMgMgcoMsgBody(&param->body, ptr , sMem , maxBlkSize , pst->intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#else /* ,,,,,,,,,,,, */ 
    ret1 = cmUnpkMgMgcoMsgBody(&param->body, ptr , pst->intfVer ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
#endif /*  GCP_VER_1_3,#else  */
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->lcl,mBuf);
#ifdef GCP_PROV_SCTP
    CMCHKUNPK(SUnpkU8, &param->unorder,mBuf);
#endif /*  GCP_PROV_SCTP  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoMsg*/
#endif /* GCP_MGCO */

/*
*
*    Fun:    cmUnpkMgMgtSta
*
*    Desc:    unpack the structure mgMgtSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgtSta
(
MgMgtSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgtSta(param ,mBuf)
MgMgtSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMgtSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    switch( param->type )
    {
       case  MGT_STATUS_FLOW :
          CMCHKUNPK(SUnpkU8, &param->u.action,mBuf);
          break;
       case  MGT_STATUS_HANDOFF_FAILED :
          break;
#ifdef GCP_MGCO
       case  MGT_STATUS_MGCO_VER :
          CMCHKUNPK(cmUnpkTknU32, &param->u.mgcoVersion,mBuf);
          break;
#endif /*  GCP_MGCO  */
#ifdef GCP_MGCP
       case  MGT_STATUS_MGCP_VER :
          CMCHKUNPK(cmUnpkTknU32, &param->u.mgcpVersion,mBuf);
          break;
#endif /*  GCP_MGCP  */
       case  MGT_STATUS_PEER :
          CMCHKUNPK(SUnpkU8, &param->u.reason,mBuf);
          break;
       case  MGT_STATUS_REDIRECTION_FAILED :
          break;
       case  MGT_STATUS_SAP_RECVRY_FAILED :
          break;
       case  MGT_STATUS_SAP_RECVRY_SUCCESS :
          break;
       case  MGT_STATUS_SRVC_PRVDR_FAILED :
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgtSta*/
#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 

/*
*
*    Fun:    cmUnpkMgMgcoCommand
*
*    Desc:    unpack the structure MgMgcoCommand
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoCommand
(
MgMgcoCommand *param,
Mem *sMem,
Size maxBlkSize,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoCommand(param , sMem, maxBlkSize,  pst, mBuf)
MgMgcoCommand *param;
Mem *sMem;
Size maxBlkSize;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkMgMgcoCommand)

    CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
    CMCHKUNPK(cmUnpkMgMgcoContextId, &param->contextId,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->peerId,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->cmdStatus,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->cmdType,mBuf);
    if( param->cmdType.pres != NOTPRSNT )
    {
       switch( param->cmdType.val )
       {
          case  CH_CMD_TYPE_CFM :
             for (i=0;i<MGT_ONE_CMD;i++)
             {
                if(cmAllocEvnt(sizeof(MgMgcoCmdReply), maxBlkSize, sMem,
                  (Ptr*)&(param->u.mgCmdCfm[i])) != ROK)
                {
                   RETVALUE(RFAILED);
                }
                ret1 = cmUnpkMgMgcoCmdReply( (param->u.mgCmdCfm[i]), sMem , maxBlkSize , pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf);
                   RETVALUE( ret1 );
                }
             }
             break;
          case  CH_CMD_TYPE_IND :
             for (i=0;i<MGT_ONE_CMD;i++)
             {
                if(cmAllocEvnt(sizeof(MgMgcoCommandReq), maxBlkSize, sMem,
                  (Ptr*)&(param->u.mgCmdInd[i])) != ROK)
                {
                   RETVALUE(RFAILED);
                }
                ret1 = cmUnpkMgMgcoCommandReq( (param->u.mgCmdInd[i]), sMem , maxBlkSize , pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf);
                   RETVALUE( ret1 );
                }
             }
             break;
          case  CH_CMD_TYPE_REQ :
             for (i=0;i<MGT_ONE_CMD;i++)
             {
                if(cmAllocEvnt(sizeof(MgMgcoCommandReq), maxBlkSize, sMem,
                  (Ptr*)&(param->u.mgCmdReq[i])) != ROK)
                {
                   RETVALUE(RFAILED);
                }
                ret1 = cmUnpkMgMgcoCommandReq( (param->u.mgCmdReq[i]), sMem , maxBlkSize , pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf);
                   RETVALUE( ret1 );
                }
             }
             break;
          case  CH_CMD_TYPE_RSP :
             for (i=0;i<MGT_ONE_CMD;i++)
             {
                if(cmAllocEvnt(sizeof(MgMgcoCmdReply), maxBlkSize, sMem,
                  (Ptr*)&(param->u.mgCmdRsp[i])) != ROK)
                {
                   RETVALUE(RFAILED);
                }
                ret1 = cmUnpkMgMgcoCmdReply( (param->u.mgCmdRsp[i]), sMem , maxBlkSize , pst->intfVer ,mBuf);
                if(ret1 != ROK)
                {
                   SPutMsg(mBuf);
                   RETVALUE( ret1 );
                }
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoCommand*/


/*
*
*    Fun:    cmUnpkMgMgcoChCntxt
*
*    Desc:    unpack the structure MgMgcoChCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoChCntxt
(
MgMgcoChCntxt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoChCntxt(param ,ptr, mBuf)
MgMgcoChCntxt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMgcoChCntxt)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkMgMgcoContextProps(&param->cxtProps, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkMgMgcoContextAudit, &param->cxtAudit,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoChCntxt*/

/*
*
*    Fun:    cmUnpkMgMgcoUpdateCntxt
*
*    Desc:    unpack the structure MgMgcoUpdateCntxt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoUpdateCntxt
(
MgMgcoUpdateCntxt *param,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoUpdateCntxt(param , sMem, maxBlkSize, mBuf)
MgMgcoUpdateCntxt *param;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoUpdateCntxt)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
    CMCHKUNPK(cmUnpkMgMgcoContextId, &param->contextId,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->peerId,mBuf);
    ret1 = cmUnpkMgMgcoChCntxt(&param->contextProp, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkTknU8, &param->status,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoUpdateCntxt*/

/*
*
*    Fun:    cmUnpkMgMgcoInd
*
*    Desc:    unpack the structure MgMgcoInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMgcoInd
(
MgMgcoInd *param,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMgcoInd(param , sMem, maxBlkSize, mBuf)
MgMgcoInd *param;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkMgMgcoInd)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkMgMgcoTransId, &param->transId,mBuf);
    CMCHKUNPK(cmUnpkMgMgcoContextId, &param->cntxtId,mBuf);
    CMCHKUNPK(cmUnpkTknU32, &param->peerId,mBuf);
    ret1 = cmUnpkMgMgcoErrDesc(&param->err, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(cmUnpkTknPres, &param->txnPending,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMgcoInd*/


/*
*
*    Fun:    cmUnpkMgtMgcoCmdReq
*
*    Desc:    unpack the primitive MgtMgcoCmdReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoCmdReq
(
MgtMgcoCmdReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoCmdReq(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoCmdReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    U32 index;
    MgMgcoCommand chCmdReq;
    
    TRC3(cmUnpkMgtMgcoCmdReq)
    index = 0;

    /* mgt_c_005.main_14: chCmdReq is initialized to zero before unpacking */
    cmMemset((U8 *)&chCmdReq,0, sizeof(MgMgcoCommand));
	
    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT066, pst);
    switch(pst->selector)
    {
#ifdef LCMGT    
    case MGT_SEL_LC:
    ret1 = cmUnpkMgMgcoCommand(&chCmdReq, sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)EMGT067, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /* LCMGT */
    break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
    
    CMCHKUNPK(cmUnpkMgMgcoTransId, &(chCmdReq.transId),mBuf);
    CMCHKUNPK(cmUnpkMgMgcoContextId, &(chCmdReq.contextId),mBuf);
    CMCHKUNPK(cmUnpkTknU32, &(chCmdReq.peerId),mBuf);
    CMCHKUNPK(cmUnpkTknU8, &(chCmdReq.cmdStatus),mBuf);
    CMCHKUNPK(cmUnpkTknU8, &(chCmdReq.cmdType),mBuf);
    /*
     * Now you have packed the individual members, Now Unpack the 
     * member of the union
     */
    switch (chCmdReq.cmdType.val)
    {  
      case CH_CMD_TYPE_REQ:
      case CH_CMD_TYPE_IND:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKUNPK(cmUnpkPtr,(PTR*)&(chCmdReq.u.mgCmdReq[index]),mBuf);
        } 
        break;
      case CH_CMD_TYPE_RSP:
      case CH_CMD_TYPE_CFM:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKUNPK(cmUnpkPtr,(PTR*)&(chCmdReq.u.mgCmdRsp[index]),mBuf);
        }
        break;
    }
    break;
#endif/*LWLCMGT*/
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &chCmdReq));
} /*end of function cmUnpkMgtMgcoCmdReq*/

    
/*
*
*    Fun:    cmUnpkMgtMgcoCmdInd
*
*    Desc:    unpack the primitive MgtMgcoCmdInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoCmdInd
(
MgtMgcoCmdInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoCmdInd(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoCmdInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    U32 index;
    MgMgcoCommand chCmdInd;
    
    TRC3(cmUnpkMgtMgcoCmdInd)
    index = 0;
    
    /* mgt_c_005.main_14: chCmdInd is initialized to zero before unpacking */
    cmMemset((U8 *)&chCmdInd,0, sizeof(MgMgcoCommand));
	
    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT068, pst);
    switch(pst->selector)
    {
#ifdef  LCMGT    
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
        ret1 = cmUnpkMgMgcoCommand(&chCmdInd, sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)EMGT069, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    break;
#endif
#ifdef  LWLCMGT    
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
/*Now UnPack One by one */
    CMCHKUNPK(cmUnpkMgMgcoTransId, &(chCmdInd.transId),mBuf);
    CMCHKUNPK(cmUnpkMgMgcoContextId, &(chCmdInd.contextId),mBuf);
    CMCHKUNPK(cmUnpkTknU32, &(chCmdInd.peerId),mBuf);
    CMCHKUNPK(cmUnpkTknU8, &(chCmdInd.cmdStatus),mBuf);
    CMCHKUNPK(cmUnpkTknU8, &(chCmdInd.cmdType),mBuf);
    /*
     * Now you have packed the individual members, Now Unpack the 
     * member of the union
     */
    switch (chCmdInd.cmdType.val)
    {  
      case CH_CMD_TYPE_REQ:
      case CH_CMD_TYPE_IND:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKUNPK(cmUnpkPtr,(PTR*)&(chCmdInd.u.mgCmdReq[index]),mBuf);
        } 
      case CH_CMD_TYPE_RSP:
      case CH_CMD_TYPE_CFM:
        for (index=0;index < MGT_ONE_CMD;index++)
        {
          CMCHKUNPK(cmUnpkPtr,(PTR*)&(chCmdInd.u.mgCmdRsp[index]),mBuf);
        }
    }
    break;
#endif
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &chCmdInd));
} /*end of function cmUnpkMgtMgcoCmdInd*/


/*
*
*    Fun:    cmUnpkMgtMgcoUpdCtxtReq
*
*    Desc:    unpack the primitive MgtMgcoUpdCtxtReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoUpdCtxtReq
(
MgtMgcoUpdCtxtReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoUpdCtxtReq(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoUpdCtxtReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcoUpdateCntxt *chCntxtReq;
    
    TRC3(cmUnpkMgtMgcoUpdCtxtReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT070, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          if(cmAllocEvnt(sizeof(MgMgcoUpdateCntxt), maxBlkSize, sMem,
            (Ptr*)&chCntxtReq) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoUpdateCntxt( (chCntxtReq), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT071, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&chCntxtReq, mBuf, EMGT072,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, chCntxtReq));
} /*end of function cmUnpkMgtMgcoUpdCtxtReq*/

/*
*
*    Fun:    cmUnpkMgtMgcoUpdCtxtInd
*
*    Desc:    unpack the primitive MgtMgcoUpdCtxtInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoUpdCtxtInd
(
MgtMgcoUpdCtxtInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoUpdCtxtInd(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoUpdCtxtInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcoUpdateCntxt *chCntxtInd;
    
    TRC3(cmUnpkMgtMgcoUpdCtxtInd)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT073, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          if(cmAllocEvnt(sizeof(MgMgcoUpdateCntxt), maxBlkSize, sMem,
            (Ptr*)&chCntxtInd) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoUpdateCntxt( (chCntxtInd), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT074, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&chCntxtInd, mBuf, EMGT075,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, chCntxtInd));
} /*end of function cmUnpkMgtMgcoUpdCtxtInd*/

/*
*
*    Fun:    cmUnpkMgtMgcoErrReq
*
*    Desc:    unpack the primitive MgtMgcoErrReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoErrReq
(
MgtMgcoErrReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoErrReq(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoErrReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcoInd *errRsp;
    
    TRC3(cmUnpkMgtMgcoErrReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT076, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          if(cmAllocEvnt(sizeof(MgMgcoInd), maxBlkSize, sMem,
            (Ptr*)&errRsp) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoInd( (errRsp), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT077, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&errRsp, mBuf, EMGT078,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, errRsp));
} /*end of function cmUnpkMgtMgcoErrReq*/

/*
*
*    Fun:    cmUnpkMgtMgcoTxnStaInd
*
*    Desc:    unpack the primitive MgtMgcoTxnStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoTxnStaInd
(
MgtMgcoTxnStaInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoTxnStaInd(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoTxnStaInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcoInd *chTxnStaInd;
    
    TRC3(cmUnpkMgtMgcoTxnStaInd)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT079, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          if(cmAllocEvnt(sizeof(MgMgcoInd), maxBlkSize, sMem,
            (Ptr*)&chTxnStaInd) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoInd( (chTxnStaInd), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT080, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&chTxnStaInd, mBuf, EMGT081,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, chTxnStaInd));
} /*end of function cmUnpkMgtMgcoTxnStaInd*/

#endif /* GCP_CH && GCP_VER_1_5 */

/*
*
*    Fun:    cmUnpkMgtBndReq
*
*    Desc:    unpack the primitive MgtBndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtBndReq
(
MgtBndReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtBndReq(func, pst, mBuf)
MgtBndReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SuId suId;
    SpId spId;
    
    TRC3(cmUnpkMgtBndReq)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, EMGT082, pst);
    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT083, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, spId));
} /*end of function cmUnpkMgtBndReq*/

/*
*
*    Fun:    cmUnpkMgtUbndReq
*
*    Desc:    unpack the primitive MgtUbndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtUbndReq
(
MgtUbndReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtUbndReq(func, pst, mBuf)
MgtUbndReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    Reason reason;
    
    TRC3(cmUnpkMgtUbndReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT084, pst);
    CMCHKUNPKLOG(SUnpkS16, &reason, mBuf, EMGT085, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, reason));
} /*end of function cmUnpkMgtUbndReq*/

/*
*
*    Fun:    cmUnpkMgtBndCfm
*
*    Desc:    unpack the primitive MgtBndCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtBndCfm
(
MgtBndCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtBndCfm(func, pst, mBuf)
MgtBndCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SuId suId;
    U8 status;
    
    TRC3(cmUnpkMgtBndCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, EMGT086, pst);
    CMCHKUNPKLOG(SUnpkU8, &status, mBuf, EMGT087, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, status));
} /*end of function cmUnpkMgtBndCfm*/

/*
*
*    Fun:    cmUnpkMgtCntrlReq
*
*    Desc:    unpack the primitive MgtCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtCntrlReq
(
MgtCntrlReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtCntrlReq(func, pst, mBuf)
MgtCntrlReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    MgMgtCntrl cntrl;
    
    TRC3(cmUnpkMgtCntrlReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT088, pst);
    CMCHKUNPKLOG(cmUnpkMgMgtCntrl, &(cntrl), mBuf, EMGT089,pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &cntrl));
} /*end of function cmUnpkMgtCntrlReq*/

/*
*
*    Fun:    cmUnpkMgtCntrlCfm
*
*    Desc:    unpack the primitive MgtCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtCntrlCfm
(
MgtCntrlCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtCntrlCfm(func, pst, mBuf)
MgtCntrlCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    MgMgtCntrl cntrl;
    Reason reason;
    
    TRC3(cmUnpkMgtCntrlCfm)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT090, pst);
    CMCHKUNPKLOG(cmUnpkMgMgtCntrl, &(cntrl), mBuf, EMGT091,pst);
    CMCHKUNPKLOG(SUnpkS16, &reason, mBuf, EMGT092, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &cntrl, reason));
} /*end of function cmUnpkMgtCntrlCfm*/

/*
*
*    Fun:    cmUnpkMgtAuditReq
*
*    Desc:    unpack the primitive MgtAuditReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtAuditReq
(
MgtAuditReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtAuditReq(func, pst, mBuf)
MgtAuditReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    MgMgtAudit audit;
    
    TRC3(cmUnpkMgtAuditReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT093, pst);
    CMCHKUNPKLOG(cmUnpkMgMgtAudit, &(audit), mBuf, EMGT094,pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &audit));
} /*end of function cmUnpkMgtAuditReq*/

/*
*
*    Fun:    cmUnpkMgtAuditCfm
*
*    Desc:    unpack the primitive MgtAuditCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtAuditCfm
(
MgtAuditCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtAuditCfm(func, pst, mBuf)
MgtAuditCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    MgMgtAudit audit;
    Reason reason;
    
    TRC3(cmUnpkMgtAuditCfm)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT095, pst);
    CMCHKUNPKLOG(cmUnpkMgMgtAudit, &(audit), mBuf, EMGT096,pst);
    CMCHKUNPKLOG(SUnpkS16, &reason, mBuf, EMGT097, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &audit, reason));
} /*end of function cmUnpkMgtAuditCfm*/

/*
*
*    Fun:    cmUnpkMgtStaInd
*
*    Desc:    unpack the primitive MgtStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtStaInd
(
MgtStaInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgtStaInd(func, pst, mBuf)
MgtStaInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    MgMgtSta sta;
    
    TRC3(cmUnpkMgtStaInd)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT098, pst);
    CMCHKUNPKLOG(cmUnpkMgMgtSta, &(sta), mBuf, EMGT099,pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, &sta));
} /*end of function cmUnpkMgtStaInd*/
#ifdef GCP_MGCP

/*
*
*    Fun:    cmUnpkMgtMgcpTxnReq
*
*    Desc:    unpack the primitive MgtMgcpTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcpTxnReq
(
MgtMgcpTxnReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcpTxnReq(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcpTxnReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcpTxn *mgTxn;
    
    TRC3(cmUnpkMgtMgcpTxnReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT100, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          if(cmAllocEvnt(sizeof(MgMgcpTxn), maxBlkSize, sMem,
            (Ptr*)&mgTxn) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcpTxn( (mgTxn), sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT101, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&mgTxn, mBuf, EMGT102,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, mgTxn));
} /*end of function cmUnpkMgtMgcpTxnReq*/

/*
*
*    Fun:    cmUnpkMgtMgcpTxnInd
*
*    Desc:    unpack the primitive MgtMgcpTxnInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcpTxnInd
(
MgtMgcpTxnInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcpTxnInd(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcpTxnInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SuId suId;
    MgMgcpTxn *mgTxn;
    
    TRC3(cmUnpkMgtMgcpTxnInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, EMGT103, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          if(cmAllocEvnt(sizeof(MgMgcpTxn), maxBlkSize, sMem,
            (Ptr*)&mgTxn) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcpTxn( (mgTxn), sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT104, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&mgTxn, mBuf, EMGT105,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, mgTxn));
} /*end of function cmUnpkMgtMgcpTxnInd*/
#endif /* GCP_MGCP */
#ifdef GCP_MGCO

/*
*
*    Fun:    cmUnpkMgtMgcoTxnReq
*
*    Desc:    unpack the primitive MgtMgcoTxnReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoTxnReq
(
MgtMgcoTxnReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoTxnReq(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoTxnReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SpId spId;
    MgMgcoMsg *mgTxn;
    
    TRC3(cmUnpkMgtMgcoTxnReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, EMGT106, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
          if(cmAllocEvnt(sizeof(MgMgcoMsg), maxBlkSize, sMem,
            (Ptr*)&mgTxn) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoMsg( (mgTxn), sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT107, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&mgTxn, mBuf, EMGT108,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, mgTxn));
} /*end of function cmUnpkMgtMgcoTxnReq*/

/*
*
*    Fun:    cmUnpkMgtMgcoTxnInd
*
*    Desc:    unpack the primitive MgtMgcoTxnInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     mgt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgtMgcoTxnInd
(
MgtMgcoTxnInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkMgtMgcoTxnInd(func, pst, mBuf,  sMem, maxBlkSize)
MgtMgcoTxnInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    S16 ret1;
    SuId suId;
    MgMgcoMsg *mgTxn;
    
    TRC3(cmUnpkMgtMgcoTxnInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, EMGT109, pst);
    switch(pst->selector)
    {
#ifdef LCMGT
       case MGT_SEL_LC:
	   case MGT_SEL_LC_SS:
          if(cmAllocEvnt(sizeof(MgMgcoMsg), maxBlkSize, sMem,
            (Ptr*)&mgTxn) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkMgMgcoMsg( (mgTxn), sMem , maxBlkSize , pst ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)EMGT110, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
          break;
#endif /* LCMGT */
#ifdef LWLCMGT
       case  MGT_SEL_LWLC:
	   case MGT_SEL_LWLC_SS: 
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&mgTxn, mBuf, EMGT111,pst);
          break;
#endif /* LWLCMGT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, mgTxn));
} /*end of function cmUnpkMgtMgcoTxnInd*/
#endif /* GCP_MGCO */


#endif /* #if(defined(LCMGT) || defined(LWLCMGT)) */


/********************************************************************30**

         End of file:     mgt.c@@/main/mgcp_rel_1.5_mnt/3 - Fri Jun 24 18:40:12 2005

*********************************************************************31*/
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1. Initial release
1.1+         001.101  bbk  1. Changed data type for peerId in MgLclInfo
                              from U16 to U32. Change is under GCP_ENHNC_1_2
                              compile time flag
/main/3      ---       pk  1. Added MEGACO support.
/main/3+ 001.main_3    sk  1. Added Pres field in mgMgcoAuditDesc
/main/3+ 002.main_3    vj  1. Modified MgDName structure so that the generated
                              mgt.c packs/unpacks ipAddr irrespective of 
                              namePres field.
         003.main_3    vj  1. Modified MgPeerInfo structure for MEGACO, and
                              added mid as a new field.
                           2. Modified MgMgcoMsg structure for MEGACO by
                              changing the type of mid field to TknStrOSXL.
/main/9      ---      ra   1. GCP 1.3 release
/main/9  001.main_9   ra   1. Changes in termination state descriptor to
                              allow multiple property parms => changes in
                              packing/unpacking. Also RUG compliance has
                              been built in to allow the new MGT version to
                              interoperate with the old MGT version until
                              both the GCP and MU binaries have been updated
                              with the new MGT version.
/main/9  002.main_9   ra   1. MGTIFVER is now put under MG_RUG flag.
                           2. intfVer is now being passed to functions
                              in case the flag GCP_VER_1_3 is not defined.
                              Consequently, function definitions have been
                              changed at many places.
/main/9  003.main_9   ra   1. Changes in pkunpk functions to allow errDesc
                              in messageBody if GCP_VER_1_3 flag is defined.
/main/14     ---      pk   1. GCP release 1.5                              
/main/14 001.main_14  ra   1. Changes in Audit Descriptor Packing/Unpacking
			                  2. Changes in DigitMapDescriptot Packing/Unpacking
   mgt_c_002.main_14  gk   1. Added wildcard support in Termination id
                              for GCP_ASN
               			   2. Added Annex C support in GCP_ASN
   mgt_c_003.main_14  gk   1. Support for packages to U16 under 
                              flag MGT_PROPR_PKG_SUPPORT
   mgt_c_004.main_14  gk   1. boolean field is added in MgMgcoValue union
                           2. No code should be outside the switch case
   mgt_c_005.main_14  gk   1. chCmdReq, chCmdInd are initialized to zero
                              before unpacking                        
*********************************************************************91*/
