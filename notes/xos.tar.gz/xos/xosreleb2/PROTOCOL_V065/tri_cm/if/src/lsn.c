/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

  
/********************************************************************20**

     Name:     Layer management interface - mtp level 3

     Type:     C source file
  
     Desc:     C source code for common packing and un-packing
               functions for layer manager interface.

     File:     lsn.c
  
     Sid:      lsn.c@@/main/5 - Mon Apr  9 13:48:15 2001
  
     Prg:      sr
  
*********************************************************************21*/



 
/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     
*
*/
  


 
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"
#include "cm_hash.h"
#include "lsn.h"

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"
#include "lsn.x"
#include "cm_hash.x"
 

/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */



/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

#ifdef LCLSN
#ifdef LCSNMILSN
#if (SN_LMINT3 || SMSN_LMINT3)


/*
*
*       Fun:   Pack configuration  Confirm
*
*       Desc:  This function is used to confirm the receipt of configuration
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnCfgCfm
(
Pst *pst,                 /* post structure */    
SnMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLsnCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SnMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;
 
   TRC3(cmPkLsnCfgCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN001, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSN002, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELSN003, pst);
   
   pst->event = EVTLSNCFGCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnCfgCfm */



/*
*
*       Fun:   Pack control  Confirm
*
*       Desc:  This function is used to confirm the receipt of control
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnCntrlCfm
(
Pst *pst,                 /* post structure */    
SnMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLsnCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SnMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;
 
   TRC3(cmPkLsnCntrlCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN004, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSN005, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELSN006, pst);
   pst->event = EVTLSNCNTRLCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnCntrlCfm */

#endif /* SN_LMINT3 || SMSN_LMINT3 */


/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnStaCfm
(
Pst *pst,                 /* post structure */     
SnMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 cmPkLsnStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SnMngmt *sta;             /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;                 /* return value */
 
   TRC3(cmPkLsnStaCfm)
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN007, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   switch (sta->hdr.elmId.elmnt)
   {
      case STNSAP:
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snSAP.sapState, mBuf, ELSN008, pst);
         break;
      case STDLSAP:
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.state, mBuf, ELSN009, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.bndState, mBuf, ELSN010, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.flcSt, mBuf, ELSN011, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.congPrior, mBuf, ELSN012, pst);
         CMCHKPKLOG( SPkU32, sta->t.ssta.s.snDLSAP.tQSize, mBuf, ELSN013, pst);
         CMCHKPKLOG( SPkU32, sta->t.ssta.s.snDLSAP.rTQSize, mBuf, ELSN014, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.blkd, mBuf, ELSN015, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.locBlkd, mBuf, ELSN016, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.remBlkd, mBuf, ELSN017, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.inhbt, mBuf, ELSN018, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.locInhbt, mBuf, ELSN019, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.rmtInhbt, mBuf, ELSN020, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.uninhbt, mBuf, ELSN021, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snDLSAP.emerg, mBuf, ELSN022, pst);
         break;
      case STLNKSET:
         CMCHKPKLOG( SPkU16, sta->t.ssta.s.snLnkSet.nmbActLnks, mBuf, ELSN023, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snLnkSet.state, mBuf, ELSN024, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snLnkSet.tfpFlg, mBuf, ELSN025, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snLnkSet.tfrFlg, mBuf, ELSN026, pst);
#if SS7_NTT
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snLnkSet.NTTState, mBuf, ELSN027, pst);
#endif
         break;
      case STROUT:
         CMCHKPKLOG( SPkU32, sta->t.ssta.s.snRout.dpc, mBuf, ELSN028, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snRout.upSwtch, mBuf, ELSN029, pst);
         CMCHKPKLOG( SPkU16, sta->t.ssta.s.snRout.nmbActvLnkSets, mBuf, ELSN030, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snRout.state, mBuf, ELSN031, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snRout.congLvl, mBuf, ELSN032, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snRout.rstFlg, mBuf, ELSN033, pst);
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snRout.restrict, mBuf, ELSN034, pst);
         break;
      case STGEN:
         CMCHKPKLOG( SPkU8, sta->t.ssta.s.snSP.spRst, mBuf, ELSN035, pst);
         break;
      case STSID:         /* system id */
         /* pack system id structure */
         CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELSN036, pst)
         break;
      default:
         break;
   }
   CMCHKPKLOG( cmPkDateTime, &sta->t.ssta.dt, mBuf, ELSN037, pst);
#if (SN_LMINT3 || SMSN_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELSN038, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKPKLOG( cmPkHeader, &sta->hdr, mBuf, ELSN039, pst);
   pst->event = EVTLSNSTACFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnStaCfm */

 

/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnStaInd
(
Pst *pst,                 /* post structure */
SnMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 cmPkLsnStaInd(pst, sta)
Pst *pst;                 /* post structure */   
SnMngmt *sta;             /* unsolicited status */
#endif
{
   S16 i;                 /* counter */
   Buffer *mBuf;          /* message buffer */
   S16 ret1;                 /* return value */
 
   TRC3(cmPkLsnStaInd)
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN040, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
#if (SN_LMINT3 || SMSN_LMINT3)
   for (i = 0; i < 8; i++)  
   {
      CMCHKPKLOG( SPkU8, sta->t.usta.evntParm[i], mBuf, ELSN041, pst);
   }
   CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, mBuf, ELSN042, pst);
#else /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKPKLOG( SPkU16, sta->t.usta.evnt, mBuf, ELSN043, pst);
   for (i = 0; i < 8; i++)  
   {
      CMCHKPKLOG( SPkU8, sta->t.usta.evntParm[i], mBuf, ELSN044, pst);
   }
   CMCHKPKLOG( cmPkDateTime, &sta->t.usta.dt, mBuf, ELSN045, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */

   CMCHKPKLOG( cmPkHeader, &sta->hdr, mBuf, ELSN046, pst);
   pst->event = EVTLSNSTAIND;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnStaInd */
 

/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SnMngmt *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLsnStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SnMngmt *sts;             /* statistics */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;                 /* return value */
 
   TRC3(cmPkLsnStsCfm)
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN047, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU8, sts->t.sts.dura.days, mBuf, ELSN048, pst);
   CMCHKPKLOG( SPkU8, sts->t.sts.dura.hours, mBuf, ELSN049, pst);
   CMCHKPKLOG( SPkU8, sts->t.sts.dura.mins, mBuf, ELSN050, pst);
   CMCHKPKLOG( SPkU8, sts->t.sts.dura.secs, mBuf, ELSN051, pst);
   CMCHKPKLOG( SPkU8, sts->t.sts.dura.tenths, mBuf, ELSN052, pst);
   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.usrUnavailRx, mBuf, ELSN053, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.usrUnavailTx, mBuf, ELSN054, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.traTx, mBuf, ELSN055, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.traRx, mBuf, ELSN056, pst);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.trwTx, mBuf, ELSN057, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.trwRx, mBuf, ELSN058, pst);
#endif
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snGlb.msuDropRteErr, mBuf, ELSN059, pst);
         break;
      case STDLSAP:
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeOverTx, mBuf, ELSN060, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeOverRx, mBuf, ELSN061, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeOverAckTx, mBuf, ELSN062, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeOverAckRx, mBuf, ELSN063, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeBackTx, mBuf, ELSN064, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeBackRx, mBuf, ELSN065, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeBackAckTx, mBuf, ELSN066, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.changeBackAckRx, mBuf, ELSN067, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.emChangeOverTx, mBuf, ELSN068, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.emChangeOverRx, mBuf, ELSN069, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.emChangeOverAckTx, mBuf, ELSN070, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.emChangeOverAckRx, mBuf, ELSN071, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhTx, mBuf, ELSN072, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhRx, mBuf, ELSN073, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkUninhTx, mBuf, ELSN074, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkUninhRx, mBuf, ELSN075, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhAckTx, mBuf, ELSN076, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhAckRx, mBuf, ELSN077, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkUninhAckTx, mBuf, ELSN078, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkUninhAckRx, mBuf, ELSN079, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhDenTx, mBuf, ELSN080, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkInhDenRx, mBuf, ELSN081, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkForceUninhTx, mBuf, ELSN082, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkForceUninhRx, mBuf, ELSN083, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkLocInhTstTx, mBuf, ELSN084, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkLocInhTstRx, mBuf, ELSN085, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkRmtInhTstTx, mBuf, ELSN086, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkRmtInhTstRx, mBuf, ELSN087, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkConOrdTx, mBuf, ELSN088, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkConOrdRx, mBuf, ELSN089, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkConAckTx, mBuf, ELSN090, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkConAckRx, mBuf, ELSN091, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkTstTx, mBuf, ELSN092, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkTstRx, mBuf, ELSN093, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkTstAckTx, mBuf, ELSN094, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkTstAckRx, mBuf, ELSN095, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.txDrop, mBuf, ELSN096, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.txCongDrop, mBuf, ELSN097, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.sifOctTx, mBuf, ELSN098, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.sifOctRx, mBuf, ELSN099, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.sioOctTx, mBuf, ELSN100, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.sioOctRx, mBuf, ELSN101, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.msuTx, mBuf, ELSN102, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.msuRx, mBuf, ELSN103, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.cong1, mBuf, ELSN104, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.cong2, mBuf, ELSN105, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.cong3, mBuf, ELSN106, pst);
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snDLSAP.durLnkUnav, mBuf, ELSN107, pst);
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snDLSAP.durLnkCong, mBuf, ELSN108, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snDLSAP.lnkErrPduRx, mBuf, ELSN109, pst);
         break;
      case STROUT:
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snRout.dpc, mBuf, ELSN110, pst);
         CMCHKPKLOG( SPkU8, sts->t.sts.s.snRout.upSwtch, mBuf, ELSN111, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.routeTstTx, mBuf, ELSN112, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.routeTstRx, mBuf, ELSN113, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.congTstRx, mBuf, ELSN114, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.congTstTx, mBuf, ELSN115, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txProhibTx, mBuf, ELSN116, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txProhibRx, mBuf, ELSN117, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txRestrictTx, mBuf, ELSN118, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txRestrictRx, mBuf, ELSN119, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txAllowTx, mBuf, ELSN120, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txAllowRx, mBuf, ELSN121, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txCntrlTx, mBuf, ELSN122, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.txCntrlRx, mBuf, ELSN123, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.rteUnavCnt, mBuf, ELSN124, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.sifOctTx, mBuf, ELSN125, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snRout.sioOctTx, mBuf, ELSN126, pst);
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snRout.durRteUnav, mBuf, ELSN127, pst);
#if SS7_NTT
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snRout.usnRx, mBuf, ELSN128, pst);
#endif
         break;
      case STLNKSET:
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snLnkSet.strtLnkSetFail, mBuf, ELSN129, pst);
         CMCHKPKLOG( SPkS32, sts->t.sts.s.snLnkSet.stopLnkSetFail, mBuf, ELSN130, pst);
         CMCHKPKLOG( SPkU32, sts->t.sts.s.snLnkSet.durLnkSetUnav, mBuf, ELSN131, pst);
         break;
      default:
         break;
   }
   CMCHKPKLOG( SPkS16, action, mBuf, ELSN132, pst);
   CMCHKPKLOG( cmPkDateTime, &sts->t.sts.dt, mBuf, ELSN133, pst);
#if (SN_LMINT3 || SMSN_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELSN134, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKPKLOG( cmPkHeader, &sts->hdr, mBuf, ELSN135, pst);
   pst->event = EVTLSNSTSCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnStsCfm */


/*
*
*       Fun:   Pack Trace Indication
*
*       Desc:  This function is used to pack the trace indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnTrcInd
(
Pst *pst,                 /* post structure */
SnMngmt *trc              /* trace */
)
#else
PUBLIC S16 cmPkLsnTrcInd(pst, trc)
Pst *pst;                 /* post structure */   
SnMngmt *trc;             /* trace */
#endif
{
   S16 i;                 /* counter */
   Buffer *mBuf;          /* message buffer */
   S16 ret1;                 /* return value */
 
   TRC3(cmPkLsnTrcInd)
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSNLOGERROR(ERRCLS_ADD_RES, ELSN136, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU16, trc->t.trc.evnt, mBuf, ELSN137, pst);
   for (i = 0; i < 16; i++)  
   {
      CMCHKPKLOG( SPkU8, trc->t.trc.evntParm[i], mBuf, ELSN138, pst);
   }
   CMCHKPKLOG( cmPkDateTime, &trc->t.trc.dt, mBuf, ELSN139, pst);
   CMCHKPKLOG( cmPkHeader, &trc->hdr, mBuf, ELSN140, pst);
   pst->event = EVTLSNTRCIND;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnTrcInd */

/* Unpacking functions */


/*
*
*       Fun:   cmUnpkLsnCntrlReq
*
*       Desc:  Unpack Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnCntrlReq
(
LsnCntrlReq func,           /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnCntrlReq(func, pst, mBuf)
LsnCntrlReq func;           /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SnMngmt cntrl;             /* control */

   TRC3(cmUnpkLsnCntrlReq)
   CMCHKUNPKLOG( cmUnpkHeader, &cntrl.hdr, mBuf, ELSN141, pst);
   CMCHKUNPKLOG( cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ELSN142, pst);
   CMCHKUNPKLOG( SUnpkU8, &cntrl.t.cntrl.subAction, mBuf, ELSN143, pst);
   CMCHKUNPKLOG( SUnpkU8, &cntrl.t.cntrl.action, mBuf, ELSN144, pst);
   switch (cntrl.hdr.elmId.elmnt)
   {
      case STGEN:
         CMCHKUNPKLOG( SUnpkU32, &cntrl.t.cntrl.ctlType.snDbg.dbgMask, mBuf, ELSN145, pst);
         break;
     
      case STROUT:
         CMCHKUNPKLOG( SUnpkU8, &cntrl.t.cntrl.ctlType.snRouteId.upSwtch, mBuf, ELSN146, pst);
         CMCHKUNPKLOG( SUnpkU32, &cntrl.t.cntrl.ctlType.snRouteId.dpc, mBuf, ELSN147, pst);
         break;
#if (SS7_TTC || SS7_NTT)
      case STDLSAP:
      case STLNKSET:
         CMCHKUNPKLOG( SUnpkU8, &cntrl.t.cntrl.ctlType.srtReqFlg, mBuf, ELSN148, pst);
         break;
#endif

      case STGRDLSAP:
      case STGRNSAP:
         CMCHKUNPKLOG( SUnpkU16, &cntrl.t.cntrl.ctlType.groupKey.dstProcId, mBuf, ELSN149, pst);
         break;
      case STNSAP:
         break; 
      default:
         break;
   }
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, &cntrl);
   RETVALUE(ROK);
} /* end of cmUnpkLsnCntrlReq */

/*
*
*       Fun:   cmUnpkLsnStsReq
*
*       Desc:  Unpack Statistics Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnStsReq
(
LsnStsReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnStsReq(func, pst, mBuf)
LsnStsReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   Action action;           /* action */
   SnMngmt sts;               /* statistics */

   TRC3(cmUnpkLsnStsReq)
   CMCHKUNPKLOG( cmUnpkHeader, &sts.hdr, mBuf, ELSN150, pst);
   CMCHKUNPKLOG( cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELSN151, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ELSN152, pst);
   switch (sts.hdr.elmId.elmnt)
   {
      case STGEN:
      case STDLSAP:
      case STLNKSET:
         break;
      case STROUT:
         CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.s.snRout.upSwtch, mBuf, ELSN153, pst);
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snRout.dpc, mBuf, ELSN154, pst);
         break;
      default:
         break;
   }
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, action, &sts); 
   RETVALUE(ROK);
} /* end of cmUnpkLsnStsReq */

/*
*
*       Fun:   cmUnpkLsnStaReq
*
*       Desc:  Unpack Status Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnStaReq
(
LsnStaReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnStaReq(func, pst, mBuf)
LsnStaReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SnMngmt sta;               /* status */

   TRC3(cmUnpkLsnStaReq)
   CMCHKUNPKLOG( cmUnpkHeader, &sta.hdr, mBuf, ELSN155, pst);
   CMCHKUNPKLOG( cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELSN156, pst);
   switch (sta.hdr.elmId.elmnt)
   {
      case STNSAP:
      case STDLSAP:
      case STLNKSET:
      case STGEN:
      case STSID:
         break;
      case STROUT:
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.upSwtch, mBuf, ELSN157, pst);
         CMCHKUNPKLOG( SUnpkU32, &sta.t.ssta.s.snRout.dpc, mBuf, ELSN158, pst);
         break;
      default:
         break;
   }
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, &sta);
   RETVALUE(ROK);
} /* end of cmUnpkLsnStaReq */


/*
*
*       Fun:   cmUnpkLsnCfgReq
*
*       Desc:  Unpack Configuration Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnCfgReq
(
LsnCfgReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnCfgReq(func, pst, mBuf)
LsnCfgReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SnMngmt cfg;             /* configuration */
   S16 i;                   /* counter */

   TRC3(cmUnpkLsnCfgReq)
   CMCHKUNPKLOG( cmUnpkHeader, &cfg.hdr, mBuf, ELSN159, pst);
   switch (cfg.hdr.elmId.elmnt)
   {
      case STGEN:
#ifdef SR
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.srInst, mBuf, ELSN160, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.srEnt, mBuf, ELSN161, pst); 
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.srProcId, mBuf, ELSN162, pst); 
#endif
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.dstInst, mBuf, ELSN163, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.dstEnt, mBuf, ELSN164, pst); 
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.sm.dstProcId, mBuf, ELSN165, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.route, mBuf, ELSN166, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.prior, mBuf, ELSN167, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.pool, mBuf, ELSN168, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.region, mBuf, ELSN169, pst); 
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.sm.selector, mBuf, ELSN170, pst); 
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t26, mBuf, ELSN171, pst);
#endif
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t21, mBuf, ELSN172, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t19, mBuf, ELSN173, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t18, mBuf, ELSN174, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t16, mBuf, ELSN175, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snGen.tmr.t15, mBuf, ELSN176, pst);
         CMCHKUNPKLOG( SUnpkS16, &cfg.t.cfg.s.snGen.rteTimeRes, mBuf, ELSN177, pst);
         CMCHKUNPKLOG( SUnpkS16, &cfg.t.cfg.s.snGen.spTimeRes, mBuf, ELSN178, pst);
         CMCHKUNPKLOG( SUnpkS16, &cfg.t.cfg.s.snGen.cbTimeRes, mBuf, ELSN179, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snGen.nmbRteInst, mBuf, ELSN180, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.nmbLnkSets, mBuf, ELSN181, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.nmbRouts, mBuf, ELSN182, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.nmbNSap, mBuf, ELSN183, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snGen.nmbDLSap, mBuf, ELSN184, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.tfrReq, mBuf, ELSN185, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.rstReq, mBuf, ELSN186, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.ssfValid, mBuf, ELSN187, pst);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_CHINA)
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snGen.spCode2, mBuf, ELSN188, pst);
#endif
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snGen.spCode1, mBuf, ELSN189, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snGen.typeSP, mBuf, ELSN190, pst);
         break;
      case STNSAP:
#ifdef SN_SG
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snNSAP.usrParts, mBuf, ELSN191, pst);
#endif
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.route, mBuf, ELSN192, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.prior, mBuf, ELSN193, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.dpcLen, mBuf, ELSN194, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.mem.pool, mBuf, ELSN195, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.mem.region, mBuf, ELSN196, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.selector, mBuf, ELSN197, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.upSwtch, mBuf, ELSN198, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.lnkType, mBuf, ELSN199, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snNSAP.ssf, mBuf, ELSN200, pst);
         break;
      case STDLSAP:
      case STDLSAPACT:
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.flushContFlag, mBuf, ELSN201, pst);
         CMCHKUNPKLOG( SUnpkS16, &cfg.t.cfg.s.snDLSAP.spId, mBuf, ELSN202, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.dpcLen, mBuf, ELSN203, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.mem.pool, mBuf, ELSN204, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.mem.region, mBuf, ELSN205, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.selector, mBuf, ELSN206, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.route, mBuf, ELSN207, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.prior, mBuf, ELSN208, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.dstInst, mBuf, ELSN209, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.dstEnt, mBuf, ELSN210, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snDLSAP.dstProcId, mBuf, ELSN211, pst);
#ifdef SDT2
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.tBnd, mBuf, ELSN212, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.tFlc, mBuf, ELSN213, pst);
#endif /* SDT2 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.tCraft, mBuf, ELSN214, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t37, mBuf, ELSN215, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t36, mBuf, ELSN216, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t35, mBuf, ELSN217, pst);
#endif
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t34, mBuf, ELSN218, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t33, mBuf, ELSN219, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t32, mBuf, ELSN220, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t31, mBuf, ELSN221, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t24, mBuf, ELSN222, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t23, mBuf, ELSN223, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t22, mBuf, ELSN224, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t17, mBuf, ELSN225, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t14, mBuf, ELSN226, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t13, mBuf, ELSN227, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t12, mBuf, ELSN228, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t7, mBuf, ELSN229, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t5, mBuf, ELSN230, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t4, mBuf, ELSN231, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t3, mBuf, ELSN232, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t2, mBuf, ELSN233, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snDLSAP.tmr.t1, mBuf, ELSN234, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.ssf, mBuf, ELSN235, pst);
         for (i = 0; i < LSN_LNKTSTMAX; i++)
         {
            CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.tst[i], mBuf, ELSN236, pst);
         }
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.tstLen, mBuf, ELSN237, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.lnkTstSLC, mBuf, ELSN238, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snDLSAP.lnkId, mBuf, ELSN239, pst);
#ifndef SDT2
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.maxCredit, mBuf, ELSN240, pst);
#endif /* SDT2 */
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.discPrior, mBuf, ELSN241, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.p3QLen, mBuf, ELSN242, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.p2QLen, mBuf, ELSN243, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.p1QLen, mBuf, ELSN244, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.maxSLTtry, mBuf, ELSN245, pst);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.isCLink, mBuf, ELSN246, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.l2Type, mBuf, ELSN247, pst);
#endif
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.upSwtch, mBuf, ELSN248, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.lnkType, mBuf, ELSN249, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.msgPrior, mBuf, ELSN250, pst);
         CMCHKUNPKLOG( SUnpkS16, &cfg.t.cfg.s.snDLSAP.msgSize, mBuf, ELSN251, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snDLSAP.lnkPrior, mBuf, ELSN252, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.adjDpc, mBuf, ELSN253, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snDLSAP.opc, mBuf, ELSN254, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snDLSAP.lnkSetId, mBuf, ELSN255, pst);
         break;
      case STROUT:
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.rctReq, mBuf, ELSN256, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.multiMsgPrior, mBuf, ELSN257, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snRout.lsetSel, mBuf, ELSN258, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snRout.slsRange, mBuf, ELSN259, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.rstReq, mBuf, ELSN260, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.brdcastFlg, mBuf, ELSN261, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.ssf, mBuf, ELSN262, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.rteToAdjSp, mBuf, ELSN263, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t6, mBuf, ELSN264, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t8, mBuf, ELSN265, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t10, mBuf, ELSN266, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t11, mBuf, ELSN267, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t19, mBuf, ELSN268, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t21, mBuf, ELSN269, pst);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t18, mBuf, ELSN270, pst);
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.t25, mBuf, ELSN271, pst);
#endif
#if (SS7_TTC || SS7_NTT)
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.tc, mBuf, ELSN272, pst);
#endif
#ifdef SN_SG
         CMCHKUNPKLOG( cmUnpkTmrCfg, &cfg.t.cfg.s.snRout.tmr.tQry, mBuf, ELSN273, pst);
#endif
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.dir, mBuf, ELSN274, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snRout.cmbLnkSetId, mBuf, ELSN275, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.upSwtch, mBuf, ELSN276, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.swtchType, mBuf, ELSN277, pst);
         CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snRout.spType, mBuf, ELSN278, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snRout.dpc, mBuf, ELSN279, pst);
         break;
      case STLNKSET:       /* link set configuration */
         for (i = 0; i < LSN_MAXCMBLNK; i++)
         {
            CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.snLnkSet.cmbLnkSet[i].lnkSetPrior, mBuf, ELSN280, pst);
            CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snLnkSet.cmbLnkSet[i].cmbLnkSetId, mBuf, ELSN281, pst);
         }
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snLnkSet.nmbCmbLnkSet, mBuf, ELSN282, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snLnkSet.nmbActLnkReqd, mBuf, ELSN283, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.snLnkSet.adjDpc, mBuf, ELSN284, pst);
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.snLnkSet.lnkSetId, mBuf, ELSN285, pst);
         break;
      default:
         break;
   }
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, &cfg);
   RETVALUE(ROK);
} /* end of cmUnpkLsnCfgReq */
#endif
#ifdef LCSMSNMILSN

/*
*
*       Fun:   Pack Configuration Request
*
*       Desc:  This function is used to pack the configuration request
*              primitive to MTP level 3.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnCfgReq
(
Pst *pst,                   /* post structure */    
SnMngmt *cfg                /* configuration */
)
#else
PUBLIC S16 cmPkLsnCfgReq(pst, cfg)
Pst *pst;                   /* post structure */    
SnMngmt *cfg;               /* configuration */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 i;
 
   TRC3(cmPkLsnCfgReq)
   SGetMsg(pst->region, pst->pool, &mBuf);
   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         SPkU8(cfg->t.cfg.s.snGen.typeSP, mBuf);
         SPkU32(cfg->t.cfg.s.snGen.spCode1, mBuf);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96 || SS7_CHINA)
         SPkU32(cfg->t.cfg.s.snGen.spCode2, mBuf);
#endif
         SPkU8(cfg->t.cfg.s.snGen.ssfValid, mBuf);
         SPkU8(cfg->t.cfg.s.snGen.rstReq, mBuf);
         SPkU8(cfg->t.cfg.s.snGen.tfrReq, mBuf);
         SPkU16(cfg->t.cfg.s.snGen.nmbDLSap, mBuf);
         SPkU16(cfg->t.cfg.s.snGen.nmbNSap, mBuf);
         SPkU16(cfg->t.cfg.s.snGen.nmbRouts, mBuf);
         SPkU16(cfg->t.cfg.s.snGen.nmbLnkSets, mBuf);
         SPkU32(cfg->t.cfg.s.snGen.nmbRteInst, mBuf);
         SPkS16(cfg->t.cfg.s.snGen.cbTimeRes, mBuf);
         SPkS16(cfg->t.cfg.s.snGen.spTimeRes, mBuf);
         SPkS16(cfg->t.cfg.s.snGen.rteTimeRes, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t15, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t16, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t18, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t19, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t21, mBuf);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         cmPkTmrCfg(&cfg->t.cfg.s.snGen.tmr.t26, mBuf);
#endif
         SPkU8(cfg->t.cfg.s.snGen.sm.selector, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.region, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.pool, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.prior, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.route, mBuf); 
         SPkU16(cfg->t.cfg.s.snGen.sm.dstProcId, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.dstEnt, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.sm.dstInst, mBuf); 
#ifdef SR /* Simple Router */
         SPkU16(cfg->t.cfg.s.snGen.srProcId, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.srEnt, mBuf); 
         SPkU8(cfg->t.cfg.s.snGen.srInst, mBuf); 
#endif
         break;
      case STNSAP:
         SPkU8(cfg->t.cfg.s.snNSAP.ssf, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.lnkType, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.upSwtch, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.selector, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.mem.region, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.mem.pool, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.dpcLen, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.prior, mBuf);
         SPkU8(cfg->t.cfg.s.snNSAP.route, mBuf);
#ifdef SN_SG
         SPkU32(cfg->t.cfg.s.snNSAP.usrParts, mBuf);
#endif
         break;
      case STDLSAP:
      case STDLSAPACT: /* fall thru */
         SPkU16(cfg->t.cfg.s.snDLSAP.lnkSetId, mBuf);
         SPkU32(cfg->t.cfg.s.snDLSAP.opc, mBuf);
         SPkU32(cfg->t.cfg.s.snDLSAP.adjDpc, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.lnkPrior, mBuf);
         SPkS16(cfg->t.cfg.s.snDLSAP.msgSize, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.msgPrior, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.lnkType, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.upSwtch, mBuf);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         SPkU8(cfg->t.cfg.s.snDLSAP.l2Type, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.isCLink, mBuf);
#endif
         SPkU8(cfg->t.cfg.s.snDLSAP.maxSLTtry, mBuf);
         SPkU32(cfg->t.cfg.s.snDLSAP.p1QLen, mBuf);
         SPkU32(cfg->t.cfg.s.snDLSAP.p2QLen, mBuf);
         SPkU32(cfg->t.cfg.s.snDLSAP.p3QLen, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.discPrior, mBuf);
#ifndef SDT2
         SPkU32(cfg->t.cfg.s.snDLSAP.maxCredit, mBuf);
#endif /* SDT2 */
         SPkU16(cfg->t.cfg.s.snDLSAP.lnkId, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.lnkTstSLC, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.tstLen, mBuf);
         for (i = (LSN_LNKTSTMAX-1); i >= 0; i--)
            SPkU8(cfg->t.cfg.s.snDLSAP.tst[i], mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.ssf, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t1, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t2, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t3, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t4, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t5, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t7, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t12, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t13, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t14, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t17, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t22, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t23, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t24, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t31, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t32, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t33, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t34, mBuf);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t35, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t36, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.t37, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.tCraft, mBuf);
#endif
#ifdef SDT2
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.tFlc, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snDLSAP.tmr.tBnd, mBuf);
#endif /* SDT2 */
         SPkU16(cfg->t.cfg.s.snDLSAP.dstProcId, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.dstEnt, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.dstInst, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.prior, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.route, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.selector, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.mem.region, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.mem.pool, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.dpcLen, mBuf);
         SPkS16(cfg->t.cfg.s.snDLSAP.spId, mBuf);
         SPkU8(cfg->t.cfg.s.snDLSAP.flushContFlag, mBuf);
         break;
      case STROUT:
         SPkU32(cfg->t.cfg.s.snRout.dpc, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.spType, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.swtchType, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.upSwtch, mBuf);
         SPkU16(cfg->t.cfg.s.snRout.cmbLnkSetId, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.dir, mBuf);
#ifdef SN_SG
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.tQry, mBuf);
#endif
#if (SS7_TTC || SS7_NTT)
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.tc, mBuf);
#endif
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t25, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t18, mBuf);
#endif
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t21, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t19, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t11, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t10, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t8, mBuf);
         cmPkTmrCfg(&cfg->t.cfg.s.snRout.tmr.t6, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.rteToAdjSp, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.ssf, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.brdcastFlg, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.rstReq, mBuf);
         SPkU16(cfg->t.cfg.s.snRout.slsRange, mBuf);
         SPkU32(cfg->t.cfg.s.snRout.lsetSel, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.multiMsgPrior, mBuf);
         SPkU8(cfg->t.cfg.s.snRout.rctReq, mBuf);
         break;
      case STLNKSET:       /* link set configuration */
         SPkU16(cfg->t.cfg.s.snLnkSet.lnkSetId, mBuf);
         SPkU32(cfg->t.cfg.s.snLnkSet.adjDpc, mBuf);
         SPkU16(cfg->t.cfg.s.snLnkSet.nmbActLnkReqd, mBuf);
         SPkU16(cfg->t.cfg.s.snLnkSet.nmbCmbLnkSet, mBuf);
         for (i = (LSN_MAXCMBLNK-1); i >= 0; i--)
         {
            SPkU16(cfg->t.cfg.s.snLnkSet.cmbLnkSet[i].cmbLnkSetId, mBuf);
            SPkU8(cfg->t.cfg.s.snLnkSet.cmbLnkSet[i].lnkSetPrior, mBuf);
         }
         break;
      default:
         break;
   }
   cmPkHeader(&cfg->hdr, mBuf);
   pst->event = (Event)EVTLSNCFGREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnCfgReq */
 

/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request
*              primitive to MTP level 3.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnCntrlReq
(
Pst *pst,                   /* post structure */
SnMngmt *cntrl              /* control */
)
#else
PUBLIC S16 cmPkLsnCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
SnMngmt *cntrl;             /* control */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLsnCntrlReq)
   SGetMsg(pst->region, pst->pool, &mBuf);
   switch (cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
         SPkU32(cntrl->t.cntrl.ctlType.snDbg.dbgMask, mBuf);
         break;
     
      case STROUT:
         SPkU32(cntrl->t.cntrl.ctlType.snRouteId.dpc, mBuf);
         SPkU8(cntrl->t.cntrl.ctlType.snRouteId.upSwtch, mBuf);
         break;
#if (SS7_TTC || SS7_NTT)
      case STLNKSET:
      case STDLSAP:
         SPkU8(cntrl->t.cntrl.ctlType.srtReqFlg, mBuf);
         break;
#endif

      case STGRDLSAP:
      case STGRNSAP:
         SPkU16(cntrl->t.cntrl.ctlType.groupKey.dstProcId, mBuf);
         break;
      case STNSAP:
         break; 
      default:
         break;
   }
   SPkU8(cntrl->t.cntrl.action, mBuf);
   SPkU8(cntrl->t.cntrl.subAction, mBuf);
   cmPkDateTime(&cntrl->t.cntrl.dt, mBuf);
   cmPkHeader(&cntrl->hdr, mBuf);
   pst->event = (Event)EVTLSNCNTRLREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}

/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to MTP level 3.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnStaReq
(
Pst *pst,                   /* post structure */    
SnMngmt *sta                /* solicited status */
)
#else
PUBLIC S16 cmPkLsnStaReq(pst, sta)
Pst *pst;                   /* post structure */    
SnMngmt *sta;               /* solicited status */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLsnStaReq)
   SGetMsg(pst->region, pst->pool, &mBuf);
   switch (sta->hdr.elmId.elmnt)
   {
      /* it's not necessary to pack in StaReq except STROUT */
      case STNSAP:
      case STDLSAP:
      case STLNKSET:
      case STGEN:
      case STSID:
         break;
      case STROUT:
         SPkU32(sta->t.ssta.s.snRout.dpc, mBuf);
         SPkU8(sta->t.ssta.s.snRout.upSwtch, mBuf);
         break;
      default:
         break;
   }
   cmPkDateTime(&sta->t.ssta.dt, mBuf);
   cmPkHeader(&sta->hdr, mBuf);
   pst->event = (Event)EVTLSNSTAREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnStaReq(sta) */


/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to MTP level 3.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLsnStsReq
(
Pst *pst,                   /* post structure */    
Action action,              /* action */
SnMngmt *sts                /* statistics */
)
#else
PUBLIC S16 cmPkLsnStsReq(pst, action, sts)
Pst *pst;                   /* post structure */    
Action action;              /* action */
SnMngmt *sts;               /* statistics */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLsnStsReq)
   SGetMsg(pst->region, pst->pool, &mBuf);
   switch (sts->hdr.elmId.elmnt)
   {
      /* it's not necessary to pack in StsReq except STROUT */
      case STGEN:
      case STDLSAP:
      case STLNKSET:
         break;
      case STROUT:
         SPkU32(sts->t.sts.s.snRout.dpc, mBuf);
         SPkU8(sts->t.sts.s.snRout.upSwtch, mBuf);
         break;
      default:
         break;
   }
   SPkS16(action, mBuf);
   cmPkDateTime(&sts->t.sts.dt, mBuf);
   cmPkHeader(&sts->hdr, mBuf);
   pst->event = (Event)EVTLSNSTSREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLsnStsReq(sts) */
 
  
/*
*
*       Fun:   Unpack Status confirm
*
*       Desc:  This function is used to unpack the status request
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnStaCfm
(
LsnStaCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnStaCfm(func, pst, mBuf)
LsnStaCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SnMngmt sta;
   Txt ptNmb[32];         /* part number */

   TRC3(cmUnpkLsnStaCfm)

   CMCHKUNPKLOG( cmUnpkHeader, &sta.hdr, mBuf, ELSN286, pst); 
#if (SN_LMINT3 || SMSN_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ELSN287, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKUNPKLOG( cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELSN288, pst);
   switch (sta.hdr.elmId.elmnt)
   {
      case STNSAP:
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snSAP.sapState, mBuf, ELSN289, pst);
         break;
      case STDLSAP:
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.emerg, mBuf, ELSN290, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.uninhbt, mBuf, ELSN291, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.rmtInhbt, mBuf, ELSN292, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.locInhbt, mBuf, ELSN293, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.inhbt, mBuf, ELSN294, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.remBlkd, mBuf, ELSN295, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.locBlkd, mBuf, ELSN296, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.blkd, mBuf, ELSN297, pst);
         CMCHKUNPKLOG( SUnpkU32, &sta.t.ssta.s.snDLSAP.rTQSize, mBuf, ELSN298, pst);
         CMCHKUNPKLOG( SUnpkU32, &sta.t.ssta.s.snDLSAP.tQSize, mBuf, ELSN299, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.congPrior, mBuf, ELSN300, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.flcSt, mBuf, ELSN301, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.bndState, mBuf, ELSN302, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snDLSAP.state, mBuf, ELSN303, pst);
         break;
      case STLNKSET:
#if SS7_NTT
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snLnkSet.NTTState, mBuf, ELSN304, pst);
#endif
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snLnkSet.tfrFlg, mBuf, ELSN305, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snLnkSet.tfpFlg, mBuf, ELSN306, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snLnkSet.state, mBuf, ELSN307, pst);
         CMCHKUNPKLOG( SUnpkU16, &sta.t.ssta.s.snLnkSet.nmbActLnks, mBuf, ELSN308, pst);
         break;
      case STROUT:
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.restrict, mBuf, ELSN309, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.rstFlg, mBuf, ELSN310, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.congLvl, mBuf, ELSN311, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.state, mBuf, ELSN312, pst);
         CMCHKUNPKLOG( SUnpkU16, &sta.t.ssta.s.snRout.nmbActvLnkSets, mBuf, ELSN313, pst);
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snRout.upSwtch, mBuf, ELSN314, pst);
         CMCHKUNPKLOG( SUnpkU32, &sta.t.ssta.s.snRout.dpc, mBuf, ELSN315, pst);
         break;
      case STGEN:
         CMCHKUNPKLOG( SUnpkU8, &sta.t.ssta.s.snSP.spRst, mBuf, ELSN316, pst);
         break;
      case STSID:         /* system id */
         /* unpack system id structure */
         sta.t.ssta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId, mBuf, ELSN317, pst);
         break;
      default:
         break;
   }
   SPutMsg(mBuf);
   (*func)(pst, &sta);
   RETVALUE(ROK);
} /* end of cmUnpkLsnStaCfm */

  
/*
*
*       Fun:   Unpack Statistics Confirm
*
*       Desc:  This function is used to unpack the statistics confirm
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnStsCfm
(
LsnStsCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnStsCfm(func, pst, mBuf)
LsnStsCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   Action action;
   SnMngmt sts;
   TRC3(cmUnpkLsnStsCfm)
   CMCHKUNPKLOG( cmUnpkHeader, &sts.hdr, mBuf, ELSN318, pst);
#if (SN_LMINT3 || SMSN_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm, mBuf, ELSN319, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKUNPKLOG( cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELSN320, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ELSN321, pst);
   switch (sts.hdr.elmId.elmnt)
   {
      case STGEN:
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.msuDropRteErr, mBuf, ELSN322, pst);
#if (SS7_ANS92 || SS7_ANS88 || SS7_ANS96)
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.trwRx, mBuf, ELSN323, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.trwTx, mBuf, ELSN324, pst);
#endif
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.traRx, mBuf, ELSN325, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.traTx, mBuf, ELSN326, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.usrUnavailTx, mBuf, ELSN327, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snGlb.usrUnavailRx, mBuf, ELSN328, pst);
         break;
      case STDLSAP:
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkErrPduRx, mBuf, ELSN329, pst);
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snDLSAP.durLnkCong, mBuf, ELSN330, pst);
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snDLSAP.durLnkUnav, mBuf, ELSN331, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.cong3, mBuf, ELSN332, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.cong2, mBuf, ELSN333, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.cong1, mBuf, ELSN334, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.msuRx, mBuf, ELSN335, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.msuTx, mBuf, ELSN336, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.sioOctRx, mBuf, ELSN337, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.sioOctTx, mBuf, ELSN338, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.sifOctRx, mBuf, ELSN339, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.sifOctTx, mBuf, ELSN340, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.txCongDrop, mBuf, ELSN341, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.txDrop, mBuf, ELSN342, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkTstAckRx, mBuf, ELSN343, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkTstAckTx, mBuf, ELSN344, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkTstRx, mBuf, ELSN345, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkTstTx, mBuf, ELSN346, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkConAckRx, mBuf, ELSN347, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkConAckTx, mBuf, ELSN348, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkConOrdRx, mBuf, ELSN349, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkConOrdTx, mBuf, ELSN350, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkRmtInhTstRx, mBuf, ELSN351, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkRmtInhTstTx, mBuf, ELSN352, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkLocInhTstRx, mBuf, ELSN353, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkLocInhTstTx, mBuf, ELSN354, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkForceUninhRx, mBuf, ELSN355, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkForceUninhTx, mBuf, ELSN356, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhDenRx, mBuf, ELSN357, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhDenTx, mBuf, ELSN358, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkUninhAckRx, mBuf, ELSN359, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkUninhAckTx, mBuf, ELSN360, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhAckRx, mBuf, ELSN361, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhAckTx, mBuf, ELSN362, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkUninhRx, mBuf, ELSN363, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkUninhTx, mBuf, ELSN364, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhRx, mBuf, ELSN365, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.lnkInhTx, mBuf, ELSN366, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.emChangeOverAckRx, mBuf, ELSN367, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.emChangeOverAckTx, mBuf, ELSN368, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.emChangeOverRx, mBuf, ELSN369, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.emChangeOverTx, mBuf, ELSN370, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeBackAckRx, mBuf, ELSN371, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeBackAckTx, mBuf, ELSN372, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeBackRx, mBuf, ELSN373, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeBackTx, mBuf, ELSN374, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeOverAckRx, mBuf, ELSN375, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeOverAckTx, mBuf, ELSN376, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeOverRx, mBuf, ELSN377, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snDLSAP.changeOverTx, mBuf, ELSN378, pst);
         break;
      case STROUT:
#if SS7_NTT
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.usnRx, mBuf, ELSN379, pst);
#endif 
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snRout.durRteUnav, mBuf, ELSN380, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.sioOctTx, mBuf, ELSN381, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.sifOctTx, mBuf, ELSN382, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.rteUnavCnt, mBuf, ELSN383, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txCntrlRx, mBuf, ELSN384, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txCntrlTx, mBuf, ELSN385, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txAllowRx, mBuf, ELSN386, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txAllowTx, mBuf, ELSN387, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txRestrictRx, mBuf, ELSN388, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txRestrictTx, mBuf, ELSN389, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txProhibRx, mBuf, ELSN390, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.txProhibTx, mBuf, ELSN391, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.congTstTx, mBuf, ELSN392, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.congTstRx, mBuf, ELSN393, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.routeTstRx, mBuf, ELSN394, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snRout.routeTstTx, mBuf, ELSN395, pst);
         CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.s.snRout.upSwtch, mBuf, ELSN396, pst);
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snRout.dpc, mBuf, ELSN397, pst);
         break;
      case STLNKSET:
         CMCHKUNPKLOG( SUnpkU32, &sts.t.sts.s.snLnkSet.durLnkSetUnav, mBuf, ELSN398, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snLnkSet.stopLnkSetFail, mBuf, ELSN399, pst);
         CMCHKUNPKLOG( SUnpkS32, &sts.t.sts.s.snLnkSet.strtLnkSetFail, mBuf, ELSN400, pst);
         break;
      default:
         break;
   }
   CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.dura.tenths, mBuf, ELSN401, pst);
   CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.dura.secs, mBuf, ELSN402, pst);
   CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.dura.mins, mBuf, ELSN403, pst);
   CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.dura.hours, mBuf, ELSN404, pst);
   CMCHKUNPKLOG( SUnpkU8, &sts.t.sts.dura.days, mBuf, ELSN405, pst);
   SPutMsg(mBuf);
   (*func)(pst, action, &sts); 
   RETVALUE(ROK);
} /* end of cmUnpkLsnStsCfm */

  
/*
*
*       Fun:   Unpack Status Indication
*
*       Desc:  This function is used to unpack the unsolicited status 
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnStaInd
(
LsnStaInd func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnStaInd(func, pst, mBuf)
LsnStaInd func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SnMngmt sta;
   S16 i;

   TRC3(cmUnpkLsnStaInd)
   CMCHKUNPKLOG( cmUnpkHeader, &sta.hdr, mBuf, ELSN406, pst);

#if (SN_LMINT3 || SMSN_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmAlarm, &sta.t.usta.alarm, mBuf, ELSN407, pst);
   for (i = 7; i >= 0; i--)  
   {
      CMCHKUNPKLOG( SUnpkU8, &sta.t.usta.evntParm[i], mBuf, ELSN408, pst);
   }
#else /* SN_LMINT3 || SMSN_LMINT3 */
   CMCHKUNPKLOG( cmUnpkDateTime, &sta.t.usta.dt, mBuf, ELSN409, pst);
   for (i = 7; i >= 0; i--)  
   {
      CMCHKUNPKLOG( SUnpkU8, &sta.t.usta.evntParm[i], mBuf, ELSN410, pst);
   }
   CMCHKUNPKLOG( SUnpkU16, &sta.t.usta.evnt, mBuf, ELSN411, pst);
#endif /* SN_LMINT3 || SMSN_LMINT3 */

   SPutMsg(mBuf);
   (*func)(pst, &sta); 
   RETVALUE(ROK);
} /* end of cmUnpkLsnStaInd */

  
/*
*
*       Fun:   Unpack Trace Indication
*
*       Desc:  This function is used to unpack the trace indication
*              primitive to layer management.
*
*       Ret:   RETVOID
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnTrcInd
(
LsnTrcInd func,           /* primitive pointer */
Pst *pst,                 /* post structure */
Buffer *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnTrcInd(func, pst, mBuf)
LsnTrcInd func;           /* primitive pointer */
Pst *pst;                 /* post structure */
Buffer *mBuf;             /* message buffer */
#endif
{
   SnMngmt trc;
   S16 i;

   TRC3(cmUnpkLsnTrcInd)

   CMCHKUNPKLOG( cmUnpkHeader, &trc.hdr, mBuf, ELSN412, pst);
   CMCHKUNPKLOG( cmUnpkDateTime, &trc.t.trc.dt, mBuf, ELSN413, pst);
   for (i = 15; i >= 0; i--)  
   {
      CMCHKUNPKLOG( SUnpkU8, &trc.t.trc.evntParm[i], mBuf, ELSN414, pst);
   }
   CMCHKUNPKLOG( SUnpkU16, &trc.t.trc.evnt, mBuf, ELSN415, pst);
   SPutMsg(mBuf);
   (*func)(pst, &trc); 
   RETVALUE(ROK);;
} /* end of cmUnpkLsnTrcInd */

#if (SN_LMINT3 || SMSN_LMINT3)


/*
*
*       Fun:   Unpack config confirmation
*
*       Desc:  This function is used to unpack the  config confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnCfgCfm
(
LsnCfgCfm func, /* primitive pointer */
Pst *pst,
Buffer *mBuf   /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnCfgCfm(func, pst, mBuf)
LsnCfgCfm func; /* primitive pointer */
Pst *pst;
Buffer *mBuf;  /* message buffer */
#endif
{
   SnMngmt cfm;

   TRC3(cmUnpkLsnCfgCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELSN416, pst);

   /* unpack status structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSN417, pst);

   SPutMsg(mBuf);

   (*func)(pst, &cfm); 

   RETVALUE(ROK);
} /* end of cmUnpkLsnCfgCfm */


/*
*
*       Fun:   Unpack control confirmation
*
*       Desc:  This function is used to unpack the  control confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsn.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLsnCntrlCfm
(
LsnCntrlCfm func, /* primitive pointer */
Pst *pst,
Buffer *mBuf   /* message buffer */
)
#else
PUBLIC S16 cmUnpkLsnCntrlCfm(func, pst, mBuf)
LsnCntrlCfm func; /* primitive pointer */
Pst *pst;
Buffer *mBuf;  /* message buffer */
#endif
{
   SnMngmt cfm;

   TRC3(cmUnpkLsnCntrlCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELSN418, pst);

   /* unpack status structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSN419, pst);

   SPutMsg(mBuf);

   (*func)(pst, &cfm); 

   RETVALUE(ROK);
} /* end of cmUnpkLsnCntrlCfm */
#endif /* SN_LMINT3 || SMSN_LMINT3 */
#endif 
#endif /* LCLSN */
  
/********************************************************************30**
  
         End of file:     lsn.c@@/main/5 - Mon Apr  9 13:48:15 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      sr   1. initial release.
1.2          ---      sr   2. Modifications in gencfg pack/unpack for TTC
1.3          ---      sr   3. pack/unpack functions for control request 
                              modified to include SRT required flag.
/main/4      ---      sr   1. Packing/unpacking funcs. of CfgReq modified
                              to take care of new parameter in route 
                              config which supports static load sharing.
             ---      sr   1. Add pack/unpack for t6 in route cfg
             ---      vk   1. Add pack/unpack for isCLink in snDLSapCfg.
             ---      sr   1. Modified copyright header and error
                              codes
/main/5      ---      nb   1. Signalling Gateway new fields
                           2. move txCntrl frm dlsap to route
*********************************************************************91*/

