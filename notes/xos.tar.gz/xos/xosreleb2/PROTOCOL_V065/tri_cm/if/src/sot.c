/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     Common SOT Interface Packing/Unpacking functions

     Type:     C source file

     Desc:     Functions shared by SIP and SIP-User

     File:     sot.c

     Sid:      sot.c@@/main/10 - Tue Apr 20 00:23:22 2004

     Prg:      wvdl

*********************************************************************21*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000156     SIP     
*
*/

/* header/extern include files (.h) */ 
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_tpt.h"        /* transport related structures */
#include "cm_hash.h"
#include "cm_abnf.h"       /* common abnf library */
#include "cm_tkns.h"
#include "cm_sdp.h"
#include "cm_dns.h"        /* common DNS */
#include "cm5.h"
#include "sot.h"           /* SIP layer */

/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"
#include "cm_llist.x"
#include "cm_xtree.x"
#include "cm_tkns.x"
#include "cm_tpt.x"        /* transport related structures */
#include "cm_mblk.x"
#include "cm_sdp.x"
#include "cm_abnf.x"       /* common abnf library */
#include "cm_dns.x"        /* common DNS */
#include "cm_lib.x"
#include "cm5.x"
#include "sot.x"           /* SIP layer */

/* The packing functions for tknstringosxl takes val, mBuf, ptr and there is no
 * easy way for me to swop the arguments for all the tknstrosxl's using the p/u
 * tool and thats why this macro is redefined here */
#ifdef CMCHKUNPKPTR
#undef CMCHKUNPKPTR
#endif
#define CMCHKUNPKPTR(func, val, ptr, mBuf) \
   { \
      S16 ret; \
      if ((ret = func(val, mBuf, ptr)) != ROK) \
         RETVALUE(ret); \
   }

#ifdef CP_UA_IF_TYPE_SS
extern U32 g_sipUaModId;
extern void XosToFrameCallBack(U32 mid, Pst *pPst, void * pvBuf);
#endif /* CP_UA_IF_TYPE_SS */

#if(defined(LCSOT) || defined(LWLCSOT))

/*
*
*    Fun:    cmPkSoIpv4Address
*
*    Desc:    pack the structure SoIpv4Address
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoIpv4Address
(
SoIpv4Address *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoIpv4Address(param ,mBuf)
SoIpv4Address *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoIpv4Address)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU8, &param->adr4,mBuf);
       CMCHKPK(cmPkTknU8, &param->adr3,mBuf);
       CMCHKPK(cmPkTknU8, &param->adr2,mBuf);
       CMCHKPK(cmPkTknU8, &param->adr1,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoIpv4Address*/

/*
*
*    Fun:    cmPkSoTransportParam
*
*    Desc:    pack the structure SoTransportParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTransportParam
(
SoTransportParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTransportParam(param ,mBuf)
SoTransportParam *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTransportParam)

    CMCHKPK(cmPkTknStrOSXL, &param->otherTransport,mBuf);
    CMCHKPK(cmPkTknU8, &param->transportParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTransportParam*/

/*
*
*    Fun:    cmPkSoUserParam
*
*    Desc:    pack the structure SoUserParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUserParam
(
SoUserParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUserParam(param ,mBuf)
SoUserParam *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUserParam)

    CMCHKPK(cmPkTknStrOSXL, &param->otherUser,mBuf);
    CMCHKPK(cmPkTknU8, &param->userParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUserParam*/

/*
*
*    Fun:    cmPkSoExtVal
*
*    Desc:    pack the structure SoExtVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoExtVal
(
SoExtVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoExtVal(param ,mBuf)
SoExtVal *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoExtVal)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_EXTVAL_NONSTD :
             CMCHKPK(cmPkTknStrOSXL, &param->t.ext,mBuf);
             break;
          case  SO_EXTVAL_STD :
             CMCHKPK(cmPkTknU8, &param->t.std,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoExtVal*/

/*
*
*    Fun:    cmPkSoNameVal
*
*    Desc:    pack the structure SoNameVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNameVal
(
SoNameVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNameVal(param ,mBuf)
SoNameVal *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoNameVal)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->value,mBuf);
       CMCHKPK(cmPkTknStrOSXL, &param->name,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNameVal*/

/*
*
*    Fun:    cmPkSoHost
*
*    Desc:    pack the structure SoHost
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHost
(
SoHost *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHost(param ,mBuf)
SoHost *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoHost)

    if( param->hostType.pres != NOTPRSNT )
    {
       switch( param->hostType.val )
       {
          case  SO_HOST_HOSTNAME :
             CMCHKPK(cmPkTknStrOSXL, &param->t.hostName,mBuf);
             break;
          case  SO_HOST_IPV4ADDRESS :
             CMCHKPK(cmPkSoIpv4Address, &param->t.ipv4Address,mBuf);
             break;
          case  SO_HOST_IPV6REFERENCE :
             CMCHKPK(cmPkTknStrOSXL, &param->t.ipv6Reference,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->hostType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHost*/

/*
*
*    Fun:    cmPkSoSipDate
*
*    Desc:    pack the structure SoSipDate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSipDate
(
SoSipDate *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSipDate(param ,mBuf)
SoSipDate *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSipDate)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->sec,mBuf);
       CMCHKPK(cmPkTknU16, &param->mn,mBuf);
       CMCHKPK(cmPkTknU16, &param->hr,mBuf);
       CMCHKPK(cmPkTknU16, &param->year,mBuf);
       CMCHKPK(cmPkTknU8, &param->month,mBuf);
       CMCHKPK(cmPkTknU16, &param->day,mBuf);
       CMCHKPK(cmPkTknU8, &param->wkDay,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSipDate*/

/*
*
*    Fun:    cmPkSoUrlParameter
*
*    Desc:    pack the structure SoUrlParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUrlParameter
(
SoUrlParameter *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUrlParameter(param ,mBuf)
SoUrlParameter *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoUrlParameter)

    if( param->urlParameterType.pres != NOTPRSNT )
    {
       switch( param->urlParameterType.val )
       {
          case  SO_URLPARAMETER_COMP :
             ret1 = cmPkSoStrValue(&param->t.comp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_ISUB :
#ifdef SO_ENUM
             CMCHKPK(cmPkTknStrOSXL, &param->t.isub,mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_LRPARAM :
             break;
          case  SO_URLPARAMETER_MADDRHOST :
             ret1 = cmPkSoHost(&param->t.maddrHost,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_METHOD :
             ret1 = cmPkSoExtVal(&param->t.method,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_OTHERPARAM :
             ret1 = cmPkSoNameVal(&param->t.otherParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_PHONECONTEXT :
#ifdef SO_ENUM
             CMCHKPK(cmPkTknStrOSXL, &param->t.phoneContext,mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_POSTD :
#ifdef SO_ENUM
             CMCHKPK(cmPkTknStrOSXL, &param->t.postd,mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_TRANSPORTPARAM :
             ret1 = cmPkSoTransportParam(&param->t.transportParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_TSPDOMAIN :
#ifdef SO_PINT
             ret1 = cmPkSoHost(&param->t.tspDomain,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_PINT  */
             break;
          case  SO_URLPARAMETER_TTLPARAM :
             CMCHKPK(cmPkTknU16, &param->t.ttlParam,mBuf);
             break;
          case  SO_URLPARAMETER_USERPARAM :
             ret1 = cmPkSoUserParam(&param->t.userParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->urlParameterType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUrlParameter*/

/*
*
*    Fun:    cmPkSoHeaderExt
*
*    Desc:    pack the structure SoHeaderExt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHeaderExt
(
SoHeaderExt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHeaderExt(param ,mBuf)
SoHeaderExt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoHeaderExt)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoNameVal( (param->header[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHeaderExt*/

/*
*
*    Fun:    cmPkSoQValue
*
*    Desc:    pack the structure SoQValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoQValue
(
SoQValue *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoQValue(param ,mBuf)
SoQValue *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoQValue)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU16, &param->qVFrac,mBuf);
       CMCHKPK(cmPkTknU16, &param->qVInt,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoQValue*/

/*
*
*    Fun:    cmPkSoStrValue
*
*    Desc:    pack the structure SoStrValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoStrValue
(
SoStrValue *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoStrValue(param ,mBuf)
SoStrValue *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoStrValue)

    if( param->valueType.pres != NOTPRSNT )
    {
       CMCHKPK(cmPkTknStrOSXL, &param->value,mBuf);
    }
    CMCHKPK(cmPkTknU8, &param->valueType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoStrValue*/

/*
*
*    Fun:    cmPkSoUserInfo
*
*    Desc:    pack the structure SoUserInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUserInfo
(
SoUserInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUserInfo(param ,mBuf)
SoUserInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoUserInfo)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->password,mBuf);
       ret1 = cmPkSoStrValue(&param->userType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUserInfo*/

/*
*
*    Fun:    cmPkSoHeaders
*
*    Desc:    pack the structure SoHeaders
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHeaders
(
SoHeaders *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHeaders(param ,mBuf)
SoHeaders *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoHeaders)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoHeaderExt(&param->headerExt,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoNameVal(&param->header,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHeaders*/

/*
*
*    Fun:    cmPkSoTknStrOSXLLst
*
*    Desc:    pack the structure SoTknStrOSXLLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTknStrOSXLLst
(
SoTknStrOSXLLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTknStrOSXLLst(param ,mBuf)
SoTknStrOSXLLst *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoTknStrOSXLLst)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkTknStrOSXL,  (param->stringList[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTknStrOSXLLst*/

/*
*
*    Fun:    cmPkSoHostPort
*
*    Desc:    pack the structure SoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHostPort
(
SoHostPort *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHostPort(param ,mBuf)
SoHostPort *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoHostPort)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->port,mBuf);
       ret1 = cmPkSoHost(&param->host,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHostPort*/

/*
*
*    Fun:    cmPkSoUrlParameters
*
*    Desc:    pack the structure SoUrlParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUrlParameters
(
SoUrlParameters *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUrlParameters(param ,mBuf)
SoUrlParameters *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoUrlParameters)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoUrlParameter( (param->urlParameter[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUrlParameters*/

/*
*
*    Fun:    cmPkSoParameter
*
*    Desc:    pack the structure SoParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoParameter
(
SoParameter *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoParameter(param ,mBuf)
SoParameter *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoParameter)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoStrValue(&param->paramVal,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->token,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoParameter*/

/*
*
*    Fun:    cmPkSoDateTime
*
*    Desc:    pack the structure SoDateTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDateTime
(
SoDateTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDateTime(param ,mBuf)
SoDateTime *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoDateTime)

    if( param->dateTimeType.pres != NOTPRSNT )
    {
       switch( param->dateTimeType.val )
       {
          case  SO_DATETIME_DELTASECONDS :
             CMCHKPK(cmPkTknU32, &param->t.deltaSeconds,mBuf);
             break;
          case  SO_DATETIME_SIPDATE :
             CMCHKPK(cmPkSoSipDate, &param->t.sipDate,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->dateTimeType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDateTime*/

/*
*
*    Fun:    cmPkSoTypeSub
*
*    Desc:    pack the structure SoTypeSub
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTypeSub
(
SoTypeSub *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTypeSub(param ,mBuf)
SoTypeSub *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTypeSub)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->subType,mBuf);
       CMCHKPK(cmPkTknStrOSXL, &param->type,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTypeSub*/

/*
*
*    Fun:    cmPkSoMediaRangeVal
*
*    Desc:    pack the structure SoMediaRangeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMediaRangeVal
(
SoMediaRangeVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMediaRangeVal(param ,mBuf)
SoMediaRangeVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoMediaRangeVal)

    if( param->mediaRangeValType.pres != NOTPRSNT )
    {
       switch( param->mediaRangeValType.val )
       {
          case  SO_MEDIARANGEVAL_ALLSTAR :
             break;
          case  SO_MEDIARANGEVAL_TYPESTAR :
             CMCHKPK(cmPkTknStrOSXL, &param->t.typeStar,mBuf);
             break;
          case  SO_MEDIARANGEVAL_TYPESUB :
             ret1 = cmPkSoTypeSub(&param->t.typeSub,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->mediaRangeValType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMediaRangeVal*/


/*
*
*    Fun:    cmPkSoContactParamStd
*
*    Desc:    pack the structure SoContactParamStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContactParamStd
(
SoContactParamStd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContactParamStd(param ,mBuf)
SoContactParamStd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoContactParamStd)

    if( param->contactParamStdType.pres != NOTPRSNT )
    {
       switch( param->contactParamStdType.val )
       {
          case  SO_CONTACTPARAMSTD_ACTION :
             CMCHKPK(cmPkTknU8, &param->t.action,mBuf);
             break;
          case  SO_CONTACTPARAMSTD_EXPIRES :
             CMCHKPK(cmPkTknU32, &param->t.contactParExpires,mBuf);
             break;
          case  SO_CONTACTPARAMSTD_Q :
             CMCHKPK(cmPkSoQValue, &param->t.qValue,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->contactParamStdType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContactParamStd*/

/*
*
*    Fun:    cmPkSoCallInfoPurpose
*
*    Desc:    pack the structure SoCallInfoPurpose
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCallInfoPurpose
(
SoCallInfoPurpose *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCallInfoPurpose(param ,mBuf)
SoCallInfoPurpose *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoCallInfoPurpose)

    CMCHKPK(cmPkTknStrOSXL, &param->purposeExt,mBuf);
    CMCHKPK(cmPkTknU8, &param->callInfoPurposeType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCallInfoPurpose*/

/*
*
*    Fun:    cmPkSoSubscExpReason
*
*    Desc:    pack the structure SoSubscExpReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSubscExpReason
(
SoSubscExpReason *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSubscExpReason(param ,mBuf)
SoSubscExpReason *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSubscExpReason)

    CMCHKPK(cmPkTknStrOSXL, &param->subscExpReasonExt,mBuf);
    CMCHKPK(cmPkTknU8, &param->subscExpReasonType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSubscExpReason*/

/*
*
*    Fun:    cmPkSoDisplayName
*
*    Desc:    pack the structure SoDisplayName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDisplayName
(
SoDisplayName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDisplayName(param ,mBuf)
SoDisplayName *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoDisplayName)

    if( param->displayNameType.pres != NOTPRSNT )
    {
       switch( param->displayNameType.val )
       {
          case  SO_PARAMVAL_QUOTEDSTR :
             CMCHKPK(cmPkTknStrOSXL, &param->t.quotedStr,mBuf);
             break;
          case  SO_PARAMVAL_TOKEN :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.displayNameRep,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->displayNameType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDisplayName*/

/*
*
*    Fun:    cmPkSoAbsoluteUri
*
*    Desc:    pack the structure SoAbsoluteUri
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAbsoluteUri
(
SoAbsoluteUri *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAbsoluteUri(param ,mBuf)
SoAbsoluteUri *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoAbsoluteUri)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->absUriDesc,mBuf);
       CMCHKPK(cmPkTknStrOSXL, &param->scheme,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAbsoluteUri*/
#ifdef SO_ENUM

/*
*
*    Fun:    cmPkSoTelNumPar
*
*    Desc:    pack the structure SoTelNumPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTelNumPar
(
SoTelNumPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTelNumPar(param ,mBuf)
SoTelNumPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoTelNumPar)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_TEL_CIC :
             CMCHKPK(cmPkTknStrOSXL, &param->t.cic,mBuf);
             break;
          case  SO_TEL_EXTN :
             ret1 = cmPkSoParameter(&param->t.extn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_TEL_ISUB :
             CMCHKPK(cmPkTknStrOSXL, &param->t.isub,mBuf);
             break;
          case  SO_TEL_PHONE_CONTEXT :
             CMCHKPK(cmPkTknStrOSXL, &param->t.phCntxt,mBuf);
             break;
          case  SO_TEL_POSTD :
             CMCHKPK(cmPkTknStrOSXL, &param->t.postd,mBuf);
             break;
          case  SO_TEL_RN :
             CMCHKPK(cmPkTknStrOSXL, &param->t.rn,mBuf);
             break;
          case  SO_TEL_TSP :
             ret1 = cmPkSoHost(&param->t.tsp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTelNumPar*/

/*
*
*    Fun:    cmPkSoTelNumPars
*
*    Desc:    pack the structure SoTelNumPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTelNumPars
(
SoTelNumPars *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTelNumPars(param ,mBuf)
SoTelNumPars *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoTelNumPars)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoTelNumPar( (param->par[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTelNumPars*/

/*
*
*    Fun:    cmPkSoTelUrl
*
*    Desc:    pack the structure SoTelUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTelUrl
(
SoTelUrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTelUrl(param ,mBuf)
SoTelUrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoTelUrl)

    ret1 = cmPkSoTelNumPars(&param->pars,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknStrOSXL, &param->digits,mBuf);
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTelUrl*/
#endif /* SO_ENUM */

/*
*
*    Fun:    cmPkSoPriority
*
*    Desc:    pack the structure SoPriority
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoPriority
(
SoPriority *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoPriority(param ,mBuf)
SoPriority *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoPriority)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->otherPriority,mBuf);
       CMCHKPK(cmPkTknU8, &param->priorityType,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoPriority*/

/*
*
*    Fun:    cmPkSoSipUrl
*
*    Desc:    pack the structure SoSipUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSipUrl
(
SoSipUrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSipUrl(param ,mBuf)
SoSipUrl *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSipUrl)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoHeaders(&param->headers,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoUrlParameters(&param->urlParameters,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoHostPort(&param->hostPort,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoUserInfo(&param->userInfo,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSipUrl*/

/*
*
*    Fun:    cmPkSoAddrSpec
*
*    Desc:    pack the structure SoAddrSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAddrSpec
(
SoAddrSpec *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAddrSpec(param ,mBuf)
SoAddrSpec *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAddrSpec)

    if( param->addrSpecType.pres != NOTPRSNT )
    {
       switch( param->addrSpecType.val )
       {
          case  SO_ADDRSPEC_ABSOLUTEURI :
             ret1 = cmPkSoAbsoluteUri(&param->t.absoluteUri,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRSPEC_IMURL :
#ifdef SO_INSTMSG
             ret1 = cmPkSoSipUrl(&param->t.imUrl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_INSTMSG  */
             break;
          case  SO_ADDRSPEC_SIPSURL :
#ifdef SO_TLS
             ret1 = cmPkSoSipUrl(&param->t.sipsUrl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_TLS  */
             break;
          case  SO_ADDRSPEC_SIPURL :
             ret1 = cmPkSoSipUrl(&param->t.sipUrl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRSPEC_TELURL :
#ifdef SO_ENUM
             ret1 = cmPkSoTelUrl(&param->t.telUrl,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_ENUM  */
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrSpecType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAddrSpec*/

/*
*
*    Fun:    cmPkSoContactParam
*
*    Desc:    pack the structure SoContactParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContactParam
(
SoContactParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContactParam(param ,mBuf)
SoContactParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoContactParam)

    if( param->contactParamType.pres != NOTPRSNT )
    {
       switch( param->contactParamType.val )
       {
          case  SO_CONTACTPARAM_EXTN :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_CONTACTPARAM_FEAT :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoStrValue(&param->t.fparam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_CONTACTPARAM_STD :
             CMCHKPK(cmPkSoContactParamStd, &param->t.contactParamStd,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->contactParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContactParam*/

/*
*
*    Fun:    cmPkSoInfoParam
*
*    Desc:    pack the structure SoInfoParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoInfoParam
(
SoInfoParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoInfoParam(param ,mBuf)
SoInfoParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoInfoParam)

    if( param->infoParamType.pres != NOTPRSNT )
    {
       switch( param->infoParamType.val )
       {
          case  SO_INFOPARAM_EXTN :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_INFOPARAM_PURPOSE :
             ret1 = cmPkSoCallInfoPurpose(&param->t.callInfoPurpose,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->infoParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoInfoParam*/

/*
*
*    Fun:    cmPkSoNameAddr
*
*    Desc:    pack the structure SoNameAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNameAddr
(
SoNameAddr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNameAddr(param ,mBuf)
SoNameAddr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoNameAddr)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoAddrSpec(&param->addrSpec,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoDisplayName(&param->displayName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNameAddr*/

/*
*
*    Fun:    cmPkSoContactParams
*
*    Desc:    pack the structure SoContactParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContactParams
(
SoContactParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContactParams(param ,mBuf)
SoContactParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoContactParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoContactParam( (param->contactParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContactParams*/

/*
*
*    Fun:    cmPkSoViaParam
*
*    Desc:    pack the structure SoViaParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoViaParam
(
SoViaParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoViaParam(param ,mBuf)
SoViaParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoViaParam)

    if( param->viaParamType.pres != NOTPRSNT )
    {
       switch( param->viaParamType.val )
       {
          case  SO_VIAPARAM_GENERICPARAM :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_MADDR :
             ret1 = cmPkSoHost(&param->t.maddr,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_RECEIVED :
             ret1 = cmPkSoHost(&param->t.received,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_VIABRANCH :
             CMCHKPK(cmPkTknStrOSXL, &param->t.viaBranch,mBuf);
             break;
          case  SO_VIAPARAM_VIACOMP :
             ret1 = cmPkSoStrValue(&param->t.comp,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_VIARPORT :
#ifdef SO_NAT
             CMCHKPK(cmPkTknU32, &param->t.viaRport,mBuf);
#endif /*  SO_NAT  */
             break;
          case  SO_VIAPARAM_VIATTL :
             CMCHKPK(cmPkTknU16, &param->t.viaTtl,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->viaParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoViaParam*/

/*
*
*    Fun:    cmPkSoParameters
*
*    Desc:    pack the structure SoParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoParameters
(
SoParameters *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoParameters(param ,mBuf)
SoParameters *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoParameters)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoParameter( (param->parameter[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoParameters*/

/*
*
*    Fun:    cmPkSoProtocolName
*
*    Desc:    pack the structure SoProtocolName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoProtocolName
(
SoProtocolName *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoProtocolName(param ,mBuf)
SoProtocolName *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoProtocolName)

    CMCHKPK(cmPkTknStrOSXL, &param->protocolExt,mBuf);
    CMCHKPK(cmPkTknU8, &param->protocolNameType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoProtocolName*/

/*
*
*    Fun:    cmPkSoMediaRange
*
*    Desc:    pack the structure SoMediaRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMediaRange
(
SoMediaRange *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMediaRange(param ,mBuf)
SoMediaRange *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoMediaRange)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->parameters,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoMediaRangeVal(&param->mediaRangeVal,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMediaRange*/

/*
*
*    Fun:    cmPkSoCodings
*
*    Desc:    pack the structure SoCodings
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCodings
(
SoCodings *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCodings(param ,mBuf)
SoCodings *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoCodings)

    ret1 = cmPkSoExtVal(&param->contentCoding,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknU8, &param->codingsType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCodings*/

/*
*
*    Fun:    cmPkSoInfoParams
*
*    Desc:    pack the structure SoInfoParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoInfoParams
(
SoInfoParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoInfoParams(param ,mBuf)
SoInfoParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoInfoParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoInfoParam( (param->infoParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoInfoParams*/

/*
*
*    Fun:    cmPkSoAddrCh
*
*    Desc:    pack the structure SoAddrCh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAddrCh
(
SoAddrCh *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAddrCh(param ,mBuf)
SoAddrCh *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAddrCh)

    if( param->addrChType.pres != NOTPRSNT )
    {
       switch( param->addrChType.val )
       {
          case  SO_ADDRCH_ADDRSPEC :
             ret1 = cmPkSoAddrSpec(&param->t.addrSpec,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRCH_NAMEADDR :
             ret1 = cmPkSoNameAddr(&param->t.nameAddr,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrChType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAddrCh*/

/*
*
*    Fun:    cmPkSoContactItem
*
*    Desc:    pack the structure SoContactItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContactItem
(
SoContactItem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContactItem(param ,mBuf)
SoContactItem *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoContactItem)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoContactParams(&param->contactParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAddrCh(&param->contactAddrChoice,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContactItem*/

/*
*
*    Fun:    cmPkSoAddrParam
*
*    Desc:    pack the structure SoAddrParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAddrParam
(
SoAddrParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAddrParam(param ,mBuf)
SoAddrParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAddrParam)

    if( param->addrParamType.pres != NOTPRSNT )
    {
       switch( param->addrParamType.val )
       {
          case  SO_ADDRPARAM_GENERICPARAM :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRPARAM_TAGPARAM :
             CMCHKPK(cmPkTknStrOSXL, &param->t.tagParam,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->addrParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAddrParam*/

/*
*
*    Fun:    cmPkSoAlso
*
*    Desc:    pack the structure SoAlso
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAlso
(
SoAlso *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAlso(param ,mBuf)
SoAlso *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAlso)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAddrCh( (param->addrChoice[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAlso*/

/*
*
*    Fun:    cmPkSoSentProtocol
*
*    Desc:    pack the structure SoSentProtocol
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSentProtocol
(
SoSentProtocol *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSentProtocol(param ,mBuf)
SoSentProtocol *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSentProtocol)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoExtVal(&param->transport,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->protocolVersion,mBuf);
       ret1 = cmPkSoProtocolName(&param->protocolName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSentProtocol*/

/*
*
*    Fun:    cmPkSoHostPortType
*
*    Desc:    pack the structure SoHostPortType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHostPortType
(
SoHostPortType *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHostPortType(param ,mBuf)
SoHostPortType *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoHostPortType)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_HOSTPORTTYPE_HOST :
             CMCHKPK(cmPkTknStrOSXL, &param->t.host,mBuf);
             break;
          case  SO_HOSTPORTTYPE_HOSTPORT :
             ret1 = cmPkSoHostPort(&param->t.hostPort,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHostPortType*/

/*
*
*    Fun:    cmPkSoViaParams
*
*    Desc:    pack the structure SoViaParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoViaParams
(
SoViaParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoViaParams(param ,mBuf)
SoViaParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoViaParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoViaParam( (param->viaParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoViaParams*/

/*
*
*    Fun:    cmPkSoRetryParam
*
*    Desc:    pack the structure SoRetryParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRetryParam
(
SoRetryParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRetryParam(param ,mBuf)
SoRetryParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRetryParam)

    if( param->retryParamType.pres != NOTPRSNT )
    {
       switch( param->retryParamType.val )
       {
          case  SO_RETRYPARAM_DURATION :
             CMCHKPK(cmPkTknU32, &param->t.retryDuration,mBuf);
             break;
          case  SO_RETRYPARAM_EXTN :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->retryParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRetryParam*/

/*
*
*    Fun:    cmPkSoAcceptParam
*
*    Desc:    pack the structure SoAcceptParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptParam
(
SoAcceptParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptParam(param ,mBuf)
SoAcceptParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcceptParam)

    if( param->prodcomType.pres != NOTPRSNT )
    {
       switch( param->prodcomType.val )
       {
          case  SO_GENERIC_PARAM_TYPE :
             ret1 = cmPkSoParameter(&param->u.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_QVALUE_TYPE :
             CMCHKPK(cmPkSoQValue, &param->u.qValue,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->prodcomType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptParam*/

/*
*
*    Fun:    cmPkSoAcceptParams
*
*    Desc:    pack the structure SoAcceptParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptParams
(
SoAcceptParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptParams(param ,mBuf)
SoAcceptParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAcceptParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcceptParam( (param->ap[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptParams*/

/*
*
*    Fun:    cmPkSoAcceptSeq
*
*    Desc:    pack the structure SoAcceptSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptSeq
(
SoAcceptSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptSeq(param ,mBuf)
SoAcceptSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcceptSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoAcceptParams(&param->acceptParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoMediaRange(&param->mediaRange,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptSeq*/

/*
*
*    Fun:    cmPkSoAcceptEncodingSeq
*
*    Desc:    pack the structure SoAcceptEncodingSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptEncodingSeq
(
SoAcceptEncodingSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptEncodingSeq(param ,mBuf)
SoAcceptEncodingSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcceptEncodingSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoAcceptParams(&param->apList,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoCodings(&param->codings,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptEncodingSeq*/

/*
*
*    Fun:    cmPkSoAcceptLanguageSeq
*
*    Desc:    pack the structure SoAcceptLanguageSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptLanguageSeq
(
SoAcceptLanguageSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptLanguageSeq(param ,mBuf)
SoAcceptLanguageSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcceptLanguageSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoAcceptParams(&param->acceptParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->languageRange,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptLanguageSeq*/

/*
*
*    Fun:    cmPkSoContactItems
*
*    Desc:    pack the structure SoContactItems
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContactItems
(
SoContactItems *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContactItems(param ,mBuf)
SoContactItems *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoContactItems)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoContactItem( (param->contactItem[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContactItems*/

/*
*
*    Fun:    cmPkSoProdcom
*
*    Desc:    pack the structure SoProdcom
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoProdcom
(
SoProdcom *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoProdcom(param ,mBuf)
SoProdcom *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoProdcom)

    if( param->prodcomType.pres != NOTPRSNT )
    {
       switch( param->prodcomType.val )
       {
          case  SO_PRODCOM_COMMENT :
             CMCHKPK(cmPkTknStrOSXL, &param->t.comment,mBuf);
             break;
          case  SO_PRODCOM_PRODUCT :
             ret1 = cmPkSoNameVal(&param->t.product,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->prodcomType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoProdcom*/

/*
*
*    Fun:    cmPkSoViaItem
*
*    Desc:    pack the structure SoViaItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoViaItem
(
SoViaItem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoViaItem(param ,mBuf)
SoViaItem *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoViaItem)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->viaComment,mBuf);
       ret1 = cmPkSoViaParams(&param->viaParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoHostPortType(&param->sentBy,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoSentProtocol(&param->sentProtocol,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoViaItem*/

/*
*
*    Fun:    cmPkSoRouteSeq
*
*    Desc:    pack the structure SoRouteSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRouteSeq
(
SoRouteSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRouteSeq(param ,mBuf)
SoRouteSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRouteSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->rParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoNameAddr(&param->nameAddr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRouteSeq*/

/*
*
*    Fun:    cmPkSoWarningItem
*
*    Desc:    pack the structure SoWarningItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoWarningItem
(
SoWarningItem *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoWarningItem(param ,mBuf)
SoWarningItem *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoWarningItem)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->warnText,mBuf);
       CMCHKPK(cmPkTknStrOSXL, &param->warnAgent,mBuf);
       CMCHKPK(cmPkTknU16, &param->warnCode,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoWarningItem*/

/*
*
*    Fun:    cmPkSoAccept
*
*    Desc:    pack the structure SoAccept
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAccept
(
SoAccept *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAccept(param ,mBuf)
SoAccept *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAccept)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcceptSeq( (param->accept[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAccept*/

/*
*
*    Fun:    cmPkSoAcceptEncoding
*
*    Desc:    pack the structure SoAcceptEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptEncoding
(
SoAcceptEncoding *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptEncoding(param ,mBuf)
SoAcceptEncoding *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAcceptEncoding)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcceptEncodingSeq( (param->acceptEncoding[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptEncoding*/

/*
*
*    Fun:    cmPkSoAcceptLanguage
*
*    Desc:    pack the structure SoAcceptLanguage
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptLanguage
(
SoAcceptLanguage *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptLanguage(param ,mBuf)
SoAcceptLanguage *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAcceptLanguage)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcceptLanguageSeq( (param->acceptLanguage[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptLanguage*/
#ifdef SO_EVENT

/*
*
*    Fun:    cmPkSoEventHeader
*
*    Desc:    pack the structure SoEventHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEventHeader
(
SoEventHeader *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEventHeader(param ,mBuf)
SoEventHeader *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoEventHeader)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->eventName,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEventHeader*/

#endif /* SO_EVENT */

/*
*
*    Fun:    cmPkSoCallInfoSeq
*
*    Desc:    pack the structure SoCallInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCallInfoSeq
(
SoCallInfoSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCallInfoSeq(param ,mBuf)
SoCallInfoSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoCallInfoSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoInfoParams(&param->infoParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAbsoluteUri(&param->absoluteUri,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCallInfoSeq*/

/*
*
*    Fun:    cmPkSoCallInfo
*
*    Desc:    pack the structure SoCallInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCallInfo
(
SoCallInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCallInfo(param ,mBuf)
SoCallInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoCallInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoCallInfoSeq( (param->callInfo[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCallInfo*/

/*
*
*    Fun:    cmPkSoInfoSeq
*
*    Desc:    pack the structure SoInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoInfoSeq
(
SoInfoSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoInfoSeq(param ,mBuf)
SoInfoSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoInfoSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->genericParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAbsoluteUri(&param->absoluteUri,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoInfoSeq*/

/*
*
*    Fun:    cmPkSoInfo
*
*    Desc:    pack the structure SoInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoInfo
(
SoInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoInfo(param ,mBuf)
SoInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoInfo)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoInfoSeq( (param->info[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoInfo*/

/*
*
*    Fun:    cmPkSoAddrParams
*
*    Desc:    pack the structure SoAddrParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAddrParams
(
SoAddrParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAddrParams(param ,mBuf)
SoAddrParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAddrParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAddrParam( (param->addrParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAddrParams*/

/*
*
*    Fun:    cmPkSoRoute
*
*    Desc:    pack the structure SoRoute
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRoute
(
SoRoute *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRoute(param ,mBuf)
SoRoute *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRoute)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRouteSeq( (param->route[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRoute*/

/*
*
*    Fun:    cmPkSoDispositionParam
*
*    Desc:    pack the structure SoDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDispositionParam
(
SoDispositionParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDispositionParam(param ,mBuf)
SoDispositionParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoDispositionParam)

    if( param->dispositionParamType.pres != NOTPRSNT )
    {
       switch( param->dispositionParamType.val )
       {
          case  SO_DISP_PARAM_EXTN :
             ret1 = cmPkSoParameter(&param->t.parameter,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_DISP_PARAM_HANDLING :
             ret1 = cmPkSoExtVal(&param->t.handlingParmVal,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->dispositionParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDispositionParam*/

/*
*
*    Fun:    cmPkSoDispositionParams
*
*    Desc:    pack the structure SoDispositionParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDispositionParams
(
SoDispositionParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDispositionParams(param ,mBuf)
SoDispositionParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoDispositionParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoDispositionParam( (param->dispositionParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDispositionParams*/

/*
*
*    Fun:    cmPkSoAllow
*
*    Desc:    pack the structure SoAllow
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAllow
(
SoAllow *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAllow(param ,mBuf)
SoAllow *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAllow)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoExtVal( (param->method[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAllow*/

/*
*
*    Fun:    cmPkSoContentDisposition
*
*    Desc:    pack the structure SoContentDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContentDisposition
(
SoContentDisposition *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContentDisposition(param ,mBuf)
SoContentDisposition *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoContentDisposition)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoDispositionParams(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStrValue(&param->type,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContentDisposition*/

/*
*
*    Fun:    cmPkSoRetryParams
*
*    Desc:    pack the structure SoRetryParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRetryParams
(
SoRetryParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRetryParams(param ,mBuf)
SoRetryParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRetryParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRetryParam( (param->retryParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRetryParams*/

/*
*
*    Fun:    cmPkSoProdcomLst
*
*    Desc:    pack the structure SoProdcomLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoProdcomLst
(
SoProdcomLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoProdcomLst(param ,mBuf)
SoProdcomLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoProdcomLst)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoProdcom( (param->prodcom[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoProdcomLst*/

/*
*
*    Fun:    cmPkSoWarning
*
*    Desc:    pack the structure SoWarning
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoWarning
(
SoWarning *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoWarning(param ,mBuf)
SoWarning *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoWarning)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoWarningItem( (param->warningItem[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoWarning*/

/*
*
*    Fun:    cmPkSoContact
*
*    Desc:    pack the structure SoContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContact
(
SoContact *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContact(param ,mBuf)
SoContact *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoContact)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoContactItems(&param->contactItems,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU8, &param->contactDescType,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContact*/

/*
*
*    Fun:    cmPkSoCSeq
*
*    Desc:    pack the structure SoCSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCSeq
(
SoCSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCSeq(param ,mBuf)
SoCSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoCSeq)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoExtVal(&param->method,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->cSeqVal,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCSeq*/

/*
*
*    Fun:    cmPkSoAddress
*
*    Desc:    pack the structure SoAddress
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAddress
(
SoAddress *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAddress(param ,mBuf)
SoAddress *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAddress)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoAddrParams(&param->addrParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAddrCh(&param->addrCh,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAddress*/

/*
*
*    Fun:    cmPkSoTimestamp
*
*    Desc:    pack the structure SoTimestamp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTimestamp
(
SoTimestamp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTimestamp(param ,mBuf)
SoTimestamp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTimestamp)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknU32, &param->timestampDelayFrac,mBuf);
       CMCHKPK(cmPkTknU32, &param->timestampDelay,mBuf);
       CMCHKPK(cmPkTknU32, &param->timestampFrac,mBuf);
       CMCHKPK(cmPkTknU32, &param->timestampVal,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTimestamp*/

/*
*
*    Fun:    cmPkSoVia
*
*    Desc:    pack the structure SoVia
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoVia
(
SoVia *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoVia(param ,mBuf)
SoVia *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoVia)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoViaItem( (param->viaItem[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoVia*/

/*
*
*    Fun:    cmPkSoAuthorization
*
*    Desc:    pack the structure SoAuthorization
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAuthorization
(
SoAuthorization *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAuthorization(param ,mBuf)
SoAuthorization *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAuthorization)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->authParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->authScheme,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAuthorization*/

/*
*
*    Fun:    cmPkSoAuthenticate
*
*    Desc:    pack the structure SoAuthenticate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAuthenticate
(
SoAuthenticate *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAuthenticate(param ,mBuf)
SoAuthenticate *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAuthenticate)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAuthorization( (param->challenge[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAuthenticate*/

/*
*
*    Fun:    cmPkSoReplyTo
*
*    Desc:    pack the structure SoReplyTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReplyTo
(
SoReplyTo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReplyTo(param ,mBuf)
SoReplyTo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReplyTo)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAddrCh(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReplyTo*/

/*
*
*    Fun:    cmPkSoContentEncoding
*
*    Desc:    pack the structure SoContentEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContentEncoding
(
SoContentEncoding *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContentEncoding(param ,mBuf)
SoContentEncoding *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoContentEncoding)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoExtVal( (param->contentCoding[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContentEncoding*/

/*
*
*    Fun:    cmPkSoContentTypeHdr
*
*    Desc:    pack the structure SoContentTypeHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoContentTypeHdr
(
SoContentTypeHdr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoContentTypeHdr(param ,mBuf)
SoContentTypeHdr *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoContentTypeHdr)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->parameters,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStrValue(&param->subType,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStrValue(&param->type,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoContentTypeHdr*/

/*
*
*    Fun:    cmPkSoRetryAfter
*
*    Desc:    pack the structure SoRetryAfter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRetryAfter
(
SoRetryAfter *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRetryAfter(param ,mBuf)
SoRetryAfter *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRetryAfter)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoRetryParams(&param->retryParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->retryAfterComment,mBuf);
       CMCHKPK(cmPkTknU32, &param->retryAfterTime,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRetryAfter*/

/*
*
*    Fun:    cmPkSoRAck
*
*    Desc:    pack the structure SoRAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRAck
(
SoRAck *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRAck(param ,mBuf)
SoRAck *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRAck)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoExtVal(&param->method,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->cSeqNum,mBuf);
       CMCHKPK(cmPkTknU32, &param->responseNum,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRAck*/
#ifdef SO_REFER

/*
*
*    Fun:    cmPkSoReferTo
*
*    Desc:    pack the structure SoReferTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReferTo
(
SoReferTo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReferTo(param ,mBuf)
SoReferTo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReferTo)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAddrCh(&param->addr,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReferTo*/

/*
*
*    Fun:    cmPkSoReferredByParam
*
*    Desc:    pack the structure SoReferredByParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReferredByParam
(
SoReferredByParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReferredByParam(param ,mBuf)
SoReferredByParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReferredByParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_RF_BY_GENERIC_PARAM :
             ret1 = cmPkSoParameter(&param->t.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RF_BY_ID_PAR :
             CMCHKPK(cmPkTknStrOSXL, &param->t.cid,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReferredByParam*/

/*
*
*    Fun:    cmPkSoReferredByParams
*
*    Desc:    pack the structure SoReferredByParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReferredByParams
(
SoReferredByParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReferredByParams(param ,mBuf)
SoReferredByParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoReferredByParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoReferredByParam( (param->soRefrdByPar[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReferredByParams*/

/*
*
*    Fun:    cmPkSoReferredBy
*
*    Desc:    pack the structure SoReferredBy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReferredBy
(
SoReferredBy *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReferredBy(param ,mBuf)
SoReferredBy *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReferredBy)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoReferredByParams(&param->refrdByPar,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoAddrCh(&param->referredUrl,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReferredBy*/

/*
*
*    Fun:    cmPkSoReplacesParam
*
*    Desc:    pack the structure SoReplacesParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReplacesParam
(
SoReplacesParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReplacesParam(param ,mBuf)
SoReplacesParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReplacesParam)

    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  SO_REPLACES_GENERIC_PARAMS :
             ret1 = cmPkSoParameter(&param->u.genericParams,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REPLACES_PARAMTYPE_FROMTAG :
             CMCHKPK(cmPkTknStrOSXL, &param->u.fromTag,mBuf);
             break;
          case  SO_REPLACES_PARAMTYPE_TOTAG :
             CMCHKPK(cmPkTknStrOSXL, &param->u.toTag,mBuf);
             break;
          case  SO_REPLACES_PARAMTYPE_EARLYONLY :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->paramType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReplacesParam*/

/*
*
*    Fun:    cmPkSoReplacesParams
*
*    Desc:    pack the structure SoReplacesParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReplacesParams
(
SoReplacesParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReplacesParams(param ,mBuf)
SoReplacesParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoReplacesParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoReplacesParam( (param->replacesParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReplacesParams*/

/*
*
*    Fun:    cmPkSoReplaces
*
*    Desc:    pack the structure SoReplaces
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReplaces
(
SoReplaces *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReplaces(param ,mBuf)
SoReplaces *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReplaces)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoReplacesParams(&param->replacesParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknStrOSXL, &param->callId,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReplaces*/
#endif /* SO_REFER */
#ifdef SO_SESSTIMER

/*
*
*    Fun:    cmPkSoSessExpParam
*
*    Desc:    pack the structure SoSessExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSessExpParam
(
SoSessExpParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSessExpParam(param ,mBuf)
SoSessExpParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSessExpParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_SESSION_EXP_EXTN :
             ret1 = cmPkSoParameter(&param->u.param,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SESSION_EXP_REFRESHER :
             CMCHKPK(cmPkTknU8, &param->u.refresher,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSessExpParam*/

/*
*
*    Fun:    cmPkSoSessExpParams
*
*    Desc:    pack the structure SoSessExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSessExpParams
(
SoSessExpParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSessExpParams(param ,mBuf)
SoSessExpParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSessExpParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoSessExpParam( (param->param[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSessExpParams*/

/*
*
*    Fun:    cmPkSoSessionExpires
*
*    Desc:    pack the structure SoSessionExpires
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSessionExpires
(
SoSessionExpires *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSessionExpires(param ,mBuf)
SoSessionExpires *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSessionExpires)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoSessExpParams(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->deltaSeconds,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSessionExpires*/

/*
*
*    Fun:    cmPkSoMinSE
*
*    Desc:    pack the structure SoMinSE
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMinSE
(
SoMinSE *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMinSE(param ,mBuf)
SoMinSE *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoMinSE)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoParameters(&param->params,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKPK(cmPkTknU32, &param->deltaSeconds,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMinSE*/
#endif /* SO_SESSIONTIMER */
#ifdef SO_CALLERPREF

/*
*
*    Fun:    cmPkSoRequestDispositionParam
*
*    Desc:    pack the structure SoRequestDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRequestDispositionParam
(
SoRequestDispositionParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRequestDispositionParam(param ,mBuf)
SoRequestDispositionParam *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoRequestDispositionParam)

    CMCHKPK(cmPkTknU8, &param->dispSubType,mBuf);
    CMCHKPK(cmPkTknU8, &param->dispositionType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRequestDispositionParam*/

/*
*
*    Fun:    cmPkSoRequestDisposition
*
*    Desc:    pack the structure SoRequestDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRequestDisposition
(
SoRequestDisposition *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRequestDisposition(param ,mBuf)
SoRequestDisposition *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRequestDisposition)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRequestDispositionParam( (param->requestDispositionParams[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRequestDisposition*/

/*
*
*    Fun:    cmPkSoAcParam
*
*    Desc:    pack the structure SoAcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcParam
(
SoAcParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcParam(param ,mBuf)
SoAcParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_ACCEPTCONTACT_PAR_EXPLICIT :
             break;
          case  SO_ACCEPTCONTACT_PAR_EXTN :
             ret1 = cmPkSoParameter(&param->u.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ACCEPTCONTACT_PAR_FP :
             ret1 = cmPkSoStrValue(&param->u.fparam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ACCEPTCONTACT_PAR_REQUIRE :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcParam*/

/*
*
*    Fun:    cmPkSoAcParams
*
*    Desc:    pack the structure SoAcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcParams
(
SoAcParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcParams(param ,mBuf)
SoAcParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAcParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcParam( (param->acParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcParams*/

/*
*
*    Fun:    cmPkSoAcceptContact
*
*    Desc:    pack the structure SoAcceptContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcceptContact
(
SoAcceptContact *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcceptContact(param ,mBuf)
SoAcceptContact *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoAcceptContact)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAcParams( (param->acParams[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcceptContact*/

/*
*
*    Fun:    cmPkSoRcParam
*
*    Desc:    pack the structure SoRcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRcParam
(
SoRcParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRcParam(param ,mBuf)
SoRcParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRcParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_REJECTCONTACT_PAR_EXTN :
             ret1 = cmPkSoParameter(&param->u.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REJECTCONTACT_PAR_FP :
             ret1 = cmPkSoStrValue(&param->u.fparam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRcParam*/

/*
*
*    Fun:    cmPkSoRcParams
*
*    Desc:    pack the structure SoRcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRcParams
(
SoRcParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRcParams(param ,mBuf)
SoRcParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRcParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRcParam( (param->rcParam[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRcParams*/

/*
*
*    Fun:    cmPkSoRejectContact
*
*    Desc:    pack the structure SoRejectContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRejectContact
(
SoRejectContact *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRejectContact(param ,mBuf)
SoRejectContact *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRejectContact)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRcParams( (param->rcParams[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRejectContact*/
#endif /* SO_CALLERPREF */

/*
*
*    Fun:    cmPkSoTypeVal
*
*    Desc:    pack the structure SoTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTypeVal
(
SoTypeVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTypeVal(param ,mBuf)
SoTypeVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoTypeVal)

    ret1 = cmPkSoStrValue(&param->val,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkSoStrValue(&param->type,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoTypeVal*/

/*
*
*    Fun:    cmPkSoPrivLst
*
*    Desc:    pack the structure SoPrivLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoPrivLst
(
SoPrivLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoPrivLst(param ,mBuf)
SoPrivLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoPrivLst)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoTypeVal( (param->privVal[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoPrivLst*/

/*
*
*    Fun:    cmPkSoRpiTok
*
*    Desc:    pack the structure SoRpiTok
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRpiTok
(
SoRpiTok *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRpiTok(param ,mBuf)
SoRpiTok *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRpiTok)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_RPI_ID_TYPE :
             ret1 = cmPkSoStrValue(&param->u.id,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_OTHER_RPI_TOKEN :
             ret1 = cmPkSoTypeVal(&param->u.othRpi,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_PRIVACY :
             ret1 = cmPkSoPrivLst(&param->u.prvLst,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_PTY_TYPE :
             ret1 = cmPkSoStrValue(&param->u.party,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_SCREEN :
             CMCHKPK(cmPkTknU8, &param->u.scrn,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRpiTok*/

/*
*
*    Fun:    cmPkSoRpiTokLst
*
*    Desc:    pack the structure SoRpiTokLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRpiTokLst
(
SoRpiTokLst *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRpiTokLst(param ,mBuf)
SoRpiTokLst *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRpiTokLst)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRpiTok( (param->rpiTok[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRpiTokLst*/

/*
*
*    Fun:    cmPkSoRpid
*
*    Desc:    pack the structure SoRpid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRpid
(
SoRpid *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRpid(param ,mBuf)
SoRpid *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRpid)

    ret1 = cmPkSoRpiTokLst(&param->rpiTokLst,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkSoNameAddr(&param->nameAddr,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoRpid*/

/*
*
*    Fun:    cmPkSoRemPartyId
*
*    Desc:    pack the structure SoRemPartyId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRemPartyId
(
SoRemPartyId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRemPartyId(param ,mBuf)
SoRemPartyId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRemPartyId)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRpid( (param->rpidLst[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRemPartyId*/

/*
*
*    Fun:    cmPkSoRpidPrivcy
*
*    Desc:    pack the structure SoRpidPrivcy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRpidPrivcy
(
SoRpidPrivcy *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRpidPrivcy(param ,mBuf)
SoRpidPrivcy *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoRpidPrivcy)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoRpiTokLst( (param->rpidPriv[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRpidPrivcy*/
#ifdef SO_EVENT

/*
*
*    Fun:    cmPkSoSubExpParam
*
*    Desc:    pack the structure SoSubExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSubExpParam
(
SoSubExpParam *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSubExpParam(param ,mBuf)
SoSubExpParam *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSubExpParam)

    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_SUB_EXP_PAR_EXPIRES :
             CMCHKPK(cmPkTknU32, &param->u.expires,mBuf);
             break;
          case  SO_SUB_EXP_PAR_GENERIC_PARAM :
             ret1 = cmPkSoParameter(&param->u.genericParam,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SUB_EXP_PAR_REASON :
             ret1 = cmPkSoStrValue(&param->u.reason,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SUB_EXP_PAR_RETRY_AFT :
             CMCHKPK(cmPkTknU32, &param->u.retryAfter,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSubExpParam*/

/*
*
*    Fun:    cmPkSoSubExpParams
*
*    Desc:    pack the structure SoSubExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSubExpParams
(
SoSubExpParams *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSubExpParams(param ,mBuf)
SoSubExpParams *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSubExpParams)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoSubExpParam( (param->subExpParamList[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSubExpParams*/

/*
*
*    Fun:    cmPkSoSubscState
*
*    Desc:    pack the structure SoSubscState
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSubscState
(
SoSubscState *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSubscState(param ,mBuf)
SoSubscState *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSubscState)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoSubExpParams(&param->subExpParams,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStrValue(&param->subVal,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSubscState*/
#endif /* SO_EVENT */

/*
*
*    Fun:    cmPkSoMechPar
*
*    Desc:    pack the structure SoMechPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMechPar
(
SoMechPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMechPar(param ,mBuf)
SoMechPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoMechPar)

    if( param->mechParamType.pres != NOTPRSNT )
    {
       switch( param->mechParamType.val )
       {
          case  SO_MECH_PAR_DG_ALG :
             CMCHKPK(cmPkTknStrOSXL, &param->u.dgAlg,mBuf);
             break;
          case  SO_MECH_PAR_DG_QOP :
             CMCHKPK(cmPkTknStrOSXL, &param->u.dgQop,mBuf);
             break;
          case  SO_MECH_PAR_DG_VERIFY :
             CMCHKPK(cmPkTknStrOSXL, &param->u.dgVerify,mBuf);
             break;
          case  SO_MECH_PAR_EXTN :
             ret1 = cmPkSoParameter(&param->u.ext,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_MECH_PAR_PREF :
             CMCHKPK(cmPkSoQValue, &param->u.pref,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->mechParamType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMechPar*/

/*
*
*    Fun:    cmPkSoMechPars
*
*    Desc:    pack the structure SoMechPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMechPars
(
SoMechPars *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMechPars(param ,mBuf)
SoMechPars *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoMechPars)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoMechPar( (param->mechPar[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMechPars*/

/*
*
*    Fun:    cmPkSoSecMech
*
*    Desc:    pack the structure SoSecMech
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSecMech
(
SoSecMech *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSecMech(param ,mBuf)
SoSecMech *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSecMech)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoMechPars(&param->mechPars,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStrValue(&param->mechName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSecMech*/

/*
*
*    Fun:    cmPkSoSecVerify
*
*    Desc:    pack the structure SoSecVerify
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSecVerify
(
SoSecVerify *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSecVerify(param ,mBuf)
SoSecVerify *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSecVerify)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoSecMech( (param->secMech[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSecVerify*/

/*
*
*    Fun:    cmPkSoSecServer
*
*    Desc:    pack the structure SoSecServer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSecServer
(
SoSecServer *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSecServer(param ,mBuf)
SoSecServer *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSecServer)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoSecMech( (param->secMech[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSecServer*/

/*
*
*    Fun:    cmPkSoSecClient
*
*    Desc:    pack the structure SoSecClient
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSecClient
(
SoSecClient *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSecClient(param ,mBuf)
SoSecClient *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSecClient)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoSecMech( (param->secMech[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSecClient*/

/*
*
*    Fun:    cmPkSoReasonPar
*
*    Desc:    pack the structure SoReasonPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReasonPar
(
SoReasonPar *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReasonPar(param ,mBuf)
SoReasonPar *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReasonPar)

    if( param->reasonType.pres != NOTPRSNT )
    {
       switch( param->reasonType.val )
       {
          case  SO_REASON_CAUSE :
             CMCHKPK(cmPkTknU32, &param->u.cause,mBuf);
             break;
          case  SO_REASON_EXTN :
             ret1 = cmPkSoParameter(&param->u.extn,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REASON_TEXT :
             CMCHKPK(cmPkTknStrOSXL, &param->u.text,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->reasonType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReasonPar*/

/*
*
*    Fun:    cmPkSoReasonPars
*
*    Desc:    pack the structure SoReasonPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReasonPars
(
SoReasonPars *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReasonPars(param ,mBuf)
SoReasonPars *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoReasonPars)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoReasonPar( (param->reasonPar[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReasonPars*/

/*
*
*    Fun:    cmPkSoReasonVal
*
*    Desc:    pack the structure SoReasonVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReasonVal
(
SoReasonVal *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReasonVal(param ,mBuf)
SoReasonVal *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoReasonVal)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoReasonPars(&param->reasonPars,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoProtocolName(&param->protocolName,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReasonVal*/

/*
*
*    Fun:    cmPkSoReason
*
*    Desc:    pack the structure SoReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoReason
(
SoReason *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoReason(param ,mBuf)
SoReason *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoReason)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoReasonVal( (param->reasonVal[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoReason*/

/*
*
*    Fun:    cmPkSoPrivacy
*
*    Desc:    pack the structure SoPrivacy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoPrivacy
(
SoPrivacy *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoPrivacy(param ,mBuf)
SoPrivacy *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoPrivacy)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoStrValue( (param->privVal[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoPrivacy*/

/*
*
*    Fun:    cmPkSoPAssertedId
*
*    Desc:    pack the structure SoPAssertedId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoPAssertedId
(
SoPAssertedId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoPAssertedId(param ,mBuf)
SoPAssertedId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoPAssertedId)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAddrCh( (param->addrChoice[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoPAssertedId*/

/*
*
*    Fun:    cmPkSoPPreferredId
*
*    Desc:    pack the structure SoPPreferredId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoPPreferredId
(
SoPPreferredId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoPPreferredId(param ,mBuf)
SoPPreferredId *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoPPreferredId)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoAddrCh( (param->addrChoice[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoPPreferredId*/

/*
*
*    Fun:    cmPkSoHeader
*
*    Desc:    pack the structure SoHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHeader
(
SoHeader *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHeader(param ,mBuf)
SoHeader *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoHeader)

    if( param->headerType.pres != NOTPRSNT )
    {
       switch( param->headerType.val )
       {
          case  SO_HEADER_ANONMY :
             ret1 = cmPkSoStrValue(&param->t.anony,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTDISPOSITION :
             ret1 = cmPkSoContentDisposition(&param->t.contentDisposition,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTENCODING :
             ret1 = cmPkSoContentEncoding(&param->t.contentEncoding,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTLANGUAGE :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.contentLanguage,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTLENGTH :
             CMCHKPK(cmPkTknU32, &param->t.contentLength,mBuf);
             break;
          case  SO_HEADER_ENT_CONTENTTYPE :
             ret1 = cmPkSoContentTypeHdr(&param->t.contentType,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_MIMEVERSION :
             CMCHKPK(cmPkTknStrOSXL, &param->t.mimeVersion,mBuf);
             break;
          case  SO_HEADER_GEN_ACCEPT :
             ret1 = cmPkSoAccept(&param->t.accept,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ACCEPTENCODING :
             ret1 = cmPkSoAcceptEncoding(&param->t.acceptEncoding,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ACCEPTLANGUAGE :
             ret1 = cmPkSoAcceptLanguage(&param->t.acceptLanguage,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALERTINFO :
             ret1 = cmPkSoInfo(&param->t.alertInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALLOW :
             ret1 = cmPkSoAllow(&param->t.allow,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALLOW_EVENTS :
#ifdef SO_EVENT
             ret1 = cmPkSoTknStrOSXLLst(&param->t.allowEvents,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_GEN_ALLOW_EVENTSU :
#ifdef SO_EVENT
             ret1 = cmPkSoTknStrOSXLLst(&param->t.allowEvents,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_GEN_CALLID :
             CMCHKPK(cmPkTknStrOSXL, &param->t.callId,mBuf);
             break;
          case  SO_HEADER_GEN_CALLINFO :
             ret1 = cmPkSoCallInfo(&param->t.callInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_CONTACT :
             ret1 = cmPkSoContact(&param->t.contact,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_CSEQ :
             ret1 = cmPkSoCSeq(&param->t.cSeq,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_DATE :
             CMCHKPK(cmPkSoSipDate, &param->t.date,mBuf);
             break;
          case  SO_HEADER_GEN_ENCRYPTION :
             CMCHKPK(cmPkTknStrOSXL, &param->t.encryption,mBuf);
             break;
          case  SO_HEADER_GEN_EXPIRES :
             CMCHKPK(cmPkTknU32, &param->t.expires,mBuf);
             break;
          case  SO_HEADER_GEN_EXTENSION :
             CMCHKPK(cmPkTknStrOSXL, &param->t.extensionHeader,mBuf);
             break;
          case  SO_HEADER_GEN_FROM :
             ret1 = cmPkSoAddress(&param->t.from,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_MINEXPIRES :
             CMCHKPK(cmPkTknU32, &param->t.minExpires,mBuf);
             break;
          case  SO_HEADER_GEN_MINSE :
#ifdef SO_SESSTIMER
             ret1 = cmPkSoMinSE(&param->t.minSe,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_SESSTIMER  */
             break;
          case  SO_HEADER_GEN_ORGANIZATION :
             CMCHKPK(cmPkTknStrOSXL, &param->t.organization,mBuf);
             break;
          case  SO_HEADER_GEN_PASSERTEDID :
             ret1 = cmPkSoPAssertedId(&param->t.assertId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PATH :
             ret1 = cmPkSoRoute(&param->t.path,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PMEDIAAUTHORIZATION :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.pMediaAuth,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PPREFERREDID :
             ret1 = cmPkSoPPreferredId(&param->t.preferredId,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PRIVACY :
             ret1 = cmPkSoPrivacy(&param->t.privacy,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PROXYREQUIRE :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.proxyRequire,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RACK :
             ret1 = cmPkSoRAck(&param->t.rAck,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REASON :
             ret1 = cmPkSoReason(&param->t.reason,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RECORDROUTE :
             ret1 = cmPkSoRoute(&param->t.recordRoute,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REPLYTO :
             ret1 = cmPkSoReplyTo(&param->t.replyTo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REQUIRE :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.require,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RSEQ :
             CMCHKPK(cmPkTknU32, &param->t.rSeq,mBuf);
             break;
          case  SO_HEADER_GEN_SERVICEROUTE :
             ret1 = cmPkSoRoute(&param->t.serviceRoute,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_SESSION_EXPIRES :
          case  SO_HEADER_GEN_SESSION_EXPIRESX :
#ifdef SO_SESSTIMER
             ret1 = cmPkSoSessionExpires(&param->t.sessExpires,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             ret1 = cmPkSoSessionExpires(&param->t.sessExpires,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_SESSTIMER  */
             break;
          case  SO_HEADER_GEN_SUBJECT :
             CMCHKPK(cmPkTknStrOSXL, &param->t.subject,mBuf);
             break;
          case  SO_HEADER_GEN_SUPPORTED :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.supported,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_TIMESTAMP :
             CMCHKPK(cmPkSoTimestamp, &param->t.timestamp,mBuf);
             break;
          case  SO_HEADER_GEN_TO :
             ret1 = cmPkSoAddress(&param->t.to,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_USERAGENT :
             ret1 = cmPkSoProdcomLst(&param->t.userAgent,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_VIA :
             ret1 = cmPkSoVia(&param->t.via,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_WARNING :
             ret1 = cmPkSoWarning(&param->t.warning,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_WWWAUTHENTICATE :
             ret1 = cmPkSoAuthenticate(&param->t.wwwAuthenticate,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REM_PARTY_ID :
             ret1 = cmPkSoRemPartyId(&param->t.remPtid,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_ACCEPT_CONTACT :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoAcceptContact(&param->t.acceptContact,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_ACCEPT_CONTACTA :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoAcceptContact(&param->t.acceptContact,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_ALSO :
             ret1 = cmPkSoAlso(&param->t.also,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_AUTHENTICATIONINFO :
             ret1 = cmPkSoParameters(&param->t.authInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_AUTHORIZATION :
             ret1 = cmPkSoAuthorization(&param->t.authorization,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_EVENT :
#ifdef SO_EVENT
             ret1 = cmPkSoEventHeader(&param->t.event,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_REQ_EVENTO :
#ifdef SO_EVENT
             ret1 = cmPkSoEventHeader(&param->t.event,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_REQ_INREPLYTO :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.inReplyTo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_MAXFORWARDS :
             CMCHKPK(cmPkTknU32, &param->t.maxForwards,mBuf);
             break;
          case  SO_HEADER_REQ_PRIORITY :
             ret1 = cmPkSoPriority(&param->t.priority,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_PROXYAUTHORIZATION :
             ret1 = cmPkSoAuthorization(&param->t.proxyAuthorization,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_REFERBY :
#ifdef SO_REFER
             ret1 = cmPkSoReferredBy(&param->t.referredBy,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERBYB :
#ifdef SO_REFER
             ret1 = cmPkSoReferredBy(&param->t.referredBy,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERTO :
#ifdef SO_REFER
             ret1 = cmPkSoReferTo(&param->t.referTo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERTOR :
#ifdef SO_REFER
             ret1 = cmPkSoReferTo(&param->t.referTo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REJECT_CONTACT :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoRejectContact(&param->t.rejectContact,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REJECT_CONTACTJ :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoRejectContact(&param->t.rejectContact,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REPLACES :
#ifdef SO_REFER
             ret1 = cmPkSoReplaces(&param->t.replaces,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REQUESTDISPOSITION :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoRequestDisposition(&param->t.requestDisposition,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REQUESTDISPOSITIOND :
#ifdef SO_CALLERPREF
             ret1 = cmPkSoRequestDisposition(&param->t.requestDisposition,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_RESPONSEKEY :
             CMCHKPK(cmPkTknStrOSXL, &param->t.responseKey,mBuf);
             break;
          case  SO_HEADER_REQ_ROUTE :
             ret1 = cmPkSoRoute(&param->t.route,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RPID_PRIV :
             ret1 = cmPkSoRpidPrivcy(&param->t.rpidPriv,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_ERRORINFO :
             ret1 = cmPkSoInfo(&param->t.errorInfo,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_PROXYAUTHENTICATE :
             ret1 = cmPkSoAuthenticate(&param->t.proxyAuthenticate,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_RETRYAFTER :
             ret1 = cmPkSoRetryAfter(&param->t.retryAfter,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_SERVER :
             ret1 = cmPkSoProdcomLst(&param->t.server,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_UNSUPPORTED :
             ret1 = cmPkSoTknStrOSXLLst(&param->t.unsupported,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_CLIENT :
             ret1 = cmPkSoSecClient(&param->t.secClient,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_SERVER :
             ret1 = cmPkSoSecServer(&param->t.secServer,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_VERIFY :
             ret1 = cmPkSoSecVerify(&param->t.secVerify,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SUBSC_STATE :
#ifdef SO_EVENT
             ret1 = cmPkSoSubscState(&param->t.subscSt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->headerType,mBuf);
    RETVALUE(ROK);

} /*end of function cmPkSoHeader*/

/*
*
*    Fun:    cmPkSoRequestLine
*
*    Desc:    pack the structure SoRequestLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRequestLine
(
SoRequestLine *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRequestLine(param ,mBuf)
SoRequestLine *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRequestLine)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->sipVersion,mBuf);
       ret1 = cmPkSoAddrSpec(&param->addrSpec,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoExtVal(&param->method,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRequestLine*/

/*
*
*    Fun:    cmPkSoHeaderSeq
*
*    Desc:    pack the structure SoHeaderSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHeaderSeq
(
SoHeaderSeq *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHeaderSeq(param ,mBuf)
SoHeaderSeq *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoHeaderSeq)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoHeader( (param->header[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHeaderSeq*/

/*
*
*    Fun:    cmPkSoStatusLine
*
*    Desc:    pack the structure SoStatusLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoStatusLine
(
SoStatusLine *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoStatusLine(param ,mBuf)
SoStatusLine *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoStatusLine)

    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKPK(cmPkTknStrOSXL, &param->reasonPhrase,mBuf);
       CMCHKPK(cmPkTknU16, &param->statusCode,mBuf);
       CMCHKPK(cmPkTknStrOSXL, &param->sipVersion,mBuf);
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoStatusLine*/

/*
*
*    Fun:    cmPkSoRequest
*
*    Desc:    pack the structure SoRequest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRequest
(
SoRequest *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRequest(param ,mBuf)
SoRequest *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRequest)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoHeaderSeq(&param->request,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoRequestLine(&param->requestLine,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRequest*/

/*
*
*    Fun:    cmPkSoResponse
*
*    Desc:    pack the structure SoResponse
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoResponse
(
SoResponse *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoResponse(param ,mBuf)
SoResponse *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoResponse)

    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmPkSoHeaderSeq(&param->response,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmPkSoStatusLine(&param->statusLine,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoResponse*/
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    cmPkSoCLegInfo
*
*    Desc:    pack the structure SoCLegInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCLegInfo
(
SoCLegInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCLegInfo(param ,mBuf)
SoCLegInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoCLegInfo)

    CMCHKPK(SPkU8, param->cLegState,mBuf);
    CMCHKPK(SPkU32, param->cLegId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCLegInfo*/


/*
*
*    Fun:    cmPkSoAuditInfo
*
*    Desc:    pack the structure SoAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAuditInfo
(
SoAuditInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAuditInfo(param ,mBuf)
SoAuditInfo *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoAuditInfo)

    for (i=param->numCallLegs -1;i>=0;i--)
    {
       CMCHKPK(cmPkSoCLegInfo, &param->cLegInfo[i], mBuf);
    }
    CMCHKPK(SPkU16, param->numCallLegs,mBuf);
    CMCHKPK(SPkU8, param->sessionStartedBy,mBuf);
    CMCHKPK(cmPkTknStrOSXL, &param->callId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAuditInfo*/

/*
*
*    Fun:    cmPkSoSSapInfo
*
*    Desc:    pack the structure SoSSapInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSSapInfo
(
SoSSapInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSSapInfo(param ,mBuf)
SoSSapInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoSSapInfo)

    for (i=param->numCalls -1;i>=0;i--)
    {
       ret1 = cmPkSoAuditInfo(&param->callInfo[i],mBuf);
       if( ret1 != ROK)
       {
          RETVALUE( ret1 );
       }
    }
    CMCHKPK(SPkU16, param->numCalls,mBuf);
    CMCHKPK(SPkS16, param->spId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSSapInfo*/

/*
*
*    Fun:    cmPkSoAudit
*
*    Desc:    pack the structure SoAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAudit
(
SoAudit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAudit(param ,mBuf)
SoAudit *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAudit)

    switch( param->auditType )
    {
       case  SOT_AUDIT_CALL :
          ret1 = cmPkSoAuditInfo(&param->auditInfo.callInfo,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  SOT_AUDIT_SSAP :
          ret1 = cmPkSoSSapInfo(&param->auditInfo.ssapInfo,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU8, param->moreAudit,mBuf);
    CMCHKPK(SPkU8, param->auditType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAudit*/
#endif /* SO_UA */


/*
*
*    Fun:    cmPkSoRegRefreshInfo
*
*    Desc:    pack the structure SoRegRefreshInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRegRefreshInfo
(
SoRegRefreshInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRegRefreshInfo(param ,mBuf)
SoRegRefreshInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRegRefreshInfo)

    ret1 = cmPkSoAddrSpec(&param->regAddr,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkTknStrOSXL, &param->callId,mBuf);
    ret1 = cmPkSoAddress(&param->from,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkSoAddress(&param->to,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmPkSoContactItem(&param->contactItem,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoRegRefreshInfo*/

/*
*
*    Fun:    cmPkSoRefreshEvnt
*
*    Desc:    pack the structure SoRefreshEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRefreshEvnt
(
SoRefreshEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRefreshEvnt(param ,mBuf)
SoRefreshEvnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoRefreshEvnt)

    switch( param->type )
    {
       case  SOT_ET_REG_TMO :
          ret1 = cmPkSoRegRefreshInfo(&param->t.regInfo,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  SOT_ET_SUBSC_TMO :
#ifdef SO_EVENT
          CMCHKPK(cmPkTknStrOSXL, &param->t.subscId,mBuf);
#endif /*  SO_EVENT  */
          break;
       default:
          break;
    }
    CMCHKPK(SPkU8, param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRefreshEvnt*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmPkSoErrEvnt
*
*    Desc:    pack the structure SoErrEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoErrEvnt
(
SoErrEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoErrEvnt(param ,mBuf)
SoErrEvnt *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoErrEvnt)

#ifndef SO_REL_1_2_INF
#ifdef SO_EVENT
    switch( param->errCode )
    {
       case  SOT_ERR_REFER_TMO :
          CMCHKPK(cmPkTknStrOSXL, &param->t.referId,mBuf);
          break;
       case  SOT_ERR_SUBSC_TMO :
          CMCHKPK(cmPkTknStrOSXL, &param->t.subscId,mBuf);
          break;
       default:
          break;
    }
#endif /*  SO_EVENT  */
    CMCHKPK(SPkU8, param->callCleared,mBuf);
    CMCHKPK(SPkU8, param->eventType,mBuf);
#endif /*  SO_REL_1_2_INF  */
    CMCHKPK(SPkU16, param->errCode,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoErrEvnt*/


#ifndef CM_SDP_OPAQUE
/*
*
*    Fun:    cmPkSoSdpEvnt
*
*    Desc:    pack the structure SoSdpEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSdpEvnt
(
SoSdpEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSdpEvnt(param ,mBuf)
SoSdpEvnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoSdpEvnt)

    ret1 = cmPkCmSdpInfo(&param->sdp, 0 ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoSdpEvnt*/
#endif /* CM_SDP_OPAQUE */

/*
*
*    Fun:    cmPkSoBodySinglePart
*
*    Desc:    pack the structure SoBodySinglePart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoBodySinglePart
(
SoBodySinglePart *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoBodySinglePart(param ,mBuf)
SoBodySinglePart *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoBodySinglePart)

    if( param->bodySinglePartType.pres != NOTPRSNT )
    {
       switch( param->bodySinglePartType.val )
       {
          case  SOT_BODYSINGLEPART_SDP :
#ifndef CM_SDP_OPAQUE
             CMCHKPK(cmPkSoSdpEvnt,  (param->s.sdp), mBuf);
             cmFreeMem((Ptr)param->s.sdp);
#endif /* CM_SDP_OPAQUE */
             break;
          case  SOT_BODYSINGLEPART_STR :
             CMCHKPK(cmPkTknBuf, &param->s.str,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->bodySinglePartType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoBodySinglePart*/

/*
*
*    Fun:    cmPkSoBodyMultiPartElm
*
*    Desc:    pack the structure SoBodyMultiPartElm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoBodyMultiPartElm
(
SoBodyMultiPartElm *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoBodyMultiPartElm(param ,mBuf)
SoBodyMultiPartElm *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoBodyMultiPartElm)

    ret1 = cmPkSoBody( (param->body),mBuf);
    if(ret1 != ROK)
    {
       SPutMsg(mBuf );
       RETVALUE( ret1 );
    }
    ret1 = cmPkSoHeaderSeq(&param->hdrSeq,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoBodyMultiPartElm*/

/*
*
*    Fun:    cmPkSoBodyMultiPart
*
*    Desc:    pack the structure SoBodyMultiPart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoBodyMultiPart
(
SoBodyMultiPart *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoBodyMultiPart(param ,mBuf)
SoBodyMultiPart *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmPkSoBodyMultiPart)

    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=param->numComp.val-1;i>=0;i--)
       {
          ret1 = cmPkSoBodyMultiPartElm( (param->bodyElm[i]),mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf );
             RETVALUE( ret1 );
          }
       }
    }
    CMCHKPK(cmPkTknU16, &param->numComp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoBodyMultiPart*/

/*
*
*    Fun:    cmPkSoBody
*
*    Desc:    pack the structure SoBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoBody
(
SoBody *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoBody(param ,mBuf)
SoBody *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoBody)

    if( param->bodyType.pres != NOTPRSNT )
    {
       switch( param->bodyType.val )
       {
          case  SOT_BODYTYPE_MULTIPART :
             ret1 = cmPkSoBodyMultiPart(&param->u.multiPart,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SOT_BODYTYPE_SINGLEPART :
             ret1 = cmPkSoBodySinglePart(&param->u.singlePart,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->bodyType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoBody*/

/*
*
*    Fun:    cmPkSoEvnt
*
*    Desc:    pack the structure SoEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEvnt
(
SoEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEvnt(param ,mBuf)
SoEvnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoEvnt)

#ifdef SO_REPLACES
    CMCHKPK(SPkU32, param->rplcCLegId,mBuf);
    CMCHKPK(SPkU32, param->rplcSpConId,mBuf);
    CMCHKPK(SPkU32, param->rplcSuConId,mBuf);
#endif /*  SO_REPLACES  */

   /*- sot_c_001.main_10 : Packing/Unpacking for Lawful Call Intercept -*/
#ifdef SO_CALEA
    {
       TknBuf  tknBuf;

       CMCHKPK(SPkU32, param->messageId,mBuf);
       
       if (param->rawMsg != NULLP)
       {
            tknBuf.pres = PRSNT_NODEF;
            tknBuf.val  = param->rawMsg;
       }
       else
            tknBuf.pres = NOTPRSNT;
           
       CMCHKPK(cmPkTknBuf, &tknBuf, mBuf);
    }
#endif
    CMCHKPK(SPkU32, param->dstTranCb,mBuf);
    CMCHKPK(SPkU32, param->srcTranCb,mBuf);
    CMCHKPK(SPkU32, param->callLegId,mBuf);
    CMCHKPK(SPkU32, param->transId,mBuf);
    ret1 = cmPkSoBody(&param->sipBody,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    if( param->sipMessageType.pres != NOTPRSNT )
    {
       switch( param->sipMessageType.val )
       {
          case  SO_SIPMESSAGE_AUDIT :
#ifndef SO_REL_1_2_INF
#ifdef SO_UA
             ret1 = cmPkSoAudit(&param->t.auditEvnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /* SO_UA */
#endif /*  SO_REL_1_2_INF  */
             break;
          case  SO_SIPMESSAGE_ERROR :
             ret1 = cmPkSoErrEvnt(&param->t.errEvnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SIPMESSAGE_REFRESH :
#ifndef SO_REL_1_2_INF
             ret1 = cmPkSoRefreshEvnt(&param->t.refreshEvnt,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REL_1_2_INF  */
             break;
          case  SO_SIPMESSAGE_REQUEST :
             ret1 = cmPkSoRequest(&param->t.request,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SIPMESSAGE_RESPONSE :
             ret1 = cmPkSoResponse(&param->t.response,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(cmPkTknU8, &param->sipMessageType,mBuf);
    CMCHKPK(cmPkTknU8, &param->eventType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEvnt*/

/*
*
*    Fun:    cmPkSotBndReq
*
*    Desc:    pack the primitive SotBndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotBndReq
(
Pst *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 cmPkSotBndReq(pst, suId, spId)
Pst *pst;
SuId suId;
SpId spId;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotBndReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT001, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT002, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT003, pst);
    pst->event = (Event) EVTSOTBNDREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotBndReq*/

/*
*
*    Fun:    cmPkSotUbndReq
*
*    Desc:    pack the primitive SotUbndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotUbndReq
(
Pst *pst,
SpId spId,
Reason reason
)
#else
PUBLIC S16 cmPkSotUbndReq(pst, spId, reason)
Pst *pst;
SpId spId;
Reason reason;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotUbndReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT004, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(cmPkReason, reason, mBuf, ESOT005, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT006, pst);
    pst->event = (Event) EVTSOTUBNDREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotUbndReq*/

/*
*
*    Fun:    cmPkSotConReq
*
*    Desc:    pack the primitive SotConReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotConReq
(
Pst *pst,
SpId spId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotConReq(pst, spId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotConReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT007, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT008, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT009, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT010, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT011, pst);
    pst->event = (Event) EVTSOTCONREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotConReq*/

/*
*
*    Fun:    cmPkSotConRsp
*
*    Desc:    pack the primitive SotConRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotConRsp
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotConRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotConRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT012, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT013, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT014, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT015, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT016, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT017, pst);
    pst->event = (Event) EVTSOTCONRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotConRsp*/

/*
*
*    Fun:    cmPkSotCnStReq
*
*    Desc:    pack the primitive SotCnStReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCnStReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCnStReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCnStReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT018, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT019, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT020, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT021, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT022, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT023, pst);
    pst->event = (Event) EVTSOTCNSTREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCnStReq*/
#ifndef SO_REL_1_2_INF

/*
*
*    Fun:    cmPkSotAckReq
*
*    Desc:    pack the primitive SotAckReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotAckReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotAckReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotAckReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT024, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT025, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT026, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT027, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT028, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT029, pst);
    pst->event = (Event) EVTSOTACKREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotAckReq*/

/*
*
*    Fun:    cmPkSotCancelReq
*
*    Desc:    pack the primitive SotCancelReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCancelReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCancelReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCancelReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT030, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT031, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT032, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT033, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT034, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT035, pst);
    pst->event = (Event) EVTSOTCANCELREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCancelReq*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmPkSotRelReq
*
*    Desc:    pack the primitive SotRelReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRelReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotRelReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRelReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT036, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT037, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT038, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT039, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT040, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT041, pst);
    pst->event = (Event) EVTSOTRELREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotRelReq*/

/*
*
*    Fun:    cmPkSotRelRsp
*
*    Desc:    pack the primitive SotRelRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRelRsp
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotRelRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRelRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT042, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT043, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT044, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT045, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT046, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT047, pst);
    pst->event = (Event) EVTSOTRELRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotRelRsp*/

/*
*
*    Fun:    cmPkSotModReq
*
*    Desc:    pack the primitive SotModReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotModReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotModReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotModReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT048, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT049, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT050, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT051, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT052, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT053, pst);
    pst->event = (Event) EVTSOTMODREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotModReq*/

/*
*
*    Fun:    cmPkSotModRsp
*
*    Desc:    pack the primitive SotModRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotModRsp
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotModRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotModRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT054, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT055, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT056, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT057, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT058, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT059, pst);
    pst->event = (Event) EVTSOTMODRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotModRsp*/

/*
*
*    Fun:    cmPkSotCAMReq
*
*    Desc:    pack the primitive SotCAMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCAMReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCAMReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCAMReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT060, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT061, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT062, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT063, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT064, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT065, pst);
    pst->event = (Event) EVTSOTCAMREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCAMReq*/




/*- sot.c_001.main_10 : Packing/Unpacking for Lawful Call Intercept -*/
#ifdef SO_CALEA

/*
*
*    Fun:    cmPkSotRawMsg
*
*    Desc:    pack the primitive SotRawMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRawMsg
(
Pst *pst,
SpId suId,
UConnId suConnId,
UConnId spConnId,
U32 transId,
U32 callLegId,
U32 messageId,
U8 eventType,
U8 sipMessageType,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSotRawMsg(pst, suId, suConnId, spConnId, transId, callLegId, messageId, eventType, sipMessageType, mBuf)
Pst *pst;
SpId suId;
UConnId suConnId;
UConnId spConnId;
U32 transId;
U32 callLegId;
U32 messageId;
U8 eventType;
U8 sipMessageType;
Buffer *mBuf;
#endif
{
    S16 ret1;

    TRC3(cmPkSotRawMsg)

    if (mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
           if(ret1 != ROK)
           {
              SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                    __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                   (ErrVal)ESOT060, (ErrVal)0, "SGetMsg() failed");
           }
#endif
           RETVALUE(ret1);
       }
    }

    CMCHKPKLOG(SPkU8 , sipMessageType, mBuf, ESOT063, pst);
    CMCHKPKLOG(SPkU8 , eventType     , mBuf, ESOT064, pst);
    CMCHKPKLOG(SPkU32, messageId     , mBuf, ESOT065, pst);
    CMCHKPKLOG(SPkU32, callLegId     , mBuf, ESOT065, pst);
    CMCHKPKLOG(SPkU32, transId       , mBuf, ESOT065, pst);
    CMCHKPKLOG(SPkU32, spConnId      , mBuf, ESOT065, pst);
    CMCHKPKLOG(SPkU32, suConnId      , mBuf, ESOT065, pst);
    CMCHKPKLOG(SPkU16, suId          , mBuf, ESOT065, pst);

    pst->event = (Event) EVTSOTRAWMSG;

    RETVALUE(SPstTsk(pst,mBuf));

} /*end of function cmPkSotRawMsg*/

#endif








/*
*
*    Fun:    cmPkSotCAMRsp
*
*    Desc:    pack the primitive SotCAMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCAMRsp
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCAMRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCAMRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT066, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT067, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT068, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT069, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT070, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT071, pst);
    pst->event = (Event) EVTSOTCAMRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCAMRsp*/
#ifdef SO_REL_1_2_INF

/*
*
*    Fun:    cmPkSotCIMReq
*
*    Desc:    pack the primitive SotCIMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMReq
(
Pst *pst,
SpId spId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMReq(pst, spId, soEvnt)
Pst *pst;
SpId spId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT072, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT073, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT074, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT075, pst);
    pst->event = (Event) EVTSOTCIMREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCIMReq*/

/*
*
*    Fun:    cmPkSotCIMRsp
*
*    Desc:    pack the primitive SotCIMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMRsp
(
Pst *pst,
SpId spId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMRsp(pst, spId, soEvnt)
Pst *pst;
SpId spId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT076, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT077, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT078, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT079, pst);
    pst->event = (Event) EVTSOTCIMRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCIMRsp*/
#else

/*
*
*    Fun:    cmPkSotCIMReq
*
*    Desc:    pack the primitive SotCIMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMReq
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMReq(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT080, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT081, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT082, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT083, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT084, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT085, pst);
    pst->event = (Event) EVTSOTCIMREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCIMReq*/

/*
*
*    Fun:    cmPkSotCIMRsp
*
*    Desc:    pack the primitive SotCIMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMRsp
(
Pst *pst,
SpId spId,
UConnId spConnId,
UConnId suConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMRsp(pst, spId, spConnId, suConnId, soEvnt)
Pst *pst;
SpId spId;
UConnId spConnId;
UConnId suConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMRsp)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT086, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT087, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT088, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT089, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT090, pst);
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT091, pst);
    pst->event = (Event) EVTSOTCIMRSP;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotCIMRsp*/
#endif /* SO_REL_1_2_INF */
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    cmPkSotAuditReq
*
*    Desc:    pack the primitive SotAuditReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotAuditReq
(
Pst *pst,
SpId spId,
SoEvnt *evnt
)
#else
PUBLIC S16 cmPkSotAuditReq(pst, spId, evnt)
Pst *pst;
SpId spId;
SoEvnt *evnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotAuditReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT092, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          ret1 = cmPkSoEvnt( (evnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT093, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)evnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKPKLOG(cmPkPtr, (PTR)evnt, mBuf, ESOT094, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, spId, mBuf, ESOT095, pst);
    pst->event = (Event) EVTSOTAUDITREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkSotAuditReq*/
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmPkSotBndCfm
*
*    Desc:    pack the primitive SotBndCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotBndCfm
(
Pst *pst,
SuId suId,
U8 status
)
#else
PUBLIC S16 cmPkSotBndCfm(pst, suId, status)
Pst *pst;
SuId suId;
U8 status;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotBndCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT096, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    CMCHKPKLOG(SPkU8, status, mBuf, ESOT097, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT098, pst);
    pst->event = (Event) EVTSOTBNDCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotBndCfm*/

/*
*
*    Fun:    cmPkSotConInd
*
*    Desc:    pack the primitive SotConInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotConInd
(
Pst *pst,
SuId suId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotConInd(pst, suId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotConInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT099, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT100, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT101, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT102, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT103, pst);
    pst->event = (Event) EVTSOTCONIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
        ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotConInd*/

/*
*
*    Fun:    cmPkSotConCfm
*
*    Desc:    pack the primitive SotConCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotConCfm
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotConCfm(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotConCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT104, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT105, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT106, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT107, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT108, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT109, pst);
    pst->event = (Event) EVTSOTCONCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotConCfm*/

/*
*
*    Fun:    cmPkSotModInd
*
*    Desc:    pack the primitive SotModInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotModInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotModInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotModInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT110, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT111, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT112, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT113, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT114, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT115, pst);
    pst->event = (Event) EVTSOTMODIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotModInd*/

/*
*
*    Fun:    cmPkSotModCfm
*
*    Desc:    pack the primitive SotModCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotModCfm
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotModCfm(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotModCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT116, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT117, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT118, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT119, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT120, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT121, pst);
    pst->event = (Event) EVTSOTMODCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotModCfm*/

/*
*
*    Fun:    cmPkSotCnStInd
*
*    Desc:    pack the primitive SotCnStInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCnStInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCnStInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCnStInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT122, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT123, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT124, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT125, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT126, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT127, pst);
    pst->event = (Event) EVTSOTCNSTIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCnStInd*/

/*
*
*    Fun:    cmPkSotRelCfm
*
*    Desc:    pack the primitive SotRelCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRelCfm
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotRelCfm(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRelCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT128, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT129, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT130, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT131, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT132, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT133, pst);
    pst->event = (Event) EVTSOTRELCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotRelCfm*/

/*
*
*    Fun:    cmPkSotCAMCfm
*
*    Desc:    pack the primitive SotCAMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCAMCfm
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCAMCfm(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCAMCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT134, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT135, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT136, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT137, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT138, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT139, pst);
    pst->event = (Event) EVTSOTCAMCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCAMCfm*/

/*
*
*    Fun:    cmPkSotCAMInd
*
*    Desc:    pack the primitive SotCAMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCAMInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCAMInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCAMInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT140, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT141, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT142, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT143, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT144, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT145, pst);
    pst->event = (Event) EVTSOTCAMIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCAMInd*/
#ifdef SO_REL_1_2_INF

/*
*
*    Fun:    cmPkSotRelInd
*
*    Desc:    pack the primitive SotRelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRelInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
U8 relType,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotRelInd(pst, suId, suConnId, spConnId, relType, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
U8 relType;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRelInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT146, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT147, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT148, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU8, relType, mBuf, ESOT149, pst);
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT150, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT151, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT152, pst);
    pst->event = (Event) EVTSOTRELIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotRelInd*/

/*
*
*    Fun:    cmPkSotCIMInd
*
*    Desc:    pack the primitive SotCIMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMInd
(
Pst *pst,
SuId suId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMInd(pst, suId, soEvnt)
Pst *pst;
SuId suId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT153, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT154, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT155, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT156, pst);
    pst->event = (Event) EVTSOTCIMIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCIMInd*/

/*
*
*    Fun:    cmPkSotCIMCfm
*
*    Desc:    pack the primitive SotCIMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMCfm
(
Pst *pst,
SuId suId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMCfm(pst, suId, soEvnt)
Pst *pst;
SuId suId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT157, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT158, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT159, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT160, pst);
    pst->event = (Event) EVTSOTCIMCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCIMCfm*/
#else

/*
*
*    Fun:    cmPkSotRelInd
*
*    Desc:    pack the primitive SotRelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRelInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotRelInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRelInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT161, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT162, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT163, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT164, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT165, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT166, pst);
    pst->event = (Event) EVTSOTRELIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotRelInd*/

/*
*
*    Fun:    cmPkSotCIMInd
*
*    Desc:    pack the primitive SotCIMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT167, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT168, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT169, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT170, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT171, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT172, pst);
    pst->event = (Event) EVTSOTCIMIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCIMInd*/

/*
*
*    Fun:    cmPkSotCIMCfm
*
*    Desc:    pack the primitive SotCIMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCIMCfm
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCIMCfm(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCIMCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT173, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT174, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT175, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT176, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT177, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT178, pst);
    pst->event = (Event) EVTSOTCIMCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCIMCfm*/
#endif /* SO_REL_1_2_INF */
#ifndef SO_REL_1_2_INF

/*
*
*    Fun:    cmPkSotAckInd
*
*    Desc:    pack the primitive SotAckInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotAckInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotAckInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotAckInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT179, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT180, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT181, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT182, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT183, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT184, pst);
    pst->event = (Event) EVTSOTACKIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotAckInd*/

/*
*
*    Fun:    cmPkSotCancelInd
*
*    Desc:    pack the primitive SotCancelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotCancelInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotCancelInd(pst, suId, suConnId, spConnId, soEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotCancelInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT185, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT186, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT187, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT188, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT189, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT190, pst);
    pst->event = (Event) EVTSOTCANCELIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotCancelInd*/


#ifdef SO_UA
/*
*
*    Fun:    cmPkSotAuditCfm
*
*    Desc:    pack the primitive SotAuditCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotAuditCfm
(
Pst *pst,
SuId suId,
SoEvnt *soEvnt
)
#else
PUBLIC S16 cmPkSotAuditCfm(pst, suId, soEvnt)
Pst *pst;
SuId suId;
SoEvnt *soEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotAuditCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT191, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (soEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT192, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)soEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)soEvnt, mBuf, ESOT193, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT194, pst);
    pst->event = (Event) EVTSOTAUDITCFM;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotAuditCfm*/
#endif /* SO_UA */


/*
*
*    Fun:    cmPkSotErrInd
*
*    Desc:    pack the primitive SotErrInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotErrInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *errEvnt
)
#else
PUBLIC S16 cmPkSotErrInd(pst, suId, suConnId, spConnId, errEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *errEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotErrInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT195, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (errEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT196, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)errEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)errEvnt, mBuf, ESOT197, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT198, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT199, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT200, pst);
    pst->event = (Event) EVTSOTERRIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotErrInd*/

/*
*
*    Fun:    cmPkSotRefreshInd
*
*    Desc:    pack the primitive SotRefreshInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSotRefreshInd
(
Pst *pst,
SuId suId,
UConnId suConnId,
UConnId spConnId,
SoEvnt *refreshEvnt
)
#else
PUBLIC S16 cmPkSotRefreshInd(pst, suId, suConnId, spConnId, refreshEvnt)
Pst *pst;
SuId suId;
UConnId suConnId;
UConnId spConnId;
SoEvnt *refreshEvnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkSotRefreshInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ESOT201, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
       case SO_SSAP_LC_SS:
          ret1 = cmPkSoEvnt( (refreshEvnt),mBuf);
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ESOT202, (ErrVal)ret1, "Packing failure");
             RETVALUE( ret1 );
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          cmFreeMem((Ptr)refreshEvnt);
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
       case  SO_SSAP_LWLC_SS:
          CMCHKPKLOG(cmPkPtr, (PTR)refreshEvnt, mBuf, ESOT203, pst); 
       break;
#endif /* LWLCSOT */
    }
    CMCHKPKLOG(SPkU32, spConnId, mBuf, ESOT204, pst);
    CMCHKPKLOG(SPkU32, suConnId, mBuf, ESOT205, pst);
    CMCHKPKLOG(SPkS16, suId, mBuf, ESOT206, pst);
    pst->event = (Event) EVTSOTREFRESHIND;

	/*POST_VIA_SELECTOR*/
	switch(pst->selector)
	{
	case SO_SSAP_LC:
	case SO_SSAP_LWLC:
		ret1 = SPstTsk(pst,mBuf);
		break;
#ifdef CP_UA_IF_TYPE_SS
	case SO_SSAP_LC_SS:
	case SO_SSAP_LWLC_SS:
		XosToFrameCallBack(g_sipUaModId, pst, mBuf);
		ret1 = ROK;
		break;
#endif /* CP_UA_IF_TYPE_SS */
	default:
		SLogError(pst->srcEnt, pst->srcInst,pst->selector,
                __FILE__, __LINE__, (ErrCls)ERRCLS_INT_PAR,
               (ErrVal)ESOT030, (ErrVal)0, "selector failed");
		ret1 = RFAILED;
		break;
	}

	RETVALUE(ret1);
} /*end of function cmPkSotRefreshInd*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmUnpkSoIpv4Address
*
*    Desc:    unpack the structure soIpv4Address
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoIpv4Address
(
SoIpv4Address *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoIpv4Address(param ,mBuf)
SoIpv4Address *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoIpv4Address)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->adr1,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->adr2,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->adr3,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->adr4,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoIpv4Address*/

/*
*
*    Fun:    cmUnpkSoTransportParam
*
*    Desc:    unpack the structure SoTransportParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTransportParam
(
SoTransportParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTransportParam(param ,ptr, mBuf)
SoTransportParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTransportParam)

    CMCHKUNPK(cmUnpkTknU8, &param->transportParamType,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->otherTransport, ptr, mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTransportParam*/

/*
*
*    Fun:    cmUnpkSoUserParam
*
*    Desc:    unpack the structure SoUserParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUserParam
(
SoUserParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUserParam(param ,ptr, mBuf)
SoUserParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUserParam)

    CMCHKUNPK(cmUnpkTknU8, &param->userParamType,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->otherUser, ptr, mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUserParam*/

/*
*
*    Fun:    cmUnpkSoExtVal
*
*    Desc:    unpack the structure SoExtVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoExtVal
(
SoExtVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoExtVal(param ,ptr, mBuf)
SoExtVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoExtVal)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_EXTVAL_NONSTD :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.ext, ptr, mBuf);
             break;
          case  SO_EXTVAL_STD :
             CMCHKUNPK(cmUnpkTknU8, &param->t.std,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoExtVal*/

/*
*
*    Fun:    cmUnpkSoNameVal
*
*    Desc:    unpack the structure SoNameVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNameVal
(
SoNameVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNameVal(param ,ptr, mBuf)
SoNameVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoNameVal)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->name, ptr, mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->value, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoNameVal*/

/*
*
*    Fun:    cmUnpkSoHost
*
*    Desc:    unpack the structure SoHost
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHost
(
SoHost *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHost(param ,ptr, mBuf)
SoHost *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoHost)

    CMCHKUNPK(cmUnpkTknU8, &param->hostType,mBuf);
    if( param->hostType.pres != NOTPRSNT )
    {
       switch( param->hostType.val )
       {
          case  SO_HOST_HOSTNAME :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.hostName, ptr, mBuf);
             break;
          case  SO_HOST_IPV4ADDRESS :
             CMCHKUNPK(cmUnpkSoIpv4Address, &param->t.ipv4Address,mBuf);
             break;
          case  SO_HOST_IPV6REFERENCE :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.ipv6Reference, ptr, mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHost*/

/*
*
*    Fun:    cmUnpkSoSipDate
*
*    Desc:    unpack the structure soSipDate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSipDate
(
SoSipDate *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSipDate(param ,mBuf)
SoSipDate *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSipDate)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->wkDay,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->day,mBuf);
       CMCHKUNPK(cmUnpkTknU8, &param->month,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->year,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->hr,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->mn,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->sec,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSipDate*/

/*
*
*    Fun:    cmUnpkSoUrlParameter
*
*    Desc:    unpack the structure SoUrlParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUrlParameter
(
SoUrlParameter *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUrlParameter(param ,ptr, mBuf)
SoUrlParameter *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoUrlParameter)

    CMCHKUNPK(cmUnpkTknU8, &param->urlParameterType,mBuf);
    if( param->urlParameterType.pres != NOTPRSNT )
    {
       switch( param->urlParameterType.val )
       {
          case  SO_URLPARAMETER_COMP :
             ret1 = cmUnpkSoStrValue(&param->t.comp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_ISUB :
#ifdef SO_ENUM
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.isub, ptr, mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_LRPARAM :
             break;
          case  SO_URLPARAMETER_MADDRHOST :
             ret1 = cmUnpkSoHost(&param->t.maddrHost, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_METHOD :
             ret1 = cmUnpkSoExtVal(&param->t.method, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_OTHERPARAM :
             ret1 = cmUnpkSoNameVal(&param->t.otherParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_PHONECONTEXT :
#ifdef SO_ENUM
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.phoneContext, ptr, mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_POSTD :
#ifdef SO_ENUM
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.postd, ptr, mBuf);
#endif /*  SO_ENUM  */
             break;
          case  SO_URLPARAMETER_TRANSPORTPARAM :
             ret1 = cmUnpkSoTransportParam(&param->t.transportParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_URLPARAMETER_TSPDOMAIN :
#ifdef SO_PINT
             ret1 = cmUnpkSoHost(&param->t.tspDomain, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_PINT  */
             break;
          case  SO_URLPARAMETER_TTLPARAM :
             CMCHKUNPK(cmUnpkTknU16, &param->t.ttlParam,mBuf);
             break;
          case  SO_URLPARAMETER_USERPARAM :
             ret1 = cmUnpkSoUserParam(&param->t.userParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoUrlParameter*/

/*
*
*    Fun:    cmUnpkSoHeaderExt
*
*    Desc:    unpack the structure SoHeaderExt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHeaderExt
(
SoHeaderExt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHeaderExt(param ,ptr, mBuf)
SoHeaderExt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoHeaderExt)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->header));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoNameVal), (Ptr*)&(param->header[i]));
          ret1 = cmUnpkSoNameVal( (param->header[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHeaderExt*/

/*
*
*    Fun:    cmUnpkSoQValue
*
*    Desc:    unpack the structure soQValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoQValue
(
SoQValue *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoQValue(param ,mBuf)
SoQValue *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoQValue)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->qVInt,mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->qVFrac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoQValue*/

/*
*
*    Fun:    cmUnpkSoStrValue
*
*    Desc:    unpack the structure SoStrValue
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoStrValue
(
SoStrValue *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoStrValue(param ,ptr, mBuf)
SoStrValue *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoStrValue)

    CMCHKUNPK(cmUnpkTknU8, &param->valueType,mBuf);
    if( param->valueType.pres != NOTPRSNT )
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->value, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoStrValue*/

/*
*
*    Fun:    cmUnpkSoUserInfo
*
*    Desc:    unpack the structure SoUserInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUserInfo
(
SoUserInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUserInfo(param ,ptr, mBuf)
SoUserInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoUserInfo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStrValue(&param->userType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->password, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoUserInfo*/

/*
*
*    Fun:    cmUnpkSoHeaders
*
*    Desc:    unpack the structure SoHeaders
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHeaders
(
SoHeaders *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHeaders(param ,ptr, mBuf)
SoHeaders *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoHeaders)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoNameVal(&param->header, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHeaderExt(&param->headerExt, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHeaders*/

/*
*
*    Fun:    cmUnpkSoTknStrOSXLLst
*
*    Desc:    unpack the structure SoTknStrOSXLLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTknStrOSXLLst
(
SoTknStrOSXLLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTknStrOSXLLst(param ,ptr, mBuf)
SoTknStrOSXLLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoTknStrOSXLLst)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->stringList));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(TknStrOSXL), (Ptr*)&(param->stringList[i]));
          CMCHKUNPKPTR(cmUnpkTknStrOSXL,  (param->stringList[i]), ptr, mBuf);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTknStrOSXLLst*/

/*
*
*    Fun:    cmUnpkSoHostPort
*
*    Desc:    unpack the structure SoHostPort
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHostPort
(
SoHostPort *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHostPort(param ,ptr, mBuf)
SoHostPort *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoHostPort)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoHost(&param->host, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPK(cmUnpkTknU32, &param->port,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHostPort*/

/*
*
*    Fun:    cmUnpkSoUrlParameters
*
*    Desc:    unpack the structure SoUrlParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUrlParameters
(
SoUrlParameters *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUrlParameters(param ,ptr, mBuf)
SoUrlParameters *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoUrlParameters)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->urlParameter));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoUrlParameter), (Ptr*)&(param->urlParameter[i]));
          ret1 = cmUnpkSoUrlParameter( (param->urlParameter[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoUrlParameters*/

/*
*
*    Fun:    cmUnpkSoParameter
*
*    Desc:    unpack the structure SoParameter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoParameter
(
SoParameter *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoParameter(param ,ptr, mBuf)
SoParameter *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoParameter)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->token, ptr, mBuf);
       ret1 = cmUnpkSoStrValue(&param->paramVal, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoParameter*/

/*
*
*    Fun:    cmUnpkSoDateTime
*
*    Desc:    unpack the structure soDateTime
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDateTime
(
SoDateTime *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDateTime(param ,mBuf)
SoDateTime *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoDateTime)

    CMCHKUNPK(cmUnpkTknU8, &param->dateTimeType,mBuf);
    if( param->dateTimeType.pres != NOTPRSNT )
    {
       switch( param->dateTimeType.val )
       {
          case  SO_DATETIME_DELTASECONDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.deltaSeconds,mBuf);
             break;
          case  SO_DATETIME_SIPDATE :
             CMCHKUNPK(cmUnpkSoSipDate, &param->t.sipDate,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoDateTime*/

/*
*
*    Fun:    cmUnpkSoTypeSub
*
*    Desc:    unpack the structure SoTypeSub
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTypeSub
(
SoTypeSub *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTypeSub(param ,ptr, mBuf)
SoTypeSub *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTypeSub)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->type, ptr, mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->subType, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTypeSub*/

/*
*
*    Fun:    cmUnpkSoMediaRangeVal
*
*    Desc:    unpack the structure SoMediaRangeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMediaRangeVal
(
SoMediaRangeVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMediaRangeVal(param ,ptr, mBuf)
SoMediaRangeVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoMediaRangeVal)

    CMCHKUNPK(cmUnpkTknU8, &param->mediaRangeValType,mBuf);
    if( param->mediaRangeValType.pres != NOTPRSNT )
    {
       switch( param->mediaRangeValType.val )
       {
          case  SO_MEDIARANGEVAL_ALLSTAR :
             break;
          case  SO_MEDIARANGEVAL_TYPESTAR :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.typeStar, ptr, mBuf);
             break;
          case  SO_MEDIARANGEVAL_TYPESUB :
             ret1 = cmUnpkSoTypeSub(&param->t.typeSub, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMediaRangeVal*/


/*
*
*    Fun:    cmUnpkSoContactParamStd
*
*    Desc:    unpack the structure soContactParamStd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContactParamStd
(
SoContactParamStd *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContactParamStd(param ,mBuf)
SoContactParamStd *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoContactParamStd)

    CMCHKUNPK(cmUnpkTknU8, &param->contactParamStdType,mBuf);
    if( param->contactParamStdType.pres != NOTPRSNT )
    {
       switch( param->contactParamStdType.val )
       {
          case  SO_CONTACTPARAMSTD_ACTION :
             CMCHKUNPK(cmUnpkTknU8, &param->t.action,mBuf);
             break;
          case  SO_CONTACTPARAMSTD_EXPIRES :
             CMCHKUNPK(cmUnpkTknU32, &param->t.contactParExpires,mBuf);
             break;
          case  SO_CONTACTPARAMSTD_Q :
             CMCHKUNPK(cmUnpkSoQValue, &param->t.qValue,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContactParamStd*/

/*
*
*    Fun:    cmUnpkSoCallInfoPurpose
*
*    Desc:    unpack the structure SoCallInfoPurpose
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCallInfoPurpose
(
SoCallInfoPurpose *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCallInfoPurpose(param ,ptr, mBuf)
SoCallInfoPurpose *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoCallInfoPurpose)

    CMCHKUNPK(cmUnpkTknU8, &param->callInfoPurposeType,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->purposeExt, ptr, mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoCallInfoPurpose*/

/*
*
*    Fun:    cmUnpkSoSubscExpReason
*
*    Desc:    unpack the structure SoSubscExpReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSubscExpReason
(
SoSubscExpReason *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSubscExpReason(param ,ptr, mBuf)
SoSubscExpReason *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSubscExpReason)

    CMCHKUNPK(cmUnpkTknU8, &param->subscExpReasonType,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->subscExpReasonExt, ptr, mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoSubscExpReason*/

/*
*
*    Fun:    cmUnpkSoDisplayName
*
*    Desc:    unpack the structure SoDisplayName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDisplayName
(
SoDisplayName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDisplayName(param ,ptr, mBuf)
SoDisplayName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoDisplayName)

    CMCHKUNPK(cmUnpkTknU8, &param->displayNameType,mBuf);
    if( param->displayNameType.pres != NOTPRSNT )
    {
       switch( param->displayNameType.val )
       {
          case  SO_PARAMVAL_QUOTEDSTR :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.quotedStr, ptr, mBuf);
             break;
          case  SO_PARAMVAL_TOKEN :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.displayNameRep, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoDisplayName*/

/*
*
*    Fun:    cmUnpkSoAbsoluteUri
*
*    Desc:    unpack the structure SoAbsoluteUri
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAbsoluteUri
(
SoAbsoluteUri *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAbsoluteUri(param ,ptr, mBuf)
SoAbsoluteUri *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoAbsoluteUri)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->scheme, ptr, mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->absUriDesc, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAbsoluteUri*/
#ifdef SO_ENUM

/*
*
*    Fun:    cmUnpkSoTelNumPar
*
*    Desc:    unpack the structure SoTelNumPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTelNumPar
(
SoTelNumPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTelNumPar(param ,ptr, mBuf)
SoTelNumPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoTelNumPar)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_TEL_CIC :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.cic, ptr, mBuf);
             break;
          case  SO_TEL_EXTN :
             ret1 = cmUnpkSoParameter(&param->t.extn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_TEL_ISUB :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.isub, ptr, mBuf);
             break;
          case  SO_TEL_PHONE_CONTEXT :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.phCntxt, ptr, mBuf);
             break;
          case  SO_TEL_POSTD :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.postd, ptr, mBuf);
             break;
          case  SO_TEL_RN :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.rn, ptr, mBuf);
             break;
          case  SO_TEL_TSP :
             ret1 = cmUnpkSoHost(&param->t.tsp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTelNumPar*/

/*
*
*    Fun:    cmUnpkSoTelNumPars
*
*    Desc:    unpack the structure SoTelNumPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTelNumPars
(
SoTelNumPars *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTelNumPars(param ,ptr, mBuf)
SoTelNumPars *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoTelNumPars)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->par));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoTelNumPar), (Ptr*)&(param->par[i]));
          ret1 = cmUnpkSoTelNumPar( (param->par[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTelNumPars*/

/*
*
*    Fun:    cmUnpkSoTelUrl
*
*    Desc:    unpack the structure SoTelUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTelUrl
(
SoTelUrl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTelUrl(param ,ptr, mBuf)
SoTelUrl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoTelUrl)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->digits, ptr, mBuf);
    ret1 = cmUnpkSoTelNumPars(&param->pars, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTelUrl*/
#endif /* SO_ENUM */

/*
*
*    Fun:    cmUnpkSoPriority
*
*    Desc:    unpack the structure SoPriority
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoPriority
(
SoPriority *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoPriority(param ,ptr, mBuf)
SoPriority *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoPriority)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->priorityType,mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->otherPriority, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoPriority*/

/*
*
*    Fun:    cmUnpkSoSipUrl
*
*    Desc:    unpack the structure SoSipUrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSipUrl
(
SoSipUrl *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSipUrl(param ,ptr, mBuf)
SoSipUrl *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSipUrl)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoUserInfo(&param->userInfo, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHostPort(&param->hostPort, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoUrlParameters(&param->urlParameters, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHeaders(&param->headers, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSipUrl*/

/*
*
*    Fun:    cmUnpkSoAddrSpec
*
*    Desc:    unpack the structure SoAddrSpec
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAddrSpec
(
SoAddrSpec *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAddrSpec(param ,ptr, mBuf)
SoAddrSpec *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAddrSpec)

    CMCHKUNPK(cmUnpkTknU8, &param->addrSpecType,mBuf);
    if( param->addrSpecType.pres != NOTPRSNT )
    {
       switch( param->addrSpecType.val )
       {
          case  SO_ADDRSPEC_ABSOLUTEURI :
             ret1 = cmUnpkSoAbsoluteUri(&param->t.absoluteUri, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRSPEC_IMURL :
#ifdef SO_INSTMSG
             ret1 = cmUnpkSoSipUrl(&param->t.imUrl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_INSTMSG  */
             break;
          case  SO_ADDRSPEC_SIPSURL :
#ifdef SO_TLS
             ret1 = cmUnpkSoSipUrl(&param->t.sipsUrl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_TLS  */
             break;
          case  SO_ADDRSPEC_SIPURL :
             ret1 = cmUnpkSoSipUrl(&param->t.sipUrl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRSPEC_TELURL :
#ifdef SO_ENUM
             ret1 = cmUnpkSoTelUrl(&param->t.telUrl, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_ENUM  */
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAddrSpec*/

/*
*
*    Fun:    cmUnpkSoContactParam
*
*    Desc:    unpack the structure SoContactParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContactParam
(
SoContactParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContactParam(param ,ptr, mBuf)
SoContactParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoContactParam)

    CMCHKUNPK(cmUnpkTknU8, &param->contactParamType,mBuf);
    if( param->contactParamType.pres != NOTPRSNT )
    {
       switch( param->contactParamType.val )
       {
          case  SO_CONTACTPARAM_EXTN :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_CONTACTPARAM_FEAT :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoStrValue(&param->t.fparam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_CONTACTPARAM_STD :
             CMCHKUNPK(cmUnpkSoContactParamStd, &param->t.contactParamStd,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContactParam*/

/*
*
*    Fun:    cmUnpkSoInfoParam
*
*    Desc:    unpack the structure SoInfoParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoInfoParam
(
SoInfoParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoInfoParam(param ,ptr, mBuf)
SoInfoParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoInfoParam)

    CMCHKUNPK(cmUnpkTknU8, &param->infoParamType,mBuf);
    if( param->infoParamType.pres != NOTPRSNT )
    {
       switch( param->infoParamType.val )
       {
          case  SO_INFOPARAM_EXTN :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_INFOPARAM_PURPOSE :
             ret1 = cmUnpkSoCallInfoPurpose(&param->t.callInfoPurpose, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoInfoParam*/

/*
*
*    Fun:    cmUnpkSoNameAddr
*
*    Desc:    unpack the structure SoNameAddr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNameAddr
(
SoNameAddr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNameAddr(param ,ptr, mBuf)
SoNameAddr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoNameAddr)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoDisplayName(&param->displayName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoAddrSpec(&param->addrSpec, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoNameAddr*/

/*
*
*    Fun:    cmUnpkSoContactParams
*
*    Desc:    unpack the structure SoContactParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContactParams
(
SoContactParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContactParams(param ,ptr, mBuf)
SoContactParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoContactParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->contactParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoContactParam), (Ptr*)&(param->contactParam[i]));
          ret1 = cmUnpkSoContactParam( (param->contactParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContactParams*/

/*
*
*    Fun:    cmUnpkSoViaParam
*
*    Desc:    unpack the structure SoViaParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoViaParam
(
SoViaParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoViaParam(param ,ptr, mBuf)
SoViaParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoViaParam)

    CMCHKUNPK(cmUnpkTknU8, &param->viaParamType,mBuf);
    if( param->viaParamType.pres != NOTPRSNT )
    {
       switch( param->viaParamType.val )
       {
          case  SO_VIAPARAM_GENERICPARAM :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_MADDR :
             ret1 = cmUnpkSoHost(&param->t.maddr, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_RECEIVED :
             ret1 = cmUnpkSoHost(&param->t.received, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_VIABRANCH :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.viaBranch, ptr, mBuf);
             break;
          case  SO_VIAPARAM_VIACOMP :
             ret1 = cmUnpkSoStrValue(&param->t.comp, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_VIAPARAM_VIARPORT :
#ifdef SO_NAT
             CMCHKUNPK(cmUnpkTknU32, &param->t.viaRport,mBuf);
#endif /*  SO_NAT  */
             break;
          case  SO_VIAPARAM_VIATTL :
             CMCHKUNPK(cmUnpkTknU16, &param->t.viaTtl,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoViaParam*/

/*
*
*    Fun:    cmUnpkSoParameters
*
*    Desc:    unpack the structure SoParameters
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoParameters
(
SoParameters *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoParameters(param ,ptr, mBuf)
SoParameters *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoParameters)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->parameter));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoParameter), (Ptr*)&(param->parameter[i]));
          ret1 = cmUnpkSoParameter( (param->parameter[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoParameters*/

/*
*
*    Fun:    cmUnpkSoProtocolName
*
*    Desc:    unpack the structure SoProtocolName
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoProtocolName
(
SoProtocolName *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoProtocolName(param ,ptr, mBuf)
SoProtocolName *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoProtocolName)

    CMCHKUNPK(cmUnpkTknU8, &param->protocolNameType,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->protocolExt, ptr, mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoProtocolName*/

/*
*
*    Fun:    cmUnpkSoMediaRange
*
*    Desc:    unpack the structure SoMediaRange
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMediaRange
(
SoMediaRange *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMediaRange(param ,ptr, mBuf)
SoMediaRange *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoMediaRange)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoMediaRangeVal(&param->mediaRangeVal, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->parameters, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMediaRange*/

/*
*
*    Fun:    cmUnpkSoCodings
*
*    Desc:    unpack the structure SoCodings
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCodings
(
SoCodings *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCodings(param ,ptr, mBuf)
SoCodings *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoCodings)

    CMCHKUNPK(cmUnpkTknU8, &param->codingsType,mBuf);
    ret1 = cmUnpkSoExtVal(&param->contentCoding, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCodings*/

/*
*
*    Fun:    cmUnpkSoInfoParams
*
*    Desc:    unpack the structure SoInfoParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoInfoParams
(
SoInfoParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoInfoParams(param ,ptr, mBuf)
SoInfoParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoInfoParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->infoParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoInfoParam), (Ptr*)&(param->infoParam[i]));
          ret1 = cmUnpkSoInfoParam( (param->infoParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoInfoParams*/

/*
*
*    Fun:    cmUnpkSoAddrCh
*
*    Desc:    unpack the structure SoAddrCh
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAddrCh
(
SoAddrCh *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAddrCh(param ,ptr, mBuf)
SoAddrCh *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAddrCh)

    CMCHKUNPK(cmUnpkTknU8, &param->addrChType,mBuf);
    if( param->addrChType.pres != NOTPRSNT )
    {
       switch( param->addrChType.val )
       {
          case  SO_ADDRCH_ADDRSPEC :
             ret1 = cmUnpkSoAddrSpec(&param->t.addrSpec, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRCH_NAMEADDR :
             ret1 = cmUnpkSoNameAddr(&param->t.nameAddr, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAddrCh*/

/*
*
*    Fun:    cmUnpkSoContactItem
*
*    Desc:    unpack the structure SoContactItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContactItem
(
SoContactItem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContactItem(param ,ptr, mBuf)
SoContactItem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoContactItem)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAddrCh(&param->contactAddrChoice, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoContactParams(&param->contactParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContactItem*/

/*
*
*    Fun:    cmUnpkSoAddrParam
*
*    Desc:    unpack the structure SoAddrParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAddrParam
(
SoAddrParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAddrParam(param ,ptr, mBuf)
SoAddrParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAddrParam)

    CMCHKUNPK(cmUnpkTknU8, &param->addrParamType,mBuf);
    if( param->addrParamType.pres != NOTPRSNT )
    {
       switch( param->addrParamType.val )
       {
          case  SO_ADDRPARAM_GENERICPARAM :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ADDRPARAM_TAGPARAM :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.tagParam, ptr, mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAddrParam*/

/*
*
*    Fun:    cmUnpkSoAlso
*
*    Desc:    unpack the structure SoAlso
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAlso
(
SoAlso *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAlso(param ,ptr, mBuf)
SoAlso *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAlso)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->addrChoice));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAddrCh), (Ptr*)&(param->addrChoice[i]));
          ret1 = cmUnpkSoAddrCh( (param->addrChoice[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAlso*/

/*
*
*    Fun:    cmUnpkSoSentProtocol
*
*    Desc:    unpack the structure SoSentProtocol
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSentProtocol
(
SoSentProtocol *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSentProtocol(param ,ptr, mBuf)
SoSentProtocol *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSentProtocol)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoProtocolName(&param->protocolName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->protocolVersion, ptr, mBuf);
       ret1 = cmUnpkSoExtVal(&param->transport, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSentProtocol*/

/*
*
*    Fun:    cmUnpkSoHostPortType
*
*    Desc:    unpack the structure SoHostPortType
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHostPortType
(
SoHostPortType *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHostPortType(param ,ptr, mBuf)
SoHostPortType *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoHostPortType)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_HOSTPORTTYPE_HOST :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.host, ptr, mBuf);
             break;
          case  SO_HOSTPORTTYPE_HOSTPORT :
             ret1 = cmUnpkSoHostPort(&param->t.hostPort, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHostPortType*/

/*
*
*    Fun:    cmUnpkSoViaParams
*
*    Desc:    unpack the structure SoViaParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoViaParams
(
SoViaParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoViaParams(param ,ptr, mBuf)
SoViaParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoViaParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->viaParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoViaParam), (Ptr*)&(param->viaParam[i]));
          ret1 = cmUnpkSoViaParam( (param->viaParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoViaParams*/

/*
*
*    Fun:    cmUnpkSoRetryParam
*
*    Desc:    unpack the structure SoRetryParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRetryParam
(
SoRetryParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRetryParam(param ,ptr, mBuf)
SoRetryParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRetryParam)

    CMCHKUNPK(cmUnpkTknU8, &param->retryParamType,mBuf);
    if( param->retryParamType.pres != NOTPRSNT )
    {
       switch( param->retryParamType.val )
       {
          case  SO_RETRYPARAM_DURATION :
             CMCHKUNPK(cmUnpkTknU32, &param->t.retryDuration,mBuf);
             break;
          case  SO_RETRYPARAM_EXTN :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRetryParam*/

/*
*
*    Fun:    cmUnpkSoAcceptParam
*
*    Desc:    unpack the structure SoAcceptParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptParam
(
SoAcceptParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptParam(param ,ptr, mBuf)
SoAcceptParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcceptParam)

    CMCHKUNPK(cmUnpkTknU8, &param->prodcomType,mBuf);
    if( param->prodcomType.pres != NOTPRSNT )
    {
       switch( param->prodcomType.val )
       {
          case  SO_GENERIC_PARAM_TYPE :
             ret1 = cmUnpkSoParameter(&param->u.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_QVALUE_TYPE :
             CMCHKUNPK(cmUnpkSoQValue, &param->u.qValue,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptParam*/

/*
*
*    Fun:    cmUnpkSoAcceptParams
*
*    Desc:    unpack the structure SoAcceptParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptParams
(
SoAcceptParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptParams(param ,ptr, mBuf)
SoAcceptParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAcceptParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->ap));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcceptParam), (Ptr*)&(param->ap[i]));
          ret1 = cmUnpkSoAcceptParam( (param->ap[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptParams*/

/*
*
*    Fun:    cmUnpkSoAcceptSeq
*
*    Desc:    unpack the structure SoAcceptSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptSeq
(
SoAcceptSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptSeq(param ,ptr, mBuf)
SoAcceptSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcceptSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoMediaRange(&param->mediaRange, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoAcceptParams(&param->acceptParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptSeq*/

/*
*
*    Fun:    cmUnpkSoAcceptEncodingSeq
*
*    Desc:    unpack the structure SoAcceptEncodingSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptEncodingSeq
(
SoAcceptEncodingSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptEncodingSeq(param ,ptr, mBuf)
SoAcceptEncodingSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcceptEncodingSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoCodings(&param->codings, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoAcceptParams(&param->apList, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptEncodingSeq*/

/*
*
*    Fun:    cmUnpkSoAcceptLanguageSeq
*
*    Desc:    unpack the structure SoAcceptLanguageSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptLanguageSeq
(
SoAcceptLanguageSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptLanguageSeq(param ,ptr, mBuf)
SoAcceptLanguageSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcceptLanguageSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->languageRange, ptr, mBuf);
       ret1 = cmUnpkSoAcceptParams(&param->acceptParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptLanguageSeq*/

/*
*
*    Fun:    cmUnpkSoContactItems
*
*    Desc:    unpack the structure SoContactItems
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContactItems
(
SoContactItems *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContactItems(param ,ptr, mBuf)
SoContactItems *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoContactItems)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->contactItem));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoContactItem), (Ptr*)&(param->contactItem[i]));
          ret1 = cmUnpkSoContactItem( (param->contactItem[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContactItems*/

/*
*
*    Fun:    cmUnpkSoProdcom
*
*    Desc:    unpack the structure SoProdcom
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoProdcom
(
SoProdcom *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoProdcom(param ,ptr, mBuf)
SoProdcom *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoProdcom)

    CMCHKUNPK(cmUnpkTknU8, &param->prodcomType,mBuf);
    if( param->prodcomType.pres != NOTPRSNT )
    {
       switch( param->prodcomType.val )
       {
          case  SO_PRODCOM_COMMENT :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.comment, ptr, mBuf);
             break;
          case  SO_PRODCOM_PRODUCT :
             ret1 = cmUnpkSoNameVal(&param->t.product, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoProdcom*/

/*
*
*    Fun:    cmUnpkSoViaItem
*
*    Desc:    unpack the structure SoViaItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoViaItem
(
SoViaItem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoViaItem(param ,ptr, mBuf)
SoViaItem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoViaItem)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoSentProtocol(&param->sentProtocol, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHostPortType(&param->sentBy, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoViaParams(&param->viaParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->viaComment, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoViaItem*/

/*
*
*    Fun:    cmUnpkSoRouteSeq
*
*    Desc:    unpack the structure SoRouteSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRouteSeq
(
SoRouteSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRouteSeq(param ,ptr, mBuf)
SoRouteSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRouteSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoNameAddr(&param->nameAddr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->rParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRouteSeq*/

/*
*
*    Fun:    cmUnpkSoWarningItem
*
*    Desc:    unpack the structure SoWarningItem
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoWarningItem
(
SoWarningItem *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoWarningItem(param ,ptr, mBuf)
SoWarningItem *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoWarningItem)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU16, &param->warnCode,mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->warnAgent, ptr, mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->warnText, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoWarningItem*/

/*
*
*    Fun:    cmUnpkSoAccept
*
*    Desc:    unpack the structure SoAccept
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAccept
(
SoAccept *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAccept(param ,ptr, mBuf)
SoAccept *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAccept)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->accept));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcceptSeq), (Ptr*)&(param->accept[i]));
          ret1 = cmUnpkSoAcceptSeq( (param->accept[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAccept*/

/*
*
*    Fun:    cmUnpkSoAcceptEncoding
*
*    Desc:    unpack the structure SoAcceptEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptEncoding
(
SoAcceptEncoding *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptEncoding(param ,ptr, mBuf)
SoAcceptEncoding *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAcceptEncoding)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->acceptEncoding));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcceptEncodingSeq), (Ptr*)&(param->acceptEncoding[i]));
          ret1 = cmUnpkSoAcceptEncodingSeq( (param->acceptEncoding[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptEncoding*/

/*
*
*    Fun:    cmUnpkSoAcceptLanguage
*
*    Desc:    unpack the structure SoAcceptLanguage
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptLanguage
(
SoAcceptLanguage *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptLanguage(param ,ptr, mBuf)
SoAcceptLanguage *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAcceptLanguage)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->acceptLanguage));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcceptLanguageSeq), (Ptr*)&(param->acceptLanguage[i]));
          ret1 = cmUnpkSoAcceptLanguageSeq( (param->acceptLanguage[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptLanguage*/
#ifdef SO_EVENT

/*
*
*    Fun:    cmUnpkSoEventHeader
*
*    Desc:    unpack the structure SoEventHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEventHeader
(
SoEventHeader *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEventHeader(param ,ptr, mBuf)
SoEventHeader *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoEventHeader)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->eventName, ptr, mBuf);
       ret1 = cmUnpkSoParameters(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoEventHeader*/

#endif /* SO_EVENT */

/*
*
*    Fun:    cmUnpkSoCallInfoSeq
*
*    Desc:    unpack the structure SoCallInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCallInfoSeq
(
SoCallInfoSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCallInfoSeq(param ,ptr, mBuf)
SoCallInfoSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoCallInfoSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAbsoluteUri(&param->absoluteUri, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoInfoParams(&param->infoParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCallInfoSeq*/

/*
*
*    Fun:    cmUnpkSoCallInfo
*
*    Desc:    unpack the structure SoCallInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCallInfo
(
SoCallInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCallInfo(param ,ptr, mBuf)
SoCallInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoCallInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->callInfo));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoCallInfoSeq), (Ptr*)&(param->callInfo[i]));
          ret1 = cmUnpkSoCallInfoSeq( (param->callInfo[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCallInfo*/

/*
*
*    Fun:    cmUnpkSoInfoSeq
*
*    Desc:    unpack the structure SoInfoSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoInfoSeq
(
SoInfoSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoInfoSeq(param ,ptr, mBuf)
SoInfoSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoInfoSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAbsoluteUri(&param->absoluteUri, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->genericParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoInfoSeq*/

/*
*
*    Fun:    cmUnpkSoInfo
*
*    Desc:    unpack the structure SoInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoInfo
(
SoInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoInfo(param ,ptr, mBuf)
SoInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoInfo)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->info));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoInfoSeq), (Ptr*)&(param->info[i]));
          ret1 = cmUnpkSoInfoSeq( (param->info[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoInfo*/

/*
*
*    Fun:    cmUnpkSoAddrParams
*
*    Desc:    unpack the structure SoAddrParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAddrParams
(
SoAddrParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAddrParams(param ,ptr, mBuf)
SoAddrParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAddrParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->addrParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAddrParam), (Ptr*)&(param->addrParam[i]));
          ret1 = cmUnpkSoAddrParam( (param->addrParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAddrParams*/

/*
*
*    Fun:    cmUnpkSoRoute
*
*    Desc:    unpack the structure SoRoute
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRoute
(
SoRoute *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRoute(param ,ptr, mBuf)
SoRoute *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRoute)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->route));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRouteSeq), (Ptr*)&(param->route[i]));
          ret1 = cmUnpkSoRouteSeq( (param->route[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRoute*/

/*
*
*    Fun:    cmUnpkSoDispositionParam
*
*    Desc:    unpack the structure SoDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDispositionParam
(
SoDispositionParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDispositionParam(param ,ptr, mBuf)
SoDispositionParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoDispositionParam)

    CMCHKUNPK(cmUnpkTknU8, &param->dispositionParamType,mBuf);
    if( param->dispositionParamType.pres != NOTPRSNT )
    {
       switch( param->dispositionParamType.val )
       {
          case  SO_DISP_PARAM_EXTN :
             ret1 = cmUnpkSoParameter(&param->t.parameter, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_DISP_PARAM_HANDLING :
             ret1 = cmUnpkSoExtVal(&param->t.handlingParmVal, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoDispositionParam*/

/*
*
*    Fun:    cmUnpkSoDispositionParams
*
*    Desc:    unpack the structure SoDispositionParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDispositionParams
(
SoDispositionParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDispositionParams(param ,ptr, mBuf)
SoDispositionParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoDispositionParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->dispositionParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoDispositionParam), (Ptr*)&(param->dispositionParam[i]));
          ret1 = cmUnpkSoDispositionParam( (param->dispositionParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoDispositionParams*/

/*
*
*    Fun:    cmUnpkSoAllow
*
*    Desc:    unpack the structure SoAllow
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAllow
(
SoAllow *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAllow(param ,ptr, mBuf)
SoAllow *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAllow)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->method));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoExtVal), (Ptr*)&(param->method[i]));
          ret1 = cmUnpkSoExtVal( (param->method[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAllow*/

/*
*
*    Fun:    cmUnpkSoContentDisposition
*
*    Desc:    unpack the structure SoContentDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContentDisposition
(
SoContentDisposition *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContentDisposition(param ,ptr, mBuf)
SoContentDisposition *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoContentDisposition)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStrValue(&param->type, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoDispositionParams(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContentDisposition*/

/*
*
*    Fun:    cmUnpkSoRetryParams
*
*    Desc:    unpack the structure SoRetryParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRetryParams
(
SoRetryParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRetryParams(param ,ptr, mBuf)
SoRetryParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRetryParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->retryParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRetryParam), (Ptr*)&(param->retryParam[i]));
          ret1 = cmUnpkSoRetryParam( (param->retryParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRetryParams*/

/*
*
*    Fun:    cmUnpkSoProdcomLst
*
*    Desc:    unpack the structure SoProdcomLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoProdcomLst
(
SoProdcomLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoProdcomLst(param ,ptr, mBuf)
SoProdcomLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoProdcomLst)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->prodcom));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoProdcom), (Ptr*)&(param->prodcom[i]));
          ret1 = cmUnpkSoProdcom( (param->prodcom[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoProdcomLst*/

/*
*
*    Fun:    cmUnpkSoWarning
*
*    Desc:    unpack the structure SoWarning
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoWarning
(
SoWarning *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoWarning(param ,ptr, mBuf)
SoWarning *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoWarning)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->warningItem));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoWarningItem), (Ptr*)&(param->warningItem[i]));
          ret1 = cmUnpkSoWarningItem( (param->warningItem[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoWarning*/

/*
*
*    Fun:    cmUnpkSoContact
*
*    Desc:    unpack the structure SoContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContact
(
SoContact *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContact(param ,ptr, mBuf)
SoContact *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoContact)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU8, &param->contactDescType,mBuf);
       ret1 = cmUnpkSoContactItems(&param->contactItems, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContact*/

/*
*
*    Fun:    cmUnpkSoCSeq
*
*    Desc:    unpack the structure SoCSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCSeq
(
SoCSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCSeq(param ,ptr, mBuf)
SoCSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoCSeq)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->cSeqVal,mBuf);
       ret1 = cmUnpkSoExtVal(&param->method, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCSeq*/

/*
*
*    Fun:    cmUnpkSoAddress
*
*    Desc:    unpack the structure SoAddress
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAddress
(
SoAddress *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAddress(param ,ptr, mBuf)
SoAddress *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAddress)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAddrCh(&param->addrCh, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoAddrParams(&param->addrParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAddress*/

/*
*
*    Fun:    cmUnpkSoTimestamp
*
*    Desc:    unpack the structure soTimestamp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTimestamp
(
SoTimestamp *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTimestamp(param ,mBuf)
SoTimestamp *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTimestamp)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->timestampVal,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->timestampFrac,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->timestampDelay,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->timestampDelayFrac,mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTimestamp*/

/*
*
*    Fun:    cmUnpkSoVia
*
*    Desc:    unpack the structure SoVia
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoVia
(
SoVia *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoVia(param ,ptr, mBuf)
SoVia *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoVia)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->viaItem));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoViaItem), (Ptr*)&(param->viaItem[i]));
          ret1 = cmUnpkSoViaItem( (param->viaItem[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoVia*/

/*
*
*    Fun:    cmUnpkSoAuthorization
*
*    Desc:    unpack the structure SoAuthorization
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAuthorization
(
SoAuthorization *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAuthorization(param ,ptr, mBuf)
SoAuthorization *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAuthorization)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->authScheme, ptr, mBuf);
       ret1 = cmUnpkSoParameters(&param->authParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAuthorization*/

/*
*
*    Fun:    cmUnpkSoAuthenticate
*
*    Desc:    unpack the structure SoAuthenticate
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAuthenticate
(
SoAuthenticate *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAuthenticate(param ,ptr, mBuf)
SoAuthenticate *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAuthenticate)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->challenge));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAuthorization), (Ptr*)&(param->challenge[i]));
          ret1 = cmUnpkSoAuthorization( (param->challenge[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAuthenticate*/

/*
*
*    Fun:    cmUnpkSoReplyTo
*
*    Desc:    unpack the structure SoReplyTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReplyTo
(
SoReplyTo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReplyTo(param ,ptr, mBuf)
SoReplyTo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReplyTo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAddrCh(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReplyTo*/

/*
*
*    Fun:    cmUnpkSoContentEncoding
*
*    Desc:    unpack the structure SoContentEncoding
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContentEncoding
(
SoContentEncoding *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContentEncoding(param ,ptr, mBuf)
SoContentEncoding *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoContentEncoding)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->contentCoding));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoExtVal), (Ptr*)&(param->contentCoding[i]));
          ret1 = cmUnpkSoExtVal( (param->contentCoding[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContentEncoding*/

/*
*
*    Fun:    cmUnpkSoContentTypeHdr
*
*    Desc:    unpack the structure SoContentTypeHdr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoContentTypeHdr
(
SoContentTypeHdr *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoContentTypeHdr(param ,ptr, mBuf)
SoContentTypeHdr *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoContentTypeHdr)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStrValue(&param->type, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoStrValue(&param->subType, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->parameters, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoContentTypeHdr*/

/*
*
*    Fun:    cmUnpkSoRetryAfter
*
*    Desc:    unpack the structure SoRetryAfter
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRetryAfter
(
SoRetryAfter *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRetryAfter(param ,ptr, mBuf)
SoRetryAfter *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRetryAfter)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->retryAfterTime,mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->retryAfterComment, ptr, mBuf);
       ret1 = cmUnpkSoRetryParams(&param->retryParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRetryAfter*/

/*
*
*    Fun:    cmUnpkSoRAck
*
*    Desc:    unpack the structure SoRAck
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRAck
(
SoRAck *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRAck(param ,ptr, mBuf)
SoRAck *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRAck)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->responseNum,mBuf);
       CMCHKUNPK(cmUnpkTknU32, &param->cSeqNum,mBuf);
       ret1 = cmUnpkSoExtVal(&param->method, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRAck*/
#ifdef SO_REFER

/*
*
*    Fun:    cmUnpkSoReferTo
*
*    Desc:    unpack the structure SoReferTo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReferTo
(
SoReferTo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReferTo(param ,ptr, mBuf)
SoReferTo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReferTo)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAddrCh(&param->addr, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoParameters(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReferTo*/

/*
*
*    Fun:    cmUnpkSoReferredByParam
*
*    Desc:    unpack the structure SoReferredByParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReferredByParam
(
SoReferredByParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReferredByParam(param ,ptr, mBuf)
SoReferredByParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReferredByParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_RF_BY_GENERIC_PARAM :
             ret1 = cmUnpkSoParameter(&param->t.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RF_BY_ID_PAR :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.cid, ptr, mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReferredByParam*/

/*
*
*    Fun:    cmUnpkSoReferredByParams
*
*    Desc:    unpack the structure SoReferredByParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReferredByParams
(
SoReferredByParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReferredByParams(param ,ptr, mBuf)
SoReferredByParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoReferredByParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->soRefrdByPar));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoReferredByParam), (Ptr*)&(param->soRefrdByPar[i]));
          ret1 = cmUnpkSoReferredByParam( (param->soRefrdByPar[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReferredByParams*/

/*
*
*    Fun:    cmUnpkSoReferredBy
*
*    Desc:    unpack the structure SoReferredBy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReferredBy
(
SoReferredBy *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReferredBy(param ,ptr, mBuf)
SoReferredBy *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReferredBy)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoAddrCh(&param->referredUrl, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoReferredByParams(&param->refrdByPar, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReferredBy*/

/*
*
*    Fun:    cmUnpkSoReplacesParam
*
*    Desc:    unpack the structure SoReplacesParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReplacesParam
(
SoReplacesParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReplacesParam(param ,ptr, mBuf)
SoReplacesParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReplacesParam)

    CMCHKUNPK(cmUnpkTknU8, &param->paramType,mBuf);
    if( param->paramType.pres != NOTPRSNT )
    {
       switch( param->paramType.val )
       {
          case  SO_REPLACES_GENERIC_PARAMS :
             ret1 = cmUnpkSoParameter(&param->u.genericParams, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REPLACES_PARAMTYPE_FROMTAG :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.fromTag, ptr, mBuf);
             break;
          case  SO_REPLACES_PARAMTYPE_TOTAG :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.toTag, ptr, mBuf);
             break;
          case  SO_REPLACES_PARAMTYPE_EARLYONLY :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReplacesParam*/

/*
*
*    Fun:    cmUnpkSoReplacesParams
*
*    Desc:    unpack the structure SoReplacesParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReplacesParams
(
SoReplacesParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReplacesParams(param ,ptr, mBuf)
SoReplacesParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoReplacesParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->replacesParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoReplacesParam), (Ptr*)&(param->replacesParam[i]));
          ret1 = cmUnpkSoReplacesParam( (param->replacesParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReplacesParams*/

/*
*
*    Fun:    cmUnpkSoReplaces
*
*    Desc:    unpack the structure SoReplaces
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReplaces
(
SoReplaces *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReplaces(param ,ptr, mBuf)
SoReplaces *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReplaces)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->callId, ptr, mBuf);
       ret1 = cmUnpkSoReplacesParams(&param->replacesParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReplaces*/
#endif /* SO_REFER */
#ifdef SO_SESSTIMER

/*
*
*    Fun:    cmUnpkSoSessExpParam
*
*    Desc:    unpack the structure SoSessExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSessExpParam
(
SoSessExpParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSessExpParam(param ,ptr, mBuf)
SoSessExpParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSessExpParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_SESSION_EXP_EXTN :
             ret1 = cmUnpkSoParameter(&param->u.param, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SESSION_EXP_REFRESHER :
             CMCHKUNPK(cmUnpkTknU8, &param->u.refresher,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSessExpParam*/

/*
*
*    Fun:    cmUnpkSoSessExpParams
*
*    Desc:    unpack the structure SoSessExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSessExpParams
(
SoSessExpParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSessExpParams(param ,ptr, mBuf)
SoSessExpParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSessExpParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->param));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoSessExpParam), (Ptr*)&(param->param[i]));
          ret1 = cmUnpkSoSessExpParam( (param->param[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSessExpParams*/

/*
*
*    Fun:    cmUnpkSoSessionExpires
*
*    Desc:    unpack the structure SoSessionExpires
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSessionExpires
(
SoSessionExpires *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSessionExpires(param ,ptr, mBuf)
SoSessionExpires *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSessionExpires)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->deltaSeconds,mBuf);
       ret1 = cmUnpkSoSessExpParams(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSessionExpires*/

/*
*
*    Fun:    cmUnpkSoMinSE
*
*    Desc:    unpack the structure SoMinSE
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMinSE
(
SoMinSE *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMinSE(param ,ptr, mBuf)
SoMinSE *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoMinSE)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPK(cmUnpkTknU32, &param->deltaSeconds,mBuf);
       ret1 = cmUnpkSoParameters(&param->params, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMinSE*/
#endif /* SO_SESSIONTIMER */
#ifdef SO_CALLERPREF

/*
*
*    Fun:    cmUnpkSoRequestDispositionParam
*
*    Desc:    unpack the structure SoRequestDispositionParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRequestDispositionParam
(
SoRequestDispositionParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRequestDispositionParam(param ,ptr, mBuf)
SoRequestDispositionParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoRequestDispositionParam)

    CMCHKUNPK(cmUnpkTknU8, &param->dispositionType,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->dispSubType,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoRequestDispositionParam*/

/*
*
*    Fun:    cmUnpkSoRequestDisposition
*
*    Desc:    unpack the structure SoRequestDisposition
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRequestDisposition
(
SoRequestDisposition *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRequestDisposition(param ,ptr, mBuf)
SoRequestDisposition *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRequestDisposition)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->requestDispositionParams));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRequestDispositionParam), (Ptr*)&(param->requestDispositionParams[i]));
          ret1 = cmUnpkSoRequestDispositionParam( (param->requestDispositionParams[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRequestDisposition*/

/*
*
*    Fun:    cmUnpkSoAcParam
*
*    Desc:    unpack the structure SoAcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcParam
(
SoAcParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcParam(param ,ptr, mBuf)
SoAcParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_ACCEPTCONTACT_PAR_EXPLICIT :
             break;
          case  SO_ACCEPTCONTACT_PAR_EXTN :
             ret1 = cmUnpkSoParameter(&param->u.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ACCEPTCONTACT_PAR_FP :
             ret1 = cmUnpkSoStrValue(&param->u.fparam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_ACCEPTCONTACT_PAR_REQUIRE :
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcParam*/

/*
*
*    Fun:    cmUnpkSoAcParams
*
*    Desc:    unpack the structure SoAcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcParams
(
SoAcParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcParams(param ,ptr, mBuf)
SoAcParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAcParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->acParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcParam), (Ptr*)&(param->acParam[i]));
          ret1 = cmUnpkSoAcParam( (param->acParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcParams*/

/*
*
*    Fun:    cmUnpkSoAcceptContact
*
*    Desc:    unpack the structure SoAcceptContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcceptContact
(
SoAcceptContact *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcceptContact(param ,ptr, mBuf)
SoAcceptContact *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoAcceptContact)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->acParams));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAcParams), (Ptr*)&(param->acParams[i]));
          ret1 = cmUnpkSoAcParams( (param->acParams[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcceptContact*/

/*
*
*    Fun:    cmUnpkSoRcParam
*
*    Desc:    unpack the structure SoRcParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRcParam
(
SoRcParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRcParam(param ,ptr, mBuf)
SoRcParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRcParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_REJECTCONTACT_PAR_EXTN :
             ret1 = cmUnpkSoParameter(&param->u.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REJECTCONTACT_PAR_FP :
             ret1 = cmUnpkSoStrValue(&param->u.fparam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRcParam*/

/*
*
*    Fun:    cmUnpkSoRcParams
*
*    Desc:    unpack the structure SoRcParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRcParams
(
SoRcParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRcParams(param ,ptr, mBuf)
SoRcParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRcParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rcParam));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRcParam), (Ptr*)&(param->rcParam[i]));
          ret1 = cmUnpkSoRcParam( (param->rcParam[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRcParams*/

/*
*
*    Fun:    cmUnpkSoRejectContact
*
*    Desc:    unpack the structure SoRejectContact
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRejectContact
(
SoRejectContact *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRejectContact(param ,ptr, mBuf)
SoRejectContact *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRejectContact)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rcParams));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRcParams), (Ptr*)&(param->rcParams[i]));
          ret1 = cmUnpkSoRcParams( (param->rcParams[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRejectContact*/
#endif /* SO_CALLERPREF */

/*
*
*    Fun:    cmUnpkSoTypeVal
*
*    Desc:    unpack the structure SoTypeVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTypeVal
(
SoTypeVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTypeVal(param ,ptr, mBuf)
SoTypeVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoTypeVal)

    ret1 = cmUnpkSoStrValue(&param->type, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkSoStrValue(&param->val, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTypeVal*/

/*
*
*    Fun:    cmUnpkSoPrivLst
*
*    Desc:    unpack the structure SoPrivLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoPrivLst
(
SoPrivLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoPrivLst(param ,ptr, mBuf)
SoPrivLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoPrivLst)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->privVal));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoTypeVal), (Ptr*)&(param->privVal[i]));
          ret1 = cmUnpkSoTypeVal( (param->privVal[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoPrivLst*/

/*
*
*    Fun:    cmUnpkSoRpiTok
*
*    Desc:    unpack the structure SoRpiTok
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRpiTok
(
SoRpiTok *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRpiTok(param ,ptr, mBuf)
SoRpiTok *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRpiTok)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_RPI_ID_TYPE :
             ret1 = cmUnpkSoStrValue(&param->u.id, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_OTHER_RPI_TOKEN :
             ret1 = cmUnpkSoTypeVal(&param->u.othRpi, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_PRIVACY :
             ret1 = cmUnpkSoPrivLst(&param->u.prvLst, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_PTY_TYPE :
             ret1 = cmUnpkSoStrValue(&param->u.party, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_RPI_SCREEN :
             CMCHKUNPK(cmUnpkTknU8, &param->u.scrn,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRpiTok*/

/*
*
*    Fun:    cmUnpkSoRpiTokLst
*
*    Desc:    unpack the structure SoRpiTokLst
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRpiTokLst
(
SoRpiTokLst *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRpiTokLst(param ,ptr, mBuf)
SoRpiTokLst *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRpiTokLst)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rpiTok));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRpiTok), (Ptr*)&(param->rpiTok[i]));
          ret1 = cmUnpkSoRpiTok( (param->rpiTok[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRpiTokLst*/

/*
*
*    Fun:    cmUnpkSoRpid
*
*    Desc:    unpack the structure SoRpid
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRpid
(
SoRpid *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRpid(param ,ptr, mBuf)
SoRpid *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRpid)

    ret1 = cmUnpkSoNameAddr(&param->nameAddr, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkSoRpiTokLst(&param->rpiTokLst, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRpid*/

/*
*
*    Fun:    cmUnpkSoRemPartyId
*
*    Desc:    unpack the structure SoRemPartyId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRemPartyId
(
SoRemPartyId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRemPartyId(param ,ptr, mBuf)
SoRemPartyId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRemPartyId)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rpidLst));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRpid), (Ptr*)&(param->rpidLst[i]));
          ret1 = cmUnpkSoRpid( (param->rpidLst[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRemPartyId*/

/*
*
*    Fun:    cmUnpkSoRpidPrivcy
*
*    Desc:    unpack the structure SoRpidPrivcy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRpidPrivcy
(
SoRpidPrivcy *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRpidPrivcy(param ,ptr, mBuf)
SoRpidPrivcy *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoRpidPrivcy)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->rpidPriv));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoRpiTokLst), (Ptr*)&(param->rpidPriv[i]));
          ret1 = cmUnpkSoRpiTokLst( (param->rpidPriv[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRpidPrivcy*/
#ifdef SO_EVENT

/*
*
*    Fun:    cmUnpkSoSubExpParam
*
*    Desc:    unpack the structure SoSubExpParam
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSubExpParam
(
SoSubExpParam *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSubExpParam(param ,ptr, mBuf)
SoSubExpParam *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSubExpParam)

    CMCHKUNPK(cmUnpkTknU8, &param->type,mBuf);
    if( param->type.pres != NOTPRSNT )
    {
       switch( param->type.val )
       {
          case  SO_SUB_EXP_PAR_EXPIRES :
             CMCHKUNPK(cmUnpkTknU32, &param->u.expires,mBuf);
             break;
          case  SO_SUB_EXP_PAR_GENERIC_PARAM :
             ret1 = cmUnpkSoParameter(&param->u.genericParam, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SUB_EXP_PAR_REASON :
             ret1 = cmUnpkSoStrValue(&param->u.reason, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SUB_EXP_PAR_RETRY_AFT :
             CMCHKUNPK(cmUnpkTknU32, &param->u.retryAfter,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSubExpParam*/

/*
*
*    Fun:    cmUnpkSoSubExpParams
*
*    Desc:    unpack the structure SoSubExpParams
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSubExpParams
(
SoSubExpParams *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSubExpParams(param ,ptr, mBuf)
SoSubExpParams *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSubExpParams)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->subExpParamList));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoSubExpParam), (Ptr*)&(param->subExpParamList[i]));
          ret1 = cmUnpkSoSubExpParam( (param->subExpParamList[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSubExpParams*/

/*
*
*    Fun:    cmUnpkSoSubscState
*
*    Desc:    unpack the structure SoSubscState
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSubscState
(
SoSubscState *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSubscState(param ,ptr, mBuf)
SoSubscState *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSubscState)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStrValue(&param->subVal, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoSubExpParams(&param->subExpParams, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSubscState*/
#endif /* SO_EVENT */

/*
*
*    Fun:    cmUnpkSoMechPar
*
*    Desc:    unpack the structure SoMechPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMechPar
(
SoMechPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMechPar(param ,ptr, mBuf)
SoMechPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoMechPar)

    CMCHKUNPK(cmUnpkTknU8, &param->mechParamType,mBuf);
    if( param->mechParamType.pres != NOTPRSNT )
    {
       switch( param->mechParamType.val )
       {
          case  SO_MECH_PAR_DG_ALG :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.dgAlg, ptr, mBuf);
             break;
          case  SO_MECH_PAR_DG_QOP :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.dgQop, ptr, mBuf);
             break;
          case  SO_MECH_PAR_DG_VERIFY :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.dgVerify, ptr, mBuf);
             break;
          case  SO_MECH_PAR_EXTN :
             ret1 = cmUnpkSoParameter(&param->u.ext, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_MECH_PAR_PREF :
             CMCHKUNPK(cmUnpkSoQValue, &param->u.pref,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMechPar*/

/*
*
*    Fun:    cmUnpkSoMechPars
*
*    Desc:    unpack the structure SoMechPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMechPars
(
SoMechPars *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMechPars(param ,ptr, mBuf)
SoMechPars *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoMechPars)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->mechPar));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoMechPar), (Ptr*)&(param->mechPar[i]));
          ret1 = cmUnpkSoMechPar( (param->mechPar[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMechPars*/

/*
*
*    Fun:    cmUnpkSoSecMech
*
*    Desc:    unpack the structure SoSecMech
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSecMech
(
SoSecMech *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSecMech(param ,ptr, mBuf)
SoSecMech *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoSecMech)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStrValue(&param->mechName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoMechPars(&param->mechPars, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSecMech*/

/*
*
*    Fun:    cmUnpkSoSecVerify
*
*    Desc:    unpack the structure SoSecVerify
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSecVerify
(
SoSecVerify *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSecVerify(param ,ptr, mBuf)
SoSecVerify *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSecVerify)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->secMech));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoSecMech), (Ptr*)&(param->secMech[i]));
          ret1 = cmUnpkSoSecMech( (param->secMech[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSecVerify*/

/*
*
*    Fun:    cmUnpkSoSecServer
*
*    Desc:    unpack the structure SoSecServer
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSecServer
(
SoSecServer *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSecServer(param ,ptr, mBuf)
SoSecServer *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSecServer)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->secMech));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoSecMech), (Ptr*)&(param->secMech[i]));
          ret1 = cmUnpkSoSecMech( (param->secMech[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSecServer*/

/*
*
*    Fun:    cmUnpkSoSecClient
*
*    Desc:    unpack the structure SoSecClient
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSecClient
(
SoSecClient *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSecClient(param ,ptr, mBuf)
SoSecClient *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSecClient)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->secMech));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoSecMech), (Ptr*)&(param->secMech[i]));
          ret1 = cmUnpkSoSecMech( (param->secMech[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSecClient*/

/*
*
*    Fun:    cmUnpkSoReasonPar
*
*    Desc:    unpack the structure SoReasonPar
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReasonPar
(
SoReasonPar *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReasonPar(param ,ptr, mBuf)
SoReasonPar *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReasonPar)

    CMCHKUNPK(cmUnpkTknU8, &param->reasonType,mBuf);
    if( param->reasonType.pres != NOTPRSNT )
    {
       switch( param->reasonType.val )
       {
          case  SO_REASON_CAUSE :
             CMCHKUNPK(cmUnpkTknU32, &param->u.cause,mBuf);
             break;
          case  SO_REASON_EXTN :
             ret1 = cmUnpkSoParameter(&param->u.extn, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_REASON_TEXT :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->u.text, ptr, mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReasonPar*/

/*
*
*    Fun:    cmUnpkSoReasonPars
*
*    Desc:    unpack the structure SoReasonPars
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReasonPars
(
SoReasonPars *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReasonPars(param ,ptr, mBuf)
SoReasonPars *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoReasonPars)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->reasonPar));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoReasonPar), (Ptr*)&(param->reasonPar[i]));
          ret1 = cmUnpkSoReasonPar( (param->reasonPar[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReasonPars*/

/*
*
*    Fun:    cmUnpkSoReasonVal
*
*    Desc:    unpack the structure SoReasonVal
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReasonVal
(
SoReasonVal *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReasonVal(param ,ptr, mBuf)
SoReasonVal *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoReasonVal)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoProtocolName(&param->protocolName, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoReasonPars(&param->reasonPars, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReasonVal*/

/*
*
*    Fun:    cmUnpkSoReason
*
*    Desc:    unpack the structure SoReason
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoReason
(
SoReason *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoReason(param ,ptr, mBuf)
SoReason *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoReason)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->reasonVal));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoReasonVal), (Ptr*)&(param->reasonVal[i]));
          ret1 = cmUnpkSoReasonVal( (param->reasonVal[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoReason*/

/*
*
*    Fun:    cmUnpkSoPrivacy
*
*    Desc:    unpack the structure SoPrivacy
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoPrivacy
(
SoPrivacy *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoPrivacy(param ,ptr, mBuf)
SoPrivacy *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoPrivacy)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->privVal));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoStrValue), (Ptr*)&(param->privVal[i]));
          ret1 = cmUnpkSoStrValue( (param->privVal[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoPrivacy*/

/*
*
*    Fun:    cmUnpkSoPAssertedId
*
*    Desc:    unpack the structure SoPAssertedId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoPAssertedId
(
SoPAssertedId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoPAssertedId(param ,ptr, mBuf)
SoPAssertedId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoPAssertedId)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->addrChoice));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAddrCh), (Ptr*)&(param->addrChoice[i]));
          ret1 = cmUnpkSoAddrCh( (param->addrChoice[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoPAssertedId*/

/*
*
*    Fun:    cmUnpkSoPPreferredId
*
*    Desc:    unpack the structure SoPPreferredId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoPPreferredId
(
SoPPreferredId *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoPPreferredId(param ,ptr, mBuf)
SoPPreferredId *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoPPreferredId)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->addrChoice));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAddrCh), (Ptr*)&(param->addrChoice[i]));
          ret1 = cmUnpkSoAddrCh( (param->addrChoice[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoPPreferredId*/

/*
*
*    Fun:    cmUnpkSoHeader
*
*    Desc:    unpack the structure SoHeader
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHeader
(
SoHeader *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHeader(param ,ptr, mBuf)
SoHeader *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoHeader)

    CMCHKUNPK(cmUnpkTknU8, &param->headerType,mBuf);
    if( param->headerType.pres != NOTPRSNT )
    {
       switch( param->headerType.val )
       {
          case  SO_HEADER_ANONMY :
             ret1 = cmUnpkSoStrValue(&param->t.anony, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTDISPOSITION :
             ret1 = cmUnpkSoContentDisposition(&param->t.contentDisposition, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTENCODING :
             ret1 = cmUnpkSoContentEncoding(&param->t.contentEncoding, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTLANGUAGE :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.contentLanguage, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_CONTENTLENGTH :
             CMCHKUNPK(cmUnpkTknU32, &param->t.contentLength,mBuf);
             break;
          case  SO_HEADER_ENT_CONTENTTYPE :
             ret1 = cmUnpkSoContentTypeHdr(&param->t.contentType, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_ENT_MIMEVERSION :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.mimeVersion, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_ACCEPT :
             ret1 = cmUnpkSoAccept(&param->t.accept, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ACCEPTENCODING :
             ret1 = cmUnpkSoAcceptEncoding(&param->t.acceptEncoding, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ACCEPTLANGUAGE :
             ret1 = cmUnpkSoAcceptLanguage(&param->t.acceptLanguage, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALERTINFO :
             ret1 = cmUnpkSoInfo(&param->t.alertInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALLOW :
             ret1 = cmUnpkSoAllow(&param->t.allow, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_ALLOW_EVENTS :
#ifdef SO_EVENT
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.allowEvents, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_GEN_ALLOW_EVENTSU :
#ifdef SO_EVENT
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.allowEvents, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_GEN_CALLID :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.callId, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_CALLINFO :
             ret1 = cmUnpkSoCallInfo(&param->t.callInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_CONTACT :
             ret1 = cmUnpkSoContact(&param->t.contact, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_CSEQ :
             ret1 = cmUnpkSoCSeq(&param->t.cSeq, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_DATE :
             CMCHKUNPK(cmUnpkSoSipDate, &param->t.date,mBuf);
             break;
          case  SO_HEADER_GEN_ENCRYPTION :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.encryption, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_EXPIRES :
             CMCHKUNPK(cmUnpkTknU32, &param->t.expires,mBuf);
             break;
          case  SO_HEADER_GEN_EXTENSION :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.extensionHeader, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_FROM :
             ret1 = cmUnpkSoAddress(&param->t.from, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_MINEXPIRES :
             CMCHKUNPK(cmUnpkTknU32, &param->t.minExpires,mBuf);
             break;
          case  SO_HEADER_GEN_MINSE :
#ifdef SO_SESSTIMER
             ret1 = cmUnpkSoMinSE(&param->t.minSe, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_SESSTIMER  */
             break;
          case  SO_HEADER_GEN_ORGANIZATION :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.organization, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_PASSERTEDID :
             ret1 = cmUnpkSoPAssertedId(&param->t.assertId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PATH :
             ret1 = cmUnpkSoRoute(&param->t.path, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PMEDIAAUTHORIZATION :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.pMediaAuth, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PPREFERREDID :
             ret1 = cmUnpkSoPPreferredId(&param->t.preferredId, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PRIVACY :
             ret1 = cmUnpkSoPrivacy(&param->t.privacy, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_PROXYREQUIRE :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.proxyRequire, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RACK :
             ret1 = cmUnpkSoRAck(&param->t.rAck, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REASON :
             ret1 = cmUnpkSoReason(&param->t.reason, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RECORDROUTE :
             ret1 = cmUnpkSoRoute(&param->t.recordRoute, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REPLYTO :
             ret1 = cmUnpkSoReplyTo(&param->t.replyTo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_REQUIRE :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.require, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_RSEQ :
             CMCHKUNPK(cmUnpkTknU32, &param->t.rSeq,mBuf);
             break;
          case  SO_HEADER_GEN_SERVICEROUTE :
             ret1 = cmUnpkSoRoute(&param->t.serviceRoute, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_SESSION_EXPIRES :
          case  SO_HEADER_GEN_SESSION_EXPIRESX :
#ifdef SO_SESSTIMER
             ret1 = cmUnpkSoSessionExpires(&param->t.sessExpires, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             ret1 = cmUnpkSoSessionExpires(&param->t.sessExpires, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_SESSTIMER  */
             break;
          case  SO_HEADER_GEN_SUBJECT :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.subject, ptr, mBuf);
             break;
          case  SO_HEADER_GEN_SUPPORTED :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.supported, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_TIMESTAMP :
             CMCHKUNPK(cmUnpkSoTimestamp, &param->t.timestamp,mBuf);
             break;
          case  SO_HEADER_GEN_TO :
             ret1 = cmUnpkSoAddress(&param->t.to, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_USERAGENT :
             ret1 = cmUnpkSoProdcomLst(&param->t.userAgent, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_VIA :
             ret1 = cmUnpkSoVia(&param->t.via, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_WARNING :
             ret1 = cmUnpkSoWarning(&param->t.warning, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_GEN_WWWAUTHENTICATE :
             ret1 = cmUnpkSoAuthenticate(&param->t.wwwAuthenticate, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REM_PARTY_ID :
             ret1 = cmUnpkSoRemPartyId(&param->t.remPtid, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_ACCEPT_CONTACT :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoAcceptContact(&param->t.acceptContact, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_ACCEPT_CONTACTA :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoAcceptContact(&param->t.acceptContact, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_ALSO :
             ret1 = cmUnpkSoAlso(&param->t.also, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_AUTHENTICATIONINFO :
             ret1 = cmUnpkSoParameters(&param->t.authInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_AUTHORIZATION :
             ret1 = cmUnpkSoAuthorization(&param->t.authorization, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_EVENT :
#ifdef SO_EVENT
             ret1 = cmUnpkSoEventHeader(&param->t.event, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_REQ_EVENTO :
#ifdef SO_EVENT
             ret1 = cmUnpkSoEventHeader(&param->t.event, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          case  SO_HEADER_REQ_INREPLYTO :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.inReplyTo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_MAXFORWARDS :
             CMCHKUNPK(cmUnpkTknU32, &param->t.maxForwards,mBuf);
             break;
          case  SO_HEADER_REQ_PRIORITY :
             ret1 = cmUnpkSoPriority(&param->t.priority, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_PROXYAUTHORIZATION :
             ret1 = cmUnpkSoAuthorization(&param->t.proxyAuthorization, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_REQ_REFERBY :
#ifdef SO_REFER
             ret1 = cmUnpkSoReferredBy(&param->t.referredBy, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERBYB :
#ifdef SO_REFER
             ret1 = cmUnpkSoReferredBy(&param->t.referredBy, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERTO :
#ifdef SO_REFER
             ret1 = cmUnpkSoReferTo(&param->t.referTo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REFERTOR :
#ifdef SO_REFER
             ret1 = cmUnpkSoReferTo(&param->t.referTo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REJECT_CONTACT :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoRejectContact(&param->t.rejectContact, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REJECT_CONTACTJ :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoRejectContact(&param->t.rejectContact, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REPLACES :
#ifdef SO_REFER
             ret1 = cmUnpkSoReplaces(&param->t.replaces, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REFER  */
             break;
          case  SO_HEADER_REQ_REQUESTDISPOSITION :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoRequestDisposition(&param->t.requestDisposition, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_REQUESTDISPOSITIOND :
#ifdef SO_CALLERPREF
             ret1 = cmUnpkSoRequestDisposition(&param->t.requestDisposition, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_CALLERPREF  */
             break;
          case  SO_HEADER_REQ_RESPONSEKEY :
             CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.responseKey, ptr, mBuf);
             break;
          case  SO_HEADER_REQ_ROUTE :
             ret1 = cmUnpkSoRoute(&param->t.route, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RPID_PRIV :
             ret1 = cmUnpkSoRpidPrivcy(&param->t.rpidPriv, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_ERRORINFO :
             ret1 = cmUnpkSoInfo(&param->t.errorInfo, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_PROXYAUTHENTICATE :
             ret1 = cmUnpkSoAuthenticate(&param->t.proxyAuthenticate, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_RETRYAFTER :
             ret1 = cmUnpkSoRetryAfter(&param->t.retryAfter, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_SERVER :
             ret1 = cmUnpkSoProdcomLst(&param->t.server, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_RSP_UNSUPPORTED :
             ret1 = cmUnpkSoTknStrOSXLLst(&param->t.unsupported, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_CLIENT :
             ret1 = cmUnpkSoSecClient(&param->t.secClient, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_SERVER :
             ret1 = cmUnpkSoSecServer(&param->t.secServer, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SEC_VERIFY :
             ret1 = cmUnpkSoSecVerify(&param->t.secVerify, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_HEADER_SUBSC_STATE :
#ifdef SO_EVENT
             ret1 = cmUnpkSoSubscState(&param->t.subscSt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_EVENT  */
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHeader*/

/*
*
*    Fun:    cmUnpkSoRequestLine
*
*    Desc:    unpack the structure SoRequestLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRequestLine
(
SoRequestLine *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRequestLine(param ,ptr, mBuf)
SoRequestLine *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRequestLine)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoExtVal(&param->method, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoAddrSpec(&param->addrSpec, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->sipVersion, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRequestLine*/

/*
*
*    Fun:    cmUnpkSoHeaderSeq
*
*    Desc:    unpack the structure SoHeaderSeq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHeaderSeq
(
SoHeaderSeq *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHeaderSeq(param ,ptr, mBuf)
SoHeaderSeq *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoHeaderSeq)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->numComp.val), (Ptr*)&(param->header));
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoHeader), (Ptr*)&(param->header[i]));
          ret1 = cmUnpkSoHeader( (param->header[i]), ptr ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoHeaderSeq*/

/*
*
*    Fun:    cmUnpkSoStatusLine
*
*    Desc:    unpack the structure SoStatusLine
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoStatusLine
(
SoStatusLine *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoStatusLine(param ,ptr, mBuf)
SoStatusLine *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoStatusLine)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->sipVersion, ptr, mBuf);
       CMCHKUNPK(cmUnpkTknU16, &param->statusCode,mBuf);
       CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->reasonPhrase, ptr, mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoStatusLine*/

/*
*
*    Fun:    cmUnpkSoRequest
*
*    Desc:    unpack the structure SoRequest
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRequest
(
SoRequest *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRequest(param ,ptr, mBuf)
SoRequest *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRequest)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoRequestLine(&param->requestLine, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHeaderSeq(&param->request, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRequest*/

/*
*
*    Fun:    cmUnpkSoResponse
*
*    Desc:    unpack the structure SoResponse
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoResponse
(
SoResponse *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoResponse(param ,ptr, mBuf)
SoResponse *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoResponse)

    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    if(param->pres.pres != NOTPRSNT)
    {
       ret1 = cmUnpkSoStatusLine(&param->statusLine, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
       ret1 = cmUnpkSoHeaderSeq(&param->response, ptr ,mBuf);
       if (ret1 != ROK)
       {
          RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoResponse*/
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    cmUnpkSoCLegInfo
*
*    Desc:    unpack the structure soCLegInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCLegInfo
(
SoCLegInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCLegInfo(param ,mBuf)
SoCLegInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoCLegInfo)

    CMCHKUNPK(SUnpkU32, &param->cLegId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->cLegState,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoCLegInfo*/

/*
*
*    Fun:    cmUnpkSoAuditInfo
*
*    Desc:    unpack the structure SoAuditInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAuditInfo
(
SoAuditInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAuditInfo(param ,ptr, mBuf)
SoAuditInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoAuditInfo)

    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->callId, ptr, mBuf);
    CMCHKUNPK(SUnpkU8, &param->sessionStartedBy,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numCallLegs,mBuf);
    for (i=0;i<param->numCallLegs ;i++)
    {
       CMCHKUNPK(cmUnpkSoCLegInfo, &param->cLegInfo[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAuditInfo*/

/*
*
*    Fun:    cmUnpkSoSSapInfo
*
*    Desc:    unpack the structure SoSSapInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSSapInfo
(
SoSSapInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSSapInfo(param ,ptr, mBuf)
SoSSapInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoSSapInfo)

    CMCHKUNPK(SUnpkS16, &param->spId,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numCalls,mBuf);
    for (i=0;i<param->numCalls ;i++)
    {
       ret1 = cmUnpkSoAuditInfo(&param->callInfo[i], ptr ,mBuf);
       if( ret1 != ROK)
       {
          RETVALUE( ret1 );
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSSapInfo*/

/*
*
*    Fun:    cmUnpkSoAudit
*
*    Desc:    unpack the structure SoAudit
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAudit
(
SoAudit *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAudit(param ,ptr, mBuf)
SoAudit *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAudit)

    CMCHKUNPK(SUnpkU8, &param->auditType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->moreAudit,mBuf);
    switch( param->auditType )
    {
       case  SOT_AUDIT_CALL :
          ret1 = cmUnpkSoAuditInfo(&param->auditInfo.callInfo, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  SOT_AUDIT_SSAP :
          ret1 = cmUnpkSoSSapInfo(&param->auditInfo.ssapInfo, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAudit*/
#endif /* SO_UA */


/*
*
*    Fun:    cmUnpkSoRegRefreshInfo
*
*    Desc:    unpack the structure SoRegRefreshInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRegRefreshInfo
(
SoRegRefreshInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRegRefreshInfo(param ,ptr, mBuf)
SoRegRefreshInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRegRefreshInfo)

    ret1 = cmUnpkSoContactItem(&param->contactItem, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkSoAddress(&param->to, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    ret1 = cmUnpkSoAddress(&param->from, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->callId, ptr, mBuf);
    ret1 = cmUnpkSoAddrSpec(&param->regAddr, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRegRefreshInfo*/

/*
*
*    Fun:    cmUnpkSoRefreshEvnt
*
*    Desc:    unpack the structure SoRefreshEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRefreshEvnt
(
SoRefreshEvnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRefreshEvnt(param ,ptr, mBuf)
SoRefreshEvnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoRefreshEvnt)

    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    switch( param->type )
    {
       case  SOT_ET_REG_TMO :
          ret1 = cmUnpkSoRegRefreshInfo(&param->t.regInfo, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  SOT_ET_SUBSC_TMO :
#ifdef SO_EVENT
          CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.subscId, ptr, mBuf);
#endif /*  SO_EVENT  */
          break;
       default:
          break;
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoRefreshEvnt*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmUnpkSoErrEvnt
*
*    Desc:    unpack the structure SoErrEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoErrEvnt
(
SoErrEvnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoErrEvnt(param ,ptr, mBuf)
SoErrEvnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoErrEvnt)

    CMCHKUNPK(SUnpkU16, &param->errCode,mBuf);
#ifndef SO_REL_1_2_INF
    CMCHKUNPK(SUnpkU8, &param->eventType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->callCleared,mBuf);
#ifdef SO_EVENT
    switch( param->errCode )
    {
       case  SOT_ERR_REFER_TMO :
          CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.referId, ptr, mBuf);
          break;
       case  SOT_ERR_SUBSC_TMO :
          CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->t.subscId, ptr, mBuf);
          break;
       default:
          break;
    }
#endif /*  SO_EVENT  */
#endif /*  SO_REL_1_2_INF  */
    RETVALUE(ROK);
} /*end of function cmUnpkSoErrEvnt*/

#ifndef CM_SDP_OPAQUE
/*
*
*    Fun:    cmUnpkSoSdpEvnt
*
*    Desc:    unpack the structure SoSdpEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSdpEvnt
(
SoSdpEvnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSdpEvnt(param ,mBuf)
SoSdpEvnt *param;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkSoSdpEvnt)

    ptr =(Ptr)param;

    ret1 = cmUnpkCmSdpInfo(&param->sdp, ptr , 0 ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSdpEvnt*/
#endif /* CM_SDP_OPAQUE */

/*
*
*    Fun:    cmUnpkSoBodySinglePart
*
*    Desc:    unpack the structure SoBodySinglePart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoBodySinglePart
(
SoBodySinglePart *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoBodySinglePart(param ,ptr,  sMem, maxBlkSize, mBuf)
SoBodySinglePart *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoBodySinglePart)

    CMCHKUNPK(cmUnpkTknU8, &param->bodySinglePartType,mBuf);
    if( param->bodySinglePartType.pres != NOTPRSNT )
    {
       switch( param->bodySinglePartType.val )
       {
          case  SOT_BODYSINGLEPART_SDP :
#ifndef CM_SDP_OPAQUE
             if(cmAllocEvnt(sizeof(SoSdpEvnt)*(1), maxBlkSize, sMem,
               (Ptr*)&param->s.sdp) != ROK)
             {
                RETVALUE(RFAILED);
             }
             CMCHKUNPK(cmUnpkSoSdpEvnt,  (param->s.sdp), mBuf);
#endif /* CM_SDP_OPAQUE */
             break;
          case  SOT_BODYSINGLEPART_STR :
             CMCHKUNPK(cmUnpkTknBuf, &param->s.str,&mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoBodySinglePart*/

/*
*
*    Fun:    cmUnpkSoBodyMultiPartElm
*
*    Desc:    unpack the structure SoBodyMultiPartElm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoBodyMultiPartElm
(
SoBodyMultiPartElm *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoBodyMultiPartElm(param ,ptr,  sMem, maxBlkSize, mBuf)
SoBodyMultiPartElm *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoBodyMultiPartElm)

    ret1 = cmUnpkSoHeaderSeq(&param->hdrSeq, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMGETMBLK(ptr, sizeof(SoBody)*(1), (Ptr*)&(param->body));
    ret1 = cmUnpkSoBody( (param->body), ptr , sMem , maxBlkSize ,mBuf);
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       RETVALUE( ret1 );
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoBodyMultiPartElm*/

/*
*
*    Fun:    cmUnpkSoBodyMultiPart
*
*    Desc:    unpack the structure SoBodyMultiPart
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoBodyMultiPart
(
SoBodyMultiPart *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoBodyMultiPart(param ,ptr,  sMem, maxBlkSize, mBuf)
SoBodyMultiPart *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Cntr i;
    TRC3(cmUnpkSoBodyMultiPart)

    CMCHKUNPK(cmUnpkTknU16, &param->numComp,mBuf);
    if( param->numComp.pres != NOTPRSNT )
    {
       for (i=0;i<param->numComp.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoBodyMultiPartElm), (Ptr*)&(param->bodyElm[i]));
          ret1 = cmUnpkSoBodyMultiPartElm( (param->bodyElm[i]), ptr , sMem , maxBlkSize ,mBuf);
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             RETVALUE( ret1 );
          }
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoBodyMultiPart*/

/*
*
*    Fun:    cmUnpkSoBody
*
*    Desc:    unpack the structure SoBody
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoBody
(
SoBody *param,
Ptr ptr,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoBody(param ,ptr,  sMem, maxBlkSize, mBuf)
SoBody *param;
Ptr ptr;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoBody)

    CMCHKUNPK(cmUnpkTknU8, &param->bodyType,mBuf);
    if( param->bodyType.pres != NOTPRSNT )
    {
       switch( param->bodyType.val )
       {
          case  SOT_BODYTYPE_MULTIPART :
             ret1 = cmUnpkSoBodyMultiPart(&param->u.multiPart, ptr , sMem , maxBlkSize ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SOT_BODYTYPE_SINGLEPART :
             ret1 = cmUnpkSoBodySinglePart(&param->u.singlePart, ptr , sMem , maxBlkSize ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoBody*/

/*
*
*    Fun:    cmUnpkSoEvnt
*
*    Desc:    unpack the structure SoEvnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEvnt
(
SoEvnt *param,
Mem *sMem,
Size maxBlkSize,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEvnt(param , sMem, maxBlkSize, mBuf)
SoEvnt *param;
Mem *sMem;
Size maxBlkSize;
Buffer *mBuf;
#endif
{
    Ptr ptr;
    S16 ret1;
    TRC3(cmUnpkSoEvnt)

    ptr =(Ptr)param;

    CMCHKUNPK(cmUnpkTknU8, &param->eventType,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->sipMessageType,mBuf);
    if( param->sipMessageType.pres != NOTPRSNT )
    {
       switch( param->sipMessageType.val )
       {
          case  SO_SIPMESSAGE_AUDIT :
#ifndef SO_REL_1_2_INF
#ifdef SO_UA
             ret1 = cmUnpkSoAudit(&param->t.auditEvnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /* SO_UA */
#endif /*  SO_REL_1_2_INF  */
             break;
          case  SO_SIPMESSAGE_ERROR :
             ret1 = cmUnpkSoErrEvnt(&param->t.errEvnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SIPMESSAGE_REFRESH :
#ifndef SO_REL_1_2_INF
             ret1 = cmUnpkSoRefreshEvnt(&param->t.refreshEvnt, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
#endif /*  SO_REL_1_2_INF  */
             break;
          case  SO_SIPMESSAGE_REQUEST :
             ret1 = cmUnpkSoRequest(&param->t.request, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          case  SO_SIPMESSAGE_RESPONSE :
             ret1 = cmUnpkSoResponse(&param->t.response, ptr ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    ret1 = cmUnpkSoBody(&param->sipBody, ptr , sMem , maxBlkSize ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKUNPK(SUnpkU32, &param->transId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->callLegId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->srcTranCb,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dstTranCb,mBuf);

   /*- sot.c_001.main_10 : Packing/Unpacking for Lawful Call Intercept -*/
#ifdef SO_CALEA
    {
       TknBuf  tknBuf;

       CMCHKUNPK(cmUnpkTknBuf, &tknBuf, &mBuf);

       if (tknBuf.pres == PRSNT_NODEF)
          param->rawMsg = tknBuf.val;
       else
          param->rawMsg = NULLP;

       CMCHKUNPK(SUnpkU32, &param->messageId,mBuf);
    }
#endif

#ifdef SO_REPLACES
    CMCHKUNPK(SUnpkU32, &param->rplcSuConId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->rplcSpConId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->rplcCLegId,mBuf);
#endif /*  SO_REPLACES  */
    RETVALUE(ROK);
} /*end of function cmUnpkSoEvnt*/

/*
*
*    Fun:    cmUnpkSotBndReq
*
*    Desc:    unpack the primitive SotBndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotBndReq
(
SotBndReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSotBndReq(func, pst, mBuf)
SotBndReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SuId suId;
    SpId spId;
    
    TRC3(cmUnpkSotBndReq)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT207, pst);
    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT208, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, spId));
} /*end of function cmUnpkSotBndReq*/

/*
*
*    Fun:    cmUnpkSotUbndReq
*
*    Desc:    unpack the primitive SotUbndReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotUbndReq
(
SotUbndReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSotUbndReq(func, pst, mBuf)
SotUbndReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SpId spId;
    Reason reason;
    
    TRC3(cmUnpkSotUbndReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT209, pst);
    CMCHKUNPKLOG(cmUnpkReason, &reason, mBuf, ESOT210, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, reason));
} /*end of function cmUnpkSotUbndReq*/

/*
*
*    Fun:    cmUnpkSotConReq
*
*    Desc:    unpack the primitive SotConReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotConReq
(
SotConReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotConReq(func, pst, mBuf,  sMem, maxBlkSize)
SotConReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotConReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT211, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT212, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT213, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT214,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, suConnId, soEvnt));
} /*end of function cmUnpkSotConReq*/

/*
*
*    Fun:    cmUnpkSotConRsp
*
*    Desc:    unpack the primitive SotConRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotConRsp
(
SotConRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotConRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotConRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotConRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT215, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT216, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT217, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             SPutMsg(mBuf);/* sot_c_002.main_1: free mBuf if allocevent fails */
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT218, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT219,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotConRsp*/

/*
*
*    Fun:    cmUnpkSotCnStReq
*
*    Desc:    unpack the primitive SotCnStReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCnStReq
(
SotCnStReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCnStReq(func, pst, mBuf,  sMem, maxBlkSize)
SotCnStReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCnStReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT220, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT221, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT222, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             SPutMsg(mBuf);/* sot_c_002.main_1: free mBuf if allocevent fails */
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT223, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT224,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCnStReq*/
#ifndef SO_REL_1_2_INF

/*
*
*    Fun:    cmUnpkSotAckReq
*
*    Desc:    unpack the primitive SotAckReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotAckReq
(
SotAckReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotAckReq(func, pst, mBuf,  sMem, maxBlkSize)
SotAckReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotAckReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT225, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT226, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT227, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT228, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT229,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotAckReq*/

/*
*
*    Fun:    cmUnpkSotCancelReq
*
*    Desc:    unpack the primitive SotCancelReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCancelReq
(
SotCancelReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCancelReq(func, pst, mBuf,  sMem, maxBlkSize)
SotCancelReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCancelReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT230, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT231, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT232, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT233, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT234,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCancelReq*/
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmUnpkSotRelReq
*
*    Desc:    unpack the primitive SotRelReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRelReq
(
SotRelReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRelReq(func, pst, mBuf,  sMem, maxBlkSize)
SotRelReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotRelReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT235, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT236, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT237, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT238, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT239,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotRelReq*/

/*
*
*    Fun:    cmUnpkSotRelRsp
*
*    Desc:    unpack the primitive SotRelRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRelRsp
(
SotRelRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRelRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotRelRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotRelRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT240, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT241, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT242, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             SPutMsg(mBuf);/*  sot_c_002.main_10: free mBuf if allocevent fails */
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT243, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT244,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotRelRsp*/

/*
*
*    Fun:    cmUnpkSotModReq
*
*    Desc:    unpack the primitive SotModReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotModReq
(
SotModReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotModReq(func, pst, mBuf,  sMem, maxBlkSize)
SotModReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotModReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT245, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT246, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT247, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             SPutMsg(mBuf);/*  sot_c_002.main_10: free mBuf if allocevent fails */
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT248, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT249,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotModReq*/

/*
*
*    Fun:    cmUnpkSotModRsp
*
*    Desc:    unpack the primitive SotModRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotModRsp
(
SotModRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotModRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotModRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotModRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT250, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT251, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT252, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT253, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT254,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotModRsp*/

/*
*
*    Fun:    cmUnpkSotCAMReq
*
*    Desc:    unpack the primitive SotCAMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCAMReq
(
SotCAMReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCAMReq(func, pst, mBuf,  sMem, maxBlkSize)
SotCAMReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCAMReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT255, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT256, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT257, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT258, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT259,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCAMReq*/






/*- sot.c_001.main_10 : Packing/Unpacking for Lawful Call Intercept -*/
#ifdef SO_CALEA

/*
*
*    Fun:    cmUnpkSotRawMsg
*
*    Desc:    unpack the primitive cmUnpkSotRawMsg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRawMsg
(
SotRawMsg func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRawMsg(func, pst, mBuf,  sMem, maxBlkSize)
SotRawMsg func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
    SuId    suId;
    UConnId suConnId;
    UConnId spConnId;
    U32     transId;
    U32     callLegId;
    U32     messageId;
    U8      eventType;
    U8      sipMessageType;

    TRC3(cmUnpkSotRawMsg)

    CMCHKUNPKLOG(SUnpkS16, &suId     , mBuf, ESOT255, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId , mBuf, ESOT256, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId , mBuf, ESOT257, pst);
    CMCHKUNPKLOG(SUnpkU32, &transId  , mBuf, ESOT257, pst);
    CMCHKUNPKLOG(SUnpkU32, &callLegId, mBuf, ESOT257, pst);
    CMCHKUNPKLOG(SUnpkU32, &messageId, mBuf, ESOT257, pst);
    CMCHKUNPKLOG(SUnpkU8 , &eventType, mBuf, ESOT257, pst);
    CMCHKUNPKLOG(SUnpkU8 , &sipMessageType, mBuf, ESOT257, pst);

    RETVALUE((*func)(pst    , suId     , suConnId , spConnId ,
                     transId, callLegId, messageId, eventType,
                     sipMessageType, mBuf));

} /*end of function cmUnpkSotRawMsg*/

#endif











/*
*
*    Fun:    cmUnpkSotCAMRsp
*
*    Desc:    unpack the primitive SotCAMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCAMRsp
(
SotCAMRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCAMRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotCAMRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCAMRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT260, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT261, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT262, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT263, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT264,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCAMRsp*/
#ifdef SO_REL_1_2_INF

/*
*
*    Fun:    cmUnpkSotCIMReq
*
*    Desc:    unpack the primitive SotCIMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMReq
(
SotCIMReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMReq(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT265, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT266, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT267,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, soEvnt));
} /*end of function cmUnpkSotCIMReq*/

/*
*
*    Fun:    cmUnpkSotCIMRsp
*
*    Desc:    unpack the primitive SotCIMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMRsp
(
SotCIMRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT268, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT269, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT270,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, soEvnt));
} /*end of function cmUnpkSotCIMRsp*/
#else

/*
*
*    Fun:    cmUnpkSotCIMReq
*
*    Desc:    unpack the primitive SotCIMReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMReq
(
SotCIMReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMReq(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT271, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT272, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT273, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT274, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT275,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCIMReq*/

/*
*
*    Fun:    cmUnpkSotCIMRsp
*
*    Desc:    unpack the primitive SotCIMRsp
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMRsp
(
SotCIMRsp func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMRsp(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMRsp func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    UConnId spConnId;
    UConnId suConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMRsp)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT276, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT277, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT278, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT279, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT280,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, spConnId, suConnId, soEvnt));
} /*end of function cmUnpkSotCIMRsp*/
#endif /* SO_REL_1_2_INF */
#ifndef SO_REL_1_2_INF
#ifdef SO_UA

/*
*
*    Fun:    cmUnpkSotAuditReq
*
*    Desc:    unpack the primitive SotAuditReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotAuditReq
(
SotAuditReq func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotAuditReq(func, pst, mBuf,  sMem, maxBlkSize)
SotAuditReq func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SpId spId;
    SoEvnt *evnt;
    
    TRC3(cmUnpkSotAuditReq)

    CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESOT281, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&evnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (evnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT282, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&evnt, mBuf, ESOT283,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, spId, evnt));
} /*end of function cmUnpkSotAuditReq*/
#endif /* SO_UA */
#endif /* SO_REL_1_2_INF */

/*
*
*    Fun:    cmUnpkSotBndCfm
*
*    Desc:    unpack the primitive SotBndCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotBndCfm
(
SotBndCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSotBndCfm(func, pst, mBuf)
SotBndCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    SuId suId;
    U8 status;
    
    TRC3(cmUnpkSotBndCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT284, pst);
    CMCHKUNPKLOG(SUnpkU8, &status, mBuf, ESOT285, pst);
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, status));
} /*end of function cmUnpkSotBndCfm*/

/*
*
*    Fun:    cmUnpkSotConInd
*
*    Desc:    unpack the primitive SotConInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotConInd
(
SotConInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotConInd(func, pst, mBuf,  sMem, maxBlkSize)
SotConInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotConInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT286, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT287, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT288, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT289,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, spConnId, soEvnt));
} /*end of function cmUnpkSotConInd*/

/*
*
*    Fun:    cmUnpkSotConCfm
*
*    Desc:    unpack the primitive SotConCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotConCfm
(
SotConCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotConCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotConCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotConCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT290, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT291, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT292, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT293, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT294,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotConCfm*/

/*
*
*    Fun:    cmUnpkSotModInd
*
*    Desc:    unpack the primitive SotModInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotModInd
(
SotModInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotModInd(func, pst, mBuf,  sMem, maxBlkSize)
SotModInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotModInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT295, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT296, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT297, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT298, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT299,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotModInd*/

/*
*
*    Fun:    cmUnpkSotModCfm
*
*    Desc:    unpack the primitive SotModCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotModCfm
(
SotModCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotModCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotModCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotModCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT300, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT301, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT302, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT303, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT304,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotModCfm*/

/*
*
*    Fun:    cmUnpkSotCnStInd
*
*    Desc:    unpack the primitive SotCnStInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCnStInd
(
SotCnStInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCnStInd(func, pst, mBuf,  sMem, maxBlkSize)
SotCnStInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCnStInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT305, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT306, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT307, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT308, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT309,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCnStInd*/

/*
*
*    Fun:    cmUnpkSotRelCfm
*
*    Desc:    unpack the primitive SotRelCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRelCfm
(
SotRelCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRelCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotRelCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotRelCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT310, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT311, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT312, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT313, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT314,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotRelCfm*/

/*
*
*    Fun:    cmUnpkSotCAMCfm
*
*    Desc:    unpack the primitive SotCAMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCAMCfm
(
SotCAMCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCAMCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotCAMCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCAMCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT315, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT316, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT317, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT318, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT319,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCAMCfm*/

/*
*
*    Fun:    cmUnpkSotCAMInd
*
*    Desc:    unpack the primitive SotCAMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCAMInd
(
SotCAMInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCAMInd(func, pst, mBuf,  sMem, maxBlkSize)
SotCAMInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCAMInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT320, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT321, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT322, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT323, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT324,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCAMInd*/
#ifdef SO_REL_1_2_INF

/*
*
*    Fun:    cmUnpkSotRelInd
*
*    Desc:    unpack the primitive SotRelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRelInd
(
SotRelInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRelInd(func, pst, mBuf,  sMem, maxBlkSize)
SotRelInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    U8 relType;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotRelInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT325, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT326, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT327, pst);
    CMCHKUNPKLOG(SUnpkU8, &relType, mBuf, ESOT328, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT329, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT330,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, relType, soEvnt));
} /*end of function cmUnpkSotRelInd*/

/*
*
*    Fun:    cmUnpkSotCIMInd
*
*    Desc:    unpack the primitive SotCIMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMInd
(
SotCIMInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMInd(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT331, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT332, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT333,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, soEvnt));
} /*end of function cmUnpkSotCIMInd*/

/*
*
*    Fun:    cmUnpkSotCIMCfm
*
*    Desc:    unpack the primitive SotCIMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMCfm
(
SotCIMCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT334, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT335, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT336,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, soEvnt));
} /*end of function cmUnpkSotCIMCfm*/
#else

/*
*
*    Fun:    cmUnpkSotRelInd
*
*    Desc:    unpack the primitive SotRelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRelInd
(
SotRelInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRelInd(func, pst, mBuf,  sMem, maxBlkSize)
SotRelInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotRelInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT337, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT338, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT339, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT340, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT341,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotRelInd*/

/*
*
*    Fun:    cmUnpkSotCIMInd
*
*    Desc:    unpack the primitive SotCIMInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMInd
(
SotCIMInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMInd(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT342, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT343, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT344, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT345, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT346,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCIMInd*/

/*
*
*    Fun:    cmUnpkSotCIMCfm
*
*    Desc:    unpack the primitive SotCIMCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCIMCfm
(
SotCIMCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCIMCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotCIMCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCIMCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT347, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT348, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT349, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT350, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT351,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCIMCfm*/
#endif /* SO_REL_1_2_INF */
#ifndef SO_REL_1_2_INF

/*
*
*    Fun:    cmUnpkSotAckInd
*
*    Desc:    unpack the primitive SotAckInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotAckInd
(
SotAckInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotAckInd(func, pst, mBuf,  sMem, maxBlkSize)
SotAckInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotAckInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT352, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT353, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT354, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT355, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT356,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotAckInd*/

/*
*
*    Fun:    cmUnpkSotCancelInd
*
*    Desc:    unpack the primitive SotCancelInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotCancelInd
(
SotCancelInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotCancelInd(func, pst, mBuf,  sMem, maxBlkSize)
SotCancelInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotCancelInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT357, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT358, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT359, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT360, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT361,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, soEvnt));
} /*end of function cmUnpkSotCancelInd*/

#ifdef SO_UA
/*
*
*    Fun:    cmUnpkSotAuditCfm
*
*    Desc:    unpack the primitive SotAuditCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotAuditCfm
(
SotAuditCfm func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotAuditCfm(func, pst, mBuf,  sMem, maxBlkSize)
SotAuditCfm func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    SoEvnt *soEvnt;
    
    TRC3(cmUnpkSotAuditCfm)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT362, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&soEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (soEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT363, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&soEvnt, mBuf, ESOT364,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, soEvnt));
} /*end of function cmUnpkSotAuditCfm*/
#endif /* SO_UA */

/*
*
*    Fun:    cmUnpkSotErrInd
*
*    Desc:    unpack the primitive SotErrInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotErrInd
(
SotErrInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotErrInd(func, pst, mBuf,  sMem, maxBlkSize)
SotErrInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *errEvnt;
    
    TRC3(cmUnpkSotErrInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT365, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT366, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT367, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&errEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (errEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT368, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&errEvnt, mBuf, ESOT369,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, errEvnt));
} /*end of function cmUnpkSotErrInd*/

/*
*
*    Fun:    cmUnpkSotRefreshInd
*
*    Desc:    unpack the primitive SotRefreshInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     sot.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSotRefreshInd
(
SotRefreshInd func,
Pst *pst,
Buffer *mBuf,
Mem *sMem,
Size maxBlkSize
)
#else
PUBLIC S16 cmUnpkSotRefreshInd(func, pst, mBuf,  sMem, maxBlkSize)
SotRefreshInd func;
Pst *pst;
Buffer *mBuf;
Mem *sMem;
Size maxBlkSize;
#endif
{
#ifdef LCSOT
    S16 ret1;
#endif
    SuId suId;
    UConnId suConnId;
    UConnId spConnId;
    SoEvnt *refreshEvnt;
    
    TRC3(cmUnpkSotRefreshInd)

    CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESOT370, pst);
    CMCHKUNPKLOG(SUnpkU32, &suConnId, mBuf, ESOT371, pst);
    CMCHKUNPKLOG(SUnpkU32, &spConnId, mBuf, ESOT372, pst);
    switch(pst->selector)
    {
#ifdef LCSOT
       case SO_SSAP_LC:
          if(cmAllocEvnt(sizeof(SoEvnt), maxBlkSize, sMem,
            (Ptr*)&refreshEvnt) != ROK)
          {
             RETVALUE(RFAILED);
          }
          ret1 = cmUnpkSoEvnt( (refreshEvnt), sMem , maxBlkSize ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
          if(ret1 != ROK)
          {
             SPutMsg(mBuf);
             SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
                  (ErrVal)ESOT373, (ErrVal)ret1, "Unpacking failure");
             RETVALUE( ret1 );
          }
#endif /* ERRCLASS & ERRCLS_DEBUG */
       break;
#endif /* LCSOT */
#ifdef LWLCSOT
       case  SO_SSAP_LWLC:
          CMCHKUNPKLOG(cmUnpkPtr, (PTR*)&refreshEvnt, mBuf, ESOT374,pst);
       break;
#endif /* LWLCSOT */
    }
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, suId, suConnId, spConnId, refreshEvnt));
} /*end of function cmUnpkSotRefreshInd*/
#endif /* SO_REL_1_2_INF */

#ifdef CM_SDP_SIP_IM_SUPPORT

/*
*
*    Fun:    cmPkCmSdpMedFmtAddrSpecList
*
*    Desc:    pack the structure CmSdpMedFmtTnList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCmSdpMedFmtAddrSpecList
(
CmSdpMedFmtSipList *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkCmSdpMedFmtAddrSpecList(param ,mBuf)
CmSdpMedFmtSipList *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkCmSdpMedFmtAddrSpecList)

    if( param->num.pres != NOTPRSNT )
    {
       for (i=param->num.val-1;i>=0;i--)
       {
          CMCHKPK(cmPkSoAddrSpec, (SoAddrSpec*)(param->fmts[i]), mBuf);
       }
    }
    CMCHKPK(cmPkTknU16, &param->num,mBuf);
    return(ROK);
} /*end of function cmPkCmSdpMedFmtAddrSpecList*/


/*
*
*    Fun:    cmUnpkCmSdpMedFmtAddrSpecList
*
*    Desc:    unpack the structure cmSdpMedFmtSipList
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cm_sdp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCmSdpMedFmtAddrSpecList
(
CmSdpMedFmtSipList *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkCmSdpMedFmtAddrSpecList(param ,ptr, mBuf)
CmSdpMedFmtSipList *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkCmSdpMedFmtAddrSpecList)

    CMCHKUNPK(cmUnpkTknU16, &param->num,mBuf);
    if( param->num.pres != NOTPRSNT )
    {
       CMGETMBLK(ptr, sizeof(Ptr)*(param->num.val), (Ptr*)&(param->fmts));
       for (i=0;i<param->num.val;i++)
       {
          CMGETMBLK(ptr, sizeof(SoAddrSpec), (Ptr*)&(param->fmts[i]));
          CMCHKUNPKPTR(cmUnpkSoAddrSpec, (SoAddrSpec*)(param->fmts[i]), mBuf, ptr);
       }
    }
    return(ROK);
} /*end of function cmUnpkCmSdpMedFmtAddrSpecList*/
#endif /* CM_SDP_SIP_IM_SUPPORT */


#ifdef __cplusplus
}
#endif /*__cplusplus*/

#endif /* #if(defined(LCSOT) || defined(LWLCSOT)) */


/********************************************************************30**

         End of file:     sot.c@@/main/10 - Tue Apr 20 00:23:22 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      bsr  1. initial release.
/main/2      ---      cy   1. release 1.2
/main/10     ---      wh   1. release 2.1
/main/10+    sot_c_001.main_10  ng   1. Added changes for lawful intercept
/main/10+    sot_c_002.main_10  ng   2. Free mBuf if allocevent fails
*********************************************************************91*/

