/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Common STU Interface functions
  
     Type:     Common Source File
  
     Desc:     Routines shared across the STU interface
 
     File:     stu.c

     Sid:      stu.c@@/main/16 - Fri Sep 16 02:51:42 2005
  
     Prg:      fmg
  
*********************************************************************21*/
 


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "stu.h"           /* common stu */
#include "cm_ss7.h"        /* common ss7 */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */
#include "stu.x"           /* common stu */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

#ifdef LCSTU
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
PRIVATE S16  cmUnpkCode    ARGS((StAnsCode   *code,   Buffer *mBuf));
PRIVATE S16  cmUnpkCompId  ARGS((StAnsCompId *compId, Buffer *mBuf));
PRIVATE S16  cmPkCode      ARGS((StAnsCode   *code,   Buffer *mBuf));
PRIVATE S16  cmPkCompId    ARGS((StAnsCompId *compId, Buffer *mBuf));
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */
#endif /* LCSTU */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */
/*
 * support functions
 */


/*
*
*       Fun:    cmZeroStComp
*
*       Desc:   Initialize the TCAP component event structure with all zero
*               values.
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmZeroStComp
(
StComps    *compEv          /* component structure */
)
#else
PUBLIC S16 cmZeroStComp(compEv)
StComps    *compEv;         /* component structure */
#endif
{
   /* zero out components */

   cmZero((Data *)compEv, sizeof(StComps));

   RETVALUE(ROK);
} /* end of cmZeroStComp */

#ifdef LCSTU

/*
*
*       Fun:   cmPkStComp
*
*       Desc:  Pack an TCAP component event structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStComp
(
StComps   *compEv,   /* Component event */
Buffer    *mBuf      /* Message buffer to pack the component event */
)
#else
PUBLIC S16 cmPkStComp(compEv, mBuf)
StComps   *compEv;   /* Component event */
Buffer    *mBuf;     /* Message buffer to pack the component event */
#endif
{
   TRC2(cmPkStComp)

   /* pack each type of component */

   if (compEv == (StComps *)NULLP)
   {
      RETVALUE(RFAILED);
   }

   /* Pack the component event parameters, last parameter first */

   CMCHKPK(cmPkBool, compEv->stLastCmp, mBuf);
   CMCHKPK(cmPkBool, compEv->cancelFlg, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   CMCHKPK(SPkU8,       compEv->stParamFlg,     mBuf);
   CMCHKPK(cmPkCode,    &compEv->stAnsProbCode, mBuf);
   CMCHKPK(cmPkStOctet, &compEv->stAnsErrCode,  mBuf);
   CMCHKPK(cmPkCode,    &compEv->stAnsOpCode,   mBuf);
   CMCHKPK(cmPkCompId,  &compEv->stCompId,      mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */

   CMCHKPK(cmPkStStr, &compEv->stProbCode,    mBuf);
   CMCHKPK(SPkU8,     compEv->stProbCodeFlg,  mBuf);
   CMCHKPK(cmPkStStr, &compEv->stErrorCode,   mBuf);
   CMCHKPK(SPkU8,     compEv->stErrorCodeFlg, mBuf);
   CMCHKPK(cmPkStStr, &compEv->stOpCode,      mBuf);
   CMCHKPK(SPkU8,     compEv->stOpCodeFlg,    mBuf);
   CMCHKPK(SPkU8,     compEv->opClass,        mBuf);
   CMCHKPK(SPkU16,    compEv->stInvokeTimer,  mBuf);

   if (compEv->stLinkedId.pres == TRUE)
   {
      /* pack octet contents */
      CMCHKPK(SPkS8, compEv->stLinkedId.octet, mBuf);
   }

   /* pack present/nonpresent */
   CMCHKPK(cmPkBool, compEv->stLinkedId.pres,  mBuf);

   if (compEv->stInvokeId.pres == TRUE)
   {
      /* pack octet contents */
      CMCHKPK(SPkS8, compEv->stInvokeId.octet, mBuf);
   }

   /* pack present/nonpresent */
   CMCHKPK(cmPkBool, compEv->stInvokeId.pres, mBuf);

   CMCHKPK(cmPkStCompType, compEv->stCompType, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStComp */


/*
*
*       Fun:   cmUnpkStComp
*
*       Desc:  This function is used to unpack a TCAP component event structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStComp
(
StComps   *compEv,   /* Component event */
Buffer    *mBuf      /* Message buffer containing the component event */
)
#else
PUBLIC S16 cmUnpkStComp(compEv, mBuf)
StComps   *compEv;   /* Component event */
Buffer    *mBuf;     /* Message buffer containing the component event */
#endif
{
   TRC2(cmUnpkStComp)

   /* Initialize the event structure */
   cmZero((Data *)compEv, sizeof(StComps));

   CMCHKUNPK(cmUnpkStCompType, &compEv->stCompType, mBuf);

   CMCHKUNPK(cmUnpkBool, &compEv->stInvokeId.pres,  mBuf);
   
   /* Unpack Invoke Id only if it is present */
   if (compEv->stInvokeId.pres == TRUE)
   {
      CMCHKUNPK(SUnpkS8, &compEv->stInvokeId.octet, mBuf);
   }

   CMCHKUNPK(cmUnpkBool, &compEv->stLinkedId.pres,  mBuf);

   /* Unpack Linked Id only if it is present */
   if (compEv->stLinkedId.pres == TRUE)
   {
      CMCHKUNPK(SUnpkS8, &compEv->stLinkedId.octet, mBuf);
   }

   CMCHKUNPK(SUnpkU16,      &compEv->stInvokeTimer,  mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->opClass,        mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->stOpCodeFlg,    mBuf);
   CMCHKUNPK(cmUnpkStStr,   &compEv->stOpCode,       mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->stErrorCodeFlg, mBuf);
   CMCHKUNPK(cmUnpkStStr,   &compEv->stErrorCode,    mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->stProbCodeFlg,  mBuf);
   CMCHKUNPK(cmUnpkStStr,   &compEv->stProbCode,     mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   CMCHKUNPK(cmUnpkCompId,  &compEv->stCompId,       mBuf);
   CMCHKUNPK(cmUnpkCode,    &compEv->stAnsOpCode,    mBuf);
   CMCHKUNPK(cmUnpkStOctet, &compEv->stAnsErrCode,   mBuf);
   CMCHKUNPK(cmUnpkCode,    &compEv->stAnsProbCode,  mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->stParamFlg,     mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */

   CMCHKUNPK(SUnpkU8,       &compEv->cancelFlg,      mBuf);
   CMCHKUNPK(SUnpkU8,       &compEv->stLastCmp,      mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkStComp */


/*
*
*       Fun:   cmPkStDlgEv
*
*       Desc:  Pack a TCAP dialog event structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStDlgEv
(
StDlgEv   *dlgEv,       /* Dialogue event structure */
Buffer    *mBuf         /* Message buffer to pack the event structure */
)
#else
PUBLIC S16 cmPkStDlgEv(dlgEv, mBuf)
StDlgEv   *dlgEv;       /* Dialogue event structure */
Buffer    *mBuf;        /* Message buffer to pack the event structure */
#endif
{
/* Rolling Upgrade Feature */
/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   S16    rVal;
#endif
   
   TRC2(cmPkStDlgEv)

   /* Pack the dialogue event only if it is present, otherwise just pack the
      present field */
           
/* Rolling Upgrade Feature */
/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if ((dlgEv->pres == TRUE) && (dlgEv->ansiDlgEv.pres.pres == TRUE))
   {
      if ((dlgEv->ansiDlgEv.usrInfo.pres == TRUE) &&
          (dlgEv->ansiDlgEv.usrInfo.val != NULLP))
      {
         rVal = SCatMsg(mBuf, dlgEv->ansiDlgEv.usrInfo.val, M1M2);

         /* Deallocate the user info buffer */
         (Void)SPutMsg(dlgEv->ansiDlgEv.usrInfo.val);
 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (rVal != ROK)
         {
            (Void)SPutMsg(mBuf);
            RETVALUE(rVal);
         }
#endif
         CMCHKPK( SPkU8, TRUE, mBuf); /* User Information is packed */
      }
      /* User info present flag field pack fix */
      else
      {
         CMCHKPK( SPkU8, FALSE, mBuf); /* User Information is not packed */
      }
      CMCHKPK( cmPkTknStr64, &dlgEv->ansiDlgEv.confInfo, mBuf);

      if (dlgEv->ansiDlgEv.secType.pres)
      {
         if (dlgEv->ansiDlgEv.secType.val == ST_ANS_ENC_TYP_OID)
         {
            CMCHKPK( cmPkTknOid, &dlgEv->ansiDlgEv.secCntxt.oidSec, mBuf);
         }
         else
         {
            CMCHKPK( cmPkTknS32, &dlgEv->ansiDlgEv.secCntxt.intSec, mBuf);
         }
      }

      CMCHKPK( cmPkTknU8, &dlgEv->ansiDlgEv.secType, mBuf);

      if (dlgEv->ansiDlgEv.acnType.pres)
      {
         if (dlgEv->ansiDlgEv.acnType.val == ST_ANS_ENC_TYP_OID)
         {
            CMCHKPK( cmPkTknOid, &dlgEv->ansiDlgEv.acn.oidAcn, mBuf);
         }
         else
         {
            CMCHKPK( cmPkTknS32, &dlgEv->ansiDlgEv.acn.intAcn, mBuf);
         }
      }

      CMCHKPK( cmPkTknU8, &dlgEv->ansiDlgEv.acnType, mBuf);
 
      /* Pack Ansi dialogue event present/not-present flag */
      CMCHKPK( cmPkBool, dlgEv->ansiDlgEv.pres.pres, mBuf);
   }
   else
/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#endif /* SS7_ANS96 || SS7_ANS88 || SS7_ANS92 */

   if (dlgEv->pres == TRUE)
   {
      CMCHKPK( SPkU8, dlgEv->abrtSrc, mBuf);

      if(dlgEv->resPres)
      {
         CMCHKPK( SPkU8, dlgEv->resReason, mBuf);
         CMCHKPK( SPkU8, dlgEv->resSrc,    mBuf);
         CMCHKPK( SPkU8, dlgEv->result,    mBuf);
      }

      CMCHKPK( cmPkBool,   dlgEv->resPres,   mBuf);
      CMCHKPK( cmPkStStr, &dlgEv->apConName, mBuf);
      CMCHKPK( SPkU8,      dlgEv->stDlgType, mBuf);

/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
      /* Pack Ansi dialogue event present/not-present flag */
      CMCHKPK( cmPkBool, dlgEv->ansiDlgEv.pres.pres, mBuf);
#endif /* SS7_ANS96 || SS7_ANS88 || SS7_ANS92  */
   }

   /* pack present/not-present */
   CMCHKPK(cmPkBool, dlgEv->pres, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkStDlgEv */


/*
*
*       Fun:   cmUnpkStDlgEv
*
*       Desc:  Unpack a TCAP dialog event structure
*
*       Ret:   ROK if successful
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStDlgEv
(
StDlgEv   *dlgEv,    /* Dialogue Event structure */
Buffer   **msgBuf,   /* Buffer containing the dialogue event */
Bool       stUnpkUInfo  /* Whether to unpack user info */
)
#else
PUBLIC S16 cmUnpkStDlgEv(dlgEv, msgBuf, stUnpkUInfo)
StDlgEv   *dlgEv;    /* Dialogue Event structure */
Buffer   **msgBuf;   /* Buffer containing the dialogue event */
Bool       stUnpkUInfo; /* Whether to unpack user info */
#endif
{

/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   MsgLen    bufLen;
#endif

   Buffer   *mBuf;

   TRC2(cmUnpkStDlgEv)

   mBuf = *msgBuf;

   /* Initialize the dialogue event structure */
   cmZero((Data *)dlgEv, sizeof(StDlgEv));

   /* Unpack the dialogue event present field*/
   CMCHKUNPK( cmUnpkBool, &dlgEv->pres, mBuf);

   if (!dlgEv->pres)
   {
      /* Dialogue event not present, returns */
      RETVALUE(ROK);
   }

/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   /* Unpack the Ansi dialogue event present flag */
   CMCHKUNPK( cmUnpkBool, &dlgEv->ansiDlgEv.pres.pres, mBuf);

   if (dlgEv->ansiDlgEv.pres.pres == TRUE)
   {
      CMCHKUNPK( cmUnpkTknU8, &dlgEv->ansiDlgEv.acnType, mBuf);
      if (dlgEv->ansiDlgEv.acnType.pres == TRUE)
      {
         if (dlgEv->ansiDlgEv.acnType.val == ST_ANS_ENC_TYP_OID)
         {
            CMCHKUNPK( cmUnpkTknOid, &dlgEv->ansiDlgEv.acn.oidAcn, mBuf);
         }
         else
         {
            CMCHKUNPK( cmUnpkTknS32, &dlgEv->ansiDlgEv.acn.intAcn, mBuf);
         }
      }
      
      CMCHKUNPK( cmUnpkTknU8, &dlgEv->ansiDlgEv.secType, mBuf);
      if (dlgEv->ansiDlgEv.secType.pres == TRUE)
      {
         if (dlgEv->ansiDlgEv.secType.val == ST_ANS_ENC_TYP_OID)
         {
            CMCHKUNPK( cmUnpkTknOid, &dlgEv->ansiDlgEv.secCntxt.oidSec, mBuf);
         }
         else
         {
            CMCHKUNPK( cmUnpkTknS32, &dlgEv->ansiDlgEv.secCntxt.intSec, mBuf);
         }
      }
      
      CMCHKUNPK( cmUnpkTknStr64, &dlgEv->ansiDlgEv.confInfo, mBuf);
      CMCHKUNPK( SUnpkU8, &dlgEv->ansiDlgEv.usrInfo.pres, mBuf);

      (Void)SFndLenMsg(mBuf, &bufLen);
      if ((dlgEv->ansiDlgEv.usrInfo.pres == TRUE) && (bufLen > 0))
      {
         dlgEv->ansiDlgEv.usrInfo.pres = TRUE;
         /* imp, isni fields are present in the mBuf, if the
          * interface version is STUV2. So remaining bytes in mBuf are not all 
          * user info. Do not copy the user info section from mBuf at this 
          * point. 
          */
         if (stUnpkUInfo)
         {        
            dlgEv->ansiDlgEv.usrInfo.val  = mBuf;
            *msgBuf = NULLP;
         }
      }
      RETVALUE(ROK);
   }
/* Modified #if section to make it available for 
   ANSI88, ANSI92 and ANSI96 */
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */

   CMCHKUNPK( SUnpkU8,     &dlgEv->stDlgType, mBuf);
   CMCHKUNPK( cmUnpkStStr, &dlgEv->apConName, mBuf);
   CMCHKUNPK( cmUnpkBool,  &dlgEv->resPres,   mBuf);

   if (dlgEv->resPres)
   {
      CMCHKUNPK( SUnpkU8, &dlgEv->result,    mBuf);
      CMCHKUNPK( SUnpkU8, &dlgEv->resSrc,    mBuf);
      CMCHKUNPK( SUnpkU8, &dlgEv->resReason, mBuf);
   }

   CMCHKUNPK( SUnpkU8, &dlgEv->abrtSrc, mBuf);

   RETVALUE(ROK);
}  /* end of cmUnpkStDlgEv */


/*
*
*       Fun:   cmPkStQosSet
*
*       Desc:  Pack TCAP quality of service set
*
*       Ret:   ROK if successful
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStQosSet
(
StQosSet   *qos,         /* qos set */
Buffer     *mBuf         /* message buffer to pack the Qos Set */
)
#else
PUBLIC S16 cmPkStQosSet(qos, mBuf)
StQosSet   *qos;         /* qos set */
Buffer     *mBuf;        /* message buffer to pack the Qos Set */
#endif
{
   
   TRC2(cmPkStQosSet)

   CMCHKPK( cmPkPrior, qos->msgPrior, mBuf);
   CMCHKPK( SPkU8,     qos->retOpt,   mBuf);
   CMCHKPK( SPkU8,     qos->seqCtl,   mBuf);

   RETVALUE(ROK);
} /* end of cmPkStQosSet */


/*
*
*       Fun:   cmUnpkStQosSet
*
*       Desc:  unpack TCAP quality of service set
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStQosSet
(
StQosSet   *qos,         /* qos set */
Buffer     *mBuf         /* message buffer containing the Qos Set */
)
#else
PUBLIC S16 cmUnpkStQosSet(qos, mBuf)
StQosSet   *qos;         /* qos set */
Buffer     *mBuf;        /* message buffer containing the Qos Set */
#endif
{
   
   TRC2(cmUnpkStQosSet)

   CMCHKUNPK( SUnpkU8,     &qos->seqCtl,   mBuf);
   CMCHKUNPK( SUnpkU8,     &qos->retOpt,   mBuf);
   CMCHKUNPK( cmUnpkPrior, &qos->msgPrior, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkStQosSet */


#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
/*
*
*       Fun:   cmPkCode
*
*       Desc:  Pack an Ansi TCAP Component Code
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCode
(
StAnsCode    *code,       /* Component code */
Buffer       *mBuf        /* Buffer to pack the code */
)
#else
PRIVATE S16 cmPkCode(code, mBuf)
StAnsCode    *code;       /* Component code */
Buffer       *mBuf;       /* Buffer to pack the code */
#endif
{
   
   TRC2(cmPkCode)

   if (code->pres == TRUE)
   {
      /* pack contents */
      CMCHKPK( SPkU8, code->specifier, mBuf);
      CMCHKPK( SPkU8, code->type,      mBuf);
   }

   /* pack present/nonpresent */
   CMCHKPK( cmPkBool, code->pres, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkCode */


/*
*
*       Fun:   cmUnpkCode
*
*       Desc:  This function is used to unpack a TCAP code
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCode
(
StAnsCode    *code,       /* Component code */
Buffer       *mBuf        /* Buffer containing the code */
)
#else
PRIVATE S16 cmUnpkCode(code, mBuf)
StAnsCode    *code;       /* Component code */
Buffer       *mBuf;       /* Buffer containing the code */
#endif
{
   
   TRC2(cmUnpkCode)

   CMCHKUNPK( cmUnpkBool, &code->pres, mBuf);
   
   if (code->pres == TRUE)
   {
      /* unpack contents */
      CMCHKUNPK( SUnpkU8, &code->type,      mBuf);
      CMCHKUNPK( SUnpkU8, &code->specifier, mBuf);
   }

   RETVALUE(ROK);
} /* end of cmUnpkCode */


/*
*
*       Fun:   cmPkCompId
*
*       Desc:  Pack an Ansi TCAP Comp Id
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkCompId
(
StAnsCompId    *compId,    /* Component Id */
Buffer         *mBuf       /* Buffer to pack component Id */
)
#else
PRIVATE S16 cmPkCompId(compId, mBuf)
StAnsCompId    *compId;    /* Component Id */
Buffer         *mBuf;      /* Buffer to pack component Id */
#endif
{
   TRC2(cmPkCompId)

   if (compId->pres == TRUE)
   {
      if (compId->corrPres)
      {
         CMCHKPK( SPkU8, compId->corrId, mBuf);
      }
      
      CMCHKPK( cmPkBool, compId->corrPres, mBuf);
      
      if (compId->invPres)
      {
         CMCHKPK( SPkU8, compId->invokeId, mBuf);
      }
      
      CMCHKPK( cmPkBool, compId->invPres, mBuf);
   }

   /* pack present/nonpresent */
   CMCHKPK( cmPkBool, compId->pres, mBuf);
   
   RETVALUE(ROK);
}  /* end of cmPkCompId */


/*
*
*       Fun:   cmUnpkCompId
*
*       Desc:  This function is used to unpack a TCAP component id
*
*       Ret:   ROK on success
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkCompId
(
StAnsCompId    *compId,    /* Component Id */
Buffer         *mBuf       /* Buffer containing the component Id */
)
#else
PRIVATE S16 cmUnpkCompId(compId, mBuf)
StAnsCompId    *compId;    /* Component Id */
Buffer         *mBuf;      /* Buffer containing the component Id */
#endif
{
   TRC2(cmUnpkCompId)

   CMCHKUNPK( cmUnpkBool, &compId->pres, mBuf);
   
   if (compId->pres == TRUE)
   {
      CMCHKUNPK( cmUnpkBool, &compId->invPres, mBuf);

      if (compId->invPres == TRUE)
      {
         CMCHKUNPK( SUnpkU8, &compId->invokeId, mBuf);
      }
      
      CMCHKUNPK( cmUnpkBool, &compId->corrPres, mBuf);

      if (compId->corrPres == TRUE)
      {
         CMCHKUNPK( SUnpkU8, &compId->corrId, mBuf);
      }
   }

   RETVALUE(ROK);
} /* end of cmUnpkCompId */
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 */


/*
*     Packing routines for primitives flowing from TCAP-User to TCAP at
*     STU Interface.
*/

/*
*
*       Fun:   cmPkStuBndReq
*
*       Desc:  This function packs the STU bind request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStuBndReq
(
Pst      *pst,           /* Post structure */
SuId      suId,          /* service provider id */
SpId      spId,          /* service provider id */
Ssn       ssn            /* sub system number */
)
#else
PUBLIC S16 cmPkStuBndReq(pst, suId, spId, ssn)
Pst      *pst;           /* Post structure */
SuId      suId;          /* service user id */
SpId      spId;          /* service provider id */
Ssn       ssn;           /* sub system number */
#endif
{
   Buffer *mBuf;         /* message buffer */
   
   TRC3(cmPkStuBndReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU001, pst);
   CMCHKPKLOG( cmPkSpId, spId, mBuf, ESTU002, pst);
   CMCHKPKLOG( cmPkSsn,  ssn,  mBuf, ESTU003, pst);

   pst->event = (Event)EVTSTUBNDREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuBndReq  */


/*
*
*       Fun:   cmPkStuUbndReq
*
*       Desc:  This function packs the STU unbind request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStuUbndReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id */
Reason    reason
)
#else
PUBLIC S16 cmPkStuUbndReq(pst, spId, reason)
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id */
Reason    reason;
#endif
{
   Buffer *mBuf;            /* message buffer */

   TRC3(cmPkStuUbndReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkSpId,   spId ,  mBuf, ESTU004, pst);
   CMCHKPKLOG( cmPkReason, reason, mBuf, ESTU005, pst);

   pst->event = (Event)EVTSTUUBNDREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuUbndReq  */


/*
*
*       Fun:   cmPkStuCmpReq
*
*       Desc:  This function packs the STU Component request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStuCmpReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id */
StDlgId   suDlgId,       /* service user dialog id */
StDlgId   spDlgId,       /* service provider dialogue id */
StComps  *compEv,        /* component */
Buffer   *cpBuf          /* Component parameter buffer */
)
#else
PUBLIC S16 cmPkStuCmpReq(pst, spId, suDlgId, spDlgId, compEv, cpBuf)
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id */
StDlgId   suDlgId;       /* service user dialog id */
StDlgId   spDlgId;       /* service provider dialogue id */
StComps  *compEv;        /* component */
Buffer   *cpBuf;         /* Component parameter buffer */
#endif
{
   S16     rVal;
   Buffer *mBuf;            /* message buffer */

   TRC3(cmPkStuCmpReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   if (cpBuf != NULLP)
   {
      rVal = SCatMsg(mBuf, cpBuf, M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(cpBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU006, rVal, "cmPkStuCmpReq:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      (Void)SPutMsg(cpBuf);
   }

   CMCHKPKLOG( cmPkStComp,  compEv,  mBuf, ESTU007, pst);
   CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU008, pst);
   CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU009, pst);
   CMCHKPKLOG( cmPkSpId,    spId,    mBuf, ESTU010, pst);

   pst->event = (Event)EVTSTUCMPREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuCmpReq  */


/*
*
*       Fun:   cmPkStuDatReq
*
*       Desc:  This function packs the STU data request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStuDatReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id */
U8        msgType,       /* TCAP message type */
StDlgId   suDlgId,       /* service user dialog id */
StDlgId   spDlgId,       /* service provider dialogue id */
SpAddr   *dstAddr,       /* SCCP destination address - if needed */
SpAddr   *srcAddr,       /* SCCP source address - if needed */
Bool      endFlg,        /* If true then pre-arranged termination */
StQosSet *qosSet,        /* Quality of Service set for SCCP */
StDlgEv  *dlgEv,         /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam, /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf          /* User info buffer */
)
#else
#ifdef STUV2
PUBLIC S16 cmPkStuDatReq(pst, spId, msgType, suDlgId, spDlgId, dstAddr,
                         srcAddr, endFlg, qosSet, dlgEv, dataParam, uiBuf)
#else /*  not STUV2 */
PUBLIC S16 cmPkStuDatReq(pst, spId, msgType, suDlgId, spDlgId, dstAddr,
                            srcAddr, endFlg, qosSet, dlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id */
U8        msgType;       /* TCAP message type */
StDlgId   suDlgId;       /* service user dialog id */
StDlgId   spDlgId;       /* service provider dialogue id */
SpAddr   *dstAddr;       /* SCCP destination address - if needed */
SpAddr   *srcAddr;       /* SCCP source address - if needed */
Bool      endFlg;        /* If true then pre-arranged termination */
StQosSet *qosSet;        /* Quality of Service set for SCCP */
StDlgEv  *dlgEv;         /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam;  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;         /* User info buffer */
#endif
{
   S16     rVal;
   Buffer *mBuf;
   U8      len;
   /* Interface version number */
   CmIntfVer intfVer;   /* remote interface version number */
   
   TRC3(cmPkStuDatReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use  interface version as in pst 
    * structure, else use self STU interface version. 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   if (uiBuf != NULLP)
   {
      rVal = SCatMsg(mBuf, uiBuf, M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(uiBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU011, rVal, "cmPkStuDatReq:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      (Void)SPutMsg(uiBuf);
   }
   
   /*  pack fields based on interface version  */
   switch(intfVer)
   {
      case 0x0100:    /* Interface version STUV1 */
      {
         if (dlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv,  dlgEv,  mBuf, ESTU012, pst);
         }
         else
         {
            StDlgEv   tmpDlgEv;

            tmpDlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv,  &tmpDlgEv,  mBuf, ESTU013, pst);
         }
         CMCHKPKLOG( cmPkStQosSet, qosSet, mBuf, ESTU014, pst);
         CMCHKPKLOG( cmPkBool,     endFlg, mBuf, ESTU015, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU016, rVal, 
                        "cmPkStuDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(dstAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU017, rVal, 
                        "cmPkStuDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU018, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU019, pst);
         CMCHKPKLOG( SPkU8,       msgType, mBuf, ESTU020, pst);
         CMCHKPKLOG( cmPkSpId,    spId,    mBuf, ESTU021, pst);          
      }
         break;          

      case 0x0200:    /* Interface version STUV2 */
      case 0x0300:    /* Interface version STUV3, there is no difference in 
                         DatReq for STUV2 and STUV3 */
      {
         /* Set bit vector value if Rolling Upgrade support is enabled */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector  */
  
         /* Initialize bit vector */
         bitVector = 0; 
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#ifdef STUV2
         /* pack isni for ANS96 variant */
#ifdef SS7_ANS96
          CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */         
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */

         if (dlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv,  dlgEv,  mBuf, ESTU012, pst);
         }
         else
         {
            StDlgEv   tmpDlgEv;

            tmpDlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv,  &tmpDlgEv,  mBuf, ESTU013, pst);
         }
         CMCHKPKLOG( cmPkStQosSet, qosSet, mBuf, ESTU014, pst);
         CMCHKPKLOG( cmPkBool,     endFlg, mBuf, ESTU015, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU016, rVal, 
                        "cmPkStuDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(dstAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU017, rVal, 
                        "cmPkStuDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif
         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU018, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU019, pst);
         CMCHKPKLOG( SPkU8,       msgType, mBuf, ESTU020, pst);
         CMCHKPKLOG( cmPkSpId,    spId,    mBuf, ESTU021, pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }    
         break;

      default:
         RETVALUE(RINVIFVER);
         break;
   }/* switch(intfVer) */

   pst->event = (Event)EVTSTUDATREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuDatReq */


/*
*
*       Fun:   cmPkStuUDatReq
*
*       Desc:  This function packs the STU Unit data request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkStuUDatReq
(
Pst      *pst,           /* Post structure */
SpId      spId,          /* service provider id */
StDlgId   suDlgId,       /* service user dialog id */
StDlgId   spDlgId,       /* service provider dialogue id */
SpAddr   *dstAddr,       /* SCCP destination address - if needed */
SpAddr   *srcAddr,       /* SCCP source address - if needed */
StQosSet *qosSet,        /* Quality of Service set for SCCP */
StDlgEv  *dlgEv,         /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam,  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf          /* User info buffer */
)
#else
#ifdef STUV2
PUBLIC S16 cmPkStuUDatReq(pst, spId, suDlgId, spDlgId, dstAddr, srcAddr,
                             qosSet, dlgEv, dataParam, uiBuf)
#else  /* not STUV2 */
PUBLIC S16 cmPkStuUDatReq(pst, spId, suDlgId, spDlgId, dstAddr, srcAddr,
                             qosSet, dlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;           /* Post structure */
SpId      spId;          /* service provider id */
StDlgId   suDlgId;       /* service user dialog id */
StDlgId   spDlgId;       /* service provider dialogue id */
SpAddr   *dstAddr;       /* SCCP destination address - if needed */
SpAddr   *srcAddr;       /* SCCP source address - if needed */
StQosSet *qosSet;        /* Quality of Service set for SCCP */
StDlgEv  *dlgEv;         /* tcap dialog portion event */
#ifdef STUV2
StDataParam *dataParam;  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;         /* User info buffer */
#endif
{
   S16     rVal;
   Buffer *mBuf;
   U8      len;
   /* Interface version number */
   CmIntfVer intfVer;   /* remote interface version number */  

   TRC3(cmPkStuUDatReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use interface version as in pst 
    * structure, else use self STU interface version. 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   if (uiBuf != NULLP)
   {
      rVal = SCatMsg(mBuf, uiBuf, M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(uiBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU022, rVal, "cmPkStuUDatReq:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      (Void)SPutMsg(uiBuf);
   }

   /*  pack fields based on interface version */
   switch(intfVer)
   {
      case 0x0100:    /* Interface version STUV1 */
      {
         if (dlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv,  dlgEv,  mBuf, ESTU023, pst);
         }
         else
         {
            StDlgEv   tmpDlgEv;

            tmpDlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv,  &tmpDlgEv,  mBuf, ESTU024, pst);
         }
         CMCHKPKLOG( cmPkStQosSet, qosSet, mBuf, ESTU025, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU026, rVal, 
                        "cmPkStuUDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(dstAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU027, rVal, 
                        "cmPkStuUDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU028, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU029, pst);
         CMCHKPKLOG( cmPkSpId,    spId,    mBuf, ESTU030, pst);
      }
         break;

      case 0x0200:    /* Interface version STUV2 */
      case 0x0300:    /* Interface version STUV3, there is no difference
                         in UDatReq for STUV2 and STUV3 */
      {
         /* Set bit vector value if Rolling Upgrade support is enabled */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector array */
  
         /* Initialize bit vector  */
         bitVector = 0; 
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#ifdef STUV2
         /* pack isni for ANS96 variant */
#ifdef SS7_ANS96
          CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */         
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */   

         if (dlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv,  dlgEv,  mBuf, ESTU023, pst);
         }
         else
         {
            StDlgEv   tmpDlgEv;

            tmpDlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv,  &tmpDlgEv,  mBuf, ESTU024, pst);
         }
         CMCHKPKLOG( cmPkStQosSet, qosSet, mBuf, ESTU025, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU026, rVal, 
                        "cmPkStuUDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(dstAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU027, rVal, 
                        "cmPkStuUDatReq:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif
         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU028, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU029, pst);
         CMCHKPKLOG( cmPkSpId,    spId,    mBuf, ESTU030, pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }
         break;

      default:
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   pst->event = (Event)EVTSTUUDATREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuUDatReq */


/* 
* 
*       Fun:   cmPkStuSteReq
*  
*       Desc:  packs and posts state request
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuSteReq
(
Pst          *pst,          /* post structure */
SpId          spId,         /* service provider id */
CmSS7SteMgmt *steMgmt       /* SSN and PC state */
)
#else
PUBLIC S16 cmPkStuSteReq(pst, spId, steMgmt)
Pst          *pst;          /* post structure */
SpId          spId;         /* service provider id */
CmSS7SteMgmt *steMgmt;      /* SSN and PC state */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkStuSteReq)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU031, pst);
   CMCHKPKLOG( cmPkSpId, spId, mBuf, ESTU032, pst);

   pst->event = (Event)EVTSTUSTEREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuSteReq */


/* 
* 
*       Fun:   cmPkStuSteRsp
*  
*       Desc:  packs and posts state response
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuSteRsp
(
Pst          *pst,          /* post structure */
SpId          spId,         /* service provider id */
CmSS7SteMgmt *steMgmt       /* SSN and PC state */
)
#else
PUBLIC S16 cmPkStuSteRsp(pst, spId, steMgmt)
Pst          *pst;          /* post structure */
SpId          spId;         /* service provider id */
CmSS7SteMgmt *steMgmt;      /* SSN and PC state */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkStuSteRsp)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU033, pst);
   CMCHKPKLOG( cmPkSpId, spId, mBuf, ESTU034, pst);

   pst->event = (Event)EVTSTUSTERSP; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuSteRsp */


/*
*     Unpacking routines for primitives flowing from TCAP to TCAP-User at
*     STU Interface.
*/


/*
*
*       Fun:  cmUnpkStuUDatInd 
*
*       Desc:  Unpack Unidirectional Data Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuUDatInd
(
StuUDatInd  func,           /* Layer function to be called back */
Pst        *pst,            /* post structure */
Buffer     *mBuf            /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuUDatInd(func, pst, mBuf)
StuUDatInd  func;           /* Layer function to be called back */
Pst        *pst;            /* post structure */
Buffer     *mBuf;           /* message buffer */
#endif
{
   SuId       suId;         /* service user id */
/* suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
   StDlgId    suDlgId;      /* Service User Dialog id */
   StDlgId    spDlgId;      /* Service Provider Dialog id */
#endif
   SpAddr     dstAddr;      /* Sccp dest address */
   SpAddr     srcAddr;      /* Sccp src address (ours) */
   StQosSet   qosSet;       /* TCAP Quality of service */
   Dpc        opc;          /* originating point code */
   StDlgEv    dlgEv;        /* TCAP dialog portion event */
   MsgLen     len;
   /* Interface Version number */
   CmIntfVer intfVer;       /* remote interface version number */
#ifdef STUV2
   StDataParam dataParam;  /* other data primitive parameters */
#endif /* STUV2 */  

   TRC3(cmUnpkStuUDatInd)

   /* Routine organization modified, unpacking is
    * based on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   /* Initialize imp, isni fields */
#ifdef STUV2
   dataParam.imp.pres = NOTPRSNT;
#ifdef SS7_ANS96
   dataParam.isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 */   
#endif /* STUV2 */
   
   /* Unpack based on interface version number */ 
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */
      {
         CMCHKUNPKLOG( cmUnpkSuId,     &suId,    mBuf, ESTU035, pst);
         CMCHKUNPKLOG( cmUnpkSpAddr,   &dstAddr, mBuf, ESTU036, pst);
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr, mBuf, ESTU037, pst);
         CMCHKUNPKLOG( cmUnpkStQosSet, &qosSet,  mBuf, ESTU038, pst);
         CMCHKUNPKLOG( cmUnpkDpc,      &opc,     mBuf, ESTU039, pst);
         /* Unpack user info, set flag to TRUE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &dlgEv,  &mBuf, TRUE, ESTU040, pst);
      }   
         break;

      case 0x0200:        /* interface version STUV2 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SS7_ANS96
         MsgLen    bufLen;   /* Buffer Length */
#endif /* SS7_ANS96 */
#ifdef STUV2
#ifndef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore insi */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /*  SS7_ANS96 */          
#endif /* STUV2 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* Unpack bit vector */
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKUNPKLOG( cmUnpkSuId,     &suId,    mBuf, ESTU035, pst);
         CMCHKUNPKLOG( cmUnpkSpAddr,   &dstAddr, mBuf, ESTU036, pst);
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr, mBuf, ESTU037, pst);
         CMCHKUNPKLOG( cmUnpkStQosSet, &qosSet,  mBuf, ESTU038, pst);
         CMCHKUNPKLOG( cmUnpkDpc,      &opc,     mBuf, ESTU039, pst);
         /* Dont unpack User Info, set flag to FALSE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &dlgEv,  &mBuf, FALSE, ESTU040, pst);
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);
         
         /* unpack isni if compile flag for ANS96  is enabled and:
          *     1) rolling upgrade support enabled and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ANS96
          */     
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 */
         /* compile flags for ANS96  is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
          if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */
#endif /* STUV2 */
#ifdef SS7_ANS96
         /* User information was not retrieved from mBuf during unpacking
          * dialogue event. So if the user info is present, unpack it at 
          * this point */
         if (dlgEv.ansiDlgEv.pres.pres == TRUE)
         {        
            if (dlgEv.ansiDlgEv.usrInfo.pres == TRUE)
            {                
               (Void)SFndLenMsg(mBuf, &bufLen);
               if (bufLen > 0)
               {        
                  dlgEv.ansiDlgEv.usrInfo.val = mBuf;
                  mBuf = NULLP;
               }
            }
         }    
#endif /* SS7_ANS96 */
      } 
        break;

      /* Case added for STUV3 */
      case 0x0300:        /* interface version STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SS7_ANS96
         MsgLen    bufLen;   /* Buffer Length */
#endif /* SS7_ANS96 */
#ifdef STUV2
#ifndef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore insi */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /*  SS7_ANS96 */          
#endif /* STUV2 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* Unpack bit vector */
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKUNPKLOG( cmUnpkSuId,     &suId,    mBuf, ESTU035, pst);
#ifdef STUV3
         CMCHKUNPKLOG( cmUnpkStDlgId,  &suDlgId, mBuf, ESTU036, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &spDlgId, mBuf, ESTU037, pst); 
#endif
         CMCHKUNPKLOG( cmUnpkSpAddr,   &dstAddr, mBuf, ESTU038, pst);
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr, mBuf, ESTU039, pst);
         CMCHKUNPKLOG( cmUnpkStQosSet, &qosSet,  mBuf, ESTU040, pst);
         CMCHKUNPKLOG( cmUnpkDpc,      &opc,     mBuf, ESTU041, pst);
         /* Dont unpack User Info, set flag to FALSE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &dlgEv,  &mBuf, FALSE, ESTU042, pst);
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);
         
         /* unpack isni if compile flag for ANS96  is enabled and:
          *     1) rolling upgrade support enabled and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ANS96
          */     
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 */
         /* compile flags for ANS96  is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
          if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */
#endif /* STUV2 */
#ifdef SS7_ANS96
         /* User information was not retrieved from mBuf during unpacking
          * dialogue event. So if the user info is present, unpack it at 
          * this point */
         if (dlgEv.ansiDlgEv.pres.pres == TRUE)
         {        
            if (dlgEv.ansiDlgEv.usrInfo.pres == TRUE)
            {                
               (Void)SFndLenMsg(mBuf, &bufLen);
               if (bufLen > 0)
               {        
                  dlgEv.ansiDlgEv.usrInfo.val = mBuf;
                  mBuf = NULLP;
               }
            }
         }    
#endif /* SS7_ANS96 */
      } /* STUV3 */ 
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch (intfVer) */

   if (mBuf != NULLP)
   {
      (Void)SFndLenMsg(mBuf, &len);

      if (len == (MsgLen)0)
      {
         (Void)SPutMsg(mBuf); 
         mBuf = NULLP;
      }
   }

   /* Call proper callback routine */ 
#ifdef STUV2
/* suDlgId and spDlgId are added for STUV3 */
#ifdef STUV3
   RETVALUE((*func)(pst, suId, suDlgId, spDlgId, &dstAddr, &srcAddr, &qosSet, opc, &dlgEv, &dataParam, mBuf));
#else  /* not STUV3 */
   RETVALUE((*func)(pst, suId, &dstAddr, &srcAddr, &qosSet, opc, &dlgEv, 
                    &dataParam,mBuf));
#endif
#else /* not STUV2 */
   RETVALUE((*func)(pst, suId, &dstAddr, &srcAddr, &qosSet, opc, &dlgEv, mBuf));
#endif /* STUV2 */

} /* end of cmUnpkStuUDatInd */


/*
*
*       Fun:   cmUnpkStuDatInd
*
*       Desc:  Unpack Data Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuDatInd
(
StuDatInd   func,           /* Layer function to be called back */
Pst        *pst,            /* post structure */
Buffer     *mBuf            /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuDatInd(func, pst, mBuf)
StuDatInd   func;           /* Layer function to be called back */
Pst        *pst;            /* post structure */
Buffer     *mBuf;           /* message buffer */
#endif
{
   SuId       suId;         /* service user id */
   SpAddr     dstAddr;      /* Sccp dest address */
   SpAddr     srcAddr;      /* Sccp src address (ours) */
   U8         msgType;      /* TCAP message type */
   StDlgId    suDlgId;      /* Service User Dialog id */
   StDlgId    spDlgId;      /* Service Provider Dialog id */
   U8         compsPres;    /* components present */
   StOctet    pAbrtCause;   /* abort information if abort component */
   StQosSet   qosSet;       /* TCAP Quality of service */
   Dpc        opc;          /* originating point code */
   StDlgEv    dlgEv;        /* TCAP dialog portion event */
   MsgLen     len;
   /* Interface Version number */
   CmIntfVer intfVer;       /* remote interface version number */
#ifdef STUV2
   StDataParam dataParam;  /* other data primitive parameters */
#endif /* STUV2 */

   TRC2(cmUnpkStuDatInd)

   /* Routine organization modified, unpacking is
    * based on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   /* Initialize imp, isni fields */
#ifdef STUV2
   dataParam.imp.pres = NOTPRSNT;
#ifdef SS7_ANS96
   dataParam.isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 */   
#endif /* STUV2 */
   
   /* Unpack based on interface version number */ 
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */
      {
         CMCHKUNPKLOG( cmUnpkSuId,     &suId,       mBuf, ESTU041, pst); 
         CMCHKUNPKLOG( SUnpkU8,        &msgType,    mBuf, ESTU042, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &spDlgId,    mBuf, ESTU043, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &suDlgId,    mBuf, ESTU044, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &dstAddr,    mBuf, ESTU045, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,    mBuf, ESTU046, pst); 
         CMCHKUNPKLOG( cmUnpkBool,     &compsPres,  mBuf, ESTU047, pst); 
         CMCHKUNPKLOG( cmUnpkStOctet,  &pAbrtCause, mBuf, ESTU048, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &qosSet,     mBuf, ESTU049, pst); 
         CMCHKUNPKLOG( cmUnpkDpc,      &opc,        mBuf, ESTU050, pst); 
         /* Unpack User Info, set flag to TRUE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &dlgEv,     &mBuf, TRUE, ESTU051, pst); 
      }
         break;

      case 0x0200:        /* interface version STUV2 */
      case 0x0300:    /* Interface version STUV3, there is no difference in 
                         DatInd for STUV2 and STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SS7_ANS96
         MsgLen    bufLen;   /* Buffer Length */
#endif /* SS7_ANS96 */
#ifdef STUV2
#ifndef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT         
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore insi */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /*  SS7_ANS96 */          
#endif /* STUV2 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* Unpack bit vector */
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKUNPKLOG( cmUnpkSuId,     &suId,       mBuf, ESTU041, pst); 
         CMCHKUNPKLOG( SUnpkU8,        &msgType,    mBuf, ESTU042, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &spDlgId,    mBuf, ESTU043, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &suDlgId,    mBuf, ESTU044, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &dstAddr,    mBuf, ESTU045, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,    mBuf, ESTU046, pst); 
         CMCHKUNPKLOG( cmUnpkBool,     &compsPres,  mBuf, ESTU047, pst); 
         CMCHKUNPKLOG( cmUnpkStOctet,  &pAbrtCause, mBuf, ESTU048, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &qosSet,     mBuf, ESTU049, pst); 
         CMCHKUNPKLOG( cmUnpkDpc,      &opc,        mBuf, ESTU050, pst); 
         /* Dont unpack User Info, set flag to FALSE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &dlgEv,     &mBuf, FALSE, ESTU051, pst); 
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);
         
         /* unpack isni if compile flag for ANS96  is enabled and:
          *     1) rolling upgrade support enabled and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ans96
          */     
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else  /* SS7_ANS96 */
         /* compile flags for ANS96  is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
          if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */
#endif /* STUV2 */
#ifdef SS7_ANS96
         /* User information was not retrieved from mBuf during unpacking
          * dialogue event. So if the user info is present, unpack it at 
          * this point */
         if (dlgEv.ansiDlgEv.pres.pres == TRUE)
         {        
            if (dlgEv.ansiDlgEv.usrInfo.pres == TRUE)
            {                
               (Void)SFndLenMsg(mBuf, &bufLen);
               if (bufLen > 0)
               {        
                  dlgEv.ansiDlgEv.usrInfo.val = mBuf;
                  mBuf = NULLP;
               }
            }
         }    
#endif /* SS7_ANS96 */
      }   
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch (intfVer) */

   if (mBuf != NULLP)
   {
      (Void)SFndLenMsg(mBuf,&len);

      if (len == (MsgLen)0)
      {
         SPutMsg(mBuf); 
         mBuf = NULLP;
      }
   }

   /* Call proper callback routine */ 
#ifdef STUV2
   RETVALUE((*func)(pst, suId, msgType, suDlgId, spDlgId, &dstAddr, &srcAddr,
                    compsPres, &pAbrtCause, &qosSet, opc, &dlgEv, &dataParam, 
                    mBuf));
#else
   RETVALUE((*func)(pst, suId, msgType, suDlgId, spDlgId, &dstAddr, &srcAddr,
                    compsPres, &pAbrtCause, &qosSet, opc, &dlgEv, mBuf));
#endif /* STUV2 */

} /* end of cmUnpkStuDatInd */


/*
*
*       Fun:   cmUnpkStuCmpInd
*
*       Desc:  Unpack TCAP Component Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuCmpInd
(
StuCmpInd  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuCmpInd(func, pst, mBuf)
StuCmpInd  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SuId       suId;         /* service user id */
   StDlgId    suDlgId;      /* Service User Dialog id */
   StDlgId    spDlgId;      /* Service Provider Dialog id */
   StComps    stComps;      /* TCAP components */
   Dpc        opc;          /* originating point code */
   Status     status;       /* indication status */
   MsgLen     len;

   TRC3(cmUnpkStuCmpInd)

   /* zero out component before unpacking */
   cmZeroStComp(&stComps);

   CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU052, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &spDlgId, mBuf, ESTU053, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &suDlgId, mBuf, ESTU054, pst);
   CMCHKUNPKLOG( cmUnpkStComp,  &stComps, mBuf, ESTU055, pst); 
   CMCHKUNPKLOG( cmUnpkDpc,     &opc,     mBuf, ESTU056, pst); 
   CMCHKUNPKLOG( cmUnpkStatus,  &status,  mBuf, ESTU057, pst); 

   (Void)SFndLenMsg(mBuf,&len);

   if (len == (MsgLen)0)
   {
      SPutMsg(mBuf); 
      mBuf = NULLP;
   }

   RETVALUE((*func)(pst, suId, suDlgId, spDlgId, &stComps, opc, status, mBuf));

} /* end of cmUnpkStuCmpInd */
  

/*
*
*       Fun:   cmUnpkStuCmpCfm
*
*       Desc:  Unpack TCAP Component Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuCmpCfm
(
StuCmpCfm  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuCmpCfm(func, pst, mBuf)
StuCmpCfm  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SuId      suId;          /* service user id */
   StDlgId   suDlgId;       /* dialog id */
   StDlgId   spDlgId;       /* dialog id */
   
   TRC3(cmUnpkStuCmpCfm)

   CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU058, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &spDlgId, mBuf, ESTU059, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &suDlgId, mBuf, ESTU060, pst); 

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, suId, suDlgId, spDlgId));

} /* end of cmUnpkStuCmpCfm */


/*
*
*       Fun:   cmUnpkStuNotInd
*
*       Desc:  Unpack Notice Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuNotInd
(
StuNotInd  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuNotInd(func, pst, mBuf)
StuNotInd  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SuId      suId;          /* service user id */
   SpAddr    dstAddr;       /* Sccp dest address */
   SpAddr    srcAddr;       /* Sccp src address (ours) */
   StDlgId   suDlgId;       /* dialog id */
   StDlgId   spDlgId;       /* dialog id */
   RCause    retCause;      /* return cause */
   /* Interface Version number */
   CmIntfVer intfVer;       /* remote interface version number */
#ifdef STUV2
   StDataParam dataParam;  /* other data primitive parameters */
#endif /* STUV2 */
   
   TRC2(cmUnpkStuNotInd)

   /* Routine organization modified, unpacking is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   /* Initialize imp, isni fields */
#ifdef STUV2
   dataParam.imp.pres = NOTPRSNT;
#ifdef SS7_ANS96
   dataParam.isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 */   
#endif /* STUV2 */

   /* Unpack based on interface version number */ 
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */
      {   
         CMCHKUNPKLOG( cmUnpkSuId,    &suId,     mBuf, ESTU061, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId, &suDlgId,  mBuf, ESTU062, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId, &spDlgId,  mBuf, ESTU063, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,  &dstAddr,  mBuf, ESTU064, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,  &srcAddr,  mBuf, ESTU065, pst); 
         CMCHKUNPKLOG( cmUnpkRCause,  &retCause, mBuf, ESTU066, pst); 
      }
         break;

      case 0x0200:        /* interface version STUV2 */
      case 0x0300:        /* interface version STUV3 , there is no difference in Not Indication 
                             in STUV2 and STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#ifdef STUV2
#ifndef SS7_ANS96
          SpIsni tmpIsni;     /* temporary buffer to unpack and ignore insi */
#endif /* ! SS7_ANS96 */          
#endif /* STUV2 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
 
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */        

         CMCHKUNPKLOG( cmUnpkSuId,    &suId,     mBuf, ESTU061, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId, &suDlgId,  mBuf, ESTU062, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId, &spDlgId,  mBuf, ESTU063, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,  &dstAddr,  mBuf, ESTU064, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,  &srcAddr,  mBuf, ESTU065, pst); 
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);
         
         /* unpack isni if compile flag for ANS96  is enabled and:
          *     1) rolling upgrade support enabld and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ANS96
          */     
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 */
         /* compile flags for ANS96  is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
          if (bitVector & STU_SS7_ANS96_BIT)
             CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */
#endif /* STUV2 */          
         CMCHKUNPKLOG( cmUnpkRCause,  &retCause, mBuf, ESTU066, pst);
      }
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch (intfVer) */

   (Void)SPutMsg(mBuf);

   /* Call proper callback routine */ 
#ifdef STUV2
   RETVALUE((*func)(pst, suId, suDlgId, spDlgId, &dstAddr, &srcAddr, 
                    &dataParam, retCause));
#else /* other than STUV2 */   
   RETVALUE((*func)(pst, suId, suDlgId, spDlgId, &dstAddr, &srcAddr, retCause));
#endif /* STUV2 */
   
} /* end of cmUnpkStuNotInd */


/*
*
*       Fun:   cmUnpkStuSteInd 
*
*       Desc:  This function unpacks the SSN/Point Code state change
*              Indication.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuSteInd
(
StuSteInd  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuSteInd(func, pst, mBuf)
StuSteInd  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   CmSS7SteMgmt   steMgmt;
   SuId           suId;
   /* Interface Version number, ril, sccpState */
   CmIntfVer      intfVer;  /* interface version number */
#ifdef STUV2
   StMgmntParam   mgmntParam;  /* other management primitive parameters */
#endif /* STUV2 */   

   TRC3(cmUnpkStuSteInd)

   /* Routine organization modified, unpacking is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version  as in 
    * pst->intfVer, else use self STU interface version 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */  

#ifdef STUV2
         /* assign default values to sccpState and ril */
         mgmntParam.sccpState = STUIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
         mgmntParam.ril = STUIF_VER2_STEIND_DEF_RIL_VAL;
#endif /* STUV2 */

   /* unpack parameters based on received remote interface version num */
   switch (intfVer)
   {
      case 0x0100:      
         CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU067, pst); 
         CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU068, pst); 
         break;
         
      case 0x0200:      
      case 0x0300:        /* interface version STUV3 , there is no difference in SteInd
                             in STUV2 and STUV3 */
         CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU067, pst); 
         CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU068, pst); 
#ifdef STUV2
         CMCHKUNPKLOG(SUnpkU8,  &mgmntParam.sccpState,  mBuf, ESTUXXX, pst);
         CMCHKUNPKLOG(SUnpkU8,  &mgmntParam.ril,  mBuf, ESTUXXX, pst);
#endif /* STUV2 */         
         break;

      default:
         /* invalid remote interface interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* intfVer */

   (Void)SPutMsg(mBuf);

   /* for STUV2 routine prototype is changed */
#ifdef STUV2
   RETVALUE((*func)(pst, suId, &steMgmt, &mgmntParam));
#else  /* not STUV2 */ 
   RETVALUE((*func)(pst, suId, &steMgmt));
#endif /* STUV2 */
   
} /* end of cmUnpkStuSteInd */


/*
*
*       Fun:   cmUnpkStuSteCfm
*
*       Desc:  This function unpacks the SSN/Point Code state change
*              Confirm.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuSteCfm
(
StuSteCfm  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuSteCfm(func, pst, mBuf)
StuSteCfm  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   CmSS7SteMgmt   steMgmt;
   SuId           suId;
   /* Interface Version number, ril, sccpState */
   CmIntfVer intfVer;       /* interface version number */
#ifdef STUV2
   StMgmntParam   mgmntParam;  /* other management primitive parameters */
#endif /* STUV2 */

   TRC3(cmUnpkStuSteCfm)

   /* Routine organization modified, unpacking is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version  as in 
    * pst->intfVer, else use self STU interface version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

#ifdef STUV2
         /* assign default values to sccpState and ril */
         mgmntParam.sccpState = STUIF_VER2_STECFM_DEF_SCCPSTATE_VAL;
         mgmntParam.ril = STUIF_VER2_STECFM_DEF_RIL_VAL;
#endif /* STUV2 */

   /* unpack parameters based on received remote interface version num */
   switch (intfVer)
   {
      case 0x0100:      /* interface version STUV1 */
         CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU069, pst); 
         CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU070, pst); 
         break;
         
      case 0x0200:      /* interface version STUV2 */
      case 0x0300:      /* interface version STUV3 , there is no difference in SteCfm 
                           in STUV2 and STUV3 */
         CMCHKUNPKLOG( cmUnpkSuId,    &suId,    mBuf, ESTU069, pst); 
         CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU070, pst);
#ifdef STUV2
         CMCHKUNPKLOG(SUnpkU8,  &mgmntParam.sccpState,  mBuf, ESTUXXX, pst);
         CMCHKUNPKLOG(SUnpkU8,  &mgmntParam.ril,  mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         break;

      default:
         /* invalid remote interface interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   (Void)SPutMsg(mBuf);

   /* for STUV2 routine prototype is changed */
#ifdef STUV2
   RETVALUE((*func)(pst, suId, &steMgmt, &mgmntParam));
#else   
   RETVALUE((*func)(pst, suId, &steMgmt));
#endif /* STUV2 */

} /* end of cmUnpkStuSteCfm */


/*
*
*       Fun:   cmUnpkStuStaInd
*
*       Desc:  Unpack TCAP Status Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuStaInd
(
StuStaInd  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuStaInd(func, pst, mBuf)
StuStaInd  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SuId     suId;           /* service user id */
   Status   status;         /* indication status */
   
   TRC3(cmUnpkStuCmpInd)

   CMCHKUNPKLOG( cmUnpkSuId,   &suId,   mBuf, ESTU071, pst); 
   CMCHKUNPKLOG( cmUnpkStatus, &status, mBuf, ESTU072, pst); 

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, suId, status));

} /* end of cmUnpkStuStaInd */


/*
*
*       Fun:   cmUnpkStuBndCfm
*
*       Desc:  Unpack TCAP Bind Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuBndCfm
(
StuBndCfm  func,            /* Layer function to be called back */
Pst       *pst,             /* post structure */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuBndCfm(func, pst, mBuf)
StuBndCfm  func;            /* Layer function to be called back */
Pst       *pst;             /* post structure */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SuId     suId;           /* service user id */
   U8       status;         /* indication status */
   
   TRC3(cmUnpkStuCmpInd)
 
   CMCHKUNPKLOG( cmUnpkSuId, &suId,   mBuf, ESTU073, pst); 
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESTU074, pst); 
 
   (Void)SPutMsg(mBuf);
 
   RETVALUE((*func)(pst, suId, status));
 
} /* end of cmUnpkStuBndCfm */


/*
*     Packing routines for primitives flowing from TCAP to TCAP-User at
*     STU Interface.
*/

/* 
* 
*       Fun:   cmPkStuUDatInd
*  
*       Desc:  This function packs a unstrcutured data indication for a loosely
*              coupled STU interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuUDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
#ifdef STUV3
StDlgId  suDlgId,
StDlgId  spDlgId,
#endif
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
#ifdef STUV2
StDataParam *dataParam,  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
#ifdef STUV2
#ifdef STUV3
PUBLIC S16 cmPkStuUDatInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr, stQosSet, opc,
                            stDlgEv, dataParam, uiBuf)
#else /* STUV3 */
PUBLIC S16 cmPkStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                            stDlgEv, dataParam, uiBuf)
#endif
#else /* STUV2 */
PUBLIC S16 cmPkStuUDatInd(pst, suId, destAddr, srcAddr, stQosSet, opc,
                            stDlgEv, uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
#ifdef STUV3
StDlgId   suDlgId;
StDlgId   spDlgId;
#endif
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
/* new structure StDataParam added as parameter */
#ifdef STUV2
StDataParam *dataParam;  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   Buffer    *mBuf;
   S16        rVal;
   U8         len;
   /* Interface Version number */
   CmIntfVer intfVer;     /* remote interface version number */

   TRC2(cmPkStuUDatInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   if (uiBuf != NULLP)
   { 
      rVal = SCatMsg(mBuf,uiBuf,M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(uiBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU075, rVal, "cmPkStuUDatInd:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      (Void)SPutMsg(uiBuf);
   }
   /* Pack depending upon interface version number */
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */
      {
         if (stDlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv, stDlgEv, mBuf, ESTU076, pst);
         }
         else
         {
            StDlgEv   dlgEv;

            dlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv, &dlgEv, mBuf, ESTU077, pst);
         }
         CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU078, pst);
         CMCHKPKLOG( cmPkStQosSet, stQosSet, mBuf, ESTU079, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU080, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU081, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU082, pst);
      }  
         break;
 
      case 0x0200:        /* interface version STUV2 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector */

         /* initialize bitVector */
         bitVector = 0x0000;
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */        
         /* Pack isni field */
#ifdef STUV2
#ifdef SS7_ANS96
         CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         if (stDlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv, stDlgEv, mBuf, ESTU076, pst);
         }
         else
         {
            StDlgEv   dlgEv;

            dlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv, &dlgEv, mBuf, ESTU077, pst);
         }
         CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU078, pst);
         CMCHKPKLOG( cmPkStQosSet, stQosSet, mBuf, ESTU079, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU080, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU081, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU082, pst);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }  
        break;

      /* case added for STUV3 */
      case 0x0300:        /* interface version STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector */

         /* initialize bitVector */
         bitVector = 0x0000;
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */        
         /* Pack isni field */
#ifdef STUV2
#ifdef SS7_ANS96
         CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         if (stDlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv, stDlgEv, mBuf, ESTU076, pst);
         }
         else
         {
            StDlgEv   dlgEv;

            dlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv, &dlgEv, mBuf, ESTU077, pst);
         }
         CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU078, pst);
         CMCHKPKLOG( cmPkStQosSet, stQosSet, mBuf, ESTU079, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU080, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU081, rVal, 
                        "cmPkStuUDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif
#ifdef STUV3
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU082, pst);
         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU083, pst);
#endif
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU084, pst);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }  
         break;       
        
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   pst->event = (Event)EVTSTUUDATIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuUDatInd */


/* 
* 
*       Fun:   cmPkStuDatInd
*  
*       Desc:  This function packs a data indication for a loosely coupled
*              STU interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuDatInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        msgType,          /* message type */
StDlgId   suDlgId,          /* user dialog id */
StDlgId   spDlgId,          /* provider dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
Bool      compsPres,        /* terminating dialog */
StOctet  *prvAbrtCause,     /* Abort information if abort component */
StQosSet *stQosSet,         /* TCAP Quality of Service */
Dpc       opc,              /* originating point code */
StDlgEv  *stDlgEv,          /* TCAP Dialog portion event */
#ifdef STUV2
StDataParam *dataParam,  /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf             /* TCAP Dialog portion user info buffer */
)
#else
/* Routine prototype modified to include dataParam */
#ifdef STUV2
PUBLIC S16 cmPkStuDatInd(pst, suId, msgType, suDlgId, spDlgId,
                           destAddr, srcAddr, compsPres, prvAbrtCause,
                           stQosSet, opc, stDlgEv,dataParam,uiBuf)
#else  /* not STUV2 */
PUBLIC S16 cmPkStuDatInd(pst, suId, msgType, suDlgId, spDlgId,
                           destAddr, srcAddr, compsPres, prvAbrtCause,
                           stQosSet, opc, stDlgEv,uiBuf)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        msgType;          /* message type */
StDlgId   suDlgId;          /* user dialog id */
StDlgId   spDlgId;          /* provider dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
Bool      compsPres;        /* terminating dialog */
StOctet  *prvAbrtCause;     /* Abort information if abort component */
StQosSet *stQosSet;         /* TCAP Quality of Service */
Dpc       opc;              /* originating point code */
StDlgEv  *stDlgEv;          /* TCAP Dialog portion event */
#ifdef STUV2
StDataParam *dataParam;     /* new structure having imp and isni */
#endif /* STUV2 */
Buffer   *uiBuf;            /* TCAP Dialog portion user info buffer */
#endif
{
   Buffer *mBuf;
   S16     rVal;
   U8      len;
   /* Interface Version number */
   CmIntfVer intfVer;     /* remote interface version number */

   TRC2(cmPkStuDatInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   if (uiBuf != NULLP)
   { 
      rVal = SCatMsg(mBuf,uiBuf,M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(uiBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU083, rVal, "cmPkStuDatInd:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      (Void)SPutMsg(uiBuf);
   }
   /* Pack depending upon interface version number */ 
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */ 
      {
         if (stDlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv, stDlgEv, mBuf, ESTU084, pst);
         }
         else
         {
            StDlgEv    dlgEv;

            dlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv, &dlgEv, mBuf, ESTU085, pst);
         }
         CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU086, pst);
         CMCHKPKLOG( cmPkStQosSet, stQosSet, mBuf, ESTU087, pst);

         if (prvAbrtCause != NULLP)
         {
            CMCHKPKLOG( cmPkStOctet, prvAbrtCause, mBuf, ESTU088, pst);
         }
         else
         {
            StOctet    pAbtCause;

            pAbtCause.pres = FALSE;
            CMCHKPKLOG( cmPkStOctet, &pAbtCause, mBuf, ESTU089, pst);
         }
         CMCHKPKLOG( cmPkBool, compsPres, mBuf, ESTU090, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU091, rVal, 
                        "cmPkStuDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU092, rVal, 
                        "cmPkStuDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU093, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU094, pst);
         CMCHKPKLOG( SPkU8, msgType, mBuf, ESTU095, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU096, pst);
      }   
         break;

      case 0x0200:        /* interface version STUV2 */ 
      case 0x0300:        /* interface version STUV3 , there is no difference in DatInd 
                             in STUV2 and STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector */

         /* initialize bitVector */
         bitVector = 0x0000;
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */        
         /* Pack isni field */
#ifdef STUV2
#ifdef SS7_ANS96
         CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         if (stDlgEv != NULLP)
         {
            CMCHKPKLOG( cmPkStDlgEv, stDlgEv, mBuf, ESTU084, pst);
         }
         else
         {
            StDlgEv    dlgEv;

            dlgEv.pres = FALSE;
            CMCHKPKLOG( cmPkStDlgEv, &dlgEv, mBuf, ESTU085, pst);
         }
         CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU086, pst);
         CMCHKPKLOG( cmPkStQosSet, stQosSet, mBuf, ESTU087, pst);

         if (prvAbrtCause != NULLP)
         {
            CMCHKPKLOG( cmPkStOctet, prvAbrtCause, mBuf, ESTU088, pst);
         }
         else
         {
            StOctet    pAbtCause;

            pAbtCause.pres = FALSE;
            CMCHKPKLOG( cmPkStOctet, &pAbtCause, mBuf, ESTU089, pst);
         }
         CMCHKPKLOG( cmPkBool, compsPres, mBuf, ESTU090, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU091, rVal, 
                        "cmPkStuDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU092, rVal, 
                        "cmPkStuDatInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU093, pst);
         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU094, pst);
         CMCHKPKLOG( SPkU8, msgType, mBuf, ESTU095, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU096, pst);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }   
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */
   
   pst->event = (Event)EVTSTUDATIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuDatInd */

 
/*  
*  
*       Fun:   cmPkStuCmpInd
*   
*       Desc:  This function packs a Component indication for a loosely 
*              coupled STU interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  stu.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 cmPkStuCmpInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId,          /* dialog Id */
StComps  *compEv,           /* component */
Dpc       opc,              /* originating point code */
Status    status,           /* status */
Buffer   *cpBuf             /* Component parameter buffer */
)
#else
PUBLIC S16 cmPkStuCmpInd(pst, suId, suDlgId, spDlgId, compEv, opc,
                           status,cpBuf)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
StComps  *compEv;           /* component */
Dpc       opc;              /* originating point code */
Status    status;           /* status */
Buffer   *cpBuf;            /* Component parameter buffer */
#endif
{
   Buffer *mBuf;
   S16     rVal;

   TRC2(cmPkStuCmpInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   if (cpBuf != NULLP)
   {
      rVal = SCatMsg(mBuf,cpBuf,M1M2);

#if (ERRCLASS & ERRCLS_ADD_RES)
      if (rVal != ROK)
      {
         (Void)SPutMsg(mBuf);
         (Void)SPutMsg(cpBuf);
         STULOGERROR(ERRCLS_ADD_RES, ESTU097, rVal, "cmPkStuCmpInd:SCatMsg Failed");
         RETVALUE(rVal);
      }
#endif
      SPutMsg(cpBuf);
   }

   CMCHKPKLOG( cmPkStatus, status, mBuf, ESTU098, pst);
   CMCHKPKLOG( cmPkDpc, opc, mBuf, ESTU099, pst);
   CMCHKPKLOG( cmPkStComp, compEv, mBuf, ESTU100, pst);
   CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU101, pst);
   CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU102, pst);
   CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU103, pst);
   
   pst->event = (Event)EVTSTUCMPIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuCmpInd */
 

/*  
*  
*       Fun:   cmPkStuCmpCfm
*   
*       Desc:  This function packs a Component confirm for a loosely 
*              coupled STU interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  stu.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 cmPkStuCmpCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog Id */
StDlgId   spDlgId           /* dialog Id */
)
#else
PUBLIC S16 cmPkStuCmpCfm(pst, suId, suDlgId, spDlgId)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog Id */
StDlgId   spDlgId;          /* dialog Id */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkStuCmpCfm)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU104, pst);
   CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU105, pst);
   CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU106, pst);

   pst->event = (Event)EVTSTUCMPCFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuCmpCfm */


/* 
* 
*       Fun:   cmPkStuNotInd
*  
*       Desc:  This function packs a notice indication for a loosely coupled
*              STU interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuNotInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
StDlgId   suDlgId,          /* dialog id */
StDlgId   spDlgId,          /* dialog id */
SpAddr   *destAddr,         /* TCAP dest address */
SpAddr   *srcAddr,          /* TCAP src address */
#ifdef STUV2
StDataParam *dataParam,  /* new structure having imp and isni */
#endif /* STUV2 */
RCause    retCause          /* return cause */
)
#else
#ifdef STUV2
PUBLIC S16 cmPkStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                           dataParam, retCause)
#else  /* not STUV2 */
PUBLIC S16 cmPkStuNotInd(pst, suId, suDlgId, spDlgId, destAddr, srcAddr,
                           retCause)
#endif /* STUV2 */
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
StDlgId   suDlgId;          /* dialog id */
StDlgId   spDlgId;          /* dialog id */
SpAddr   *destAddr;         /* TCAP dest address */
SpAddr   *srcAddr;          /* TCAP src address */
#ifdef STUV2
StDataParam *dataParam;  /* new structure having imp and isni */
#endif /* STUV2 */
RCause    retCause;         /* return cause */
#endif
{
   Buffer *mBuf;
   S16     rVal;
   U8      len;
   /* Interface Version number */
   CmIntfVer intfVer;     /* remote interface version number */

   TRC2(cmPkStuNotInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version as in
    * pst->intfVer, else use self STU intf version */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   /* Pack based on interface version number */
   switch (intfVer)
   {
      case 0x0100:        /* interface version STUV1 */        
      {
         CMCHKPKLOG( cmPkRCause, retCause, mBuf, ESTU107, pst);

         rVal = cmPkSpAddr(srcAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU108, rVal, 
                        "cmPkStuNotInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         rVal = cmPkSpAddr(destAddr, mBuf, &len);

#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU109, rVal, 
                        "cmPkStuNotInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU110, pst);
         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU111, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU112, pst);
      }
         break;

      case 0x0200:        /* interface version STUV2 */        
      case 0x0300:        /* interface version STUV3 , there is no difference in Not Indication 
                             in STUV2 and STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;              /* bitvector  */

         /* initialize bitVector */
         bitVector = 0x0000;
#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector |= STU_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         /* Pack cause */
         CMCHKPKLOG( cmPkRCause, retCause, mBuf, ESTU107, pst);
#ifdef STUV2
#ifdef SS7_ANS96
         CMCHKPKLOG(cmPkSpIsni, &dataParam->isni, mBuf, ESTUXXX, pst);
#endif /* SS7_ANS96 */
          
         /* if importance is present, pack importance value */
         CMCHKPKLOG(cmPkTknU8, &dataParam->imp, mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         rVal = cmPkSpAddr(srcAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU108, rVal, 
                        "cmPkStuNotInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif
         /* Pack destination address */
         rVal = cmPkSpAddr(destAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            SPutMsg(mBuf);
            STULOGERROR(ERRCLS_ADD_RES, ESTU109, rVal, 
                        "cmPkStuNotInd:cmPkSpAddr Failed");
            RETVALUE(rVal);
         }
#endif

         CMCHKPKLOG( cmPkStDlgId, spDlgId, mBuf, ESTU110, pst);
         CMCHKPKLOG( cmPkStDlgId, suDlgId, mBuf, ESTU111, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU112, pst);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }
         break;  

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   pst->event = (Event)EVTSTUNOTIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuNotInd */


/* 
* 
*       Fun:   cmPkStuSteInd
*  
*       Desc:  This function packs a subsystem state indication for a loosely
*              coupled STU interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuSteInd
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam *mgmntParam       /* other mgmnt params like ril and SCCP State */
#endif /* STUV2 */
)
#else
/* Routine prototype modified to include sccpState, 
 * ril fields */
PUBLIC S16 cmPkStuSteInd(pst, suId, steMgmt
#ifdef STUV2
, mgmntParam
#endif /* STUV2 */
)
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;      /* other mgmnt params like ril and SCCP State */
#endif /* STUV2 */
#endif
{
   Buffer *mBuf;
   /* Interface Version Number */
   CmIntfVer intfVer;           /* interface version number */

   TRC2(cmPkStuSteInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version  as in 
    * pst->intfVer, else use self STU interface version 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   

   /* pack parameters based on interface version number */
   switch (intfVer)
   {
      case 0x0100:      /* interface version STUV1 */
         CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU113, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU114, pst);
         break;

      case 0x0200:      /* interface version STUV2 */   
      case 0x0300:      /* interface version STUV3 , there is no difference in SteInd 
                           in STUV2 and STUV3 */
         /*  sccpState and ril fields are packed */
#ifdef STUV2
         CMCHKPKLOG(SPkU8, mgmntParam->ril, mBuf, ESTUXXX, pst);
         CMCHKPKLOG(SPkU8, mgmntParam->sccpState, mBuf, ESTUXXX, pst);
#endif /* STUV2 */
         CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU113, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU114, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */      

   pst->event = (Event)EVTSTUSTEIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuSteInd */


/* 
* 
*       Fun:   cmPkStuSteCfm
*  
*       Desc:  This function packs a subsystem state confirm for a loosely
*              coupled STU interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  stu.c
* 
*/
#ifdef ANSI
PUBLIC S16 cmPkStuSteCfm
(
Pst          *pst,              /* post structure */
SuId          suId,             /* service user id */
CmSS7SteMgmt *steMgmt           /* Status management structure */
/* Sccp State, Restricted importance level fields  */
#ifdef STUV2
,StMgmntParam *mgmntParam       /* SCCP State */
#endif /* STUV2 */
)
#else
/* Routine prototype modified to include sccpState, 
 * ril fields */
PUBLIC S16 cmPkStuSteCfm(pst, suId, steMgmt
#ifdef STUV2
,mgmntParam
#endif /* STUV2 */
)
Pst          *pst;              /* post structure */
SuId          suId;             /* service user id */
CmSS7SteMgmt *steMgmt;          /* Status management structure */
/* Sccp State, Restricted importance level fields  */
#ifdef STUV2
StMgmntParam *mgmntParam;      /* SCCP State */
#endif /* STUV2 */
#endif
{
   Buffer *mBuf;
   /* Interface Version Number */
   CmIntfVer intfVer;           /* interface version number */

   TRC2(cmPkStuSteCfm)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   /* Routine organization modified, packing is
    * done on interface version number basis */

   /* if Rolling Upgrade support is enabled, use interface version  as in 
    * pst->intfVer, else use self STU interface version 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   /* pack parameters based on interface version number */
   switch (intfVer)
   {
      case 0x0100:     /* interface version STUV1 */
         CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU115, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU116, pst);
         break;
         
      case 0x0200:     /* interface version STUV2 */
      case 0x0300:     /* interface version STUV3 , there is no difference in SteCfm 
                          in STUV2 and STUV3 */
         /* sccpState and ril fields are packed */
#ifdef STUV2
         CMCHKPKLOG(SPkU8, mgmntParam->ril, mBuf, ESTUXXX, pst);
         CMCHKPKLOG(SPkU8, mgmntParam->sccpState, mBuf, ESTUXXX, pst);
#endif /* STUV2 */   
         CMCHKPKLOG( cmPkSteMgmt, steMgmt, mBuf, ESTU115, pst);
         CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU116, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
         break;
   } /* intfVer */

   pst->event = (Event)EVTSTUSTECFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuSteCfm */

 
/*  
*  
*       Fun:   cmPkStuStaInd
*   
*       Desc:  This function packs a Status indication for a loosely 
*              coupled STU interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  stu.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 cmPkStuStaInd
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
Status    status            /* status */
)
#else
PUBLIC S16 cmPkStuStaInd(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
Status    status;           /* status */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkStuStaInd)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkStatus, status, mBuf, ESTU117, pst);
   CMCHKPKLOG( cmPkSuId, suId, mBuf, ESTU118, pst);
   
   pst->event = (Event)EVTSTUSTAIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuStaInd */


/*  
*  
*       Fun:   cmPkStuBndCfm
*   
*       Desc:  This function packs a Bind Confirm for a loosely 
*              coupled STU interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  stu.c
*  
*/ 
#ifdef ANSI
PUBLIC S16 cmPkStuBndCfm
(
Pst      *pst,              /* post structure */
SuId      suId,             /* service user id */
U8        status            /* status */
)
#else
PUBLIC S16 cmPkStuBndCfm(pst, suId, status)
Pst      *pst;              /* post structure */
SuId      suId;             /* service user id */
U8        status;           /* status */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkStuBndCfm)

   STU_GETMSG(pst, mBuf, ESTUXXX);

   CMCHKPKLOG( cmPkStatus, status, mBuf, ESTU119, pst);
   CMCHKPKLOG( cmPkSuId,   suId,   mBuf, ESTU120, pst);
   
   pst->event = (Event)EVTSTUBNDCFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkStuBndCfm */


/*
*     Unpacking routines for primitives flowing from TCAP-User to TCAP at
*     STU Interface.
*/


/*
*
*       Fun:   cmUnpkStuBndReq
*
*       Desc:  This function Unpacks the TCAP User Bind Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuBndReq
(
StuBndReq  func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuBndReq(func, pst, mBuf)
StuBndReq  func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
  SuId     suId;            /* service user id */
  SpId     spId;            /* service provider id */
  Ssn      ssn;
  
  TRC3(cmUnpkStuBndReq)
  
  CMCHKUNPKLOG( cmUnpkSsn,  &ssn,  mBuf, ESTU121, pst); 
  CMCHKUNPKLOG( cmUnpkSpId, &spId, mBuf, ESTU122, pst); 
  CMCHKUNPKLOG( cmUnpkSuId, &suId, mBuf, ESTU123, pst);

  (Void)SPutMsg(mBuf);

  (*func)(pst, suId, spId, ssn);

  RETVALUE(ROK);
} /* end of cmUnpkStuBndReq */


/*
*
*       Fun:   cmUnpkStuUbndReq
*
*       Desc:  This function unpacks the unbind Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuUbndReq
(
StuUbndReq func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuUbndReq(func, pst, mBuf)
StuUbndReq func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   Reason  reason;
   SpId    spId;
   
   TRC3(cmUnpkStuUbndReq)
   
   CMCHKUNPKLOG( cmUnpkReason, &reason, mBuf, ESTU124, pst); 
   CMCHKUNPKLOG( cmUnpkSpId,   &spId,   mBuf, ESTU125, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, spId, reason);

   RETVALUE(ROK);
} /* end of cmUnpkStuUbndReq */


/*
*
*       Fun:   cmUnpkStuDatReq
*
*       Desc:  This function unpacks the TCAP User Data Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuDatReq
(
StuDatReq  func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuDatReq(func, pst, mBuf)
StuDatReq  func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SpId      spId;          /* provider id */
   U8        msgType;       /* TCAP message type */
   StDlgId   stSuDlgId;     /* service user dialog id */
   StDlgId   stSpDlgId;     /* Service provider dialog Id */
   SpAddr    destAddr;      /* SCCP destination address - if needed */
   SpAddr    srcAddr;       /* SCCP source address - if needed */
   Bool      endFlag;       /* arranged termination = TRUE */
   StQosSet  stQosSet;      /* TCAP Quality of Service */
   StDlgEv   stDlgEv;       /* dialog portion event */
   MsgLen    len;
   /* Interface version number */
   CmIntfVer intfVer;   /* remote interface version number */
   /* new structure StDataParam as variable */
#ifdef STUV2
   StDataParam dataParam;  /* other data primitive parameters */
#endif /* STUV2 */

   TRC3(cmUnpkStuDatReq)

   /* Routine organization modified, unpacking is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use interface version as in pst 
    * structure, else use self STU interface version. 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* Initialize imp, isni fields */
#ifdef STUV2
   dataParam.imp.pres = NOTPRSNT;
#ifdef SS7_ANS96
   dataParam.isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 */   
#endif /* STUV2 */
   
   /* Unpack fields based on interface version */
   switch(intfVer)
   {
      case 0x0100:    /* Interface version STUV1 */
      {
         CMCHKUNPKLOG( cmUnpkSpId,     &spId,      mBuf, ESTU126, pst); 
         CMCHKUNPKLOG( SUnpkU8,        &msgType,   mBuf, ESTU127, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSpDlgId, mBuf, ESTU128, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSuDlgId, mBuf, ESTU129, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &destAddr,  mBuf, ESTU130, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,   mBuf, ESTU131, pst); 
         CMCHKUNPKLOG( cmUnpkBool,     &endFlag,   mBuf, ESTU132, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &stQosSet,  mBuf, ESTU133, pst); 
         /* Unpack User Info, set flag to TRUE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &stDlgEv,  &mBuf, TRUE, ESTU134, pst);
      }   
         break;
      
      case 0x0200:    /* Interface version STUV2 */
      case 0x0300:    /* interface version STUV3 , there is no difference in DatReq
                         in STUV2 and STUV3 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SS7_ANS96
         MsgLen    bufLen;   /* Buffer Length */
#endif /* SS7_ANS96 */
#ifdef STUV2
#ifndef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT         
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore isni */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /*  (SS7_ANS96) */
#endif /* STUV2 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT         
         /* unpack bitVector */
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKUNPKLOG( cmUnpkSpId,     &spId,      mBuf, ESTU126, pst); 
         CMCHKUNPKLOG( SUnpkU8,        &msgType,   mBuf, ESTU127, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSpDlgId, mBuf, ESTU128, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSuDlgId, mBuf, ESTU129, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &destAddr,  mBuf, ESTU130, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,   mBuf, ESTU131, pst); 
         CMCHKUNPKLOG( cmUnpkBool,     &endFlag,   mBuf, ESTU132, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &stQosSet,  mBuf, ESTU133, pst); 
         /* Dont unpack User Info, set flag to FALSE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &stDlgEv,  &mBuf, FALSE, ESTU134, pst);
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);
         
         /* unpack isni if compile flag for ANS96 is enabled and:
          *     1) rolling upgrade support enabld and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ANS96
          */
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
            CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 */
         /* compile flags for ANS96 is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
            CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);     
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */ 
#endif /* STUV2 */
#ifdef SS7_ANS96
         /* User information was not retrieved from mBuf during unpacking
          * dialogue event. So if the user info is present, unpack it at 
          * this point */
         if (stDlgEv.ansiDlgEv.pres.pres == TRUE)
         {        
            if (stDlgEv.ansiDlgEv.usrInfo.pres == TRUE)
            {                
               (Void)SFndLenMsg(mBuf, &bufLen);
               if (bufLen > 0)
               {        
                  stDlgEv.ansiDlgEv.usrInfo.val = mBuf;
                  mBuf = NULLP;
               }
            }
         }    
#endif /* SS7_ANS96 */         
      }         
         break;

      default:
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   if (mBuf != NULLP)
   {
      (Void)SFndLenMsg(mBuf, &len);
      if (len == 0)
      {
         (Void)SPutMsg(mBuf);
         mBuf = NULLP;
      }
   }

   /* call callback routine based on interface 
    * version */
#ifdef STUV2
   (*func)(pst, spId, msgType, stSuDlgId, stSpDlgId,
           &destAddr, &srcAddr, endFlag, &stQosSet, &stDlgEv, &dataParam, mBuf);
#else  /* not STUV2 */
   (*func)(pst, spId, msgType, stSuDlgId, stSpDlgId,
           &destAddr, &srcAddr, endFlag, &stQosSet, &stDlgEv, mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);
}  /* end of cmUnpkStuDatReq */


/*
*
*       Fun:   cmUnpkStuUDatReq
*
*       Desc:  This function unpacks the TCAP User Unit Data Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuUDatReq
(
StuUDatReq func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuUDatReq(func, pst, mBuf)
StuUDatReq func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SpId      spId;          /* provider id */
   StDlgId   stSuDlgId;     /* dialog id */
   StDlgId   stSpDlgId;     /* dialog id */
   SpAddr    destAddr;      /* SCCP destination address - if needed */
   SpAddr    srcAddr;       /* SCCP source address - if needed */
   StQosSet  stQosSet;      /* TCAP Quality of Service */
   StDlgEv   stDlgEv;       /* dialog portion event */
   MsgLen    len;
   /* Interface version number */
   CmIntfVer intfVer;   /* remote interface version number */
   /* StDataParam containing imp, isni fields */
#ifdef STUV2
   StDataParam dataParam;  /* other data primitive parameters */
#endif /* STUV2 */  

   TRC3(cmUnpkStuUDatReq)

   /* routine organization modified, unpacking is
    * based on interface version number  */

   /* if Rolling Upgrade support is enabled, use interface version as in pst 
    * structure, else use self STU interface version. 
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = STUIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* Initialize imp, isni fields */
#ifdef STUV2
   dataParam.imp.pres = NOTPRSNT;
#ifdef SS7_ANS96
   dataParam.isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 */   
#endif /* STUV2 */

   /* Unpack  fields based on interface version  */
   switch(intfVer)
   {
      case 0x0100:    /* Interface version STUV1 */
      {
         CMCHKUNPKLOG( cmUnpkSpId,     &spId,      mBuf, ESTU135, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSpDlgId, mBuf, ESTU136, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSuDlgId, mBuf, ESTU137, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &destAddr,  mBuf, ESTU138, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,   mBuf, ESTU139, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &stQosSet,  mBuf, ESTU140, pst); 
         /* Unpack User Info, set FLAG to TRUE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &stDlgEv,  &mBuf, TRUE, ESTU141, pst); 
      }
      break;

      case 0x0200:    /* Interface version STUV2 */
      case 0x0300:    /* Interface version STUV3 , there is no difference in
                         UDatReq for SUTV2 and STUV3*/
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector;   /* bitVector for compile flags */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SS7_ANS96
         MsgLen    bufLen;   /* Buffer Length */
#endif /* SS7_ANS96 */
#ifdef STUV2
#ifndef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT         
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore isni */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /*  (SS7_ANS96) */
#endif /* STUV2 */

#ifdef TDS_ROLL_UPGRADE_SUPPORT         
         /* unpack bitVector */
         CMCHKUNPK(SUnpkU16, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKUNPKLOG( cmUnpkSpId,     &spId,      mBuf, ESTU135, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSpDlgId, mBuf, ESTU136, pst); 
         CMCHKUNPKLOG( cmUnpkStDlgId,  &stSuDlgId, mBuf, ESTU137, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &destAddr,  mBuf, ESTU138, pst); 
         CMCHKUNPKLOG( cmUnpkSpAddr,   &srcAddr,   mBuf, ESTU139, pst); 
         CMCHKUNPKLOG( cmUnpkStQosSet, &stQosSet,  mBuf, ESTU140, pst); 
         /* Dont unpack User Info, set flag to FALSE */
         STCHKUNPKLOG( cmUnpkStDlgEv,  &stDlgEv,  &mBuf, FALSE, ESTU141, pst); 
#ifdef STUV2
         /* Unpack importance field */
         CMCHKUNPKLOG( cmUnpkTknU8, &dataParam.imp, mBuf, ESTUXXX, pst);

         /* unpack isni if compile flag for ANS96 is enabled and:
          *     1) rolling upgrade support enabld and bitVector indicates that
          *     the flag is enabled at originating side and hence isni was
          *     packed
          *     2) No rolling upgrade support enabled. In this case unpacking
          *     of isni is solely on the basis of compile flags for ANS96
          */
#ifdef SS7_ANS96
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
            CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPKLOG(cmUnpkSpIsni, &dataParam.isni, mBuf, ESTUXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 */
         /* compile flags for ANS96 is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & STU_SS7_ANS96_BIT)
            CMCHKUNPKLOG(cmUnpkSpIsni, &tmpIsni, mBuf, ESTUXXX, pst);     
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 */ 
#endif /* STUV2 */
#ifdef SS7_ANS96
         /* User information was not retrieved from mBuf during unpacking
          * dialogue event. So if the user info is present, unpack it at 
          * this point */
         if (stDlgEv.ansiDlgEv.pres.pres == TRUE)
         {        
            if (stDlgEv.ansiDlgEv.usrInfo.pres == TRUE)
            {                
               (Void)SFndLenMsg(mBuf, &bufLen);
               if (bufLen > 0)
               {        
                  stDlgEv.ansiDlgEv.usrInfo.val = mBuf;
                  mBuf = NULLP;
               }
            }
         }    
#endif /* SS7_ANS96 */
      }
      break;

      default:
         RETVALUE(RINVIFVER);
         break;
   } /* switch(intfVer) */

   if (mBuf != NULLP)
   {
      (Void)SFndLenMsg(mBuf, &len);

      if (len == 0)
      {
         (Void)SPutMsg(mBuf);
         mBuf = NULLP;
      }
   }

   /* call routine based on interface version */
#ifdef STUV2
   (*func)(pst, spId, stSuDlgId, stSpDlgId, &destAddr, &srcAddr,
           &stQosSet, &stDlgEv, &dataParam, mBuf);
#else  /* STUV2 */ 
   (*func)(pst, spId, stSuDlgId, stSpDlgId, &destAddr, &srcAddr,
           &stQosSet, &stDlgEv,mBuf);
#endif /* STUV2 */

   RETVALUE(ROK);
}  /* end of cmUnpkStuUDatReq */


/*
*
*       Fun:   cmUnpkStuCmpReq
*
*       Desc:  This function unpacks the TCAP User Component Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuCmpReq
(
StuCmpReq  func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuCmpReq(func, pst, mBuf)
StuCmpReq  func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   SpId     spId;           /* service provider id number */
   StDlgId  stSuDlgId;      /* dialog ID for this component */
   StDlgId  stSpDlgId;      /* dialog ID for this component */
   StComps  stComp;         /* component being passed */
   MsgLen   len;
   
   TRC3(cmUnpkStuCmpReq)

   /* zero out component before unpacking */
   cmZeroStComp(&stComp);

   CMCHKUNPKLOG( cmUnpkSpId,    &spId,      mBuf, ESTU142, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &stSpDlgId, mBuf, ESTU143, pst); 
   CMCHKUNPKLOG( cmUnpkStDlgId, &stSuDlgId, mBuf, ESTU144, pst); 
   CMCHKUNPKLOG( cmUnpkStComp,  &stComp,    mBuf, ESTU145, pst); 

   (Void)SFndLenMsg(mBuf,&len);

   if (len == 0)
   {
      (Void)SPutMsg(mBuf);
      mBuf = NULLP;

   }

   (*func)(pst, spId, stSuDlgId, stSpDlgId, &stComp, mBuf );

   RETVALUE(ROK);
} /* end of cmUnpkStuCmpReq */


/*
*
*       Fun:   cmUnpkStuSteReq
*
*       Desc:  This function unpacks the status Request for SSN and Point
*              Codes  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuSteReq
(
StuSteReq  func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuSteReq(func, pst, mBuf)
StuSteReq  func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   CmSS7SteMgmt  steMgmt;
   SpId          spId;
   
   TRC3(cmUnpkStuSteReq)
   
   CMCHKUNPKLOG( cmUnpkSpId,    &spId,    mBuf, ESTU146, pst); 
   CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU147, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, spId, &steMgmt);

   RETVALUE(ROK);
} /* end of cmUnpkStuSteReq */


/*
*
*       Fun:   cmUnpkStuSteRsp
*
*       Desc:  This function unpacks the status Rsponse for SSN and Point
*              Codes  
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  stu.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkStuSteRsp
(
StuSteRsp  func,            /* Call back function */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkStuSteRsp(func, pst, mBuf)
StuSteRsp  func;            /* Call back function */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   CmSS7SteMgmt  steMgmt;
   SpId          spId;
   
   TRC3(cmUnpkStuSteRsp)
   
   CMCHKUNPKLOG( cmUnpkSpId,    &spId,    mBuf, ESTU148, pst); 
   CMCHKUNPKLOG( cmUnpkSteMgmt, &steMgmt, mBuf, ESTU149, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, spId, &steMgmt);

   RETVALUE(ROK);
} /* end of cmUnpkStuSteRsp */

#endif /* LCSTU */


/********************************************************************30**
  
         End of file:     stu.c@@/main/16 - Fri Sep 16 02:51:42 2005
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.
 
1.2          ---  fmg   1. included cm_ss7.?
             ---  fmg   2. removed cmPkStOctet and cmUnpkStOctet
 
1.3          ---  aa    1. changed the #if SS7_ANS88 to #if SS7_ANS88||SS7_ANS92
             ---  aa    2. changed the packing and unpacking of invoke and
                           linked id
 
1.4          ---  aa    1. Changed the packing and unpacking such that the
                           return values of functions are checked only under
                           ADD_RES calss (for packing) and under the DEBUG
                           class for unpacking routines. The macro's used 
                           can be found in ssi.h
             ---  aa    2. change copyright header
 
1.5          ---  aa    1. Include cm_ss7.x before stu.x
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.6          ---      aa   1. Changed class to opClass in StComp.
 
1.7          ---      nj   1. Reorganized the file and added packing/unpacking
                              for ANSI-96 dialogue portion.

1.8          ---      nj   1. Added unpacking routine for the new primitive
                              Bind confirm at the stu interface.
             ---      nj   2. Added packing/unpacking routines for the STU
                              interface primitives.

1.9          ---      nj   1. Added packing/unpacking for a present flag for
                              the user information in the ansi dialogue event
                              structure.

1.9+                  zr   1. ANSI dialogue event pack routine changed
                              to handle user info present field correctly

1.9+                  zr   1. Rolling Upgrade Feature
                   zr   1. Handle SPT and STU interface change
                           - New parameters like imp, isni, sccpState and
                             ril are passed in STU interface in new structures 
                             StDataParam and StMgmntParam. Following packing 
                             and unpacking routines are modified
                              - cmPkStuDatReq
                              - cmUnpkStuDatReq
                              - cmPkStuUDatReq
                              - cmUnpkStuUDatReq
                              - cmPkStuDatInd
                              - cmUnpkStuDatInd
                              - cmPkStuUDatInd
                              - cmUnpkStuUDatInd
                              - cmPkStuNotInd
                              - cmUnpkStuNotInd
                              - cmPkStuSteInd
                              - cmUnpkStuSteInd
                              - cmPkStuSteCfm
                              - cmUnpkStuSteCfm
                           - Above packing and unpacking are reorganized
                             according to Rolling Upgrade specification.
1.9+                 yk   1. Packing and Unpacking is added for suDlgId and spDlgId.
                          2. While Packing and Unpacking case is added for STUV3
/main/15     ---      cp   1.  Removed STU2 flag
/main/16     ---      st   1. Update for MAP 2.3 Release.
*********************************************************************91*/
