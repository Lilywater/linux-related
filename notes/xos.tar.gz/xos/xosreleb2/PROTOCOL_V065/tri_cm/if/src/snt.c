/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     SNT Interface
  
     Type:     C file
  
     Desc:     This file contains the packing/unpacking functions
               for the primitives on snt interface

     File:     snt.c

     Sid:      snt.c@@/main/5 - Fri Nov 16 17:52:18 2001
  
     Prg:      cp
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_ss7.h"        /* common ss7 */
#include "snt.h"           /* spt interface */
#include "cm_err.h"        /* common error */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */
#include "snt.x"           /* spt interface */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/*
 * support functions
 */

#ifdef LCSNT

  
/*
*
*       Fun:   portable - Network Bind Request
*
*       Desc:  This function binds a SCCP Entity to an MTP Level 3 Entity.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSntBndReq
(
Pst *pst,                       /* post structure */
SuId suId,                      /* service user id */
SpId spId,                      /* service provider id */
SrvInfo sInfo                   /* service info */
)
#else
PUBLIC S16 cmPkSntBndReq(pst, suId, spId, sInfo)
Pst *pst;                       /* post structure */
SuId suId;                      /* service user id */
SpId spId;                      /* service provider id */
SrvInfo sInfo;                  /* service info */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;

   TRC3(cmPkSntBndReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT001, (ErrVal) ret1,"SGetMsg failed"); 
      RETVALUE(ret1);
   }

      CMCHKPKLOG(SPkS16, suId, mBuf, ESNT002, pst);
      CMCHKPKLOG(SPkS16, spId, mBuf, ESNT003, pst);
      CMCHKPKLOG(SPkU8, sInfo, mBuf, ESNT004, pst);
      pst->event = EVTSNTBNDREQ;
      SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSntBndReq */

  
/*
*
*       Fun:   portable - Network Unit Data Request
*
*       Desc:  This function tells the MTP Level 3 to transmit data.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSntUDatReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc opc,                        /* originating pont code */
Dpc dpc,                        /* destination point code */
SrvInfo sInfo,                  /* service information */
LnkSel sls,                     /* signalling link selector */
Priority prior,                 /* priority */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmPkSntUDatReq(pst, spId, opc, dpc, sInfo, sls, prior, mBuf)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc opc;                        /* originating pont code */
Dpc dpc;                        /* destination point code */
SrvInfo sInfo;                  /* service information */
LnkSel sls;                     /* signalling link selector */
Priority prior;                 /* priority */
Buffer *mBuf;                   /* message buffer */
#endif
{
  
   TRC3(cmPkSntUDatReq)

   CMCHKPKLOG(SPkU8, prior, mBuf, ESNT006, pst);
   CMCHKPKLOG(SPkU8, sls, mBuf, ESNT007, pst);
   CMCHKPKLOG(SPkU8, sInfo, mBuf, ESNT008, pst);
   CMCHKPKLOG(SPkU32, dpc, mBuf, ESNT009, pst);
   CMCHKPKLOG(SPkU32, opc, mBuf, ESNT010, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESNT011, pst);
  
   pst->event = EVTSNTUDATREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}  /* end of cmPkSntUDatReq */

#ifdef SNT2
  
/*
*
*       Fun:   portable - Network status Request
*
*       Desc:  This function sends status request to MTP3
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSntStaReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* service provider id */
Dpc dpc                         /* destination point code */
)
#else
PUBLIC S16 cmPkSntStaReq(pst, spId, dpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* service provider id */
Dpc dpc;                        /* destination point code */
#endif
{
   Buffer *mBuf;       /* message buffer */
   S16 ret1;           /* return value */
  
   TRC3(cmPkSntStaReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT013, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG(SPkU32, dpc, mBuf, ESNT014, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESNT015, pst);
  
   pst->event = EVTSNTSTAREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}  /* end of cmPkSntStaReq */

#endif /* SNT2 */

/* Added from cp_ex_ms.c */

  
/*
 *      LOOSELY COUPLED LOWER INTERFACE
 */
  
  
/*
*
*       Fun:   cmUnpkSntUDatInd
*
*       Desc:  Unpack Network Data Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  snt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSntUDatInd
(
SntUDatInd func,                /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntUDatInd(func, pst, mBuf)
SntUDatInd func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;                   /* service user id */
   Dpc opc;                     /* originating point code */
   Dpc dpc;                     /* distination point code */
   SrvInfo sInfo;               /* service information */
   LnkSel sls;                  /* signalling link selector */
  
   TRC3(cmUnpkSntDatInd)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT017, pst); 
   CMCHKUNPKLOG( SUnpkU32, &opc, mBuf, ESNT018, pst);  
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESNT019, pst);  
   CMCHKUNPKLOG( SUnpkU8, &sInfo, mBuf, ESNT020, pst); 
   CMCHKUNPKLOG( SUnpkU8, &sls, mBuf, ESNT021, pst);   
   (*func)(pst, suId, opc, dpc, sInfo, sls, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSntDatInd */

  
/*
*
*       Fun:   cmUnpkSntFlcInd
*
*       Desc:  Unpack Network Flow Control Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSntFlcInd
(
SntFlcInd func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntFlcInd(func, pst, mBuf)
SntFlcInd func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;                   /* service user id */
   Action action;               /* action */
  
   TRC3(cmUnpkSntFlcInd)
  
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT022, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ESNT023, pst);
   SPutMsg(mBuf);
   (*func)(pst, suId, action);

   RETVALUE(ROK);
} /* end of cmUnpkSntFlcInd */

 
/*
*
*       Fun:   cmUnpkSntStaInd
*
*       Desc:  Unpack Status Indication
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSntStaInd
(
SntStaInd func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaInd(func, pst, mBuf)
SntStaInd func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   Status status;           /* status information */
   Dpc dpc;                 /* destination point code */
   Priority prior;          /* priority */
  
   TRC3(cmUnpkSntStaInd)
  
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT024, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESNT025, pst);
   CMCHKUNPKLOG( SUnpkS16, &status, mBuf, ESNT026, pst);
   CMCHKUNPKLOG( SUnpkU8, &prior, mBuf, ESNT027, pst);
   SPutMsg(mBuf);
   (*func)(pst, suId, dpc, status, prior);

   RETVALUE(ROK);
}  /* end of cmUnpkSntStaInd */

#ifdef SNT2
 
/*
*
*       Fun:   cmUnpkSntStacfm
*
*       Desc:  Unpack Status confirmation
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSntStaCfm
(
SntStaCfm func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaCfm(func, pst, mBuf)
SntStaCfm func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   Status status;           /* status information */
   Dpc dpc;                 /* destination point code */
   U8 congLevel;            /* congestion level */
  
   TRC3(cmUnpkSntStaCfm)
  
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT028, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESNT029, pst);
   CMCHKUNPKLOG( SUnpkS16, &status, mBuf, ESNT030, pst);
   CMCHKUNPKLOG( SUnpkU8, &congLevel, mBuf, ESNT031, pst);
   SPutMsg(mBuf);
   (*func)(pst, suId, dpc, status, congLevel);

   RETVALUE(ROK);
}  /* end of cmUnpkSntStaCfm */

 
/*
*
*       Fun:   cmUnpkSntBndCfm
*
*       Desc:  Unpack Bind confirmation
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  snt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSntBndCfm
(
SntBndCfm func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntBndCfm(func, pst, mBuf)
SntBndCfm func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   U8 status;               /* status information */
  
   TRC3(cmUnpkSntBndCfm)
  
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT032, pst);
   CMCHKUNPKLOG( SUnpkU8, &status, mBuf, ESNT033, pst);
   SPutMsg(mBuf);
   (*func)(pst, suId, status);

   RETVALUE(ROK);
}  /* end of cmUnpkSntBndCfm */

#endif /* SNT2 */




/*
*
*       Fun:   Pack - Network Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntUDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* Service User Id */
Dpc cgAdr,                  /* Calling Address */
Dpc cdAdr,                  /* Called Address */
SrvInfo srvInfo,            /* Servise Information Octet */
LnkSel lnkSel,              /* signalling Link Selection */
Buffer *mBuf                /* Pointer to the Buffer */
)
#else
PUBLIC S16 cmPkSntUDatInd(pst, suId, cgAdr, cdAdr, srvInfo, lnkSel, mBuf)
Pst *pst;                   /* post structure */
SuId suId;                  /* Service User Id */
Dpc cgAdr;                  /* Calling Address */
Dpc cdAdr;                  /* Called Address */
SrvInfo srvInfo;            /* Servise Information Octet */
LnkSel lnkSel;              /* signalling Link Selection */
Buffer *mBuf;               /* Pointer to the Buffer */
#endif
{
   TRC3(cmPkSntUDatInd)

   CMCHKPKLOG( SPkU8, lnkSel, mBuf, ESNT034, pst);
   CMCHKPKLOG( SPkU8, srvInfo, mBuf, ESNT035, pst);
   CMCHKPKLOG( SPkU32, cdAdr, mBuf, ESNT036, pst);
   CMCHKPKLOG( SPkU32, cgAdr, mBuf, ESNT037, pst);
   CMCHKPKLOG( SPkS16, suId, mBuf, ESNT038, pst);
   pst->event = (Event) EVTSNTUDATIND;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSntUDatInd */


/*
*
*       Fun:   Pack - Status Indication
*
*       Desc:  This function is used to Indicate Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority prior                /* priority */
)
#else
PUBLIC S16 cmPkSntStaInd(pst, suId, adr, status, prior)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority prior;               /* priority */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSntStaInd)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU8, prior, mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkS16, status, mBuf, ESNT041, pst);
   CMCHKPKLOG( SPkU32, adr, mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, suId, mBuf, ESNT043, pst);
   pst->event = (Event) EVTSNTSTAIND;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSntStaInd */


/*
*
*       Fun:   cmPkSntFlcReq
*
*       Desc:  Pack Network Flow Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntFlcReq
(
Pst *pst,                     /* post structure */
SpId spId,                    /* Service User ID */
Action action                 /* action */
)
#else
PUBLIC S16 cmPkSntFlcReq(pst, spId, action)
Pst *pst;                     /* post structure */
SpId spId;                    /* Service User ID */
Action action;                /* action */
#endif
{

   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSntFlcReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT044, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, action, mBuf, ESNT045, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESNT046, pst);
   pst->event = (Event) EVTSNTFLCREQ;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmkSntFlcReq */


/*
*
*       Fun:   cmPkSntFlcInd
*
*       Desc:  Pack Network Flow Control Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntFlcInd
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Action action                 /* action */
)
#else
PUBLIC S16 cmPkSntFlcInd(pst, suId, action)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Action action;                /* action */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSntFlcInd)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT047, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, action, mBuf, ESNT048, pst);
   CMCHKPKLOG( SPkS16, suId, mBuf, ESNT049, pst);
   pst->event = (Event) EVTSNTFLCREQ;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmkSntFlcInd */


#ifdef SNT2
/*
*
*       Fun:   Pack - Status confirmation
*
*       Desc:  This function is used to confirm Signalling Point status when requested
               in a status request.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
Dpc adr,                      /* Address */
Status status,                /* Status */
Priority congLevel            /* Congestion level */
)
#else
PUBLIC S16 cmPkSntStaCfm(pst, suId, adr, status, congLevel)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
Dpc adr;                      /* Address */
Status status;                /* Status */
Priority congLevel;           /* Congestion level */
#endif
{
   Buffer *mBuf;             /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSntStaCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT050, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU8, congLevel, mBuf, ESNT051, pst);
   CMCHKPKLOG( SPkS16, status, mBuf, ESNT052, pst);
   CMCHKPKLOG( SPkU32, adr, mBuf, ESNT053, pst);
   CMCHKPKLOG( SPkS16, suId, mBuf, ESNT054, pst);
   pst->event = (Event) EVTSNTSTACFM;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSntStaCfm */

/*
*
*       Fun:   Pack - Bind confirmation
*
*       Desc:  This function is used to confirm bind request.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntBndCfm
(
Pst *pst,                     /* post structure */
SuId suId,                    /* Service User ID */
U8 status                     /* Status */
)
#else
PUBLIC S16 cmPkSntBndCfm(pst, suId, status)
Pst *pst;                     /* post structure */
SuId suId;                    /* Service User ID */
U8 status;                    /* Status */
#endif
{
   Buffer *mBuf;             /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSntBndCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT055, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU8, status, mBuf, ESNT056, pst);
   CMCHKPKLOG( SPkS16, suId, mBuf, ESNT057, pst);
   pst->event = (Event) EVTSNTBNDCFM;       /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSntBndCfm */

#endif /* SNT2 */

/* Unpack functions */

  
/*
*
*       Fun:   cmUnpkSntBndReq
*
*       Desc:  unpack network bind request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSntBndReq
(
SntBndReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntBndReq(func, pst, mBuf)
SntBndReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SrvInfo srvInfo;         /* service information */       
   SpId spId;               /* service provider id */
   SuId suId;               /* service user id */

   TRC3(cmUnpkSntBndReq)

   CMCHKUNPKLOG( SUnpkU8, &srvInfo, mBuf, ESNT058, pst);
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESNT059, pst);
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESNT060, pst);

   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, spId, srvInfo);
   RETVALUE(ROK);
} /* end of cmUnpkSntBndReq */

  
/*
*
*       Fun:   cmUnpkSntUDatReq
*
*       Desc:  Unpack Network Data Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSntUDatReq
(
SntUDatReq func,               /* primitive pointer */
Pst *pst,                      /* post structure */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntUDatReq(func, pst, mBuf)
SntUDatReq func;               /* primitive pointer */
Pst *pst;                      /* post structure */
Buffer *mBuf;                  /* message buffer */
#endif
{
   SpId spId;                  /* service provider id */
   Dpc cgAdr;                  /* calling address */
   Dpc cdAdr;                  /* called address */
   SrvInfo srvInfo;            /* service information */       
   LnkSel lnkSel;              /* link selection */
   Priority prior;             /* congestion priority */

   TRC3(cmUnpkSntUDatReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESNT072, pst);
   CMCHKUNPKLOG( SUnpkU32, &cgAdr, mBuf, ESNT073, pst);
   CMCHKUNPKLOG( SUnpkU32, &cdAdr, mBuf, ESNT074, pst);
   CMCHKUNPKLOG( SUnpkU8, &srvInfo, mBuf, ESNT075, pst);
   CMCHKUNPKLOG( SUnpkU8, &lnkSel, mBuf, ESNT076, pst);
   CMCHKUNPKLOG( SUnpkU8, &prior, mBuf, ESNT077, pst);
   (Void) (*func)(pst, spId, cgAdr, cdAdr, srvInfo, lnkSel, prior, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSntUDatReq */


  
/*
*
*       Fun:   cmUnpkSntFlcReq
*
*       Desc:  Unpack Network Flow Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSntFlcReq
(
SntFlcReq func,                /* primitive pointer */
Pst *pst,                      /* post structure */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntFlcReq(func, pst, mBuf)
SntFlcReq func;                /* primitive pointer */
Pst *pst;                      /* post structure */
Buffer *mBuf;                  /* message buffer */
#endif
{
   SpId spId;                  /* service provider id */
   Action action;              /* action */

   TRC3(cmUnpkSntFlcReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESNT078, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ESNT079, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, spId, action);
   RETVALUE(ROK);
} /* end of cmUnpkSntFlcReq */

#ifdef SNT2 
/*
*
*       Fun:   cmUnpkSntStaReq
*
*       Desc:  Unpack Network status Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  snt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSntStaReq
(
SntStaReq func,                /* primitive parameter */
Pst *pst,                      /* post structure */
Buffer *mBuf                   /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaReq(func, pst, mBuf)
SntStaReq func;                /* primitive parameter */
Pst *pst;                      /* post structure */
Buffer *mBuf;                  /* message buffer */
#endif
{
   SpId spId;                  /* service provider id */
   Dpc dpc;                    /* destination point code */

   TRC3(cmUnpkSntStaReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESNT081, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, spId, dpc);
   RETVALUE(ROK);
} /* end of cmUnpkSntStaReq */
#endif /* SNT2 */

#ifdef SNTIWF

/*
*
*       Fun:   Pack - Status Apply Request
*
*       Desc:  This function is used to request a change in Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaApyReq
(
Pst         *pst,                 /* post structure */
SpId         spId,                /* Service Provider ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc,                 /* Destination Point code */
SrvInfo      srvInfo,             /* Service Information */
Status       status,              /* Status */
Priority     prior                /* priority */
)
#else
PUBLIC S16 cmPkSntStaApyReq(pst, spId, apc, dpc, srvInfo, status, prior)
Pst         *pst;                 /* post structure */
SpId         spId;                /* Service Provider ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
SrvInfo      srvInfo;             /* Service Information */
Status       status;              /* Status */
Priority     prior;               /* priority */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaApyReq)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU8,  prior,   mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkS16, status,  mBuf, ESNT041, pst);
   CMCHKPKLOG( SPkU8,  srvInfo, mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, spId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAAPYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaApyReq */


/*
*
*       Fun:   Pack - Status Apply Indication
*
*       Desc:  This function is used to indicate a change in Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaApyInd
(
Pst         *pst,                 /* post structure */
SuId         suId,                /* Service User ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc,                 /* Destination Point code */
SrvInfo      srvInfo,             /* Service Information */
Status       status,              /* Status */
Priority     prior                /* priority */
)
#else
PUBLIC S16 cmPkSntStaApyInd(pst, suId, apc, dpc, srvInfo, status, prior)
Pst         *pst;                 /* post structure */
SuId         suId;                /* Service User ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
SrvInfo      srvInfo;             /* Service Information */
Status       status;              /* Status */
Priority     prior;               /* priority */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaApyInd)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU8,  prior,   mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkS16, status,  mBuf, ESNT041, pst);
   CMCHKPKLOG( SPkU8,  srvInfo, mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, suId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAAPYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaApyInd */


/*
*
*       Fun:   Pack - Status Query Request
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaQryReq
(
Pst         *pst,                 /* post structure */
SpId         spId,                /* Service Provider ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc                  /* Destination Point code */
)
#else
PUBLIC S16 cmPkSntStaQryReq(pst, spId, apc, dpc)
Pst         *pst;                 /* post structure */
SpId         spId;                /* Service Provider ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaQryReq)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, spId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAQRYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaQryReq */


/*
*
*       Fun:   Pack - Status Query Indication
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaQryInd
(
Pst         *pst,                 /* post structure */
SuId         suId,                /* Service User ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc                  /* Destination Point code */
)
#else
PUBLIC S16 cmPkSntStaQryInd(pst, suId, apc, dpc)
Pst         *pst;                 /* post structure */
SuId         suId;                /* Service User ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaQryInd)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, suId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAQRYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaQryInd */


/*
*
*       Fun:   Pack - Status Query Response
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaQryRsp
(
Pst         *pst,                 /* post structure */
SuId         suId,                /* Service User ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc,                 /* Destination Point code */
Status       status,              /* Status */
Priority     prior                /* priority */
)
#else
PUBLIC S16 cmPkSntStaQryRsp(pst, suId, apc, dpc, status, prior)
Pst         *pst;                 /* post structure */
SuId         suId;                /* Service User ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
Status       status;              /* Status */
Priority     prior;               /* priority */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaQryRsp)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU8,  prior,   mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkS16, status,  mBuf, ESNT041, pst);
   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, suId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAQRYRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaQryRsp */


/*
*
*       Fun:   Pack - Status Query Confirm
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSntStaQryCfm
(
Pst         *pst,                 /* post structure */
SpId         spId,                /* Service Provider ID */
Dpc          apc,                 /* Affected Point Code */
Dpc          dpc,                 /* Destination Point code */
Status       status,              /* Status */
Priority     prior                /* priority */
)
#else
PUBLIC S16 cmPkSntStaQryCfm(pst, spId, apc, dpc, status, prior)
Pst         *pst;                 /* post structure */
SpId         spId;                /* Service Provider ID */
Dpc          apc;                 /* Affected Point Code */
Dpc          dpc;                 /* Destination Point code */
Status       status;              /* Status */
Priority     prior;               /* priority */
#endif
{
   Buffer   *mBuf;                /* message buffer */
   S16       ret1;                /* return value */

   TRC3(cmPkSntStaQryCfm)

   /* Allocate a message buffer here to pack the primitive parameters */
   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SNTLOGERROR(ERRCLS_ADD_RES, ESNT039, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   CMCHKPKLOG( SPkU8,  prior,   mBuf, ESNT040, pst);
   CMCHKPKLOG( SPkS16, status,  mBuf, ESNT041, pst);
   CMCHKPKLOG( SPkU32, dpc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkU32, apc,     mBuf, ESNT042, pst);
   CMCHKPKLOG( SPkS16, spId,    mBuf, ESNT043, pst);

   /* Post the primitive to the ddestination layer */
   pst->event = (Event) EVTSNTSTAQRYCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSntStaQryCfm */


/*
*
*       Fun:   Unpack - Status Apply Request
*
*       Desc:  This function is used to request a change in Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaApyReq
(
SntStaApyReq func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaApyReq(func, pst, mBuf)
SntStaApyReq func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SpId     spId;                 /* service provider id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */
   SrvInfo  srvInfo;              /* service information */
   Status   status;               /* status */
   Priority priority;             /* priority */

   TRC3(cmUnpkSntStaApyReq)

   CMCHKUNPKLOG( SUnpkS16, &spId,     mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,      mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,      mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &srvInfo,  mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkS16, &status,   mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &priority, mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, spId, apc, dpc, srvInfo, status, priority);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaApyReq */


/*
*
*       Fun:   Unpack - Status Apply Indication
*
*       Desc:  This function is used to indicate a change in Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaApyInd
(
SntStaApyInd func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaApyInd(func, pst, mBuf)
SntStaApyInd func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SuId     suId;                 /* service user id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */
   SrvInfo  srvInfo;              /* service information */
   Status   status;               /* status */
   Priority priority;             /* priority */

   TRC3(cmUnpkSntStaApyInd)

   CMCHKUNPKLOG( SUnpkS16, &suId,      mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &srvInfo,   mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkS16, &status,    mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &priority,  mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, suId, apc, dpc, srvInfo, status, priority);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaApyInd */


/*
*
*       Fun:   Unpack - Status Query Request
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaQryReq
(
SntStaQryReq func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaQryReq(func, pst, mBuf)
SntStaQryReq func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SpId     spId;                 /* service provider id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */

   TRC3(cmUnpkSntStaQryReq)

   CMCHKUNPKLOG( SUnpkS16, &spId,    mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,     mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,     mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, spId, apc, dpc);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaQryReq */


/*
*
*       Fun:   Unpack - Status Query Indication
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaQryInd
(
SntStaQryInd func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaQryInd(func, pst, mBuf)
SntStaQryInd func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SuId     suId;                 /* service user id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */

   TRC3(cmUnpkSntStaQryInd)

   CMCHKUNPKLOG( SUnpkS16, &suId,    mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,     mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,     mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, suId, apc, dpc);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaQryInd */


/*
*
*       Fun:   Unpack - Status Query Response
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaQryRsp
(
SntStaQryRsp func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaQryRsp(func, pst, mBuf)
SntStaQryRsp func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SuId     suId;                 /* service user id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */
   Status   status;               /* status */
   Priority priority;             /* priority */

   TRC3(cmUnpkSntStaQryRsp)

   CMCHKUNPKLOG( SUnpkS16, &suId,      mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkS16, &status,    mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &priority,  mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, suId, apc, dpc, status, priority);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaQryRsp */


/*
*
*       Fun:   Unpack - Status Query Confirm
*
*       Desc:  This function is used to query a Signalling Point status.
*
*       Ret:   ROK     - ok
*              RFAILED - not ok
*
*       Notes: This primitive is used only in a Signaling Gateway where MTP3 layer
*              is interworking with another equivalent (for example, M3UA) layer.
*
*       File:  snt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSntStaQryCfm
(
SntStaQryCfm func,                /* primitive parameter */
Pst          *pst,                /* post structure */
Buffer       *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSntStaQryCfm(func, pst, mBuf)
SntStaQryCfm func;                /* primitive parameter */
Pst          *pst;                /* post structure */
Buffer       *mBuf;               /* message buffer */
#endif
{
   SpId     spId;                 /* service provider id */
   Dpc      apc;                  /* affected point code */
   Dpc      dpc;                  /* destination point code */
   Status   status;               /* status */
   Priority priority;             /* priority */

   TRC3(cmUnpkSntStaQryCfm)

   CMCHKUNPKLOG( SUnpkS16, &spId,      mBuf, ESNT080, pst);
   CMCHKUNPKLOG( SUnpkU32, &apc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc,       mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkS16, &status,    mBuf, ESNT081, pst);
   CMCHKUNPKLOG( SUnpkU8,  &priority,  mBuf, ESNT081, pst);

   (Void) SPutMsg(mBuf);

   /* Make a function call into the layer */
   (Void) (*func)(pst, spId, apc, dpc, status, priority);

   RETVALUE(ROK);
} /* end of cmUnpkSntStaQryCfm */

#endif /* SNTIWF */
#endif /* LCSNT */

  
/********************************************************************30**
  
         End of file:     snt.c@@/main/5 - Fri Nov 16 17:52:18 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      cp   1. initial release.
                      sr   1. Common pack/unpack functions for SNT interface
                      pm   2. corrected the cmPkSntBndCfm declaration.
                      sr   3. corrected the names for pack/unpack functions
                           4. modified loosely coupled flag LCSNLISNT to LCSNT.
             ---      pm   5. added cmPkSntFlcReq and cmPkSntFlcInd functions.
/main/2        ---     ssk   6. fixed the problems in Pk&Unpk of FlcReq.
                           7. Removed the SEL_LC_NEW & OLD # defines . 
                              LDF needs the packing/unpacking to be done 
                              irrespective of the selector value. 

/main/4      ---      nj   1. Added packing/unpakcing functions for the 
                              interworking status (apply/query) primitives
/main/5      ---      nt   1. Warning removed from cmPkSntFlcInd in packing of
                              action.
*********************************************************************91*/
