/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     SHT Interface

     Type:     C source file
  
     Desc:     C source code for common packing and un-packing
               functions for SHT interface.

     File:     sht.c
  
     Sid:      sht.c@@/main/6 - Fri Sep 16 02:50:52 2005
  
     Prg:      ash
  
*********************************************************************21*/

/* header include files (.h)            */
#include "envopt.h"                             /* environ options      */  
#include "envdep.h"                             /* environ dependent    */
#include "envind.h"                             /* environ independent  */
#include "gen.h"                                /* general layer        */
#include "ssi.h"                                /* system services      */
#include "sht.h"                                /* layer management i/f */

/* header/extern include files (.x)     */
#include "gen.x"                                /* general layer        */
#include "ssi.x"                                /* system services      */
#include "sht.x"                                /* layer management i/f */

 
/*
 *     This software may be combined with the following TRILLIUM
 *     software:
 *
 *     part no.                      description
 *     --------    ----------------------------------------------
 *     1000119     System Agent
 *        *        All other Trillium portable products
 *
 */

 

/*****************************************************************************
 * Packing Functions
 *****************************************************************************/
/*
 *
 *       Fun  : cmPkShtHeader
 *
 *       Desc : This function packs the SHT Interface request header structure
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkShtHeader
(
ShtHeader       *hdr,                           /* SHT Header           */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmPkShtHeader(hdr, mBuf)
ShtHeader       *hdr;                           /* SHT Header           */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
   TRC2(cmPkShtHeader)

   /* pack response structure */
   CMCHKPK(cmPkMemoryId, &hdr->response.mem, mBuf);
   CMCHKPK(cmPkRoute, hdr->response.route, mBuf);
   CMCHKPK(cmPkPriority, hdr->response.prior, mBuf);
   CMCHKPK(cmPkSelector, hdr->response.selector, mBuf);

   /* pack transaction Id */
   CMCHKPK(cmPkTranId, hdr->transId, mBuf);
   RETVALUE(ROK);
} /* end of cmPkShtHeader */


/*
 *
 *       Fun  : cmPkShtCntrlReqEvnt
 *
 *       Desc : This function packs the system agent control request event
 *              structure.
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkShtCntrlReqEvnt
(
ShtCntrlReqEvnt *reqInfo,                       /* SH cntrl req event   */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmPkShtCntrlReqEvnt(reqInfo, mBuf)
ShtCntrlReqEvnt *reqInfo;                       /* SH cntrl req event   */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
   TRC2(cmPkShtCntrlReqEvnt)

   /* pack structure specific to request type */
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         CMCHKPK(cmPkEntityId, &reqInfo->s.bndEna.dstEnt, mBuf);
         CMCHKPK(cmPkProcId, reqInfo->s.bndEna.dstProcId, mBuf);
         CMCHKPK(SPkU8, reqInfo->s.bndEna.grpType, mBuf);
         break;

      case SHT_REQTYPE_UBND_DIS:   /* system agent control unbind disble */
         CMCHKPK(cmPkEntityId, &reqInfo->s.ubndDis.dstEnt, mBuf);
         CMCHKPK(cmPkProcId, reqInfo->s.ubndDis.dstProcId, mBuf);
         CMCHKPK(SPkU8, reqInfo->s.ubndDis.grpType, mBuf);
         break;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
      case SHT_REQTYPE_GETVER:   /* system agent control, get intf ver */
         /* No parameters are there in Get Ver*/
         break;

      case SHT_REQTYPE_SETVER:   /* system agent control set intf ver */
         CMCHKPK(SPkU8,        reqInfo->s.svReq.grpType,   mBuf);
         CMCHKPK(cmPkProcId,   reqInfo->s.svReq.dstProcId, mBuf);
         CMCHKPK(cmPkEntityId, &reqInfo->s.svReq.dstEnt,   mBuf);
         CMCHKPK(cmPkIntf,     &reqInfo->s.svReq.intf,     mBuf);
         break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

      default:
         break;
   } /* end switch */

   /* pack request type parameter */
   CMCHKPK(SPkU8, reqInfo->reqType, mBuf);

   /* pack SHT header structure */
   CMCHKPK(cmPkShtHeader, &reqInfo->hdr, mBuf);
   RETVALUE(ROK);
} /* end of cmPkShtCntrlReqEvnt */


/*
 *
 *       Fun  : Pack System agent control Request 
 *
 *       Desc : This function is used to pack the system agent control request
 *              primitive.
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkMiShtCntrlReq
(
Pst             *pst,                           /* post structure       */    
ShtCntrlReqEvnt *reqInfo                        /* SH cntrl req event   */
)
#else
PUBLIC S16 cmPkMiShtCntrlReq(pst, reqInfo)
Pst             *pst;                           /* post structure       */    
ShtCntrlReqEvnt *reqInfo;                       /* SH cntrl req event   */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16    retVal;              /* return value */
 
   TRC2(cmPkMiShtCntrlReq)

   /* allocate message buffer */
   if ((retVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
      /* message allocation failure */
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                __LINE__, ERRCLS_ADD_RES, ESHTXXX, (ErrVal) retVal, 
                "SGetMsg failed");
      RETVALUE(retVal);
   }

   /* pack system agent control request event */
   CMCHKPKLOG(cmPkShtCntrlReqEvnt, reqInfo, mBuf, ESHTXXX, pst);

   /* fill event and post the message */
   pst->event = EVTSHTCNTRLREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkMiShtCntrlReq */


/*
 *
 *       Fun  : cmPkShtCntrlCfmEvnt
 *
 *       Desc : This function packs the system agent control confirm event
 *              structure
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkShtCntrlCfmEvnt
(
ShtCntrlCfmEvnt *cfmInfo,                       /* SH cntrl req event   */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmPkShtCntrlCfmEvnt(cfmInfo, mBuf)
ShtCntrlCfmEvnt *cfmInfo;                       /* SH cntrl req event   */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U16     intfIndex;
#endif

   TRC2(cmPkShtCntrlCfmEvnt)

   /* pack status parameter */
   CMCHKPK(cmPkCmStatus, &cfmInfo->status, mBuf);

   /* pack transaction Id */
   CMCHKPK(cmPkTranId, cfmInfo->transId, mBuf);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   switch (cfmInfo->reqType)
   {
      case SHT_REQTYPE_GETVER:
         for (intfIndex = 0; intfIndex < cfmInfo->t.gvCfm.numUif; intfIndex++)
            CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.uifList[intfIndex], mBuf);
         CMCHKPK(SPkU16,      cfmInfo->t.gvCfm.numUif,              mBuf);

         for (intfIndex = 0; intfIndex < cfmInfo->t.gvCfm.numLif; intfIndex++)
            CMCHKPK(cmPkIntf, &cfmInfo->t.gvCfm.lifList[intfIndex], mBuf);
         CMCHKPK(SPkU16,      cfmInfo->t.gvCfm.numLif,              mBuf);

         CMCHKPK(cmPkIntf,    &cfmInfo->t.gvCfm.pif,                mBuf);
         break;

      default:
         break;
   }
   CMCHKPK(SPkU8, cfmInfo->reqType, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
} /* end of cmPkShtCntrlCfmEvnt */


/*
 *
 *       Fun  : Pack System agent control Confirm Primitive
 *
 *       Desc : This function is used to pack the system agent control confirm
 *              primitive.
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkMiShtCntrlCfm
(
Pst             *pst,                           /* post structure       */
ShtCntrlCfmEvnt *cfmInfo                        /* SH cntrl req event   */
)
#else
PUBLIC S16 cmPkMiShtCntrlCfm(pst, cfmInfo)
Pst             *pst;                           /* post structure       */
ShtCntrlCfmEvnt *cfmInfo;                       /* SH cntrl req event   */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16    retVal;              /* return value */
 
   TRC2(cmPkMiShtCntrlCfm)

   /* allocate message buffer */
   if ((retVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
      /* message allocation failure */
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                __LINE__, ERRCLS_ADD_RES, ESHTXXX, (ErrVal) retVal, 
                "SGetMsg failed");
      RETVALUE(retVal);
   }

   /* pack system agent control confirm event */
   CMCHKPKLOG(cmPkShtCntrlCfmEvnt, cfmInfo, mBuf, ESHTXXX, pst);

   /* fill event and post the message */
   pst->event = EVTSHTCNTRLCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkMiShtCntrlCfm */



/*****************************************************************************
 * Unpacking Functions
 *****************************************************************************/
/*
 *
 *       Fun  : cmUnpkShtHeader
 *
 *       Desc : This function unpacks the SHT Interface request header
 *              structure
 *
 *       Ret  : ROK      - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkShtHeader
(
ShtHeader       *hdr,                           /* SHT header pointer   */
Buffer          *mBuf                           /* message buffer */
)
#else
PUBLIC S16 cmUnpkShtHeader(hdr, mBuf)
ShtHeader       *hdr;                           /* SHT header pointer   */
Buffer          *mBuf;                          /* message buffer */
#endif
{
   TRC2(cmUnpkShtHeader)

   /* unpack transaction Id */
   CMCHKUNPK(cmUnpkTranId, &hdr->transId, mBuf);

   /* unpack response structure */
   CMCHKUNPK(cmUnpkSelector, &hdr->response.selector, mBuf);
   CMCHKUNPK(cmUnpkPriority, &hdr->response.prior, mBuf);
   CMCHKUNPK(cmUnpkRoute, &hdr->response.route, mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &hdr->response.mem, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkShtHeader */


/*
 *
 *       Fun  : cmUnpkShtCntrlReqEvnt
 *
 *       Desc : This function unpacks the system agent control request event
 *              structure
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkShtCntrlReqEvnt
(
ShtCntrlReqEvnt *reqInfo,                       /* SH cntrl req event   */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmUnpkShtCntrlReqEvnt(reqInfo, mBuf)
ShtCntrlReqEvnt *reqInfo;                       /* SH cntrl req event   */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
   TRC2(cmUnpkShtCntrlReqEvnt)

   /* unpack SHT header  */
   CMCHKUNPK(cmUnpkShtHeader, &reqInfo->hdr, mBuf);

   /* unpack request type parameter */
   CMCHKUNPK(SUnpkU8, &reqInfo->reqType, mBuf);

   /* unpack structure specific to request type */
   switch (reqInfo->reqType)
   {
      case SHT_REQTYPE_BND_ENA:   /* system agent control bind enable */
         CMCHKUNPK(SUnpkU8, &reqInfo->s.bndEna.grpType, mBuf);
         CMCHKUNPK(cmUnpkProcId, &reqInfo->s.bndEna.dstProcId, mBuf);
         CMCHKUNPK(cmUnpkEntityId, &reqInfo->s.bndEna.dstEnt, mBuf);
         break;

      case SHT_REQTYPE_UBND_DIS:   /* system agent control unbind disble */
         CMCHKUNPK(SUnpkU8, &reqInfo->s.ubndDis.grpType, mBuf);
         CMCHKUNPK(cmUnpkProcId, &reqInfo->s.ubndDis.dstProcId, mBuf);
         CMCHKUNPK(cmUnpkEntityId, &reqInfo->s.ubndDis.dstEnt, mBuf);
         break;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
      case SHT_REQTYPE_GETVER:
         /* No parameters have been packed, no need of unpacking */
         break;

      case SHT_REQTYPE_SETVER:
         CMCHKUNPK(cmUnpkIntf,     &reqInfo->s.svReq.intf,     mBuf);
         CMCHKUNPK(cmUnpkEntityId, &reqInfo->s.svReq.dstEnt,   mBuf);
         CMCHKUNPK(cmUnpkProcId,   &reqInfo->s.svReq.dstProcId, mBuf);
         CMCHKUNPK(SUnpkU8,        &reqInfo->s.svReq.grpType,   mBuf);
         break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

      default:
         break;
   } /* end switch */

   RETVALUE(ROK);
} /* end of cmPkShtCntrlReqEvnt */


/*
 *
 *       Fun  : Unpack System agent control Request 
 *
 *       Desc : This function is used to unpack the system agent control
 *              request primitive.
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkMiShtCntrlReq
(
ShtCntrlReq     func,                           /* primitive callback   */
Pst             *pst,                           /* post structure       */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmUnpkMiShtCntrlReq(func, pst, mBuf)
ShtCntrlReq     func;                           /* primitive callback   */
Pst             *pst;                           /* post structure       */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
   ShtCntrlReqEvnt reqInfo;   /* request event */

   TRC2(cmUnpkMiShtCntrlReq)

   /* unpack system agent control request event structure */
   CMCHKUNPKLOG(cmUnpkShtCntrlReqEvnt, &reqInfo, mBuf, ESHTXXX, pst);

   /* release message bugger */
   SPutMsg(mBuf);
 
   /* call the function */
   (*func) (pst, &reqInfo);
   RETVALUE(ROK);

} /* end of cmUnpkMiShtCntrlReq */


/*
 *
 *       Fun  : cmUnpkShtCntrlCfmEvnt
 *
 *       Desc : This function unpacks the system agent control confirm event
 *              structure
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None.
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkShtCntrlCfmEvnt
(
ShtCntrlCfmEvnt *cfmInfo,                       /* SH cntrl req event   */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmUnpkShtCntrlCfmEvnt(cfmInfo, mBuf)
ShtCntrlCfmEvnt *cfmInfo;                       /* SH cntrl req event   */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   S32     intfIndex;                           /* interface index     */
#endif

   TRC2(cmUnpkShtCntrlCfmEvnt)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8, &cfmInfo->reqType, mBuf);
   switch (cfmInfo->reqType)
   {
      case SHT_REQTYPE_GETVER:
         CMCHKUNPK(cmUnpkIntf,    &cfmInfo->t.gvCfm.pif,               mBuf);

         CMCHKUNPK(SUnpkU16,      &cfmInfo->t.gvCfm.numLif,            mBuf);
         for(intfIndex=cfmInfo->t.gvCfm.numLif-1; intfIndex >= 0; --intfIndex)
            CMCHKUNPK(cmUnpkIntf, &cfmInfo->t.gvCfm.lifList[intfIndex], mBuf);

         CMCHKUNPK(SUnpkU16,      &cfmInfo->t.gvCfm.numUif,             mBuf);
         for(intfIndex=cfmInfo->t.gvCfm.numUif-1; intfIndex >= 0; --intfIndex)
            CMCHKUNPK(cmUnpkIntf, &cfmInfo->t.gvCfm.uifList[intfIndex], mBuf);
         break;

      default:
         break;
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack transaction Id */
   CMCHKUNPK(cmUnpkTranId, &cfmInfo->transId, mBuf);

   /* unpack status structure */
   CMCHKUNPK(cmUnpkCmStatus, &cfmInfo->status, mBuf);
   RETVALUE(ROK);
} /* end of cmPkShtCntrlCfmEvnt */

/*

 *
 *       Fun  : Unpack System agent control Confirm 
 *
 *       Desc : This function is used to unpack the system agent control
 *              confirm primitive.
 *
 *       Ret  : ROK - ok
 *
 *       Notes: None
 *
 *       File : sht.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkMiShtCntrlCfm
(
ShtCntrlCfm     func,                           /* primitive callback   */
Pst             *pst,                           /* post structure       */
Buffer          *mBuf                           /* message buffer       */
)
#else
PUBLIC S16 cmUnpkMiShtCntrlCfm(func, pst, mBuf)
ShtCntrlCfm     func;                           /* primitive callback   */
Pst             *pst;                           /* post structure       */
Buffer          *mBuf;                          /* message buffer       */
#endif
{
   ShtCntrlCfmEvnt cfmInfo;   /* confirm event */

   TRC2(cmUnpkMiShtCntrlCfm)

   /* unpack system agent control confirm event structure */
   CMCHKUNPKLOG(cmUnpkShtCntrlCfmEvnt, &cfmInfo, mBuf, ESHTXXX, pst);

   /* release message bugger */
   SPutMsg(mBuf);
 
   /* call the function */
   (*func) (pst, &cfmInfo);
   RETVALUE(ROK);
} /* end of cmUnpkMiShtCntrlCfm */

  
/********************************************************************30**
  
         End of file:     sht.c@@/main/6 - Fri Sep 16 02:50:52 2005
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      ash  1. Initial release.
                           2. Replaced ShSht with MiSht
             ---      ark  3. Fixed compilation warnings
                           4. Added conversion function initializers and
                              misc formatting changes
             ---      ark  5. Moved conversion function initializers to
                              cm_cfn.[cx]
/main/4      ---      cvp  1. changed the copyright header.
/main/5      ---      ns   1. changes for rolling upgrade feature. pack/unpack
                              functions for get and set interface version
/main/6      ---      st   1. Update for MAP Release 2.3
*********************************************************************91*/
 

