/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
        Name:     MAP PSF 
    
        Type:     C source file
  
        Desc:     This file consists of all outgoing primitives from MAP update
                  module at management interface.
 
        File:     lzj.c

        Sid:      lzj.c@@/main/1 - Fri Dec 10 17:54:49 2004
  
        Prg:      jz
  
*********************************************************************21*/

/*
 *      This software may be combined with the following TRILLIUM
 *      software:
 *
 *      part no.                      description
 *      --------    ----------------------------------------------
 *      1XXX032     GSM Mobile Application Part - MAP
 */
 
  

/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm_ss7.h"        /* common ss7 */
#include "cm5.h"           /* common timer routines */
#include "cm_err.h"        /* common error */
#include "lma.h"           /* MAP layer management Interface */
//#include "ma.h"
#include "mat.h"           /* MAP Upper Interface */
#include "stu.h"           /* MAP Lwer Interface */
#include "cm_ftha.h"
#include "mrs.h"
#include "sht.h"
#include "cm_pftha.h"      /* common PSF */
#include "cm_tupsf.h"      /* common TCAP user PSF */
#include "lzj.h"           /* MAP PSF management */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm5.x"           /* Common Timer */
#include "lma.x"           /* MAP layer management Interface */
#include "stu.x"           /* MAP Lower interface */
#include "mat.x"           /* MAP Upper Interface  */
#include "cm_ftha.x"
#include "mrs.x"
#include "sht.x"
#include "cm_pftha.x"      /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#include "cm_tupsf.x"      /* common TCAP user PSF */
#include "lzj.x"           /* MAP PSF management */
//#include "ma.x"


/* local defines */

/* local externs */

/*      CONFIGURATION 
*/


/*
 *
 *      Fun:   cmPkLzjCfgReq
 *
 *      Desc:  This function packs PSF's configuration request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjCfgReq
(
Pst         *pst,               /* post structure         */
CmTuMngmt   *cfg                /* management structure   */
)
#else
PUBLIC S16 cmPkLzjCfgReq(pst, cfg)
Pst         *pst;               /* post structure         */
CmTuMngmt   *cfg;               /* management structure   */
#endif
{
   TRC2(cmPkLzjCfgReq)

   RETVALUE(cmPkCmTuCfgReq(pst, cfg, LZJIFVER));

} /* end of cmPkLzjCfgReq */


/*
 *
 *      Fun:   cmPkLzjCfgCfm
 *
 *      Desc:  This function packs PSF's configuration confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjCfgCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkLzjCfgCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt   *cfm;               /* management structure */
#endif
{

   TRC2(cmPkLzjCfgCfm)

   RETVALUE(cmPkCmTuCfgCfm(pst, cfm));

} /* end of cmPkLzjCfgCfm */

/*      CONTROL 
*/


/*
 *
 *       Fun:   Pack the control Request
 *
 *       Desc:  This function is used to pack the control request
 *              primitive to PSF-MAP.
 *
 *       Ret:   ROK      - ok
 *
 *       Notes: None
 *
 *       File:  lzj.c
 *
 */
  
#ifdef ANSI
PUBLIC S16 cmPkLzjCntrlReq
(
Pst *pst,                   /* post structure */    
CmTuMngmt *cntrl              /* control request */
)
#else
PUBLIC S16 cmPkLzjCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */    
CmTuMngmt *cntrl;             /* control request */
#endif
{
 
   TRC3(cmPkLzjCntrlReq);

   RETVALUE(cmPkCmTuCntrlReq(pst, cntrl, LZJIFVER));

} /* cmPkLzjCntrlReq */


/*
 *
 *      Fun:   cmPkLzjCntrlCfm
 *
 *      Desc:  This function packs PSF's control confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjCntrlCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkLzjCntrlCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt   *cfm;               /* management structure */
#endif
{
   TRC2(cmPkLzjCntrlCfm)

   RETVALUE(cmPkCmTuCntrlCfm(pst, cfm));

} /* end of cmPkLzjCntrlCfm */


/*
 *
 *      Fun:   cmPkLzjStaReq
 *
 *      Desc:  This function packs PSF'solicited status request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjStaReq
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *sta                /* management structure */
)
#else
PUBLIC S16 cmPkLzjStaReq(pst, sta)
Pst         *pst;               /* post structure       */
CmTuMngmt   *sta;               /* management structure */
#endif
{
   TRC2(cmPkLzjStaReq)

   RETVALUE(cmPkCmTuStaReq(pst, sta, LZJIFVER));

} /* end of cmPkLzjStaReq */


/*
 *
 *      Fun:   cmPkLzjStaCfm
 *
 *      Desc:  This function packs PSF'solicited status confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjStaCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *sta                /* management structure */
)
#else
PUBLIC S16 cmPkLzjStaCfm(pst, sta)
Pst         *pst;               /* post structure       */
CmTuMngmt   *sta;               /* management structure */
#endif
{
   TRC2(cmPkLzjStaCfm)

   RETVALUE(cmPkCmTuStaCfm(pst, sta));

} /* end of cmPkLzjStaCfm */



/*
 *
 *      Fun:   cmPkLzjStsReq
 *
 *      Desc:  This function packs PSF'statistics request
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjStsReq
(
Pst         *pst,               /* post structure       */
Action      action,             /* action               */
CmTuMngmt   *sts                /* management structure */
)
#else
PUBLIC S16 cmPkLzjStsReq(pst, action, sts)
Pst         *pst;               /* post structure       */
Action      action;             /* action               */
CmTuMngmt   *sts;               /* management structure */
#endif
{
   TRC2(cmPkLzjStsReq)

   RETVALUE(cmPkCmTuStsReq(pst, action, sts, LZJIFVER));

} /* end of cmPkLzjStsReq */



/*
 *
 *      Fun:   cmPkLzjStsCfm
 *
 *      Desc:  This function packs PSF'statistics confirm
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjStsCfm
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *cfm                /* management structure */
)
#else
PUBLIC S16 cmPkLzjStsCfm(pst, cfm)
Pst         *pst;               /* post structure       */
CmTuMngmt   *cfm;               /* management structure */
#endif
{
   TRC2(cmPkLzjStsCfm)

   RETVALUE(cmPkCmTuStsCfm(pst, cfm));

} /* end of cmPkLzjStsCfm */



/*
 *
 *      Fun:   cmPkLzjStaInd
 *
 *      Desc:  This function packs PSF's unsolicited status
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjStaInd
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *usta               /* management structure */
)
#else
PUBLIC S16 cmPkLzjStaInd(pst, usta)
Pst         *pst;               /* post structure       */
CmTuMngmt   *usta;              /* management structure */
#endif
{
   TRC2(cmPkLzjStaInd)

   RETVALUE(cmPkCmTuStaInd(pst, usta));

} /* end of cmPkLzjStaInd */



/*
 *
 *      Fun:   cmPkLzjTrcInd
 *
 *      Desc:  This function packs PSF's trace indication
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmPkLzjTrcInd
(
Pst         *pst,               /* post structure       */
CmTuMngmt   *trc                /* management structure */
)
#else
PUBLIC S16 cmPkLzjTrcInd(pst, trc)
Pst         *pst;               /* post structure       */
CmTuMngmt   *trc;               /* management structure */
#endif
{
   TRC2(cmPkLzjTrcInd)

   RETVALUE(cmPkCmTuTrcInd(pst, trc));

} /* end of cmPkLzjTrcInd */


/* unpacking functions */


/*
 *
 *      Fun:   cmUnpkLzjCfgReq
 *
 *      Desc:  This function unpacks configuration request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjCfgReq
(
CmTuCfgReq   func,              /* primtive to call */
Pst          *pst,              /* post */
Buffer       *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkLzjCfgReq(func, pst, mBuf)
CmTuCfgReq   func;              /* primtive to call */
Pst          *pst;              /* post */
Buffer       *mBuf;             /* message buffer */
#endif
{
   TRC2(cmUnpkLzjCfgReq)

   /* call primitive */
   RETVALUE(cmUnpkCmTuCfgReq(func, pst, mBuf));

} /* end of cmUnpkLzjCfgReq */


/*
 *
 *      Fun:   cmUnpkLzjCfgCfm
 *
 *      Desc:  This function unpacks configuration confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjCfgCfm
(
CmTuCfgCfm   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjCfgCfm(func, pst, mBuf)
CmTuCfgCfm   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjCfgCfm)

   RETVALUE(cmUnpkCmTuCfgCfm(func, pst, mBuf));

} /* end of cmUnpkLzjCfgCfm */


/*
 *
 *      Fun:   cmUnpkLzjCntrlReq
 *
 *      Desc:  This function unpacks control request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjCntrlReq
(
CmTuCntrlReq func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjCntrlReq(func, pst, mBuf)
CmTuCntrlReq func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjCntrlReq)

   /* call primitive */
   RETVALUE(cmUnpkCmTuCntrlReq(func, pst, mBuf));

} /* end of cmUnpkLzjCntrlReq */


/*
 *
 *      Fun:   cmUnpkLzjCntrlCfm
 *
 *      Desc:  This function unpacks control confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjCntrlCfm
(
CmTuCntrlCfm   func,            /* primtive to call */
Pst            *pst,            /* post             */
Buffer         *mBuf            /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjCntrlCfm(func, pst, mBuf)
CmTuCntrlCfm   func;            /* primtive to call */
Pst            *pst;            /* post             */
Buffer         *mBuf;           /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjCntrlCfm)

   /* call primitive */
   RETVALUE(cmUnpkCmTuCntrlCfm(func, pst, mBuf));

} /* end of cmUnpkLzjCntrlCfm */


/*
 *
 *      Fun:   cmUnpkLzjStaReq
 *
 *      Desc:  This function unpacks status request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjStaReq
(
CmTuStaReq   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjStaReq(func, pst, mBuf)
CmTuStaReq   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjStaReq)

   /* call primitive */
   RETVALUE(cmUnpkCmTuStaReq(func, pst, mBuf));

} /* end of cmUnpkLzjStaReq */


/*
 *
 *      Fun:   cmUnpkLzjStaCfm
 *
 *      Desc:  This function unpacks status confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjStaCfm
(
CmTuStaCfm   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjStaCfm(func, pst, mBuf)
CmTuStaCfm   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjStaCfm)

   /* call primitive */
   RETVALUE(cmUnpkCmTuStaCfm(func, pst, mBuf));

} /* end of cmUnpkLzjStaCfm */


/*
 *
 *      Fun:   cmUnpkLzjStsReq
 *
 *      Desc:  This function unpacks statistics request to PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjStsReq
(
CmTuStsReq   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjStsReq(func, pst, mBuf)
CmTuStsReq   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjStsReq)
   
   /* call primitive */
   RETVALUE(cmUnpkCmTuStsReq(func, pst, mBuf));

} /* end of cmUnpkLzjStsReq */



/*
 *
 *      Fun:   cmUnpkLzjStsCfm
 *
 *      Desc:  This function unpacks statistics confirm from PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjStsCfm
(
CmTuStsCfm   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjStsCfm(func, pst, mBuf)
CmTuStsCfm   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjStsCfm)
   
   /* call primitive */
   RETVALUE(cmUnpkCmTuStsCfm(func, pst, mBuf));

} /* end of cmUnpkLzjStsCfm */



/*
 *
 *      Fun:   cmUnpkLzjStaInd
 *
 *      Desc:  This function unpacks unsolicited status indication from 
 *             PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjStaInd
(
CmTuStaInd   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjStaInd(func, pst, mBuf)
CmTuStaInd   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjStaInd)

   /* call primitive */
   RETVALUE(cmUnpkCmTuStaInd(func, pst, mBuf));

} /* end of cmUnpkLzjStaInd */



/*
 *
 *      Fun:   cmUnpkLzjTrcInd
 *
 *      Desc:  This function unpacks PSF's trace indication
 *             indication
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  lzj.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmUnpkLzjTrcInd
(
CmTuStaInd   func,              /* primtive to call */
Pst          *pst,              /* post             */
Buffer       *mBuf              /* message buffer   */
)
#else
PUBLIC S16 cmUnpkLzjTrcInd(func, pst, mBuf)
CmTuStaInd   func;              /* primtive to call */
Pst          *pst;              /* post             */
Buffer       *mBuf;             /* message buffer   */
#endif
{
   TRC2(cmUnpkLzjTrcInd)

   /* call primitive */
   RETVALUE(cmUnpkCmTuTrcInd(func, pst, mBuf));

} /* end of cmUnpkLzjTrcInd */

  
/********************************************************************30**
  
         End of file:     lzj.c@@/main/1 - Fri Dec 10 17:54:49 2004
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      jz   1. initial release.

*********************************************************************91*/
