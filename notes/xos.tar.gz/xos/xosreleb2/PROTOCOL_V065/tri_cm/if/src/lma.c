/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     map
  
     Type:     C Source file
  
     Desc:     C source code for packing and unpacking of interface structures 
  
     File:     lma.c
  
     Sid:      lma.c@@/main/2 - Fri Sep 16 02:49:06 2005
  
     Prg:      ssk
  
*********************************************************************21*/

#ifdef __cplusplus
extern "C" {
#endif

   
/* header include files (.h) */
  
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_err.h"        /* common error */
#include "stu.h"           /* tcap layer */
#include "mat.h"           /* map layer */
#include "lma.h"           /* layer management, MAP */
#include "cm5.h"

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* Common ss7 structures */
#include "stu.x"
#include "lma.x"           /* layer management, TCAP */
#include "mat.x"           /* map  layer */

#ifdef LCLMA
/* forward references */
PRIVATE S16 cmPkMaSts ARGS   ((MaMAUSts *sts,Buffer *mBuf));
PRIVATE S16 cmUnpkMaSts ARGS ((MaMAUSts *sts,Buffer *mBuf));

/*
*
*       Fun:   cmPkMaSts    
*
*       Desc:  This function packs the Statistics structure 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PRIVATE S16 cmPkMaSts 
(
MaMAUSts     *sts,              /* MAP Upper SAP statistics */
Buffer        *mBuf             /* message buffer */
)
#else
PRIVATE S16 cmPkMaSts (sts, mBuf)
MaMAUSts     *sts;              /* MAP Upper SAP statistics */
Buffer        *mBuf;            /* message buffer */
#endif
{

  TRC2(cmPkMaSts)

#if (MAP_HLR || MAP_MLC)
#if (MAP_REL98 || MAP_REL99)
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->lcsSndRoutInfoReqTx, mBuf);
#endif /* MAP_REL98 || MAP_REL99 */

   CMCHKPK(cmPkCntr, sts->anyTimeInterReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyTimeInterReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyTimeInterRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyTimeInterRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyTimeInterReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyTimeInterReqTx, mBuf);
#endif /* MAP_HLR || MAP_MLC */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
   CMCHKPK(cmPkCntr, sts->subsLocReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->subsLocReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->subsLocRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->subsLocRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->subsLocReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->subsLocReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->provSubsLocReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsLocReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsLocRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsLocRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsLocReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsLocReqTx, mBuf);
#endif
#endif /* MAP_MSC || MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */

#if MAP_REL99

#if MAP_HLR
   CMCHKPK(cmPkCntr, sts->notSubsModReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubsModReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubsModRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubsModRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubsModReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubsModReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->anyModReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyModReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyModRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyModRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyModReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyModReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->anySubsInterReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anySubsInterReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anySubsInterRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anySubsInterRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anySubsInterReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anySubsInterReqTx, mBuf);
#endif /* MAP_HLR */
   
#endif /* MAP_REL99 */

#if (MAP_HLR || MAP_GSN)

   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsNoteMsPresReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->failRptReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->failRptReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->failRptRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->failRptRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->failRptReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->failRptReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->gprsRoutInfoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsRoutInfoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsRoutInfoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsRoutInfoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsRoutInfoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsRoutInfoReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->gprsUpLocReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsUpLocReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsUpLocRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsUpLocRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsUpLocReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->gprsUpLocReqTx, mBuf);
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   CMCHKPK(cmPkCntr, sts->provSubsInfoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsInfoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsInfoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsInfoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsInfoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSubsInfoReqTx, mBuf);
#endif

#if MAP_MSC
#if MAP_REL6

   CMCHKPK(cmPkCntr, sts->relResReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->relResReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->relResRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->relResRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->relResReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->relResReqTx, mBuf);

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_MSC || MAP_HLR)

#if MAP_REL99

   CMCHKPK(cmPkCntr, sts->istCmdReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istCmdReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->istCmdRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istCmdRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->istCmdReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istCmdReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->istAlrtReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istAlrtReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->istAlrtRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istAlrtRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->istAlrtReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->istAlrtReqTx, mBuf);

#endif /* MAP_REL99 */

   CMCHKPK(cmPkCntr, sts->ssInvNotReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ssInvNotReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ssInvNotRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ssInvNotRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ssInvNotReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ssInvNotReqTx, mBuf);
#endif 
#if MAP_HLR
   CMCHKPK(cmPkCntr, sts->anyInterReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyInterReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyInterRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyInterRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyInterReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->anyInterReqTx, mBuf);
#endif
#if (MAP_MSC || MAP_GSN)
   CMCHKPK(cmPkCntr, sts->mtFwdSMReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->mtFwdSMReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->mtFwdSMRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->mtFwdSMRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->mtFwdSMReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->mtFwdSMReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->fwdSMReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdSMReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdSMRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdSMRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdSMReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdSMReqTx, mBuf);
#endif /* MAP_MSC || MAP_GSN */
#if MAP_MSC
   CMCHKPK(cmPkCntr, sts->siwfsSigModReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->siwfsSigModReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->siwfsSigModRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->siwfsSigModRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->siwfsSigModReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->siwfsSigModReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->provSiwfsNmbReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSiwfsNmbReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSiwfsNmbRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSiwfsNmbRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSiwfsNmbReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provSiwfsNmbReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndGrpCallEndSigReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->fwdGrpCallSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdGrpCallSigReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->proGrpCallReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->proGrpCallReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->proGrpCallRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->proGrpCallRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->proGrpCallSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->proGrpCallSigReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->prepGrpCallReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->prepGrpCallReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->prepGrpCallRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->prepGrpCallRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->prepGrpCallReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->prepGrpCallReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->resCallHandlReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->resCallHandlReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->resCallHandlRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->resCallHandlRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->resCallHandlReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->resCallHandlReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->notInterHoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notInterHoReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->fwdAccSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdAccSigReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->procAccSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procAccSigReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->sndEndSigRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndEndSigRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndEndSigReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndEndSigReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->perSubHoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perSubHoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->perSubHoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perSubHoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->perSubHoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perSubHoReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->perHoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perHoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->perHoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perHoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->perHoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->perHoReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->preSubHoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preSubHoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->preSubHoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preSubHoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->preSubHoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preSubHoReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->preHoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preHoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->preHoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preHoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->preHoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->preHoReqTx, mBuf);
#endif

#if MAP_VLR
   CMCHKPK(cmPkCntr, sts->sndIdReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIdReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIdRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIdRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIdReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIdReqTx, mBuf);
#endif

#if (MAP_VLR || MAP_HLR)

#if MAP_REL99

   CMCHKPK(cmPkCntr, sts->notMmEvReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notMmEvReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->notMmEvRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notMmEvRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->notMmEvReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notMmEvReqTx, mBuf);

#endif /* MAP_REL99 */

   CMCHKPK(cmPkCntr, sts->staRptReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->staRptReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->staRptRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->staRptRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->staRptReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->staRptReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->rmtUsrFreeReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->rmtUsrFreeReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->rmtUsrFreeRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->rmtUsrFreeRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->rmtUsrFreeReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->rmtUsrFreeReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->setRptStateReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->setRptStateReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->setRptStateRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->setRptStateRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->setRptStateReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->setRptStateReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->notSubPresReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->notSubPresReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->bgnSubActvReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->bgnSubActvReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->provRoamNmbReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provRoamNmbReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provRoamNmbRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provRoamNmbRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->provRoamNmbReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->provRoamNmbReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->sndIMSIReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIMSIReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIMSIRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIMSIRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIMSIReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndIMSIReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->restoreReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->restoreReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->restoreRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->restoreRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->restoreReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->restoreReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->upLocReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->upLocReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->upLocRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->upLocRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->upLocReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->upLocReqTx, mBuf);
#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN )
   CMCHKPK(cmPkCntr, sts->sndParamReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndParamReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndParamRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndParamRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndParamReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->sndParamReqTx, mBuf);
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN )

#if MAP_REL99

   CMCHKPK(cmPkCntr, sts->authFailRptReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authFailRptReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->authFailRptRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authFailRptRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->authFailRptReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authFailRptReqTx, mBuf);

#endif /* MAP_REL99 */

   CMCHKPK(cmPkCntr, sts->dactvTrReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvTrReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvTrRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvTrRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvTrReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvTrReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->actvTrReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvTrReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvTrRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvTrRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvTrReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvTrReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->resetReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->resetReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->delSubReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->delSubReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->delSubRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->delSubRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->delSubReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->delSubReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->insSubReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->insSubReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->insSubRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->insSubRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->insSubReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->insSubReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->authInfReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authInfReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->authInfRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authInfRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->authInfReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->authInfReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->purgMsReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->purgMsReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->purgMsRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->purgMsRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->purgMsReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->purgMsReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->canLocReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->canLocReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->canLocRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->canLocRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->canLocReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->canLocReqTx, mBuf);
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_MSC || MAP_HLR)

   CMCHKPK(cmPkCntr, sts->infSCReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->infSCReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->alrtSCWRsltReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->alrtSCWRsltReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->alrtSCReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->alrtSCReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->alrtSCRspRx, mBuf); 
   CMCHKPK(cmPkCntr, sts->alrtSCRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->alrtSCReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->alrtSCReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->smDelReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smDelReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->smDelRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smDelRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->smDelReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smDelReqTx, mBuf);


   CMCHKPK(cmPkCntr, sts->routInfoSMReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoSMReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoSMRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoSMRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoSMReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoSMReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->routInfoReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->routInfoReqTx, mBuf);
#endif

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   CMCHKPK(cmPkCntr, sts->chkIMEIReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->chkIMEIReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->chkIMEIRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->chkIMEIRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->chkIMEIReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->chkIMEIReqTx, mBuf);

#endif /* (MAP_MSC || MAP_VLR || MAP_GSN) */

#if (MAP_MSC || MAP_VLR)

   CMCHKPK(cmPkCntr, sts->trSubReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->trSubReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->detIMSIReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->detIMSIReqTx, mBuf);

#endif /* MAP_MSC || MAP_VLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
   CMCHKPK(cmPkCntr, sts->smRdyReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smRdyReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->smRdyRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smRdyRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->smRdyReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->smRdyReqTx, mBuf);
#endif /* (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN) */

#if (MAP_MSC || MAP_VLR || MAP_HLR)

   CMCHKPK(cmPkCntr, sts->eraseCcEntReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseCcEntReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseCcEntRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseCcEntRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseCcEntReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseCcEntReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->regCcEntReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regCcEntReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regCcEntRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regCcEntRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regCcEntReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regCcEntReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->fwdChkSSIndReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->fwdChkSSIndReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->ussNotReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussNotReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussNotRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussNotRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussNotReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussNotReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->ussReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->ussReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->procUSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->procUSSDatReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSDatReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSDatRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSDatRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSDatReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->procUSSDatReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->getPasswdReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->getPasswdReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->getPasswdRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->getPasswdRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->getPasswdReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->getPasswdReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->regPasswdReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regPasswdReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regPasswdRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regPasswdRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regPasswdReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regPasswdReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->interSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->interSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->interSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->interSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->interSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->interSSReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->dactvSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->dactvSSReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->actvSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->actvSSReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->eraseSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->eraseSSReqTx, mBuf);

   CMCHKPK(cmPkCntr, sts->regSSReRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regSSReTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regSSRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regSSRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->regSSReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->regSSReqTx, mBuf);

#endif /* MSC || VLR || HLR */

   CMCHKPK(cmPkCntr, sts->abrtRx, mBuf);
   CMCHKPK(cmPkCntr, sts->abrtTx, mBuf);
   CMCHKPK(cmPkCntr, sts->closeRx, mBuf);
   CMCHKPK(cmPkCntr, sts->closeTx, mBuf);
   CMCHKPK(cmPkCntr, sts->openRspRx, mBuf);
   CMCHKPK(cmPkCntr, sts->openRspTx, mBuf);
   CMCHKPK(cmPkCntr, sts->openReqRx, mBuf);
   CMCHKPK(cmPkCntr, sts->openReqTx, mBuf);
   CMCHKPK(cmPkSwtch,sts->swtch, mBuf);

  RETVALUE(ROK);
} /* cmPkMaSts  */
/*
*
*       Fun:   cmUnpkMaSts    
*
*       Desc:  This function unpacks the Statistics structure 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkMaSts 
(
MaMAUSts     *sts,              /* MAP Upper SAP statistics */
Buffer        *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkMaSts (sts, mBuf)
MaMAUSts     *sts;              /* MAP Upper SAP statistics */
Buffer        *mBuf;            /* message buffer */
#endif
{

   TRC2(cmUnpkMaSts)

   CMCHKUNPK(cmUnpkSwtch, &sts->swtch, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->openReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->openReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->openRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->openRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->closeTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->closeRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->abrtTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->abrtRx, mBuf);

#if (MAP_MSC || MAP_VLR || MAP_HLR)
   CMCHKUNPK(cmUnpkCntr, &sts->regSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->actvSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->interSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->interSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->interSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->interSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->interSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->interSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regPasswdReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->getPasswdReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSDatReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->procUSSReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procUSSReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->ussReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->ussNotReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussNotReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussNotRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussNotRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussNotReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ussNotReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->fwdChkSSIndReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdChkSSIndReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->regCcEntReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->eraseCcEntReRx, mBuf);

#endif /* MSC || VLR || HLR */

#if (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smRdyReRx, mBuf);
#endif /* (MAP_MSC || MAP_VLR || MAP_HLR || MAP_GSN) */


#if (MAP_MSC || MAP_VLR)
   CMCHKUNPK(cmUnpkCntr, &sts->detIMSIReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->detIMSIReqRx, mBuf);


   CMCHKUNPK(cmUnpkCntr, &sts->trSubReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->trSubReqRx, mBuf);

#endif /* MAP_MSC || MAP_VLR */

#if (MAP_MSC || MAP_VLR || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->chkIMEIReRx, mBuf);

#endif /* (MAP_MSC || MAP_VLR || MAP_GSN) */

#if (MAP_MSC || MAP_HLR)
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->routInfoSMReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->smDelReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smDelReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smDelRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smDelRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smDelReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->smDelReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCRspRx, mBuf); 
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCWRsltReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->alrtSCWRsltReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->infSCReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->infSCReqRx, mBuf);

#endif

#if (MAP_VLR || MAP_HLR || MAP_GSN )
   CMCHKUNPK(cmUnpkCntr, &sts->canLocReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->canLocReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->canLocRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->canLocRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->canLocReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->canLocReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->purgMsReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->purgMsReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->purgMsRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->purgMsRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->purgMsReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->purgMsReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->authInfReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authInfReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authInfRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authInfRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authInfReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authInfReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->insSubReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->insSubReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->insSubRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->insSubRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->insSubReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->insSubReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->delSubReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->delSubReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->delSubRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->delSubRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->delSubReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->delSubReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->resetReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resetReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->actvTrReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvTrReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvTrRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvTrRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvTrReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->actvTrReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->dactvTrReRx, mBuf);

#if MAP_REL99

   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->authFailRptReRx, mBuf);

#endif /* MAP_REL99 */

#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndParamReRx, mBuf);
#endif /* MAP_VLR || MAP_HLR || MAP_GSN */

#if (MAP_VLR || MAP_HLR)
   CMCHKUNPK(cmUnpkCntr, &sts->upLocReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->upLocReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->upLocRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->upLocRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->upLocReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->upLocReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->restoreReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->restoreReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->restoreRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->restoreRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->restoreReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->restoreReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIMSIReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provRoamNmbReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->bgnSubActvReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->bgnSubActvReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubPresReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubPresReqRx, mBuf);


   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->setRptStateReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->rmtUsrFreeReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->staRptReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->staRptReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->staRptRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->staRptRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->staRptReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->staRptReRx, mBuf);

#if MAP_REL99

   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notMmEvReRx, mBuf);

#endif /* MAP_REL99 */
   
#endif

#if MAP_VLR
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndIdReRx, mBuf);

#endif

#if MAP_MSC
   CMCHKUNPK(cmUnpkCntr, &sts->preHoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preHoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preHoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preHoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preHoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preHoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->preSubHoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->perHoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perHoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perHoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perHoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perHoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perHoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->perSubHoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->sndEndSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndEndSigReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndEndSigRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndEndSigRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procAccSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->procAccSigReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->fwdAccSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdAccSigReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->notInterHoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notInterHoReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->resCallHandlReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->prepGrpCallReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallSigReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->proGrpCallReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->fwdGrpCallSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdGrpCallSigReqRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->sndGrpCallEndSigReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSiwfsNmbReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->siwfsSigModReRx, mBuf);

#endif

#if (MAP_MSC || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->fwdSMReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->mtFwdSMReRx, mBuf);

#endif /* MAP_MSC || MAP_GSN */
#if MAP_HLR
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyInterReRx, mBuf);

#endif
#if (MAP_MSC || MAP_HLR)
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->ssInvNotReRx, mBuf);

#if MAP_REL99

   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istAlrtReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->istCmdReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istCmdReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istCmdRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istCmdRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istCmdReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->istCmdReRx, mBuf);

#endif /* MAP_REL99 */

#endif 
#if MAP_MSC
#if MAP_REL6

   CMCHKUNPK(cmUnpkCntr, &sts->relResReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->relResReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->relResRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->relResRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->relResReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->relResReRx, mBuf);

#endif /* MAP_REL6 */
#endif /* MAP_MSC */

#if (MAP_VLR || MAP_HLR || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsInfoReRx, mBuf);

#endif

#if (MAP_HLR || MAP_GSN)
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsUpLocReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsRoutInfoReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->failRptReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->failRptReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->failRptRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->failRptRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->failRptReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->failRptReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->gprsNoteMsPresReRx, mBuf);

#if MAP_REL99

#if MAP_HLR
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anySubsInterReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->anyModReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyModReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyModRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyModRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyModReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyModReRx, mBuf);
   
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->notSubsModReRx, mBuf);
#endif /* MAP_HLR */
   
#endif /* MAP_REL99 */

#if (MAP_REL98 || MAP_REL99)
#if (MAP_MSC || MAP_GSN || MAP_MLC)
#if (MAP_MSC || MAP_MLC || (MAP_REL99 && MAP_REL4 && MAP_GSN))
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->provSubsLocReRx, mBuf);

   CMCHKUNPK(cmUnpkCntr, &sts->subsLocReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->subsLocReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->subsLocRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->subsLocRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->subsLocReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->subsLocReRx, mBuf);
#endif
#endif /* MAP_MSC || MAP_MLC */
#endif /* MAP_REL98 || MAP_REL99 */
   
#endif

#if (MAP_HLR || MAP_MLC)
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->anyTimeInterReRx, mBuf);

#if (MAP_REL98 || MAP_REL99)
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoRspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoRspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoReTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &sts->lcsSndRoutInfoReRx, mBuf);
#endif /* MAP_REL98 || MAP_REL99 */
#endif /* MAP_HLR || MAP_MLC */

  RETVALUE(ROK);
}   
 




/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaStaCfm
(
Pst *pst,                   /* post structure */
MaMngmt *sta                /* solicited status */
)
#else
PUBLIC S16 cmPkLmaStaCfm(pst, sta)
Pst *pst;                   /* post structure */
MaMngmt *sta;               /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 rVal;
   
   TRC3(cmPkLmaStaCfm)
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
      RETVALUE(rVal);
   
   if (sta->cfm.status == LCM_PRIM_OK)
   {
      switch (sta->hdr.elmId.elmnt)
      {
         case STMATSAP:
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            CMCHKPKLOG(SPkU16, sta->t.ssta.s.maUSta.maVerStaTC.remIntfVer, mBuf, ELMA001, pst);
            CMCHKPKLOG(SPkU16, sta->t.ssta.s.maUSta.maVerStaTC.selfIntfVer, mBuf, ELMA002, pst);
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.maUSta.maVerStaTC.remIntfValid, mBuf, ELMA003, pst);
            CMCHKPKLOG(SPkU16, sta->t.ssta.s.maUSta.maVerStaMU.remIntfVer, mBuf, ELMA004, pst);
            CMCHKPKLOG(SPkU16, sta->t.ssta.s.maUSta.maVerStaMU.selfIntfVer, mBuf, ELMA005, pst);
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.maUSta.maVerStaMU.remIntfValid, mBuf, ELMA006, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
            CMCHKPKLOG(SPkU8, sta->t.ssta.s.maUSta.maState, mBuf, ELMA007, pst);
            CMCHKPKLOG(cmPkSwtch, sta->t.ssta.s.maUSta.swtch, mBuf, ELMA008, pst);
            break;
         case STSID:
            CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELMA009, pst);
            break;
      }
      CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELMA010, pst);
   }
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm      , mBuf,ELMA011,pst);

   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELMA012, pst);
   pst->event = MA_EVTLMASTACFM;
   (Void)SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaStaCfm */


/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaStaInd
(
Pst *pst,           /* post structure */
MaMngmt *usta       /* unsolicited status */
)
#else
PUBLIC S16 cmPkLmaStaInd(pst, usta)
Pst *pst;           /* post structure */
MaMngmt *usta;      /* unsolicited status */
#endif
{
   Buffer *mBuf;
   S16 rVal;
   
   TRC3(cmPkLmaStaInd)
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
      RETVALUE(rVal);
#if (MAP_SEC && LMAV2)
   CMCHKPKLOG(SPkU8, (U8)usta->t.usta.info.secUsta.acVer, mBuf, ELMA013, pst);
   CMCHKPKLOG(SPkU8, (U8)usta->t.usta.info.secUsta.acName, mBuf, ELMA014, pst);
   if (usta->t.usta.info.secUsta.cmpId.cmpType == LMA_ERROR_COMP)
   {
      CMCHKPKLOG(SPkU8, (U8)usta->t.usta.info.secUsta.cmpId.cmpVal.errCode, mBuf, ELMA015, pst);
   }
   else
   {
      CMCHKPKLOG(SPkU8, (U8)usta->t.usta.info.secUsta.cmpId.cmpVal.oprCode, mBuf, ELMA016, pst);
   }
   CMCHKPKLOG(SPkU8, (U8)usta->t.usta.info.secUsta.cmpId.cmpType, mBuf, ELMA017, pst);
   CMCHKPKLOG(SPkU32, usta->t.usta.info.secUsta.secSpi, mBuf, ELMA018, pst);
   CMCHKPKLOG(cmPkTknU16, &usta->t.usta.info.secUsta.plmnId.mnc, mBuf, ELMA019, pst);
   CMCHKPKLOG(cmPkTknU16, &usta->t.usta.info.secUsta.plmnId.mcc, mBuf, ELMA020, pst);
#endif /* MAP_SEC && LMAV2 */
   CMCHKPKLOG(cmPkMemoryId, &usta->t.usta.info.mem,     mBuf, ELMA021, pst);
   CMCHKPKLOG(SPkU32,       usta->t.usta.info.param,    mBuf, ELMA022, pst);
   CMCHKPKLOG(SPkU16,       usta->t.usta.info.oprCode,  mBuf, ELMA023, pst);
   CMCHKPKLOG(SPkU8,        usta->t.usta.info.state,    mBuf, ELMA024, pst);
   CMCHKPKLOG(SPkS8,        usta->t.usta.info.invokeId, mBuf, ELMA025, pst);
   CMCHKPKLOG(SPkU32,       usta->t.usta.info.dlgId,    mBuf, ELMA026, pst);
   CMCHKPKLOG(SPkU16,       usta->t.usta.info.sapId,    mBuf, ELMA027, pst);
   CMCHKPKLOG(cmPkCmAlarm,  &usta->t.usta.alarm,        mBuf, ELMA028, pst);
   CMCHKPKLOG(cmPkHeader, &usta->hdr, mBuf, ELMA029, pst); 
   
   pst->event = MA_EVTLMASTAIND;
   (Void)SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaStaInd */


/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaStsCfm
(
Pst *pst,                 /* post structure */
Action action,            /* action */
MaMngmt *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLmaStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */
Action action;            /* action */
MaMngmt *sts;             /* statistics */
#endif
{
   Buffer *mBuf;
   S16 rVal;
   
   TRC3(cmPkLmaStsCfm)

   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
      RETVALUE(rVal);

   if (sts->cfm.status == LCM_PRIM_OK)
   {
#if (MAP_SEC && LMAV2)
      switch (sts->hdr.elmId.elmnt)
      {
         case STMATSAP:
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbFbAtmpt, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbTvpChkFail, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbExtractFail, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbProtFail, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbInvUnsecOpenReq, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbInvSecOpenReq, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbInvSpiAtmpt, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbInvSrcPlmn, mBuf);
            CMCHKPK(cmPkCntr, sts->t.sts.secSts.nmbInvDstPlmn, mBuf);
            CMCHKPKLOG(cmPkMaSts, &sts->t.sts.secSts.secSapSts,mBuf, ELMA030, pst);
            CMCHKPKLOG(cmPkSwtch, sts->t.sts.secSts.secSapSts.swtch, mBuf, ELMA031, pst);
            break;
      }
#endif /* (MAP_SEC && LMAV2) */

      switch (sts->hdr.elmId.elmnt)
      {
         case STMATSAP:
            CMCHKPKLOG(cmPkMaSts, &sts->t.sts.maMAUSts, mBuf, ELMA032, pst);
            CMCHKPKLOG(cmPkSwtch, sts->t.sts.maMAUSts.swtch, mBuf, ELMA033, pst);
            break;
      }
      CMCHKPKLOG(cmPkDuration, &sts->t.sts.dura, mBuf, ELMA034, pst); 
      CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELMA035, pst); 
   }
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm       , mBuf,ELMA036,pst);

   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELMA037, pst);
   CMCHKPKLOG(cmPkAction, action, mBuf, ELMA038, pst); 

   pst->event = MA_EVTLMASTSCFM;
   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLmaStsCfm */


/*
*
*       Fun:   Pack Trace Indication
*
*       Desc:  This function is used to pack the trace indication
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaTrcInd
(
Pst *pst,                   /* post structure */
MaMngmt *trc                /* trace */
)
#else
PUBLIC S16 cmPkLmaTrcInd(pst, trc)
Pst *pst;                   /* post structure */
MaMngmt *trc;               /* trace */
#endif
{
   U32 i;                 /* counter for counting the U16 value */
   S16 rVal;
   Buffer *mBuf;          /* message buffer */

   TRC3(cmPkLmaTrcInd)

#if (ERRCLASS & ERRCLS_DEBUG)
      if (trc->t.trc.len > LMA_MAX_TRC_LEN)
      {
         RETVALUE(RFAILED);
      }
#endif
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
      RETVALUE(rVal);
   }
   CMCHKPKLOG(cmPkHeader, &trc->hdr, mBuf, ELMA039, pst); 
   CMCHKPKLOG(cmPkDateTime, &trc->t.trc.dt, mBuf, ELMA040, pst); 
   CMCHKPKLOG(SPkU16, trc->t.trc.evnt, mBuf, ELMA041, pst);
   for (i = 0; i < (U32) (trc->t.trc.len); i++)  
   {
      CMCHKPKLOG(SPkU8, trc->t.trc.evntParm[i], mBuf, ELMA042, pst);
   }

   CMCHKPKLOG(SPkU16, trc->t.trc.len, mBuf, ELMA043, pst);
   pst->event = MA_EVTLMATRCIND;
   (Void)SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaTrcInd */



/*
*
*       Fun:   Pack Configuration Request
*
*       Desc:  This function is used to pack the configuration request
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaCfgReq
(
Pst *pst,                     /* post structure */
MaMngmt *cfg                  /* configuration */
)
#else
PUBLIC S16 cmPkLmaCfgReq(pst, cfg)
Pst *pst;                     /* post structure */
MaMngmt *cfg;                 /* configuration */
#endif
{
   Buffer *mBuf;
   S16    rVal;
   S16    i;
   S16    j;

   TRC2(cmPkLmaCfgReq)

   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
     RETVALUE(RFAILED);
   }

   switch (cfg->hdr.elmId.elmnt)
   {
      case STMATGEN:
#ifdef MA_SEG
         CMCHKPKLOG(SPkU32,cfg->t.cfg.s.maGen.sigFrameSz,mBuf,ELMA044,pst);
#endif /* MA_SEG */
         
#if (MAP_SEC && LMAV2)
/*lma_c_001.main_2: Added to support Security Feature as configurable */
#ifdef MAP_SEC_RECFG
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maGen.secGenCfg.mapSecFlg,
         mBuf,ELMA045,pst);
#endif /* MAP_SEC_RECFG */
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maGen.secGenCfg.secPlmnsOnly, mBuf, ELMA045, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.secGenCfg.maxpp, mBuf, ELMA046, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.secGenCfg.maxPlmn, mBuf, ELMA047, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.secGenCfg.tvPeriod, mBuf, ELMA048, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.secGenCfg.tvpWinSz, mBuf, ELMA049, pst);
         i = cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp-1;
         if (i >= LMA_MAX_SEC_COMPS)
         {
            i = LMA_MAX_SEC_COMPS-1;
         }
         for (; i>=0; i--)
         {
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].cmpCmb, mBuf, ELMA050, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].oprCode, mBuf, ELMA051, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].acVer, mBuf, ELMA052, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maGen.secGenCfg.opCmp[i].acName, mBuf, ELMA053, pst);
         }
         CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maGen.secGenCfg.nmbOpCmp, mBuf, ELMA054, pst);
         CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maGen.secGenCfg.rxFbInd, mBuf, ELMA055, pst);
         CMCHKPKLOG(cmPkTknU16, &cfg->t.cfg.s.maGen.secGenCfg.plmnId.mnc, mBuf, ELMA056, pst);
         CMCHKPKLOG(cmPkTknU16, &cfg->t.cfg.s.maGen.secGenCfg.plmnId.mcc, mBuf, ELMA057, pst);
#endif /* (MAP_SEC && LMAV2) */
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.range, mBuf, ELMA058, pst);
         CMCHKPKLOG(cmPkPst, &cfg->t.cfg.s.maGen.smPst, mBuf, ELMA059, pst);
         CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maGen.timeRes, mBuf, ELMA060, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.nmbOpr, mBuf, ELMA061, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.nmbDlgs, mBuf, ELMA062, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maGen.nmbMAUSaps, mBuf, ELMA063, pst);
         break;
      case STMATSAP:
#if (MAP_SEC && LMAV2)
         i=cfg->t.cfg.s.maMAU.secSapCfg.neId.length-1; 
         if (i >= LMA_NEID_SIZE)
         {
            i=LMA_NEID_SIZE-1; 
         }
         for (; i>=0; i--)
         {
            CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.secSapCfg.neId.strg[i], mBuf, ELMA064, pst);
         }

         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.secSapCfg.neId.length, mBuf, ELMA065, pst);
#endif /* (MAP_SEC && LMAV2) */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer, cfg->t.cfg.s.maMAU.intfVerTC, mBuf, 
                    ELMA066, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.remIntfValidTC, mBuf, 
                    ELMA067, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.pClass, mBuf, ELMA068, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.retOpt, mBuf, ELMA069, pst);
         /* Pack the tIntTmr Structure */
         CMCHKPKLOG(cmPkTmrCfg,&cfg->t.cfg.s.maMAU.tIntTmr,mBuf,ELMA070,pst);
/* lma_c_001.main_2: Addition, Added to support Dlg Hash Size element */
#ifdef MAP_NSRP
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maMAU.dlgHshSize, mBuf, ERRLMA, pst);
#endif /* MAP_NSRP */
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maMAU.range, mBuf, ELMA071, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maMAU.stDlgId, mBuf, ELMA072, pst);
         CMCHKPKLOG(cmPkSpId, cfg->t.cfg.s.maMAU.spIdTC, mBuf, ELMA073, pst);
         CMCHKPKLOG(cmPkRoute, cfg->t.cfg.s.maMAU.routeTC, mBuf, ELMA074, pst);
         CMCHKPKLOG(cmPkPrior, cfg->t.cfg.s.maMAU.priorTC, mBuf, ELMA075, pst);
         CMCHKPKLOG(cmPkInst, cfg->t.cfg.s.maMAU.instTC, mBuf, ELMA076, pst);
         CMCHKPKLOG(cmPkEnt, cfg->t.cfg.s.maMAU.entTC, mBuf, ELMA077, pst);
         CMCHKPKLOG(cmPkProcId, cfg->t.cfg.s.maMAU.procIdTC, mBuf, ELMA078, pst);
         CMCHKPKLOG(cmPkMemoryId, &cfg->t.cfg.s.maMAU.memTC, mBuf, ELMA079, pst);
         CMCHKPKLOG(cmPkSelector, cfg->t.cfg.s.maMAU.selectorTC, mBuf, ELMA080, pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer, cfg->t.cfg.s.maMAU.intfVerMU, mBuf, ELMA081, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.remIntfValidMU, mBuf, ELMA082, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         for (i=MA_MAX_OPR-1; i>=0; i--)
         {
           if (cfg->t.cfg.s.maMAU.apnCfg[i].pres == TRUE)
           {
#ifdef ZJ
             CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].upd, mBuf, ELMA083, pst);
#endif
             CMCHKPKLOG(cmPkTmrCfg, &cfg->t.cfg.s.maMAU.apnCfg[i].oprTmr, mBuf, ELMA084, pst);
             for (j=cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len -1; j>=0; j--)
             {
               CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].altApn.string[j], mBuf, ELMA085, pst);
             }
             CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maMAU.apnCfg[i].altApn.len, mBuf, ELMA086, pst);

             for (j=cfg->t.cfg.s.maMAU.apnCfg[i].apn.len -1; j>=0; j--)
             {
               CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].apn.string[j], mBuf, ELMA087, pst);
             }
             CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maMAU.apnCfg[i].apn.len, mBuf, ELMA088, pst);

             CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].maVer, mBuf, ELMA089, pst);
             CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].oprClass, mBuf, ELMA090, pst);
             CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].oprCode, mBuf, ELMA091, pst);
           }
           CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.apnCfg[i].pres, mBuf, ELMA092, pst);
         }
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maMAU.maxDlg, mBuf, ELMA093, pst);
         CMCHKPKLOG(cmPkTmrCfg, &cfg->t.cfg.s.maMAU.maGrdTmr, mBuf, ELMA094, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.maPrior, mBuf, ELMA095, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maMAU.ssn, mBuf, ELMA096, pst);
         CMCHKPKLOG(cmPkRoute, cfg->t.cfg.s.maMAU.routeMU, mBuf, ELMA097, pst);
         CMCHKPKLOG(cmPkPrior, cfg->t.cfg.s.maMAU.priorMU, mBuf, ELMA098, pst);
         CMCHKPKLOG(cmPkMemoryId, &cfg->t.cfg.s.maMAU.memMU, mBuf, ELMA099, pst);
         CMCHKPKLOG(cmPkSelector, cfg->t.cfg.s.maMAU.selectorMU, mBuf, ELMA100, pst);
         CMCHKPKLOG(cmPkSwtch   , cfg->t.cfg.s.maMAU.swtch, mBuf, ELMA101, pst);
         break;
#if (MAP_SEC && LMAV2)
      case STMATPG:
         i = cfg->t.cfg.s.maSecPg.nmbPgTupleEnt-1;
         if (i >= LMA_MAX_PG_TUPLES)
         {
            i= LMA_MAX_PG_TUPLES - 1;
         }
         for (; i>=0; i--)
         {
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecPg.pg[i].pl, mBuf, ELMA102, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecPg.pg[i].acVer, mBuf, ELMA103, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecPg.pg[i].oprCode, mBuf, ELMA104, pst);
         }
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecPg.nmbPgTupleEnt, mBuf, ELMA105, pst);
         CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maSecPg.pgi, mBuf, ELMA106, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecPg.ac, mBuf, ELMA107, pst);

         break;

      case STMATPP:
         CMCHKPKLOG(SPkU16, cfg->t.cfg.s.maSecPp.ppi, mBuf, ELMA108, pst);
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecPp.ppri, mBuf, ELMA109, pst);
         CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maSecPp.ppid, mBuf, ELMA110, pst);

         break;

      case STMATSA:
         i = cfg->t.cfg.s.maSecSa.nmbPlmns-1;
         if (i >= LMA_MAX_SA_PLMNS)
         {
            i = LMA_MAX_SA_PLMNS-1;
         }
         for (; i>=0; i--)
         {
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecSa.sa[i].txFbInd, mBuf, ELMA111, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecSa.sa[i].mea, mBuf, ELMA112, pst);
            j=cfg->t.cfg.s.maSecSa.sa[i].mek.mekLen-1;
            if (j >= LMA_SEC_MEK_SIZE)
            {
               j = LMA_SEC_MEK_SIZE-1;
            }
            for (; j>=0; j--)
            {
               CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].mek.mek[j], mBuf, ELMA113, pst);
            }
            CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].mek.mekLen, mBuf, ELMA114, pst);
            CMCHKPKLOG(SPkU8, (U8)cfg->t.cfg.s.maSecSa.sa[i].mia, mBuf, ELMA115, pst);
            j=cfg->t.cfg.s.maSecSa.sa[i].mik.mikLen-1;
            if (j >= LMA_SEC_MIK_SIZE)
            {
               j = LMA_SEC_MIK_SIZE-1;
            }
            for (; j>=0; j--)
            {
               CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].mik.mik[j], mBuf, ELMA116, pst);
            }
            CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].mik.mikLen, mBuf, ELMA117, pst);
            CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].ppri, mBuf, ELMA118, pst);
            CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maSecSa.sa[i].ppid, mBuf, ELMA119, pst);
            CMCHKPKLOG(SPkU32, cfg->t.cfg.s.maSecSa.sa[i].spi, mBuf, ELMA120, pst);
            CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.sa[i].mapSec, mBuf, ELMA121, pst);

            CMCHKPKLOG(cmPkTknU32, &cfg->t.cfg.s.maSecSa.sa[i].plmn_164.ndc, mBuf, ELMA122, pst);
            CMCHKPKLOG(cmPkTknU16, &cfg->t.cfg.s.maSecSa.sa[i].plmn_164.cc, mBuf, ELMA123, pst);

            CMCHKPKLOG(cmPkTknU16, &cfg->t.cfg.s.maSecSa.sa[i].plmnId.mnc, mBuf, ELMA124, pst);
            CMCHKPKLOG(cmPkTknU16, &cfg->t.cfg.s.maSecSa.sa[i].plmnId.mcc, mBuf, ELMA125, pst);
         }
         CMCHKPKLOG(SPkU8, cfg->t.cfg.s.maSecSa.nmbPlmns, mBuf, ELMA126, pst);

         break;

#endif /* MAP_SEC && LMAV2 */
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
                 __LINE__, (ErrCls) ERRCLS_DEBUG, (ErrVal)ELMA127, 
                 (ErrVal)cfg->hdr.elmId.elmnt, "smPkLmaCfgReq () Failed"); 
#endif
         RETVALUE(RFAILED);
         break;
   }
   CMCHKPKLOG(cmPkHeader, &cfg->hdr, mBuf, ELMA128, pst);
   pst->event = (Event)MA_EVTLMACFGREQ; /* event */
   /* Put version information in Pst structure */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LMAIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaCfgReq */

/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaCntrlReq
(
Pst *pst,                     /* post structure */
MaMngmt *cntrl                /* control */
)
#else
PUBLIC S16 cmPkLmaCntrlReq(pst, cntrl)
Pst *pst;                     /* post structure */
MaMngmt *cntrl;               /* control */
#endif
{
   Buffer *mBuf;
   S16    rVal;

   TRC3(cmPkLmaCntrlReq)

   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
     RETVALUE(RFAILED);
   }
#ifdef LMAV3
   CMCHKPKLOG(SPkU32,        cntrl->t.cntrl.nmbCb,       mBuf, ELMA129, pst);
   CMCHKPKLOG(SPkU8,         cntrl->t.cntrl.cbType,      mBuf, ELMA130, pst);
   CMCHKPKLOG(cmPkTicks,     cntrl->t.cntrl.expTime,     mBuf, ELMA131, pst);
#endif /* LMAV3 */
   switch (cntrl->hdr.elmId.elmnt)
   {
#if (MAP_SEC && LMAV2)
      case STMATSA:
         CMCHKPKLOG(SPkU8, (U8 )cntrl->t.cntrl.par.plmn.type, mBuf, ELMA132, pst);
         CMCHKPKLOG(SPkU32, cntrl->t.cntrl.par.plmn.spi, mBuf, ELMA133, pst);
         CMCHKPKLOG(cmPkTknU16, &cntrl->t.cntrl.par.plmn.id.mnc, mBuf, ELMA134, pst);
         CMCHKPKLOG(cmPkTknU16, &cntrl->t.cntrl.par.plmn.id.mcc, mBuf, ELMA135, pst);
         break;
#endif
      case STGRSUSAP:
      case STGRSPSAP:
         CMCHKPKLOG(cmPkProcId, cntrl->t.cntrl.par.dstProcId, mBuf, ELMA136, pst);
         break;
   }
#ifdef DEBUGP
   if (cntrl->t.cntrl.subAction == SADBG)
   {
      CMCHKPKLOG(SPkU32,cntrl->t.cntrl.s.dbg.dbgMask,mBuf,ELMA137,pst);
   }
#endif 
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.subAction, mBuf, ELMA138, pst);
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.action, mBuf, ELMA139, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt, mBuf, ELMA140, pst);
   CMCHKPKLOG(cmPkHeader, &cntrl->hdr, mBuf, ELMA141, pst);

   pst->event = (Event)MA_EVTLMACNTRLREQ; /* event */
   /* Put version information in Pst structure for rolling upgrade compliance */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LMAIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaCntrlReq */

/*
*
*       Fun:   Unpack Configuration Request
*
*       Desc:  This function is used to Unpack Configuration Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaCfgReq
(
LmaCfgReq func,    /* Primitvie to call */
Pst *pst,          /* post structure */
Buffer *mBuf 
)
#else
PUBLIC S16 cmUnpkLmaCfgReq(func,pst, mBuf)
LmaCfgReq func;    /* Primitvie to call */
Pst *pst;          /* post structure */
Buffer *mBuf;
#endif
{
   MaMngmt cfg;
   U16     j;
   U16     i;
#if (MAP_SEC && LMAV2)
   U8      temp;   /* temp variable to save enum value */
#endif

   TRC3(cmUnpkLmaCfgReq)

   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ELMA142, pst);
   switch (cfg.hdr.elmId.elmnt)
   {
      case STMATSAP:
         CMCHKUNPKLOG(cmUnpkSwtch    , &cfg.t.cfg.s.maMAU.swtch, mBuf, ELMA143, pst);
         CMCHKUNPKLOG(cmUnpkSelector, &cfg.t.cfg.s.maMAU.selectorMU, mBuf, ELMA144, pst);
         CMCHKUNPKLOG(cmUnpkMemoryId, &cfg.t.cfg.s.maMAU.memMU, mBuf, ELMA145, pst); 
         CMCHKUNPKLOG(cmUnpkPrior , &cfg.t.cfg.s.maMAU.priorMU, mBuf, ELMA146, pst); 
         CMCHKUNPKLOG(cmUnpkRoute , &cfg.t.cfg.s.maMAU.routeMU, mBuf, ELMA147, pst); 
         CMCHKUNPKLOG(SUnpkU8 , &cfg.t.cfg.s.maMAU.ssn, mBuf, ELMA148, pst); 
         CMCHKUNPKLOG(SUnpkU8 , &cfg.t.cfg.s.maMAU.maPrior, mBuf, ELMA149, pst); 
         CMCHKUNPKLOG(cmUnpkTmrCfg , &cfg.t.cfg.s.maMAU.maGrdTmr, mBuf, ELMA150, pst); 
         CMCHKUNPKLOG(SUnpkU32 , &cfg.t.cfg.s.maMAU.maxDlg, mBuf, ELMA151, pst); 
         for (i=0; i< MA_MAX_OPR; i++)
         {
           CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].pres, mBuf, ELMA152, pst);
           if (cfg.t.cfg.s.maMAU.apnCfg[i].pres == TRUE)
           {
             CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].oprCode, mBuf, ELMA153, pst);
             CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].oprClass, mBuf, ELMA154, pst);
             CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].maVer, mBuf, ELMA155, pst);
             CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.maMAU.apnCfg[i].apn.len, mBuf, ELMA156, pst);
             for (j=0; j<cfg.t.cfg.s.maMAU.apnCfg[i].apn.len; j++)
             {
               CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].apn.string[j], mBuf, ELMA157, pst);
             }
             CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.maMAU.apnCfg[i].altApn.len, mBuf, ELMA158, pst);
             for (j=0; j<cfg.t.cfg.s.maMAU.apnCfg[i].altApn.len; j++)
             {
               CMCHKUNPKLOG( SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].altApn.string[j], mBuf, ELMA159, pst);
             }
           
             CMCHKUNPKLOG(cmUnpkTmrCfg, &cfg.t.cfg.s.maMAU.apnCfg[i].oprTmr, mBuf, ELMA160, pst); 
#ifdef ZJ
             CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.apnCfg[i].upd, mBuf, ELMA161, pst);
#endif
           }  
         }

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.remIntfValidMU, mBuf, ELMA162, pst);
         CMCHKUNPKLOG(cmUnpkIntfVer, &cfg.t.cfg.s.maMAU.intfVerMU, mBuf, ELMA163, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */ 

         CMCHKUNPKLOG(cmUnpkSelector, &cfg.t.cfg.s.maMAU.selectorTC, mBuf, ELMA164, pst);
         CMCHKUNPKLOG(cmUnpkMemoryId, &cfg.t.cfg.s.maMAU.memTC, mBuf, ELMA165, pst); 
         CMCHKUNPKLOG(cmUnpkProcId , &cfg.t.cfg.s.maMAU.procIdTC, mBuf, ELMA166, pst);
         CMCHKUNPKLOG(cmUnpkEnt    , &cfg.t.cfg.s.maMAU.entTC, mBuf, ELMA167, pst); 
         CMCHKUNPKLOG(cmUnpkInst  , &cfg.t.cfg.s.maMAU.instTC, mBuf, ELMA168, pst); 
         CMCHKUNPKLOG(cmUnpkPrior , &cfg.t.cfg.s.maMAU.priorTC, mBuf, ELMA169, pst); 
         CMCHKUNPKLOG(cmUnpkRoute , &cfg.t.cfg.s.maMAU.routeTC, mBuf, ELMA170, pst); 
         CMCHKUNPKLOG(cmUnpkSpId , &cfg.t.cfg.s.maMAU.spIdTC, mBuf, ELMA171, pst); 
         CMCHKUNPKLOG(SUnpkU32 , &cfg.t.cfg.s.maMAU.stDlgId, mBuf, ELMA172, pst); 
         CMCHKUNPKLOG(SUnpkU32 , &cfg.t.cfg.s.maMAU.range, mBuf, ELMA173, pst); 

/* lma_c_001.main_2: Addition, Added to support Dlg Hash Size element */
#ifdef MAP_NSRP
         CMCHKUNPKLOG(SUnpkU32 , &cfg.t.cfg.s.maMAU.dlgHshSize, mBuf, ERRLMA, pst);
#endif /* MAP_NSRP */

         /* Unpack the tIntTmr structure */
         CMCHKUNPKLOG(cmUnpkTmrCfg, &cfg.t.cfg.s.maMAU.tIntTmr, mBuf, ELMA174, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.retOpt, mBuf, ELMA175, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.pClass, mBuf, ELMA176, pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.remIntfValidTC, mBuf, ELMA177, pst);
         CMCHKUNPKLOG(cmUnpkIntfVer, &cfg.t.cfg.s.maMAU.intfVerTC, mBuf, ELMA178, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */ 
#if (MAP_SEC && LMAV2)
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.secSapCfg.neId.length, mBuf, ELMA179, pst);
         if (cfg.t.cfg.s.maMAU.secSapCfg.neId.length > LMA_NEID_SIZE)
         {
            for (i=0; i < LMA_NEID_SIZE; i++)
            {
               CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[i], mBuf, ELMA180, pst);
            }
         }
         else
         {
         for (i=0; i < cfg.t.cfg.s.maMAU.secSapCfg.neId.length; i++)
         {
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maMAU.secSapCfg.neId.strg[i], mBuf, ELMA181, pst);
         }
         }
#endif /* (MAP_SEC && LMAV2) */

         break;
      case STMATGEN:
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.maGen.nmbMAUSaps, mBuf, ELMA182, pst);
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.maGen.nmbDlgs, mBuf, ELMA183, pst); 
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.maGen.nmbOpr, mBuf, ELMA184, pst); 
         CMCHKUNPKLOG( SUnpkU16, &cfg.t.cfg.s.maGen.timeRes, mBuf, ELMA185, pst); 
         CMCHKUNPKLOG(cmUnpkPst, &cfg.t.cfg.s.maGen.smPst, mBuf, ELMA186, pst); 
         CMCHKUNPKLOG( SUnpkU32, &cfg.t.cfg.s.maGen.range, mBuf, ELMA187, pst);
#if (MAP_SEC && LMAV2)
         CMCHKUNPKLOG(cmUnpkTknU16, &cfg.t.cfg.s.maGen.secGenCfg.plmnId.mcc, mBuf, ELMA188, pst);
         CMCHKUNPKLOG(cmUnpkTknU16, &cfg.t.cfg.s.maGen.secGenCfg.plmnId.mnc, mBuf, ELMA189, pst);
         temp = 0;
         CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA190, pst);
         cfg.t.cfg.s.maGen.secGenCfg.rxFbInd = (LmaFallBackInd)temp;

         CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.maGen.secGenCfg.nmbOpCmp, mBuf, ELMA191, pst);
         for (i=0; (i< cfg.t.cfg.s.maGen.secGenCfg.nmbOpCmp) &&
                         (i<LMA_MAX_SEC_COMPS); i++)
         {
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maGen.secGenCfg.opCmp[i].acName, mBuf, ELMA192, pst);
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA193, pst);
            cfg.t.cfg.s.maGen.secGenCfg.opCmp[i].acVer = (LmaAcVer)temp;
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maGen.secGenCfg.opCmp[i].oprCode, mBuf, ELMA194, pst);
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA195, pst);
            cfg.t.cfg.s.maGen.secGenCfg.opCmp[i].cmpCmb = (LmaCmpTypeCmb)temp;
         }
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maGen.secGenCfg.tvpWinSz, mBuf, ELMA196, pst);
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maGen.secGenCfg.tvPeriod, mBuf, ELMA197, pst);
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maGen.secGenCfg.maxPlmn, mBuf, ELMA198, pst);
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maGen.secGenCfg.maxpp, mBuf, ELMA199, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maGen.secGenCfg.secPlmnsOnly, mBuf, ELMA200, pst);
        
/*lma_c_001.main_2: Added to support Security Feature as configurable */
#ifdef MAP_SEC_RECFG
        CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maGen.secGenCfg.mapSecFlg, mBuf,
        ELMA200, pst);
#endif /* MAP_SEC_RECFG */
#endif /* (MAP_SEC && LMAV2) */
#ifdef MA_SEG
         CMCHKUNPKLOG(SUnpkU32,&cfg.t.cfg.s.maGen.sigFrameSz,mBuf,ELMA201,pst);
#endif /* MA_SEG */

         break;
#if (MAP_SEC && LMAV2)
      case STMATPG:
         temp = 0;
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecPg.ac, mBuf, ELMA202, pst);
         CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.maSecPg.pgi, mBuf, ELMA203, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecPg.nmbPgTupleEnt, mBuf, ELMA204, pst);
         for (i= 0; (i < cfg.t.cfg.s.maSecPg.nmbPgTupleEnt) &&
                         (i<LMA_MAX_PG_TUPLES); i++)
         {
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecPg.pg[i].oprCode, mBuf, ELMA205, pst);
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA206, pst);
            cfg.t.cfg.s.maSecPg.pg[i].acVer = (LmaAcVer)temp;
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA207, pst);
            cfg.t.cfg.s.maSecPg.pg[i].pl = (LmaSecPl)temp;
         }
         break;

      case STMATPP:
         CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maSecPp.ppid, mBuf, ELMA208, pst);
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecPp.ppri, mBuf, ELMA209, pst);
         CMCHKUNPKLOG(SUnpkU16, &cfg.t.cfg.s.maSecPp.ppi, mBuf, ELMA210, pst);
         break;

      case STMATSA:
         temp = 0;
         CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.nmbPlmns, mBuf, ELMA211, pst);
         for (i=0; (i<cfg.t.cfg.s.maSecSa.nmbPlmns) && 
                         (i<LMA_MAX_SA_PLMNS); i++)
         {
            CMCHKUNPKLOG(cmUnpkTknU16, &cfg.t.cfg.s.maSecSa.sa[i].plmnId.mcc, mBuf, ELMA212, pst);
            CMCHKUNPKLOG(cmUnpkTknU16, &cfg.t.cfg.s.maSecSa.sa[i].plmnId.mnc, mBuf, ELMA213, pst);
            CMCHKUNPKLOG(cmUnpkTknU16, &cfg.t.cfg.s.maSecSa.sa[i].plmn_164.cc, mBuf, ELMA214, pst);
            CMCHKUNPKLOG(cmUnpkTknU32, &cfg.t.cfg.s.maSecSa.sa[i].plmn_164.ndc, mBuf, ELMA215, pst);
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].mapSec, mBuf, ELMA216, pst);
            CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maSecSa.sa[i].spi, mBuf, ELMA217, pst);
            CMCHKUNPKLOG(SUnpkU32, &cfg.t.cfg.s.maSecSa.sa[i].ppid, mBuf, ELMA218, pst);
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].ppri, mBuf, ELMA219, pst);
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].mik.mikLen, mBuf, ELMA220, pst);
            for (j=0; (j<cfg.t.cfg.s.maSecSa.sa[i].mik.mikLen) &&
                            (j<LMA_SEC_MIK_SIZE); j++)
            {
               CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].mik.mik[j], mBuf, ELMA221, pst);
            }
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA222, pst);
            cfg.t.cfg.s.maSecSa.sa[i].mia = (LmaSecMia)temp;
            CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].mek.mekLen, mBuf, ELMA223, pst);
            for (j=0; (j<cfg.t.cfg.s.maSecSa.sa[i].mek.mekLen) &&
                            (j<LMA_SEC_MEK_SIZE); j++)
            {
               CMCHKUNPKLOG(SUnpkU8, &cfg.t.cfg.s.maSecSa.sa[i].mek.mek[j], mBuf, ELMA224, pst);
            }
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA225, pst);
            cfg.t.cfg.s.maSecSa.sa[i].mea = (LmaSecMea)temp;
            CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA226, pst);
            cfg.t.cfg.s.maSecSa.sa[i].txFbInd = (LmaFallBackInd)temp;
         }
         break;

#endif /* MAP_SEC && LMAV2 */

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__, (ErrCls) ERRCLS_DEBUG, ELMA227, (ErrVal)cfg.hdr.elmId.elmnt,
                   "cmUnpkLmaCfgReq () Failed");
#endif
         break;
   }
   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cfg));
} /* end of cmUnpkLmaCfgReq */


/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaStaReq
(
Pst *pst,                     /* post structure */
MaMngmt *sta                  /* solicited status */
)
#else
PUBLIC S16 cmPkLmaStaReq(pst, sta)
Pst *pst;                     /* post structure */
MaMngmt *sta;                 /* solicited status */
#endif
{
   Buffer *mBuf;
   S16    rVal;

   TRC3(cmPkLmaStaReq)
 
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
     RETVALUE(RFAILED);
   }
   switch (sta->hdr.elmId.elmnt)
   {
      case STMATSAP:
      case STSID:
         /* don't need to pack in a StaReq */
         break;
      default:
        RETVALUE(RFAILED);
   }
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELMA228, pst);
   pst->event = (Event)MA_EVTLMASTAREQ; /* event */
   /* Put version information in Pst structure for rolling upgrade compliance */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LMAIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLmaStaReq */
  

/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLmaStsReq
(
Pst *pst,                   /* post structure */
Action action,              /* action */
MaMngmt *sts                /* statistics */
)
#else
PUBLIC S16 cmPkLmaStsReq(pst, action, sts)
Pst *pst;                   /* post structure */
Action action;              /* action */
MaMngmt *sts;               /* statistics */
#endif
{
   Buffer *mBuf;
   S16    rVal;

   TRC3(cmPkLmaStsReq)

   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
   {
     RETVALUE(RFAILED);
   }
   switch (sts->hdr.elmId.elmnt)
   {
      case STMATSAP:
         /* don't need to pack anything in a StsReq */
         break;
      default:
         RETVALUE(RFAILED);
         break;
   }
   /* date time and duration also need not be packed */
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELMA229, pst);
   CMCHKPKLOG(cmPkAction, action, mBuf, ELMA230, pst);
   pst->event = (Event)MA_EVTLMASTSREQ; /* event */
   /* Put version information in Pst structure for rolling upgrade compliance */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LMAIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkMiLmaStsReq */
/*
*
*       Fun:   cmUnpkLmaStaReq
*
*       Desc:  This function is used to Unpack Status Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaStaReq
(
LmaStaReq func,    /* Primitvie to call */
Pst *pst,          /* post structure */
Buffer *mBuf 
)
#else
PUBLIC S16 cmUnpkLmaStaReq(func,pst, mBuf)
LmaStaReq func;    /* Primitvie to call */
Pst *pst;          /* post structure */
Buffer *mBuf;
#endif
{
   MaMngmt sta;
   
   TRC3(cmUnpkLmaStaReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELMA231, pst);
   switch (sta.hdr.elmId.elmnt)
   {
      case STMATSAP:
      case STSID:
         /* don't need to unpack anything in a StaReq */
         break;
   }
   (Void)SPutMsg(mBuf);
   RETVALUE((*func)(pst, &sta));
} /* end of cmUnpkLmaStaReq */

/*
*
*       Fun:   cmUnpkLmaStsReq    
*
*       Desc:  This function is used to unpack the layer manager statistics
*              request 
*
*       Ret:   ROK 
*
*       Notes: None 
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaStsReq 
(
LmaStsReq func,      /* Primitvie to call */
Pst     *pst,        /* Post structure */
Buffer  *mBuf        /* message Buffer */
)
#else
PUBLIC S16 cmUnpkLmaStsReq (func,pst, mBuf)
LmaStsReq func;      /* Primitvie to call */
Pst     *pst;        /* Post structure */
Buffer  *mBuf;       /* message Buffer */
#endif
{
  Action action;
  MaMngmt sts;
   
  TRC2(cmUnpkLmaStsReq)

  CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ELMA232, pst);
  CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELMA233, pst); 
  switch (sts.hdr.elmId.elmnt)
  {
      case STMATSAP:
         /* don't need to unpack anything in a Sts req */
         break;
  }
  (Void)SPutMsg(mBuf);

  RETVALUE((*func)(pst, action, &sts));
} /* cmUnpkLmaStsReq  */

/*
*
*       Fun:   Unpack Control Request
*
*       Desc:  This function is used to Unpack Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaCntrlReq
(
LmaCntrlReq  func, /* Primitvie to call */
Pst *pst,          /* post structure */
Buffer *mBuf       /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaCntrlReq(func,pst, mBuf)
LmaCntrlReq  func; /* Primitvie to call */
Pst *pst;          /* post structure */
Buffer *mBuf;      /* message buffer */
#endif
{
   MaMngmt cntrl;
#if (MAP_SEC && LMAV2)
   U8      temp;   /* temp value to save enum value */
#endif
   
   TRC3(cmUnpkLmaCntrlReq)
   CMCHKUNPKLOG(cmUnpkHeader, &cntrl.hdr, mBuf, ELMA234, pst); 
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ELMA235, pst); 
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.action, mBuf, ELMA236, pst); 
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.subAction, mBuf, ELMA237, pst); 
#ifdef DEBUGP
   if (cntrl.t.cntrl.subAction == SADBG)
   {
      CMCHKUNPKLOG(SUnpkU32,&cntrl.t.cntrl.s.dbg.dbgMask,mBuf,ELMA238,pst);
   }
#endif 

   switch (cntrl.hdr.elmId.elmnt)
   {
#if (MAP_SEC && LMAV2)
      case STMATSA:
         CMCHKUNPKLOG(cmUnpkTknU16, &cntrl.t.cntrl.par.plmn.id.mcc, mBuf, ELMA239, pst);
         CMCHKUNPKLOG(cmUnpkTknU16, &cntrl.t.cntrl.par.plmn.id.mnc, mBuf, ELMA240, pst);
         CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.par.plmn.spi, mBuf, ELMA241, pst);
         temp = 0;
         CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA242, pst);
         cntrl.t.cntrl.par.plmn.type = (LmaPlmnDelType)temp;
         break;
#endif
      case STGRSUSAP:
      case STGRSPSAP:
         CMCHKUNPKLOG(cmUnpkProcId, &cntrl.t.cntrl.par.dstProcId, mBuf, ELMA243, pst);
         break;
   }
#ifdef LMAV3
   CMCHKUNPKLOG(cmUnpkTicks, &cntrl.t.cntrl.expTime,     mBuf, ELMA244, pst);
   CMCHKUNPKLOG(SUnpkU8,     &cntrl.t.cntrl.cbType,      mBuf, ELMA245, pst);
   CMCHKUNPKLOG(SUnpkU32,    &cntrl.t.cntrl.nmbCb,       mBuf, ELMA246, pst);
#endif /* LMAV3 */
   (Void)SPutMsg(mBuf);
   RETVALUE((*func)(pst, &cntrl));
} /* end of cmUnpkLmaCntrlReq */



  
/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function is used to unpack the status request
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaStaCfm
(
LmaStaCfm func,        /* Primitive to call */
Pst *pst,              /* post structure */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaStaCfm(func,pst, mBuf)
LmaStaCfm func;        /* Primitive to call */
Pst *pst;              /* post structure */
Buffer *mBuf;          /* message buffer */
#endif
{
   MaMngmt sta;
   Txt     ptNmb[32];

   TRC3(cmUnpkLmaStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELMA247, pst); 
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm , mBuf,ELMA248,pst);
   if (sta.cfm.status == LCM_PRIM_OK)
   {
      CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELMA249, pst);
      switch (sta.hdr.elmId.elmnt)
      {
         case STSID:
         {
            sta.t.ssta.s.sysId.ptNmb = ptNmb;
            CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId, mBuf, ELMA250, pst);
            break;
         }  

         case STMATSAP:
            CMCHKUNPKLOG(cmUnpkSwtch, &sta.t.ssta.s.maUSta.swtch, mBuf, ELMA251, pst);
            CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.maUSta.maState, mBuf, ELMA252, pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.maUSta.maVerStaMU.remIntfValid, mBuf, ELMA253, pst);
            CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.maUSta.maVerStaMU.selfIntfVer, mBuf, ELMA254, pst);
            CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.maUSta.maVerStaMU.remIntfVer, mBuf, ELMA255, pst);
            CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.maUSta.maVerStaTC.remIntfValid, mBuf, ELMA256, pst);
            CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.maUSta.maVerStaTC.selfIntfVer, mBuf, ELMA257, pst);
            CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.maUSta.maVerStaTC.remIntfVer, mBuf, ELMA258, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
            break;
      }
   }
   SPutMsg(mBuf);
   (*func)(pst, &sta);
   RETVALUE(ROK);
} /* end of cmUnpkLmaStaCfm */

  
/*
*
*       Fun:   Unpack Statistics Confirm
*
*       Desc:  This function is used to unpack the statistics confirm
*              primitive to MAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaStsCfm
(
LmaStsCfm func,        /* Primitive to call */
Pst *pst,              /* post structure */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaStsCfm(func,pst, mBuf)
LmaStsCfm func;        /* Primitive to call */
Pst *pst;              /* post structure */
Buffer *mBuf;          /* message buffer */
#endif
{
   Action action;
   MaMngmt sts;
   TRC3(cmUnpkLmaStsCfm)
   CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ELMA259, pst);
   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELMA260, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm       , mBuf,ELMA261,pst);
   if (sts.cfm.status == LCM_PRIM_OK)
   {
      CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELMA262, pst);
      CMCHKUNPKLOG(cmUnpkDuration, &sts.t.sts.dura, mBuf, ELMA263, pst);
      /* statistics */
      switch (sts.hdr.elmId.elmnt)
      {
         case STMATSAP:
            /* get switch type first */
            CMCHKUNPKLOG(cmUnpkSwtch, &sts.t.sts.maMAUSts.swtch, mBuf, ELMA264, pst);
            CMCHKUNPKLOG(cmUnpkMaSts, &sts.t.sts.maMAUSts,mBuf, ELMA265, pst);
            break;
      }
#if (MAP_SEC && LMAV2)
      switch (sts.hdr.elmId.elmnt)
      {
         case STMATSAP:
            /* get switch type first */
            CMCHKUNPKLOG(cmUnpkSwtch, &sts.t.sts.secSts.secSapSts.swtch, mBuf, ELMA266, pst);
            CMCHKUNPKLOG(cmUnpkMaSts, &sts.t.sts.secSts.secSapSts,mBuf, ELMA267, pst);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbInvDstPlmn, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbInvSrcPlmn, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbInvSpiAtmpt, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbInvSecOpenReq, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbInvUnsecOpenReq, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbProtFail, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbExtractFail, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbTvpChkFail, mBuf);
            CMCHKUNPK(cmUnpkCntr, &sts.t.sts.secSts.nmbFbAtmpt, mBuf);
            break;
      }
#endif /* (MAP_SEC && LMAV2) */
   }
   SPutMsg(mBuf);
   (*func)(pst, action, &sts); 
   RETVALUE(ROK);
} /* end of cmUnpkLmaStsCfm */

  
/*
*
*       Fun:   Unpack Status Indication
*
*       Desc:  This function is used to unpack the unsolicited status 
*              primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaStaInd
(
LmaStaInd func,        /* Primitive to call */
Pst *pst,              /* post structure */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaStaInd(func,pst, mBuf)
LmaStaInd func;        /* Primitive to call */
Pst *pst;              /* post structure */
Buffer *mBuf;          /* message buffer */
#endif
{
   MaMngmt usta;
#if (MAP_SEC && LMAV2)
   U8      temp;       /* temp value to save enum value */
#endif

   TRC3(cmUnpkLmaStaInd)
   CMCHKUNPKLOG(cmUnpkHeader, &usta.hdr, mBuf, ELMA268, pst);
   CMCHKUNPKLOG(cmUnpkCmAlarm, &usta.t.usta.alarm,      mBuf, ELMA269, pst);
   CMCHKUNPKLOG(SUnpkU16,   &usta.t.usta.info.sapId,   mBuf, ELMA270, pst);
   CMCHKUNPKLOG(SUnpkU32,   &usta.t.usta.info.dlgId,   mBuf, ELMA271, pst);
   CMCHKUNPKLOG(SUnpkS8,    &usta.t.usta.info.invokeId,mBuf, ELMA272, pst);
   CMCHKUNPKLOG(SUnpkU8,    &usta.t.usta.info.state,   mBuf, ELMA273, pst);
   CMCHKUNPKLOG(SUnpkU16,   &usta.t.usta.info.oprCode, mBuf, ELMA274, pst);
   CMCHKUNPKLOG(SUnpkU32,   &usta.t.usta.info.param,   mBuf, ELMA275, pst);
   CMCHKUNPKLOG(cmUnpkMemoryId,&usta.t.usta.info.mem,   mBuf, ELMA276, pst);
#if (MAP_SEC && LMAV2)
   CMCHKUNPKLOG(cmUnpkTknU16, &usta.t.usta.info.secUsta.plmnId.mcc, mBuf, ELMA277, pst);
   CMCHKUNPKLOG(cmUnpkTknU16, &usta.t.usta.info.secUsta.plmnId.mnc, mBuf, ELMA278, pst);
   CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.info.secUsta.secSpi, mBuf, ELMA279, pst);
   temp = 0;
   CMCHKUNPKLOG(SUnpkU8, (U8*)&temp, mBuf, ELMA280, pst);
   usta.t.usta.info.secUsta.cmpId.cmpType = (LmaCmpType)temp;
   if (usta.t.usta.info.secUsta.cmpId.cmpType == LMA_ERROR_COMP)
   {
      CMCHKUNPKLOG(SUnpkU8, (U8*)&usta.t.usta.info.secUsta.cmpId.cmpVal.errCode, mBuf, ELMA281, pst);
   }
   else
   {
      CMCHKUNPKLOG(SUnpkU8, (U8*)&usta.t.usta.info.secUsta.cmpId.cmpVal.oprCode, mBuf, ELMA282, pst);
   }
   CMCHKUNPKLOG(SUnpkU8, (U8*)&usta.t.usta.info.secUsta.acName, mBuf, ELMA283, pst);
   CMCHKUNPKLOG(SUnpkU8, &temp, mBuf, ELMA284, pst);
   usta.t.usta.info.secUsta.acVer = (LmaAcVer)temp;
#endif /* MAP_SEC && LMAV2 */
   SPutMsg(mBuf);
   (*func)(pst, &usta); 
   RETVALUE(ROK);
} /* end of cmUnpkLmaStaInd */

/*
*
*       Fun:   Unpack Trace Indication
*
*       Desc:  This function is used to unpack the trace indication 
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLmaTrcInd
(
LmaTrcInd   func,      /* Primitive to call */
Pst *pst,              /* post structure */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaTrcInd(func,pst, mBuf)
LmaTrcInd   func;      /* Primitive to call */
Pst *pst;              /* post structure */
Buffer *mBuf;          /* message buffer */
#endif
{
   MaMngmt trc;
   S32 i; /* counter for counting the U16 value */

   TRC3(cmUnpkLmaTrcInd)

   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.len, mBuf, ELMA285, pst);
   for (i = (trc.t.trc.len -1); i >= 0; i--)  
   {
      CMCHKUNPKLOG(SUnpkU8, &trc.t.trc.evntParm[i], mBuf, ELMA286, pst);
   }
   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.evnt, mBuf, ELMA287, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &trc.t.trc.dt, mBuf, ELMA288, pst);
   CMCHKUNPKLOG(cmUnpkHeader, &trc.hdr, mBuf, ELMA289, pst);
   SPutMsg(mBuf);
   (*func)(pst, &trc); 
   RETVALUE(ROK);
} /* end of cmUnpkLmaTrcInd */

/*
*
*       Fun:   Pack Configuration Confirm
*
*       Desc:  This function is used to pack the Configuration Confirm
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lma.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmaCfgCfm
(
Pst       *pst,           /* post structure */
MaMngmt   *cfm            /* confirm structure */
)
#else
PUBLIC S16 cmPkLmaCfgCfm(pst, cfm)
Pst       *pst;           /* post structure */
MaMngmt   *cfm;           /* confirm structure */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 rVal;
 
   TRC3(cmPkLmaCfgCfm)
 
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
      RETVALUE(rVal);
 
   CMCHKPKLOG( cmPkCmStatus, &cfm->cfm, mBuf, ELMA290, pst);
   CMCHKPKLOG( cmPkHeader,   &cfm->hdr, mBuf, ELMA291, pst);
 
   pst->event = MA_EVTLMACFGCFM;
 
   (Void)SPstTsk(pst, mBuf);
 
   RETVALUE(ROK);
} /* end of cmPkLmaCfgCfm */
 

/*
*
*       Fun:   Unpack config confirmation
*
*       Desc:  This function is used to unpack the  config confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmaCfgCfm
(
LmaCfgReq  func,      /* Layer function to be called back */
Pst       *pst,
Buffer    *mBuf       /* message buffer */ 
)
#else
PUBLIC S16 cmUnpkLmaCfgCfm(func, pst, mBuf)
LmaCfgReq  func;      /* Layer function to be called back */
Pst       *pst;
Buffer    *mBuf;      /* message buffer */
#endif
{
   MaMngmt   cfm;
 
   TRC3(cmUnpkLmaCfgCfm)
 
   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELMA292, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELMA293, pst);
 
   SPutMsg(mBuf);
 
   RETVALUE((*func)(pst, &cfm));
} /* end of cmUnpkLmaCfgCfm */
 

/*
*
*       Fun:   Pack Control Confirm
*
*       Desc:  This function is used to pack the Control Confirm
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lma.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmaCntrlCfm
(
Pst       *pst,           /* post structure */
MaMngmt   *cfm            /* confirm structure */
)
#else
PUBLIC S16 cmPkLmaCntrlCfm(pst, cfm)
Pst       *pst;           /* post structure */
MaMngmt   *cfm;           /* confirm structure */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16     rVal;      
 
   TRC3(cmPkLmaCntrlCfm)
 
   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
      RETVALUE(rVal);
 
   CMCHKPKLOG( cmPkCmStatus, &cfm->cfm, mBuf, ELMA294, pst);
   CMCHKPKLOG( cmPkHeader,   &cfm->hdr, mBuf, ELMA295, pst);
 
   pst->event = MA_EVTLMACNTRLCFM;
 
   (Void)SPstTsk(pst, mBuf);
 
   RETVALUE(ROK);
} /* end of cmPkLmaCntrlCfm */
 

/*
 
*
*       Fun:   Unpack control confirmation
*
*       Desc:  This function is used to unpack the  control confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lma.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmaCntrlCfm
(
LmaCfgReq  func,      /* Layer function to be called back */
Pst       *pst,
Buffer    *mBuf       /* message buffer */
)
#else
PUBLIC S16 cmUnpkLmaCntrlCfm(func, pst, mBuf)
LmaCfgReq  func;      /* Layer function to be called back */
Pst       *pst;
Buffer    *mBuf;      /* message buffer */
#endif
{
   MaMngmt   cfm;
 
   TRC3(cmUnpkLmaCntrlCfm)
 
   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELMA296, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELMA297, pst);
 
   SPutMsg(mBuf);
 
   RETVALUE((*func)(pst, &cfm));
} /* end of cmUnpkLmaCntrlCfm */
 
#endif /* LCLMA */

#ifdef __cplusplus
}
#endif

   
/********************************************************************30**

         End of file:     lma.c@@/main/2 - Fri Sep 16 02:49:06 2005

*********************************************************************31*/

   
/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ssk  1. initial release.
  
1.2          ---      ssk  1. Phase 2+ gpr release .

1.3          ---      ssk  1. Status Ind Pk/Unpk related change.

             ---      ssk  2. retOpt field packing/unpacking routines
                              are added. 

             ---      jz   3. pClass field packing/unpacking routines
                              are added. 

1.7          ---      jz   1. Added packing and unpacking for group sap 
                              parameter in control request.

/main/3      ---      jie  1. update for MAP 1.5 release.

             ---      jie  1. Rolling Upgrade compliance

             ---      yz   2. Remove REL99 flag for sndEndSigRspTx/Rx.

             ---      jie  1. Change for MAP REL4 support without the MAPsec 
                              feature.

/main/4      ---      jie  1. update for MAP 1.6 release.

             ---      yz   1. Addition of MAP segmentation feature from 1.5.

             ---      jie  2. Change for 2002/09 rel99/rel4 release.

/main/5      ---      jie  1. update for MAP 1.7 release.

/main/6      ---      cp   1. Removed STU2 flag
/main/2      ---      rbabu 1. update for MAP 2.3 release.
/main/2     lma_c_001.main_2 dm 1. Added to support Dlg Hash size paramater.
                                 2. Added to support Security Feature parameter.
*********************************************************************91*/
