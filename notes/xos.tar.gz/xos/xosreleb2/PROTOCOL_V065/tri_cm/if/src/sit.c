/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP interface

    Type:     C source file

    Desc:     Functions required for packing and unpacking of ISUP
              Events and their members.

    File:     sit.c

    Sid:      sit.c@@/main/15 - Wed Jul 25 13:21:21 2001
 
    Prg:      dm

*********************************************************************21*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm_hash.h"       /* hash-list header */
#include "cm5.h"           /* common - hashing */
#include "cm_ss7.h"        /* common - SS7 */
#include "sit.h"           /* isup layer */
#include "lsi.h"           /* layer manager */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_hash.x"       /* hash-list structure */
#include "cm5.x"           /* common - hashing */
#include "cm_ss7.x"        /* common - SS7 */
#include "lsi.x"           /* layer manager */
#include "sit.x"           /* isup layer */


/* local defines */

/* local typedefs */
  
/* local externs */

/* forward references */

  
/*
*     support functions
*/
#ifdef LCSIT

#ifdef __cplusplus
extern "C" {
#endif

/* packing functions for ISUP information elements */
PRIVATE S16 siPkAccTrnspt    ARGS((SiAccTrnspt *pAccTrnspt,Buffer *mBuf));
PRIVATE S16 siPkAutoCongLvl  ARGS((SiAutoCongLvl *pAutoCongLvl, Buffer *mBuf));
PRIVATE S16 siPkSubNum       ARGS((SiSubNum *pSubNum,Buffer *mBuf));
PRIVATE S16 siPkBckCalInd    ARGS((SiBckCalInd *pBckCalInd,Buffer *mBuf));
PRIVATE S16 siPkCallRef      ARGS((SiCallRef *pCallRef,Buffer *mBuf));
PRIVATE S16 siPkCalModInd    ARGS((SiCalModInd *pCalModInd,Buffer *mBuf));
PRIVATE S16 siPkCauseDgn     ARGS((SiCauseDgn *pCauseDgn,Buffer *mBuf));
PRIVATE S16 siPkCgPtyCat     ARGS((SiCgPtyCat *pCgPtyCat,Buffer *mBuf));
PRIVATE S16 siPkCirStateInd  ARGS((SiCirStateInd *pCirStateInd, Buffer *mBuf));
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siPkConnectedNum2 ARGS((SiConnectedNum2 *pConnectedNum2, 
                                   Buffer *mBuf));
#endif
PRIVATE S16 siPkConnectedNum ARGS((SiConnectedNum *pConnectedNum, 
                                   Buffer *mBuf));
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkGrpNum ARGS((SiOutgTrkGrpNum *pGrpNum, Buffer *mBuf));
#endif
#endif
PRIVATE S16 siPkConnReq      ARGS((SiConnReq *pConnReq,Buffer *mBuf));
PRIVATE S16 siPkContInd      ARGS((SiContInd *pContInd,Buffer *mBuf));
PRIVATE S16 siPkCugIntCode   ARGS((SiCugIntCode *pCugIntCode,Buffer *mBuf));
PRIVATE S16 siPkEvntInfo     ARGS((SiEvntInfo *pEvntInfo,Buffer *mBuf));
PRIVATE S16 siPkFacInd       ARGS((SiFacInd *pFacInd,Buffer *mBuf));
PRIVATE S16 siPkFwdCallInd   ARGS((SiFwdCallInd *pFwdCallInd,Buffer *mBuf));
PRIVATE S16 siPkInfoInd      ARGS((SiInfoInd *pInfoInd,Buffer *mBuf));
PRIVATE S16 siPkInfoReqInd   ARGS((SiInfoReqInd *pInfoReqInd,Buffer *mBuf));
PRIVATE S16 siPkNatConInd    ARGS((SiNatConInd *pNatConInd,Buffer *mBuf));
PRIVATE S16 siPkOpFwdCalInd  ARGS((SiOpFwdCalInd *pOpFwdCalInd, Buffer *mBuf));
PRIVATE S16 siPkOptBckCalInd ARGS((SiOptBckCalInd *pOptBckCalInd, 
                                   Buffer *mBuf));
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
PRIVATE S16 siPkOptBckCalIndQ ARGS((SiOptBckCalIndQ *pOptBckCalIndQ,
                                    Buffer *mBuf));
#endif
PRIVATE S16 siPkOrigCdNum    ARGS((SiOrigCdNum *pOrigCdNum,Buffer *mBuf));
PRIVATE S16 siPkPassAlng     ARGS((SiPassAlng *pPassAlng,Buffer *mBuf));
PRIVATE S16 siPkRangStat     ARGS((SiRangStat *pRangStat, Buffer *mBuf));
PRIVATE S16 siPkRedirgNum    ARGS((SiRedirNum *pRedirgNum,Buffer *mBuf));
PRIVATE S16 siPkRedirInfo    ARGS((SiRedirInfo *pRedirInfo,Buffer *mBuf));
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkRedirNum     ARGS((SiRedirNum *pRedirNum,Buffer *mBuf));
#endif
PRIVATE S16 siPkSigPointCode ARGS((SiSigPointCode *pSigPointCode,
                                   Buffer *mBuf));
PRIVATE S16 siPkSusResInd    ARGS((SiSusResInd *pSusResInd,Buffer *mBuf));
PRIVATE S16 siPkTranNetSel   ARGS((SiTranNetSel *pTranNetSel,Buffer *mBuf));

/* si037.220 : Addeded Transit network selection fields for ANSI */
#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkTranNetSel1   ARGS((SiTranNetSel1 *pTranNetSel1, Buffer *mBuf));
#endif
#endif

PRIVATE S16 siPkTxMedReq     ARGS((SiTxMedReq *pTxMedReq,Buffer *mBuf));
PRIVATE S16 siPkUsr2UsrInd   ARGS((SiUsr2UsrInd *pUsr2UsrInd,Buffer *mBuf));
PRIVATE S16 siPkUsr2UsrInfo  ARGS((SiUsr2UsrInfo *pUsr2UsrInfo, Buffer *mBuf));
PRIVATE S16 siPkSiUsrServInfo ARGS((SiUsrServInfo *pUsrServInfo,Buffer *mBuf));
PRIVATE S16 siPkSiUsrTSrvInfo ARGS((SiUsrTSrvInfo *pUsrTSrvInfo,Buffer *mBuf));
PRIVATE S16 siPkServiceAct   ARGS((SiServiceAct *pServiceAct,Buffer *mBuf));
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkGenAddr      ARGS((SiGenAddr *pGenAddr,Buffer *mBuf));
#endif /* SS7_ANS92 || SS7_ANS95 || SS7_BELL */
#if (SS7_BELL || SS7_ANS95)
PRIVATE S16 siPkGenName      ARGS((SiGenName *pGenName,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_BELL || SS7_ANS95 || SS7_INDIA)
PRIVATE S16 siPkHopCounter     ARGS((SiHopCounter *pHopCounter,Buffer *mBuf));
#endif
#if (SS7_BELL || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siPkRedirCap    ARGS((SiRedirCap *pRedirCap,Buffer *mBuf));
PRIVATE S16 siPkRedirCntr    ARGS((SiRedirCntr *pRedirCntr,Buffer *mBuf));
#endif /* SS7_BELL */
PRIVATE S16 siPkSiGenDigits  ARGS((SiGenDigits *pGenDigits,Buffer *mBuf));
PRIVATE S16 siPkSiGenNum     ARGS((SiGenNum *pGenNum,Buffer *mBuf));
PRIVATE S16 siPkCirGrpSupMTypInd ARGS((SiCirGrpSupMTypInd *pCgsmti, 
                                       Buffer *mBuf));
PRIVATE S16 siPkSiPropDly    ARGS((SiPropDly *pPropDly,Buffer *mBuf));
PRIVATE S16 siPkSiNetSpecFacil ARGS((SiNetSpecFacil *pNetFac,Buffer *mBuf));
PRIVATE S16 siPkSiCllDiverInfo ARGS((SiCllDiverInfo *pCllDivr,
                                     Buffer *mBuf));
PRIVATE S16 siPkSiRedirRestr ARGS((SiRedirRestr *pRedirRstr,Buffer *mBuf));
PRIVATE S16 siPkSiMcidReqInd ARGS((SiMcidReqInd *pMcidReq,Buffer *mBuf));
PRIVATE S16 siPkSiMcidRspInd ARGS((SiMcidRspInd *pMcidRsp,Buffer *mBuf));
PRIVATE S16 siPkSiRemotOper  ARGS((SiRemotOper *pRemotOper,Buffer *mBuf));
PRIVATE S16 siPkSiAccDelInfo ARGS((SiAccDelInfo *pAccDelInfo, Buffer *mBuf));
PRIVATE S16 siPkSiEchoCtl    ARGS((SiEchoCtl *pEchoCtl,Buffer *mBuf));
PRIVATE S16 siPkSiParmCompInfo ARGS((SiParmCompInfo *pParmCom, Buffer *mBuf));
PRIVATE S16 siPkSiMsgCompInfo  ARGS((SiMsgCompInfo *pMsgCom,Buffer *mBuf));
PRIVATE S16 siPkSiMlppPrec     ARGS((SiMlppPrec *pMlppPrec,Buffer *mBuf));
PRIVATE S16 siPkNotifInd       ARGS((SiNotifInd *pNotifInd,Buffer *mBuf));
#if SS7_SINGTEL
PRIVATE S16 siPkCllChrgeInfo  ARGS((SiCllChrgeInfo *pCllChrgeInfo, Buffer *mBuf));
PRIVATE S16 siPkChrgeRateInfo ARGS((SiChrgeRateInfo *pChrgeRateInfo,
                                    Buffer *mBuf));
PRIVATE S16 siPkTrnkOff       ARGS((TrnkOff *pTrnkOff,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
PRIVATE S16 siPkCllChrgeBnd  ARGS((SiChargeBand *pCllChrgeBnd, Buffer
*mBuf));
#endif

/* si034.220: Addition - added CHINA variant */
#ifdef SS7_CHINA
PRIVATE S16 siPkCallRefA    ARGS((SiCallRefA *pCallRefA,Buffer *mBuf));
PRIVATE S16 siPkConnReqA    ARGS((SiConnReqA *pConnReqA,Buffer *mBuf));
PRIVATE S16 siPkSigPointCodeA ARGS((SiSigPointCodeA *pSigPointCodeA,
                                    Buffer *mBuf));
PRIVATE S16 siPkChargeInform ARGS((SiChargeInform *pChargeInform, Buffer
*mBuf));
#endif /* if SS7_CHINA */

#if SS7_Q767IT
PRIVATE S16 siPkBackVadInd  ARGS((SiBackVadInd *pBackVadInd,Buffer *mBuf));
PRIVATE S16 siPkFwdVadInd   ARGS((SiFwdVadInd *pFwdVadInd,Buffer *mBuf));
#endif
 
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkCallRefA    ARGS((SiCallRefA *pCallRefA,Buffer *mBuf));
PRIVATE S16 siPkConnReqA    ARGS((SiConnReqA *pConnReqA,Buffer *mBuf));
PRIVATE S16 siPkOrigLineInf ARGS((SiOrigLineInf *pOrigLineInf, Buffer *mBuf));
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_ITU2000)
PRIVATE S16 siPkChargeNum   ARGS((SiChargeNum *pChargeNum,Buffer *mBuf));
#endif
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
PRIVATE S16 siPkOpFwdCalIndQ ARGS((SiOpFwdCalIndQ *pOpFwdCalIndQ, 
                                   Buffer *mBuf));
#endif
#if SS7_ANS88
PRIVATE S16 siPkOpFwdCalIndA  ARGS((SiOpFwdCalIndA *pOpFwdCalIndA, 
                                    Buffer *mBuf));
PRIVATE S16 siPkCugIntCodeA   ARGS((SiCugIntCodeA *pCugIntCodeA, Buffer *mBuf));
PRIVATE S16 siPkInfoIndA      ARGS((SiInfoIndA *pInfoIndA,Buffer *mBuf));
PRIVATE S16 siPkInfoReqIndA   ARGS((SiInfoReqIndA *pInfoReqIndA, Buffer *mBuf));
PRIVATE S16 siPkSigPointCodeA ARGS((SiSigPointCodeA *pSigPointCodeA,
                                    Buffer *mBuf));
PRIVATE S16 siPkIndex         ARGS((SiIndex *pIndex,Buffer *mBuf));
PRIVATE S16 siPkFacInfInd     ARGS((SiFacInfInd *pFacInfInd,Buffer *mBuf));
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siPkServiceCode   ARGS((SiServiceCode *pServiceCode,Buffer *mBuf));
PRIVATE S16 siPkBusinessGrp   ARGS((SiBusinessGrp *pBusinessGrp, Buffer *mBuf));
PRIVATE S16 siPkCarrierId     ARGS((SiCarrierId *pCarrierId,Buffer *mBuf));
PRIVATE S16 siPkCarrierSelInf ARGS((SiCarrierSelInf *pCarrierSelInf, 
                                    Buffer *mBuf));
PRIVATE S16 siPkEgress        ARGS((SiEgress *pEgress,Buffer *mBuf));
PRIVATE S16 siPkJurisInf      ARGS((SiJurisInf *pJurisInf,Buffer *mBuf));
PRIVATE S16 siPkNetTransport  ARGS((SiNetTransport *pNetTransport, 
                                    Buffer *mBuf));
PRIVATE S16 siPkSpecProcReq   ARGS((SiSpecProcReq *pSpecProcReq, Buffer *mBuf));
PRIVATE S16 siPkTransReq      ARGS((SiTransReq *pTransReq,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
PRIVATE S16 siPkLoopPrvntInd  ARGS((SiLoopPrvntInd *pLoop,Buffer *mBuf));
PRIVATE S16 siPkCalTrnsfrRef  ARGS((SiCallTRef *ptRef,Buffer *mBuf));
#endif
#if (SS7_ETSI || SS7_FTZ)
PRIVATE S16 siPkFreePhParam   ARGS((SiFreePhInd *pFreePhInd, Buffer *mBuf));
PRIVATE S16 siPkCCBSParam     ARGS((SiCcbsParam *pCCBSParam,Buffer *mBuf));
#endif
#if SS7_FTZ
PRIVATE S16 siPkNaPaFF      ARGS((SiNaPaFF *pNaPaFF,Buffer *mBuf,U8 evntType));
PRIVATE S16 siPkNaPaSPV     ARGS((SiNaPaSPV *pNaPaSPV,Buffer *mBuf));
PRIVATE S16 siPkNaPaFE      ARGS((SiNaPaFE *pNaPaFE,Buffer *mBuf));
PRIVATE S16 siPkNaPaSSP     ARGS((SiNaPaSSP *pNaPaSSP,Buffer *mBuf));
PRIVATE S16 siPkNaPaCdPNO   ARGS((SiNaPaCdPNO *pNaPaCdPNO,Buffer *mBuf));
PRIVATE S16 siPkNaPaExTID   ARGS((SiNaPaExTID *pNaPaExTID,Buffer *mBuf));
PRIVATE S16 siPkNaPaCHGI    ARGS((SiNaPaCHGI *pNaPaCHGI,Buffer *mBuf));
PRIVATE S16 siPkFacIndInfor ARGS((SiFacIndInfor *pFacIndInfor, Buffer *mBuf));
PRIVATE S16 siPkNaPaTTZ     ARGS((SiNaPaTTZ *pNaPaTTZ,Buffer *mBuf));
PRIVATE S16 siPkNaPaUKK     ARGS((SiNaPaUKK *pNaPaUKK, Buffer *mBuf));
#endif /* SS7_FTZ */
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
PRIVATE S16 siPkNaPaChgPID  ARGS((SiNaPaChgPID *pNaPaChgPID,Buffer *mBuf));
#endif
#if SS7_RUSSIA
PRIVATE S16 siPkBillZoneNum ARGS((SiBillZoneNum *pBillZoneNum, Buffer *mBuf));
#endif /* SS7_RUSSIA */

#if SS7_NTT
PRIVATE S16 siPkMsgAreaInfo ARGS((SiMsgAreaInfo  *pMsgAreaInfo,
   Buffer *mBuf));
PRIVATE S16 siPkSubsNumber ARGS((SiSubsNumber  *pSubsNumber,
   Buffer *mBuf));
PRIVATE S16 siPkReasProhibCllngNo ARGS((SiReasProhibCllngNo  *pReasProhibCllngNo,
   Buffer *mBuf));
PRIVATE S16 siPkSupplUserType ARGS((SiSupplUserType  *pSupplUserType,
   Buffer *mBuf));
PRIVATE S16 siPkCarrierInfoTrans ARGS((SiCarrierInfoTrans  *pCarrierInfoTrans,
   Buffer *mBuf));
PRIVATE S16 siPkNwFuncType ARGS((SiNwFuncType  *pNwFuncType,
   Buffer *mBuf));
PRIVATE S16 siPkChrgInfoType ARGS((SiChrgInfoType *pchrgInfoType,
   Buffer *mBuf));
PRIVATE S16 siPkChrgInfo ARGS((SiChrgInfo *pchrgInfo, 
      SiChrgInfoType *pchrgInfoType, Buffer *mBuf));
PRIVATE S16 siPkChrgInfoDelay ARGS((SiChrgInfoDelay *pchrgInfoDelay, 
   Buffer *mBuf));
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
PRIVATE S16 siPkCirAsgnMap ARGS((SiCirAsgnMap *pkParam,
   Buffer *mBuf));
#endif
#if SS7_ANS95
PRIVATE S16 siPkOptrServicesInfo ARGS((SiOptrServicesInfo *pkParam,
   Buffer *mBuf));
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
PRIVATE S16 siPkBackGVNS ARGS((SiBackGVNS *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkForwardGVNS ARGS((SiForwardGVNS *pkParam,
   Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
PRIVATE S16 siPkCallDivTrtInd ARGS((SiCallDivTrtInd *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkCallOfferTrtInd ARGS((SiCallOfferTrtInd *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkCallInNmb ARGS((SiCallInNmb *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkCcss ARGS((SiCcss *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkCollCallReq ARGS((SiCollCallReq *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkConfTrtInd ARGS((SiConfTrtInd *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkCorrelationId ARGS((SiCorrelationId *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkDisplayInfo ARGS((SiDisplayInfo *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkNetMgmtControls ARGS((SiNetMgmtControls *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkScfId ARGS((SiScfId *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkUidActionInd ARGS((SiUidActionInd *pkParam,
   Buffer *mBuf));
PRIVATE S16 siPkUidCapInd ARGS((SiUidCapInd *pkParam,
   Buffer *mBuf));
#endif

/* sit_c_003.main_15: Addition - added Indian variant */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
PRIVATE S16 siPkAppTransParam ARGS((SiAppTransParam *pkParam,
   Buffer *mBuf));
#endif
/* sit_c_005.main_15: Addition - SS7_ITU2000 variant */
#if SS7_ITU2000
PRIVATE S16 siPkCalgGeoLoc ARGS((SiCalgGeoLoc *pkParam,Buffer *mBuf));
PRIVATE S16 siPkCCNRPosInd ARGS((SiCCNRPosInd *pkParam,Buffer *mBuf));
PRIVATE S16 siPkNetRoutNum ARGS((SiNetRoutNum *pkParam,Buffer *mBuf));
PRIVATE S16 siPkPivotCap ARGS((SiPivotCap *pkParam,Buffer *mBuf));
PRIVATE S16 siPkQOnRelCap ARGS((SiQOnRelCap *pkParam,Buffer *mBuf));
PRIVATE S16 siPkPivotStat ARGS((SiPivotStat *pkParam,Buffer *mBuf));
PRIVATE S16 siPkRedirStat ARGS((SiRedirStat *pkParam,Buffer *mBuf));
PRIVATE S16 siPkPivotCntr ARGS((SiPivotCntr *pkParam,Buffer *mBuf));
PRIVATE S16 siPkPivotRtgInd ARGS((SiPivotRtgInd *pkParam,Buffer *mBuf));
PRIVATE S16 siPkPivotRtgBkInfo ARGS((SiPivotRtgBkInfo *pkParam,Buffer *mBuf));
PRIVATE S16 siPkNumPortFwdInfo ARGS((SiNumPortFwdInfo *pkParam,
   Buffer *mBuf));
#endif

/* unpacking functions for ISUP information elements */
PRIVATE S16 siUnpkAccTrnspt   ARGS((SiAccTrnspt *pAccTrnspt,Buffer *mBuf));
PRIVATE S16 siUnpkAutoCongLvl ARGS((SiAutoCongLvl *pAutoCongLvl,
                                    Buffer *mBuf));
PRIVATE S16 siUnpkSubNum      ARGS((SiSubNum *pSubNum,Buffer *mBuf));
PRIVATE S16 siUnpkBckCalInd   ARGS((SiBckCalInd *pBckCalInd,Buffer *mBuf));
PRIVATE S16 siUnpkCallRef     ARGS((SiCallRef *pCallRef,Buffer *mBuf));
PRIVATE S16 siUnpkCalModInd   ARGS((SiCalModInd *pCalModInd,Buffer *mBuf));
PRIVATE S16 siUnpkCauseDgn    ARGS((SiCauseDgn *pCauseDgn,Buffer *mBuf));
PRIVATE S16 siUnpkCgPtyCat    ARGS((SiCgPtyCat *pCgPtyCat,Buffer *mBuf));
PRIVATE S16 siUnpkCirStateInd ARGS((SiCirStateInd *pCirStateInd,
                                    Buffer *mBuf));
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siUnpkGrpNum ARGS((SiOutgTrkGrpNum *pGrpNum, Buffer *mBuf));
#endif
#endif
PRIVATE S16 siUnpkConnectedNum ARGS((SiConnectedNum *pConnectedNum,
                                     Buffer *mBuf));
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkConnectedNum2 ARGS((SiConnectedNum2 *pConnectedNum2,
        Buffer *mBuf));
#endif
PRIVATE S16 siUnpkConnReq     ARGS((SiConnReq *pConnReq,Buffer *mBuf));
PRIVATE S16 siUnpkContInd     ARGS((SiContInd *pContInd,Buffer *mBuf));
PRIVATE S16 siUnpkCugIntCode  ARGS((SiCugIntCode *pCugIntCode,
                                    Buffer *mBuf));
PRIVATE S16 siUnpkEvntInfo    ARGS((SiEvntInfo *pEvntInfo,Buffer *mBuf));
PRIVATE S16 siUnpkFacInd      ARGS((SiFacInd *pFacInd,Buffer *mBuf));
PRIVATE S16 siUnpkFwdCallInd  ARGS((SiFwdCallInd *pFwdCallInd,
                                    Buffer *mBuf));
PRIVATE S16 siUnpkInfoInd     ARGS((SiInfoInd *pInfoInd,Buffer *mBuf));
PRIVATE S16 siUnpkInfoReqInd  ARGS((SiInfoReqInd *pInfoReqInd,
                                    Buffer *mBuf));
PRIVATE S16 siUnpkNatConInd   ARGS((SiNatConInd *pNatConInd,Buffer *mBuf));
PRIVATE S16 siUnpkOpFwdCalInd ARGS((SiOpFwdCalInd *pOpFwdCalInd,
                                    Buffer *mBuf));
PRIVATE S16 siUnpkOptBckCalInd ARGS((SiOptBckCalInd *pOptBckCalInd,
                                     Buffer *mBuf));
 
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
PRIVATE S16 siUnpkOptBckCalIndQ ARGS((SiOptBckCalIndQ *pOptBckCalIndQ,
            Buffer *mBuf));
#endif
 
PRIVATE S16 siUnpkOrigCdNum    ARGS((SiOrigCdNum *pOrigCdNum,Buffer *mBuf));
PRIVATE S16 siUnpkPassAlng     ARGS((SiPassAlng *pPassAlng,Buffer *mBuf));
PRIVATE S16 siUnpkRangStat     ARGS((SiRangStat *pRangStat, Buffer *mBuf));
PRIVATE S16 siUnpkRedirgNum    ARGS((SiRedirNum *pRedirgNum,Buffer *mBuf));
PRIVATE S16 siUnpkRedirInfo    ARGS((SiRedirInfo *pRedirInfo,Buffer *mBuf));
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkRedirNum     ARGS((SiRedirNum *pRedirNum,Buffer *mBuf));
#endif
PRIVATE S16 siUnpkSigPointCode ARGS((SiSigPointCode *pSigPointCode,
                                     Buffer *mBuf));
PRIVATE S16 siUnpkSusResInd    ARGS((SiSusResInd *pSusResInd,Buffer *mBuf));
PRIVATE S16 siUnpkTranNetSel   ARGS((SiTranNetSel *pTranNetSel, Buffer *mBuf));

/* si037.220 : Addeded Transit network selection fields for ANSI */
#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siUnpkTranNetSel1   ARGS((SiTranNetSel1 *pTranNetSel1, Buffer *mBuf));
#endif
#endif

PRIVATE S16 siUnpkTxMedReq     ARGS((SiTxMedReq *pTxMedReq,Buffer *mBuf));
PRIVATE S16 siUnpkUsr2UsrInd   ARGS((SiUsr2UsrInd *pUsr2UsrInd,
                                     Buffer *mBuf));
PRIVATE S16 siUnpkUsr2UsrInfo  ARGS((SiUsr2UsrInfo *pUsr2UsrInfo,
                                     Buffer *mBuf));
PRIVATE S16 siUnpkSiUsrServInfo ARGS((SiUsrServInfo *pUsrServInfo,
                                      Buffer *mBuf));
PRIVATE S16 siUnpkSiUsrTSrvInfo ARGS((SiUsrTSrvInfo *pUsrTSrvInfo,
                                      Buffer *mBuf));
PRIVATE S16 siUnpkServiceAct    ARGS((SiServiceAct *pServiceAct, Buffer *mBuf));
PRIVATE S16 siUnpkSiGenDigits   ARGS((SiGenDigits *pGenDigits, Buffer *mBuf));
PRIVATE S16 siUnpkSiGenNum      ARGS((SiGenNum *pGenNum,Buffer *mBuf));
PUBLIC S16 siUnpkCirGrpSupMTypInd ARGS((SiCirGrpSupMTypInd *pCgsmti, 
                                        Buffer *mBuf));
PRIVATE S16 siUnpkSiPropDly      ARGS((SiPropDly *pPropDly,Buffer *mBuf));
PRIVATE S16 siUnpkSiNetSpecFacil ARGS((SiNetSpecFacil *pNetFac, Buffer *mBuf));
PRIVATE S16 siUnpkSiCllDiverInfo ARGS((SiCllDiverInfo *pCllDivr,
                                       Buffer *mBuf));
PRIVATE S16 siUnpkSiRedirRestr ARGS((SiRedirRestr *pRedirRstr, Buffer *mBuf));
PRIVATE S16 siUnpkSiMcidReqInd ARGS((SiMcidReqInd *pMcidReq,Buffer *mBuf));
PRIVATE S16 siUnpkSiMcidRspInd ARGS((SiMcidRspInd *pMcidRsp,Buffer *mBuf));
PRIVATE S16 siUnpkSiRemotOper  ARGS((SiRemotOper *pRemotOper,Buffer *mBuf));
PRIVATE S16 siUnpkSiAccDelInfo ARGS((SiAccDelInfo *pAccDelInfo, Buffer *mBuf));
PRIVATE S16 siUnpkSiEchoCtl    ARGS((SiEchoCtl *pEchoCtl, Buffer *mBuf));
PRIVATE S16 siUnpkSiParmCompInfo ARGS((SiParmCompInfo *pParmCom, Buffer *mBuf));
PRIVATE S16 siUnpkSiMsgCompInfo  ARGS((SiMsgCompInfo *pMsgCom, Buffer *mBuf));
PRIVATE S16 siUnpkSiMlppPrec     ARGS((SiMlppPrec *pMlppPrec,Buffer *mBuf));
PRIVATE S16 siUnpkNotifInd       ARGS((SiNotifInd *pNotifInd,Buffer *mBuf));
#if SS7_SINGTEL
PRIVATE S16 siUnpkCllChrgeInfo   ARGS((SiCllChrgeInfo *pCllChrgeInfo,
                                       Buffer *mBuf));
PRIVATE S16 siUnpkChrgeRateInfo  ARGS((SiChrgeRateInfo *pChrgeRateInfo,
                                       Buffer *mBuf));
PRIVATE S16 siUnpkTrnkOff        ARGS((TrnkOff *pTrnkOff,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_INDIA || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCllChrgeBnd  ARGS((SiChargeBand *pCllChrgeBnd, Buffer
*mBuf));
#endif

/* si034.220: Addition - added CHINA variant */
#ifdef SS7_CHINA
PRIVATE S16 siUnpkCallRefA    ARGS((SiCallRefA *pCallRefA,Buffer *mBuf));
PRIVATE S16 siUnpkConnReqA    ARGS((SiConnReqA *pConnReqA,Buffer *mBuf));
PRIVATE S16 siUnpkSigPointCodeA ARGS((SiSigPointCodeA *pSigPointCodeA,
                                      Buffer *mBuf));
PRIVATE S16 siUnpkChargeInform ARGS((SiChargeInform *pChargeInform, Buffer
*mBuf));
#endif /* if SS7_CHINA */

#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
PRIVATE S16 siUnpkOpFwdCalIndQ ARGS((SiOpFwdCalIndQ *pOpFwdCalIndQ,
                                     Buffer *mBuf));
#endif
#if SS7_Q767IT
PRIVATE S16 siUnpkBackVadInd ARGS((SiBackVadInd *pBackVadInd, Buffer *mBuf));
PRIVATE S16 siUnpkFwdVadInd  ARGS((SiFwdVadInd *pFwdVadInd,Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCallRefA    ARGS((SiCallRefA *pCallRefA,Buffer *mBuf));
#endif 
#if (SS7_ANS88 || SS7_ITU2000 || SS7_ANS92 || SS7_ANS95 || SS7_BELL \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkChargeNum   ARGS((SiChargeNum *pChargeNum,Buffer *mBuf));
#endif 
/* sit_c_001.main_15, MODIFIED: moved siUnpkCallRefA and siUnpkChargeNum prototype 
 * out of hash define
 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
PRIVATE S16 siUnpkConnReqA    ARGS((SiConnReqA *pConnReqA,Buffer *mBuf));
PRIVATE S16 siUnpkOrigLineInf ARGS((SiOrigLineInf *pOrigLineInf, Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkOpFwdCalIndA ARGS((SiOpFwdCalIndA *pOpFwdCalIndA,
                                     Buffer *mBuf));
PRIVATE S16 siUnpkCugIntCodeA ARGS((SiCugIntCodeA *pCugIntCodeA, Buffer *mBuf));
PRIVATE S16 siUnpkInfoIndA    ARGS((SiInfoIndA *pInfoIndA,Buffer *mBuf));
PRIVATE S16 siUnpkInfoReqIndA ARGS((SiInfoReqIndA *pInfoReqIndA, Buffer *mBuf));
PRIVATE S16 siUnpkSigPointCodeA ARGS((SiSigPointCodeA *pSigPointCodeA,
                                      Buffer *mBuf));
PRIVATE S16 siUnpkIndex ARGS((SiIndex *pIndex,Buffer *mBuf));
PRIVATE S16 siUnpkFacInfInd ARGS((SiFacInfInd *pFacInfInd,Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkServiceCode ARGS((SiServiceCode *pServiceCode,Buffer *mBuf));
PRIVATE S16 siUnpkGenAddr     ARGS((SiGenAddr *pGenAddr,Buffer *mBuf));
PRIVATE S16 siUnpkBusinessGrp ARGS((SiBusinessGrp *pBusinessGrp, Buffer *mBuf));
PRIVATE S16 siUnpkCarrierId   ARGS((SiCarrierId *pCarrierId,Buffer *mBuf));
PRIVATE S16 siUnpkCarrierSelInf ARGS((SiCarrierSelInf *pCarrierSelInf,
                                      Buffer *mBuf));
PRIVATE S16 siUnpkEgress       ARGS((SiEgress *pEgress,Buffer *mBuf));
PRIVATE S16 siUnpkJurisInf     ARGS((SiJurisInf *pJurisInf,Buffer *mBuf));
PRIVATE S16 siUnpkNetTransport ARGS((SiNetTransport *pNetTransport,
                                     Buffer *mBuf));
PRIVATE S16 siUnpkSpecProcReq ARGS((SiSpecProcReq *pSpecProcReq,Buffer *mBuf));
PRIVATE S16 siUnpkTransReq    ARGS((SiTransReq *pTransReq,Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_BELL || SS7_ANS95 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkGenName     ARGS((SiGenName *pGenName,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_BELL || SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || SS7_ETSIV3 \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkHopCounter  ARGS((SiHopCounter *pHopCounter,Buffer *mBuf));
#endif
#if (SS7_BELL || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkRedirCap    ARGS((SiRedirCap *pRedirCap,Buffer *mBuf));
PRIVATE S16 siUnpkRedirCntr    ARGS((SiRedirCntr *pRedirCntr,Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || SS7_ETSIV3 || \
     defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkLoopPrvntInd ARGS((SiLoopPrvntInd *pLoopPrvntInd,Buffer *mBuf));
PRIVATE S16 siUnpkCalTrnsfrRef ARGS((SiCallTRef *pCalTrnsfrRef, Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSI || SS7_FTZ || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCCBSParam    ARGS((SiCcbsParam *pCCBSParam,Buffer *mBuf));
PRIVATE S16 siUnpkFreePhParam  ARGS((SiFreePhInd *pFreePhInd,Buffer *mBuf));
#endif
#if SS7_FTZ
PRIVATE S16 siUnpkNaPaFF     ARGS((SiNaPaFF *pNaPaFF,Buffer *mBuf,U8 evntType));
PRIVATE S16 siUnpkNaPaSPV    ARGS((SiNaPaSPV *pNaPaSPV,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaFE     ARGS((SiNaPaFE *pNaPaFE,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaSSP    ARGS((SiNaPaSSP *pNaPaSSP,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaCdPNO  ARGS((SiNaPaCdPNO *pNaPaCdPNO,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaExTID  ARGS((SiNaPaExTID *pNaPaExTID,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaCHGI   ARGS((SiNaPaCHGI *pNaPaCHGI,Buffer *mBuf));
PRIVATE S16 siUnpkFacIndInfor ARGS((SiFacIndInfor *pFacIndInfor, Buffer *mBuf));
PRIVATE S16 siUnpkNaPaTTZ     ARGS((SiNaPaTTZ *pNaPaTTZ,Buffer *mBuf));
PRIVATE S16 siUnpkNaPaUKK     ARGS((SiNaPaUKK *pNaPaUKK, Buffer *mBuf));
#endif /* SS7_FTZ */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkNaPaChgPID ARGS((SiNaPaChgPID *pNaPaChgPID, Buffer *mBuf));
#endif
#if SS7_RUSSIA
PRIVATE S16 siUnpkBillZoneNum ARGS((SiBillZoneNum *pBillZoneNum, Buffer *mBuf));
#endif /* SS7_RUSSIA */

#if SS7_NTT
PRIVATE S16 siUnpkMsgAreaInfo ARGS((SiMsgAreaInfo  *pMsgAreaInfo,
   Buffer *mBuf));
PRIVATE S16 siUnpkSubsNumber ARGS((SiSubsNumber  *pSubsNumber,
   Buffer *mBuf));
PRIVATE S16 siUnpkReasProhibCllngNo ARGS((SiReasProhibCllngNo  *pReasProhibCllngNo,
   Buffer *mBuf));
PRIVATE S16 siUnpkSupplUserType ARGS((SiSupplUserType  *pSupplUserType,
   Buffer *mBuf));
PRIVATE S16 siUnpkCarrierInfoTrans ARGS((SiCarrierInfoTrans  *pCarrierInfoTrans,
   Buffer *mBuf));
PRIVATE S16 siUnpkNwFuncType ARGS((SiNwFuncType  *pNwFuncType,
   Buffer *mBuf));
PRIVATE S16 siUnpkChrgInfoType ARGS((SiChrgInfoType *pchrgInfoType,
   Buffer *mBuf));
PRIVATE S16 siUnpkChrgInfo ARGS((SiChrgInfo *pchrgInfo, 
   SiChrgInfoType *pchrgInfoType, Buffer *mBuf));
PRIVATE S16 siUnpkChrgInfoDelay ARGS((SiChrgInfoDelay *pchrgInfoDelay,
   Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCirAsgnMap ARGS((SiCirAsgnMap *unpkParam,
   Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS95) || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkOptrServicesInfo ARGS((SiOptrServicesInfo *unpkParam,
   Buffer *mBuf));
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if ((SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000) || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkBackGVNS ARGS((SiBackGVNS *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkForwardGVNS ARGS((SiForwardGVNS *unpkParam,
   Buffer *mBuf));
#endif
/* sit_c_003.main_15: Addition - added Indian variant */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || SS7_ETSIV3 || \
     defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCallDivTrtInd ARGS((SiCallDivTrtInd *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkCallOfferTrtInd ARGS((SiCallOfferTrtInd *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkCallInNmb ARGS((SiCallInNmb *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkCcss ARGS((SiCcss *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkCollCallReq ARGS((SiCollCallReq *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkConfTrtInd ARGS((SiConfTrtInd *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkCorrelationId ARGS((SiCorrelationId *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkDisplayInfo ARGS((SiDisplayInfo *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkNetMgmtControls ARGS((SiNetMgmtControls *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkScfId ARGS((SiScfId *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkUidActionInd ARGS((SiUidActionInd *unpkParam,
   Buffer *mBuf));
PRIVATE S16 siUnpkUidCapInd ARGS((SiUidCapInd *unpkParam,
   Buffer *mBuf));
#endif

/* sit_c_003.main_15: Addition - added Indian variant */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || \
     defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkAppTransParam ARGS((SiAppTransParam *unpkParam,
   Buffer *mBuf));
#endif
#if (SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 siUnpkCalgGeoLoc ARGS((SiCalgGeoLoc *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkCCNRPosInd ARGS((SiCCNRPosInd *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkNetRoutNum ARGS((SiNetRoutNum *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkPivotCap ARGS((SiPivotCap *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkQOnRelCap ARGS((SiQOnRelCap *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkPivotStat ARGS((SiPivotStat *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkRedirStat ARGS((SiRedirStat *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkPivotCntr ARGS((SiPivotCntr *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkPivotRtgInd ARGS((SiPivotRtgInd *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkPivotRtgBkInfo ARGS((SiPivotRtgBkInfo *pkParam,Buffer *mBuf));
PRIVATE S16 siUnpkNumPortFwdInfo ARGS((SiNumPortFwdInfo *pkParam,
   Buffer *mBuf));
#endif

#ifdef __cplusplus
}
#endif



/*
*
*       Fun:   siPkCnStEvnt 
*
*       Desc:  This function packs the "CnStEvnt" event structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siPkCnStEvnt
(
SiCnStEvnt *pSiCnStEvnt,      /* Connect Status Event */
Buffer *mBuf,                 /* message buffer */
Pst *pst                      /* post structure */
)
#else
PUBLIC S16 siPkCnStEvnt(pSiCnStEvnt,mBuf,pst)
SiCnStEvnt *pSiCnStEvnt;       /* Connect Status Event */
Buffer *mBuf;                  /* message buffer */
Pst *pst;                      /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= SIT_SS7_ANS88_BIT;
#endif /* SS7_ANS88 */
#ifdef SS7_ANS92
   bitVector |= SIT_SS7_ANS92_BIT;
#endif /* SS7_ANS92 */
#ifdef SS7_ANS95
   bitVector |= SIT_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= SIT_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSI
   bitVector |= SIT_SS7_ETSI_BIT;
#endif /* SS7_ETSI */
#ifdef SS7_ETSIV3
   bitVector |= SIT_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
   bitVector |= SIT_SS7_INDIA_BIT;
#endif
/* sit033.220: Addition - added SS7_CHINA */
#ifdef SS7_CHINA
   bitVector |= SIT_SS7_CHINA_BIT;
#endif /* SS7_CHINA */
#ifdef SS7_ITU2000
   bitVector |= SIT_SS7_ITU2000_BIT;
#endif /* SS7_ITU2000 */
#ifdef SS7_RUSS2000
   bitVector |= SIT_SS7_RUSS2000_BIT;
#endif /* SS7_RUSS2000 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkCnStEvnt)
/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   

#if SS7_ITU2000
   /* Redirect Status */
   CMCHKPKLOG(siPkRedirStat,&pSiCnStEvnt->redirStat,mBuf,ESITXXX,pst);

   /*Pivot Routing Backward Info*/
   CMCHKPKLOG(siPkPivotRtgBkInfo, &pSiCnStEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst); 

   /* HTR Information */
   CMCHKPKLOG(siPkChargeNum, &pSiCnStEvnt->htrInfo,mBuf,ESITXXX,pst);  

   /* CCNR Possible indicator */
   CMCHKPKLOG(siPkCCNRPosInd, &pSiCnStEvnt->ccnrPosInd, mBuf,ESITXXX,pst);

#endif
/* si034.220: Addition - added SS7_CHINA */
#ifdef SS7_CHINA
  CMCHKPKLOG(siPkChargeInform,&pSiCnStEvnt->chrgeInform,mBuf,ESITXXX,pst);
#endif /* if SS7_CHINA */

/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
  CMCHKPKLOG(siPkCllChrgeBnd,&pSiCnStEvnt->chrgeBnd,mBuf,ESITXXX,pst);
#endif

/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* UID action indicator */
   CMCHKPKLOG(siPkUidActionInd,&pSiCnStEvnt->uidActionInd,
              mBuf,ESIT001,pst);
   /* call history information */
   CMCHKPKLOG(siPkSiPropDly,&pSiCnStEvnt->cllHstry, mBuf,ESIT002,pst);
   /* confrence treatment indicators */
   CMCHKPKLOG(siPkConfTrtInd,&pSiCnStEvnt->confTrtInd, mBuf,ESIT003,pst);
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   /* backward GVNS */
   CMCHKPKLOG(siPkBackGVNS,&pSiCnStEvnt->backGVNS, mBuf,ESIT004,pst);
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
   /* application transport parameter */
   CMCHKPKLOG(siPkAppTransParam,&pSiCnStEvnt->appTransParam, 
                   mBuf,ESIT005,pst);
   CMCHKPKLOG(siPkOpFwdCalInd,&pSiCnStEvnt->opFwdCalInd,mBuf,ESIT006,pst); 
   /* optional forward call indicators */
#endif
#if SS7_NTT
   /* Carrier Info Transfer */
   CMCHKPKLOG(siPkCarrierInfoTrans,&pSiCnStEvnt->carrierInfoTrans,
                  mBuf,ESIT007,pst);
   /* Charge information delay */
   CMCHKPKLOG(siPkChrgInfoDelay,&pSiCnStEvnt->chrgInfoDelay,mBuf,ESIT008,pst);
   /* Message Area Information */
   CMCHKPKLOG(siPkMsgAreaInfo,&pSiCnStEvnt->msgAreaInfo,mBuf,ESIT009,pst);
#endif
#if SS7_RUSSIA
   CMCHKPKLOG(siPkBillZoneNum,&pSiCnStEvnt->billZoneNum,mBuf,ESIT010,pst);
#endif /* SS7_RUSSIA */
#if SS7_FTZ
   /* National Parameter FF */
   {
      S16 ret;
      if ((ret = siPkNaPaFF(&pSiCnStEvnt->naPaFF, mBuf, EVTGTCHG)) != ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT011,(ErrVal)ret,
                   "Packing failure");
          RETVALUE(ret);
       }
   }
#endif
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* National Parameter for charged party ID*/
   CMCHKPKLOG(siPkNaPaChgPID,&pSiCnStEvnt->naPaChgPID, mBuf,ESIT012,pst);
#endif
#if SS7_FTZ
   /* National Parameter for charging information*/
   CMCHKPKLOG(siPkNaPaCHGI,&pSiCnStEvnt->naPaCHGI,mBuf,ESIT013,pst);
   /* National Parameter for exch & trunk ID */
   CMCHKPKLOG(siPkNaPaExTID,&pSiCnStEvnt->naPaExTID,mBuf,ESIT014,pst);
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   CMCHKPKLOG(siPkLoopPrvntInd,&pSiCnStEvnt->loopPrvntInd,
                   mBuf,ESIT015,pst);
   /* Loop Prevention Indicator */
   CMCHKPKLOG(siPkCalTrnsfrRef,&pSiCnStEvnt->calTrnsfrRef,
                   mBuf,ESIT016,pst);
   /* Call Transfer Reference */
   CMCHKPKLOG(siPkCgPtyNum,&pSiCnStEvnt->calTrnsNmb,mBuf,ESIT017,pst);     
   /* Call Transfer Number */
#endif
#if SS7_SINGTEL
   CMCHKPKLOG(siPkTrnkOff,(&pSiCnStEvnt->trnkOff),mBuf,ESIT018,pst);       
   /* trunk offer info */
#endif
#if SS7_NTT
   {
      S16   ret; /* return value */

      if ((ret = siPkChrgInfo(&pSiCnStEvnt->chrgInfo, &pSiCnStEvnt->
                  chrgInfoType, mBuf)) != ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT019,(ErrVal)ret,
                   "Packing failure for Charge Information (NTT)");
          RETVALUE(ret);
      }
   }
   /* Charge information type */
   CMCHKPKLOG(siPkChrgInfoType,&pSiCnStEvnt->chrgInfoType,mBuf,ESIT020,pst);
#endif
#if SS7_SINGTEL
   CMCHKPKLOG(siPkChrgeRateInfo,&pSiCnStEvnt->rateInfo,mBuf,ESIT021,pst);
   /* charge rate info */
   CMCHKPKLOG(siPkCllChrgeInfo,&pSiCnStEvnt->chrgeInfo,mBuf,ESIT022,pst); 
   /* call charge info */
#endif
#if SS7_Q767IT
   CMCHKPKLOG(siPkBackVadInd,&pSiCnStEvnt->backVad,mBuf,ESIT023,pst);     
   /* backward vad indicat*/
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkRedirInfo,(&pSiCnStEvnt->redirInf),mBuf,ESIT024,pst);    
   /* redirection info */
   CMCHKPKLOG(siPkNotifInd,&pSiCnStEvnt->notifIndR2,mBuf,ESIT025,pst);   
   /* notification indic */
   CMCHKPKLOG(siPkNotifInd,&pSiCnStEvnt->notifInd1,mBuf,ESIT026,pst);   
   /* notification indic */
   CMCHKPKLOG(siPkNetTransport,&pSiCnStEvnt->netTransport,mBuf,ESIT027,pst);
   /* network transport */
   CMCHKPKLOG(siPkInfoInd,&pSiCnStEvnt->infoInd2,mBuf,ESIT028,pst);     
   /* information indicat */
   CMCHKPKLOG(siPkBusinessGrp,&pSiCnStEvnt->businessGrp,mBuf,ESIT029,pst);
   /* business group */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkOrigLineInf,&pSiCnStEvnt->origLineInf,mBuf,ESIT030,pst);
   /* originating line information */
#endif
   CMCHKPKLOG(siPkSiMsgCompInfo,&pSiCnStEvnt->msgCom,mBuf,ESIT031,pst);  
   /* mssge comp info */
   CMCHKPKLOG(siPkSiMcidRspInd,&pSiCnStEvnt->mcidRsp,mBuf,ESIT032,pst);  
   /* MCID response ind */
   CMCHKPKLOG(siPkSiMcidReqInd,&pSiCnStEvnt->mcidReq,mBuf,ESIT033,pst);  
   /* MCID request ind */
   CMCHKPKLOG(siPkSiRedirRestr,&pSiCnStEvnt->redirRstr,mBuf,ESIT034,pst); 
   /* redirection restr */
   CMCHKPKLOG(siPkServiceAct,&pSiCnStEvnt->serviceAct,mBuf,ESIT035,pst); 
   /* service activatn */
   CMCHKPKLOG(siPkSiRemotOper,&pSiCnStEvnt->remotOper,mBuf,ESIT036,pst);  
   /* remote operat */
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkServiceAct,&pSiCnStEvnt->serviceAct2,mBuf,ESITXXX,pst); 
   /* service activatn */
   CMCHKPKLOG(siPkSiRemotOper,&pSiCnStEvnt->remotOper1,mBuf,ESITXXX,pst);  
   /* remote operat */
#endif   
   CMCHKPKLOG(siPkSiNetSpecFacil,&pSiCnStEvnt->netFac,mBuf,ESIT037,pst);  
   /* network specific facility */
   CMCHKPKLOG(siPkSiCllDiverInfo,&pSiCnStEvnt->cllDivr,mBuf,ESIT038,pst); 
   /* call Divers info */
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiCnStEvnt->parmCom,mBuf,ESIT039,pst); 
   /* parameter cmptblty information */
   CMCHKPKLOG(siPkSiGenNum,&pSiCnStEvnt->genNmbR,mBuf,ESIT040,pst);        
   /* generic number */
   CMCHKPKLOG(siPkSiGenNum,&pSiCnStEvnt->genNmb,mBuf,ESIT041,pst);       
   /* generic number */
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiCnStEvnt->accDelInfo,mBuf,ESIT042,pst);
   /* access delivery information */
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiCnStEvnt->accDelInfo1,mBuf,ESITXXX,pst);
   /* access delivery information */
#endif   
   CMCHKPKLOG(siPkSiEchoCtl,&pSiCnStEvnt->echoControl,mBuf,ESIT043,pst);  
   /* echo control */
   CMCHKPKLOG(siPkTxMedReq,&pSiCnStEvnt->txMedUsed,mBuf,ESIT044,pst);    
   /* transmission medium used */
   CMCHKPKLOG(siPkNotifInd,&pSiCnStEvnt->notifIndR1,mBuf,ESIT045,pst);   
   /* notification indic */
   CMCHKPKLOG(siPkNotifInd,&pSiCnStEvnt->notifInd,mBuf,ESIT046,pst);     
   /* notification ind */
   CMCHKPKLOG(siPkCallRef,&pSiCnStEvnt->callRef,mBuf,ESIT047,pst);        
   /* call reference */
   CMCHKPKLOG(siPkConnReq,&pSiCnStEvnt->connReq,mBuf,ESIT048,pst);       
   /* connection request */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* outgoing trunk grp number */
   CMCHKPKLOG(siPkGrpNum, &pSiCnStEvnt->grpNum, mBuf, ESIT049, pst);
#endif
#endif
#if SS7_ANS88
   CMCHKPKLOG(siPkIndex,&pSiCnStEvnt->index,mBuf,ESIT050,pst);            
   /* index */
#endif
   CMCHKPKLOG(siPkCgPtyNum,&pSiCnStEvnt->cgPtyNum,mBuf,ESIT051,pst);     
   /* calling party number*/
   CMCHKPKLOG(siPkCgPtyCat,&pSiCnStEvnt->cgPtyCat,mBuf,ESIT052,pst);    
   /* calling party category */
#if SS7_ANS88
   CMCHKPKLOG(siPkInfoReqIndA,&pSiCnStEvnt->infoReqIndA,mBuf,ESIT053,pst);
   /* information request indicators */
   CMCHKPKLOG(siPkInfoIndA,&pSiCnStEvnt->infoIndA,mBuf,ESIT054,pst);     
   /* information indicators */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkRedirNum,&pSiCnStEvnt->redirgNum,mBuf,ESIT055,pst);    
   /* redirection number */
#endif
   CMCHKPKLOG(siPkInfoReqInd,&pSiCnStEvnt->infoReqInd,mBuf,ESIT056,pst);  
   /* information request indicators */
   CMCHKPKLOG(siPkInfoInd,&pSiCnStEvnt->infoInd,mBuf,ESIT057,pst);        
   /* information indicators */
   CMCHKPKLOG(siPkCdPtyNum, &pSiCnStEvnt->redirNum,mBuf,ESIT058,pst);
   /* redirection number */
   CMCHKPKLOG(siPkEvntInfo,&pSiCnStEvnt->evntInfo,mBuf,ESIT059,pst);      
   /* event information */
   CMCHKPKLOG(siPkCalModInd,&pSiCnStEvnt->calModInd,mBuf,ESIT060,pst);   
   /* call modification indicators */
   CMCHKPKLOG(siPkAccTrnspt,&pSiCnStEvnt->accTrnspt,mBuf,ESIT061,pst);    
   /* access transport */
#if SS7_ANS88
   CMCHKPKLOG(siPkRedirInfo,&pSiCnStEvnt->redirInfo,mBuf,ESIT062,pst);    
   /* redirection inform */
#endif
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiCnStEvnt->usr2UsrInfo,mBuf,ESIT063,pst); 
   /* user to user info */
   CMCHKPKLOG(siPkUsr2UsrInd,&pSiCnStEvnt->usr2UsrInd,mBuf,ESIT064,pst);   
   /* user to user indic */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKPKLOG(siPkConnectedNum2,&pSiCnStEvnt->connNum2,mBuf,ESIT065,pst);  
#endif
   CMCHKPKLOG(siPkConnectedNum,&pSiCnStEvnt->connNum,mBuf,ESIT066,pst);  
   /* connected number */
   CMCHKPKLOG(siPkCauseDgn,&pSiCnStEvnt->causeDgn,mBuf,ESIT067,pst);   
   /* cause indicators */
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
   CMCHKPKLOG(siPkOptBckCalIndQ,&pSiCnStEvnt->optBckCalIndQ,mBuf,ESIT068,
              pst);
   /* optional backward call indicators */
#endif  
   CMCHKPKLOG(siPkOptBckCalInd,&pSiCnStEvnt->optBckCalInd,mBuf,ESIT069,
              pst);
   /* optional backward call indicators */
/* si034.220 - Mod - put connReqA, callRefA under CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKPKLOG(siPkConnReqA,&pSiCnStEvnt->connReqA,mBuf,ESIT070,pst);   
   /* connection request */
   CMCHKPKLOG(siPkCallRefA,&pSiCnStEvnt->callRefA,mBuf,ESIT071,pst); 
   /* call reference */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkChargeNum,&pSiCnStEvnt->chargeNum,mBuf,ESIT072,pst);
   /* charge number */
#endif
   CMCHKPKLOG(siPkBckCalInd,&pSiCnStEvnt->bckCallInd,mBuf,ESIT073,pst); 
   /* backward call */ 
   CMCHKPKLOG(siPkSubNum,&pSiCnStEvnt->subNum,mBuf,ESIT074,pst);  
   /* subsequent number */

   /* sit_c_001.main_15, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SPkU8() function fails.
 */
   CMCHKPKLOG(SPkU32, bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkCnStEvnt */


/*
*
*       Fun:   siPkConEvnt
*
*       Desc:  This function packs the "ConEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkConEvnt
(
SiConEvnt *pSiConEvnt,          /* ISUP Connect Event */
Buffer *mBuf,                   /* message buffer */
Pst *pst,                       /* post structure */
U8 evntType                     /* event type */
)
#else
PUBLIC S16 siPkConEvnt(pSiConEvnt,mBuf,pst,evntType)
SiConEvnt *pSiConEvnt;           /* ISUP Connect Event */
Buffer *mBuf;                    /* message buffer */
Pst *pst;                        /* post structure */
U8 evntType;                     /* event type */
#endif
{
/* sit_c_002.main_15 - Addition. Added variable for Bellcore and Rolling
 * upgrade.
 */
#ifdef SS7_BELL
   CmIntfVer intfVer;   
#endif /* SS7_BELL */

   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= SIT_SS7_ANS88_BIT;
#endif /* SS7_ANS88 */
#ifdef SS7_ANS92
   bitVector |= SIT_SS7_ANS92_BIT;
#endif /* SS7_ANS92 */
#ifdef SS7_ANS95
   bitVector |= SIT_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= SIT_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSI
   bitVector |= SIT_SS7_ETSI_BIT;
#endif /* SS7_ETSI */
#ifdef SS7_ETSIV3
   bitVector |= SIT_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
   bitVector |= SIT_SS7_INDIA_BIT;
#endif
/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   
#ifdef SS7_ITU2000
   bitVector |= SIT_SS7_ITU2000_BIT;
#endif /* SS7_ITU2000 */
#ifdef SS7_RUSS2000
   bitVector |= SIT_SS7_RUSS2000_BIT;
#endif /* SS7_RUSS2000 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
/* sit_c_002.main_15 - Addition. Added variable for Bellcore and Rolling
 * upgrade.
 */
#ifdef SS7_BELL
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer
#else
   intfVer = SITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_BELL */   

   TRC3(siPkConEvnt)

/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   

#if SS7_ITU2000
   /* Number Portability Forward Info */
   CMCHKPKLOG(siPkNumPortFwdInfo, &pSiConEvnt->numPortFwdInfo, mBuf,ESITXXX,pst);

   /* Redirect Status */
   CMCHKPKLOG(siPkRedirStat, &pSiConEvnt->redirStat, mBuf,ESITXXX,pst);     

   /*Pivot Routing Backward Info*/
   CMCHKPKLOG(siPkPivotRtgBkInfo, &pSiConEvnt->pivotRtgBkInfo, mBuf,ESITXXX,pst); 

   /* Pivot Routing Forward Info*/
   CMCHKPKLOG(siPkPivotRtgBkInfo, &pSiConEvnt->pivotRtgFwInfo, mBuf,ESITXXX,pst);

   /* Pivot Counter */
   CMCHKPKLOG(siPkPivotCntr, &pSiConEvnt->pivotCntr, mBuf,ESITXXX,pst);        

   /* Query on Release Capability */
   CMCHKPKLOG(siPkQOnRelCap, &pSiConEvnt->qonRelCap, mBuf,ESITXXX,pst);    

   /* Network Routing Number */
   CMCHKPKLOG(siPkNetRoutNum, &pSiConEvnt->netRoutNum, mBuf,ESITXXX,pst);  
   
   /* Calling geodetic location */
   CMCHKPKLOG(siPkCalgGeoLoc, &pSiConEvnt->calgGeoLoc, mBuf,ESITXXX,pst);    

   /* Original Called IN Number */
   CMCHKPKLOG(siPkOrigCdNum, &pSiConEvnt->origCallInNum, mBuf,ESITXXX,pst);   

   /* Called Directory Number */
   CMCHKPKLOG(siPkCdPtyNum, &pSiConEvnt->cadDirNmb, mBuf,ESITXXX,pst);  

   /* Pivot Capability */   
   CMCHKPKLOG(siPkPivotCap, &pSiConEvnt->pivotCap, mBuf,ESITXXX,pst);      

   /* HTR Information */
   CMCHKPKLOG(siPkChargeNum, &pSiConEvnt->htrInfo, mBuf,ESITXXX,pst);       

#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
   /* application transport parameter */
   CMCHKPKLOG(siPkAppTransParam,&pSiConEvnt->appTransParam,
                                     mBuf,ESIT075,pst);
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   /* forward GVNS */
   CMCHKPKLOG(siPkForwardGVNS,&pSiConEvnt->forwardGVNS, mBuf,ESIT076,pst);
   /* backward GVNS */
   CMCHKPKLOG(siPkBackGVNS,&pSiConEvnt->backGVNS, mBuf,ESIT077,pst);
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* CCSS */
   CMCHKPKLOG(siPkCcss,&pSiConEvnt->ccss, mBuf,ESIT078,pst);
   /* collect call request */
   CMCHKPKLOG(siPkCollCallReq,&pSiConEvnt->collCallReq, mBuf,ESIT079,pst);
   /* UID capability indicator */
   CMCHKPKLOG(siPkUidCapInd,&pSiConEvnt->uidCapInd, mBuf,ESIT080,pst);
   /* SCF Id */
   CMCHKPKLOG(siPkScfId,&pSiConEvnt->scfId, mBuf,ESIT081,pst);
   /* call offering treatment ind */
   CMCHKPKLOG(siPkCallOfferTrtInd,&pSiConEvnt->callOfferTrtInd, 
                   mBuf,ESIT082,pst);
   /* call IN number */
   CMCHKPKLOG(siPkCallInNmb,&pSiConEvnt->callInNmb, mBuf,ESIT083,pst);
   /* call diversion treatment ind */
   CMCHKPKLOG(siPkCallDivTrtInd,&pSiConEvnt->callDivTrtInd, 
                   mBuf,ESIT084,pst);
   /* correlation Id */
   CMCHKPKLOG(siPkCorrelationId,&pSiConEvnt->correlationId, 
                   mBuf,ESIT085,pst);
   /* network management controls */
   CMCHKPKLOG(siPkNetMgmtControls,&pSiConEvnt->netMgmtControls, 
                   mBuf,ESIT086,pst);
   /* confrence treatment indicators */
   CMCHKPKLOG(siPkConfTrtInd,&pSiConEvnt->confTrtInd, mBuf,ESIT087,pst);
   /* display information */
   CMCHKPKLOG(siPkDisplayInfo,&pSiConEvnt->displayInfo, mBuf,ESIT088,pst);
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   CMCHKPKLOG(siPkCirAsgnMap,&pSiConEvnt->cirAsgnMap,mBuf,ESIT089,pst);
   /* circuit assignment map */
#endif
#if SS7_ANS95
   /* Operator services info */ 
   CMCHKPKLOG(siPkOptrServicesInfo, &pSiConEvnt->optrServicesInfo,
                          mBuf,ESIT090,pst);
#endif
#if SS7_NTT
   /* Network function type */
   CMCHKPKLOG(siPkNwFuncType,&pSiConEvnt->nwFuncType,mBuf,ESIT091,pst);
   /*  Carrier Info Transfer */
   CMCHKPKLOG(siPkCarrierInfoTrans,&pSiConEvnt->carrierInfoTrans,mBuf, ESIT092,pst);
   /* Supplementary user type */
   CMCHKPKLOG(siPkSupplUserType,&pSiConEvnt->supplUserType,mBuf,ESIT093,pst);
   /* Reason for prohibiting calling no */
   CMCHKPKLOG(siPkReasProhibCllngNo,&pSiConEvnt->rpCllngNo,mBuf,ESIT094,pst);
   /* Subscriber Number */
   CMCHKPKLOG(siPkSubsNumber,&pSiConEvnt->subsNumber,mBuf,ESIT095,pst);
   /* Message Area Information */
   CMCHKPKLOG(siPkMsgAreaInfo,&pSiConEvnt->msgAreaInfo,mBuf,ESIT096,pst);
#endif
#ifdef SS7_FTZ
   CMCHKPKLOG(siPkNaPaUKK,&pSiConEvnt->naPaUKK,mBuf,ESIT097,pst);
   /* National Parameter for UKK */
   CMCHKPKLOG(siPkNaPaSPV,&pSiConEvnt->naPaSPV,mBuf,ESIT098,pst);
   /* National Parameter for SPV */
   CMCHKPKLOG(siPkNaPaCdPNO,&pSiConEvnt->naPaCdPNO,mBuf,ESIT099,pst);
   /* National Parameter for called pty nmb */
   CMCHKPKLOG(siPkNaPaSSP,&pSiConEvnt->naPaSSP,mBuf,ESIT100,pst);
   /* National Parameter for SSP */
   CMCHKPKLOG(siPkNaPaFE,&pSiConEvnt->naPaFE,mBuf,ESIT101,pst);
   /* National Parameter FE */
   { 
      S16 ret; 
      if ((ret = siPkNaPaFF(&pSiConEvnt->naPaFF, mBuf, evntType)) != ROK) 
      { 
         SPutMsg(mBuf); 
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT102,(ErrVal)ret, 
                   "Packing failure"); 
          RETVALUE(ret); 
       } 
   }
   /* National Parameter FF */
#endif
#if (SS7_ETSI || SS7_FTZ)
   CMCHKPKLOG(siPkFreePhParam,&pSiConEvnt->freePhParam,mBuf,ESIT103,pst);
   /* freephone indicator */
   CMCHKPKLOG(siPkCCBSParam,&pSiConEvnt->ccbsParam,mBuf,ESIT104,pst);    
   /* CCBS parmeter */
#endif
#if (SS7_BELL || SS7_ITU2000)
   /* redirect counter */
   CMCHKPKLOG(siPkRedirCntr, &pSiConEvnt->redirCntr,mBuf,ESIT105,pst);
   /* redirect capability */
   CMCHKPKLOG(siPkRedirCap, &pSiConEvnt->redirCap,mBuf,ESIT106,pst);       
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_BELL || SS7_ANS95 || SS7_INDIA)
   /* hop counter */
   CMCHKPKLOG(siPkHopCounter, &pSiConEvnt->hopCounter,mBuf,ESIT107,pst);
#endif
#if (SS7_BELL || SS7_ANS95)
   /* generic name */
   CMCHKPKLOG(siPkGenName, &pSiConEvnt->genName,mBuf,ESIT108,pst);       
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS92 || SS7_ANS95)
   CMCHKPKLOG(siPkNotifInd,&pSiConEvnt->notifIndR1,mBuf,ESIT109,pst);   
   /* notification indic */
   CMCHKPKLOG(siPkNotifInd,&pSiConEvnt->notifInd1,mBuf,ESIT110,pst);
   /* notification indic */
#endif /* SS7_ANS92 || SS7_ANS95 */   
#endif /* SIT_PARAMETER */   
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkTransReq,&pSiConEvnt->transReq,mBuf,ESIT111,pst);    
   /* transaction request */
   CMCHKPKLOG(siPkSpecProcReq,&pSiConEvnt->specProcReq,mBuf,ESIT112,pst);
   /* spec process reqst */
   CMCHKPKLOG(siPkNetTransport,&pSiConEvnt->netTransport,mBuf,ESIT113,pst);
   /* network transport */
   CMCHKPKLOG(siPkJurisInf,&pSiConEvnt->jurisInf,mBuf,ESIT114,pst);     
   /* jurisdict info */
   CMCHKPKLOG(siPkInfoReqInd,&pSiConEvnt->infoReqInd,mBuf,ESIT115,pst);  
   /* info req indicators */
   CMCHKPKLOG(siPkGenAddr,&pSiConEvnt->genAddrR,mBuf,ESIT116,pst);       
   /* generic address */
   CMCHKPKLOG(siPkGenAddr,&pSiConEvnt->genAddr,mBuf,ESIT117,pst);       
   /* generic address */
   CMCHKPKLOG(siPkEgress,&pSiConEvnt->egress,mBuf,ESIT118,pst);         
   /* ergress service */
   CMCHKPKLOG(siPkCarrierSelInf,&pSiConEvnt->carSelInf,mBuf,ESIT119,pst);
   /* carrier select info */
   CMCHKPKLOG(siPkCarrierId,&pSiConEvnt->carrierId,mBuf,ESIT120,pst);   
   /* carrier ident */
   CMCHKPKLOG(siPkInfoInd,&pSiConEvnt->infoInd,mBuf,ESIT121,pst);
   /* information ident */
   CMCHKPKLOG(siPkBusinessGrp,&pSiConEvnt->businessGrp,mBuf,ESIT122,pst);  
   /* business group */
#endif
#if SS7_SINGTEL
   CMCHKPKLOG(siPkCgPtyNum,&pSiConEvnt->cgPtyNumS,mBuf,ESIT123,pst);     
   /* calling party number */
#endif
#if SS7_Q767IT
   CMCHKPKLOG(siPkBackVadInd,&pSiConEvnt->backVad,mBuf,ESIT124,pst);     
   /* backward vad indicat*/
#endif
   CMCHKPKLOG(siPkSiRedirRestr,&pSiConEvnt->redirRstr,mBuf,ESIT125,pst); 
   /* redirection restr */
   CMCHKPKLOG(siPkCdPtyNum, &pSiConEvnt->redirNum,mBuf,ESIT126,pst);
   /* redirection number*/
   CMCHKPKLOG(siPkSiGenNum,&pSiConEvnt->genNmbR,mBuf,ESIT127,pst);        
   /* generic number */
   CMCHKPKLOG(siPkSiGenNum,&pSiConEvnt->genNmb,mBuf,ESIT128,pst);        
   /* generic number */
   CMCHKPKLOG(siPkSiPropDly,&pSiConEvnt->cllHstry,mBuf,ESIT129,pst);    
   /* call history info*/
   CMCHKPKLOG(siPkNotifInd,&pSiConEvnt->notifIndR2,mBuf,ESIT130,pst);   
   /* notification indic */
   CMCHKPKLOG(siPkNotifInd,&pSiConEvnt->notifInd,mBuf,ESIT131,pst);  
   /* notification ind */
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiConEvnt->accDelInfo,mBuf,ESIT132,pst); 
   /* access delivery information */
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiConEvnt->accDelInfo1,mBuf,ESITXXX,pst); 
   /* access delivery information */
#endif   
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKPKLOG(siPkConnectedNum2,&pSiConEvnt->connNum2,mBuf,ESIT133,pst);   
#endif
   CMCHKPKLOG(siPkConnectedNum,&pSiConEvnt->connNum,mBuf,ESIT134,pst);   
   /* connected number */
#if (SS7_Q767 || SS7_RUSSIA)  
   CMCHKPKLOG(siPkOptBckCalIndQ,&pSiConEvnt->optBckCalIndQ,mBuf,ESIT135,pst);
   /* optional backward call indicators */
#endif  
   CMCHKPKLOG(siPkOptBckCalInd,&pSiConEvnt->optBckCalInd,mBuf,ESIT136,pst);
   /* optional backward call indicators */
   CMCHKPKLOG(siPkCgPtyNum,&pSiConEvnt->cgPtyNum1,mBuf,ESIT137,pst);    
   /* calling party number*/
   CMCHKPKLOG(siPkBckCalInd,&pSiConEvnt->bckCallInd,mBuf,ESIT138,pst);   
   /* backward call indicators */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKPKLOG(siPkTxMedReq,&pSiConEvnt->txMedUsed,mBuf,ESIT139,pst);    
#endif
   /* transmission medium used */
   CMCHKPKLOG(siPkTxMedReq,&pSiConEvnt->txMedUsPr,mBuf,ESIT140,pst);     
   /* trans medium used*/
   CMCHKPKLOG(siPkSiMlppPrec,&pSiConEvnt->mlppPrec,mBuf,ESIT141,pst);
   /* MLPP precedence */
   CMCHKPKLOG(siPkServiceAct,&pSiConEvnt->serviceAct,mBuf,ESIT142,pst);
   /* service activatn */
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkServiceAct,&pSiConEvnt->serviceAct2,mBuf,ESIT142,pst);
   /* service activatn */
#endif   
/* sit_c_002.main_15 - Modification. Modified service activation parameter for
 * Bellcore variant.
 */
#ifdef SS7_ANS92
   CMCHKPKLOG(siPkServiceAct,&pSiConEvnt->serviceAct1,mBuf,ESIT143,pst);
   /* service activation for ANSI 92 */
#else
#ifdef SS7_BELL
   switch (intfVer)
   {
      case 0x0100:
      {
         SiServiceAct tmp;
	 tmp.eh.pres = NOTPRSNT;
	 CMCHKPKLOG(siPkServiceAct, &tmp, mBuf, ESITXXX, pst);
	 break;
      }

      case 0x0200:
         break;

      default: 
	 /* invalid interface version number */
	 SPutMsg(mBuf);
	 RETVALUE(RINVIFVER);
   }
#endif /* SS7_BELL */
#endif /* SS7_ANS92 */   
#if (SS7_ANS92 || SS7_ANS95)
   CMCHKPKLOG(siPkServiceCode,&pSiConEvnt->servCode,mBuf,ESIT144,pst);
   /* service code for ANSI 92 */
#else
#ifdef SS7_BELL
   switch (intfVer)
   {
      case 0x0100:
      {
         SiServiceCode tmp;
	 tmp.eh.pres = NOTPRSNT;
	 CMCHKPKLOG(siPkServiceCode, &tmp, mBuf, ESITXXX, pst);
	 break;
      }

      case 0x0200:
         break;

      default:
	 /* invalid interface version number */
	 SPutMsg(mBuf);
	 RETVALUE(RINVIFVER);
   }
#endif  
#endif /* SS7_ANS92 || SS7_ANS95 */  
	 
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiConEvnt->parmCom,mBuf,ESIT145,pst);  
   /* parameter cmptblty */
   CMCHKPKLOG(siPkSiRemotOper,&pSiConEvnt->remotOper,mBuf,ESIT146,pst);  
   /* remote operations*/
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkSiRemotOper,&pSiConEvnt->remotOper1,mBuf,ESITXXX,pst);  
   /* remote operations*/
#endif   
   CMCHKPKLOG(siPkSiUsrTSrvInfo,&pSiConEvnt->usrTSrvInfo,mBuf,ESIT147,pst);
   /* user teleservice info */
   CMCHKPKLOG(siPkSiGenDigits,&pSiConEvnt->genDigitsR,mBuf,ESIT148,pst);  
   /* generic digits */
   CMCHKPKLOG(siPkSiGenDigits,&pSiConEvnt->genDigits,mBuf,ESIT149,pst);  
   /* generic digits */
#ifndef SS7_CHINA
   CMCHKPKLOG(siPkSigPointCode,&pSiConEvnt->orgPteCde,mBuf,ESIT150,pst); 
   /* originating ISC point code */
/* si034.220 - Addition for China Variant */
#else
   CMCHKPKLOG(siPkSigPointCodeA,&pSiConEvnt->orgPteCdeA,mBuf,ESITXXX,pst); 
   /* originating ISC point code */
#endif   
   CMCHKPKLOG(siPkSiNetSpecFacil,&pSiConEvnt->netFac,mBuf,ESIT151,pst);  
   /* network specific facility */
   CMCHKPKLOG(siPkSiUsrServInfo,&pSiConEvnt->usrServInfo1,mBuf,ESIT152,pst);
   /* user service info prime */
   CMCHKPKLOG(siPkSiPropDly,&pSiConEvnt->propDly,mBuf,ESIT153,pst);      
   /* propagation delay counter*/
   CMCHKPKLOG(siPkUsr2UsrInd,&pSiConEvnt->usr2UsrInd,mBuf,ESIT154,pst);   
   /* user to user indicators */
   CMCHKPKLOG(siPkSiUsrServInfo,&pSiConEvnt->usrServInfo,mBuf,ESIT155,pst);
   /* User Service Info */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkOrigLineInf,&pSiConEvnt->origLineInf,mBuf,ESIT156,pst); 
   /* originating line information */
   CMCHKPKLOG(siPkChargeNum,&pSiConEvnt->chargeNum,mBuf,ESIT157,pst);   
   /* connected number */
#endif
#if SS7_ANS88
   CMCHKPKLOG(siPkRedirInfo,&pSiConEvnt->redirInfoA,mBuf,ESIT158,pst);   
   /* redirection information */
#endif
   CMCHKPKLOG(siPkSiEchoCtl,&pSiConEvnt->echoControl,mBuf,ESIT159,pst);
   /* echo control */
   CMCHKPKLOG(siPkAccTrnspt,&pSiConEvnt->accTrnspt,mBuf,ESIT160,pst);   
   /* access transport */
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiConEvnt->usr2UsrInfo,mBuf,ESIT161,pst); 
   /* user to user info */
   CMCHKPKLOG(siPkOrigCdNum,&pSiConEvnt->origCdNum,mBuf,ESIT162,pst);     
   /* original called num */
   CMCHKPKLOG(siPkConnReq,&pSiConEvnt->connReq,mBuf,ESIT163,pst);        
   /* connection request */
#if SS7_ANS88
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiConEvnt->usr2UsrInfoA,mBuf,ESIT164,pst);
   /* user to user information */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKPKLOG(siPkConnReqA,&pSiConEvnt->connReqA,mBuf,ESIT165,pst);    
   /* connection request */
#endif
#if SS7_ANS88
   CMCHKPKLOG(siPkCugIntCodeA,&pSiConEvnt->cugIntCodeA,mBuf,ESIT166,pst); 
   /* closed group interlock code */
#endif
   CMCHKPKLOG(siPkCugIntCode,&pSiConEvnt->cugIntCode,mBuf,ESIT167,pst);   
   /* closed group interlock  code */
   CMCHKPKLOG(siPkRedirInfo,&pSiConEvnt->redirInfo,mBuf,ESIT168,pst);     
   /* redirection info */
   CMCHKPKLOG(siPkRedirgNum,&pSiConEvnt->redirgNum,mBuf,ESIT169,pst);     
   /* redirection number */
#if SS7_ANS88
   CMCHKPKLOG(siPkOpFwdCalIndA,&pSiConEvnt->opFwdCalIndA,mBuf,ESIT170,pst);
   /* optional forward call indicators */
#endif
#if SS7_Q767IT
   CMCHKPKLOG(siPkFwdVadInd,&pSiConEvnt->fwdVad,mBuf,ESIT171,pst);     
   /* forward vad indicat */
#endif
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
   CMCHKPKLOG(siPkOpFwdCalIndQ,&pSiConEvnt->opFwdCalIndQ,mBuf,ESIT172,pst);
   /* optional forward call indicators */
#endif
   CMCHKPKLOG(siPkOpFwdCalInd,&pSiConEvnt->opFwdCalInd,mBuf,ESIT173,pst); 
   /* optional forward call indicators */
#if SS7_BELL
   CMCHKPKLOG(siPkCgPtyNum1,&pSiConEvnt->cgPtyNumB,mBuf,ESITXXX,pst);
   /* calling party number for Bell */
#endif
   CMCHKPKLOG(siPkCgPtyNum,&pSiConEvnt->cgPtyNum,mBuf,ESIT174,pst);      
   /* calling party number*/
   CMCHKPKLOG(siPkCallRef,&pSiConEvnt->callRef,mBuf,ESIT175,pst);        
   /* call reference */
/* si034.220: Addition - Added switch for CHINA */  
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKPKLOG(siPkCallRefA,&pSiConEvnt->callRefA,mBuf,ESIT176,pst);       
   /* call reference */
#endif
   CMCHKPKLOG(siPkTranNetSel,&pSiConEvnt->tranNetSel,mBuf,ESIT177,pst);   
   /* transit network selection */
/* si037.220 : Transit N/W selection p[ar. as per ANSI specs */
#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkTranNetSel1,&pSiConEvnt->tranNetSel1,mBuf,ESITXXX,pst);   
#endif	 
#endif	 
   CMCHKPKLOG(siPkCdPtyNum,&pSiConEvnt->cdPtyNum,mBuf,ESIT178,pst);      
   /* called party number */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkSiUsrServInfo,&pSiConEvnt->usrServInfoA,mBuf,ESIT179,pst);
   /* user serv Info */
#endif
   CMCHKPKLOG(siPkTxMedReq,&pSiConEvnt->txMedReq,mBuf,ESIT180,pst);      
   /* transmission medium requirement */
   CMCHKPKLOG(siPkCgPtyCat,&pSiConEvnt->cgPtyCat,mBuf,ESIT181,pst);     
   /* calling party categ */
   CMCHKPKLOG(siPkFwdCallInd,&pSiConEvnt->fwdCallInd,mBuf,ESIT182,pst);  
   /* forward call indic */
   CMCHKPKLOG(siPkNatConInd,&pSiConEvnt->natConInd,mBuf,ESIT183,pst);    
   /* Nature of connection  indicators */
   /* sit_c_001.main_15, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SPkU8() function fails.
 */
   CMCHKPKLOG(SPkU32, bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkConEvnt */


/*
*
*       Fun:   siPkFacEvnt
*
*       Desc:  This function packs the "FacEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkFacEvnt
(
SiFacEvnt *pSiFacEvnt,         /* facility event */
Buffer *mBuf,                  /* message buffer */
Pst *pst,                      /* post structure */
U8 evntType                    /* event type */
)
#else
PUBLIC S16 siPkFacEvnt(pSiFacEvnt,mBuf,pst,evntType)
SiFacEvnt *pSiFacEvnt;          /* facility event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
U8 evntType;                     /* event type */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= SIT_SS7_ANS88_BIT;
#endif /* SS7_ANS88 */
#ifdef SS7_ITU97
   bitVector |= SIT_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
   bitVector |= SIT_SS7_INDIA_BIT;
#endif
/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   
#ifdef SS7_ITU2000
   bitVector |= SIT_SS7_ITU2000_BIT;
#endif /* SS7_ITU2000 */
#ifdef SS7_RUSS2000
   bitVector |= SIT_SS7_RUSS2000_BIT;
#endif /* SS7_RUSS2000 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkFacEvnt)

#ifdef SS7_FTZ
   { 
      S16 ret; 
      if ((ret=siPkNaPaFF(&pSiFacEvnt->naPaFF,mBuf,evntType))!=ROK) 
      { 
         SPutMsg(mBuf); 
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT184,(ErrVal)ret, 
                   "Packing failure"); 
          RETVALUE(ret); 
       } 
   }
   /* National Parameter FF */
#endif
/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if SS7_ITU2000
   CMCHKPKLOG(siPkRedirStat,&pSiFacEvnt->redirStat,mBuf,ESITXXX,pst);
   /* Redirect Status */
   CMCHKPKLOG(siPkPivotRtgBkInfo,&pSiFacEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst);
   /*Pivot Routing Backward Info*/
   CMCHKPKLOG(siPkPivotCntr,&pSiFacEvnt->pivotCntr,mBuf,ESITXXX,pst);        
   /* Pivot Counter */
   CMCHKPKLOG(siPkPivotStat,&pSiFacEvnt->pivotStat,mBuf,ESITXXX,pst);       
   /* Pivot Status */
   CMCHKPKLOG(siPkPivotRtgInd,&pSiFacEvnt->pivotRtgInd,mBuf,ESITXXX,pst);   
   /* Pivot Routing Indicators */   
   CMCHKPKLOG(siPkCdPtyNum,&pSiFacEvnt->redirNum,mBuf,ESITXXX,pst);        
   /* redirection number */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   CMCHKPKLOG(siPkNotifInd,&pSiFacEvnt->notifInd,mBuf,ESIT185,pst);     
   /* notification ind */
   CMCHKPKLOG(siPkAccTrnspt,&pSiFacEvnt->accTrans,mBuf,ESIT186,pst);    
   /* access transport */
   CMCHKPKLOG(siPkCgPtyNum,&pSiFacEvnt->calTrnsNmb,mBuf,ESIT187,pst);     
   /* Call Transfer Number*/
#endif
   CMCHKPKLOG(siPkConnReq,&pSiFacEvnt->connReq,mBuf,ESIT188,pst); 
   /* connection request */
   CMCHKPKLOG(siPkServiceAct,&pSiFacEvnt->serviceAct,mBuf,ESIT189,pst); 
   /* service activatn */
   CMCHKPKLOG(siPkSiRemotOper,&pSiFacEvnt->remotOper,mBuf,ESIT190,pst); 
   /* remote operat */
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkConnReqA,&pSiFacEvnt->connReqA,mBuf,ESITXXX,pst); 
   /* connection request */
   CMCHKPKLOG(siPkServiceAct,&pSiFacEvnt->serviceAct2,mBuf,ESITXXX,pst); 
   /* service activatn */
   CMCHKPKLOG(siPkSiRemotOper,&pSiFacEvnt->remotOper1,mBuf,ESITXXX,pst); 
   /* remote operat */
#endif
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiFacEvnt->parmCom,mBuf,ESIT191,pst); 
   /* parameter cmptblty  information */
   CMCHKPKLOG(siPkSiMsgCompInfo,&pSiFacEvnt->msgCom,mBuf,ESIT192,pst);
   /* mssge comp info */
   CMCHKPKLOG(siPkCauseDgn,&pSiFacEvnt->causeDgn,mBuf,ESIT193,pst);     
   /* cause indicator */
   CMCHKPKLOG(siPkCallRef,&pSiFacEvnt->callRef,mBuf,ESIT194,pst);        
   /* call reference */
   CMCHKPKLOG(siPkUsr2UsrInd,&pSiFacEvnt->usr2UsrInd,mBuf,ESIT195,pst); 
   /* user to user indicator */
#if (SS7_ANS88 || SS7_CHINA)
   CMCHKPKLOG(siPkCallRefA,&pSiFacEvnt->callRefA,mBuf,ESIT196,pst);      
#endif
#if SS7_ANS88
   /* call reference */
   CMCHKPKLOG(siPkCgPtyNum,&pSiFacEvnt->cgPtyNum,mBuf,ESIT197,pst);     
   /* calling party number */
   CMCHKPKLOG(siPkCdPtyNum,&pSiFacEvnt->cdPtyNum,mBuf,ESIT198,pst);      
   /* called party number */
   CMCHKPKLOG(siPkFacInfInd,&pSiFacEvnt->facInfInd,mBuf,ESIT199,pst);    
   /* facility information indicator */
#endif
   CMCHKPKLOG(siPkFacInd,&pSiFacEvnt->facInd,mBuf,ESIT200,pst);         
   /* facility indicator */
   /* sit_c_001.main_15, ADDED: pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SPkU8() function fails.
 */
   CMCHKPKLOG(SPkU32, bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkFacEvnt */


/*
*
*       Fun:   siPkInfoEvnt
*
*       Desc:  This function packs the "InfoEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkInfoEvnt
(
SiInfoEvnt *pSiInfoEvnt,       /* Information Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siPkInfoEvnt(pSiInfoEvnt,mBuf,pst)
SiInfoEvnt *pSiInfoEvnt;        /* Information Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siPkInfoEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   CMCHKPKLOG(siPkAccTrnspt,&pSiInfoEvnt->accTrnspt,mBuf,ESIT201,pst);
   /* access transport */
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiInfoEvnt->usr2UsrInfo,mBuf,ESIT202,pst);
   /* user to user information */
   CMCHKPKLOG(siPkPassAlng,&pSiInfoEvnt->passAlng,mBuf,ESIT203,pst);      
   /* pass along */
/* si034.220: Addition - added item for switch China */
#if SS7_CHINA
   CMCHKPKLOG(siPkCallRefA,&pSiInfoEvnt->callRefA,mBuf,ESITXXX,pst);       
   /* call reference */
#endif
   CMCHKPKLOG(siPkCallRef,&pSiInfoEvnt->callRef,mBuf,ESIT204,pst);     
   /* call reference */

   RETVALUE(ROK);
} /* end of siPkInfoEvnt */


/*
*
*       Fun:   siPkRelEvnt
*
*       Desc:  This function packs the "RelEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkRelEvnt
(
SiRelEvnt *pSiRelEvnt,     /* Release Event */
Buffer *mBuf,              /* message buffer */
Pst *pst                    /* post structure */
)
#else
PUBLIC S16 siPkRelEvnt(pSiRelEvnt,mBuf,pst)
SiRelEvnt *pSiRelEvnt;      /* Release Event */
Buffer *mBuf;               /* message buffer */
Pst *pst;                   /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= SIT_SS7_ANS88_BIT;
#endif /* SS7_ANS88 */
#ifdef SS7_ANS92
   bitVector |= SIT_SS7_ANS92_BIT;
#endif /* SS7_ANS92 */
#ifdef SS7_ANS95
   bitVector |= SIT_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= SIT_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSIV3
   bitVector |= SIT_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
   bitVector |= SIT_SS7_INDIA_BIT;
#endif
/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   
#ifdef SS7_ITU2000
   bitVector |= SIT_SS7_ITU2000_BIT;
#endif /* SS7_ITU2000 */
#ifdef SS7_RUSS2000
   bitVector |= SIT_SS7_RUSS2000_BIT;
#endif /* SS7_RUSS2000 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkRelEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

/* sit_c_003.main_15: Addition - Added ITU2000 parameters */   
#if SS7_ITU2000
   /* Redirect Backward Info */
   CMCHKPKLOG(siPkPivotRtgBkInfo, &pSiRelEvnt->redirBkInfo, mBuf,ESITXXX,pst);

   /* Redirect counter */
   CMCHKPKLOG(siPkRedirCntr, &pSiRelEvnt->redirCntr,mBuf,ESITXXX,pst);

   /* HTR Information */
   CMCHKPKLOG(siPkChargeNum, &pSiRelEvnt->htrInfo, mBuf,ESITXXX,pst);       

#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* remote operations */
   CMCHKPKLOG(siPkSiRemotOper, &pSiRelEvnt->remotOper,mBuf,ESIT205,pst);
   /* display information */
   CMCHKPKLOG(siPkDisplayInfo, &pSiRelEvnt->displayInfo,mBuf,ESIT206,pst);
#endif
#if (SS7_NTT || SS7_ANS95)
   /* service activation */
   CMCHKPKLOG(siPkServiceAct, &pSiRelEvnt->serviceAct,mBuf,ESIT207,pst);
#endif
#if SS7_NTT 
   /* called party number */
   CMCHKPKLOG(siPkCdPtyNum, &pSiRelEvnt->cdPtyNum,mBuf,ESIT208,pst);
#endif
#if SS7_SINGTEL
   CMCHKPKLOG(siPkTrnkOff,&pSiRelEvnt->trnkOff,mBuf,ESIT209,pst); 
   /* trunk offer info */
#endif
#if SS7_Q767IT
   CMCHKPKLOG(siPkBackVadInd,&pSiRelEvnt->backVad,mBuf,ESIT210,pst);     
   /* backward vad indicat*/
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkGenAddr,&pSiRelEvnt->genAddrR,mBuf,ESIT211,pst);       
   /* generic address */
   CMCHKPKLOG(siPkGenAddr,&pSiRelEvnt->genAddr,mBuf,ESIT212,pst);       
   /* generic address */
   CMCHKPKLOG(siPkChargeNum,&pSiRelEvnt->chargeNum,mBuf,ESIT213,pst);    
   /* charge number */
#endif
   CMCHKPKLOG(siPkUsr2UsrInd,&pSiRelEvnt->usr2UsrInd,mBuf,ESIT214,pst);  
   /* user to user */
   CMCHKPKLOG(siPkSiRedirRestr,&pSiRelEvnt->redirRstr,mBuf,ESIT215,pst); 
   /* redirection restr */
   CMCHKPKLOG(siPkSiNetSpecFacil,&pSiRelEvnt->netFac,mBuf,ESIT216,pst);  
   /* network specific */
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiRelEvnt->parmCom,mBuf,ESIT217,pst);  
   /* parameter cmptblty information */
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiRelEvnt->accDelInfo,mBuf,ESIT218,pst); 
   /* access delivery */ 
/* si034.220 - Addition for China Variant */
#if SS7_CHINA
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiRelEvnt->accDelInfo1,mBuf,ESITXXX,pst); 
   /* access delivery */ 
#endif
   CMCHKPKLOG(siPkAutoCongLvl,&pSiRelEvnt->autoCongLvl,mBuf,ESIT219,pst); 
   /* automatic congestion level */
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiRelEvnt->usr2UsrInfo,mBuf,ESIT220,pst); 
   /* user to user information */
   CMCHKPKLOG(siPkAccTrnspt,&pSiRelEvnt->accTrnspt,mBuf,ESIT221,pst);    
   /* access transport */
   CMCHKPKLOG(siPkSigPointCode,&pSiRelEvnt->sigPointCode,mBuf,ESIT222,pst);
   /* signalling point code */
#if SS7_ANS88
   CMCHKPKLOG(siPkCugIntCodeA,&pSiRelEvnt->cugIntCodeA,mBuf,ESIT223,pst); 
   /* closed group interlock code */
#endif
/* si034.220: Addition - added item for switch China */   
#if (SS7_ANS88 || SS7_CHINA)
   CMCHKPKLOG(siPkSigPointCodeA,&pSiRelEvnt->sigPointCodeA,mBuf,ESITXXX,pst);
#endif   
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkCallRefA,&pSiRelEvnt->callRefA,mBuf,ESIT225,pst);       
   /* call reference */
#endif
#if SS7_ANS88
   CMCHKPKLOG(siPkRedirNum,&pSiRelEvnt->redirgNum,mBuf,ESIT226,pst);    
   /* redirection number */
#endif
   CMCHKPKLOG(siPkCdPtyNum, &pSiRelEvnt->redirNum,mBuf,ESIT227,pst);
   /* redirection number */
   CMCHKPKLOG(siPkRedirInfo,&pSiRelEvnt->redirInfo,mBuf,ESIT228,pst);   
   /* redirection information */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if SS7_BELL
   CMCHKPKLOG(siPkChargeNum,&pSiRelEvnt->redirgNumB,mBuf,ESITXXX,pst);    
   /* Redirection Number */
#endif
#endif
#if SS7_ANS88
   CMCHKPKLOG(siPkRedirInfo,&pSiRelEvnt->redirInfoA,mBuf,ESIT229,pst);    
   /* redirection information */
#endif
   CMCHKPKLOG(siPkCauseDgn,&pSiRelEvnt->causeDgn,mBuf,ESIT230,pst);      
   /* cause indicators */
   /* sit_c_001.main_15, ADDED:  pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SPkU8 function fails.
 */
   CMCHKPKLOG(SPkU32, bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkRelEvnt */


/*
*
*       Fun:   siPkResmEvnt
*
*       Desc:  This function packs the "ResmEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkResmEvnt
(
SiResmEvnt *pSiResmEvnt,       /* resume event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siPkResmEvnt(pSiResmEvnt,mBuf,pst)
SiResmEvnt *pSiResmEvnt;        /* resume event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siPkResmEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   CMCHKPKLOG(siPkCallRef,&pSiResmEvnt->callRef,mBuf,ESIT231,pst);  
   /* call reference */
/* si034.220: Addition - For CHINA Variant */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKPKLOG(siPkCallRefA,&pSiResmEvnt->callRefA,mBuf,ESIT232,pst);     
   /* call reference */
#endif
   CMCHKPKLOG(siPkSusResInd,&pSiResmEvnt->susResInd,mBuf,ESIT233,pst); 
   /* Suspend/Resume indicators */
   RETVALUE(ROK);
} /* end of siPkResmEvnt */


/*
*
*       Fun:   siPkStaEvnt
*
*       Desc:  This function packs the "StaEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkStaEvnt
(
SiStaEvnt *pSiStaEvnt,         /* Status Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siPkStaEvnt(pSiStaEvnt,mBuf,pst)
SiStaEvnt *pSiStaEvnt;          /* Status Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= SIT_SS7_ANS88_BIT;
#endif /* SS7_ANS88 */
#ifdef SS7_ANS92
   bitVector |= SIT_SS7_ANS92_BIT;
#endif /* SS7_ANS92 */
#ifdef SS7_ANS95
   bitVector |= SIT_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkStaEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

#if SS7_ANS95
   CMCHKPKLOG(siPkCirAsgnMap,&pSiStaEvnt->cirAsgnMap,mBuf,ESIT234,pst); 
   /* circuit assignment map */
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkNatConInd,&pSiStaEvnt->natConInd,mBuf,ESIT235,pst); 
   /* Nature of connection indicators */
#endif
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiStaEvnt->parmCom,mBuf,ESIT236,pst); 
   /* parameter cmptblty information */
   CMCHKPKLOG(siPkCauseDgn,&pSiStaEvnt->causeDgn,mBuf,ESIT237,pst);      
   /* cause indicators */
   CMCHKPKLOG(siPkContInd,&pSiStaEvnt->contInd,mBuf,ESIT238,pst);        
   /* continuity indicator*/
   CMCHKPKLOG(siPkCirStateInd,&pSiStaEvnt->cirStateInd,mBuf,ESIT239,pst);
   /* circuit state indicators */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPKLOG(siPkCirStateInd,&pSiStaEvnt->cirSteIndA,mBuf,ESIT240,pst);
#endif
   CMCHKPKLOG(siPkCirGrpSupMTypInd,&pSiStaEvnt->cgsmti,mBuf,ESIT241,pst); 
   /* circuit group supv. msg. type indicators*/
   CMCHKPKLOG(siPkRangStat,&pSiStaEvnt->rangStat,mBuf,ESIT242,pst);       
   /* range and status */
   /* sit_c_001.main_15, ADDED: pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modifid macro to ensure that SPutMsg is
 * called if SPkU8() function fails. 
 */
   CMCHKPKLOG(SPkU32, bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkStaEvnt */


/*
*
*       Fun:   siPkSuspEvnt
*
*       Desc:  This function packs the "SuspEvnt" event structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siPkSuspEvnt
(
SiSuspEvnt *pSiSuspEvnt,       /* Suspend Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siPkSuspEvnt(pSiSuspEvnt,mBuf,pst)
SiSuspEvnt *pSiSuspEvnt;        /* Suspend Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siPkSuspEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   CMCHKPKLOG(siPkCallRef,&pSiSuspEvnt->callRef,mBuf,ESIT243,pst); 
   /* call reference */
/* si034.220: Addition - switch CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKPKLOG(siPkCallRefA,&pSiSuspEvnt->callRefA,mBuf,ESIT244,pst);      
   /* call reference */
#endif
   CMCHKPKLOG(siPkSusResInd,&pSiSuspEvnt->susResInd,mBuf,ESIT245,pst);   
   /* suspend/resume indicators */
   RETVALUE(ROK);
} /* end of siPkSuspEvnt */


#if SS7_FTZ

/*
*
*       Fun:   siPkSiFtzEvnt
*
*       Desc:  This function packs the "FtzEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siPkSiFtzEvnt
(
SiFtzEvnt *pSiFtzEvnt,         /* FTZ utilities Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst,                       /* post structure */
U8 evntType                     /* event type */
)
#else
PUBLIC S16 siPkSiFtzEvnt(pSiFtzEvnt,mBuf,pst,evntType)
SiFtzEvnt *pSiFtzEvnt;          /* FTZ utilities Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
U8 evntType;                    /* event type */
#endif
{
   TRC3(siPkSiFtzEvnt)
   CMCHKPKLOG(siPkUsr2UsrInfo,&pSiFtzEvnt->usr2UsrInfo,mBuf,ESIT246,pst);
   /* user to user information */
   CMCHKPKLOG(siPkUsr2UsrInd,&pSiFtzEvnt->usr2UsrInd,mBuf,ESIT247,pst);
   /* user to user indicator */
   CMCHKPKLOG(siPkSigPointCode,&pSiFtzEvnt->sigPointCode,mBuf,ESIT248,pst);
   /* signalling point code */
   CMCHKPKLOG(siPkNaPaTTZ,&pSiFtzEvnt->naPaTTZ,mBuf,ESIT249,pst);
   /* National Parameter for Tln-2-Tln sign. */
   CMCHKPKLOG(siPkNaPaCHGI,&pSiFtzEvnt->naPaCHGI,mBuf,ESIT250,pst);
   /* National Parameter for charging infor. */
   {
      S16 ret;
      if ((ret = siPkNaPaFF(&pSiFtzEvnt->naPaFF, mBuf, evntType)) != ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT251,(ErrVal)ret,
                   "Packing failure");
          RETVALUE(ret);
       }
   }
   /* National Parameter FF */
   CMCHKPKLOG(siPkFacIndInfor,&pSiFtzEvnt->facIndInf,mBuf,ESIT252,pst);
   /* Facility Information Indicator */
   CMCHKPKLOG(siPkFacInd,&pSiFtzEvnt->facInd,mBuf,ESIT253,pst);
   /* facility indicator */
   CMCHKPKLOG(siPkCauseDgn,&pSiFtzEvnt->causeDgn,mBuf,ESIT254,pst);
   /* cause indicator */
   CMCHKPKLOG(siPkAutoCongLvl,&pSiFtzEvnt->auCongLvl,mBuf,ESIT255,pst);
   /* automatic congestion level */
   CMCHKPKLOG(siPkAccTrnspt,&pSiFtzEvnt->accTrnspt,mBuf,ESIT256,pst);
   /* access transport */
   CMCHKPKLOG(siPkSiAccDelInfo,&pSiFtzEvnt->accDelInfo,mBuf,ESIT257,pst);
   /* access delivery information */
   CMCHKPKLOG(siPkSiParmCompInfo,&pSiFtzEvnt->parmComp,mBuf,ESIT258,pst);
   /* parameter compatibility information */
   CMCHKPKLOG(siPkSiMsgCompInfo,&pSiFtzEvnt->msgCom,mBuf,ESIT259,pst);
   /* message compatibility information */
   RETVALUE(ROK);
} /* end of siPkSiFtzEvnt */
#endif /* SS7_FTZ */


/* packing functions for ISUP information elements */


/*
*
*       Fun:   siPkAccTrnspt
*
*       Desc:  This function packs the "AccTrnspt" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkAccTrnspt
(
SiAccTrnspt *pAccTrnspt,              /* Access transport */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkAccTrnspt(pAccTrnspt,mBuf)
SiAccTrnspt *pAccTrnspt;               /* Access transport */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkAccTrnspt)
   if (pAccTrnspt->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pAccTrnspt->infoElmts,mBuf); 
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pAccTrnspt->eh,mBuf);     
   /* element header */
   RETVALUE(ROK);
} /* end of siPkAccTrnspt */


/*
*
*       Fun:   siPkAutoCongLvl
*
*       Desc:  This function packs the "AutoCongLvl" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkAutoCongLvl
(
SiAutoCongLvl *pAutoCongLvl,          /* Autonatic Congestion Level */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkAutoCongLvl(pAutoCongLvl,mBuf)
SiAutoCongLvl *pAutoCongLvl;           /* Autonatic Congestion Level */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkAutoCongLvl)
   if (pAutoCongLvl->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pAutoCongLvl->auCongLvl,mBuf); 
      /* auto congestion level */
   }
   CMCHKPK(cmPkElmtHdr,&pAutoCongLvl->eh,mBuf);       
   /* element header */
   RETVALUE(ROK);
} /* end of siPkAutoCongLvl */


/*
*
*       Fun:   siPkSubNum
*
*       Desc:  This function packs the "SubNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSubNum
(
SiSubNum *pSubNum,                    /* subsequent number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSubNum(pSubNum,mBuf)
SiSubNum *pSubNum;                     /* subsequent number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSubNum)
   if (pSubNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pSubNum->addrSig,mBuf); 
      /* Address Signal */ 
      CMCHKPK(cmPkTknU8,&pSubNum->oddEven,mBuf); 
      /* odd or even */
   }
   CMCHKPK(cmPkElmtHdr,&pSubNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSubNum */


/*
*
*       Fun:   siPkBckCalInd
*
*       Desc:  This function packs the "BckCalInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkBckCalInd
(
SiBckCalInd *pBckCalInd,              /* Backward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkBckCalInd(pBckCalInd,mBuf)
SiBckCalInd *pBckCalInd;               /* Backward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkBckCalInd)
   if (pBckCalInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pBckCalInd->sccpMethInd,mBuf); 
      /* SCCP method indictr */
      CMCHKPK(cmPkTknU8,&pBckCalInd->echoCtrlDevInd,mBuf); 
      /* echo control device indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->isdnAccInd,mBuf); 
      /* ISDN access indictor*/
      CMCHKPK(cmPkTknU8,&pBckCalInd->holdInd,mBuf); 
      /* holding indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->isdnUsrPrtInd,mBuf); 
      /* ISDN User Part indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->end2EndInfoInd,mBuf); 
      /* end to end information indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->intInd,mBuf); 
      /* interworking indictr*/
      CMCHKPK(cmPkTknU8,&pBckCalInd->end2EndMethInd,mBuf); 
      /* end to end method indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->cadPtyCatInd,mBuf); 
      /* called party category indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->cadPtyStatInd,mBuf); 
      /* called party status indicator */
      CMCHKPK(cmPkTknU8,&pBckCalInd->chrgInd,mBuf); 
      /* Charge Indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pBckCalInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkBckCalInd */


/*
*
*       Fun:   siPkCallRef
*
*       Desc:  This function packs the "CallRef" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCallRef
(
SiCallRef *pCallRef,                  /* Call Reference */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCallRef(pCallRef,mBuf)
SiCallRef *pCallRef;                   /* Call Reference */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCallRef)
   if (pCallRef->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pCallRef->pntCde,mBuf); 
      /* point code */
      CMCHKPK(cmPkTknU32,&pCallRef->callId,mBuf); 
      /* call identity */
   }
   CMCHKPK(cmPkElmtHdr,&pCallRef->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCallRef */


/*
*
*       Fun:   siPkSiPropDly 
*
*       Desc:  This function packs the propagation delay counter info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiPropDly
(
SiPropDly *pPropDly,                    /* propagation delay */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiPropDly(pPropDly,mBuf)
SiPropDly *pPropDly;                     /* propagation delay */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiPropDly)
   if (pPropDly->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pPropDly->delayVal,mBuf); 
      /* delay value */
   }
   CMCHKPK(cmPkElmtHdr,&pPropDly->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiPropDly */


/*
*
*       Fun:   siPkSiNetSpecFacil
*
*       Desc:  This function packs the network specific facility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiNetSpecFacil
(
SiNetSpecFacil *pNetFac,                /* network facility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiNetSpecFacil(pNetFac,mBuf)
SiNetSpecFacil *pNetFac;                 /* network facility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiNetSpecFacil)
   if (pNetFac->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNetFac->netFac,mBuf); 
      /* network facility */
   }
   CMCHKPK(cmPkElmtHdr,&pNetFac->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiNetSpecFacil */

#if SS7_SINGTEL

/*
*
*       Fun:   siPkTrnkOff
*
*       Desc:  This function packs the trunk offering info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkTrnkOff
(
TrnkOff *pTrnkOff,                      /* trunk offering Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkTrnkOff(pTrnkOff,mBuf)
TrnkOff *pTrnkOff;                       /* trunk offering Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkTrnkOff)
   if (pTrnkOff->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pTrnkOff->trnkOffInfo,mBuf); 
      /* trunk offering Info */
   }
   CMCHKPK(cmPkElmtHdr,&pTrnkOff->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkTrnkOff */


/*
*
*       Fun:   siPkCllChrgeInfo
*
*       Desc:  This function packs the call charge info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCllChrgeInfo
(
SiCllChrgeInfo *pCllChrgeInfo,            /* call charge Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkCllChrgeInfo(pCllChrgeInfo,mBuf)
SiCllChrgeInfo *pCllChrgeInfo;             /* call charge Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkCllChrgeInfo)
   if (pCllChrgeInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pCllChrgeInfo->pntCde,mBuf); 
      /* point code */
      CMCHKPK(cmPkTknU8,&pCllChrgeInfo->chgePoint,mBuf); 
      /* charge point */
      CMCHKPK(cmPkTknU8,&pCllChrgeInfo->chgePrty,mBuf); 
      /* chargeable party */
      CMCHKPK(cmPkTknU8,&pCllChrgeInfo->chgeMeth,mBuf); 
      /* charging method */
      CMCHKPK(cmPkTknU8,&pCllChrgeInfo->typeCalls,mBuf); 
      /* type of calls */
   }
   /* element header */   
   CMCHKPK(cmPkElmtHdr,&pCllChrgeInfo->eh,mBuf);
   RETVALUE(ROK);
} /* end of siPkCllChrgeInfo */


/*
*
*       Fun:   siPkChrgeRateInfo
*
*       Desc:  This function packs the charge rate info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkChrgeRateInfo
(
SiChrgeRateInfo *pChrgeRateInfo,          /* charge rate Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkChrgeRateInfo(pChrgeRateInfo,mBuf)
SiChrgeRateInfo *pChrgeRateInfo;           /* charge rate Information */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siPkChrgeRateInfo)
   if (pChrgeRateInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pChrgeRateInfo->nominalTime,mBuf); 
      /* nominal time */
      CMCHKPK(cmPkTknU8,&pChrgeRateInfo->tariffFact,mBuf); 
      /* tariff factor */ 
      CMCHKPK(cmPkTknU8,&pChrgeRateInfo->tariffUnit,mBuf); 
      /*tariff unit chagring */
      CMCHKPK(cmPkTknU8,&pChrgeRateInfo->tariffCat,mBuf); 
      /* tariff category */
      CMCHKPK(cmPkTknU8,&pChrgeRateInfo->pktChrgng,mBuf); 
      /* packet chagring */
   }
   /* element header */
   CMCHKPK(cmPkElmtHdr,&pChrgeRateInfo->eh,mBuf); 
   RETVALUE(ROK);
} /* end of siPkChrgeRateInfo */
#endif

#if SS7_Q767IT

/*
*
*       Fun:   siPkFwdVadInd
*
*       Desc:  This function packs the forward vad indicator
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkFwdVadInd
(
SiFwdVadInd *pFwdVadInd,                /* forward vad indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkFwdVadInd(pFwdVadInd,mBuf)
SiFwdVadInd *pFwdVadInd;                 /* forward vad indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkFwdVadInd)
   if (pFwdVadInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pFwdVadInd->srvSteInd,mBuf); 
      /* service state indicator */
      CMCHKPK(cmPkTknU8,&pFwdVadInd->procInd,mBuf); 
      /* procedure indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pFwdVadInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkFwdVadInd */


/*
*
*       Fun:   siPkBackVadInd
*
*       Desc:  This function packs the backward vad indicator
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkBackVadInd
(
SiBackVadInd *pBackVadInd,              /* backward vad indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkBackVadInd(pBackVadInd,mBuf)
SiBackVadInd *pBackVadInd;               /* backward vad indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkBackVadInd)
   if (pBackVadInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pBackVadInd->snInd,mBuf); 
      /* sn indicator */
      CMCHKPK(cmPkTknU8,&pBackVadInd->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknStr,&pBackVadInd->addrSig,mBuf); 
      /* Address Signal */
   }
   CMCHKPK(cmPkElmtHdr,&pBackVadInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkBackVadInd */
#endif


/*
*
*       Fun:   siPkSiCllDiverInfo
*
*       Desc:  This function packs the call diversion info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiCllDiverInfo
(
SiCllDiverInfo *pCllDivr,               /* call Diversion information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiCllDiverInfo(pCllDivr,mBuf)
SiCllDiverInfo *pCllDivr;                /* call Diversion information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiCllDiverInfo)
   if (pCllDivr->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCllDivr->redirRsn,mBuf); 
      /* redirection reason */
      CMCHKPK(cmPkTknU8,&pCllDivr->notSuscr,mBuf); 
      /* notification subscribtion */
   }
   CMCHKPK(cmPkElmtHdr,&pCllDivr->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiCllDiverInfo */


/*
*
*       Fun:   siPkSiRedirRestr
*
*       Desc:  This function packs the redirection restriction
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiRedirRestr
(
SiRedirRestr *pRedirRstr,               /* redirection restriction */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiRedirRestr(pRedirRstr,mBuf)
SiRedirRestr *pRedirRstr;                /* redirection restriction */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiRedirRestr)
   if (pRedirRstr->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pRedirRstr->presRest,mBuf); 
      /* presentation restr */
   }
   CMCHKPK(cmPkElmtHdr,&pRedirRstr->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiRedirRestr */


/*
*
*       Fun:   siPkSiMcidReqInd
*
*       Desc:  This function packs the MCID request indicators
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiMcidReqInd
(
SiMcidReqInd *pMcidReq,                 /* MCID request indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiMcidReqInd(pMcidReq,mBuf)
SiMcidReqInd *pMcidReq;                  /* MCID request indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiMcidReqInd)
   if (pMcidReq->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pMcidReq->hldInd,mBuf); 
      /* hold indicators */
      CMCHKPK(cmPkTknU8,&pMcidReq->reqInd,mBuf); 
      /* mcid request indicators */
   }
   CMCHKPK(cmPkElmtHdr,&pMcidReq->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiMcidReqInd */


/*
*
*       Fun:   siPkSiMcidRspInd
*
*       Desc:  This function packs the MCID response indicators
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiMcidRspInd
(
SiMcidRspInd *pMcidRsp,                 /* MCID response indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiMcidRspInd(pMcidRsp,mBuf)
SiMcidRspInd *pMcidRsp;                  /* MCID response indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiMcidRspInd)
   if (pMcidRsp->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pMcidRsp->hldInd,mBuf); 
      /* hold indicators */
      CMCHKPK(cmPkTknU8,&pMcidRsp->rspInd,mBuf); 
      /* mcid response indicators */
   }
   CMCHKPK(cmPkElmtHdr,&pMcidRsp->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiMcidRspInd */


/*
*
*       Fun:   siPkSiRemotOper 
*
*       Desc:  This function packs the remote operation info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiRemotOper
(
SiRemotOper *pRemotOper,                /* remote operations */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiRemotOper(pRemotOper,mBuf)
SiRemotOper *pRemotOper;                 /* remote operations */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiRemotOper)
   if (pRemotOper->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pRemotOper->compon,mBuf); 
      /* components */
      CMCHKPK(cmPkTknU8,&pRemotOper->protProf,mBuf); 
      /* protocol profile */
   }
   CMCHKPK(cmPkElmtHdr,&pRemotOper->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiRemotOper */


/*
*
*       Fun:   siPkSiAccDelInfo 
*
*       Desc:  This function packs the access delivery info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiAccDelInfo
(
SiAccDelInfo *pAccDelInfo,              /* access delivery */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiAccDelInfo(pAccDelInfo,mBuf)
SiAccDelInfo *pAccDelInfo;               /* access delivery */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiAccDelInfo)
   if (pAccDelInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pAccDelInfo->delInd,mBuf); 
      /* delivery indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pAccDelInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiAccDelInfo */


/*
*
*       Fun:   siPkSiEchoCtl
*
*       Desc:  This function packs the echo control info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiEchoCtl
(
SiEchoCtl *pEchoCtl,                    /* echo control */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiEchoCtl(pEchoCtl,mBuf)
SiEchoCtl *pEchoCtl;                     /* echo control */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiEchoCtl)
   if (pEchoCtl->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pEchoCtl->incEchoReq,mBuf); 
      /* incoming echo control device request */
      CMCHKPK(cmPkTknU8,&pEchoCtl->outEchoReq,mBuf); 
      /* outgoing echo control  request*/
      CMCHKPK(cmPkTknU8,&pEchoCtl->incEchoRsp,mBuf); 
      /* incoming echo control response*/
      CMCHKPK(cmPkTknU8,&pEchoCtl->outEchoRsp,mBuf); 
      /* outgoing echo control response */
   }
   CMCHKPK(cmPkElmtHdr,&pEchoCtl->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiEchoCtl */


/*
*
*       Fun:   siPkSiParmCompInfo
*
*       Desc:  This function packs the parameter compatibility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiParmCompInfo
(
SiParmCompInfo *pParmCom,               /* parameter compatibility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiParmCompInfo(pParmCom,mBuf)
SiParmCompInfo *pParmCom;                /* parameter compatibility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiParmCompInfo)
   if (pParmCom->eh.pres)
   {
      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd10,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI10,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss10,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd10,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd10,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd10,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd10,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd10,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar10,mBuf); 
      /* upgraded parm 10 */
 
      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd9,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI9,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss9,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd9,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd9,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd9,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd9,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd9,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar9,mBuf); 
      /* upgraded parm 9 */
 
      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd8,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI8,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss8,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd8,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd8,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd8,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd8,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd8,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar8,mBuf); 
      /* upgraded parm 8 */
 
      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd7,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI7,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss7,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd7,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd7,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd7,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd7,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd7,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar7,mBuf); 
      /* upgraded parm 7 */
 
      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd6,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI6,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss6,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd6,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd6,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd6,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd6,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd6,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar6,mBuf); 
      /* upgraded parm 6 */

      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd5,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI5,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss5,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd5,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd5,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd5,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd5,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd5,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar5,mBuf); 
      /* upgraded parm 5 */

      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd4,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI4,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss4,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd4,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd4,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd4,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd4,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd4,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar4,mBuf); 
      /* upgraded parm 4 */

      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd3,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI3,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss3,mBuf); 
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd3,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd3,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd3,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd3,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd3,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar3,mBuf); 
      /* upgraded parm 3 */

      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd2,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI2,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss2,mBuf); 
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd2,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd2,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd2,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd2,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd2,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar2,mBuf); 
      /* upgraded parm 2 */

      /* additional instruction indicator */
      CMCHKPK(cmPkTknStr,&pParmCom->addInstInd1,mBuf);
      /* broadband narrowband interworking ind */
      CMCHKPK(cmPkTknU8,&pParmCom->pBbNbIntwkI1,mBuf);
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKPK(cmPkTknU8,&pParmCom->passNtPoss1,mBuf); 
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdParInd1,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pParmCom->dcrdMsgInd1,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pParmCom->sndNotInd1,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pParmCom->relCllInd1,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pParmCom->tranXInd1,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pParmCom->upgrPar1,mBuf); 
      /* upgraded parm 1 */
   }
   CMCHKPK(cmPkElmtHdr,&pParmCom->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiParmCompInfo */


/*
*
*       Fun:   siPkSiMsgCompInfo
*
*       Desc:  This function packs the message compatibility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiMsgCompInfo
(
SiMsgCompInfo *pMsgCom,                 /* message compatibility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiMsgCompInfo(pMsgCom,mBuf)
SiMsgCompInfo *pMsgCom;                  /* message compatibility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiMsgCompInfo)
   if (pMsgCom->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pMsgCom->bbNbIntwkI1,mBuf); 
      /* broadband narrowband interworking indicator */
      CMCHKPK(cmPkTknU8,&pMsgCom->passNotPoss1,mBuf); 
      /* pass on not possible ind */
      CMCHKPK(cmPkTknU8,&pMsgCom->dcrdMsgInd1,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pMsgCom->sndNotInd1,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pMsgCom->relCllInd1,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pMsgCom->tranXInd1,mBuf); 
      /* transit exchange indic */
      CMCHKPK(cmPkTknU8,&pMsgCom->bbNbIntwkI,mBuf); 
      /* broadband narrowband interworking indicator */
      CMCHKPK(cmPkTknU8,&pMsgCom->passNotPoss,mBuf); 
      /* pass on not possible ind */
      CMCHKPK(cmPkTknU8,&pMsgCom->dcrdMsgInd,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pMsgCom->sndNotInd,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pMsgCom->relCllInd,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pMsgCom->tranXInd,mBuf); 
      /* transit exchange indic */
   }
   CMCHKPK(cmPkElmtHdr,&pMsgCom->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiMsgCompInfo */


/*
*
*       Fun:   siPkSiMlppPrec
*
*       Desc:  This function packs the MLPP precedence info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiMlppPrec
(
SiMlppPrec *pMlppPrec,                  /* MLPP precedence */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siPkSiMlppPrec(pMlppPrec,mBuf)
SiMlppPrec *pMlppPrec;                   /* MLPP precedence */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siPkSiMlppPrec)
   if (pMlppPrec->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pMlppPrec->servDomain,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pMlppPrec->frthDig,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pMlppPrec->thrdDig,mBuf); 
      /* discard parameter ind */
      CMCHKPK(cmPkTknU8,&pMlppPrec->scndDig,mBuf); 
      /* discard message ind */
      CMCHKPK(cmPkTknU8,&pMlppPrec->frstDig,mBuf); 
      /* send notification indic*/
      CMCHKPK(cmPkTknU8,&pMlppPrec->lfb,mBuf); 
      /* release call indicator*/
      CMCHKPK(cmPkTknU8,&pMlppPrec->precdLvl,mBuf); 
      /* transit exchange indic */
   }
   CMCHKPK(cmPkElmtHdr,&pMlppPrec->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiMlppPrec */

/*si034.220 : Addition - SS7_CHINA flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)

/*
*
*       Fun:   siPkCallRefA
*
*       Desc:  This function packs the "CallRefA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCallRefA
(
SiCallRefA *pCallRefA,                /* Call Reference */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCallRefA(pCallRefA,mBuf)
SiCallRefA *pCallRefA;                 /* Call Reference */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCallRefA)
   if (pCallRefA->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pCallRefA->pntCde,mBuf); 
      /* point code */
      CMCHKPK(cmPkTknU32,&pCallRefA->callId,mBuf); 
      /* call identity */
   }
   CMCHKPK(cmPkElmtHdr,&pCallRefA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCallRefA */

#endif

/*
*
*       Fun:   siPkCalModInd
* 
*       Desc:  This function packs the "CalModInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCalModInd
(
SiCalModInd *pCalModInd,              /* Call Modification Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCalModInd(pCalModInd,mBuf)
SiCalModInd *pCalModInd;               /* Call Modification Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCalModInd)
   if (pCalModInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCalModInd->modInd,mBuf); 
      /* call modification indicators */
   }
   CMCHKPK(cmPkElmtHdr,&pCalModInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCalModInd */


/*
*
*       Fun:   siPkCauseDgn
*
*       Desc:  This function packs the "CauseDgn" information
*              element structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCauseDgn
(
SiCauseDgn *pCauseDgn,                /* Cause Indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCauseDgn(pCauseDgn,mBuf)
SiCauseDgn *pCauseDgn;                 /* Cause Indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCauseDgn)
   if (pCauseDgn->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pCauseDgn->dgnVal,mBuf); 
      /* diagnostics */ 
      CMCHKPK(cmPkTknU8,&pCauseDgn->causeVal,mBuf); 
      /* cause value */ 
      CMCHKPK(cmPkTknU8,&pCauseDgn->recommend,mBuf); 
      /* recommendation */ 
      CMCHKPK(cmPkTknU8,&pCauseDgn->cdeStand,mBuf); 
      /* coding standard */
      CMCHKPK(cmPkTknU8,&pCauseDgn->location,mBuf); 
      /* location */
   }
   CMCHKPK(cmPkElmtHdr,&pCauseDgn->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCauseDgn */


/*
*
*       Fun:   siPkCdPtyNum
*
*       Desc:  This function packs the "CdPtyNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siPkCdPtyNum
(
SiCdPtyNum *pCdPtyNum,                /* Called Party Number */
Buffer *mBuf                           /* message buffer */
)
#else
PUBLIC S16 siPkCdPtyNum(pCdPtyNum,mBuf)
SiCdPtyNum *pCdPtyNum;                 /* Called Party Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCdPtyNum)
   if (pCdPtyNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pCdPtyNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pCdPtyNum->innInd,mBuf); 
      /* international network number indicator */
      CMCHKPK(cmPkTknU8,&pCdPtyNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pCdPtyNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pCdPtyNum->natAddrInd,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pCdPtyNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCdPtyNum */


/*
*
*       Fun:   siPkCgPtyCat
*
*       Desc:  This function packs the "CgPtyCat" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCgPtyCat
(
SiCgPtyCat *pCgPtyCat,                /* Calling Party Category */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCgPtyCat(pCgPtyCat,mBuf)
SiCgPtyCat *pCgPtyCat;                 /* Calling Party Category */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCgPtyCat)
   if (pCgPtyCat->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCgPtyCat->cgPtyCat,mBuf); 
      /* calling party category */
   }
   CMCHKPK(cmPkElmtHdr,&pCgPtyCat->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCgPtyCat */


/*
*
*       Fun:   siPkCgPtyNum
*      
*       Desc:  This function packs the "CgPtyNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siPkCgPtyNum
(
SiCgPtyNum *pCgPtyNum,                /* Calling Party Number */
Buffer *mBuf                           /* message buffer */
)
#else
PUBLIC S16 siPkCgPtyNum(pCgPtyNum,mBuf)
SiCgPtyNum *pCgPtyNum;                 /* Calling Party Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCgPtyNum)
   if (pCgPtyNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pCgPtyNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->niInd,mBuf); 
      /* number incomplete indicator */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->scrnInd,mBuf); 
      /* screen indicator */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->natAddrInd,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pCgPtyNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCgPtyNum */


#if SS7_BELL
/*
*
*       Fun:   siPkCgPtyNum1
*      
*       Desc:  This function packs the "CgPtyNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siPkCgPtyNum1
(
SiCgPtyNum1 *pCgPtyNum,                /* Calling Party Number */
Buffer *mBuf                           /* message buffer */
)
#else
PUBLIC S16 siPkCgPtyNum1(pCgPtyNum,mBuf)
SiCgPtyNum1 *pCgPtyNum;                 /* Calling Party Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCgPtyNum1)
   if (pCgPtyNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pCgPtyNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->scrnInd,mBuf);
      /* screen indicator */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pCgPtyNum->natAddrInd,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pCgPtyNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCgPtyNum1 */
#endif  /* SS7_BELL */


/*
*
*       Fun:   siPkSiGenNum
*      
*       Desc:  This function packs the "SiGenNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiGenNum
(
SiGenNum *pGenNum,                    /* Generic Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSiGenNum(pGenNum,mBuf)
SiGenNum *pGenNum;                     /* Generic Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSiGenNum)
   if (pGenNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pGenNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pGenNum->niInd,mBuf); 
      /* number incomplete indicator */
      CMCHKPK(cmPkTknU8,&pGenNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pGenNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pGenNum->scrnInd,mBuf); 
      /* screen indicator */
      CMCHKPK(cmPkTknU8,&pGenNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pGenNum->natAddrInd,mBuf); 
      /* nature of addresss indicator */
      CMCHKPK(cmPkTknU8,&pGenNum->nmbQual,mBuf); 
      /* number qualifier */
   }
   CMCHKPK(cmPkElmtHdr,&pGenNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiGenNum */


/*
*
*       Fun:   siPkCirGrpSupMTypInd
*      
*       Desc:  This function packs the "CirGrpSupMTypInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCirGrpSupMTypInd
(
SiCirGrpSupMTypInd *pCgsmti,          /* Circuit Group Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCirGrpSupMTypInd(pCgsmti,mBuf)
SiCirGrpSupMTypInd *pCgsmti;           /* Circuit Group Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCirGrpSupMTypInd)
   if (pCgsmti->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCgsmti->typeInd,mBuf); 
      /* circuit state indicator. */
   }
   CMCHKPK(cmPkElmtHdr,&pCgsmti->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCirGrpSupMTypInd */


/*
*
*       Fun:   siPkCirStateInd
*      
*       Desc:  This function packs the "CirStateInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCirStateInd
(
SiCirStateInd *pCirStateInd,          /* Circuit State Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCirStateInd(pCirStateInd,mBuf)
SiCirStateInd *pCirStateInd;           /* Circuit State Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCirStateInd)
   if (pCirStateInd->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pCirStateInd->cirSteInd,mBuf); 
      /* circuit state indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pCirStateInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCirStateInd */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siPkConnectedNum2
*      
*       Desc:  This function packs the "ConnectedNum2" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkConnectedNum2
(
SiConnectedNum2 *pConnectedNum2,       /* Connected number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkConnectedNum2(pConnectedNum2,mBuf)
SiConnectedNum2 *pConnectedNum2;       /* Connected number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkConnectedNum2)
   if (pConnectedNum2->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pConnectedNum2->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pConnectedNum2->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pConnectedNum2->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pConnectedNum2->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pConnectedNum2->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pConnectedNum2->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkConnectedNum2 */
#endif


/*
*
*       Fun:   siPkConnectedNum
*      
*       Desc:  This function packs the "ConnectedNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkConnectedNum
(
SiConnectedNum *pConnectedNum,        /* Connected number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkConnectedNum(pConnectedNum,mBuf)
SiConnectedNum *pConnectedNum;         /* Connected number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkConnectedNum)
   if (pConnectedNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pConnectedNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pConnectedNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pConnectedNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pConnectedNum->scrnInd,mBuf); 
      /* screen indicator */
      CMCHKPK(cmPkTknU8,&pConnectedNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pConnectedNum->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pConnectedNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkConnectedNum */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
 
/*
*
*       Fun:   siPkGrpNum
*      
*       Desc:  This function packs the "SiPkGrpNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkGrpNum
(
SiOutgTrkGrpNum  *pGrpNum, /* outgoing trunk group number */
Buffer           *mBuf    /* message buffer */
)
#else
PRIVATE S16 siPkGrpNum(pGrpNum, mBuf)
SiOutgTrkGrpNum  *pGrpNum; /* outgoing trunk group number */
Buffer           *mBuf;   /* message buffer */
#endif
{
   TRC3(siPkGrpNum)
   if( pGrpNum->eh.pres )
   {
      /* Pack the digits in the trunk group number */
      CMCHKPK(cmPkTknStr,&pGrpNum->digits,mBuf); 
   }
   /* element header */
   CMCHKPK(cmPkElmtHdr,&pGrpNum->eh,mBuf); 
   RETVALUE(ROK);
}
#endif
#endif


/*
*
*       Fun:   siPkConnReq
*      
*       Desc:  This function packs the "ConnReq" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkConnReq
(
SiConnReq *pConnReq,                  /* Connection Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkConnReq(pConnReq,mBuf)
SiConnReq *pConnReq;                   /* Connection Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkConnReq)
   if (pConnReq->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pConnReq->credit,mBuf); 
      /* credit */
      CMCHKPK(cmPkTknU8,&pConnReq->protClass,mBuf); 
      /* protocol classs */
      CMCHKPK(cmPkTknU16,&pConnReq->pntCde,mBuf); 
      /* point code */
      CMCHKPK(cmPkTknU32,&pConnReq->locRef,mBuf); 
      /* local reference  (really a 24bit quantity) */
   }
   CMCHKPK(cmPkElmtHdr,&pConnReq->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkConnReq */

/*si034.220: Addition - SS7_CHINA flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)

/*
*
*       Fun:   siPkConnReqA
*      
*       Desc:  This function packs the "ConnReqA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkConnReqA
(
SiConnReqA *pConnReqA,                /* Connection Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkConnReqA(pConnReqA,mBuf)
SiConnReqA *pConnReqA;                 /* Connection Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkConnReqA)
   if (pConnReqA->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pConnReqA->credit,mBuf); 
      /* credit */
      CMCHKPK(cmPkTknU8,&pConnReqA->protClass,mBuf); 
      /* protocol classs */
      CMCHKPK(cmPkTknU32,&pConnReqA->pntCde,mBuf); 
      /* point code */
      CMCHKPK(cmPkTknU32,&pConnReqA->locRef,mBuf); 
      /* local reference (really a 24bit quantity) */
   }
   CMCHKPK(cmPkElmtHdr,&pConnReqA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkConnReqA */

#endif

/*
*
*       Fun:   siPkContInd
*      
*       Desc:  This function packs the "ContInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkContInd
(
SiContInd *pContInd,                  /* Continuity indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkContInd(pContInd,mBuf)
SiContInd *pContInd;                   /* Continuity indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkContInd)
   if (pContInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pContInd->contInd,mBuf); 
      /* continuity indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pContInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkContInd */


/*
*
*       Fun:   siPkCugIntCode
*      
*       Desc:  This function packs the "CugIntCode" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCugIntCode
(
SiCugIntCode *pCugIntCode,            /* Closed User Group Interlock Code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCugIntCode(pCugIntCode,mBuf)
SiCugIntCode *pCugIntCode;             /* Closed User Group Interlock Code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCugIntCode)
   if (pCugIntCode->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pCugIntCode->binCde,mBuf); 
      /* binary Code */
      CMCHKPK(cmPkTknU8,&pCugIntCode->dig3,mBuf); 
      /* Digit 3 */
      CMCHKPK(cmPkTknU8,&pCugIntCode->dig4,mBuf); 
      /* Digit 4 */
      CMCHKPK(cmPkTknU8,&pCugIntCode->dig1,mBuf); 
      /* Digit 1 */
      CMCHKPK(cmPkTknU8,&pCugIntCode->dig2,mBuf); 
      /* Digit 2 */
   }
   CMCHKPK(cmPkElmtHdr,&pCugIntCode->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCugIntCode */
 
#if SS7_ANS88

/*
*
*       Fun:   siPkCugIntCodeA
*      
*       Desc:  This function packs the "CugIntCodeA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCugIntCodeA
(
SiCugIntCodeA *pCugIntCodeA,          /* Closed User Group Interlock Code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCugIntCodeA(pCugIntCodeA,mBuf)
SiCugIntCodeA *pCugIntCodeA;           /* Closed User Group Interlock Code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCugIntCodeA)
   if (pCugIntCodeA->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pCugIntCodeA->ISDNIdent,mBuf); 
      /* binary Code */
      CMCHKPK(cmPkTknU16,&pCugIntCodeA->binCde,mBuf); 
      /* binary Code */
   }
   CMCHKPK(cmPkElmtHdr,&pCugIntCodeA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCugIntCodeA */
 
#endif

/*
*
*       Fun:   siPkEvntInfo
*
*       Desc:  This function packs the "EvntInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkEvntInfo
(
SiEvntInfo *pEvntInfo,                /* Event Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkEvntInfo(pEvntInfo,mBuf)
SiEvntInfo *pEvntInfo;                 /* Event Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkEvntInfo)
   if (pEvntInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pEvntInfo->evntPresResInd,mBuf); 
      /* event presentation restriction indicators */
      CMCHKPK(cmPkTknU8,&pEvntInfo->evntInd,mBuf); 
      /* event indicators */
   }
   CMCHKPK(cmPkElmtHdr,&pEvntInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkEvntInfo */


/*
*
*       Fun:   siPkFacInd
*
*       Desc:  This function packs the "FacInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkFacInd
(
SiFacInd *pFacInd,                    /* Facility Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkFacInd(pFacInd,mBuf)
SiFacInd *pFacInd;                     /* Facility Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkFacInd)
   if (pFacInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pFacInd->facInd,mBuf); 
      /* facility indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pFacInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkFacInd */


/*
*
*       Fun:   siPkFwdCallInd
*
*       Desc:  This function packs the "FwdCallInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkFwdCallInd
(
SiFwdCallInd *pFwdCallInd,            /* Forward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkFwdCallInd(pFwdCallInd,mBuf)
SiFwdCallInd *pFwdCallInd;             /* Forward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implement */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SI_ANSILNP
   bitVector |= SIT_ANSILNP_BIT;
#endif /* SI_ANSILNP */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkFwdCallInd)
   if (pFwdCallInd->eh.pres)
   {
#ifdef SI_ANSILNP
      CMCHKPK(cmPkTknU8,&pFwdCallInd->transCallNInd,mBuf);
      /* Translated called number indicator */
#endif /* SI_ANSILNP */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->sccpMethInd,mBuf); 
      /* SCCP method indicat */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->isdnAccInd,mBuf); 
      /* ISDN access indicat */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->isdnUsrPrtPrfInd,mBuf);
      /* ISDN User Part preference indicator */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->isdnUsrPrtInd,mBuf); 
      /* ISDN User Part indicator */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->end2EndInfoInd,mBuf); 
      /* end to end information indicator */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->intInd,mBuf); 
      /* interworking indictr*/
      CMCHKPK(cmPkTknU8,&pFwdCallInd->end2EndMethInd,mBuf); 
      /* end to end method indicator */
      CMCHKPK(cmPkTknU8,&pFwdCallInd->natIntCallInd,mBuf); 
      /* National/International Call Indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pFwdCallInd->eh,mBuf); 
   /* element header */
   /* sit_c_001.main_15, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU32, bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkFwdCallInd */


/*
*
*       Fun:   siPkInfoInd
*
*       Desc:  This function packs the "InfoInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkInfoInd
(
SiInfoInd *pInfoInd,                  /* Information Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkInfoInd(pInfoInd,mBuf)
SiInfoInd *pInfoInd;                   /* Information Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkInfoInd)
   if (pInfoInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pInfoInd->spare,mBuf); 
      /* spare (insure we get second octet) */
      CMCHKPK(cmPkTknU8,&pInfoInd->solInfoInd,mBuf); 
      /* solicitation info indicator */
      CMCHKPK(cmPkTknU8,&pInfoInd->chrgInfoRespInd,mBuf); 
      /* charge information response indicator */
      CMCHKPK(cmPkTknU8,&pInfoInd->cgPtyCatRespInd,mBuf); 
      /* calling party category response ind. */
      CMCHKPK(cmPkTknU8,&pInfoInd->holdProvInd,mBuf); 
      /* hold provided indicator */
      CMCHKPK(cmPkTknU8,&pInfoInd->cgPtyAddrRespInd,mBuf); 
      /* calling party address response ind. */
   }
   CMCHKPK(cmPkElmtHdr,&pInfoInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkInfoInd */

#if SS7_ANS88

/*
*
*       Fun:   siPkInfoIndA
*
*       Desc:  This function packs the "InfoIndA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkInfoIndA
(
SiInfoIndA *pInfoIndA,                /* Information Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkInfoIndA(pInfoIndA,mBuf)
SiInfoIndA *pInfoIndA;                 /* Information Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkInfoIndA)
   if (pInfoIndA->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pInfoIndA->indexRspInd,mBuf); 
      /* spare (insure we get second octet) */
      CMCHKPK(cmPkTknU8,&pInfoIndA->redirAddrRspIndb,mBuf); 
      /* solicitation info indicator */
      CMCHKPK(cmPkTknU8,&pInfoIndA->redirAddrRspInda,mBuf); 
      /* solicitation info indicator */
      CMCHKPK(cmPkTknU8,&pInfoIndA->chrgInfoRespInd,mBuf); 
      /* charge information response indicator */
      CMCHKPK(cmPkTknU8,&pInfoIndA->cgPtyCatRespInd,mBuf); 
      /* calling party categ response ind. */
      CMCHKPK(cmPkTknU8,&pInfoIndA->connAddrRspInd,mBuf); 
      /* hold provided indicator */
      CMCHKPK(cmPkTknU8,&pInfoIndA->cgPtyAddrRespInd,mBuf); 
      /* calling party address response ind. */
   }
   CMCHKPK(cmPkElmtHdr,&pInfoIndA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkInfoIndA */

#endif

/*
*
*       Fun:   siPkInfoReqInd
*
*       Desc:  This function packs the "InfoReqInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkInfoReqInd
(
SiInfoReqInd *pInfoReqInd,            /* Information Request Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkInfoReqInd(pInfoReqInd,mBuf)
SiInfoReqInd *pInfoReqInd;             /* Information Request Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkInfoReqInd)
   if (pInfoReqInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pInfoReqInd->spare,mBuf); 
      /* spare (insure second octet...) */
      CMCHKPK(cmPkTknU8,&pInfoReqInd->malCaIdReqInd,mBuf); 
      /* malicious call id request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqInd->chrgInfoReqInd,mBuf); 
      /* charge information request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqInd->cgPtyCatReqInd,mBuf); 
      /* calling party category request ind. */
      CMCHKPK(cmPkTknU8,&pInfoReqInd->holdingInd,mBuf); 
      /* holding indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqInd->cgPtyAdReqInd,mBuf); 
      /* calling party address request ind. */
   }   
   CMCHKPK(cmPkElmtHdr,&pInfoReqInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkInfoReqInd */

#if SS7_ANS88

/*
*
*       Fun:   siPkInfoReqIndA
*
*       Desc:  This function packs the "InfoReqIndA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkInfoReqIndA
(
SiInfoReqIndA *pInfoReqIndA,          /* Information Request Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkInfoReqIndA(pInfoReqIndA,mBuf)
SiInfoReqIndA *pInfoReqIndA;           /* Information Request Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkInfoReqIndA)
   if (pInfoReqIndA->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->holdingInd,mBuf); 
      /* spare (insure second octet...) */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->malCaIdReqInd,mBuf); 
      /* malicious call id request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->indexReqInd,mBuf); 
      /* malicious call id request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->redirAddrReqInd,mBuf); 
      /* malicious call id request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->chrgInfoReqInd,mBuf); 
      /* charge information request indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->cgPtyCatReqInd,mBuf); 
      /* calling party categ request ind. */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->connAddrReqInd,mBuf); 
      /* holding indicator */
      CMCHKPK(cmPkTknU8,&pInfoReqIndA->cgPtyAdReqInd,mBuf); 
      /* calling party address request ind. */
   }
   CMCHKPK(cmPkElmtHdr,&pInfoReqIndA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkInfoReqIndA */

#endif

/*
*
*       Fun:   siPkNatConInd
*
*       Desc:  This function packs the "NatConInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkNatConInd
(
SiNatConInd *pNatConInd,              /* Nature of Connection Indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkNatConInd(pNatConInd,mBuf)
SiNatConInd *pNatConInd;               /* Nature of Connection Indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNatConInd)
   if (pNatConInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNatConInd->echoCntrlDevInd,mBuf); 
      /* echo control device indicator */
      CMCHKPK(cmPkTknU8,&pNatConInd->contChkInd,mBuf); 
      /* continuity check indicator */
      CMCHKPK(cmPkTknU8,&pNatConInd->satInd,mBuf); 
      /* Satellite Indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pNatConInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNatConInd */


/*
*
*       Fun:   siPkOpFwdCalInd
*
*       Desc:  This function packs the "OpFwdCalInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOpFwdCalInd
(
SiOpFwdCalInd *pOpFwdCalInd,          /* Optional Forward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOpFwdCalInd(pOpFwdCalInd,mBuf)
SiOpFwdCalInd *pOpFwdCalInd;           /* Optional Forward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOpFwdCalInd)
   if (pOpFwdCalInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOpFwdCalInd->conLineIdReqInd,mBuf); 
      /* Connected line identity request ind */
      CMCHKPK(cmPkTknU8,&pOpFwdCalInd->simpleSegmInd,mBuf); 
      /* Simple segmentation indicator */
      CMCHKPK(cmPkTknU8,&pOpFwdCalInd->clsdUGrpCaInd,mBuf); 
      /* closed user group call indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOpFwdCalInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOpFwdCalInd */

#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)

/*
*
*       Fun:   siPkOpFwdCalIndQ
*
*       Desc:  This function packs the "OpFwdCalInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOpFwdCalIndQ
(
SiOpFwdCalIndQ *pOpFwdCalIndQ,        /* Optional Forward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOpFwdCalIndQ(pOpFwdCalIndQ,mBuf)
SiOpFwdCalIndQ *pOpFwdCalIndQ;         /* Optional Forward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOpFwdCalIndQ)
   if (pOpFwdCalIndQ->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndQ->connAddrReqInd1,mBuf); 
      /* connected addr request indic */
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndQ->clsdUGrpCaInd,mBuf); 
      /* closed user group call indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOpFwdCalIndQ->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOpFwdCalIndQ */
#endif

#if SS7_ANS88

/*
*
*       Fun:   siPkOpFwdCalIndA
*
*       Desc:  This function packs the "OpFwdCalInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOpFwdCalIndA
(
SiOpFwdCalIndA *pOpFwdCalIndA,        /* Optional Forward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOpFwdCalIndA(pOpFwdCalIndA,mBuf)
SiOpFwdCalIndA *pOpFwdCalIndA;         /* Optional Forward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOpFwdCalIndA)
   if (pOpFwdCalIndA->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndA->connAddrReqInd1,mBuf); 
      /* connected addr request indic */
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndA->callgPtyNumIncomInd,mBuf);
      /* calling party number incompl ind. */
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndA->ccbsCallInd,mBuf); 
      /* CCBS call indicator */
      CMCHKPK(cmPkTknU8,&pOpFwdCalIndA->clsdUGrpCaInd,mBuf); 
      /* closed user group call indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOpFwdCalIndA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOpFwdCalIndA */
#endif


/*
*
*       Fun:   siPkOptBckCalInd
*
*       Desc:  This function packs the "OptBckCalInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOptBckCalInd
(
SiOptBckCalInd *pOptBckCalInd,        /* Optional Backward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOptBckCalInd(pOptBckCalInd,mBuf)
SiOptBckCalInd *pOptBckCalInd;         /* Optional Backward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOptBckCalInd)
   if (pOptBckCalInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->usrNetIneractInd,mBuf);
      /* user-network inter-action indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->netExcDelInd,mBuf);
      /* Network excessive delay indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->mlppUserInd,mBuf);
      /* MLPP User indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->simpleSegmInd,mBuf);
      /* Simple segmentation indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->caFwdMayOcc,mBuf); 
      /* call forwarding may occur indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalInd->inbndInfoInd,mBuf); 
      /* in-band information indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOptBckCalInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOptBckCalInd */

#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)

/*
*
*       Fun:   siPkOptBckCalIndQ
*
*       Desc:  This function packs the "OptBckCalIndQ" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOptBckCalIndQ
(
SiOptBckCalIndQ *pOptBckCalIndQ,      /* Optional Backward Call Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOptBckCalIndQ(pOptBckCalIndQ,mBuf)
SiOptBckCalIndQ *pOptBckCalIndQ;       /* Optional Backward Call Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOptBckCalIndQ)
   if (pOptBckCalIndQ->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOptBckCalIndQ->caFwdMayOcc,mBuf); 
      /* call forwarding may occur indicator */
      CMCHKPK(cmPkTknU8,&pOptBckCalIndQ->inbndInfoInd,mBuf); 
      /* in-band information indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOptBckCalIndQ->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOptBckCalIndQ */
#endif  


/*
*
*       Fun:   siPkOrigCdNum
*
*       Desc:  This function packs the "OrigCdNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOrigCdNum
(
SiOrigCdNum *pOrigCdNum,              /* Original Called Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOrigCdNum(pOrigCdNum,mBuf)
SiOrigCdNum *pOrigCdNum;               /* Original Called Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOrigCdNum)
   if (pOrigCdNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pOrigCdNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pOrigCdNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pOrigCdNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      /* sit_c_001.main_15, ADDED: added packing for scrInd */
      CMCHKPK(cmPkTknU8,&pOrigCdNum->scrInd,mBuf); 
      /* screening indicator */
      CMCHKPK(cmPkTknU8,&pOrigCdNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pOrigCdNum->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOrigCdNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOrigCdNum */


/*
*
*       Fun:   siPkPassAlng
*
*       Desc:  This function packs the "PassAlng" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkPassAlng
(
SiPassAlng *pPassAlng,                /* Pass Along */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkPassAlng(pPassAlng,mBuf)
SiPassAlng *pPassAlng;                 /* Pass Along */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkPassAlng)
   if (pPassAlng->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pPassAlng->passAlng,mBuf); 
      /* pass along */
   }
   CMCHKPK(cmPkElmtHdr,&pPassAlng->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPassAlng */


/*
*
*       Fun:   siPkRangStat
*
*       Desc:  This function packs the "RangStat" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRangStat
(
SiRangStat *pRangStat,                /* Range and Status */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRangStat(pRangStat,mBuf)
SiRangStat *pRangStat;                 /* Range and Status */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRangStat)
   if (pRangStat->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pRangStat->status,mBuf); 
      /* status */
      CMCHKPK(cmPkTknU8,&pRangStat->range,mBuf); 
      /* range */
   }
   CMCHKPK(cmPkElmtHdr,&pRangStat->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRangStat */


/*
*
*       Fun:   siPkRedirgNum
*
*       Desc:  This function packs the "RedirgNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRedirgNum
(
SiRedirNum *pRedirgNum,               /* Redirection Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRedirgNum(pRedirgNum,mBuf)
SiRedirNum *pRedirgNum;                /* Redirection Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRedirgNum)
   if (pRedirgNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pRedirgNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pRedirgNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pRedirgNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pRedirgNum->scrInd,mBuf); 
      /* screening ind. */
      CMCHKPK(cmPkTknU8,&pRedirgNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pRedirgNum->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pRedirgNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirgNum */


/*
*
*       Fun:   siPkRedirInfo
*
*       Desc:  This function packs the "RedirInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRedirInfo
(
SiRedirInfo *pRedirInfo,              /* Redirection Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRedirInfo(pRedirInfo,mBuf)
SiRedirInfo *pRedirInfo;               /* Redirection Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRedirInfo)
   if (pRedirInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pRedirInfo->redirReas,mBuf); 
      /* redirection reason */
      CMCHKPK(cmPkTknU8,&pRedirInfo->redirCnt,mBuf); 
      /* redirection count */
      CMCHKPK(cmPkTknU8,&pRedirInfo->origRedirReas,mBuf); 
      /* original redirection reason */
      CMCHKPK(cmPkTknU8,&pRedirInfo->redirInd,mBuf); 
      /* redirection indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pRedirInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirInfo */


#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
/*
*
*       Fun:   siPkRedirNum
*
*       Desc:  This function packs the "RedirNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRedirNum
(
SiRedirNum *pRedirNum,                /* Redirection Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRedirNum(pRedirNum,mBuf)
SiRedirNum *pRedirNum;                 /* Redirection Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRedirNum)
   if (pRedirNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pRedirNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pRedirNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pRedirNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKPK(cmPkTknU8,&pRedirNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pRedirNum->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pRedirNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirNum */

#endif /* SS7_ANS88 */

/*
*
*       Fun:   siPkSigPointCode
*
*       Desc:  This function packs the "SigPointCode" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSigPointCode
(
SiSigPointCode *pSigPointCode,        /* Signalling Point Code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSigPointCode(pSigPointCode,mBuf)
SiSigPointCode *pSigPointCode;         /* Signalling Point Code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSigPointCode)
   if (pSigPointCode->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pSigPointCode->sigPointCode,mBuf); 
      /* signalling pnt code */
   }
   CMCHKPK(cmPkElmtHdr,&pSigPointCode->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSigPointCode */

/* si034.220: Addition - SS7_CHINA flag */
#if (SS7_ANS88 || SS7_CHINA)

/*
*
*       Fun:   siPkSigPointCodeA
*
*       Desc:  This function packs the "SigPointCodeA" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSigPointCodeA
(
SiSigPointCodeA *pSigPointCodeA,      /* Signalling Point Code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSigPointCodeA(pSigPointCodeA,mBuf)
SiSigPointCodeA *pSigPointCodeA;       /* Signalling Point Code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSigPointCodeA)
   if (pSigPointCodeA->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pSigPointCodeA->sigPointCode,mBuf); 
      /* signalling pnt cde */
   }
   CMCHKPK(cmPkElmtHdr,&pSigPointCodeA->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSigPointCodeA */

#endif

/*
*
*       Fun:   siPkSusResInd
*
*       Desc:  This function packs the "SusResInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSusResInd
(
SiSusResInd *pSusResInd,              /* Suspend/Resume indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSusResInd(pSusResInd,mBuf)
SiSusResInd *pSusResInd;               /* Suspend/Resume indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSusResInd)
   if (pSusResInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pSusResInd->susResInd,mBuf); 
      /* suspend/resume indicats */
   }
   CMCHKPK(cmPkElmtHdr,&pSusResInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSusResInd */


/*
*
*       Fun:   siPkTranNetSel
*
*       Desc:  This function packs the "TranNetSel" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkTranNetSel
(
SiTranNetSel *pTranNetSel,            /* Transit Network Selection */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkTranNetSel(pTranNetSel,mBuf)
SiTranNetSel *pTranNetSel;             /* Transit Network Selection */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkTranNetSel)
   if (pTranNetSel->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pTranNetSel->netId,mBuf); 
      /* network identification */
      CMCHKPK(cmPkTknU8,&pTranNetSel->oddEven,mBuf); 
      /* odd/even */
      CMCHKPK(cmPkTknU8,&pTranNetSel->typNetId,mBuf); 
      /* type of network identification */
      CMCHKPK(cmPkTknU8,&pTranNetSel->netIdPln,mBuf); 
      /* network id plan */
   }
   CMCHKPK(cmPkElmtHdr,&pTranNetSel->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkTranNetSel */

/* si037.220 : Addeded Transit network selection fields for ANSI */

#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)					 

/*
*
*       Fun:   siPkTranNetSel1
*
*       Desc:  This function packs the "TranNetSel" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkTranNetSel1
(
SiTranNetSel1 *pTranNetSel1,            /* Transit Network Selection */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkTranNetSel1(pTranNetSel1,mBuf)
SiTranNetSel1 *pTranNetSel1;             /* Transit Network Selection */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkTranNetSel1)
   if (pTranNetSel1->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pTranNetSel1->CirCd,mBuf); 
      /* Circuit Code */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->dig3,mBuf); 
      /* Digit 3 */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->dig2,mBuf); 
      /* Digit 2 */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->dig1,mBuf); 
      /* Digit 1 */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->oddEven,mBuf); 
      /* odd/even */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->typNetId,mBuf); 
      /* type of network identification */
      CMCHKPK(cmPkTknU8,&pTranNetSel1->netIdPln,mBuf); 
      /* network id plan */
   }
   CMCHKPK(cmPkElmtHdr,&pTranNetSel1->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkTranNetSel1 */
#endif 
#endif 


/*
*
*       Fun:   siPkTxMedReq
*
*       Desc:  This function packs the "TxMedReq" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkTxMedReq
(
SiTxMedReq *pTxMedReq,                /* Transmission Medium Requirement */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkTxMedReq(pTxMedReq,mBuf)
SiTxMedReq *pTxMedReq;                 /* Transmission Medium Requirement */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkTxMedReq)
   if (pTxMedReq->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pTxMedReq->trMedReq,mBuf); 
      /* tranmission medium requirement */
   }
   CMCHKPK(cmPkElmtHdr,&pTxMedReq->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkTxMedReq */


/*
*
*       Fun:   siPkUsr2UsrInd
*
*       Desc:  This function packs the "Usr2UsrInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkUsr2UsrInd
(
SiUsr2UsrInd *pUsr2UsrInd,            /* User to User indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkUsr2UsrInd(pUsr2UsrInd,mBuf)
SiUsr2UsrInd *pUsr2UsrInd;             /* User to User indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkUsr2UsrInd)
   if (pUsr2UsrInd->eh.pres)
   {
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
      CMCHKPK(cmPkTknU8,&pUsr2UsrInd->spare,mBuf); 
#endif
      CMCHKPK(cmPkTknU8,&pUsr2UsrInd->serv3,mBuf); 
      /* service 3 */
      CMCHKPK(cmPkTknU8,&pUsr2UsrInd->serv2,mBuf); 
      /* service 2 */
      CMCHKPK(cmPkTknU8,&pUsr2UsrInd->serv1,mBuf); 
      /* service 1 */
      CMCHKPK(cmPkTknU8,&pUsr2UsrInd->type,mBuf); 
      /* type */
   }
   CMCHKPK(cmPkElmtHdr,&pUsr2UsrInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkUsr2UsrInd */


/*
*
*       Fun:   siPkUsr2UsrInfo
*
*       Desc:  This function packs the "Usr2UsrInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkUsr2UsrInfo
(
SiUsr2UsrInfo *pUsr2UsrInfo,          /* User to user information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkUsr2UsrInfo(pUsr2UsrInfo,mBuf)
SiUsr2UsrInfo *pUsr2UsrInfo;           /* User to user information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkUsr2UsrInfo)
   if (pUsr2UsrInfo->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pUsr2UsrInfo->info,mBuf); 
      /* user to user info */
   }
   CMCHKPK(cmPkElmtHdr,&pUsr2UsrInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkUsr2UsrInfo */


/*
*
*       Fun:   siPkSiUsrServInfo
*
*       Desc:  This function packs the "UsrServInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiUsrServInfo
(
SiUsrServInfo *pUsrServInfo,          /* User Service Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSiUsrServInfo(pUsrServInfo,mBuf)
SiUsrServInfo *pUsrServInfo;           /* User Service Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSiUsrServInfo)
   if (pUsrServInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pUsrServInfo->lyr3Ident,mBuf); 
      /* layer 3 identity */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->usrInfLyr3Prot,mBuf); 
      /* user information layer 3 protocol */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->lyr2Ident,mBuf); 
      /* layer 2 identity */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->usrInfLyr2Prot,mBuf); 
      /* user information layer 2 protocol */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->duplexMode,mBuf); 
      /* duplex mode */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->modemType,mBuf); 
      /* modem type */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->nmbStpBits,mBuf); 
      /* number of stop bits */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->nmbDatBits,mBuf); 
      /* number of data bits excluding parity bit*/
      CMCHKPK(cmPkTknU8,&pUsrServInfo->parity,mBuf); 
      /* parity information */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->hdrNohdr,mBuf); 
      /* rate adaption header/no header */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->multiFrm,mBuf); 
      /* multiple frame establishment supprt*/
      CMCHKPK(cmPkTknU8,&pUsrServInfo->mode,mBuf); 
      /* mode of operation */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->logLnkNegot,mBuf); 
      /* logical link identifr negotiation */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->asgnrAsgne,mBuf); 
      /* assignor/assignee */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->inOutBandNeg,mBuf); 
      /* inband/outband negotiation */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->interRate,mBuf); 
      /* intermediate rate */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->niClkOnTx,mBuf); 
      /* network independent clock on transmissn */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->niClkOnRx,mBuf); 
      /* network independent clock on reception */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->flcOnTx,mBuf); 
      /* flow control on transmission */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->flcOnRx,mBuf); 
      /* flow control on reception */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->syncAsync,mBuf); 
      /* synchronous/asynch */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->negot,mBuf); 
      /* negotiation */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->usrRate,mBuf); 
      /* user rate */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->lyr1Ident,mBuf); 
      /* layer 1 identity */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->usrInfLyr1Prot,mBuf); 
      /* usr information layer 1 protocol */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->rateMultiplier,mBuf); 
      /* rate multiplier */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->symmetry,mBuf); 
      /* symmetry */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->infoTranRate1,mBuf); 
      /* information transfer rate */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->chanStruct,mBuf); 
      /* structure */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->config,mBuf); 
      /* configuration */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->establish,mBuf); 
      /* establishment */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->tranMode,mBuf); 
      /* transfer mode */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->infoTranRate0,mBuf); 
      /* information transfer rate */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->cdeStand,mBuf); 
      /* coding standard */
      CMCHKPK(cmPkTknU8,&pUsrServInfo->infoTranCap,mBuf); 
      /* information transfer capability */
   }
   CMCHKPK(cmPkElmtHdr,&pUsrServInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiUsrServInfo */


/*
*
*       Fun:   siPkSiUsrTSrvInfo
*
*       Desc:  This function packs the "UsrTeleSrvInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiUsrTSrvInfo
(
SiUsrTSrvInfo *pUsrTSrvInfo,          /* User Service Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSiUsrTSrvInfo(pUsrTSrvInfo,mBuf)
SiUsrTSrvInfo *pUsrTSrvInfo;           /* User Service Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSiUsrTSrvInfo)
   if (pUsrTSrvInfo->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pUsrTSrvInfo->extHighLyr,mBuf); 
      /* extended high layer characteristics */
      CMCHKPK(cmPkTknU8,&pUsrTSrvInfo->highLyr,mBuf); 
      /* high layer characteristics */
      CMCHKPK(cmPkTknU8,&pUsrTSrvInfo->codeStd,mBuf); 
      /* coding standard */
      CMCHKPK(cmPkTknU8,&pUsrTSrvInfo->interp,mBuf); 
      /* interpretation */
      CMCHKPK(cmPkTknU8,&pUsrTSrvInfo->presMeth,mBuf); 
      /* presentation method */
   }
   CMCHKPK(cmPkElmtHdr,&pUsrTSrvInfo->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiUsrTSrvInfo */


/*
*
*       Fun:   siPkSiGenDigits
*
*       Desc:  This function packs the "GenDigits" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSiGenDigits
(
SiGenDigits *pGenDigits,              /* Generic Digits */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSiGenDigits(pGenDigits,mBuf)
SiGenDigits *pGenDigits;               /* Generic Digits */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSiGenDigits)
   if (pGenDigits->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pGenDigits->digits,mBuf); 
      /* digits */
      CMCHKPK(cmPkTknU8,&pGenDigits->encodeScheme,mBuf); 
      /* encoding scheme */
      CMCHKPK(cmPkTknU8,&pGenDigits->typeOfDigits,mBuf); 
      /* type of digits */
   }
   CMCHKPK(cmPkElmtHdr,&pGenDigits->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSiGenDigits */

#if (SS7_BELL || SS7_ANS95)

/*
*
*       Fun:   siPkGenName
*
*       Desc:  This function packs the "GenName" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkGenName
(
SiGenName *pGenName,                   /* Generic Name */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkGenName(pGenName, mBuf)
SiGenName *pGenName;                   /* Generic Name */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkGenName)
   if (pGenName->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pGenName->character,mBuf); 
      /* Character */

      CMCHKPK(cmPkTknU8,&pGenName->typeName,mBuf);
      /* type of name */

      CMCHKPK(cmPkTknU8,&pGenName->avail,mBuf); 
      /* availability */

      CMCHKPK(cmPkTknU8,&pGenName->present,mBuf); 
      /* presentation  */
   }
   CMCHKPK(cmPkElmtHdr,&pGenName->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkGenName */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_BELL || SS7_ANS95 || SS7_INDIA)

/*
*
*       Fun:   siPkHopCounter
*
*       Desc:  This function packs the "HopCounter" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkHopCounter
(
SiHopCounter *pHopCounter,             /* hop counter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkHopCounter(pHopCounter, mBuf)
SiHopCounter *pHopCounter;             /* hop counter  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkHopCounter)
   if (pHopCounter->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pHopCounter->hopCounter,mBuf);
      /* hop counter */

   }
   CMCHKPK(cmPkElmtHdr,&pHopCounter->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkHopCounter */
#endif
#if (SS7_BELL || SS7_ITU2000)

/*
*
*       Fun:   siPkRedirCap
*
*       Desc:  This function packs the "RedirCap" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRedirCap
(
SiRedirCap *pRedirCap,                 /* redirect capability */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRedirCap(pRedirCap, mBuf)
SiRedirCap *pRedirCap;                 /* redirect capability  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRedirCap)
   if (pRedirCap->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pRedirCap->redirCap, mBuf);
      /* redirect capability */

   }
   CMCHKPK(cmPkElmtHdr,&pRedirCap->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirCap */


/*
*
*       Fun:   siPkRedirCntr
*
*       Desc:  This function packs the "RedirCntr" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkRedirCntr
(
SiRedirCntr *pRedirCntr,               /* redirect counter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkRedirCntr(pRedirCntr, mBuf)
SiRedirCntr *pRedirCntr;               /* redirect counter  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkRedirCntr)
   if (pRedirCntr->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pRedirCntr->redirCntr, mBuf);
      /* redirect counter */

   }
   CMCHKPK(cmPkElmtHdr,&pRedirCntr->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirCntr */

#endif /* SS7_BELL */

#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)

/*
*
*       Fun:   siPkGenAddr
*
*       Desc:  This function packs the "GenAddr" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkGenAddr
(
SiGenAddr *pGenAddr,                  /* Generic Address */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkGenAddr(pGenAddr,mBuf)
SiGenAddr *pGenAddr;                   /* Generic Address */
Buffer *mBuf;                          /* message buffer */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup bit vector implement */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector = 0x00;
#ifdef SI_ANSILNP
   bitVector |= SIT_ANSILNP_BIT;
#endif /* SI_ANSILNP */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siPkGenAddr)
   if (pGenAddr->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pGenAddr->addrSig,mBuf); 
      /* addressing signal */
#ifdef SI_ANSILNP
      CMCHKPK(cmPkTknU8,&pGenAddr->testInd,mBuf);
      /* test indicator */
#endif /* SI_ANSILNP */
      CMCHKPK(cmPkTknU8,&pGenAddr->numPlan1,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pGenAddr->presRest,mBuf); 
      /* presentation restriction */
      CMCHKPK(cmPkTknU8,&pGenAddr->oddEven,mBuf); 
      /* odd / even address signal */
      CMCHKPK(cmPkTknU8,&pGenAddr->natAddr,mBuf); 
      /* nature of address indic */
      CMCHKPK(cmPkTknU8,&pGenAddr->typeOfAddr,mBuf); 
      /* type of address */
   }
   CMCHKPK(cmPkElmtHdr,&pGenAddr->eh,mBuf); 
   /* element header */
   /* sit_c_001.main_15, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU32, bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   RETVALUE(ROK);
} /* end of siPkGenAddr */
#endif /* (SS7_ANS92 || SS7_ANS95 || SS7_BELL) */


/*
*
*       Fun:   siPkNotifInd
*
*       Desc:  This function packs the "NotifInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkNotifInd
(
SiNotifInd *pNotifInd,                /* Notification Indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkNotifInd(pNotifInd,mBuf)
SiNotifInd *pNotifInd;                 /* Notification Indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNotifInd)
   if (pNotifInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNotifInd->notifInd,mBuf); 
      /* Notification Indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pNotifInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNotifInd */


/*
*
*       Fun:   siPkServiceAct
*
*       Desc:  This function packs the "ServiceAct" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkServiceAct
(
SiServiceAct *pServiceAct,            /* Service Activation */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkServiceAct(pServiceAct,mBuf)
SiServiceAct *pServiceAct;             /* Service Activation */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkServiceAct)
   if (pServiceAct->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pServiceAct->serviceAct,mBuf); 
      /* service activation */
   }
   CMCHKPK(cmPkElmtHdr,&pServiceAct->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkServiceAct */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_ITU2000)

/*
*
*       Fun:   siPkChargeNum
*
*       Desc:  This function packs the "ChargeNum" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkChargeNum
(
SiChargeNum *pChargeNum,              /* Charge Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkChargeNum(pChargeNum,mBuf)
SiChargeNum *pChargeNum;               /* Charge Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkChargeNum)
   if (pChargeNum->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pChargeNum->addrSig,mBuf); 
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pChargeNum->numPlan,mBuf); 
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pChargeNum->oddEven,mBuf); 
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pChargeNum->natAddr,mBuf); 
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pChargeNum->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkChargeNum */
#endif

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL) 

/*
*
*       Fun:   siPkOrigLineInf
*
*       Desc:  This function packs the "OrigLineInf" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkOrigLineInf
(
SiOrigLineInf *pOrigLineInf,          /* Originating Line Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOrigLineInf(pOrigLineInf,mBuf)
SiOrigLineInf *pOrigLineInf;           /* Originating Line Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOrigLineInf)
   if (pOrigLineInf->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pOrigLineInf->lineInfo,mBuf); 
      /* call forwarding may occur indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pOrigLineInf->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOrigLineInf */
#endif

#if SS7_ANS88

/*
*
*       Fun:   siPkIndex
*
*       Desc:  This function packs the "Index" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkIndex
(
SiIndex *pIndex,                      /* Index */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkIndex(pIndex,mBuf)
SiIndex *pIndex;                       /* Index */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkIndex)
   if (pIndex->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pIndex->index,mBuf); 
      /* call forwarding may occur ind */
   }
   CMCHKPK(cmPkElmtHdr,&pIndex->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkIndex */


/*
*
*       Fun:   siPkFacInfInd
*
*       Desc:  This function packs the "FacInfInd" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkFacInfInd
(
SiFacInfInd *pFacInfInd,              /* Facility Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkFacInfInd(pFacInfInd,mBuf)
SiFacInfInd *pFacInfInd;               /* Facility Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkFacInfInd)
   if (pFacInfInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pFacInfInd->facReqActInd,mBuf); 
      /* facility indicator */
      CMCHKPK(cmPkTknU8,&pFacInfInd->facReqEnqInd,mBuf); 
      /* facility indicator */
      CMCHKPK(cmPkTknU8,&pFacInfInd->callgPtyAnsInd,mBuf); 
      /* facility indicator */
      CMCHKPK(cmPkTknU8,&pFacInfInd->calldPtyFreeInd,mBuf); 
      /* facility indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pFacInfInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkFacInfInd */
#endif

#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)

/*
*
*       Fun:   siPkServiceCode
*
*       Desc:  This function packs the "SiServiceCode" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkServiceCode
(
SiServiceCode *pServiceCode,           /* Service code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkServiceCode(pServiceCode,mBuf)
SiServiceCode *pServiceCode;           /* Service code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkServiceCode)
   if (pServiceCode->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pServiceCode->sCode,mBuf); 
      /* service activation */
   }
   CMCHKPK(cmPkElmtHdr,&pServiceCode->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkServiceCode */


/*
*
*       Fun:   siPkBusinessGrp
*
*       Desc:  This function packs the "BusinessGrp" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkBusinessGrp
(
SiBusinessGrp *pBusinessGrp,          /* Business Group */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkBusinessGrp(pBusinessGrp,mBuf)
SiBusinessGrp *pBusinessGrp;           /* Business Group */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkBusinessGrp)
   if (pBusinessGrp->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pBusinessGrp->linePriv,mBuf); 
      /* line privileges */
      CMCHKPK(cmPkTknU16,&pBusinessGrp->subGrpIdent,mBuf); 
      /* sub-group identif */
      CMCHKPK(cmPkTknU32,&pBusinessGrp->busiGrpIdent,mBuf); 
      /* business group id */
      CMCHKPK(cmPkTknU8,&pBusinessGrp->attendStat,mBuf); 
      /* attendant status */
      CMCHKPK(cmPkTknU8,&pBusinessGrp->BGIDident,mBuf); 
      /* BGID identifier  */
      CMCHKPK(cmPkTknU8,&pBusinessGrp->linePrivInfInd,mBuf); 
      /* line privileges info ident. */
      CMCHKPK(cmPkTknU8,&pBusinessGrp->partySel,mBuf); 
      /* party selector */
   }
   CMCHKPK(cmPkElmtHdr,&pBusinessGrp->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkBusinessGrp */


/*
*
*       Fun:   siPkCarrierId
*
*       Desc:  This function packs the "CarrierId" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCarrierId
(
SiCarrierId *pCarrierId,              /* Carrier ID */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCarrierId(pCarrierId,mBuf)
SiCarrierId *pCarrierId;               /* Carrier ID */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCarrierId)
   if (pCarrierId->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCarrierId->CIDigit4,mBuf); 
      /* Network Id Digit 4 */
      CMCHKPK(cmPkTknU8,&pCarrierId->CIDigit3,mBuf); 
      /* Network Id Digit 3 */
      CMCHKPK(cmPkTknU8,&pCarrierId->CIDigit2,mBuf); 
      /* Network Id Digit 2 */
      CMCHKPK(cmPkTknU8,&pCarrierId->CIDigit1,mBuf); 
      /* Network Id Digit 1 */
      CMCHKPK(cmPkTknU8,&pCarrierId->typNetId2,mBuf); 
      /* type of network id */
      CMCHKPK(cmPkTknU8,&pCarrierId->netIdPln1,mBuf); 
      /* network id plan */
   }
   CMCHKPK(cmPkElmtHdr,&pCarrierId->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCarrierId */


/*
*
*       Fun:   siPkCarrierSelInf
*
*       Desc:  This function packs the "CarrierSelInf" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCarrierSelInf
(
SiCarrierSelInf *pCarrierSelInf,      /* Carrier Selection Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCarrierSelInf(pCarrierSelInf,mBuf)
SiCarrierSelInf *pCarrierSelInf;       /* Carrier Selection Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCarrierSelInf)
   if (pCarrierSelInf->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCarrierSelInf->carrierSelInf,mBuf); 
      /* Carrier Selection Information  */
   }
   CMCHKPK(cmPkElmtHdr,&pCarrierSelInf->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCarrierSelInf */


/*
*
*       Fun:   siPkEgress
*
*       Desc:  This function packs the "Egress" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkEgress
(
SiEgress *pEgress,                    /* Egress Service */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkEgress(pEgress,mBuf)
SiEgress *pEgress;                     /* Egress Service */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkEgress)
   if (pEgress->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pEgress->egress,mBuf); 
      /* egress */
   }
   CMCHKPK(cmPkElmtHdr,&pEgress->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkEgress */


/*
*
*       Fun:   siPkJurisInf
*
*       Desc:  This function packs the "JurisInf" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkJurisInf
(
SiJurisInf *pJurisInf,                /* Jurisdiction Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkJurisInf(pJurisInf,mBuf)
SiJurisInf *pJurisInf;                 /* Jurisdiction Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkJurisInf)
   if (pJurisInf->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig6,mBuf); 
      /* address signal 6 */
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig5,mBuf); 
      /* address signal 5 */
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig4,mBuf); 
      /* address signal 4 */
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig3,mBuf); 
      /* address signal 3 */
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig2,mBuf); 
      /* address signal 2 */
      CMCHKPK(cmPkTknU8,&pJurisInf->addrSig1,mBuf); 
      /* address signal 1 */
   }
   CMCHKPK(cmPkElmtHdr,&pJurisInf->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkJurisInf */


/*
*
*       Fun:   siPkNetTransport
*
*       Desc:  This function packs the "NetTransport" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkNetTransport
(
SiNetTransport *pNetTransport,        /* Network Transport */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkNetTransport(pNetTransport,mBuf)
SiNetTransport *pNetTransport;         /* Network Transport */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNetTransport)
   if (pNetTransport->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNetTransport->netTransport,mBuf); 
      /* network transport */
   }
   CMCHKPK(cmPkElmtHdr,&pNetTransport->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNetTransport */


/*
*
*       Fun:   siPkSpecProcReq
*
*       Desc:  This function packs the "SpecProcReq" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkSpecProcReq
(
SiSpecProcReq *pSpecProcReq,          /* Special Processing Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkSpecProcReq(pSpecProcReq,mBuf)
SiSpecProcReq *pSpecProcReq;           /* Special Processing Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkSpecProcReq)
   if (pSpecProcReq->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pSpecProcReq->specProcReq,mBuf); 
      /* specl proces request */
   }
   CMCHKPK(cmPkElmtHdr,&pSpecProcReq->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkSpecProcReq */


/*
*
*       Fun:   siPkTransReq
*
*       Desc:  This function packs the "TransReq" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkTransReq
(
SiTransReq *pTransReq,                /* Transaction Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkTransReq(pTransReq,mBuf)
SiTransReq *pTransReq;                 /* Transaction Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkTransReq)
   if (pTransReq->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pTransReq->SCCPAddr,mBuf); 
      /* SCCP address */
      CMCHKPK(cmPkTknU32,&pTransReq->transId,mBuf); 
      /* transaction id */
   }
   CMCHKPK(cmPkElmtHdr,&pTransReq->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkTransReq */

#endif /* SS7_ANS92 || SS7_ANS95 */


/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
/*
*
*       Fun:   siPkLoopPrvntInd
*
*       Desc:  This function packs the "Loop Prevention Indicator" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkLoopPrvntInd
(
SiLoopPrvntInd *pLoop,                   /* loop prevention indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkLoopPrvntInd(pLoop,mBuf)
SiLoopPrvntInd *pLoop;                   /* loop prevention indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkLoopPrvntInd)
   if (pLoop->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pLoop->loopPrvntType,mBuf); 
      /* loop prevention type */
      CMCHKPK(cmPkTknU8,&pLoop->loopPrvntRspInd,mBuf); 
      /* loop prevention response indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pLoop->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkLoopPrvntInd */

/*
*
*       Fun:   siPkCalTrnsfrRef
*
*       Desc:  This function packs the "Call Transfer Reference" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkCalTrnsfrRef
(
SiCallTRef *ptRef,                    /* call transfer reference */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCalTrnsfrRef(ptRef,mBuf)
SiCallTRef *ptRef;                     /* call transfer reference */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCalTrnsfrRef)
   if (ptRef->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&ptRef->callTrnsfr,mBuf); 
      /* call transfer reference */
   }
   CMCHKPK(cmPkElmtHdr,&ptRef->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCalTrnsfrRef */

#endif
#if (SS7_ETSI || SS7_FTZ)

/*
*
*       Fun:   siPkFreePhParam
*
*       Desc:  This function packs the "FreePhone Parmeter" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkFreePhParam
(
SiFreePhInd *pFreePhInd,              /* Freephone indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkFreePhParam(pFreePhInd,mBuf)
SiFreePhInd *pFreePhInd;               /* Freephone indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkFreePhParam)
   if (pFreePhInd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pFreePhInd->freePhInd,mBuf); 
      /* freephone ind */
   }
   CMCHKPK(cmPkElmtHdr,&pFreePhInd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkFreePhParam */



/*
*
*       Fun:   siPkCCBSParam
*
*       Desc:  This function packs the "CCBS Parmeter" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkCCBSParam
(
SiCcbsParam *pCCBSParam,              /* Freephone indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCCBSParam(pCCBSParam,mBuf)
SiCcbsParam *pCCBSParam;               /* Freephone indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCCBSParam)
   if (pCCBSParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCCBSParam->ccbsCallInd,mBuf); 
      /* CCBS ind */
   }
   CMCHKPK(cmPkElmtHdr,&pCCBSParam->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCCBSParam */

#endif /* (SS7_ETSI || SS7_FTZ) */

#if SS7_FTZ


/*
*
*       Fun:   siPkNaPaFF
*
*       Desc:  This function packs the "National Parameter FF" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaFF 
(
SiNaPaFF *pNaPaFF,             /* national parameter FF */
Buffer *mBuf,                  /* message buffer */
U8 evntType                    /* event type used as selector */
)
#else
PRIVATE S16 siPkNaPaFF (pNaPaFF,mBuf,evntType)
SiNaPaFF *pNaPaFF;             /* national parameter FF */
Buffer *mBuf;                  /* message buffer */
U8 evntType;                   /* event type used as selector */
#endif
{
   TRC3(siPkNaPaFF)
   if (pNaPaFF->eh.pres)
   {
      switch (evntType)
      {
         case EVTGTNANA:
            CMCHKPK(cmPkTknStr,&pNaPaFF->messg.inNANA.data,mBuf);
            /* undecoded data */
            break;
         case EVTGTIAM:
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inIAM.srvIndAddOct,mBuf);
            /* service indicator additional info octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inIAM.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inIAM.zoneInd,mBuf);
            /* zoning indicator */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inIAM.catphInd,mBuf);
            /* catastrophe indicator */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inIAM.natClgPtyCat,mBuf);
            /* national calling party category */
            break;
         case EVTGTANM:
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inANM.srvIndAddOct,mBuf);
            /* service indicator addtitional info octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inANM.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inANM.SINMeanInd,mBuf);
            /* SIN meaning indicator */
            break;
         case EVTGTFRQ:
            CMCHKPK(cmPkTknU32,&pNaPaFF->messg.inFRQ.cugIntCode,mBuf);
            /* closed user group interlock code */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inFRQ.cugCallInd,mBuf);
            /* closed user group call indicator */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inFRQ.trmSelCode,mBuf);
            /* terminal selection code */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inFRQ.srvIndAddOct,mBuf);
            /* service indicator addtitional info octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inFRQ.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inFRQ.facCode,mBuf);
            /* facility code */
            break;
         case EVTGTMLTP:
         case EVTGTCHG:
         case EVTGTFACD:
         case EVTGTFIN:
            CMCHKPK(cmPkTknU8,&pNaPaFF->messg.inMultMsg.multPurp,mBuf);
            /* multipurpouse code */
            break;
         default:
            RETVALUE(RFAILED);

      } /* end of switch evntType */
   }       /* end of if evntType */
   CMCHKPK(cmPkElmtHdr,&pNaPaFF->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaFF */


/*
*
*       Fun:   siPkNaPaSPV
*
*       Desc:  This function packs the "Nat. Par. for SPV " information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaSPV 
(
SiNaPaSPV *pNaPaSPV,                 /* National parameter for SPV */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaSPV (pNaPaSPV,mBuf)
SiNaPaSPV *pNaPaSPV;                  /* National parameter for SPV */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaSPV)
   if (pNaPaSPV->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNaPaSPV->naPaKDEInd,mBuf);
      /* KDE indicator */
      CMCHKPK(cmPkTknU8,&pNaPaSPV->naPaSPVSrvInd,mBuf);
      /* SPV service indicator */
      CMCHKPK(cmPkTknU8,&pNaPaSPV->naPaSPVInd,mBuf);
      /* SPV indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaSPV->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaSPV */


/*
*
*       Fun:   siPkNaPaFE
*
*       Desc:  This function packs the "National  Parmeter FE" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaFE 
(
SiNaPaFE *pNaPaFE,                   /* national parameter FE */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaFE (pNaPaFE,mBuf)
SiNaPaFE *pNaPaFE;                    /* national parameter FE */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaFE)

   if (pNaPaFE->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNaPaFE->disastrPriv,mBuf);
      /* Disaster Privilege */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaFE->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaFE */


/*
*
*       Fun:   siPkNaPaSSP
*
*       Desc:  This function packs the "Nat. Parameter for SSP" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaSSP 
(
SiNaPaSSP *pNaPaSSP,                 /* national parameter for SSP */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaSSP (pNaPaSSP,mBuf)
SiNaPaSSP *pNaPaSSP;                  /* national parameter for SSP */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaSSP)

   if (pNaPaSSP->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNaPaSSP->servTypRec,mBuf);
      /* service type recognition */
      CMCHKPK(cmPkTknU8,&pNaPaSSP->naPaTrnstInd,mBuf);
      /* transit indicator */
      CMCHKPK(cmPkTknU8,&pNaPaSSP->callDiver,mBuf);
      /* indic. for call diversion */
      CMCHKPK(cmPkTknU8,&pNaPaSSP->nmbFiveProt,mBuf);
      /* indic. for number 5 protection function */
      CMCHKPK(cmPkTknU8,&pNaPaSSP->stopSignMon,mBuf);
      /* indic. for stopping signalling monitoring */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaSSP->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaSSP */


/*
*
*       Fun:   siPkNaPaCdPNO
*
*       Desc:  This function packs the "Nat. Parmeter for CdPNO" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaCdPNO 
(
SiNaPaCdPNO *pNaPaCdPNO,             /* national parameter for CdPNO */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaCdPNO (pNaPaCdPNO,mBuf)
SiNaPaCdPNO *pNaPaCdPNO;              /* national parameter for CdPNO */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaCdPNO)
 
   if (pNaPaCdPNO->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNaPaCdPNO->addrSig,mBuf);
      /* Address Signal */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->innInd,mBuf);
      /* international network number indicator */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->numPlan,mBuf);
      /* numbering plan */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->presRest,mBuf);
      /* presentation restriction */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->screenInd,mBuf);
      /* screening indicator */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->oddEven,mBuf);
      /* odd or even */
      CMCHKPK(cmPkTknU8,&pNaPaCdPNO->natAddrInd,mBuf);
      /* nature of addresss indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaCdPNO->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaCdPNO */


/*
*
*       Fun:   siPkNaPaExTID
*
*       Desc:  This function packs the "Nat. Parameter for ExTID" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaExTID 
(
SiNaPaExTID *pNaPaExTID,             /* national parameter for ExTID */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaExTID (pNaPaExTID,mBuf)
SiNaPaExTID *pNaPaExTID;              /* national parameter for ExTID */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaExTID)

   if (pNaPaExTID->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNaPaExTID->incTrkId,mBuf);
      /* incoming trunk Id */
      CMCHKPK(cmPkTknU16,&pNaPaExTID->sigPntCde,mBuf);
      /* signalling point code */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaExTID->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaExTID */
#endif
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)

/*
*
*       Fun:   siPkNaPaChgPID
*
*       Desc:  This function packs the "Nat. Parameter for ChgPID" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaChgPID
(
SiNaPaChgPID *pNaPaChgPID,           /* national parameter for ChgPID */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaChgPID (pNaPaChgPID,mBuf)
SiNaPaChgPID *pNaPaChgPID;            /* national parameter for ChgPID */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaChgPID)
 
   if (pNaPaChgPID->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNaPaChgPID->naPaChgPtyId,mBuf);
      /* charged party identification */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaChgPID->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaChgPID */
#endif
#if SS7_FTZ

/*
*
*       Fun:   siPkNaPaCHGI
*
*       Desc:  This function packs the "Nat. Parameter for CHGI" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaCHGI 
(
SiNaPaCHGI *pNaPaCHGI,             /* national parameter for CHGI */
Buffer *mBuf                       /* message buffer */
)
#else
PRIVATE S16 siPkNaPaCHGI (pNaPaCHGI,mBuf)
SiNaPaCHGI *pNaPaCHGI;             /* national parameter for CHGI */
Buffer *mBuf;                      /* message buffer */
#endif
{
   TRC3(siPkNaPaCHGI)
 
   if (pNaPaCHGI->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNaPaCHGI->naPaRcptInf,mBuf);
      /* receipt information */
      CMCHKPK(cmPkTknU8,&pNaPaCHGI->naPaSeqNmb,mBuf);
      /* sequence number */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaCHGI->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaCHGI */


/*
*
*       Fun:   siPkFacIndInfor
*
*       Desc:  This function packs the "Facility indic. inf. Par." 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkFacIndInfor 
(
SiFacIndInfor *pFacIndInfor,         /* facility indicator information */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkFacIndInfor (pFacIndInfor,mBuf)
SiFacIndInfor *pFacIndInfor;          /* facility indicator information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkFacIndInfor)
 
   if (pFacIndInfor->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pFacIndInfor->cldPtyFreeInd,mBuf);
      /* called party free indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pFacIndInfor->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkFacIndInfor */


/*
*
*       Fun:   siPkNaPaTTZ
*
*       Desc:  This function packs the "Nat. Parameter for TTZ" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaTTZ 
(
SiNaPaTTZ *pNaPaTTZ,                 /* national parameter for TTZ */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNaPaTTZ (pNaPaTTZ,mBuf)
SiNaPaTTZ *pNaPaTTZ;                  /* national parameter for TTZ */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNaPaTTZ)
 
   if (pNaPaTTZ->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pNaPaTTZ->naPaTTZ,mBuf);
      /* national paramemeter for Tln-2-Tln sign. */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaTTZ->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaTTZ */


/*
*
*       Fun:   siPkNaPaUKK
*
*       Desc:  This function packs the "National Parameter for UKK"
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siPkNaPaUKK 
(
SiNaPaUKK *pNaPaUKK,          /* National Parameter for UKK */
Buffer *mBuf                  /* message buffer */
)
#else
PRIVATE S16 siPkNaPaUKK (pNaPaUKK,mBuf)
SiNaPaUKK *pNaPaUKK;          /* National Parameter for UKK */
Buffer *mBuf;                 /* message buffer */
#endif
{
   TRC3(siPkNaPaUKK)
 
   if (pNaPaUKK->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pNaPaUKK->servTypeRecogn,mBuf);
      /* service type recognition */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->clientRecognIndB,mBuf);
      /* client recognition Indicator 2nd octet */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->clientRecognIndA,mBuf);
      /* client recognition Indicator 1st octet */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->rstrRteAccCds,mBuf);
      /* restriction on route access codes */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->natCarRoutInd,mBuf);
      /* national carrier routing indicator */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->intCarRoutInd,mBuf);
      /* international carrier routing indicator */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->intSpZonInd,mBuf);
      /* international special zoning indicator */
      CMCHKPK(cmPkTknU8,&pNaPaUKK->intSpRoutInd,mBuf);
      /* international special routing indicator */
   }
   CMCHKPK(cmPkElmtHdr,&pNaPaUKK->eh,mBuf);
   /* element header */

   RETVALUE(ROK);
} /* end of siPkNaPaUKK */
#endif /* SS7_FTZ */

#if SS7_RUSSIA
/*
*
*       Fun:   siPkBillZoneNum
*
*       Desc:  This function packs the billing zone number
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkBillZoneNum 
(
SiBillZoneNum *pBillZoneNum,             /* Billing Zone Number */
Buffer *mBuf                             /* message buffer */
) 
#else
PRIVATE S16 siPkBillZoneNum(pBillZoneNum,mBuf)
SiBillZoneNum *pBillZoneNum;             /* Billing Zone Number */
Buffer *mBuf;                            /* message buffer */
#endif

{
   TRC2(siPkBillZoneNum)
   if (pBillZoneNum->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pBillZoneNum->billZoneNum,mBuf); 
      /* Billing Zone Number */
   }
   /* element header */   
   CMCHKPK(cmPkElmtHdr,&pBillZoneNum->eh,mBuf);
   RETVALUE(ROK);
} /* end of siPkBillZoneNum */
#endif /* SS7_RUSSIA */

#if SS7_NTT
/*
*
*       Fun:   siPkMsgAreaInfo
*
*       Desc:  This function packs the Message area information
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkMsgAreaInfo
(
SiMsgAreaInfo            *pkParam,     /* Message area information */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkMsgAreaInfo (pkParam, mBuf)
SiMsgAreaInfo            *pkParam;     /* Message area information */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkMsgAreaInfo)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr, &pkParam->msgAreaInfo, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkMsgAreaInfo */

/*
*
*       Fun:   siPkChrgInfo
*
*       Desc:  This function packs the Charge Information
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkChrgInfo
(
SiChrgInfo               *pkParam,     /* Charge Information */
SiChrgInfoType           *pcType,      /* Charge information type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkChrgInfo (pkParam, pcType, mBuf)
SiChrgInfo               *pkParam;     /* Charge Information */
SiChrgInfoType           *pcType;      /* Charge information type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkChrgInfo)

   if (pkParam->eh.pres) 
   {
      if ((pcType->eh.pres) && 
            (pcType->chrgInfoType.pres))
      {
         switch (pcType->chrgInfoType.val)
         {
            case CHRGINFTYP_INTAUTO:
               CMCHKPK(cmPkTknStr, &pkParam->p.chrg1.chrgData, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg1.chrgInfoIdctr, mBuf);
               break;
   
            case CHRGINFTYP_FLEXCHRG:
               CMCHKPK(cmPkTknStr, &pkParam->p.chrg2.billRateInfo, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.billRateIdctr, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.billCollMthd, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.chrgdUType, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.operType, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.operClass, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.activationId, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg2.signalElemType, mBuf);
               break;
   
            case CHRGINFTYP_FLEXINTER:
               CMCHKPK(cmPkTknStr, &pkParam->p.chrg3.billRateInfo, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.billRateIdctr, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.billCollMthd, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.chrgdUType, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.operType, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.operClass, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.activationId, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg3.signalElemType, mBuf);
               break;
   
            case CHRGINFTYP_NTTPHS:
               CMCHKPK(cmPkTknStr, &pkParam->p.chrg4.calledAreaInf, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg4.oddEvenIdctr, mBuf);
               CMCHKPK(cmPkTknU8, &pkParam->p.chrg4.signalElemType, mBuf);
               break;
   
            default:
               CMCHKPK(cmPkTknStrE, &pkParam->p.data.chrgInfo, mBuf);
               break;
   
         }
      }
      else
      {
         CMCHKPK(cmPkTknStrE, &pkParam->p.data.chrgInfo, mBuf);
      }
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkChrgInfo */

/*
*
*       Fun:   siPkChrgInfoType
*
*       Desc:  This function packs the Charge information type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkChrgInfoType
(
SiChrgInfoType           *pkParam,     /* Charge information type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkChrgInfoType (pkParam, mBuf)
SiChrgInfoType           *pkParam;     /* Charge information type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkChrgInfoType)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->chrgInfoType, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkChrgInfoType */

/*
*
*       Fun:   siPkChrgInfoDelay
*
*       Desc:  This function packs the Charge information delay
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkChrgInfoDelay
(
SiChrgInfoDelay          *pkParam,     /* Charge information delay */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkChrgInfoDelay (pkParam, mBuf)
SiChrgInfoDelay          *pkParam;     /* Charge information delay */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkChrgInfoDelay)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr, &pkParam->chrgInfoDelay, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);
 
   RETVALUE(ROK);
}   /* siPkChrgInfoDelay */

/*
*
*       Fun:   siPkSubsNumber
*
*       Desc:  This function packs the Subscriber number
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkSubsNumber
(
SiSubsNumber             *pkParam,     /* Subscriber number */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkSubsNumber (pkParam, mBuf)
SiSubsNumber             *pkParam;     /* Subscriber number */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkSubsNumber)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr, &pkParam->subsNumber, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkSubsNumber */

/*
*
*       Fun:   siPkReasProhibCllngNo
*
*       Desc:  This function packs the Reason for prohibiting cllng no
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkReasProhibCllngNo
(
SiReasProhibCllngNo      *pkParam,     /* Reason for prohibiting cllng no */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkReasProhibCllngNo (pkParam, mBuf)
SiReasProhibCllngNo      *pkParam;     /* Reason for prohibiting cllng no */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkReasProhibCllngNo)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->rpCllngNo, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkReasProhibCllngNo */

/*
*
*       Fun:   siPkSupplUserType
*
*       Desc:  This function packs the Supplementary user type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkSupplUserType
(
SiSupplUserType          *pkParam,     /* Supplementary user type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkSupplUserType (pkParam, mBuf)
SiSupplUserType          *pkParam;     /* Supplementary user type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkSupplUserType)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr, &pkParam->supplUserType, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkSupplUserType */

/*
*
*       Fun:   siPkCarrierInfoTrans
*
*       Desc:  This function packs the Carrier Information transfer
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkCarrierInfoTrans
(
SiCarrierInfoTrans       *pkParam,     /* Carrier Information transfer */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkCarrierInfoTrans (pkParam, mBuf)
SiCarrierInfoTrans       *pkParam;     /* Carrier Information transfer */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkCarrierInfoTrans)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr, &pkParam->carrierInfoTrans, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkCarrierInfoTrans */

/*
*
*       Fun:   siPkNwFuncType
*
*       Desc:  This function packs the Network function type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siPkNwFuncType
(
SiNwFuncType             *pkParam,     /* Network function type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siPkNwFuncType (pkParam, mBuf)
SiNwFuncType             *pkParam;     /* Network function type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siPkNwFuncType)

   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->nwFuncType, mBuf);
   }
   CMCHKPK(cmPkElmtHdr, &pkParam->eh, mBuf);

   RETVALUE(ROK);
}   /* siPkNwFuncType */

#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
/*
* 
*        Fun:   siPkCirAsgnMap
* 
*        Desc:  This function packs the "CirAsgnMap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCirAsgnMap
(
SiCirAsgnMap *pkParam,              /* circuit assignment map */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCirAsgnMap(pkParam,mBuf)
SiCirAsgnMap *pkParam;               /* circuit assignment map */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCirAsgnMap)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU32,&pkParam->mapFormat,mBuf);
      CMCHKPK(cmPkTknU8 ,&pkParam->mapType,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCirAsgnMap */
#endif

#if SS7_ANS95
/*
* 
*        Fun:   siPkOptrServicesInfo
* 
*        Desc:  This function packs the "OptrServicesInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkOptrServicesInfo
(
SiOptrServicesInfo *pkParam,              /* operator services information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkOptrServicesInfo(pkParam,mBuf)
SiOptrServicesInfo *pkParam;               /* operator services information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkOptrServicesInfo)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8 ,&pkParam->infoVal,mBuf);
      CMCHKPK(cmPkTknU8 ,&pkParam->infoType,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkOptrServicesInfo */
#endif

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
/*
* 
*        Fun:   siPkBackGVNS
* 
*        Desc:  This function packs the "BackGVNS" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkBackGVNS
(
SiBackGVNS *pkParam,              /* BackGVNS */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkBackGVNS(pkParam,mBuf)
SiBackGVNS *pkParam;               /* BackGVNS */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkBackGVNS)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->extInfo,mBuf);
      /* Extension Info */
      CMCHKPK(cmPkTknU8,&pkParam->termAccessInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkBackGVNS */

/*
* 
*        Fun:   siPkForwardGVNS
* 
*        Desc:  This function packs the "ForwardGVNS" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkForwardGVNS
(
SiForwardGVNS *pkParam,              /* ForwardGVNS */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkForwardGVNS(pkParam,mBuf)
SiForwardGVNS *pkParam;               /* ForwardGVNS */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkForwardGVNS)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->lenInd1,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->oddEven1,mBuf);
      CMCHKPK(cmPkTknStr,&pkParam->digits1,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->lenInd2,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->oddEven2,mBuf);
      CMCHKPK(cmPkTknStr,&pkParam->digits2,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->lenInd3,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->oddEven3,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->numPlan,mBuf);
      CMCHKPK(cmPkTknU8, &pkParam->natOfAddr,mBuf);
      CMCHKPK(cmPkTknStr,&pkParam->digits3,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkForwardGVNS */
#endif

/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)

/*
* 
*        Fun:   siPkCallDivTrtInd
* 
*        Desc:  This function packs the "CallDivTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCallDivTrtInd
(
SiCallDivTrtInd *pkParam,              /* call diversion treatment ind */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCallDivTrtInd(pkParam,mBuf)
SiCallDivTrtInd *pkParam;               /* call diversion treatment ind */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCallDivTrtInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->extInfo,mBuf);
      CMCHKPK(cmPkTknU8 ,&pkParam->callDivInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCallDivTrtInd */


/*
* 
*        Fun:   siPkCallOfferTrtInd
* 
*        Desc:  This function packs the "CallOfferTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCallOfferTrtInd
(
SiCallOfferTrtInd *pkParam,              /* call offering treatment ind */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCallOfferTrtInd(pkParam,mBuf)
SiCallOfferTrtInd *pkParam;               /* call offering treatment ind */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCallOfferTrtInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->extInfo,mBuf);
      /* Extension Info */
      CMCHKPK(cmPkTknU8,&pkParam->callOfferInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCallOfferTrtInd */


/*
* 
*        Fun:   siPkCallInNmb
* 
*        Desc:  This function packs the "CallInNmb" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCallInNmb
(
SiCallInNmb *pkParam,              /* call IN number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCallInNmb(pkParam,mBuf)
SiCallInNmb *pkParam;               /* call IN number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCallInNmb)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->addrSig,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->numPlan,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->presRest,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->scrInd,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->oddEven,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->natAddr,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCallInNmb */

/*
* 
*        Fun:   siPkCcss
* 
*        Desc:  This function packs the "Ccss" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCcss
(
SiCcss *pkParam,              /* Ccss */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCcss(pkParam,mBuf)
SiCcss *pkParam;               /* Ccss */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCcss)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->ccssCallInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCcss */

/*
* 
*        Fun:   siPkCollCallReq
* 
*        Desc:  This function packs the "CollCallReq" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCollCallReq
(
SiCollCallReq *pkParam,              /* collect call request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCollCallReq(pkParam,mBuf)
SiCollCallReq *pkParam;               /* collect call request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCollCallReq)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->collCallReqInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCollCallReq */

/*
* 
*        Fun:   siPkConfTrtInd
* 
*        Desc:  This function packs the "ConfTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkConfTrtInd
(
SiConfTrtInd *pkParam,              /* confrence treatment indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkConfTrtInd(pkParam,mBuf)
SiConfTrtInd *pkParam;               /* confrence treatment indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkConfTrtInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->extInfo,mBuf);
      /* Extension Info */
      CMCHKPK(cmPkTknU8,&pkParam->confAcceptInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkConfTrtInd */

/*
* 
*        Fun:   siPkCorrelationId
* 
*        Desc:  This function packs the "CorrelationId" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCorrelationId
(
SiCorrelationId *pkParam,              /* CorrelationId */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkCorrelationId(pkParam,mBuf)
SiCorrelationId *pkParam;               /* CorrelationId */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkCorrelationId)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->correlationId,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCorrelationId */

/*
* 
*        Fun:   siPkDisplayInfo
* 
*        Desc:  This function packs the "DisplayInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkDisplayInfo
(
SiDisplayInfo *pkParam,              /* display information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkDisplayInfo(pkParam,mBuf)
SiDisplayInfo *pkParam;               /* display information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkDisplayInfo)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->displayInfo,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkDisplayInfo */

/*
* 
*        Fun:   siPkNetMgmtControls
* 
*        Desc:  This function packs the "NetMgmtControls" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkNetMgmtControls
(
SiNetMgmtControls *pkParam,              /* network management controls */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkNetMgmtControls(pkParam,mBuf)
SiNetMgmtControls *pkParam;               /* network management controls */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkNetMgmtControls)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->extInfo,mBuf);
      /* Extension Info */
      CMCHKPK(cmPkTknU8,&pkParam->tmpAltRoutInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNetMgmtControls */

/*
* 
*        Fun:   siPkScfId
* 
*        Desc:  This function packs the "ScfId" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkScfId
(
SiScfId *pkParam,              /* ScfId */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkScfId(pkParam,mBuf)
SiScfId *pkParam;               /* ScfId */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkScfId)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->scfId,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkScfId */

/*
* 
*        Fun:   siPkUidActionInd
* 
*        Desc:  This function packs the "UidActionInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkUidActionInd
(
SiUidActionInd *pkParam,              /* UID action indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkUidActionInd(pkParam,mBuf)
SiUidActionInd *pkParam;               /* UID action indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkUidActionInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->t9InstInd,mBuf);
      /* T9 instruction ind. */
      CMCHKPK(cmPkTknU8, &pkParam->throughConnInstInd,mBuf);
      /* Through connection instruction ind. */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkUidActionInd */

/*
* 
*        Fun:   siPkUidCapInd
* 
*        Desc:  This function packs the "UidCapInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkUidCapInd
(
SiUidCapInd *pkParam,              /* UID capability indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkUidCapInd(pkParam,mBuf)
SiUidCapInd *pkParam;               /* UID capability indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkUidCapInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8, &pkParam->t9Ind,mBuf);
      /* T9 instruction ind. */
      CMCHKPK(cmPkTknU8, &pkParam->throughConnInd,mBuf);
      /* Through connection instruction ind. */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkUidCapInd */
#endif

/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
/*
* 
*        Fun:   siPkAppTransParam
* 
*        Desc:  This function packs the "AppTransParam" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkAppTransParam
(
SiAppTransParam *pkParam,              /* application transport parameter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siPkAppTransParam(pkParam,mBuf)
SiAppTransParam *pkParam;               /* application transport parameter */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siPkAppTransParam)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->encapAppInfo,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->slr,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->seqInd,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->apmSegInd,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->atii,mBuf);
#if SS7_ITU2000
      CMCHKPK(cmPkTknU8,&pkParam->appContextId1,mBuf);
#endif
      CMCHKPK(cmPkTknU8,&pkParam->appContextId,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkAppTransParam */
#endif

/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if SS7_ITU2000
/*
* 
*        Fun:   siPkCalgGeoLoc
* 
*        Desc:  This function packs the "CalgGeoLoc" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCalgGeoLoc
(
SiCalgGeoLoc *pkParam,                /* calling geodetic location parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkCalgGeoLoc(pkParam,mBuf)
SiCalgGeoLoc *pkParam;                /* calling geodetic location parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkCalgGeoLoc)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->shapeDescr,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->typeShape,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->presRest,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->scrnInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCalgGeoLoc */

/*
* 
*        Fun:   siPkCCNRPosInd
* 
*        Desc:  This function packs the "CCNRPosInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkCCNRPosInd
(
SiCCNRPosInd *pkParam,                /* CCNR Possible indicator parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkCCNRPosInd(pkParam,mBuf)
SiCCNRPosInd *pkParam;                /* CCNR Possible indicator parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkCCNRPosInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->ccnrPosInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCCNRPosInd */

/*
* 
*        Fun:   siPkNetRoutNum
* 
*        Desc:  This function packs the "NetRoutNum" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkNetRoutNum
(
SiNetRoutNum *pkParam,                /* Network Routing Number parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNetRoutNum(pkParam,mBuf)
SiNetRoutNum *pkParam;                /* Network Routing Number parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkNetRoutNum)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->addrSig,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->oddEven,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->numPlan,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->natAddrInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNetRoutNum */

/*
* 
*        Fun:   siPkPivotCap
* 
*        Desc:  This function packs the "PivotCap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkPivotCap
(
SiPivotCap *pkParam,                  /* Pivot CapabilityCCNR parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkPivotCap(pkParam,mBuf)
SiPivotCap *pkParam;                  /* Pivot Capability parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkPivotCap)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->iwToRedirInd,mBuf);
      CMCHKPK(cmPkTknU8,&pkParam->pivotPossInd,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPivotCap */

/*
* 
*        Fun:   siPkPivotCntr
* 
*        Desc:  This function packs the "PivotCntr" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkPivotCntr
(
SiPivotCntr *pkParam,                 /* Pivot Counter parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkPivotCntr(pkParam,mBuf)
SiPivotCntr *pkParam;                 /* Pivot Counter parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkPivotCntr)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->pivotCntr,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPivotCntr */

/*
* 
*        Fun:   siPkPivotRtgInd
* 
*        Desc:  This function packs the "PivotRtgInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkPivotRtgInd
(
SiPivotRtgInd *pkParam,               /* Pivot Routing parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkPivotRtgInd(pkParam,mBuf)
SiPivotRtgInd *pkParam;               /* Pivot Routing parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkPivotRtgInd)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->pivotRtg,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPivotRtgInd */

/*
* 
*        Fun:   siPkPivotRtgBkInfo
* 
*        Desc:  This function packs the "PivotRtgBkInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkPivotRtgBkInfo
(
SiPivotRtgBkInfo *pkParam,            /* Pivot Routing Backward/Fwd parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkPivotRtgBkInfo(pkParam,mBuf)
SiPivotRtgBkInfo *pkParam;            /* Pivot Routing Backward/Fwd parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkPivotRtgBkInfo)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknStr,&pkParam->pivotRtgInfo,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPivotRtgBkInfo */

/*
* 
*        Fun:   siPkNumPortFwdInfo
* 
*        Desc:  This function packs the "NumPortFwdInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkNumPortFwdInfo
(
SiNumPortFwdInfo *pkParam,            /* Number Portability Forward parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkNumPortFwdInfo(pkParam,mBuf)
SiNumPortFwdInfo *pkParam;            /* Number Portability Forward parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkNumPortFwdInfo)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->numPortStatus,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkNumPortFwdInfo */

/*
* 
*        Fun:   siPkQOnRelCap
* 
*        Desc:  This function packs the "QOnRelCap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkQOnRelCap
(
SiQOnRelCap *pkParam,                 /* Query on Release Cap parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkQOnRelCap(pkParam,mBuf)
SiQOnRelCap *pkParam;                 /* Query on Release Cap parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkQOnRelCap)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->qorCap,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkQOnRelCap */

/*
* 
*        Fun:   siPkPivotStat
* 
*        Desc:  This function packs the "PivotStat" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkPivotStat
(
SiPivotStat *pkParam,                 /* Pivot Status parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkPivotStat(pkParam,mBuf)
SiPivotStat *pkParam;                 /* Pivot Status parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkPivotStat)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->status,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkPivotStat */

/*
* 
*        Fun:   siPkRedirStat
* 
*        Desc:  This function packs the "RedirStat" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siPkRedirStat
(
SiRedirStat *pkParam,                 /* Redirect Status parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siPkRedirStat(pkParam,mBuf)
SiRedirStat *pkParam;                 /* Redirect Status parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siPkRedirStat)
   if (pkParam->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pkParam->status,mBuf);
      /* Information elements */
   }
   CMCHKPK(cmPkElmtHdr,&pkParam->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkRedirStat */

#endif

 


/* unpacking functions for ISUP events/messages */


/*
*
*       Fun:   siUnpkSiCnStEvnt 
*
*       Desc:  This function unpacks the "CnStEvnt" event structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkSiCnStEvnt
(
SiCnStEvnt *pSiCnStEvnt,          /* Connect Status Event */
Buffer *mBuf,                     /* message buffer */
Pst *pst                          /* post structure */
)
#else
PUBLIC S16 siUnpkSiCnStEvnt(pSiCnStEvnt,mBuf,pst)
SiCnStEvnt *pSiCnStEvnt;           /* Connect Status Event */
Buffer *mBuf;                      /* message buffer */
Pst *pst;                          /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siUnpkSiCnStEvnt)
   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SUnpkU8() function fails.
 */
   CMCHKUNPKLOG(SUnpkU32, &bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPKLOG(siUnpkSubNum,&pSiCnStEvnt->subNum,mBuf,ESIT260,pst);
   /* subsequent number */
   CMCHKUNPKLOG(siUnpkBckCalInd,&pSiCnStEvnt->bckCallInd,mBuf,ESIT261,pst);
   /* backward call indicators */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL) 
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiCnStEvnt->chargeNum,mBuf,ESIT262,pst);
   /* connected number */
#endif
/* si034.220 - Mod - put callRefA, connReqA under CHINA too */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA) 
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiCnStEvnt->callRefA,mBuf,ESIT263,pst);
   /* call reference */
   CMCHKUNPKLOG(siUnpkConnReqA,&pSiCnStEvnt->connReqA,mBuf,ESIT264,pst);
   /* connection req*/
#endif
   CMCHKUNPKLOG(siUnpkOptBckCalInd,&pSiCnStEvnt->optBckCalInd,mBuf,ESIT265,
                pst);
   /* optional backward call indicators */
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
   CMCHKUNPKLOG(siUnpkOptBckCalIndQ,&pSiCnStEvnt->optBckCalIndQ,mBuf,ESIT266,
                pst);
   /* optional backward call indicators */
#endif  
   CMCHKUNPKLOG(siUnpkCauseDgn,&pSiCnStEvnt->causeDgn,mBuf,ESIT267,pst);
   /* cause indicators */
   CMCHKUNPKLOG(siUnpkConnectedNum,&pSiCnStEvnt->connNum,mBuf,ESIT268,pst);
   /* connected number */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKUNPKLOG(siUnpkConnectedNum2,&pSiCnStEvnt->connNum2,mBuf,ESIT269,pst);
#endif
   CMCHKUNPKLOG(siUnpkUsr2UsrInd,&pSiCnStEvnt->usr2UsrInd,mBuf,ESIT270,pst);
   /* user to user indicators */
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiCnStEvnt->usr2UsrInfo,mBuf,ESIT271,
                pst);
   /* user to user information */
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkRedirInfo,&pSiCnStEvnt->redirInfo,mBuf,ESIT272,pst);
   }
   else
      pSiCnStEvnt->redirInfo.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiCnStEvnt->redirInfo,mBuf,ESIT272,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiRedirInfo   tempRedirInfo;
      CMCHKUNPKLOG(siUnpkRedirInfo,&tempRedirInfo,mBuf,ESITXXX,pst);
   }
#endif
   /* redirection info */
#endif
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiCnStEvnt->accTrnspt,mBuf,ESIT273,pst);
   /* access transport */
   CMCHKUNPKLOG(siUnpkCalModInd,&pSiCnStEvnt->calModInd,mBuf,ESIT274,pst);
   /* call modification indicators */
   CMCHKUNPKLOG(siUnpkEvntInfo,&pSiCnStEvnt->evntInfo,mBuf,ESIT275,pst);
   /* event info */
   CMCHKUNPKLOG(siUnpkCdPtyNum, &pSiCnStEvnt->redirNum,mBuf,ESIT276,pst);
   /* redirection numb */
   CMCHKUNPKLOG(siUnpkInfoInd,&pSiCnStEvnt->infoInd,mBuf,ESIT277,pst);
   /* information ind */
   CMCHKUNPKLOG(siUnpkInfoReqInd,&pSiCnStEvnt->infoReqInd,mBuf,ESIT278,pst);
   /* information request indicators */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkRedirNum,&pSiCnStEvnt->redirgNum,mBuf,ESIT279,pst);
   /* redirection num */
#endif
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkInfoIndA,&pSiCnStEvnt->infoIndA,mBuf,ESIT280,pst);
      /* information ind */
      CMCHKUNPKLOG(siUnpkInfoReqIndA,&pSiCnStEvnt->infoReqIndA,mBuf,ESIT281,
                   pst);
      /* information req indicators */
   }
   else
   {
      pSiCnStEvnt->infoIndA.eh.pres = NOTPRSNT;
      pSiCnStEvnt->infoReqIndA.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkInfoIndA,&pSiCnStEvnt->infoIndA,mBuf,ESIT280,pst);
   /* information ind */
   CMCHKUNPKLOG(siUnpkInfoReqIndA,&pSiCnStEvnt->infoReqIndA,mBuf,ESIT281,
                pst);
   /* information req indicators */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      {
         SiInfoIndA tempInfoIndA;
         CMCHKUNPKLOG(siUnpkInfoIndA,&tempInfoIndA,mBuf,ESITXXX,pst);
      }
      {
         SiInfoReqIndA tempReqIndA;
         CMCHKUNPKLOG(siUnpkInfoReqIndA,&tempReqIndA,mBuf,ESITXXX, pst);
      }
   }
#endif
#endif
   CMCHKUNPKLOG(siUnpkCgPtyCat,&pSiCnStEvnt->cgPtyCat,mBuf,ESIT282,pst);
   /* calling party category */
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiCnStEvnt->cgPtyNum,mBuf,ESIT283,pst);
   /* callng party num */
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkIndex,&pSiCnStEvnt->index,mBuf,ESIT284,pst);
   }
   else
      pSiCnStEvnt->index.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkIndex,&pSiCnStEvnt->index,mBuf,ESIT284,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiIndex tempIndex;
      CMCHKUNPKLOG(siUnpkIndex,&tempIndex,mBuf,ESITXXX,pst);
   }
#endif
   /* index */
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkGrpNum,&pSiCnStEvnt->grpNum,mBuf,ESIT285,pst);
#endif
#endif
   CMCHKUNPKLOG(siUnpkConnReq,&pSiCnStEvnt->connReq,mBuf,ESIT286,pst);
   /* connection req */
   CMCHKUNPKLOG(siUnpkCallRef,&pSiCnStEvnt->callRef,mBuf,ESIT287,pst);
   /* call reference */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifInd,mBuf,ESIT288,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifIndR1,mBuf,ESIT289,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkTxMedReq,&pSiCnStEvnt->txMedUsed,mBuf,ESIT290,pst);
   /* transmission medium used */
   CMCHKUNPKLOG(siUnpkSiEchoCtl,&pSiCnStEvnt->echoControl,mBuf,ESIT291,pst);
   /* echo control */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiCnStEvnt->accDelInfo1,mBuf,ESITXXX,
                pst);
   /* access delivery information */
#endif   
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiCnStEvnt->accDelInfo,mBuf,ESIT292,
                pst);
   /* access delivery information */
   CMCHKUNPKLOG(siUnpkSiGenNum,&pSiCnStEvnt->genNmb,mBuf,ESIT293,pst);
   /* generic number */
   CMCHKUNPKLOG(siUnpkSiGenNum,&pSiCnStEvnt->genNmbR,mBuf,ESIT294,pst);    
   /* generic number */
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiCnStEvnt->parmCom,mBuf,ESIT295,pst);
   /* parameter cmptblty information */
   CMCHKUNPKLOG(siUnpkSiCllDiverInfo,&pSiCnStEvnt->cllDivr,mBuf,ESIT296,pst);
   /* call Divers info */
   CMCHKUNPKLOG(siUnpkSiNetSpecFacil,&pSiCnStEvnt->netFac,mBuf,ESIT297,pst);
   /* network specific facility */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiCnStEvnt->remotOper1,mBuf,ESIT298,pst);
   /* remote operat */
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiCnStEvnt->serviceAct2,mBuf,ESIT299,pst);
   /* service activatn */
#endif
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiCnStEvnt->remotOper,mBuf,ESIT298,pst);
   /* remote operat */
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiCnStEvnt->serviceAct,mBuf,ESIT299,pst);
   /* service activatn */
   CMCHKUNPKLOG(siUnpkSiRedirRestr,&pSiCnStEvnt->redirRstr,mBuf,ESIT300,pst);
   /* redirection restr */
   CMCHKUNPKLOG(siUnpkSiMcidReqInd,&pSiCnStEvnt->mcidReq,mBuf,ESIT301,pst);
   /* MCID request ind */
   CMCHKUNPKLOG(siUnpkSiMcidRspInd,&pSiCnStEvnt->mcidRsp,mBuf,ESIT302,pst);
   /* MCID response ind */
   CMCHKUNPKLOG(siUnpkSiMsgCompInfo,&pSiCnStEvnt->msgCom,mBuf,ESIT303,pst);
   /* mssge comp info */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkOrigLineInf,&pSiCnStEvnt->origLineInf,mBuf,ESIT304,
                pst);
   /* originating line information */
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkBusinessGrp,&pSiCnStEvnt->businessGrp,mBuf,ESIT305,
                   pst);
      /* business group */
      CMCHKUNPKLOG(siUnpkInfoInd,&pSiCnStEvnt->infoInd2,mBuf,ESIT306,pst);
      /* information indic */
      CMCHKUNPKLOG(siUnpkNetTransport,&pSiCnStEvnt->netTransport,mBuf,ESIT307,
                   pst);
      /* network transport */
      CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifInd1,mBuf,ESIT308,pst);
      /* notification ind */
      CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifIndR2,mBuf,ESIT309,pst);
      /* notification ind */
      CMCHKUNPKLOG(siUnpkRedirInfo,&pSiCnStEvnt->redirInf,mBuf,ESIT310,pst);
      /* redirection info */
   }
#ifndef SS7_BELL
   else
   {
      pSiCnStEvnt->redirgNum.eh.pres = NOTPRSNT;
      pSiCnStEvnt->businessGrp.eh.pres = NOTPRSNT;
      pSiCnStEvnt->infoInd2.eh.pres = NOTPRSNT;
      pSiCnStEvnt->netTransport.eh.pres = NOTPRSNT;
      pSiCnStEvnt->notifInd1.eh.pres = NOTPRSNT;
      pSiCnStEvnt->notifIndR2.eh.pres = NOTPRSNT;
      pSiCnStEvnt->redirInf.eh.pres = NOTPRSNT;
   }
#endif
#else
   CMCHKUNPKLOG(siUnpkBusinessGrp,&pSiCnStEvnt->businessGrp,mBuf,ESIT305,
                pst);
   /* business group */
   CMCHKUNPKLOG(siUnpkInfoInd,&pSiCnStEvnt->infoInd2,mBuf,ESIT306,pst);
   /* information indic */
   CMCHKUNPKLOG(siUnpkNetTransport,&pSiCnStEvnt->netTransport,mBuf,ESIT307,
                pst);
   /* network transport */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifInd1,mBuf,ESIT308,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiCnStEvnt->notifIndR2,mBuf,ESIT309,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiCnStEvnt->redirInf,mBuf,ESIT310,pst);
   /* redirection info */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      {
         SiBusinessGrp tempBusinessGrp; 
         CMCHKUNPKLOG(siUnpkBusinessGrp,&tempBusinessGrp,mBuf,ESITXXX, pst);
      }
      {
         SiInfoInd tempInfoInd;
         CMCHKUNPKLOG(siUnpkInfoInd,&tempInfoInd,mBuf,ESITXXX,pst);
      }
      {
         SiNetTransport tempTransport;
         CMCHKUNPKLOG(siUnpkNetTransport,&tempTransport,mBuf,ESITXXX, pst);
      }
      {
         SiNotifInd tempNotifInd;
         CMCHKUNPKLOG(siUnpkNotifInd,&tempNotifInd,mBuf,ESITXXX,pst);
         CMCHKUNPKLOG(siUnpkNotifInd,&tempNotifInd,mBuf,ESITXXX,pst);
         /* notification ind and repeated notification ind */
      }
      {
         SiRedirInfo tempRedirInf;
         CMCHKUNPKLOG(siUnpkRedirInfo,&tempRedirInf,mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if SS7_Q767IT
   CMCHKUNPKLOG(siUnpkBackVadInd,&pSiCnStEvnt->backVad,mBuf,ESIT311,pst);
   /* backward vad ind*/
#endif
#if SS7_SINGTEL
   CMCHKUNPKLOG(siUnpkCllChrgeInfo,&pSiCnStEvnt->chrgeInfo,mBuf,ESIT312,pst);
   /* call charge info */
   CMCHKUNPKLOG(siUnpkChrgeRateInfo,&pSiCnStEvnt->rateInfo,mBuf,ESIT313,pst);
   /* charge rate info */
#endif
#if SS7_NTT
   /* Charge information type */
   CMCHKUNPKLOG(siUnpkChrgInfoType,&pSiCnStEvnt->chrgInfoType,mBuf,ESIT314,pst);
   {
      S16   ret; /* return value */

      if ((ret = siUnpkChrgInfo(&pSiCnStEvnt->chrgInfo, &pSiCnStEvnt->
                  chrgInfoType, mBuf)) != ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__,
                   __LINE__,(ErrCls)ERRCLS_ADD_RES,ESIT315,(ErrVal)ret,
                   "UnPacking failure for Charge Information (NTT)");
         RETVALUE(ret);
      }
   }
#endif
#if SS7_SINGTEL
   CMCHKUNPKLOG(siUnpkTrnkOff,&pSiCnStEvnt->trnkOff,mBuf,ESIT316,pst);
   /* trunk offer info */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_FTZ
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSI_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ETSIV3_BIT || bitVector & SIT_SS7_INDIA_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiCnStEvnt->calTrnsNmb,mBuf,ESIT317,pst);
      /* Call Transfer Number*/
      CMCHKUNPKLOG(siUnpkCalTrnsfrRef,&pSiCnStEvnt->calTrnsfrRef,mBuf,
                   ESIT318,pst);
      /* call transfer reference */
      CMCHKUNPKLOG(siUnpkLoopPrvntInd,&pSiCnStEvnt->loopPrvntInd,mBuf,
                   ESIT319,pst);
      /* loop prevention indicator */
   }
#ifndef SS7_FTZ
   else
   {
      pSiCnStEvnt->calTrnsNmb.eh.pres = NOTPRSNT;
      pSiCnStEvnt->calTrnsfrRef.eh.pres = NOTPRSNT;
      pSiCnStEvnt->loopPrvntInd.eh.pres = NOTPRSNT;
   }
#endif
#else
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiCnStEvnt->calTrnsNmb,mBuf,ESIT317,pst);
   /* Call Transfer Number*/
   CMCHKUNPKLOG(siUnpkCalTrnsfrRef,&pSiCnStEvnt->calTrnsfrRef,mBuf,
                ESIT318,pst);
   /* call transfer reference */
   CMCHKUNPKLOG(siUnpkLoopPrvntInd,&pSiCnStEvnt->loopPrvntInd,mBuf,
                ESIT319,pst);
   /* loop prevention indicator */
#endif
#else /* variant flag is not defined */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSI_BIT) || 
       (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ETSIV3_BIT || bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiCgPtyNum tempTrnsNmb;
         CMCHKUNPKLOG(siUnpkCgPtyNum,&tempTrnsNmb,mBuf,ESITXXX,pst);
      }
      {
         SiCallTRef tempTrnsfrRef;
         CMCHKUNPKLOG(siUnpkCalTrnsfrRef,&tempTrnsfrRef,mBuf, ESITXXX,pst);
      }
      {
         SiLoopPrvntInd tempPrvntInd;
         CMCHKUNPKLOG(siUnpkLoopPrvntInd,&tempPrvntInd,mBuf, ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#ifdef SS7_FTZ
   /* National Parameter for exch & trunk ID */
   CMCHKUNPKLOG(siUnpkNaPaExTID,&pSiCnStEvnt->naPaExTID,mBuf,ESIT320,pst);
   /* National Parameter for charging information */
   CMCHKUNPKLOG(siUnpkNaPaCHGI,&pSiCnStEvnt->naPaCHGI,mBuf,ESIT321,pst);
#endif
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_FTZ
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
      || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkNaPaChgPID,&pSiCnStEvnt->naPaChgPID,mBuf,ESIT322,pst);
   }
#ifndef SS7_FTZ
   else
      pSiCnStEvnt->naPaChgPID.eh.pres = NOTPRSNT;
#endif
#else
   CMCHKUNPKLOG(siUnpkNaPaChgPID,&pSiCnStEvnt->naPaChgPID,mBuf,ESIT322,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
      || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT))
   {
      SiNaPaChgPID tempChgPID;
      CMCHKUNPKLOG(siUnpkNaPaChgPID,&tempChgPID,mBuf,ESITXXX,pst);
   }
#endif
   /* National Parameter for charged party ID*/
#endif
#ifdef SS7_FTZ
   /* National Parameter FF */
   {
      S16 ret;
      if ((ret=siUnpkNaPaFF(&pSiCnStEvnt->naPaFF,mBuf,EVTGTCHG))!=ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__,
             __LINE__,(ErrCls)ERRCLS_DEBUG,(ErrVal)ESIT323,(ErrVal)ret,
             "Unpacking failure");
         RETVALUE(ret);
      }
   }
#endif
#if SS7_RUSSIA
   CMCHKUNPKLOG(siUnpkBillZoneNum,&pSiCnStEvnt->billZoneNum,mBuf,ESIT324,pst);
#endif /* SS7_RUSSIA */
#if SS7_NTT
   /* Message Area Information */
   CMCHKUNPKLOG(siUnpkMsgAreaInfo,&pSiCnStEvnt->msgAreaInfo,mBuf,ESIT325,pst);
   /* Charge information delay */
   CMCHKUNPKLOG(siUnpkChrgInfoDelay,&pSiCnStEvnt->chrgInfoDelay,mBuf,ESIT326,pst);
   /* Carrier Info Transfer */
   CMCHKUNPKLOG(siUnpkCarrierInfoTrans,&pSiCnStEvnt->carrierInfoTrans,
                  mBuf,ESIT327,pst);
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT || 
        bitVector & SIT_SS7_INDIA_BIT) || 
       (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT))
   {
      /* optional forward call indicators */
      CMCHKUNPKLOG(siUnpkOpFwdCalInd,&pSiCnStEvnt->opFwdCalInd,
                      mBuf,ESIT328,pst); 
      /* application transport parameter */
      CMCHKUNPKLOG(siUnpkAppTransParam,&pSiCnStEvnt->appTransParam,
                     mBuf,ESIT329,pst);
   }
   else
   {
      pSiCnStEvnt->opFwdCalInd.eh.pres = NOTPRSNT;
      pSiCnStEvnt->appTransParam.eh.pres = NOTPRSNT;
   }
#else
   /* optional forward call indicators */
   CMCHKUNPKLOG(siUnpkOpFwdCalInd,&pSiCnStEvnt->opFwdCalInd,
                   mBuf,ESIT328,pst); 
   /* application transport parameter */
   CMCHKUNPKLOG(siUnpkAppTransParam,&pSiCnStEvnt->appTransParam,
                  mBuf,ESIT329,pst);
#endif
#else /* variant flag is not defined */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
      || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT)
       ||  (bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiOpFwdCalInd tempCalInd;
         CMCHKUNPKLOG(siUnpkOpFwdCalInd,&tempCalInd, mBuf,ESITXXX,pst); 
      }
      {
         SiAppTransParam tempTransParam;
         CMCHKUNPKLOG(siUnpkAppTransParam,&tempTransParam, mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) 
      || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT))
   {
      CMCHKUNPKLOG(siUnpkBackGVNS,&pSiCnStEvnt->backGVNS, mBuf,ESIT330,pst);
   }
   else
      pSiCnStEvnt->backGVNS.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkBackGVNS,&pSiCnStEvnt->backGVNS, mBuf,ESIT330,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) 
       || (bitVector & SIT_SS7_RUSS2000_BIT) ||
       (bitVector & SIT_SS7_ITU2000_BIT))
   {
      SiBackGVNS tempBkGVNS;
      CMCHKUNPKLOG(siUnpkBackGVNS,&tempBkGVNS, mBuf,ESITXXX,pst);
   }
#endif
   /* backward GVNS */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_INDIA_BIT))
   {
      /* confrence treatment indicators */
      CMCHKUNPKLOG(siUnpkConfTrtInd,&pSiCnStEvnt->confTrtInd, 
                      mBuf,ESIT331,pst);
      /* call history information */
      CMCHKUNPKLOG(siUnpkSiPropDly,&pSiCnStEvnt->cllHstry, mBuf,ESIT332,pst);
      /* UID action indicator */
      CMCHKUNPKLOG(siUnpkUidActionInd,&pSiCnStEvnt->uidActionInd,
                                    mBuf,ESIT333,pst);
   }
   else
   {
      pSiCnStEvnt->confTrtInd.eh.pres = NOTPRSNT;
      pSiCnStEvnt->cllHstry.eh.pres = NOTPRSNT;
      pSiCnStEvnt->uidActionInd.eh.pres = NOTPRSNT;
   }
#else
   /* confrence treatment indicators */
   CMCHKUNPKLOG(siUnpkConfTrtInd,&pSiCnStEvnt->confTrtInd, 
                   mBuf,ESIT331,pst);
   /* call history information */
   CMCHKUNPKLOG(siUnpkSiPropDly,&pSiCnStEvnt->cllHstry, mBuf,ESIT332,pst);
   /* UID action indicator */
   CMCHKUNPKLOG(siUnpkUidActionInd,&pSiCnStEvnt->uidActionInd,
                                    mBuf,ESIT333,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
        || (bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiConfTrtInd tempTrtInd;
         CMCHKUNPKLOG(siUnpkConfTrtInd,&tempTrtInd, mBuf,ESITXXX,pst);
      }
      {
         SiPropDly tempCllHstry;
         CMCHKUNPKLOG(siUnpkSiPropDly,&tempCllHstry, mBuf,ESITXXX,pst);
      }
      {
         SiUidActionInd tempActionInd;
         CMCHKUNPKLOG(siUnpkUidActionInd,&tempActionInd, mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if SS7_INDIA
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_INDIA_BIT) 
   {
      CMCHKUNPKLOG(siUnpkCllChrgeBnd,&pSiCnStEvnt->chrgeBnd,mBuf,ESITXXX,pst);
   }
   else
      pSiCnStEvnt->chrgeBnd.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkCllChrgeBnd,&pSiCnStEvnt->chrgeBnd,mBuf,ESITXXX,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_INDIA_BIT) 
   {
      SiChargeBand chrgeBnd;
      CMCHKUNPKLOG(siUnpkCllChrgeBnd,&chrgeBnd,mBuf,ESITXXX,pst);
   }
#endif
#endif

/* si034.220: Addition - added SS7_CHINA */
#ifdef SS7_CHINA
  CMCHKUNPKLOG(siUnpkChargeInform,&pSiCnStEvnt->chrgeInform,mBuf,ESITXXX,pst);
#endif /* if SS7_CHINA */

/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if SS7_ITU2000
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
      CMCHKUNPKLOG(siUnpkCCNRPosInd,&pSiCnStEvnt->ccnrPosInd,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkChargeNum,&pSiCnStEvnt->htrInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiCnStEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkRedirStat,&pSiCnStEvnt->redirStat,mBuf,ESITXXX,pst);
   }
   else
   {
      pSiCnStEvnt->ccnrPosInd.eh.pres = NOTPRSNT;
      pSiCnStEvnt->htrInfo.eh.pres = NOTPRSNT;
      pSiCnStEvnt->pivotRtgBkInfo.eh.pres = NOTPRSNT;
      pSiCnStEvnt->redirStat.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkCCNRPosInd,&pSiCnStEvnt->ccnrPosInd,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiCnStEvnt->htrInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiCnStEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkRedirStat,&pSiCnStEvnt->redirStat,mBuf,ESITXXX,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
     SiCCNRPosInd  ccnrPosInd; 
     SiChargeNum htrInfo; 
     SiPivotRtgBkInfo pivotRtgBkInfo;
     SiRedirStat redirStat;

     CMCHKUNPKLOG(siUnpkCCNRPosInd,&ccnrPosInd,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkChargeNum,&htrInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkCllChrgeBnd,&pivotRtgBkInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkRedirStat,&redirStat,mBuf,ESITXXX,pst);
   
   }
#endif
#endif

   RETVALUE(ROK);
} /* end of siUnpkSiCnStEvnt */


/*
*
*       Fun:   siUnpkSiConEvnt
*
*       Desc:  This function unpacks the "ConEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiConEvnt
(
SiConEvnt *pSiConEvnt,         /* ISUP Connect Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst,                      /* post structure */
U8 evntType                    /* event type */
)
#else
PUBLIC S16 siUnpkSiConEvnt(pSiConEvnt,mBuf,pst,evntType)
SiConEvnt *pSiConEvnt;          /* ISUP Connect Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
U8 evntType;                    /* event type */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
/* sit_c_002.main_15 - Addition. Added variable intfVer for Bellcore on
 * Rolling upgrade.
 */
#ifdef SS7_BELL
   CmIntfVer intfVer;   
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer
#else
   intfVer = SITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_BELL */   

   TRC3(siUnpkSiConEvnt)
   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SUnpkU8() function fails.
 */
   CMCHKUNPKLOG(SUnpkU32, &bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPKLOG(siUnpkNatConInd,&pSiConEvnt->natConInd,mBuf, ESIT334,pst); 
   /* Nature of connection indicators */
   CMCHKUNPKLOG(siUnpkFwdCallInd,&pSiConEvnt->fwdCallInd,mBuf,ESIT335,pst); 
   /* forward call indic */
   CMCHKUNPKLOG(siUnpkCgPtyCat,&pSiConEvnt->cgPtyCat,mBuf,ESIT336,pst);  
   /* calling party category */
   CMCHKUNPKLOG(siUnpkTxMedReq,&pSiConEvnt->txMedReq,mBuf,ESIT337,pst); 
   /* transmission medium  requirement */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkSiUsrServInfo,&pSiConEvnt->usrServInfoA,mBuf, ESIT338,
                pst);
   /* user service Info */
#endif
   CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiConEvnt->cdPtyNum,mBuf,ESIT339,pst);     
   /* called party number*/
/* si037.220 : Transit Network Selection Par. as per ansi specs */	 
#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkTranNetSel1,&pSiConEvnt->tranNetSel1,mBuf,ESITXXX,pst);
   /* transit network selection */
#endif	 	 
#endif	 	 
   CMCHKUNPKLOG(siUnpkTranNetSel,&pSiConEvnt->tranNetSel,mBuf,ESIT340,pst);
   /* transit network selection */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiConEvnt->callRefA,mBuf,ESIT341,pst);   
   /* call reference */
#endif
   CMCHKUNPKLOG(siUnpkCallRef,&pSiConEvnt->callRef,mBuf,ESIT342,pst);    
   /* call reference */
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiConEvnt->cgPtyNum,mBuf,ESIT343,pst);   
   /* calling party nmber*/
#if SS7_BELL 
   CMCHKUNPKLOG(siUnpkCgPtyNum1,&pSiConEvnt->cgPtyNumB,mBuf,ESITXXX,pst);   
   /* calling party nmber*/
#endif
   CMCHKUNPKLOG(siUnpkOpFwdCalInd,&pSiConEvnt->opFwdCalInd,
                   mBuf,ESIT344,pst); 
   /* optional forward call indicators */
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)
   CMCHKUNPKLOG(siUnpkOpFwdCalIndQ,&pSiConEvnt->opFwdCalIndQ,
                   mBuf,ESIT345,pst);
   /* optional forward call indicators */
#endif
#if SS7_Q767IT
   CMCHKUNPKLOG(siUnpkFwdVadInd,&pSiConEvnt->fwdVad,mBuf,ESIT346,pst);  
   /* forward vad indicat */
#endif
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
   /* Variant flag is defined at the destination, unpacking will be done 
    * only if the orignator indicates that is has packed the parameter 
    * (determined from the bit vector). If not send by orignator we 
    * mark as not present for the parameter
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkOpFwdCalIndA,&pSiConEvnt->opFwdCalIndA,
                   mBuf,ESIT347,pst);
   }
   else
      pSiConEvnt->opFwdCalIndA.eh.pres = NOTPRSNT;
#else
   /* No rolling upgrade support so we base our unpacking decision
    * solely on the compile tiem flag
    */
   CMCHKUNPKLOG(siUnpkOpFwdCalIndA,&pSiConEvnt->opFwdCalIndA,
                mBuf,ESIT347,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* the compile time flag is not defined at destination but may be 
    * defined at origiator. If so we unpack and discard the parameter
    */
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiOpFwdCalIndA tempCalIndA;
      CMCHKUNPKLOG(siUnpkOpFwdCalIndA,&tempCalIndA, mBuf,ESITXXX,pst);
   }
#endif
   /* optional forward call indicators */
#endif
   CMCHKUNPKLOG(siUnpkRedirgNum,&pSiConEvnt->redirgNum,mBuf,ESIT348,pst);  
   /* redirection number */
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiConEvnt->redirInfo,mBuf,ESIT349,pst); 
   /* redirection information */
   CMCHKUNPKLOG(siUnpkCugIntCode,&pSiConEvnt->cugIntCode,mBuf,ESIT350,pst); 
   /* closed group interlock code */
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkCugIntCodeA,&pSiConEvnt->cugIntCodeA,mBuf,ESIT351,pst); 
   }
   else
      pSiConEvnt->cugIntCodeA.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkCugIntCodeA,&pSiConEvnt->cugIntCodeA,mBuf,ESIT351,pst); 
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiCugIntCodeA tempCodeA;
      CMCHKUNPKLOG(siUnpkCugIntCodeA,&tempCodeA,mBuf,ESITXXX,pst); 
   }
#endif
   /* closed group interlock code */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKUNPKLOG(siUnpkConnReqA,&pSiConEvnt->connReqA,mBuf,ESIT352,pst);   
   /* connection request */
#endif
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiConEvnt->usr2UsrInfoA,mBuf,ESIT353,pst); 
   }
   else
      pSiConEvnt->usr2UsrInfoA.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiConEvnt->usr2UsrInfoA,mBuf,ESIT353,pst); 
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiUsr2UsrInfo tempUsrInfoA; /* temp. user to user information */
      CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&tempUsrInfoA,mBuf,ESITXXX,pst); 
   }
#endif
   /* user to user information */
#endif
   CMCHKUNPKLOG(siUnpkConnReq,&pSiConEvnt->connReq,mBuf,ESIT354,pst);    
   /* connection request */
   CMCHKUNPKLOG(siUnpkOrigCdNum,&pSiConEvnt->origCdNum,mBuf,ESIT355,pst);    
   /* original called number */
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiConEvnt->usr2UsrInfo,mBuf,ESIT356,pst); 
   /* user to user info */
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiConEvnt->accTrnspt,mBuf,ESIT357,pst);   
   /* access transport */
   CMCHKUNPKLOG(siUnpkSiEchoCtl,&pSiConEvnt->echoControl,mBuf,ESIT358,pst);
   /* echo control */   
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      CMCHKUNPKLOG(siUnpkRedirInfo,&pSiConEvnt->redirInfoA,mBuf,ESIT359,pst); 
   }
   else
      pSiConEvnt->redirInfoA.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiConEvnt->redirInfoA,mBuf,ESIT359,pst); 
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT) 
   {
      SiRedirInfo   tempRedirInfoA;
      CMCHKUNPKLOG(siUnpkRedirInfo,&tempRedirInfoA,mBuf,ESITXXX,pst); 
   }
#endif
   /* redirection information */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiConEvnt->chargeNum,mBuf,ESIT360,pst);  
   /* connected number */
   CMCHKUNPKLOG(siUnpkOrigLineInf,&pSiConEvnt->origLineInf,mBuf,ESIT361,pst); 
   /* originating line information */
#endif
   CMCHKUNPKLOG(siUnpkSiUsrServInfo,&pSiConEvnt->usrServInfo,mBuf,ESIT362,
               pst);
   /* User Service Info */
   CMCHKUNPKLOG(siUnpkUsr2UsrInd,&pSiConEvnt->usr2UsrInd,mBuf,ESIT363,pst);  
   /* user to user indicators */
   CMCHKUNPKLOG(siUnpkSiPropDly,&pSiConEvnt->propDly,mBuf,ESIT364,pst);    
   /* propagation delay  counter*/
   CMCHKUNPKLOG(siUnpkSiUsrServInfo,&pSiConEvnt->usrServInfo1,mBuf,ESIT365,
               pst);
   /* user service info prime */
   CMCHKUNPKLOG(siUnpkSiNetSpecFacil,&pSiConEvnt->netFac,mBuf,ESIT366,pst);
   /* network specific facility */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSigPointCodeA,&pSiConEvnt->orgPteCdeA,mBuf,ESITXXX,pst); 
   /* originating ISC point code */
#else
   CMCHKUNPKLOG(siUnpkSigPointCode,&pSiConEvnt->orgPteCde,mBuf,ESIT367,pst); 
   /* originating ISC point code */
#endif   
   CMCHKUNPKLOG(siUnpkSiGenDigits,&pSiConEvnt->genDigits,mBuf,ESIT368,pst);  
   /* generic digits */
   CMCHKUNPKLOG(siUnpkSiGenDigits,&pSiConEvnt->genDigitsR,mBuf,ESIT369,pst);  
   /* generic digits */
   CMCHKUNPKLOG(siUnpkSiUsrTSrvInfo,&pSiConEvnt->usrTSrvInfo,mBuf,ESIT370,
               pst);
   /* user teleservice info */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiConEvnt->remotOper1,mBuf,ESITXXX,pst);  
   /* remote operations*/
#endif   
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiConEvnt->remotOper,mBuf,ESIT371,pst);  
   /* remote operations*/
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiConEvnt->parmCom,mBuf,ESIT372,pst); 
   /* parameter cmptblty*/
/* sit_c_002.main_15 - Modification. Modified service activation parameter for
 * Bellcore variant.
 */
#if (SS7_ANS92 || SS7_ANS95)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      CMCHKUNPKLOG(siUnpkServiceCode,&pSiConEvnt->servCode,mBuf,ESIT373,pst);
   }
   else
      pSiConEvnt->servCode.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkServiceCode,&pSiConEvnt->servCode,mBuf,ESIT373,pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* variant flag is not defined */
#ifdef SS7_BELL
   switch (intfVer)
   {
      case 0x0100:
      {
         SiServiceCode tmpServCode;
	 CMCHKUNPKLOG(siUnpkServiceCode, &tmpServCode, mBuf, ESITXXX, pst);
	 break;
      }

      case 0x0200:
         break;

      default:
	 /* invalid interface version number */
	 SPutMsg(mBuf);
	 RETVALUE(RINVIFVER);
   }
#else   
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      SiServiceCode tempServCode;
      CMCHKUNPKLOG(siUnpkServiceCode,&tempServCode,mBuf,ESITXXX,pst);
   }
#endif
#endif /*SS7_BELL */   
   /* service code for ANSI 92 */
#endif
#ifdef SS7_ANS92
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS92_BIT)
   {
      CMCHKUNPKLOG(siUnpkServiceAct,&pSiConEvnt->serviceAct1,mBuf,ESIT374,pst);
   }
   else
      pSiConEvnt->serviceAct1.eh.pres = NOTPRSNT; 
#else
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiConEvnt->serviceAct1,mBuf,ESIT374,pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   
#else /* variant flag is not defined */
#ifdef SS7_BELL
   switch (intfVer)
   {
      case 0x0100:
      {
         SiServiceAct tmpServAct;
	 CMCHKUNPKLOG(siUnpkServiceAct, &tmpServAct, mBuf, ESITXXX, pst);
	 break;
      }

      case 0x0200:
         break;

      default:
	 /* invalid interface version number */
	 SPutMsg(mBuf);
	 RETVALUE(RINVIFVER);
   }
#else   
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS92_BIT)
   {
      SiServiceAct  tempServiceAct1;
      CMCHKUNPKLOG(siUnpkServiceAct,&tempServiceAct1,mBuf,ESITXXX,pst);
   }
#endif
#endif /* SS7_BELL */   
   /* service activatn */
#endif
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiConEvnt->serviceAct2,mBuf,ESITXXX,pst);
   /* service activatn */
#endif   
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiConEvnt->serviceAct,mBuf,ESIT375,pst);
   /* service activatn */
   CMCHKUNPKLOG(siUnpkSiMlppPrec,&pSiConEvnt->mlppPrec,mBuf,ESIT376,pst);  
   /* MLPP precedence */
   CMCHKUNPKLOG(siUnpkTxMedReq,&pSiConEvnt->txMedUsPr,mBuf,ESIT377,pst);  
   /* trans medium used*/
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKUNPKLOG(siUnpkTxMedReq,&pSiConEvnt->txMedUsed,mBuf,ESIT378,pst);
   /* transmission medium used */
#endif
   CMCHKUNPKLOG(siUnpkBckCalInd,&pSiConEvnt->bckCallInd,mBuf,ESIT379,pst); 
   /* backward call indicators */
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiConEvnt->cgPtyNum1,mBuf,ESIT380,pst);    
   /* calling party number*/
   CMCHKUNPKLOG(siUnpkOptBckCalInd,&pSiConEvnt->optBckCalInd,mBuf,ESIT381,
               pst); 
   /* optional backward call indicators */
#if (SS7_Q767 || SS7_RUSSIA) 
   CMCHKUNPKLOG(siUnpkOptBckCalIndQ,&pSiConEvnt->optBckCalIndQ,mBuf,ESIT382,
               pst);
   /* optional backward call indicators */
#endif  
   CMCHKUNPKLOG(siUnpkConnectedNum,&pSiConEvnt->connNum,mBuf,ESIT383,pst);  
   /* connected number */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
   CMCHKUNPKLOG(siUnpkConnectedNum2,&pSiConEvnt->connNum2,mBuf,ESIT384,pst);  
#endif
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiConEvnt->accDelInfo1,
                   mBuf,ESITXXX,pst);
   /* access delivery information */
#endif
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiConEvnt->accDelInfo,
                   mBuf,ESIT385,pst);
   /* access delivery information */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifInd,mBuf,ESIT386,pst);     
   /* notification ind */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifIndR2,mBuf,ESIT387,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkSiPropDly,&pSiConEvnt->cllHstry,mBuf,ESIT388,pst);  
   /* call history info*/
   CMCHKUNPKLOG(siUnpkSiGenNum,&pSiConEvnt->genNmb,mBuf,ESIT389,pst);       
   /* generic number */
   CMCHKUNPKLOG(siUnpkSiGenNum,&pSiConEvnt->genNmbR,mBuf,ESIT390,pst);        
   /* generic number */
   CMCHKUNPKLOG(siUnpkCdPtyNum, &pSiConEvnt->redirNum,mBuf,ESIT391,pst);
   /* redirection number*/
   CMCHKUNPKLOG(siUnpkSiRedirRestr,&pSiConEvnt->redirRstr,mBuf,ESIT392,pst); 
   /* redirection restr */
#if SS7_Q767IT
   CMCHKUNPKLOG(siUnpkBackVadInd,&pSiConEvnt->backVad,mBuf,ESIT393,pst);   
   /* backward vad ind*/
#endif
#if SS7_SINGTEL
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiConEvnt->cgPtyNumS,mBuf,ESIT394,pst);     
   /* calling party number */
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
#endif
   {   
      CMCHKUNPKLOG(siUnpkBusinessGrp,&pSiConEvnt->businessGrp,mBuf,ESIT395,pst); 
      /* business group */
      CMCHKUNPKLOG(siUnpkInfoInd,&pSiConEvnt->infoInd,mBuf,ESIT396,pst);
      /* information ident */
      CMCHKUNPKLOG(siUnpkCarrierId,&pSiConEvnt->carrierId,mBuf,ESIT397,pst);    
      /* carrier ident */
      CMCHKUNPKLOG(siUnpkCarrierSelInf,&pSiConEvnt->carSelInf,mBuf,ESIT398,pst); 
      /* carrier selct inf */
      CMCHKUNPKLOG(siUnpkEgress,&pSiConEvnt->egress,mBuf,ESIT399,pst);          
      /* ergress service */
      CMCHKUNPKLOG(siUnpkGenAddr,&pSiConEvnt->genAddr,mBuf,ESIT400,pst);        
      /* generic address */
      CMCHKUNPKLOG(siUnpkGenAddr,&pSiConEvnt->genAddrR,mBuf,ESIT401,pst);        
      /* generic address */
      CMCHKUNPKLOG(siUnpkInfoReqInd,&pSiConEvnt->infoReqInd,mBuf,ESIT402,pst); 
      /* info req indicat */
      CMCHKUNPKLOG(siUnpkJurisInf,&pSiConEvnt->jurisInf,mBuf,ESIT403,pst);     
      /* jurisdict info */
      CMCHKUNPKLOG(siUnpkNetTransport,&pSiConEvnt->netTransport,mBuf,ESIT404,pst);
      /* network transport */
      CMCHKUNPKLOG(siUnpkSpecProcReq,&pSiConEvnt->specProcReq,mBuf,ESIT405,pst);
      /* spec procss reqst */
      CMCHKUNPKLOG(siUnpkTransReq,&pSiConEvnt->transReq,mBuf,ESIT406,pst);      
      /* transaction reqst */
   }
#ifndef SS7_BELL
   else
   {
      pSiConEvnt->businessGrp.eh.pres = NOTPRSNT; 
      pSiConEvnt->infoInd.eh.pres = NOTPRSNT;
      pSiConEvnt->carrierId.eh.pres = NOTPRSNT;    
      pSiConEvnt->carSelInf.eh.pres = NOTPRSNT; 
      pSiConEvnt->egress.eh.pres = NOTPRSNT;          
      pSiConEvnt->genAddr.eh.pres = NOTPRSNT;        
      pSiConEvnt->genAddrR.eh.pres = NOTPRSNT;        
      pSiConEvnt->infoReqInd.eh.pres = NOTPRSNT; 
      pSiConEvnt->jurisInf.eh.pres = NOTPRSNT;     
      pSiConEvnt->netTransport.eh.pres = NOTPRSNT;
      pSiConEvnt->specProcReq.eh.pres = NOTPRSNT;
      pSiConEvnt->transReq.eh.pres = NOTPRSNT;      
   }
#endif
#else
   CMCHKUNPKLOG(siUnpkBusinessGrp,&pSiConEvnt->businessGrp,mBuf,ESIT395,pst); 
   /* business group */
   CMCHKUNPKLOG(siUnpkInfoInd,&pSiConEvnt->infoInd,mBuf,ESIT396,pst);
   /* information ident */
   CMCHKUNPKLOG(siUnpkCarrierId,&pSiConEvnt->carrierId,mBuf,ESIT397,pst);    
   /* carrier ident */
   CMCHKUNPKLOG(siUnpkCarrierSelInf,&pSiConEvnt->carSelInf,mBuf,ESIT398,pst); 
   /* carrier selct inf */
   CMCHKUNPKLOG(siUnpkEgress,&pSiConEvnt->egress,mBuf,ESIT399,pst);          
   /* ergress service */
   CMCHKUNPKLOG(siUnpkGenAddr,&pSiConEvnt->genAddr,mBuf,ESIT400,pst);        
   /* generic address */
   CMCHKUNPKLOG(siUnpkGenAddr,&pSiConEvnt->genAddrR,mBuf,ESIT401,pst);        
   /* generic address */
   CMCHKUNPKLOG(siUnpkInfoReqInd,&pSiConEvnt->infoReqInd,mBuf,ESIT402,pst); 
   /* info req indicat */
   CMCHKUNPKLOG(siUnpkJurisInf,&pSiConEvnt->jurisInf,mBuf,ESIT403,pst);     
   /* jurisdict info */
   CMCHKUNPKLOG(siUnpkNetTransport,&pSiConEvnt->netTransport,mBuf,ESIT404,pst);
   /* network transport */
   CMCHKUNPKLOG(siUnpkSpecProcReq,&pSiConEvnt->specProcReq,mBuf,ESIT405,pst);
   /* spec procss reqst */
   CMCHKUNPKLOG(siUnpkTransReq,&pSiConEvnt->transReq,mBuf,ESIT406,pst);      
   /* transaction reqst */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {   
      {
         SiBusinessGrp tempBusinessGrp;
         CMCHKUNPKLOG(siUnpkBusinessGrp,&tempBusinessGrp,mBuf,ESITXXX,pst); 
      }
      {
         SiInfoInd tempInfoInd;
         CMCHKUNPKLOG(siUnpkInfoInd,&tempInfoInd,mBuf,ESITXXX,pst);
      }
      {
         SiCarrierId tempCarrierId;
         CMCHKUNPKLOG(siUnpkCarrierId,&tempCarrierId,mBuf,ESITXXX,pst);    
      }
      {
         SiCarrierSelInf tempSelInf;
         CMCHKUNPKLOG(siUnpkCarrierSelInf,&tempSelInf,mBuf,ESITXXX,pst); 
      }
      {
         SiEgress tempEgress;
         CMCHKUNPKLOG(siUnpkEgress,&tempEgress,mBuf,ESITXXX,pst);          
      }
      {
         SiGenAddr tempGenAddr;
         CMCHKUNPKLOG(siUnpkGenAddr,&tempGenAddr,mBuf,ESITXXX,pst);        
         CMCHKUNPKLOG(siUnpkGenAddr,&tempGenAddr,mBuf,ESITXXX,pst);        
         /* generic address and repeated generic address */
      }
      {
         SiInfoReqInd    tempReqInd;
         CMCHKUNPKLOG(siUnpkInfoReqInd,&tempReqInd,mBuf,ESITXXX,pst); 
      }
      {
         SiJurisInf tempJurisInf;
         CMCHKUNPKLOG(siUnpkJurisInf,&tempJurisInf,mBuf,ESITXXX,pst);     
      }
      {
         SiNetTransport  tempTransport;
         CMCHKUNPKLOG(siUnpkNetTransport,&tempTransport,mBuf,ESITXXX,pst);
      }
      {
         SiSpecProcReq   tempProcReq;
         CMCHKUNPKLOG(siUnpkSpecProcReq,&tempProcReq,mBuf,ESITXXX,pst);
      }
      {
         SiTransReq tempTransReq;
         CMCHKUNPKLOG(siUnpkTransReq,&tempTransReq,mBuf,ESITXXX,pst);      
      }
   }
#endif
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS92 || SS7_ANS95)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifInd1,mBuf,ESIT407,pst);
      /* notification ind */
      CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifIndR1,mBuf,ESIT408,pst);
      /* notification ind */
   }
   else
   {
      pSiConEvnt->notifInd1.eh.pres = NOTPRSNT;
      pSiConEvnt->notifIndR1.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifInd1,mBuf,ESIT407,pst);
   /* notification ind */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiConEvnt->notifIndR1,mBuf,ESIT408,pst);
   /* notification ind */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      SiNotifInd  tempNotifInd;
      CMCHKUNPKLOG(siUnpkNotifInd,&tempNotifInd,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkNotifInd,&tempNotifInd,mBuf,ESITXXX,pst);
      /* notification ind and repeated notification ind */
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* variant flag */
#endif /* SIT_PARAMETER */   
#if (SS7_BELL|| SS7_ANS95)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if (bitVector & SIT_SS7_ANS95_BIT) 
#endif
   {
      CMCHKUNPKLOG(siUnpkGenName,&pSiConEvnt->genName,mBuf,ESIT409,pst);        
   }
#ifndef SS7_BELL
   else
      pSiConEvnt->genName.eh.pres = NOTPRSNT;
#endif
#else
   CMCHKUNPKLOG(siUnpkGenName,&pSiConEvnt->genName,mBuf,ESIT409,pst);        
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT) 
   {
      SiGenName tempGenName;
      CMCHKUNPKLOG(siUnpkGenName,&tempGenName,mBuf,ESITXXX,pst);        
   }
#endif
   /* generic name */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_BELL || SS7_ANS95 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ANS95_BIT) || (bitVector & SIT_SS7_INDIA_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkHopCounter,&pSiConEvnt->hopCounter,mBuf,ESIT410,pst); 
   }
#ifndef SS7_BELL
   else
      pSiConEvnt->hopCounter.eh.pres = NOTPRSNT;
#endif
#else
   CMCHKUNPKLOG(siUnpkHopCounter,&pSiConEvnt->hopCounter,mBuf,ESIT410,pst);   
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ANS95_BIT) || (bitVector & SIT_SS7_INDIA_BIT))
   {
      SiHopCounter tempCounter;
      CMCHKUNPKLOG(siUnpkHopCounter,&tempCounter,mBuf,ESITXXX,pst);
   }
#endif
   /* hop counter */
#endif
#if (SS7_BELL || SS7_ITU2000)
   CMCHKUNPKLOG(siUnpkRedirCap,&pSiConEvnt->redirCap,mBuf,ESIT411,pst);   
   /* Redirect capability */
   CMCHKUNPKLOG(siUnpkRedirCntr,&pSiConEvnt->redirCntr,mBuf,ESIT412,pst);   
   /* Redirect counter */
#endif
#if (SS7_ETSI || SS7_FTZ)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_FTZ
   if (bitVector & SIT_SS7_ETSI_BIT) 
#endif
   {
      CMCHKUNPKLOG(siUnpkCCBSParam,&pSiConEvnt->ccbsParam,mBuf,ESIT413,pst);   
      /* CCBS parmeter */
      CMCHKUNPKLOG(siUnpkFreePhParam,&pSiConEvnt->freePhParam,mBuf,ESIT414,pst);
      /* freephone indicator */
   }
#ifndef SS7_FTZ
   else
   {
      pSiConEvnt->ccbsParam.eh.pres = NOTPRSNT;
      pSiConEvnt->freePhParam.eh.pres = NOTPRSNT;
   }
#endif
#else
   CMCHKUNPKLOG(siUnpkCCBSParam,&pSiConEvnt->ccbsParam,mBuf,ESIT413,pst);   
   /* CCBS parmeter */
   CMCHKUNPKLOG(siUnpkFreePhParam,&pSiConEvnt->freePhParam,mBuf,ESIT414,pst);
   /* freephone indicator */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ETSI_BIT) 
   {
      {
         SiCcbsParam tempCcbsParam;
         CMCHKUNPKLOG(siUnpkCCBSParam,&tempCcbsParam,mBuf,ESITXXX,pst);   
      }
      {
         SiFreePhInd tempPhParam;
         CMCHKUNPKLOG(siUnpkFreePhParam,&tempPhParam,mBuf,ESITXXX,pst);
      }
   }
#endif
#endif
#ifdef SS7_FTZ
   {
      S16 ret;
      if ((ret=siUnpkNaPaFF(&pSiConEvnt->naPaFF,mBuf,evntType))!=ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__,
             __LINE__,(ErrCls)ERRCLS_DEBUG,(ErrVal)ESIT415,(ErrVal)ret,
             "Unpacking failure");
         RETVALUE(ret);
      }
   }
   /* National Parameter FF */
   CMCHKUNPKLOG(siUnpkNaPaFE,&pSiConEvnt->naPaFE,mBuf,ESIT416,pst);
   /* National Parameter FE */
   CMCHKUNPKLOG(siUnpkNaPaSSP,&pSiConEvnt->naPaSSP,mBuf,ESIT417,pst);
   /* National Parameter for SSP */
   CMCHKUNPKLOG(siUnpkNaPaCdPNO,&pSiConEvnt->naPaCdPNO,mBuf,ESIT418,pst);
   /* National Parameter for called pty nmb */
   CMCHKUNPKLOG(siUnpkNaPaSPV,&pSiConEvnt->naPaSPV,mBuf,ESIT419,pst);
   /* National Parameter for SPV */
   CMCHKUNPKLOG(siUnpkNaPaUKK,&pSiConEvnt->naPaUKK,mBuf,ESIT420,pst);
   /* National Parameter for UKK */
#endif
#if SS7_NTT
   /* Message Area Information */
   CMCHKUNPKLOG(siUnpkMsgAreaInfo,&pSiConEvnt->msgAreaInfo,mBuf,ESIT421,pst);
   /* Subscriber Number */
   CMCHKUNPKLOG(siUnpkSubsNumber,&pSiConEvnt->subsNumber,mBuf,ESIT422,pst);
   /* Reason for prohibiting calling no */
   CMCHKUNPKLOG(siUnpkReasProhibCllngNo,&pSiConEvnt->rpCllngNo,mBuf,
         ESIT423,pst);
   /* Supplementary user type */
   CMCHKUNPKLOG(siUnpkSupplUserType,&pSiConEvnt->supplUserType,mBuf,
         ESIT424,pst);
   /*  Carrier Info Transfer */
   CMCHKUNPKLOG(siUnpkCarrierInfoTrans,&pSiConEvnt->carrierInfoTrans,mBuf,
         ESIT425,pst);
   /* Network function type */
   CMCHKUNPKLOG(siUnpkNwFuncType,&pSiConEvnt->nwFuncType,mBuf,ESIT426,pst);
#endif
#if SS7_ANS95
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT) 
   {
      CMCHKUNPKLOG(siUnpkOptrServicesInfo, &pSiConEvnt->optrServicesInfo,
                   mBuf,ESIT427,pst);
   }
   else
      pSiConEvnt->optrServicesInfo.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkOptrServicesInfo, &pSiConEvnt->optrServicesInfo,
                                    mBuf,ESIT427,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT) 
   {
      SiOptrServicesInfo tempServicesInfo;
      CMCHKUNPKLOG(siUnpkOptrServicesInfo, &tempServicesInfo,mBuf,ESITXXX,pst);
   }
#endif
   /* Operator services info */ 
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS95_BIT) || (bitVector & SIT_SS7_ITU97_BIT)
       ||(bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT))
   {
      CMCHKUNPKLOG(siUnpkCirAsgnMap,&pSiConEvnt->cirAsgnMap,mBuf,ESIT428,pst);
   }
   else
      pSiConEvnt->cirAsgnMap.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkCirAsgnMap,&pSiConEvnt->cirAsgnMap,mBuf,ESIT428,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS95_BIT) || (bitVector & SIT_SS7_ITU97_BIT) 
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT))
   {
      SiCirAsgnMap tempAsgnMap;
      CMCHKUNPKLOG(siUnpkCirAsgnMap,&tempAsgnMap,mBuf,ESITXXX,pst);
   }
#endif
   /* circuit assignment map */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
        || (bitVector & SIT_SS7_INDIA_BIT))
   {
      /* display information */
      CMCHKUNPKLOG(siUnpkDisplayInfo,&pSiConEvnt->displayInfo, mBuf,ESIT429,pst);
      /* confrence treatment indicators */
      CMCHKUNPKLOG(siUnpkConfTrtInd,&pSiConEvnt->confTrtInd, mBuf,ESIT430,pst);
      /* network management controls */
      CMCHKUNPKLOG(siUnpkNetMgmtControls,&pSiConEvnt->netMgmtControls,
                    mBuf,ESIT431,pst);
      /* correlation Id */
      CMCHKUNPKLOG(siUnpkCorrelationId,&pSiConEvnt->correlationId,
                    mBuf,ESIT432,pst);
      /* call diversion treatment ind */
      CMCHKUNPKLOG(siUnpkCallDivTrtInd,&pSiConEvnt->callDivTrtInd,
                    mBuf,ESIT433,pst);
      /* call IN number */
      CMCHKUNPKLOG(siUnpkCallInNmb,&pSiConEvnt->callInNmb, mBuf,ESIT434,pst);
      /* call offering treatment ind */
      CMCHKUNPKLOG(siUnpkCallOfferTrtInd,&pSiConEvnt->callOfferTrtInd,
                    mBuf,ESIT435,pst);
      /* SCF Id */
      CMCHKUNPKLOG(siUnpkScfId,&pSiConEvnt->scfId, mBuf,ESIT436,pst);
      /* UID capability indicator */
      CMCHKUNPKLOG(siUnpkUidCapInd,&pSiConEvnt->uidCapInd, mBuf,ESIT437,pst);
      /* collect call request */
      CMCHKUNPKLOG(siUnpkCollCallReq,&pSiConEvnt->collCallReq, mBuf,ESIT438,pst);
      /* CCSS */
      CMCHKUNPKLOG(siUnpkCcss,&pSiConEvnt->ccss, mBuf,ESIT439,pst);
   }
   else
   {
      pSiConEvnt->displayInfo.eh.pres = NOTPRSNT;
      pSiConEvnt->confTrtInd.eh.pres = NOTPRSNT;
      pSiConEvnt->netMgmtControls.eh.pres = NOTPRSNT;
      pSiConEvnt->correlationId.eh.pres = NOTPRSNT;
      pSiConEvnt->callDivTrtInd.eh.pres = NOTPRSNT;
      pSiConEvnt->callInNmb.eh.pres = NOTPRSNT;
      pSiConEvnt->callOfferTrtInd.eh.pres = NOTPRSNT;
      pSiConEvnt->scfId.eh.pres = NOTPRSNT;
      pSiConEvnt->uidCapInd.eh.pres = NOTPRSNT;
      pSiConEvnt->collCallReq.eh.pres = NOTPRSNT;
      pSiConEvnt->ccss.eh.pres = NOTPRSNT;
   }
#else
   /* display information */
   CMCHKUNPKLOG(siUnpkDisplayInfo,&pSiConEvnt->displayInfo, mBuf,ESIT429,pst);
   /* confrence treatment indicators */
   CMCHKUNPKLOG(siUnpkConfTrtInd,&pSiConEvnt->confTrtInd, mBuf,ESIT430,pst);
   /* network management controls */
   CMCHKUNPKLOG(siUnpkNetMgmtControls,&pSiConEvnt->netMgmtControls,
                 mBuf,ESIT431,pst);
   /* correlation Id */
   CMCHKUNPKLOG(siUnpkCorrelationId,&pSiConEvnt->correlationId,
                 mBuf,ESIT432,pst);
   /* call diversion treatment ind */
   CMCHKUNPKLOG(siUnpkCallDivTrtInd,&pSiConEvnt->callDivTrtInd,
                 mBuf,ESIT433,pst);
   /* call IN number */
   CMCHKUNPKLOG(siUnpkCallInNmb,&pSiConEvnt->callInNmb, mBuf,ESIT434,pst);
   /* call offering treatment ind */
   CMCHKUNPKLOG(siUnpkCallOfferTrtInd,&pSiConEvnt->callOfferTrtInd,
                 mBuf,ESIT435,pst);
   /* SCF Id */
   CMCHKUNPKLOG(siUnpkScfId,&pSiConEvnt->scfId, mBuf,ESIT436,pst);
   /* UID capability indicator */
   CMCHKUNPKLOG(siUnpkUidCapInd,&pSiConEvnt->uidCapInd, mBuf,ESIT437,pst);
   /* collect call request */
   CMCHKUNPKLOG(siUnpkCollCallReq,&pSiConEvnt->collCallReq, mBuf,ESIT438,pst);
   /* CCSS */
   CMCHKUNPKLOG(siUnpkCcss,&pSiConEvnt->ccss, mBuf,ESIT439,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT) || 
       (bitVector & SIT_SS7_ITU2000_BIT)
        || (bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiDisplayInfo  tempDisplayInfo;
         CMCHKUNPKLOG(siUnpkDisplayInfo,&tempDisplayInfo, mBuf,ESITXXX,pst);
      }
      {
         SiConfTrtInd tempTrtInd;
         CMCHKUNPKLOG(siUnpkConfTrtInd,&tempTrtInd, mBuf,ESITXXX,pst);
      }
      {
         SiNetMgmtControls tempMgmtControls;
         CMCHKUNPKLOG(siUnpkNetMgmtControls,&tempMgmtControls,mBuf,ESITXXX,pst);
      }
      {
         SiCorrelationId tempCorrelationId;
         CMCHKUNPKLOG(siUnpkCorrelationId,&tempCorrelationId, mBuf,ESITXXX,pst);
      }
      {
         SiCallDivTrtInd tempDivTrtInd;
         CMCHKUNPKLOG(siUnpkCallDivTrtInd,&tempDivTrtInd, mBuf,ESITXXX,pst);
      }
      {
         SiCallInNmb  tempCallInNmb;
         CMCHKUNPKLOG(siUnpkCallInNmb,&tempCallInNmb, mBuf,ESITXXX,pst);
      }
      {
         SiCallOfferTrtInd tempTrtInd;
         CMCHKUNPKLOG(siUnpkCallOfferTrtInd,&tempTrtInd, mBuf,ESITXXX,pst);
      }
      {
         SiScfId tempScfId;
         CMCHKUNPKLOG(siUnpkScfId,&tempScfId, mBuf,ESITXXX,pst);
      }
      {
         SiUidCapInd  tempCapInd;
         CMCHKUNPKLOG(siUnpkUidCapInd,&tempCapInd, mBuf,ESITXXX,pst);
      }
      {
         SiCollCallReq tempCallReq;
         CMCHKUNPKLOG(siUnpkCollCallReq,&tempCallReq, mBuf,ESITXXX,pst);
      }
      {
         SiCcss tempCcss;
         CMCHKUNPKLOG(siUnpkCcss,&tempCcss, mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_RUSS2000_BIT)
       || (bitVector & SIT_SS7_ITU2000_BIT))
   {
      /* backward GVNS */
      CMCHKUNPKLOG(siUnpkBackGVNS,&pSiConEvnt->backGVNS, mBuf,ESIT440,pst);
      /* forward GVNS */
      CMCHKUNPKLOG(siUnpkForwardGVNS,&pSiConEvnt->forwardGVNS, mBuf,ESIT441,pst);
   }
   else
   {
      pSiConEvnt->backGVNS.eh.pres = NOTPRSNT;
      pSiConEvnt->forwardGVNS.eh.pres = NOTPRSNT;
   }
#else
   /* backward GVNS */
   CMCHKUNPKLOG(siUnpkBackGVNS,&pSiConEvnt->backGVNS, mBuf,ESIT440,pst);
   /* forward GVNS */
   CMCHKUNPKLOG(siUnpkForwardGVNS,&pSiConEvnt->forwardGVNS, mBuf,ESIT441,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT)  || (bitVector & SIT_SS7_RUSS2000_BIT)
       || (bitVector & SIT_SS7_ITU2000_BIT))
   {
      {
         SiBackGVNS tempBackGVNS;
         CMCHKUNPKLOG(siUnpkBackGVNS,&tempBackGVNS, mBuf,ESITXXX,pst);
      }
      {
         SiForwardGVNS  tempFwGVNS;
         CMCHKUNPKLOG(siUnpkForwardGVNS,&tempFwGVNS, mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ETSIV3_BIT) || (bitVector & SIT_SS7_ITU97_BIT) ||
       (bitVector & SIT_SS7_RUSS2000_BIT)
       || (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_INDIA_BIT))
   {
      CMCHKUNPKLOG(siUnpkAppTransParam,&pSiConEvnt->appTransParam,
                    mBuf,ESIT442,pst);
   }
   else
      pSiConEvnt->appTransParam.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkAppTransParam,&pSiConEvnt->appTransParam,
                    mBuf,ESIT442,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ETSIV3_BIT) || (bitVector & SIT_SS7_ITU97_BIT) ||
       (bitVector & SIT_SS7_RUSS2000_BIT)
       || (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_INDIA_BIT))
   {
      SiAppTransParam tempTransParam;
      CMCHKUNPKLOG(siUnpkAppTransParam,&tempTransParam, mBuf,ESIT442,pst);
   }
#endif
   /* application transport parameter */
#endif

/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if SS7_ITU2000
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
      CMCHKUNPKLOG(siUnpkChargeNum,&pSiContEvnt->htrInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotCap,&pSiConEvnt->pivotCap,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiConEvnt->cadDirNmb,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkOrigCdNum,&pSiConEvnt->origCallInNum,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkCalgGeoLoc,&pSiContEvnt->calgGeoLoc,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkNetRoutNum,&pSiConEvnt->netRoutNum,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkQOnRelCap,&pSiConEvnt->qonRelCap,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotCntr,&pSiConEvnt->pivotCntr,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiConEvnt->pivotRtgFwInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiContEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkRedirStat,&pSiConEvnt->redirStat,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkNumPortFwdInfo,&pSiConEvnt->numPortFwdInfo,mBuf,ESITXXX,pst);
   }
   else
   {
      pSiConEvnt->htrInfo.eh.pres = NOTPRSNT;
      pSiConEvnt->pivotCap.eh.pres = NOTPRSNT;
      pSiConEvnt->cadDirNmb.eh.pres = NOTPRSNT;
      pSiConEvnt->origCallInNum.eh.pres = NOTPRSNT;
      pSiConEvnt->calgGeoLoc.eh.pres = NOTPRSNT;
      pSiConEvnt->netRoutNum.eh.pres = NOTPRSNT;
      pSiConEvnt->qonRelCap.eh.pres = NOTPRSNT;
      pSiConEvnt->pivotCntr.eh.pres = NOTPRSNT;
      pSiConEvnt->pivotRtgFwInfo.eh.pres = NOTPRSNT;
      pSiConEvnt->pivotRtgBkInfo.eh.pres = NOTPRSNT;
      pSiConEvnt->redirStat.eh.pres = NOTPRSNT;
      pSiConEvnt->numPortFwdInfo.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiConEvnt->htrInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotCap,&pSiConEvnt->pivotCap,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiConEvnt->cadDirNmb,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkOrigCdNum,&pSiConEvnt->origCallInNum,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkCalgGeoLoc,&pSiConEvnt->calgGeoLoc,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkNetRoutNum,&pSiConEvnt->netRoutNum,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkQOnRelCap,&pSiConEvnt->qonRelCap,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotCntr,&pSiConEvnt->pivotCntr,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiConEvnt->pivotRtgFwInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiConEvnt->pivotRtgBkInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkRedirStat,&pSiConEvnt->redirStat,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkNumPortFwdInfo,&pSiConEvnt->numPortFwdInfo,mBuf,ESITXXX,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
     SiChargeNum htrInfo;           
     SiPivotCap pivotCap;           
     SiCdPtyNum cadDirNmb;          
     SiOrigCdNum origCallInNum;     
     SiCalgGeoLoc calgGeoLoc;       
     SiNetRoutNum netRoutNum;      
     SiQOnRelCap qonRelCap;        
     SiPivotCntr pivotCntr;        
     SiPivotRtgBkInfo pivotRtgFwInfo;
     SiPivotRtgBkInfo pivotRtgBkInfo;
     SiRedirStat redirStat;          
     SiNumPortFwdInfo numPortFwdInfo;

     CMCHKUNPKLOG(siUnpkChargeNum,&htrInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotCap,&pivotCap,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkCdPtyNum,&cadDirNmb,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkOrigCdNum,&origCallInNum,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkCalgGeoLoc,&calgGeoLoc,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkNetRoutNum,&netRoutNum,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkQOnRelCap,&qonRelCap,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotCntr,&pivotCntr,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pivotRtgFwInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pivotRtgBkInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkRedirStat,&redirStat,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkNumPortFwdInfo,&numPortFwdInfo,mBuf,ESITXXX,pst); 
   }
#endif
#endif
   RETVALUE(ROK);
} /* end of siUnpkSiConEvnt */


/*
*
*       Fun:   siUnpkSiFacEvnt
*
*       Desc:  This function unpacks the "FacEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiFacEvnt
(
SiFacEvnt *pSiFacEvnt,         /* facility event */
Buffer *mBuf,                  /* message buffer */
Pst *pst,                      /* post structure */
U8 evntType                    /* event type */
)
#else
PUBLIC S16 siUnpkSiFacEvnt(pSiFacEvnt,mBuf,pst,evntType)
SiFacEvnt *pSiFacEvnt;          /* facility event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
U8 evntType;                    /* event type */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siUnpkSiFacEvnt)
   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SUnpkU8() function fails.
 */
   CMCHKUNPKLOG(SUnpkU32, &bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPKLOG(siUnpkFacInd,&pSiFacEvnt->facInd,mBuf,ESIT443,pst);      
   /* facility indicator */
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      CMCHKUNPKLOG(siUnpkFacInfInd,&pSiFacEvnt->facInfInd,mBuf,ESIT444,pst); 
      /* facility information indicator */
      CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiFacEvnt->cdPtyNum,mBuf,ESIT445,pst);  
      /* called party number */
      CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiFacEvnt->cgPtyNum,mBuf,ESIT446,pst);  
      /* calling party nmber */
   }
   else
   {
      pSiFacEvnt->facInfInd.eh.pres = NOTPRSNT;
      pSiFacEvnt->cdPtyNum.eh.pres = NOTPRSNT;
      pSiFacEvnt->cgPtyNum.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkFacInfInd,&pSiFacEvnt->facInfInd,mBuf,ESIT444,pst); 
   /* facility information indicator */
   CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiFacEvnt->cdPtyNum,mBuf,ESIT445,pst);  
   /* called party number */
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiFacEvnt->cgPtyNum,mBuf,ESIT446,pst);  
   /* calling party nmber */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      {
         SiFacInfInd tempInfInd;
         CMCHKUNPKLOG(siUnpkFacInfInd,&tempInfInd,mBuf,ESITXXX,pst); 
      }
      {
      
         SiCdPtyNum tempCdPtyNum;
         CMCHKUNPKLOG(siUnpkCdPtyNum,&tempCdPtyNum,mBuf,ESITXXX,pst);  
      }
      {
         SiCgPtyNum tempCgPtyNum;
         CMCHKUNPKLOG(siUnpkCgPtyNum,&tempCgPtyNum,mBuf,ESITXXX,pst);  
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif

#if (SS7_ANS88 || SS7_CHINA)
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiFacEvnt->callRefA,mBuf,ESIT447,pst);  
   /* call reference */
#endif

   CMCHKUNPKLOG(siUnpkUsr2UsrInd,&pSiFacEvnt->usr2UsrInd,mBuf,ESIT448,pst);
   /* user to user indicator */
   CMCHKUNPKLOG(siUnpkCallRef,&pSiFacEvnt->callRef,mBuf,ESIT449,pst);     
   /* call reference */
   CMCHKUNPKLOG(siUnpkCauseDgn,&pSiFacEvnt->causeDgn,mBuf,ESIT450,pst);     
   /* cause indicator */
   CMCHKUNPKLOG(siUnpkSiMsgCompInfo,&pSiFacEvnt->msgCom,mBuf,ESIT451,pst);   
   /* mssge comp info */
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiFacEvnt->parmCom,mBuf,ESIT452,pst);
   /* parameter cmptblty information */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiFacEvnt->remotOper1,mBuf,ESITXXX,pst);
   /* remote operat */
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiFacEvnt->serviceAct2,mBuf,ESITXXX,pst); 
   /* service activatn */
   CMCHKUNPKLOG(siUnpkConnReqA,&pSiFacEvnt->connReqA,mBuf,ESITXXX,pst);        
   /* connection request */
#endif
   CMCHKUNPKLOG(siUnpkSiRemotOper,&pSiFacEvnt->remotOper,mBuf,ESIT453,pst);
   /* remote operat */
   CMCHKUNPKLOG(siUnpkServiceAct,&pSiFacEvnt->serviceAct,mBuf,ESIT454,pst); 
   /* service activatn */
   CMCHKUNPKLOG(siUnpkConnReq,&pSiFacEvnt->connReq,mBuf,ESIT455,pst);        
   /* connection request */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ETSI_BIT) || (bitVector & SIT_SS7_ITU97_BIT)
       || (bitVector & SIT_SS7_RUSS2000_BIT || bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ETSIV3_BIT || bitVector & SIT_SS7_INDIA_BIT))
   {
      CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiFacEvnt->calTrnsNmb,mBuf,ESIT456,pst);
      /* Call Transfer Number*/
      CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiFacEvnt->accTrans,mBuf,ESIT457,pst);   
      /* access transport */
      CMCHKUNPKLOG(siUnpkNotifInd,&pSiFacEvnt->notifInd,mBuf,ESIT458,pst);     
      /* notification ind */
   }
   else
   {
      pSiFacEvnt->calTrnsNmb.eh.pres = NOTPRSNT;
      pSiFacEvnt->accTrans.eh.pres = NOTPRSNT;
      pSiFacEvnt->notifInd.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkCgPtyNum,&pSiFacEvnt->calTrnsNmb,mBuf,ESIT456,pst);
   /* Call Transfer Number*/
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiFacEvnt->accTrans,mBuf,ESIT457,pst);   
   /* access transport */
   CMCHKUNPKLOG(siUnpkNotifInd,&pSiFacEvnt->notifInd,mBuf,ESIT458,pst);     
   /* notification ind */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ETSI_BIT) || (bitVector & SIT_SS7_ITU97_BIT) || 
       (bitVector & SIT_SS7_RUSS2000_BIT) || (bitVector & SIT_SS7_ITU2000_BIT)
       || (bitVector & SIT_SS7_ETSIV3_BIT || bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiCgPtyNum tempTrnsNmb;
         CMCHKUNPKLOG(siUnpkCgPtyNum,&tempTrnsNmb,mBuf,ESITXXX,pst);
      }
      {
         SiAccTrnspt tempAccTrans;
         CMCHKUNPKLOG(siUnpkAccTrnspt,&tempAccTrans,mBuf,ESITXXX,pst);   
      }
      {
         SiNotifInd tempNotifInd;
         CMCHKUNPKLOG(siUnpkNotifInd,&tempNotifInd,mBuf,ESITXXX,pst);     
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if  SS7_ITU2000
   /* sit_c_005.main_15, MODIFIED: changes for ISUP ITU2000 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ETSI_BIT)
   {
     CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiFacEvnt->redirNum,mBuf,ESITXXX,pst);  
     /* redirection number */
     CMCHKUNPKLOG(siUnpkPivotRtgInd,&pSiFacEvnt->pivotRtgInd,mBuf,ESITXXX,pst);
     /* Pivot Routing Indicators */   
     CMCHKUNPKLOG(siUnpkPivotStat,&pSiFacEvnt->pivotStat,mBuf,ESITXXX,pst);
     /* Pivot Status */
     CMCHKUNPKLOG(siUnpkPivotCntr,&pSiFacEvnt->pivotCntr,mBuf,ESITXXX,pst);    
     /* Pivot Counter */
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiFacEvnt->pivotRtgBkInfo,mBuf,
                  ESITXXX,pst) ;
     /*Pivot Routing Backward Info*/
     CMCHKUNPKLOG(siUnpkRedirStat,&pSiFacEvnt->redirStat,mBuf,ESITXXX,pst); 
     /* Redirect Status */
   }
   else
   {
      pSiFacEvnt->redirNum.eh.pres = NOTPRSNT;
      pSiFacEvnt->pivotRtgInd.eh.pres = NOTPRSNT;
      pSiFacEvnt->pivotStat.eh.pres = NOTPRSNT;
      pSiFacEvnt->pivotCntr.eh.pres = NOTPRSNT;
      pSiFacEvnt->pivotRtgBkInfo.eh.pres = NOTPRSNT;
      pSiFacEvnt->redirStat.eh.pres = NOTPRSNT;
   }
#else
     CMCHKUNPKLOG(siUnpkCdPtyNum,&pSiFacEvnt->redirNum,mBuf,ESITXXX,pst);  
     /* redirection number */
     CMCHKUNPKLOG(siUnpkPivotRtgInd,&pSiFacEvnt->pivotRtgInd,mBuf,ESITXXX,pst);
     /* Pivot Routing Indicators */   
     CMCHKUNPKLOG(siUnpkPivotStat,&pSiFacEvnt->pivotStat,mBuf,ESITXXX,pst);
     /* Pivot Status */
     CMCHKUNPKLOG(siUnpkPivotCntr,&pSiFacEvnt->pivotCntr,mBuf,ESITXXX,pst);    
     /* Pivot Counter */
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiFacEvnt->pivotRtgBkInfo,mBuf,
                  ESITXXX,pst) ;
     /*Pivot Routing Backward Info*/
     CMCHKUNPKLOG(siUnpkRedirStat,&pSiFacEvnt->redirStat,mBuf,ESITXXX,pst); 
     /* Redirect Status */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if (bitVector & SIT_SS7_ITU2000_BIT)
   {
     SiCdPtyNum redirNum;     
     SiPivotRtgInd pivotRtgInd;
     SiPivotStat pivotStat; 
     SiPivotCntr pivotCntr;  
     SiPivotRtgBkInfo pivotRtgBkInfo;
     SiRedirStat redirStat; 

     CMCHKUNPKLOG(siUnpkCdPtyNum,&redirNum,mBuf,ESITXXX,pst);  
     CMCHKUNPKLOG(siUnpkPivotRtgInd,&pivotRtgInd,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotStat,&pivotStat,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotCntr,&pivotCntr,mBuf,ESITXXX,pst);    
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pivotRtgBkInfo,mBuf,ESITXXX,pst) ;
     CMCHKUNPKLOG(siUnpkRedirStat,&redirStat,mBuf,ESITXXX,pst); 
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#ifdef SS7_FTZ
   {
      S16 ret;
      if ((ret=siUnpkNaPaFF(&pSiFacEvnt->naPaFF,mBuf,evntType))!=ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__,
             __LINE__,(ErrCls)ERRCLS_DEBUG,(ErrVal)ESIT459,(ErrVal)ret,
             "Unpacking failure");
         RETVALUE(ret);
      }
   }
   /* National Parameter FF */
#endif
   RETVALUE(ROK);
} /* end of siUnpkSiFacEvnt */


/*
*
*       Fun:   siUnpkSiInfoEvnt
*
*       Desc:  This function unpacks the "InfoEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiInfoEvnt
(
SiInfoEvnt *pSiInfoEvnt,       /* Information Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siUnpkSiInfoEvnt(pSiInfoEvnt,mBuf,pst)
SiInfoEvnt *pSiInfoEvnt;        /* Information Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siUnpkSiInfoEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif


   CMCHKUNPKLOG(siUnpkCallRef,&pSiInfoEvnt->callRef,mBuf,ESIT460,pst); 
   /* call reference */
/* si034.220: Addition - added item for switch China */   
#if SS7_CHINA   
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiInfoEvnt->callRefA,mBuf,ESITXXX,pst); 
   /* call reference */
#endif /* if SS7_CHINA */   
   CMCHKUNPKLOG(siUnpkPassAlng,&pSiInfoEvnt->passAlng,mBuf,ESIT461,pst);
   /* pass along */
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiInfoEvnt->usr2UsrInfo,mBuf,ESIT462,pst); 
   /* user to user information */
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiInfoEvnt->accTrnspt,mBuf,ESIT463,pst);  
   /* access transport */
   RETVALUE(ROK);
} /* end of siUnpkSiInfoEvnt */


/*
*
*       Fun:   siUnpkSiRelEvnt
*
*       Desc:  This function unpacks the "RelEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiRelEvnt
(
SiRelEvnt *pSiRelEvnt,         /* Release Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siUnpkSiRelEvnt(pSiRelEvnt,mBuf,pst)
SiRelEvnt *pSiRelEvnt;          /* Release Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siUnpkSiRelEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SUnpkU8() function fails.
 */
   CMCHKUNPKLOG(SUnpkU32, &bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPKLOG(siUnpkCauseDgn,&pSiRelEvnt->causeDgn,mBuf,ESIT464,pst);  
   /* cause indicators */
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      CMCHKUNPKLOG(siUnpkRedirInfo,&pSiRelEvnt->redirInfoA,mBuf,ESIT465,pst); 
   }
   else
      pSiRelEvnt->redirInfoA.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiRelEvnt->redirInfoA,mBuf,ESIT465,pst); 
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      SiRedirInfo tempRedirInfoA;
      CMCHKUNPKLOG(siUnpkRedirInfo,&tempRedirInfoA,mBuf,ESITXXX,pst); 
   }
#endif
   /* redirection information */
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if SS7_BELL 
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiRelEvnt->redirgNumB,mBuf,ESITXXX,pst);  
   /* redirection number */
#endif
#endif /* SIT_PARAMETER */
   CMCHKUNPKLOG(siUnpkRedirInfo,&pSiRelEvnt->redirInfo,mBuf,ESIT466,pst);  
   /* redirection information */
   CMCHKUNPKLOG(siUnpkCdPtyNum, &pSiRelEvnt->redirNum,mBuf,ESIT467,pst);
   /* redirection number*/
#if SS7_ANS88
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      CMCHKUNPKLOG(siUnpkRedirNum,&pSiRelEvnt->redirgNum,mBuf,ESIT468,pst);  
   }
   else
      pSiRelEvnt->redirgNum.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkRedirNum,&pSiRelEvnt->redirgNum,mBuf,ESIT468,pst);  
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS88_BIT)
   {
      SiRedirNum tempRedirgNum;
      CMCHKUNPKLOG(siUnpkRedirNum,&tempRedirgNum,mBuf,ESITXXX,pst);  
   }
#endif
   /* redirection number*/
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiRelEvnt->callRefA,mBuf,ESIT469,pst); 
   /* call reference */
#endif
#if (SS7_ANS88 || SS7_CHINA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & (SIT_SS7_ANS88_BIT | SIT_SS7_CHINA_BIT))
   {
      CMCHKUNPKLOG(siUnpkSigPointCodeA,&pSiRelEvnt->sigPointCodeA,mBuf,ESIT470,
                  pst); 
      /* signalling point code */
   }
   else
   {
      pSiRelEvnt->sigPointCodeA.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkSigPointCodeA,&pSiRelEvnt->sigPointCodeA,mBuf,ESIT470,
               pst); 
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & (SIT_SS7_ANS88_BIT | SIT_SS7_CHINA_BIT))
   {
      {
         SiSigPointCodeA tempPointCodeA;
         CMCHKUNPKLOG(siUnpkSigPointCodeA,&tempPointCodeA,mBuf,ESITXXX, pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS88 || SS7_CHINA */

#if (SS7_ANS88)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & (SIT_SS7_ANS88_BIT))
   {
      CMCHKUNPKLOG(siUnpkCugIntCodeA,&pSiRelEvnt->cugIntCodeA,mBuf,ESIT471,pst); 
      /* closed group interlock code */
   }
   else
   {
      pSiRelEvnt->cugIntCodeA.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkCugIntCodeA,&pSiRelEvnt->cugIntCodeA,mBuf,ESIT471,pst); 
   /* closed group interlock code */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & (SIT_SS7_ANS88_BIT))
   {
      {
         SiCugIntCodeA tempIntCodeA;
         CMCHKUNPKLOG(siUnpkCugIntCodeA,&tempIntCodeA,mBuf,ESITXXX,pst); 
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS88 */



   CMCHKUNPKLOG(siUnpkSigPointCode,&pSiRelEvnt->sigPointCode,mBuf,ESIT472,pst);
   /* signalling point code */
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiRelEvnt->accTrnspt,mBuf,ESIT473,pst);    
   /* access transport */
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiRelEvnt->usr2UsrInfo,mBuf,ESIT474,pst); 
   /* user to user  information */
   CMCHKUNPKLOG(siUnpkAutoCongLvl,&pSiRelEvnt->autoCongLvl,mBuf,ESIT475,pst); 
   /* automatic congestion level */
/* si034.220: Addition - Changes for CHINA */
#ifdef SS7_CHINA
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiRelEvnt->accDelInfo1,mBuf,ESITXXX,pst); 
   /* access delivery  */
#endif
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiRelEvnt->accDelInfo,mBuf,ESIT476,pst); 
   /* access delivery  */
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiRelEvnt->parmCom,mBuf,ESIT477,pst); 
   /* parameter cmptblty information */
   CMCHKUNPKLOG(siUnpkSiNetSpecFacil,&pSiRelEvnt->netFac,mBuf,ESIT478,pst);  
   /* network specific */
   CMCHKUNPKLOG(siUnpkSiRedirRestr,&pSiRelEvnt->redirRstr,mBuf,ESIT479,pst); 
   /* redirection restr */
   CMCHKUNPKLOG(siUnpkUsr2UsrInd,&pSiRelEvnt->usr2UsrInd,mBuf,ESIT480,pst); 
   /* user to user */ 
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkChargeNum,&pSiRelEvnt->chargeNum,mBuf,ESIT481,pst); 
      /* charge number */
      CMCHKUNPKLOG(siUnpkGenAddr,&pSiRelEvnt->genAddr,mBuf,ESIT482,pst);    
      /* generic address */
      CMCHKUNPKLOG(siUnpkGenAddr,&pSiRelEvnt->genAddrR,mBuf,ESIT483,pst);     
      /* generic address */
   }
#ifndef SS7_BELL
   else
   {
      pSiRelEvnt->chargeNum.eh.pres = NOTPRSNT;
      pSiRelEvnt->genAddr.eh.pres = NOTPRSNT;
      pSiRelEvnt->genAddrR.eh.pres = NOTPRSNT;
   }
#endif
#else
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiRelEvnt->chargeNum,mBuf,ESIT481,pst); 
   /* charge number */
   CMCHKUNPKLOG(siUnpkGenAddr,&pSiRelEvnt->genAddr,mBuf,ESIT482,pst);    
   /* generic address */
   CMCHKUNPKLOG(siUnpkGenAddr,&pSiRelEvnt->genAddrR,mBuf,ESIT483,pst);     
   /* generic address */
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      {
         SiChargeNum tempChargeNum;
         CMCHKUNPKLOG(siUnpkChargeNum,&tempChargeNum,mBuf,ESITXXX,pst); 
      }
      {
         SiGenAddr tempGenAddr;
         CMCHKUNPKLOG(siUnpkGenAddr,&tempGenAddr,mBuf,ESITXXX,pst);    
         CMCHKUNPKLOG(siUnpkGenAddr,&tempGenAddr,mBuf,ESITXXX,pst);    
         /* generic address and repeated generic addr */
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if SS7_Q767IT
   CMCHKUNPKLOG(siUnpkBackVadInd,&pSiRelEvnt->backVad,mBuf,ESIT484,pst);    
   /* backward vad ind*/
#endif
#if SS7_SINGTEL
   CMCHKUNPKLOG(siUnpkTrnkOff,&pSiRelEvnt->trnkOff,mBuf,ESIT485,pst);     
   /* trunk offer info */
#endif
#if SS7_NTT
   /* called party number */
   CMCHKUNPKLOG(siUnpkCdPtyNum, &pSiRelEvnt->cdPtyNum,mBuf,ESIT486,pst);
#endif
#if (SS7_NTT || SS7_ANS95)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_NTT
   if (bitVector & SIT_SS7_ANS95_BIT)
#endif
   {
      CMCHKUNPKLOG(siUnpkServiceAct, &pSiRelEvnt->serviceAct,mBuf,ESIT487,pst);
   }
#ifndef SS7_NTT
   else
      pSiRelEvnt->serviceAct.eh.pres = NOTPRSNT;
#endif
#else
   CMCHKUNPKLOG(siUnpkServiceAct, &pSiRelEvnt->serviceAct,mBuf,ESIT487,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT)
   {
      SiServiceAct tempServiceAct;
      CMCHKUNPKLOG(siUnpkServiceAct, &tempServiceAct,mBuf,ESITXXX,pst);
   }
#endif
   /* service activation */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || SS7_INDIA)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT) || 
       (bitVector & SIT_SS7_RUSS2000_BIT) || (bitVector & SIT_SS7_ITU2000_BIT)
        || (bitVector & SIT_SS7_INDIA_BIT))
   {
      /* display information */
      CMCHKUNPKLOG(siUnpkDisplayInfo, &pSiRelEvnt->displayInfo,mBuf,ESIT488,pst);
      /* remote operations */
      CMCHKUNPKLOG(siUnpkSiRemotOper, &pSiRelEvnt->remotOper,mBuf,ESIT489,pst);
   }
   else
   {
      pSiRelEvnt->displayInfo.eh.pres = NOTPRSNT;
      pSiRelEvnt->remotOper.eh.pres = NOTPRSNT;
   }
#else
   /* display information */
   CMCHKUNPKLOG(siUnpkDisplayInfo, &pSiRelEvnt->displayInfo,mBuf,ESIT488,pst);
   /* remote operations */
   CMCHKUNPKLOG(siUnpkSiRemotOper, &pSiRelEvnt->remotOper,mBuf,ESIT489,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_003.main_15: Addition - added SS7_INDIA */
   if ((bitVector & SIT_SS7_ITU97_BIT) || (bitVector & SIT_SS7_ETSIV3_BIT) || 
       (bitVector & SIT_SS7_RUSS2000_BIT) || (bitVector & SIT_SS7_ITU2000_BIT)
        || (bitVector & SIT_SS7_INDIA_BIT))
   {
      {
         SiDisplayInfo tempDisplayInfo;
         CMCHKUNPKLOG(siUnpkDisplayInfo, &tempDisplayInfo,mBuf,ESITXXX,pst);
      }
      {
         SiRemotOper tempOper;
         CMCHKUNPKLOG(siUnpkSiRemotOper, &tempOper,mBuf,ESITXXX,pst);
      }
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if SS7_ITU2000
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
      CMCHKUNPKLOG(siUnpkChargeNum,&pSiReltEvnt->htrInfo,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkRedirCntr,&pSiRelEvnt->redirCntr,mBuf,ESITXXX,pst);
      CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiRelEvnt->redirBkInfo,mBuf,ESITXXX,pst);
   }
   else
   {
      pSiRelEvnt->htrInfo.eh.pres = NOTPRSNT;
      pSiRelEvnt->redirCntr.eh.pres = NOTPRSNT;
      pSiRelEvnt->redirBkInfo.eh.pres = NOTPRSNT;
   }
#else
   CMCHKUNPKLOG(siUnpkChargeNum,&pSiRelEvnt->htrInfo,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkRedirCntr,&pSiRelEvnt->redirCntr,mBuf,ESITXXX,pst);
   CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&pSiRelEvnt->redirBkInfo,mBuf,ESITXXX,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ITU2000_BIT) 
   {
     SiChargeNum htrInfo;           
     SiRedirCntr redirCntr;       
     SiPivotRtgBkInfo redirBkInfo;

     CMCHKUNPKLOG(siUnpkChargeNum,&htrInfo,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkRedirCntr,&redirCntr,mBuf,ESITXXX,pst);
     CMCHKUNPKLOG(siUnpkPivotRtgBkInfo,&redirBkInfo,mBuf,ESITXXX,pst);
   }
#endif
#endif
   RETVALUE(ROK);
} /* end of siUnpkSiRelEvnt */


/*
*
*       Fun:   siUnpkSiResmEvnt
*
*       Desc:  This function unpacks the "ResmEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiResmEvnt
(
SiResmEvnt *pSiResmEvnt,       /* resume event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siUnpkSiResmEvnt(pSiResmEvnt,mBuf,pst)
SiResmEvnt *pSiResmEvnt;        /* resume event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siUnpkSiResmEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   CMCHKUNPKLOG(siUnpkSusResInd,&pSiResmEvnt->susResInd,mBuf,ESIT490,pst);  
   /* Suspend/Resume indicators */
/* si034.220: Addition - Changes for CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiResmEvnt->callRefA,mBuf,ESIT491,pst);  
   /* call reference */
#endif
   CMCHKUNPKLOG(siUnpkCallRef,&pSiResmEvnt->callRef,mBuf,ESIT492,pst);   
   /* call reference */
   RETVALUE(ROK);
} /* end of siUnpkSiResmEvnt */


/*
*
*       Fun:   siUnpkSiStaEvnt
*
*       Desc:  This function unpacks the "StaEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiStaEvnt
(
SiStaEvnt *pSiStaEvnt,     /* Status Event */
Buffer *mBuf,              /* message buffer */
Pst *pst                    /* post structure */
)
#else
PUBLIC S16 siUnpkSiStaEvnt(pSiStaEvnt,mBuf,pst)
SiStaEvnt *pSiStaEvnt;      /* Status Event */
Buffer *mBuf;               /* message buffer */
Pst *pst;                   /* post structure */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siUnpkSiStaEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* sit_c_002.main_15 - Modification. Modified macro to ensure that SPutMsg
 * is called if the SUnpkU8() function fails.
 */
   CMCHKUNPKLOG(SUnpkU32, &bitVector, mBuf, ESITXXX, pst);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPKLOG(siUnpkRangStat,&pSiStaEvnt->rangStat,mBuf,ESIT493,pst);   
   /* range and status */
   CMCHKUNPKLOG(siUnpkCirGrpSupMTypInd,&pSiStaEvnt->cgsmti,mBuf,ESIT494,pst);
   /* circuit group supv. msg. type indictrs*/
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPKLOG(siUnpkCirStateInd,&pSiStaEvnt->cirSteIndA,mBuf,ESIT495,pst);
   /* circuit state indicators */
#endif
   CMCHKUNPKLOG(siUnpkCirStateInd,&pSiStaEvnt->cirStateInd,mBuf,ESIT496,pst);
   /* circuit state indicators */
   CMCHKUNPKLOG(siUnpkContInd,&pSiStaEvnt->contInd,mBuf,ESIT497,pst);
   /* continuity indicator */
   CMCHKUNPKLOG(siUnpkCauseDgn,&pSiStaEvnt->causeDgn,mBuf,ESIT498,pst);
   /* cause indicators */
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiStaEvnt->parmCom,mBuf,ESIT499,pst);
   /* parameter cmptblty information */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
#endif
   {
      CMCHKUNPKLOG(siUnpkNatConInd,&pSiStaEvnt->natConInd,mBuf,ESIT500,pst);
   }
#ifndef SS7_BELL
   else
      pSiStaEvnt->natConInd.eh.pres = NOTPRSNT;
#endif
#else
   CMCHKUNPKLOG(siUnpkNatConInd,&pSiStaEvnt->natConInd,mBuf,ESIT500,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & SIT_SS7_ANS92_BIT) || (bitVector & SIT_SS7_ANS95_BIT))
   {
      SiNatConInd tempConInd;
      CMCHKUNPKLOG(siUnpkNatConInd,&tempConInd,mBuf,ESITXXX,pst);
   }
#endif
   /* Nature of connection indicators */
#endif
#if SS7_ANS95
   /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT)
   {
      CMCHKUNPKLOG(siUnpkCirAsgnMap,&pSiStaEvnt->cirAsgnMap,mBuf,ESIT501,pst);
   }
   else
      pSiStaEvnt->cirAsgnMap.eh.pres = NOTPRSNT;
#else
   CMCHKUNPKLOG(siUnpkCirAsgnMap,&pSiStaEvnt->cirAsgnMap,mBuf,ESIT501,pst);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & SIT_SS7_ANS95_BIT)
   {
      SiCirAsgnMap tempAsgnMap;
      CMCHKUNPKLOG(siUnpkCirAsgnMap,&tempAsgnMap,mBuf,ESITXXX,pst);
   }
#endif
   /* circuit assignment map */
#endif

   RETVALUE(ROK);
} /* end of siUnpkSiStaEvnt */


/*
*
*       Fun:   siUnpkSiSuspEvnt
*
*       Desc:  This function unpacks the "SuspEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI 
PUBLIC S16 siUnpkSiSuspEvnt
(
SiSuspEvnt *pSiSuspEvnt,       /* Suspend Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst                        /* post structure */
)
#else
PUBLIC S16 siUnpkSiSuspEvnt(pSiSuspEvnt,mBuf,pst)
SiSuspEvnt *pSiSuspEvnt;        /* Suspend Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
#endif
{
   TRC3(siUnpkSiSuspEvnt)
#if (!(ERRCLASS & ERRCLS_ADD_RES))
   UNUSED(pst);
#endif

   CMCHKUNPKLOG(siUnpkSusResInd,&pSiSuspEvnt->susResInd,mBuf,ESIT502,pst);
   /* suspend/resume indicators */
/* si034.220: Addition - Changes for CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
   CMCHKUNPKLOG(siUnpkCallRefA,&pSiSuspEvnt->callRefA,mBuf,ESIT503,pst);
   /* call reference */
#endif
   CMCHKUNPKLOG(siUnpkCallRef,&pSiSuspEvnt->callRef,mBuf,ESIT504,pst);
   /* call reference */
   RETVALUE(ROK);
} /* end of siUnpkSiSuspEvnt */

#if SS7_FTZ

/*
*
*       Fun:   siUnpkSiFtzEvnt
*
*       Desc:  This function unpacks the "FtzEvnt" event structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkSiFtzEvnt
(
SiFtzEvnt *pSiFtzEvnt,         /* FTZ utilities Event */
Buffer *mBuf,                  /* message buffer */
Pst *pst,                      /* post structure */
U8 evntType                    /* event type */
)
#else
PUBLIC S16 siUnpkSiFtzEvnt(pSiFtzEvnt,mBuf,pst,evntType)
SiFtzEvnt *pSiFtzEvnt;          /* FTZ utilities Event */
Buffer *mBuf;                   /* message buffer */
Pst *pst;                       /* post structure */
U8 evntType;                    /* event type */
#endif
{
   TRC3(siUnpkSiFtzEvnt)

   CMCHKUNPKLOG(siUnpkSiMsgCompInfo,&pSiFtzEvnt->msgCom,mBuf,ESIT505,pst);
   /* message compatibility information */
   CMCHKUNPKLOG(siUnpkSiParmCompInfo,&pSiFtzEvnt->parmComp,mBuf,ESIT506,pst);
   /* parameter compatibility information */
   CMCHKUNPKLOG(siUnpkSiAccDelInfo,&pSiFtzEvnt->accDelInfo,mBuf,ESIT507,pst);
   /* access delivery information */
   CMCHKUNPKLOG(siUnpkAccTrnspt,&pSiFtzEvnt->accTrnspt,mBuf,ESIT508,pst);
   /* access transport */
   CMCHKUNPKLOG(siUnpkAutoCongLvl,&pSiFtzEvnt->auCongLvl,mBuf,ESIT509,pst);
   /* automatic congestion level */
   CMCHKUNPKLOG(siUnpkCauseDgn,&pSiFtzEvnt->causeDgn,mBuf,ESIT510,pst);
   /* cause indicator */
   CMCHKUNPKLOG(siUnpkFacInd,&pSiFtzEvnt->facInd,mBuf,ESIT511,pst);
   /* facility indicator */
   CMCHKUNPKLOG(siUnpkFacIndInfor,&pSiFtzEvnt->facIndInf,mBuf,ESIT512,pst);
   /* Facility Information Indicator */
   {
      S16 ret;
      if ((ret=siUnpkNaPaFF(&pSiFtzEvnt->naPaFF,mBuf,evntType))!=ROK)
      {
         SPutMsg(mBuf);
         SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId, __FILE__,
             __LINE__,(ErrCls)ERRCLS_DEBUG,(ErrVal)ESIT513,(ErrVal)ret,
             "Unpacking failure");
         RETVALUE(ret);
      }
   }
   /* National Parameter FF */
   CMCHKUNPKLOG(siUnpkNaPaCHGI,&pSiFtzEvnt->naPaCHGI,mBuf,ESIT514,pst);
   /* National Parameter for charging infor. */
   CMCHKUNPKLOG(siUnpkNaPaTTZ,&pSiFtzEvnt->naPaTTZ,mBuf,ESIT515,pst);
   /* National Parameter for Tln-2-Tln sign. */
   CMCHKUNPKLOG(siUnpkSigPointCode,&pSiFtzEvnt->sigPointCode,mBuf,ESIT516,pst);
   /* signalling point code */
   CMCHKUNPKLOG(siUnpkUsr2UsrInd,&pSiFtzEvnt->usr2UsrInd,mBuf,ESIT517,pst);
   /* user to user indicator */
   CMCHKUNPKLOG(siUnpkUsr2UsrInfo,&pSiFtzEvnt->usr2UsrInfo,mBuf,ESIT518,pst);
   /* user to user information */

   RETVALUE(ROK);
} /* end of siUnpkSiFtzEvnt */
#endif /* SS7_FTZ */

/* unpacking functions for ISUP information elements */


/*
*
*       Fun:   siUnpkAccTrnspt
*
*       Desc:  This function unpacks the "AccTrnspt" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkAccTrnspt
(
SiAccTrnspt *pAccTrnspt,                /* Access transport */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkAccTrnspt(pAccTrnspt,mBuf)
SiAccTrnspt *pAccTrnspt;                 /* Access transport */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkAccTrnspt)
   CMCHKUNPK(cmUnpkElmtHdr,&pAccTrnspt->eh,mBuf);
   /* element header */
   if (pAccTrnspt->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pAccTrnspt->infoElmts,mBuf);  
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkAccTrnspt */


/*
*
*       Fun:   siUnpkAutoCongLvl
*
*       Desc:  This function unpacks the "AutoCongLvl" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkAutoCongLvl
(
SiAutoCongLvl *pAutoCongLvl,            /* Autonatic Congestion Level */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkAutoCongLvl(pAutoCongLvl,mBuf)
SiAutoCongLvl *pAutoCongLvl;             /* Autonatic Congestion Level */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkAutoCongLvl)
   CMCHKUNPK(cmUnpkElmtHdr,&pAutoCongLvl->eh,mBuf);
   /* element header */
   if (pAutoCongLvl->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pAutoCongLvl->auCongLvl,mBuf); 
      /* auto congestion level */
   }
   RETVALUE(ROK);
} /* end of siUnpkAutoCongLvl */


/*
*
*       Fun:   siUnpkSubNum
*
*       Desc:  This function unpacks the "SubNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSubNum
(
SiSubNum *pSubNum,                      /* subsequent number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSubNum(pSubNum,mBuf)
SiSubNum *pSubNum;                       /* subsequent number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSubNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pSubNum->eh,mBuf);
   /* element header */
   if (pSubNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pSubNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknStr,&pSubNum->addrSig,mBuf);  
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkSubNum */


/*
*
*       Fun:   siUnpkBckCalInd
*
*       Desc:  This function unpacks the "BckCalInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkBckCalInd
(
SiBckCalInd *pBckCalInd,                /* Backward Call Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkBckCalInd(pBckCalInd,mBuf)
SiBckCalInd *pBckCalInd;                 /* Backward Call Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkBckCalInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pBckCalInd->eh,mBuf);
   /* element header */
   if (pBckCalInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->chrgInd,mBuf);   
      /* Charge Indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->cadPtyStatInd,mBuf);
      /* called party status indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->cadPtyCatInd,mBuf);
      /* called party category indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->end2EndMethInd,mBuf);
      /* end to end method indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->intInd,mBuf);  
      /* interworking indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->end2EndInfoInd,mBuf); 
      /* end to end info indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->isdnUsrPrtInd,mBuf);  
      /* ISDN User Part indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->holdInd,mBuf);   
      /* holding indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->isdnAccInd,mBuf);  
      /* ISDN access indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->echoCtrlDevInd,mBuf); 
      /* echo control device indicator */
      CMCHKUNPK(cmUnpkTknU8,&pBckCalInd->sccpMethInd,mBuf);  
      /* SCCP method indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkBckCalInd */


/*
*
*       Fun:   siUnpkCallRef
*
*       Desc:  This function unpacks the "CallRef" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCallRef
(
SiCallRef *pCallRef,                    /* Call Reference */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCallRef(pCallRef,mBuf)
SiCallRef *pCallRef;                     /* Call Reference */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCallRef)
   CMCHKUNPK(cmUnpkElmtHdr,&pCallRef->eh,mBuf);
   /* element header */
   if (pCallRef->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pCallRef->callId,mBuf);   
      /* call identity */
      CMCHKUNPK(cmUnpkTknU16,&pCallRef->pntCde,mBuf);    
      /* point code */
   }
   RETVALUE(ROK);
} /* end of siUnpkCallRef */


/*
*
*       Fun:   siUnpkSiPropDly 
*
*       Desc:  This function unpacks the propagation delay counter info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiPropDly
(
SiPropDly *pPropDly,                    /* propagation delay */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiPropDly(pPropDly,mBuf)
SiPropDly *pPropDly;                     /* propagation delay */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiPropDly)
   CMCHKUNPK(cmUnpkElmtHdr,&pPropDly->eh,mBuf);
   /* element header */
   if (pPropDly->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU16,&pPropDly->delayVal,mBuf); 
      /* delay value */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiPropDly */


/*
*
*       Fun:   siUnpkSiNetSpecFacil
*
*       Desc:  This function unpacks the network specific facility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiNetSpecFacil
(
SiNetSpecFacil *pNetFac,                /* network facility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiNetSpecFacil(pNetFac,mBuf)
SiNetSpecFacil *pNetFac;                 /* network facility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiNetSpecFacil)
   CMCHKUNPK(cmUnpkElmtHdr,&pNetFac->eh,mBuf);
   /* element header */
   if (pNetFac->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pNetFac->netFac,mBuf); 
      /* network facility */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiNetSpecFacil */

#if SS7_SINGTEL

/*
*
*       Fun:   siUnpkTrnkOff
*
*       Desc:  This function unpacks the trunk offering info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkTrnkOff
(
TrnkOff *pTrnkOff,                      /* trunk offering Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkTrnkOff(pTrnkOff,mBuf)
TrnkOff *pTrnkOff;                       /* trunk offering Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkTrnkOff)
   CMCHKUNPK(cmUnpkElmtHdr,&pTrnkOff->eh,mBuf);
   /* element header */
   if (pTrnkOff->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pTrnkOff->trnkOffInfo,mBuf);  
      /* trunk offering Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkTrnkOff */


/*
*
*       Fun:   siUnpkCllChrgeInfo
*
*       Desc:  This function unpacks the call charge info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCllChrgeInfo
(
SiCllChrgeInfo *pCllChrgeInfo,            /* call charge Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCllChrgeInfo(pCllChrgeInfo,mBuf)
SiCllChrgeInfo *pCllChrgeInfo;             /* call charge Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCllChrgeInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pCllChrgeInfo->eh,mBuf);
   /* element header */
   if (pCllChrgeInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCllChrgeInfo->typeCalls,mBuf);
      /* type of calls */
      CMCHKUNPK(cmUnpkTknU8,&pCllChrgeInfo->chgeMeth,mBuf); 
      /* charging method */
      CMCHKUNPK(cmUnpkTknU8,&pCllChrgeInfo->chgePrty,mBuf);
      /* chargeable party */
      CMCHKUNPK(cmUnpkTknU8,&pCllChrgeInfo->chgePoint,mBuf);
      /* charge point */
      CMCHKUNPK(cmUnpkTknU16,&pCllChrgeInfo->pntCde,mBuf);  
      /* point code */
   }
   RETVALUE(ROK);
} /* end of siUnpkCllChrgeInfo */


/*
*
*       Fun:   siUnpkChrgeRateInfo
*
*       Desc:  This function unpacks the charge rate info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkChrgeRateInfo
(
SiChrgeRateInfo *pChrgeRateInfo,          /* charge rate Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkChrgeRateInfo(pChrgeRateInfo,mBuf)
SiChrgeRateInfo *pChrgeRateInfo;           /* charge rate Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkChrgeRateInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pChrgeRateInfo->eh,mBuf);
   /* element header */
   if (pChrgeRateInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pChrgeRateInfo->pktChrgng,mBuf);
      /* packet chagring */
      CMCHKUNPK(cmUnpkTknU8,&pChrgeRateInfo->tariffCat,mBuf);
      /* tariff category */
      CMCHKUNPK(cmUnpkTknU8,&pChrgeRateInfo->tariffUnit,mBuf);
      /* tariff unit */
      CMCHKUNPK(cmUnpkTknU8,&pChrgeRateInfo->tariffFact,mBuf);
      /* tariff factor chagring */
      CMCHKUNPK(cmUnpkTknU16,&pChrgeRateInfo->nominalTime,mBuf);
      /* nominal time */
   }
   RETVALUE(ROK);
} /* end of siUnpkChrgeRateInfo */
#endif

/* sit_c_003.main_15: Addition - added packing and unpacking
 * functions for Indian variant */
#if (SS7_INDIA || defined(TDS_ROLL_UPGRADE_SUPPORT)) 

/*
*
*       Fun:   siUnpkCllChrgeBnd
*
*       Desc:  This function unpacks the charge band info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCllChrgeBnd
(
SiChargeBand *pCllChrgeBnd,
Buffer *mBuf               
)
#else
PRIVATE S16 siUnpkCllChrgeBnd(pCllChrgeBnd,mBuf)
SiChargeBand *pCllChrgeBnd;
Buffer *mBuf;
#endif
{
   TRC2(siUnpkCllChrgeBnd)
   CMCHKUNPK(cmUnpkElmtHdr,&pCllChrgeBnd->eh,mBuf);
   /* element header */
   if (pCllChrgeBnd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCllChrgeBnd->chrgeBandNum,mBuf);  
      /* charge Band Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkCllChrgeBnd */
#endif
 
#ifdef SS7_INDIA

/*
*
*       Fun:   siPkCllChrgeBnd
*
*       Desc:  This function packs the call charge band info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkCllChrgeBnd
(
SiChargeBand *pCllChrgeBnd,
Buffer *mBuf 
)
#else
PRIVATE S16 siPkCllChrgeBnd(pCllChrgeBnd,mBuf)
SiChargeBand *pCllChrgeBnd;
Buffer *mBuf;
#endif
{
   TRC2(siPkCllChrgeBnd)
   if (pCllChrgeBnd->eh.pres)
   {
      CMCHKPK(cmPkTknU8,&pCllChrgeBnd->chrgeBandNum,mBuf); 
      /* charge Band Info */
   }
   CMCHKPK(cmPkElmtHdr,&pCllChrgeBnd->eh,mBuf); 
   /* element header */
   RETVALUE(ROK);
} /* end of siPkCllChrgeBnd */
#endif /* SS7_INDIA */

/* si034.220: Addition - added packing and unpacking
 * functions for CHINA variant */
#ifdef SS7_CHINA 

/*
*
*       Fun:   siUnpkChargeInform
*
*       Desc:  This function unpacks the charge information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkChargeInform
(
SiChargeInform *pChargeInform,
Buffer *mBuf               
)
#else
PRIVATE S16 siUnpkChargeInform(pChargeInform,mBuf)
SiChargeInform *pChargeInform;
Buffer *mBuf;
#endif
{
   TRC2(siUnpkChargeInform)
   CMCHKUNPK(cmUnpkElmtHdr,&pChargeInform->eh,mBuf);
   /* element header */
   if (pChargeInform->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU16,&pChargeInform->chargeInformation,mBuf);  
      /* charge Information */
   }
   RETVALUE(ROK);
} /* end of siUnpkChargeInform */
#endif /* if SS7_CHINA */
 
#ifdef SS7_CHINA 

/*
*
*       Fun:   siPkChargeInform
*
*       Desc:  This function unpacks the charge information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siPkChargeInform
(
SiChargeInform *pChargeInform,
Buffer *mBuf               
)
#else
PRIVATE S16 siPkChargeInform(pChargeInform,mBuf)
SiChargeInform *pChargeInform;
Buffer *mBuf;
#endif
{
   TRC2(siPkChargeInform)
   if (pChargeInform->eh.pres)
   {
      CMCHKPK(cmPkTknU16,&pChargeInform->chargeInformation,mBuf);  
      /* charge Information */
   }
   CMCHKPK(cmPkElmtHdr,&pChargeInform->eh,mBuf);
   /* element header */
   RETVALUE(ROK);
} /* end of siPkChargeInform */
#endif /* if SS7_CHINA */

#if SS7_Q767IT

/*
*
*       Fun:   siUnpkFwdVadInd
*
*       Desc:  This function unpacks the forward vad indicator
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkFwdVadInd
(
SiFwdVadInd *pFwdVadInd,                /* forward vad indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkFwdVadInd(pFwdVadInd,mBuf)
SiFwdVadInd *pFwdVadInd;                 /* forward vad indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkFwdVadInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pFwdVadInd->eh,mBuf);
   /* element header */
   if (pFwdVadInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFwdVadInd->procInd,mBuf); 
      /* procedure indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdVadInd->srvSteInd,mBuf); 
      /* service state indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkFwdVadInd */


/*
*
*       Fun:   siUnpkBackVadInd
*
*       Desc:  This function unpacks the backward vad indicator
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkBackVadInd
(
SiBackVadInd *pBackVadInd,              /* backward vad indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkBackVadInd(pBackVadInd,mBuf)
SiBackVadInd *pBackVadInd;               /* backward vad indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkBackVadInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pBackVadInd->eh,mBuf);
   /* element header */
   if (pBackVadInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pBackVadInd->addrSig,mBuf); 
      /* Address Signal */
      CMCHKUNPK(cmUnpkTknU8,&pBackVadInd->oddEven,mBuf);  
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pBackVadInd->snInd,mBuf);    
      /* sn indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkBackVadInd */
#endif


/*
*
*       Fun:   siUnpkSiCllDiverInfo
*
*       Desc:  This function unpacks the call diversion info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiCllDiverInfo
(
SiCllDiverInfo *pCllDivr,               /* call Diversion information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiCllDiverInfo(pCllDivr,mBuf)
SiCllDiverInfo *pCllDivr;                /* call Diversion information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiCllDiverInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pCllDivr->eh,mBuf);
   /* element header */
   if (pCllDivr->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCllDivr->notSuscr,mBuf); 
      /* notification subscribtion */
      CMCHKUNPK(cmUnpkTknU8,&pCllDivr->redirRsn,mBuf);  
      /* redirection reason */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiCllDiverInfo */


/*
*
*       Fun:   siUnpkSiRedirRestr
*
*       Desc:  This function unpacks the redirection restriction
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiRedirRestr
(
SiRedirRestr *pRedirRstr,               /* redirection restriction */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiRedirRestr(pRedirRstr,mBuf)
SiRedirRestr *pRedirRstr;                /* redirection restriction */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiRedirRestr)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirRstr->eh,mBuf);
   /* element header */
   if (pRedirRstr->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirRstr->presRest,mBuf);
      /* presentation restr */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiRedirRestr */


/*
*
*       Fun:   siUnpkSiMcidReqInd
*
*       Desc:  This function unpacks the MCID request indicators
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiMcidReqInd
(
SiMcidReqInd *pMcidReq,                 /* MCID request indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiMcidReqInd(pMcidReq,mBuf)
SiMcidReqInd *pMcidReq;                  /* MCID request indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiMcidReqInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pMcidReq->eh,mBuf);
   /* element header */
   if (pMcidReq->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pMcidReq->reqInd,mBuf); 
      /* mcid request indicators */
      CMCHKUNPK(cmUnpkTknU8,&pMcidReq->hldInd,mBuf); 
      /* hold indicators */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiMcidReqInd */


/*
*
*       Fun:   siUnpkSiMcidRspInd
*
*       Desc:  This function unpacks the MCID response indicators
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiMcidRspInd
(
SiMcidRspInd *pMcidRsp,                 /* MCID response indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiMcidRspInd(pMcidRsp,mBuf)
SiMcidRspInd *pMcidRsp;                  /* MCID response indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiMcidRspInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pMcidRsp->eh,mBuf);
   /* element header */
   if (pMcidRsp->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pMcidRsp->rspInd,mBuf);  
      /* mcid response indicators */
      CMCHKUNPK(cmUnpkTknU8,&pMcidRsp->hldInd,mBuf);  
      /* hold indicators */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiMcidRspInd */


/*
*
*       Fun:   siUnpkSiRemotOper 
*
*       Desc:  This function unpacks the remote operation info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiRemotOper
(
SiRemotOper *pRemotOper,                /* remote operations */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiRemotOper(pRemotOper,mBuf)
SiRemotOper *pRemotOper;                 /* remote operations */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiRemotOper)
   CMCHKUNPK(cmUnpkElmtHdr,&pRemotOper->eh,mBuf);
   /* element header */
   if (pRemotOper->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRemotOper->protProf,mBuf); 
      /* protocol profile */
      CMCHKUNPK(cmUnpkTknStr,&pRemotOper->compon,mBuf);   
      /* components */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiRemotOper */


/*
*
*       Fun:   siUnpkSiAccDelInfo 
*
*       Desc:  This function unpacks the access delivery info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiAccDelInfo
(
SiAccDelInfo *pAccDelInfo,              /* access delivery */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiAccDelInfo(pAccDelInfo,mBuf)
SiAccDelInfo *pAccDelInfo;               /* access delivery */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiAccDelInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pAccDelInfo->eh,mBuf);
   /* element header */
   if (pAccDelInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pAccDelInfo->delInd,mBuf);    
      /* delivery indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiAccDelInfo */


/*
*
*       Fun:   siUnpkSiEchoCtl
*
*       Desc:  This function unpacks the echo control info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiEchoCtl
(
SiEchoCtl *pEchoCtl,                    /* echo control */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiEchoCtl(pEchoCtl,mBuf)
SiEchoCtl *pEchoCtl;                     /* echo control */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiEchoCtl)
   CMCHKUNPK(cmUnpkElmtHdr,&pEchoCtl->eh,mBuf);
   /* element header */
   if (pEchoCtl->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pEchoCtl->outEchoRsp,mBuf); 
      /* outgoing echo control device response */
      CMCHKUNPK(cmUnpkTknU8,&pEchoCtl->incEchoRsp,mBuf);  
      /* incoming echo control device response*/
      CMCHKUNPK(cmUnpkTknU8,&pEchoCtl->outEchoReq,mBuf); 
      /* outgoing echo control device request*/
      CMCHKUNPK(cmUnpkTknU8,&pEchoCtl->incEchoReq,mBuf); 
      /* incoming echo control device request */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiEchoCtl */


/*
*
*       Fun:   siUnpkSiParmCompInfo
*
*       Desc:  This function unpacks the parameter compatibility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiParmCompInfo
(
SiParmCompInfo *pParmCom,               /* parameter compatibility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiParmCompInfo(pParmCom,mBuf)
SiParmCompInfo *pParmCom;                /* parameter compatibility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiParmCompInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pParmCom->eh,mBuf);
   /* element header */
   if (pParmCom->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar1,mBuf);   
      /* upgraded parm 1 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd1,mBuf);  
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd1,mBuf); 
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd1,mBuf);  
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd1,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd1,mBuf); 
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss1,mBuf); 
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI1,mBuf);
      /* additional instruction indicator */
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd1,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar2,mBuf);  
      /* upgraded parm 2 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd2,mBuf);  
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd2,mBuf);  
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd2,mBuf); 
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd2,mBuf); 
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd2,mBuf); 
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss2,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI2,mBuf);
      /* additional instruction indicator */
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd2,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar3,mBuf);   
      /* upgraded parm 3 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd3,mBuf); 
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd3,mBuf); 
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd3,mBuf); 
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd3,mBuf); 
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd3,mBuf); 
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss3,mBuf); 
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI3,mBuf);
      /* additional instruction indicator */
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd3,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar4,mBuf);
      /* upgraded parm 4 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd4,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd4,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd4,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd4,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd4,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss4,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI4,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd4,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar5,mBuf);
      /* upgraded parm 5 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd5,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd5,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd5,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd5,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd5,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss5,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI5,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd5,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar6,mBuf);
      /* upgraded parm 6 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd6,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd6,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd6,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd6,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd6,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss6,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI6,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd6,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar7,mBuf);
      /* upgraded parm 7 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd7,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd7,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd7,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd7,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd7,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss7,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI7,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd7,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar8,mBuf);
      /* upgraded parm 8 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd8,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd8,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd8,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd8,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd8,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss8,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI8,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd8,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar9,mBuf);
      /* upgraded parm 9 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd9,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd9,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd9,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd9,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd9,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss9,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI9,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd9,mBuf);

      CMCHKUNPK(cmUnpkTknU8,&pParmCom->upgrPar10,mBuf);
      /* upgraded parm 10 */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->tranXInd10,mBuf);
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->relCllInd10,mBuf);
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->sndNotInd10,mBuf);
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdMsgInd10,mBuf);
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->dcrdParInd10,mBuf);
      /* discard parameter ind */
/* sit_c_003.main_15: Addition - added SS7_INDIA */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->passNtPoss10,mBuf);
      /* pass not possible ind */
#endif /* ETSI or FTZ */
      /* broadband narrowband interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pParmCom->pBbNbIntwkI10,mBuf);
      /* additional instruction indicator */  
      CMCHKUNPK(cmUnpkTknStr,&pParmCom->addInstInd10,mBuf);
   }
   RETVALUE(ROK);
} /* end of siUnpkSiParmCompInfo */


/*
*
*       Fun:   siUnpkSiMsgCompInfo
*
*       Desc:  This function unpacks the message compatibility info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiMsgCompInfo
(
SiMsgCompInfo *pMsgCom,                 /* message compatibility */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiMsgCompInfo(pMsgCom,mBuf)
SiMsgCompInfo *pMsgCom;                  /* message compatibility */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiMsgCompInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pMsgCom->eh,mBuf);
   /* element header */
   if (pMsgCom->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->tranXInd,mBuf);   
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->relCllInd,mBuf); 
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->sndNotInd,mBuf);  
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->dcrdMsgInd,mBuf); 
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->passNotPoss,mBuf); 
      /* pass on not possible ind */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->bbNbIntwkI,mBuf); 
      /* broadband network interworking ind */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->tranXInd1,mBuf);  
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->relCllInd1,mBuf); 
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->sndNotInd1,mBuf); 
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->dcrdMsgInd1,mBuf); 
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->passNotPoss1,mBuf); 
      /* pass on not possible ind */
      CMCHKUNPK(cmUnpkTknU8,&pMsgCom->bbNbIntwkI1,mBuf);
      /* broadband network interworking ind */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiMsgCompInfo */


/*
*
*       Fun:   siUnpkSiMlppPrec
*
*       Desc:  This function unpacks the MLPP precedence info
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiMlppPrec
(
SiMlppPrec *pMlppPrec,                  /* MLPP precedence */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiMlppPrec(pMlppPrec,mBuf)
SiMlppPrec *pMlppPrec;                   /* MLPP precedence */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiMlppPrec)
   CMCHKUNPK(cmUnpkElmtHdr,&pMlppPrec->eh,mBuf);
   /* element header */
   if (pMlppPrec->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->precdLvl,mBuf); 
      /* transit exchange indic */
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->lfb,mBuf);     
      /* release call indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->frstDig,mBuf);  
      /* send notification indic*/
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->scndDig,mBuf);  
      /* discard message ind */
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->thrdDig,mBuf); 
      /* discard parameter ind */
      CMCHKUNPK(cmUnpkTknU8,&pMlppPrec->frthDig,mBuf);  
      /* discard parameter ind */
      CMCHKUNPK(cmUnpkTknU32,&pMlppPrec->servDomain,mBuf);
      /* discard parameter ind */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiMlppPrec */

/* si034.220: MODIFIED: Put the SS7_CHINA flag */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL \
     || SS7_CHINA || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkCallRefA
*
*       Desc:  This function unpacks the "CallRefA" information
*              element structure for ANSI
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCallRefA
(
SiCallRefA *pCallRefA,                    /* Call Reference */
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkCallRefA(pCallRefA,mBuf)
SiCallRefA *pCallRefA;                     /* Call Reference */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkCallRefA)
   CMCHKUNPK(cmUnpkElmtHdr,&pCallRefA->eh,mBuf);
   /* element header */
   if (pCallRefA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pCallRefA->callId,mBuf);    
      /* call identity */
      CMCHKUNPK(cmUnpkTknU32,&pCallRefA->pntCde,mBuf);    
      /* point code */
   }
   RETVALUE(ROK);
} /* end of siUnpkCallRefA */

#endif

/*
*
*       Fun:   siUnpkCalModInd
* 
*       Desc:  This function unpacks the "CalModInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCalModInd
(
SiCalModInd *pCalModInd,                /* Call Modification Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCalModInd(pCalModInd,mBuf)
SiCalModInd *pCalModInd;                 /* Call Modification Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCalModInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pCalModInd->eh,mBuf);
   /* element header */
   if (pCalModInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCalModInd->modInd,mBuf); 
      /* call modification indicators */
   }
   RETVALUE(ROK);
} /* end of siUnpkCalModInd */


/*
*
*       Fun:   siUnpkCauseDgn
*
*       Desc:  This function unpacks the "CauseDgn" information
*              element structure.
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCauseDgn
(
SiCauseDgn *pCauseDgn,                  /* Cause Indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCauseDgn(pCauseDgn,mBuf)
SiCauseDgn *pCauseDgn;                   /* Cause Indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCauseDgn)
   CMCHKUNPK(cmUnpkElmtHdr,&pCauseDgn->eh,mBuf);
   /* element header */
   if (pCauseDgn->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCauseDgn->location,mBuf);  
      /* location */
      CMCHKUNPK(cmUnpkTknU8,&pCauseDgn->cdeStand,mBuf);    
      /* coding standard */
      CMCHKUNPK(cmUnpkTknU8,&pCauseDgn->recommend,mBuf);  
      /* recommendation */ 
      CMCHKUNPK(cmUnpkTknU8,&pCauseDgn->causeVal,mBuf);   
      /* cause value */ 
      CMCHKUNPK(cmUnpkTknStr,&pCauseDgn->dgnVal,mBuf);   
      /* diagnostics */ 
   }
   RETVALUE(ROK);
} /* end of siUnpkCauseDgn */


/*
*
*       Fun:   siUnpkCdPtyNum
*
*       Desc:  This function unpacks the "CdPtyNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkCdPtyNum
(
SiCdPtyNum *pCdPtyNum,                  /* Called Party Number */
Buffer *mBuf                             /* message buffer */
)
#else
PUBLIC S16 siUnpkCdPtyNum(pCdPtyNum,mBuf)
SiCdPtyNum *pCdPtyNum;                   /* Called Party Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCdPtyNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pCdPtyNum->eh,mBuf);
   /* element header */
   if (pCdPtyNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCdPtyNum->natAddrInd,mBuf); 
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pCdPtyNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pCdPtyNum->numPlan,mBuf);  
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknU8,&pCdPtyNum->innInd,mBuf);   
      /* international network number indicator */
      CMCHKUNPK(cmUnpkTknStr,&pCdPtyNum->addrSig,mBuf);  
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkCdPtyNum */


/*
*
*       Fun:   siUnpkCgPtyCat
*
*       Desc:  This function unpacks the "CgPtyCat" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCgPtyCat
(
SiCgPtyCat *pCgPtyCat,                  /* Calling Party Category */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCgPtyCat(pCgPtyCat,mBuf)
SiCgPtyCat *pCgPtyCat;                   /* Calling Party Category */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCgPtyCat)
   CMCHKUNPK(cmUnpkElmtHdr,&pCgPtyCat->eh,mBuf);
   /* element header */
   if (pCgPtyCat->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyCat->cgPtyCat,mBuf);    
      /* calling party category*/
   }
   RETVALUE(ROK);
} /* end of siUnpkCgPtyCat */


/*
*
*       Fun:   siUnpkCgPtyNum
*      
*       Desc:  This function unpacks the "CgPtyNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkCgPtyNum
(
SiCgPtyNum *pCgPtyNum,                  /* Calling Party Number */
Buffer *mBuf                             /* message buffer */
)
#else
PUBLIC S16 siUnpkCgPtyNum(pCgPtyNum,mBuf)
SiCgPtyNum *pCgPtyNum;                   /* Calling Party Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCgPtyNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pCgPtyNum->eh,mBuf);
   /* element header */
   if (pCgPtyNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->natAddrInd,mBuf);  
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->scrnInd,mBuf);  
      /* screen indicator */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->presRest,mBuf);  
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->numPlan,mBuf);  
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->niInd,mBuf);    
      /* number incomplete indicator */
      CMCHKUNPK(cmUnpkTknStr,&pCgPtyNum->addrSig,mBuf);   
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkCgPtyNum */


#if SS7_BELL
/*
*
*       Fun:   siUnpkCgPtyNum1
*      
*       Desc:  This function unpacks the "CgPtyNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkCgPtyNum1
(
SiCgPtyNum1 *pCgPtyNum,                  /* Calling Party Number */
Buffer *mBuf                             /* message buffer */
)
#else
PUBLIC S16 siUnpkCgPtyNum1(pCgPtyNum,mBuf)
SiCgPtyNum1 *pCgPtyNum;                   /* Calling Party Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCgPtyNum1)
   CMCHKUNPK(cmUnpkElmtHdr,&pCgPtyNum->eh,mBuf);
   /* element header */
   if (pCgPtyNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->natAddrInd,mBuf);  
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->scrnInd,mBuf);
      /* screen indicator */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->presRest,mBuf);  
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pCgPtyNum->numPlan,mBuf);  
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pCgPtyNum->addrSig,mBuf);   
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkCgPtyNum1 */
#endif  /* SS7_BELL */


/*
*
*       Fun:   siUnpkSiGenNum
*      
*       Desc:  This function unpacks the "SiGenNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiGenNum
(
SiGenNum *pGenNum,                      /* Generic Number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiGenNum(pGenNum,mBuf)
SiGenNum *pGenNum;                       /* Generic Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiGenNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pGenNum->eh,mBuf);
   /* element header */
   if (pGenNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->nmbQual,mBuf);  
      /* number qualifier */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->natAddrInd,mBuf);  
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->oddEven,mBuf);    
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->scrnInd,mBuf);    
      /* screen indicator */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->presRest,mBuf);   
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->numPlan,mBuf);   
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknU8,&pGenNum->niInd,mBuf);    
      /* number incomplete indicator */
      CMCHKUNPK(cmUnpkTknStr,&pGenNum->addrSig,mBuf);  
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiGenNum */


/*
*
*       Fun:   siUnpkCirGrpSupMTypInd
*      
*       Desc:  This function unpacks the "CirGrpSupMTypInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkCirGrpSupMTypInd
(
SiCirGrpSupMTypInd *pCgsmti,            /* Circuit Group Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PUBLIC S16 siUnpkCirGrpSupMTypInd(pCgsmti,mBuf)
SiCirGrpSupMTypInd *pCgsmti;             /* Circuit Group Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCirGrpSupMTypInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pCgsmti->eh,mBuf);
   /* element header */
   if (pCgsmti->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCgsmti->typeInd,mBuf); 
      /* circuit group indicator. */
   }
   RETVALUE(ROK);
} /* end of siUnpkCirGrpSupMTypInd */


/*
*
*       Fun:   siUnpkCirStateInd
*      
*       Desc:  This function unpacks the "CirStateInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCirStateInd
(
SiCirStateInd *pCirStateInd,            /* Circuit State Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCirStateInd(pCirStateInd,mBuf)
SiCirStateInd *pCirStateInd;             /* Circuit State Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCirStateInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pCirStateInd->eh,mBuf);
   /* element header */
   if (pCirStateInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pCirStateInd->cirSteInd,mBuf); 
      /* circuit state indicatr*/
   }
   RETVALUE(ROK);
} /* end of siUnpkCirStateInd */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
 
/*
*
*       Fun:   siUnpkGrpNum
*      
*       Desc:  This function unpacks the "SiOutgTrkGrpNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkGrpNum
(
SiOutgTrkGrpNum *pGrpNum,                /*  outgoing trunk group number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkGrpNum(pGrpNum,mBuf)
SiOutgTrkGrpNum *pGrpNum;                /*  outgoing trunk group number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkGrpNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pGrpNum->eh,mBuf);
   /* element header */
   if (pGrpNum->eh.pres)
   {
      /* unpack the  outgoing trunk group number */
      CMCHKUNPK(cmUnpkTknStr,&pGrpNum->digits,mBuf);  
   }
   RETVALUE(ROK);
} /* end of siUnpkGrpNum */
#endif
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))

 
 /*
 *
*       Fun:   siUnpkConnectedNum2
*      
*       Desc:  This function unpacks the "ConnectedNum2" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkConnectedNum2
(
SiConnectedNum2 *pConnectedNum2,         /* Connected number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkConnectedNum2(pConnectedNum2,mBuf)
SiConnectedNum2 *pConnectedNum2;         /* Connected number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkConnectedNum2)
   CMCHKUNPK(cmUnpkElmtHdr,&pConnectedNum2->eh,mBuf);
   /* element header */
   if (pConnectedNum2->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum2->natAddr,mBuf); 
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum2->oddEven,mBuf);  
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum2->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum2->numPlan,mBuf);  
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pConnectedNum2->addrSig,mBuf); 
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkConnectedNum2 */
#endif


/*
*
*       Fun:   siUnpkConnectedNum
*      
*       Desc:  This function unpacks the "ConnectedNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkConnectedNum
(
SiConnectedNum *pConnectedNum,          /* Connected number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkConnectedNum(pConnectedNum,mBuf)
SiConnectedNum *pConnectedNum;           /* Connected number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkConnectedNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pConnectedNum->eh,mBuf);
   /* element header */
   if (pConnectedNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum->natAddr,mBuf); 
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum->oddEven,mBuf);  
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum->scrnInd,mBuf); 
      /* screen indicator */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pConnectedNum->numPlan,mBuf);  
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pConnectedNum->addrSig,mBuf); 
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkConnectedNum */


/*
*
*       Fun:   siUnpkConnReq
*      
*       Desc:  This function unpacks the "ConnReq" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkConnReq
(
SiConnReq *pConnReq,                    /* Connection Request */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkConnReq(pConnReq,mBuf)
SiConnReq *pConnReq;                     /* Connection Request */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkConnReq)
   CMCHKUNPK(cmUnpkElmtHdr,&pConnReq->eh,mBuf);
   /* element header */
   if (pConnReq->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pConnReq->locRef,mBuf); 
      /* local reference (really a 24bit quantity) */
      CMCHKUNPK(cmUnpkTknU16,&pConnReq->pntCde,mBuf);     
      /* point code */
      CMCHKUNPK(cmUnpkTknU8,&pConnReq->protClass,mBuf);  
      /* protocol classs */
      CMCHKUNPK(cmUnpkTknU8,&pConnReq->credit,mBuf);    
      /* credit */
   }
   RETVALUE(ROK);
} /* end of siUnpkConnReq */

/*si034.220: Addition - SS7_CHINA flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)

/*
*
*       Fun:   siUnpkConnReqA
*      
*       Desc:  This function unpacks the "ConnReqA" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkConnReqA
(
SiConnReqA *pConnReqA,                    /* Connection Request */
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkConnReqA(pConnReqA,mBuf)
SiConnReqA *pConnReqA;                     /* Connection Request */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkConnReqA)
   CMCHKUNPK(cmUnpkElmtHdr,&pConnReqA->eh,mBuf);
   /* element header */
   if (pConnReqA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pConnReqA->locRef,mBuf);    
      /* local reference (really a 24bit quantity) */
      CMCHKUNPK(cmUnpkTknU32,&pConnReqA->pntCde,mBuf);   
      /* point code */
      CMCHKUNPK(cmUnpkTknU8,&pConnReqA->protClass,mBuf); 
      /* protocol classs */
      CMCHKUNPK(cmUnpkTknU8,&pConnReqA->credit,mBuf);   
      /* credit */
   }
   RETVALUE(ROK);
} /* end of siUnpkConnReqA */

#endif

/*
*
*       Fun:   siUnpkContInd
*      
*       Desc:  This function unpacks the "ContInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkContInd
(
SiContInd *pContInd,                    /* Continuity indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkContInd(pContInd,mBuf)
SiContInd *pContInd;                     /* Continuity indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkContInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pContInd->eh,mBuf);
   /* element header */
   if (pContInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pContInd->contInd,mBuf);  
      /* continuity indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkContInd */


/*
*
*       Fun:   siUnpkCugIntCode
*      
*       Desc:  This function unpacks the "CugIntCode" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCugIntCode
(
SiCugIntCode *pCugIntCode,              /* Closed User Group Interlock Code */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkCugIntCode(pCugIntCode,mBuf)
SiCugIntCode *pCugIntCode;               /* Closed User Group Interlock Code */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkCugIntCode)
   CMCHKUNPK(cmUnpkElmtHdr,&pCugIntCode->eh,mBuf);
   /* element header */
   if (pCugIntCode->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCugIntCode->dig2,mBuf);  
      /* Digit 2 */
      CMCHKUNPK(cmUnpkTknU8,&pCugIntCode->dig1,mBuf);   
      /* Digit 1 */
      CMCHKUNPK(cmUnpkTknU8,&pCugIntCode->dig4,mBuf);   
      /* Digit 4 */
      CMCHKUNPK(cmUnpkTknU8,&pCugIntCode->dig3,mBuf);    
      /* Digit 3 */
      CMCHKUNPK(cmUnpkTknU16,&pCugIntCode->binCde,mBuf); 
      /* binary Code */
   }
   RETVALUE(ROK);
} /* end of siUnpkCugIntCode */
 
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkCugIntCodeA
*      
*       Desc:  This function unpacks the "CugIntCodeA" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCugIntCodeA
(
SiCugIntCodeA *pCugIntCodeA,              /* Closed User Group Interlck Code*/
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkCugIntCodeA(pCugIntCodeA,mBuf)
SiCugIntCodeA *pCugIntCodeA;               /* Closed User Group Interlck Code */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkCugIntCodeA)
   CMCHKUNPK(cmUnpkElmtHdr,&pCugIntCodeA->eh,mBuf);
   /* element header */
   if (pCugIntCodeA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU16,&pCugIntCodeA->binCde,mBuf);   
      /* binary Code */
      CMCHKUNPK(cmUnpkTknU16,&pCugIntCodeA->ISDNIdent,mBuf); 
      /* ISDN identity */
   }
   RETVALUE(ROK);
} /* end of siUnpkCugIntCodeA */
 
#endif 

/*
*
*       Fun:   siUnpkEvntInfo
*
*       Desc:  This function unpacks the "EvntInfo" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkEvntInfo
(
SiEvntInfo *pEvntInfo,                  /* Event Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkEvntInfo(pEvntInfo,mBuf)
SiEvntInfo *pEvntInfo;                   /* Event Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkEvntInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pEvntInfo->eh,mBuf);
   /* element header */
   if (pEvntInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pEvntInfo->evntInd,mBuf);      
      /* event indicators */
      CMCHKUNPK(cmUnpkTknU8,&pEvntInfo->evntPresResInd,mBuf);
      /* event presentation restriction indicators*/
   }
   RETVALUE(ROK);
} /* end of siUnpkEvntInfo */


/*
*
*       Fun:   siUnpkFacInd
*
*       Desc:  This function unpacks the "FacInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkFacInd
(
SiFacInd *pFacInd,                      /* Facility Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkFacInd(pFacInd,mBuf)
SiFacInd *pFacInd;                       /* Facility Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkFacInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pFacInd->eh,mBuf);
   /* element header */
   if (pFacInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFacInd->facInd,mBuf);   
      /* facility indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkFacInd */


/*
*
*       Fun:   siUnpkFwdCallInd
*
*       Desc:  This function unpacks the "FwdCallInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkFwdCallInd
(
SiFwdCallInd *pFwdCallInd,              /* Forward Call Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkFwdCallInd(pFwdCallInd,mBuf)
SiFwdCallInd *pFwdCallInd;               /* Forward Call Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(siUnpkFwdCallInd)

   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU32, &bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkElmtHdr,&pFwdCallInd->eh,mBuf);
   /* element header */
   if (pFwdCallInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->natIntCallInd,mBuf); 
      /* National/Internat Call Indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->end2EndMethInd,mBuf); 
      /* end to end method indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->intInd,mBuf);       
      /* interworking indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->end2EndInfoInd,mBuf); 
      /* end to end infos rmation indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->isdnUsrPrtInd,mBuf); 
      /* ISDN User Part indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->isdnUsrPrtPrfInd,mBuf);
      /* ISDN User Part preference indicat*/
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->isdnAccInd,mBuf);  
      /* ISDN access indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->sccpMethInd,mBuf);  
      /* SCCP method indicator */
#ifdef SI_ANSILNP
      /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* SI_ANSILNP is defined at the destination, unpacking will be done 
       * only if the orignator indicates that is has packed the parameter 
       * (determined from the bit vector). If not send by orignator we 
       * substitute a default value for the parameter
       */
      if (bitVector & SIT_ANSILNP_BIT)
      {
         CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->transCallNInd,mBuf);
      }
      else
      {
         pFwdCallInd->transCallNInd.pres = PRSNT_NODEF;
         pFwdCallInd->transCallNInd.val = SITIF_VER1_CONREQ_DEF_TRANSID_VAL;
      }
#else
      /* No rolling upgrade support so we base our unpacking decision
       * solely on the compile tiem flag
       */
      CMCHKUNPK(cmUnpkTknU8,&pFwdCallInd->transCallNInd,mBuf);
#endif
#else /* SI_ANSILNP not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* the compile time flag is not defined at destination but may be 
       * defined at origiator. If so we unpack and discard the parameter
       */
     if (bitVector & SIT_ANSILNP_BIT)
     {
        TknU8 tempVar;
        CMCHKUNPK(cmUnpkTknU8,&tempVar,mBuf);
     }
#endif
      /* Translated called number indicator */
#endif /* SI_ANSILNP */
   }
   RETVALUE(ROK);
} /* end of siUnpkFwdCallInd */


/*
*
*       Fun:   siUnpkInfoInd
*
*       Desc:  This function unpacks the "InfoInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkInfoInd
(
SiInfoInd *pInfoInd,                    /* Information Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkInfoInd(pInfoInd,mBuf)
SiInfoInd *pInfoInd;                     /* Information Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkInfoInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pInfoInd->eh,mBuf);
   /* element header */
   if (pInfoInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->cgPtyAddrRespInd,mBuf);  
      /* calling party a ddress respnse ind*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->holdProvInd,mBuf);    
      /* hold provided indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->cgPtyCatRespInd,mBuf); 
      /* calling party categ response ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->chrgInfoRespInd,mBuf); 
      /* charge information response indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->solInfoInd,mBuf);     
      /* solicitation infos rmation indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoInd->spare,mBuf);       
      /* spare (insure we get second octet) */
   }
   RETVALUE(ROK);
} /* end of siUnpkInfoInd */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkInfoIndA
*
*       Desc:  This function unpacks the "InfoIndA" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkInfoIndA
(
SiInfoIndA *pInfoIndA,                    /* Information Indicators */
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkInfoIndA(pInfoIndA,mBuf)
SiInfoIndA *pInfoIndA;                     /* Information Indicators */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkInfoIndA)
   CMCHKUNPK(cmUnpkElmtHdr,&pInfoIndA->eh,mBuf);
   /* element header */
   if (pInfoIndA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->cgPtyAddrRespInd,mBuf);  
      /* calling party addr response ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->connAddrRspInd,mBuf);  
      /* hold provided indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->cgPtyCatRespInd,mBuf); 
      /* calling party categ response ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->chrgInfoRespInd,mBuf); 
      /* charge information response indicat */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->redirAddrRspInda,mBuf); 
      /* solicitation info indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->redirAddrRspIndb,mBuf); 
      /* solicitation info indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoIndA->indexRspInd,mBuf);    
      /* solicitation info indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkInfoIndA */

#endif

/*
*
*       Fun:   siUnpkInfoReqInd
*
*       Desc:  This function unpacks the "InfoReqInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkInfoReqInd
(
SiInfoReqInd *pInfoReqInd,              /* Information Request Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkInfoReqInd(pInfoReqInd,mBuf)
SiInfoReqInd *pInfoReqInd;               /* Information Request Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkInfoReqInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pInfoReqInd->eh,mBuf);
   /* element header */
   if (pInfoReqInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->cgPtyAdReqInd,mBuf); 
      /* calling party addr request ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->holdingInd,mBuf);   
      /* holding indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->cgPtyCatReqInd,mBuf); 
      /* calling party categ request ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->chrgInfoReqInd,mBuf); 
      /* charge information request indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->malCaIdReqInd,mBuf); 
      /* malicious call id request indicator */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqInd->spare,mBuf);    
      /* spare (insure second octet...) */
   }
   RETVALUE(ROK);
} /* end of siUnpkInfoReqInd */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkInfoReqIndA
*
*       Desc:  This function unpacks the "InfoReqIndA" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkInfoReqIndA
(
SiInfoReqIndA *pInfoReqIndA,              /* Information Request Indicators */
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkInfoReqIndA(pInfoReqIndA,mBuf)
SiInfoReqIndA *pInfoReqIndA;               /* Information Request Indicators */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkInfoReqIndA)
   CMCHKUNPK(cmUnpkElmtHdr,&pInfoReqIndA->eh,mBuf);
   /* element header */
   if (pInfoReqIndA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->cgPtyAdReqInd,mBuf);
      /* calling party addr request ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->connAddrReqInd,mBuf); 
      /* holding indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->cgPtyCatReqInd,mBuf);
      /* calling party categ request ind. */
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->chrgInfoReqInd,mBuf); 
      /* charge information request indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->redirAddrReqInd,mBuf); 
      /* malicious call id request indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->indexReqInd,mBuf); 
      /* malicious call id request indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->malCaIdReqInd,mBuf);
      /* malicious call id request indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pInfoReqIndA->holdingInd,mBuf);   
      /* spare (insure second octet...) */
   }
   RETVALUE(ROK);
} /* end of siUnpkInfoReqIndA */

#endif

/*
*
*       Fun:   siUnpkNatConInd
*
*       Desc:  This function unpacks the "NatConInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkNatConInd
(
SiNatConInd *pNatConInd,                /* Nature of Connection Indicator */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkNatConInd(pNatConInd,mBuf)
SiNatConInd *pNatConInd;                 /* Nature of Connection Indicator */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkNatConInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pNatConInd->eh,mBuf);
   /* element header */
   if (pNatConInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNatConInd->satInd,mBuf);     
      /* Satellite Indicat */
      CMCHKUNPK(cmUnpkTknU8,&pNatConInd->contChkInd,mBuf);  
      /* continuity check indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNatConInd->echoCntrlDevInd,mBuf); 
      /* echo control device indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkNatConInd */


/*
*
*       Fun:   siUnpkOpFwdCalInd
*
*       Desc:  This function unpacks the "OpFwdCalInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOpFwdCalInd
(
SiOpFwdCalInd *pOpFwdCalInd,            /* Optional Forward Call Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkOpFwdCalInd(pOpFwdCalInd,mBuf)
SiOpFwdCalInd *pOpFwdCalInd;             /* Optional Forward Call Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkOpFwdCalInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pOpFwdCalInd->eh,mBuf);
   /* element header*/
   if (pOpFwdCalInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalInd->clsdUGrpCaInd,mBuf); 
      /* closed user grp call indicatr */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalInd->simpleSegmInd,mBuf);
      /* Simple segmentation indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalInd->conLineIdReqInd,mBuf);
      /* Connected line identity request ind */
   }
   RETVALUE(ROK);
} /* end of siUnpkOpFwdCalInd */

#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)

/*
*
*       Fun:   siUnpkOpFwdCalIndQ
*
*       Desc:  This function unpacks the "OpFwdCalInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOpFwdCalIndQ
(
SiOpFwdCalIndQ *pOpFwdCalIndQ,          /* Optional Forward Call Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkOpFwdCalIndQ(pOpFwdCalIndQ,mBuf)
SiOpFwdCalIndQ *pOpFwdCalIndQ;           /* Optional Forward Call Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkOpFwdCalIndQ)
   CMCHKUNPK(cmUnpkElmtHdr,&pOpFwdCalIndQ->eh,mBuf);
   /* element header*/
   if (pOpFwdCalIndQ->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndQ->clsdUGrpCaInd,mBuf);   
      /* closed user grp call indicatr */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndQ->connAddrReqInd1,mBuf); 
      /* connected addr request indic */
   }
   RETVALUE(ROK);
} /* end of siUnpkOpFwdCalIndQ */
#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkOpFwdCalIndA
*
*       Desc:  This function unpacks the "OpFwdCalInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOpFwdCalIndA
(
SiOpFwdCalIndA *pOpFwdCalIndA,          /* Optional Forward Call Indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkOpFwdCalIndA(pOpFwdCalIndA,mBuf)
SiOpFwdCalIndA *pOpFwdCalIndA;           /* Optional Forward Call Indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkOpFwdCalIndA)
   CMCHKUNPK(cmUnpkElmtHdr,&pOpFwdCalIndA->eh,mBuf);
   /* element header*/
   if (pOpFwdCalIndA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndA->clsdUGrpCaInd,mBuf);  
      /* closed user grp call indicatr */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndA->ccbsCallInd,mBuf);   
      /* CCBS call indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndA->callgPtyNumIncomInd,mBuf);
      /* calling party number incompl ind. */
      CMCHKUNPK(cmUnpkTknU8,&pOpFwdCalIndA->connAddrReqInd1,mBuf);  
      /* connected addr request indic */
   }
   RETVALUE(ROK);
} /* end of siUnpkOpFwdCalIndA */
#endif


/*
*
*       Fun:   siUnpkOptBckCalInd
*
*       Desc:  This function unpacks the "OptBckCalInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOptBckCalInd
(
SiOptBckCalInd *pOptBckCalInd,          /* Optional Backward Call Indicators*/
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkOptBckCalInd(pOptBckCalInd,mBuf)
SiOptBckCalInd *pOptBckCalInd;           /* Optional Backward Call Indicators*/
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkOptBckCalInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pOptBckCalInd->eh,mBuf);
   /* element header */
   if (pOptBckCalInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->inbndInfoInd,mBuf); 
      /* in-band info indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->caFwdMayOcc,mBuf); 
      /* call forwarding may occur indic */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->simpleSegmInd,mBuf);
      /* Simple segmentation indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->mlppUserInd,mBuf);
      /* MLPP User indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->netExcDelInd,mBuf);
      /* Network excessive delay indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalInd->usrNetIneractInd,mBuf);
      /* user-network interaction ind */
   }
   RETVALUE(ROK);
} /* end of siUnpkOptBckCalInd */

#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT)

/*
*
*       Fun:   siUnpkOptBckCalIndQ
*
*       Desc:  This function unpacks the "OptBckCalIndQ" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOptBckCalIndQ
(
SiOptBckCalIndQ *pOptBckCalIndQ,       /* Optional Backward Call Indicators */
Buffer *mBuf                            /* message buffer */
)
#else
PRIVATE S16 siUnpkOptBckCalIndQ(pOptBckCalIndQ,mBuf)
SiOptBckCalIndQ *pOptBckCalIndQ;        /* Optional Backward Call Indicators */
Buffer *mBuf;                           /* message buffer */
#endif
{
   TRC2(siUnpkOptBckCalIndQ)
   CMCHKUNPK(cmUnpkElmtHdr,&pOptBckCalIndQ->eh,mBuf);
   /* element header */
   if (pOptBckCalIndQ->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalIndQ->inbndInfoInd,mBuf);  
      /* in-band info indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOptBckCalIndQ->caFwdMayOcc,mBuf); 
      /* call forwarding may occur indic */
   }
   RETVALUE(ROK);
} /* end of siUnpkOptBckCalIndQ */
#endif  


/*
*
*       Fun:   siUnpkOrigCdNum
*
*       Desc:  This function unpacks the "OrigCdNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOrigCdNum
(
SiOrigCdNum *pOrigCdNum,                /* Original Called Number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkOrigCdNum(pOrigCdNum,mBuf)
SiOrigCdNum *pOrigCdNum;                 /* Original Called Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkOrigCdNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pOrigCdNum->eh,mBuf);
   /* element header */
   if (pOrigCdNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOrigCdNum->natAddr,mBuf);  
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOrigCdNum->oddEven,mBuf);   
      /* odd or even */
      /* sit_c_001.main_15, ADDED: added unpacking for scrInd */
      CMCHKUNPK(cmUnpkTknU8,&pOrigCdNum->scrInd,mBuf);   
      /* screening indicator */
      CMCHKUNPK(cmUnpkTknU8,&pOrigCdNum->presRest,mBuf);   
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pOrigCdNum->numPlan,mBuf);   
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pOrigCdNum->addrSig,mBuf); 
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkOrigCdNum */


/*
*
*       Fun:   siUnpkPassAlng
*
*       Desc:  This function unpacks the "PassAlng" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkPassAlng
(
SiPassAlng *pPassAlng,                  /* Pass Along */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkPassAlng(pPassAlng,mBuf)
SiPassAlng *pPassAlng;                   /* Pass Along */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkPassAlng)
   CMCHKUNPK(cmUnpkElmtHdr,&pPassAlng->eh,mBuf);
   /* element header */
   if (pPassAlng->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pPassAlng->passAlng,mBuf);  
      /* pass along */
   }
   RETVALUE(ROK);
} /* end of siUnpkPassAlng */


/*
*
*       Fun:   siUnpkRangStat
*
*       Desc:  This function unpacks the "RangStat" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PUBLIC S16 siUnpkRangStat
(
SiRangStat *pRangStat,                  /* Range and Status */
Buffer *mBuf                             /* message buffer */
)
#else
PUBLIC S16 siUnpkRangStat(pRangStat,mBuf)
SiRangStat *pRangStat;                   /* Range and Status */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkRangStat)
   CMCHKUNPK(cmUnpkElmtHdr,&pRangStat->eh,mBuf);
   /* element header */
   if (pRangStat->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRangStat->range,mBuf);  
      /* range */
      CMCHKUNPK(cmUnpkTknStr,&pRangStat->status,mBuf);  
      /* status */
   }
   RETVALUE(ROK);
} /* end of siUnpkRangStat */


/*
*
*       Fun:   siUnpkRedirgNum
*
*       Desc:  This function unpacks the "RedirgNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkRedirgNum
(
SiRedirNum *pRedirgNum,                /* Redirection Information */
Buffer *mBuf                            /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirgNum(pRedirgNum,mBuf)
SiRedirNum *pRedirgNum;                 /* Redirection Information */
Buffer *mBuf;                           /* message buffer */
#endif
{
   TRC2(siUnpkRedirgNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirgNum->eh,mBuf);
   /* element header */
   if (pRedirgNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirgNum->natAddr,mBuf); 
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pRedirgNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pRedirgNum->scrInd,mBuf); 
      /* screening ind. */
      CMCHKUNPK(cmUnpkTknU8,&pRedirgNum->presRest,mBuf); 
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pRedirgNum->numPlan,mBuf);   
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pRedirgNum->addrSig,mBuf); 
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirgNum */


/*
*
*       Fun:   siUnpkRedirInfo
*
*       Desc:  This function unpacks the "RedirInfo" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkRedirInfo
(
SiRedirInfo *pRedirInfo,                /* Redirection Number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirInfo(pRedirInfo,mBuf)
SiRedirInfo *pRedirInfo;                 /* Redirection Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkRedirInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirInfo->eh,mBuf);
   /* element header */
   if (pRedirInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirInfo->redirInd,mBuf); 
      /* redirection indicator*/
      CMCHKUNPK(cmUnpkTknU8,&pRedirInfo->origRedirReas,mBuf);
      /* original redirection reason */
      CMCHKUNPK(cmUnpkTknU8,&pRedirInfo->redirCnt,mBuf); 
      /* redirection count */
      CMCHKUNPK(cmUnpkTknU8,&pRedirInfo->redirReas,mBuf); 
      /* redirection reason */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirInfo */


/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
*
*       Fun:   siUnpkRedirNum
*
*       Desc:  This function unpacks the "RedirNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkRedirNum
(
SiRedirNum *pRedirNum,                  /* Redirection Number */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirNum(pRedirNum,mBuf)
SiRedirNum *pRedirNum;                   /* Redirection Number */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkRedirNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirNum->eh,mBuf);
   /* element header */
   if (pRedirNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirNum->natAddr,mBuf);  
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pRedirNum->oddEven,mBuf);   
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pRedirNum->presRest,mBuf);   
      /* Address presentation restricted ind. */
      CMCHKUNPK(cmUnpkTknU8,&pRedirNum->numPlan,mBuf);   
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pRedirNum->addrSig,mBuf);  
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirNum */

#endif /* endif SS7_ANS88 */

/*
*
*       Fun:   siUnpkSigPointCode
*
*       Desc:  This function unpacks the "SigPointCode" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSigPointCode
(
SiSigPointCode *pSigPointCode,          /* Signalling Point Code */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSigPointCode(pSigPointCode,mBuf)
SiSigPointCode *pSigPointCode;           /* Signalling Point Code */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSigPointCode)
   CMCHKUNPK(cmUnpkElmtHdr,&pSigPointCode->eh,mBuf);
   /* element header */
   if (pSigPointCode->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU16,&pSigPointCode->sigPointCode,mBuf);
      /* signalling point code */
   }
   RETVALUE(ROK);
} /* end of siUnpkSigPointCode */

/* si034.220: Addition - SS7_CHINA Flag */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(SS7_CHINA) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkSigPointCodeA
*
*       Desc:  This function unpacks the "SigPointCodeA" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSigPointCodeA
(
SiSigPointCodeA *pSigPointCodeA,          /* Signalling Point Code */
Buffer *mBuf                               /* message buffer */
)
#else
PRIVATE S16 siUnpkSigPointCodeA(pSigPointCodeA,mBuf)
SiSigPointCodeA *pSigPointCodeA;           /* Signalling Point Code */
Buffer *mBuf;                              /* message buffer */
#endif
{
   TRC2(siUnpkSigPointCodeA)
   CMCHKUNPK(cmUnpkElmtHdr,&pSigPointCodeA->eh,mBuf);
   /* element header */
   if (pSigPointCodeA->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pSigPointCodeA->sigPointCode,mBuf); 
      /* signalling point code */
   }
   RETVALUE(ROK);
} /* end of siUnpkSigPointCodeA */

#endif

/*
*
*       Fun:   siUnpkSusResInd
*
*       Desc:  This function unpacks the "SusResInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSusResInd
(
SiSusResInd *pSusResInd,                /* Suspend/Resume indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSusResInd(pSusResInd,mBuf)
SiSusResInd *pSusResInd;                 /* Suspend/Resume indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSusResInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pSusResInd->eh,mBuf);
   /* element header */
   if (pSusResInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pSusResInd->susResInd,mBuf);  
      /* suspend/resume indicat*/
   }
   RETVALUE(ROK);
} /* end of siUnpkSusResInd */


/*
*
*       Fun:   siUnpkTranNetSel
*
*       Desc:  This function unpacks the "TranNetSel" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkTranNetSel
(
SiTranNetSel *pTranNetSel,              /* Transit Network Selection */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkTranNetSel(pTranNetSel,mBuf)
SiTranNetSel *pTranNetSel;               /* Transit Network Selection */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkTranNetSel)
   CMCHKUNPK(cmUnpkElmtHdr,&pTranNetSel->eh,mBuf);
   /* element header */
   if (pTranNetSel->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel->netIdPln,mBuf);  
      /* network id plan */
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel->typNetId,mBuf); 
      /* type of network identification */
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel->oddEven,mBuf); 
      /* odd/even */
      CMCHKUNPK(cmUnpkTknStr,&pTranNetSel->netId,mBuf); 
      /* network identification*/
   }
   RETVALUE(ROK);
} /* end of siUnpkTranNetSel */

/* si037.220 : Addeded Transit network selection fields for ANSI */					 
#if TNS_ANSI
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)					 

/*
*
*       Fun:   siUnpkTranNetSel1
*
*       Desc:  This function unpacks the "TranNetSel" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkTranNetSel1
(
SiTranNetSel1 *pTranNetSel1,              /* Transit Network Selection */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkTranNetSel1(pTranNetSel1,mBuf)
SiTranNetSel1 *pTranNetSel1;               /* Transit Network Selection */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkTranNetSel1)
   CMCHKUNPK(cmUnpkElmtHdr,&pTranNetSel1->eh,mBuf);
   /* element header */
   if (pTranNetSel1->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel1->netIdPln,mBuf);  
      /* network id plan */
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel1->typNetId,mBuf); 
      /* type of network identification */
      CMCHKUNPK(cmUnpkTknU8,&pTranNetSel1->oddEven,mBuf); 
      /* odd/even */
      CMCHKUNPK(cmPkTknU8,&pTranNetSel1->dig1,mBuf); 
      /* Digit 1 */
      CMCHKUNPK(cmPkTknU8,&pTranNetSel1->dig2,mBuf); 
      /* Digit 2 */
      CMCHKUNPK(cmPkTknU8,&pTranNetSel1->dig3,mBuf); 
      /* Digit 3 */
      CMCHKUNPK(cmPkTknU8,&pTranNetSel1->CirCd,mBuf); 
      /* Circuit Code */
   }
   RETVALUE(ROK);
} /* end of siUnpkTranNetSel1 */
#endif			
#endif			


/*
*
*       Fun:   siUnpkTxMedReq
*
*       Desc:  This function unpacks the "TxMedReq" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkTxMedReq
(
SiTxMedReq *pTxMedReq,                  /* Transmission Medium Requirement */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkTxMedReq(pTxMedReq,mBuf)
SiTxMedReq *pTxMedReq;                   /* Transmission Medium Requirement */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkTxMedReq)
   CMCHKUNPK(cmUnpkElmtHdr,&pTxMedReq->eh,mBuf);
   /* element header */
   if (pTxMedReq->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pTxMedReq->trMedReq,mBuf);  
      /* tranmission medium requirement */
   }
   RETVALUE(ROK);
} /* end of siUnpkTxMedReq */


/*
*
*       Fun:   siUnpkUsr2UsrInd
*
*       Desc:  This function unpacks the "Usr2UsrInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkUsr2UsrInd
(
SiUsr2UsrInd *pUsr2UsrInd,              /* User to User indicators */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkUsr2UsrInd(pUsr2UsrInd,mBuf)
SiUsr2UsrInd *pUsr2UsrInd;               /* User to User indicators */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkUsr2UsrInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pUsr2UsrInd->eh,mBuf);
   /* element header */
   if (pUsr2UsrInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pUsr2UsrInd->type,mBuf);     
      /* type */
      CMCHKUNPK(cmUnpkTknU8,&pUsr2UsrInd->serv1,mBuf);    
      /* service 1 */
      CMCHKUNPK(cmUnpkTknU8,&pUsr2UsrInd->serv2,mBuf);   
      /* service 2 */
      CMCHKUNPK(cmUnpkTknU8,&pUsr2UsrInd->serv3,mBuf);   
      /* service 3 */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SIT_PARAMETER) || defined(TDS_ROLL_UPGRADE_SUPPORT))
      CMCHKUNPK(cmUnpkTknU8,&pUsr2UsrInd->spare,mBuf);   
#endif
   }
   RETVALUE(ROK);
} /* end of siUnpkUsr2UsrInd */


/*
*
*       Fun:   siUnpkUsr2UsrInfo
*
*       Desc:  This function unpacks the "Usr2UsrInfo" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkUsr2UsrInfo
(
SiUsr2UsrInfo *pUsr2UsrInfo,            /* User to user information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkUsr2UsrInfo(pUsr2UsrInfo,mBuf)
SiUsr2UsrInfo *pUsr2UsrInfo;             /* User to user information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkUsr2UsrInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pUsr2UsrInfo->eh,mBuf);
   /* element header */
   if (pUsr2UsrInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pUsr2UsrInfo->info,mBuf);   
      /* user to user info */
   }
   RETVALUE(ROK);
} /* end of siUnpkUsr2UsrInfo */


/*
*
*       Fun:   siUnpkSiUsrServInfo
*
*       Desc:  This function unpacks the "UsrServInfo" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiUsrServInfo
(
SiUsrServInfo *pUsrServInfo,            /* User Service Information */
Buffer *mBuf                             /* message buffer */
)
#else
PRIVATE S16 siUnpkSiUsrServInfo(pUsrServInfo,mBuf)
SiUsrServInfo *pUsrServInfo;             /* User Service Information */
Buffer *mBuf;                            /* message buffer */
#endif
{
   TRC2(siUnpkSiUsrServInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pUsrServInfo->eh,mBuf);
   /* element header */
   if (pUsrServInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->infoTranCap,mBuf);
      /* information transfer capability */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->cdeStand,mBuf); 
      /* coding standard */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->infoTranRate0,mBuf);
      /* information transfer rate */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->tranMode,mBuf);
      /* transfer mode */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->establish,mBuf);
      /* establishment */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->config,mBuf);  
      /* configuration */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->chanStruct,mBuf);
      /* structure */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->infoTranRate1,mBuf);
      /* information transfer rate */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->symmetry,mBuf); 
      /* symmetry */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->rateMultiplier,mBuf); 
      /* rate multiplier */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->usrInfLyr1Prot,mBuf); 
      /* usr information layer 1 protocol */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->lyr1Ident,mBuf);
      /* layer 1 identity */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->usrRate,mBuf);  
      /* user rate */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->negot,mBuf);   
      /* negotiation */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->syncAsync,mBuf); 
      /* synchronous/asynch*/
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->flcOnRx,mBuf);  
      /* flow control on reception */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->flcOnTx,mBuf); 
      /* flow control on transmission */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->niClkOnRx,mBuf); 
      /* network independent clock on recept */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->niClkOnTx,mBuf);
      /* network independent clock on transmiss*/
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->interRate,mBuf);
      /* intermediate rate */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->inOutBandNeg,mBuf);
      /* inband/outband negotiation */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->asgnrAsgne,mBuf);
      /* assignor/assignee */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->logLnkNegot,mBuf);
      /* logical link ident  negotiation */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->mode,mBuf);  
      /* mode of operation */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->multiFrm,mBuf);  
      /* multiple frame estab lishment support */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->hdrNohdr,mBuf); 
      /* rate adaption header/no header */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->parity,mBuf);  
      /* parity information*/
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->nmbDatBits,mBuf);
      /* number of data bits exclud parity bit */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->nmbStpBits,mBuf);
      /* number of stp bits*/
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->modemType,mBuf); 
      /* modem type */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->duplexMode,mBuf);
      /* duplex mode */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->usrInfLyr2Prot,mBuf);
      /* user information layer 2 protocol */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->lyr2Ident,mBuf); 
      /* layer 2 identity */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->usrInfLyr3Prot,mBuf);
      /* user information layer 3 protocol */
      CMCHKUNPK(cmUnpkTknU8,&pUsrServInfo->lyr3Ident,mBuf); 
      /* layer 3 identity */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiUsrServInfo */



/*
*
*       Fun:   siUnpkSiUsrTSrvInfo
*
*       Desc:  This function unpacks the "UsrTSrvInfo" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiUsrTSrvInfo
(
SiUsrTSrvInfo *pUsrTSrvInfo,          /* User Teleservice Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkSiUsrTSrvInfo(pUsrTSrvInfo,mBuf)
SiUsrTSrvInfo *pUsrTSrvInfo;           /* User Teleservice Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC2(siUnpkSiUsrTSrvInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&pUsrTSrvInfo->eh,mBuf);
   /* element header */
   if (pUsrTSrvInfo->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pUsrTSrvInfo->presMeth,mBuf);
      /* presentation method */
      CMCHKUNPK(cmUnpkTknU8,&pUsrTSrvInfo->interp,mBuf);
      /* interpretation */
      CMCHKUNPK(cmUnpkTknU8,&pUsrTSrvInfo->codeStd,mBuf);
      /* coding standard */
      CMCHKUNPK(cmUnpkTknU8,&pUsrTSrvInfo->highLyr,mBuf);
      /* high layer characteristics */
      CMCHKUNPK(cmUnpkTknU8,&pUsrTSrvInfo->extHighLyr,mBuf);
      /* extended high layer characteristics */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiUsrTSrvInfo */


/*
*
*       Fun:   siUnpkSiGenDigits
*
*       Desc:  This function unpacks the "GenDigits" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSiGenDigits
(
SiGenDigits *pGenDigits,              /* Generic Address */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkSiGenDigits(pGenDigits,mBuf)
SiGenDigits *pGenDigits;               /* Generic Address */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkSiGenDigits)
   CMCHKUNPK(cmUnpkElmtHdr,&pGenDigits->eh,mBuf);
   /* element header */
   if (pGenDigits->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pGenDigits->typeOfDigits,mBuf);
      /* type of digits */
      CMCHKUNPK(cmUnpkTknU8,&pGenDigits->encodeScheme,mBuf);
      /* encoding scheme */
      CMCHKUNPK(cmUnpkTknStr,&pGenDigits->digits,mBuf); 
      /* digits */
   }
   RETVALUE(ROK);
} /* end of siUnpkSiGenDigits */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkGenAddr
*
*       Desc:  This function unpacks the "GenAddr" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkGenAddr
(
SiGenAddr *pGenAddr,                  /* Generic Address */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkGenAddr(pGenAddr,mBuf)
SiGenAddr *pGenAddr;                   /* Generic Address */
Buffer *mBuf;                          /* message buffer */
#endif
{
   /* sit_c_001.main_15, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U32 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(siUnpkGenAddr)
   /* sit_c_001.main_15, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU32, &bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkElmtHdr,&pGenAddr->eh,mBuf);
   /* element header */
   if (pGenAddr->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->typeOfAddr,mBuf); 
      /* type of address */
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->natAddr,mBuf);    
      /* nature of address indic */
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->oddEven,mBuf);    
      /* odd / even address sign */
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->presRest,mBuf);   
      /* presentation restrict */
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->numPlan1,mBuf);   
      /* numbering plan */
#ifdef SI_ANSILNP
      /* sit_c_001.main_15, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* SI_ANSILNP is defined at the destination, unpacking will be done 
       * only if the orignator indicates that is has packed the parameter 
       * (determined from the bit vector). If not send by orignator we 
       * substitute a default value for the parameter
       */
      if (bitVector & SIT_ANSILNP_BIT)
      {
         CMCHKUNPK(cmUnpkTknU8,&pGenAddr->testInd,mBuf);
      }
      else
      {
         pGenAddr->testInd.pres = PRSNT_NODEF;
         pGenAddr->testInd.val = SITIF_VER1_CONREQ_DEF_TESTIND_VAL;
      }
#else
      /* No rolling upgrade support so we base our unpacking decision
       * solely on the compile tiem flag
       */
      CMCHKUNPK(cmUnpkTknU8,&pGenAddr->testInd,mBuf);
#endif
#else /* SI_ANSILNP not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* the compile time flag is not defined at destination but may be 
       * defined at origiator. If so we unpack and discard the parameter
       */
     if (bitVector & SIT_ANSILNP_BIT)
     {
        TknU8 tempVar;
        CMCHKUNPK(cmUnpkTknU8,&tempVar,mBuf);
     }
#endif
      /* test indicator */
#endif /* SI_ANSILNP */
      CMCHKUNPK(cmUnpkTknStr,&pGenAddr->addrSig,mBuf);  
      /* addressing signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkGenAddr */
#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_BELL || SS7_ANS95 || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkGenName
*
*       Desc:  This function unpacks the "GenName" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkGenName
(
SiGenName *pGenName,                   /* Generic Name */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkGenName(pGenName,mBuf)
SiGenName *pGenName;                   /* Generic Name */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkGenName)
   CMCHKUNPK(cmUnpkElmtHdr,&pGenName->eh,mBuf);
   /* element header */
   if (pGenName->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pGenName->present,mBuf); 
      /* presentation */
      CMCHKUNPK(cmUnpkTknU8,&pGenName->avail,mBuf);    
      /* availability */
      CMCHKUNPK(cmUnpkTknU8,&pGenName->typeName,mBuf);    
      /* type of name */
      CMCHKUNPK(cmUnpkTknStr,&pGenName->character,mBuf);  
      /* character */
   }
   RETVALUE(ROK);
} /* end of siUnpkGenName */
#endif
/* sit_c_003.main_15: Addition - added SS7_INDIA */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_BELL || SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || SS7_ETSIV3 \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkHopCounter
*
*       Desc:  This function unpacks the "HopCounter" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkHopCounter
(
SiHopCounter *pHopCounter,             /* hop counter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkHopCounter(pHopCounter,mBuf)
SiHopCounter *pHopCounter;             /* hop counter  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkHopCounter)
   CMCHKUNPK(cmUnpkElmtHdr,&pHopCounter->eh,mBuf);
   /* element header */
   if (pHopCounter->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pHopCounter->hopCounter,mBuf); 
      /* hop counter */
   }
   RETVALUE(ROK);
} /* end of siUnpkHopCounter */
#endif
#if (SS7_BELL || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkRedirCap
*
*       Desc:  This function unpacks the "RedirCap" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkRedirCap
(
SiRedirCap *pRedirCap,                 /* Redirect capability */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirCap(pRedirCap,mBuf)
SiRedirCap *pRedirCap;                 /* Redirect capability  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkRedirCap)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirCap->eh,mBuf);
   /* element header */
   if (pRedirCap->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirCap->redirCap,mBuf); 
      /* capability */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirCap */



/*
*
*       Fun:   siUnpkRedirCntr
*
*       Desc:  This function unpacks the "RedirCntr" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkRedirCntr
(
SiRedirCntr *pRedirCntr,               /* Redirect counter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirCntr(pRedirCntr,mBuf)
SiRedirCntr *pRedirCntr;               /* Redirect counter  */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkRedirCntr)
   CMCHKUNPK(cmUnpkElmtHdr,&pRedirCntr->eh,mBuf);
   /* element header */
   if (pRedirCntr->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pRedirCntr->redirCntr,mBuf); 
      /* counter */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirCntr */
#endif /* SS7_BELL || SS7_ITU2000 */


/*
*
*       Fun:   siUnpkNotifInd
*
*       Desc:  This function unpacks the "NotifInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkNotifInd
(
SiNotifInd *pNotifInd,                /* Notification Indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkNotifInd(pNotifInd,mBuf)
SiNotifInd *pNotifInd;                 /* Notification Indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkNotifInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pNotifInd->eh,mBuf);
   /* element header */
   if (pNotifInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNotifInd->notifInd,mBuf);  
      /* Notification Indicat */
   }
   RETVALUE(ROK);
} /* end of siUnpkNotifInd */


/*
*
*       Fun:   siUnpkServiceAct
*
*       Desc:  This function unpacks the "ServiceAct" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkServiceAct
(
SiServiceAct *pServiceAct,            /* Service Activation */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkServiceAct(pServiceAct,mBuf)
SiServiceAct *pServiceAct;             /* Service Activation */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkServiceAct)
   CMCHKUNPK(cmUnpkElmtHdr,&pServiceAct->eh,mBuf);
   /* element header */
   if (pServiceAct->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pServiceAct->serviceAct,mBuf);
      /* service activation */
   }
   RETVALUE(ROK);
} /* end of siUnpkServiceAct */

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkChargeNum
*
*       Desc:  This function unpacks the "ChargeNum" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkChargeNum
(
SiChargeNum *pChargeNum,              /* Charge Number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkChargeNum(pChargeNum,mBuf)
SiChargeNum *pChargeNum;               /* Charge Number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC2(siUnpkChargeNum)
   CMCHKUNPK(cmUnpkElmtHdr,&pChargeNum->eh,mBuf);
   /* element header */
   if (pChargeNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pChargeNum->natAddr,mBuf);   
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pChargeNum->oddEven,mBuf);    
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pChargeNum->numPlan,mBuf);   
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknStr,&pChargeNum->addrSig,mBuf);  
      /* Address Signal */
   }
   RETVALUE(ROK);
} /* end of siUnpkChargeNum */
#endif


/* sit_c_001.main_15, MODIFIED: moved the siUnpkChargeNum function out of hash 
 * define 
 */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
/*
*
*       Fun:   siUnpkOrigLineInf
*
*       Desc:  This function unpacks the "OrigLineInf" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkOrigLineInf
(
SiOrigLineInf *pOrigLineInf,          /* Originating Line Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkOrigLineInf(pOrigLineInf,mBuf)
SiOrigLineInf *pOrigLineInf;           /* Originating Line Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC2(siUnpkOrigLineInf)
   CMCHKUNPK(cmUnpkElmtHdr,&pOrigLineInf->eh,mBuf);
   /* element header */
   if (pOrigLineInf->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pOrigLineInf->lineInfo,mBuf); 
      /* tranmission medium requirement */
   }
   RETVALUE(ROK);
} /* end of siUnpkOrigLineInf */
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS88) || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkIndex
*
*       Desc:  This function unpacks the "Index" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkIndex
(
SiIndex *pIndex,                      /* Index */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkIndex(pIndex,mBuf)
SiIndex *pIndex;                       /* Index */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC2(siUnpkIndex)
   CMCHKUNPK(cmUnpkElmtHdr,&pIndex->eh,mBuf);
   /* element header */
   if (pIndex->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pIndex->index,mBuf);  
      /* tranmission medium requirement */
   }
   RETVALUE(ROK);
} /* end of siUnpkIndex */


/*
*
*       Fun:   siUnpkFacInfInd
*
*       Desc:  This function unpacks the "FacInfInd" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkFacInfInd
(
SiFacInfInd *pFacInfInd,              /* Facility Information Indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkFacInfInd(pFacInfInd,mBuf)
SiFacInfInd *pFacInfInd;               /* Facility Information Indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC2(siUnpkFacInfInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pFacInfInd->eh,mBuf);
   /* element header */
   if (pFacInfInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFacInfInd->calldPtyFreeInd,mBuf);
      /* facility indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFacInfInd->callgPtyAnsInd,mBuf);
      /* facility indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFacInfInd->facReqEnqInd,mBuf);
      /* facility indicator */
      CMCHKUNPK(cmUnpkTknU8,&pFacInfInd->facReqActInd,mBuf);
      /* facility indicator */
   }
   RETVALUE(ROK);
} /* end of siUnpkFacInfInd */
#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL || defined(TDS_ROLL_UPGRADE_SUPPORT))


/*
*
*       Fun:   siUnpkServiceCode
*
*       Desc:  This function unpacks the "SiServiceCode" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkServiceCode
(
SiServiceCode *pServiceCode,           /* Service code */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkServiceCode(pServiceCode,mBuf)
SiServiceCode *pServiceCode;           /* Service code */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkServiceCode)
   CMCHKUNPK(cmUnpkElmtHdr,&pServiceCode->eh,mBuf);
   /* element header */
   if (pServiceCode->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pServiceCode->sCode,mBuf);
      /* service activation */
   }
   RETVALUE(ROK);
} /* end of siUnpkServiceCode */


/*
*
*       Fun:   siUnpkBusinessGrp
*
*       Desc:  This function unpacks the "BusinessGrp" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkBusinessGrp
(
SiBusinessGrp *pBusinessGrp,          /* Business Group */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkBusinessGrp(pBusinessGrp,mBuf)
SiBusinessGrp *pBusinessGrp;           /* Business Group */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkBusinessGrp)
   CMCHKUNPK(cmUnpkElmtHdr,&pBusinessGrp->eh,mBuf);
   /* element header */

   if (pBusinessGrp->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pBusinessGrp->partySel,mBuf); 
      /* party selector */
      CMCHKUNPK(cmUnpkTknU8,&pBusinessGrp->linePrivInfInd,mBuf); 
      /* line privileges info ident. */
      CMCHKUNPK(cmUnpkTknU8,&pBusinessGrp->BGIDident,mBuf); 
      /* BGID identif  */
      CMCHKUNPK(cmUnpkTknU8,&pBusinessGrp->attendStat,mBuf);
      /* attendant stat */
      CMCHKUNPK(cmUnpkTknU32,&pBusinessGrp->busiGrpIdent,mBuf);   
      /* busin group id */
      CMCHKUNPK(cmUnpkTknU16,&pBusinessGrp->subGrpIdent,mBuf);
      /* sub-group ident */
      CMCHKUNPK(cmUnpkTknU8,&pBusinessGrp->linePriv,mBuf); 
      /* line privileges */
   }
   RETVALUE(ROK);
} /* end of siUnpkBusinessGrp */


/*
*
*       Fun:   siUnpkCarrierId
*
*       Desc:  This function unpacks the "CarrierId" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCarrierId
(
SiCarrierId *pCarrierId,              /* Carrier ID */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCarrierId(pCarrierId,mBuf)
SiCarrierId *pCarrierId;               /* Carrier ID */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCarrierId)
   CMCHKUNPK(cmUnpkElmtHdr,&pCarrierId->eh,mBuf);
   /* element header */

   if (pCarrierId->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->netIdPln1,mBuf); 
      /* network id plan */
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->typNetId2,mBuf);  
      /* type of network id */
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->CIDigit1,mBuf);  
      /* Network Id Digit 1 */
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->CIDigit2,mBuf); 
      /* Network Id Digit 2 */
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->CIDigit3,mBuf);   
      /* Network Id Digit 3 */
      CMCHKUNPK(cmUnpkTknU8,&pCarrierId->CIDigit4,mBuf);  
      /* Network Id Digit 4 */
   }
   RETVALUE(ROK);
} /* end of siUnpkCarrierId */


/*
*
*       Fun:   siUnpkCarrierSelInf
*
*       Desc:  This function unpacks the "CarrierSelInf" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkCarrierSelInf
(
SiCarrierSelInf *pCarrierSelInf,      /* Carrier Selection Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCarrierSelInf(pCarrierSelInf,mBuf)
SiCarrierSelInf *pCarrierSelInf;       /* Carrier Selection Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCarrierSelInf)
   CMCHKUNPK(cmUnpkElmtHdr,&pCarrierSelInf->eh,mBuf);
   /* element header */
   if (pCarrierSelInf->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCarrierSelInf->carrierSelInf,mBuf); 
      /* Carrier Selection  Information  */
   }
   RETVALUE(ROK);
} /* end of siUnpkCarrierSelInf */


/*
*
*       Fun:   siUnpkEgress
*
*       Desc:  This function unpacks the "Egress" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkEgress
(
SiEgress *pEgress,                    /* Egress Service */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkEgress(pEgress,mBuf)
SiEgress *pEgress;                     /* Egress Service */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkEgress)
   CMCHKUNPK(cmUnpkElmtHdr,&pEgress->eh,mBuf);
   /* element header */
   if (pEgress->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pEgress->egress,mBuf);   
      /* egress */
   }
   RETVALUE(ROK);
} /* end of siUnpkEgress */


/*
*
*       Fun:   siUnpkJurisInf
*
*       Desc:  This function unpacks the "JurisInf" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkJurisInf
(
SiJurisInf *pJurisInf,                /* Jurisdiction Information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkJurisInf(pJurisInf,mBuf)
SiJurisInf *pJurisInf;                 /* Jurisdiction Information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkJurisInf)
   CMCHKUNPK(cmUnpkElmtHdr,&pJurisInf->eh,mBuf);
   /* element header */
   if (pJurisInf->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig1,mBuf); 
      /* address signal 1 */
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig2,mBuf); 
      /* address signal 2 */
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig3,mBuf);  
      /* address signal 3 */
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig4,mBuf);   
      /* address signal 4 */
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig5,mBuf); 
      /* address signal 5 */
      CMCHKUNPK(cmUnpkTknU8,&pJurisInf->addrSig6,mBuf); 
      /* address signal 6 */
   }
   RETVALUE(ROK);
} /* end of siUnpkJurisInf */


/*
*
*       Fun:   siUnpkNetTransport
*
*       Desc:  This function unpacks the "NetTransport" information
*              element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkNetTransport
(
SiNetTransport *pNetTransport,        /* Network Transport */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkNetTransport(pNetTransport,mBuf)
SiNetTransport *pNetTransport;         /* Network Transport */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkNetTransport)
   CMCHKUNPK(cmUnpkElmtHdr,&pNetTransport->eh,mBuf);
   /* element header */
   if (pNetTransport->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pNetTransport->netTransport,mBuf);
      /* network transport */
   }
   RETVALUE(ROK);
} /* end of siUnpkNetTransport */


/*
*
*       Fun:   siUnpkSpecProcReq
*
*       Desc:  This function unpacks the "SpecProcReq" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkSpecProcReq
(
SiSpecProcReq *pSpecProcReq,          /* Special Processing Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkSpecProcReq(pSpecProcReq,mBuf)
SiSpecProcReq *pSpecProcReq;           /* Special Processing Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkSpecProcReq)
   CMCHKUNPK(cmUnpkElmtHdr,&pSpecProcReq->eh,mBuf);
   /* element header */
   if (pSpecProcReq->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pSpecProcReq->specProcReq,mBuf);
      /* specl proces reqst */
   }
   RETVALUE(ROK);
} /* end of siUnpkSpecProcReq */


/*
*
*       Fun:   siUnpkTransReq
*
*       Desc:  This function unpacks the "TransReq" information
*              element structure
*
*       Ret:   RETVALUE(ROK)
*
*       Notes: None
*
*       File:  sit.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siUnpkTransReq
(
SiTransReq *pTransReq,                /* Transaction Request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkTransReq(pTransReq,mBuf)
SiTransReq *pTransReq;                 /* Transaction Request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkTransReq)
   CMCHKUNPK(cmUnpkElmtHdr,&pTransReq->eh,mBuf);
   /* element header */
   if (pTransReq->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pTransReq->transId,mBuf);  
      /* transaction id */
      CMCHKUNPK(cmUnpkTknStr,&pTransReq->SCCPAddr,mBuf);   
      /* SCCP address */
   }
   RETVALUE(ROK);
} /* end of siUnpkTransReq */

#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSI || SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || \
     defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
*
*       Fun:   siUnpkCalTrnsfrRef
*
*       Desc:  This function unpacks the "Call Transfer Reference" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkCalTrnsfrRef
(
SiCallTRef *pCalTrnsfrRef,            /* call transfer reference */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCalTrnsfrRef(pCalTrnsfrRef,mBuf)
SiCallTRef *pCalTrnsfrRef;             /* call transfer reference */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCalTrnsfrRef)
   CMCHKUNPK(cmUnpkElmtHdr,&pCalTrnsfrRef->eh,mBuf); 
   /* element header */
   if (pCalTrnsfrRef->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCalTrnsfrRef->callTrnsfr,mBuf); 
      /* call transfer reference */
   }
   RETVALUE(ROK);
} /* end of siUnpkCalTrnsfrRef */


/*
*
*       Fun:   siUnpkLoopPrvntInd
*
*       Desc:  This function unpacks the "Loop Prevention Indicator" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkLoopPrvntInd
(
SiLoopPrvntInd *pLoopPrvntInd,           /* loop prevention Indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkLoopPrvntInd(pLoopPrvntInd,mBuf)
SiLoopPrvntInd *pLoopPrvntInd;            /* loop prevention Indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkLoopPrvntInd)
   CMCHKUNPK(cmUnpkElmtHdr,&pLoopPrvntInd->eh,mBuf); 
   /* element header */
   if (pLoopPrvntInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pLoopPrvntInd->loopPrvntRspInd,mBuf); 
      /* loop prevention response ind */
      CMCHKUNPK(cmUnpkTknU8,&pLoopPrvntInd->loopPrvntType,mBuf); 
      /* loop prevention type */
   }
   RETVALUE(ROK);
} /* end of siUnpkLoopPrvntInd */

#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSI || SS7_FTZ || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
*
*       Fun:   siUnpkFreePhParam
*
*       Desc:  This function unpacks the "FreePhone Parmeter" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkFreePhParam
(
SiFreePhInd *pFreePhInd,              /* Freephone indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkFreePhParam(pFreePhInd,mBuf)
SiFreePhInd *pFreePhInd;               /* Freephone indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkFreePhParam)
   CMCHKUNPK(cmUnpkElmtHdr,&pFreePhInd->eh,mBuf); 
   /* element header */
   if (pFreePhInd->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFreePhInd->freePhInd,mBuf); 
      /* freephone ind */
   }
   RETVALUE(ROK);
} /* end of siUnpkFreePhParam */



/*
*
*       Fun:   siUnpkCCBSParam
*
*       Desc:  This function unpacks the "CCBS Parmeter" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkCCBSParam
(
SiCcbsParam *pCCBSParam,              /* Freephone indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCCBSParam(pCCBSParam,mBuf)
SiCcbsParam *pCCBSParam;               /* Freephone indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCCBSParam)
   CMCHKUNPK(cmUnpkElmtHdr,&pCCBSParam->eh,mBuf); 
   if (pCCBSParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pCCBSParam->ccbsCallInd,mBuf); 
      /* CCBS ind */
   }
   /* element header */
   RETVALUE(ROK);
} /* end of siUnpkCCBSParam */

#endif /* SS7_ETSI || SS7_FTZ */

#if SS7_FTZ

/*
*
*       Fun:   siUnpkNaPaFF
*
*       Desc:  This function unpacks the "National Parameter FF"
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaFF 
(
SiNaPaFF *pNaPaFF,         /* national parameter FF */
Buffer *mBuf,              /* message buffer */
U8 evntType                /* event type used as union selector */
)
#else
PRIVATE S16 siUnpkNaPaFF (pNaPaFF,mBuf,evntType)
SiNaPaFF *pNaPaFF;         /* national parameter FF */
Buffer *mBuf;              /* message buffer */
U8 evntType;               /* event type used as union selector */
#endif
{
   TRC3(siUnpkNaPaFF)
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaFF->eh,mBuf);
   /* element header */
   if (pNaPaFF->eh.pres)
   {
      switch (evntType)
      {
         case EVTGTNANA:
            CMCHKUNPK(cmUnpkTknStr,&pNaPaFF->messg.inNANA.data,mBuf);
            /* undecoded data */
            break;
         case EVTGTIAM:
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inIAM.natClgPtyCat,mBuf);
            /* national calling party category */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inIAM.catphInd,mBuf);
            /* catastrophe indicator */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inIAM.zoneInd,mBuf);
            /* zoning indicator */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inIAM.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inIAM.srvIndAddOct,mBuf);
            /* service indicator additional info octet */
            break;
         case EVTGTANM:
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inANM.SINMeanInd,mBuf);
            /* SIN meaning indicator */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inANM.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inANM.srvIndAddOct,mBuf);
            /* service indicator addtitional info octet */
            break;
         case EVTGTFRQ:
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inFRQ.facCode,mBuf);
            /* facility code */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inFRQ.srvIndOct,mBuf);
            /* service indicator octet */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inFRQ.srvIndAddOct,mBuf);
            /* service indicator addtitional info octet */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inFRQ.trmSelCode,mBuf);
            /* terminal selection code */
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inFRQ.cugCallInd,mBuf);
            /* closed user group call indicator */
            CMCHKUNPK(cmUnpkTknU32,&pNaPaFF->messg.inFRQ.cugIntCode,mBuf);
            /* closed user group interlock code */
            break;
         case EVTGTMLTP:
         case EVTGTCHG:
         case EVTGTFACD:
         case EVTGTFIN:
            CMCHKUNPK(cmUnpkTknU8,&pNaPaFF->messg.inMultMsg.multPurp,mBuf);
            /* multipurpouse code */
            break;

         default:
            RETVALUE(RFAILED);
         } /* end of switch evntType */
   }       /* end of if (pNaPaFF->eh.pres) */

   RETVALUE(ROK);
} /* end of siUnpkNaPaFF */


/*
*
*       Fun:   siUnpkNaPaSPV
*
*       Desc:  This function unpacks the "Nat. Par. for SPV " 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaSPV 
(
SiNaPaSPV *pNaPaSPV,            /* National parameter for SPV */
Buffer *mBuf                    /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaSPV (pNaPaSPV,mBuf)
SiNaPaSPV *pNaPaSPV;            /* National parameter for SPV */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(siUnpkNaPaSPV)
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaSPV->eh,mBuf);
   /* element header */
   if (pNaPaSPV->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSPV->naPaSPVInd,mBuf);
      /* SPV indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSPV->naPaSPVSrvInd,mBuf);
      /* SPV service indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSPV->naPaKDEInd,mBuf);
      /* KDE indicator */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaSPV */


/*
*
*       Fun:   siUnpkNaPaFE
*
*       Desc:  This function unpacks the "National Parameter FE" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaFE 
(
SiNaPaFE *pNaPaFE,               /* national parameter FE */
Buffer *mBuf                     /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaFE (pNaPaFE,mBuf)
SiNaPaFE *pNaPaFE;               /* national parameter FE */
Buffer *mBuf;                    /* message buffer */
#endif
{
   TRC3(siUnpkNaPaFE)

   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaFE->eh,mBuf);
   /* element header */
   if (pNaPaFE->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaFE->disastrPriv,mBuf);
      /* Disaster Privilege */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaFE */


/*
*
*       Fun:   siUnpkNaPaSSP
*
*       Desc:  This function unpacks the "Nat. Parameter for SSP" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaSSP 
(
SiNaPaSSP *pNaPaSSP,             /* national parameter for SSP */
Buffer *mBuf                     /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaSSP (pNaPaSSP,mBuf)
SiNaPaSSP *pNaPaSSP;             /* national parameter for SSP */
Buffer *mBuf;                    /* message buffer */
#endif
{
   TRC3(siUnpkNaPaSSP)

   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaSSP->eh,mBuf);
   /* element header */
   if (pNaPaSSP->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSSP->stopSignMon,mBuf);
      /* indic. for stopping signalling monitoring */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSSP->nmbFiveProt,mBuf);
      /* indic. for number 5 protection function */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSSP->callDiver,mBuf);
      /* indic. for call diversion */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSSP->naPaTrnstInd,mBuf);
      /* transit indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaSSP->servTypRec,mBuf);
      /* service type recognition */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaSSP */


/*
*
*       Fun:   siUnpkNaPaCdPNO
*
*       Desc:  This function unpacks the "Nat. Parmeter for CdPNO" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaCdPNO 
(
SiNaPaCdPNO *pNaPaCdPNO,             /* national parameter for CdPNO */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaCdPNO (pNaPaCdPNO,mBuf)
SiNaPaCdPNO *pNaPaCdPNO;              /* national parameter for CdPNO */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkNaPaCdPNO)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaCdPNO->eh,mBuf);
   /* element header */
   if (pNaPaCdPNO->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->natAddrInd,mBuf);
      /* nature of addresss indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->oddEven,mBuf);
      /* odd or even */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->screenInd,mBuf);
      /* screening indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->presRest,mBuf);
      /* presentation restriction */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->numPlan,mBuf);
      /* numbering plan */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCdPNO->innInd,mBuf);
      /* international network number indicator */
      CMCHKUNPK(cmUnpkTknStr,&pNaPaCdPNO->addrSig,mBuf);
      /* Address Signal */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaCdPNO */


/*
*
*       Fun:   siUnpkNaPaExTID
*
*       Desc:  This function unpacks the "Nat. Parameter for ExTID" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaExTID 
(
SiNaPaExTID *pNaPaExTID,         /* national parameter for ExTID */
Buffer *mBuf                     /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaExTID (pNaPaExTID,mBuf)
SiNaPaExTID *pNaPaExTID;         /* national parameter for ExTID */
Buffer *mBuf;                    /* message buffer */
#endif
{
   TRC3(siUnpkNaPaExTID)

   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaExTID->eh,mBuf);
   /* element header */
   if (pNaPaExTID->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU16,&pNaPaExTID->sigPntCde,mBuf);
      /* signalling point code */
      CMCHKUNPK(cmUnpkTknStr,&pNaPaExTID->incTrkId,mBuf);
      /* incoming trunk Id */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaExTID */
#endif
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_FTZ || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun:   siUnpkNaPaChgPID
*
*       Desc:  This function unpacks the "Nat. Parameter for ChgPID" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaChgPID
(
SiNaPaChgPID *pNaPaChgPID,           /* national parameter for ChgPID */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaChgPID (pNaPaChgPID,mBuf)
SiNaPaChgPID *pNaPaChgPID;            /* national parameter for ChgPID */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkNaPaChgPID)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaChgPID->eh,mBuf);
   /* element header */
   if (pNaPaChgPID->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pNaPaChgPID->naPaChgPtyId,mBuf);
      /* charged party identification */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaChgPID */
#endif
#if SS7_FTZ

/*
*
*       Fun:   siUnpkNaPaCHGI
*
*       Desc:  This function unpacks the "Nat. Parameter for CHGI" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaCHGI 
(
SiNaPaCHGI *pNaPaCHGI,             /* national parameter for CHGI */
Buffer *mBuf                       /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaCHGI (pNaPaCHGI,mBuf)
SiNaPaCHGI *pNaPaCHGI;             /* national parameter for CHGI */
Buffer *mBuf;                      /* message buffer */
#endif
{
   TRC3(siUnpkNaPaCHGI)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaCHGI->eh,mBuf);
   /* element header */
   if (pNaPaCHGI->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCHGI->naPaSeqNmb,mBuf);
      /* sequence number */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaCHGI->naPaRcptInf,mBuf);
      /* receipt information */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaCHGI */


/*
*
*       Fun:   siUnpkFacIndInfor
*
*       Desc:  This function unpacks the "Facility indic. inf. Par." 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkFacIndInfor 
(
SiFacIndInfor *pFacIndInfor,      /* facility indicator information */
Buffer *mBuf                      /* message buffer */
)
#else
PRIVATE S16 siUnpkFacIndInfor (pFacIndInfor,mBuf)
SiFacIndInfor *pFacIndInfor;      /* facility indicator information */
Buffer *mBuf;                     /* message buffer */
#endif
{
   TRC3(siUnpkFacIndInfor)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pFacIndInfor->eh,mBuf);
   /* element header */
   if (pFacIndInfor->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pFacIndInfor->cldPtyFreeInd,mBuf);
      /* called party free indicator */
   }

   RETVALUE(ROK);
} /* end of siUnpkFacIndInfor */


/*
*
*       Fun:   siUnpkNaPaTTZ
*
*       Desc:  This function unpacks the "Nat. Parameter for TTZ" 
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaTTZ 
(
SiNaPaTTZ *pNaPaTTZ,              /* national parameter for TTZ */
Buffer *mBuf                      /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaTTZ (pNaPaTTZ,mBuf)
SiNaPaTTZ *pNaPaTTZ;              /* national parameter for TTZ */
Buffer *mBuf;                     /* message buffer */
#endif
{
   TRC3(siUnpkNaPaTTZ)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaTTZ->eh,mBuf);
   /* element header */
   if (pNaPaTTZ->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&pNaPaTTZ->naPaTTZ,mBuf);
      /* national paramemeter for Tln-2-Tln sign. */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaTTZ */


/*
*
*       Fun:   siUnpkNaPaUKK
*
*       Desc:  This function unpacks the "National Parameter for UKK"
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkNaPaUKK 
(
SiNaPaUKK *pNaPaUKK,          /* National Parameter UKK */
Buffer *mBuf                  /* message buffer */
)
#else
PRIVATE S16 siUnpkNaPaUKK (pNaPaUKK,mBuf)
SiNaPaUKK *pNaPaUKK;          /* National Parameter UKK */
Buffer *mBuf;                 /* message buffer */
#endif
{
   TRC3(siUnpkNaPaUKK)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pNaPaUKK->eh,mBuf);
   /* element header */
   if (pNaPaUKK->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->intSpRoutInd,mBuf);
      /* international special routing indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->intSpZonInd,mBuf);
      /* international special zoning indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->intCarRoutInd,mBuf);
      /* international carrier routing indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->natCarRoutInd,mBuf);
      /* national carrier routing indicator */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->rstrRteAccCds,mBuf);
      /* restriction on route access codes */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->clientRecognIndA,mBuf);
      /* client recognition Indicator 1st octet */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->clientRecognIndB,mBuf);
      /* client recognition Indicator 2nd octet */
      CMCHKUNPK(cmUnpkTknU8,&pNaPaUKK->servTypeRecogn,mBuf);
      /* service type recognition */
   }

   RETVALUE(ROK);
} /* end of siUnpkNaPaUKK */
#endif /* SS7_FTZ */

#if SS7_RUSSIA
/*
*
*       Fun:   siUnpkBillZoneNum
*
*       Desc:  This function unpacks the Billing Zone Number
*              information element structure
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/

#ifdef ANSI
PRIVATE S16 siUnpkBillZoneNum 
(
SiBillZoneNum *pBillZoneNum,  /* Billing Zone Number */
Buffer *mBuf                  /* message buffer */
)
#else
PRIVATE S16 siUnpkBillZoneNum (pBillZoneNum,mBuf)
SiBillZoneNum *pBillZoneNum;  /* Billing Zone Number */
Buffer *mBuf;                 /* message buffer */
#endif
{

   TRC3(siUnpkBillZoneNum)
 
   CMCHKUNPK(cmUnpkElmtHdr,&pBillZoneNum->eh,mBuf);
   /* element header */
   if (pBillZoneNum->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU32,&pBillZoneNum->billZoneNum,mBuf);
      /* Billing Zone Number */
   }

   RETVALUE(ROK);
} /* end of siUnpkBillZoneNum */
#endif

#if SS7_NTT
/*
*
*       Fun:   siUnpkMsgAreaInfo
*
*       Desc:  This function unpacks the Message area information
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkMsgAreaInfo
(
SiMsgAreaInfo            *unpkParam,   /* Message area information */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkMsgAreaInfo (unpkParam, mBuf)
SiMsgAreaInfo            *unpkParam;   /* Message area information */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkMsgAreaInfo)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr, &unpkParam->msgAreaInfo, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkMsgAreaInfo */

/*
*
*       Fun:   siUnpkChrgInfo
*
*       Desc:  This function unpacks the Charge Information
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkChrgInfo
(
SiChrgInfo               *unpkParam,   /* Charge Information */
SiChrgInfoType           *pcType,      /* Charge information type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkChrgInfo (unpkParam, pcType, mBuf)
SiChrgInfo               *unpkParam;   /* Charge Information */
SiChrgInfoType           *pcType;      /* Charge information type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkChrgInfo)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      if ((pcType->eh.pres) && 
            (pcType->chrgInfoType.pres))
      {
         switch (pcType->chrgInfoType.val)
         {
            case CHRGINFTYP_INTAUTO:
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg1.chrgInfoIdctr, mBuf);
               CMCHKUNPK(cmUnpkTknStr, &unpkParam->p.chrg1.chrgData, mBuf);
               break;
   
            case CHRGINFTYP_FLEXCHRG:
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.signalElemType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.activationId, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.operClass, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.operType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.chrgdUType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.billCollMthd, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg2.billRateIdctr, mBuf);
               CMCHKUNPK(cmUnpkTknStr, &unpkParam->p.chrg2.billRateInfo, mBuf);
               break;
   
            case CHRGINFTYP_FLEXINTER:
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.signalElemType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.activationId, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.operClass, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.operType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.chrgdUType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.billCollMthd, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg3.billRateIdctr, mBuf);
               CMCHKUNPK(cmUnpkTknStr, &unpkParam->p.chrg3.billRateInfo, mBuf);
               break;
   
            case CHRGINFTYP_NTTPHS:
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg4.signalElemType, mBuf);
               CMCHKUNPK(cmUnpkTknU8, &unpkParam->p.chrg4.oddEvenIdctr, mBuf);
               CMCHKUNPK(cmUnpkTknStr, &unpkParam->p.chrg4.calledAreaInf, mBuf);
               break;
   
            default:
               CMCHKUNPK(cmUnpkTknStrE, &unpkParam->p.data.chrgInfo, mBuf);
               break;
   
         }
      }
      else
      {
         CMCHKUNPK(cmUnpkTknStrE, &unpkParam->p.data.chrgInfo, mBuf);
      }
   }

   RETVALUE(ROK);
}   /* siUnpkChrgInfo */

/*
*
*       Fun:   siUnpkChrgInfoType
*
*       Desc:  This function unpacks the Charge information type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkChrgInfoType
(
SiChrgInfoType            *unpkParam,   /* Charge information type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkChrgInfoType (unpkParam, mBuf)
SiChrgInfoType            *unpkParam;   /* Charge information type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkChrgInfoType)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->chrgInfoType, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkChrgInfoType */

/*
*
*       Fun:   siUnpkChrgInfoDelay
*
*       Desc:  This function unpacks the Charge information delay
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkChrgInfoDelay
(
SiChrgInfoDelay          *unpkParam,   /* Charge information delay */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkChrgInfoDelay (unpkParam, mBuf)
SiChrgInfoDelay          *unpkParam;   /* Charge information delay */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkChrgInfoDelay)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr, &unpkParam->chrgInfoDelay, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkChrgInfoDelay */

/*
*
*       Fun:   siUnpkSubsNumber
*
*       Desc:  This function unpacks the Subscriber number
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkSubsNumber
(
SiSubsNumber             *unpkParam,   /* Subscriber number */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkSubsNumber (unpkParam, mBuf)
SiSubsNumber             *unpkParam;   /* Subscriber number */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkSubsNumber)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr, &unpkParam->subsNumber, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkSubsNumber */

/*
*
*       Fun:   siUnpkReasProhibCllngNo
*
*       Desc:  This function unpacks the Reason for prohibiting cllng no
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkReasProhibCllngNo
(
SiReasProhibCllngNo      *unpkParam,   /* Reason for prohibiting cllng no */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkReasProhibCllngNo (unpkParam, mBuf)
SiReasProhibCllngNo      *unpkParam;   /* Reason for prohibiting cllng no */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkReasProhibCllngNo)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->rpCllngNo, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkReasProhibCllngNo */

/*
*
*       Fun:   siUnpkSupplUserType
*
*       Desc:  This function unpacks the Supplementary user type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkSupplUserType
(
SiSupplUserType          *unpkParam,   /* Supplementary user type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkSupplUserType (unpkParam, mBuf)
SiSupplUserType          *unpkParam;   /* Supplementary user type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkSupplUserType)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr, &unpkParam->supplUserType, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkSupplUserType */

/*
*
*       Fun:   siUnpkCarrierInfoTrans
*
*       Desc:  This function unpacks the Carrier Information transfer
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkCarrierInfoTrans
(
SiCarrierInfoTrans       *unpkParam,   /* Carrier Information transfer */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkCarrierInfoTrans (unpkParam, mBuf)
SiCarrierInfoTrans       *unpkParam;   /* Carrier Information transfer */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkCarrierInfoTrans)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr, &unpkParam->carrierInfoTrans, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkCarrierInfoTrans */

/*
*
*       Fun:   siUnpkNwFuncType
*
*       Desc:  This function unpacks the Network function type
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PRIVATE S16 siUnpkNwFuncType
(
SiNwFuncType             *unpkParam,   /* Network function type */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 siUnpkNwFuncType (unpkParam, mBuf)
SiNwFuncType             *unpkParam;   /* Network function type */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(siUnpkNwFuncType)

   CMCHKUNPK(cmUnpkElmtHdr, &unpkParam->eh, mBuf);

   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->nwFuncType, mBuf);
   }

   RETVALUE(ROK);
}   /* siUnpkNwFuncType */

#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
* 
*        Fun:   siUnpkCirAsgnMap
* 
*        Desc:  This function unpacks the "CirAsgnMap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCirAsgnMap
(
SiCirAsgnMap *unpkParam,              /* circuit assignment map */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCirAsgnMap(unpkParam,mBuf)
SiCirAsgnMap *unpkParam;               /* circuit assignment map */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCirAsgnMap)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8 ,&unpkParam->mapType,mBuf);
      CMCHKUNPK(cmUnpkTknU32,&unpkParam->mapFormat,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCirAsgnMap */
#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (defined(SS7_ANS95) || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
* 
*        Fun:   siUnpkOptrServicesInfo
* 
*        Desc:  This function unpacks the "OptrServicesInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkOptrServicesInfo
(
SiOptrServicesInfo *unpkParam,              /* operator services information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkOptrServicesInfo(unpkParam,mBuf)
SiOptrServicesInfo *unpkParam;               /* operator services information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkOptrServicesInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8 ,&unpkParam->infoType,mBuf);
      CMCHKUNPK(cmUnpkTknU8 ,&unpkParam->infoVal,mBuf);
      /* Information elements */
   }
   /* element header */
   RETVALUE(ROK);
} /* end of siUnpkOptrServicesInfo */
#endif

/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if ((SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000) || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
* 
*        Fun:   siUnpkBackGVNS
* 
*        Desc:  This function unpacks the "BackGVNS" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkBackGVNS
(
SiBackGVNS *unpkParam,              /* BackGVNS */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkBackGVNS(unpkParam,mBuf)
SiBackGVNS *unpkParam;               /* BackGVNS */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkBackGVNS)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->termAccessInd,mBuf);
      /* Information elements */
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->extInfo,mBuf);
      /* Extension Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkBackGVNS */

/*
* 
*        Fun:   siUnpkForwardGVNS
* 
*        Desc:  This function unpacks the "ForwardGVNS" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkForwardGVNS
(
SiForwardGVNS *unpkParam,              /* ForwardGVNS */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkForwardGVNS(unpkParam,mBuf)
SiForwardGVNS *unpkParam;               /* ForwardGVNS */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkForwardGVNS)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->digits3,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->natOfAddr,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->numPlan,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->oddEven3,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->lenInd3,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->digits2,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->oddEven2,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->lenInd2,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->digits1,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->oddEven1,mBuf);
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->lenInd1,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkForwardGVNS */
#endif

/* sit_c_003.main_15: Addition - added SS7_INDIA */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || SS7_ETSIV3 \
     || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
* 
*        Fun:   siUnpkCallDivTrtInd
* 
*        Desc:  This function unpacks the "CallDivTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCallDivTrtInd
(
SiCallDivTrtInd *unpkParam,              /* call diversion treatment ind */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCallDivTrtInd(unpkParam,mBuf)
SiCallDivTrtInd *unpkParam;               /* call diversion treatment ind */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCallDivTrtInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8 ,&unpkParam->callDivInd,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->extInfo,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCallDivTrtInd */


/*
* 
*        Fun:   siUnpkCallOfferTrtInd
* 
*        Desc:  This function unpacks the "CallOfferTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCallOfferTrtInd
(
SiCallOfferTrtInd *unpkParam,              /* call offering treatment ind */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCallOfferTrtInd(unpkParam,mBuf)
SiCallOfferTrtInd *unpkParam;               /* call offering treatment ind */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCallOfferTrtInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->callOfferInd,mBuf);
      /* Information elements */
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->extInfo,mBuf);
      /* Extension Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkCallOfferTrtInd */


/*
* 
*        Fun:   siUnpkCallInNmb
* 
*        Desc:  This function unpacks the "CallInNmb" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCallInNmb
(
SiCallInNmb *unpkParam,              /* call IN number */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCallInNmb(unpkParam,mBuf)
SiCallInNmb *unpkParam;               /* call IN number */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCallInNmb)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->natAddr,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->oddEven,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->scrInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->presRest,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->numPlan,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->addrSig,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCallInNmb */

/*
* 
*        Fun:   siUnpkCcss
* 
*        Desc:  This function unpacks the "Ccss" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCcss
(
SiCcss *unpkParam,              /* Ccss */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCcss(unpkParam,mBuf)
SiCcss *unpkParam;               /* Ccss */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCcss)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->ccssCallInd,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCcss */

/*
* 
*        Fun:   siUnpkCollCallReq
* 
*        Desc:  This function unpacks the "CollCallReq" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCollCallReq
(
SiCollCallReq *unpkParam,              /* collect call request */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCollCallReq(unpkParam,mBuf)
SiCollCallReq *unpkParam;               /* collect call request */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCollCallReq)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->collCallReqInd,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCollCallReq */

/*
* 
*        Fun:   siUnpkConfTrtInd
* 
*        Desc:  This function unpacks the "ConfTrtInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkConfTrtInd
(
SiConfTrtInd *unpkParam,              /* confrence treatment indicators */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkConfTrtInd(unpkParam,mBuf)
SiConfTrtInd *unpkParam;               /* confrence treatment indicators */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkConfTrtInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->confAcceptInd,mBuf);
      /* Information elements */
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->extInfo,mBuf);
      /* Extension Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkConfTrtInd */

/*
* 
*        Fun:   siUnpkCorrelationId
* 
*        Desc:  This function unpacks the "CorrelationId" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCorrelationId
(
SiCorrelationId *unpkParam,              /* CorrelationId */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkCorrelationId(unpkParam,mBuf)
SiCorrelationId *unpkParam;               /* CorrelationId */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkCorrelationId)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->correlationId,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCorrelationId */

/*
* 
*        Fun:   siUnpkDisplayInfo
* 
*        Desc:  This function unpacks the "DisplayInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkDisplayInfo
(
SiDisplayInfo *unpkParam,              /* display information */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkDisplayInfo(unpkParam,mBuf)
SiDisplayInfo *unpkParam;               /* display information */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkDisplayInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->displayInfo,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkDisplayInfo */

/*
* 
*        Fun:   siUnpkNetMgmtControls
* 
*        Desc:  This function unpacks the "NetMgmtControls" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkNetMgmtControls
(
SiNetMgmtControls *unpkParam,              /* network management controls */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkNetMgmtControls(unpkParam,mBuf)
SiNetMgmtControls *unpkParam;               /* network management controls */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkNetMgmtControls)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->tmpAltRoutInd,mBuf);
      /* Information elements */
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->extInfo,mBuf);
      /* Extension Info */
   }
   RETVALUE(ROK);
} /* end of siUnpkNetMgmtControls */

/*
* 
*        Fun:   siUnpkScfId
* 
*        Desc:  This function unpacks the "ScfId" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkScfId
(
SiScfId *unpkParam,              /* ScfId */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkScfId(unpkParam,mBuf)
SiScfId *unpkParam;               /* ScfId */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkScfId)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->scfId,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkScfId */

/*
* 
*        Fun:   siUnpkUidActionInd
* 
*        Desc:  This function unpacks the "UidActionInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkUidActionInd
(
SiUidActionInd *unpkParam,              /* UID action indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkUidActionInd(unpkParam,mBuf)
SiUidActionInd *unpkParam;               /* UID action indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkUidActionInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->throughConnInstInd,mBuf);
      /* Through connection instruction ind. */
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->t9InstInd,mBuf);
      /* T9 instruction ind. */
   }
   RETVALUE(ROK);
} /* end of siUnpkUidActionInd */

/*
* 
*        Fun:   siUnpkUidCapInd
* 
*        Desc:  This function unpacks the "UidCapInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkUidCapInd
(
SiUidCapInd *unpkParam,              /* UID capability indicator */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkUidCapInd(unpkParam,mBuf)
SiUidCapInd *unpkParam;               /* UID capability indicator */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkUidCapInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->throughConnInd,mBuf);
      /* Through connection instruction ind. */
      CMCHKUNPK(cmUnpkTknU8, &unpkParam->t9Ind,mBuf);
      /* T9 instruction ind. */
   }
   RETVALUE(ROK);
} /* end of siUnpkUidCapInd */
#endif

/* sit_c_003.main_15: Addition - added SS7_INDIA */
/* sit_c_001.main_15, MODIFIED: Put the TDS_ROLL_UPGRADE_SUPPORT flag */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA || \
     defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
* 
*        Fun:   siUnpkAppTransParam
* 
*        Desc:  This function unpacks the "AppTransParam" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkAppTransParam
(
SiAppTransParam *unpkParam,              /* application transport parameter */
Buffer *mBuf                           /* message buffer */
)
#else
PRIVATE S16 siUnpkAppTransParam(unpkParam,mBuf)
SiAppTransParam *unpkParam;               /* application transport parameter */
Buffer *mBuf;                          /* message buffer */
#endif
{
   TRC3(siUnpkAppTransParam)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->appContextId,mBuf);
#if SS7_ITU2000
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->appContextId1,mBuf);
#endif
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->atii,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->apmSegInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->seqInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->slr,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->encapAppInfo,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkAppTransParam */
#endif

/* sit_c_005.main_15: Addition - added SS7_ITU2000 */
#if (SS7_ITU2000 || defined(TDS_ROLL_UPGRADE_SUPPORT))
/*
* 
*        Fun:   siUnpkCalgGeoLoc
* 
*        Desc:  This function unpacks the "CalgGeoLoc" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCalgGeoLoc
(
SiCalgGeoLoc *unpkParam,              /* calling geodetic location parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkCalgGeoLoc(unpkParam,mBuf)
SiCalgGeoLoc *unpkParam;              /* calling geodetic location parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkCalgGeoLoc)
   /* element header */
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->scrnInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->presRest,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->typeShape,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->shapeDescr,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCalgGeoLoc */

/*
* 
*        Fun:   siUnpkCCNRPosInd
* 
*        Desc:  This function upacks the "CCNRPosInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkCCNRPosInd
(
SiCCNRPosInd *unpkParam,              /* CCNR Possible indicator parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkCCNRPosInd(unpkParam,mBuf)
SiCCNRPosInd *unpkParam;              /* CCNR Possible indicator parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkCCNRPosInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->ccnrPosInd,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkCCNRPosInd */

/*
* 
*        Fun:   siUnpkNetRoutNum
* 
*        Desc:  This function unpacks the "NetRoutNum" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkNetRoutNum
(
SiNetRoutNum *unpkParam,              /* Network Routing Number parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkNetRoutNum(unpkParam,mBuf)
SiNetRoutNum *unpkParam;              /* Network Routing Number parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkNetRoutNum)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->natAddrInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->numPlan,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->oddEven,mBuf);
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->addrSig,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkNetRoutNum */

/*
* 
*        Fun:   siUnpkPivotCap
* 
*        Desc:  This function unpacks the "PivotCap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkPivotCap
(
SiPivotCap *unpkParam,                /* Pivot CapabilityCCNR parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkPivotCap(unpkParam,mBuf)
SiPivotCap *unpkParam;                /* Pivot Capability parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkPivotCap)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->pivotPossInd,mBuf);
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->iwToRedirInd,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPivotCap */

/*
* 
*        Fun:   siUnpkPivotCntr
* 
*        Desc:  This function unpacks the "PivotCntr" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkPivotCntr
(
SiPivotCntr *unpkParam,               /* Pivot Counter parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkPivotCntr(unpkParam,mBuf)
SiPivotCntr *unpkParam;               /* Pivot Counter parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkPivotCntr)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->pivotCntr,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPivotCntr */

/*
* 
*        Fun:   siUnpkPivotRtgInd
* 
*        Desc:  This function unpacks the "PivotRtgInd" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkPivotRtgInd
(
SiPivotRtgInd *unpkParam,             /* Pivot Routing parameter */
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkPivotRtgInd(unpkParam,mBuf)
SiPivotRtgInd *unpkParam;             /* Pivot Routing parameter */
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkPivotRtgInd)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->pivotRtg,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPivotRtgInd */

/*
* 
*        Fun:   siUnpkPivotRtgBkInfo
* 
*        Desc:  This function unpacks the "PivotRtgBkInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkPivotRtgBkInfo
(
SiPivotRtgBkInfo *unpkParam,          /* Pivot Routing Backward/Fwd parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkPivotRtgBkInfo(unpkParam,mBuf)
SiPivotRtgBkInfo *unpkParam;          /* Pivot Routing Backward/Fwd parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkPivotRtgBkInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknStr,&unpkParam->pivotRtgInfo,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPivotRtgBkInfo */

/*
* 
*        Fun:   siUnpkNumPortFwdInfo
* 
*        Desc:  This function unpacks the "NumPortFwdInfo" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkNumPortFwdInfo
(
SiNumPortFwdInfo *unpkParam,          /* Number Portability Forward parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkNumPortFwdInfo(unpkParam,mBuf)
SiNumPortFwdInfo *unpkParam;          /* Number Portability Forward parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkNumPortFwdInfo)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->numPortStatus,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkNumPortFwdInfo */

/*
* 
*        Fun:   siUnpkQOnRelCap
* 
*        Desc:  This function unpacks the "QOnRelCap" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkQOnRelCap
(
SiQOnRelCap *unpkParam,               /* Query on Release Cap parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkQOnRelCap(unpkParam,mBuf)
SiQOnRelCap *unpkParam;               /* Query on Release Cap parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkQOnRelCap)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->qorCap,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPkQOnRelCap */

/*
* 
*        Fun:   siUnpkPivotStat
* 
*        Desc:  This function unpacks the "PivotStat" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkPivotStat
(
SiPivotStat *unpkParam,               /* Pivot Status parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkPivotStat(unpkParam,mBuf)
SiPivotStat *unpkParam;               /* Pivot Status parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkPivotStat)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->status,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkPivotStat */

/*
* 
*        Fun:   siUnpkkRedirStat
* 
*        Desc:  This function unpacks the "RedirStat" information
*               element structure
* 
*        Ret:   ROK
* 
*        Notes: None
* 
*        File:  sit.c
* 
*/

#ifdef ANSI
PRIVATE S16 siUnpkRedirStat
(
SiRedirStat *unpkParam,               /* Redirect Status parameter*/
Buffer *mBuf                          /* message buffer */
)
#else
PRIVATE S16 siUnpkRedirStat(unpkParam,mBuf)
SiRedirStat *unpkParam;               /* Redirect Status parameter*/
Buffer *mBuf;                         /* message buffer */
#endif
{
   TRC3(siUnpkRedirStat)
   CMCHKUNPK(cmUnpkElmtHdr,&unpkParam->eh,mBuf);
   /* element header */
   if (unpkParam->eh.pres)
   {
      CMCHKUNPK(cmUnpkTknU8,&unpkParam->status,mBuf);
      /* Information elements */
   }
   RETVALUE(ROK);
} /* end of siUnpkRedirStat */

#endif



  
/************************************************************************
 *  PRIMITIVE PACKING/UNPACKING FUNCTIONS FOR LOOSELY COUPLED SIT I/F
 ***********************************************************************/


/*
*
*       Fun:   cmPkSitBndReq
*
*       Desc:  Pack bind request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitBndReq 
(
Pst *pst,
SuId suId,
SpId spId
)
#else
PUBLIC S16 cmPkSitBndReq (pst, suId, spId)
Pst *pst;
SuId suId;
SpId spId;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitBndReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSpId, spId, mBuf, ESIT519, pst);
   CMCHKPKLOG(cmPkSuId, suId, mBuf, ESIT520, pst);

   pst->event = EVTSITBNDREQ;
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitBndReq */


/*
*
*       Fun:   cmUnpkSitBndReq
*
*       Desc:  Unpack bind request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitBndReq 
(
SitBndReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitBndReq (func, pst, mBuf)
SitBndReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId suId;
   SpId spId;

   TRC2(cmUnpkSitBndReq)

   CMCHKUNPKLOG(cmUnpkSuId, &suId, mBuf, ESIT521, pst);
   CMCHKUNPKLOG(cmUnpkSpId, &spId, mBuf, ESIT522, pst);

   SPutMsg(mBuf);

   RETVALUE( func(pst, suId, spId) );
}/* cmUnpkSitBndReq */

#ifdef SIT2


/*
*
*       Fun:   cmPkSitBndCfm
*
*       Desc:  Pack bind confirmation at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitBndCfm 
(
Pst *pst,
SuId suId,
U8   status
)
#else
PUBLIC S16 cmPkSitBndCfm (pst, suId, status)
Pst *pst;
SuId suId;
U8   status;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitBndCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(SPkU8,    status, mBuf, ESIT523, pst);
   CMCHKPKLOG(cmPkSuId, suId,   mBuf, ESIT524, pst);

   pst->event = EVTSITBNDCFM;
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitBndCfm */


/*
*
*       Fun:   cmUnpkSitBndCfm
*
*       Desc:  Unpack bind confirmation at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitBndCfm 
(
SitBndCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitBndCfm (func, pst, mBuf)
SitBndCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId suId;
   U8   status;

   TRC2(cmUnpkSitBndCfm)

   CMCHKUNPKLOG(cmUnpkSuId, &suId,   mBuf, ESIT525, pst);
   CMCHKUNPKLOG(SUnpkU8,    &status, mBuf, ESIT526, pst);

   SPutMsg(mBuf);
   RETVALUE( func(pst, suId, status) );
}/* cmUnpkSitBndCfm */
#endif /* SIT2 */


/*
*
*       Fun:   cmPkSitConReq
*
*       Desc:  Pack Connection request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitConReq 
(
Pst       *pst, 
SpId      spId, 
SiInstId  suInstId,
SiInstId  spInstId, 
Bool      cirSelFlg, 
CirId     circuit,
SiConEvnt *siConEvnt,
U8        xchgType, 
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitConReq (pst, spId, suInstId, spInstId, cirSelFlg, circuit,
                          siConEvnt, xchgType, uBuf)
Pst       *pst;
SpId      spId;
SiInstId  suInstId;
SiInstId  spInstId; 
Bool      cirSelFlg; 
CirId     circuit;
SiConEvnt *siConEvnt;
U8        xchgType; 
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitConReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   
   CMCHKPKLOG(SPkU8, xchgType, mBuf, ESIT527, pst);
   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTIAM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,   mBuf, ESIT528, pst);
   CMCHKPKLOG(cmPkBool,     cirSelFlg, mBuf, ESIT529, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId,  mBuf, ESIT530, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId,  mBuf, ESIT531, pst);
   CMCHKPKLOG(cmPkSpId,     spId,      mBuf, ESIT532, pst);

   pst->event = (Event) EVTSITCONREQ;      /* event */
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}/* cmPkSitConReq */


/*
*
*       Fun:   cmUnpkSitConReq
*
*       Desc:  Unpack connection request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitConReq 
(
SitConReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitConReq (func, pst, mBuf)
SitConReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   Bool      cirSelFlg;        /* circuit selection flag */
   CirId     circuit;          /* circuit ID code */
   SiConEvnt siConEvnt;        /* connect event */
   U8        xchgType;         /* type of exchange */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitConReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,      mBuf, ESIT533, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId,  mBuf, ESIT534, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId,  mBuf, ESIT535, pst);
   CMCHKUNPKLOG(cmUnpkBool,     &cirSelFlg, mBuf, ESIT536, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,   mBuf, ESIT537, pst);
   if (siUnpkSiConEvnt(&siConEvnt, mBuf, pst, EVTGTIAM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }
   CMCHKUNPKLOG(SUnpkU8, &xchgType, mBuf, ESIT538, pst);

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func(pst, spId, suInstId, spInstId, cirSelFlg, circuit, 
                  &siConEvnt, xchgType, mBuf) );
}/* cmUnpkSitConReq */


/*
*
*       Fun:   cmPkSitConInd
*
*       Desc:  Pack connection indication at SIT interface service provider
*              
*       Ret:   ROK - ok; RFAILED - failed
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitConInd 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
SiConEvnt *siConEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitConInd (pst, suId, suInstId, spInstId, circuit, siConEvnt,
                            uBuf)
Pst       *pst;
SuId      suId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
SiConEvnt *siConEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitConInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTIAM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }
 
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT539, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT540, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT541, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT542, pst);

   pst->event = (Event) EVTSITCONIND;       /* event */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitConInd */


/*
*
*       Fun:   cmUnpkSitConInd
*
*       Desc:  Unpack connection indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitConInd 
(
SitConInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitConInd (func, pst, mBuf)
SitConInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;
   SiInstId  suInstId;
   SiInstId  spInstId;
   CirId     circuit;
   SiConEvnt siConEvnt;
   MsgLen    msgLen;

   TRC2(cmUnpkSitConInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT543, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT544, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT545, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT546, pst);

   if (siUnpkSiConEvnt(&siConEvnt, mBuf, pst, EVTGTIAM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, suId, suInstId, spInstId, circuit, &siConEvnt, mBuf) );
}/* cmUnpkSitConInd */


/*
*
*       Fun:   cmPkSitConRsp
*
*       Desc:  Pack SIT Connection Response at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitConRsp 
(
Pst       *pst,
SpId      spId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
SiConEvnt *siConEvnt,
U8        xchgType,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitConRsp (pst, spId, suInstId, spInstId, circuit, siConEvnt, 
                          xchgType, uBuf)
Pst       *pst;
SpId      spId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
SiConEvnt *siConEvnt;
U8        xchgType;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitConRsp)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   CMCHKPKLOG(SPkU8, xchgType, mBuf, ESIT547, pst);
 
   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTANM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT548, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT549, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT550, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT551, pst);
 
   pst->event = (Event) EVTSITCONRSP;      /* event */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitConRsp */


/*
*
*       Fun:   cmUnpkSitConRsp
*
*       Desc:  Unpack SIT Connection Response at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitConRsp 
(
SitConRsp func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitConRsp (func, pst, mBuf)
SitConRsp func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;
   SiInstId  suInstId;
   SiInstId  spInstId;
   CirId     circuit;
   SiConEvnt siConEvnt;
   U8        xchgType;
   MsgLen    msgLen;

   TRC2(cmUnpkSitConRsp)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT552, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT553, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT554, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT555, pst);

   if (siUnpkSiConEvnt(&siConEvnt, mBuf, pst, EVTGTANM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKUNPKLOG(SUnpkU8, &xchgType, mBuf, ESIT556, pst);

   SFndLenMsg(mBuf, &msgLen);

   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
  
   RETVALUE( func(pst, spId, suInstId, spInstId, circuit, &siConEvnt,
                  xchgType, mBuf) ); 
}/* cmUnpkSitConRsp */


/*
*
*       Fun:   cmPkSitConCfm
*
*       Desc:  Pack SIT Connection Confirmation at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitConCfm 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
SiConEvnt *siConEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitConCfm (pst, suId, suInstId, spInstId, circuit,
                          siConEvnt, uBuf)
Pst       *pst;
SuId      suId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
SiConEvnt *siConEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitConCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkConEvnt(siConEvnt, mBuf, pst, EVTGTANM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT557, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT558, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT559, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT560, pst);

   pst->event = EVTSITCONCFM;

   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}/* cmPkSitConCfm */


/*
*
*       Fun:   cmUnpkSitConCfm
*
*       Desc:  Unpack SIT connection confirmation at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitConCfm 
(
SitConCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitConCfm (func, pst, mBuf)
SitConCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;
   SiInstId  suInstId;
   SiInstId  spInstId;
   CirId     circuit;
   SiConEvnt siConEvnt;
   MsgLen    msgLen;

   TRC2(cmUnpkSitConCfm)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT561, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT562, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT563, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT564, pst);

   if (siUnpkSiConEvnt(&siConEvnt, mBuf, pst, EVTGTANM) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func(pst, suId, suInstId, spInstId, circuit, &siConEvnt, mBuf) );
}/* cmUnpkSitConCfm */


/*
*
*       Fun:   cmPkSitCnStReq
*
*       Desc:  Pack connection progress status request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitCnStReq 
(
Pst        *pst,
SpId       spId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiCnStEvnt *siCnStEvnt, 
U8         evntType,
U8         xchgType,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitCnStReq (pst, spId, suInstId, spInstId, circuit,
                           siCnStEvnt, evntType, xchgType, uBuf)
Pst        *pst;
SpId       spId;
SiInstId   suInstId;
SiInstId   spInstId;
CirId      circuit;
SiCnStEvnt *siCnStEvnt;
U8         evntType;
U8         xchgType;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitCnStReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   CMCHKPKLOG(SPkU8, xchgType, mBuf, ESIT565, pst);
   CMCHKPKLOG(SPkU8, evntType, mBuf, ESIT566, pst);

   if (siPkCnStEvnt(siCnStEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT567, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT568, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT569, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT570, pst);

   pst->event = (Event) EVTSITCNSTREQ;      /* event */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitCnstReq */


/*
*
*       Fun:   cmUnpkSitCnStReq
*
*       Desc:  Unpack connection progress status request at SIT i/f service 
*              provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitCnStReq 
(
SitCnStReq func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitCnStReq (func, pst, mBuf)
SitCnStReq func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SpId       spId;
   SiInstId   suInstId;
   SiInstId   spInstId;
   CirId      circuit;
   SiCnStEvnt siCnStEvnt;
   U8         evntType;
   U8         xchgType;
   MsgLen     msgLen;

   TRC2(cmUnpkSitCnStReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT571, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT572, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT573, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT574, pst);

   if (siUnpkSiCnStEvnt(&siCnStEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKUNPKLOG(SUnpkU8, &evntType, mBuf, ESIT575,pst);
   CMCHKUNPKLOG(SUnpkU8, &xchgType, mBuf, ESIT576,pst);

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, spId, suInstId, spInstId, circuit, &siCnStEvnt,
                   evntType, xchgType, mBuf) );
}/* cmUnpkSitCnStReq */


/*
*
*       Fun:   cmUnpkSitCnStInd
*
*       Desc:  Pack connection progress status indication at SIT i/f service
*              provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitCnStInd 
(
Pst        *pst,
SuId       suId,
SiInstId   suInstId,
SiInstId   spInstId,
CirId      circuit,
SiCnStEvnt *siCnStEvnt,
U8         evntType,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitCnStInd (pst, suId, suInstId, spInstId, circuit,
                           siCnStEvnt, evntType, uBuf)
Pst        *pst;
SuId       suId;
SiInstId   suInstId;
SiInstId   spInstId;
CirId      circuit;
SiCnStEvnt *siCnStEvnt;
U8         evntType;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitCnStInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   CMCHKPKLOG(SPkU8, evntType, mBuf, ESIT577, pst);
   if (siPkCnStEvnt(siCnStEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT578, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT579, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT580, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT581, pst);

   pst->event = (Event) EVTSITCNSTIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitCnStInd */


/*
*
*       Fun:   cmUnpkSitCnStInd
*
*       Desc:  Unpack connection progress status indication at SIT i/f service 
*              user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitCnStInd 
(
SitCnStInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitCnStInd (func, pst, mBuf)
SitCnStInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SuId       suId;
   SiInstId   suInstId;
   SiInstId   spInstId;
   CirId      circuit;
   SiCnStEvnt siCnStEvnt;
   U8         evntType;
   MsgLen     msgLen;

   TRC2(cmUnpkSitCnStInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT582, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT583, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT584, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT585, pst);
   if (siUnpkSiCnStEvnt(&siCnStEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }
   CMCHKUNPKLOG(SUnpkU8, &evntType, mBuf, ESIT586, pst);

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, suId, suInstId, spInstId, circuit, &siCnStEvnt,
                   evntType, mBuf) );
}/* cmUnpkSitCnStInd */


/*
*
*       Fun:   cmPkSitDatReq
*
*       Desc:  Pack data request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitDatReq 
(
Pst        *pst, 
SpId       spId,
SiInstId   suInstId, 
SiInstId   spInstId,
CirId      circuit,
SiInfoEvnt *siInfoEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitDatReq (pst, spId, suInstId, spInstId, circuit,
                          siInfoEvnt, uBuf)
Pst        *pst;
SpId       spId;
SiInstId   suInstId;
SiInstId   spInstId;
CirId      circuit;
SiInfoEvnt *siInfoEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;
    
   TRC2(cmPkSitDatReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkInfoEvnt(siInfoEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
       RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT587, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT588, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT589, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT590, pst);

   pst->event = (Event) EVTSITDATREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitDatReq */


/*
*
*       Fun:   cmUnpkSitDatReq
*
*       Desc:  Unpack data request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitDatReq 
(
SitDatReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitDatReq (func, pst, mBuf)
SitDatReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId       spId;
   SiInstId   suInstId;
   SiInstId   spInstId;
   CirId      circuit;
   SiInfoEvnt siInfoEvnt;
   MsgLen     msgLen;

   TRC2(cmUnpkSitDatReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT591, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT592, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT593, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT594, pst);
   if (siUnpkSiInfoEvnt(&siInfoEvnt,    mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE ( func(pst, spId, suInstId, spInstId, circuit, &siInfoEvnt, 
                   mBuf) );
}/* cmUnpkSitDatReq */


/*
*
*       Fun:   cmPkSitDatInd
*
*       Desc:  Pack data indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitDatInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId,
SiInstId   spInstId, 
CirId      circuit,
SiInfoEvnt *siInfoEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitDatInd (pst, suId, suInstId, spInstId, circuit, siInfoEvnt,
                          uBuf)
Pst        *pst;
SuId       suId;
SiInstId   suInstId;
SiInstId   spInstId;
CirId      circuit;
SiInfoEvnt *siInfoEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitDatInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkInfoEvnt(siInfoEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT595, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT596, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT597, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT598, pst);

   pst->event = (Event) EVTSITDATIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitDatInd */


/*
*
*       Fun:   cmUnpkSitDatInd
*
*       Desc:  Unpack data indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitDatInd 
(
SitDatInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitDatInd (func, pst, mBuf)
SitDatInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId       suId;            /* service user id */
   SiInstId   suInstId;        /* service user instance id */
   SiInstId   spInstId;        /* service provider instance id */
   CirId      circuit;         /* circuit ID code */
   SiInfoEvnt siInfoEvnt;      /* information event */
   MsgLen     msgLen;          /* message length */

   TRC2(cmUnpkSitDatInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT599, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT600, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT601, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT602, pst);

   if (siUnpkSiInfoEvnt(&siInfoEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, suId, suInstId, spInstId, circuit, &siInfoEvnt, 
                   mBuf) );
}/* cmUnpkSitDatInd */


/*
*
*       Fun:   cmPkSitFacReq
*
*       Desc:  Pack facility request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFacReq 
(
Pst       *pst,
SpId      spId,
SiInstId  suInstId,
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFacReq (pst, spId, suInstId, spInstId, circuit,
                          evntType, siFacEvnt, uBuf)
Pst       *pst;
SpId      spId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
U8        evntType;
SiFacEvnt *siFacEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitFacReq)
    
   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTFRQ) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
       RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT603, pst);
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT604, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT605, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT606, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT607, pst);

   pst->event = (Event) EVTSITFACREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitFacReq */


/*
*
*       Fun:   cmUnpkSitFacReq 
*
*       Desc:  Unpack facility request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFacReq 
(
SitFacReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFacReq (func, pst, mBuf)
SitFacReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiFacEvnt siFacEvnt;        /* facility event */
   U8        evntType;         /* event type */
   MsgLen    msgLen;           /* length of message */

   TRC2(cmUnpkSitFacReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT608,  pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT609,  pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT610,  pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT611,  pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType, mBuf, ESIT612, pst);

   if (siUnpkSiFacEvnt(&siFacEvnt, mBuf, pst, EVTGTFRQ) != ROK) 
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, spId, suInstId, spInstId, circuit, evntType, 
                   &siFacEvnt, mBuf) ); 
} /* cmUnpkSitFacReq */


/*
*
*       Fun:   cmPkSitFacInd
*
*       Desc:  Pack facilitity indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFacInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFacInd (pst, suId, suInstId, spInstId, circuit, evntType, 
                          siFacEvnt, uBuf)
Pst       *pst; 
SuId      suId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
U8        evntType;
SiFacEvnt *siFacEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitFacInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTFRQ) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(ROK);
   }

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT613, pst); 
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT614, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT615, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT616, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT617, pst); 

   pst->event = (Event) EVTSITFACIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitFacInd */


/*
*
*       Fun:   cmUnpkSitFacInd
*
*       Desc:  Unpack facility indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFacInd 
(
SitFacInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFacInd (func, pst, mBuf)
SitFacInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId; 
   SiInstId  suInstId; 
   SiInstId  spInstId; 
   CirId     circuit;
   U8        evntType;
   SiFacEvnt siFacEvnt;
   MsgLen    msgLen;

   TRC2(cmUnpkSitFacInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT618, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT619, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT620, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT621, pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType, mBuf, ESIT622, pst);

   if (siUnpkSiFacEvnt(&siFacEvnt, mBuf, pst, EVTGTFRQ) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func(pst, suId, suInstId, spInstId, circuit, evntType, 
                   &siFacEvnt, mBuf) );  
}/* cmUnpkSitFacInd */


/*
*
*       Fun:   cmPkSitFacRsp
*
*       Desc:  Pack facility response at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFacRsp 
(
Pst       *pst, 
SpId      spId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFacRsp (pst, spId, suInstId, spInstId, circuit, 
                          evntType, siFacEvnt, uBuf)
Pst       *pst; 
SpId      spId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
U8        evntType;
SiFacEvnt *siFacEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitFacRsp)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTMLTP) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT623, pst);
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT624, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT625, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT626, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT627, pst);

   pst->event = (Event) EVTSITFACRSP;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitFacRsp */


/*
*
*       Fun:   cmUnpkSitFacRsp
*
*       Desc:  Unpack facility response at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFacRsp 
(
SitFacRsp func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFacRsp (func, pst, mBuf)
SitFacRsp func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId; 
   SiInstId  suInstId; 
   SiInstId  spInstId; 
   CirId     circuit;
   U8        evntType;
   SiFacEvnt siFacEvnt;
   MsgLen    msgLen;

   TRC2(cmUnpkSitFacRsp)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT628, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT629, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT630, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT631, pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType, mBuf, ESIT632, pst);

   if (siUnpkSiFacEvnt(&siFacEvnt, mBuf, pst, EVTGTMLTP) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func(pst, spId, suInstId, spInstId, circuit, evntType, &siFacEvnt,
                  mBuf) );
}/* cmUnpkSitFacRsp */


/*
*
*       Fun:   cmPkSitFacCfm
*
*       Desc:  Pack facility confirmation at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFacCfm 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
U8        evntType,
SiFacEvnt *siFacEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFacCfm (pst, suId, suInstId, spInstId, circuit, 
                          evntType, siFacEvnt, uBuf)
Pst       *pst;
SuId      suId;
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
U8        evntType;
SiFacEvnt *siFacEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitFacCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkFacEvnt(siFacEvnt, mBuf, pst, EVTGTMLTP) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT633, pst); 
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT634, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT635, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT636, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT637, pst); 

   pst->event = (Event) EVTSITFACCFM;       /* event */
   (Void) SPstTsk(pst, mBuf); 

   RETVALUE(ROK);
}/* cmPkSitFacCfm */


/*
*
*       Fun:   cmUnpkSitFacCfm
*
*       Desc:  Unpack facility confirm at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFacCfm 
(
SitFacCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFacCfm (func, pst, mBuf)
SitFacCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;
   SiInstId  suInstId; 
   SiInstId  spInstId; 
   CirId     circuit;
   U8        evntType;
   SiFacEvnt siFacEvnt;
   MsgLen    msgLen;

   TRC2(cmUnpkSitFacCfm)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT638, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT639, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT640, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT641, pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType, mBuf, ESIT642, pst);

   if (siUnpkSiFacEvnt(&siFacEvnt, mBuf, pst, EVTGTMLTP) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }
   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE( func(pst, suId, suInstId, spInstId, circuit, evntType, &siFacEvnt,
                  mBuf) );
}/* cmUnpkSitFacCfm */


/*
*
*       Fun:   cmPkSitSuspReq
*
*       Desc:  Pack suspend request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitSuspReq 
(
Pst        *pst, 
SpId       spId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiSuspEvnt *siSuspEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitSuspReq (pst, spId, suInstId, spInstId, circuit, 
                           siSuspEvnt, uBuf)
Pst        *pst; 
SpId       spId; 
SiInstId   suInstId; 
SiInstId   spInstId; 
CirId      circuit;
SiSuspEvnt *siSuspEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitSuspReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkSuspEvnt(siSuspEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT643, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT644, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT645, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT646, pst);

   pst->event = (Event) EVTSITSUSPREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitSuspReq */


/*
*
*       Fun:   cmUnpkSitSuspReq
*
*       Desc:  Unpack suspend request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitSuspReq 
(
SitSuspReq func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitSuspReq (func, pst, mBuf)
SitSuspReq func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SpId       spId; 
   SiInstId   suInstId; 
   SiInstId   spInstId; 
   CirId      circuit;
   SiSuspEvnt siSuspEvnt;
   MsgLen     msgLen;

   TRC2(cmUnpkSitSuspReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT647, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT648, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT649, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT650, pst);

   if (siUnpkSiSuspEvnt(&siSuspEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE (func (pst, spId, suInstId, spInstId, circuit, &siSuspEvnt, 
                   mBuf) );
}/* cmUnpkSitSuspReq */


/*
*
*       Fun:   cmPkSitSuspInd
*
*       Desc:  Pack suspend indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitSuspInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiSuspEvnt *siSuspEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitSuspInd (pst, suId, suInstId, spInstId, circuit,siSuspEvnt,
                           uBuf)
Pst        *pst; 
SuId       suId; 
SiInstId   suInstId; 
SiInstId   spInstId; 
CirId      circuit;
SiSuspEvnt *siSuspEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitSuspInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkSuspEvnt(siSuspEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT651, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT652, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT653, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT654, pst); 

   pst->event = (Event) EVTSITSUSPIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitSuspInd */


/*
*
*       Fun:   cmUnpkSitSuspInd
*
*       Desc:  Unpack suspend indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitSuspInd 
(
SitSuspInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitSuspInd (func, pst, mBuf)
SitSuspInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SuId       suId; 
   SiInstId   suInstId; 
   SiInstId   spInstId; 
   CirId      circuit;
   SiSuspEvnt siSuspEvnt;
   MsgLen     msgLen;

   TRC2(cmUnpkSitSuspInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT655, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT656, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT657, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT658, pst);

   if (siUnpkSiSuspEvnt(&siSuspEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func(pst, suId, suInstId, spInstId, circuit, &siSuspEvnt, mBuf) );
}/* cmUnpkSitSuspInd */


/*
*
*       Fun:   cmPkSitResmReq
*
*       Desc:  Pack resume request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitResmReq 
(
Pst        *pst, 
SpId       spId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiResmEvnt *siResmEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitResmReq (pst, spId, suInstId, spInstId, circuit, 
                           siResmEvnt, uBuf)
Pst        *pst; 
SpId       spId; 
SiInstId   suInstId; 
SiInstId   spInstId; 
CirId      circuit;
SiResmEvnt *siResmEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitResmReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkResmEvnt(siResmEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
       RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT659, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT660, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT661, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT662, pst);

   pst->event = (Event) EVTSITRESMREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitResmReq */


/*
*
*       Fun:   cmUnpkSitResmReq
*
*       Desc:  Unpack resume request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitResmReq 
(
SitResmReq func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitResmReq (func, pst, mBuf)
SitResmReq func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SpId       spId; 
   SiInstId   suInstId; 
   SiInstId   spInstId; 
   CirId      circuit;
   SiResmEvnt siResmEvnt;
   MsgLen     msgLen;

   TRC2(cmUnpkSitResmReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT663, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT664, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT665, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT666, pst);

   if (siUnpkSiResmEvnt(&siResmEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE( func(pst, spId, suInstId, spInstId, circuit, &siResmEvnt, mBuf) );
}/* cmUnpkSitResmReq */


/*
*
*       Fun:   cmPkSitResmInd
*
*       Desc:  Pack resume indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitResmInd 
(
Pst        *pst, 
SuId       suId, 
SiInstId   suInstId, 
SiInstId   spInstId, 
CirId      circuit,
SiResmEvnt *siResmEvnt,
Buffer     *uBuf
)
#else
PUBLIC S16 cmPkSitResmInd (pst, suId, suInstId, spInstId, circuit,siResmEvnt,
                           uBuf)
Pst        *pst; 
SuId       suId; 
SiInstId   suInstId; 
SiInstId   spInstId; 
CirId      circuit;
SiResmEvnt *siResmEvnt;
Buffer     *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitResmInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkResmEvnt(siResmEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT667, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT668, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT669, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT670, pst); 

   pst->event = (Event) EVTSITRESMIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitResmInd */


/*
*
*       Fun:   cmUnpkSitResmInd
*
*       Desc:  Pack resume indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitResmInd 
(
SitResmInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitResmInd (func, pst, mBuf)
SitResmInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SuId       suId; 
   SiInstId   suInstId; 
   SiInstId   spInstId; 
   CirId      circuit;
   SiResmEvnt siResmEvnt;
   MsgLen     msgLen;

   TRC2(cmUnpkSitResmInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT671, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT672, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT673, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT674, pst);

   if (siUnpkSiResmEvnt(&siResmEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE( func (pst, suId, suInstId, spInstId, circuit, &siResmEvnt, 
                   mBuf) );
}/* cmUnpkSitResmInd */


/*
*
*       Fun:   cmPkSitStaReq
*
*       Desc:  Pack status request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitStaReq 
(
Pst       *pst, 
SpId      spId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
Bool      globalFlag, 
CirId     circuit, 
U8        eventType, 
SiStaEvnt *siStaEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitStaReq (pst, spId, suInstId, spInstId, globalFlag, 
                          circuit, eventType, siStaEvnt,uBuf)
Pst       *pst; 
SpId      spId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
Bool      globalFlag; 
CirId     circuit; 
U8        eventType; 
SiStaEvnt *siStaEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;
   Bool   evtprcs;

   TRC2(cmPkSitStaReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;   

   evtprcs = FALSE;
   if (siStaEvnt != NULLP)
   {
      evtprcs = TRUE;
      if (siPkStaEvnt(siStaEvnt, mBuf, pst) != ROK)
      {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
         RETVALUE(RFAILED);
      }
   }

   CMCHKPKLOG(cmPkBool,     evtprcs,    mBuf, ESIT675, pst);
   CMCHKPKLOG(SPkU8,        eventType,  mBuf, ESIT676, pst);
   CMCHKPKLOG(cmPkBool,     globalFlag, mBuf, ESIT677, pst);
   CMCHKPKLOG(cmPkCirId,    circuit,    mBuf, ESIT678, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId,   mBuf, ESIT679, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId,   mBuf, ESIT680, pst);
   CMCHKPKLOG(cmPkSpId,     spId,       mBuf, ESIT681, pst);
 
   pst->event = (Event) EVTSITSTAREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitStaReq */


/*
*
*       Fun:   cmUnpkSitStaReq
*
*       Desc:  Unpack status request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitStaReq 
(
SitStaReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitStaReq (func, pst, mBuf)
SitStaReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId; 
   SiInstId  suInstId; 
   SiInstId  spInstId; 
   Bool      globalFlag; 
   CirId     circuit; 
   U8        eventType; 
   SiStaEvnt siStaEvnt;
   Bool      evtprcs;
   MsgLen    msgLen;

   TRC2(cmUnpkSitStaReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,       mBuf, ESIT682, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId,   mBuf, ESIT683, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId,   mBuf, ESIT684, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,    mBuf, ESIT685, pst);
   CMCHKUNPKLOG(cmUnpkBool,     &globalFlag, mBuf, ESIT686, pst);
   CMCHKUNPKLOG(SUnpkU8,        &eventType,  mBuf, ESIT687, pst);
   CMCHKUNPKLOG(cmUnpkBool,     &evtprcs,    mBuf, ESIT688, pst);

   if (evtprcs)
   {
      if (siUnpkSiStaEvnt(&siStaEvnt, mBuf, pst) != ROK)
      {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
         RETVALUE(RFAILED);
      }
   }
      
   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func (pst, spId, suInstId, spInstId, globalFlag, circuit,
                   eventType, ((evtprcs) ? &siStaEvnt : NULLP), mBuf) );
}/* cmUnpkSitStaReq */


/*
*
*       Fun:   cmPkSitStaInd
*
*       Desc:  Pack status indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitStaInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit, 
Bool      globalFlag, 
U8        eventType, 
SiStaEvnt *siStaEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitStaInd (pst, suId, suInstId, spInstId, circuit, 
                          globalFlag, eventType, siStaEvnt, uBuf)
Pst       *pst; 
SuId      suId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit; 
Bool      globalFlag; 
U8        eventType; 
SiStaEvnt *siStaEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;
   Bool   evtprcs;

   TRC2(cmPkSitStaInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   evtprcs = FALSE;
   if (siStaEvnt != NULLP)
   {
      evtprcs = TRUE;
      if (siPkStaEvnt(siStaEvnt, mBuf, pst) != ROK)
      {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
         RETVALUE(RFAILED);
      }
   }

   CMCHKPKLOG(cmPkBool,     evtprcs,    mBuf, ESIT689, pst);
   CMCHKPKLOG(SPkU8,        eventType,  mBuf, ESIT690, pst); 
   CMCHKPKLOG(cmPkBool,     globalFlag, mBuf, ESIT691, pst); 
   CMCHKPKLOG(cmPkCirId,    circuit,    mBuf, ESIT692, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId,   mBuf, ESIT693, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId,   mBuf, ESIT694, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,       mBuf, ESIT695, pst); 

   pst->event = (Event) EVTSITSTAIND;       /* event */
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitStaInd */


/*
*
*       Fun:   cmUnpkSitStaInd
*
*       Desc:  Unpack status indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitStaInd 
(
SitStaInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitStaInd (func, pst, mBuf)
SitStaInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   Bool      globalFlg;        /* global flag */
   U8        evntType;         /* event type */
   Bool      evtprcs;          /* event present flag */
   SiStaEvnt siStaEvnt;        /* status event */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitStaInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,      mBuf, ESIT696, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId,  mBuf, ESIT697, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId,  mBuf, ESIT698, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,   mBuf, ESIT699, pst);
   CMCHKUNPKLOG(cmUnpkBool,     &globalFlg, mBuf, ESIT700, pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType,  mBuf, ESIT701, pst);
   CMCHKUNPKLOG(cmUnpkBool,     &evtprcs,   mBuf, ESIT702, pst);

   if (evtprcs)
   {
      if (siUnpkSiStaEvnt(&siStaEvnt, mBuf, pst) != ROK)
      {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
         RETVALUE(RFAILED);
      }
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE( func (pst, suId, suInstId, spInstId, circuit, globalFlg,
                   evntType, ((evtprcs) ? &siStaEvnt : NULLP), mBuf) );
}/* cmUnpkSitStaInd */


/*
*
*       Fun:   cmPkSitRelReq
*
*       Desc:  Pack release request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitRelReq 
(
Pst       *pst, 
SpId      spId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitRelReq (pst, spId, suInstId, spInstId, circuit, 
                          siRelEvnt, uBuf)
Pst       *pst; 
SpId      spId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
SiRelEvnt *siRelEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitRelReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
       RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT703, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT704, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT705, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT706, pst);

   pst->event = (Event) EVTSITRELREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitRelReq */


/*
*
*       Fun:   cmUnpkSitRelReq
*
*       Desc:  Unpack release request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitRelReq 
(
SitRelReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitRelReq (func, pst, mBuf)
SitRelReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiRelEvnt siRelEvnt;        /* release event */
   MsgLen    msgLen;           /* length of message */

   TRC2(cmUnpkSitRelReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT707, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT708, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT709, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT710, pst);
   if (siUnpkSiRelEvnt(&siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
/* sit_c_007.main_15 - Deletion. Delete printf statement */
   RETVALUE ( func (pst, spId, suInstId, spInstId, circuit, &siRelEvnt, 
                    mBuf) );
/* sit_c_007.main_15 - Deletion. Delete printf statement */
}/* cmUnpkSitRelReq */


/*
*
*       Fun:   cmPkSitRelInd
*
*       Desc:  Pack release indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitRelInd 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitRelInd (pst, suId, suInstId, spInstId, circuit, siRelEvnt,
                          uBuf)
Pst       *pst; 
SuId      suId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
SiRelEvnt *siRelEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitRelInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT711, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT712, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT713, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT714, pst); 

   pst->event = (Event) EVTSITRELIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitRelInd */


/*
*
*       Fun:   cmUnpkSitRelInd
*
*       Desc:  Pack release indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitRelInd 
(
SitRelInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitRelInd (func, pst, mBuf)
SitRelInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiRelEvnt siRelEvnt;        /* release event */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitRelInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT715, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT716, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT717, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT718, pst);

   if (siUnpkSiRelEvnt(&siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func (pst, suId, suInstId, spInstId, circuit, &siRelEvnt, 
                    mBuf) );
}/* cmUnpkSitRelInd */


/*
*
*       Fun:   cmPkSitRelRsp
*
*       Desc:  Pack release response at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitRelRsp 
(
Pst       *pst, 
SpId      spId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitRelRsp (pst, spId, suInstId, spInstId, circuit, 
                          siRelEvnt, uBuf)
Pst       *pst; 
SpId      spId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
SiRelEvnt *siRelEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitRelRsp)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
       RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT719, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT720, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT721, pst);
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT722, pst);

   pst->event = (Event) EVTSITRELRSP;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitRelRsp */


/*
*
*       Fun:   cmUnpkSitRelRsp
*
*       Desc:  Unpack release response at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitRelRsp 
(
SitRelRsp func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitRelRsp (func, pst, mBuf)
SitRelRsp func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiRelEvnt siRelEvnt;        /* release event */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitRelRsp)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT723, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT724, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT725, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT726, pst);

   if (siUnpkSiRelEvnt(&siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }
   RETVALUE ( func (pst, spId, suInstId, spInstId, circuit, &siRelEvnt, 
                    mBuf) );
}/* cmUnpkSitRelRsp */


/*
*
*       Fun:   cmPkSitRelCfm
*
*       Desc:  Pack release confirm at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitRelCfm 
(
Pst       *pst, 
SuId      suId, 
SiInstId  suInstId, 
SiInstId  spInstId, 
CirId     circuit,
SiRelEvnt *siRelEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitRelCfm (pst, suId, suInstId, spInstId, circuit, siRelEvnt,
                          uBuf)
Pst       *pst; 
SuId      suId; 
SiInstId  suInstId; 
SiInstId  spInstId; 
CirId     circuit;
SiRelEvnt *siRelEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitRelCfm)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   if (siPkRelEvnt(siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT727, pst); 
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT728, pst); 
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT729, pst); 
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT730, pst); 

   pst->event = (Event) EVTSITRELCFM;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitRelCfm */


/*
*
*       Fun:   cmUnpkSitRelCfm
*
*       Desc:  Pack release confirm at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitRelCfm 
(
SitRelCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitRelCfm (func, pst, mBuf)
SitRelCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiRelEvnt siRelEvnt;        /* release event */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitRelCfm)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT731, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT732, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT733, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT734, pst);

   if (siUnpkSiRelEvnt(&siRelEvnt, mBuf, pst) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func (pst, suId, suInstId, spInstId, circuit, &siRelEvnt, 
                    mBuf) );
}/* cmUnpkSitRelCfm */


/*
*
*       Fun:   cmPkSitUMsgReq 
*
*       Desc:  Pack unrecognised message request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitUMsgReq 
(
Pst      *pst,
SpId     spId,
SiInstId suInstId,
SiInstId spInstId,
CirId    circuit,
Buffer   *uBuf
)
#else
PUBLIC S16 cmPkSitUMsgReq (pst, spId, suInstId, spInstId, circuit, uBuf)
Pst      *pst;
SpId     spId;
SiInstId suInstId;
SiInstId spInstId;
CirId    circuit;
Buffer   *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitUMsgReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT735, pst)
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT736, pst)
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT737, pst)
   CMCHKPKLOG(cmPkSpId,     spId,     mBuf, ESIT738, pst)

   pst->event = (Event) EVTSITUMSGREQ;      /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitUMsgReq */


/*
*
*       Fun:   cmUnpkSitUMsgReq
*
*       Desc:  Unpack unrecognised message request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitUMsgReq 
(
SitUMsgReq func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitUMsgReq (func, pst, mBuf)
SitUMsgReq func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SpId spId;                  /* service user id */
   SiInstId suInstId;          /* service user instance id */
   SiInstId spInstId;          /* service provider instance id */
   CirId circuit;              /* circuit  */
   S16 msglen;                 /* message length */

   TRC2(cmUnpkSitUMsgReq)

   CMCHKUNPKLOG(cmUnpkSpId,     &spId,     mBuf, ESIT739, pst)
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT740, pst)
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT741, pst)
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT742, pst)

   SFndLenMsg(mBuf, &msglen);
   if(msglen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE ( func (pst, spId, suInstId, spInstId, circuit, mBuf) );
}/* cmUnpkSitUMsgReq */


/*
*
*       Fun:   cmPkSitUMsgInd
*
*       Desc:  Pack unrecognised message indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitUMsgInd 
(
Pst     *pst,               /* post structure */
SuId     suId,              /* service provider id */
SiInstId suInstId,          /* service user instance id */
SiInstId spInstId,          /* service provider instance id */
CirId    circuit,           /* circuit ID code */
Buffer   *uBuf              /* message with unrecognizable parameters */
)
#else
PUBLIC S16 cmPkSitUMsgInd (pst, suId, suInstId, spInstId, circuit, uBuf)
Pst      *pst;
SuId     suId;
SiInstId suInstId;
SiInstId spInstId;
CirId    circuit;
Buffer   *uBuf;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitUMsgInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT743, pst)
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT744, pst)
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT745, pst)
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT746, pst)

   pst->event = (Event) EVTSITUMSGIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitUMsgInd */


/*
*
*       Fun:   cmUnpkSitUMsgInd
*
*       Desc:  Unpack unrecognised message indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitUMsgInd 
(
SitUMsgInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkSitUMsgInd (func, pst, mBuf)
SitUMsgInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{  
   SuId     suId;
   SiInstId suInstId;
   SiInstId spInstId;
   CirId    circuit;
   MsgLen   msgLen;                /* message length */

   TRC2(cmUnpkSitUMsgInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT747, pst)
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT748, pst)
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT749, pst)
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT750, pst)

   SFndLenMsg(mBuf, &msgLen);
   if(msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func (pst, suId, suInstId, spInstId, circuit, mBuf) );
}/* cmUnpkSitUMsgInd */


/*
*
*       Fun:   cmPkSitPtCdeStaReq
*
*       Desc:  Pack point code status request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitPtCdeStaReq 
(
Pst  *pst,
SpId spId,
SiInstId intfId
)
#else
PUBLIC S16 cmPkSitPtCdeStaReq (pst, spId, intfId)
Pst  *pst;
SpId spId;
SiInstId intfId;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitPtCdeStaReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkDpc,  intfId,  mBuf, ESIT751, pst)
   CMCHKPKLOG(cmPkSpId, spId, mBuf, ESIT752, pst)

   pst->event = EVTSITPTCDESTAREQ;
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitPtCdeStaReq */


/*
*
*       Fun:   cmUnpkSitPtCdeStaReq
*
*       Desc:  Unpack point code status request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitPtCdeStaReq 
(
SitPtCdeStaReq func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSitPtCdeStaReq (func, pst, mBuf)
SitPtCdeStaReq func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId spId;
   SiInstId intfId;

   TRC2(cmUnpkSitPtCdeStaReq) 

   CMCHKUNPKLOG(cmUnpkSpId, &spId,    mBuf, ESIT753, pst)
   CMCHKUNPKLOG(cmUnpkDpc,  &intfId,  mBuf, ESIT754, pst)

   SPutMsg(mBuf);
   RETVALUE( func (pst, spId, intfId) );
}/* cmUnpkSitPtCdeStaReq */


/*
*
*       Fun:   cmPkSitPtCdeStaCfm
*
*       Desc:  Pack point code status confirmation at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitPtCdeStaCfm 
(
Pst  *pst,
SuId suId,
SiInstId intfId,
U8   status,
U8   congLevel
)
#else
PUBLIC S16 cmPkSitPtCdeStaCfm (pst, suId, intfId, status, congLevel)
Pst  *pst;
SuId suId;
SiInstId intfId;
U8   status;
U8   congLevel;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSitPtCdeStaCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(SPkU8,    congLevel, mBuf, ESIT755, pst)
   CMCHKPKLOG(SPkU8,    status,    mBuf, ESIT756, pst)
   CMCHKPKLOG(cmPkDpc,  intfId,    mBuf, ESIT757, pst)
   CMCHKPKLOG(cmPkSuId, suId,      mBuf, ESIT758, pst)

   pst->event = EVTSITPTCDESTACFM;
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitPtCdeStaCfm */


/*
*
*       Fun:   cmUnpkSitPtCdeStaCfm
*
*       Desc:  Pack point code status confirmation at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitPtCdeStaCfm 
(
SitPtCdeStaCfm func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSitPtCdeStaCfm (func, pst, mBuf)
SitPtCdeStaCfm func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId suId;
   SiInstId intfId;
   U8   status;
   U8   congLevel;

   TRC2(cmUnpkSitPtCdeStaCfm)

   CMCHKUNPKLOG(cmUnpkSuId, &suId,      mBuf, ESIT759, pst)
   CMCHKUNPKLOG(cmUnpkDpc,  &intfId,    mBuf, ESIT760, pst)
   CMCHKUNPKLOG(SUnpkU8,    &status,    mBuf, ESIT761, pst)
   CMCHKUNPKLOG(SUnpkU8,    &congLevel, mBuf, ESIT762, pst)

   RETVALUE( func (pst, suId, intfId, status, congLevel) );
}/* cmUnpkSitPtCdeStaCfm */

#ifdef SS7_FTZ

/*
*
*       Fun:   cmPkSitFtzReq
*
*       Desc:  Pack FTZ utilities request at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFtzReq 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
U8        evntType,
SiFtzEvnt *siFtzEvnt,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFtzReq (pst, suId, suInstId, spInstId, circuit,
                          evntType,siFtzEvnt, uBuf)
Pst       *pst;
SuId      suId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
U8        evntType;
SiFtzEvnt *siFtzEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;
   U8     unionSel;

   TRC2(cmPkSitFtzReq)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   switch(evntType)
   {
      case GT_NANA:
         unionSel = EVTGTNANA;
         break;

      case GT_FACINF:
         unionSel = EVTGTMLTP;
         break;

      default:
         unionSel = 0;
         break;
   }

   if (siPkSiFtzEvnt(siFtzEvnt, mBuf, pst, unionSel) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT763, pst);
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT764, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT765, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT766, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT767, pst);

   pst->event = (Event) EVTSITFTZREQ;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkSitFtzReq */


/*
*
*       Fun:   cmUnpkSitFtzReq
*
*       Desc:  Unpack FTZ utilities request at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFtzReq 
(
SitFtzReq func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFtzReq (func, pst, mBuf)
SitFtzReq func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SpId      spId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   SiFtzEvnt siFtzEvnt;        /* Ftz utilities event */
   U8        evntType;         /* event type */
   U8        unionSel;         /* union selector */
   MsgLen    msgLen;           /* message length */

   TRC2(cmUnpkSitFtzReq)

   CMCHKUNPKLOG(SUnpkS16, &spId,     mBuf, ESIT768, pst);
   CMCHKUNPKLOG(SUnpkU32, &suInstId, mBuf, ESIT769, pst);
   CMCHKUNPKLOG(SUnpkU32, &spInstId, mBuf, ESIT770, pst);
   CMCHKUNPKLOG(SUnpkU32, &circuit,  mBuf, ESIT771, pst);
   CMCHKUNPKLOG(SUnpkU8,  &evntType, mBuf, ESIT772, pst);

   switch(evntType)
   {
      case GT_NANA:
         unionSel = EVTGTNANA;
         break;
      case GT_FACINF:
         unionSel = EVTGTMLTP;
         break;
      default: 
         unionSel = 0;
         break;
   }

   if (siUnpkSiFtzEvnt(&siFtzEvnt, mBuf, pst, unionSel) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func (pst, spId, suInstId, spInstId, circuit, evntType, 
                   &siFtzEvnt, mBuf) );
}/* cmUnpkSitFtzReq */


/*
*
*       Fun:   cmPkSitFtzInd
*
*       Desc:  Pack FTZ utilities indication at SIT i/f service provider
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSitFtzInd 
(
Pst       *pst,
SuId      suId,
SiInstId  suInstId,
SiInstId  spInstId,
CirId     circuit,
U8        evntType,
SiFtzEvnt *siFtzEvnt ,
Buffer    *uBuf
)
#else
PUBLIC S16 cmPkSitFtzInd (pst, suId, suInstId, spInstId, circuit, evntType,
                          siFtzEvnt, uBuf)
Pst       *pst;
SuId      suId;
SiInstId  suInstId;
SiInstId  spInstId;
CirId     circuit;
U8        evntType;
SiFtzEvnt *siFtzEvnt;
Buffer    *uBuf;
#endif
{
   Buffer *mBuf;
   U8     unionSel;                /* union selector */

   TRC2(cmPkSitFtzInd)

   if (uBuf == NULLP)
   {
      if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
         RETVALUE(RFAILED);
   }
   else
      mBuf = uBuf;

   switch(evntType)
   {
      case GT_NANA:
         unionSel = EVTGTNANA;
         break;
      case GT_FACINF:
         unionSel = EVTGTMLTP;
         break;
      default:
         unionSel = 0;
         break;
   }
   if (siPkSiFtzEvnt(siFtzEvnt, mBuf, pst, unionSel) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   } 

   CMCHKPKLOG(SPkU8,        evntType, mBuf, ESIT773, pst);
   CMCHKPKLOG(cmPkCirId,    circuit,  mBuf, ESIT774, pst);
   CMCHKPKLOG(cmPkSiInstId, spInstId, mBuf, ESIT775, pst);
   CMCHKPKLOG(cmPkSiInstId, suInstId, mBuf, ESIT776, pst);
   CMCHKPKLOG(cmPkSuId,     suId,     mBuf, ESIT777, pst);

   pst->event = (Event) EVTSITFTZIND;       /* event */
   (Void) SPstTsk(pst, mBuf);

   RETVALUE(RFAILED);
}/* cmPkSitFtzInd */


/*
*
*       Fun:   cmUnpkSitFtzInd
*
*       Desc:  Unpack FTZ utilities indication at SIT i/f service user
*              
*       Ret:   ROK - ok; RFAILD - failed;
*
*       Notes: None
*
*       File:  sit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSitFtzInd 
(
SitFtzInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkSitFtzInd (func, pst, mBuf)
SitFtzInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SuId      suId;             /* service user id */
   SiInstId  suInstId;         /* service user instance id */
   SiInstId  spInstId;         /* service provider instance id */
   CirId     circuit;          /* circuit ID code */
   U8        evntType;         /* event type */
   SiFtzEvnt siFtzEvnt;        /* Ftz utilities event */
   U8        unionSel;         /* union selector */
   MsgLen    msgLen;           /* message length */
 
   TRC2(cmUnpkSitFtzInd)

   CMCHKUNPKLOG(cmUnpkSuId,     &suId,     mBuf, ESIT778, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &suInstId, mBuf, ESIT779, pst);
   CMCHKUNPKLOG(cmUnpkSiInstId, &spInstId, mBuf, ESIT780, pst);
   CMCHKUNPKLOG(cmUnpkCirId,    &circuit,  mBuf, ESIT781, pst);
   CMCHKUNPKLOG(SUnpkU8,        &evntType, mBuf, ESIT782, pst);

   switch(evntType)
   {
      case GT_NANA:
         unionSel = EVTGTNANA;
         break;

      case GT_FACINF:
         unionSel = EVTGTMLTP;
         break;

      default:
         unionSel = 0;
         break;
   }
   if (siUnpkSiFtzEvnt(&siFtzEvnt, mBuf, pst, unionSel) != ROK)
   {
/* sit_c_002.main_15 - Deletion. Delete SPutMsg to avoid double calling it.
 */
      RETVALUE(RFAILED);
   }

   SFndLenMsg(mBuf, &msgLen);
   if (msgLen == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   RETVALUE( func (pst, suId, suInstId, spInstId, circuit, evntType,&siFtzEvnt,
                   mBuf) );
}/* cmUnpkSitFtzInd */

#endif /* SS7_FTZ */

#endif /* LCSIT */

  
/********************************************************************30**
  
         End of file:     sit.c@@/main/15 - Wed Jul 25 13:21:21 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      dm   1. initial release

1.2          ---      ao   1. fixed packing order in siPkCllChrgeInfo
 
1.3          ---      rs   1. Included cm_hash.h/cm_hash.x 

1.4          ---      ao   1. Added support for local number portability
             ---      ao   2. Added echo control info to the ConEvnt. Changed 
                              definition of redirection number.

1.5          ---      rh   1. added primitive packing/unpacking functions
1.6          ---      ao   2. Added Russian variant
             ---      ym   1. Corrected the packing/unpacking function 
                               for structure of parameter compatibility .
                               These changes are under SIT_PARAMETER flag.
                           2. Packing/unpacking functions are added for
                              outgoing trunk group number in CnStEvnt.
                              These changes are under SIT_PARAMETER flag.
1.6+         ---      ym   1. Packing and unpacking of siconevnt and sicnstevnt
                              is modified for addition of connNum2 field.
                              These changes are under SIT_PARAMETER flag.

1.7          ---      bn   1. Added bellcore variant

1.8          ---      bn   1. Added new bellcore elements.

1.9          ---      ym   1. Added NTT variant.
1.10         ---      ym   1. A field for bit H in user to user idctr is
                              added under SIT_PARAMETER flag.
             ---      ym   1. Functions made public for feature
                              transparency in ICC.
1.11         ---      ym   1. Changes for ISUP v2.18
/main/13     ---      sk   1. Packing and unpacking function added for
                              notification indicator in ConEvnt
             ---      bsp  1. Added packing/unpacking functions for
                              parameters added by ANS95, ITU97 and 
                              ETSIv3 specifications.
                           2. Changed packing/unpacking of parameter 
                              compatibility information to pack/unpack 
                              additional instruction indicators.
                           3. Changed comparision element header present
                              field from TRUE.
                           4. Enabled APM and PRI packing/unpacking for ITU97
                           5. Fixed compilation errors
                      hy   1. add a packing and unpacking of screening 
                              indicator in redircting number processing.
                           2. Add a unpacking for connection request in 
                              siUnpkSiFacEvnt function.
                           3. Fixed a bug in the siPkChrgeRateInfo function
                              definition for non-ANSI
/main/14     ---      hy   1. Added packing/unpacking functions
                              for calling party no for Bell
                           2. Added packing/unpacking of redirction number
                              in release event for Bellcore. 
/main/15     ---      hy   1. Added screen indicator in packing/unpacking
                              of calling party number used by BELL.
   sit_c_001.main_15  hy   1. Changes for bit vector implementation to support
                              the rolling upgrade across the same 
                              specification family. It supports from: 
                              ANS88 to ANS92 or vice versa
                              ANS92 to ANS95 or vice versa
                              ANS88 to ANS95 or vice versa
                              ITU to ITU97 or vice versa
                              ETSI to ETSIV3 or vice versa
                           2. OR'ing TDS_ROLL_UPGRADE_SUPPORT with flag
                              SIT_PARAMETER
                           3. Added packing/unpacking for screen indicator
                              in origCdNum
   sit_c_002.main_15  mm   1. In all functions cmPkSit<Sitprimitive> and
                              cmUnpkSit<Sitprimitive> delete extra SPutMsg 
			      to avoid double calling it.
                           2. Modified macro CMCHKPK/CMCHKUNPK into 
			      CMCHKPKLOG/CMCHKUNPKLOG to ensure that SPutMsg
			      is called if Packing/Unpacking fail.
			   3. Modified service activation parameter for 
			      Bellcore variant. Also add transaction fucntions 
			      for rolling upgrade.			      
   sit_c_003.main_15  tz   1. Added packing and unpacking of charge band
                              parameter for Indian variant.
                           2. Added SS7_INDIA flags. 
   sit_c_004.main_15  rk   1. Added CHINA flag and switch where applicable.
                           2. Added packing and unpacking of charge information
			      parameter for China variant
   sit_c_005.main_15  rk   1. Transit network parameter for ansi specs defined.
			      This parameter is under TNS_ANSI compile time 
                              flag as it is a particular customer requirement.
                              We assume that encoding/decoding of the TNS 
                              parameter will be done by user.
                      bn   2. added packing and unpacking functions for ITU2000
                              variant and compile time flags for Russian 2000
                      bn   3. changed bitVector to U32 from U8.
   sit_c_006.main_15  bn   1. corrected TDS_ROLL_UPGRADE_SUPPORT flag
   sit_c_007.main_15  rk   1. Deleted printf statements
*********************************************************************91*/
