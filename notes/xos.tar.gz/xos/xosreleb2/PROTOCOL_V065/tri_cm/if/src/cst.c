/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Compression/Decompression Module
  
     Type:     C source file
  
     Desc:     C source code for common packing and un-packing functions 
               for the Upper Interface(CST) supplied by TRILLIUM
              
     File:     cst.c
  
     Sid:      cst.c@@/main/1 - Tue Apr 20 00:23:05 2004

     Prg:      ps
  
*********************************************************************21*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_inet.h"       /* common sockets */
#include "cm_err.h"        /* common error */
#include "cm_tpt.h"        /* common transport defines */
#include "cst.h"           /* compression  interface */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_inet.x"       /* common sockets */
#include "cm_tpt.x"        /* common transport typedefs */
#include "cst.x"           /* compression  interface */

#ifdef CM_COMPRESS


/*
*
*    Fun:    cmPkSoConnInfo
*
*    Desc:    pack the structure SoConnInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoConnInfo
(
SoConnInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoConnInfo(param ,mBuf)
SoConnInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoConnInfo)

    CMCHKPK(cmPkCmTptAddr, &param->peerAddr,mBuf);
    CMCHKPK(SPkU32, param->connId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoConnInfo*/

/*
*
*    Fun:    cmPkSoCompContext
*
*    Desc:    pack the structure SoCompContext
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCompContext
(
SoCompContext *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCompContext(param ,mBuf)
SoCompContext *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoCompContext)

    if( param->choice != NOTPRSNT )
    {
       switch( param->choice )
       {
          case  SO_COMP_CONTEXT_CLIENT :
             CMCHKPK(cmPkSoConnInfo, &param->t.client,mBuf);
             break;
          case  SO_COMP_CONTEXT_SERVER :
             CMCHKPK(cmPkSoConnInfo, &param->t.server,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    CMCHKPK(SPkU8, param->choice,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCompContext*/

/*
*
*    Fun:    cmUnpkSoConnInfo
*
*    Desc:    unpack the structure SoConnInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoConnInfo
(
SoConnInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoConnInfo(param, mBuf)
SoConnInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoConnInfo)

    CMCHKUNPK(SUnpkU32, &param->connId,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->peerAddr,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoConnInfo*/

/*
*
*    Fun:    cmUnpkSoCompContext
*
*    Desc:    unpack the structure SoCompContext
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCompContext
(
SoCompContext *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCompContext(param, mBuf)
SoCompContext *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoCompContext)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->choice,mBuf);
    if( param->choice != NOTPRSNT )
    {
       switch( param->choice )
       {
          case  SO_COMP_CONTEXT_CLIENT :
             CMCHKUNPK(cmUnpkSoConnInfo, &param->t.client,mBuf);
             break;
          case  SO_COMP_CONTEXT_SERVER :
             CMCHKUNPK(cmUnpkSoConnInfo, &param->t.server,mBuf);
             break;
          default:
             RETVALUE(RFAILED);
       }
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCompContext*/



/*
*
*    Fun:    cmPkCstCompressReq
*
*    Desc:    pack the primitive CstCompressReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCstCompressReq
(
Pst       *pst,
Buffer    *mBuf,
Ptr       compContext 
)
#else
PUBLIC S16 cmPkCstCompressReq (pst, mBuf, compContext)
Pst       *pst;
Buffer    *mBuf;
Ptr       compContext;
#endif
{
    TRC3 (cmPkCstCompressReq)

#if (ERRCLASS & ERRCLS_ADD_RES)
    if(mBuf == NULLP)
    {
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ECST001, (ErrVal)1, "CstCompressReq :Packing failure");

       RETVALUE (RFAILED);
    }
#endif

    CMCHKPKLOG(cmPkSoCompContext, ((SoCompContext *)compContext),
               mBuf, ECST002, pst);

    pst->event = (Event) EVTCSTCOMPRESSREQ;

    RETVALUE (SPstTsk(pst,mBuf));

} /*end of function cmPkCstCompressReq*/



/*
*
*    Fun:    cmPkCstCompressCfm
*
*    Desc:    pack the primitive CstCompressCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCstCompressCfm
(
Pst     *pst,
Bool    success,
Buffer  *compMsg,
Buffer  *unCompMsg,
Ptr     compContext
)
#else
PUBLIC S16 cmPkCstCompressCfm (pst, success, compMsg, unCompMsg, compContext)
Pst     *pst;
Bool    success;
Buffer  *compMsg;
Buffer  *unCompMsg;
Ptr     compContext;
#endif
{
    Buffer *mBuf;

    TRC3 (cmPkCstCompressCfm)

#if (ERRCLASS & ERRCLS_ADD_RES)
    if ((success  && (compMsg   == NULLP)) ||
        (!success && (unCompMsg == NULLP)))
    {
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ECST003, (ErrVal)1, "CstCompressCfm :Packing failure");

       RETVALUE (RFAILED);
    }
#endif

    if (success)
      mBuf = compMsg;
    else
      mBuf = unCompMsg;

    CMCHKPKLOG (cmPkSoCompContext, ((SoCompContext *)compContext),
               mBuf, ECST004, pst);

    CMCHKPK (SPkU8, success, mBuf);

    pst->event = (Event) EVTCSTCOMPRESSCFM;

    RETVALUE (SPstTsk (pst, mBuf));

} /* end of function cmPkCstCompressCfm */



/*
*
*    Fun:    cmPkCstDecompressReq
*
*    Desc:    pack the primitive CstDecompressReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCstDecompressReq
(
Pst       *pst,
Buffer    *compMsg,
Ptr       compContext 
)
#else
PUBLIC S16 cmPkCstDecompressReq (pst, compMsg, compContext)
Pst       *pst;
Buffer    *compMsg;
Ptr       compContext;
#endif
{
    TRC3 (cmPkCstDecompressReq)

#if (ERRCLASS & ERRCLS_ADD_RES)
    if (compMsg == NULLP)
    {
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ECST005, (ErrVal)1, "CstDecompressReq :Packing failure");

       RETVALUE (RFAILED);
    }
#endif

    CMCHKPKLOG (cmPkSoCompContext, ((SoCompContext *)compContext),
                compMsg, ECST006, pst);

    pst->event = (Event) EVTCSTDECOMPRESSREQ;

    RETVALUE (SPstTsk (pst,compMsg));

} /*end of function cmPkCstDecompressReq */



/*
*
*    Fun:    cmPkCstDecompressCfm
*
*    Desc:    pack the primitive CstDecompressCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkCstDecompressCfm
(
Pst     *pst,
Bool    success,
Buffer  *unCompMsg,
Ptr     compContext
)
#else
PUBLIC S16 cmPkCstDecompressCfm (pst, success, unCompMsg, compContext)
Pst     *pst;
Bool    success;
Buffer  *unCompMsg;
Ptr     compContext;
#endif
{
    Buffer *mBuf;

    TRC3 (cmPkCstDecompressCfm)

#if (ERRCLASS & ERRCLS_ADD_RES)
    if (success  && (unCompMsg   == NULLP))
    {
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ECST007, (ErrVal)1, "CstDecompressCfm :Packing failure");

       RETVALUE (RFAILED);
    }
#endif

    if (success)
      mBuf = unCompMsg;
    else
    {
      if((SGetMsg (pst->region, pst->pool, &mBuf)) != ROK)
      {
#if (ERRCLASS & ERRCLS_ADD_RES)
         SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
               __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
              (ErrVal)ECST008, (ErrVal)0, "SGetMsg() failed");
#endif
         RETVALUE (RFAILED);
      }
    }

    CMCHKPKLOG (cmPkSoCompContext, ((SoCompContext *)compContext),
               mBuf, ECST009, pst);

    CMCHKPK (SPkU8, success, mBuf);

    pst->event = (Event) EVTCSTDECOMPRESSCFM;

    RETVALUE (SPstTsk (pst, mBuf));

} /* end of function cmPkCstDecompressCfm */



/*
*
*    Fun:    cmUnpkCstCompressReq
*
*    Desc:    unpack the primitive CstCompressReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCstCompressReq
(
CstCompressReq func,
Pst            *pst,
Buffer         *mBuf 
)
#else
PUBLIC S16 cmUnpkCstCompressReq (func, pst, mBuf)
CstCompressReq func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
    SoCompContext compContext;

    TRC3 (cmUnpkCstCompressReq)

    CMCHKUNPKLOG (cmUnpkSoCompContext, &compContext,  mBuf, ECST010, pst);

    (*func) (pst, mBuf, (Ptr)&compContext);

    RETVALUE (ROK);

} /*end of function cmUnpkCstCompressReq*/



/*
*
*    Fun:    cmUnpkCstCompressCfm
*
*    Desc:    unpack the primitive CstCompressCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCstCompressCfm
(
CstCompressCfm func,
Pst            *pst,
Buffer         *mBuf 
)
#else
PUBLIC S16 cmUnpkCstCompressCfm (func, pst, mBuf)
CstCompressCfm func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
    Bool          success;
    SoCompContext compContext;

    TRC3 (cmUnpkCstCompressCfm)

    CMCHKUNPK (SUnpkU8, &success, mBuf);

    CMCHKUNPKLOG (cmUnpkSoCompContext, &compContext,  mBuf, ECST011, pst);

    if (success)
       (*func) (pst, success, mBuf, NULLP, &compContext);
    else
       (*func) (pst, success, NULLP, mBuf, (Ptr)&compContext);

    RETVALUE (ROK);

} /*end of function cmUnpkCstCompressCfm*/



/*
*
*    Fun:    cmUnpkCstDecompressReq
*
*    Desc:    unpack the primitive CstDecompressReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     cmp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCstDecompressReq
(
CstDecompressReq func,
Pst              *pst,
Buffer           *mBuf 
)
#else
PUBLIC S16 cmUnpkCstDecompressReq (func, pst, mBuf)
CstDecompressReq func;
Pst              *pst;
Buffer           *mBuf;
#endif
{
    SoCompContext compContext;

    TRC3 (cmUnpkCstDecompressReq)

    CMCHKUNPKLOG (cmUnpkSoCompContext, &compContext,  mBuf, ECST012, pst);

    (*func) (pst, mBuf, (Ptr)&compContext);

    RETVALUE (ROK);

} /*end of function cmUnpkCstDecompressReq*/



/*
*
*    Fun:    cmUnpkCstDecompressCfm
*
*    Desc:    unpack the primitive CstDecompressCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     so_tcm.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkCstDecompressCfm
(
CstDecompressCfm func,
Pst              *pst,
Buffer           *mBuf 
)
#else
PUBLIC S16 cmUnpkCstDecompressCfm (func, pst, mBuf)
CstDecompressCfm func;
Pst              *pst;
Buffer           *mBuf;
#endif
{
    Bool          success;
    SoCompContext compContext;

    TRC3 (cmUnpkCstDecompressCfm)

    CMCHKUNPK (SUnpkU8, &success, mBuf);

    CMCHKUNPKLOG (cmUnpkSoCompContext, &compContext,  mBuf, ECST013, pst);

    if (success)
       (*func) (pst, success, mBuf , &compContext);
    else
    {
       (Void) SPutMsg (mBuf);
       (*func) (pst, success, NULLP, (Ptr)&compContext);
    }

    RETVALUE (ROK);

} /*end of function cmUnpkCstDecompressCfm*/

#endif  /* CM_COMPRESS */


/********************************************************************30**

         End of file:     cst.c@@/main/1 - Tue Apr 20 00:23:05 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/1      ---      ps  1. initial release.
*********************************************************************91*/

