/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Common SPT
  
     Type:     Common Source Code
  
     Desc:     Routines shared across the SPT interface
 
     File:     spt.c

     Sid:      spt.c@@/main/13 - Tue Jan 22 15:18:23 2002
  
     Prg:      fmg
  
*********************************************************************21*/
 

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_ss7.h"        /* common ss7 */
#include "spt.h"           /* spt interface */
#include "cm_err.h"        /* common error */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */
#include "spt.x"           /* spt interface */



/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/*
 * support functions
 */
#ifdef LCSPT


/*
*
*       Fun:   cmPkSpUDatEvnt
*
*       Desc:  Unpack unit data event
*
*       Ret:   ROK on success
*
*       Notes: Connection Oriented Control
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSpUDatEvnt
(
Pst *pst,                         /* post structure */
SpUDatEvnt *ud,                   /* Unit Data Event */
Buffer *mBuf                      /* message buffer */
)
#else
PUBLIC S16 cmPkSpUDatEvnt(pst, ud, mBuf)
Pst *pst;                         /* post structure */
SpUDatEvnt *ud;                   /* Unit Data Event */
Buffer *mBuf;                     /* message buffer */
#endif
{
   S16 rVal;                      /* return value */
   U8 len;                        /* length */
   CmIntfVer intfVer;             /* remote interface version number */

   TRC2(cmPkSpUDatEvnt)

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
      {
         CMCHKPK(SPkU8, ud->prior, mBuf);
         CMCHKPK(SPkU32, ud->sc, mBuf);
         CMCHKPK(SPkU8, ud->esc, mBuf);
         CMCHKPK(SPkU8, ud->tmr, mBuf);
         rVal = cmPkSpAddr(&ud->cgAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         rVal = cmPkSpAddr(&ud->cdAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         CMCHKPK(cmPkSpQosSet, &ud->qos, mBuf);
      }
      break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector[1];              /* bitvector array */

         /* initialize bitVector */
         bitVector[0] = 0x0000;

#ifdef SS7_ANS96
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector[0] |= SPT_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */

#ifdef SS7_BELL05
         /* set bit corresponding to flag SS7_ANS96 */
         bitVector[0] |= SPT_SS7_BELL05_BIT;
#endif /* SS7_BELL05 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#ifdef SPTV2
#ifdef SS7_BELL05
         CMCHKPK(cmPkSpIns, &ud->ins, mBuf);   
#endif /* SS7_BELL05 */

#if (SS7_ANS96 || SS7_BELL05)
         CMCHKPK(cmPkSpIsni, &ud->isni, mBuf);   
#endif /* SS7_ANS96 || SS7_BELL05 */

         /* if importance is present, pack importance value */
         if (ud->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, ud->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, ud->imp.pres, mBuf);
#endif /* SPTV2 */

         CMCHKPK(SPkU8, ud->prior, mBuf);
         CMCHKPK(SPkU32, ud->sc, mBuf);
         CMCHKPK(SPkU8, ud->esc, mBuf);
         CMCHKPK(SPkU8, ud->tmr, mBuf);
         rVal = cmPkSpAddr(&ud->cgAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         rVal = cmPkSpAddr(&ud->cdAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         CMCHKPK(cmPkSpQosSet, &ud->qos, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* pack bitVector */
         CMCHKPK(SPkU16, bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      }
      break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* end of cmPkSpUDatEvnt */


/*
*
*       Fun:   cmUnpkSpUDatEvnt
*
*       Desc:  Unpack unit data event
*
*       Ret:   ROK on success
*
*       Notes: Connection Oriented Control
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSpUDatEvnt
(
Pst *pst,              /* post structure */
SpUDatEvnt *ud,        /* Unit Data Event */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSpUDatEvnt(pst, ud, mBuf)
Pst *pst;              /* post structure */
SpUDatEvnt *ud;        /* Unit Data Event */
Buffer *mBuf;          /* message buffer */
#endif
{
   CmIntfVer intfVer;
   
   TRC2(cmUnpkSpUDatEvnt)

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
      {
         CMCHKUNPK(cmUnpkSpQosSet, &ud->qos, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &ud->cdAddr, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &ud->cgAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->tmr, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->esc, mBuf);
         CMCHKUNPK(SUnpkU32, &ud->sc, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->prior, mBuf);
#ifdef SPTV2
         /* initialize imp with default value not presesnt */
         ud->imp.pres = NOTPRSNT;
#if (SS7_ANS96 || SS7_BELL05)
         /* initialize isni with default value not presesnt */
         ud->isni.isniPres = NOTPRSNT;
#endif /* SS7_ANS96 || SS7_BELL05 */
#ifdef SS7_BELL05
         /* initialize ins with default value not presesnt */
         ud->ins.insPres = NOTPRSNT;
#endif /* SS7_BELL05 */
#endif /* SPTV2 */
      }
      break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector[1];   /* bitVector for compile flags */
#ifdef SPTV2
#if !(SS7_ANS96 || SS7_BELL05)
         SpIsni tmpIsni;     /* temporary buffer to unpack and ignore insi */
#endif /* ! (SS7_ANS96 || SS7_BELL05) */
#ifndef SS7_BELL05
         SpIns tmpIns;       /* temporary buffer to unpack and ignore ins */
#endif /* SS7_BELL05 */
#endif /* SPTV2 */

         CMCHKUNPK(SUnpkU16, &bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkSpQosSet, &ud->qos, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &ud->cdAddr, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &ud->cgAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->tmr, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->esc, mBuf);
         CMCHKUNPK(SUnpkU32, &ud->sc, mBuf);
         CMCHKUNPK(SUnpkU8, &ud->prior, mBuf);

#ifdef SPTV2
         /* Unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &ud->imp.pres, mBuf);
         /* if importance is present, Unpack importance value */
         if (ud->imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &ud->imp.val, mBuf);

         /* unpack isni if compile flag for ansi96 or bell05 is enabled and:
          *    1) rolling upgrade support enabld and bitVector indicates that
          *       the flag is enabled at originating side and hence isni was
          *       packed
          *    2) No rolling upgrade support enabled. In this case unpacking
          *       of isni is solely on the basis of compile flags for ans96
          *       and bell05
          */
#if (SS7_ANS96 || SS7_BELL05)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* spt_c_002.main_13 - addition - initialize isni as NOTPRSNT,
          * if isni is not unpacked.
          */
         if ((bitVector[0] & SPT_SS7_ANS96_BIT) ||
             (bitVector[0] & SPT_SS7_BELL05_BIT))
         {
            CMCHKUNPK(cmUnpkSpIsni, &ud->isni, mBuf);
         }
         else
            ud->isni.isniPres = NOTPRSNT;
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkSpIsni, &ud->isni, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#else /* SS7_ANS96 || SS7_BELL05 */
         /* compile flags for ans96 and bell05 is not enabled at our side.
          * If bitVector indicates flag is enabled at originating end and
          * hence isni was packed, then unpack isni into  temporary buffer
          * and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector[0] & SPT_SS7_ANS96_BIT) ||
             (bitVector[0] & SPT_SS7_BELL05_BIT))
            CMCHKUNPK(cmUnpkSpIsni, &tmpIsni, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#endif /* SS7_ANS96 || SS7_BELL05 */

         /* unpack ins if compile flag for bell05 is enabled and:
          *    1) rolling upgrade support enabld and bitVector indicates that
          *       the flag is enabled at originating side and hence ins was
          *       packed
          *    2) No rolling upgrade support enabled. In this case unpacking
          *       of ins is solely on the basis of compile flag for bell05
          */
#ifdef SS7_BELL05
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* spt_c_002.main_13 - addition - initialize ins as NOTPRSNT,
          * if ins is not unpacked.
          */
         if (bitVector[0] & SPT_SS7_BELL05_BIT)
         {
            CMCHKUNPK(cmUnpkSpIns, &ud->ins, mBuf);
         }
         else
            ud->ins.insPres = NOTPRSNT;
#else /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkSpIns, &ud->ins, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_BELL05 */
         /* compile flags for bell05 is not enabled at our side. If bitVector
          * indicates flag is enabled at originating end and hence ins was
          * packed, then unpack ins into  temporary buffer and ignore
          */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector[0] & SPT_SS7_BELL05_BIT)
            CMCHKUNPK(cmUnpkSpIns, &tmpIns, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_BELL05 */
#endif /* SPTV2 */
       }
       break;

       default:
          /* invaid interface version */
          RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* end of cmUnpkSpUDatEvnt */


/*
*
*       Fun:   cmPkSpQosSet
*
*       Desc:  unpack quality of service set
*
*       Ret:   ROK on success
*
*       Notes: Connection Oriented Control
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSpQosSet
(
SpQosSet *qos,         /* qos set */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmPkSpQosSet(qos, mBuf)
SpQosSet *qos;         /* qos set */
Buffer *mBuf;          /* message buffer */
#endif
{
   
   TRC2(cmPkSpQosSet)

   CMCHKPK(SPkU8, qos->credit, mBuf);
   CMCHKPK(SPkU8, qos->retOpt, mBuf);
   CMCHKPK(SPkU8, qos->pClass, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSpQosSet */


/*
*
*       Fun:   cmUnpkSpQosSet
*
*       Desc:  unpack quality of service set
*
*       Ret:   ROK on success
*
*       Notes: Connection Oriented Control
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSpQosSet
(
SpQosSet *qos,         /* qos set */
Buffer *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSpQosSet(qos, mBuf)
SpQosSet *qos;         /* qos set */
Buffer *mBuf;          /* message buffer */
#endif
{
   
   TRC2(cmUnpkSpQosSet)

   CMCHKUNPK(SUnpkU8, &qos->pClass, mBuf);
   CMCHKUNPK(SUnpkU8, &qos->retOpt, mBuf);
   CMCHKUNPK(SUnpkU8, &qos->credit, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSpQosSet */

#ifdef SPCO

/*
*
*       Fun:   cmPkSpConEvnt
*
*       Desc:  pack SCCP Connection Event Structure
*
*       Ret:   RFAILED/ROK/ROKDNA
*
*       Notes: common routine used by all SCCP (connection oriented) users.
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpConEvnt
(
Pst *pst,              /* post structure */
SpConEvnt *conEvnt,    /* connection event structure */
Buffer *mBuf           /* message mBuffer */
)
#else
PUBLIC S16 cmPkSpConEvnt(pst, conEvnt, mBuf)
Pst *pst;              /* post structure */
SpConEvnt *conEvnt;    /* connection event structure */
Buffer *mBuf;          /* message mBuffer */
#endif
{
   U8 len;             /* length */
   S16 rVal;           /* return value */
   CmIntfVer intfVer;  /* interface version number */
   
   TRC2(cmPkSpConEvnt)

   /* if rolling upgrade support is enabled, use interface version
    * as received in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (conEvnt->type)
   {
      case CE_REQ0:
         CMCHKPK(SPkU8, conEvnt->t.req0.eds, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.req0.rcs, mBuf);
         rVal = cmPkSpAddr(&conEvnt->t.req0.cgAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         rVal = cmPkSpAddr(&conEvnt->t.req0.cdAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         break;
      case CE_REQ1:
         CMCHKPK(SPkU8, conEvnt->t.req1.eds, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.req1.rcs, mBuf);
         break;
      case CE_REQ2:
         CMCHKPK(SPkU8, conEvnt->t.req2.refInd, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.req2.repReq, mBuf);
         CMCHKPK(SPkU32, conEvnt->t.req2.opc, mBuf);
         CMCHKPK(SPkU32, conEvnt->t.req2.slr, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.req2.nwInd, mBuf);
         break;
      case CE_IND:
         CMCHKPK(SPkU8, conEvnt->t.ind.eds, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.ind.rcs, mBuf);
         rVal = cmPkSpAddr(&conEvnt->t.ind.cgAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         rVal = cmPkSpAddr(&conEvnt->t.ind.cdAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         break;
      case CE_RESP:
         CMCHKPK(SPkU8, conEvnt->t.resp.eds, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.resp.rcs, mBuf);
         rVal = cmPkSpAddr(&conEvnt->t.resp.rspAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         break;
      case CE_CFM:
         CMCHKPK(SPkU8, conEvnt->t.cfm.eds, mBuf);
         CMCHKPK(SPkU8, conEvnt->t.cfm.rcs, mBuf);
         rVal = cmPkSpAddr(&conEvnt->t.cfm.rspAddr, mBuf, &len);
#if (ERRCLASS & ERRCLS_ADD_RES)
         if (rVal != ROK)
         {
            RETVALUE(rVal);
         }
#endif
         break;
      case CE_REP:
         CMCHKPK(SPkU32, conEvnt->t.reply.slr, mBuf);
         break;
   }

   /* pack qos, conId, type and imp depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         /* quality of service */
         CMCHKPK(cmPkSpQosSet, &conEvnt->qos, mBuf);
         /* connection id */
         CMCHKPK(cmPkSpConId, &conEvnt->conId, mBuf);
         /* type */
         CMCHKPK(SPkU8, conEvnt->type, mBuf);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         /* if importance is present, pack importance value */
         if (conEvnt->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, conEvnt->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, conEvnt->imp.pres, mBuf);
#endif /* SPTV2 */

         /* quality of service */
         CMCHKPK(cmPkSpQosSet, &conEvnt->qos, mBuf);
         /* connection id */
         CMCHKPK(cmPkSpConId, &conEvnt->conId, mBuf);
         /* type */
         CMCHKPK(SPkU8, conEvnt->type, mBuf);
         break;

      default:
         /* invalid interface version */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* end of cmPkSpConEvnt */


/*
*
*       Fun:   cmUnpkSpConEvnt
*
*       Desc:  unpack SCCP Connection Event Structure
*
*       Ret:   RFAILED/ROK/ROKDNA
*
*       Notes: Connection Oriented Control
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpConEvnt
(
Pst *pst,              /* post structure */
SpConEvnt *conEvnt,    /* connection control block */
Buffer *mBuf           /* message mBuffer */
)
#else
PUBLIC S16 cmUnpkSpConEvnt(pst, conEvnt, mBuf)
Pst *pst;              /* post structure */
SpConEvnt *conEvnt;    /* connection control block */
Buffer *mBuf;          /* message mBuffer */
#endif
{
   CmIntfVer intfVer;  /* interface version number */

   TRC2(cmUnpkSpConEvnt)

   /* if rolling upgrade support is enabled, use interface version
    * as received in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack type, conId, qos and imp depending on intfVer recvd */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPK(SUnpkU8, &conEvnt->type, mBuf);
         CMCHKUNPK(cmUnpkSpConId, &conEvnt->conId, mBuf);
         CMCHKUNPK(cmUnpkSpQosSet, &conEvnt->qos, mBuf);
#ifdef SPTV2
         /* initialize imp pres with default value notprsnt */
         conEvnt->imp.pres = NOTPRSNT;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPK(SUnpkU8, &conEvnt->type, mBuf);
         CMCHKUNPK(cmUnpkSpConId, &conEvnt->conId, mBuf);
         CMCHKUNPK(cmUnpkSpQosSet, &conEvnt->qos, mBuf);

#ifdef SPTV2
         /* Unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &conEvnt->imp.pres, mBuf);
         /* if importance is present, Unpack importance value */
         if (conEvnt->imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &conEvnt->imp.val, mBuf);
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   switch(conEvnt->type)
   {
      case CE_REQ0:
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.req0.cdAddr, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.req0.cgAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req0.rcs, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req0.eds, mBuf);
         break;
      case CE_REQ1:
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req1.rcs, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req1.eds, mBuf);
         break;
      case CE_REQ2:
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req2.nwInd, mBuf);
         CMCHKUNPK(SUnpkU32, &conEvnt->t.req2.slr, mBuf);
         CMCHKUNPK(SUnpkU32, &conEvnt->t.req2.opc, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req2.repReq, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.req2.refInd, mBuf);
         break;
      case CE_IND:
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.ind.cdAddr, mBuf);
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.ind.cgAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.ind.rcs, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.ind.eds, mBuf);
         break;
      case CE_RESP:
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.resp.rspAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.resp.rcs, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.resp.eds, mBuf);
         break;
      case CE_CFM:
         CMCHKUNPK(cmUnpkSpAddr, &conEvnt->t.cfm.rspAddr, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.cfm.rcs, mBuf);
         CMCHKUNPK(SUnpkU8, &conEvnt->t.cfm.eds, mBuf);
         break;
      case CE_REP:
         CMCHKUNPK(SUnpkU32, &conEvnt->t.reply.slr, mBuf);
         break;
   }
   RETVALUE(ROK);
} /* end of cmUnpkSpConEvnt */


/*
*
*       Fun:   cmPkSpConId
*
*       Desc:  pack connection id
*
*       Ret:   none
*
*       Notes: none
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpConId
(
SpConId *conId,                 /* connection id */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 cmPkSpConId(conId, mBuf)
SpConId *conId;                 /* connection id */
Buffer *mBuf;                   /* buffer */
#endif
{

   TRC2(cmPkSpConId)
   
   CMCHKPK(SPkU32, conId->spInstId, mBuf);
   CMCHKPK(SPkU32, conId->suInstId, mBuf);
   CMCHKPK(SPkS16, conId->spId, mBuf);
   CMCHKPK(SPkS16, conId->suId, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSpConId */


/*
*
*       Fun:   cmUnpkSpConId
*
*       Desc:  pack connection id
*
*       Ret:   none
*
*       Notes: none
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpConId
(
SpConId *conId,                 /* connection id */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 cmUnpkSpConId(conId, mBuf)
SpConId *conId;                 /* connection id */
Buffer *mBuf;                   /* buffer */
#endif
{

   TRC2(cmUnpkSpConId)
   
   CMCHKUNPK(SUnpkS16, &conId->suId, mBuf);
   CMCHKUNPK(SUnpkS16, &conId->spId, mBuf);
   CMCHKUNPK(SUnpkU32, &conId->suInstId, mBuf);
   CMCHKUNPK(SUnpkU32, &conId->spInstId, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSpConId */

#endif /* SPCO */


/*
*     upper interface packing functions
*/
  
  
/*
*
*       Fun:   Pack - Data Indication
*
*       Desc:  This function provides for an exchange of user
*              data units.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSptUDatInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc opc,                        /* Originating point code */
SpUDatEvnt *ud,                 /* Unit Data Event */
Buffer *mBuf                    /* Pointer to the Buffer */
)
#else
PUBLIC S16 cmPkSptUDatInd(pst, suId, opc, ud, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc opc;                        /* Originating point code */
SpUDatEvnt *ud;                 /* Unit Data Event */
Buffer *mBuf;                   /* Pointer to the Buffer */
#endif
{
   TRC3(cmPkSptUDatInd)

   CMCHKPKVERLOG(cmPkSpUDatEvnt, ud, mBuf, ESPT001, pst);   
   CMCHKPKLOG(SPkU32, opc, mBuf, ESPT002, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT003, pst);
   /*
    ** Removed the check for selector , since selector
    ** could be anything in the DFTHA environment
    */
   pst->event = EVTSPTUDATIND;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkSptUDatInd */
  
/*
*
*       Fun:   Pack - Status Indication
*
*       Desc:  This function is used to Indicate Signalling Point status.
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSptStaInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User ID */
Dpc opc,                        /* Originating point code */
SpUDatEvnt *ud,                 /* Unit Data Event */
RCause rc,                      /* Return cause */
Buffer *mBuf                    /* Message buffer */
)
#else
PUBLIC S16 cmPkSptStaInd(pst, suId, opc, ud, rc, mBuf)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User ID */
Dpc opc;                        /* Originating point code */
SpUDatEvnt *ud;                 /* Unit Data Event */
RCause rc;                      /* Return casue */
Buffer *mBuf;                   /* Message buffer */
#endif
{
   TRC3(cmPkSptStaInd)
  
   if (!mBuf)
   {
      SPT_GETMSG(pst, mBuf, ESPT004);
   }

   CMCHKPKLOG(SPkU8, rc, mBuf, ESPT005, pst);
   CMCHKPKVERLOG(cmPkSpUDatEvnt, ud, mBuf, ESPT006, pst);
   CMCHKPKLOG(SPkU32, opc, mBuf, ESPT007, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT008, pst);
   pst->event = EVTSPTSTAIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptStaInd */
  
/*
*
*       Fun:   Pack - Coordinated Indication
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptCordInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 cmPkSptCordInd(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Affected Subsystem */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   Buffer *mBuf;

   TRC3(cmPkSptCordInd)

   SPT_GETMSG(pst, mBuf, ESPT009);  

   CMCHKPKLOG(SPkU8, smi, mBuf, ESPT010, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT011, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT012, pst);
   pst->event = EVTSPTCRDIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptCordInd */
  
/*
*
*       Fun:   Pack - Coordinated Confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSptCordCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Ssn aSsn,                       /* Affected Subsystem */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 cmPkSptCordCfm(pst, suId, aSsn, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Ssn aSsn;                       /* Calling Address */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptCordCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT013);
   
   CMCHKPKLOG(SPkU8, smi, mBuf, ESPT014, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT015, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT016, pst);
   pst->event = EVTSPTCRDCFM;
   SPstTsk(pst, mBuf);
   

   RETVALUE(ROK);
} /* end of cmPkSptCordCfm */
  
/*
*
*       Fun:   State Indication
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat,                    /* user status */
Smi smi                         /* subsystem multiplicity indicator */
)
#else
PUBLIC S16 cmPkSptSteInd(pst, suId, aDpc, aSsn, uStat, smi)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Calling Address */
UStat uStat;                    /* user status */
Smi smi;                        /* subsystem multiplicity indicator */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteInd)
  
   SPT_GETMSG(pst, mBuf, ESPT017)
   
   CMCHKPKLOG(SPkU8, smi, mBuf, ESPT018, pst);
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT019, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT020, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT021, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT022, pst);
   pst->event = EVTSPTSTEIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteInd */

 
/*
*
*       Fun:   Pack - PC State Indication
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination point code */
Sps sps                         /* signalling point status */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PUBLIC S16 cmPkSptPCSteInd(pst, suId, aDpc, sps
#ifdef SPTV2
, sccpState, ril
#endif /* SPTV2 */
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination point code */
Sps sps;                        /* signalling point status */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   Buffer *mBuf;                /* message buffer */
   CmIntfVer intfVer;           /* interface version number */

   TRC3(cmPkSptPCSteInd)
  
   SPT_GETMSG(pst, mBuf, ESPT023)

   /* if rolling upgrade support is enabled, use interface version
    * as in ps-intfVer, else use self SPT interface version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   /* pack parameters based on interface version number */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, sps, mBuf, ESPT024, pst);
         CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT025, pst);
         CMCHKPKLOG(SPkS16, suId, mBuf, ESPT026, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         CMCHKPKLOG(SPkU8, ril, mBuf, ESPT027, pst);
         CMCHKPKLOG(SPkU8, sccpState, mBuf, ESPT028, pst);
#endif /* SPTV2 */
         CMCHKPKLOG(SPkU8, sps, mBuf, ESPT029, pst);
         CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT030, pst);
         CMCHKPKLOG(SPkS16, suId, mBuf, ESPT031, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   pst->event = EVTSPTPCSTEIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteInd */

#ifdef SPT2
 
/*
*
*       Fun:   Pack - State confirmation
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* status */
)
#else
PUBLIC S16 cmPkSptSteCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
#endif
{
   Buffer *mBuf;
   TRC3(cmPkSptSteCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT032)
   
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT033, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT034, pst);
   pst->event = EVTSPTSTECFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteCfm */

 
/*
*
*       Fun:   Pack - Bind confirmation
*
*       Desc:
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptBndCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status                       /* status */
)
#else
PUBLIC S16 cmPkSptBndCfm(pst, suId, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
#endif
{
   Buffer *mBuf;
   TRC3(cmPkSptBndCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT035)
   
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT036, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT037, pst);
   pst->event = EVTSPTBNDCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptBndCfm */

  
/*
*
*       Fun:   Status confirmation
*
*       Desc:
*
*       Ret:   ROK   - ok
*
*       Notes: 
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptStaCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
U8 status,                      /* status */
Dpc dpc,                        /* destination pointcode */
Ssn ssn,                        /* subsystem */
UStat uStat,                    /* user status */
Smi smi                         /* subsystem multiplicity indicator */
#ifdef SPTV2
, U8 sccpState,                 /* remote sccp status */
U8 ril                          /* restricted importance level */
#endif /* SPTV2 */
)
#else
PUBLIC S16 cmPkSptStaCfm(pst, suId, status, dpc, ssn, uStat, smi
#ifdef SPTV2
, sccpState, ril
#endif /* SPTV2 */
)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
U8 status;                      /* status */
Dpc dpc;                        /* pointcode */
Ssn ssn;                        /* subsystem */
UStat uStat;                    /* user status */
Smi smi;                        /* subsystem multiplicity indicator */
#ifdef SPTV2
U8 sccpState;                   /* remote sccp status */
U8 ril;                         /* restricted importance level */
#endif /* SPTV2 */
#endif
{
   Buffer *mBuf;                /* message buffer */
   CmIntfVer intfVer;           /* interface version number */
  
   TRC3(cmPkSptStaCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT038)
   
   /* if rolling upgrade support is enabled, use interface verison
    * as in pst-intfVer, else use self SPT interface version
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* pack parmaters based on remote interface version number */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, smi, mBuf, ESPT039, pst);
         CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT040, pst);
         CMCHKPKLOG(SPkU8, ssn, mBuf, ESPT041, pst);
         CMCHKPKLOG(SPkU32, dpc, mBuf, ESPT042, pst);
         CMCHKPKLOG(SPkU8, status, mBuf, ESPT043, pst);
         CMCHKPKLOG(SPkS16, suId, mBuf, ESPT044, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         CMCHKPKLOG(SPkU8, ril, mBuf, ESPT045, pst);
         CMCHKPKLOG(SPkU8, sccpState, mBuf, ESPT046, pst);
#endif /* SPTV2 */
         CMCHKPKLOG(SPkU8, smi, mBuf, ESPT047, pst);
         CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT048, pst);
         CMCHKPKLOG(SPkU8, ssn, mBuf, ESPT049, pst);
         CMCHKPKLOG(SPkU32, dpc, mBuf, ESPT050, pst);
         CMCHKPKLOG(SPkU8, status, mBuf, ESPT051, pst);
         CMCHKPKLOG(SPkS16, suId, mBuf, ESPT052, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   pst->event = EVTSPTSTACFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptStaCfm */

#endif /* SPT2 */

#ifdef SPCO

 
/*
*
*       Fun:   Connection Indication
*
*       Desc:  Pack - Connection Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptConInd
(
Pst *pst,            /* post structure */
SpConEvnt *conEvnt,        /* connection event */
Buffer *mBuf               /* buffer */
)
#else
PUBLIC S16 cmPkSptConInd(pst, conEvnt, mBuf)
Pst *pst;            /* post structure */
SpConEvnt *conEvnt;        /* connection event */
Buffer *mBuf;              /* buffer */
#endif
{
   Buffer *buf;
   TRC3(cmPkSptConInd)
  
   if (mBuf == (Buffer*)NULLP)
      SPT_GETMSG(pst, buf, ESPT053)
   else
      buf = mBuf;

   CMCHKPKVERLOG(cmPkSpConEvnt, conEvnt, buf, ESPT054, pst);
   pst->event = EVTSPTCONIND;
   SPstTsk(pst, buf);
   
   RETVALUE(ROK);
} /* end of cmPkSptConInd */
 
/*
*
*       Fun:   Connection Confirmation
*
*       Desc:  Pack - Connection Confirmation
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptConCfm
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 cmPkSptConCfm(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event */
Buffer *mBuf;                   /* buffer */
#endif
{
   Buffer *buf;
   TRC3(cmPkSptConCfm)
  
   if (mBuf == (Buffer*)NULLP)
   {
      SPT_GETMSG(pst, buf, ESPT055)
   }
   else
      buf = mBuf;

   CMCHKPKVERLOG(cmPkSpConEvnt, conEvnt, buf, ESPT056, pst);
   pst->event = EVTSPTCONCFM;
   SPstTsk(pst, buf);
   
   RETVALUE(ROK);
} /* end of cmPkSptConCfm */

 
/*
*
*       Fun:   Data Indication
*
*       Desc:  Pack - Data Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDatInd
(
Pst *pst,                       /* post structure */
SpDatEvnt *datEvnt,             /* data event */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 cmPkSptDatInd(pst, datEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDatEvnt *datEvnt;             /* data event */
Buffer *mBuf;                   /* buffer */
#endif
{
   CmIntfVer intfVer;  /* interface version number */

   TRC3(cmPkSptDatInd)

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* pack parmeters depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, datEvnt->cfmReq, mBuf, ESPT057, pst);
         CMCHKPKLOG(cmPkSpConId, &datEvnt->conId, mBuf, ESPT058, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         /* if importance is present, pack importance value */
         if (datEvnt->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, datEvnt->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, datEvnt->imp.pres, mBuf);
#endif /* SPTV2 */
         CMCHKPKLOG(SPkU8, datEvnt->cfmReq, mBuf, ESPT059, pst);
         CMCHKPKLOG(cmPkSpConId, &datEvnt->conId, mBuf, ESPT060, pst);
         break;

      default:
         /* invalid interface version */
         RETVALUE(RINVIFVER);
   }

   pst->event = EVTSPTDATIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptDatInd */

 
/*
*
*       Fun:   Expedited Data Indication
*
*       Desc:  Pack - Expedited Data Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptEDatInd
(
Pst *pst,            /* post structure */
SpConId *conId,            /* connection id */
Buffer *mBuf               /* buffer */
)
#else
PUBLIC S16 cmPkSptEDatInd(pst, conId, mBuf)
Pst *pst;            /* post structure */
SpConId *conId;            /* connection id */
Buffer *mBuf;              /* buffer */
#endif
{
   TRC3(cmPkSptEDatInd)
  
   CMCHKPKLOG(cmPkSpConId, conId, mBuf, ESPT061, pst);
   pst->event = EVTSPTEDATIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);

} /* end of cmPkSptEDatInd */


/*
*
*       Fun:   Data Acknowledgement Indication
*
*       Desc:  Pack - Data Acknowledgement Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDatAckInd
(
Pst *pst,            /* post structure */
SpConId *conId             /* connection id */
)
#else
PUBLIC S16 cmPkSptDatAckInd(pst, conId)
Pst *pst;            /* post structure */
SpConId *conId;            /* connection id */
#endif
{
   Buffer *mBuf;

   TRC3(cmPkSptDatAckInd)
  
   SPT_GETMSG(pst, mBuf, ESPT062)

   CMCHKPKLOG(cmPkSpConId, conId, mBuf, ESPT063, pst);
   
   pst->event = EVTSPTDATACKIND;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);

} /* end of cmPkSptDatAckInd */

 
/*
*
*       Fun:   Reset Indication
*
*       Desc:  Pack - Reset Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptRstInd
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 cmPkSptRstInd(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   Buffer *mBuf;

   TRC3(cmPkSptRstInd)
     
   SPT_GETMSG(pst, mBuf, ESPT064)

   CMCHKPKLOG(SPkU8, rstEvnt->orig, mBuf, ESPT065, pst);
   CMCHKPKLOG(SPkU8, rstEvnt->rsn, mBuf, ESPT066, pst);
   CMCHKPKLOG(cmPkSpConId, &rstEvnt->conId, mBuf, ESPT067, pst);
   pst->event = EVTSPTRSTIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);

} /* end of cmPkSptRstInd */
 
/*
*
*       Fun:   Reset Confirmation
*
*       Desc:  Pack - Reset Confirmation
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptRstCfm
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 cmPkSptRstCfm(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   Buffer *mBuf;

   TRC3(cmPkSptRstCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT068)
   
   CMCHKPKLOG(SPkU8, rstEvnt->orig, mBuf, ESPT069, pst);
   CMCHKPKLOG(SPkU8, rstEvnt->rsn, mBuf, ESPT070, pst);
   CMCHKPKLOG(cmPkSpConId, &rstEvnt->conId, mBuf, ESPT071, pst);
   pst->event = EVTSPTRSTCFM;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptRstCfm */

 
/*
*
*       Fun:   Disconnect Indication
*
*       Desc:  Pack - Disconnect Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDisInd
(
Pst *pst,                       /* post structure */
SpDisEvnt *disEvnt,             /* disconnect event */
Buffer *mBuf                    /* buffer */
)
#else
PUBLIC S16 cmPkSptDisInd(pst, disEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDisEvnt *disEvnt;             /* disconnect event */
Buffer *mBuf;                   /* buffer */
#endif
{
   U8 len;
   S16 ret1;
   CmIntfVer intfVer;

   TRC3(cmPkSptDisInd)
      
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      
   if (!mBuf)
   {
      SPT_GETMSG(pst, mBuf, ESPT072)
   }  

   /* pack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, disEvnt->orig, mBuf, ESPT073, pst);
         CMCHKPKLOG(SPkU8, disEvnt->rsn, mBuf, ESPT074, pst);
         ret1 = cmPkSpAddr(&disEvnt->rspAddr, mBuf, &len);
         if (ret1 != ROK)
         {
            SPutMsg(mBuf);
            SPTLOGERROR(ERRCLS_ADD_RES, ESPT075, (ErrVal) ret1, 
                        "Packing failure");
            RETVALUE(ret1);
         }
         CMCHKPKLOG(cmPkSpConId, &disEvnt->conId, mBuf, ESPT076, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         /* if importance is present, pack importance value */
         if (disEvnt->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, disEvnt->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, disEvnt->imp.pres, mBuf);
#endif /* SPTV2 */

         CMCHKPKLOG(SPkU8, disEvnt->orig, mBuf, ESPT077, pst);
         CMCHKPKLOG(SPkU8, disEvnt->rsn, mBuf, ESPT078, pst);
         ret1 = cmPkSpAddr(&disEvnt->rspAddr, mBuf, &len);
         if (ret1 != ROK)
         {
            SPutMsg(mBuf);
            SPTLOGERROR(ERRCLS_ADD_RES, ESPT079, (ErrVal) ret1, 
                        "Packing failure");
            RETVALUE(ret1);
         }
         CMCHKPKLOG(cmPkSpConId, &disEvnt->conId, mBuf, ESPT080, pst);
         break;

      default:
         /* invalid interface version */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   pst->event = EVTSPTDISIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptDisInd */

  
/*
*
*       Fun:   Inform Indication
*
*       Desc:  Inform Indication
*
*       Ret:   ROK   - ok
*
*       Notes:
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptInfInd
(
Pst *pst,                       /* post structure */
SpInfEvnt *infEvnt              /* inform event */
)
#else
PUBLIC S16 cmPkSptInfInd(pst, infEvnt)
Pst *pst;                       /* post structure */
SpInfEvnt *infEvnt;             /* inform event */
#endif
{
   Buffer *mBuf;
   
   TRC3(cmPkSptInfInd)

   SPT_GETMSG(pst, mBuf, ESPT081)

   CMCHKPKLOG(SPkU8, infEvnt->rsn, mBuf, ESPT082, pst);
   CMCHKPKLOG(cmPkSpQosSet, &infEvnt->qos, mBuf, ESPT083, pst);
   CMCHKPKLOG(cmPkSpConId, &infEvnt->conId, mBuf, ESPT084, pst);
   pst->event = EVTSPTCNSTIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* end of cmPkSptInfInd */

#endif /* SPCO */


/*
*     support functions
*/
  
/*
 *      LOOSELY COUPLED UPPER INTERFACE...
 */


/*
*
*       Fun:   cmUnpkSptBndReq
*
*       Desc:  unpack network bind request.
*
*       Ret:   S16
*
*       Notes: Verify packing order....
*
*       File:  spt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSptBndReq
(
SptBndReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptBndReq(func, pst, mBuf)
SptBndReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SuId suId;                   /* service user id */
   SpId spId;                   /* service provider id */
   Ssn ssn;                     /* subsystem number */
  
   TRC3(cmUnpkSptBndReq)
  
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT085, pst);
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT086, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT087, pst);         /* ssn */
   SPutMsg(mBuf);
   (*func)(pst, suId, spId, ssn );  
   RETVALUE(ROK);
}  /* end of cmUnpkSptBndReq */

  
/*
*
*       Fun:   cmUnpkSptUbndReq
*
*       Desc:  Unpack Network Unbind Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptUbndReq
(
SptUbndReq func,                   /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptUbndReq(func, pst, mBuf)
SptUbndReq func;                   /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   Reason reason;               /* reason */
  
   TRC3(cmUnpkSptUbndReq)
  
   CMCHKUNPKLOG( cmUnpkSpId, &spId, mBuf, ESPT088, pst);
   CMCHKUNPKLOG( cmUnpkReason, &reason, mBuf, ESPT089, pst);

   SPutMsg(mBuf);
   (*func)(pst, spId, reason);
   RETVALUE(ROK);
} /* end of cmUnpkSptUbndReq */

  
/*
*
*       Fun:   cmUnpkSptUDatReq
*
*       Desc:  Unpack Network Data Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptUDatReq
(
SptUDatReq func,                   /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptUDatReq(func, pst, mBuf)
SptUDatReq func;                   /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   SpUDatEvnt uData;            /* unit data event */
  
   TRC3(cmUnpkSptUDatReq)
  
   CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESPT090, pst);
   CMCHKUNPKVERLOG(cmUnpkSpUDatEvnt, &uData, mBuf, ESPT091, pst);
   (*func)(pst, spId, &uData, mBuf);

   RETVALUE(ROK);
}  /* end of cmUnpkSptUDatReq */

/* spt_c_003.main_13 - Addition - Unpack function for Unit data service 
 * request.
 */
#ifdef SPTV2_1
  
/*
*
*       Fun:   cmUnpkSptUDatSrvReq
*
*       Desc:  Unpack unit Data Service Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptUDatSrvReq
(
SptUDatSrvReq func,             /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptUDatSrvReq(func, pst, mBuf)
SptUDatSrvReq func;             /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   SpUDatEvnt uData;            /* unit data event */
  
   TRC3(cmUnpkSptUDatSrvReq)
  
   CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESPTXXX, pst);
   CMCHKUNPKVERLOG(cmUnpkSpUDatEvnt, &uData, mBuf, ESPTXXX, pst);
   (*func)(pst, spId, &uData, mBuf);

   RETVALUE(ROK);
}  /* end of cmUnpkSptUDatSrvReq */
#endif /* SPTV2_1 */

  
/*
*
*       Fun:   cmUnpkSptCordReq
*
*       Desc:  Unpack Coordinated State Change Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptCordReq
(
SptCordReq func,                   /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptCordReq(func, pst, mBuf)
SptCordReq func;                /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   Ssn aSsn;                    /* affected subsystem */
  
   TRC3(cmUnpkSptCordReq)
  
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT092, pst);
   CMCHKUNPKLOG( SUnpkU8, &aSsn, mBuf, ESPT093, pst);
   SPutMsg(mBuf);
   (*func)(pst, spId, aSsn);

   RETVALUE(ROK);
} /* end of cmUnpkSptCordReq */

  
/*
*
*       Fun:   cmUnpkSptCordRsp
*
*       Desc:  Unpack Coordinated State Change Response
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptCordRsp
(
SptCordRsp func,                   /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptCordRsp(func, pst, mBuf)
SptCordRsp func;                   /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   Ssn aSsn;                    /* affect subsystem  */
  
   TRC3(cmUnpkSptCordRsp)
  
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT094, pst);
   CMCHKUNPKLOG( SUnpkU8, &aSsn, mBuf, ESPT095, pst);
   SPutMsg(mBuf);
   (*func)(pst, spId, aSsn);
   RETVALUE(ROK);
} /* end of cmUnpkSptCordRsp */

  
/*
*
*       Fun:   cmUnpkSptSteReq
*
*       Desc:  Unpack State Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptSteReq
(
SptSteReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptSteReq(func, pst, mBuf)
SptSteReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   Ssn aSsn;                    /* affected subsystem */
   UStat uStat;                 /* user status */
  
   TRC3(cmUnpkSptSteReq)
  
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT096, pst);
   CMCHKUNPKLOG( SUnpkU8, &aSsn, mBuf, ESPT097, pst);
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT098, pst);
   SPutMsg(mBuf);
   (*func)(pst, spId, aSsn, uStat);
   RETVALUE(ROK);
} /* end of cmUnpkSptSteReq */

#ifdef SPT2
  
/*
*
*       Fun:   cmUnpkSptStaReq
*
*       Desc:  Unpack status Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptStaReq
(
SptStaReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptStaReq(func, pst, mBuf)
SptStaReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpId spId;                   /* service provider id */
   U8 status;                   /* status */
   Dpc dpc;                     /* destination pointcode */
   Ssn ssn;                     /* subsystem */
  
   TRC3(cmUnpkSptStaReq)
  
   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT099, pst);
   CMCHKUNPKLOG( SUnpkU8, &status, mBuf, ESPT100, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT101, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT102, pst);
   SPutMsg(mBuf);
   (*func)(pst, spId, status, dpc, ssn);
   RETVALUE(ROK);
} /* end of cmUnpkSptStaReq */
#endif /* SPT2 */

#ifdef SPCO

/*
*
*       Fun:   cmUnpkSptConReq
*
*       Desc:  Unpack Connection Request Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptConReq
(
SptConReq func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptConReq(func, pst, mBuf)
SptConReq func;                 /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpConEvnt conEvnt;
   MsgLen    len;

   TRC3(cmUnpkSptConReq)

   CMCHKUNPKVERLOG(cmUnpkSpConEvnt, &conEvnt, mBuf, ESPT103, pst);

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &conEvnt, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptConReq */


/*
*
*       Fun:   cmUnpkSptConRsp
*
*       Desc:  Unpack Connection Response Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptConRsp
(
SptConRsp func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptConRsp(func, pst, mBuf)
SptConRsp func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpConEvnt conEvnt;
   MsgLen    len;

   TRC3(cmUnpkSptConRsp)

   CMCHKUNPKVERLOG(cmUnpkSpConEvnt, &conEvnt, mBuf, ESPT104, pst);

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &conEvnt, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSptConRsp */


/*
*
*       Fun:   cmUnpkSptDatReq
*
*       Desc:  Unpack Data Request Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptDatReq
(
SptDatReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptDatReq(func, pst, mBuf)
SptDatReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpDatEvnt datEvnt;           /* data event struct */
   CmIntfVer intfVer;           /* interface version number */

   TRC3(cmUnpkSptDatReq)

   /* if rolling upgrade support is enabled, use interface version
    * as recvd in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG(cmUnpkSpConId, &datEvnt.conId, mBuf, ESPT105, pst);
         CMCHKUNPKLOG(SUnpkU8, &datEvnt.cfmReq, mBuf, ESPT106, pst);
#ifdef SPTV2
         /* initialize imp pres with default value notprsnt */
         datEvnt.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG(cmUnpkSpConId, &datEvnt.conId, mBuf, ESPT107, pst);
         CMCHKUNPKLOG(SUnpkU8, &datEvnt.cfmReq, mBuf, ESPT108, pst);
#ifdef SPTV2
         /* Unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &datEvnt.imp.pres, mBuf);
         /* if importance is present, Unpack importance value */
         if (datEvnt.imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &datEvnt.imp.val, mBuf);
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   (*func)(pst, &datEvnt, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptDatReq */


/*
*
*       Fun:   cmUnpkSptEDatReq
*
*       Desc:  Unpack Expedited Data Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptEDatReq
(
SptEDatReq func,                   /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptEDatReq(func, pst, mBuf)
SptEDatReq func;                   /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpConId conId;                  

   TRC3(cmUnpkSptEDatReq)

   CMCHKUNPKLOG( cmUnpkSpConId, &conId, mBuf, ESPT109, pst);
   (*func)(pst, &conId, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptEDatReq */


/*
*
*       Fun:   cmUnpkSptDatAckReq
*
*       Desc:  Unpack Data Acknowledgement Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptDatAckReq      
(
SptDatAckReq func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptDatAckReq(func, pst, mBuf)
SptDatAckReq func;                 /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpConId conId;

   TRC3(cmUnpkSptDatAckReq)

   CMCHKUNPKLOG( cmUnpkSpConId, &conId, mBuf, ESPT110, pst);
   SPutMsg(mBuf);
   (*func)(pst, &conId);

   RETVALUE(ROK);
} /* end of cmUnpkSptDatAckReq */


/*
*
*       Fun:   cmUnpkSptRstReq
*
*       Desc:  Unpack Reset Request Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptRstReq
(
SptRstReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptRstReq(func, pst, mBuf)
SptRstReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpRstEvnt rstEvnt;

   TRC3(cmUnpkSptRstReq)

   CMCHKUNPKLOG( cmUnpkSpConId, &rstEvnt.conId, mBuf, ESPT111, pst);
   CMCHKUNPKLOG( SUnpkU8, &rstEvnt.rsn, mBuf, ESPT112, pst);
   CMCHKUNPKLOG( SUnpkU8, &rstEvnt.orig, mBuf, ESPT113, pst);

   SPutMsg(mBuf);

   (*func)(pst, &rstEvnt);

   RETVALUE(ROK);
} /* end of cmUnpkSptRstReq */


/*
*
*       Fun:   cmUnpkSptRstRsp
*
*       Desc:  Unpack Reset Response Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptRstRsp
(
SptRstRsp func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptRstRsp(func, pst, mBuf)
SptRstRsp func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpRstEvnt rstEvnt;

   TRC3(cmUnpkSptRstRsp)

   CMCHKUNPKLOG( cmUnpkSpConId, &rstEvnt.conId, mBuf, ESPT114, pst);
   CMCHKUNPKLOG( SUnpkU8, &rstEvnt.rsn, mBuf, ESPT115, pst);
   CMCHKUNPKLOG( SUnpkU8, &rstEvnt.orig, mBuf, ESPT116, pst);
   SPutMsg(mBuf);
   (*func)(pst, &rstEvnt);

   RETVALUE(ROK);
} /* end of cmUnpkSptRstRsp */


/*
*
*       Fun:   cmUnpkSptDisReq
*
*       Desc:  Unpack Disconnect Request Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptDisReq
(
SptDisReq func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptDisReq(func, pst, mBuf)
SptDisReq func;                 /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   MsgLen len;                  /* message length */
   SpDisEvnt disEvnt;           /* disconnect event struct */
   CmIntfVer intfVer;           /* interface version number */

   TRC3(cmUnpkSptDisReq)

   /* if rolling upgrade support is enabled, use interface version
    * as recvd in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG(cmUnpkSpConId, &disEvnt.conId, mBuf, ESPT117, pst);
         CMCHKUNPKLOG(cmUnpkSpAddr, &disEvnt.rspAddr, mBuf, ESPT118, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.rsn, mBuf, ESPT119, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.orig, mBuf, ESPT120, pst);
#ifdef SPTV2
         /* initialize imp pres with default value notprsnt */
         disEvnt.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG(cmUnpkSpConId, &disEvnt.conId, mBuf, ESPT121, pst);
         CMCHKUNPKLOG(cmUnpkSpAddr, &disEvnt.rspAddr, mBuf, ESPT122, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.rsn, mBuf, ESPT123, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.orig, mBuf, ESPT124, pst);
#ifdef SPTV2
         /* Unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &disEvnt.imp.pres, mBuf);
         /* if importance is present, Unpack importance value */
         if (disEvnt.imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &disEvnt.imp.val, mBuf);
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */ 

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &disEvnt, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptDisReq */


/*
*
*       Fun:   cmUnpkSptInfReq
*
*       Desc:  Unpack Disconnect Request Event
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkSptInfReq
(
SptInfReq func,                    /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptInfReq(func, pst, mBuf)
SptInfReq func;                    /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpInfEvnt infEvnt;

   TRC3(cmUnpkSptInfReq)

   CMCHKUNPKLOG( cmUnpkSpConId, &infEvnt.conId, mBuf, ESPT125, pst);
   CMCHKUNPKLOG( cmUnpkSpQosSet, &infEvnt.qos, mBuf, ESPT126, pst);
   CMCHKUNPKLOG( SUnpkU8, &infEvnt.rsn, mBuf, ESPT127, pst);
   SPutMsg(mBuf);

   (*func)(pst, &infEvnt);
   RETVALUE(ROK);
} /* end of cmUnpkSptInfReq */

#endif  /* SPCO */ 

/*
*
*       Fun:   cmPkSptBndReq
*
*       Desc:  This function packs the SPT bind request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptBndReq
(
Pst    *pst,                    /* post structure */
SuId    suId,                   /* service user id */
SpId    spId,                   /* service provider id */
Ssn     ssn                     /* signaling system number */
)
#else
PUBLIC S16 cmPkSptBndReq(pst, suId, spId, ssn)
Pst    *pst;                    /* post structure */
SuId    suId;                   /* service user id */
SpId    spId;                   /* service provider id */
Ssn     ssn;                    /* signaling system number */
#endif
{
   Buffer    *mBuf;             /* message buffer */
   
   TRC3(cmPkSptBndReq)

   SPT_GETMSG(pst, mBuf, ESPT128);

   CMCHKPKLOG( cmPkSsn,  ssn,  mBuf, ESPT129, pst);
   CMCHKPKLOG( cmPkSpId, spId, mBuf, ESPT130, pst);
   CMCHKPKLOG( cmPkSuId, suId, mBuf, ESPT131, pst);

   pst->event = (Event)EVTSPTBNDREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptBndReq  */
  

/*
*
*       Fun:   cmPkSptUbndReq
*
*       Desc:  This function packs the SPT unbind request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptUbndReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Reason  reason                  /* reason */
)
#else
PUBLIC S16 cmPkSptUbndReq(pst, spId, reason)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Reason  reason;                 /* reason */
#endif
{
   Buffer    *mBuf;             /* message buffer */
   
   TRC3(cmPkSptUbndReq)

   SPT_GETMSG(pst, mBuf, ESPT132);

   CMCHKPKLOG( cmPkReason, reason, mBuf, ESPT133, pst);
   CMCHKPKLOG( cmPkSpId,   spId,   mBuf, ESPT134, pst);
   
   pst->event = (Event)EVTSPTUBNDREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptUbndReq  */


/*
*
*       Fun:   cmPkSptUDatReq
*
*       Desc:  This function packs the SPT unit data request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptUDatReq
(
Pst         *pst,               /* post structure */
SpId         spId,              /* service provider id */
SpUDatEvnt  *event,             /* SCCP event */
Buffer      *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmPkSptUDatReq(pst, spId, event, mBuf)
Pst         *pst;               /* post structure */
SpId         spId;              /* service provider id */
SpUDatEvnt  *event;             /* SCCP event */
Buffer      *mBuf;              /* message buffer */
#endif
{
   
   TRC3(cmPkSptUDatReq)

   CMCHKPKVERLOG(cmPkSpUDatEvnt, event, mBuf, ESPT135, pst);
   CMCHKPKLOG(cmPkSpId,       spId,  mBuf, ESPT136, pst);

   pst->event = (Event)EVTSPTUDATREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptUDatReq */

/* spt_c_003.main_13 - Addition - Unpack function for Unit data service 
 * request.
 */
#ifdef SPTV2_1

/*
*
*       Fun:   cmPkSptUDatSrvReq
*
*       Desc:  This function packs the SPT unit data service request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptUDatSrvReq
(
Pst         *pst,               /* post structure */
SpId         spId,              /* service provider id */
SpUDatEvnt  *event,             /* SCCP event */
Buffer      *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmPkSptUDatSrvReq(pst, spId, event, mBuf)
Pst         *pst;               /* post structure */
SpId         spId;              /* service provider id */
SpUDatEvnt  *event;             /* SCCP event */
Buffer      *mBuf;              /* message buffer */
#endif
{
   
   TRC3(cmPkSptUDatSrvReq)

   CMCHKPKVERLOG(cmPkSpUDatEvnt, event, mBuf, ESPTXXX, pst);
   CMCHKPKLOG(cmPkSpId,       spId,  mBuf, ESPTXXX, pst);

   pst->event = (Event)EVTSPTUDATSRVREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptUDatSrvReq */
#endif /* SPTV2_1 */


/*
*
*       Fun:   cmPkSptCordReq
*
*       Desc:  This function packs the Subsystem coordination request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptCordReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 cmPkSptCordReq(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   Buffer    *mBuf;

   TRC3(cmPkSptCordReq)

   SPT_GETMSG(pst, mBuf, ESPT137);

   CMCHKPKLOG(SPkU8,  aSsn, mBuf, ESPT138, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT139, pst);

   pst->event = EVTSPTCRDREQ;

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptCordReq */
  

/*
*
*       Fun:   cmPkSptCordRsp
*
*       Desc:  This function packs the Subsystem Coordination Response
*              
*       Ret:   ROK
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptCordRsp
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn                    /* affected subsystem number */
)
#else
PUBLIC S16 cmPkSptCordRsp(pst, spId, aSsn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
#endif
{
   Buffer   *mBuf;

   TRC3(cmPkSptCordRsp)

   SPT_GETMSG(pst, mBuf, ESPT140);

   CMCHKPKLOG(SPkU8,  aSsn, mBuf, ESPT141, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT142, pst);

   pst->event = EVTSPTCRDRSP;

   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
}  /* end of cmPkSptCordRsp */
  

/*
*
*       Fun:   cmPkSptSteReq
*
*       Desc:  This function packs the Subsystem State Change Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
Ssn     aSsn,                   /* affected subsystem number */
UStat   uStat                   /* User Status */
)
#else
PUBLIC S16 cmPkSptSteReq(pst, spId, aSsn, uStat)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
Ssn     aSsn;                   /* affected subsystem number */
UStat   uStat;                  /* User Status */
#endif
{
   Buffer   *mBuf;

   TRC3(cmPkSptSteReq)

   SPT_GETMSG(pst, mBuf, ESPT143);

   CMCHKPKLOG(SPkU8,  uStat, mBuf, ESPT144, pst);
   CMCHKPKLOG(SPkU8,  aSsn,  mBuf, ESPT145, pst);
   CMCHKPKLOG(SPkS16, spId,  mBuf, ESPT146, pst);

   pst->event = EVTSPTSTEREQ;

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptSteReq */


#ifdef SPT2
/*
*
*       Fun:   cmPkSptStaReq 
*
*       Desc:  This function packs the Point code and subsyatem
*              status request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptStaReq
(
Pst    *pst,                    /* post structure */
SpId    spId,                   /* service provider id */
U8      status,                 /* Type of status */
Dpc     dpc,                    /* Destination point code */
Ssn     ssn                     /* affected subsystem number */
)
#else
PUBLIC S16 cmPkSptStaReq(pst, spId, status, dpc, ssn)
Pst    *pst;                    /* post structure */
SpId    spId;                   /* service provider id */
U8      status;                 /* Type of status */
Dpc     dpc;                    /* Destination point code */
Ssn     ssn;                    /* affected subsystem number */
#endif
{
   Buffer   *mBuf;

   TRC3(cmPkSptStaReq)

   SPT_GETMSG(pst, mBuf, ESPT147);

   CMCHKPKLOG(SPkU8,  ssn,    mBuf, ESPT148, pst);
   CMCHKPKLOG(SPkU32, dpc,    mBuf, ESPT149, pst);
   CMCHKPKLOG(SPkU8,  status, mBuf, ESPT150, pst);
   CMCHKPKLOG(SPkS16, spId,   mBuf, ESPT151, pst);

   pst->event = EVTSPTSTAREQ;

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptStaReq */
#endif /* SPT2 */

/*
*
*       Fun:   cmUnpkSptUDatInd
*
*       Desc:  This function Unpacks the SCCP Unit Data Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptUDatInd
(
SptUDatInd    func,         /* call back function */
Pst          *pst,          /* post */
Buffer       *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptUDatInd(func, pst, mBuf)
SptUDatInd    func;         /* call back function */
Pst          *pst;          /* post */
Buffer       *mBuf;         /* message buffer */
#endif
{
   SuId       suId;         /* service user id */
   Dpc        opc;          /* calling address Dpc */
   SpUDatEvnt uData;        /* Unit data event */
   
   TRC3(cmUnpkSptUDatInd)

   CMCHKUNPKLOG(cmUnpkSuId, &suId, mBuf, ESPT152, pst); 
   CMCHKUNPKLOG(cmUnpkDpc, &opc, mBuf, ESPT153, pst); 
   CMCHKUNPKVERLOG(cmUnpkSpUDatEvnt, &uData, mBuf, ESPT154, pst); 

   (*func)(pst, suId, opc, &uData, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptUDatInd */


/*
*
*       Fun:   cmUnpkSptStaInd
*
*       Desc:  This function Unpacks the SCCP Status Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptStaInd
(
SptStaInd    func,          /* call back function */
Pst         *pst,           /* post */
Buffer      *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptStaInd(func, pst, mBuf)
SptStaInd    func;          /* call back function */
Pst         *pst;           /* post */
Buffer      *mBuf;          /* message buffer */
#endif
{
   SuId       suId;         /* service user id */
   Dpc        opc;          /* calling address Dpc */
   SpUDatEvnt uData;        /* Unit data event */
   RCause     retCause;     /* return cause */
   
   TRC3(cmUnpkSptStaInd)

   CMCHKUNPKLOG(cmUnpkSuId, &suId, mBuf, ESPT155, pst); 
   CMCHKUNPKLOG(cmUnpkDpc, &opc, mBuf, ESPT156, pst); 
   CMCHKUNPKVERLOG(cmUnpkSpUDatEvnt, &uData, mBuf, ESPT157, pst); 
   CMCHKUNPKLOG(cmUnpkRCause, &retCause, mBuf, ESPT158, pst); 

   (*func)(pst, suId, opc, &uData, retCause, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptStaInd */


/*
*
*       Fun:   cmUnpkSptCordInd
*
*       Desc:  This function Unpacks the SCCP Cord Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptCordInd
(
SptCordInd    func,         /* call back function */
Pst          *pst,          /* post */
Buffer       *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptCordInd(func, pst, mBuf)
SptCordInd    func;         /* call back function */
Pst          *pst;          /* post */
Buffer       *mBuf;         /* message buffer */
#endif
{
   SuId    suId;
   Ssn     aSsn;
   Smi     smi;
   
   TRC3(cmUnpkSptCordInd)

   CMCHKUNPKLOG( cmUnpkSuId, &suId, mBuf, ESPT159, pst); 
   CMCHKUNPKLOG( cmUnpkSsn,  &aSsn, mBuf, ESPT160, pst); 
   CMCHKUNPKLOG( cmUnpkSmi,  &smi,  mBuf, ESPT161, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, suId, aSsn, smi);

   RETVALUE(ROK);
} /* end of cmUnpkSptCordInd */


/*
*
*       Fun:   cmUnpkSptCordCfm
*
*       Desc:  This function Unpacks the SCCP Cord Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptCordCfm
(
SptCordCfm    func,         /* call back function */
Pst          *pst,          /* post */
Buffer       *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptCordCfm(func, pst, mBuf)
SptCordCfm    func;         /* call back function */
Pst          *pst;          /* post */
Buffer       *mBuf;         /* message buffer */
#endif
{
   SuId    suId;
   Ssn     aSsn;
   Smi     smi;
   
   TRC3(cmUnpkSptCordCfm)

   CMCHKUNPKLOG( cmUnpkSuId, &suId, mBuf, ESPT162, pst); 
   CMCHKUNPKLOG( cmUnpkSsn,  &aSsn, mBuf, ESPT163, pst); 
   CMCHKUNPKLOG( cmUnpkSmi,  &smi,  mBuf, ESPT164, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, suId, aSsn, smi);

   RETVALUE(ROK);
} /* end of cmUnpkSptCordCfm */


/*
*
*       Fun:   cmUnpkSptSteInd
*
*       Desc:  This function Unpacks the SCCP Status Element Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteInd
(
SptSteInd    func,          /* call back function */
Pst         *pst,           /* post */
Buffer      *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptSteInd(func, pst, mBuf)
SptSteInd    func;          /* call back function */
Pst         *pst;           /* post */
Buffer      *mBuf;          /* message buffer */
#endif
{
   SuId    suId;
   Dpc     aDpc;
   Ssn     aSsn;
   Smi     smi;
   UStat   uStat;
   
   TRC3(cmUnpkSptSteInd)

   CMCHKUNPKLOG( cmUnpkSuId,  &suId,  mBuf, ESPT165, pst); 
   CMCHKUNPKLOG( cmUnpkDpc,   &aDpc,  mBuf, ESPT166, pst); 
   CMCHKUNPKLOG( cmUnpkSsn,   &aSsn,  mBuf, ESPT167, pst); 
   CMCHKUNPKLOG( cmUnpkUStat, &uStat, mBuf, ESPT168, pst); 
   CMCHKUNPKLOG( cmUnpkSmi,   &smi,   mBuf, ESPT169, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, suId, aDpc, aSsn, uStat, smi);

   RETVALUE(ROK);
} /* end of cmUnpkSptSteInd */


/*
*
*       Fun:   cmUnpkSptPCSteInd
*
*       Desc:  This function Unpacks the SCCP PC Status Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteInd
(
SptPCSteInd    func,        /* call back function */
Pst           *pst,         /* post */
Buffer        *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptPCSteInd(func, pst, mBuf)
SptPCSteInd    func;        /* call back function */
Pst           *pst;         /* post */
Buffer        *mBuf;        /* message buffer */
#endif
{
   SuId      suId;          /* service user sap id */
   Dpc       aDpc;          /* affedcted point code */
   Sps       sps;           /* status of affedted point code */
   CmIntfVer intfVer;       /* interface versionn number */
#ifdef SPTV2
   U8        sccpState;     /* remote sccp status */
   U8        ril;           /* restrictied importance level */
#endif /* SPTV2 */
   
   TRC3(cmUnpkSptPCSteInd)

   /* if rolling upgrade support is enabled, use interface verison
    * as in pst-intfVer, else use self SPT interface version
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack parameters based on received remote interface version num */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG( cmUnpkSuId, &suId, mBuf, ESPT170, pst); 
         CMCHKUNPKLOG( cmUnpkDpc,  &aDpc, mBuf, ESPT171, pst); 
         CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT172, pst); 
#ifdef SPTV2
         /* assign default values to sccpState and ril */
         sccpState = SPTIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
         ril = SPTIF_VER2_STEIND_DEF_RIL_VAL;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG( cmUnpkSuId, &suId, mBuf, ESPT173, pst); 
         CMCHKUNPKLOG( cmUnpkDpc,  &aDpc, mBuf, ESPT174, pst); 
         CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT175, pst); 
#ifdef SPTV2
         CMCHKUNPKLOG(SUnpkU8,  &sccpState,  mBuf, ESPT176, pst); 
         CMCHKUNPKLOG(SUnpkU8,  &ril,  mBuf, ESPT177, pst); 
#endif /* SPTV2 */
         break;

      default:
         /* invalid remote interface interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   (Void)SPutMsg(mBuf);

#ifdef SPTV2
   (*func)(pst, suId, aDpc, sps, sccpState, ril);
#else
   (*func)(pst, suId, aDpc, sps);
#endif /* SPTV2 */

   RETVALUE(ROK);
} /* end of cmUnpkSptPCSteInd */

#ifdef SPT2

/*
*
*       Fun:   cmUnpkSptBndCfm
*
*       Desc:  This function Unpacks the SCCP Bind Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptBndCfm
(
SptBndCfm    func,          /* call back function */
Pst         *pst,           /* post */
Buffer      *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptBndCfm(func, pst, mBuf)
SptBndCfm    func;          /* call back function */
Pst         *pst;           /* post */
Buffer      *mBuf;          /* message buffer */
#endif
{
   SuId    suId;
   U8      status;
   
   TRC3(cmUnpkSptBndCfm)

   CMCHKUNPKLOG( cmUnpkSuId, &suId,   mBuf, ESPT178, pst); 
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT179, pst); 

   (Void)SPutMsg(mBuf);

   (*func)(pst, suId, status);

   RETVALUE(ROK);
} /* end of cmUnpkSptBndCfm */


/*
*
*       Fun:   cmUnpkSptSteCfm
*
*       Desc:  This function Unpacks the SCCP State change Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteCfm
(
SptSteCfm    func,          /* call back function */
Pst         *pst,           /* post */
Buffer      *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptSteCfm(func, pst, mBuf)
SptSteCfm    func;          /* call back function */
Pst         *pst;           /* post */
Buffer      *mBuf;          /* message buffer */
#endif
{
   SuId    suId;
   U8      status;
   
   TRC3(cmUnpkSptSteCfm)

   CMCHKUNPKLOG( cmUnpkSuId, &suId,   mBuf, ESPT180, pst); 
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT181, pst); 

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, suId, status));

} /* end of cmUnpkSptSteCfm */


/*
*
*       Fun:   cmUnpkSptStaCfm
*
*       Desc:  This function Unpacks the SCCP Point Code/Subsystem
*              status Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptStaCfm
(
SptStaCfm    func,          /* call back function */
Pst         *pst,           /* post */
Buffer      *mBuf           /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptStaCfm(func, pst, mBuf)
SptStaCfm    func;          /* call back function */
Pst         *pst;           /* post */
Buffer      *mBuf;          /* message buffer */
#endif
{
   CmIntfVer intfVer;       /* interface version number */
   SuId    suId;            /* service user sap id */
   U8      status;          /* point code status */
   Dpc     dpc;             /* point code */
   Ssn     ssn;             /* subsystem number */
   UStat   ustat;           /* subsystem(user) status */
   Smi     smi;             /* subsystem multiplicity indicator */
#ifdef SPTV2
   U8 sccpState;            /* remote sccp status */
   U8 ril;                  /* restiricted importance level */
#endif /* SPTV2 */
 
   /* if rolling upgrade support is enabled, use interface verison
    * as in pst-intfVer, else use self SPT interface version
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC3(cmUnpkSptStaCfm)

   /* unpcak parameters based on received remote interface version number */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG(cmUnpkSuId, &suId, mBuf, ESPT182, pst); 
         CMCHKUNPKLOG(SUnpkU8, &status, mBuf, ESPT183, pst); 
         CMCHKUNPKLOG(cmUnpkDpc, &dpc, mBuf, ESPT184, pst); 
         CMCHKUNPKLOG(cmUnpkSsn, &ssn, mBuf, ESPT185, pst); 
         CMCHKUNPKLOG(cmUnpkUStat, &ustat, mBuf, ESPT186, pst); 
         CMCHKUNPKLOG(cmUnpkSmi, &smi, mBuf, ESPT187, pst); 
#ifdef SPTV2
         /* assign default values to sccp state and ril */
         sccpState = SPTIF_VER2_STEIND_DEF_SCCPSTATE_VAL;
         ril = SPTIF_VER2_STEIND_DEF_RIL_VAL;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG(cmUnpkSuId, &suId, mBuf, ESPT188, pst); 
         CMCHKUNPKLOG(SUnpkU8, &status, mBuf, ESPT189, pst); 
         CMCHKUNPKLOG(cmUnpkDpc, &dpc, mBuf, ESPT190, pst); 
         CMCHKUNPKLOG(cmUnpkSsn, &ssn, mBuf, ESPT191, pst); 
         CMCHKUNPKLOG(cmUnpkUStat, &ustat, mBuf, ESPT192, pst); 
         CMCHKUNPKLOG(cmUnpkSmi, &smi, mBuf, ESPT193, pst); 
#ifdef SPTV2
         CMCHKUNPKLOG(SUnpkU8, &sccpState,    mBuf, ESPT194, pst); 
         CMCHKUNPKLOG(SUnpkU8, &ril,    mBuf, ESPT195, pst); 
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

#ifdef SPTV2
   (*func)(pst, suId, status, dpc, ssn, ustat, smi, sccpState, ril);
#else
   (*func)(pst, suId, status, dpc, ssn, ustat, smi);
#endif /* SPTV2 */

   (Void)SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptStaCfm */
#endif /* SPT2 */

#ifdef SPCO
  
/*
*
*       Fun:   Pack SPT - SCCP Connection Request
*
*       Desc:  Pack Connection Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptConReq
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmPkSptConReq(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(cmPkSptConReq);

   if (!mBuf)
   {
      SPT_GETMSG(pst, mBuf, ESPT196);
   }
 
   CMCHKPKVERLOG(cmPkSpConEvnt, conEvnt, mBuf, ESPT197, pst);
   pst->event = EVTSPTCONREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptConReq */

  
/*
*
*       Fun:   Pack SPT - SCCP Connection Response
*
*       Desc:  Pack Connection Response Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSptConRsp
(
Pst *pst,                       /* post structure */
SpConEvnt *conEvnt,             /* connection event */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmPkSptConRsp(pst, conEvnt, mBuf)
Pst *pst;                       /* post structure */
SpConEvnt *conEvnt;             /* connection event */
Buffer *mBuf;                   /* message buffer */
#endif
{
   TRC3(cmPkSptConRsp);

   if (!mBuf)
   {
      SPT_GETMSG(pst, mBuf, ESPT198);
   }
 
   CMCHKPKVERLOG(cmPkSpConEvnt, conEvnt, mBuf, ESPT199, pst);
   pst->event = EVTSPTCONRSP;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
}  /* end of cmPkSptConRsp */

  
/*
*
*       Fun:   Pack SPT - SCCP Data Request
*
*       Desc:  Pack Data Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDatReq
(
Pst *pst,                       /* post structure */
SpDatEvnt *datEvnt,             /* data event */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmPkSptDatReq(pst, datEvnt, mBuf)
Pst *pst;                       /* post structure */
SpDatEvnt *datEvnt;             /* data event */
Buffer *mBuf;                   /* message buffer */
#endif
{
   CmIntfVer intfVer;           /* interface version number */

   TRC3(cmPkSptDatReq);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, datEvnt->cfmReq, mBuf, ESPT200, pst);
         CMCHKPKLOG(cmPkSpConId, &datEvnt->conId, mBuf, ESPT201, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         /* if importance is present, pack importance value */
         if (datEvnt->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, datEvnt->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, datEvnt->imp.pres, mBuf);
#endif /* SPTV2 */
         CMCHKPKLOG(SPkU8, datEvnt->cfmReq, mBuf, ESPT202, pst);
         CMCHKPKLOG(cmPkSpConId, &datEvnt->conId, mBuf, ESPT203, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   }

   pst->event = EVTSPTDATREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptDatReq */

  
/*
*
*       Fun:   Pack SPT - SCCP Expedited Data Request
*
*       Desc:  Pack Expedited Data Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptEDatReq
(
Pst *pst,             /* post structure */
SpConId *conId,             /* connection id */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmPkSptEDatReq(pst, conId, mBuf)
Pst *pst;             /* post structure */
SpConId *conId;             /* connection id */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC3(cmPkSptEDatReq);       

   CMCHKPKLOG(cmPkSpConId, conId, mBuf, ESPT204, pst);
   pst->event = EVTSPTEDATREQ;
   
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptEDatReq */


/*
*
*       Fun:   Pack SPT - SCCP Data Acknowledgment Request
*
*       Desc:  Pack Expedited Data Acknowledgment Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDatAckReq
(
Pst *pst,             /* post structure */
SpConId *conId              /* connection id */
)
#else
PUBLIC S16 cmPkSptDatAckReq(pst, conId)
Pst *pst;             /* post structure */
SpConId *conId;             /* connection id */
#endif
{
   Buffer *mBuf;                      

   TRC3(cmPkSptDatAckReq);

   SPT_GETMSG(pst, mBuf, ESPT205);
 
   CMCHKPKLOG(cmPkSpConId, conId, mBuf, ESPT206, pst);
   pst->event = EVTSPTDATACKREQ;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}  /* end of cmPkSptDatAckReq */

  
/*
*
*       Fun:   Pack SPT - SCCP Reset Request
*
*       Desc:  Pack Reset Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptRstReq
(
Pst *pst,                       /* post structure */
SpRstEvnt *rstEvnt              /* reset event */
)
#else
PUBLIC S16 cmPkSptRstReq(pst, rstEvnt)
Pst *pst;                       /* post structure */
SpRstEvnt *rstEvnt;             /* reset event */
#endif
{
   Buffer *mBuf;
 
   TRC3(cmPkSptRstReq);
  
   SPT_GETMSG(pst, mBuf, ESPT207);
  
   CMCHKPKLOG(SPkU8,rstEvnt->orig, mBuf, ESPT208, pst);
   CMCHKPKLOG(SPkU8,rstEvnt->rsn, mBuf, ESPT209, pst);
   CMCHKPKLOG(cmPkSpConId,&rstEvnt->conId, mBuf, ESPT210, pst);
   pst->event = EVTSPTRSTREQ;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
}  /* end of cmPkSptRstReq */
  
/*
*
*       Fun:   Pack SPT - SCCP Reset Response
*
*       Desc:  Pack Reset Response Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptRstRsp
(
Pst *pst,             /* post structure */
SpRstEvnt *rstEvnt          /* reset event */
)
#else
PUBLIC S16 cmPkSptRstRsp(pst, rstEvnt)
Pst *pst;             /* post structure */
SpRstEvnt *rstEvnt;         /* reset event */
#endif
{
   Buffer *mBuf;
 
   TRC3(cmPkSptRstRsp);
  
   SPT_GETMSG(pst, mBuf, ESPT211);
 
   CMCHKPKLOG(SPkU8, rstEvnt->orig, mBuf, ESPT212, pst);
   CMCHKPKLOG(SPkU8, rstEvnt->rsn, mBuf, ESPT213, pst);
   CMCHKPKLOG(cmPkSpConId, &rstEvnt->conId, mBuf, ESPT214, pst);
   pst->event = EVTSPTRSTRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptRstRsp */

  
/*
*
*       Fun:   Pack SPT - SCCP Disconnect Request
*
*       Desc:  Pack Disconnect Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptDisReq
(
Pst *pst,                   /* post structure */
SpDisEvnt *disEvnt,         /* connection id */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmPkSptDisReq(pst, disEvnt, mBuf)
Pst *pst;                   /* post structure */
SpDisEvnt *disEvnt;         /* connection id */
Buffer *mBuf;               /* message buffer */
#endif
{
   U8 len;                  /* length */
   /* spt_c_001.main_13 - missing semicolon */
   CmIntfVer intfVer;       /* interface version number */
 
   TRC3(spPkUiSptDisReq)
  
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   if (!mBuf)
   {
      SPT_GETMSG(pst, mBuf, ESPT215);
   }  
 
   /* pack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKPKLOG(SPkU8, disEvnt->orig, mBuf, ESPT216, pst);
         CMCHKPKLOG(SPkU8, disEvnt->rsn, mBuf, ESPT217, pst);
         cmPkSpAddr(&disEvnt->rspAddr, mBuf, &len);
         CMCHKPKLOG(cmPkSpConId, &disEvnt->conId, mBuf, ESPT218, pst);
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
#ifdef SPTV2
         /* if importance is present, pack importance value */
         if (disEvnt->imp.pres != NOTPRSNT)
            CMCHKPK(SPkU8, disEvnt->imp.val, mBuf);
         /* pack imp pres field */
         CMCHKPK(SPkU8, disEvnt->imp.pres, mBuf);
#endif /* SPTV2 */

         CMCHKPKLOG(SPkU8, disEvnt->orig, mBuf, ESPT219, pst);
         CMCHKPKLOG(SPkU8, disEvnt->rsn, mBuf, ESPT220, pst);
         cmPkSpAddr(&disEvnt->rspAddr, mBuf, &len);
         CMCHKPKLOG(cmPkSpConId, &disEvnt->conId, mBuf, ESPT221, pst);
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   }

   pst->event = EVTSPTDISREQ;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
}  /* end of cmPkSptDisReq */

  
/*
*
*       Fun:   Upper interface - SCCP Inform Request
*
*       Desc:  Inform Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptInfReq
(
Pst *pst,                       /* post structure */
SpInfEvnt *infEvnt              /* info event */
)
#else
PUBLIC S16 cmPkSptInfReq(pst, infEvnt)
Pst *pst;                       /* post structure */
SpInfEvnt *infEvnt;             /* info event*/
#endif
{
   Buffer *mBuf;
 
   TRC3(cmPkSptInfReq);
  
   SPT_GETMSG(pst, mBuf, ESPT222);

   CMCHKPKLOG(SPkU8, infEvnt->rsn, mBuf, ESPT223, pst);
   CMCHKPKLOG(cmPkSpQosSet, &infEvnt->qos, mBuf, ESPT224, pst);
   CMCHKPKLOG(cmPkSpConId, &infEvnt->conId, mBuf, ESPT225, pst);
   pst->event = EVTSPTCNSTREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}  /* end of cmPkSptInfReq */

#ifdef SPTV2
  
/*
*
*       Fun:   Pack SPT - Audit Request
*
*       Desc:  Pack Audit Request Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptAudReq
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 cmPkSptAudReq(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   Buffer *mBuf;                /* message buffer */
 
   TRC3(cmPkSptAudReq);
  
   SPT_GETMSG(pst, mBuf, ESPT226);
  
   CMCHKPKLOG(SPkU8, audEvnt->state, mBuf, ESPT227, pst);
   CMCHKPKLOG(cmPkSpConId, &audEvnt->conId, mBuf, ESPT228, pst);
   pst->event = EVTSPTAUDREQ;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* cmPkSptAudReq */


/*
*
*       Fun:   cmUnpkSptAudReq
*
*       Desc:  Unpack Audit Request Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptAudReq
(
SptAudReq func,              /* primitive to call */
Pst *pst,                    /* post structure */
Buffer *mBuf                 /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptAudReq(func, pst, mBuf)
SptAudReq func;              /* primitive to call */
Pst *pst;                    /* post structure */
Buffer *mBuf;                /* message buffer */
#endif
{
   SpAudEvnt audEvnt;        /* audit event struct */

   TRC3(cmUnpkSptAudReq)

   CMCHKUNPKLOG(cmUnpkSpConId, &audEvnt.conId, mBuf, ESPT229, pst);
   CMCHKUNPKLOG(SUnpkU8, &audEvnt.state, mBuf, ESPT230, pst);

   SPutMsg(mBuf);

   (*func)(pst, &audEvnt);
   RETVALUE(ROK);
} /* cmUnpkSptAudReq */

  
/*
*
*       Fun:   Pack SPT - Audit Response
*
*       Desc:  Pack Audit Response Event
*              
*
*       Ret:   ROK
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptAudRsp
(
Pst *pst,                   /* post structure */
SpAudEvnt *audEvnt          /* audit event */
)
#else
PUBLIC S16 cmPkSptAudRsp(pst, audEvnt)
Pst *pst;                   /* post structure */
SpAudEvnt *audEvnt;         /* audit event */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkSptAudRsp);
  
   SPT_GETMSG(pst, mBuf, ESPT231);
 
   CMCHKPKLOG(SPkU8, audEvnt->state, mBuf, ESPT232, pst);
   CMCHKPKLOG(cmPkSpConId, &audEvnt->conId, mBuf, ESPT233, pst);
   pst->event = EVTSPTAUDRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* cmPkSptAudRsp */


/*
*
*       Fun:   cmUnpkSptAudRsp
*
*       Desc:  Unpack Audit Response Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptAudRsp
(
SptAudRsp func,               /* primitive to call */
Pst *pst,                     /* post structure */
Buffer *mBuf                  /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptAudRsp(func, pst, mBuf)
SptAudRsp func;               /* primitive to call */
Pst *pst;                     /* post structure */
Buffer *mBuf;                 /* message buffer */
#endif
{
   SpAudEvnt audEvnt;         /* audit event struct */

   TRC3(cmUnpkSptAudRsp)

   CMCHKUNPKLOG(cmUnpkSpConId, &audEvnt.conId, mBuf, ESPT234, pst);
   CMCHKUNPKLOG(SUnpkU8, &audEvnt.state, mBuf, ESPT235, pst);

   SPutMsg(mBuf);

   (*func)(pst, &audEvnt);
   RETVALUE(ROK);
} /* cmUnpkSptAudRsp */

 
/*
*
*       Fun:   Audit Indication
*
*       Desc:  Pack - Audit Indication
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptAudInd
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 cmPkSptAudInd(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   Buffer *mBuf;                /* message buffer */

   TRC3(cmPkSptAudInd)
     
   SPT_GETMSG(pst, mBuf, ESPT236)

   CMCHKPKLOG(SPkU8, audEvnt->state, mBuf, ESPT237, pst);
   CMCHKPKLOG(cmPkSpConId, &audEvnt->conId, mBuf, ESPT238, pst);
   pst->event = EVTSPTAUDIND;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);

} /* cmPkSptAudInd */


/*
*
*       Fun:   cmUnpkSptAudInd
*
*       Desc:  Unpack Audit Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptAudInd
(
SptAudInd func,               /* primitive to call */
Pst *pst,                     /* post structure */
Buffer *mBuf                  /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptAudInd(func, pst, mBuf)
SptAudInd func;               /* primitive to call */
Pst *pst;                     /* post structure */
Buffer *mBuf;                 /* message buffer */
#endif
{
   SpAudEvnt audEvnt;         /* audit event struct */

   TRC3(cmUnpkSptAudInd)

   CMCHKUNPKLOG(cmUnpkSpConId, &audEvnt.conId, mBuf, ESPT239, pst);
   CMCHKUNPKLOG(SUnpkU8, &audEvnt.state, mBuf, ESPT240, pst);

   SPutMsg(mBuf);

   (*func)(pst, &audEvnt);
   RETVALUE(ROK);
} /* cmUnpkSptAudInd */

 
/*
*
*       Fun:   Audit Confirmation
*
*       Desc:  Pack - Audit Confirmation
*
*
*       Ret:   ROK   - ok
*
*       Notes: Connection Oriented
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptAudCfm
(
Pst *pst,                       /* post structure */
SpAudEvnt *audEvnt              /* audit event */
)
#else
PUBLIC S16 cmPkSptAudCfm(pst, audEvnt)
Pst *pst;                       /* post structure */
SpAudEvnt *audEvnt;             /* audit event */
#endif
{
   Buffer *mBuf;                /* message buffer */

   TRC3(cmPkSptAudCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT241)
   
   CMCHKPKLOG(SPkU8, audEvnt->state, mBuf, ESPT242, pst);
   CMCHKPKLOG(cmPkSpConId, &audEvnt->conId, mBuf, ESPT243, pst);
   pst->event = EVTSPTAUDCFM;
   SPstTsk(pst, mBuf);
   
   RETVALUE(ROK);
} /* cmPkSptAudCfm */


/*
*
*       Fun:   cmUnpkSptAudCfm
*
*       Desc:  Unpack Audit Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptAudCfm
(
SptAudCfm func,          /* primitive to call */
Pst *pst,                /* post structure */
Buffer *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptAudCfm(func, pst, mBuf)
SptAudCfm func;          /* primitive to call */
Pst *pst;                /* post structure */
Buffer *mBuf;            /* message buffer */
#endif
{
   SpAudEvnt audEvnt;    /* audit event struct */

   TRC3(cmUnpkSptAudCfm)

   CMCHKUNPKLOG(cmUnpkSpConId, &audEvnt.conId, mBuf, ESPT244, pst);
   CMCHKUNPKLOG(SUnpkU8, &audEvnt.state, mBuf, ESPT245, pst);

   SPutMsg(mBuf);

   (*func)(pst, &audEvnt);
   RETVALUE(ROK);
} /* cmUnpkSptAudCfm */
#endif /* SPTV2 */


/*
*
*       Fun:   cmUnpkSptConInd
*
*       Desc:  Unpack Connection Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptConInd
(
SptConInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptConInd(func, pst, mBuf)
SptConInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpConEvnt conEvnt;
   MsgLen    len;

   TRC3(cmUnpkSptConInd)

   CMCHKUNPKVERLOG(cmUnpkSpConEvnt, &conEvnt, mBuf, ESPT246, pst );

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &conEvnt, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptConInd */

/*
*
*       Fun:   cmUnpkSptConCfm
*
*       Desc:  Unpack Connection Confirm Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptConCfm
(
SptConCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptConCfm(func, pst, mBuf)
SptConCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpConEvnt conEvnt;
   MsgLen    len;

   TRC3(cmUnpkSptConCfm)

   CMCHKUNPKVERLOG(cmUnpkSpConEvnt, &conEvnt, mBuf, ESPT247, pst);

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &conEvnt, mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkSptConCfm */

/*
*
*       Fun:   cmUnpkSptDatInd
*
*       Desc:  Unpack Data Induest Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptDatInd
(
SptDatInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptDatInd(func, pst, mBuf)
SptDatInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpDatEvnt datEvnt;     /* data event struct */
   CmIntfVer intfVer;     /* interface version number */

   TRC3(cmUnpkSptDatInd)

   /* if rolling upgrade support is enabled, use interface version
    * as recvd in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG(cmUnpkSpConId, &datEvnt.conId, mBuf, ESPT248, pst);
         CMCHKUNPKLOG(SUnpkU8, &datEvnt.cfmReq, mBuf, ESPT249, pst);
#ifdef SPTV2
         /* initialize imp pres with default value notprsnt */
         datEvnt.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
         break;
 
      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG(cmUnpkSpConId, &datEvnt.conId, mBuf, ESPT250, pst);
         CMCHKUNPKLOG(SUnpkU8, &datEvnt.cfmReq, mBuf, ESPT251, pst);
#ifdef SPTV2
         /* unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &datEvnt.imp.pres, mBuf);
         /* if importance is present, unpack importance value */
         if (datEvnt.imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &datEvnt.imp.val, mBuf);
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   }

   (*func)(pst, &datEvnt, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSptDatInd */

/*
*
*       Fun:   cmUnpkSptEDatInd
*
*       Desc:  Unpack Expedited Data Indicaion Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptEDatInd
(
SptEDatInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptEDatInd(func, pst, mBuf)
SptEDatInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpConId conId;

   TRC3(cmUnpkSptEDatInd)

   CMCHKUNPKLOG(cmUnpkSpConId,&conId, mBuf, ESPT252, pst);   
   (*func)(pst, &conId, mBuf);
   RETVALUE(ROK);

} /* end of cmUnpkSptEDatInd */


/*
*
*       Fun:   cmUnpkSptDatAckInd
*
*       Desc:  Unpack Data Acknowledgement Indication
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptDatAckInd
(
SptDatAckInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptDatAckInd(func, pst, mBuf)
SptDatAckInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpConId conId;

   TRC3(cmUnpkSptDatAckReq)

   CMCHKUNPKLOG(cmUnpkSpConId,&conId, mBuf, ESPT253, pst);
   
   SPutMsg(mBuf);
   (*func)(pst, &conId);
   RETVALUE(ROK);
} /* end of cmUnpkSptDatAckInd */


/*
*
*       Fun:   cmUnpkSptRstReq
*
*       Desc:  Unpack Reset Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptRstInd
(
SptRstInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptRstInd(func, pst, mBuf)
SptRstInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpRstEvnt rstEvnt;

   TRC3(cmUnpkSptRstInd)

   CMCHKUNPKLOG(cmUnpkSpConId, &rstEvnt.conId, mBuf, ESPT254, pst);
   CMCHKUNPKLOG(SUnpkU8, &rstEvnt.rsn, mBuf, ESPT255, pst);
   CMCHKUNPKLOG(SUnpkU8, &rstEvnt.orig, mBuf, ESPT256, pst);

   SPutMsg(mBuf);

   (*func)(pst, &rstEvnt);
   RETVALUE(ROK);
} /* end of cmUnpkSptRstInd */

/*
*
*       Fun:   cmUnpkSptRstCfm
*
*       Desc:  Unpack Reset Confirm Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptRstCfm
(
SptRstCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptRstCfm(func, pst, mBuf)
SptRstCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpRstEvnt rstEvnt;

   TRC3(cmUnpkSptRstCfm)

   CMCHKUNPKLOG(cmUnpkSpConId, &rstEvnt.conId, mBuf, ESPT257, pst);
   CMCHKUNPKLOG(SUnpkU8, &rstEvnt.rsn, mBuf, ESPT258, pst);
   CMCHKUNPKLOG(SUnpkU8, &rstEvnt.orig, mBuf, ESPT259, pst);

   SPutMsg(mBuf);

   (*func)(pst, &rstEvnt);
   RETVALUE(ROK);

} /* end of cmUnpkSptRstCfm */

/*
*
*       Fun:   cmUnpkSptDisInd
*
*       Desc:  Unpack Disconnect Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptDisInd
(
SptDisInd func,             /* primitive to call */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSptDisInd(func, pst, mBuf)
SptDisInd func;             /* primitive to call */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SpDisEvnt disEvnt;       /* disconnect event struct */
   MsgLen    len;           /* message length */
   CmIntfVer intfVer;       /* interface version number */

   TRC3(cmUnpkSptDisInd)

   /* if rolling upgrade support is enabled, use interface version
    * as recvd in pst-intfVer, else use self SPT intf version.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = SPTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* unpack fields depending on intfVer */
   switch (intfVer)
   {
      case 0x0100:      /* interface version SPTV1 */
         CMCHKUNPKLOG(cmUnpkSpConId, &disEvnt.conId, mBuf, ESPT260, pst);
         CMCHKUNPKLOG(cmUnpkSpAddr, &disEvnt.rspAddr, mBuf, ESPT261, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.rsn, mBuf, ESPT262, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.orig, mBuf, ESPT263, pst);
#ifdef SPTV2
         /* initialize imp pres with default value notprsnt */
         disEvnt.imp.pres = NOTPRSNT;
#endif /* SPTV2 */
         break;

      case 0x0200:      /* interface version SPTV2 */
      case 0x0201:  /* spt_c_003.main_13 -Addition - interface version SPTV2_1*/
         CMCHKUNPKLOG(cmUnpkSpConId, &disEvnt.conId, mBuf, ESPT264, pst);
         CMCHKUNPKLOG(cmUnpkSpAddr, &disEvnt.rspAddr, mBuf, ESPT265, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.rsn, mBuf, ESPT266, pst);
         CMCHKUNPKLOG(SUnpkU8, &disEvnt.orig, mBuf, ESPT267, pst);
#ifdef SPTV2
         /* Unpack imp pres field */
         CMCHKUNPK(SUnpkU8, &disEvnt.imp.pres, mBuf);
         /* if importance is present, Unpack importance value */
         if (disEvnt.imp.pres != NOTPRSNT)
            CMCHKUNPK(SUnpkU8, &disEvnt.imp.val, mBuf);
#endif /* SPTV2 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   }

   SFndLenMsg(mBuf, &len);
   if (len == 0)
   {
      SPutMsg(mBuf);
      mBuf = NULLP;
   }

   (*func)(pst, &disEvnt, mBuf);
   RETVALUE(ROK);

} /* end of cmUnpkSptDisInd */


/*
*
*       Fun:   cmUnpkSptInfInd
*
*       Desc:  Unpack Infconnect Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptInfInd
(
SptInfInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSptInfInd(func, pst, mBuf)
SptInfInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
   SpInfEvnt infEvnt;

   TRC3(cmUnpkSptInfInd)

   CMCHKUNPKLOG(cmUnpkSpConId, &infEvnt.conId, mBuf, ESPT268, pst);
   CMCHKUNPKLOG(cmUnpkSpQosSet, &infEvnt.qos, mBuf, ESPT269, pst);
   CMCHKUNPKLOG(SUnpkU8, &infEvnt.rsn, mBuf, ESPT270, pst);

   SPutMsg(mBuf);

   (*func)(pst, &infEvnt);
   RETVALUE(ROK);

} /* end of cmUnpkSptInfInd */
#endif /* SPCO */

  
/*
*
*       Fun:   Pack Sub-system State Apply Request Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteApyReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat                     /* Sub-system state */
)
#else
PUBLIC S16 cmPkSptSteApyReq(pst, spId, aDpc, aSsn, uStat)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Affected Subsystem */
UStat uStat;                    /* Sub-system state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteApyReq)
  
   SPT_GETMSG(pst, mBuf, ESPT271)
   
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT272, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT273, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT274, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT275, pst);
   pst->event = EVTSPTSTEAPYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteApyReq */

  
/*
*
*       Fun:   Pack Sub-system State Apply Indication Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteApyInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat                     /* sub-system state */
)
#else
PUBLIC S16 cmPkSptSteApyInd(pst, suId, aDpc, aSsn, uStat)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Affected Subsystem */
UStat uStat;                    /* sub-system state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteApyInd)
  
   SPT_GETMSG(pst, mBuf, ESPT276)
   
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT277, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT278, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT279, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT280, pst);
   pst->event = EVTSPTSTEAPYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteApyInd */

  
/*
*
*       Fun:   Pack Sub-system State Apply Response Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteApyRsp
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat,                    /* sub-system state */
U8 status                       /* request completion status */
)
#else
PUBLIC S16 cmPkSptSteApyRsp(pst, spId, aDpc, aSsn, uStat, status)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* ffected Subsystem */
UStat uStat;                    /* sub-system state */
U8 status;                      /* request completion status */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteApyRsp)
  
   SPT_GETMSG(pst, mBuf, ESPT281)
   
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT282, pst);
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT283, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT284, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT285, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT286, pst);
   pst->event = EVTSPTSTEAPYRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteApyRsp */

  
/*
*
*       Fun:   Pack Sub-system State Apply Confirmation Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteApyCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
UStat uStat,                    /* sub-system state */
U8 status                       /* request completion status */
)
#else
PUBLIC S16 cmPkSptSteApyCfm(pst, suId, aDpc, aSsn, uStat, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Affected Subsystem */
UStat uStat;                    /* sub-system state */
U8 status;                      /* request completion status */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteApyCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT287)
   
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT288, pst);
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT289, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT290, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT291, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT292, pst);
   pst->event = EVTSPTSTEAPYCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteApyCfm */

  
/*
*
*       Fun:   Pack Sub-system State Query Request Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteQryReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn                        /* Affected Subsystem */
)
#else
PUBLIC S16 cmPkSptSteQryReq(pst, spId, aDpc, aSsn)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Calling Address */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteQryReq)
  
   SPT_GETMSG(pst, mBuf, ESPT293)
   
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT294, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT295, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT296, pst);
   pst->event = EVTSPTSTEQRYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteQryReq */

  
/*
*
*       Fun:   Pack Sub-system State Query Indication Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteQryInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn                        /* Affected Subsystem */
)
#else
PUBLIC S16 cmPkSptSteQryInd(pst, suId, aDpc, aSsn)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Calling Address */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteQryInd)
  
   SPT_GETMSG(pst, mBuf, ESPT297)
   
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT298, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT299, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT300, pst);
   pst->event = EVTSPTSTEQRYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteQryInd */

  
/*
*
*       Fun:   Pack Sub-system State Query Response Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteQryRsp
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
U8 status,                      /* request completion status */
UStat uStat                     /* sub-system state */
)
#else
PUBLIC S16 cmPkSptSteQryRsp(pst, spId, aDpc, aSsn, status, uStat)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Affected Subsystem */
U8 status;                      /* request completion status */
UStat uStat;                    /* sub-system state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteQryRsp)
  
   SPT_GETMSG(pst, mBuf, ESPT301)
   
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT302, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT303, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT304, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT305, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT306, pst);
   pst->event = EVTSPTSTEQRYRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteQryRsp */

  
/*
*
*       Fun:   Pack Sub-system State Query Confirmation Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptSteQryCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Ssn aSsn,                       /* Affected Subsystem */
U8 status,                      /* request completion status */
UStat uStat                     /* sub-system state */
)
#else
PUBLIC S16 cmPkSptSteQryCfm(pst, suId, aDpc, aSsn, status, uStat)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Ssn aSsn;                       /* Affected Subsystem */
U8 status;                      /* request completion status */
UStat uStat;                    /* sub-system state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptSteQryCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT307)
   
   CMCHKPKLOG(SPkU8, uStat, mBuf, ESPT308, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT309, pst);
   CMCHKPKLOG(SPkU8, aSsn, mBuf, ESPT310, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT311, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT312, pst);
   pst->event = EVTSPTSTEQRYCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptSteQryCfm */

  
/*
*
*       Fun:   Pack Point Code State Apply Request Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteApyReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Sps sps                         /* point code status */
)
#else
PUBLIC S16 cmPkSptPCSteApyReq(pst, spId, aDpc, sps)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Sps sps;                        /* point code status */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteApyReq)
  
   SPT_GETMSG(pst, mBuf, ESPT313)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT314, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT315, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT316, pst);
   pst->event = EVTSPTPCSTEAPYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteApyReq */

  
/*
*
*       Fun:   Pack Point Code State Apply Indication Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteApyInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Sps sps                         /* point code state */
)
#else
PUBLIC S16 cmPkSptPCSteApyInd(pst, suId, aDpc, sps)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Sps sps;                        /* point code state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteApyInd)
  
   SPT_GETMSG(pst, mBuf, ESPT317)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT318, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT319, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT320, pst);
   pst->event = EVTSPTPCSTEAPYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteApyInd */

  
/*
*
*       Fun:   Pack Point Code State Apply Response Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteApyRsp
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
Sps sps,                        /* point code state */
U8 status                       /* user status */
)
#else
PUBLIC S16 cmPkSptPCSteApyRsp(pst, spId, aDpc, sps, status)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
Sps sps;                        /* point code state */
U8 status;                      /* user status */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteApyRsp)
  
   SPT_GETMSG(pst, mBuf, ESPT321)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT322, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT323, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT324, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT325, pst);
   pst->event = EVTSPTPCSTEAPYRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteApyRsp */

  
/*
*
*       Fun:   Pack Point Code State Apply Confirmation Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteApyCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
Sps sps,                        /* point code state */
U8 status                       /* user status */
)
#else
PUBLIC S16 cmPkSptPCSteApyCfm(pst, suId, aDpc, sps, status)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
Sps sps;                        /* point code state */
U8 status;                      /* user status */
#endif
{
   Buffer *mBuf;
   TRC3(cmPkSptPCSteApyCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT326)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT327, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT328, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT329, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT330, pst);
   pst->event = EVTSPTPCSTEAPYCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteApyCfm */

  
/*
*
*       Fun:   Pack Point Code State Query Request Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteQryReq
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc                        /* affected destination pointcode */
)
#else
PUBLIC S16 cmPkSptPCSteQryReq(pst, spId, aDpc)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteQryReq)
  
   SPT_GETMSG(pst, mBuf, ESPT331)
   
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT332, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT333, pst);
   pst->event = EVTSPTPCSTEQRYREQ;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteQryReq */

  
/*
*
*       Fun:   Pack Point Code State Query Indication Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteQryInd
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc                        /* affected destination pointcode */
)
#else
PUBLIC S16 cmPkSptPCSteQryInd(pst, suId, aDpc)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteQryInd)
  
   SPT_GETMSG(pst, mBuf, ESPT334)
   
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT335, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT336, pst);
   pst->event = EVTSPTPCSTEQRYIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteQryInd */

  
/*
*
*       Fun:   Pack Point Code State Query Response Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteQryRsp
(
Pst *pst,                       /* post structure */
SpId spId,                      /* Service Provider Id */
Dpc aDpc,                       /* affected destination pointcode */
U8 status,                      /* request completion status */
Sps sps                         /* point code state */
)
#else
PUBLIC S16 cmPkSptPCSteQryRsp(pst, spId, aDpc, status, sps)
Pst *pst;                       /* post structure */
SpId spId;                      /* Service Provider Id */
Dpc aDpc;                       /* affected destination pointcode */
U8 status;                      /* request completion status */
Sps sps;                        /* point code state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteQryRsp)
                                                 
   SPT_GETMSG(pst, mBuf, ESPT337)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT338, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT339, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT340, pst);
   CMCHKPKLOG(SPkS16, spId, mBuf, ESPT341, pst);
   pst->event = EVTSPTPCSTEQRYRSP;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteQryRsp */

  
/*
*
*       Fun:   Pack Point Code State Query Confirmation Event
*
*       Desc:
*
*
*       Ret:   ROK   - ok
*
*       Notes: SCCP Management
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSptPCSteQryCfm
(
Pst *pst,                       /* post structure */
SuId suId,                      /* Service User Id */
Dpc aDpc,                       /* affected destination pointcode */
U8 status,                      /* request completion status */
Sps sps                         /* point code state */
)
#else
PUBLIC S16 cmPkSptPCSteQryCfm(pst, suId, aDpc, status, sps)
Pst *pst;                       /* post structure */
SuId suId;                      /* Service User Id */
Dpc aDpc;                       /* affected destination pointcode */
U8 status;                      /* request completion status */
Sps sps;                        /* point code state */
#endif
{
   Buffer *mBuf;
  
   TRC3(cmPkSptPCSteQryCfm)
  
   SPT_GETMSG(pst, mBuf, ESPT342)
   
   CMCHKPKLOG(SPkU8, sps, mBuf, ESPT343, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESPT344, pst);
   CMCHKPKLOG(SPkU32, aDpc, mBuf, ESPT345, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESPT346, pst);
   pst->event = EVTSPTPCSTEQRYCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkSptPCSteQryCfm */


/*
*
*       Fun:   cmUnpkSptSteApyReq
*
*       Desc:  Unpack Sub-system State Apply Request Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteApyReq
(
SptSteApyReq   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteApyReq(func, pst, mBuf)
SptSteApyReq   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId        spId;
   Dpc         dpc;
   Ssn         ssn;
   UStat       uStat;
   
   TRC3(cmUnpkSptSteApyReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT347, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT348, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT349, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT350, pst);

   SPutMsg(mBuf);

   (*func)(pst, spId, dpc, ssn, uStat);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteApyReq */


/*
*
*       Fun:   cmUnpkSptSteApyInd
*
*       Desc:  Unpack Sub-system State Apply Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteApyInd
(
SptSteApyInd   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteApyInd(func, pst, mBuf)
SptSteApyInd   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Ssn         ssn;
   UStat       uStat;
   
   TRC3(cmUnpkSptSteApyInd)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT351, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT352, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT353, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT354, pst);

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, ssn, uStat);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteApyInd */


/*
*
*       Fun:   cmUnpkSptSteApyCfm
*
*       Desc:  Unpack Sub-system State Apply Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteApyCfm
(
SptSteApyCfm   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteApyCfm(func, pst, mBuf)
SptSteApyCfm   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Ssn         ssn;
   UStat       uStat;
   U8          status;
   
   TRC3(cmUnpkSptSteApyCfm)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT355, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT356, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT357, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT358, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT359, pst); 

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, ssn, uStat, status);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteApyCfm */


/*
*
*       Fun:   cmUnpkSptSteApyRsp
*
*       Desc:  Unpack Sub-system State Apply Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteApyRsp
(
SptSteApyRsp   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteApyRsp(func, pst, mBuf)
SptSteApyRsp   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId        spId;
   Dpc         dpc;
   Ssn         ssn;
   UStat       uStat;
   U8          status;
   
   TRC3(cmUnpkSptSteApyRsp)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT360, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT361, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT362, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT363, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT364, pst);

   SPutMsg(mBuf);

   (*func)(pst, spId, dpc, ssn, uStat, status);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteApyRsp */


/*
*
*       Fun:   cmUnpkSptPCSteApyReq
*
*       Desc:  Unpack Point Code State Apply Request Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteApyReq
(
SptPCSteApyReq func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteApyReq(func, pst, mBuf)
SptPCSteApyReq func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId        spId;
   Dpc         dpc;
   Sps         sps;
   
   TRC3(cmUnpkSptPCSteApyReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT365, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT366, pst);
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT367, pst); 

   SPutMsg(mBuf);

   (*func)(pst, spId, dpc, sps);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteApyReq */


/*
*
*       Fun:   cmUnpkSptPCSteApyInd
*
*       Desc:  Unpack Point Code State Apply Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteApyInd
(
SptPCSteApyInd func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteApyInd(func, pst, mBuf)
SptPCSteApyInd func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Sps         sps;
   
   TRC3(cmUnpkSptPCSteApyInd)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT368, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT369, pst);
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT370, pst); 

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, sps);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteApyInd */


/*
*
*       Fun:   cmUnpkSptPCSteApyCfm
*
*       Desc:  Unpack Point Code State Apply Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteApyCfm
(
SptPCSteApyCfm func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteApyCfm(func, pst, mBuf)
SptPCSteApyCfm func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Sps         sps;
   U8          status;
   
   TRC3(cmUnpkSptPCSteApyCfm)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT371, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT372, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT373, pst); 
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT374, pst); 

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, sps, status);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteApyCfm */


/*
*
*       Fun:   cmUnpkSptPCSteApyRsp
*
*       Desc:  Unpack Point Code State Apply Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteApyRsp
(
SptPCSteApyRsp func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteApyRsp(func, pst, mBuf)
SptPCSteApyRsp func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId        spId;
   Dpc         dpc;
   Sps         sps;
   U8          status;
   
   TRC3(cmUnpkSptPCSteApyRsp)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT375, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT376, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT377, pst); 
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT378, pst); 

   SPutMsg(mBuf);

   (*func)(pst, spId, dpc, sps, status);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteApyRsp */


/*
*
*       Fun:   cmUnpkSptSteQryReq
*
*       Desc:  Unpack Sub-system State Query Request Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteQryReq
(
SptSteQryReq   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteQryReq(func, pst, mBuf)
SptSteQryReq   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SpId        spId;
   Dpc         dpc;
   Ssn         ssn;
   
   TRC3(cmUnpkSptSteQryReq)

   CMCHKUNPKLOG( SUnpkS16, &spId, mBuf, ESPT379, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT380, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT381, pst);         /* ssn */

   SPutMsg(mBuf);

   (*func)(pst, spId, dpc, ssn);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteQryReq */


/*
*
*       Fun:   cmUnpkSptSteQryInd
*
*       Desc:  Unpack Sub-system State Query Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteQryInd
(
SptSteQryInd   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteQryInd(func, pst, mBuf)
SptSteQryInd   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Ssn         ssn;
   
   TRC3(cmUnpkSptSteQryInd)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT382, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT383, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT384, pst);         /* ssn */

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, ssn);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteQryInd */


/*
*
*       Fun:   cmUnpkSptSteQryCfm
*
*       Desc:  Unpack Sub-system State Query Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteQryCfm
(
SptSteQryCfm   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteQryCfm(func, pst, mBuf)
SptSteQryCfm   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Ssn         ssn;
   UStat       uStat;
   U8          status;
   
   TRC3(cmUnpkSptSteQryCfm)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT385, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT386, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT387, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT388, pst); 
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT389, pst);

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, ssn, status, uStat);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteQryCfm */


/*
*
*       Fun:   cmUnpkSptSteQryRsp
*
*       Desc:  Unpack Sub-system State Query Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptSteQryRsp
(
SptSteQryRsp   func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptSteQryRsp(func, pst, mBuf)
SptSteQryRsp   func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   Ssn         ssn;
   U8          status;
   UStat       uStat;
   
   TRC3(cmUnpkSptSteQryRsp)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT390, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT391, pst);
   CMCHKUNPKLOG( SUnpkU8, &ssn, mBuf, ESPT392, pst);         /* ssn */
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT393, pst); 
   CMCHKUNPKLOG( SUnpkU8, &uStat, mBuf, ESPT394, pst);

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, ssn, status, uStat);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptSteQryRsp */


/*
*
*       Fun:   cmUnpkSptPCSteQryReq
*
*       Desc:  Unpack Point Code State Query Request Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteQryReq
(
SptPCSteQryReq func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteQryReq(func, pst, mBuf)
SptPCSteQryReq func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   
   TRC3(cmUnpkSptPCSteQryReq)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT395, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT396, pst);

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteQryReq */


/*
*
*       Fun:   cmUnpkSptPCSteQryInd
*
*       Desc:  Unpack Point Code State Query Indication Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteQryInd
(
SptPCSteQryInd func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteQryInd(func, pst, mBuf)
SptPCSteQryInd func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   
   TRC3(cmUnpkSptPCSteQryInd)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT397, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT398, pst);

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteQryInd */


/*
*
*       Fun:   cmUnpkSptPCSteQryCfm
*
*       Desc:  Unpack Point Code State Query Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteQryCfm
(
SptPCSteQryCfm func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteQryCfm(func, pst, mBuf)
SptPCSteQryCfm func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   U8          status;
   Sps         sps;
   
   TRC3(cmUnpkSptPCSteQryCfm)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT399, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT400, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT401, pst); 
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT402, pst); 

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, status, sps);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteQryCfm */


/*
*
*       Fun:   cmUnpkSptPCSteQryRsp
*
*       Desc:  Unpack Point Code State Query Confirmation Event
*
*       Ret:   ROK   - ok
*
*       Notes: None
*
*       File:  spt.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSptPCSteQryRsp
(
SptPCSteQryRsp func,
Pst            *pst,
Buffer         *mBuf
)
#else
PUBLIC S16 cmUnpkSptPCSteQryRsp(func, pst, mBuf)
SptPCSteQryRsp func;
Pst            *pst;
Buffer         *mBuf;
#endif
{
   SuId        suId;
   Dpc         dpc;
   U8          status;
   Sps         sps;
   
   TRC3(cmUnpkSptPCSteQryRsp)

   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESPT403, pst);
   CMCHKUNPKLOG( SUnpkU32, &dpc, mBuf, ESPT404, pst);
   CMCHKUNPKLOG( SUnpkU8,    &status, mBuf, ESPT405, pst); 
   CMCHKUNPKLOG( cmUnpkSps,  &sps,  mBuf, ESPT406, pst); 

   SPutMsg(mBuf);

   (*func)(pst, suId, dpc, status, sps);
   
   RETVALUE(ROK);

} /* end of cmUnpkSptPCSteQryRsp */
#endif /* LCSPT */

/********************************************************************30**
  
         End of file:     spt.c@@/main/13 - Tue Jan 22 15:18:23 2002
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  fmg   1. initial release.

1.2          ---  fmg   1. removed duplicate inclusions of spt.[xh]

1.3          ---  aa    1. Changed the packing and unpacking such that the
                           return values of functions are checked only under
                           ADD_RES calss (for packing) and under the DEBUG
                           class for unpacking routines. The macro's used 
                           can be found in ssi.h
             ---  aa    2. change copyright header

1.4          ---  mjp   1. removed #define SPCO

1.5          ---  mjp   1. added pack and unpack of sc field in UDatEvnt 

1.6          ---  mjp   1. moved cm_ss7.(h/x) above spt.(h.x)

*********************************************************************81*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.7          ---      cp   1. added the packing/unpacking functions as 
                              per tco0001.
                      nj   2. Added the packing/unpacking functions for
                               the SPT interface primitives. Were 
                               previously in the SCCP's upper layer's 
                               xx_ptli.c and xx_ex_ms.c files.
                           3. Added the packing/unpacking functions 
                              for the Connection Oriented Classes, from 
                              the layer4 files.
                      cp   4. Added SPCO flag around the 
                              packing/unpacking fns for conn-orieneted 
                              data structures.
                      nj   5. Took out connection-less packing/unpacking 
                              functions out of the SPCO flag.
                      cp   6. Added flag LCSPT.
/main/9      ---      ssk  1. Removed SEL_LC_NEW check from PkUDatInd()
                              function.
/main/10     ---     nt   1. Packing/unpacking funcs added for SUA-NIF i/f
/main/11     ---     dw   1. For freeing mBuf in case it doesnot contain any
                             user data
/main/12     ---    srg    1. To fix the findfuntypemismatch error found during the 
                              PRE-RTR of BSSAP+.
/main/13     ---       rc  1. Addition for sccp release 3.2:
                             - packing/unpacking of audit primitives.
                             - translation of primitives from SPTV1 to SPTV2
                               interface and vice-versa.
                             - sccpState and ril added in param list to function
                               PCSteInd and StaCfm
                             - support for ISNI, INS and imp parameter at SPT
                               interface.
   spt_c_001.main_13   rc  1. Missing semicolon added.
   spt_c_002.main_13   rc  1. Initializing isni and ins when unpacking UDatEvnt
                              structure.
   spt_c_003.main_13   sm  1. Pack/Unpack functions added for unit data service
                              request at upper interface.
*********************************************************************91*/
