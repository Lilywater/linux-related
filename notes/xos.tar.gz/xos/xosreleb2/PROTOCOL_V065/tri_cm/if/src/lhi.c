/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     TCP UDP Convergence Layer
  
     Type:     C source file
  
     Desc:     C source code for common packing and un-packing functions for
               layer management interface(LHI) supplied by TRILLIUM.
              
     File:     lhi.c
  
     Sid:      lhi.c@@/main/4 - Thu Jun 28 13:31:14 2001

     Prg:      asa
  
*********************************************************************21*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*
*/
  

/* header include files (.h) */
#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
#include "gen.h"           /* general layer */
#include "cm_gen.h"        /* common pack/unpack defines */
#include "ssi.h"           /* system services */
#include "lhi.h"           /* layer management, HI Layer */
/* hi009.104 - added for HI_ZERO macro */
#include "hi.h"            /* HI Layer */
 
/* header/extern include files (.x) */
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "lhi.x"           /* layer management, HI layer */ 
/* hi009.104 - added as HI_ZERO macro calls cmMemset which is defined in
 * cm_lib.x */
#include "cm_lib.x"            /* has the prototype of cmMemset() */

/* local defines */
  
/* local typedefs */
  
/* local externs */
  
/* forward references */



/* functions in other modules */
  
/* public variable declarations */
  
/* private variable declarations */

#ifdef LCLHI


 
/*
*     layer management interface packing functions
*/


/*
*
*       Fun:   Pack Config Request
*
*       Desc:  This function is used to a pack config request
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkLhiCfgReq
(
Pst *pst,                 /* post structure */    
HiMngmt *cfg              /* configuration */
)
#else
PUBLIC S16 cmPkLhiCfgReq(pst, cfg)
Pst *pst;                 /* post structure */    
HiMngmt *cfg;             /* configuration */
#endif
{
 
   Buffer *mBuf;            /* message buffer */
   U8     i;

   TRC3(cmPkLhiCfgReq)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   
   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:
      {
         HiGenCfg *gen = &(cfg->t.cfg.s.hiGen);
         
   /* hi009.104 - added to pack the addr & port to bind the generic sock */
#ifdef HI_SPECIFY_GENSOCK_ADDR
#ifdef IPV6_SUPPORTED         
         CMCHKPKLOG(cmPkCmIpv6TptAddr,
                                &gen->ipv6GenSockAddr, mBuf, ELHIXXX, pst);
#endif /* IPV6_SUPPORTED */         
         CMCHKPKLOG(cmPkCmIpv4TptAddr, 
                                &gen->ipv4GenSockAddr, mBuf, ELHIXXX, pst);
#endif /* HI_SPECIFY_GENSOCK_ADDR */
         
         CMCHKPKLOG(cmPkPst,    &gen->lmPst,       mBuf, ELHI001, pst);   
         CMCHKPKLOG(cmPkTicks,  gen->timeRes,      mBuf, ELHI002, pst);   
         CMCHKPKLOG(cmPkStatus, gen->poolStopThr, mBuf, ELHI003, pst);   
         CMCHKPKLOG(cmPkStatus, gen->poolDropThr, mBuf, ELHI004, pst);   
         CMCHKPKLOG(cmPkStatus, gen->poolStrtThr, mBuf, ELHI005, pst);   
         CMCHKPKLOG(SPkU16,     gen->schdTmrVal,   mBuf, ELHI006, pst);   
         CMCHKPKLOG(cmPkBool,   gen->permTsk,      mBuf, ELHI007, pst);   
#ifdef HI006_12 
         CMCHKPKLOG(SPkU8, gen->numClToAccept, mBuf, ELHI008, pst);
         CMCHKPKLOG(SPkU8, gen->numUdpMsgsToRead, mBuf, ELHI009, pst);
#ifdef HI_REL_1_3
         CMCHKPKLOG(SPkU8, gen->numRawMsgsToRead, mBuf, ELHI010, pst);
#endif /* HI_REL_1_3 */
         CMCHKPKLOG(SPkU32, gen->selTimeout, mBuf, ELHI011, pst);
#endif /* HI006_12 */         
#ifdef HI_REL_1_2
         CMCHKPKLOG(SPkU16, gen->numFdBins, mBuf, ELHI012, pst);   
         CMCHKPKLOG(SPkU16, gen->numFdsPerSet, mBuf, ELHI013, pst);   
#endif /* HI_REL_1_2 */
         CMCHKPKLOG(SPkU32, gen->numCons, mBuf, ELHI014, pst);   
         CMCHKPKLOG(SPkU16, gen->numSaps, mBuf, ELHI015, pst);   
      break;
      }

      case STTSAP:
      {
         HiSapCfg *sap = &(cfg->t.cfg.s.hiSap);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* hi009.104 - addition - packing fields for interface ver info */
         CMCHKPKLOG(cmPkIntfVer, sap->remIntfVer, mBuf, ELHIXXX, pst);
         CMCHKPKLOG(SPkU8, sap->remIntfValid, mBuf, ELHIXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */         

         for(i=0; i< LHI_MAX_HDR_TYPE; i++)
         {
            CMCHKPKLOG(SPkU32, sap->hdrInf[i].hdrLen, mBuf, ELHI016, pst);   
            CMCHKPKLOG(SPkU32, sap->hdrInf[i].offLen, mBuf, ELHI017, pst);   
            CMCHKPKLOG(SPkU32, sap->hdrInf[i].lenLen, mBuf, ELHI018, pst);   
            CMCHKPKLOG(SPkU32, sap->hdrInf[i].flag,   mBuf, ELHI019, pst);   
         }

         CMCHKPKLOG(cmPkMemoryId, &sap->uiMemId, mBuf, ELHI020, pst);   
         CMCHKPKLOG(cmPkSelector, sap->uiSel,    mBuf, ELHI021, pst);   
         CMCHKPKLOG(cmPkRoute,    sap->uiRoute,  mBuf, ELHI022, pst);   
         CMCHKPKLOG(cmPkPrior,    sap->uiPrior,  mBuf, ELHI023, pst);   
         CMCHKPKLOG(SPkU16,       sap->numBins,  mBuf, ELHI024, pst);   
         CMCHKPKLOG(SPkU32,       sap->txqCongStopLim,  mBuf, ELHI025, pst);   
         CMCHKPKLOG(SPkU32,       sap->txqCongDropLim,  mBuf, ELHI026, pst);   
         CMCHKPKLOG(SPkU32,       sap->txqCongStrtLim, mBuf, ELHI027, pst);   
         CMCHKPKLOG(cmPkBool,     sap->flcEnb,     mBuf, ELHI028, pst);   
         CMCHKPKLOG(cmPkSpId,     sap->spId,       mBuf, ELHI029, pst);   

      break;
      }

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI030, cfg->hdr.elmId.elmnt, 
                     "cmPkLhiCfgReq() Failed"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }/* end of switch */

   CMCHKPKLOG(cmPkCmStatus, &cfg->cfm, mBuf, ELHI031, pst);
   CMCHKPKLOG(cmPkHeader, &cfg->hdr, mBuf, ELHI032, pst);
   pst->event = (Event)EVTLHICFGREQ;

/* hi009.104 - fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LHIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
      
   RETVALUE(SPstTsk(pst, mBuf));
}


/*
*
*       Fun:   Pack Config Confirm
*
*       Desc:  This function is used to a pack config confirm 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkLhiCfgCfm
(
Pst *pst,                 /* post structure */    
HiMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLhiCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */    
HiMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiCfgCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELHI033, pst);
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ELHI034, pst);
   
   pst->event = EVTLHICFGCFM;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of cmPkLhiCfgCfm */


/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiCntrlReq
(
Pst *pst,                 /* post structure */    
HiMngmt *ctl              /* configuration */
)
#else
PUBLIC S16 cmPkLhiCntrlReq(pst, ctl)
Pst *pst;                 /* post structure */    
HiMngmt *ctl;             /* configuration */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiCntrlReq)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   switch(ctl->hdr.elmId.elmnt) 
   {
      case STGEN:
         if(ctl->t.cntrl.subAction == SADBG)
         {
#ifdef DEBUGP
           CMCHKPKLOG(SPkU32, ctl->t.cntrl.ctlType.hiDbg.dbgMask, 
                      mBuf, ELHI035, pst);
#endif
         }
         break;

      case STTSAP:
         if(ctl->t.cntrl.subAction == SATRC)
         {
            CMCHKPKLOG(cmPkSpId, ctl->t.cntrl.ctlType.trcDat.sapId, 
                       mBuf, ELHI036, pst);
            CMCHKPKLOG(SPkS16, ctl->t.cntrl.ctlType.trcDat.trcLen, 
                       mBuf, ELHI037, pst);
         }
         else if(ctl->t.cntrl.subAction == SAELMNT)
         {
            CMCHKPKLOG(cmPkSpId, ctl->t.cntrl.ctlType.sapId, mBuf, 
                       ELHI038, pst);
         }
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI039,  ctl->t.cntrl.subAction, 
                     "cmPkLhiCntrlReq() : invalid subAction(STTSAP) "); 
#endif /* ERRCLS_DEBUG */
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         break;

      case STGRTSAP:
         if(ctl->t.cntrl.subAction == SAGR_PRIORITY)
         {
            CMCHKPKLOG(cmPkPrior, ctl->t.cntrl.ctlType.priority, mBuf, 
                       ELHI040, pst);
         }
         else if(ctl->t.cntrl.subAction == SAGR_ROUTE)
         {
            CMCHKPKLOG(cmPkProcId, ctl->t.cntrl.ctlType.route, mBuf, 
                       ELHI041, pst);
         }
         else if(ctl->t.cntrl.subAction == SAGR_DSTPROCID)
         {
            CMCHKPKLOG(cmPkProcId, ctl->t.cntrl.ctlType.dstProcId, mBuf, 
                       ELHI042, pst);
         }
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI043, ctl->t.cntrl.subAction, 
                     "cmPkLhiCntrlReq() :invalid subAction(STGRTSAP)"); 
#endif /* ERRCLS_DEBUG */
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI044, ctl->hdr.elmId.elmnt, 
                     "cmPkLhiCntrlReq () Failed : invalid elmnt"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }/* end of switch */

   CMCHKPKLOG(SPkU8,       ctl->t.cntrl.subAction, mBuf, ELHI045, pst);
   CMCHKPKLOG(SPkU8,       ctl->t.cntrl.action,    mBuf, ELHI046, pst);
   CMCHKPKLOG(cmPkDateTime, &ctl->t.cntrl.dt,       mBuf, ELHI047, pst);

   CMCHKPKLOG(cmPkCmStatus, &ctl->cfm, mBuf, ELHI048, pst);
   CMCHKPKLOG(cmPkHeader,   &ctl->hdr, mBuf, ELHI049, pst);
   pst->event = (Event)EVTLHICNTRLREQ;

/* hi009.104 - fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = (CmIntfVer) LHIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   RETVALUE(SPstTsk(pst, mBuf));
}


/*
*
*       Fun:   Pack Control Confirm
*
*       Desc:  This function is used to pack the control confirm 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiCntrlCfm
(
Pst *pst,                 /* post structure */    
HiMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLhiCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */    
HiMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiCntrlCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELHI050, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELHI051, pst);
   
   pst->event = EVTLHICNTRLCFM;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of cmPkLhiCntrlCfm */


 
/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiStsReq
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
HiMngmt *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLhiStsReq(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
HiMngmt *sts;             /* statistics */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiStsReq)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   switch(sts->hdr.elmId.elmnt)
   {
      case STGEN:
         break;
      case STTSAP:
      {
         CMCHKPKLOG(cmPkSpId, sts->t.sts.s.sapSts.sapId, mBuf, ELHI052, pst);
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI053, sts->hdr.elmId.elmnt, 
                     "cmPkLhiStsReq () Failed : invalid elmnt"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELHI054, pst);
   CMCHKPKLOG(cmPkHeader,   &sts->hdr, mBuf, ELHI055, pst);
   CMCHKPKLOG(cmPkAction,   action,    mBuf, ELHI056, pst);
   pst->event = EVTLHISTSREQ;

/* hi009.104 - fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LHIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkLhiStsReq */

 
/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiStsCfm
(
Pst *pst,                 /* post structure */    
HiMngmt *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLhiStsCfm(pst, sts)
Pst *pst;                 /* post structure */    
HiMngmt *sts;             /* statistics */
#endif

{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiStsCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   switch(sts->hdr.elmId.elmnt)
   {
      case STGEN:
      {
         HiGenSts *gSts = &(sts->t.sts.s.genSts);
#ifdef HI_REL_1_3  
         CMCHKPKLOG(cmPkStsCntr, gSts->numRxRawMsg,  mBuf, ELHI057, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numTxRawMsg,  mBuf, ELHI058, pst);
#endif /* HI_REL_1_3 */ 
         CMCHKPKLOG(cmPkStsCntr, gSts->numRxbytes,  mBuf, ELHI059, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numTxbytes,  mBuf, ELHI060, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numRxUdpMsg, mBuf, ELHI061, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numTxUdpMsg, mBuf, ELHI062, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numRxTcpMsg, mBuf, ELHI063, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numTxTcpMsg, mBuf, ELHI064, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numFlcInd,   mBuf, ELHI065, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->rxMsgVerErr, mBuf, ELHI066, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockShutErr, mBuf, ELHI067, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockClosErr, mBuf, ELHI068, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockSOptErr, mBuf, ELHI069, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockLstnErr, mBuf, ELHI070, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockCnctErr, mBuf, ELHI071, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockBindErr, mBuf, ELHI072, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockOpenErr, mBuf, ELHI073, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockRxErr,   mBuf, ELHI074, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->sockTxErr,   mBuf, ELHI075, pst);
         CMCHKPKLOG(cmPkStsCntr, gSts->numCons,     mBuf, ELHI076, pst);
         break;
      }
      case STTSAP:
      {
         HiSapSts *sSts = &(sts->t.sts.s.sapSts);
#ifdef HI_REL_1_3  
         CMCHKPKLOG(cmPkStsCntr, sSts->numRxRawMsg,  mBuf, ELHI077, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numTxRawMsg,  mBuf, ELHI078, pst);
#endif /* HI_REL_1_3 */ 
         CMCHKPKLOG(cmPkStsCntr, sSts->numRxbytes,  mBuf, ELHI079, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numTxbytes,  mBuf, ELHI080, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numRxUdpMsg, mBuf, ELHI081, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numTxUdpMsg, mBuf, ELHI082, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numRxTcpMsg, mBuf, ELHI083, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numTxTcpMsg, mBuf, ELHI084, pst);
         CMCHKPKLOG(cmPkStsCntr, sSts->numCons,     mBuf, ELHI085, pst);
         CMCHKPKLOG(cmPkSpId,    sSts->sapId,       mBuf, ELHI086, pst);
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI087, sts->hdr.elmId.elmnt, 
                     "cmPkLhiStsCfm() : invalid elmnt"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }
   
   CMCHKPKLOG(cmPkDuration, &sts->t.sts.dura, mBuf, ELHI088, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELHI089, pst);

   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELHI090, pst);
   CMCHKPKLOG(cmPkHeader,   &sts->hdr, mBuf, ELHI091, pst);
   pst->event = (Event)EVTLHISTSCFM;
   RETVALUE(SPstTsk(pst, mBuf));
}


/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiStaReq
(
Pst *pst,                 /* post structure */     
HiMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 cmPkLhiStaReq(pst, sta)
Pst *pst;                 /* post structure */     
HiMngmt *sta;             /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiStaReq)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   switch(sta->hdr.elmId.elmnt)
   {
      case STSID:
         break;
      case STTSAP:
         CMCHKPKLOG(cmPkSpId, sta->t.ssta.s.sapSta.spId, mBuf, ELHI092, pst);
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI093, sta->hdr.elmId.elmnt, 
                     "cmPkLhiStaReq () : invalid elmnt"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELHI094, pst);
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELHI095, pst);
   pst->event = (Event)EVTLHISTAREQ;

   /* hi009.104 - fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LHIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */   
   
   RETVALUE(SPstTsk(pst, mBuf));
}


/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiStaCfm
(
Pst *pst,                 /* post structure */     
HiMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 cmPkLhiStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
HiMngmt *sta;             /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(cmPkLhiStaCfm)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   switch(sta->hdr.elmId.elmnt)
   {
      case STSID:
      {
         CMCHKPKLOG(cmPkSystemId, &(sta->t.ssta.s.sysId), mBuf, ELHI096, pst);
         break;
      }
      case STTSAP:
      {
         HiSapSta *sSta = &(sta->t.ssta.s.sapSta);

/* hi009.104 - pcak self and remote interface version num */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer, sSta->remIfVer, mBuf, ELHIXXX, pst);
         CMCHKPKLOG(cmPkIntfVer, sSta->selfIfVer, mBuf, ELHIXXX, pst);
         CMCHKPKLOG(cmPkBool, sSta->remIntfValid, mBuf, ELHIXXX, pst);         
#endif /* TDS_ROLL_UPGRADE_SUPPORT */         

         CMCHKPKLOG(cmPkState, sSta->state, mBuf, ELHI097, pst);
         CMCHKPKLOG(cmPkSpId,  sSta->spId,  mBuf, ELHI098, pst);
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI099, sta->hdr.elmId.elmnt, 
                     "cmPkLhiStaReq () Failed"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   /* date */
   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELHI100, pst);

   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELHI101, pst);
   CMCHKPKLOG(cmPkHeader,   &sta->hdr, mBuf, ELHI102, pst);
   pst->event = EVTLHISTACFM;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkLhiStaCfm */


/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiStaInd
(
Pst *pst,                 /* post structure */
HiMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 cmPkLhiStaInd(pst, sta)
Pst *pst;                 /* post structure */   
HiMngmt *sta;             /* unsolicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */

   TRC3(cmPkLhiStaInd)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   if(sta->t.usta.info.type != LHI_ALARMINFO_TYPE_NTPRSNT) 
   {
      switch(sta->t.usta.info.type)
      {
         case LHI_ALARMINFO_PAR_TYPE:
            CMCHKPKLOG(SPkU8, sta->t.usta.info.inf.parType, mBuf, ELHI103, 
                       pst);
            break;

         case LHI_ALARMINFO_MEM_ID:
            CMCHKPKLOG(cmPkPool, sta->t.usta.info.inf.mem.pool, 
                       mBuf, ELHI104, pst);
            CMCHKPKLOG(cmPkRegion, sta->t.usta.info.inf.mem.region, 
                       mBuf, ELHI105, pst);
            break;

         case LHI_ALARMINFO_CON_STATE:
            CMCHKPKLOG(cmPkState, sta->t.usta.info.inf.conState,
                       mBuf, ELHI106, pst);
            break;

         case LHI_ALARMINFO_SAP_STATE:
            CMCHKPKLOG(cmPkState, sta->t.usta.info.inf.state, 
                       mBuf, ELHI107, pst);
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            LHILOGERROR(pst, ELHI108, sta->t.usta.info.type, 
                        "cmPkLhiStaInd () Failed"); 
#endif
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
      }
   }
   CMCHKPKLOG(SPkU8,   sta->t.usta.info.type, mBuf, ELHI109, pst);
   CMCHKPKLOG(cmPkSpId,    sta->t.usta.info.spId,  mBuf, ELHI110, pst);
   CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm,     mBuf, ELHI111, pst);

   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELHI112, pst);
   CMCHKPKLOG(cmPkHeader,   &sta->hdr, mBuf, ELHI113, pst);
   pst->event = (Event)EVTLHISTAIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkLhiStaInd */
 


/*
*
*       Fun:   Pack Trace Indication
*
*       Desc:  This function is used to pack the trace indication
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLhiTrcInd
(
Pst *pst,                 /* post */
HiMngmt *trc,             /* trace */
Buffer  *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmPkLhiTrcInd(pst, trc, mBuf)
Pst *pst;                 /* post */
HiMngmt *trc;             /* trace */
Buffer  *mBuf;            /* message buffer */
#endif
{
 
   TRC3(cmPkLhiTrcInd)

   if (mBuf == NULLP)
   {
      if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      {
         RETVALUE(RFAILED);
      }
   }
   /* hi023.104 Sap Id in Trace Information */
#ifdef HI_ENB_SAP_TRC
   CMCHKPKLOG(SPkU16, trc->t.trc.sap, mBuf, ELHI114, pst);
#endif
   CMCHKPKLOG(SPkU16, trc->t.trc.evnt, mBuf, ELHI114, pst);
   CMCHKPKLOG(cmPkDateTime, &trc->t.trc.dt, mBuf, ELHI115, pst);

   CMCHKPKLOG(cmPkCmStatus, &trc->cfm, mBuf, ELHI116, pst);
   CMCHKPKLOG(cmPkHeader,   &trc->hdr, mBuf, ELHI117, pst);
   pst->event = EVTLHITRCIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkLhiTrcInd */


/*
*     layer management interface un-packing functions
*/

/*
*
*       Fun:   Un-pack Config Request
*
*       Desc:  This function is used to a un-pack config request
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLhiCfgReq
(
LhiCfgReq func,
Pst *pst,                 /* post structure */    
Buffer *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiCfgReq(func, pst, mBuf)
LhiCfgReq func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;             /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */
   U8       i;
    
   TRC3(cmUnpkLhiCfgReq)

   /* hi009.104 - call the new MACRO to init struc to all zeros */
   LHI_ZERO((U8 *)&mgt, sizeof(HiMngmt));
   
   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI118, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI119, pst);
   
   switch (mgt.hdr.elmId.elmnt)
   {
      case STGEN:
      {
         HiGenCfg *gen = &(mgt.t.cfg.s.hiGen);

         CMCHKUNPKLOG(SUnpkU16,     &gen->numSaps, mBuf, ELHI120, pst);   
         CMCHKUNPKLOG(SUnpkU32,     &gen->numCons, mBuf, ELHI121, pst);   
#ifdef HI_REL_1_2
         CMCHKUNPKLOG(SUnpkU16,     &gen->numFdsPerSet, mBuf, ELHI122, pst);   
         CMCHKUNPKLOG(SUnpkU16,     &gen->numFdBins, mBuf, ELHI123, pst);   
#endif /* HI_REL_1_2 */
#ifdef HI006_12
         CMCHKUNPKLOG(SUnpkU32,     &gen->selTimeout, mBuf, ELHI124, pst);
#ifdef HI_REL_1_3
         CMCHKUNPKLOG(SUnpkU8,     &gen->numRawMsgsToRead, mBuf, ELHI125, pst);
#endif /* HI_REL_1_3 */
         CMCHKUNPKLOG(SUnpkU8,     &gen->numUdpMsgsToRead, mBuf, ELHI126, pst);
         CMCHKUNPKLOG(SUnpkU8,     &gen->numClToAccept, mBuf, ELHI127, pst);
#endif /* HI006_12 */
         CMCHKUNPKLOG(cmUnpkBool,   &gen->permTsk,      mBuf, ELHI128, pst);   
         CMCHKUNPKLOG(SUnpkU16,     &gen->schdTmrVal,   mBuf, ELHI129, pst);   
         CMCHKUNPKLOG(cmUnpkStatus, &gen->poolStrtThr, mBuf, ELHI130, pst);   
         CMCHKUNPKLOG(cmUnpkStatus, &gen->poolDropThr, mBuf, ELHI131, pst);   
         CMCHKUNPKLOG(cmUnpkStatus, &gen->poolStopThr, mBuf, ELHI132, pst);   
         CMCHKUNPKLOG(cmUnpkTicks,  &gen->timeRes,      mBuf, ELHI133, pst);   
         CMCHKUNPKLOG(cmUnpkPst,    &gen->lmPst,        mBuf, ELHI134, pst); 

   /* hi009.104 - added to unpack the addr & port to bind the generic sock */
#ifdef HI_SPECIFY_GENSOCK_ADDR     
         CMCHKUNPKLOG(cmUnpkCmIpv4TptAddr, 
                                &gen->ipv4GenSockAddr, mBuf, ELHIXXX, pst);
#ifdef IPV6_SUPPORTED         
         CMCHKUNPKLOG(cmUnpkCmIpv6TptAddr,
                                &gen->ipv6GenSockAddr, mBuf, ELHIXXX, pst);
#endif /* IPV6_SUPPORTED */             
#endif /* HI_SPECIFY_GENSOCK_ADDR */         
      break;
      }

      case STTSAP:
      {
         HiSapCfg *sap = &(mgt.t.cfg.s.hiSap);

         CMCHKUNPKLOG(cmUnpkSpId,&sap->spId,       mBuf, ELHI135, pst);   
         CMCHKUNPKLOG(cmUnpkBool,&sap->flcEnb,     mBuf, ELHI136, pst);   
         CMCHKUNPKLOG(SUnpkU32,  &sap->txqCongStrtLim, mBuf, ELHI137, pst);   
         CMCHKUNPKLOG(SUnpkU32,  &sap->txqCongDropLim,  mBuf, ELHI138, pst);   
         CMCHKUNPKLOG(SUnpkU32,  &sap->txqCongStopLim,  mBuf, ELHI139, pst);   
         CMCHKUNPKLOG(SUnpkU16,  &sap->numBins,  mBuf, ELHI140, pst);   
         CMCHKUNPKLOG(cmUnpkPrior, &sap->uiPrior,  mBuf, ELHI141, pst);   
         CMCHKUNPKLOG(cmUnpkRoute, &sap->uiRoute,  mBuf, ELHI142, pst);   
         CMCHKUNPKLOG(cmUnpkSelector,&sap->uiSel,    mBuf, ELHI143, pst);   
         CMCHKUNPKLOG(cmUnpkMemoryId,&sap->uiMemId,  mBuf, ELHI144, pst);   
         for(i=LHI_MAX_HDR_TYPE; i >0; i--)
         {
            CMCHKUNPKLOG(SUnpkU32, &sap->hdrInf[i-1].flag,    mBuf, 
                         ELHI145, pst);
            CMCHKUNPKLOG(SUnpkU32, &sap->hdrInf[i-1].lenLen,  mBuf, 
                         ELHI146, pst);
            CMCHKUNPKLOG(SUnpkU32, &sap->hdrInf[i-1].offLen,  mBuf, 
                         ELHI147, pst);
            CMCHKUNPKLOG(SUnpkU32, &sap->hdrInf[i-1].hdrLen,  mBuf, 
                         ELHI148, pst);
         }/* end for loop */

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* hi009.104 - addition - unpacking fields for interface ver info */
         CMCHKUNPKLOG(SUnpkU8, &sap->remIntfValid, mBuf, ELHIXXX, pst);
         CMCHKUNPKLOG(cmUnpkIntfVer, &sap->remIntfVer, mBuf, ELHIXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */         
      break;
      }

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI149, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiCfgReq () Failed"); 
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }/* end of switch */

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);

   RETVALUE(ROK);
}


/*
*
*       Fun:   Un-pack Config Confirm
*
*       Desc:  This function is used to a un-pack config confirm 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLhiCfgCfm
(
LhiCfgCfm func,
Pst *pst,                 /* post structure */    
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiCfgCfm(func, pst, mBuf)
LhiCfgCfm func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;              /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */

   TRC3(cmUnpkLhiCfgCfm)

   /* hi009.104 - added missing init to 0 */
   HI_ZERO((U8*)&mgt, sizeof(HiMngmt))
   
   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI150, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI151, pst);

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);

   RETVALUE(ROK);
} /* end of cmUnpkLhiCfgCfm */


/*
*
*       Fun:   Un-pack Control Request
*
*       Desc:  This function is used to un-pack the control request 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiCntrlReq
(
LhiCntrlReq func,
Pst *pst,                 /* post structure */    
Buffer *mBuf              /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiCntrlReq(func, pst, mBuf)
LhiCntrlReq func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;             /* message buffer */
#endif
{
   HiMngmt  mgt;          /* configuration */

   TRC3(cmUnpkLhiCntrlReq)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI152, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI153, pst);

   CMCHKUNPKLOG(cmUnpkDateTime, &mgt.t.cntrl.dt,  mBuf, ELHI154, pst);
   CMCHKUNPKLOG(SUnpkU8, &mgt.t.cntrl.action,    mBuf, ELHI155, pst);
   CMCHKUNPKLOG(SUnpkU8, &mgt.t.cntrl.subAction, mBuf, ELHI156, pst);

   switch(mgt.hdr.elmId.elmnt) 
   {
      case STGEN:
         if(mgt.t.cntrl.subAction == SADBG)
         {
#ifdef DEBUGP
           CMCHKUNPKLOG(SUnpkU32, &(mgt.t.cntrl.ctlType.hiDbg.dbgMask), 
                        mBuf, ELHI157, pst);
#endif
         }
         break;

      case STTSAP:
         if(mgt.t.cntrl.subAction == SAELMNT)
         {
            CMCHKUNPKLOG(cmUnpkSpId, &(mgt.t.cntrl.ctlType.sapId), mBuf, 
                         ELHI158, pst);
         }
         else if(mgt.t.cntrl.subAction == SATRC)
         {
            CMCHKUNPKLOG(SUnpkS16, &(mgt.t.cntrl.ctlType.trcDat.trcLen), 
                         mBuf, ELHI159, pst);
            CMCHKUNPKLOG(cmUnpkSpId, &(mgt.t.cntrl.ctlType.trcDat.sapId), 
                         mBuf, ELHI160, pst);
         }
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI161, mgt.t.cntrl.subAction, 
                     "cmUnpkLhiCntrlReq() : invalid subAction(STTSAP)"); 
#endif /* ERRCLS_DEBUG */
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         break;

      case STGRTSAP:
         if(mgt.t.cntrl.subAction == SAGR_PRIORITY)
         {
            CMCHKUNPKLOG(cmUnpkPrior, &(mgt.t.cntrl.ctlType.priority), mBuf, 
                         ELHI162, pst);
         }
         else if(mgt.t.cntrl.subAction == SAGR_ROUTE)
         {
            CMCHKUNPKLOG(cmUnpkRoute, &(mgt.t.cntrl.ctlType.route), mBuf, 
                         ELHI163, pst);
         }
         else if(mgt.t.cntrl.subAction == SAGR_DSTPROCID)
         {
            CMCHKUNPKLOG(cmUnpkProcId, &(mgt.t.cntrl.ctlType.dstProcId), mBuf,
                         ELHI164, pst);
         }
         else
         {
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI165, mgt.t.cntrl.subAction, 
             "cmUnpkLhiCntrlReq () Failed : invalid subAction(STGRTSAP)"); 
#endif
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
         }
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI166, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiCntrlReq () Failed"); 
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }/* end of switch */

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);
   RETVALUE(ROK);
}


/*
*
*       Fun:   Un-pack Control Confirm
*
*       Desc:  This function is used to un-pack the control confirm 
*              to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiCntrlCfm
(
LhiCntrlCfm func,
Pst *pst,                 /* post structure */    
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiCntrlCfm(func, pst, mBuf)
LhiCntrlCfm func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;              /* message buffer */
#endif
{
   HiMngmt  cfm;            /* configuration */
 
   TRC3(cmUnpkLhiCntrlCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELHI167, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELHI168, pst);

   (Void)SPutMsg(mBuf);
   (*func)(pst, &cfm);
   RETVALUE(ROK);
} /* end of cmUnpkLhiCntrlCfm */


 
/*
*
*       Fun:   Un-pack Statistics Request
*
*       Desc:  This function is used to un-pack the statistics request
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiStsReq
(
LhiStsReq func,
Pst *pst,                 /* post structure */    
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiStsReq(func, pst, mBuf)
LhiStsReq func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;              /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */
   Action   action;         /* action type */

   TRC3(cmUnpkLhiStsReq)

   CMCHKUNPKLOG(cmUnpkAction,   &action,  mBuf, ELHI169, pst);
   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI170, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI171, pst);

   switch(mgt.hdr.elmId.elmnt)
   {
      case STGEN:
        break;
      case STTSAP:
      {
         CMCHKUNPKLOG(cmUnpkSpId, &mgt.t.sts.s.sapSts.sapId, mBuf, ELHI172, 
                      pst);
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI173, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiStsReq () Failed"); 
#endif
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);
   (*func)(pst, action, &mgt);
   RETVALUE(ROK);
} /* end of cmUnpkLhiStsReq */

 
/*
*
*       Fun:   Un-pack Statistics Confirm
*
*       Desc:  This function is used to un-pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiStsCfm
(
LhiStsCfm func,
Pst *pst,                 /* post structure */    
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiStsCfm(func, pst, mBuf)
LhiStsCfm func;
Pst *pst;                 /* post structure */    
Buffer *mBuf;              /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */

   TRC3(cmUnpkLhiStsCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI174, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI175, pst);
   
   CMCHKUNPKLOG(cmUnpkDateTime, &mgt.t.sts.dt,   mBuf, ELHI176, pst);
   CMCHKUNPKLOG(cmUnpkDuration, &mgt.t.sts.dura, mBuf, ELHI177, pst);

   switch(mgt.hdr.elmId.elmnt)
   {
      case STGEN:
      {
         HiGenSts *gSts = &(mgt.t.sts.s.genSts);

         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numCons,     mBuf, ELHI178, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockTxErr,   mBuf, ELHI179, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockRxErr,   mBuf, ELHI180, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockOpenErr, mBuf, ELHI181, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockBindErr, mBuf, ELHI182, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockCnctErr, mBuf, ELHI183, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockLstnErr, mBuf, ELHI184, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockSOptErr, mBuf, ELHI185, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockClosErr, mBuf, ELHI186, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->sockShutErr, mBuf, ELHI187, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->rxMsgVerErr, mBuf, ELHI188, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numFlcInd,   mBuf, ELHI189, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numTxTcpMsg, mBuf, ELHI190, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numRxTcpMsg, mBuf, ELHI191, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numTxUdpMsg, mBuf, ELHI192, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numRxUdpMsg, mBuf, ELHI193, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numTxbytes,  mBuf, ELHI194, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numRxbytes,  mBuf, ELHI195, pst);
#ifdef HI_REL_1_3  
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numTxRawMsg,  mBuf, ELHI196, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &gSts->numRxRawMsg,  mBuf, ELHI197, pst);
#endif  /* HI_REL_1_3 */ 
         break;
      }
      case STTSAP:
      {
         HiSapSts *sSts = &(mgt.t.sts.s.sapSts);

         CMCHKUNPKLOG(cmUnpkSpId,    &sSts->sapId,       mBuf, ELHI198, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numCons,     mBuf, ELHI199, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numTxTcpMsg, mBuf, ELHI200, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numRxTcpMsg, mBuf, ELHI201, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numTxUdpMsg, mBuf, ELHI202, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numRxUdpMsg, mBuf, ELHI203, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numTxbytes,  mBuf, ELHI204, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numRxbytes,  mBuf, ELHI205, pst);
#ifdef HI_REL_1_3
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numTxRawMsg,  mBuf, ELHI206, pst);
         CMCHKUNPKLOG(cmUnpkStsCntr, &sSts->numRxRawMsg,  mBuf, ELHI207, pst);
#endif  /* HI_REL_1_3 */ 
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI208, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiStsCfm () Failed"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }
   
   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);
   RETVALUE(ROK);
}


/*
*
*       Fun:   Un-pack Status Request
*
*       Desc:  This function is used to un-pack the status request
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiStaReq
(
LhiStaReq func,
Pst *pst,                 /* post structure */     
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiStaReq(func, pst, mBuf)
LhiStaReq func;
Pst *pst;                 /* post structure */     
Buffer *mBuf;              /* message buffer */
#endif
{
   HiMngmt  mgt;            /* configuration */

   TRC3(cmUnpkLhiStaReq)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI209, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI210, pst);
   
   switch(mgt.hdr.elmId.elmnt)
   {
      case STSID:
         break;
      case STTSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &mgt.t.ssta.s.sapSta.spId, mBuf, 
                      ELHI211, pst);
         break;
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI212, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiStaReq () Failed"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);
   RETVALUE(ROK);
}


/*
*
*       Fun:   Un-pack Status Confirm
*
*       Desc:  This function is used to un-pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiStaCfm
(
LhiStaCfm func,
Pst *pst,                 /* post structure */     
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiStaCfm(func, pst, mBuf)
LhiStaCfm func;
Pst *pst;                 /* post structure */     
Buffer *mBuf;              /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */
   Txt      ptNum[8];       /* part number */
    
   TRC3(cmUnpkLhiStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI213, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI214, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &mgt.t.ssta.dt, mBuf, ELHI215, pst);
   
   switch(mgt.hdr.elmId.elmnt)
   {
      case STSID:
      {
         mgt.t.ssta.s.sysId.ptNmb = ptNum;
         CMCHKUNPKLOG(cmUnpkSystemId, &(mgt.t.ssta.s.sysId), 
                      mBuf, ELHI216, pst);
         break;
      }
      case STTSAP:
      {
         HiSapSta *sSta = &(mgt.t.ssta.s.sapSta);

         CMCHKUNPKLOG(cmUnpkSpId,  &(sSta->spId),  mBuf, ELHI217, pst);
         CMCHKUNPKLOG(cmUnpkState, &(sSta->state), mBuf, ELHI218, pst);
/* hi009.104 - addition - unpacking self and remote interface version num */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG(SUnpkU8, &sSta->remIntfValid, mBuf, ELHIXXX, pst);
         CMCHKUNPKLOG(cmUnpkIntfVer, &sSta->selfIfVer, mBuf, ELHIXXX, pst);   
         CMCHKUNPKLOG(cmUnpkIntfVer, &sSta->remIfVer, mBuf, ELHIXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LHILOGERROR(pst, ELHI219, mgt.hdr.elmId.elmnt, 
                     "cmUnpkLhiStaReq () Failed"); 
#endif /* ERRCLS_DEBUG */
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);
   RETVALUE(ROK);
} /* end of cmUnpkLhiStaCfm */


/*
*
*       Fun:   Un-pack Status Indication
*
*       Desc:  This function is used to un-pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiStaInd
(
LhiStaInd func,
Pst *pst,                 /* post structure */
Buffer *mBuf               /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiStaInd(func, pst, mBuf)
LhiStaInd func;
Pst *pst;                 /* post structure */   
Buffer *mBuf;              /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */

   TRC3(cmUnpkLhiStaInd)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI220, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI221, pst);
   
   CMCHKUNPKLOG(cmUnpkCmAlarm, &mgt.t.usta.alarm,      mBuf, ELHI222, pst);
   CMCHKUNPKLOG(cmUnpkSpId,    &mgt.t.usta.info.spId,  mBuf, ELHI223, pst);
   CMCHKUNPKLOG(SUnpkU8,       &mgt.t.usta.info.type,  mBuf, ELHI224, pst);

   if(mgt.t.usta.info.type != LHI_ALARMINFO_TYPE_NTPRSNT)
   {
      switch(mgt.t.usta.info.type)
      {
         case LHI_ALARMINFO_SAP_STATE:
            CMCHKUNPKLOG(cmUnpkState, &mgt.t.usta.info.inf.state, 
                         mBuf, ELHI225, pst);
            break;

         case LHI_ALARMINFO_CON_STATE:
            CMCHKPKLOG(cmUnpkState, &mgt.t.usta.info.inf.conState, 
                       mBuf, ELHI226, pst);
            break;

         case LHI_ALARMINFO_MEM_ID:
            CMCHKPKLOG(cmUnpkPool, &mgt.t.usta.info.inf.mem.pool, mBuf, 
                       ELHI227, pst);
            CMCHKPKLOG(cmUnpkRegion, &mgt.t.usta.info.inf.mem.region, mBuf, 
                       ELHI228, pst);
            break;

         case LHI_ALARMINFO_PAR_TYPE:
            CMCHKPKLOG(SUnpkU8, &mgt.t.usta.info.inf.parType, mBuf, 
                       ELHI229, pst);
            break;

         default:
#if (ERRCLASS & ERRCLS_DEBUG)
            LHILOGERROR(pst, ELHI230, mgt.t.usta.info.type, 
                        "cmUnpkLhiStaInd () Failed"); 
#endif /* ERRCLS_DEBUG */
            (Void)SPutMsg(mBuf);
            RETVALUE(RFAILED);
      }/* end of switch */
   }

   (Void)SPutMsg(mBuf);
   (*func)(pst, &mgt);
   RETVALUE(ROK);
} /* end of cmUnpkLhiStaInd */
 


/*
*
*       Fun:   Un-pack Trace Indication
*
*       Desc:  This function is used to un-pack the trace indication
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lhi.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLhiTrcInd
(
LhiTrcInd func,
Pst *pst,                 /* post */
Buffer  *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLhiTrcInd(func, pst, mBuf)
LhiTrcInd func;
Pst *pst;                 /* post */
Buffer  *mBuf;            /* message buffer */
#endif
{
 
   HiMngmt  mgt;            /* configuration */

   TRC3(cmUnpkLhiTrcInd)

   CMCHKUNPKLOG(cmUnpkHeader,   &mgt.hdr, mBuf, ELHI231, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &mgt.cfm, mBuf, ELHI232, pst);

   CMCHKUNPKLOG(cmUnpkDateTime, &mgt.t.trc.dt, mBuf, ELHI233, pst);
   CMCHKUNPKLOG(SUnpkU16, &mgt.t.trc.evnt, mBuf, ELHI234, pst);
   /* hi023.104 Sap Id in Trace Information */
#ifdef HI_ENB_SAP_TRC
   CMCHKUNPKLOG(SUnpkU16, &mgt.t.trc.sap, mBuf, ELHI234, pst);
#endif
   (*func)(pst, &mgt, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkLhiTrcInd */

#endif /* LCLHI */

/********************************************************************30**
 
         End of file:     lhi.c@@/main/4 - Thu Jun 28 13:31:14 2001

*********************************************************************31*/
 
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
 
/********************************************************************50**
 
*********************************************************************51*/
 
/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/
/********************************************************************70**
  
  version    initials                   description
-----------  ---------  ------------------------------------------------
 
*********************************************************************71*/
 
/********************************************************************80**
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      asa  1. initial release.
1.1+         hi002.11 asa  1. numCons in HiGenCfg changed to U32.
                          2. added HiHdrInfo in HiSapCfg.
1.1+         hi003.11 asa  1. allocating memory before calling
                             cmUnpkSystemId().
/main/2       ---      cvp  1. added new parameters numFdsPerSet and  
                             numFdBins in HiGenCfg structure.
                          2. fixed bug in StsCfm primitive.
                          3. changed the copyright header.
             /main/4                sb   1. changes for Raw socket interface.added 
                             numRxRawMsg & numTxRawMsg.
/main/4+     hi005.13 cvp  1. Added new general configuration parameters
                              selTimeout, numUdpMsgsToRead, 
                              numUdpMsgsToRead and numClToAccept 
                              packing and unpacking functions. The flag
                              name that protect these changes is 
                              HI006_12. The flag name is kept to 
                              preserve backward compatibility with the
                              modifications in the earlier release.
/main/4      ---      cvp  1. Changed the copyright header.
                           2. Updated error codes.
/main/4    hi009.104  mmh  1. added Rolling Upgrade support
                               - call LHI_ZERO macro in cmUnpkLhiCfgReq()
                               - include header file hi.h and cm_lib.x for RUG
                               - in cmPkLhiCfgReq() added packing fields for
                                 interface ver info.
                               - in cmPkLhiCfgReq() fill interface version 
                                 number in pst.
                               - in cmPkLhiCntrlReq(), cmPkLhiStsReq(), 
                                 cmPkLhiStaReq(), fill interface 
                                 version number in pst.
                               - in cmPkLhiStaCfm() pcak self and remote 
                                 interface version num.
                               - in cmUnpkLhiCfgReq(), cmUnpkLhiStaCfm() added
                                 for unpacking fields for interface ver info.
                               - added init of mgt in cmUnpkLhiCfgCfm()
                           2. added the calls to pack/unpack the addr/port
                              to be used to bind generic sockets in functions
                              cmPkLhiCfgReq and cmUnpkLhiCfgReq under the
                              flag HI_SPECIFY_GENSOCK_ADDR
/main/4+    hi023.104 jc  1. Add Sap Id in Trace 
*********************************************************************91*/
