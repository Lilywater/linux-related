/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     layer management interface - sccp
  
     Type:     C file
  
     Desc:     This file contains the packing/unpacking functions
               for the primitives on lsp interface

     File:     lsp.c

     Sid:      lsp.c@@/main/4_1 - Tue Jan 22 15:14:22 2002
  
     Prg:      cp
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "cm_ss7.h"        /* common ss7 */
#include "lsp.h"           /* spt interface */
#include "cm_err.h"        /* common error */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */
#include "lsp.x"           /* spt interface */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */
#ifdef LCLSP
PRIVATE S16 cmPkSpGenCfg ARGS((Pst *pst, SpGenCfg *spGenCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSpGenCfg ARGS((Pst *pst, LspRetroCfgReq func1,
                                 SpGenCfg *spGenCfg, Buffer *mBuf));
PRIVATE S16 cmPkSpNwCfg ARGS((Pst *pst, SpNwCfg *spNwCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSpNwCfg ARGS((Pst *pst, LspRetroCfgReq func1,
                                SpNwCfg *spNwCfg, Buffer *mBuf));
PRIVATE S16 cmPkSpSAPCfg ARGS((Pst *pst, SpSAPCfg *spSAPCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSpSAPCfg ARGS((Pst *pst, SpSAPCfg *spSAPCfg, Buffer *mBuf));
PRIVATE S16 cmPkSpNSAPCfg ARGS((Pst *pst, SpNSAPCfg *spNSAPCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSpNSAPCfg ARGS((Pst *pst, SpNSAPCfg *spNSAPCfg,Buffer *mBuf));
PRIVATE S16 cmPkSpRteCfg ARGS((Pst *pst, SpRteCfg *spRteCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSpRteCfg ARGS((Pst *pst, SpRteCfg *spRteCfg, Buffer *mBuf));

#if (SS7_ANS96 || SS7_BELL05)
PRIVATE S16 cmPkSpNidDpcCfg ARGS((Pst *pst, SpNidDpcCfg *spNidDpcCfg,
                                  Buffer *mBuf));
PRIVATE S16 cmUnpkSpNidDpcCfg ARGS((Pst *pst, SpNidDpcCfg *spNidDpcCfg,
                                    Buffer *mBuf));
#endif /* SS7_ANS96 || SS7_BELL05 */

#ifdef SS7_BELL05
PRIVATE S16 cmPkSpNwNidSs7NidCfg ARGS((Pst *pst,
                                       SpNwNidSs7NidCfg *spNwNidSs7NidCfg,
                                       Buffer *mBuf));
PRIVATE S16 cmUnpkSpNwNidSs7NidCfg ARGS((Pst *pst,
                                         SpNwNidSs7NidCfg *spNwNidSs7NidCfg,
                                         Buffer *mBuf));
#endif /* SS7_BELL05 */

PRIVATE S16 cmPkSpTrfLimCfg ARGS((Pst *pst, SpTrfLimCfg *spTrfLimCfg,
                                    Buffer *mBuf));
PRIVATE S16 cmUnpkSpTrfLimCfg ARGS((Pst *pst, SpTrfLimCfg *spTrfLimCfg,
                                    Buffer *mBuf));
PRIVATE S16 cmPkSpMsgImpCfg ARGS((Pst *pst, SpMsgImpCfg *spMsgImpCfg,
                                    Buffer *mBuf));
PRIVATE S16 cmUnpkSpMsgImpCfg ARGS((Pst *pst, SpMsgImpCfg *spMsgImpCfg,
                                    Buffer *mBuf));

PRIVATE S16 gtPkSpActn ARGS((SpActn *actn, Buffer *mBuf));
PRIVATE S16 gtUnpkSpActn ARGS((SpActn *actn, Buffer *mBuf));
PRIVATE S16 gtPkGt ARGS((GlbTi *gt, Swtch sw, Buffer *mBuf));
PRIVATE S16 gtUnpkGt ARGS((GlbTi *gt, Swtch sw, Buffer *mBuf));
PRIVATE S16 gtPkSpAddrMapCfg ARGS((Pst *pst, SpAddrMapCfg *addrMap,
                                   Buffer *mBuf));
PRIVATE S16 gtUnpkSpAddrMapCfg ARGS((Pst *pst, SpAddrMapCfg *addrMap,
                                     Buffer *mBuf));
PRIVATE S16 gtPkSpRule ARGS((SpRule *rule, Buffer *mBuf));
PRIVATE S16 gtUnpkSpRule ARGS((SpRule *rule, Buffer *mBuf));
PRIVATE S16 gtPkSpAssoCfg ARGS((Pst *pst, SpAssoCfg *assoCfg, Buffer *mBuf));
PRIVATE S16 gtUnpkSpAssoCfg ARGS((Pst *pst, SpAssoCfg *assoCfg, Buffer *mBuf));
#endif /* LCLSP */

/* local function definition */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/*
 * support functions
 */

#ifdef LCLSP
  
/*
*
*       Fun:   cmUnpkLspCntrlReq
*
*       Desc:  Unpack Control Request
*
*       Ret:   S16
*
*       Notes: None
*  
*       File:  lsp.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLspCntrlReq
(
LspCntrlReq func,               /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspCntrlReq(func, pst, mBuf)
LspCntrlReq func;               /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpMngmt cntrl;               /* control */
   CmIntfVer intfVer;           /* interface version number */
  
   TRC3(cmUnpkLspCntrlReq)

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkHeader, &cntrl.hdr, mBuf, ELSP001, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ELSP002, pst);
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.action, mBuf, ELSP003, pst);
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.subAction, mBuf, ELSP004, pst);

   switch (cntrl.hdr.elmId.elmnt)
   {
      case STGEN:
      {
#ifdef DEBUGP
         if (cntrl.t.cntrl.subAction == SADBG)
         {
            CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.ctlType.spDbg.dbgMask, mBuf,
                         ELSP005, pst);
         }
#endif /* DEBUGP */

         switch (intfVer)
         {
            case 0x0100:     /* interface version LSPV1 */
               if (cntrl.t.cntrl.action == ACONG)
               {
                  /* this control req is not valid in LSPV1 */
                  LSPLOGERROR(ERRCLS_DEBUG, (ErrVal)ELSP006,
                              (ErrVal) cntrl.hdr.elmId.elmnt,
                              "cmUnpkLspCntrlReq() Failed");
                  RETVALUE(RFAILED);
               }
               break;

            case 0x0200:     /* interface version LSPV2 */
            case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
            case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
            case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
            case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
            case 0x0205:     /* lsp_c_002.main_4_1 - added interface version 
                              * LSPV2_5. 
                              */ 
               if ((cntrl.t.cntrl.subAction == SAUSTA) ||
                   (cntrl.t.cntrl.subAction == SAREPORT))
               {
                  CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.ctlType.ustaMask, mBuf,
                               ELSP007, pst);
               }
               if (cntrl.t.cntrl.action == ACONG)
               {
                  CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.ctlType.spCong.sscThresh,
                               mBuf, ELSP008, pst);
                  CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.ctlType.spCong.congLvl,
                               mBuf, ELSP009, pst);
               }
               break;

            default:
               /* invalid interface version number */
               RETVALUE(RINVIFVER);
         } /* switch (intfVer) */
         break;
      }

      case STGRTSAP:
      case STGRNSAP:
      case STALLSAP:
         CMCHKUNPKLOG(SUnpkU16, &cntrl.t.cntrl.par.dstProcId, mBuf, ELSP010,
                      pst);
         break;

      case STDELADRMAP:
         CMCHKUNPKVERLOG(gtUnpkSpAddrMapCfg, &cntrl.t.cntrl.cfg.spAddrMap, mBuf,
                      ELSP011, pst);
         break;

      case STDELASSO:
         /* lsp_c_001.main_4_1 - addition - based to LSP version either unpack
          * the whole Association or just the spRule structure.
          */
         switch (intfVer)
         {
            case 0x0100:     /* interface version LSPV1 */
            case 0x0200:     /* interface version LSPV2 */
            case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
            case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
            case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
               /* We just need to unpack the rule */
               CMCHKUNPKLOG(gtUnpkSpRule, &cntrl.t.cntrl.cfg.spAsso.rule, mBuf,
                             ELSP012, pst); 
               /* lsp_c_001.main_4_1 - addition - initialise the network id to 
                * 0xffff so that the association is deleted from all the
                * network.
                */
#ifdef LSPV2_4      
               cntrl.t.cntrl.cfg.spAsso.nwId = 0xffff;
#endif /* LSPV2_4 */      
               break;
            case 0x0204:/* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
            case 0x0205:     /* lsp_c_002.main_4_1 - added interface version 
                              * LSPV2_5. 
                              */ 
               /* lsp_c_001.main_4_1 - addition - network id needed, so unpacking 
                * the full association.
                */
               CMCHKUNPKVERLOG(gtUnpkSpAssoCfg, &cntrl.t.cntrl.cfg.spAsso, mBuf, 
                               ELSPXXX, pst);
               break;
            default:
               /* invalid interface version number */
               RETVALUE(RINVIFVER);
         }
         break;

      case STDELROUT:
         CMCHKUNPKLOG(cmUnpkSpId, &cntrl.t.cntrl.cfg.spDelRte.nSapId, mBuf,
                      ELSP013, pst);
         CMCHKUNPKLOG(cmUnpkDpc, &cntrl.t.cntrl.cfg.spDelRte.dpc, mBuf, ELSP014,
                      pst);
         CMCHKUNPK(cmUnpkBool, &cntrl.t.cntrl.cfg.spDelRte.ssnPres, mBuf);
         CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.cfg.spDelRte.ssn, mBuf, ELSP015,
                      pst);
         break;

      /* sp001.302 - addition - deletion of network, sap and nSap */
      case STDELNW:        /* fall through */
      case STDELTSAP:      /* fall through */
      case STDELNSAP:
         switch (intfVer)
         {
            case 0x0100:     /* interface version LSPV1 */
               /* this control req is not valid in LSPV1 */
               LSPLOGERROR(ERRCLS_DEBUG, (ErrVal)ELSP006,
                           (ErrVal) cntrl.hdr.elmId.elmnt,
                           "cmUnpkLspCntrlReq() Failed");
               RETVALUE(RFAILED);
               break;

            case 0x0200:     /* interface version LSPV2 */
            case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
            case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
            case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
            case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
            case 0x0205:     /* lsp_c_002.main_4_1 - added interface version 
                              * LSPV2_5. 
                              */
               /* nothing to unpack */
               break;

            default:
               /* invalid interface version number */
               RETVALUE(RINVIFVER);
         } /* switch (intfVer) */
         break;
   } /* switch (...elmnt) */

   SPutMsg(mBuf);
   (*func)(pst, &cntrl);

   RETVALUE(ROK);
} /* end of cmUnpkLspCntrlReq */

  
/*
*
*       Fun:   cmUnpkLspStsReq
*
*       Desc:  Unpack Statistics Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLspStsReq
(
LspStsReq func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspStsReq(func, pst, mBuf)
LspStsReq func;                 /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   Action action;               /* action */
   SpMngmt sts;                 /* statistics */
  
   TRC3(cmUnpkLspStsReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELSP016, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELSP017, pst);

   /* unpack fields depending upon the element type */
   switch (sts.hdr.elmId.elmnt)
   {
      case STGEN:     /* fall through */
      case STNSAP:    /* fall through */
      case STTSAP:    /* fall through */
         /* Nothing to unpack */
         break;

      case STROUT:
         /* unpack the network Id */
         CMCHKUNPKLOG(cmUnpkNwId, &sts.t.sts.s.spRteSts.nwId, mBuf, ELSP018,
                      pst);
         CMCHKUNPKLOG(cmUnpkDpc, &sts.t.sts.s.spRteSts.pc, mBuf, ELSP019, pst);
         break;
   } /* switch (...elmnt) */

   CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ELSP020, pst);
   SPutMsg(mBuf);
   (*func)(pst, action, &sts);
   RETVALUE(ROK);
} /* end of cmUnpkLspStsReq */

  
/*
*
*       Fun:   cmUnpkLspStaReq
*
*       Desc:  Unpack Status Request
*
*       Ret:   S16
*
*       Notes: None
*
*       File:  lsp.c
*
*/

#ifdef ANSI
PUBLIC S16 cmUnpkLspStaReq
(
LspStaReq func,                 /* primitive to call */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspStaReq(func, pst, mBuf)
LspStaReq func;                 /* primitive to call */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpMngmt sta;                 /* status */
  
   TRC3(cmUnpkLspStaReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELSP021, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case STNSAP:   /* lower SAP - fall through */
      case STTSAP:   /* upper SAP - fall through */
      case STSID:    /* system Id */
         /* Nothing to unpack */
         break;

      case STROUT:
         /* Unpack the swtch */
         CMCHKUNPKLOG(cmUnpkNwId, &sta.t.ssta.s.spRteSta.pcSta.nwId, mBuf,
                      ELSP022, pst);
         /* Unpack the pointcode */
         CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.s.spRteSta.pcSta.pc, mBuf,
                      ELSP023, pst);
         break;
         
      default:
         /* Ignore */
         break;
   } /* switch (...elmnt) */

   SPutMsg(mBuf);
   (*func)(pst, &sta);

   RETVALUE(ROK);
} /* end of cmUnpkLspStaReq */

  
/*
*
*       Fun:   cmUnpkLspCfgReq
*
*       Desc:  Unpack Configuration Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLspCfgReq
(
LspCfgReq func,                 /* primitive to call */
LspRetroCfgReq func1,           /* function for retrofitting genCfg param */
Pst *pst,                       /* post structure */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspCfgReq(func, func1, pst, mBuf)
LspCfgReq func;                 /* primitive to call */
LspRetroCfgReq func1;           /* function for retrofitting genCfg param */
Pst *pst;                       /* post structure */
Buffer *mBuf;                   /* message buffer */
#endif
{
   SpMngmt cfg;                 /* configuration */
   S16 ret1;                    /* return value */
  
   TRC3(cmUnpkLspCfgReq)
   
   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ELSP024, pst);

   switch (cfg.hdr.elmId.elmnt)
   {
      case STGEN:
         ret1 = cmUnpkSpGenCfg(pst, func1, &cfg.t.cfg.s.spGen, mBuf);
         break;

      case STNW:
         ret1 = cmUnpkSpNwCfg(pst, func1, &cfg.t.cfg.s.spNw, mBuf);
         break;

      case STTSAP:
         CMCHKUNPKVERLOG(cmUnpkSpSAPCfg, &cfg.t.cfg.s.spSap, mBuf, ELSP025,
                         pst);
         break;

      case STNSAP:
         CMCHKUNPKVERLOG(cmUnpkSpNSAPCfg, &cfg.t.cfg.s.spNSap, mBuf, ELSP026,
                         pst);
         break;

      case STASSO :
         CMCHKUNPKVERLOG(gtUnpkSpAssoCfg, &cfg.t.cfg.s.spAsso, mBuf, ELSP027,
                         pst);
         break;

      case STADRMAP:
         CMCHKUNPKVERLOG(gtUnpkSpAddrMapCfg, &cfg.t.cfg.s.spAddrMap, mBuf,
                         ELSP028, pst);
         break;

      case STROUT:
         CMCHKUNPKVERLOG(cmUnpkSpRteCfg, &cfg.t.cfg.s.spRte, mBuf, ELSP029,
                         pst);
         break;

#if (SS7_ANS96 || SS7_BELL05)
      case STNIDPC:
         CMCHKUNPKVERLOG(cmUnpkSpNidDpcCfg, &cfg.t.cfg.s.spNidDpc, mBuf,
                         ELSP030, pst);
         break;
#endif /* SS7_ANS96 || SS7_BELL05 */

#ifdef SS7_BELL05
      case STNWSS7:
         CMCHKUNPKVERLOG(cmUnpkSpNwNidSs7NidCfg, &cfg.t.cfg.s.spNwNidSs7Nid,
                         mBuf, ELSP031, pst);
         break;
#endif /* SS7_BELL05 */

      case STTRFLIM:
         CMCHKUNPKVERLOG(cmUnpkSpTrfLimCfg, &cfg.t.cfg.s.spTrfLim, mBuf,
                         ELSP032, pst);
         break;

      case STMSGIMP:
         CMCHKUNPKVERLOG(cmUnpkSpMsgImpCfg, &cfg.t.cfg.s.spMsgImp, mBuf,
                         ELSP033, pst);
         break;

      default:
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal) ELSPXXX, 
                     (ErrVal) (cfg.hdr.elmId.elmnt),
                     "cmUnpkLspCfgReq() Failed"); 
         RETVALUE(RFAILED);
   } /* switch (...elmnt) */

   (Void) SPutMsg(mBuf);
   (*func)(pst, &cfg);
   RETVALUE(ROK);
} /* cmUnpkLspCfgReq */


/*
*
*       Fun:   Pack Configuration Request
*
*       Desc:  This function is used to pack the configuration request
*              primitive to SCCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLspCfgReq
(
Pst *pst,                   /* post structure */    
SpMngmt *cfg                /* configuration */
)
#else
PUBLIC S16 cmPkLspCfgReq(pst, cfg)
Pst *pst;                   /* post structure */    
SpMngmt *cfg;               /* configuration */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLspCfgReq)

   SGetMsg(pst->region, pst->pool, &mBuf);

   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:   /* general configuration */
         CMCHKPKVERLOG(cmPkSpGenCfg, &cfg->t.cfg.s.spGen, mBuf, ELSP034, pst);
         break;

      case STNW:    /* network configuration */
         CMCHKPKVERLOG(cmPkSpNwCfg, &cfg->t.cfg.s.spNw, mBuf, ELSP035, pst);
         break;

      case STTSAP:  /* Upper SAP configuration */
         CMCHKPKVERLOG(cmPkSpSAPCfg, &cfg->t.cfg.s.spSap, mBuf, ELSP036, pst);
         break;

      case STNSAP:  /* lower SAP configuration */ 
         CMCHKPKVERLOG(cmPkSpNSAPCfg, &cfg->t.cfg.s.spNSap, mBuf, ELSP037, pst);
         break;

      case STASSO:  /* association configuration */
         CMCHKPKVERLOG(gtPkSpAssoCfg, &cfg->t.cfg.s.spAsso, mBuf, ELSP038, pst);
         break;

      case STADRMAP:  /* addres map configuration */
         CMCHKPKVERLOG(gtPkSpAddrMapCfg, &cfg->t.cfg.s.spAddrMap, mBuf, ELSP039,
                       pst);
         break;

      case STROUT:    /* route configuration */
         CMCHKPKVERLOG(cmPkSpRteCfg, &cfg->t.cfg.s.spRte, mBuf, ELSP040, pst);
         break;

#if (SS7_ANS96 || SS7_BELL05)
      case STNIDPC:   /* NID to DPC mapping configuration */
         CMCHKPKVERLOG(cmPkSpNidDpcCfg, &cfg->t.cfg.s.spNidDpc, mBuf, ELSP041,
                       pst);
         break;
#endif /* SS7_ANS96 || SS7_BELL05 */

#ifdef SS7_BELL05
      case STNWSS7:   /* Network specific NID to SS7 format NID mapping cfg */
         CMCHKPKVERLOG(cmPkSpNwNidSs7NidCfg, &cfg->t.cfg.s.spNwNidSs7Nid, mBuf,
                       ELSP042, pst);
         break;
#endif /* SS7_BELL05 */

      case STTRFLIM:  /* traffic limitation database configuration */
         CMCHKPKVERLOG(cmPkSpTrfLimCfg, &cfg->t.cfg.s.spTrfLim, mBuf, ELSP043,
                       pst);
         break;

      case STMSGIMP:  /* message importance configuration */
         CMCHKPKVERLOG(cmPkSpMsgImpCfg, &cfg->t.cfg.s.spMsgImp, mBuf, ELSP044,
                       pst);
         break;

      default:
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal) ELSP045, 
                     (ErrVal) cfg->hdr.elmId.elmnt, "cmPkLspCfgReq () Failed"); 
         RETVALUE(RFAILED);
   } /* switch (...elmnt) */

   CMCHKPKLOG(cmPkHeader, &cfg->hdr, mBuf, ELSP046, pst);
   pst->event = (Event) EVTLSPCFGREQ;

/* fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspCfgReq */


/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to SCCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspStaReq
(
Pst *pst,                   /* post structure */    
SpMngmt *sta                /* solicited status */
)
#else
PUBLIC S16 cmPkLspStaReq(pst, sta)
Pst *pst;                   /* post structure */    
SpMngmt *sta;               /* solicited status */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLspStaReq)
   SGetMsg(pst->region, pst->pool, &mBuf);
   switch (sta->hdr.elmId.elmnt)
   {
      case STNSAP:   /* lower SAP - fall through */
      case STTSAP:   /* upper SAP - fall through */
      case STSID:    /* system Id */
         /* Nothing to pack */
         break;

      case STROUT:
         /* Pack the pointcode */
         CMCHKPKLOG(cmPkDpc, sta->t.ssta.s.spRteSta.pcSta.pc, mBuf, ELSP047,
                    pst);
         /* Pack the network Id */
         CMCHKPKLOG(cmPkNwId, sta->t.ssta.s.spRteSta.pcSta.nwId, mBuf, ELSP048,
                    pst);
         break;

      default:
         /* Do not pack the union */
         break;
   }

   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELSP049, pst);
   pst->event = (Event)EVTLSPSTAREQ;

   /* fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspStaReq */
 

/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to SCCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspStsReq
(
Pst *pst,                   /* post structure */    
Action action,              /* action */
SpMngmt *sts                /* statistics */
)
#else
PUBLIC S16 cmPkLspStsReq(pst, action, sts)
Pst *pst;                   /* post structure */    
Action action;              /* action */
SpMngmt *sts;               /* statistics */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLspStsReq)
   SGetMsg(pst->region, pst->pool, &mBuf);

   CMCHKPKLOG(SPkS16, action, mBuf, ELSP050, pst);

   /* pack fields depending upon the element type */
   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:    /* fall through */
      case STNSAP:   /* fall through */
      case STTSAP:
         /* Nothing to pack */
         break;

      case STROUT:
         /* Pack the pointcode */
         CMCHKPKLOG(cmPkDpc, sts->t.sts.s.spRteSts.pc, mBuf, ELSP051, pst);
         /* Pack the network Id */
         CMCHKPKLOG(cmPkNwId, sts->t.sts.s.spRteSts.nwId, mBuf, ELSP052, pst);
         break;

      default:
         /* Do not pack the union */
         break;
   } /* switch (...elmnt) */

   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELSP053, pst);
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELSP054, pst);
   pst->event = (Event)EVTLSPSTSREQ;

/* fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      pst->intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspStsReq */
 

/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request
*              primitive to SCCP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspCntrlReq
(
Pst *pst,                   /* post structure */
SpMngmt *cntrl              /* control */
)
#else
PUBLIC S16 cmPkLspCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */
SpMngmt *cntrl;             /* control */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(cmPkLspCntrlReq)
   SGetMsg(pst->region, pst->pool, &mBuf);

   switch (cntrl->hdr.elmId.elmnt)
   {
      case STGEN:
#ifdef DEBUGP
         if (cntrl->t.cntrl.subAction == SADBG)
         {
            CMCHKPKLOG(SPkU32, cntrl->t.cntrl.ctlType.spDbg.dbgMask, mBuf,
                       ELSP055, pst);
         }
#endif /* DEBUGP */
         if ((cntrl->t.cntrl.subAction == SAUSTA) ||
             (cntrl->t.cntrl.subAction == SAREPORT))
         {
            CMCHKPKLOG(SPkU32, cntrl->t.cntrl.ctlType.ustaMask, mBuf,
                       ELSP056, pst);
         }
         if (cntrl->t.cntrl.action == ACONG)
         {
            CMCHKPKLOG(SPkU8, cntrl->t.cntrl.ctlType.spCong.congLvl, mBuf,
                       ELSP057, pst);
            CMCHKPKLOG(SPkU8, cntrl->t.cntrl.ctlType.spCong.sscThresh, mBuf,
                       ELSP058, pst);
         }
         break;

      case STGRTSAP:
      case STGRNSAP:
      case STALLSAP:
         CMCHKPKLOG(SPkU16, cntrl->t.cntrl.par.dstProcId, mBuf, ELSP059, pst);
         break;

      case STDELASSO:
         /* lsp_c_001.main_4_1 - modification - now we pack the full association */
         CMCHKPKVERLOG(gtPkSpAssoCfg, &cntrl->t.cntrl.cfg.spAsso, mBuf, ELSPXXX,
                       pst);
         /* lsp_c_001.main_4_1 - deletion - packing of rule not required */
         break;

      case STDELADRMAP:
         /* Optimise the packing for the deletion case */
         CMCHKPKVERLOG(gtPkSpAddrMapCfg, &cntrl->t.cntrl.cfg.spAddrMap, mBuf,
                       ELSP061, pst);
         break;

      case STDELROUT:
         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.cfg.spDelRte.ssn, mBuf, ELSP062, pst);
         CMCHKPK(cmPkBool, cntrl->t.cntrl.cfg.spDelRte.ssnPres, mBuf);
         CMCHKPKLOG(cmPkDpc, cntrl->t.cntrl.cfg.spDelRte.dpc, mBuf, ELSP063,
                    pst);
         CMCHKPKLOG(cmPkSpId, cntrl->t.cntrl.cfg.spDelRte.nSapId, mBuf, ELSP064,
                    pst);
         break;

      /* sp001.302 - addition - deletion of network, sap and nSap */
      case STDELNW:      /* fall through */
      case STDELTSAP:    /* fall through */
      case STDELNSAP:
         /* nothing to unpack */
         break;
   } /* switch (...elmnt) */

   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.subAction, mBuf, ELSP065, pst);
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.action, mBuf, ELSP066, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt, mBuf, ELSP067, pst);
   CMCHKPKLOG(cmPkHeader, &cntrl->hdr, mBuf, ELSP068, pst);
   pst->event = (Event)EVTLSPCNTRLREQ;

/* fill interface version number in pst */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspCntrlReq */


/*
*
*       Fun:   Unpack Trace Indication
*
*       Desc:  This function is used to unpack the trace indication 
*              primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLspTrcInd
(
LspTrcInd func,             /* primitive function */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */ 
)
#else
PUBLIC S16 cmUnpkLspTrcInd(func, pst, mBuf)
LspTrcInd func;             /* primitive function */   
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SpMngmt trc;           /* management trace struct */
   U16 i;                 /* loop counter */

   TRC3(cmUnpkLspTrcInd);

   CMCHKUNPKLOG(cmUnpkHeader, &trc.hdr, mBuf, ELSP069, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &trc.t.trc.dt, mBuf, ELSP070, pst);
   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.evnt, mBuf, ELSP071, pst);
   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.len, mBuf, ELSP072, pst);
   for (i = trc.t.trc.len; i > 0; i--) 
      CMCHKUNPKLOG(SUnpkU8, &trc.t.trc.evntParm[i-1], mBuf, ELSP073, pst);

   SPutMsg(mBuf);
   (*func)(pst, &trc); 

   RETVALUE(ROK);
} /* end of cmUnpkLspTrcInd */


  
/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function is used to unpack the status request
*              primitive to layer manager..
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLspStaCfm
(
LspStaCfm func,             /* primitive function */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspStaCfm(func, pst, mBuf)
LspStaCfm func;             /* primitive function */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SpMngmt sta;             /* solicited status confirm */
   S16 i;                   /* loop counter */
   CmIntfVer intfVer;       /* interface version number */
   Txt ptNmb[8];            /* part number */

   TRC3(cmUnpkLspStaCfm)

   /* if rolling upgrade support is enabled, use intfVer as in
    *  pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELSP074, pst);
#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ELSP075, pst);
#endif /* SMSP_LMINT3 */
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELSP076, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case STNSAP:   /* fall through */
      case STTSAP:
         CMCHKUNPKLOG(SUnpkS16, &sta.t.ssta.s.spSta.status, mBuf, ELSP077, pst);
/* unpacking self and remote interface version num */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG(cmUnpkIntfVer, &sta.t.ssta.s.spSta.selfIntfVer, mBuf,
                      ELSP078, pst);
         CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spSta.remIntfValid, mBuf,
                      ELSP079, pst);
         CMCHKUNPKLOG(cmUnpkIntfVer, &sta.t.ssta.s.spSta.remIntfVer, mBuf,
                      ELSP080, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;

      case STSID:   /* system Id */
         sta.t.ssta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId, mBuf, ELSP081, pst);
         break;

      case STROUT:
         switch (intfVer)
         {
            case 0x0100:     /* interface version LSPV1 */
            {
               CMCHKUNPKLOG(cmUnpkNwId, &sta.t.ssta.s.spRteSta.pcSta.nwId, mBuf,
                            ELSP082, pst);
               CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.s.spRteSta.pcSta.pc, mBuf,
                            ELSP083, pst);
               CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.pcSta.status, mBuf,
                            ELSP084, pst);
               CMCHKUNPKLOG(cmUnpkSmi, &sta.t.ssta.s.spRteSta.pcSta.smi, mBuf,
                            ELSP085, pst);
               CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.nmbSsns, mBuf,
                            ELSP086, pst);
               for (i = 0; i < sta.t.ssta.s.spRteSta.nmbSsns; i++)
               {
                  CMCHKUNPKLOG(cmUnpkSsn, &sta.t.ssta.s.spRteSta.ssnSta[i].ssn, 
                                mBuf, ELSP087, pst);
                  CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.ssnSta[i].status,
                               mBuf, ELSP088, pst);
                  CMCHKUNPKLOG(cmUnpkSmi, &sta.t.ssta.s.spRteSta.ssnSta[i].smi, 
                               mBuf, ELSP089, pst);
               }
               break;
            }

            case 0x0200:     /* interface version LSPV2 */
            case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
            case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
            case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
            case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
            case 0x0205:     /* lsp_c_002.main_4_1 - added interface version 
                              * LSPV2_5.
                              */
            {
               CMCHKUNPKLOG(cmUnpkNwId, &sta.t.ssta.s.spRteSta.pcSta.nwId, mBuf,
                            ELSP090, pst);
               CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.s.spRteSta.pcSta.pc, mBuf,
                            ELSP091, pst);
               CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.pcSta.status, mBuf,
                            ELSP092, pst);
               CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.pcSta.sccpSts, mBuf,
                            ELSP093, pst);
               CMCHKUNPKLOG(SUnpkS8, &sta.t.ssta.s.spRteSta.pcSta.rl, mBuf,
                            ELSP094, pst);
               CMCHKUNPKLOG(SUnpkS8, &sta.t.ssta.s.spRteSta.pcSta.rsl, mBuf,
                            ELSP095, pst);
               CMCHKUNPKLOG(SUnpkS8, &sta.t.ssta.s.spRteSta.pcSta.cl, mBuf,
                            ELSP096, pst);
               CMCHKUNPKLOG(SUnpkS8, &sta.t.ssta.s.spRteSta.pcSta.ril, mBuf,
                            ELSP097, pst);
               CMCHKUNPKLOG(cmUnpkSmi, &sta.t.ssta.s.spRteSta.pcSta.smi, mBuf,
                            ELSP098, pst);
               CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.nmbSsns, mBuf,
                            ELSP099, pst);
               for (i = 0; i < sta.t.ssta.s.spRteSta.nmbSsns; i++)
               {
                  CMCHKUNPKLOG(cmUnpkSsn, &sta.t.ssta.s.spRteSta.ssnSta[i].ssn, 
                                mBuf, ELSP100, pst);
                  CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.spRteSta.ssnSta[i].status,
                               mBuf, ELSP101, pst);
                  CMCHKUNPKLOG(cmUnpkSmi, &sta.t.ssta.s.spRteSta.ssnSta[i].smi, 
                               mBuf, ELSP102, pst);
               }
               break;
            }

            default:
               /* invalid interface version number */
               RETVALUE(RINVIFVER);
         } /* switch (intfVer) */
         break;
            
      default:
         break;
   } /* switch (...elmnt) */

   SPutMsg(mBuf);
   (*func)(pst, &sta);

   RETVALUE(ROK);
} /* end of cmUnpkLspStaCfm */

  
/*
*
*       Fun:   Unpack Statistics Confirm
*
*       Desc:  This function is used to unpack the statistics confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLspStsCfm
(
LspStsCfm func,
Pst *pst,
Buffer *mBuf   /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspStsCfm(func, pst, mBuf)
LspStsCfm func;
Pst *pst;
Buffer *mBuf;  /* message buffer */
#endif
{
   Action action;
   SpMngmt sts;

   TRC3(cmUnpkLspStsCfm)

   /* unpack statistics */

   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELSP103, pst);

#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm, mBuf, ELSP104, pst);
#endif /* SMSP_LMINT3 */

   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELSP105, pst);
   CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ELSP106, pst);

   /* unpack depending upon element type */
   switch (sts.hdr.elmId.elmnt)
   {
      case STGEN:
        CMCHKUNPKVERLOG(cmUnpkSpGLBSts, &sts.t.sts.s.spGlbSts, mBuf, ELSP107,
                        pst);
        break;


     case STNSAP:
        CMCHKUNPKVERLOG(cmUnpkSpNSAPSts, &sts.t.sts.s.spNSapSts, mBuf, ELSP108,
                        pst);
        break;

     case STTSAP:
        CMCHKUNPKVERLOG(cmUnpkSpSAPSts, &sts.t.sts.s.spSapSts, mBuf, ELSP109,
                        pst);
        break;

     case STROUT:
        CMCHKUNPKVERLOG(cmUnpkSpRTESts, &sts.t.sts.s.spRteSts, mBuf, ELSP110,
                        pst);
        break;

     default:
         break;
   } /* switch (...elmnt) */

   SPutMsg(mBuf);
   (*func)(pst, action, &sts); 
   RETVALUE(ROK);
} /* end of cmUnpkLspStsCfm */

  
/*
*
*       Fun:   Unpack Status Indication
*
*       Desc:  This function is used to unpack the unsolicited status 
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLspStaInd
(
LspStaInd func,              /* primitive function */
Pst *pst,                    /* post structure */
Buffer *mBuf                 /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspStaInd(func, pst, mBuf)
LspStaInd func;              /* primitive function */
Pst *pst;                    /* post structure */
Buffer *mBuf;                /* message buffer */
#endif
{
   SpMngmt sta;              /* management unsolicited status struct */
   S16 i;                    /* counter */
   S16 ret1;                 /* return value */
   CmIntfVer intfVer;        /* interface version number */

   TRC3(cmUnpkLspStaInd)

   /* if rolling upgrade support is desired, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELSP111, pst);

#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmAlarm, &sta.t.usta.alarm, mBuf, ELSP112, pst);
#else
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.usta.dt, mBuf, ELSP113, pst);
   CMCHKUNPKLOG(SUnpkU16, &sta.t.usta.evnt, mBuf, ELSP114, pst);
#endif /* SMSP_LMINT3 */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
         for (i = (S16) (LSP_USTA_EP_MAX - 1); i >= 0; i--)
         {
            CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evtRep.evntParm[i], mBuf,
                         ELSP115, pst);
         }
         break;

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
#if (SP_LMINT3 || SMSP_LMINT3)
         if (sta.t.usta.alarm.category == LCM_CATEGORY_PERF_MONIT)
         {
            CMCHKUNPKLOG(cmUnpkNwId, &sta.t.usta.evtRep.spRep.nwId, mBuf,
                         ELSP116, pst);
            CMCHKUNPKLOG(cmUnpkSwtch, &sta.t.usta.evtRep.spRep.sw, mBuf,
                         ELSP117, pst);
            /* sp037.302 - modification - reversing the order of unpacking
             * of called and calling party address to conform to packing
             * order.
             */
                    
            ret1 = cmUnpkSpAddr(&sta.t.usta.evtRep.spRep.cgPa, mBuf);
            if (ret1 != ROK)
               RETVALUE(ret1);
            ret1 = cmUnpkSpAddr(&sta.t.usta.evtRep.spRep.cdPa, mBuf);
            if (ret1 != ROK)
               RETVALUE(ret1);
            CMCHKUNPKLOG(cmUnpkDpc, &sta.t.usta.evtRep.spRep.dpc, mBuf, ELSP118,
                         pst);
            CMCHKUNPKLOG(cmUnpkSsn, &sta.t.usta.evtRep.spRep.ssn, mBuf, ELSP119,
                         pst);
            CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evtRep.spRep.protClass, mBuf,
                         ELSP120, pst);
            CMCHKUNPKLOG(SUnpkU32, &sta.t.usta.evtRep.spRep.segLr, mBuf,
                         ELSP121, pst)
            CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evtRep.spRep.congLvl, mBuf,
                         ELSP122, pst)
         }
#endif /* SP_LMINT3 || SMSP_LMINT3 */
         if (sta.t.usta.alarm.category != LCM_CATEGORY_PERF_MONIT)
         {
            for (i = (S16) (LSP_USTA_EP_MAX - 1); i >= 0; i--)
            {
               CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evtRep.evntParm[i], mBuf,
                            ELSP123, pst);
            }
         }
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   SPutMsg(mBuf);

   (*func)(pst, &sta); 

   RETVALUE(ROK);
} /* end of cmUnpkLspStaInd */

#if (SP_LMINT3 || SMSP_LMINT3)
  
/*
*
*       Fun:   Unpack config confirmation
*
*       Desc:  This function is used to unpack the  config confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLspCfgCfm
(
LspCfgCfm func,       /* primitive function */
Pst *pst,             /* post structure */
Buffer *mBuf          /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspCfgCfm(func, pst, mBuf)
LspCfgCfm func;       /* primitive function */
Pst *pst;             /* post structure */
Buffer *mBuf;         /* message buffer */
#endif
{
   SpMngmt cfm;       /* config confirm */

   TRC3(cmUnpkLspCfgCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELSP124, pst);

   /* unpack status structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSP125, pst);

   SPutMsg(mBuf);

   (*func)(pst, &cfm); 

   RETVALUE(ROK);
} /* end of cmUnpkLspCfgCfm */

  
/*
*
*       Fun:   Unpack control confirmation
*
*       Desc:  This function is used to unpack the  control confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkLspCntrlCfm
(
LspCntrlCfm func,       /* primitive function */
Pst *pst,               /* post structure */
Buffer *mBuf            /* message buffer */
)
#else
PUBLIC S16 cmUnpkLspCntrlCfm(func, pst, mBuf)
LspCntrlCfm func;       /* primitive function */
Pst *pst;               /* post structure */
Buffer *mBuf;           /* message buffer */
#endif
{
   SpMngmt cfm;         /* control confirm */

   TRC3(cmUnpkLspCntrlCfm)

   /* unpack header */
   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELSP126, pst);

   /* unpack status structure */
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSP127, pst);

   SPutMsg(mBuf);

   (*func)(pst, &cfm); 

   RETVALUE(ROK);
} /* end of cmUnpkLspCntrlCfm */
#endif /* (SP_LMINT3 || SMSP_LMINT3) */


/*
*     layer management interface packing functions
*/

/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspStaInd
(
Pst *pst,                 /* post structure */
SpMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 cmPkLspStaInd(pst, sta)
Pst *pst;                 /* post structure */   
SpMngmt *sta;             /* unsolicited status */
#endif
{
   S16 i;                 /* counter */
   Buffer *mBuf;          /* message buffer */
   S16 ret1;              /* return value */
   U8 len;                /* spAddr length */
   CmIntfVer intfVer;     /* interface version number */

   TRC3(cmPkLspStaInd)

   /* if rolling upgrade support is desired, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP128, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
         for (i = 0; i < (S16) LSP_USTA_EP_MAX; i++)  
            CMCHKPKLOG(SPkU8, sta->t.usta.evtRep.evntParm[i], mBuf, ELSP129,
                       pst);
         break;

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
         /* pack sccp error performance report */
#if (SP_LMINT3 || SMSP_LMINT3)
         if (sta->t.usta.alarm.category == LCM_CATEGORY_PERF_MONIT)
         {
            CMCHKPKLOG(SPkU8, sta->t.usta.evtRep.spRep.congLvl, mBuf, ELSP130,
                       pst);
            CMCHKPKLOG(SPkU32, sta->t.usta.evtRep.spRep.segLr, mBuf, ELSP131,
                       pst);
            CMCHKPKLOG(SPkU8, sta->t.usta.evtRep.spRep.protClass, mBuf, ELSP132,
                       pst);
            CMCHKPKLOG(cmPkSsn, sta->t.usta.evtRep.spRep.ssn, mBuf, ELSP133,
                       pst);
            CMCHKPKLOG(cmPkDpc, sta->t.usta.evtRep.spRep.dpc, mBuf, ELSP134,
                       pst);
            /* sp037.302 - deletion - packing of dpc for second time removed*/

            ret1 = cmPkSpAddr(&sta->t.usta.evtRep.spRep.cdPa, mBuf, &len);
            if (ret1 != ROK)
               RETVALUE(ret1);
            ret1 = cmPkSpAddr(&sta->t.usta.evtRep.spRep.cgPa, mBuf, &len);
            if (ret1 != ROK)
               RETVALUE(ret1);
            CMCHKPKLOG(cmPkSwtch, sta->t.usta.evtRep.spRep.sw, mBuf, ELSP136,
                       pst);
            CMCHKPKLOG(cmPkNwId, sta->t.usta.evtRep.spRep.nwId, mBuf, ELSP137,
                       pst);
            break;
         }
#endif /* SP_LMINT3 || SMSP_LMINT3 */
         if (sta->t.usta.alarm.category != LCM_CATEGORY_PERF_MONIT)
         {
            for (i = 0; i < (S16) LSP_USTA_EP_MAX; i++)  
               CMCHKPKLOG(SPkU8, sta->t.usta.evtRep.evntParm[i], mBuf, ELSP138,
                          pst);
         }
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKPKLOG(cmPkCmAlarm, &sta->t.usta.alarm, mBuf, ELSP139, pst);
#else
   CMCHKPKLOG(SPkU16, sta->t.usta.evnt, mBuf, ELSP140, pst);
   CMCHKPKLOG(cmPkDateTime, &sta->t.usta.dt, mBuf, ELSP141, pst);
#endif /* SP_LMINT3 */

   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELSP142, pst);

   if (pst->selector == SEL_LC_NEW)
   {
      pst->event = EVTLSPSTAIND;
      SPstTsk(pst, mBuf);
   }
   else
   {
      LSPLOGERROR(ERRCLS_DEBUG, ELSP143, (ErrVal)pst->selector,
                 "invalid selector");
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmPkLspStaInd */
 

/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspStaCfm
(
Pst *pst,                 /* post structure */     
SpMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 cmPkLspStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
SpMngmt *sta;             /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;              /* return value */
   S16 i;                 /* loop counter */
   CmIntfVer intfVer;     /* interface version number */
 
   TRC3(cmPkLspStaCfm)

   /* if rolling upgrade support is enabled, use intfVer as in
    * pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP144, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }
   switch (sta->hdr.elmId.elmnt)
   {
      case STNSAP:   /* fall through */
      case STTSAP:
/* pcak self and remote interface version num */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.s.spSta.remIntfVer, mBuf, ELSP145,
                    pst);
         CMCHKPKLOG(cmPkBool, sta->t.ssta.s.spSta.remIntfValid, mBuf, ELSP146,
                    pst);
         CMCHKPKLOG(cmPkIntfVer, sta->t.ssta.s.spSta.selfIntfVer, mBuf, ELSP147,
                    pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         CMCHKPKLOG(SPkS16, sta->t.ssta.s.spSta.status, mBuf, ELSP148, pst);
         break;

      case STSID:   /* system Id */
         CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELSP149, pst);
         break;

      case STROUT:
         switch (intfVer)
         {
            case 0x0100:     /* interface version LSPV1 */
            {
               for (i = (sta->t.ssta.s.spRteSta.nmbSsns - 1); i >= 0; i--)
               {
                  CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.ssnSta[i].smi, 
                              mBuf, ELSP150, pst);
                  CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.ssnSta[i].status, 
                              mBuf, ELSP151, pst);
                  CMCHKPKLOG(cmPkSsn, sta->t.ssta.s.spRteSta.ssnSta[i].ssn, 
                              mBuf, ELSP152, pst);
               }
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.nmbSsns, mBuf, ELSP153,
                          pst);
               CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.pcSta.smi, mBuf,
                          ELSP154, pst);
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.pcSta.status, mBuf,
                          ELSP155, pst);
               CMCHKPKLOG(SPkU32, sta->t.ssta.s.spRteSta.pcSta.pc, mBuf,
                          ELSP156, pst);
               CMCHKPKLOG(cmPkNwId, sta->t.ssta.s.spRteSta.pcSta.nwId, mBuf,
                          ELSP157, pst);
               break;
            }

            case 0x0200:     /* interface version LSPV2 */
            case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
            case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
            case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
            case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
            case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
            {
               for (i = (sta->t.ssta.s.spRteSta.nmbSsns - 1); i >= 0; i--)
               {
                  CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.ssnSta[i].smi, 
                              mBuf, ELSP158, pst);
                  CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.ssnSta[i].status, 
                              mBuf, ELSP159, pst);
                  CMCHKPKLOG(cmPkSsn, sta->t.ssta.s.spRteSta.ssnSta[i].ssn, 
                              mBuf, ELSP160, pst);
               }
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.nmbSsns, mBuf, ELSP161,
                          pst);
               CMCHKPKLOG(cmPkSmi, sta->t.ssta.s.spRteSta.pcSta.smi, mBuf,
                          ELSP162, pst);
               CMCHKPKLOG(SPkS8, sta->t.ssta.s.spRteSta.pcSta.ril, mBuf,
                          ELSP163, pst);
               CMCHKPKLOG(SPkS8, sta->t.ssta.s.spRteSta.pcSta.cl, mBuf,
                          ELSP164, pst);
               CMCHKPKLOG(SPkS8, sta->t.ssta.s.spRteSta.pcSta.rsl, mBuf,
                          ELSP165, pst);
               CMCHKPKLOG(SPkS8, sta->t.ssta.s.spRteSta.pcSta.rl, mBuf,
                          ELSP166, pst);
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.pcSta.sccpSts, mBuf,
                          ELSP167, pst);
               CMCHKPKLOG(SPkU8, sta->t.ssta.s.spRteSta.pcSta.status, mBuf,
                          ELSP168, pst);
               CMCHKPKLOG(cmPkDpc, sta->t.ssta.s.spRteSta.pcSta.pc, mBuf,
                          ELSP169, pst);
               CMCHKPKLOG(cmPkNwId, sta->t.ssta.s.spRteSta.pcSta.nwId, mBuf,
                          ELSP170, pst);
               break;
            }

            default:
               /* invalid interface version */
               RETVALUE(RINVIFVER);
         } /* switch (intfVer) */
         break;
         
      default:
         break;
   } /* switch (...elmnt) */

   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELSP171, pst);
#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELSP172, pst);
#endif /* SP_LMINT3 */
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELSP173, pst);

   if (pst->selector == SEL_LC_NEW)
   {
      pst->event = EVTLSPSTACFM;
      SPstTsk(pst, mBuf);
   }
   else
   {
      LSPLOGERROR(ERRCLS_DEBUG, ELSP174, (ErrVal)pst->selector,
                 "invalid selector");
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmPkLspStaCfm */


/*
*
*       Fun:   Pack Trace Indication
*
*       Desc:  This function is used to pack the trace indication
*              primitive to layer management.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLspTrcInd
(
Pst       *pst,           /* post structure */   
SpMngmt   *trc            /* trace */
)
#else
PUBLIC S16 cmPkLspTrcInd(pst, trc)
Pst       *pst;           /* post structure */   
SpMngmt   *trc;           /* trace */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16     rVal;          /* return value */
   U16     len;          /* Length of event */
   U8      i;             /* counter */

   TRC3(cmPkLspTrcInd);

   if ((rVal = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK) 
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP175, (ErrVal) rVal, "SGetMsg failed");
      RETVALUE(rVal);
   }

   len = trc->t.trc.len;
   for (i = 0; i < len; i++)  
      CMCHKPKLOG(SPkU8, trc->t.trc.evntParm[i], mBuf, ELSP176, pst);
   CMCHKPKLOG(SPkU16, trc->t.trc.len, mBuf, ELSP177, pst);
   CMCHKPKLOG(SPkU16, trc->t.trc.evnt, mBuf, ELSP178, pst);
   CMCHKPKLOG(cmPkDateTime, &trc->t.trc.dt, mBuf, ELSP179, pst);
   CMCHKPKLOG(cmPkHeader, &trc->hdr, mBuf, ELSP180, pst);

   pst->event = EVTLSPTRCIND;
   (void) SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLspTrcInd */



/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
SpMngmt *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLspStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
SpMngmt *sts;             /* statistics */
#endif
{

   Buffer *mBuf;          /* message buffer */
   S16 ret1;              /* return value */
 
   TRC3(cmPkLspStsCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP181, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }

   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:
         CMCHKPKVERLOG(cmPkSpGLBSts, &sts->t.sts.s.spGlbSts, mBuf, ELSP182,
                       pst);
         break;

      case STNSAP:
         CMCHKPKVERLOG(cmPkSpNSAPSts, &sts->t.sts.s.spNSapSts, mBuf, ELSP183,
                       pst);
         break;

      case STTSAP:
         CMCHKPKVERLOG(cmPkSpSAPSts, &sts->t.sts.s.spSapSts, mBuf, ELSP184,
                       pst);
         break;

      case STROUT:
         CMCHKPKVERLOG(cmPkSpRTESts, &sts->t.sts.s.spRteSts, mBuf, ELSP185,
                       pst);
         break;

      default:
         break;
   } /* switch (...elmnt) */

   CMCHKPKLOG(SPkS16, action, mBuf, ELSP186, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELSP187, pst);

#if (SP_LMINT3 || SMSP_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELSP188, pst);
#endif /* SP_LMINT3 */

   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELSP189, pst);
   if (pst->selector == SEL_LC_NEW)
   {
      pst->event = EVTLSPSTSCFM;
      SPstTsk(pst, mBuf);
   }
   else
   {
      LSPLOGERROR(ERRCLS_DEBUG, ELSP190, (ErrVal)pst->selector,
                 "invalid selector");
      SPutMsg(mBuf);
      RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of cmPkLspStsCfm */

#if (SP_LMINT3 || SMSP_LMINT3)

/*
*
*       Fun:   Pack configuration  Confirm
*
*       Desc:  This function is used to confirm the receipt of configuration
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspCfgCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLspCfgCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;              /* return value */
 
   TRC3(cmPkLspCfgCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP191, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSP192, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELSP193, pst);
   
   pst->event = EVTLSPCFGCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspCfgCfm */


/*
*
*       Fun:   Pack control  Confirm
*
*       Desc:  This function is used to confirm the receipt of control
*              request from layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lsp.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkLspCntrlCfm
(
Pst *pst,                 /* post structure */    
SpMngmt *cfm              /* confirm */
)
#else
PUBLIC S16 cmPkLspCntrlCfm(pst, cfm)
Pst *pst;                 /* post structure */    
SpMngmt *cfm;             /* confirm */
#endif
{
   Buffer *mBuf;          /* message buffer */
   S16 ret1;              /* return value */
 
   TRC3(cmPkLspCntrlCfm)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      LSPLOGERROR(ERRCLS_ADD_RES, ELSP194, (ErrVal) ret1, "SGetMsg failed");
      RETVALUE(ret1);
   }

   /* pack status */
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSP195, pst);

   /* pack header */
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELSP196, pst);
   pst->event = EVTLSPCNTRLCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
} /* end of cmPkLspCntrlCfm */
#endif /* (SP_LMINT3 || SMSP_LMINT3) */

/* 
 * Utility functions.
 */

/*
 * Packing functions 
 */


/*
*
*       Fun:   cmPkSpGenCfg
*
*       Desc:  This function is used to pack SCCP general configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpGenCfg
(
Pst *pst,                  /* post structure */
SpGenCfg *spGenCfg,        /* SCCP general config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpGenCfg(pst, spGenCfg, mBuf)
Pst *pst;                  /* post structure */
SpGenCfg *spGenCfg;        /* SCCP general config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmPkSpGenCfg);

   UNUSED(pst);

   CMCHKPK(cmPkPst, &spGenCfg->sm, mBuf);
#ifdef SNT2
   CMCHKPK(cmPkTmrCfg, &spGenCfg->defStatusEnqTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spGenCfg->tIntTmr, mBuf);
#endif /* SNT2 */
   CMCHKPK(cmPkTmrCfg, &spGenCfg->defRstEndTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spGenCfg->defGuaTmr, mBuf);
   CMCHKPK(SPkS16, spGenCfg->conTimeRes, mBuf);
   CMCHKPK(SPkU8, spGenCfg->itThresh, mBuf);
   CMCHKPK(SPkS16, spGenCfg->queThresh, mBuf);
   CMCHKPK(SPkS16, spGenCfg->conThresh, mBuf);
#ifdef SP_SLR_RANGE
   CMCHKPK(SPkU32, spGenCfg->slrLowRange, mBuf);
#endif /* SP_SLR_RANGE */
/* sp032.302 - addition - pack nmbConThresh */
#ifdef LSPV2_3
   CMCHKPK(SPkU32, spGenCfg->nmbConThresh, mBuf);
#endif /* LSPV2_3 */
   CMCHKPK(SPkU32, spGenCfg->nmbCon, mBuf);
   CMCHKPK(SPkS16, spGenCfg->atkDecTimeRes, mBuf);
   CMCHKPK(SPkU8, spGenCfg->maxRstSubLvl, mBuf);
   CMCHKPK(SPkU8, spGenCfg->maxRstLvl, mBuf);
   CMCHKPK(SPkS16, spGenCfg->recTimeRes, mBuf);
   CMCHKPK(SPkS16, spGenCfg->AsmbTimeRes, mBuf);
   CMCHKPK(SPkS16, spGenCfg->ssnTimeRes, mBuf);
   CMCHKPK(cmPkStatus, spGenCfg->sogThresh, mBuf);
   CMCHKPK(cmPkBool, spGenCfg->mngmntOn, mBuf);
   CMCHKPK(SPkU16, spGenCfg->nmbXUdCb, mBuf);
   CMCHKPK(SPkU16, spGenCfg->nmbRtes, mBuf);
   CMCHKPK(SPkU16, spGenCfg->nmbAddrs, mBuf);
   CMCHKPK(SPkU16, spGenCfg->nmbActns, mBuf);
   CMCHKPK(SPkU16, spGenCfg->nmbAsso, mBuf);
   CMCHKPK(SPkU8, spGenCfg->nmbNSaps, mBuf);
   CMCHKPK(SPkU8, spGenCfg->nmbSaps, mBuf);
   CMCHKPK(SPkU8, spGenCfg->nmbNws, mBuf);

   RETVALUE(ROK);
} /* cmPkSpGenCfg */


/*
*
*       Fun:   cmUnpkSpGenCfg
*
*       Desc:  This function is used to unpack SCCP general configuration
*              structure.
*
*       Ret:   ROK       : ok, unpacking successful.
*              RINVIFVER : Unpacking failed. Invalid interface version number
*
*       Notes: If received interface version is LSPV1(0x0100), do translation
*              by unpacking all the removed genCfg timers into retrofit buffer.
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpGenCfg
(
Pst *pst,                       /* post structure */
LspRetroCfgReq func1,           /* function for retrofitting genCfg param */
SpGenCfg *spGenCfg,             /* SCCP general config structure */
Buffer *mBuf                    /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpGenCfg(pst, func1, spGenCfg, mBuf)
Pst *pst;                       /* post structure */
LspRetroCfgReq func1;           /* function for retrofitting genCfg param */
SpGenCfg *spGenCfg;             /* SCCP general config structure */
Buffer *mBuf;                   /* Message buffer */
#endif
{
   CmIntfVer intfVer;           /* interface version number */

   TRC2(cmUnpkSpGenCfg);
   
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         SpRetroGenCfg spRetroGenCfg;   /* retrofit struct for genCfg param */
         TmrCfg tmpnSapTmr;    /* temp buffer to unpack and ignore nSapTmr */
         U16 tmpNmbAdjDpc;     /* temp buffer to unpack and ignore nmbAdjDpc */

         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defRstEndTmr, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->AsmbTimeRes, mBuf);

         /* unpack AsmbTmr into retrofit buffer */
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defAsmbTmr, mBuf);

         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbXUdCb, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->mngmntOn, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNws, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbSaps, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNSaps, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAsso, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbActns, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAddrs, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbRtes, mBuf);

         /* nmbAdjDpc is removed, unpack it in temp var and ignore */
         CMCHKUNPK(SUnpkU16, &tmpNmbAdjDpc, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->sogThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->ssnTimeRes, mBuf);

         /* unpack SstTmr into retrofit buffer */
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defSstTmr, mBuf);
         /* nSap timer is removed, unpack it in temp var and ignore */
         CMCHKUNPK(cmUnpkTmrCfg, &tmpnSapTmr, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
         /* unpack srt timer into retrofit buffer */
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defSrtTmr, mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */

         /* unpack IgnTmr and CrdTmr into retrofit buffer */
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defIgnTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defCrdTmr, mBuf);

         CMCHKUNPK(cmUnpkPst, &spGenCfg->sm, mBuf);
         CMCHKUNPK(SUnpkU32, &spGenCfg->nmbCon, mBuf);

         /* sp032.302 - addition - LM intfVer is LSPV1, so nmbConThresh 
          * will not be there in mBuf. If LSPV2_3 is enabled at our end 
          * then use default value for nmbConThresh. Default value for 
          * nmbConThresh is 10.
          */
#ifdef LSPV2_3
         spGenCfg->nmbConThresh = 10;
#endif /* LSPV2_3 */
 
#ifdef SP_SLR_RANGE
         CMCHKUNPK(SUnpkU32, &spGenCfg->slrLowRange, mBuf);
#endif /* SP_SLR_RANGE */
         CMCHKUNPK(SUnpkS16, &spGenCfg->conThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->queThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->conTimeRes, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defGuaTmr, mBuf);

         /* unpack connection oriented timers into retrofit buffer */
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defFrzTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defConTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defIasTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defIarTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defRepRelTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defRelTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defIntTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spRetroGenCfg.defRstTmr, mBuf);

         CMCHKUNPK(SUnpkS16, &spGenCfg->recTimeRes, mBuf);
#ifdef SNT2
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->tIntTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defStatusEnqTmr, mBuf);
#endif /* SNT2 */
#ifdef SP_RUG
         /* call function to retrofit general config paramaters */
         (*func1)(STGEN, intfVer, (PTR) &spRetroGenCfg);
#endif /* SP_RUG */
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      {
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNws, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbSaps, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNSaps, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAsso, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbActns, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAddrs, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbRtes, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbXUdCb, mBuf);
         CMCHKUNPK(cmUnpkBool, &spGenCfg->mngmntOn, mBuf);
         CMCHKUNPK(cmUnpkStatus, &spGenCfg->sogThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->ssnTimeRes, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->AsmbTimeRes, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->recTimeRes, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->maxRstLvl, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->maxRstSubLvl, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->atkDecTimeRes, mBuf);
         CMCHKUNPK(SUnpkU32, &spGenCfg->nmbCon, mBuf);
         /* sp032.302 - addition - LM intfVer is LSPV2,2_1 or 2_2, so 
          * nmbConThresh will not be there in mBuf. If LSPV2_3 is 
          * enabled at our end then use default value for nmbConThresh. 
          * Default value for nmbConThresh is 10.
          */
#ifdef LSPV2_3
         spGenCfg->nmbConThresh = 10;
#endif /* LSPV2_3 */
 
#ifdef SP_SLR_RANGE
         CMCHKUNPK(SUnpkU32, &spGenCfg->slrLowRange, mBuf);
#endif /* SP_SLR_RANGE */
         CMCHKUNPK(SUnpkS16, &spGenCfg->conThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->queThresh, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->itThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->conTimeRes, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defGuaTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defRstEndTmr, mBuf);
#ifdef SNT2
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->tIntTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defStatusEnqTmr, mBuf);
#endif /* SNT2 */
         CMCHKUNPK(cmUnpkPst, &spGenCfg->sm, mBuf);
         break;
      }

      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNws, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbSaps, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->nmbNSaps, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAsso, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbActns, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbAddrs, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbRtes, mBuf);
         CMCHKUNPK(SUnpkU16, &spGenCfg->nmbXUdCb, mBuf);
         CMCHKUNPK(cmUnpkBool, &spGenCfg->mngmntOn, mBuf);
         CMCHKUNPK(cmUnpkStatus, &spGenCfg->sogThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->ssnTimeRes, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->AsmbTimeRes, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->recTimeRes, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->maxRstLvl, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->maxRstSubLvl, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->atkDecTimeRes, mBuf);
         CMCHKUNPK(SUnpkU32, &spGenCfg->nmbCon, mBuf);
/* sp032.302 - addition - unpack nmbConThresh */
#ifdef LSPV2_3
         CMCHKUNPK(SUnpkU32, &spGenCfg->nmbConThresh, mBuf);
#endif /* LSPV2_3 */
#ifdef SP_SLR_RANGE
         CMCHKUNPK(SUnpkU32, &spGenCfg->slrLowRange, mBuf);
#endif /* SP_SLR_RANGE */
         CMCHKUNPK(SUnpkS16, &spGenCfg->conThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->queThresh, mBuf);
         CMCHKUNPK(SUnpkU8, &spGenCfg->itThresh, mBuf);
         CMCHKUNPK(SUnpkS16, &spGenCfg->conTimeRes, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defGuaTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defRstEndTmr, mBuf);
#ifdef SNT2
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->tIntTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spGenCfg->defStatusEnqTmr, mBuf);
#endif /* SNT2 */
         CMCHKUNPK(cmUnpkPst, &spGenCfg->sm, mBuf);
         break;
      }

     
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmUnpkSpGenCfg */


/*
*
*       Fun:   cmPkSpNwCfg
*
*       Desc:  This function is used to pack network configuration structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpNwCfg
(
Pst *pst,                  /* post structure */
SpNwCfg *spNwCfg,          /* SCCP network config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpNwCfg(pst, spNwCfg, mBuf)
Pst *pst;                  /* post structure */
SpNwCfg *spNwCfg;          /* SCCP network config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   S16 j;                  /* loop counter */

   TRC2(cmPkSpNwCfg);

   UNUSED(pst);
   
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defRstTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defIntTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defRepRelTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defRelTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defIarTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defIasTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defConTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defFrzTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defCongTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defDecayTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defAttackTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defAsmbTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defCrdTmr, mBuf);
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defIgnTmr, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   CMCHKPK(cmPkTmrCfg, &spNwCfg->defSrtTmr, mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */

   CMCHKPK(cmPkTmrCfg, &spNwCfg->defSstTmr, mBuf);

   /* pack sio prior to importance mapping, if present */
   if (spNwCfg->sioPrioImpPres)
   {
      for (j = (S16) (MAXSIOPRIO - 1); j >= 0; j--)
         CMCHKPK(SPkU8, spNwCfg->sioPrioImp[j], mBuf);
   }
   /* pack presence indicator of sio prior to imp mapping */
   CMCHKPK(cmPkBool, spNwCfg->sioPrioImpPres, mBuf);

#ifdef SS7_JAPAN
   CMCHKPK(cmPkBool, spNwCfg->jttMngmntOn, mBuf);
#endif /* SS7_JAPAN */

   CMCHKPK(SPkU8, spNwCfg->niInd, mBuf);
   CMCHKPK(SPkU8, spNwCfg->defHopCnt, mBuf);
   CMCHKPK(SPkU8, spNwCfg->subService,mBuf);
   CMCHKPK(cmPkDpc, spNwCfg->selfPc, mBuf);
   CMCHKPK(SPkU8, spNwCfg->pcLen, mBuf);
   CMCHKPK(cmPkSwtch, spNwCfg->variant, mBuf);
   CMCHKPK(cmPkNwId, spNwCfg->nwId, mBuf);

   RETVALUE(ROK);
} /* cmPkSpNwCfg */


/*
*
*       Fun:   cmUnpkSpNwCfg
*
*       Desc:  This function is used to unpack SCCP network configuration
*              structure.
*
*       Ret:   ROK       : ok. Unpacking successful.
*              RINVIFVER : Unpacking failed. Invalid interface version number
*
*       Notes: If received interface version is LSPV1(0x0100), copy timer config
*              values from retrofit buffer into network config struct.
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpNwCfg
(
Pst *pst,                  /* post structure */
LspRetroCfgReq func1,      /* function for retrofitting genCfg param */
SpNwCfg *spNwCfg,          /* SCCP network config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpNwCfg(pst, func1, spNwCfg, mBuf)
Pst *pst;                  /* post structure */
LspRetroCfgReq func1;      /* function for retrofitting genCfg param */
SpNwCfg *spNwCfg;          /* SCCP network config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   U16 j;                  /* loop counter */
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkSpNwCfg);
   
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKUNPK(cmUnpkNwId, &spNwCfg->nwId, mBuf);
         CMCHKUNPK(cmUnpkSwtch, &spNwCfg->variant, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->pcLen, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spNwCfg->selfPc, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->subService, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->defHopCnt, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->niInd, mBuf);

         /* assign default value (FALSE) to attack, decay and cong timers */
         spNwCfg->defAttackTmr.enb = FALSE;
         spNwCfg->defDecayTmr.enb = FALSE;
         spNwCfg->defCongTmr.enb = FALSE;

         /* assign default value (FALSE) to sio priority to imp mapping */
         spNwCfg->sioPrioImpPres = FALSE;

#ifdef SS7_JAPAN
         /* assign default value (FALSE) to jttMngmntOn flag */
         spNwCfg->jttMngmntOn = FALSE;
#endif /* SS7_JAPAN */

#ifdef SP_RUG
         /* call function to retrofit network config paramaters from
          * previously sent general config paramaters
          */
         (*func1)(STNW, intfVer, (PTR) spNwCfg);
#endif /* SP_RUG */

         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(cmUnpkNwId, &spNwCfg->nwId, mBuf);
         CMCHKUNPK(cmUnpkSwtch, &spNwCfg->variant, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->pcLen, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spNwCfg->selfPc, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->subService, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->defHopCnt, mBuf);
         CMCHKUNPK(SUnpkU8, &spNwCfg->niInd, mBuf);

#ifdef SS7_JAPAN
         CMCHKUNPK(cmUnpkBool, &spNwCfg->jttMngmntOn, mBuf);
#endif /* SS7_JAPAN */

         CMCHKUNPK(cmUnpkBool, &spNwCfg->sioPrioImpPres, mBuf);
         if (spNwCfg->sioPrioImpPres)
         {
            for (j = 0; j < (U16) MAXSIOPRIO; j++)
               CMCHKUNPK(SUnpkU8, &spNwCfg->sioPrioImp[j], mBuf);
         }
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defSstTmr, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defSrtTmr, mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */

         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defIgnTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defCrdTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defAsmbTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defAttackTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defDecayTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defCongTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defFrzTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defConTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defIasTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defIarTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defRelTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defRepRelTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defIntTmr, mBuf);
         CMCHKUNPK(cmUnpkTmrCfg, &spNwCfg->defRstTmr, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
 
   RETVALUE(ROK);
} /* cmUnpkSpNwCfg */


/*
*
*       Fun:   cmPkSpSAPCfg
*
*       Desc:  This function is used to pack SCCP upper SAP configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpSAPCfg
(
Pst *pst,                  /* post structure */
SpSAPCfg *spSAPCfg,        /* SCCP upper SAP config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpSAPCfg(pst, spSAPCfg, mBuf)
Pst *pst;                  /* post structure */
SpSAPCfg *spSAPCfg;        /* SCCP upper SAP config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   S16 j;                  /* loop counter */

   TRC2(cmPkSpSAPCfg);

   UNUSED(pst);
   
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, spSAPCfg->remIntfVer, mBuf);
   CMCHKPK(cmPkBool, spSAPCfg->remIntfValid, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   /* lsp_c_002.main_4_1 - Addition - packing the message intercept 
    * enable flag. 
    */
#ifdef LSPV2_5
   CMCHKPK(cmPkBool, spSAPCfg->msgInterceptEnabled, mBuf);
#endif

   CMCHKPK(cmPkRoute, spSAPCfg->route, mBuf);
   CMCHKPK(cmPkPriority, spSAPCfg->prior, mBuf);

   /* pack concerned point codes, if present */
   if (spSAPCfg->nmbConPc)
   {
      for (j = (S16) (spSAPCfg->nmbConPc - 1); j >= 0; j--)
      {
         CMCHKPK(cmPkDpc, spSAPCfg->conPc[j], mBuf);
      }
   }
   CMCHKPK(SPkU16, spSAPCfg->nmbConPc, mBuf);

   /* pack backup point codes, if present */
   if (spSAPCfg->nmbBpc)
   {
      for (j = (S16) (spSAPCfg->nmbBpc - 1); j >= 0; j--)
      {
         CMCHKPK(SPkU8, spSAPCfg->bpcList[j].prior, mBuf);
         CMCHKPK(cmPkDpc, spSAPCfg->bpcList[j].bpc, mBuf);
      }
   }
   CMCHKPK(SPkU16, spSAPCfg->nmbBpc, mBuf);

   CMCHKPK(cmPkMemoryId, &spSAPCfg->mem, mBuf);
   CMCHKPK(cmPkSelector, spSAPCfg->selector, mBuf);
   CMCHKPK(cmPkNwId, spSAPCfg->nwId, mBuf);

   RETVALUE(ROK);
} /* cmPkSpSAPCfg */


/*
*
*       Fun:   cmUnpkSpSAPCfg
*
*       Desc:  This function is used to unpack SCCP upper SAP configuration
*              structure.
*
*       Ret:   ROK      : Ok. Unpacking successful.
*              RINVIFVER: Unpacking failed. Invalid interface version number.
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpSAPCfg
(
Pst *pst,                  /* post structure */
SpSAPCfg *spSAPCfg,        /* SCCP upper SAP config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpSAPCfg(pst, spSAPCfg, mBuf)
Pst *pst;                  /* post structure */
SpSAPCfg *spSAPCfg;        /* SCCP upper SAP config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   U16 j;                  /* loop counter */
   CmIntfVer intfVer;      /* interface version number */
   Bool bpcInd;            /* temporary var to unpack backup inidicator */
   Dpc bpc;                /* temporary var to unpack backup point code */

   TRC2(cmUnpkSpSAPCfg);
   
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKUNPK(cmUnpkNwId, &spSAPCfg->nwId, mBuf);
         CMCHKUNPK(cmUnpkSelector, &spSAPCfg->selector, mBuf);
         CMCHKUNPK(cmUnpkMemoryId, &spSAPCfg->mem, mBuf);
         CMCHKUNPK(cmUnpkBool, &bpcInd, mBuf);
         CMCHKUNPK(cmUnpkDpc, &bpc, mBuf);
         /* translate bpcInd and bpc to nmbBpc and bpcList struct */
         if (bpcInd)
         {
            spSAPCfg->nmbBpc = 1;
            spSAPCfg->bpcList[0].bpc = bpc;
            spSAPCfg->bpcList[0].prior = 0;  /* default priority */
         }                  
         else
            spSAPCfg->nmbBpc = 0;
            
         CMCHKUNPK(SUnpkU16, &spSAPCfg->nmbConPc, mBuf);
         for (j = 0; j < spSAPCfg->nmbConPc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spSAPCfg->conPc[j], mBuf);
         }
         CMCHKUNPK(cmUnpkPriority, &spSAPCfg->prior, mBuf);
         CMCHKUNPK(cmUnpkRoute, &spSAPCfg->route, mBuf);
         /* lsp_c_002.main_4_1 - Addition - Default value set as FALSE */
#ifdef LSPV2_5
         spSAPCfg->msgInterceptEnabled = FALSE;
#endif
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(SUnpkU8, &spSAPCfg->remIntfValid, mBuf);
         CMCHKUNPK(cmUnpkIntfVer, &spSAPCfg->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      {
         CMCHKUNPK(cmUnpkNwId, &spSAPCfg->nwId, mBuf);
         CMCHKUNPK(cmUnpkSelector, &spSAPCfg->selector, mBuf);
         CMCHKUNPK(cmUnpkMemoryId, &spSAPCfg->mem, mBuf);
         CMCHKUNPK(SUnpkU16, &spSAPCfg->nmbBpc, mBuf);
         for (j = 0; j < spSAPCfg->nmbBpc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spSAPCfg->bpcList[j].bpc, mBuf);
            CMCHKUNPK(SUnpkU8, &spSAPCfg->bpcList[j].prior, mBuf);
         }
         CMCHKUNPK(SUnpkU16, &spSAPCfg->nmbConPc, mBuf);
         for (j = 0; j < spSAPCfg->nmbConPc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spSAPCfg->conPc[j], mBuf);
         }
         CMCHKUNPK(cmUnpkPriority, &spSAPCfg->prior, mBuf);
         CMCHKUNPK(cmUnpkRoute, &spSAPCfg->route, mBuf);
         /* lsp_c_002.main_4_1 - Addition - Default value set as FALSE */
#ifdef LSPV2_5
         spSAPCfg->msgInterceptEnabled = FALSE;
#endif
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(cmUnpkBool, &spSAPCfg->remIntfValid, mBuf);
         CMCHKUNPK(cmUnpkIntfVer, &spSAPCfg->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(cmUnpkNwId, &spSAPCfg->nwId, mBuf);
         CMCHKUNPK(cmUnpkSelector, &spSAPCfg->selector, mBuf);
         CMCHKUNPK(cmUnpkMemoryId, &spSAPCfg->mem, mBuf);
         CMCHKUNPK(SUnpkU16, &spSAPCfg->nmbBpc, mBuf);
         for (j = 0; j < spSAPCfg->nmbBpc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spSAPCfg->bpcList[j].bpc, mBuf);
            CMCHKUNPK(SUnpkU8, &spSAPCfg->bpcList[j].prior, mBuf);
         }
         CMCHKUNPK(SUnpkU16, &spSAPCfg->nmbConPc, mBuf);
         for (j = 0; j < spSAPCfg->nmbConPc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spSAPCfg->conPc[j], mBuf);
         }
         CMCHKUNPK(cmUnpkPriority, &spSAPCfg->prior, mBuf);
         CMCHKUNPK(cmUnpkRoute, &spSAPCfg->route, mBuf);
         /* lsp_c_002.main_4_1 - Addition - unpacking the message intercept 
          * enable flag.
          */
#ifdef LSPV2_5
         CMCHKUNPK(cmUnpkBool, &spSAPCfg->msgInterceptEnabled, mBuf);
#endif
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(cmUnpkBool, &spSAPCfg->remIntfValid, mBuf);
         CMCHKUNPK(cmUnpkIntfVer, &spSAPCfg->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }


      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmUnpkSpSAPCfg */


/*
*
*       Fun:   cmPkSpNSAPCfg
*
*       Desc:  This function is used to pack SCCP lower SAP configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpNSAPCfg
(
Pst *pst,                  /* post structure */
SpNSAPCfg *spNSAPCfg,      /* SCCP lower SAP config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpNSAPCfg(pst, spNSAPCfg, mBuf)
Pst *pst;                  /* post structure */
SpNSAPCfg *spNSAPCfg;      /* SCCP lower SAP config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmPkSpNSAPCfg);

   UNUSED(pst);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, spNSAPCfg->remIntfVer, mBuf);
   CMCHKPK(cmPkBool, spNSAPCfg->remIntfValid, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKPK(cmPkSpId, spNSAPCfg->spId, mBuf);
   CMCHKPK(cmPkInst, spNSAPCfg->dstInst, mBuf);
   CMCHKPK(cmPkEnt, spNSAPCfg->dstEnt, mBuf);
   CMCHKPK(cmPkRoute, spNSAPCfg->route, mBuf);
   CMCHKPK(cmPkPrior, spNSAPCfg->prior, mBuf);
   CMCHKPK(cmPkProcId, spNSAPCfg->dstProcId, mBuf);
   CMCHKPK(cmPkSelector, spNSAPCfg->selector, mBuf);
   CMCHKPK(cmPkMemoryId, &spNSAPCfg->mem, mBuf);
   CMCHKPK(cmPkMsgLen, spNSAPCfg->msgLen, mBuf);
   CMCHKPK(cmPkNwId, spNSAPCfg->nwId, mBuf);
   
   RETVALUE(ROK);
} /* cmPkSpNSAPCfg */


/*
*
*       Fun:   cmUnpkSpNSAPCfg
*
*       Desc:  This function is used to unpack SCCP lower SAP configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpNSAPCfg
(
Pst *pst,                  /* post structure */
SpNSAPCfg *spNSAPCfg,      /* SCCP lower SAP config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpNSAPCfg(pst, spNSAPCfg, mBuf)
Pst *pst;                  /* post structure */
SpNSAPCfg *spNSAPCfg;      /* SCCP lower SAP config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmUnpkSpNSAPCfg);

   UNUSED(pst);
   
   /* SpNSAPCfg struct is same in LSPV1(0x0100) and LSPV2(0x0200) interface
    * versions hence no need for translation of struct
    */
   CMCHKUNPK(cmUnpkNwId, &spNSAPCfg->nwId, mBuf);
   CMCHKUNPK(cmUnpkMsgLen, &spNSAPCfg->msgLen, mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &spNSAPCfg->mem, mBuf);
   CMCHKUNPK(cmUnpkSelector, &spNSAPCfg->selector, mBuf);
   CMCHKUNPK(cmUnpkProcId, &spNSAPCfg->dstProcId, mBuf);
   CMCHKUNPK(cmUnpkPrior, &spNSAPCfg->prior, mBuf);
   CMCHKUNPK(cmUnpkRoute, &spNSAPCfg->route, mBuf);
   CMCHKUNPK(cmUnpkEnt, &spNSAPCfg->dstEnt, mBuf);
   CMCHKUNPK(cmUnpkInst, &spNSAPCfg->dstInst, mBuf);
   CMCHKUNPK(cmUnpkSpId, &spNSAPCfg->spId, mBuf);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(cmUnpkBool, &spNSAPCfg->remIntfValid, mBuf);
   CMCHKUNPK(cmUnpkIntfVer, &spNSAPCfg->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
} /* cmUnpkSpNSAPCfg */


/*
*
*       Fun:   cmPkSpRteCfg
*
*       Desc:  This function is used to pack SCCP route configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpRteCfg
(
Pst *pst,                  /* post structure */
SpRteCfg *spRteCfg,        /* SCCP route config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpRteCfg(pst, spRteCfg, mBuf)
Pst *pst;                  /* post structure */
SpRteCfg *spRteCfg;        /* SCCP route config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   S16 j;                  /* loop counter */
   Cntr i;                 /* loop counter */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;    /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSpRteCfg);

   UNUSED(pst);

/* if rolling upgrade support is enabled, set bits corresponding to
 * compile flags for ansi 96 and bell05, if these flags are enabled
 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifdef SS7_ANS96
   bitVector |= LSP_SS7_ANS96_BIT;
#endif /* SS7_ANS96 */
#ifdef SS7_BELL05
   bitVector |= LSP_SS7_BELL05_BIT;
#endif /* SS7_BELL05 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* pack rteCfg parameters */
   CMCHKPK(cmPkSwtch, spRteCfg->swtch, mBuf);
   CMCHKPK(cmPkDpc, spRteCfg->dpc, mBuf);
   CMCHKPK(SPkU8, spRteCfg->status, mBuf);

#if (SS7_ANS96 || SS7_BELL05)
   CMCHKPK(SPkU8, spRteCfg->replicatedMode, mBuf);
#endif /* SS7_ANS96 || SS7_BELL05 */

   /* pack backup point codes, if present */
   if (spRteCfg->nmbBpc)
   {
      for (j = (S16) (spRteCfg->nmbBpc - 1); j >= 0; j--)
      {
         CMCHKPK(SPkU8, spRteCfg->bpcList[j].prior, mBuf);
         CMCHKPK(cmPkDpc, spRteCfg->bpcList[j].bpc, mBuf);
      }
   }
   CMCHKPK(SPkU16, spRteCfg->nmbBpc, mBuf);

   /* pack SSNs if present */
   if (spRteCfg->nmbSsns)
   {
      for (i = (Cntr)(spRteCfg->nmbSsns - 1); i >= 0; i--)
      {
         /* pack concerned point codes */
         if (spRteCfg->ssnList[i].nmbConPc)
         {
            Cntr k;
            for (k = (Cntr) (spRteCfg->ssnList[i].nmbConPc - 1); k >= 0; k--)
               CMCHKPK(cmPkDpc, spRteCfg->ssnList[i].conPc[k], mBuf);
         }
         CMCHKPK(SPkU16, spRteCfg->ssnList[i].nmbConPc, mBuf);

         /* pack backups of ssn, if present */
         if (spRteCfg->ssnList[i].nmbBpc)
         {
            for (j = (S16) (spRteCfg->ssnList[i].nmbBpc - 1); j >= 0; j--)
            {
               CMCHKPK(SPkU8, spRteCfg->ssnList[i].bpcList[j].prior, mBuf);
               CMCHKPK(cmPkDpc, spRteCfg->ssnList[i].bpcList[j].bpc, mBuf);
            }
         }
         CMCHKPK(SPkU16, spRteCfg->ssnList[i].nmbBpc, mBuf);

         /* pack replicated mode of operation of backups of ssn */
#if (SS7_ANS96 || SS7_BELL05)
         CMCHKPK(SPkU8, spRteCfg->ssnList[i].replicatedMode, mBuf);
#endif /* SS7_ANS96 || SS7_BELL05 */

         CMCHKPK(SPkU8, spRteCfg->ssnList[i].status, mBuf);
         CMCHKPK(SPkU8, spRteCfg->ssnList[i].ssn, mBuf);
      }
   }
   CMCHKPK(SPkU8, spRteCfg->nmbSsns, mBuf);
   
   CMCHKPK(cmPkSpId, spRteCfg->nSapId, mBuf);
   CMCHKPK(SPkU8, spRteCfg->flag, mBuf);

   /* sp020.302 - addition - Pack slsMask configuration in route CB. In ANSI and
    * BELLCORE networks SLS can be either 5 bit or 8 bits. In case of ITU
    * sls can be of 4 bits only.
    */
#ifdef LSPV2_1
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   CMCHKPK(SPkU8, spRteCfg->slsMask, mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
#endif /* LSPV2_1 */

   /* pack bitVector if rolling upgrade support is enabled */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8, (U8) bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
  
   RETVALUE(ROK);
} /* cmPkSpRteCfg */


/*
*
*       Fun:   cmUnpkSpRteCfg
*
*       Desc:  This function is used to unpack SCCP route configuration
*              structure.
*
*       Ret:   ROK      : Ok. Unpacking successful.
*              RINVIFVER: Unpacking failed. Invalid interface version number.
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpRteCfg
(
Pst *pst,                  /* post structure */
SpRteCfg *spRteCfg,        /* SCCP route config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpRteCfg(pst, spRteCfg, mBuf)
Pst *pst;                  /* post structure */
SpRteCfg *spRteCfg;        /* SCCP route config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   U8 i;                   /* loop counter */
   U16 j;                  /* loop counter */
   CmIntfVer intfVer;      /* interface version number */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;           /* bit vector */
#if !(SS7_ANS96 || SS7_BELL05)
   U8 tempMode;            /* temporary var to unpack replicatedMode of bkups */
#endif /* !(SS7_ANS96 || SS7_BELL05) */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   Bool bpcInd;            /* temporary var to unpack backup pc indicator */
   Dpc bpc;                /* temporary var to unpack backup point code */

   TRC2(cmUnpkSpRteCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         /* sp020.302 - addition - LM intfVer is LSPV1, so slsMask will not
          * be there in mBuf. If LSPV2_1 is enabled at our end then use default
          * value for slsMask. We can assign slsMask of 5 bits for ansi as
          * default, it does not matter even if route is other than ANSI (ITU 
          * etc.), for we are ignoring slsMask in other cases any way.
          */
#ifdef LSPV2_1
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
         spRteCfg->slsMask = (U8) 0x1f;
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
#endif /* LSPV2_1 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->flag, mBuf);
         CMCHKUNPK(cmUnpkSpId, &spRteCfg->nSapId, mBuf);
         CMCHKUNPK(SUnpkU8, &spRteCfg->nmbSsns, mBuf);
         for (i = 0; i < spRteCfg->nmbSsns;  i++)
         {
            CMCHKUNPK(SUnpkU32, &bpc, mBuf);
            CMCHKUNPK(SUnpkU8, &bpcInd, mBuf);

            /* translate bpcInd and bpc into nmbBpc and bpcList */
            if (bpcInd)
            {
               spRteCfg->ssnList[i].nmbBpc = 1;
               spRteCfg->ssnList[i].bpcList[0].bpc = bpc;
               spRteCfg->ssnList[i].bpcList[0].prior = 0;  /* default prior */
            }
            else
               spRteCfg->ssnList[i].nmbBpc = 0;
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].status, mBuf);
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].ssn, mBuf);
            CMCHKUNPK(SUnpkU16, &spRteCfg->ssnList[i].nmbConPc, mBuf);
            for (j = 0; j < spRteCfg->ssnList[i].nmbConPc; j++)
               CMCHKUNPK(cmUnpkDpc, &spRteCfg->ssnList[i].conPc[j], mBuf);
#if (SS7_ANS96 || SS7_BELL05)
            /* assign default value of replicatedMode of backups of
             * SSNs as DOMINANT
             */
            spRteCfg->ssnList[i].replicatedMode = (U8) DOMINANT;
#endif /* SS7_ANS96 || SS7_BELL05 */
         }
         CMCHKUNPK(SUnpkU32, &bpc, mBuf);
         CMCHKUNPK(SUnpkU8, &bpcInd, mBuf);

         /* translate bpcInd and bpc to nmbBpc and bpcList struct */
         if (bpcInd)
         {
            spRteCfg->nmbBpc = 1;
            spRteCfg->bpcList[0].bpc = bpc;
            spRteCfg->bpcList[0].prior = 0;  /* default priority */
         }
         else
            spRteCfg->nmbBpc = 0;
#if (SS7_ANS96 || SS7_BELL05)
         /* assign default value of replicatedMode as DOMINANT */
         spRteCfg->replicatedMode = (U8) DOMINANT;
#endif /* SS7_ANS96 || SS7_BELL05 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->status, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spRteCfg->dpc, mBuf);
         CMCHKUNPK(SUnpkS16, &spRteCfg->swtch, mBuf);
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* if rolling upgrade support enabled, unpack bitVector */
         CMCHKUNPK(SUnpkU8, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         /* sp020.302 - addition - LM intfVer is LSPV2, so slsMask will not
          * be there in mBuf. If LSPV2_1 is enabled at our end then use default
          * value for slsMask. We can assign slsMask of 5 bits for ansi as
          * default, it does not matter even if route is other than ANSI (ITU 
          * etc.), for we are ignoring slsMask in other cases any way.
          */
#ifdef LSPV2_1
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
         spRteCfg->slsMask = (U8) 0x1f;
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
#endif /* LSPV2_1 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->flag, mBuf);
         CMCHKUNPK(cmUnpkSpId, &spRteCfg->nSapId, mBuf);
         CMCHKUNPK(SUnpkU8, &spRteCfg->nmbSsns, mBuf);
         for (i = 0; i < spRteCfg->nmbSsns;  i++)
         {
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].ssn, mBuf);
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].status, mBuf);

            /* unpcak replicated mode if flags for ansi 96 or bell05 is
             * enabled and:
             *   1. rolling upgrade support enabled and bitVector indicates
             *      that the compile flag is enabled at originating side and
             *      hence field replicatedMode was packed.
             *   2. no rolling upgrade support is enabled. In this case
             *      unpacking of field is solely based on compile flag for
             *      ansi96 and bell 05.
             */
#if (SS7_ANS96 || SS7_BELL05)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            if ((bitVector & LSP_SS7_ANS96_BIT) ||
                (bitVector & LSP_SS7_BELL05_BIT))
               CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].replicatedMode, mBuf);
#else
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].replicatedMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 || SS7_BELL05 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            /* compile flags ansi 96 and bell 05 are not enabled
             * at our side, unpack and ignore field if bitVector
             * indicates its packing
             */
            if ((bitVector & LSP_SS7_ANS96_BIT) ||
                (bitVector & LSP_SS7_BELL05_BIT))
               CMCHKUNPK(SUnpkU8, &tempMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 || SS7_BELL05 */

            CMCHKUNPK(SUnpkU16, &spRteCfg->ssnList[i].nmbBpc, mBuf);
            /* unpack of backups of SSN, if present */
            for (j = 0; j < spRteCfg->ssnList[i].nmbBpc; j++)
            {
               CMCHKUNPK(cmUnpkDpc, &spRteCfg->ssnList[i].bpcList[j].bpc, mBuf);
               CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].bpcList[j].prior, mBuf);
            }
            CMCHKUNPK(SUnpkU16, &spRteCfg->ssnList[i].nmbConPc, mBuf);
            for (j = 0; j < spRteCfg->ssnList[i].nmbConPc; j++)
               CMCHKUNPK(SUnpkU32, &spRteCfg->ssnList[i].conPc[j], mBuf);

         }

         /* unpack backup point codes */
         CMCHKUNPK(SUnpkU16, &spRteCfg->nmbBpc, mBuf);
         for (j = 0; j < spRteCfg->nmbBpc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spRteCfg->bpcList[j].bpc, mBuf);
            CMCHKUNPK(SUnpkU8, &spRteCfg->bpcList[j].prior, mBuf);
         }

         /* unpcak replicated mode of point codes if flags for ansi 96 or
          * bell05 is enabled and:
          *   1. rolling upgrade support enabled and bitVector indicates
          *      that the compile flag is enabled at originating side and
          *      hence field replicatedMode was packed.
          *   2. no rolling upgrade support is enabled. In this case
          *      unpacking of field is solely based on compile flag for
          *      ansi96 and bell 05.
          */
#if (SS7_ANS96 || SS7_BELL05)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSP_SS7_ANS96_BIT) ||
             (bitVector & LSP_SS7_BELL05_BIT))
            CMCHKUNPK(SUnpkU8, &spRteCfg->replicatedMode, mBuf);
#else
         CMCHKUNPK(SUnpkU8, &spRteCfg->replicatedMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 || SS7_BELL05 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* compile flags ansi 96 and bell 05 are not enabled
          * at our side, unpack and ignore field if bitVector
          * indicates its packing
          */
         if ((bitVector & LSP_SS7_ANS96_BIT) ||
             (bitVector & LSP_SS7_BELL05_BIT))
            CMCHKUNPK(SUnpkU8, &tempMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 || SS7_BELL05 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->status, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spRteCfg->dpc, mBuf);
         CMCHKUNPK(SUnpkS16, &spRteCfg->swtch, mBuf);
         break;
      } /* case 0x0200 */

      case 0x0201:     /* sp020.302 - addition - interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* if rolling upgrade support enabled, unpack bitVector */
         CMCHKUNPK(SUnpkU8, &bitVector, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         /* LM intfVer is LSPV2_1, so slsMask will be there in mBuf. If LSPV2_1
          * is enabled at our end then unpack slsMask.The only case when LSPV2_1
          * is not enabled but intfVer is LSPV2_1 can happen is, if none of the
          * LSPV1, LSPV2 or LSPV2_1 are enabled at LM end and so latest intfVer
          * is being used when packing. But in this case there won't be slsMask
          * packed in struct so we can proceed without unpacking it. Otherwise
          * LM is always the last entity to be upgraded so can not have higher
          * intfVer than layer.
          */
#ifdef LSPV2_1
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
         CMCHKUNPK(SUnpkU8, &spRteCfg->slsMask, mBuf);
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
#endif /* LSPV2_1 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->flag, mBuf);
         CMCHKUNPK(cmUnpkSpId, &spRteCfg->nSapId, mBuf);
         CMCHKUNPK(SUnpkU8, &spRteCfg->nmbSsns, mBuf);
         for (i = 0; i < spRteCfg->nmbSsns;  i++)
         {
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].ssn, mBuf);
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].status, mBuf);

            /* unpcak replicated mode if flags for ansi 96 or bell05 is
             * enabled and:
             *   1. rolling upgrade support enabled and bitVector indicates
             *      that the compile flag is enabled at originating side and
             *      hence field replicatedMode was packed.
             *   2. no rolling upgrade support is enabled. In this case
             *      unpacking of field is solely based on compile flag for
             *      ansi96 and bell 05.
             */
#if (SS7_ANS96 || SS7_BELL05)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            if ((bitVector & LSP_SS7_ANS96_BIT) ||
                (bitVector & LSP_SS7_BELL05_BIT))
               CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].replicatedMode, mBuf);
#else
            CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].replicatedMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 || SS7_BELL05 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            /* compile flags ansi 96 and bell 05 are not enabled
             * at our side, unpack and ignore field if bitVector
             * indicates its packing
             */
            if ((bitVector & LSP_SS7_ANS96_BIT) ||
                (bitVector & LSP_SS7_BELL05_BIT))
               CMCHKUNPK(SUnpkU8, &tempMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 || SS7_BELL05 */

            CMCHKUNPK(SUnpkU16, &spRteCfg->ssnList[i].nmbBpc, mBuf);
            /* unpack of backups of SSN, if present */
            for (j = 0; j < spRteCfg->ssnList[i].nmbBpc; j++)
            {
               CMCHKUNPK(cmUnpkDpc, &spRteCfg->ssnList[i].bpcList[j].bpc, mBuf);
               CMCHKUNPK(SUnpkU8, &spRteCfg->ssnList[i].bpcList[j].prior, mBuf);
            }
            CMCHKUNPK(SUnpkU16, &spRteCfg->ssnList[i].nmbConPc, mBuf);
            for (j = 0; j < spRteCfg->ssnList[i].nmbConPc; j++)
               CMCHKUNPK(SUnpkU32, &spRteCfg->ssnList[i].conPc[j], mBuf);

         }

         /* unpack backup point codes */
         CMCHKUNPK(SUnpkU16, &spRteCfg->nmbBpc, mBuf);
         for (j = 0; j < spRteCfg->nmbBpc; j++)
         {
            CMCHKUNPK(cmUnpkDpc, &spRteCfg->bpcList[j].bpc, mBuf);
            CMCHKUNPK(SUnpkU8, &spRteCfg->bpcList[j].prior, mBuf);
         }

         /* unpcak replicated mode of point codes if flags for ansi 96 or
          * bell05 is enabled and:
          *   1. rolling upgrade support enabled and bitVector indicates
          *      that the compile flag is enabled at originating side and
          *      hence field replicatedMode was packed.
          *   2. no rolling upgrade support is enabled. In this case
          *      unpacking of field is solely based on compile flag for
          *      ansi96 and bell 05.
          */
#if (SS7_ANS96 || SS7_BELL05)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSP_SS7_ANS96_BIT) ||
             (bitVector & LSP_SS7_BELL05_BIT))
            CMCHKUNPK(SUnpkU8, &spRteCfg->replicatedMode, mBuf);
#else
         CMCHKUNPK(SUnpkU8, &spRteCfg->replicatedMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SS7_ANS96 || SS7_BELL05 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         /* compile flags ansi 96 and bell 05 are not enabled
          * at our side, unpack and ignore field if bitVector
          * indicates its packing
          */
         if ((bitVector & LSP_SS7_ANS96_BIT) ||
             (bitVector & LSP_SS7_BELL05_BIT))
            CMCHKUNPK(SUnpkU8, &tempMode, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS96 || SS7_BELL05 */

         CMCHKUNPK(SUnpkU8, &spRteCfg->status, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spRteCfg->dpc, mBuf);
         CMCHKUNPK(SUnpkS16, &spRteCfg->swtch, mBuf);
         break;
      } /* case 0x0200 */

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmUnpkSpRteCfg */

#if (SS7_ANS96 || SS7_BELL05)

/*
*
*       Fun:   cmPkSpNidDpcCfg
*
*       Desc:  This function is used to pack NID-DPC mapping configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpNidDpcCfg
(
Pst *pst,                  /* post structure */
SpNidDpcCfg *spNidDpcCfg,  /* NID-DPC mapping config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpNidDpcCfg(pst, spNidDpcCfg, mBuf)
Pst *pst;                  /* post structure */
SpNidDpcCfg *spNidDpcCfg;  /* NID-DPC mapping config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   U32 i;                  /* loop counter */

   TRC2(cmPkSpNidDpcCfg);

   UNUSED(pst);

   for (i = 0; i < spNidDpcCfg->noOfNids; i++)
   {
      CMCHKPK(cmPkDpc, spNidDpcCfg->nidMap[i].dpc, mBuf);
      CMCHKPK(SPkU16, spNidDpcCfg->nidMap[i].nid, mBuf);
   }
   CMCHKPK(SPkU32, spNidDpcCfg->noOfNids, mBuf);
  
   RETVALUE(ROK);
} /* cmPkSpNidDpcCfg */


/*
*
*       Fun:   cmUnpkSpNidDpcCfg
*
*       Desc:  This function is used to unpack NID-DPC mapping configuration
*              structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpNidDpcCfg
(
Pst *pst,                  /* post structure */
SpNidDpcCfg *spNidDpcCfg,  /* NID-DPC mapping config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpNidDpcCfg(pst, spNidDpcCfg, mBuf)
Pst *pst;                  /* post structure */
SpNidDpcCfg *spNidDpcCfg;  /* NID-DPC mapping config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */
   S32 i;                  /* loop counter */

   TRC2(cmUnpkSpNidDpcCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         /* this config is not valid in LSPV1 interface */
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal) ELSP197,
                     (ErrVal) STNIDPC, "cmUnpkSpNidDpcCfg() Failed"); 
         RETVALUE(RFAILED);
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(SUnpkU32, &spNidDpcCfg->noOfNids, mBuf);
         for (i = spNidDpcCfg->noOfNids - 1; i >= 0; i--)
         {
            CMCHKUNPK(SUnpkU16, &spNidDpcCfg->nidMap[i].nid, mBuf);
            CMCHKUNPK(cmUnpkDpc, &spNidDpcCfg->nidMap[i].dpc, mBuf);
         }
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
  
   RETVALUE(ROK);
} /* cmUnpkSpNidDpcCfg */

#endif /* SS7_ANS96 || SS7_BELL05 */

#ifdef SS7_BELL05

/*
*
*       Fun:   cmPkSpNwNidSs7NidCfg
*
*       Desc:  This function is used to pack Network specific NID to
*              SS7 format NID mapping configuration structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpNwNidSs7NidCfg
(
Pst *pst,                            /* post structure */
SpNwNidSs7NidCfg *spNwNidSs7NidCfg,  /* NW-NID to SS7-NID mapping cfg struct */
Buffer *mBuf                         /* Message buffer */
)
#else
PRIVATE S16 cmPkSpNwNidSs7NidCfg(pst, spNwNidSs7NidCfg, mBuf)
Pst *pst;                            /* post structure */
SpNwNidSs7NidCfg *spNwNidSs7NidCfg;  /* NW-NID to SS7-NID mapping cfg struct */
Buffer *mBuf;                        /* Message buffer */
#endif
{
   U32 i;                            /* loop counter */

   TRC2(cmPkSpNwNidSs7NidCfg);

   UNUSED(pst);

   for (i = 0; i < spNwNidSs7NidCfg->noOfNids; i++)
   {
      CMCHKPK(cmPkDpc, spNwNidSs7NidCfg->nwSs7NidMap[i].ss7Nid, mBuf);
      CMCHKPK(SPkU16, spNwNidSs7NidCfg->nwSs7NidMap[i].nwNid, mBuf);
   }
   CMCHKPK(SPkU32, spNwNidSs7NidCfg->noOfNids, mBuf);
  
   RETVALUE(ROK);
} /* cmPkSpNwNidSs7NidCfg */


/*
*
*       Fun:   cmUnpkSpNwNidSs7NidCfg
*
*       Desc:  This function is used to unpack Network specific NID to
*              SS7 format NID mapping configuration structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpNwNidSs7NidCfg
(
Pst *pst,                            /* post structure */
SpNwNidSs7NidCfg *spNwNidSs7NidCfg,  /* NW-NID to SS7-NID mapping cfg struct */
Buffer *mBuf                         /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpNwNidSs7NidCfg(pst, spNwNidSs7NidCfg, mBuf)
Pst *pst;                            /* post structure */
SpNwNidSs7NidCfg *spNwNidSs7NidCfg;  /* NW-NID to SS7-NID mapping cfg struct */
Buffer *mBuf;                        /* Message buffer */
#endif
{
   CmIntfVer intfVer;                /* interface version number */
   S32 i;                            /* loop counter */

   TRC2(cmUnpkSpNwNidSs7NidCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         /* this config is not valid in LSPV1 interface */
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal) ELSP198,
                     (ErrVal) STNWSS7,
                     "cmUnpkSpNwNidSs7NidCfg() Failed"); 
         RETVALUE(RFAILED);
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(SUnpkU32, &spNwNidSs7NidCfg->noOfNids, mBuf);
         for (i = spNwNidSs7NidCfg->noOfNids - 1; i >= 0; i--)
         {
            CMCHKUNPK(SUnpkU16, &spNwNidSs7NidCfg->nwSs7NidMap[i].nwNid, mBuf);
            CMCHKUNPK(SUnpkU16, &spNwNidSs7NidCfg->nwSs7NidMap[i].ss7Nid, mBuf);
         }
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
  
   RETVALUE(ROK);
} /* cmUnpkSpNwNidSs7NidCfg */

#endif /* SS7_BELL05 */


/*
*
*       Fun:   cmPkSpTrfLimCfg
*
*       Desc:  This function is used to pack traffic limitation database 
*              configuration structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpTrfLimCfg
(
Pst *pst,                  /* post structure */
SpTrfLimCfg *spTrfLimCfg,  /* traffic limitation database config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpTrfLimCfg(pst, spTrfLimCfg, mBuf)
Pst *pst;                  /* post structure */
SpTrfLimCfg *spTrfLimCfg;  /* traffic limitation database config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   U16 i;                  /* loop counter */
   U16 j;                  /* loop counter */
   U16 k;                  /* loop counter */

   TRC2(cmPkSpTrfLimCfg);

   UNUSED(pst);

   for (i = 0; i < (U16) MAXRL; i++)
   {
      for (j = 0; j < (U16) MAXRSL; j++)
      {
         for (k = 0; k < (U16) MAXCL; k++)
         {
            CMCHKPK(SPkU8, (*spTrfLimCfg)[i][j][k].rl, mBuf);
            CMCHKPK(SPkU8, (*spTrfLimCfg)[i][j][k].rsl, mBuf);
            CMCHKPK(SPkU8, (*spTrfLimCfg)[i][j][k].ril, mBuf);
         }
      }
   }
  
   RETVALUE(ROK);
} /* cmPkSpTrfLimCfg */


/*
*
*       Fun:   cmUnpkSpTrfLimCfg
*
*       Desc:  This function is used to unpack traffic limitation database
*              configuration structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpTrfLimCfg
(
Pst *pst,                  /* post structure */
SpTrfLimCfg *spTrfLimCfg,  /* traffic limitation database config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpTrfLimCfg(pst, spTrfLimCfg, mBuf)
Pst *pst;                  /* post structure */
SpTrfLimCfg *spTrfLimCfg;  /* traffic limitation database config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */
   S16 i;                  /* loop counter */
   S16 j;                  /* loop counter */
   S16 k;                  /* loop counter */

   TRC2(cmUnpkSpTrfLimCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         /* this config is not valid in LSPV1 interface */
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal)ELSP199,
                     (ErrVal) STTRFLIM, "cmUnpkSpTrfLimCfg() Failed"); 
         RETVALUE(RFAILED);
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         for (i = (S16) (MAXRL - 1); i >= 0; i--)
            for (j = (S16) (MAXRSL - 1); j >= 0; j--)
               for (k = (S16) (MAXCL - 1); k >= 0; k--)
               {
                  CMCHKUNPK(SUnpkU8, &((*spTrfLimCfg)[i][j][k].ril), mBuf);
                  CMCHKUNPK(SUnpkU8, &((*spTrfLimCfg)[i][j][k].rsl), mBuf);
                  CMCHKUNPK(SUnpkU8, &((*spTrfLimCfg)[i][j][k].rl), mBuf);
               }
      }
      break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
  
   RETVALUE(ROK);
} /* cmUnpkSpTrfLimCfg */


/*
*
*       Fun:   cmPkSpMsgImpCfg
*
*       Desc:  This function is used to pack message importance configuration
*              structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSpMsgImpCfg
(
Pst *pst,                  /* post structure */
SpMsgImpCfg *spMsgImpCfg,  /* message importance config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmPkSpMsgImpCfg(pst, spMsgImpCfg, mBuf)
Pst *pst;                  /* post structure */
SpMsgImpCfg *spMsgImpCfg;  /* message importance config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmPkSpMsgImpCfg);

   UNUSED(pst);

   CMCHKPK(SPkU8, spMsgImpCfg->defRlcImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defRlsdImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defErrImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defRscImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defRsrImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defEaImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defEdImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defItImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defAkImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defDt2Imp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defDt1Imp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defCrefImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defCcImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defCrImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defLudtSrvImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defLudtImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defXudtSrvImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defXudtImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defUdtSrvImp, mBuf);
   CMCHKPK(SPkU8, spMsgImpCfg->defUdtImp, mBuf);
  
   RETVALUE(ROK);
} /* cmPkSpMsgImpCfg */


/*
*
*       Fun:   cmUnpkSpMsgImpCfg
*
*       Desc:  This function is used to unpack message importance configuration
*              structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSpMsgImpCfg
(
Pst *pst,                  /* post structure */
SpMsgImpCfg *spMsgImpCfg,  /* message importance config structure */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 cmUnpkSpMsgImpCfg(pst, spMsgImpCfg, mBuf)
Pst *pst;                  /* post structure */
SpMsgImpCfg *spMsgImpCfg;  /* message importance config structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkSpMsgImpCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         /* this config is not valid in LSPV1 interface */
         LSPLOGERROR(ERRCLS_DEBUG, (ErrVal) ELSP200, 
                     (ErrVal) STMSGIMP, "cmUnpkSpMsgImpCfg() Failed"); 
         RETVALUE(RFAILED);
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defUdtImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defUdtSrvImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defXudtImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defXudtSrvImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defLudtImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defLudtSrvImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defCrImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defCcImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defCrefImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defDt1Imp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defDt2Imp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defAkImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defItImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defEdImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defEaImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defRsrImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defRscImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defErrImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defRlsdImp, mBuf);
         CMCHKUNPK(SUnpkU8, &spMsgImpCfg->defRlcImp, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
  
   RETVALUE(ROK);
} /* cmUnpkSpMsgImpCfg */


/*
*
*       Fun:   cmPkSpGLBSts
*
*       Desc:  This function is used to pack SCCP global statistics structure.
*
*       Ret:   ROK, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpGLBSts
(
Pst *pst,                  /* post structure */
SpGLBSts *spGLBSts,        /* global statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmPkSpGLBSts(pst, spGLBSts, mBuf)
Pst *pst;                  /* post structure */
SpGLBSts *spGLBSts;        /* global statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkSpGLBSts);

   UNUSED(pst);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKPK(SPkS32, spGLBSts->rfNTASN, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNTSA, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnequip, mBuf);
         CMCHKPK(SPkS32, spGLBSts->synError, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnknown, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->rfHopViolate, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->uDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvTx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->xuDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvTx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->msgHand, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgLoc, mBuf);
         CMCHKPK(SPkS32, spGLBSts->gttReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC1, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->luDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvRx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->segErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->TiarExpiry, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitReset, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitRel, mBuf);
         break;
      }
      
      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      {
         CMCHKPK(SPkS32, spGLBSts->rfNTASN, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNTSA, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnequip, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfHopViolate, mBuf);
         CMCHKPK(SPkS32, spGLBSts->synError, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnknown, mBuf);
         CMCHKPK(SPkS32, spGLBSts->ssCongRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->ssProhRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->uDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->xuDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvRx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->msgHand, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgLoc, mBuf);
         CMCHKPK(SPkS32, spGLBSts->gttReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC1, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->luDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvRx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->segErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->segErrFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErrTimExp, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErrNoSpc, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crefTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crefRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rsrTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rsrRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->errTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->errRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->rlsCmpFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->TiarExpiry, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitReset, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitRel, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfInvInsRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfInvIsniRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfIsniConRtFl, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfRedIsniRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnIsniId, mBuf);
         break;
      }

      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKPK(SPkS32, spGLBSts->rfNTASN, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNTSA, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfNetCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfSsnCong, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnequip, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfHopViolate, mBuf);
         CMCHKPK(SPkS32, spGLBSts->synError, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnknown, mBuf);
         CMCHKPK(SPkS32, spGLBSts->ssCongRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->ssProhRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->uDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->uDataSrvRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->xuDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->xuDataSrvRx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->msgHand, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgLoc, mBuf);
         CMCHKPK(SPkS32, spGLBSts->gttReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spGLBSts->msgRxC1, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->luDataTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->luDataSrvRx, mBuf);
 
         CMCHKPK(SPkS32, spGLBSts->segErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->segErrFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErr, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErrTimExp, mBuf);
         CMCHKPK(SPkS32, spGLBSts->reassemErrNoSpc, mBuf);
/* sp028.302 - addition - pack numConn */
#ifdef LSPV2_2
         CMCHKPK(SPkS32, spGLBSts->numConn, mBuf);
#endif /* LSPV2_2 */
         CMCHKPK(SPkS32, spGLBSts->crTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crefTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->crefRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rsrTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rsrRx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->errTx, mBuf);
         CMCHKPK(SPkS32, spGLBSts->errRx, mBuf);

         CMCHKPK(SPkS32, spGLBSts->rlsCmpFail, mBuf);
         CMCHKPK(SPkS32, spGLBSts->TiarExpiry, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitReset, mBuf);
         CMCHKPK(SPkS32, spGLBSts->prvInitRel, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfInvInsRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfInvIsniRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfIsniConRtFl, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfRedIsniRtReq, mBuf);
         CMCHKPK(SPkS32, spGLBSts->rfUnIsniId, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
 
   RETVALUE(ROK);
} /* cmPkSpGLBSts */


/*
*
*       Fun:   cmUnpkSpGLBSts
*
*       Desc:  This function is used to unpack SCCP global statistics structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpGLBSts
(
Pst *pst,                  /* post structure */
SpGLBSts *spGLBSts,        /* global statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmUnpkSpGLBSts(pst, spGLBSts, mBuf)
Pst *pst;                  /* post structure */
SpGLBSts *spGLBSts;        /* global statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkSpGLBSts);

   UNUSED(pst);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitRel, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitReset, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->TiarExpiry, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErr, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->segErr, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataTx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->gttReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgLoc, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgHand, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataRx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataRx, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->rfHopViolate, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnknown, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->synError, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnequip, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTSA, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTASN, mBuf);
         break;
      }
      
      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      {
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnIsniId, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfRedIsniRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfIsniConRtFl, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfInvIsniRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfInvInsRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitRel, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitReset, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->TiarExpiry, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rlsCmpFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->errRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->errTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rsrRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rsrTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crefRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crefTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErrNoSpc, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErrTimExp, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErr, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->segErrFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->segErr, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataTx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->gttReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgLoc, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgHand, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataTx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataTx, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->ssProhRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->ssCongRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnknown, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->synError, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfHopViolate, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnequip, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTSA, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTASN, mBuf);
         break;
      }

      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnIsniId, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfRedIsniRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfIsniConRtFl, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfInvIsniRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfInvInsRtReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitRel, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->prvInitReset, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->TiarExpiry, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rlsCmpFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->errRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->errTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rsrRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rsrTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crefRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crefTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->crTx, mBuf);
/* sp028.302 - addition - unpack numConn */
#ifdef LSPV2_2
         CMCHKUNPK(SUnpkS32, &spGLBSts->numConn, mBuf);
#endif /* LSPV2_2 */
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErrNoSpc, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErrTimExp, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->reassemErr, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->segErrFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->segErr, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->luDataTx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->gttReq, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgLoc, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->msgHand, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->xuDataTx, mBuf);
 
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->uDataTx, mBuf);

         CMCHKUNPK(SUnpkS32, &spGLBSts->ssProhRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->ssCongRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnknown, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->synError, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfHopViolate, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfUnequip, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfSsnFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetCong, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNetFail, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTSA, mBuf);
         CMCHKUNPK(SUnpkS32, &spGLBSts->rfNTASN, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */
 
   RETVALUE(ROK);
} /* cmUnpkSpGLBSts */


/*
*
*       Fun:   cmPkSpNSAPSts
*
*       Desc:  This function is used to pack lower SAP statistics structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpNSAPSts
(
Pst *pst,                  /* post structure */
SpNSAPSts *spNSAPSts,      /* lower SAP statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmPkSpNSAPSts(pst, spNSAPSts, mBuf)
Pst *pst;                  /* post structure */
SpNSAPSts *spNSAPSts;      /* lower SAP statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmPkSpNSAPSts);

   UNUSED(pst);

   /* no change in NSAP statistics struct in LSPV1 and LSPV2,
    * hence no need of translation
    */
   CMCHKPK(SPkS32, spNSAPSts->ssAllTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssOutGTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssOutRTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssProhTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssStatTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssAllRx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssOutGRx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssOutRRx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssProhRx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssStatRx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssCongTx, mBuf);
   CMCHKPK(SPkS32, spNSAPSts->ssCongRx, mBuf);
 
   RETVALUE(ROK);
} /* cmPkSpNSAPSts */


/*
*
*       Fun:   cmUnpkSpNSAPSts
*
*       Desc:  This function is used to unpack lower SAP statistics structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpNSAPSts
(
Pst *pst,                  /* post structure */
SpNSAPSts *spNSAPSts,      /* lower SAP statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmUnpkSpNSAPSts(pst, spNSAPSts, mBuf)
Pst *pst;                  /* post structure */
SpNSAPSts *spNSAPSts;      /* lower SAP statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   TRC2(cmUnpkSpNSAPSts);

   UNUSED(pst);

   /* no change in NSAP statistics struct in LSPV1 and LSPV2,
    * hence no need of translation
    */

   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssCongRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssCongTx, mBuf);

   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssStatRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssProhRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssOutRRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssOutGRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssAllRx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssStatTx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssProhTx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssOutRTx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssOutGTx, mBuf);
   CMCHKUNPK(SUnpkS32, &spNSAPSts->ssAllTx, mBuf);

   RETVALUE(ROK);
} /* cmUnpkSpNSAPSts */


/*
*
*       Fun:   cmPkSpSAPSts
*
*       Desc:  This function is used to pack upper SAP statistics structure.
*
*       Ret:   ROK, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpSAPSts
(
Pst *pst,                  /* post structure */
SpSAPSts *spSAPSts,        /* upper SAP statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmPkSpSAPSts(pst, spSAPSts, mBuf)
Pst *pst;                  /* post structure */
SpSAPSts *spSAPSts;        /* upper SAP statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkSpSAPSts);

   /* if rolling upgrade support is enabled, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqGr, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqDn, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxBSS, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC1, mBuf);
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      {
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqGr, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqDn, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssProhStart, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssProhStop, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxBSS, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt1MsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt1MsgTx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt2MsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt2MsgTx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->edMsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->edMsgTx, mBuf);
         break;
      }
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqGr, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssOOSReqDn, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssProhStart, mBuf);
         CMCHKPK(SPkS32, spSAPSts->ssProhStop, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxBSS, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgTxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgRxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt1MsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt1MsgTx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt2MsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->dt2MsgTx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->edMsgRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->edMsgTx, mBuf);
         /* lsp_c_002.main_4_1 - Addition - Statistics for message Interception
          * for class 0 and class 1. Statistics for unit data service request.
          */
#ifdef LSPV2_5
         CMCHKPK(SPkS32, spSAPSts->msgInterceptTxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgInterceptTxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgInterceptRxC0, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgInterceptRxC1, mBuf);
         CMCHKPK(SPkS32, spSAPSts->msgUDatSrvReqRx, mBuf);
         CMCHKPK(SPkS32, spSAPSts->uDataSrvTx, mBuf);
#endif /* LSPV2_5 */
         break;
      }
      
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmPkSpSAPSts */


/*
*
*       Fun:   cmUnpkSpSAPSts
*
*       Desc:  This function is used to unpack upper SAP statistics structure.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpSAPSts
(
Pst *pst,                  /* post structure */
SpSAPSts *spSAPSts,        /* upper SAP statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmUnpkSpSAPSts(pst, spSAPSts, mBuf)
Pst *pst;                  /* post structure */
SpSAPSts *spSAPSts;        /* upper SAP statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkSpSAPSts);

   /* if rolling upgrade support is enabled, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxBSS, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqDn, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqGr, mBuf);
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      {
         CMCHKUNPK(SUnpkS32, &spSAPSts->edMsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->edMsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt2MsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt2MsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt1MsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt1MsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxBSS, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssProhStop, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssProhStart, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqDn, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqGr, mBuf);
         break; 
      }
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
         /* lsp_c_002.main_4_1 - Addition - Statistics for message Interception
          * for class 0 and class 1. Statistics for unit data service request.
          */
#ifdef LSPV2_5
         CMCHKUNPK(SUnpkS32, &spSAPSts->uDataSrvTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgUDatSrvReqRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgInterceptRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgInterceptRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgInterceptTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgInterceptTxC0, mBuf);
#endif /* LSPV2_5 */
         CMCHKUNPK(SUnpkS32, &spSAPSts->edMsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->edMsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt2MsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt2MsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt1MsgTx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->dt1MsgRx, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgRxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC1, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxC0, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->msgTxBSS, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssProhStop, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssProhStart, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqDn, mBuf);
         CMCHKUNPK(SUnpkS32, &spSAPSts->ssOOSReqGr, mBuf);
         break; 
      }
      
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmUnpkSpSAPSts */


/*
*
*       Fun:   cmPkSpRTESts
*
*       Desc:  This function is used to pack route statistics structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSpRTESts
(
Pst *pst,                  /* post structure */
SpRTESts *spRTESts,        /* route statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmPkSpRTESts(pst, spRTESts, mBuf)
Pst *pst;                  /* post structure */
SpRTESts *spRTESts;        /* route statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   Cntr i;                 /* loop counter */
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkSpRTESts);

   /* if rolling upgrade support is enabled, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
         /* route statistics report is not valid in LSPV1 interface */
         RETVALUE(RFAILED);

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      {
         /* pack ssn statistics, if SSN are present in this route */
         if (spRTESts->numOfSsn)
         {
            for (i = (Cntr) (spRTESts->numOfSsn - 1); i >= 0; i--)
            {
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssAllRx, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssORDenied, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssOGRx, mBuf);
               CMCHKPK(cmPkSsn, spRTESts->ssnSts[i].ssn, mBuf);
            }
            CMCHKPK(SPkS32, spRTESts->numOfSsn, mBuf);
            CMCHKPK(cmPkDpc, spRTESts->pc, mBuf);
            CMCHKPK(cmPkNwId, spRTESts->nwId, mBuf);
         }
         break;
      }
      case 0x0205:     /* lsp_c_002.main_4_1 - added new interface version 
                        * and packing of SST and SSP trans, 
                        * receive statistics added under LSPV2_5
                        */
      {
         /* pack ssn statistics, if SSN are present in this route */
         if (spRTESts->numOfSsn)
         {
            for (i = (Cntr) (spRTESts->numOfSsn - 1); i >= 0; i--)
            {
#ifdef LSPV2_5   
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssStatTx, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssProhTx, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssStatRx, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssProhRx, mBuf);
#endif /* LSPV2_5 */   
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssAllRx, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssORDenied, mBuf);
               CMCHKPK(SPkS32, spRTESts->ssnSts[i].ssOGRx, mBuf);
               CMCHKPK(cmPkSsn, spRTESts->ssnSts[i].ssn, mBuf);
            }
            CMCHKPK(SPkS32, spRTESts->numOfSsn, mBuf);
            CMCHKPK(cmPkDpc, spRTESts->pc, mBuf);
            CMCHKPK(cmPkNwId, spRTESts->nwId, mBuf);
         }
         break;
      }
      
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmPkSpRTESts */


/*
*
*       Fun:   cmUnpkSpRTESts
*
*       Desc:  This function is used to unpack route statistics structure.
*
*       Ret:   ROK, RFAILED, RINVIFVER
*
*       Notes: None
*
*       File:  lsp.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSpRTESts
(
Pst *pst,                  /* post structure */
SpRTESts *spRTESts,        /* route statistics structure */
Buffer *mBuf               /* Message buffer */
)
#else
PUBLIC S16 cmUnpkSpRTESts(pst, spRTESts, mBuf)
Pst *pst;                  /* post structure */
SpRTESts *spRTESts;        /* route statistics structure */
Buffer *mBuf;              /* Message buffer */
#endif
{
   Cntr i;                 /* loop counter */
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkSpRTESts);

   /* if rolling upgrade support is enabled, use interface version as
    * in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
         /* route statistics report is not valid in LSPV1 interface */
         RETVALUE(RFAILED);

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
         CMCHKUNPK(cmUnpkNwId, &spRTESts->nwId, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spRTESts->pc, mBuf);
         CMCHKUNPK(SUnpkS32, &spRTESts->numOfSsn, mBuf);

         /* unpack ssn statistics, if ssn are present on route */
         if (spRTESts->numOfSsn)
         {
            for (i = 0; i < spRTESts->numOfSsn; i++)
            {
               CMCHKUNPK(cmUnpkSsn, &spRTESts->ssnSts[i].ssn, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssOGRx, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssORDenied, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssAllRx, mBuf);
            }
         }
         break;
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version 
                        * and unpacking of SST and SSP trans, 
                        * receive statistics added under LSPV2_5
                        */
         CMCHKUNPK(cmUnpkNwId, &spRTESts->nwId, mBuf);
         CMCHKUNPK(cmUnpkDpc, &spRTESts->pc, mBuf);
         CMCHKUNPK(SUnpkS32, &spRTESts->numOfSsn, mBuf);

         /* unpack ssn statistics, if ssn are present on route */
         if (spRTESts->numOfSsn)
         {
            for (i = 0; i < spRTESts->numOfSsn; i++)
            {
               CMCHKUNPK(cmUnpkSsn, &spRTESts->ssnSts[i].ssn, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssOGRx, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssORDenied, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssAllRx, mBuf);
#ifdef LSPV2_5   
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssProhRx, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssStatRx, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssProhTx, mBuf);
               CMCHKUNPK(SUnpkS32, &spRTESts->ssnSts[i].ssStatTx, mBuf);
#endif /* LSPV2_5 */   
            }
         }
         break;
     
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* cmUnpkSpRTESts */


/*
 * 
 * Fun : gtPkSpActn
 *
 * Desc : Pack SpActn
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtPkSpActn 
(
SpActn *actn,   /* GT Action */
Buffer *mBuf      /* Message buffer */
)
#else
PRIVATE S16 gtPkSpActn (actn, mBuf)
SpActn *actn;   /* GT Action */
Buffer *mBuf;     /* Message buffer */
#endif
{
   S16 i;

   TRC2 (gtPkSpActn);

   switch (actn->type)
   {
      case SP_ACTN_FIX :
      case SP_ACTN_VAR_ASC :
      case SP_ACTN_VAR_DES :
         CMCHKPK (SPkU8, actn->param.range.endDigit, mBuf);
         CMCHKPK (SPkU8, actn->param.range.startDigit, mBuf);
         break;

      case SP_ACTN_CONST:
         break;

      case SP_ACTN_GT_TO_PC:
         break;

      default:         
         for (i=SP_MAX_ACTN_PARAMS-1; i >= 0; i--)
         {
            CMCHKPK (SPkU8, actn->param.data[i], mBuf);
         }
         break;

   } /* switch */
   CMCHKPK (SPkU8, actn->type, mBuf);
   return (ROK);
} /* gtPkSpActn () */


/*
 * 
 * Fun : gtPkGt
 *
 * Desc : Pack Global Title
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtPkGt
(
GlbTi *gt,        /* GT Action */
Swtch sw,         /* Switch - to adjust teh format for ANSI */
Buffer *mBuf      /* Message buffer */
)
#else
PRIVATE S16 gtPkGt (gt, sw, mBuf)
GlbTi *gt;        /* GT Action */
Swtch sw;         /* Switch - to adjust teh format for ANSI */
Buffer *mBuf;     /* Message buffer */
#endif
{
   U8 adjFrmt;
   U8 octet = 0;
   U8 len;
   S16 ret1;
   
   TRC2 (gtPkGt);
   
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   /* Adjust ansi type 1 to equivalent ccitt (type 3) */
   if ((sw == SW_ANSI) && (gt->format == GTFRMT_1))
       adjFrmt = GTFRMT_3;
   else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
      adjFrmt = gt->format;
   
   /*
    * Pack the digits, no matter what the format. 
    * Thsi is becoz some of the rules might be ignoring the 
    * format field.
    */

   ret1 = cmPkLngAddr((LngAddrs*)&gt->addr, mBuf, &len);
   if (ret1 != ROK)
      return (ret1);

   switch (adjFrmt)
   {
      case GTFRMT_1:
         /* encode global title header */
         octet |= ((gt->gt.f1.oddEven & 0x01) << 7);
         octet |= (gt->gt.f1.natAddr & 0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         break;

      case GTFRMT_2:
         /* encode translation type */
         CMCHKPK( SPkU8, gt->gt.f2.tType, mBuf);
         break;

      case GTFRMT_3:
         /* encode global title header */
         octet |= ((gt->gt.f3.numPlan & 0x0f) << 4);
         octet |= (gt->gt.f3.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         CMCHKPK( SPkU8, gt->gt.f3.tType, mBuf);
         break;

      case GTFRMT_4:
         /* encode global title header */
         octet = (U8)(gt->gt.f4.natAddr & (U8)0x7f);
         CMCHKPK( SPkU8, octet, mBuf);
         octet = 0;
         octet |= ((gt->gt.f4.numPlan & 0x0f) << 4);
         octet |= (gt->gt.f4.encSch & 0x0f);
         CMCHKPK( SPkU8, octet, mBuf);
         CMCHKPK( SPkU8, gt->gt.f4.tType, mBuf);
         break;
   }
   CMCHKPK (SPkU8, gt->format, mBuf);
   return (ROK);
} /* gtPkGt () */


/*
 * 
 * Fun : gtPkSpAddrMapCfg
 *
 * Desc : To Pack GT AddrMap configuration structure
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtPkSpAddrMapCfg
(
Pst *pst,                  /* post structure */
SpAddrMapCfg *addrMap,     /* GT AddrMap */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 gtPkSpAddrMapCfg(pst, addrMap, mBuf)
Pst *pst;                  /* post structure */
SpAddrMapCfg *addrMap;     /* GT AddrMap */
Buffer *mBuf;              /* Message buffer */
#endif
{
   S16 ret1;               /* return value */
   U8 len;                 /* length of spAddr */
   S16 j;                  /* loop counter */

   TRC2(gtPkSpAddrMapCfg);

   UNUSED(pst);
   
   for (j = (S16) (addrMap->numEntity - 1); j >= 0; j--)
   {
      ret1 = cmPkSpAddr(&addrMap->outAddr[j], mBuf, &len);
      if (ret1 != ROK)
         RETVALUE(ret1);
   }
   CMCHKPK(SPkU8, addrMap->numEntity, mBuf);
   CMCHKPK(SPkU8, addrMap->mode, mBuf);
   ret1 = gtPkGt(&addrMap->gt, addrMap->sw, mBuf);
   if (ret1 != ROK)
      RETVALUE(ret1);
   CMCHKPK(cmPkBool, addrMap->noCplng, mBuf);
   CMCHKPK(cmPkBool, addrMap->replGt, mBuf);
   CMCHKPK(cmPkSwtch, addrMap->sw, mBuf);
   CMCHKPK(gtPkSpActn, &addrMap->actn, mBuf);
   /* lsp_c_001.main_4_1 - addition - packing of network id  and outgoing
    * network id.
    */
#ifdef LSPV2_4   
   CMCHKPK(cmPkNwId, addrMap->nwId, mBuf);
   CMCHKPK(cmPkNwId, addrMap->outNwId, mBuf);
#endif  /* LSPV2_4 */  

   RETVALUE(ROK);
} /* gtPkSpAddrMapCfg */


/*
 * 
 * Fun : gtPkSpRule
 *
 * Desc : Pack GT Rule
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtPkSpRule
(
SpRule *rule,        /* GT Rule */
Buffer *mBuf         /* Message buffer */
)
#else
PRIVATE S16 gtPkSpRule (rule, mBuf)
SpRule *rule;        /* GT Rule */
Buffer *mBuf;        /* Message buffer */
#endif
{
   U8 adjFrmt;

   TRC2 (gtPkSpRule);

   if (rule->formatPres)
   {
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
      /* Adjust ansi type 1 to equivalent ccitt (type 3) */
      if ((rule->sw == SW_ANSI) && (rule->format == GTFRMT_1))
         adjFrmt = GTFRMT_3;
      else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
         adjFrmt = rule->format;
      
      switch (adjFrmt)
      {
         case GTFRMT_0 :
            break;
         case GTFRMT_1 :
            if (rule->gt.f1.natAddrPres)
               CMCHKPK (SPkU8, rule->gt.f1.natAddr, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f1.natAddrPres, mBuf);
            if (rule->gt.f1.oddEvenPres)
               CMCHKPK (cmPkBool, rule->gt.f1.oddEven, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f1.oddEvenPres, mBuf);
            break;

         case GTFRMT_2 :
            if (rule->gt.f2.tTypePres)
               CMCHKPK (SPkU8, rule->gt.f2.tType, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f2.tTypePres, mBuf);
            break;

         case GTFRMT_3 :
            if (rule->gt.f3.encSchPres)
               CMCHKPK (SPkU8, rule->gt.f3.encSch, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f3.encSchPres, mBuf);
            if (rule->gt.f3.numPlanPres)
               CMCHKPK (SPkU8, rule->gt.f3.numPlan, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f3.numPlanPres, mBuf);
            if (rule->gt.f3.tTypePres)
               CMCHKPK (SPkU8, rule->gt.f3.tType, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f3.tTypePres, mBuf);
            break;
            
         case GTFRMT_4 :
            if (rule->gt.f4.encSchPres)
               CMCHKPK (SPkU8, rule->gt.f4.encSch, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f4.encSchPres, mBuf);
            if (rule->gt.f4.numPlanPres)
               CMCHKPK (SPkU8, rule->gt.f4.numPlan, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f4.numPlanPres, mBuf);
            if (rule->gt.f4.tTypePres)
               CMCHKPK (SPkU8, rule->gt.f4.tType, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f4.tTypePres, mBuf);
            if (rule->gt.f4.natAddrPres)
               CMCHKPK (SPkU8, rule->gt.f4.natAddr, mBuf);
            CMCHKPK (cmPkBool, rule->gt.f4.natAddrPres, mBuf);
            break;

         default :
            break;
      } /* switch () */
   CMCHKPK (SPkU8, rule->format, mBuf);
   } /* if () */
   CMCHKPK (SPkU8, rule->formatPres, mBuf);
   CMCHKPK (cmPkSwtch, rule->sw, mBuf);
   return (ROK);
} /* gtPkSpRule () */


/*
 * 
 * Fun : gtPkSpAssoCfg
 *
 * Desc : To Pack GT Association
 * 
 * Return : ROK
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtPkSpAssoCfg
(
Pst *pst,            /* post structure */
SpAssoCfg *assoCfg,  /* GT association */
Buffer *mBuf         /* Message buffer */
)
#else
PRIVATE S16 gtPkSpAssoCfg(pst, assoCfg, mBuf)
Pst *pst;            /* post structure */
SpAssoCfg *assoCfg;  /* GT association */
Buffer *mBuf;        /* Message buffer */
#endif
{
   S16 i;            /* loop counter */

   TRC2(gtPkSpAssoCfg);

   UNUSED(pst);
   
   CMCHKPK(SPkU8, assoCfg->fSetType, mBuf);
   for (i = 0; i < assoCfg->nmbActns; i++)
      CMCHKPK(gtPkSpActn, &assoCfg->actn[i], mBuf);
   CMCHKPK(SPkU8, assoCfg->nmbActns, mBuf);
   CMCHKPK(gtPkSpRule, &assoCfg->rule, mBuf);
   /* lsp_c_001.main_4_1 - addition - packing of network id */
#ifdef LSPV2_4   
   CMCHKPK(cmPkNwId, assoCfg->nwId, mBuf);
#endif  /* LSPV2_4 */  
   RETVALUE(ROK);
} /* gtPkSpAssoCfg */

/*
 * Unpacking functions 
 */


/*
 * 
 * Fun : gtUnpkSpActn
 *
 * Desc : Unpack SpActn
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtUnpkSpActn 
(
SpActn *actn,     /* GT Action */
Buffer *mBuf      /* Message buffer */
)
#else
PRIVATE S16 gtUnpkSpActn (actn, mBuf)
SpActn *actn;     /* GT Action */
Buffer *mBuf;     /* Message buffer */
#endif
{
   S16 i;         /* loop counter */

   TRC2(gtUnpkSpActn);

   CMCHKUNPK (SUnpkU8, &actn->type, mBuf);
   switch (actn->type)
   {
      case SP_ACTN_FIX :
      case SP_ACTN_VAR_ASC :
      case SP_ACTN_VAR_DES :
         CMCHKUNPK (SUnpkU8, &actn->param.range.startDigit, mBuf);
         CMCHKUNPK (SUnpkU8, &actn->param.range.endDigit, mBuf);
         break;

      case SP_ACTN_CONST:
         break;

      case SP_ACTN_GT_TO_PC:
         break;
      default:         
         for (i=0; i < SP_MAX_ACTN_PARAMS; i++)
         {
            CMCHKUNPK (SUnpkU8, &actn->param.data[i], mBuf);
         }
         break;
   } /* switch */
   return (ROK);
} /* gtUnpkSpActn */


/*
 * 
 * Fun : gtUnpkGt
 *
 * Desc : Unpack Global Title
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtUnpkGt
(
GlbTi *gt,        /* GT Action */
Swtch sw,         /* Switch - to adjust teh format for ANSI */
Buffer *mBuf      /* Message buffer */
)
#else
PRIVATE S16 gtUnpkGt (gt, sw, mBuf)
GlbTi *gt;         /* GT Action */
Swtch sw;          /* Switch - to adjust teh format for ANSI */
Buffer *mBuf;      /* Message buffer */
#endif
{
   U8 adjFrmt;
   U8 octet;

   TRC2 (gtUnpkGt);
   
   CMCHKUNPK (SUnpkU8, &gt->format, mBuf);
   
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
   if ((sw == SW_ANSI) && (gt->format == GTFRMT_1))
      adjFrmt = GTFRMT_3;
   else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
      adjFrmt = gt->format;
   switch (adjFrmt)
   {
      case GTFRMT_1:
         /* Odd/Even, and Nature of Address Indicator */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f1.oddEven = (U8)((octet >> 0x07) & 0x01);
         gt->gt.f1.natAddr = (U8)(octet & 0x7f);
         break;

      case GTFRMT_2:
         /* Translation type */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f2.tType = octet;
         break;

      case GTFRMT_3:
         /* Translation type */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f3.tType = octet;
         /* Encoding Scheme and Numbering Plan */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f3.encSch = (U8)(octet & 0x0f);
         gt->gt.f3.numPlan = (U8)((octet >> 0x04) & 0x0f);
         break;

      case GTFRMT_4:
         /* Translation type */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f4.tType = octet;
         /* Encoding Scheme and Numbering Plan */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f4.encSch = (U8)(octet & 0x0f);
         gt->gt.f4.numPlan = (U8)((octet >> 0x04) & 0x0f);
         /* Nature of address indicator */
         CMCHKUNPK( SUnpkU8, &octet, mBuf);
         gt->gt.f4.natAddr = (U8)(octet & 0x7f);
         break;
   } /* switch () */
   /* Address digits */
   CMCHKUNPK( cmUnpkLngAddr, (LngAddrs*)&gt->addr, mBuf);
   return (ROK);
} /* gtUnpkGt () */


/*
 * 
 * Fun : gtUnpkSpAddrMapCfg
 *
 * Desc : Unpack GT AddrMapCfg
 * 
 * Return : ROK      : Ok. Unpacking successful.
 *          RINVIFVER: Unpacking failed. Invalid interface version number.
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtUnpkSpAddrMapCfg
(
Pst *pst,                  /* post structure */
SpAddrMapCfg *addrMap,     /* GT AddrMap */
Buffer *mBuf               /* Message buffer */
)
#else
PRIVATE S16 gtUnpkSpAddrMapCfg(pst, addrMap, mBuf)
Pst *pst;                  /* post structure */
SpAddrMapCfg *addrMap;     /* GT AddrMap */
Buffer *mBuf;              /* Message buffer */
#endif
{
   S16 ret1;               /* return value */
   U16 j;                  /* loop counter */
   CmIntfVer intfVer;      /* interface version number */

   TRC2(gtUnpkSpAddrMapCfg);

   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LSP interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:     /* interface version LSPV1 */
      {
         CMCHKUNPK(gtUnpkSpActn, &addrMap->actn, mBuf);
         CMCHKUNPK(cmUnpkSwtch, &addrMap->sw, mBuf);
         CMCHKUNPK(cmUnpkBool, &addrMap->replGt, mBuf);

         /* assign default value of noCplng flag */
         addrMap->noCplng = FALSE;

         ret1 = gtUnpkGt(&addrMap->gt, addrMap->sw, mBuf);
         if (ret1 != ROK)
            RETVALUE(ret1);

         /* assign default value of mode and numEntity */
         addrMap->mode = DOMINANT;
         addrMap->numEntity = 1;

         ret1 = cmUnpkSpAddr(&addrMap->outAddr[0], mBuf);
         if (ret1 != ROK)
            RETVALUE(ret1);
         /* lsp_c_001.main_4_1 - addition - LM intfVer is LSPV1 or LSPV2 or
          * LSPV2_1 or LSPV2_2 or LSPV2_3 network id  and out going network id
          * would not have been packed in mbuf. In these cases use default
          * value of network id and outgoing network id.
          */
#ifdef LSPV2_4
         addrMap->nwId = 0xFFFF;
         addrMap->outNwId = 0xFFFF;
#endif  /* LSPV2_4 */
         break;
      }

      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      {
         CMCHKUNPK(gtUnpkSpActn, &addrMap->actn, mBuf);
         CMCHKUNPK(cmUnpkSwtch, &addrMap->sw, mBuf);
         CMCHKUNPK(cmUnpkBool, &addrMap->replGt, mBuf);
         CMCHKUNPK(cmUnpkBool, &addrMap->noCplng, mBuf);
         ret1 = gtUnpkGt(&addrMap->gt, addrMap->sw, mBuf);
         if (ret1 != ROK)
            RETVALUE(ret1);
         CMCHKUNPK(SUnpkU8, &addrMap->mode, mBuf);
         CMCHKUNPK(SUnpkU8, &addrMap->numEntity, mBuf);
         /* unpcak SCCP entities */
         for (j = 0; j < addrMap->numEntity; j++)
         {
            ret1 = cmUnpkSpAddr(&addrMap->outAddr[j], mBuf);
            if (ret1 != ROK)
               RETVALUE(ret1);
         }
         /* lsp_c_001.main_4_1 - addition - LM intfVer is LSPV1 or LSPV2 or
          * LSPV2_1 or LSPV2_2 or LSPV2_3 network id  and out going network id
          * would not have been packed in mbuf. In these cases use default
          * value of network id and outgoing network id.
          */
#ifdef LSPV2_4
         addrMap->nwId = 0xFFFF;
         addrMap->outNwId = 0xFFFF;
#endif  /* LSPV2_4 */
         break;
      }
      case 0x0204:     /* lsp_c_001.main_4_1 - added interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
      {
#ifdef LSPV2_4
         CMCHKUNPK(cmUnpkNwId, &addrMap->outNwId, mBuf);
         CMCHKUNPK(cmUnpkNwId, &addrMap->nwId, mBuf);
#endif  /* LSPV2_4 */
         CMCHKUNPK(gtUnpkSpActn, &addrMap->actn, mBuf);
         CMCHKUNPK(cmUnpkSwtch, &addrMap->sw, mBuf);
         CMCHKUNPK(cmUnpkBool, &addrMap->replGt, mBuf);
         CMCHKUNPK(cmUnpkBool, &addrMap->noCplng, mBuf);
         ret1 = gtUnpkGt(&addrMap->gt, addrMap->sw, mBuf);
         if (ret1 != ROK)
            RETVALUE(ret1);
         CMCHKUNPK(SUnpkU8, &addrMap->mode, mBuf);
         CMCHKUNPK(SUnpkU8, &addrMap->numEntity, mBuf);
         /* unpcak SCCP entities */
         for (j = 0; j < addrMap->numEntity; j++)
         {
            ret1 = cmUnpkSpAddr(&addrMap->outAddr[j], mBuf);
            if (ret1 != ROK)
               RETVALUE(ret1);
         }
         break;
      }
      
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
} /* gtUnpkSpAddrMapCfg */


/*
 * 
 * Fun : gtUnpkSpRule
 *
 * Desc : Unpack GT Rule
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtUnpkSpRule
(
SpRule *rule,        /* GT Rule */
Buffer *mBuf         /* Message buffer */
)
#else
PRIVATE S16 gtUnpkSpRule (rule, mBuf)
SpRule *rule;        /* GT Rule */
Buffer *mBuf;        /* Message buffer */
#endif
{
   U8 adjFrmt;

   TRC2 (gtUnpkSpRule);

   CMCHKUNPK (cmUnpkSwtch, &rule->sw, mBuf);
   CMCHKUNPK (SUnpkU8, &rule->formatPres, mBuf);
   if (rule->formatPres)
   {
      CMCHKUNPK(SUnpkU8, &rule->format, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05)
      /* Adjust ansi type 1 to equivalent ccitt (type 3) */
      if ((rule->sw == SW_ANSI) && (rule->format == GTFRMT_1))
         adjFrmt = GTFRMT_3;
      else
#endif /* SS7_ANS88 || SS7_ANS92 || SS7_ANS96 || SS7_BELL05 */
         adjFrmt = rule->format;
      switch (adjFrmt)
      {
         case GTFRMT_0 :
            break;
         case GTFRMT_1 :
            CMCHKUNPK (cmUnpkBool, &rule->gt.f1.oddEvenPres, mBuf);
            if (rule->gt.f1.oddEvenPres)
               CMCHKUNPK (cmUnpkBool, &rule->gt.f1.oddEven, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f1.natAddrPres, mBuf);
            if (rule->gt.f1.natAddrPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f1.natAddr, mBuf);
            break;

         case GTFRMT_2 :
            CMCHKUNPK (cmUnpkBool, &rule->gt.f2.tTypePres, mBuf);
            if (rule->gt.f2.tTypePres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f2.tType, mBuf);
            break;

         case GTFRMT_3 :
            CMCHKUNPK (cmUnpkBool, &rule->gt.f3.tTypePres, mBuf);
            if (rule->gt.f3.tTypePres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f3.tType, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f3.numPlanPres, mBuf);
            if (rule->gt.f3.numPlanPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f3.numPlan, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f3.encSchPres, mBuf);
            if (rule->gt.f3.encSchPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f3.encSch, mBuf);
            break;
            
         case GTFRMT_4 :
            CMCHKUNPK (cmUnpkBool, &rule->gt.f4.natAddrPres, mBuf);
            if (rule->gt.f4.natAddrPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f4.natAddr, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f4.tTypePres, mBuf);
            if (rule->gt.f4.tTypePres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f4.tType, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f4.numPlanPres, mBuf);
            if (rule->gt.f4.numPlanPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f4.numPlan, mBuf);
            CMCHKUNPK (cmUnpkBool, &rule->gt.f4.encSchPres, mBuf);
            if (rule->gt.f4.encSchPres)
               CMCHKUNPK (SUnpkU8, &rule->gt.f4.encSch, mBuf);    
            break;

         default :
            break;
      }/* switch () */
   } /* if () */
   return (ROK);
} /* gtUnpkSpRule () */


/*
 * 
 * Fun : gtUnpkSpAssoCfg
 *
 * Desc : Unpack GT Association
 * 
 * Return : ROK, RFAILED, ROUTRES
 *
 * Notes: none
 *
 * File: lsp.c
 *
 */
#ifdef ANSI
PRIVATE S16 gtUnpkSpAssoCfg
(
Pst *pst,            /* post structure */
SpAssoCfg *assoCfg,  /* GT associaktion */
Buffer *mBuf         /* Message buffer */
)
#else
PRIVATE S16 gtUnpkSpAssoCfg(pst, assoCfg, mBuf)
Pst *pst;            /* post structure */
SpAssoCfg *assoCfg;  /* GT Assocation */
Buffer *mBuf;        /* Message buffer */
#endif
{
   S16 i;            /* loop counter */
   CmIntfVer intfVer; /* lsp_c_001.main_4_1 - addition - interface version number */

   TRC2 (gtUnpkSpAssoCfg);

   UNUSED(pst);

   /* lsp_c_001.main_4_1 - addition - if rolling upgrade support is enabled, use 
    * interface version as in pst-intfVer, else use self LSP interface
    * version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSPIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      /* SpAssoCfg struct is same in LSPV1 and LSPV2, hence no
       * need for translation of struct
       */
      case 0x0100:     /* interface version LSPV1 */
      case 0x0200:     /* interface version LSPV2 */
      case 0x0201:     /* sp020.302 - added interface version LSPV2_1 */
      case 0x0202:     /* sp028.302 - added interface version LSPV2_2 */
      case 0x0203:     /* sp032.302 - added interface version LSPV2_3 */
      {
         CMCHKUNPK(gtUnpkSpRule, &assoCfg->rule, mBuf);   
         CMCHKUNPK(SUnpkU8, &assoCfg->nmbActns, mBuf);
         /* lsp_c_001.main_4_1 - modification - replacing CMCHKPK with CMCHKUNPK*/
         for (i = assoCfg->nmbActns - 1; i >= 0; i--)
            CMCHKUNPK(gtUnpkSpActn, &assoCfg->actn[i], mBuf);
         /* lsp_c_001.main_4_1 - modification - replacing CMCHKPK with CMCHKUNPK*/
         CMCHKUNPK(SUnpkU8, &assoCfg->fSetType, mBuf);
         /* lsp_c_001.main_4_1 - addition - LM intfVer is LSPV1 or LSPV2 or 
          * LSPV2_1 or LSPV2_2 or LSPV2_3 network id  
          * would not have been packed in mbuf. In these cases use default
          * value of network id and outNwId, which is 0xFFFF.
          */
#ifdef LSPV2_4
         assoCfg->nwId = 0xFFFF;
#endif  /* LSPV2_4 */
      }
         break;
      case 0x0204: /* lsp_c_001.main_4_1 - addition - interface version LSPV2_4 */
      case 0x0205:     /* lsp_c_002.main_4_1 - added interface version LSPV2_5*/
         {
#ifdef LSPV2_4
            CMCHKUNPK(cmUnpkNwId, &assoCfg->nwId, mBuf);
#endif  /* LSPV2_4 */
            CMCHKUNPK(gtUnpkSpRule, &assoCfg->rule, mBuf);   
            CMCHKUNPK(SUnpkU8, &assoCfg->nmbActns, mBuf);
            for (i = assoCfg->nmbActns - 1; i >= 0; i--)
               CMCHKUNPK(gtUnpkSpActn, &assoCfg->actn[i], mBuf);
            CMCHKUNPK(SUnpkU8, &assoCfg->fSetType, mBuf);
         }
         break;
      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   }
   RETVALUE(ROK);
} /* gtUnpkSpAssoCfg */


#endif /* LCLSP */

/********************************************************************30**
  
         End of file:     lsp.c@@/main/4_1 - Tue Jan 22 15:14:22 2002
  
*********************************************************************31*/
  
/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  
  
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      cp   1. initial release.
                      ash  2. Moved defGuaTmr outside #SPCO section and 
                              corresponding packing unpacking also changed
                           3. Removed STNSAPDIS
                           4. added tIntTmr in management general 
                              configuration under SNT2
                      cp   5. added packing/unpacking functions for TrcInd
                           6. Changed the packing/unpacking order for TrcInd
                              packng/unpacking fns.
                           7. Added flag LCLSP.

/main/2      sp005.28 cp   1. Added packing/unpacking functions for the new 
                              GTT framework and for STROUT in StaReq.
             sp009.28 cp   2. Corrected spUnpkRule function.
             sp011.28 cp   3. Added packing/unpacking for SpAddrMapCfg 
                              structure.
             ---      vb   4. Clean up of the patches
             ---      cp   5. Removed unpacking of the status field from
                              packing functions.
                      cp   6. Modified cntrl Req and cfg request 
                              packing/unpacking.
             ---      vb   7. Updated for Release 2.9

/main/4      ---      cp   1. Updated for Release 3.1
            sp011.28  sg   1. Added range for SLR 
            sp014.301 rc   2. Rolling upgrade changes, under compile flag
                              TDS_ROLL_UPGRADE_SUPPORT as per tcr0020.txt:
                           -  Packing and unpacking self and remote interface
                              version number and validity of remote interface 
                              version in sap status
                           -  Handling for status request for NSAP.
                           -  Filling interface version in pst structure while
                              packing request primitice to SCCP.
                           -  Packing and unpacking of debug cntrl moved under
                              element stgen.
/main/4_1    ---        rc   1. Release 3.2 implementing requirements as per:
                              - ITU 1996
                              - Q752 (ITU 1988, 1992 and 1996)
                              - ANSI 1996
                              - GR-246-CORE, Issue 5
                              - GSM 08.06 Ver 8.0.0 Release 1999
                              - Summary doc on JT-Q711 to JT-Q714 (SCCP Japan)
                              - Audit of signalling connections.
            sp001.302 rc   1. Sid correction
                           2. Support for deletion of nw, sap and nsap added in 
                              packing/unpacking of cntrl req.
            sp020.302 rc   1. Interface version bumped to LSPV2_1 to configure
                              slsMask in route configuration.
            sp028.302 rc   1. packing/unpacking numConn in GLB sts for interface
                              version LSPV2_2. Adding interface ver LSPV2_2
                              support in all packing/unpacking functions.
            sp032.302 cg   1. packing/unpacking nmbConThresh in GenCfg  req 
            sp037.302 mc   1. packing of dpc for second time removed.
                           2. reversing the order of unpacking of called and 
                              calling party address to conform to packing order.
   lsp_c_001.main_4_1 mc   1. packing/unpacking of network id for AssoCfg and 
                              AddrMapCfg for LSPV2_4 and related changes for 
                              all packing/unpacking function.
                           2. packing/unpacking of outNwId in AddressMap
                              configuration.
   lsp_c_002.main_4_1 sm   1. Added field msgInterceptEnabled in SAP config
                              structure so that SCCP can pass same cgAddr 
                              and cdAddr as received in incoming message to 
                              SCCP user for message intercepting. This flag 
                              should be turned ON only when message 
                              intercepting is desired.
                           2. Added packing and unpacking of msgIntercept 
                              statistics for class 0 and class 1.
                           3. packing and unpacking of SST and SSP 
                              transmit and receive statistics added under
                              LSPV2_5
*********************************************************************91*/
