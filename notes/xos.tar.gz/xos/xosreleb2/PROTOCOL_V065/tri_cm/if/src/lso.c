/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**
 
     Name:     LSO Interface
 
     Type:     C file
 
     Desc:     This file contains the packing/unpacking functions
               for the SIP primitives on lso interface

     File:     lso.c

     Sid:      lso.c@@/main/4 - Tue Apr 20 12:45:37 2004
 
     Prg:      cl
     
*********************************************************************21*/


/* header include files (.h) */
#include "envopt.h"        /* Environment options             */
#include "envdep.h"        /* Environment dependent options   */
#include "envind.h"        /* Environment independent options */
#include "gen.h"           /* General layer                   */
#include "ssi.h"           /* System service interface        */
#include "cm5.h"           /* Common timer library            */
#include "cm_llist.h"      /* Common linked list library      */
#include "cm_hash.h"       /* Common hash library             */
#include "cm_tpt.h"        /* Common transport library        */
#include "cm_tkns.h"       /* Common tokens                   */
#include "cm_mblk.h"       /* Common memory allocation        */
#include "cm_abnf.h"       /* Common abnf library             */
#include "cm_sdp.h"        /* Common SDP library              */
#include "cm_dns.h"        /* Common DNS library              */
#include "cm_inet.h"       /* Common socket library           */
#include "hit.h"           /* HIT interface defines           */
#include "lso.h"           /* Layer management, SIP           */
#include "sot.h"           /* SOT interface defines           */

/* header/extern include files (.x) */
#include "gen.x"           /* General layer                   */
#include "ssi.x"           /* System services interface       */
#include "cm5.x"           /* Common timer module             */
#include "cm_lib.x"        /* Common linrary function         */
#include "cm_llist.x"      /* Common link list library        */
#include "cm_hash.x"       /* Common hash list library        */
#include "cm_tpt.x"        /* Common transport library        */
#include "cm_tkns.x"       /* Common tokens                   */
#include "cm_xtree.x"      /* Common radix tree library       */
#include "cm_mblk.x"       /* Common memory allocation        */
#include "cm_abnf.x"       /* Common abnf library             */
#include "cm_sdp.x"        /* Common SDP library              */
#include "cm_dns.x"        /* Common DNS library              */
#include "cm_inet.x"       /* Common socket library           */
#include "hit.x"           /* HIT interface defines           */
#include "lso.x"           /* Layer management SIP            */
#include "sot.x"           /* SOT interface defines           */

#define CMGETMBLK(ptr, size, pptr) \
   { \
      S16 ret; \
      ret = cmGetMem( ptr, size, pptr); \
      if (ret != ROK) \
      { \
          RETVALUE(RFAILED); \
      } \
   }


#if(defined(LCLSO) || defined(LWLCLSO))

/*
*
*    Fun:    cmPkSoTknStr
*
*    Desc:    pack the structure SoTknStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTknStr
(
SoTknStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTknStr(param ,mBuf)
SoTknStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoTknStr)

    for (i=LSO_STR_SZ -1;i>=0;i--)
    {
       CMCHKPK(SPkS8, param->str[i],mBuf);
    }
    CMCHKPK(SPkU8, param->pres,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTknStr*/

/*
*
*    Fun:    cmPkSoTptSrvCfg
*
*    Desc:    pack the structure SoTptSrvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTptSrvCfg
(
SoTptSrvCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTptSrvCfg(param ,mBuf)
SoTptSrvCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoTptSrvCfg)

    /* so010.201: New parametesr added */
    CMCHKPK(cmPkTmrCfg, &param->opnSrvTmr,mBuf);
    CMCHKPK(SPkS16, param->opnSrvRetryCnt,mBuf);
    for (i=LSO_HOSTNAME_MAX_SZ -1;i>=0;i--)
    {
       CMCHKPK(SPkS8, param->hostname[i],mBuf);
    }
    CMCHKPK(cmPkCmTptParam, &param->tPar,mBuf);
    CMCHKPK(SPkU8, param->tptProt,mBuf);
    CMCHKPK(cmPkCmTptAddr, &param->tptAddr,mBuf);
    for (i=param->nmbSSap -1;i>=0;i--)
    {
       CMCHKPK(SPkS16, param->sSapLst[i],mBuf);
    }
    CMCHKPK(SPkU8, param->nmbSSap,mBuf);
    CMCHKPK(SPkU32, param->tptSrvId,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTptSrvCfg*/
#ifdef SO_DNS

/*
*
*    Fun:    cmPkSoDnsCfg
*
*    Desc:    pack the structure SoDnsCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDnsCfg
(
SoDnsCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDnsCfg(param ,mBuf)
SoDnsCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoDnsCfg)

    CMCHKPK(SPkU32, param->dnsNaptrCacheSz,mBuf);
    CMCHKPK(SPkU32, param->dnsSrvCacheSz,mBuf);
    CMCHKPK(SPkU32, param->dnsACacheSz,mBuf);
    CMCHKPK(SPkU8, param->useDnsCache,mBuf);
    CMCHKPK(SPkU8, param->useDns,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDnsCfg*/
#endif /* SO_DNS */

/*
*
*    Fun:    cmPkSoTmrReTxReCfg
*
*    Desc:    pack the structure SoTmrReTxReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTmrReTxReCfg
(
SoTmrReTxReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTmrReTxReCfg(param ,mBuf)
SoTmrReTxReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTmrReTxReCfg)

#if(  defined(  SO_NAT)  && defined(  SO_USE_UDP_SRVR) ) 
    CMCHKPK(SPkU32, param->natTmrVal,mBuf);
#endif /*    */
    CMCHKPK(SPkU32, param->t4,mBuf);
    CMCHKPK(SPkU32, param->t2,mBuf);
    CMCHKPK(SPkU32, param->t1,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTmrReTxReCfg*/
#ifdef SO_DNS

/*
*
*    Fun:    cmPkSoDnsReCfg
*
*    Desc:    pack the structure SoDnsReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDnsReCfg
(
SoDnsReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDnsReCfg(param ,mBuf)
SoDnsReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoDnsReCfg)

    CMCHKPK(SPkU32, param->maxDnsCacheExp,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->dnsQueryTmr,mBuf);
    CMCHKPK(SPkU8, param->maxDnsRetry,mBuf);
    CMCHKPK(SPkU32, param->tptSrvId,mBuf);
    CMCHKPK(cmPkCmTptParam, &param->dnsTptParam,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    CMCHKPK(cmPkCmTptAddr, &param->locAddr,mBuf);
    CMCHKPK(cmPkCmTptAddr, &param->dnsTptAddr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDnsReCfg*/
#endif /* SO_DNS */
#ifdef SO_NS
#ifdef SO_LCS

/*
*
*    Fun:    cmPkSoLocSrvCfg
*
*    Desc:    pack the structure SoLocSrvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoLocSrvCfg
(
SoLocSrvCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoLocSrvCfg(param ,mBuf)
SoLocSrvCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoLocSrvCfg)

    CMCHKPK(SPkU16, param->locSrchHlBins,mBuf);
    CMCHKPK(SPkU32, param->locCacheSz,mBuf);
    CMCHKPK(SPkU8, param->locCachePres,mBuf);
    CMCHKPK(SPkU8, param->useExtLocServices,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoLocSrvCfg*/

/*
*
*    Fun:    cmPkSoLocSrvReCfg
*
*    Desc:    pack the structure SoLocSrvReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoLocSrvReCfg
(
SoLocSrvReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoLocSrvReCfg(param ,mBuf)
SoLocSrvReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoLocSrvReCfg)

    CMCHKPK(SPkU32, param->maxLocCacheExp,mBuf);
    CMCHKPK(SPkU32, param->dfltLocCacheExp,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoLocSrvReCfg*/
#endif /* SO_LCS */
#endif /* SO_NS */

/*
*
*    Fun:    cmPkSoGenReCfg
*
*    Desc:    pack the structure SoGenReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoGenReCfg
(
SoGenReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoGenReCfg(param ,mBuf)
SoGenReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoGenReCfg)

#ifdef SO_NS
#ifdef SO_LCS
    CMCHKPK(cmPkSoLocSrvReCfg, &param->locSrvReCfg,mBuf);
#endif /*  SO_LCS  */
#endif /*  SO_NS  */
    CMCHKPK(cmPkSoTmrReTxReCfg, &param->tmrReTxCfg,mBuf);
#ifdef SO_DNS
    CMCHKPK(cmPkSoDnsReCfg, &param->dnsReCfg,mBuf);
#endif /*  SO_DNS  */
    CMCHKPK(SPkS8, param->GMToffset,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoGenReCfg*/

/*
*
*    Fun:    cmPkSoGenCfg
*
*    Desc:    pack the structure SoGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoGenCfg
(
SoGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoGenCfg(param ,mBuf)
SoGenCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoGenCfg)

    CMCHKPK(SPkU16, param->mtu,mBuf);
#ifdef SO_UA
    CMCHKPK(SPkU32, param->maxNumCnctPerEnt,mBuf);
    CMCHKPK(SPkU32, param->maxNumRegPerEnt,mBuf);
#endif /*  SO_UA  */
#ifdef SO_ABNF_MT_LIB
    CMCHKPK(SPkU8, param->nmbEDThreads,mBuf);
#endif /*  SO_ABNF_MT_LIB  */
#ifdef DEBUGP
    CMCHKPK(SPkU32, param->dbgMask,mBuf);
#endif /*  DEBUGP  */
    for (i=LSO_NODEID_SZ -1;i>=0;i--)
    {
       CMCHKPK(SPkU8, param->nodeIdStr[i],mBuf);
    }
    CMCHKPK(cmPkPst, &param->compPst,mBuf);
    CMCHKPK(cmPkPst, &param->lmPst,mBuf);
#ifdef SO_NS
#ifdef SO_LCS
    CMCHKPK(cmPkSoLocSrvCfg, &param->locSrvCfg,mBuf);
#endif /*  SO_LCS  */
#endif /*  SO_NS  */
#ifdef SO_DNS
    CMCHKPK(cmPkSoDnsCfg, &param->dnsCfg,mBuf);
#endif /*  SO_DNS  */
    CMCHKPK(SPkU32, param->remRegSz,mBuf);
    CMCHKPK(SPkU32, param->locRegSz,mBuf);
    CMCHKPK(SPkU32, param->sdpBlkSize,mBuf);
    CMCHKPK(SPkU32, param->maxBlkSize,mBuf);
    CMCHKPK(SPkU32, param->maxPendLocReq,mBuf);
    CMCHKPK(SPkS16, param->resThreshLower,mBuf);
    CMCHKPK(SPkS16, param->resThreshUpper,mBuf);
    CMCHKPK(SPkU32, param->maxTransPerEnt,mBuf);
    CMCHKPK(SPkU32, param->maxNmbActCalls,mBuf);
    CMCHKPK(SPkU8, param->maxNmbRemReg,mBuf);
    CMCHKPK(SPkU8, param->maxNmbNS,mBuf);
    CMCHKPK(SPkU8, param->maxNmbUA,mBuf);
    CMCHKPK(SPkS16, param->maxNmbTSaps,mBuf);
    CMCHKPK(SPkS16, param->maxNmbSSaps,mBuf);
    for (i=LSO_PROTVER_SZ -1;i>=0;i--)
    {
       CMCHKPK(SPkS8, param->protVer[i],mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoGenCfg*/

/*
*
*    Fun:    cmPkSoTSapReCfg
*
*    Desc:    pack the structure SoTSapReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTSapReCfg
(
SoTSapReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTSapReCfg(param ,mBuf)
SoTSapReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTSapReCfg)

    CMCHKPK(cmPkTmrCfg, &param->bndTmCfg,mBuf);
    CMCHKPK(SPkU8, param->maxBndRetry,mBuf);
    CMCHKPK(cmPkCmTptParam, &param->tPar,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTSapReCfg*/

/*
*
*    Fun:    cmPkSoTSapCfg
*
*    Desc:    pack the structure SoTSapCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTSapCfg
(
SoTSapCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTSapCfg(param ,mBuf)
SoTSapCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTSapCfg)

    CMCHKPK(SPkU16, param->tptAddrHlBins,mBuf);
    CMCHKPK(SPkU16, param->suConIdHlBins,mBuf);
    CMCHKPK(SPkU8, param->dstSel,mBuf);
    CMCHKPK(SPkU8, param->dstRoute,mBuf);
    CMCHKPK(SPkU8, param->dstPrior,mBuf);
    CMCHKPK(SPkU8, param->dstInst,mBuf);
    CMCHKPK(SPkU8, param->dstEnt,mBuf);
    CMCHKPK(SPkU16, param->dstProcId,mBuf);
    CMCHKPK(cmPkMemoryId, &param->memId,mBuf);
    CMCHKPK(SPkS16, param->spId,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTSapCfg*/

/*
*
*    Fun:    cmPkSoTptSrvLstCfg
*
*    Desc:    pack the structure SoTptSrvLstCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTptSrvLstCfg
(
SoTptSrvLstCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTptSrvLstCfg(param ,mBuf)
SoTptSrvLstCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoTptSrvLstCfg)

    for (i=param->nmbTptSrv -1;i>=0;i--)
    {
       CMCHKPK(cmPkSoTptSrvCfg, &param->tptSrvCfg[i], mBuf);
    }
    CMCHKPK(SPkU32, param->nmbTptSrv,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTptSrvLstCfg*/

/*
*
*    Fun:    cmPkSoDfltPrxCfg
*
*    Desc:    pack the structure SoDfltPrxCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDfltPrxCfg
(
SoDfltPrxCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDfltPrxCfg(param ,mBuf)
SoDfltPrxCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoDfltPrxCfg)

    switch( param->choice )
    {
       case  LSO_DFLT_PRX_DOMAIN_NAME :
          for (i=LSO_HOSTNAME_MAX_SZ -1;i>=0;i--)
          {
             CMCHKPK(SPkS8, param->t.domainName[i],mBuf);
          }
          break;
       case  LSO_DFLT_PRX_NONE :
          break;
       case  LSO_DFLT_PRX_TPT_ADDR :
          CMCHKPK(cmPkCmTptAddr, &param->t.dfltPrxAddr,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU8, param->choice,mBuf);
#ifdef SO_COMPRESS
    CMCHKPK(SPkU8, param->sigCompSupp,mBuf);
#endif /*  SO_COMPRESS  */
    CMCHKPK(SPkU8, param->looseRouter,mBuf);
    CMCHKPK(SPkU8, param->rcvDfltPrxOnly,mBuf);
    CMCHKPK(SPkU8, param->useDfltPrx,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDfltPrxCfg*/

/*
*
*    Fun:    cmPkSoUAReCfg
*
*    Desc:    pack the structure SoUAReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUAReCfg
(
SoUAReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUAReCfg(param ,mBuf)
SoUAReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUAReCfg)

    CMCHKPK(cmPkSoTknStr, &param->insServer,mBuf);
    CMCHKPK(cmPkSoTknStr, &param->insUserAgent,mBuf);
    /* so007.201 : Added code for packing of new parameter */
    /* lso_c_001.main_4 :Added code to reject for all the requests
     (invites & non-invites) */
#ifdef SO_REJECT_ON_UA_RESTART
    CMCHKPK(SPkU8, param->rejOnUARestart,mBuf);
#endif /*  SO_REJECT_ON_UA_RESTART */
#ifdef SO_REJECT_REINV_ON_UA_RESTART
    CMCHKPK(SPkU8, param->rejReInvOnUARestart,mBuf);
#endif /*  SO_REJECT_REINV_ON_UA_RESTART */
#ifdef SO_COMPRESS
    CMCHKPK(SPkU8, param->sigCompSupp,mBuf);
#endif /*  SO_COMPRESS  */
    CMCHKPK(SPkU8, param->relProvRspSupp,mBuf);
    CMCHKPK(SPkU8, param->relProvRspReq,mBuf);
    CMCHKPK(SPkU8, param->useIpContact,mBuf);
    CMCHKPK(SPkU8, param->addContact,mBuf);
    CMCHKPK(cmPkCmTptAddr, &param->regSrvAddr,mBuf);
    CMCHKPK(SPkU8, param->insTmStamp,mBuf);
    CMCHKPK(cmPkSoDfltPrxCfg, &param->dfltPrxCfg,mBuf);
    CMCHKPK(SPkU8, param->chkLocUsrReg,mBuf);
    CMCHKPK(SPkU8, param->refreshOnExp,mBuf);
    CMCHKPK(SPkU8, param->alertUsrOnExp,mBuf);
    CMCHKPK(SPkU32, param->dfltExpiresInInvite,mBuf);
    CMCHKPK(SPkU32, param->dfltExpiresInRegister,mBuf);
    CMCHKPK(SPkU8, param->alw3rdParty,mBuf);
    CMCHKPK(SPkU32, param->threshLower,mBuf);
    CMCHKPK(SPkU32, param->threshUpper,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUAReCfg*/

/*
*
*    Fun:    cmPkSoUACfg
*
*    Desc:    pack the structure SoUACfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUACfg
(
SoUACfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUACfg(param ,mBuf)
SoUACfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUACfg)

    CMCHKPK(SPkU16, param->serverTransHlBins,mBuf);
    CMCHKPK(SPkU16, param->clientTransHlBins,mBuf);
    CMCHKPK(SPkU16, param->regHlBins,mBuf);
    CMCHKPK(SPkU16, param->regContactHlBins,mBuf);
    CMCHKPK(SPkU16, param->regAddrHlBins,mBuf);
    CMCHKPK(SPkU16, param->callHdlHlBins,mBuf);
    CMCHKPK(SPkU16, param->callIdHlBins,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUACfg*/

/*
*
*    Fun:    cmPkSoNSCfg
*
*    Desc:    pack the structure SoNSCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNSCfg
(
SoNSCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNSCfg(param ,mBuf)
SoNSCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoNSCfg)

    CMCHKPK(SPkU8, param->pathRoute,mBuf);
    CMCHKPK(SPkS16, param->remRegSapId,mBuf);
    CMCHKPK(SPkU8, param->remRegLoc,mBuf);
    CMCHKPK(SPkU8, param->regSrvLoc,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNSCfg*/

/*
*
*    Fun:    cmPkSoProxyReCfg
*
*    Desc:    pack the structure SoProxyReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoProxyReCfg
(
SoProxyReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoProxyReCfg(param ,mBuf)
SoProxyReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoProxyReCfg)

    CMCHKPK(SPkU8, param->useIpRecRoute,mBuf);
    CMCHKPK(SPkU8, param->recordRoute,mBuf);
    CMCHKPK(SPkU8, param->prxState,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoProxyReCfg*/

/*
*
*    Fun:    cmPkSoNSReCfg
*
*    Desc:    pack the structure SoNSReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNSReCfg
(
SoNSReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNSReCfg(param ,mBuf)
SoNSReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoNSReCfg)

    CMCHKPK(cmPkSoProxyReCfg, &param->proxyReCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNSReCfg*/

/*
*
*    Fun:    cmPkSoHdrCfg
*
*    Desc:    pack the structure SoHdrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoHdrCfg
(
SoHdrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoHdrCfg(param ,mBuf)
SoHdrCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoHdrCfg)

    CMCHKPK(cmPkSoTknStr, &param->insSubject,mBuf);
    CMCHKPK(cmPkSoTknStr, &param->insOrg,mBuf);
    CMCHKPK(SPkU16, param->maxFwd,mBuf);
    CMCHKPK(SPkU8, param->insAccept,mBuf);
    CMCHKPK(SPkU8, param->insSupported,mBuf);
    CMCHKPK(SPkU8, param->insUAHdr,mBuf);
    CMCHKPK(SPkU8, param->insExpires,mBuf);
    CMCHKPK(SPkU8, param->insAllow,mBuf);
    CMCHKPK(SPkU8, param->insDate,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoHdrCfg*/

/*
*
*    Fun:    cmPkSoEntReCfg
*
*    Desc:    pack the structure SoEntReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEntReCfg
(
SoEntReCfg *param,
U16 entType,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEntReCfg(param ,entType, mBuf)
SoEntReCfg *param;
U16 entType;
Buffer *mBuf;
#endif
{
#ifdef SO_EVENT
    Cntr i;
#endif
    TRC3(cmPkSoEntReCfg)

    switch( entType )
    {
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKPK(cmPkSoNSReCfg, &param->e.nsReCfg,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKPK(cmPkSoUAReCfg, &param->e.uaReCfg,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
#ifdef SO_EVENT
    CMCHKPK(SPkU8, param->alertUsrOnEvntExp,mBuf);
    CMCHKPK(SPkU32, param->evntPkgExpires,mBuf);
    for (i=param->nmbNonStdEvntPkg -1;i>=0;i--)
    {
       CMCHKPK(cmPkSoTknStr, &param->supportedNonStdEvntPkg[i], mBuf);
    }
    CMCHKPK(SPkU8, param->nmbNonStdEvntPkg,mBuf);
    for (i=param->nmbStdEvntPkg -1;i>=0;i--)
    {
       CMCHKPK(cmPkSoTknStr, &param->supportedStdEvntPkg[i], mBuf);
    }
    CMCHKPK(SPkU8, param->nmbStdEvntPkg,mBuf);
#endif /*  SO_EVENT  */
#ifdef SO_SESSTIMER
    CMCHKPK(SPkU32, param->minSe,mBuf);
    CMCHKPK(SPkU32, param->sessTmrVal,mBuf);
    CMCHKPK(SPkU8, param->useSessTmr,mBuf);
#endif /*  SO_SESSTIMER  */
#ifdef SO_NS
    CMCHKPK(SPkS16, param->locSrvSapId,mBuf);
#endif /*  SO_NS  */
#ifdef SO_TLS
    CMCHKPK(SPkU32, param->tlsInActvTmr,mBuf);
#endif /*  SO_TLS  */
    CMCHKPK(SPkU32, param->tptInActvTmr,mBuf);
    CMCHKPK(SPkU8, param->decodeSDP,mBuf);
    CMCHKPK(SPkU8, param->alwRecurse,mBuf);
    CMCHKPK(SPkU8, param->useCompact,mBuf);
    CMCHKPK(SPkU8, param->snd100Always,mBuf);
    CMCHKPK(cmPkSoHdrCfg, &param->hdrCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEntReCfg*/

/*
*
*    Fun:    cmPkSoEntCfg
*
*    Desc:    pack the structure SoEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEntCfg
(
SoEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEntCfg(param ,mBuf)
SoEntCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoEntCfg)

#ifdef DEBUGP
    CMCHKPK(SPkU32, param->dbgMask,mBuf);
#endif /*  DEBUGP  */
#if(  defined(  SO_NAT)  && defined(  SO_USE_UDP_SRVR) ) 
    CMCHKPK(SPkU8, param->addRportByDflt,mBuf);
#endif /*    */
    CMCHKPK(cmPkSoTptSrvLstCfg, &param->tptSrvLstCfg,mBuf);
    for (i=LSO_HOSTNAME_MAX_SZ -1;i>=0;i--)
    {
       CMCHKPK(SPkS8, param->domainName[i],mBuf);
    }
    switch( param->type )
    {
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKPK(cmPkSoNSCfg, &param->e.nsCfg,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKPK(cmPkSoUACfg, &param->e.uaCfg,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU8, param->type,mBuf);
    CMCHKPK(SPkU8, param->entId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEntCfg*/

/*
*
*    Fun:    cmPkSoSSapCfg
*
*    Desc:    pack the structure SoSSapCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSSapCfg
(
SoSSapCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSSapCfg(param ,mBuf)
SoSSapCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSSapCfg)

    /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
    CMCHKPK(SPkS16, param->tlsCtxId,mBuf);
#endif
    CMCHKPK(SPkU16, param->numTransHlBins,mBuf);
    CMCHKPK(SPkU16, param->numCLegHlBins,mBuf);
    CMCHKPK(SPkU8, param->entId,mBuf);
    CMCHKPK(SPkU8, param->route,mBuf);
    CMCHKPK(SPkU8, param->prior,mBuf);
    CMCHKPK(cmPkMemoryId, &param->memId,mBuf);
    CMCHKPK(SPkU8, param->sel,mBuf);
    CMCHKPK(SPkS16, param->sSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSSapCfg*/

/*
*
*    Fun:    cmPkSoCfg
*
*    Desc:    pack the structure SoCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCfg
(
SoCfg *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCfg(param ,elmnt, mBuf)
SoCfg *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoCfg)

    switch( elmnt )
    {
       case  STGEN :
          CMCHKPK(cmPkSoGenReCfg, &param->r.genReCfg,mBuf);
          break;
       case  STSIPENT :
          ret1 = cmPkSoEntReCfg(&param->r.entReCfg, param->c.entCfg.type ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  STTSAP :
          CMCHKPK(cmPkSoTSapReCfg, &param->r.tSapReCfg,mBuf);
          break;
       default:
          break;
    }
    switch( elmnt )
    {
       case  STGEN :
          CMCHKPK(cmPkSoGenCfg, &param->c.genCfg,mBuf);
          break;
       case  STSIPENT :
          CMCHKPK(cmPkSoEntCfg, &param->c.entCfg,mBuf);
          break;
       case  STSSAP :
          CMCHKPK(cmPkSoSSapCfg, &param->c.sSapCfg,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkSoTSapCfg, &param->c.tSapCfg,mBuf);
          break;
       default:
          break;
    }
    RETVALUE(ROK);
} /*end of function cmPkSoCfg*/

/*
*
*    Fun:    cmPkSoTSapSts
*
*    Desc:    pack the structure SoTSapSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTSapSts
(
SoTSapSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTSapSts(param ,mBuf)
SoTSapSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTSapSts)

    CMCHKPK(SPkU32, param->bytesRx,mBuf);
    CMCHKPK(SPkU32, param->bytesTx,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTSapSts*/

/*
*
*    Fun:    cmPkSoSSapSts
*
*    Desc:    pack the structure SoSSapSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSSapSts
(
SoSSapSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSSapSts(param ,mBuf)
SoSSapSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSSapSts)

    CMCHKPK(SPkU32, param->numRegReq,mBuf);
    CMCHKPK(SPkU32, param->numLocReq,mBuf);
    CMCHKPK(SPkU32, param->callsRx,mBuf);
    CMCHKPK(SPkU32, param->callsTx,mBuf);
    CMCHKPK(SPkS16, param->sSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSSapSts*/

/*
*
*    Fun:    cmPkSoSummSts
*
*    Desc:    pack the structure SoSummSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSummSts
(
SoSummSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSummSts(param ,mBuf)
SoSummSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSummSts)

    CMCHKPK(SPkU32, param->sumOutResp,mBuf);
    CMCHKPK(SPkU32, param->sumInResp,mBuf);
    CMCHKPK(SPkU32, param->sumOutReq,mBuf);
    CMCHKPK(SPkU32, param->sumInReq,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSummSts*/

/*
*
*    Fun:    cmPkSoMethSts
*
*    Desc:    pack the structure SoMethSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMethSts
(
SoMethSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMethSts(param ,mBuf)
SoMethSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoMethSts)

#ifdef SO_REFER
    CMCHKPK(SPkU32, param->methOutRefer,mBuf);
    CMCHKPK(SPkU32, param->methInRefer,mBuf);
#endif /*  SO_REFER  */
#ifdef SO_INSTMSG
    CMCHKPK(SPkU32, param->methInMessage,mBuf);
    CMCHKPK(SPkU32, param->methOutMessage,mBuf);
#endif /*  SO_INSTMSG  */
#ifdef SO_EVENT
    CMCHKPK(SPkU32, param->methInNotify,mBuf);
    CMCHKPK(SPkU32, param->methOutNotify,mBuf);
    CMCHKPK(SPkU32, param->methInSubsc,mBuf);
    CMCHKPK(SPkU32, param->methOutSubsc,mBuf);
#endif /*  SO_EVENT  */
#ifdef SO_UPDATE
    CMCHKPK(SPkU32, param->methInUpdate,mBuf);
    CMCHKPK(SPkU32, param->methOutUpdate,mBuf);
#endif /*  SO_UPDATE  */
    CMCHKPK(SPkU32, param->methInPrack,mBuf);
    CMCHKPK(SPkU32, param->methOutPrack,mBuf);
    CMCHKPK(SPkU32, param->methOutInfo,mBuf);
    CMCHKPK(SPkU32, param->methInInfo,mBuf);
    CMCHKPK(SPkU32, param->methOutReg,mBuf);
    CMCHKPK(SPkU32, param->methInReg,mBuf);
    CMCHKPK(SPkU32, param->methOutOpt,mBuf);
    CMCHKPK(SPkU32, param->methInOpt,mBuf);
    CMCHKPK(SPkU32, param->methOutCanc,mBuf);
    CMCHKPK(SPkU32, param->methInCanc,mBuf);
    CMCHKPK(SPkU32, param->methOutBye,mBuf);
    CMCHKPK(SPkU32, param->methInBye,mBuf);
    CMCHKPK(SPkU32, param->methOutAck,mBuf);
    CMCHKPK(SPkU32, param->methInAck,mBuf);
    CMCHKPK(SPkU32, param->methOutInv,mBuf);
    CMCHKPK(SPkU32, param->methInInv,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMethSts*/

/*
*
*    Fun:    cmPkSoRespSts
*
*    Desc:    pack the structure SoRespSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRespSts
(
SoRespSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRespSts(param ,mBuf)
SoRespSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoRespSts)

    CMCHKPK(SPkU32, param->globalFailClassOut,mBuf);
    CMCHKPK(SPkU32, param->globalFailClassIn,mBuf);
    CMCHKPK(SPkU32, param->srvFailClassOut,mBuf);
    CMCHKPK(SPkU32, param->srvFailClassIn,mBuf);
    CMCHKPK(SPkU32, param->reqFailClassOut,mBuf);
    CMCHKPK(SPkU32, param->reqFailClassIn,mBuf);
    CMCHKPK(SPkU32, param->redirClassOut,mBuf);
    CMCHKPK(SPkU32, param->redirClassIn,mBuf);
    CMCHKPK(SPkU32, param->successClassOut,mBuf);
    CMCHKPK(SPkU32, param->successClassIn,mBuf);
    CMCHKPK(SPkU32, param->infoClassOut,mBuf);
    CMCHKPK(SPkU32, param->infoClassIn,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRespSts*/

/*
*
*    Fun:    cmPkSoCacheSts
*
*    Desc:    pack the structure SoCacheSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCacheSts
(
SoCacheSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCacheSts(param ,mBuf)
SoCacheSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoCacheSts)

    CMCHKPK(SPkU32, param->peakMemUsage,mBuf);
    CMCHKPK(SPkU32, param->peakNmbEntries,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCacheSts*/

/*
*
*    Fun:    cmPkSoErrSts
*
*    Desc:    pack the structure SoErrSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoErrSts
(
SoErrSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoErrSts(param ,mBuf)
SoErrSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoErrSts)

    CMCHKPK(SPkU32, param->sipEncFail,mBuf);
    CMCHKPK(SPkU32, param->sipDecFail,mBuf);
    CMCHKPK(SPkU32, param->sdpDecFail,mBuf);
    CMCHKPK(SPkU32, param->missingMandHdr,mBuf);
    CMCHKPK(SPkU32, param->invalidReq,mBuf);
    CMCHKPK(SPkU32, param->invalidRsp,mBuf);
    CMCHKPK(SPkU32, param->usrUnavail,mBuf);
    CMCHKPK(SPkU32, param->unkwnUser,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoErrSts*/

/*
*
*    Fun:    cmPkSoOtherSts
*
*    Desc:    pack the structure SoOtherSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoOtherSts
(
SoOtherSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoOtherSts(param ,mBuf)
SoOtherSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoOtherSts)

    CMCHKPK(SPkU32, param->tranTO,mBuf);
    CMCHKPK(SPkU32, param->reTxReq,mBuf);
    CMCHKPK(SPkU32, param->regTO,mBuf);
    CMCHKPK(SPkU32, param->nmbUnsupUri,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoOtherSts*/
#ifdef SO_DNS

/*
*
*    Fun:    cmPkSoDnsSts
*
*    Desc:    pack the structure SoDnsSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDnsSts
(
SoDnsSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDnsSts(param ,mBuf)
SoDnsSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoDnsSts)

    CMCHKPK(cmPkSoCacheSts, &param->dnsNaptrCache,mBuf);
    CMCHKPK(cmPkSoCacheSts, &param->dnsSrvCache,mBuf);
    CMCHKPK(cmPkSoCacheSts, &param->dnsACache,mBuf);
    CMCHKPK(SPkU32, param->nmbDnsQueryTO,mBuf);
    CMCHKPK(SPkU32, param->nmbDnsRspFail,mBuf);
    CMCHKPK(SPkU32, param->nmbDnsRspSuccess,mBuf);
    CMCHKPK(SPkU32, param->nmbDnsQueryTx,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDnsSts*/
#endif /* SO_DNS */

/*
*
*    Fun:    cmPkSoGenSts
*
*    Desc:    pack the structure SoGenSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoGenSts
(
SoGenSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoGenSts(param ,mBuf)
SoGenSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoGenSts)

    CMCHKPK(cmPkSoCacheSts, &param->mCastCache,mBuf);
#ifdef SO_LCS
    CMCHKPK(cmPkSoCacheSts, &param->locSrvCache,mBuf);
#endif /*  SO_LCS  */
    CMCHKPK(cmPkSoOtherSts, &param->otherSts,mBuf);
    CMCHKPK(cmPkSoErrSts, &param->errSts,mBuf);
    CMCHKPK(cmPkSoRespSts, &param->respSts,mBuf);
    CMCHKPK(cmPkSoMethSts, &param->methSts,mBuf);
    CMCHKPK(cmPkSoSummSts, &param->summSts,mBuf);
#ifdef SO_DNS
    CMCHKPK(cmPkSoDnsSts, &param->dnsSts,mBuf);
#endif /*  SO_DNS  */
    RETVALUE(ROK);
} /*end of function cmPkSoGenSts*/

/*
*
*    Fun:    cmPkSoUASts
*
*    Desc:    pack the structure SoUASts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUASts
(
SoUASts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUASts(param ,mBuf)
SoUASts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUASts)

    CMCHKPK(SPkU32, param->peakMemUsage,mBuf);
    CMCHKPK(SPkU32, param->peakNmbEntries,mBuf);
    CMCHKPK(SPkU32, param->rspRetries,mBuf);
    CMCHKPK(SPkU32, param->reqRetries,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUASts*/

/*
*
*    Fun:    cmPkSoNSSts
*
*    Desc:    pack the structure SoNSSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNSSts
(
SoNSSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNSSts(param ,mBuf)
SoNSSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoNSSts)

    CMCHKPK(SPkU32, param->peakMemUsage,mBuf);
    CMCHKPK(SPkU32, param->peakNmbEntries,mBuf);
    CMCHKPK(SPkU32, param->nmbPrxReqFail,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNSSts*/

/*
*
*    Fun:    cmPkSoEntSts
*
*    Desc:    pack the structure SoEntSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEntSts
(
SoEntSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEntSts(param ,mBuf)
SoEntSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoEntSts)

    switch( param->stsType )
    {
#ifdef SO_NS
       case  LSO_STS_NS :
          CMCHKPK(cmPkSoNSSts, &param->t.nsSts,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_STS_UA :
          CMCHKPK(cmPkSoUASts, &param->t.uaSts,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          break;
    }
    CMCHKPK(cmPkSoOtherSts, &param->otherSts,mBuf);
    CMCHKPK(cmPkSoErrSts, &param->errSts,mBuf);
    CMCHKPK(cmPkSoRespSts, &param->respSts,mBuf);
    CMCHKPK(cmPkSoMethSts, &param->methSts,mBuf);
    CMCHKPK(cmPkSoSummSts, &param->summSts,mBuf);
    CMCHKPK(SPkU8, param->stsType,mBuf);
    CMCHKPK(SPkU8, param->entId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEntSts*/

/*
*
*    Fun:    cmPkSoSts
*
*    Desc:    pack the structure SoSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSts
(
SoSts *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSts(param ,elmnt, mBuf)
SoSts *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSts)

    switch( elmnt )
    {
       case  STGEN :
          CMCHKPK(cmPkSoGenSts, &param->s.genSts,mBuf);
          break;
       case  STSIPENT :
          CMCHKPK(cmPkSoEntSts, &param->s.entSts,mBuf);
          break;
       case  STSSAP :
          CMCHKPK(cmPkSoSSapSts, &param->s.sSapSts,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkSoTSapSts, &param->s.tSapSts,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkS16, param->action,mBuf);
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSts*/

/*
*
*    Fun:    cmPkSoUASta
*
*    Desc:    pack the structure SoUASta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUASta
(
SoUASta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUASta(param ,mBuf)
SoUASta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUASta)

    CMCHKPK(SPkU8, param->regWarnState,mBuf);
    CMCHKPK(SPkU32, param->locRegEntries,mBuf);
    CMCHKPK(SPkU32, param->locRegSz,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUASta*/

/*
*
*    Fun:    cmPkSoRemRegSta
*
*    Desc:    pack the structure SoRemRegSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRemRegSta
(
SoRemRegSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRemRegSta(param ,mBuf)
SoRemRegSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoRemRegSta)

    CMCHKPK(SPkU8, param->regWarnState,mBuf);
    CMCHKPK(SPkU32, param->remRegEntries,mBuf);
    CMCHKPK(SPkU32, param->remRegSz,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRemRegSta*/

/*
*
*    Fun:    cmPkSoNSSta
*
*    Desc:    pack the structure SoNSSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoNSSta
(
SoNSSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoNSSta(param ,mBuf)
SoNSSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoNSSta)

    CMCHKPK(cmPkSoRemRegSta, &param->remRegSta,mBuf);
    CMCHKPK(SPkU8, param->prxState,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoNSSta*/

/*
*
*    Fun:    cmPkSoEntSta
*
*    Desc:    pack the structure SoEntSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoEntSta
(
SoEntSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoEntSta(param ,mBuf)
SoEntSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoEntSta)

    switch( param->type )
    {
       case  LSO_ENT_NONE :
          break;
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKPK(cmPkSoNSSta, &param->t.nsSta,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKPK(cmPkSoUASta, &param->t.uaSta,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU32, param->totNmbTrans,mBuf);
    CMCHKPK(SPkU32, param->totNmbCLegs,mBuf);
    CMCHKPK(SPkU32, param->nmbActCalls,mBuf);
    CMCHKPK(SPkU32, param->strtTm,mBuf);
    CMCHKPK(SPkU8, param->lmState,mBuf);
    CMCHKPK(SPkU8, param->operState,mBuf);
    CMCHKPK(SPkU8, param->type,mBuf);
    CMCHKPK(SPkU8, param->entId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoEntSta*/

/*
*
*    Fun:    cmPkSoGenSta
*
*    Desc:    pack the structure SoGenSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoGenSta
(
SoGenSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoGenSta(param ,mBuf)
SoGenSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoGenSta)

    CMCHKPK(SPkU32, param->mCastCacheEntries,mBuf);
#ifdef SO_LCS
    CMCHKPK(SPkU32, param->locSrvCacheEntries,mBuf);
#endif /*  SO_LCS  */
#ifdef SO_DNS
    CMCHKPK(SPkU32, param->dnsNaptrCacheEntries,mBuf);
    CMCHKPK(SPkU32, param->dnsSrvCacheEntries,mBuf);
    CMCHKPK(SPkU32, param->dnsACacheEntries,mBuf);
#endif /*  SO_DNS  */
    CMCHKPK(SPkU32, param->mCastCacheSz,mBuf);
#ifdef SO_LCS
    CMCHKPK(SPkU32, param->locCacheSz,mBuf);
#endif /*  SO_LCS  */
#ifdef SO_DNS
    CMCHKPK(SPkU32, param->dnsNaptrCacheSz,mBuf);
    CMCHKPK(SPkU32, param->dnsSrvCacheSz,mBuf);
    CMCHKPK(SPkU32, param->dnsACacheSz,mBuf);
#endif /*  SO_DNS  */
    CMCHKPK(SPkU8, param->resCong,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoGenSta*/

/*
*
*    Fun:    cmPkSoTSapSta
*
*    Desc:    pack the structure SoTSapSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTSapSta
(
SoTSapSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTSapSta(param ,mBuf)
SoTSapSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTSapSta)

    CMCHKPK(SPkS16, param->state,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTSapSta*/

/*
*
*    Fun:    cmPkSoSSapSta
*
*    Desc:    pack the structure SoSSapSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSSapSta
(
SoSSapSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSSapSta(param ,mBuf)
SoSSapSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSSapSta)

    CMCHKPK(SPkS16, param->state,mBuf);
    CMCHKPK(SPkS16, param->sSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSSapSta*/

/*
*
*    Fun:    cmPkSoTptSrvSta
*
*    Desc:    pack the structure SoTptSrvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTptSrvSta
(
SoTptSrvSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTptSrvSta(param ,mBuf)
SoTptSrvSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTptSrvSta)

    CMCHKPK(SPkS16, param->state,mBuf);
    CMCHKPK(SPkU32, param->tptSrvId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTptSrvSta*/

/*
*
*    Fun:    cmPkSoSsta
*
*    Desc:    pack the structure SoSsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSsta
(
SoSsta *param,
U16 elmnt,
/* so009.201 : Fix for packing/unpacking system id */
U8  evnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSsta(param ,elmnt, evnt, mBuf)
SoSsta *param;
U16 elmnt;
/* so009.201 : Fix for packing/unpacking system id */
U8  evnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoSsta)

    switch( elmnt )
    {
       case  STGEN :
          CMCHKPK(cmPkSoGenSta, &param->s.genSta,mBuf);
          break;
       case  STSID :
          /* so009.201 : Fix for packing/unpacking system id */
          if (evnt == EVTLSOSTACFM)
          {
            CMCHKPK(cmPkSystemId, &param->s.sysId,mBuf);
          }
          break;
       case  STSIPENT :
          CMCHKPK(cmPkSoEntSta, &param->s.entSta,mBuf);
          break;
       case  STSSAP :
          CMCHKPK(cmPkSoSSapSta, &param->s.sSapSta,mBuf);
          break;
       case  STTPTSRV :
          CMCHKPK(cmPkSoTptSrvSta, &param->s.tptSrvSta,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkSoTSapSta, &param->s.tSapSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSsta*/

/*
*
*    Fun:    cmPkSoRegInf
*
*    Desc:    pack the structure SoRegInf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoRegInf
(
SoRegInf *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoRegInf(param ,mBuf)
SoRegInf *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoRegInf)

    CMCHKPK(SPkU8, param->entId,mBuf);
    CMCHKPK(SPkU8, param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoRegInf*/

/*
*
*    Fun:    cmPkSoAlarmInfo
*
*    Desc:    pack the structure SoAlarmInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAlarmInfo
(
SoAlarmInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAlarmInfo(param ,mBuf)
SoAlarmInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoAlarmInfo)

    switch( param->alarmType )
    {
       case  LSO_PAR_CHOICE :
          CMCHKPK(SPkU32, param->v.val,mBuf);
          break;
       case  LSO_PAR_CONNID :
          CMCHKPK(SPkU32, param->v.connId,mBuf);
          break;
       case  LSO_PAR_ENT :
          CMCHKPK(SPkU8, param->v.entId,mBuf);
          break;
       case  LSO_PAR_MEM :
          CMCHKPK(cmPkMemoryId, &param->v.mem,mBuf);
          break;
       case  LSO_PAR_NONE :
          break;
       case  LSO_PAR_REASON :
          CMCHKPK(SPkU32, param->v.val,mBuf);
          break;
       case  LSO_PAR_REG :
          CMCHKPK(cmPkSoRegInf, &param->v.reg,mBuf);
          break;
       case  LSO_PAR_SAP :
          CMCHKPK(SPkS16, param->v.sapId,mBuf);
          break;
       case  LSO_PAR_STATUS :
          CMCHKPK(SPkU32, param->v.val,mBuf);
          break;
       case  LSO_PAR_TPTADDR :
          CMCHKPK(cmPkCmTptAddr, &param->v.tptAddr,mBuf);
          break;
       case  LSO_PAR_TPTPARM :
          CMCHKPK(cmPkCmTptParam, &param->v.tptParm,mBuf);
          break;
       case  LSO_PAR_TPTSRV :
          CMCHKPK(SPkU32, param->v.tptSrvId,mBuf);
          break;
       case  LSO_PAR_VAL :
          CMCHKPK(SPkU32, param->v.val,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkU8, param->alarmType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAlarmInfo*/

/*
*
*    Fun:    cmPkSoUsta
*
*    Desc:    pack the structure SoUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoUsta
(
SoUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoUsta(param ,mBuf)
SoUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoUsta)

    CMCHKPK(cmPkSoAlarmInfo, &param->alarmInfo,mBuf);
    CMCHKPK(cmPkCmAlarm, &param->alarm,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoUsta*/
#ifdef LSO_ACNT

/*
*
*    Fun:    cmPkSoAcntInfo
*
*    Desc:    pack the structure SoAcntInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcntInfo
(
SoAcntInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcntInfo(param ,mBuf)
SoAcntInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoAcntInfo)

    /* lso_c_001.main_4 : modified legId of SoAcntInfo to U32 */
    CMCHKPK(SPkU32, param->legId,mBuf);
    CMCHKPK(SPkU8, param->sdpMedia,mBuf);
    CMCHKPK(SPkU8, param->mediaType,mBuf);
    CMCHKPK(cmPkDuration, &param->duration,mBuf);
    CMCHKPK(cmPkTknStrOSXL, &param->localAddr,mBuf);
    CMCHKPK(cmPkTknStrOSXL, &param->remoteAddr,mBuf);
    CMCHKPK(SPkU8, param->origin,mBuf);
    CMCHKPK(SPkU8, param->type,mBuf);
    CMCHKPK(SPkU32, param->spconnId,mBuf);
    CMCHKPK(SPkU8, param->entId,mBuf);
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcntInfo*/

/*
*
*    Fun:    cmPkSoAcnt
*
*    Desc:    pack the structure SoAcnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoAcnt
(
SoAcnt *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoAcnt(param ,mBuf)
SoAcnt *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoAcnt)

    ret1 = cmPkSoAcntInfo(&param->acntInfo,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoAcnt*/
#endif

/*
*
*    Fun:    cmPkSoTrc
*
*    Desc:    pack the structure SoTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTrc
(
SoTrc *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTrc(param ,elmnt, mBuf)
SoTrc *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTrc)

    CMCHKPK(SPkU16, param->evnt,mBuf);
    switch( elmnt )
    {
       case  STSIPENT :
          CMCHKPK(SPkU8, param->t.entId,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(SPkS16, param->t.tSapId,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTrc*/

/*
*
*    Fun:    cmPkSoDbgCntrl
*
*    Desc:    pack the structure SoDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoDbgCntrl
(
SoDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoDbgCntrl(param ,mBuf)
SoDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoDbgCntrl)

    CMCHKPK(SPkU32, param->entDbgMask,mBuf);
    CMCHKPK(SPkS16, param->entId,mBuf);
    CMCHKPK(SPkU32, param->genDbgMask,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoDbgCntrl*/

/*
*
*    Fun:    cmPkSoTrcCntrl
*
*    Desc:    pack the structure SoTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTrcCntrl
(
SoTrcCntrl *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTrcCntrl(param ,elmnt, mBuf)
SoTrcCntrl *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTrcCntrl)

    CMCHKPK(SPkU32, param->trcMask,mBuf);
    CMCHKPK(SPkS16, param->trcLen,mBuf);
    switch( elmnt )
    {
       case  STSIPENT :
          CMCHKPK(SPkU8, param->t.entId,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(SPkS16, param->t.tSapId,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmPkSoTrcCntrl*/

/*
*
*    Fun:    cmPkSoCacheCntrl
*
*    Desc:    pack the structure SoCacheCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCacheCntrl
(
SoCacheCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCacheCntrl(param ,mBuf)
SoCacheCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoCacheCntrl)

    CMCHKPK(SPkU8, param->entId,mBuf);
    CMCHKPK(SPkU8, param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCacheCntrl*/

/*
*
*    Fun:    cmPkSoSsapCntrl
*
*    Desc:    pack the structure SoSsapCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoSsapCntrl
(
SoSsapCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoSsapCntrl(param ,mBuf)
SoSsapCntrl *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkSoSsapCntrl)

    for (i=LSO_TPTSRV_MAX -1;i>=0;i--)
    {
       CMCHKPK(SPkU32, param->tptSrvLst[i],mBuf);
    }
    CMCHKPK(SPkS16, param->sSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoSsapCntrl*/

/*
*
*    Fun:    cmPkSoTptSrvCntrl
*
*    Desc:    pack the structure SoTptSrvCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoTptSrvCntrl
(
SoTptSrvCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoTptSrvCntrl(param ,mBuf)
SoTptSrvCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkSoTptSrvCntrl)

    CMCHKPK(cmPkSoTptSrvCfg, &param->cfg,mBuf);
    CMCHKPK(SPkU32, param->entId,mBuf);
    CMCHKPK(SPkU32, param->tptSrvId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoTptSrvCntrl*/

/*
*
*    Fun:    cmPkSoCntrl
*
*    Desc:    pack the structure SoCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoCntrl
(
SoCntrl *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoCntrl(param ,elmnt, mBuf)
SoCntrl *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoCntrl)

    switch( param->subAction )
    {
       case  SADBG :
          switch( elmnt )
          {
             default:
#ifdef DEBUGP
                CMCHKPK(cmPkSoDbgCntrl, &param->s.dbgCntrl,mBuf);
#endif /*  DEBUGP  */
                break;
          }
          break;
       case  SAELMNT :
          switch( elmnt )
          {
             case  STALLSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STGEN :
                CMCHKPK(cmPkSoCacheCntrl, &param->s.cacheCntrl,mBuf);
                break;
             case  STGRDLSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STGRNSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STGRSSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STGRTSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STPEERSAP :
                CMCHKPK(SPkU16, param->s.procId,mBuf);
                break;
             case  STSIPENT :
                CMCHKPK(SPkU8, param->s.entId,mBuf);
                break;
             case  STSSAP :
                CMCHKPK(cmPkSoSsapCntrl, &param->s.sSapCntrl,mBuf);
                break;
             case  STTPTSRV :
                CMCHKPK(cmPkSoTptSrvCntrl, &param->s.tptSrvCntrl,mBuf);
                break;
             case  STTSAP :
                CMCHKPK(SPkS16, param->s.sapId,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  SATRC :
          switch( elmnt )
          {
             default:
                ret1 = cmPkSoTrcCntrl(&param->s.trcCntrl, elmnt ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
          }
          break;
       default:
          switch( elmnt )
          {
             default:
                break;
          }
          break;
    }
    CMCHKPK(SPkU8, param->subAction,mBuf);
    CMCHKPK(SPkU8, param->action,mBuf);
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoCntrl*/

/*
*
*    Fun:    cmPkSoMngmt
*
*    Desc:    pack the structure SoMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSoMngmt
(
SoMngmt *param,
U8 evnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSoMngmt(param ,evnt, mBuf)
SoMngmt *param;
U8 evnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkSoMngmt)

    switch( evnt )
    {
#ifdef LSO_ACNT
       case  EVTLSOACNTCFM :
          ret1 = cmPkSoAcnt(&param->t.acnt,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOACNTIND :
          ret1 = cmPkSoAcnt(&param->t.acnt,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOACNTREQ :
          ret1 = cmPkSoAcnt(&param->t.acnt,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
#endif /*  LSO_ACNT  */
       case  EVTLSOCFGCFM :
          ret1 = cmPkSoCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCFGREQ :
          ret1 = cmPkSoCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCNTRLCFM :
          ret1 = cmPkSoCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCNTRLREQ :
          ret1 = cmPkSoCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTACFM :
          /* so009.201 : Fix for packing/unpacking system id */
          ret1 = cmPkSoSsta(&param->t.ssta, param->hdr.elmId.elmnt, evnt, mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTAIND :
          CMCHKPK(cmPkSoUsta, &param->t.usta,mBuf);
          break;
       case  EVTLSOSTAREQ :
          /* so009.201 : Fix for packing/unpacking system id */
          ret1 = cmPkSoSsta(&param->t.ssta, param->hdr.elmId.elmnt, evnt, mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTSCFM :
          ret1 = cmPkSoSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTSREQ :
          ret1 = cmPkSoSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOTRCIND :
          ret1 = cmPkSoTrc(&param->t.trc, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkCmStatus, &param->cfm,mBuf);
    CMCHKPK(cmPkHeader, &param->hdr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkSoMngmt*/

/*
*
*    Fun:    cmPkLsoCfgReq
*
*    Desc:    pack the primitive LsoCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoCfgReq
(
Pst *pst,
SoMngmt *cfg
)
#else
PUBLIC S16 cmPkLsoCfgReq(pst, cfg)
Pst *pst;
SoMngmt *cfg;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoCfgReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(cfg, EVTLSOCFGREQ ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOCFGREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoCfgReq*/

/*
*
*    Fun:    cmPkLsoCfgCfm
*
*    Desc:    pack the primitive LsoCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoCfgCfm
(
Pst *pst,
SoMngmt *cfg
)
#else
PUBLIC S16 cmPkLsoCfgCfm(pst, cfg)
Pst *pst;
SoMngmt *cfg;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoCfgCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(cfg, EVTLSOCFGCFM ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOCFGCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoCfgCfm*/

/*
*
*    Fun:    cmPkLsoCntrlReq
*
*    Desc:    pack the primitive LsoCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoCntrlReq
(
Pst *pst,
SoMngmt *cntrl
)
#else
PUBLIC S16 cmPkLsoCntrlReq(pst, cntrl)
Pst *pst;
SoMngmt *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoCntrlReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(cntrl, EVTLSOCNTRLREQ ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOCNTRLREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoCntrlReq*/

/*
*
*    Fun:    cmPkLsoCntrlCfm
*
*    Desc:    pack the primitive LsoCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoCntrlCfm
(
Pst *pst,
SoMngmt *cntrl
)
#else
PUBLIC S16 cmPkLsoCntrlCfm(pst, cntrl)
Pst *pst;
SoMngmt *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoCntrlCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(cntrl, EVTLSOCNTRLCFM ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOCNTRLCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoCntrlCfm*/

/*
*
*    Fun:    cmPkLsoStaReq
*
*    Desc:    pack the primitive LsoStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoStaReq
(
Pst *pst,
SoMngmt *sta
)
#else
PUBLIC S16 cmPkLsoStaReq(pst, sta)
Pst *pst;
SoMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoStaReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(sta, EVTLSOSTAREQ ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOSTAREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoStaReq*/

/*
*
*    Fun:    cmPkLsoStaCfm
*
*    Desc:    pack the primitive LsoStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoStaCfm
(
Pst *pst,
SoMngmt *sta
)
#else
PUBLIC S16 cmPkLsoStaCfm(pst, sta)
Pst *pst;
SoMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoStaCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(sta, EVTLSOSTACFM ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOSTACFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoStaCfm*/

/*
*
*    Fun:    cmPkLsoStaInd
*
*    Desc:    pack the primitive LsoStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoStaInd
(
Pst *pst,
SoMngmt *sta
)
#else
PUBLIC S16 cmPkLsoStaInd(pst, sta)
Pst *pst;
SoMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoStaInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(sta, EVTLSOSTAIND ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOSTAIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoStaInd*/

/*
*
*    Fun:    cmPkLsoStsReq
*
*    Desc:    pack the primitive LsoStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoStsReq
(
Pst *pst,
Action action,
SoMngmt *sts
)
#else
PUBLIC S16 cmPkLsoStsReq(pst, action, sts)
Pst *pst;
Action action;
SoMngmt *sts;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoStsReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(sts, EVTLSOSTSREQ ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    CMCHKPKLOG(SPkS16, action, mBuf, ELSOXXX, pst);
    pst->event = (Event) EVTLSOSTSREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoStsReq*/

/*
*
*    Fun:    cmPkLsoStsCfm
*
*    Desc:    pack the primitive LsoStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoStsCfm
(
Pst *pst,
SoMngmt *sts
)
#else
PUBLIC S16 cmPkLsoStsCfm(pst, sts)
Pst *pst;
SoMngmt *sts;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoStsCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(sts, EVTLSOSTSCFM ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOSTSCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoStsCfm*/

/*
*
*    Fun:    cmPkLsoTrcInd
*
*    Desc:    pack the primitive LsoTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoTrcInd
(
Pst *pst,
SoMngmt *trc,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkLsoTrcInd(pst, trc, mBuf)
Pst *pst;
SoMngmt *trc;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkLsoTrcInd)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          RETVALUE(ret1);
       }
    }
    ret1 = cmPkSoMngmt(trc, EVTLSOTRCIND ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOTRCIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoTrcInd*/

/*
*
*    Fun:    cmPkLsoAcntReq
*
*    Desc:    pack the primitive LsoAcntReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoAcntReq
(
Pst *pst,
SoMngmt *acnt
)
#else
PUBLIC S16 cmPkLsoAcntReq(pst, acnt)
Pst *pst;
SoMngmt *acnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoAcntReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(acnt, EVTLSOACNTREQ ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOACNTREQ;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoAcntReq*/

/*
*
*    Fun:    cmPkLsoAcntCfm
*
*    Desc:    pack the primitive LsoAcntCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoAcntCfm
(
Pst *pst,
SoMngmt *acnt
)
#else
PUBLIC S16 cmPkLsoAcntCfm(pst, acnt)
Pst *pst;
SoMngmt *acnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoAcntCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(acnt, EVTLSOACNTCFM ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOACNTCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoAcntCfm*/

/*
*
*    Fun:    cmPkLsoAcntInd
*
*    Desc:    pack the primitive LsoAcntInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsoAcntInd
(
Pst *pst,
SoMngmt *acnt
)
#else
PUBLIC S16 cmPkLsoAcntInd(pst, acnt)
Pst *pst;
SoMngmt *acnt;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLsoAcntInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELSOXXX, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkSoMngmt(acnt, EVTLSOACNTIND ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLSOACNTIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLsoAcntInd*/

/*
*
*    Fun:    cmUnpkSoTknStr
*
*    Desc:    unpack the structure soTknStr
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTknStr
(
SoTknStr *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTknStr(param ,mBuf)
SoTknStr *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoTknStr)

    CMCHKUNPK(SUnpkU8, &param->pres,mBuf);
    for (i=0;i<LSO_STR_SZ ;i++)
    {
       CMCHKUNPK(SUnpkS8, &param->str[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTknStr*/

/*
*
*    Fun:    cmUnpkSoTptSrvCfg
*
*    Desc:    unpack the structure soTptSrvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTptSrvCfg
(
SoTptSrvCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTptSrvCfg(param ,mBuf)
SoTptSrvCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoTptSrvCfg)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->tptSrvId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->nmbSSap,mBuf);
    for (i=0;i<param->nmbSSap ;i++)
    {
       CMCHKUNPK(SUnpkS16, &param->sSapLst[i], mBuf);
    }
    CMCHKUNPK(cmUnpkCmTptAddr, &param->tptAddr,mBuf);
    CMCHKUNPK(SUnpkU8, &param->tptProt,mBuf);
    CMCHKUNPK(cmUnpkCmTptParam, &param->tPar,mBuf);
    for (i=0;i<LSO_HOSTNAME_MAX_SZ ;i++)
    {
       CMCHKUNPK(SUnpkS8, &param->hostname[i], mBuf);
    }
    /* so010.201: New parameters added */
    CMCHKUNPK(SUnpkS16, &param->opnSrvRetryCnt,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->opnSrvTmr,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTptSrvCfg*/
#ifdef SO_DNS

/*
*
*    Fun:    cmUnpkSoDnsCfg
*
*    Desc:    unpack the structure soDnsCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDnsCfg
(
SoDnsCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDnsCfg(param ,mBuf)
SoDnsCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoDnsCfg)

    CMCHKUNPK(SUnpkU8, &param->useDns,mBuf);
    CMCHKUNPK(SUnpkU8, &param->useDnsCache,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsACacheSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsSrvCacheSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsNaptrCacheSz,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoDnsCfg*/
#endif /* SO_DNS */

/*
*
*    Fun:    cmUnpkSoTmrReTxReCfg
*
*    Desc:    unpack the structure soTmrReTxReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTmrReTxReCfg
(
SoTmrReTxReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTmrReTxReCfg(param ,mBuf)
SoTmrReTxReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTmrReTxReCfg)

    CMCHKUNPK(SUnpkU32, &param->t1,mBuf);
    CMCHKUNPK(SUnpkU32, &param->t2,mBuf);
    CMCHKUNPK(SUnpkU32, &param->t4,mBuf);
#if(  defined(  SO_NAT)  && defined(  SO_USE_UDP_SRVR) ) 
    CMCHKUNPK(SUnpkU32, &param->natTmrVal,mBuf);
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkSoTmrReTxReCfg*/
#ifdef SO_DNS

/*
*
*    Fun:    cmUnpkSoDnsReCfg
*
*    Desc:    unpack the structure soDnsReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDnsReCfg
(
SoDnsReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDnsReCfg(param ,mBuf)
SoDnsReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoDnsReCfg)

    CMCHKUNPK(cmUnpkCmTptAddr, &param->dnsTptAddr,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->locAddr,mBuf);
    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(cmUnpkCmTptParam, &param->dnsTptParam,mBuf);
    CMCHKUNPK(SUnpkU32, &param->tptSrvId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->maxDnsRetry,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->dnsQueryTmr,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxDnsCacheExp,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoDnsReCfg*/
#endif /* SO_DNS */
#ifdef SO_NS
#ifdef SO_LCS

/*
*
*    Fun:    cmUnpkSoLocSrvCfg
*
*    Desc:    unpack the structure soLocSrvCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoLocSrvCfg
(
SoLocSrvCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoLocSrvCfg(param ,mBuf)
SoLocSrvCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoLocSrvCfg)

    CMCHKUNPK(SUnpkU8, &param->useExtLocServices,mBuf);
    CMCHKUNPK(SUnpkU8, &param->locCachePres,mBuf);
    CMCHKUNPK(SUnpkU32, &param->locCacheSz,mBuf);
    CMCHKUNPK(SUnpkU16, &param->locSrchHlBins,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoLocSrvCfg*/

/*
*
*    Fun:    cmUnpkSoLocSrvReCfg
*
*    Desc:    unpack the structure soLocSrvReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoLocSrvReCfg
(
SoLocSrvReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoLocSrvReCfg(param ,mBuf)
SoLocSrvReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoLocSrvReCfg)

    CMCHKUNPK(SUnpkU32, &param->dfltLocCacheExp,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxLocCacheExp,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoLocSrvReCfg*/
#endif /* SO_LCS */
#endif /* SO_NS */

/*
*
*    Fun:    cmUnpkSoGenReCfg
*
*    Desc:    unpack the structure soGenReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoGenReCfg
(
SoGenReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoGenReCfg(param ,mBuf)
SoGenReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoGenReCfg)

    CMCHKUNPK(SUnpkS8, &param->GMToffset,mBuf);
#ifdef SO_DNS
    CMCHKUNPK(cmUnpkSoDnsReCfg, &param->dnsReCfg,mBuf);
#endif /*  SO_DNS  */
    CMCHKUNPK(cmUnpkSoTmrReTxReCfg, &param->tmrReTxCfg,mBuf);
#ifdef SO_NS
#ifdef SO_LCS
    CMCHKUNPK(cmUnpkSoLocSrvReCfg, &param->locSrvReCfg,mBuf);
#endif /*  SO_LCS  */
#endif /*  SO_NS  */
    RETVALUE(ROK);
} /*end of function cmUnpkSoGenReCfg*/

/*
*
*    Fun:    cmUnpkSoGenCfg
*
*    Desc:    unpack the structure soGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoGenCfg
(
SoGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoGenCfg(param ,mBuf)
SoGenCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoGenCfg)

    for (i=0;i<LSO_PROTVER_SZ ;i++)
    {
       CMCHKUNPK(SUnpkS8, &param->protVer[i], mBuf);
    }
    CMCHKUNPK(SUnpkS16, &param->maxNmbSSaps,mBuf);
    CMCHKUNPK(SUnpkS16, &param->maxNmbTSaps,mBuf);
    CMCHKUNPK(SUnpkU8, &param->maxNmbUA,mBuf);
    CMCHKUNPK(SUnpkU8, &param->maxNmbNS,mBuf);
    CMCHKUNPK(SUnpkU8, &param->maxNmbRemReg,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxNmbActCalls,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxTransPerEnt,mBuf);
    CMCHKUNPK(SUnpkS16, &param->resThreshUpper,mBuf);
    CMCHKUNPK(SUnpkS16, &param->resThreshLower,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxPendLocReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxBlkSize,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sdpBlkSize,mBuf);
    CMCHKUNPK(SUnpkU32, &param->locRegSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->remRegSz,mBuf);
#ifdef SO_DNS
    CMCHKUNPK(cmUnpkSoDnsCfg, &param->dnsCfg,mBuf);
#endif /*  SO_DNS  */
#ifdef SO_NS
#ifdef SO_LCS
    CMCHKUNPK(cmUnpkSoLocSrvCfg, &param->locSrvCfg,mBuf);
#endif /*  SO_LCS  */
#endif /*  SO_NS  */
    CMCHKUNPK(cmUnpkPst, &param->lmPst,mBuf);
    CMCHKUNPK(cmUnpkPst, &param->compPst,mBuf);
    for (i=0;i<LSO_NODEID_SZ ;i++)
    {
       CMCHKUNPK(SUnpkU8, &param->nodeIdStr[i], mBuf);
    }
#ifdef DEBUGP
    CMCHKUNPK(SUnpkU32, &param->dbgMask,mBuf);
#endif /*  DEBUGP  */
#ifdef SO_ABNF_MT_LIB
    CMCHKUNPK(SUnpkU8, &param->nmbEDThreads,mBuf);
#endif /*  SO_ABNF_MT_LIB  */
#ifdef SO_UA
    CMCHKUNPK(SUnpkU32, &param->maxNumRegPerEnt,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxNumCnctPerEnt,mBuf);
#endif /*  SO_UA  */
    CMCHKUNPK(SUnpkU16, &param->mtu,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoGenCfg*/

/*
*
*    Fun:    cmUnpkSoTSapReCfg
*
*    Desc:    unpack the structure soTSapReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTSapReCfg
(
SoTSapReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTSapReCfg(param ,mBuf)
SoTSapReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTSapReCfg)

    CMCHKUNPK(cmUnpkCmTptParam, &param->tPar,mBuf);
    CMCHKUNPK(SUnpkU8, &param->maxBndRetry,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->bndTmCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTSapReCfg*/

/*
*
*    Fun:    cmUnpkSoTSapCfg
*
*    Desc:    unpack the structure soTSapCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTSapCfg
(
SoTSapCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTSapCfg(param ,mBuf)
SoTSapCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTSapCfg)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->spId,mBuf);
    CMCHKUNPK(cmUnpkMemoryId, &param->memId,mBuf);
    CMCHKUNPK(SUnpkU16, &param->dstProcId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstEnt,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstInst,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstPrior,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstRoute,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstSel,mBuf);
    CMCHKUNPK(SUnpkU16, &param->suConIdHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->tptAddrHlBins,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTSapCfg*/

/*
*
*    Fun:    cmUnpkSoTptSrvLstCfg
*
*    Desc:    unpack the structure soTptSrvLstCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTptSrvLstCfg
(
SoTptSrvLstCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTptSrvLstCfg(param ,mBuf)
SoTptSrvLstCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoTptSrvLstCfg)

    CMCHKUNPK(SUnpkU32, &param->nmbTptSrv,mBuf);
    for (i=0;i<param->nmbTptSrv ;i++)
    {
       CMCHKUNPK(cmUnpkSoTptSrvCfg, &param->tptSrvCfg[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoTptSrvLstCfg*/

/*
*
*    Fun:    cmUnpkSoDfltPrxCfg
*
*    Desc:    unpack the structure soDfltPrxCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDfltPrxCfg
(
SoDfltPrxCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDfltPrxCfg(param ,mBuf)
SoDfltPrxCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoDfltPrxCfg)

    CMCHKUNPK(SUnpkU8, &param->useDfltPrx,mBuf);
    CMCHKUNPK(SUnpkU8, &param->rcvDfltPrxOnly,mBuf);
    CMCHKUNPK(SUnpkU8, &param->looseRouter,mBuf);
#ifdef SO_COMPRESS
    CMCHKUNPK(SUnpkU8, &param->sigCompSupp,mBuf);
#endif /*  SO_COMPRESS  */
    CMCHKUNPK(SUnpkU8, &param->choice,mBuf);
    switch( param->choice )
    {
       case  LSO_DFLT_PRX_DOMAIN_NAME :
          for (i=0;i<LSO_HOSTNAME_MAX_SZ ;i++)
          {
             CMCHKUNPK(SUnpkS8, &param->t.domainName[i], mBuf);
          }
          break;
       case  LSO_DFLT_PRX_NONE :
          break;
       case  LSO_DFLT_PRX_TPT_ADDR :
          CMCHKUNPK(cmUnpkCmTptAddr, &param->t.dfltPrxAddr,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoDfltPrxCfg*/

/*
*
*    Fun:    cmUnpkSoUAReCfg
*
*    Desc:    unpack the structure soUAReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUAReCfg
(
SoUAReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUAReCfg(param ,mBuf)
SoUAReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUAReCfg)

    CMCHKUNPK(SUnpkU32, &param->threshUpper,mBuf);
    CMCHKUNPK(SUnpkU32, &param->threshLower,mBuf);
    CMCHKUNPK(SUnpkU8, &param->alw3rdParty,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dfltExpiresInRegister,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dfltExpiresInInvite,mBuf);
    CMCHKUNPK(SUnpkU8, &param->alertUsrOnExp,mBuf);
    CMCHKUNPK(SUnpkU8, &param->refreshOnExp,mBuf);
    CMCHKUNPK(SUnpkU8, &param->chkLocUsrReg,mBuf);
    CMCHKUNPK(cmUnpkSoDfltPrxCfg, &param->dfltPrxCfg,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insTmStamp,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->regSrvAddr,mBuf);
    CMCHKUNPK(SUnpkU8, &param->addContact,mBuf);
    CMCHKUNPK(SUnpkU8, &param->useIpContact,mBuf);
    CMCHKUNPK(SUnpkU8, &param->relProvRspReq,mBuf);
    CMCHKUNPK(SUnpkU8, &param->relProvRspSupp,mBuf);
#ifdef SO_COMPRESS
    CMCHKUNPK(SUnpkU8, &param->sigCompSupp,mBuf);
#endif /*  SO_COMPRESS  */
    /* so007.201 : Added code for unpacking of new parameter */
    /* lso_c_001.main_4 :Added code to reject for all the requests
     (invites & non-invites) */
#ifdef SO_REJECT_ON_UA_RESTART
    CMCHKUNPK(SUnpkU8, &param->rejOnUARestart,mBuf);
#endif /* SO_REJECT_ON_UA_RESTART */
#ifdef SO_REJECT_REINV_ON_UA_RESTART
    CMCHKUNPK(SUnpkU8, &param->rejReInvOnUARestart,mBuf);
#endif /* SO_REJECT_REINV_ON_UA_RESTART */
    CMCHKUNPK(cmUnpkSoTknStr, &param->insUserAgent,mBuf);
    CMCHKUNPK(cmUnpkSoTknStr, &param->insServer,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUAReCfg*/

/*
*
*    Fun:    cmUnpkSoUACfg
*
*    Desc:    unpack the structure soUACfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUACfg
(
SoUACfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUACfg(param ,mBuf)
SoUACfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUACfg)

    CMCHKUNPK(SUnpkU16, &param->callIdHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->callHdlHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->regAddrHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->regContactHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->regHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->clientTransHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->serverTransHlBins,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUACfg*/

/*
*
*    Fun:    cmUnpkSoNSCfg
*
*    Desc:    unpack the structure soNSCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNSCfg
(
SoNSCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNSCfg(param ,mBuf)
SoNSCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoNSCfg)

    CMCHKUNPK(SUnpkU8, &param->regSrvLoc,mBuf);
    CMCHKUNPK(SUnpkU8, &param->remRegLoc,mBuf);
    CMCHKUNPK(SUnpkS16, &param->remRegSapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->pathRoute,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoNSCfg*/

/*
*
*    Fun:    cmUnpkSoProxyReCfg
*
*    Desc:    unpack the structure soProxyReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoProxyReCfg
(
SoProxyReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoProxyReCfg(param ,mBuf)
SoProxyReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoProxyReCfg)

    CMCHKUNPK(SUnpkU8, &param->prxState,mBuf);
    CMCHKUNPK(SUnpkU8, &param->recordRoute,mBuf);
    CMCHKUNPK(SUnpkU8, &param->useIpRecRoute,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoProxyReCfg*/

/*
*
*    Fun:    cmUnpkSoNSReCfg
*
*    Desc:    unpack the structure soNSReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNSReCfg
(
SoNSReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNSReCfg(param ,mBuf)
SoNSReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoNSReCfg)

    CMCHKUNPK(cmUnpkSoProxyReCfg, &param->proxyReCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoNSReCfg*/

/*
*
*    Fun:    cmUnpkSoHdrCfg
*
*    Desc:    unpack the structure soHdrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoHdrCfg
(
SoHdrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoHdrCfg(param ,mBuf)
SoHdrCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoHdrCfg)

    CMCHKUNPK(SUnpkU8, &param->insDate,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insAllow,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insExpires,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insUAHdr,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insSupported,mBuf);
    CMCHKUNPK(SUnpkU8, &param->insAccept,mBuf);
    CMCHKUNPK(SUnpkU16, &param->maxFwd,mBuf);
    CMCHKUNPK(cmUnpkSoTknStr, &param->insOrg,mBuf);
    CMCHKUNPK(cmUnpkSoTknStr, &param->insSubject,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoHdrCfg*/

/*
*
*    Fun:    cmUnpkSoEntReCfg
*
*    Desc:    unpack the structure SoEntReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEntReCfg
(
SoEntReCfg *param,
U16 entType,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEntReCfg(param ,entType, mBuf)
SoEntReCfg *param;
U16 entType;
Buffer *mBuf;
#endif
{
#ifdef SO_EVENT
    Cntr i;
#endif
    TRC3(cmUnpkSoEntReCfg)

    CMCHKUNPK(cmUnpkSoHdrCfg, &param->hdrCfg,mBuf);
    CMCHKUNPK(SUnpkU8, &param->snd100Always,mBuf);
    CMCHKUNPK(SUnpkU8, &param->useCompact,mBuf);
    CMCHKUNPK(SUnpkU8, &param->alwRecurse,mBuf);
    CMCHKUNPK(SUnpkU8, &param->decodeSDP,mBuf);
    CMCHKUNPK(SUnpkU32, &param->tptInActvTmr,mBuf);
#ifdef SO_TLS
    CMCHKUNPK(SUnpkU32, &param->tlsInActvTmr,mBuf);
#endif /*  SO_TLS  */
#ifdef SO_NS
    CMCHKUNPK(SUnpkS16, &param->locSrvSapId,mBuf);
#endif /*  SO_NS  */
#ifdef SO_SESSTIMER
    CMCHKUNPK(SUnpkU8, &param->useSessTmr,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sessTmrVal,mBuf);
    CMCHKUNPK(SUnpkU32, &param->minSe,mBuf);
#endif /*  SO_SESSTIMER  */
#ifdef SO_EVENT
    CMCHKUNPK(SUnpkU8, &param->nmbStdEvntPkg,mBuf);
    for (i=0;i<param->nmbStdEvntPkg ;i++)
    {
       CMCHKUNPK(cmUnpkSoTknStr, &param->supportedStdEvntPkg[i], mBuf);
    }
    CMCHKUNPK(SUnpkU8, &param->nmbNonStdEvntPkg,mBuf);
    for (i=0;i<param->nmbNonStdEvntPkg ;i++)
    {
       CMCHKUNPK(cmUnpkSoTknStr, &param->supportedNonStdEvntPkg[i], mBuf);
    }
    CMCHKUNPK(SUnpkU32, &param->evntPkgExpires,mBuf);
    CMCHKUNPK(SUnpkU8, &param->alertUsrOnEvntExp,mBuf);
#endif /*  SO_EVENT  */
    switch( entType )
    {
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKUNPK(cmUnpkSoNSReCfg, &param->e.nsReCfg,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKUNPK(cmUnpkSoUAReCfg, &param->e.uaReCfg,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoEntReCfg*/

/*
*
*    Fun:    cmUnpkSoEntCfg
*
*    Desc:    unpack the structure soEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEntCfg
(
SoEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEntCfg(param ,mBuf)
SoEntCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoEntCfg)

    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    switch( param->type )
    {
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKUNPK(cmUnpkSoNSCfg, &param->e.nsCfg,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKUNPK(cmUnpkSoUACfg, &param->e.uaCfg,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
    for (i=0;i<LSO_HOSTNAME_MAX_SZ ;i++)
    {
       CMCHKUNPK(SUnpkS8, &param->domainName[i], mBuf);
    }
    CMCHKUNPK(cmUnpkSoTptSrvLstCfg, &param->tptSrvLstCfg,mBuf);
#if(  defined(  SO_NAT)  && defined(  SO_USE_UDP_SRVR) ) 
    CMCHKUNPK(SUnpkU8, &param->addRportByDflt,mBuf);
#endif /*    */
#ifdef DEBUGP
    CMCHKUNPK(SUnpkU32, &param->dbgMask,mBuf);
#endif /*  DEBUGP  */
    RETVALUE(ROK);
} /*end of function cmUnpkSoEntCfg*/

/*
*
*    Fun:    cmUnpkSoSSapCfg
*
*    Desc:    unpack the structure soSSapCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSSapCfg
(
SoSSapCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSSapCfg(param ,mBuf)
SoSSapCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSSapCfg)

    CMCHKUNPK(SUnpkS16, &param->sSapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->sel,mBuf);
    CMCHKUNPK(cmUnpkMemoryId, &param->memId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->prior,mBuf);
    CMCHKUNPK(SUnpkU8, &param->route,mBuf);
    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numCLegHlBins,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numTransHlBins,mBuf);
    /* so027.201: Changes for SIP TLS support */
#ifdef SO_TLS
    CMCHKUNPK(SUnpkS16, &param->tlsCtxId,mBuf);
#endif
    RETVALUE(ROK);
} /*end of function cmUnpkSoSSapCfg*/

/*
*
*    Fun:    cmUnpkSoCfg
*
*    Desc:    unpack the structure SoCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCfg
(
SoCfg *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCfg(param ,elmnt, mBuf)
SoCfg *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoCfg)

    switch( elmnt )
    {
       case  STGEN :
          CMCHKUNPK(cmUnpkSoGenCfg, &param->c.genCfg,mBuf);
          break;
       case  STSIPENT :
          CMCHKUNPK(cmUnpkSoEntCfg, &param->c.entCfg,mBuf);
          break;
       case  STSSAP :
          CMCHKUNPK(cmUnpkSoSSapCfg, &param->c.sSapCfg,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkSoTSapCfg, &param->c.tSapCfg,mBuf);
          break;
       default:
          break;
    }
    switch( elmnt )
    {
       case  STGEN :
          CMCHKUNPK(cmUnpkSoGenReCfg, &param->r.genReCfg,mBuf);
          break;
       case  STSIPENT :
          ret1 = cmUnpkSoEntReCfg(&param->r.entReCfg, param->c.entCfg.type ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkSoTSapReCfg, &param->r.tSapReCfg,mBuf);
          break;
       default:
          break;
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCfg*/

/*
*
*    Fun:    cmUnpkSoTSapSts
*
*    Desc:    unpack the structure soTSapSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTSapSts
(
SoTSapSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTSapSts(param ,mBuf)
SoTSapSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTSapSts)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->bytesTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->bytesRx,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTSapSts*/

/*
*
*    Fun:    cmUnpkSoSSapSts
*
*    Desc:    unpack the structure soSSapSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSSapSts
(
SoSSapSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSSapSts(param ,mBuf)
SoSSapSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSSapSts)

    CMCHKUNPK(SUnpkS16, &param->sSapId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->callsTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->callsRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numLocReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRegReq,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoSSapSts*/

/*
*
*    Fun:    cmUnpkSoSummSts
*
*    Desc:    unpack the structure soSummSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSummSts
(
SoSummSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSummSts(param ,mBuf)
SoSummSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSummSts)

    CMCHKUNPK(SUnpkU32, &param->sumInReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sumOutReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sumInResp,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sumOutResp,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoSummSts*/

/*
*
*    Fun:    cmUnpkSoMethSts
*
*    Desc:    unpack the structure soMethSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMethSts
(
SoMethSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMethSts(param ,mBuf)
SoMethSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoMethSts)

    CMCHKUNPK(SUnpkU32, &param->methInInv,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutInv,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInAck,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutAck,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInBye,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutBye,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInCanc,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutCanc,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInOpt,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutOpt,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInReg,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutReg,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInInfo,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutInfo,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutPrack,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInPrack,mBuf);
#ifdef SO_UPDATE
    CMCHKUNPK(SUnpkU32, &param->methOutUpdate,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInUpdate,mBuf);
#endif /*  SO_UPDATE  */
#ifdef SO_EVENT
    CMCHKUNPK(SUnpkU32, &param->methOutSubsc,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInSubsc,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutNotify,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInNotify,mBuf);
#endif /*  SO_EVENT  */
#ifdef SO_INSTMSG
    CMCHKUNPK(SUnpkU32, &param->methOutMessage,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methInMessage,mBuf);
#endif /*  SO_INSTMSG  */
#ifdef SO_REFER
    CMCHKUNPK(SUnpkU32, &param->methInRefer,mBuf);
    CMCHKUNPK(SUnpkU32, &param->methOutRefer,mBuf);
#endif /*  SO_REFER  */
    RETVALUE(ROK);
} /*end of function cmUnpkSoMethSts*/

/*
*
*    Fun:    cmUnpkSoRespSts
*
*    Desc:    unpack the structure soRespSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRespSts
(
SoRespSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRespSts(param ,mBuf)
SoRespSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoRespSts)

    CMCHKUNPK(SUnpkU32, &param->infoClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->infoClassOut,mBuf);
    CMCHKUNPK(SUnpkU32, &param->successClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->successClassOut,mBuf);
    CMCHKUNPK(SUnpkU32, &param->redirClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->redirClassOut,mBuf);
    CMCHKUNPK(SUnpkU32, &param->reqFailClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->reqFailClassOut,mBuf);
    CMCHKUNPK(SUnpkU32, &param->srvFailClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->srvFailClassOut,mBuf);
    CMCHKUNPK(SUnpkU32, &param->globalFailClassIn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->globalFailClassOut,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoRespSts*/

/*
*
*    Fun:    cmUnpkSoCacheSts
*
*    Desc:    unpack the structure soCacheSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCacheSts
(
SoCacheSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCacheSts(param ,mBuf)
SoCacheSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoCacheSts)

    CMCHKUNPK(SUnpkU32, &param->peakNmbEntries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->peakMemUsage,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoCacheSts*/

/*
*
*    Fun:    cmUnpkSoErrSts
*
*    Desc:    unpack the structure soErrSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoErrSts
(
SoErrSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoErrSts(param ,mBuf)
SoErrSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoErrSts)

    CMCHKUNPK(SUnpkU32, &param->unkwnUser,mBuf);
    CMCHKUNPK(SUnpkU32, &param->usrUnavail,mBuf);
    CMCHKUNPK(SUnpkU32, &param->invalidRsp,mBuf);
    CMCHKUNPK(SUnpkU32, &param->invalidReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->missingMandHdr,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sdpDecFail,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sipDecFail,mBuf);
    CMCHKUNPK(SUnpkU32, &param->sipEncFail,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoErrSts*/

/*
*
*    Fun:    cmUnpkSoOtherSts
*
*    Desc:    unpack the structure soOtherSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoOtherSts
(
SoOtherSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoOtherSts(param ,mBuf)
SoOtherSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoOtherSts)

    CMCHKUNPK(SUnpkU32, &param->nmbUnsupUri,mBuf);
    CMCHKUNPK(SUnpkU32, &param->regTO,mBuf);
    CMCHKUNPK(SUnpkU32, &param->reTxReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->tranTO,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoOtherSts*/
#ifdef SO_DNS

/*
*
*    Fun:    cmUnpkSoDnsSts
*
*    Desc:    unpack the structure soDnsSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDnsSts
(
SoDnsSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDnsSts(param ,mBuf)
SoDnsSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoDnsSts)

    CMCHKUNPK(SUnpkU32, &param->nmbDnsQueryTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->nmbDnsRspSuccess,mBuf);
    CMCHKUNPK(SUnpkU32, &param->nmbDnsRspFail,mBuf);
    CMCHKUNPK(SUnpkU32, &param->nmbDnsQueryTO,mBuf);
    CMCHKUNPK(cmUnpkSoCacheSts, &param->dnsACache,mBuf);
    CMCHKUNPK(cmUnpkSoCacheSts, &param->dnsSrvCache,mBuf);
    CMCHKUNPK(cmUnpkSoCacheSts, &param->dnsNaptrCache,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoDnsSts*/
#endif /* SO_DNS */

/*
*
*    Fun:    cmUnpkSoGenSts
*
*    Desc:    unpack the structure soGenSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoGenSts
(
SoGenSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoGenSts(param ,mBuf)
SoGenSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoGenSts)

#ifdef SO_DNS
    CMCHKUNPK(cmUnpkSoDnsSts, &param->dnsSts,mBuf);
#endif /*  SO_DNS  */
    CMCHKUNPK(cmUnpkSoSummSts, &param->summSts,mBuf);
    CMCHKUNPK(cmUnpkSoMethSts, &param->methSts,mBuf);
    CMCHKUNPK(cmUnpkSoRespSts, &param->respSts,mBuf);
    CMCHKUNPK(cmUnpkSoErrSts, &param->errSts,mBuf);
    CMCHKUNPK(cmUnpkSoOtherSts, &param->otherSts,mBuf);
#ifdef SO_LCS
    CMCHKUNPK(cmUnpkSoCacheSts, &param->locSrvCache,mBuf);
#endif /*  SO_LCS  */
    CMCHKUNPK(cmUnpkSoCacheSts, &param->mCastCache,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoGenSts*/

/*
*
*    Fun:    cmUnpkSoUASts
*
*    Desc:    unpack the structure soUASts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUASts
(
SoUASts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUASts(param ,mBuf)
SoUASts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUASts)

    CMCHKUNPK(SUnpkU32, &param->reqRetries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->rspRetries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->peakNmbEntries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->peakMemUsage,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUASts*/

/*
*
*    Fun:    cmUnpkSoNSSts
*
*    Desc:    unpack the structure soNSSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNSSts
(
SoNSSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNSSts(param ,mBuf)
SoNSSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoNSSts)

    CMCHKUNPK(SUnpkU32, &param->nmbPrxReqFail,mBuf);
    CMCHKUNPK(SUnpkU32, &param->peakNmbEntries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->peakMemUsage,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoNSSts*/

/*
*
*    Fun:    cmUnpkSoEntSts
*
*    Desc:    unpack the structure soEntSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEntSts
(
SoEntSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEntSts(param ,mBuf)
SoEntSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoEntSts)

    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->stsType,mBuf);
    CMCHKUNPK(cmUnpkSoSummSts, &param->summSts,mBuf);
    CMCHKUNPK(cmUnpkSoMethSts, &param->methSts,mBuf);
    CMCHKUNPK(cmUnpkSoRespSts, &param->respSts,mBuf);
    CMCHKUNPK(cmUnpkSoErrSts, &param->errSts,mBuf);
    CMCHKUNPK(cmUnpkSoOtherSts, &param->otherSts,mBuf);
    switch( param->stsType )
    {
#ifdef SO_NS
       case  LSO_STS_NS :
          CMCHKUNPK(cmUnpkSoNSSts, &param->t.nsSts,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_STS_UA :
          CMCHKUNPK(cmUnpkSoUASts, &param->t.uaSts,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          break;
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoEntSts*/

/*
*
*    Fun:    cmUnpkSoSts
*
*    Desc:    unpack the structure SoSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSts
(
SoSts *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSts(param ,elmnt, mBuf)
SoSts *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSts)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    CMCHKUNPK(SUnpkS16, &param->action,mBuf);
    switch( elmnt )
    {
       case  STGEN :
          CMCHKUNPK(cmUnpkSoGenSts, &param->s.genSts,mBuf);
          break;
       case  STSIPENT :
          CMCHKUNPK(cmUnpkSoEntSts, &param->s.entSts,mBuf);
          break;
       case  STSSAP :
          CMCHKUNPK(cmUnpkSoSSapSts, &param->s.sSapSts,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkSoTSapSts, &param->s.tSapSts,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSts*/

/*
*
*    Fun:    cmUnpkSoUASta
*
*    Desc:    unpack the structure soUASta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUASta
(
SoUASta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUASta(param ,mBuf)
SoUASta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUASta)

    CMCHKUNPK(SUnpkU32, &param->locRegSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->locRegEntries,mBuf);
    CMCHKUNPK(SUnpkU8, &param->regWarnState,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUASta*/

/*
*
*    Fun:    cmUnpkSoRemRegSta
*
*    Desc:    unpack the structure soRemRegSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRemRegSta
(
SoRemRegSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRemRegSta(param ,mBuf)
SoRemRegSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoRemRegSta)

    CMCHKUNPK(SUnpkU32, &param->remRegSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->remRegEntries,mBuf);
    CMCHKUNPK(SUnpkU8, &param->regWarnState,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoRemRegSta*/

/*
*
*    Fun:    cmUnpkSoNSSta
*
*    Desc:    unpack the structure soNSSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoNSSta
(
SoNSSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoNSSta(param ,mBuf)
SoNSSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoNSSta)

    CMCHKUNPK(SUnpkU8, &param->prxState,mBuf);
    CMCHKUNPK(cmUnpkSoRemRegSta, &param->remRegSta,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoNSSta*/

/*
*
*    Fun:    cmUnpkSoEntSta
*
*    Desc:    unpack the structure soEntSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoEntSta
(
SoEntSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoEntSta(param ,mBuf)
SoEntSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoEntSta)

    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    CMCHKUNPK(SUnpkU8, &param->operState,mBuf);
    CMCHKUNPK(SUnpkU8, &param->lmState,mBuf);
    CMCHKUNPK(SUnpkU32, &param->strtTm,mBuf);
    CMCHKUNPK(SUnpkU32, &param->nmbActCalls,mBuf);
    CMCHKUNPK(SUnpkU32, &param->totNmbCLegs,mBuf);
    CMCHKUNPK(SUnpkU32, &param->totNmbTrans,mBuf);
    switch( param->type )
    {
       case  LSO_ENT_NONE :
          break;
#ifdef SO_NS
       case  LSO_ENT_NS :
          CMCHKUNPK(cmUnpkSoNSSta, &param->t.nsSta,mBuf);
          break;
#endif /*  SO_NS  */
#ifdef SO_UA
       case  LSO_ENT_UA :
          CMCHKUNPK(cmUnpkSoUASta, &param->t.uaSta,mBuf);
          break;
#endif /*  SO_UA  */
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoEntSta*/

/*
*
*    Fun:    cmUnpkSoGenSta
*
*    Desc:    unpack the structure soGenSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoGenSta
(
SoGenSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoGenSta(param ,mBuf)
SoGenSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoGenSta)

    CMCHKUNPK(SUnpkU8, &param->resCong,mBuf);
#ifdef SO_DNS
    CMCHKUNPK(SUnpkU32, &param->dnsACacheSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsSrvCacheSz,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsNaptrCacheSz,mBuf);
#endif /*  SO_DNS  */
#ifdef SO_LCS
    CMCHKUNPK(SUnpkU32, &param->locCacheSz,mBuf);
#endif /*  SO_LCS  */
    CMCHKUNPK(SUnpkU32, &param->mCastCacheSz,mBuf);
#ifdef SO_DNS
    CMCHKUNPK(SUnpkU32, &param->dnsACacheEntries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsSrvCacheEntries,mBuf);
    CMCHKUNPK(SUnpkU32, &param->dnsNaptrCacheEntries,mBuf);
#endif /*  SO_DNS  */
#ifdef SO_LCS
    CMCHKUNPK(SUnpkU32, &param->locSrvCacheEntries,mBuf);
#endif /*  SO_LCS  */
    CMCHKUNPK(SUnpkU32, &param->mCastCacheEntries,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoGenSta*/

/*
*
*    Fun:    cmUnpkSoTSapSta
*
*    Desc:    unpack the structure soTSapSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTSapSta
(
SoTSapSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTSapSta(param ,mBuf)
SoTSapSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTSapSta)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->state,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTSapSta*/

/*
*
*    Fun:    cmUnpkSoSSapSta
*
*    Desc:    unpack the structure soSSapSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSSapSta
(
SoSSapSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSSapSta(param ,mBuf)
SoSSapSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSSapSta)

    CMCHKUNPK(SUnpkS16, &param->sSapId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->state,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoSSapSta*/

/*
*
*    Fun:    cmUnpkSoTptSrvSta
*
*    Desc:    unpack the structure soTptSrvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTptSrvSta
(
SoTptSrvSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTptSrvSta(param ,mBuf)
SoTptSrvSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTptSrvSta)

    CMCHKUNPK(SUnpkU32, &param->tptSrvId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->state,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTptSrvSta*/

/*
*
*    Fun:    cmUnpkSoSsta
*
*    Desc:    unpack the structure SoSsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSsta
(
SoSsta *param,
U16 elmnt,
/* so009.201 : Fix for packing/unpacking system id */
U8  evnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSsta(param ,elmnt, evnt, mBuf)
SoSsta *param;
U16 elmnt;
/* so009.201 : Fix for packing/unpacking system id */
U8  evnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoSsta)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    switch( elmnt )
    {
       case  STGEN :
          CMCHKUNPK(cmUnpkSoGenSta, &param->s.genSta,mBuf);
          break;
       case  STSID :
          /* so009.201 : Fix for packing/unpacking system id */
          if (evnt == EVTLSOSTACFM)
          {
            CMCHKUNPK(cmUnpkSystemId, &param->s.sysId,mBuf);
          }
          break;
       case  STSIPENT :
          CMCHKUNPK(cmUnpkSoEntSta, &param->s.entSta,mBuf);
          break;
       case  STSSAP :
          CMCHKUNPK(cmUnpkSoSSapSta, &param->s.sSapSta,mBuf);
          break;
       case  STTPTSRV :
          CMCHKUNPK(cmUnpkSoTptSrvSta, &param->s.tptSrvSta,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkSoTSapSta, &param->s.tSapSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSsta*/

/*
*
*    Fun:    cmUnpkSoRegInf
*
*    Desc:    unpack the structure soRegInf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoRegInf
(
SoRegInf *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoRegInf(param ,mBuf)
SoRegInf *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoRegInf)

    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoRegInf*/

/*
*
*    Fun:    cmUnpkSoAlarmInfo
*
*    Desc:    unpack the structure soAlarmInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAlarmInfo
(
SoAlarmInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAlarmInfo(param ,mBuf)
SoAlarmInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoAlarmInfo)

    CMCHKUNPK(SUnpkU8, &param->alarmType,mBuf);
    switch( param->alarmType )
    {
       case  LSO_PAR_CHOICE :
          CMCHKUNPK(SUnpkU32, &param->v.val,mBuf);
          break;
       case  LSO_PAR_CONNID :
          CMCHKUNPK(SUnpkU32, &param->v.connId,mBuf);
          break;
       case  LSO_PAR_ENT :
          CMCHKUNPK(SUnpkU8, &param->v.entId,mBuf);
          break;
       case  LSO_PAR_MEM :
          CMCHKUNPK(cmUnpkMemoryId, &param->v.mem,mBuf);
          break;
       case  LSO_PAR_NONE :
          break;
       case  LSO_PAR_REASON :
          CMCHKUNPK(SUnpkU32, &param->v.val,mBuf);
          break;
       case  LSO_PAR_REG :
          CMCHKUNPK(cmUnpkSoRegInf, &param->v.reg,mBuf);
          break;
       case  LSO_PAR_SAP :
          CMCHKUNPK(SUnpkS16, &param->v.sapId,mBuf);
          break;
       case  LSO_PAR_STATUS :
          CMCHKUNPK(SUnpkU32, &param->v.val,mBuf);
          break;
       case  LSO_PAR_TPTADDR :
          CMCHKUNPK(cmUnpkCmTptAddr, &param->v.tptAddr,mBuf);
          break;
       case  LSO_PAR_TPTPARM :
          CMCHKUNPK(cmUnpkCmTptParam, &param->v.tptParm,mBuf);
          break;
       case  LSO_PAR_TPTSRV :
          CMCHKUNPK(SUnpkU32, &param->v.tptSrvId,mBuf);
          break;
       case  LSO_PAR_VAL :
          CMCHKUNPK(SUnpkU32, &param->v.val,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAlarmInfo*/

/*
*
*    Fun:    cmUnpkSoUsta
*
*    Desc:    unpack the structure soUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoUsta
(
SoUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoUsta(param ,mBuf)
SoUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoUsta)

    CMCHKUNPK(cmUnpkCmAlarm, &param->alarm,mBuf);
    CMCHKUNPK(cmUnpkSoAlarmInfo, &param->alarmInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoUsta*/
#ifdef LSO_ACNT

/*
*
*    Fun:    cmUnpkSoAcntInfo
*
*    Desc:    unpack the structure SoAcntInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcntInfo
(
SoAcntInfo *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcntInfo(param ,ptr, mBuf)
SoAcntInfo *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoAcntInfo)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->spconnId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    CMCHKUNPK(SUnpkU8, &param->origin,mBuf);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->remoteAddr, mBuf, ptr);
    CMCHKUNPKPTR(cmUnpkTknStrOSXL, &param->localAddr, mBuf, ptr);
    CMCHKUNPK(cmUnpkDuration, &param->duration,mBuf);
    CMCHKUNPK(SUnpkU8, &param->mediaType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->sdpMedia,mBuf);
    /* lso_c_001.main_4 : modified legId of SoAcntInfo to U32 */
    CMCHKUNPK(SUnpkU32, &param->legId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcntInfo*/

/*
*
*    Fun:    cmUnpkSoAcnt
*
*    Desc:    unpack the structure SoAcnt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoAcnt
(
SoAcnt *param,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoAcnt(param ,ptr, mBuf)
SoAcnt *param;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoAcnt)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    ret1 = cmUnpkSoAcntInfo(&param->acntInfo, ptr ,mBuf);
    if (ret1 != ROK)
    {
       RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoAcnt*/
#endif

/*
*
*    Fun:    cmUnpkSoTrc
*
*    Desc:    unpack the structure SoTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTrc
(
SoTrc *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTrc(param ,elmnt, mBuf)
SoTrc *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTrc)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    switch( elmnt )
    {
       case  STSIPENT :
          CMCHKUNPK(SUnpkU8, &param->t.entId,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(SUnpkS16, &param->t.tSapId,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKUNPK(SUnpkU16, &param->evnt,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTrc*/

/*
*
*    Fun:    cmUnpkSoDbgCntrl
*
*    Desc:    unpack the structure soDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoDbgCntrl
(
SoDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoDbgCntrl(param ,mBuf)
SoDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoDbgCntrl)

    CMCHKUNPK(SUnpkU32, &param->genDbgMask,mBuf);
    CMCHKUNPK(SUnpkS16, &param->entId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->entDbgMask,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoDbgCntrl*/

/*
*
*    Fun:    cmUnpkSoTrcCntrl
*
*    Desc:    unpack the structure SoTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTrcCntrl
(
SoTrcCntrl *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTrcCntrl(param ,elmnt, mBuf)
SoTrcCntrl *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTrcCntrl)

    switch( elmnt )
    {
       case  STSIPENT :
          CMCHKUNPK(SUnpkU8, &param->t.entId,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(SUnpkS16, &param->t.tSapId,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKUNPK(SUnpkS16, &param->trcLen,mBuf);
    CMCHKUNPK(SUnpkU32, &param->trcMask,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTrcCntrl*/

/*
*
*    Fun:    cmUnpkSoCacheCntrl
*
*    Desc:    unpack the structure soCacheCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCacheCntrl
(
SoCacheCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCacheCntrl(param ,mBuf)
SoCacheCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoCacheCntrl)

    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
    CMCHKUNPK(SUnpkU8, &param->entId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoCacheCntrl*/

/*
*
*    Fun:    cmUnpkSoSsapCntrl
*
*    Desc:    unpack the structure soSsapCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoSsapCntrl
(
SoSsapCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoSsapCntrl(param ,mBuf)
SoSsapCntrl *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkSoSsapCntrl)

    CMCHKUNPK(SUnpkS16, &param->sSapId,mBuf);
    for (i=0;i<LSO_TPTSRV_MAX ;i++)
    {
       CMCHKUNPK(SUnpkU32, &param->tptSrvLst[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoSsapCntrl*/

/*
*
*    Fun:    cmUnpkSoTptSrvCntrl
*
*    Desc:    unpack the structure soTptSrvCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoTptSrvCntrl
(
SoTptSrvCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoTptSrvCntrl(param ,mBuf)
SoTptSrvCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkSoTptSrvCntrl)

    CMCHKUNPK(SUnpkU32, &param->tptSrvId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->entId,mBuf);
    CMCHKUNPK(cmUnpkSoTptSrvCfg, &param->cfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkSoTptSrvCntrl*/

/*
*
*    Fun:    cmUnpkSoCntrl
*
*    Desc:    unpack the structure SoCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoCntrl
(
SoCntrl *param,
U16 elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoCntrl(param ,elmnt, mBuf)
SoCntrl *param;
U16 elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoCntrl)

    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    CMCHKUNPK(SUnpkU8, &param->action,mBuf);
    CMCHKUNPK(SUnpkU8, &param->subAction,mBuf);
    switch( param->subAction )
    {
       case  SADBG :
          switch( elmnt )
          {
             default:
#ifdef DEBUGP
                CMCHKUNPK(cmUnpkSoDbgCntrl, &param->s.dbgCntrl,mBuf);
#endif /*  DEBUGP  */
                break;
          }
          break;
       case  SAELMNT :
          switch( elmnt )
          {
             case  STALLSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STGEN :
                CMCHKUNPK(cmUnpkSoCacheCntrl, &param->s.cacheCntrl,mBuf);
                break;
             case  STGRDLSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STGRNSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STGRSSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STGRTSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STPEERSAP :
                CMCHKUNPK(SUnpkU16, &param->s.procId,mBuf);
                break;
             case  STSIPENT :
                CMCHKUNPK(SUnpkU8, &param->s.entId,mBuf);
                break;
             case  STSSAP :
                CMCHKUNPK(cmUnpkSoSsapCntrl, &param->s.sSapCntrl,mBuf);
                break;
             case  STTPTSRV :
                CMCHKUNPK(cmUnpkSoTptSrvCntrl, &param->s.tptSrvCntrl,mBuf);
                break;
             case  STTSAP :
                CMCHKUNPK(SUnpkS16, &param->s.sapId,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  SATRC :
          switch( elmnt )
          {
             default:
                ret1 = cmUnpkSoTrcCntrl(&param->s.trcCntrl, elmnt ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
          }
          break;
       default:
          switch( elmnt )
          {
             default:
                break;
          }
          break;
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoCntrl*/

/*
*
*    Fun:    cmUnpkSoMngmt
*
*    Desc:    unpack the structure SoMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSoMngmt
(
SoMngmt *param,
U8 evnt,
Ptr ptr,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSoMngmt(param ,evnt, ptr, mBuf)
SoMngmt *param;
U8 evnt;
Ptr ptr;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkSoMngmt)

    CMCHKUNPK(cmUnpkHeader, &param->hdr,mBuf);
    CMCHKUNPK(cmUnpkCmStatus, &param->cfm,mBuf);
    switch( evnt )
    {
#ifdef LSO_ACNT
       case  EVTLSOACNTCFM :
          ret1 = cmUnpkSoAcnt(&param->t.acnt, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOACNTIND :
          ret1 = cmUnpkSoAcnt(&param->t.acnt, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOACNTREQ :
          ret1 = cmUnpkSoAcnt(&param->t.acnt, ptr ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
#endif /*  LSO_ACNT  */
       case  EVTLSOCFGCFM :
          ret1 = cmUnpkSoCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCFGREQ :
          ret1 = cmUnpkSoCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCNTRLCFM :
          ret1 = cmUnpkSoCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOCNTRLREQ :
          ret1 = cmUnpkSoCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTACFM :
          /* so009.201 : Fix for packing/unpacking system id */
          ret1 = cmUnpkSoSsta(&param->t.ssta, param->hdr.elmId.elmnt, evnt, mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTAIND :
          CMCHKUNPK(cmUnpkSoUsta, &param->t.usta,mBuf);
          break;
       case  EVTLSOSTAREQ :
          /* so009.201 : Fix for packing/unpacking system id */
          ret1 = cmUnpkSoSsta(&param->t.ssta, param->hdr.elmId.elmnt, evnt, mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTSCFM :
          ret1 = cmUnpkSoSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOSTSREQ :
          ret1 = cmUnpkSoSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLSOTRCIND :
          ret1 = cmUnpkSoTrc(&param->t.trc, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkSoMngmt*/

/*
*
*    Fun:    cmUnpkLsoCfgReq
*
*    Desc:    unpack the primitive LsoCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoCfgReq
(
LsoCfgReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoCfgReq(func, pst, mBuf)
LsoCfgReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt cfg;
    
    TRC3(cmUnpkLsoCfgReq)

    ret1 = cmUnpkSoMngmt(&cfg, EVTLSOCFGREQ , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cfg));
} /*end of function cmUnpkLsoCfgReq*/

/*
*
*    Fun:    cmUnpkLsoCfgCfm
*
*    Desc:    unpack the primitive LsoCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoCfgCfm
(
LsoCfgCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoCfgCfm(func, pst, mBuf)
LsoCfgCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt cfg;
    
    TRC3(cmUnpkLsoCfgCfm)

    ret1 = cmUnpkSoMngmt(&cfg, EVTLSOCFGCFM , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cfg));
} /*end of function cmUnpkLsoCfgCfm*/

/*
*
*    Fun:    cmUnpkLsoCntrlReq
*
*    Desc:    unpack the primitive LsoCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoCntrlReq
(
LsoCntrlReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoCntrlReq(func, pst, mBuf)
LsoCntrlReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt cntrl;
    
    TRC3(cmUnpkLsoCntrlReq)

    ret1 = cmUnpkSoMngmt(&cntrl, EVTLSOCNTRLREQ , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cntrl));
} /*end of function cmUnpkLsoCntrlReq*/

/*
*
*    Fun:    cmUnpkLsoCntrlCfm
*
*    Desc:    unpack the primitive LsoCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoCntrlCfm
(
LsoCntrlCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoCntrlCfm(func, pst, mBuf)
LsoCntrlCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt cntrl;
    
    TRC3(cmUnpkLsoCntrlCfm)

    ret1 = cmUnpkSoMngmt(&cntrl, EVTLSOCNTRLCFM , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cntrl));
} /*end of function cmUnpkLsoCntrlCfm*/

/*
*
*    Fun:    cmUnpkLsoStaReq
*
*    Desc:    unpack the primitive LsoStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoStaReq
(
LsoStaReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoStaReq(func, pst, mBuf)
LsoStaReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt sta;
    
    TRC3(cmUnpkLsoStaReq)

    ret1 = cmUnpkSoMngmt(&sta, EVTLSOSTAREQ , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLsoStaReq*/

/*
*
*    Fun:    cmUnpkLsoStaCfm
*
*    Desc:    unpack the primitive LsoStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoStaCfm
(
LsoStaCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoStaCfm(func, pst, mBuf)
LsoStaCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt sta;
    /* so009.201 : Fix for packing/unpacking system id */
    Txt     systemIdPtNmb[80];

    TRC3(cmUnpkLsoStaCfm)

    /* so009.201 : Fix for packing/unpacking system id */
    sta.t.ssta.s.sysId.ptNmb = (Txt*)systemIdPtNmb;
    ret1 = cmUnpkSoMngmt(&sta, EVTLSOSTACFM , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLsoStaCfm*/

/*
*
*    Fun:    cmUnpkLsoStaInd
*
*    Desc:    unpack the primitive LsoStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoStaInd
(
LsoStaInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoStaInd(func, pst, mBuf)
LsoStaInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt sta;
    
    TRC3(cmUnpkLsoStaInd)

    ret1 = cmUnpkSoMngmt(&sta, EVTLSOSTAIND , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLsoStaInd*/

/*
*
*    Fun:    cmUnpkLsoStsReq
*
*    Desc:    unpack the primitive LsoStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoStsReq
(
LsoStsReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoStsReq(func, pst, mBuf)
LsoStsReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Action action;
    SoMngmt sts;
    
    TRC3(cmUnpkLsoStsReq)

    CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ELSOXXX, pst);
    ret1 = cmUnpkSoMngmt(&sts, EVTLSOSTSREQ , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, action, &sts));
} /*end of function cmUnpkLsoStsReq*/

/*
*
*    Fun:    cmUnpkLsoStsCfm
*
*    Desc:    unpack the primitive LsoStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoStsCfm
(
LsoStsCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoStsCfm(func, pst, mBuf)
LsoStsCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt sts;
    
    TRC3(cmUnpkLsoStsCfm)

    ret1 = cmUnpkSoMngmt(&sts, EVTLSOSTSCFM , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sts));
} /*end of function cmUnpkLsoStsCfm*/

/*
*
*    Fun:    cmUnpkLsoTrcInd
*
*    Desc:    unpack the primitive LsoTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoTrcInd
(
LsoTrcInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsoTrcInd(func, pst, mBuf)
LsoTrcInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    SoMngmt trc;
    
    TRC3(cmUnpkLsoTrcInd)

    ret1 = cmUnpkSoMngmt(&trc, EVTLSOTRCIND , NULLP ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    RETVALUE((*func)(pst, &trc, mBuf));
} /*end of function cmUnpkLsoTrcInd*/

/*
*
*    Fun:    cmUnpkLsoAcntReq
*
*    Desc:    unpack the primitive LsoAcntReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoAcntReq
(
LsoAcntReq func,
Pst *pst,
Buffer *mBuf,
CmMemListCp *mPtr
)
#else
PUBLIC S16 cmUnpkLsoAcntReq(func, pst, mBuf,  mPtr)
LsoAcntReq func;
Pst *pst;
Buffer *mBuf;
CmMemListCp *mPtr;
#endif
{
    S16 ret1;
    SoMngmt acnt;
    
    TRC3(cmUnpkLsoAcntReq)

    ret1 = cmUnpkSoMngmt(&acnt, EVTLSOACNTREQ , mPtr ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &acnt));
} /*end of function cmUnpkLsoAcntReq*/

/*
*
*    Fun:    cmUnpkLsoAcntCfm
*
*    Desc:    unpack the primitive LsoAcntCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoAcntCfm
(
LsoAcntCfm func,
Pst *pst,
Buffer *mBuf,
CmMemListCp *mPtr
)
#else
PUBLIC S16 cmUnpkLsoAcntCfm(func, pst, mBuf,  mPtr)
LsoAcntCfm func;
Pst *pst;
Buffer *mBuf;
CmMemListCp *mPtr;
#endif
{
    S16 ret1;
    SoMngmt acnt;
    
    TRC3(cmUnpkLsoAcntCfm)

    ret1 = cmUnpkSoMngmt(&acnt, EVTLSOACNTCFM , mPtr ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &acnt));
} /*end of function cmUnpkLsoAcntCfm*/

/*
*
*    Fun:    cmUnpkLsoAcntInd
*
*    Desc:    unpack the primitive LsoAcntInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lso.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsoAcntInd
(
LsoAcntInd func,
Pst *pst,
Buffer *mBuf,
CmMemListCp *mPtr
)
#else
PUBLIC S16 cmUnpkLsoAcntInd(func, pst, mBuf,  mPtr)
LsoAcntInd func;
Pst *pst;
Buffer *mBuf;
CmMemListCp *mPtr;
#endif
{
    S16 ret1;
    SoMngmt acnt;
    
    TRC3(cmUnpkLsoAcntInd)

    ret1 = cmUnpkSoMngmt(&acnt, EVTLSOACNTIND , mPtr ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELSOXXX, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &acnt));
} /*end of function cmUnpkLsoAcntInd*/


#endif /* #if(defined(LCLSO) || defined(LWLCLSO)) */

/* __extern */








/********************************************************************30**

         End of file:     lso.c@@/main/4 - Tue Apr 20 12:45:37 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/4      ---         pg    1. initial release.
/main/4+     so007.201   ab    1. Addedpacking & unpacking of new
                                  parameter rejReInvOnUARestart in
                                  UA recfg
/main/4+     so009.201   up    1. Fix for packing/unpacking system id
/main/4+     so010.201   ab    1. Added timer configuration to tpt server
/main/4+     so027.201   ab    1. Changes for SIP TLS support
/main/4+     lso_c_001.main_4   ng    1. Addedpacking & unpacking of new
                                  parameter rejOnUARestart in
                                  UA recfg
/main/4+ lso_c_001.main_4   ng    1. Modified legId of SoAcntInfo to U32
*********************************************************************91*/
