/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     layer management - portable
  
     Type:     C include file
  
     Desc:     Structures, variables and typedefs required by the
               Layer Management service user.

     File:     lsi.c
  
     Sid:      lsi.c@@/main/7 - Wed Mar 14 15:30:54 2001

     Prg:      bn
 
*********************************************************************21*/

  
/*
*     The structures and variables declared in this file
*     correspond to structures and variables used by
*     the following TRILLIUM software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000029     Signalling System 7 - ISUP
*
*/
 
/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000029     Signalling System 7 - ISUP
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options     */  
#include "envdep.h"        /* environment dependent   */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer           */
#include "ssi.h"           /* system services         */
#include "cm_ss7.h"        /* common SS7 definitions  */
#include "lsi.h"           /* ISUP layer mgmt defines */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer           */
#include "ssi.x"           /* system services         */
#include "cm_ss7.x"        /* general SS7 layer       */
#include "lsi.x"           /* ISUP layer manager      */


/* local defines */

/* local typedefs */
  
/* local externs */
EXTERN TskInit siInit;  /* extern declaration for ISUP taskinit structure */

/* forward references */
#ifdef LCLSI /* if LSI interface is loosely coupled */

/* INTERFACE STRUCTURE PACKING/UNPACKING FUNCTIONS */
PRIVATE S16 cmPkSiCirGrTmrCfg   ARGS((SiCirGrTmrCfg *cirGrTmrCfg, 
                                      Buffer        *mBuf));
PRIVATE S16 cmUnpkSiCirGrTmrCfg ARGS((SiCirGrTmrCfg *cirGrTmrCfg,
                                      Buffer        *mBuf));
PRIVATE S16 cmPkSiGenCfg        ARGS((SiGenCfg    *genCfg,      Buffer *mBuf));
/* si009.220 - Modified: to pass pst structure for function cmUnpkSiGenCfg */
PRIVATE S16 cmUnpkSiGenCfg      ARGS((SiGenCfg    *genCfg,      Buffer *mBuf, 
                                     Pst *pst));
PRIVATE S16 cmPkSiTmrCfg        ARGS((SiTmrCfg    *siTmrCfg,    Buffer *mBuf));
PRIVATE S16 cmUnpkSiTmrCfg      ARGS((SiTmrCfg    *siTmrCfg,    Buffer *mBuf));
PRIVATE S16 cmPkSiCirTmrCfg     ARGS((SiCirTmrCfg *siCirTmrCfg, Buffer *mBuf));
PRIVATE S16 cmUnpkSiCirTmrCfg   ARGS((SiCirTmrCfg *siCirTmrCfg, Buffer *mBuf));
PRIVATE S16 cmPkSiSAPCfg        ARGS((SiSAPCfg    *siSAPCfg,    Buffer *mBuf));
PRIVATE S16 cmUnpkSiSAPCfg      ARGS((SiSAPCfg    *siSAPCfg,    Buffer *mBuf));
PRIVATE S16 cmPkSiNSAPCfg       ARGS((SiNSAPCfg   *siNSAPCfg,   Buffer *mBuf));
PRIVATE S16 cmUnpkSiNSAPCfg     ARGS((SiNSAPCfg   *siNSAPCfg,   Buffer *mBuf));
#ifdef SI_218_COMP
PRIVATE S16 cmPkSiRoutCfg       ARGS((SiRoutCfg   *siRoutCfg,   Buffer *mBuf));
PRIVATE S16 cmUnpkSiRoutCfg     ARGS((SiRoutCfg   *siRoutCfg,   Buffer *mBuf));
#endif
PRIVATE S16 cmPkSiCirCfg        ARGS((SiCirCfg    *siCirCfg,    Buffer *mBuf));
PRIVATE S16 cmUnpkSiCirCfg      ARGS((SiCirCfg    *siCirCfg,    Buffer *mBuf));
PRIVATE S16 cmPkSiIntfCbTmrCfg   ARGS((SiDpcCbTmrCfg *siDpcCbTmrCfg, 
                                      Buffer      *mBuf));
PRIVATE S16 cmUnpkSiIntfCbTmrCfg ARGS((SiDpcCbTmrCfg *siDpcCbTmrCfg, 
                                      Buffer        *mBuf));
PRIVATE S16 cmPkSiIntfCbCfg      ARGS((SiIntfCbCfg *siIntfCbCfg, Buffer *mBuf));
/* si025.220: modification - added post argument in cmUnpkSiIntfCbCfg */
PRIVATE S16 cmUnpkSiIntfCbCfg    ARGS((SiIntfCbCfg *siIntfCbCfg, Buffer *mBuf, Pst *pst));
PRIVATE S16 cmPkSiCfg           ARGS((SiMngmt    *cfg,        Buffer *mBuf));
/* si009.220 - Modified: to pass pst structure */
PRIVATE S16 cmUnpkSiCfg         ARGS((SiMngmt    *cfg,        Buffer *mBuf, 
                                      Pst *pst));

#if (SI_LMINT3 || SMSI_LMINT3)
PRIVATE S16 cmPkSiIntfSts       ARGS((SiIntfSts   *siIntfSts,   Buffer *mBuf));
PRIVATE S16 cmUnpkSiIntfSts      ARGS((SiIntfSts   *siIntfSts,   Buffer *mBuf));
PRIVATE S16 cmPkSiPduSts        ARGS((SiPduSts   *siPduSts,   Buffer *mBuf));
PRIVATE S16 cmUnpkSiPduSts      ARGS((SiPduSts   *siPduSts,   Buffer *mBuf));
#else
PRIVATE S16 cmPkSiNSAPSts       ARGS((SiNSAPSts  *siNSAPSts,  Buffer *mBuf));
PRIVATE S16 cmUnpkSiNSAPSts     ARGS((SiNSAPSts  *siNSAPSts,  Buffer *mBuf));
#endif
PRIVATE S16 cmPkSiCirSts        ARGS((SiCirSts   *siCirSts,   Buffer *mBuf));
PRIVATE S16 cmUnpkSiCirSts      ARGS((SiCirSts   *siCirSts,   Buffer *mBuf));
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */
/* si007.220 - Modified: add TDS_ROLL_UPGRADE_SUPPORT and LSIV2 flag for these
 * two functions.
 */
/* si006.220, MODIFIED: remove the TDS_ROLL_UPGRADE_SUPPORT flag and add pst as
 * an arguement
 */
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
PRIVATE S16 cmPkSiSAPSta        ARGS((SiSAPSta *sta, Buffer *mBuf, Pst *pst));
PRIVATE S16 cmUnpkSiSAPSta      ARGS((SiSAPSta *sta, Buffer *mBuf, Pst *pst));
#endif

/*
*
*       Fun:   cmPkSiCirGrTmrCfg
*
*       Desc:  Pack circuit group timer configuration structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCirGrTmrCfg 
(
SiCirGrTmrCfg *cirGrTmrCfg,
Buffer        *mBuf
)
#else
PRIVATE S16 cmPkSiCirGrTmrCfg (cirGrTmrCfg, mBuf)
SiCirGrTmrCfg *cirGrTmrCfg;
Buffer        *mBuf;
#endif
{
   TRC2(cmPkSiCirGrTmrCfg)

#ifdef SI_218_COMP
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->tGRES, mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->tFGR, mBuf);
#endif
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t28, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t23, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t22, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t21, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t20, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t19, mBuf);
   CMCHKPK(cmPkTmrCfg, &cirGrTmrCfg->t18, mBuf);

   RETVALUE(ROK);
}/* cmPkSiCirGrTmrCfg */


/*
*
*       Fun:   cmUnpkSiCirGrTmrCfg
*
*       Desc:  Unpack circuit group timer configuration structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiCirGrTmrCfg 
(
SiCirGrTmrCfg *cirGrTmrCfg,
Buffer        *mBuf
)
#else
PRIVATE S16 cmUnpkSiCirGrTmrCfg (cirGrTmrCfg, mBuf)
SiCirGrTmrCfg *cirGrTmrCfg;
Buffer        *mBuf;
#endif
{
   TRC2(cmUnpkSiCirGrTmrCfg)

   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t18, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t19, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t20, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t21, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t22, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t23, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->t28, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->tFGR, mBuf);
#endif
#ifdef SI_218_COMP
   CMCHKUNPK(cmUnpkTmrCfg, &cirGrTmrCfg->tGRES, mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiCirGrTmrCfg */


/*
*
*       Fun:   cmPkSiGenCfg   
*
*       Desc:  Pack ISUP general configuration structure 
*              
*       Ret:  ROK - ok; RFAILED - failed; 
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiGenCfg 
(
SiGenCfg *genCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiGenCfg (genCfg, mBuf)
SiGenCfg *genCfg;
Buffer   *mBuf;
#endif
{
   TRC2(cmPkSiGenCfg)

   CMCHKPK(cmPkPst,           &genCfg->sm,         mBuf);
   CMCHKPK(cmPkSiCirGrTmrCfg, &genCfg->cirGrTmr,   mBuf);
   CMCHKPK(cmPkStatus,        genCfg->poolTrLower, mBuf);
   CMCHKPK(cmPkStatus,        genCfg->poolTrUpper, mBuf);
   /* si025.220: Modification - added LSIV4 */
   /* si009, ADDED: added the field for lnkSelOpt */
#if (LSIV3 || LSIV4)
   CMCHKPK(SPkU8,             genCfg->lnkSelOpt,   mBuf);
#endif
   CMCHKPK(cmPkBool,          genCfg->sccpSup,     mBuf);
   CMCHKPK(SPkS16,            genCfg->timeRes,     mBuf);
#ifdef SI_218_COMP
   CMCHKPK(SPkU16,            genCfg->nmbRouts,    mBuf);
#endif
   CMCHKPK(SPkU32,            genCfg->nmbCalRef,   mBuf);
   CMCHKPK(SPkU16,            genCfg->nmbCirGrp,   mBuf);
   CMCHKPK(SPkU16,            genCfg->nmbIntf,     mBuf);
   CMCHKPK(SPkU32,            genCfg->nmbCir,      mBuf);
   CMCHKPK(SPkU16,            genCfg->nmbNSaps,    mBuf);
   CMCHKPK(SPkU16,            genCfg->nmbSaps,     mBuf);

   RETVALUE(ROK);
}/* cmPkSiGenCfg */


/* si009.220 - Modified: to pass pst structure and add transaction fucntion
 * for a new field lnkSelOpt.
 */
/*
*
*       Fun:   cmUnpkSiGenCfg
*
*       Desc:  Unpack ISUP gen config structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiGenCfg 
(
SiGenCfg *genCfg,
Buffer   *mBuf,
Pst      *pst
)
#else
PRIVATE S16 cmUnpkSiGenCfg (genCfg, mBuf, pst)
SiGenCfg *genCfg;
Buffer   *mBuf;
Pst      *pst;
#endif
{
   CmIntfVer   intfVer;       /* interface version */

   TRC2(cmUnpkSiGenCfg)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = LSIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:
      case 0x0200:
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbSaps,     mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbNSaps,    mBuf);
         CMCHKUNPK(SUnpkU32,            &genCfg->nmbCir,      mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbIntf,     mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbCirGrp,   mBuf);
         CMCHKUNPK(SUnpkU32,            &genCfg->nmbCalRef,   mBuf);
#ifdef SI_218_COMP
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbRouts,    mBuf);
#endif
         CMCHKUNPK(SUnpkS16,            &genCfg->timeRes,     mBuf);
         CMCHKUNPK(cmUnpkBool,          &genCfg->sccpSup,     mBuf);
/* si025.220: modification - added LSIV4 */
#if (LSIV3 || LSIV4)
         /* assign a default value of load distribution */
         genCfg->lnkSelOpt = LSI_LNKSEL_LD_DISTR;
#endif   
         CMCHKUNPK(cmUnpkStatus,        &genCfg->poolTrUpper, mBuf);
         CMCHKUNPK(cmUnpkStatus,        &genCfg->poolTrLower, mBuf);
         CMCHKUNPK(cmUnpkSiCirGrTmrCfg, &genCfg->cirGrTmr,    mBuf);
         CMCHKUNPK(cmUnpkPst,           &genCfg->sm,          mBuf);
         break;

      case 0x0300:
      /* si025.220: Addition - added case 0x0400 for LSIV4 */
      case 0x0400:
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbSaps,     mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbNSaps,    mBuf);
         CMCHKUNPK(SUnpkU32,            &genCfg->nmbCir,      mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbIntf,     mBuf);
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbCirGrp,   mBuf);
         CMCHKUNPK(SUnpkU32,            &genCfg->nmbCalRef,   mBuf);
#ifdef SI_218_COMP
         CMCHKUNPK(SUnpkU16,            &genCfg->nmbRouts,    mBuf);
#endif
         CMCHKUNPK(SUnpkS16,            &genCfg->timeRes,     mBuf);
         CMCHKUNPK(cmUnpkBool,          &genCfg->sccpSup,     mBuf);
#if (LSIV3 || LSIV4)
         CMCHKUNPK(SUnpkU8,             &genCfg->lnkSelOpt,   mBuf);
#endif   
         CMCHKUNPK(cmUnpkStatus,        &genCfg->poolTrUpper, mBuf);
         CMCHKUNPK(cmUnpkStatus,        &genCfg->poolTrLower, mBuf);
         CMCHKUNPK(cmUnpkSiCirGrTmrCfg, &genCfg->cirGrTmr,    mBuf);
         CMCHKUNPK(cmUnpkPst,           &genCfg->sm,          mBuf);
         break;

      default:
        /* invalid interface version number */
        RETVALUE(RINVIFVER);
   } /* end of switch */

   RETVALUE(ROK);
}/* cmUnpkSiGenCfg */


/*
*
*       Fun:   cmPkSiTmrCfg
*
*       Desc:  Pack ISUP connection timers configuration structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiTmrCfg 
(
SiTmrCfg *siTmrCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiTmrCfg (siTmrCfg, mBuf)
SiTmrCfg *siTmrCfg;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS92
   bitVector |= LSI_SS7_ANS92_BIT;
#endif /* SS7_ANS92 */
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= LSI_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSI
   bitVector |= LSI_SS7_ETSI_BIT;
#endif
#ifdef SS7_ETSIV3
   bitVector |= LSI_SS7_ETSIV3_BIT;
#endif
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiTmrCfg)

   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tFNLRELRSP, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tRELRSP,    mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t36, mBuf);
#if SS7_FTZ
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tGTCHG, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tECT, mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tCCRt, mBuf);
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tCRM, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tCRA, mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tEx, mBuf);
#endif
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t34, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t27, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->tCCR, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t33, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t31, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t9, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t8, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t7, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t6, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t5, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t2, mBuf);
   CMCHKPK(cmPkTmrCfg, &siTmrCfg->t1, mBuf);
   /* si001.220, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8,           bitVector,             mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiTmrCfg */


/*
*
*       Fun:   cmUnpkSiTmrCfg
*
*       Desc:  Unpack ISUP connection timers configuration structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiTmrCfg 
(
SiTmrCfg *siTmrCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiTmrCfg (siTmrCfg, mBuf)
SiTmrCfg *siTmrCfg;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiTmrCfg)

   /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8, &bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t1, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t2, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t5, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t6, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t7, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t8, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t9, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t31, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t33, mBuf);

   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCCR, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t27, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t34, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tEx, mBuf);
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* si001.220, MODIFIED: changes for ISUP rollup */
   /* Variant flag is defined at the destination, unpacking will be done 
    * only if the orignator indicates that is has packed the parameter 
    * (determined from the bit vector). If not send by orignator we 
    * mark the timer as disable.
    */
/* si004.220, MODIFIED: correction for SS7_BELL variant flag */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
#ifndef SS7_BELL
   if ((bitVector & LSI_SS7_ANS92_BIT) || (bitVector & LSI_SS7_ANS95_BIT))
#endif /* SS7_BELL */
   {
      CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCRA, mBuf);
      CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCRM, mBuf);
   }
#ifndef SS7_BELL
   else
   {
      siTmrCfg->tCRA.enb = FALSE;
      siTmrCfg->tCRM.enb = FALSE;
   }
#endif /* SS7_BELL */
#else
   /* No rolling upgrade support so we rely on the flag alone */
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCRA, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCRM, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* the compile time flag is not defined at destination but may be 
    * defined at origiator. If so we unpack and discard the parameter
    */
   if ((bitVector & LSI_SS7_ANS92_BIT) || (bitVector & LSI_SS7_ANS95_BIT))
   {
      TmrCfg tempTmr;
      CMCHKUNPK(cmUnpkTmrCfg, &tempTmr, mBuf);
      CMCHKUNPK(cmUnpkTmrCfg, &tempTmr, mBuf);
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tCCRt, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ITU97_BIT) || (bitVector & LSI_SS7_ETSI_BIT) || 
       (bitVector & LSI_SS7_ETSIV3_BIT))
   {
      CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tECT, mBuf);
   }
   else
   {
      siTmrCfg->tECT.enb = FALSE;
   }
#else
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tECT, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & LSI_SS7_ITU97_BIT) 
   {
      TmrCfg tempTmr;
      CMCHKUNPK(cmUnpkTmrCfg, &tempTmr, mBuf);
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if SS7_FTZ
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tGTCHG, mBuf);
#endif
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->t36, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tRELRSP,    mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siTmrCfg->tFNLRELRSP, mBuf);

   RETVALUE(ROK);
}/* cmUnpkSiTmrCfg */


/*
*
*       Fun:   cmPkSiCirTmrCfg
*
*       Desc:  Pack ISUP circuit timers configuration into an mBuf
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCirTmrCfg 
(
SiCirTmrCfg *siCirTmrCfg,
Buffer      *mBuf
)
#else
PRIVATE S16 cmPkSiCirTmrCfg (siCirTmrCfg, mBuf)
SiCirTmrCfg *siCirTmrCfg;
Buffer      *mBuf;
#endif
{
   TRC2(cmPkSiCirTmrCfg)

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->tVal, mBuf);
#endif
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t17, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t16, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t15, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t14, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t13, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t12, mBuf);
   CMCHKPK(cmPkTmrCfg, &siCirTmrCfg->t3,  mBuf);

   RETVALUE(ROK);
}/* cmPkSiCirTmrCfg */


/*
*
*       Fun:   cmUnpkSiCirTmrCfg
*
*       Desc:  Unpack the contents of mBuf into ISUP circuit timer 
*              configuration
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiCirTmrCfg 
(
SiCirTmrCfg *siCirTmrCfg,
Buffer      *mBuf
)
#else
PRIVATE S16 cmUnpkSiCirTmrCfg (siCirTmrCfg, mBuf)
SiCirTmrCfg *siCirTmrCfg;
Buffer      *mBuf;
#endif
{
   TRC2(cmUnpkSiCirTmrCfg)

   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t3, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t12, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t13, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t14, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t15, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t16, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->t17, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkTmrCfg, &siCirTmrCfg->tVal, mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiCirTmrCfg */


/*
*
*       Fun:   cmPkSiSAPCfg
*
*       Desc:  Pack the contents of an ISUP SAP configuration structure into
*              a message buffer
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiSAPCfg 
(
SiSAPCfg *siSAPCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiSAPCfg (siSAPCfg, mBuf)
SiSAPCfg *siSAPCfg;
Buffer   *mBuf;
#endif
{
#ifdef SI_218_COMP
   int i;
#endif

   TRC2(cmPkSiSAPCfg)

   /* si001.220, ADDED: Changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer,  siSAPCfg->remIntfVer,    mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->remIntfValid,  mBuf);
#endif
   CMCHKPK(cmPkMemoryId, &siSAPCfg->mem,          mBuf);
   CMCHKPK(cmPkSelector, siSAPCfg->selector,      mBuf);
   CMCHKPK(cmPkRoute,    siSAPCfg->route,         mBuf);
   CMCHKPK(cmPkPrior,    siSAPCfg->prior,         mBuf);
   CMCHKPK(cmPkSiTmrCfg, &siSAPCfg->tmr,          mBuf);
   CMCHKPK(SPkU8,        siSAPCfg->relLocation,   mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->passOnFlag,    mBuf);
   CMCHKPK(SPkU8,        siSAPCfg->maxLenU2U,     mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->allCallMod,    mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->reqOpt,        mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->sidPresRes,    mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->incSidPresRes, mBuf);
   CMCHKPK(SPkU8,        siSAPCfg->sidPresInd,    mBuf);
   CMCHKPK(SPkU8,        siSAPCfg->sidNPlan,      mBuf);
   CMCHKPK(SPkU8,        siSAPCfg->natAddrInd,    mBuf);
   CMCHKPK(cmPkAddrs,    &siSAPCfg->sid,          mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->sidVer,        mBuf);
   CMCHKPK(cmPkBool,     siSAPCfg->sidIns,        mBuf);
#ifdef SI_218_COMP
   for (i = ADRLEN; i != 0; i--)
   {
      CMCHKPK(SPkU8,     siSAPCfg->wcMask[i - 1], mBuf);
   }
   CMCHKPK(cmPkBool,     siSAPCfg->wcRout,        mBuf);
#endif
   CMCHKPK(SPkU8,        siSAPCfg->ssf,       mBuf);
   CMCHKPK(cmPkSwtch,    siSAPCfg->swtch,         mBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKPK(cmPkSpId,     siSAPCfg->sapId,         mBuf);
#endif

   RETVALUE(ROK);
}/* cmPkSiSAPCfg */


/*
*
*       Fun:   cmUnpkSiSAPCfg
*
*       Desc:  Unpack the contents of a message buffer into an ISUP SAP 
*              configuration structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiSAPCfg 
(
SiSAPCfg *siSAPCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiSAPCfg (siSAPCfg, mBuf)
SiSAPCfg *siSAPCfg;
Buffer   *mBuf;
#endif
{
#ifdef SI_218_COMP
   Cntr i;
#endif

   TRC2(cmUnpkSiSAPCfg)

#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKUNPK(cmUnpkSpId,     &siSAPCfg->sapId,         mBuf);
#endif
   CMCHKUNPK(cmUnpkSwtch,    &siSAPCfg->swtch,         mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->ssf,        mBuf);
#ifdef SI_218_COMP
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->wcRout,        mBuf);
   for (i = 0; i < ADRLEN; i++)
   {
      CMCHKUNPK(SUnpkU8,     &siSAPCfg->wcMask[i],     mBuf);
   }
#endif
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->sidIns,        mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->sidVer,        mBuf);
   CMCHKUNPK(cmUnpkAddrs,    &siSAPCfg->sid,           mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->natAddrInd,    mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->sidNPlan,      mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->sidPresInd,    mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->incSidPresRes, mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->sidPresRes,    mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->reqOpt,        mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->allCallMod,    mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->maxLenU2U,     mBuf);
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->passOnFlag,    mBuf);
   CMCHKUNPK(SUnpkU8,        &siSAPCfg->relLocation,   mBuf);
   CMCHKUNPK(cmUnpkSiTmrCfg, &siSAPCfg->tmr,           mBuf);
   CMCHKUNPK(cmUnpkPrior,    &siSAPCfg->prior,         mBuf);
   CMCHKUNPK(cmUnpkRoute,    &siSAPCfg->route,         mBuf);
   CMCHKUNPK(cmUnpkSelector, &siSAPCfg->selector,      mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &siSAPCfg->mem,           mBuf);
   /* si001.220, ADDED: Changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(cmUnpkBool,     &siSAPCfg->remIntfValid,  mBuf);
   CMCHKUNPK(cmUnpkIntfVer,  &siSAPCfg->remIntfVer,    mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiSAPCfg */


/*
*
*       Fun:   cmPkSiNSAPCfg
*
*       Desc:  Pack the contents of an ISUP n/w SAP configuration structure 
*              into message buffer
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiNSAPCfg 
(
SiNSAPCfg *siNSAPCfg,
Buffer    *mBuf
)
#else
PRIVATE S16 cmPkSiNSAPCfg (siNSAPCfg, mBuf)
SiNSAPCfg *siNSAPCfg;
Buffer    *mBuf;
#endif
{
   TRC2(cmPkSiNSAPCfg)

   /* si001.220, ADDED: Changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer,  siNSAPCfg->remIntfVer,   mBuf);
   CMCHKPK(cmPkBool,     siNSAPCfg->remIntfValid, mBuf);
#endif
   CMCHKPK(cmPkMemoryId, &siNSAPCfg->mem,      mBuf);
   CMCHKPK(cmPkTmrCfg,   &siNSAPCfg->tINT,     mBuf);
   CMCHKPK(cmPkSelector, siNSAPCfg->selector,  mBuf);
#ifdef SI_218_COMP
   CMCHKPK(cmPkDpc,      siNSAPCfg->dfltOpc,   mBuf);
   CMCHKPK(SPkU8,        siNSAPCfg->numResInd, mBuf);
#endif
   CMCHKPK(SPkS16,       siNSAPCfg->sapType,   mBuf);
   CMCHKPK(cmPkProcId,   siNSAPCfg->dstProcId, mBuf);
   CMCHKPK(cmPkRoute,    siNSAPCfg->route,     mBuf);
   CMCHKPK(cmPkPriority, siNSAPCfg->prior,     mBuf);
   CMCHKPK(cmPkInst,     siNSAPCfg->dstInst,   mBuf);
   CMCHKPK(cmPkEnt,      siNSAPCfg->dstEnt,    mBuf);
   CMCHKPK(SPkU8,        siNSAPCfg->ssf,       mBuf);
   CMCHKPK(cmPkSpId,     siNSAPCfg->spId,      mBuf);
   CMCHKPK(cmPkSiInstId, siNSAPCfg->nwId,      mBuf);
#ifdef SI_218_COMP
   CMCHKPK(cmPkSwtch,    siNSAPCfg->swtch,     mBuf);
#endif 
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKPK(cmPkSpId,     siNSAPCfg->nsapId,         mBuf);
#endif

   RETVALUE(ROK);
}/* cmPkSiNSAPCfg */


/*
*
*       Fun:   cmUnpkSiNSAPCfg
*
*       Desc:  Unpack the contents of message buffer into ISUP n/w SAP cfg.
*              structure
*              
*       Ret:  ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiNSAPCfg 
(
SiNSAPCfg *siNSAPCfg,
Buffer    *mBuf
)
#else
PRIVATE S16 cmUnpkSiNSAPCfg (siNSAPCfg, mBuf)
SiNSAPCfg *siNSAPCfg;
Buffer    *mBuf;
#endif
{
   TRC2(cmUnpkSiNSAPCfg)

#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKUNPK(cmUnpkSpId,     &siNSAPCfg->nsapId,     mBuf);
#endif
#ifdef SI_218_COMP
   CMCHKUNPK(cmUnpkSwtch,    &siNSAPCfg->swtch,     mBuf);
#endif 
   CMCHKUNPK(cmUnpkSiInstId, &siNSAPCfg->nwId,      mBuf);
   CMCHKUNPK(cmUnpkSpId,     &siNSAPCfg->spId,      mBuf);
   CMCHKUNPK(SUnpkU8,        &siNSAPCfg->ssf,       mBuf);
   CMCHKUNPK(cmUnpkEnt,      &siNSAPCfg->dstEnt,    mBuf);
   CMCHKUNPK(cmUnpkInst,     &siNSAPCfg->dstInst,   mBuf);
   CMCHKUNPK(cmUnpkPriority, &siNSAPCfg->prior,     mBuf);
   CMCHKUNPK(cmUnpkRoute,    &siNSAPCfg->route,     mBuf);
   CMCHKUNPK(cmUnpkProcId,   &siNSAPCfg->dstProcId, mBuf);
   CMCHKUNPK(SUnpkS16,       &siNSAPCfg->sapType,   mBuf);
#ifdef SI_218_COMP
   CMCHKUNPK(SUnpkU8,        &siNSAPCfg->numResInd, mBuf);
   CMCHKUNPK(cmUnpkDpc,      &siNSAPCfg->dfltOpc,   mBuf);
#endif
   CMCHKUNPK(cmUnpkSelector, &siNSAPCfg->selector,  mBuf);
   CMCHKUNPK(cmUnpkTmrCfg,   &siNSAPCfg->tINT,     mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &siNSAPCfg->mem,       mBuf);
   /* si001.220, ADDED: Changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(cmUnpkBool,     &siNSAPCfg->remIntfValid,  mBuf);
   CMCHKUNPK(cmUnpkIntfVer,  &siNSAPCfg->remIntfVer,    mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiNSAPCfg */

#ifdef SI_218_COMP

/*
*
*       Fun:   cmPkSiRoutCfg
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiRoutCfg 
(
SiRoutCfg *siRoutCfg,
Buffer    *mBuf
)
#else
PRIVATE S16 cmPkSiRoutCfg (siRoutCfg, mBuf)
SiRoutCfg *siRoutCfg;
Buffer    *mBuf;
#endif
{
   Cntr i;

   TRC2(cmPkSiRoutCfg)

   CMCHKPK(cmPkBool,     siRoutCfg->loadShar,            mBuf);
   for (i = siRoutCfg->nmbDpc; i != 0; i--)
   {
      CMCHKPK(cmPkPrior,    siRoutCfg->dst[i - 1].priority, mBuf);
      CMCHKPK(cmPkBool,     siRoutCfg->dst[i - 1].isupAv,   mBuf);
      CMCHKPK(cmPkSiInstId, siRoutCfg->dst[i - 1].nwId,     mBuf);
      CMCHKPK(cmPkDpc,      siRoutCfg->dst[i - 1].phyDpc,   mBuf);
   }
   CMCHKPK(SPkS16,       siRoutCfg->nmbDpc,              mBuf);
   CMCHKPK(cmPkDpc,      siRoutCfg->opc,                 mBuf);
   CMCHKPK(cmPkAddrs,    &siRoutCfg->addr,               mBuf);

   RETVALUE(ROK);
}/* cmPkSiRoutCfg */


/*
*
*       Fun: cmUnpkSiRoutCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiRoutCfg 
(
SiRoutCfg *siRoutCfg,
Buffer    *mBuf
)
#else
PRIVATE S16 cmUnpkSiRoutCfg (siRoutCfg, mBuf)
SiRoutCfg *siRoutCfg;
Buffer    *mBuf;
#endif
{
   Cntr i;

   TRC2(cmUnpkSiRoutCfg)

   CMCHKUNPK(cmUnpkAddrs,    &siRoutCfg->addr,            mBuf);
   CMCHKUNPK(cmUnpkDpc,      &siRoutCfg->opc,             mBuf);
   CMCHKUNPK(SUnpkS16,       &siRoutCfg->nmbDpc,          mBuf);
   for (i = 0; i < siRoutCfg->nmbDpc; i++)
   {
      CMCHKUNPK(cmUnpkDpc,      &siRoutCfg->dst[i].phyDpc,   mBuf);
      CMCHKUNPK(cmUnpkSiInstId, &siRoutCfg->dst[i].nwId,     mBuf);
      CMCHKUNPK(cmUnpkBool,     &siRoutCfg->dst[i].isupAv,   mBuf);
      CMCHKUNPK(cmUnpkPrior,    &siRoutCfg->dst[i].priority, mBuf);
   }
   CMCHKUNPK(cmUnpkBool,     &siRoutCfg->loadShar,        mBuf);

   RETVALUE(ROK);
}/* cmUnpkSiRoutCfg */
#endif


/*
*
*       Fun: cmPkSiCirCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCirCfg 
(
SiCirCfg *siCirCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiCirCfg (siCirCfg, mBuf)
SiCirCfg *siCirCfg;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= LSI_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSIV3
   bitVector |= LSI_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiCirCfg)

#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(SPkU8,           siCirCfg->ctrlMult,    mBuf);
   CMCHKPK(SPkU8,           siCirCfg->slotId,      mBuf);
#endif
   CMCHKPK(cmPkSiCirTmrCfg, &siCirCfg->cirTmr,     mBuf);
#if (SI_218_COMP || SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkAddrs,       &siCirCfg->clli,       mBuf);
   CMCHKPK(cmPkAddrs,       &siCirCfg->cvrTrkClli, mBuf);
   CMCHKPK(cmPkAddrs,       &siCirCfg->outTrkGrpN, mBuf);
   CMCHKPK(cmPkBool,        siCirCfg->nonSS7Con,   mBuf);
   CMCHKPK(SPkU8,           siCirCfg->numCir,      mBuf);
   CMCHKPK(cmPkCic,         siCirCfg->firstCic,    mBuf);
#endif
   CMCHKPK(cmPkBool,        siCirCfg->contReq,     mBuf);
   CMCHKPK(SPkU16,          siCirCfg->cirFlg,      mBuf);
#ifdef SI_218_COMP
   CMCHKPK(SPkU8,           siCirCfg->bearProf,    mBuf);
#endif
   CMCHKPK(SPkU8,           siCirCfg->typeCntrl,   mBuf);
   CMCHKPK(cmPkSiInstId,    siCirCfg->intfId,      mBuf);
   CMCHKPK(cmPkCic,         siCirCfg->cic,         mBuf);
   CMCHKPK(cmPkCirId,       siCirCfg->cirId,       mBuf);
   /* si001.220, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8,           bitVector,             mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiCirCfg */


/*
*
*       Fun: cmUnpkSiCirCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiCirCfg 
(
SiCirCfg *siCirCfg,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiCirCfg (siCirCfg, mBuf)
SiCirCfg *siCirCfg;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiCirCfg)

   /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8,           &bitVector,            mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkCirId,       &siCirCfg->cirId,      mBuf);
   CMCHKUNPK(cmUnpkCic,         &siCirCfg->cic,        mBuf);
   CMCHKUNPK(cmUnpkSiInstId,    &siCirCfg->intfId,     mBuf);
   CMCHKUNPK(SUnpkU8,           &siCirCfg->typeCntrl,  mBuf);
#ifdef SI_218_COMP
   CMCHKUNPK(SUnpkU8,           &siCirCfg->bearProf,   mBuf);
#endif
   CMCHKUNPK(SUnpkU16,          &siCirCfg->cirFlg,     mBuf);
   CMCHKUNPK(cmUnpkBool,        &siCirCfg->contReq,    mBuf);
#if (SI_218_COMP || SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCic,         &siCirCfg->firstCic,   mBuf);
   CMCHKUNPK(SUnpkU8,           &siCirCfg->numCir,     mBuf);
   CMCHKUNPK(cmUnpkBool,        &siCirCfg->nonSS7Con,  mBuf);
   CMCHKUNPK(cmUnpkAddrs,       &siCirCfg->outTrkGrpN, mBuf);
   CMCHKUNPK(cmUnpkAddrs,       &siCirCfg->cvrTrkClli, mBuf);
   CMCHKUNPK(cmUnpkAddrs,       &siCirCfg->clli,       mBuf);
#endif
   CMCHKUNPK(cmUnpkSiCirTmrCfg, &siCirCfg->cirTmr,     mBuf);
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   /* si001.220, MODIFIED: changes for ISUP rollup */
   /* Variant flag is defined at the destination, unpacking will be done 
    * only if the orignator indicates that is has packed the parameter 
    * (determined from the bit vector). If not send by orignator we 
    * assign a value to it because the usage of this field is guided
    * under the variant type checking in the code. During the soak time,
    * the upgraded variant won't enabled.
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
       || (bitVector & LSI_SS7_ETSIV3_BIT))
   {
      CMCHKUNPK(SUnpkU8,           &siCirCfg->slotId,     mBuf);
      CMCHKUNPK(SUnpkU8,           &siCirCfg->ctrlMult,   mBuf);
   }
   else
   {
      siCirCfg->slotId = LSI_COMMON_DEF_VAL;
      siCirCfg->ctrlMult = LSI_COMMON_DEF_VAL;
   }
#else
   /* No rolling upgrade support so we base our unpacking decision
    * solely on the compile time flag
    */
   CMCHKUNPK(SUnpkU8,           &siCirCfg->slotId,     mBuf);
   CMCHKUNPK(SUnpkU8,           &siCirCfg->ctrlMult,   mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* the compile time flag is not defined at destination but may be 
    * defined at origiator. If so we unpack and discard the parameter
    */
   if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
       || (bitVector & LSI_SS7_ETSIV3_BIT))
   {
      U8 tempVar;
      CMCHKUNPK(SUnpkU8, &tempVar, mBuf);
      CMCHKUNPK(SUnpkU8, &tempVar, mBuf);
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
   RETVALUE(ROK);
}/* cmUnpkSiCirCfg */


/*
*
*       Fun: cmPkSiIntfCbTmrCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiIntfCbTmrCfg 
(
SiDpcCbTmrCfg *siDpcCbTmrCfg,
Buffer        *mBuf
)
#else
PRIVATE S16 cmPkSiIntfCbTmrCfg (siDpcCbTmrCfg, mBuf)
SiDpcCbTmrCfg *siDpcCbTmrCfg;
Buffer        *mBuf;
#endif
{
   TRC2(cmPkSiIntfCbTmrCfg)

   CMCHKPK(cmPkTmrCfg, &siDpcCbTmrCfg->tSTAENQ,  mBuf);
   CMCHKPK(cmPkTmrCfg, &siDpcCbTmrCfg->tPAUSE, mBuf);
   CMCHKPK(cmPkTmrCfg, &siDpcCbTmrCfg->t4,     mBuf);

   RETVALUE(ROK);
}/* cmPkSiIntfCbTmrCfg */


/*
*
*       Fun: cmUnpkSiIntfCbTmrCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiIntfCbTmrCfg 
(
SiDpcCbTmrCfg *siDpcCbTmrCfg,
Buffer        *mBuf
)
#else
PRIVATE S16 cmUnpkSiIntfCbTmrCfg (siDpcCbTmrCfg, mBuf)
SiDpcCbTmrCfg *siDpcCbTmrCfg;
Buffer        *mBuf;
#endif
{
   TRC2(cmUnpkSiIntfCbTmrCfg)

   CMCHKUNPK(cmUnpkTmrCfg, &siDpcCbTmrCfg->t4,      mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siDpcCbTmrCfg->tPAUSE,  mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &siDpcCbTmrCfg->tSTAENQ, mBuf);

   RETVALUE(ROK);
}/* cmUnpkSiIntfCbTmrCfg */


/*
*
*       Fun: cmPkSiIntfCbCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiIntfCbCfg 
(
SiIntfCbCfg *siIntfCbCfg,
Buffer     *mBuf
)
#else
PRIVATE S16 cmPkSiIntfCbCfg (siIntfCbCfg, mBuf)
SiIntfCbCfg *siIntfCbCfg;
Buffer     *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= LSI_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSIV3
   bitVector |= LSI_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiIntfCbCfg)

/* si025.220: Addition - Added packing of link selection */
#ifdef LSIV4
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(SPkU8,             siIntfCbCfg->lnkSelBits,   mBuf);
#endif
   CMCHKPK(SPkU8,             siIntfCbCfg->lnkSelOpt,   mBuf);
#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(cmPkBool,          siIntfCbCfg->trunkType, mBuf);
#endif
#if (SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(SPkU8,             siIntfCbCfg->checkTable,mBuf);
#endif
#ifdef SS7_ANS95
   CMCHKPK(cmPkBool,          siIntfCbCfg->availTest, mBuf);
#endif
   CMCHKPK(SPkU8,             siIntfCbCfg->pauseActn, mBuf);
   CMCHKPK(cmPkSiIntfCbTmrCfg, &siIntfCbCfg->dpcCbTmr,mBuf);
   CMCHKPK(SPkU8,             siIntfCbCfg->ssf,       mBuf);
   CMCHKPK(cmPkSwtch,         siIntfCbCfg->swtch,     mBuf);
   CMCHKPK(cmPkDpc,           siIntfCbCfg->phyDpc,    mBuf);
   CMCHKPK(cmPkDpc,           siIntfCbCfg->opc,       mBuf);
   CMCHKPK(cmPkSpId,          siIntfCbCfg->sapId,     mBuf);
   CMCHKPK(cmPkSiInstId,      siIntfCbCfg->nwId,      mBuf);
   CMCHKPK(cmPkSiInstId,      siIntfCbCfg->intfId,    mBuf);
   /* si001.220, ADDED: if rolling upgrade support is ON, then pack the bit 
    * vector corresponding to rolling upgrade flags
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8,           bitVector,             mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiIntfCbCfg */

/* si025: modification - added pst to the cmUnpkSiIntfCbCfg */

/*
*
*       Fun: cmUnpkSiIntfCbCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiIntfCbCfg 
(
SiIntfCbCfg *siIntfCbCfg,
Buffer     *mBuf,
Pst      *pst
)
#else
PRIVATE S16 cmUnpkSiIntfCbCfg (siIntfCbCfg, mBuf, pst)
SiIntfCbCfg *siIntfCbCfg;
Buffer     *mBuf;
Pst        *pst;
#endif
{
/* si025.220: Addtion - Added interface version variable */
   CmIntfVer   intfVer;   /* interface version */
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiIntfCbCfg)

/* si025.220: Addition - Added interface version initialization */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = LSIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

/* si025.220: Modification - introduce a switch block to take care
 * of different interface version cases. */
   switch(intfVer)
   {
      case 0x0100:
      case 0x0200:
      case 0x0300:
         /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(SUnpkU8,             &bitVector,              mBuf);
         /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkSiInstId,      &siIntfCbCfg->intfId,    mBuf);
         CMCHKUNPK(cmUnpkSiInstId,      &siIntfCbCfg->nwId,      mBuf);
         CMCHKUNPK(cmUnpkSpId,          &siIntfCbCfg->sapId,     mBuf);
         CMCHKUNPK(cmUnpkDpc,           &siIntfCbCfg->opc,       mBuf);
         CMCHKUNPK(cmUnpkDpc,           &siIntfCbCfg->phyDpc,    mBuf);
         CMCHKUNPK(cmUnpkSwtch,         &siIntfCbCfg->swtch,     mBuf);
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->ssf,       mBuf);
         CMCHKUNPK(cmUnpkSiIntfCbTmrCfg, &siIntfCbCfg->dpcCbTmr, mBuf);
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->pauseActn, mBuf);
#ifdef SS7_ANS95
      /* si001.220, MODIFIED: changes for ISUP rollup */
      /* Variant flag is defined at the destination, unpacking will be done 
       * only if the orignator indicates that is has packed the parameter 
       * (determined from the bit vector). If not send by orignator we 
       * assign a value to it because the usage of this field is guided
       * under the variant type checking in the code. During the soak time,
       * the upgraded variant won't enabled.
       */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & LSI_SS7_ANS95_BIT) 
         {
            CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->availTest, mBuf);
         }
         else
            siIntfCbCfg->availTest = FALSE;
#else
      /* No rolling upgrade support so we base our unpacking decision
       * solely on the compile time flag
       */
         CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->availTest, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* the compile time flag is not defined at destination but may be 
       * defined at origiator. If so we unpack and discard the parameter
       */
         if (bitVector & LSI_SS7_ANS95_BIT) 
         {
            Bool tempTest;
            CMCHKUNPK(cmUnpkBool, &tempTest, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ITU97 || SS7_ETSIV3)
      /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ITU97_BIT) || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->checkTable, mBuf);
         }
         else
            siIntfCbCfg->checkTable = LSI_COMMON_DEF_VAL;
#else
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->checkTable, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ITU97_BIT) || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            U8 tempVal;
            CMCHKUNPK(SUnpkU8, &tempVal, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
      /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
             || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->trunkType, mBuf);
         }
         else
            siIntfCbCfg->trunkType = FALSE;
#else
         CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->trunkType, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
             || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            Bool tempVal;
            CMCHKUNPK(cmUnpkBool, &tempVal, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif

/* si025.220: Addition - added unpacking of link selection option.
 * If intfVer is 0x0100 - 0x0300, lnkSelOpt etc will not be packed. 
 * So set to default values. */
#ifdef LSIV4
         siIntfCbCfg->lnkSelOpt = LSI_LNKSEL_LD_DISTR;
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
         siIntfCbCfg->lnkSelBits = LSI_LNKSEL_5BITS;
#endif
#endif
         break;

/* si025.220: Addition - added case for interface LSIV4 */
      case 0x0400:
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(SUnpkU8,             &bitVector,              mBuf);
         /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkSiInstId,      &siIntfCbCfg->intfId,    mBuf);
         CMCHKUNPK(cmUnpkSiInstId,      &siIntfCbCfg->nwId,      mBuf);
         CMCHKUNPK(cmUnpkSpId,          &siIntfCbCfg->sapId,     mBuf);
         CMCHKUNPK(cmUnpkDpc,           &siIntfCbCfg->opc,       mBuf);
         CMCHKUNPK(cmUnpkDpc,           &siIntfCbCfg->phyDpc,    mBuf);
         CMCHKUNPK(cmUnpkSwtch,         &siIntfCbCfg->swtch,     mBuf);
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->ssf,       mBuf);
         CMCHKUNPK(cmUnpkSiIntfCbTmrCfg, &siIntfCbCfg->dpcCbTmr, mBuf);
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->pauseActn, mBuf);
#ifdef SS7_ANS95
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector & LSI_SS7_ANS95_BIT) 
         {
            CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->availTest, mBuf);
         }
         else
            siIntfCbCfg->availTest = FALSE;
#else
      /* No rolling upgrade support so we base our unpacking decision
       * solely on the compile time flag
       */
         CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->availTest, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
      /* the compile time flag is not defined at destination but may be 
       * defined at origiator. If so we unpack and discard the parameter
       */
         if (bitVector & LSI_SS7_ANS95_BIT) 
         {
            Bool tempTest;
            CMCHKUNPK(cmUnpkBool, &tempTest, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ITU97 || SS7_ETSIV3)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ITU97_BIT) || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->checkTable, mBuf);
         }
         else
            siIntfCbCfg->checkTable = LSI_COMMON_DEF_VAL;
#else
         CMCHKUNPK(SUnpkU8,             &siIntfCbCfg->checkTable, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ITU97_BIT) || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            U8 tempVal;
            CMCHKUNPK(SUnpkU8, &tempVal, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
             || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->trunkType, mBuf);
         }
         else
            siIntfCbCfg->trunkType = FALSE;
#else
         CMCHKUNPK(cmUnpkBool,           &siIntfCbCfg->trunkType, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
             || (bitVector & LSI_SS7_ETSIV3_BIT))
         {
            Bool tempVal;
            CMCHKUNPK(cmUnpkBool, &tempVal, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif

/* si025.220: Addition - added unpacking of link selection option.
 * If intfVer is 0x0400, lnkselOpt etc must have been packed. 
 * So unpack them. Assumption is LM intfVer should always be lower
 * than the protocol layer intfVer. */
#ifdef LSIV4
         CMCHKUNPK(SUnpkU8, &siIntfCbCfg->lnkSelOpt, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
         CMCHKUNPK(SUnpkU8, &siIntfCbCfg->lnkSelBits, mBuf);
#endif
#endif
         break;

      default:
        /* invalid interface version number */
        RETVALUE(RINVIFVER);
   } /* end of switch */

   RETVALUE(ROK);
}/* cmUnpkSiIntfCbCfg */


/*
*
*       Fun: cmPkSiCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCfg 
(
SiMngmt *cfg,
Buffer *mBuf 
)
#else
PRIVATE S16 cmPkSiCfg (cfg, mBuf)
SiMngmt *cfg;
Buffer *mBuf;
#endif
{
   SiCfg  *siCfg;

   TRC2(cmPkSiCfg)

   siCfg = &cfg->t.cfg;

   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         CMCHKPK(cmPkSiGenCfg, &siCfg->s.siGen, mBuf);
         break;

      case STISAP:
         CMCHKPK(cmPkSiSAPCfg, &siCfg->s.siSap, mBuf);
         break;

      case STNSAP:
         CMCHKPK(cmPkSiNSAPCfg, &siCfg->s.siNSap, mBuf);
         break;

#ifdef SI_218_COMP
      case STROUT:
#if (!(SI_LMINT3 || SMSI_LMINT3))
      /* under LMINT3 this is moved to control request */
      case STDELROUT:
#endif
         CMCHKPK(cmPkSiRoutCfg, &siCfg->s.siRout, mBuf);
         break;
#endif

      case STICIR:
         CMCHKPK(cmPkSiCirCfg, &siCfg->s.siCir, mBuf);
         break;

      case SI_STINTF:
         CMCHKPK(cmPkSiIntfCbCfg, &siCfg->s.siIntfCb, mBuf);
         break;

      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}/* cmPkSiCfg */


/*
*
*       Fun: cmUnpkSiCfg   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
/* si009.220 - Modified: to pass pst structure */
#ifdef ANSI
PRIVATE S16 cmUnpkSiCfg 
(
SiMngmt *cfg,
Buffer  *mBuf,
Pst     *pst
)
#else
PRIVATE S16 cmUnpkSiCfg (cfg, mBuf, pst)
SiMngmt *cfg;
Buffer *mBuf;
Pst    *pst;
#endif
{
   SiCfg  *siCfg;
   S16 ret1;

   TRC2(cmUnpkSiCfg)

   siCfg = &cfg->t.cfg;

   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:
         ret1 = cmUnpkSiGenCfg(&siCfg->s.siGen, mBuf, pst);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
         {
            RETVALUE(ret1);
         }
#endif
         break;

      case STISAP:
         CMCHKUNPK(cmUnpkSiSAPCfg, &siCfg->s.siSap, mBuf);
         break;

      case STNSAP:
         CMCHKUNPK(cmUnpkSiNSAPCfg, &siCfg->s.siNSap, mBuf);
         break;

#ifdef SI_218_COMP
      case STROUT:
#if (!(SI_LMINT3 || SMSI_LMINT3))
      /* under LMINT3 this is moved to control request */
      case STDELROUT:
#endif
         CMCHKUNPK(cmUnpkSiRoutCfg, &siCfg->s.siRout, mBuf);
         break;
#endif

      case STICIR:
         CMCHKUNPK(cmUnpkSiCirCfg, &siCfg->s.siCir, mBuf);
         break;

      case SI_STINTF:
         /* si025.220: modification - added post argument in cmUnpkSiIntfCbCfg */
         ret1 = cmUnpkSiIntfCbCfg(&siCfg->s.siIntfCb, mBuf, pst);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
         {
            RETVALUE(ret1);
         }
#endif
         break;

      default:
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
}/* cmUnpkSiCfg */

#if (SI_LMINT3 || SMSI_LMINT3)

/*
*
*       Fun:   cmPkSiPduSts
*
*       Desc:  pack the statistics structure
*              
*       Ret:   ROK - pass RFAILED- failed
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiPduSts 
(
SiPduSts *siPduSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiPduSts (siPduSts, mBuf)
SiPduSts *siPduSts;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS88
   bitVector |= LSI_SS7_ANS88_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ANS92
   bitVector |= LSI_SS7_ANS92_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= LSI_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
/* si029.220: Addition - added SS7_INDIA */
#ifdef SS7_INDIA
   bitVector |= LSI_SS7_INDIA_BIT;
#endif /* SS7_INDIA */
#ifdef SS7_ETSIV3
   bitVector |= LSI_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
/* si034.220: Addition - added SS7_CHINA */
#ifdef SS7_CHINA
   bitVector |= LSI_SS7_CHINA_BIT;
#endif /* SS7_CHINA */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiPduSts)

/* si029.220: Addition - added SS7_INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   CMCHKPK(cmPkCntr, siPduSts->pri, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->apn, mBuf)
#endif

/* si034.220: Addition - added SS7_CHINA */
#if SS7_CHINA
   CMCHKPK(cmPkCntr, siPduSts->opr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->mpm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cpc, mBuf)
#endif
#if SS7_NTT
   CMCHKPK(cmPkCntr, siPduSts->chgntt, mBuf)
#endif
#if SS7_RUSSIA
   CMCHKPK(cmPkCntr, siPduSts->rng, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->ccl, mBuf)
#endif
#if SS7_FTZ
   CMCHKPK(cmPkCntr, siPduSts->uin, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->nana, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->fin, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->ehza, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->chgea, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->chge, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->chg, mBuf)
#endif /* SS7_FTZ */

#if SS7_Q767IT
   CMCHKPK(cmPkCntr, siPduSts->com, mBuf)
#endif /* SS7_Q767IT */
#if SS7_SINGTEL
   CMCHKPK(cmPkCntr, siPduSts->tcm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->mcp, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cak, mBuf)
#endif /* SS7_SINGTEL */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siPduSts->exm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cvt, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cvr, mBuf)
#endif /* (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL) */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siPduSts->crm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cra, mBuf)
#endif /* SS7_ANS92 || SS7_ANS95 || SS7_BELL */
#if SS7_ANS88
   CMCHKPK(cmPkCntr, siPduSts->fai, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->fad, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->csvs, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->csvr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cmrj, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cmr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cmc, mBuf)
#endif /* SS7_ANS88 */
   CMCHKPK(cmPkCntr, siPduSts->usr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->upt, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->upa, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->ucic, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->ubl, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->uba, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->sus, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->sgm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->sam, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->rsc, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->rlc, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->res, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->rel, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->pam, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->olm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->nrm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->lpa, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->lop, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->irs, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->inr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->inf, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->idr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->iam, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->grs, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->gra, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->frj, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->fot, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->farMsg, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->fac, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->faa, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->crg, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cqr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cqm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cpg, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cot, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->con, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cgua, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cgu, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cgba, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cgb, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->cfn, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->ccr, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->blo, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->bla, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->anm, mBuf)
   CMCHKPK(cmPkCntr, siPduSts->acm, mBuf)
   /* si001.220, ADDED:  pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8, bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiPduSts */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiPduSts 
(
SiPduSts *siPduSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiPduSts (siPduSts, mBuf)
SiPduSts *siPduSts;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiPduSts)

   /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8, &bitVector, mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkCntr, &siPduSts->acm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->anm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->bla, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->blo, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->ccr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cfn, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cgb, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cgba, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cgu, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cgua, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->con, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cot, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cpg, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cqm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cqr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->crg, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->faa, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->fac, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->farMsg, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->fot, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->frj, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->gra, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->grs, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->iam, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->idr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->inf, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->inr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->irs, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->lop, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->lpa, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->nrm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->olm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->pam, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->rel, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->res, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->rlc, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->rsc, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->sam, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->sgm, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->sus, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->uba, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->ubl, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->ucic, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->upa, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->upt, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->usr, mBuf)
#if SS7_ANS88
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & LSI_SS7_ANS88_BIT) 
   {
      CMCHKUNPK(cmUnpkCntr, &siPduSts->cmc, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->cmr, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->cmrj, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->csvr, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->csvs, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->fad, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->fai, mBuf)
   }
   else
   {
      siPduSts->cmc = LSI_COMMON_DEF_VAL;
      siPduSts->cmr = LSI_COMMON_DEF_VAL;
      siPduSts->cmrj = LSI_COMMON_DEF_VAL;
      siPduSts->csvr = LSI_COMMON_DEF_VAL;
      siPduSts->csvs = LSI_COMMON_DEF_VAL;
      siPduSts->fad = LSI_COMMON_DEF_VAL;
      siPduSts->fai = LSI_COMMON_DEF_VAL;
   }
#else
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cmc, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cmr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cmrj, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->csvr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->csvs, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->fad, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->fai, mBuf)
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if (bitVector & LSI_SS7_ANS88_BIT) 
   {
      Cntr tempVal;
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS88 */
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
/* si004.220, MODIFIED: correction for SS7_BELL variant flag */
#ifndef SS7_BELL
   if ((bitVector & LSI_SS7_ANS92_BIT) || (bitVector & LSI_SS7_ANS95_BIT)) 
#endif
   {
      CMCHKUNPK(cmUnpkCntr, &siPduSts->cra, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->crm, mBuf)
   }
#ifndef SS7_BELL
   else
   {
      siPduSts->cra = LSI_COMMON_DEF_VAL;
      siPduSts->crm = LSI_COMMON_DEF_VAL;
   }
#endif
#else
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cra, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->crm, mBuf)
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ANS92_BIT) || (bitVector & LSI_SS7_ANS95_BIT)) 
   {
      Cntr tempVal;
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SS7_ANS92 || SS7_ANS95 || SS7_BELL */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cvr, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cvt, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->exm, mBuf)
#endif /* (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL) */
#if SS7_SINGTEL
   CMCHKUNPK(cmUnpkCntr, &siPduSts->cak, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->mcp, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->tcm, mBuf)
#endif /* SS7_SINGTEL */
#if SS7_Q767IT
   CMCHKUNPK(cmUnpkCntr, &siPduSts->com, mBuf)
#endif /* SS7_Q767IT */
#if SS7_FTZ
   CMCHKUNPK(cmUnpkCntr, &siPduSts->chg, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->chge, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->chgea, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->ehza, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->fin, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->nana, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->uin, mBuf)
#endif /* SS7_FTZ */
#if SS7_RUSSIA
   CMCHKUNPK(cmUnpkCntr, &siPduSts->ccl, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->rng, mBuf)
#endif
#if SS7_NTT
   CMCHKUNPK(cmUnpkCntr, &siPduSts->chgntt, mBuf)
#endif
/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ETSIV3_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
        || (bitVector & LSI_SS7_INDIA_BIT)) 
   {
      CMCHKUNPK(cmUnpkCntr, &siPduSts->apn, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->pri, mBuf)
   }
   else
   {
      siPduSts->apn = LSI_COMMON_DEF_VAL;
      siPduSts->pri = LSI_COMMON_DEF_VAL;
   }
#else
   CMCHKUNPK(cmUnpkCntr, &siPduSts->apn, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siPduSts->pri, mBuf)
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ETSIV3_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
        || (bitVector & LSI_SS7_INDIA_BIT)) 
   {
      Cntr tempVal;
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
/* si029.220: Modification - added CHINA switch */
#if SS7_CHINA
      CMCHKUNPK(cmUnpkCntr, &siPduSts->opr, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->mpm, mBuf)
      CMCHKUNPK(cmUnpkCntr, &siPduSts->cpc, mBuf)
#endif

   RETVALUE(ROK);
}/* cmUnpkSiPduSts */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiIntfSts 
(
SiIntfSts *siIntfSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiIntfSts (siIntfSts, mBuf)
SiIntfSts *siIntfSts;
Buffer   *mBuf;
#endif
{
   TRC2(cmPkSiIntfSts)

   CMCHKPK(cmPkSiPduSts, &siIntfSts->pdu.rx,  mBuf)
   CMCHKPK(cmPkSiPduSts, &siIntfSts->pdu.tx,  mBuf)
   CMCHKPK(cmPkCntr,     siIntfSts->total.rx, mBuf)
   CMCHKPK(cmPkCntr,     siIntfSts->total.tx, mBuf)

   RETVALUE(ROK);
}/* cmPkSitDpcSts */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiIntfSts 
(
SiIntfSts *siIntfSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiIntfSts (siIntfSts, mBuf)
SiIntfSts *siIntfSts;
Buffer   *mBuf;
#endif
{
   TRC2(cmUnpkSiIntfSts)

   CMCHKUNPK(cmUnpkCntr,     &siIntfSts->total.tx, mBuf)
   CMCHKUNPK(cmUnpkCntr,     &siIntfSts->total.rx, mBuf)
   CMCHKUNPK(cmUnpkSiPduSts, &siIntfSts->pdu.tx,   mBuf)
   CMCHKUNPK(cmUnpkSiPduSts, &siIntfSts->pdu.rx,   mBuf)

   RETVALUE(ROK);
}/* cmUnpkSitDpcSts */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCirSts 
(
SiCirSts *siCirSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiCirSts (siCirSts, mBuf)
SiCirSts *siCirSts;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#ifdef SS7_ITU97
   bitVector |= LSI_SS7_ITU97_BIT;
#endif /* SS7_ITU97 */
#ifdef SS7_ETSIV3
   bitVector |= LSI_SS7_ETSIV3_BIT;
#endif /* SS7_ETSIV3 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiCirSts)

#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(cmPkCntr, siCirSts->numNonCont,    mBuf)
#endif   
   CMCHKPK(cmPkCntr, siCirSts->relFail,       mBuf)
   CMCHKPK(cmPkCntr, siCirSts->relUnrecInfo,  mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxEvt,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxMsg,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->pduFmtErr,     mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxUba,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxBla,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxCgua,       mBuf)
   CMCHKPK(cmPkCntr, siCirSts->unxCgba,       mBuf)
   CMCHKPK(cmPkCntr, siCirSts->abnrmlAckCgua, mBuf)
   CMCHKPK(cmPkCntr, siCirSts->abnrmlAckCgba, mBuf)
   CMCHKPK(cmPkCntr, siCirSts->noAckCgua,     mBuf)
   CMCHKPK(cmPkCntr, siCirSts->noAckCgba,     mBuf)
   CMCHKPK(cmPkCntr, siCirSts->blkReq,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->abnrmlRel,     mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t23Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t21Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t19Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t17Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t15Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t13Exp,        mBuf)
   CMCHKPK(cmPkCntr, siCirSts->t5Exp,         mBuf)
   /* si001.220, ADDED:  pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8,           bitVector,             mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiCirSts */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiCirSts 
(
SiCirSts *siCirSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiCirSts (siCirSts, mBuf)
SiCirSts *siCirSts;
Buffer   *mBuf;
#endif
{
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiCirSts)

   /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8,             &bitVector,              mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t5Exp,         mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t13Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t15Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t17Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t19Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t21Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->t23Exp,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->abnrmlRel,     mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->blkReq,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->noAckCgba,     mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->noAckCgua,     mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->abnrmlAckCgba, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->abnrmlAckCgua, mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxCgba,       mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxCgua,       mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxBla,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxUba,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->pduFmtErr,     mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxMsg,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unxEvt,        mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->relUnrecInfo,  mBuf)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->relFail,       mBuf)
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)   
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
       || (bitVector & LSI_SS7_ETSIV3_BIT))
      CMCHKUNPK(cmUnpkCntr, &siCirSts->numNonCont,       mBuf)
   else
      siCirSts->numNonCont = LSI_COMMON_DEF_VAL;
#else
   CMCHKUNPK(cmUnpkCntr, &siCirSts->numNonCont,       mBuf)
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   if ((bitVector & LSI_SS7_ANS95_BIT) || (bitVector & LSI_SS7_ITU97_BIT)
       || (bitVector & LSI_SS7_ETSIV3_BIT))
   {
      Cntr tempVal;
      CMCHKUNPK(cmUnpkCntr, &tempVal, mBuf)
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif   

   RETVALUE(ROK);
}/* cmUnpkSiCirSts */
#else /* !(SI_LMINT3 || SMSI_LMINT3) */

/*
*
*       Fun: cmPkSiNSAPSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiNSAPSts 
(
SiNSAPSts *siNSAPSts,
Buffer    *mBuf
)
#else
PRIVATE S16 cmPkSiNSAPSts (siNSAPSts, mBuf)
SiNSAPSts *siNSAPSts;
Buffer    *mBuf;
#endif
{
   TRC2(cmPkSiNSAPSts)

/* si029.220: Addition - added ITU97 and INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   CMCHKPK(cmPkCntr, siNSAPSts->preRelRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->appTranRx, mBuf);
#endif

/* si034.220: Addition - added oprRx, mpmRx and cpcRx for CHINA */
#if SS7_CHINA
   CMCHKPK(cmPkCntr, siNSAPSts->oprRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->mpmRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->cpcRx, mBuf);
#endif

#if SS7_NTT
   CMCHKPK(cmPkCntr, siNSAPSts->chgnttRx, mBuf);
#endif
#if SS7_RUSSIA
   CMCHKPK(cmPkCntr, siNSAPSts->callClearRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->ringSendRx, mBuf);
#endif
#if SS7_FTZ
   CMCHKPK(cmPkCntr, siNSAPSts->natMsgRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->usrInfRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->ehzaRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facInfoRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargExtdARx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargExtdRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargingRx, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(cmPkCntr, siNSAPSts->loopPrvntRx, mBuf);
#endif
#if SS7_Q767IT
   CMCHKPK(cmPkCntr, siNSAPSts->comRx, mBuf);
#endif
/* si029.220: Modification - added flags for chargeRx */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
   CMCHKPK(cmPkCntr, siNSAPSts->chargeRx, mBuf);
#endif
#if SS7_SINGTEL
   CMCHKPK(cmPkCntr, siNSAPSts->chargeAckRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->trfChngeRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->malCllPrntRx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siNSAPSts->netIdRspRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->netIdReqRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->netResMgmtRx, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siNSAPSts->exitRx, mBuf);
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siNSAPSts->cirResAckRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->cirReserveRx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siNSAPSts->uneqCirIdRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->usrToUsrRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->subsAdrRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->passAlongRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->infoRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->infoReqRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->initAdrRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facRejRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facAckRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->relCmpltRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->relRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->overldRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->conRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->forwRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->resmRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->suspRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModComRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModRejRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModReqRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->confusRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->loopBckAckRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->conChkReqRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->contiRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->progressRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->answerRx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->adrCmpltRx, mBuf);

/* si029.220: Addition - added preRelTx and appTranTx for
 * ETSIV32 and ITU97 and INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   CMCHKPK(cmPkCntr, siNSAPSts->preRelTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->appTranTx, mBuf);
#endif

/* si034.220: Addition - added oprTx, mpmTx and cpcTx for CHINA */
#if SS7_CHINA
   CMCHKPK(cmPkCntr, siNSAPSts->oprTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->mpmTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->cpcTx, mBuf);
#endif

#if SS7_NTT
   CMCHKPK(cmPkCntr, siNSAPSts->chgnttTx, mBuf);
#endif
#if SS7_RUSSIA
   CMCHKPK(cmPkCntr, siNSAPSts->callClearTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->ringSendTx, mBuf);
#endif
#if SS7_FTZ
   CMCHKPK(cmPkCntr, siNSAPSts->natMsgTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->usrInfTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->ehzaTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facInfoTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargExtdATx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargExtdTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->chargingTx, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(cmPkCntr, siNSAPSts->loopPrvntTx, mBuf);
#endif
#if SS7_Q767IT
   CMCHKPK(cmPkCntr, siNSAPSts->comTx, mBuf);
#endif
/* si029.220: Modification - added flags for chargeRx */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
   CMCHKPK(cmPkCntr, siNSAPSts->chargeTx, mBuf);
#endif
#if SS7_SINGTEL
   CMCHKPK(cmPkCntr, siNSAPSts->chargeAckTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->trfChngeTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->malCllPrntTx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siNSAPSts->netIdRspTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->netIdReqTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->netResMgmtTx, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siNSAPSts->exitTx, mBuf);
#endif
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siNSAPSts->cirResAckTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->cirReserveTx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siNSAPSts->uneqCirIdTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->usrToUsrTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->subsAdrTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->passAlongTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->infoReqTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->infoTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->initAdrTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facRejTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facAckTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->facTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->relCmpltTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->overldTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->relTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->conTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->forwTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->resmTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->suspTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModComTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModRejTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->callModReqTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->confusTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->loopBckAckTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->conChkReqTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->contiTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->progressTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->answerTx, mBuf);
   CMCHKPK(cmPkCntr, siNSAPSts->adrCmpltTx, mBuf);

   RETVALUE(ROK);
}/* cmPkSiNSAPSts */


/*
*
*       Fun: cmUnpkSiNSAPSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiNSAPSts 
(
SiNSAPSts *siNSAPSts,
Buffer    *mBuf
)
#else
PRIVATE S16 cmUnpkSiNSAPSts (siNSAPSts, mBuf)
SiNSAPSts *siNSAPSts;
Buffer    *mBuf;
#endif
{
   TRC2(cmUnpkSiNSAPSts)

   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->adrCmpltTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->answerTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->progressTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->contiTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->conChkReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->loopBckAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->confusTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModRejTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModComTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->suspTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->resmTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->forwTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->conTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->relTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->overldTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->relCmpltTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facRejTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->initAdrTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->infoTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->infoReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->passAlongTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->subsAdrTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->usrToUsrTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->uneqCirIdTx, mBuf);
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cirReserveTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cirResAckTx, mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->exitTx, mBuf);
#endif
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netResMgmtTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netIdReqTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netIdRspTx, mBuf);
#if SS7_SINGTEL
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->malCllPrntTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->trfChngeTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargeAckTx, mBuf);
#endif
/* si029.220: Modification - added flags for chargeRx */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargeTx, mBuf);
#endif
#if SS7_Q767IT
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->comTx, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->loopPrvntTx, mBuf);
#endif
#if SS7_FTZ
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargingTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargExtdTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargExtdATx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facInfoTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->ehzaTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->usrInfTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->natMsgTx, mBuf);
#endif
#if SS7_RUSSIA
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->ringSendTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callClearTx, mBuf);
#endif
#if SS7_NTT
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chgnttTx, mBuf);
#endif

/* si029.220: Addition - added preRelTx and appTranTx for
 * ETSIV32 and ITU97 and INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
/* si034.220 : Modification - appTranRx & preRelRx changed to
   appTranTx & preRelTx */
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->appTranTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->preRelTx, mBuf);
#endif

/* si034.220: Addition - added oprTx, mpmTx & cpcTx for CHINA flag */
#if SS7_CHINA
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->oprTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->mpmTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cpcTx, mBuf);
#endif /* if SS7_CHINA */


   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->adrCmpltRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->answerRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->progressRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->contiRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->conChkReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->loopBckAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->confusRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModRejRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callModComRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->suspRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->resmRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->forwRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->conRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->overldRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->relRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->relCmpltRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facRejRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->initAdrRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->infoReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->infoRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->passAlongRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->subsAdrRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->usrToUsrRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->uneqCirIdRx, mBuf);
#if (SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cirReserveRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cirResAckRx, mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->exitRx, mBuf);
#endif
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netResMgmtRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netIdReqRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->netIdRspRx, mBuf);
#if SS7_SINGTEL
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->malCllPrntRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->trfChngeRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargeAckRx, mBuf);
#endif
/* si029.220: Modification - added flags for chargeRx */
#if (SS7_SINGTEL || SS7_RUSSIA || SS7_INDIA)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargeRx, mBuf);
#endif
#if SS7_Q767IT
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->comRx, mBuf);
#endif
#if (SS7_ETSI || SS7_ITU97 || SS7_ETSIV3)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->loopPrvntRx, mBuf);
#endif
#if SS7_FTZ
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargingRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargExtdRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chargExtdARx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->facInfoRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->ehzaRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->usrInfRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->natMsgRx, mBuf);
#endif
#if SS7_RUSSIA
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->ringSendRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->callClearRx, mBuf);
#endif
#if SS7_NTT
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->chgnttRx, mBuf);
#endif
/* si029.220: Addition - added ITU97 and INDIA flags */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_INDIA)
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->appTranRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->preRelRx, mBuf);
#endif

/* si034.220: Addition - added CHINA flag */
#if SS7_CHINA
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->oprRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->mpmRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siNSAPSts->cpcRx, mBuf);
#endif /* if SS7_CHINA */

   RETVALUE(ROK);
}/* cmUnpkSiNSAPSts */


/*
*
*       Fun: cmPkSiCirSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiCirSts 
(
SiCirSts *siCirSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmPkSiCirSts (siCirSts, mBuf)
SiCirSts *siCirSts;
Buffer   *mBuf;
#endif
{
   TRC2(cmPkSiCirSts)

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siCirSts->cirValRspRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirValTstRx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siCirSts->usrPrtAvRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->usrPrtTstRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrResAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrResRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrQAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrQRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrUnBlockAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrUnBlockRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrBlockAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrBlockRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirResRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->unblockAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->unblockRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->blockAckRx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->blockRx, mBuf);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkCntr, siCirSts->cirValRspTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirValTstTx, mBuf);
#endif
   CMCHKPK(cmPkCntr, siCirSts->usrPrtAvTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->usrPrtTstTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrResAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrResTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrQAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrQTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrUnBlockAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrUnBlockTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrBlockAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirGrBlockTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->cirResTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->unblockAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->unblockTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->blockAckTx, mBuf);
   CMCHKPK(cmPkCntr, siCirSts->blockTx, mBuf);

   RETVALUE(ROK);
}/* cmPkSiCirSts */


/*
*
*       Fun: cmUnpkSiCirSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiCirSts 
(
SiCirSts *siCirSts,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkSiCirSts (siCirSts, mBuf)
SiCirSts *siCirSts;
Buffer   *mBuf;
#endif
{
   TRC2(cmUnpkSiCirSts)

   CMCHKUNPK(cmUnpkCntr, &siCirSts->blockTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->blockAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unblockTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unblockAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirResTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrBlockTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrBlockAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrUnBlockTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrUnBlockAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrQTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrQAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrResTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrResAckTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->usrPrtTstTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->usrPrtAvTx, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirValTstTx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirValRspTx, mBuf);
#endif
   CMCHKUNPK(cmUnpkCntr, &siCirSts->blockRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->blockAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unblockRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->unblockAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirResRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrBlockRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrBlockAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrUnBlockRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrUnBlockAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrQRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrQAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrResRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirGrResAckRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->usrPrtTstRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->usrPrtAvRx, mBuf);
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirValTstRx, mBuf);
   CMCHKUNPK(cmUnpkCntr, &siCirSts->cirValRspRx, mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiCirSts */

#endif /* !(SI_LMINT3 || SMSI_LMINT3) */

/*
*
*       Fun: cmPkSiSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiSts 
(
SiMngmt  *sts,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkSiSts (sts, mBuf)
SiMngmt  *sts;
Buffer   *mBuf;
#endif
{
   SiSts *siSts;

   TRC2(cmPkSiSts)

   siSts = &sts->t.sts;

#if (SI_LMINT3 || SMSI_LMINT3)
   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:
         cmPkSiCirSts(&siSts->s.cir, mBuf);
         break;
 
      case SI_STINTF:
         cmPkSiIntfSts(&siSts->s.intf, mBuf);
         CMCHKPK(cmPkDpc, siSts->elmntId.intfId, mBuf);
         break;

      case STICIR:
         cmPkSiCirSts(&siSts->s.cir, mBuf);
         CMCHKPK(cmPkCirId, siSts->elmntId.circuit, mBuf);
         break;

      default:
         RETVALUE(RFAILED);
   }

#else /* !(SI_LMINT3 || SMSI_LMINT3) */
   switch (sts->hdr.elmId.elmnt)
   {
      case STNSAP:
         cmPkSiNSAPSts(&siSts->s.siSts, mBuf);
         break;

      case STICIR:
         cmPkSiCirSts(&siSts->s.siCirSts, mBuf);
         break;

      default:
         RETVALUE(RFAILED);
   }
#endif /* !(SI_LMINT3 || SMSI_LMINT3) */

   CMCHKPK(cmPkDuration, &siSts->dura, mBuf);
   CMCHKPK(cmPkDateTime, &siSts->dt,  mBuf);

   RETVALUE(ROK);
}/* cmPkSiSts */


/*
*
*       Fun: cmUnpkSiSts   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiSts 
(
SiMngmt *sts,
Buffer  *mBuf
)
#else
PUBLIC S16 cmUnpkSiSts (sts, mBuf)
SiMngmt *sts;
Buffer  *mBuf;
#endif
{
   SiSts *siSts;

   TRC2(cmUnpkSiSts)

   siSts = &sts->t.sts;

   CMCHKUNPK(cmUnpkDateTime, &siSts->dt,   mBuf);
   CMCHKUNPK(cmUnpkDuration, &siSts->dura, mBuf);

#if (SI_LMINT3 || SMSI_LMINT3)
   switch (sts->hdr.elmId.elmnt)
   {
      case STGEN:
         cmUnpkSiCirSts(&siSts->s.cir, mBuf);
         break;

      case SI_STINTF:
         CMCHKUNPK(cmUnpkDpc, &siSts->elmntId.intfId, mBuf);
         cmUnpkSiIntfSts(&siSts->s.intf, mBuf);
         break;

      case STICIR:
         CMCHKUNPK(cmUnpkCirId, &siSts->elmntId.circuit, mBuf);
         cmUnpkSiCirSts(&siSts->s.cir, mBuf);
         break;

      default:
         RETVALUE(RFAILED);
   }
#else /* !(SI_LMINT3 || SMSI_LMINT3) */
   switch (sts->hdr.elmId.elmnt)
   {
      case STNSAP:
         cmUnpkSiNSAPSts(&siSts->s.siSts, mBuf);
         break;

      case STICIR:
         cmUnpkSiCirSts(&siSts->s.siCirSts, mBuf);
         break;

      default:
         RETVALUE(RFAILED);
   }
#endif /* !(SI_LMINT3 || SMSI_LMINT3) */
   
   RETVALUE(ROK);
}/* cmUnpkSiSts */


/*
*
*       Fun: cmPkSiCntrl   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiCntrl 
(
SiMngmt *cntrl,
Buffer  *mBuf
)
#else
PUBLIC S16 cmPkSiCntrl (cntrl, mBuf)
SiMngmt *cntrl;
Buffer  *mBuf;
#endif
{
   Cntr    i;
   Elmnt   elmnt;
   SiCntrl *siCntrl;
#if (SI_LMINT3 || SMSI_LMINT3)
   SiElmntCntrl *siElmntCntrl;
#endif
   /* si001.220, ADDED: changes for ISUP rollup bit vector implementation */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector = 0x00;
#ifdef SS7_ANS95
   bitVector |= LSI_SS7_ANS95_BIT;
#endif /* SS7_ANS95 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmPkSiCntrl)

   elmnt   = cntrl->hdr.elmId.elmnt;
   siCntrl = &cntrl->t.cntrl;

#if (SI_LMINT3 || SMSI_LMINT3)
   switch (siCntrl->subAction)
   {
      case SAELMNT:
         siElmntCntrl = &siCntrl->s.siElmnt;
         switch (elmnt)
         {
            case SI_STINTF:
               CMCHKPK(cmPkDpc,  siElmntCntrl->elmntId.intfId, mBuf);
               break;

            case STICIR:
               CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cir.flag,  mBuf);
               CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cir.swtch, mBuf);
               CMCHKPK(SPkU32,   siElmntCntrl->elmntId.circuit,      mBuf);
               break;

            case SI_STCIRGRP:
               /* si006.220, MODIFIED: pack the fields related to force 
                * blocking
                */
               if (siCntrl->action == ABLK)
               {
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */
#if (LSIV2 || LSIV3 || LSIV4)
                  CMCHKPK(cmPkCic, siElmntCntrl->elmntParam.forblk.cic, mBuf);
                  CMCHKPK(cmPkDpc, siElmntCntrl->elmntParam.forblk.phyDpc, mBuf);
                  CMCHKPK(cmPkDpc, siElmntCntrl->elmntParam.forblk.opc, mBuf);
                  for (i = MAX_SIZ_STATUS; i > 0; i--)
                     CMCHKPK(SPkU8, siElmntCntrl->elmntParam.forblk.status[i - 1], 
                             mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.forblk.cgsmti, mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.forblk.range,  mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.forblk.swtch,  mBuf);
#endif /* LSIV2 || LSIV3 || LSIV4 */
                  CMCHKPK(cmPkSpId, siElmntCntrl->elmntId.sapId,            mBuf);
               }
               else
               {
#ifdef SS7_ANS95
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cirgr.mapPres, mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cirgr.mapType, mBuf);
                  CMCHKPK(SPkU32,   siElmntCntrl->elmntParam.cirgr.mapFormat, mBuf);
#endif
                  for (i = MAX_SIZ_STATUS; i > 0; i--)
                     CMCHKPK(SPkU8, siElmntCntrl->elmntParam.cirgr.status[i - 1], 
                             mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cirgr.cgsmti, mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cirgr.range,  mBuf);
                  CMCHKPK(SPkU8,    siElmntCntrl->elmntParam.cirgr.swtch,  mBuf);
                  CMCHKPK(SPkU32,   siElmntCntrl->elmntId.circuit,         mBuf);
               }
               break;

            case STNSAP:
               CMCHKPK(SPkU8, siElmntCntrl->elmntParam.nsap.nsapType, mBuf);
               CMCHKPK(cmPkSpId, siElmntCntrl->elmntId.sapId, mBuf);
               break;

            case STISAP:
               CMCHKPK(cmPkSpId, siElmntCntrl->elmntId.sapId, mBuf);
               break;

            case STGRPUPSAP:
            case STGRPNSAP:
            case STALLSAP:
               /* though we pack NSAP type always, its only used when group 
                * of NSAPs are controlled */
               CMCHKPK(SPkU8, siElmntCntrl->elmntParam.nsap.nsapType, mBuf);
               CMCHKPK(cmPkProcId, siElmntCntrl->elmntId.dstProcId,   mBuf);
               break;
         }
         break;

      case SADBG:
         CMCHKPK(SPkU32, siCntrl->s.siDbg.dbgMask, mBuf);
         break;

      case SATRC:
         CMCHKPK(SPkS16,    siCntrl->s.siTrc.nsapType, mBuf);
         CMCHKPK(cmPkSpId, siCntrl->s.siTrc.nsapId,   mBuf);
         break;
#ifdef SI_ACNT
      case SAACNT:
#endif
      case SAUSTA:
         break;
   }
#else /* LMINT2 */
   switch (siCntrl->subAction)
   {
      case SAELMNT:
         switch (elmnt)
         {
            case SI_STINTF:
               CMCHKPK(cmPkDpc, siCntrl->sigpt.intfId, mBuf);
               break;

            case STICIR:
            case STNSAP:
               CMCHKPK(cmPkCirId, siCntrl->sigpt.cirId, mBuf);
               break;

            case SI_STCIRGRP:
               CMCHKPK(cmPkCirId, siCntrl->sigpt.cirId, mBuf);
#ifdef SS7_ANS95
               CMCHKPK(SPkU8, siCntrl->param.cirgrp.mapPres, mBuf);
               CMCHKPK(SPkU8, siCntrl->param.cirgrp.mapType, mBuf);
               CMCHKPK(SPkU32,siCntrl->param.cirgrp.mapFormat, mBuf);
#endif
               for (i = MAX_SIZ_STATUS; i != 0; i--)
                  CMCHKPK(SPkU8, siCntrl->param.cirgrp.status[i - 1], mBuf);
               CMCHKPK(SPkU8, siCntrl->param.cirgrp.cgsmti, mBuf);
               CMCHKPK(SPkU8, siCntrl->param.cirgrp.range, mBuf);
               break;

            default:
               RETVALUE(RFAILED);
         }
         break;

      case SADBG:
         CMCHKPK(SPkU32, siCntrl->param.siDbg.dbgMask, mBuf);
         break;

#if SI_ACNT
      case SAACNT:
#endif
      case SAUSTA:
      case SATRC:
         break;
   }
#endif /* LMINT2 */

   CMCHKPK(SPkU8,        siCntrl->subAction, mBuf);
   CMCHKPK(SPkU8,        siCntrl->action,    mBuf);
   CMCHKPK(cmPkDateTime, &siCntrl->dt,       mBuf);
   /* si001.220, ADDED:  pack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(SPkU8,        bitVector,          mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}/* cmPkSiCntrl */


/*
*
*       Fun: cmUnpkSiCntrl   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiCntrl 
(
SiMngmt *cntrl,
Buffer  *mBuf
)
#else
PUBLIC S16 cmUnpkSiCntrl (cntrl, mBuf)
SiMngmt *cntrl;
Buffer  *mBuf;
#endif
{
   Cntr    i;
   Elmnt   elmnt;
   SiCntrl *siCntrl;
#if (SI_LMINT3 || SMSI_LMINT3)
   SiElmntId *siElmntId;
   SiElmntParam *siElmntParam;
#endif
   /* si001.220, ADDED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   U8 bitVector;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   TRC2(cmUnpkSiCntrl)

   elmnt   = cntrl->hdr.elmId.elmnt;
   siCntrl = &cntrl->t.cntrl;

   /* si001.220, ADDED: unpack the bit vector */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8,       &bitVector,           mBuf);
   /* bit vector */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkDateTime, &siCntrl->dt,        mBuf);
   CMCHKUNPK(SUnpkU8,        &siCntrl->action,    mBuf);
   CMCHKUNPK(SUnpkU8,        &siCntrl->subAction, mBuf);

#if (SI_LMINT3 || SMSI_LMINT3)
   switch (siCntrl->subAction)
   {
      case SAELMNT:
         siElmntId    = &siCntrl->s.siElmnt.elmntId;
         siElmntParam = &siCntrl->s.siElmnt.elmntParam;
         switch (elmnt)
         {
            case SI_STINTF:
               CMCHKUNPK(cmUnpkDpc,  &siElmntId->intfId, mBuf);
               break;

            case STICIR:
               CMCHKUNPK(SUnpkU32,   &siElmntId->circuit,      mBuf);
               CMCHKUNPK(SUnpkU8,    &siElmntParam->cir.swtch, mBuf);
               CMCHKUNPK(SUnpkU8,    &siElmntParam->cir.flag,  mBuf);
               break;

            case SI_STCIRGRP:
               /* si006.220, MODIFIED: unpack the fields related to force 
                * blocking
                */
               if (siCntrl->action == ABLK)
               {
                  CMCHKUNPK(cmUnpkSpId, &siElmntId->sapId,         mBuf);
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */
#if (LSIV2 || LSIV3 || LSIV4)
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->forblk.swtch,  mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->forblk.range,  mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->forblk.cgsmti, mBuf);
                  for (i = 1; i <= MAX_SIZ_STATUS; i++)
                     CMCHKUNPK(SUnpkU8, &siElmntParam->forblk.status[i - 1], mBuf);
                  CMCHKUNPK(cmUnpkDpc,  &siElmntParam->forblk.opc, mBuf);
                  CMCHKUNPK(cmUnpkDpc,  &siElmntParam->forblk.phyDpc, mBuf);
                  CMCHKUNPK(cmUnpkCic,  &siElmntParam->forblk.cic, mBuf);
#endif /* LSIV2 or LSIV3 or LSIV4 */
               }
               else
               {
                  CMCHKUNPK(SUnpkU32, &siElmntId->circuit,         mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.swtch,  mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.range,  mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.cgsmti, mBuf);
                  for (i = 1; i <= MAX_SIZ_STATUS; i++)
                     CMCHKUNPK(SUnpkU8, &siElmntParam->cirgr.status[i - 1], mBuf);
#if SS7_ANS95
   /* si001.220, MODIFIED: changes for ISUP rollup */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                  if (bitVector & LSI_SS7_ANS95_BIT) 
                  {
                     CMCHKUNPK(SUnpkU32, &siElmntParam->cirgr.mapFormat, mBuf);
                     CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.mapType, mBuf);
                     CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.mapPres, mBuf);
                  }
                  else
                  {
                     siElmntParam->cirgr.mapFormat = LSI_COMMON_DEF_VAL;
                     siElmntParam->cirgr.mapType = LSI_COMMON_DEF_VAL;
                     siElmntParam->cirgr.mapPres = LSI_COMMON_DEF_VAL;
                  }
#else
                  CMCHKUNPK(SUnpkU32, &siElmntParam->cirgr.mapFormat, mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.mapType, mBuf);
                  CMCHKUNPK(SUnpkU8,  &siElmntParam->cirgr.mapPres, mBuf);
#endif
#else /* variant flag is not defined */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                  if (bitVector & LSI_SS7_ANS95_BIT) 
                  {
                     U32 tempFormat;
                     U8  tempVal;
                  
                     CMCHKUNPK(SUnpkU32, &tempFormat, mBuf);
                     CMCHKUNPK(SUnpkU8,  &tempVal, mBuf);
                     CMCHKUNPK(SUnpkU8,  &tempVal, mBuf);
                  }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif
               }
               break;

            case STNSAP:
               CMCHKUNPK(cmUnpkSpId, &siElmntId->sapId,            mBuf);
               CMCHKUNPK(SUnpkU8, &siElmntParam->nsap.nsapType, mBuf);
               break;

            case STISAP:
               CMCHKUNPK(cmUnpkSpId,   &siElmntId->sapId,    mBuf);
               break;

            case STGRPUPSAP:
            case STGRPNSAP:
            case STALLSAP:
               CMCHKUNPK(cmUnpkProcId,   &siElmntId->dstProcId,        mBuf);
               /* though we unpack NSAP type always, its only used when group 
                * of NSAPs are controlled */
               CMCHKUNPK(SUnpkU8,   &siElmntParam->nsap.nsapType,   mBuf);
               break;
         }
         break;

      case SADBG:
         CMCHKUNPK(SUnpkU32, &siCntrl->s.siDbg.dbgMask, mBuf);
         break;

      case SATRC:
         /* si006.220, MODIFIED: should unpack nsapId first */
         CMCHKUNPK(cmUnpkSpId, &siCntrl->s.siTrc.nsapId,   mBuf);
         CMCHKUNPK(SUnpkS16,    &siCntrl->s.siTrc.nsapType, mBuf);
         break;
#ifdef SI_ACNT
      case SAACNT:
#endif
      case SAUSTA:
         break;
   }
#else /* LMINT2 */
   switch (siCntrl->subAction)
   {
      case SAELMNT:
         switch (elmnt)
         {
            case SI_STCIRGRP:
               CMCHKUNPK(SUnpkU8, &siCntrl->param.cirgrp.range, mBuf);
               CMCHKUNPK(SUnpkU8, &siCntrl->param.cirgrp.cgsmti, mBuf);
               for (i = 0; i < MAX_SIZ_STATUS; i++)
                  CMCHKUNPK(SUnpkU8, &siCntrl->param.cirgrp.status[i], mBuf);
#if SS7_ANS95
               CMCHKUNPK(SUnpkU32,&siCntrl->param.cirgrp.mapFormat, mBuf);
               CMCHKUNPK(SUnpkU8, &siCntrl->param.cirgrp.mapType, mBuf);
               CMCHKUNPK(SUnpkU8, &siCntrl->param.cirgrp.mapPres, mBuf);
#endif

            /* FALL THRU' */
            case STICIR:
            case STNSAP:
               CMCHKUNPK(cmUnpkCirId, &siCntrl->sigpt.cirId, mBuf);
               break;

            case SI_STINTF:
               CMCHKUNPK(cmUnpkDpc, &siCntrl->sigpt.intfId, mBuf);
               break;
         }
         break;

      case SADBG:
         CMCHKUNPK(SUnpkU32, &siCntrl->param.siDbg.dbgMask, mBuf);
         break;

      case SATRC:
#ifdef SI_ACNT
      case SAACNT:
#endif
      case SAUSTA:
         break;
   }
#endif /* LMINT2 */

   RETVALUE(ROK);
}/* cmUnpkSiCntrl */



/*
*
*       Fun: cmPkSiSsta   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
/* si006.220, MODIFIED: change to pass the pst into function */
PUBLIC S16 cmPkSiSsta 
(
SiMngmt *ssta,
Pst     *pst,
Buffer  *mBuf
)
#else
PUBLIC S16 cmPkSiSsta (ssta, pst, mBuf)
SiMngmt *ssta;
Pst     *pst;
Buffer *mBuf;
#endif
{
   Cntr i;
   SiSsta *siSsta;
   /* si025.220, ADDED: or LSIV4 flag  */
   /* si009.220, ADDED: or LSIV3 flag  */
   /* si006.220, ADDED: add a return value */
   /* si007.220, ADDED: added flags to avoid compilation warnings */
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
   S16 ret1;
#endif 

   TRC2(cmPkSiSsta)

   siSsta = &ssta->t.ssta;

#if (SI_LMINT3 || SMSI_LMINT3)
   switch (ssta->hdr.elmId.elmnt)
   {
      case SI_STCIRGRP: 
         /* in the new approach circuits states are packed according
          * to circuit state indicators in circuit query messages
          */
         for (i = siSsta->param.cirgr.range; i >= 0; i--)
            CMCHKPK(SPkU8,  siSsta->cfm.s.cir.state[i], mBuf);
         CMCHKPK(SPkU8,     siSsta->param.cirgr.range,   mBuf);
         CMCHKPK(cmPkCirId, siSsta->elmntId.circuit,         mBuf);
         break;

      case SI_STINTF:
         CMCHKPK(SPkU8,    siSsta->cfm.s.intf.state,   mBuf);
         CMCHKPK(cmPkDpc,  siSsta->elmntId.intfId,    mBuf);
         break;

      case STSID:
          CMCHKPK(cmPkSystemId, &siSsta->cfm.s.sid, mBuf);
          break;
      /* si025.220 - Modified: Add LSIV4 flag */
      /* si009.220 - Modified: Add LSIV3 flag and put the checking of return
       * value under ERRCLASS flag
       */
      /* si007.220 - Modified: Add LSIV2 and TDS_ROLL_UPGRADE_SUPPORT
       * flags for these situations.
       */
      /* si006.220, MODIFIED: remove TDS_ROLL_UPGRADE_SUPPORT flag and
       * pass the pst to funciton cmPkSiSAPSta
       */
      /* pack the SAP information to query the version info */
      case STNSAP:
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
         ret1 = cmPkSiSAPSta(&siSsta->cfm.s.siSAPVer, mBuf, pst); 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
            RETVALUE(ret1);
#endif /* ERRCLASS & ERRCLS_DEBUG */
#endif /* LSIV2 || LSIV3 || LSIV4 || TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKPK(SPkU8, siSsta->param.nsap.nsapType, mBuf);
         CMCHKPK(cmPkSpId, siSsta->elmntId.sapId, mBuf);
         break;

      case STISAP:
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
         ret1 = cmPkSiSAPSta(&siSsta->cfm.s.siSAPVer, mBuf, pst); 
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
            RETVALUE(ret1);
#endif /* ERRCLASS & ERRCLS_DEBUG */
#endif /* LSIV2 || LSIV3 || LSIV4 || TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKPK(cmPkSpId, siSsta->elmntId.sapId, mBuf);
         break;

      default:
         break;
   }
#else /* LMINT2 */

   CMCHKPK(SPkU8, siSsta->s.siCirSta.callState, mBuf);
   for (i = NUMCIREVTGRP; i != 0; i--)
      CMCHKPK(SPkU8, siSsta->s.siCirSta.transState[i-1], mBuf);

#endif
   CMCHKPK(cmPkDateTime, &siSsta->dt, mBuf);

   RETVALUE(ROK);
}/* cmPkSiSsta */


/*
*
*       Fun: cmUnpkSiSsta   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
/* si006.220, MODIFIED: change to pass the pst into function */
PUBLIC S16 cmUnpkSiSsta 
(
SiMngmt *ssta,
Pst     *pst,
Buffer  *mBuf
)
#else
PUBLIC S16 cmUnpkSiSsta (ssta, pst, mBuf)
SiMngmt *ssta;
Pst     *pst;
Buffer  *mBuf;
#endif
{
   Cntr   i;
   SiSsta *siSsta;
   /* si025.220, Added: add LSIV4 flag */
   /* si009.220, Added: add LSIV3 flag */
   /* si006.220, ADDED: add a return value */
   /* si007.220, ADDED: add flags to avoid compilation warnings */
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
   S16 ret1;
#endif
   /* si008.220, Added: added a part number char array */
   Txt     ptNmb[SI_MAXTXTLEN];

   TRC2(cmUnpkSiSsta)

   siSsta = &ssta->t.ssta;

   CMCHKUNPK(cmUnpkDateTime, &siSsta->dt, mBuf);
#if (SI_LMINT3 || SMSI_LMINT3)
   switch (ssta->hdr.elmId.elmnt)
   {
      case SI_STCIRGRP: 
         /* in the new approach circuits states are packed according
          * to circuit state indicators in circuit query messages
          */
         CMCHKUNPK(cmUnpkCirId,&siSsta->elmntId.circuit,       mBuf);
         CMCHKUNPK(SUnpkU8,    &siSsta->param.cirgr.range, mBuf);
         for (i = 0; i <= siSsta->param.cirgr.range; i++)
            CMCHKUNPK(SUnpkU8, &siSsta->cfm.s.cir.state[i], mBuf);
         break;

      case SI_STINTF:
         CMCHKUNPK(cmUnpkDpc,  &siSsta->elmntId.intfId,    mBuf);
         CMCHKUNPK(SUnpkU8,    &siSsta->cfm.s.intf.state,   mBuf);
         break;

      case STSID:
         /* si008.220, Added: allocate memory for part number array */
         siSsta->cfm.s.sid.ptNmb = (Txt *) ptNmb;
         CMCHKUNPK(cmUnpkSystemId, &siSsta->cfm.s.sid, mBuf);
         break;

      /* si025.220 - Modified: add LSIV4 flag */
      /* si009.220 - Modified: add LSIV3 flag and put the checkinf of
       * return value under ERRCLASS flag
       */
      /* si007.220 - Modified: add LSIV2 and TDS_ROLL_UPGRADE_SUPPORT
       * flags for these situation.
       */
      /* si006.220, MODIFIED: remove TDS_ROLL_UPGRADE_SUPPORT flag and
       * pass the pst tp function cmUnpkSiSAPSta
       */
      /* unpack the SAP information */
      case STNSAP:
         CMCHKUNPK(cmUnpkSpId, &siSsta->elmntId.sapId, mBuf);
         CMCHKUNPK(SUnpkU8, &siSsta->param.nsap.nsapType, mBuf);
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
         ret1 = cmUnpkSiSAPSta( &siSsta->cfm.s.siSAPVer, mBuf, pst);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
            RETVALUE(ret1);
#endif /* ERRCLASS & ERRCLS_DEBUG */
#endif /* LSIV2 || LSIV3 || LSIV4 || TDS_ROLL_UPGRADE_SUPPORT */
         break;

      case STISAP:
         CMCHKUNPK(cmUnpkSpId, &siSsta->elmntId.sapId, mBuf);
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))
         ret1 = cmUnpkSiSAPSta( &siSsta->cfm.s.siSAPVer, mBuf, pst);
#if (ERRCLASS & ERRCLS_DEBUG)
         if (ret1 != ROK)
            RETVALUE(ret1);
#endif /* ERRCLASS & ERRCLS_DEBUG */
#endif 
         break;
      default:
         break;
   }
#else /* LMINT2 */
   for (i = 0; i < NUMCIREVTGRP; i++)
      CMCHKUNPK(SUnpkU8, &siSsta->s.siCirSta.transState[i], mBuf);
   CMCHKUNPK(SUnpkU8, &siSsta->s.siCirSta.callState, mBuf);
#endif

   RETVALUE(ROK);
} /* cmUnpkSiSsta */

#if (SI_LMINT3 || SMSI_LMINT3)


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiUstaDgnVal 
(
SiUstaDgnVal *dgnVal, 
Buffer       *mBuf
)
#else
PRIVATE S16 cmPkSiUstaDgnVal (dgnVal, mBuf)
SiUstaDgnVal *dgnVal;
Buffer       *mBuf;
#endif
{
   TRC2(cmPkSiUstaDgnVal)

   switch (dgnVal->type)
   {
      case LSI_USTA_DGNVAL_NONE:
         break;

      case LSI_USTA_DGNVAL_EVENT:
         CMCHKPK(cmPkEvent, dgnVal->t.event, mBuf);
         break;

      case LSI_USTA_DGNVAL_SPID:
         CMCHKPK(cmPkSpId, dgnVal->t.spId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SUID:
         CMCHKPK(cmPkSuId, dgnVal->t.suId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SPINSTID:
         CMCHKPK(cmPkSiInstId, dgnVal->t.spInstId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SUINSTID:
         CMCHKPK(cmPkSiInstId, dgnVal->t.suInstId, mBuf);
         break;

      case LSI_USTA_DGNVAL_CIRCUIT:
         CMCHKPK(cmPkCirId, dgnVal->t.cirId, mBuf);
         break;

      case LSI_USTA_DGNVAL_CIC:
         CMCHKPK(cmPkCic, dgnVal->t.cic, mBuf);
         break;
/* si007.220 - Added: for packing dpc in  LSI_USTA_DGNVAL_DPC type.
 */
      case LSI_USTA_DGNVAL_DPC:
         CMCHKPK(cmPkDpc, dgnVal->t.dpc, mBuf);
         break;

      case LSI_USTA_DGNVAL_INTF:
         CMCHKPK(cmPkDpc, dgnVal->t.intfId, mBuf);
         break;

      case LSI_USTA_DGNVAL_ADDRS:
      case LSI_USTA_DGNVAL_STATUS_OCTS:
         CMCHKPK(cmPkAddrs, &dgnVal->t.addrStatus, mBuf);
         break;

      case LSI_USTA_DGNVAL_SWTCH:
         CMCHKPK(cmPkSwtch, dgnVal->t.swtch, mBuf);
         break;

      case LSI_USTA_DGNVAL_RANGE:
         CMCHKPK(SPkU8, dgnVal->t.range, mBuf);
         break;
   }

   CMCHKPK(SPkU8, dgnVal->type, mBuf)
   RETVALUE(ROK);
}/* cmPkSiUstaDgnVal */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiUstaDgnVal 
(
SiUstaDgnVal *dgnVal,
Buffer       *mBuf
)
#else
PRIVATE S16 cmUnpkSiUstaDgnVal (dgnVal, mBuf)
SiUstaDgnVal *dgnVal;
Buffer       *mBuf;
#endif
{
   TRC2(cmUnpkSiUstaDgnVal)

   CMCHKUNPK(SUnpkU8, &dgnVal->type, mBuf)
   switch (dgnVal->type)
   {
      case LSI_USTA_DGNVAL_NONE:
         break;

      case LSI_USTA_DGNVAL_EVENT:
         CMCHKUNPK(cmUnpkEvent, &dgnVal->t.event, mBuf);
         break;

      case LSI_USTA_DGNVAL_SPID:
         CMCHKUNPK(cmUnpkSpId, &dgnVal->t.spId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SUID:
         CMCHKUNPK(cmUnpkSuId, &dgnVal->t.suId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SPINSTID:
         CMCHKUNPK(cmUnpkSiInstId, &dgnVal->t.spInstId, mBuf);
         break;

      case LSI_USTA_DGNVAL_SUINSTID:
         CMCHKUNPK(cmUnpkSiInstId, &dgnVal->t.suInstId, mBuf);
         break;

      case LSI_USTA_DGNVAL_CIRCUIT:
         CMCHKUNPK(cmUnpkCirId, &dgnVal->t.cirId, mBuf);
         break;

      case LSI_USTA_DGNVAL_CIC:
         CMCHKUNPK(cmUnpkCic, &dgnVal->t.cic, mBuf);
         break;
/* si007.220 - Added: for unpacking dpc in LSI_USTA_DGNVAL_DPC type.
 */
      case LSI_USTA_DGNVAL_DPC:
         CMCHKUNPK(cmUnpkDpc, &dgnVal->t.dpc, mBuf);
         break;

      case LSI_USTA_DGNVAL_INTF:
         CMCHKUNPK(cmUnpkDpc, &dgnVal->t.intfId, mBuf);
         break;
      
      case LSI_USTA_DGNVAL_ADDRS:
      case LSI_USTA_DGNVAL_STATUS_OCTS:
         CMCHKUNPK(cmUnpkAddrs, &dgnVal->t.addrStatus, mBuf);
         break;

      case LSI_USTA_DGNVAL_SWTCH:
         CMCHKUNPK(cmUnpkSwtch, &dgnVal->t.swtch, mBuf);
         break;

      case LSI_USTA_DGNVAL_RANGE:
         CMCHKUNPK(SUnpkU8, &dgnVal->t.range, mBuf);
         break;
   }

   RETVALUE(ROK);
}/* cmUnpkSiUstaDgnVal */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkSiUstaDgn 
(
SiUstaDgn *ustaDgn,
Buffer    *mBuf
)
#else
PRIVATE S16 cmPkSiUstaDgn (ustaDgn, mBuf)
SiUstaDgn *ustaDgn;
Buffer    *mBuf;
#endif
{
   U8 i;

   TRC2(cmPkSiUstaDgn)

   for (i = LSI_USTA_MAX_DGNVAL; i > 0; i--)
   {
      CMCHKPK(cmPkSiUstaDgnVal, &ustaDgn->dgnVal[i - 1], mBuf)
   }

   RETVALUE(ROK);
}/* cmPkSiUstaDgn */


/*
*
*       Fun:   
*
*       Desc:  
*              
*       Ret:   
*
*       Notes: 
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkSiUstaDgn 
(
SiUstaDgn *ustaDgn,
Buffer    *mBuf
)
#else
PRIVATE S16 cmUnpkSiUstaDgn (ustaDgn, mBuf)
SiUstaDgn *ustaDgn;
Buffer    *mBuf;
#endif
{
   U8 i;

   TRC2(cmUnpkSiUstaDgn)

   for (i = 0; i < LSI_USTA_MAX_DGNVAL; i++)
   {
      CMCHKUNPK(cmUnpkSiUstaDgnVal, &ustaDgn->dgnVal[i], mBuf)
   }

   RETVALUE(ROK);
}/* cmUnpkSiUstaDgn */

#endif


/*
*
*       Fun: cmPkSiUsta   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiUsta 
(
SiMngmt *usta,
Buffer  *mBuf
)
#else
PUBLIC S16 cmPkSiUsta (usta, mBuf)
SiMngmt *usta;
Buffer  *mBuf;
#endif
{
   SiUsta *siUsta;

   TRC2(cmPkSiUsta)

   siUsta = &usta->t.usta;

#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKPK(cmPkSiUstaDgn,   &siUsta->dgn,   mBuf);
   CMCHKPK(cmPkCmAlarm,     &siUsta->alarm, mBuf);
#else
   CMCHKPK(SPkU32, siUsta->circuit, mBuf);
   CMCHKPK(SPkU16, siUsta->evnt,    mBuf);
   CMCHKPK(cmPkDateTime, &siUsta->dt, mBuf);
#endif

   RETVALUE(ROK);
}/* cmPkSiUsta */


/*
*
*       Fun: cmUnpkSiUsta   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiUsta 
(
SiMngmt *usta,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSiUsta (usta, mBuf)
SiMngmt *usta;
Buffer  *mBuf;
#endif
{
   SiUsta *siUsta;

   TRC2(cmUnpkSiUsta)

   siUsta = &usta->t.usta;

#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKUNPK(cmUnpkCmAlarm,     &siUsta->alarm,     mBuf);
   CMCHKUNPK(cmUnpkSiUstaDgn,   &siUsta->dgn,       mBuf);
#else
   CMCHKUNPK(cmUnpkDateTime, &siUsta->dt, mBuf);
   CMCHKUNPK(SUnpkU16, &siUsta->evnt,    mBuf);
   CMCHKUNPK(SUnpkU32, &siUsta->circuit, mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiUsta */


/*
*
*       Fun: cmPkSiTrc   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiTrc 
(
SiMngmt  *trc,
Buffer   *mBuf
)
#else
PUBLIC S16 cmPkSiTrc (trc, mBuf)
SiMngmt  *trc;
Buffer *mBuf;
#endif
{
   S16   i;
   SiTrc *siTrc;

   TRC2(cmPkSiTrc)

   siTrc = &trc->t.trc;

   for (i = 0; i < siTrc->length; i++)
      CMCHKPK(SPkU8,     siTrc->evntParm[i], mBuf);
   CMCHKPK(SPkS16,       siTrc->length,      mBuf);
   CMCHKPK(cmPkDpc,      siTrc->phyDpc,      mBuf);
   CMCHKPK(SPkU8,        siTrc->sapType,     mBuf);
   CMCHKPK(SPkU16,       siTrc->evnt,        mBuf);
   CMCHKPK(cmPkDateTime, &siTrc->dt,         mBuf);

   RETVALUE(ROK);
}/* cmPkSiTrc */


/*
*
*       Fun: cmUnpkSiTrc   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiTrc 
(
SiMngmt *trc,
Buffer  *mBuf
)
#else
PUBLIC S16 cmUnpkSiTrc (trc, mBuf)
SiMngmt *trc;
Buffer  *mBuf;
#endif
{
   Cntr i;
   SiTrc *siTrc;

   TRC2(cmUnpkSiTrc)

   siTrc = &trc->t.trc;

   CMCHKUNPK(cmUnpkDateTime, &siTrc->dt,         mBuf);
   CMCHKUNPK(SUnpkU16,       &siTrc->evnt,        mBuf);
   CMCHKUNPK(SUnpkU8,        &siTrc->sapType,     mBuf);
   CMCHKUNPK(cmUnpkDpc,      &siTrc->phyDpc,      mBuf);
   CMCHKUNPK(SUnpkS16,       &siTrc->length,      mBuf);
   for (i = (siTrc->length-1); i >= 0; i--)
      CMCHKUNPK(SUnpkU8,     &siTrc->evntParm[i], mBuf);

   RETVALUE(ROK);
}/* cmUnpkSiTrc */

#ifdef SI_ACNT

/*
*
*       Fun: cmPkSiAcnt   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiAcnt 
(
SiMngmt *acnt,
Buffer  *mBuf
)
#else
PUBLIC S16 cmPkSiAcnt (acnt, mBuf)
SiMngmt *acnt;
Buffer *mBuf;
#endif
{
   SiAcnt *siAcnt;

   TRC2(cmPkSiAcnt)

   siAcnt = &acnt->t.siAcnt;

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKPK(cmPkAddrs, &siAcnt->acntRec.chrgNum, mBuf);
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   CMCHKPK(SPkU8,     siAcnt->acntRec.numCirUsed, mBuf);
#endif
   CMCHKPK(cmPkAddrs, &siAcnt->acntRec.srcAdr,  mBuf);
   CMCHKPK(cmPkAddrs, &siAcnt->acntRec.dstAdr,  mBuf);
   CMCHKPK(cmPkTicks, siAcnt->acntRec.calDura,  mBuf);
   CMCHKPK(cmPkDateTime, &siAcnt->dt,           mBuf);
   RETVALUE(ROK);
}/* cmPkSiAcnt */


/*
*
*       Fun: cmUnpkSiAcnt   
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiAcnt 
(
SiMngmt *acnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkSiAcnt (acnt, mBuf)
SiMngmt *acnt;
Buffer *mBuf;
#endif
{
   SiAcnt *siAcnt;

   TRC2(cmUnpkSiAcnt)

   siAcnt = &acnt->t.siAcnt;

   CMCHKUNPK(cmUnpkDateTime, &siAcnt->dt,           mBuf);
   CMCHKUNPK(cmUnpkTicks, &siAcnt->acntRec.calDura, mBuf);
   CMCHKUNPK(cmUnpkAddrs, &siAcnt->acntRec.dstAdr,  mBuf);
   CMCHKUNPK(cmUnpkAddrs, &siAcnt->acntRec.srcAdr,  mBuf);
#if (SS7_ANS95 || SS7_ITU97 || SS7_ETSIV3)
   CMCHKUNPK(SUnpkU8,    &siAcnt->acntRec.numCirUsed,  mBuf);
#endif
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL)
   CMCHKUNPK(cmUnpkAddrs, &siAcnt->acntRec.chrgNum, mBuf);
#endif

   RETVALUE(ROK);
}/* cmUnpkSiAcnt */

#endif /* SI_ACNT */


/*
*
*       Fun:   cmPkLsiCfgReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiCfgReq 
(
Pst     *pst,
SiMngmt *cfg
)
#else
PUBLIC S16 cmPkLsiCfgReq (pst, cfg)
Pst     *pst;
SiMngmt *cfg;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiCfgReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiCfg,  cfg,       mBuf, ELSI001, pst);
   CMCHKPKLOG(cmPkHeader, &cfg->hdr, mBuf, ELSI002, pst); 

   pst->event = (Event) EVTLSICFGREQ;

   /* si001.220, ADDED: Changes for rolling upgrade */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* Fill interface version of the Layer Managers in post structure */
   pst->intfVer = LSIIFVER;
#endif
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}/* cmPkLsiCfgReq */


/*
*
*       Fun:   cmUnpkLsiCfgReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiCfgReq 
(
LsiCfgReq  func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkLsiCfgReq (func, pst, mBuf)
LsiCfgReq  func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SiMngmt cfg;
/* si009.220 - Added: added a return Value. */
   S16 ret1;

   TRC2(cmUnpkLsiCfgReq)

   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ELSI003, pst); 
/* si009.220 - Modified: to pass pst into cmUnpkSiCfg. */
   ret1 = cmUnpkSiCfg(&cfg, mBuf, pst);
#if (ERRCLASS & ERRCLS_DEBUG)
   if (ret1 != ROK)
   {
      SPutMsg(mBuf);
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, 
                __LINE__, (ErrCls) ERRCLS_ADD_RES, ELSI004, (ErrVal)ret1,
                "Unpacking cfg failure"); 
      RETVALUE(ret1);
   }
#endif
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &cfg) );
}/* cmUnpkLsiCfgReq */




/*
*
*       Fun:   cmPkLsiCntrlReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiCntrlReq 
(
Pst *pst,
SiMngmt *cntrl
)
#else
PUBLIC S16 cmPkLsiCntrlReq (pst, cntrl)
Pst *pst;
SiMngmt *cntrl;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiCntrlReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiCntrl, cntrl,       mBuf, ELSI005, pst);
   CMCHKPKLOG(cmPkHeader,  &cntrl->hdr, mBuf, ELSI006, pst); 

   pst->event = (Event) EVTLSICNTRLREQ;

   /* si001.220, ADDED: Changes for rolling upgrade */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* Fill interface version of the Layer Managers in post structure */
   pst->intfVer = LSIIFVER;
#endif

   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiCntrlReq */


/*
*
*       Fun:   cmUnpkLsiCntrlReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiCntrlReq 
(
LsiCntrlReq  func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkLsiCntrlReq (func, pst, mBuf)
LsiCntrlReq  func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SiMngmt cntrl;

   TRC2(cmUnpkLsiCntrlReq)

   CMCHKUNPKLOG(cmUnpkHeader,  &cntrl.hdr, mBuf, ELSI007, pst); 
   CMCHKUNPKLOG(cmUnpkSiCntrl, &cntrl,      mBuf, ELSI008, pst);
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &cntrl) );
}/* cmUnpkLsiCntrlReq */

#if (SI_LMINT3 || SMSI_LMINT3)

/*
*
*       Fun:  cmPkLsiCfgCfm    
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiCfgCfm 
(
Pst     *pst,
SiMngmt *cfm
)
#else
PUBLIC S16 cmPkLsiCfgCfm (pst, cfm)
Pst     *pst;
SiMngmt *cfm;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiCfgCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);
  
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSI009, pst); 
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ELSI010, pst); 

   pst->event = (Event) EVTLSICFGCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}/* cmPkLsiCfgCfm */


/*
*
*       Fun:  cmUnpkLsiCfgCfm 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiCfgCfm 
(
LsiCfgCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkLsiCfgCfm (func, pst, mBuf)
LsiCfgCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SiMngmt cfm;

   TRC2(cmUnpkLsiCfgCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELSI011, pst); 
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSI012, pst); 
   
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &cfm) );
}/* cmUnpkLsiCfgCfm */


/*
*
*       Fun:  cmPkLsiCntrlCfm
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiCntrlCfm 
(
Pst         *pst,
SiMngmt     *cfm
)
#else
PUBLIC S16 cmPkLsiCntrlCfm ( pst, cfm)
Pst         *pst;
SiMngmt     *cfm;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiCntrlCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);
  
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELSI013, pst); 
   CMCHKPKLOG(cmPkHeader,   &cfm->hdr, mBuf, ELSI014, pst); 

   pst->event = (Event) EVTLSICNTRLCFM;
   SPstTsk(pst, mBuf);
   RETVALUE(ROK);
}/* cmPkLsiCntrlCfm */


/*
*
*       Fun:   cmUnpkLsiCntrlCfm 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiCntrlCfm 
(
LsiCntrlCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkLsiCntrlCfm (func, pst, mBuf)
LsiCntrlCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SiMngmt cfm;

   TRC2(cmUnpkLsiCntrlCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELSI015, pst); 
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELSI016, pst); 
   
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &cfm) );
}/* cmUnpkLsiCntrlCfm */

#endif /* (SI_LMINT3 || SMSI_LMINT3) */

/*
*
*       Fun:   cmPkLsiStaReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiStaReq 
(
Pst     *pst,
SiMngmt *sta
)
#else
PUBLIC S16 cmPkLsiStaReq (pst, sta)
Pst     *pst;
SiMngmt *sta;
#endif
{
   Buffer *mBuf;
   /* si008.220, Deleted: deleted unused variable ret1  */
   
   TRC2(cmPkLsiStaReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   /* si006.220, MODIFIED: change code to pass pst to cmPkSiSsta */
   /* si008.220, Modified: change code only to pack the fields that needs to
    * be packed.
    */
   switch (sta->hdr.elmId.elmnt)
   {
#if (SI_LMINT3 || SMSI_LMINT3)
      case SI_STCIRGRP: 
         CMCHKPKLOG(SPkU8, sta->t.ssta.param.cirgr.range, mBuf, ELSIXXX, pst);
         CMCHKPKLOG(cmPkCirId, sta->t.ssta.elmntId.circuit, mBuf, ELSIXXX, pst);
         break;

      case SI_STINTF:
         CMCHKPKLOG(cmPkDpc,  sta->t.ssta.elmntId.intfId, mBuf, ELSIXXX, pst);
         break;

      case STSID:
         break;

#else 
      case STICIR:
         break;
#endif

      case STNSAP:
         CMCHKPKLOG(SPkU8, sta->t.ssta.param.nsap.nsapType, mBuf, ELSIXXX, pst);
         CMCHKPKLOG(cmPkSpId, sta->t.ssta.elmntId.sapId, mBuf, ELSIXXX, pst);
         break;

      case STISAP:
         CMCHKPKLOG(cmPkSpId, sta->t.ssta.elmntId.sapId, mBuf, ELSIXXX, pst);
         break;

      default:
         break;
   }
   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELSIXXX, pst);   
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELSI018, pst); 

   pst->event = (Event) EVTLSISTAREQ;
   /* si001.220, ADDED: Changes for rolling upgrade */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* Fill interface version of the Layer Managers in post structure */
   pst->intfVer = LSIIFVER;
#endif
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiStaReq */


/*
*
*       Fun:   cmUnpkLsiStaReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiStaReq 
(
LsiStaReq  func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkLsiStaReq (func, pst, mBuf)
LsiStaReq  func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SiMngmt sta;
   /* si008.220, Deleted: remove unused variable ret1  */

   TRC2(cmUnpkLsiStaReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELSI019, pst); 
   /* si008.220, Modified: change code to unpack the primitive one field 
    * by another.
    */
   /* si006.220, MODIFIED: change code to pass pst to cmUnpkSiSsta */ 
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELSIXXX, pst);

   switch (sta.hdr.elmId.elmnt)
   {
#if (SI_LMINT3 || SMSI_LMINT3)
      case SI_STCIRGRP: 
         /* in the new approach circuits states are packed according
          * to circuit state indicators in circuit query messages
          */
         CMCHKUNPKLOG(cmUnpkCirId,&sta.t.ssta.elmntId.circuit, mBuf, ELSIXXX, pst);
         CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.param.cirgr.range, mBuf, ELSIXXX, pst);
         break;

      case SI_STINTF:
         CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.elmntId.intfId, mBuf, ELSIXXX, pst);
         break;

      case STSID:
         break;

#else 
      case STICIR:
         break;
#endif
   
      /* unpack the SAP information */
      case STNSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &sta.t.ssta.elmntId.sapId, mBuf, ELSIXXX, pst);
         CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.param.nsap.nsapType, mBuf, ELSIXXX, pst);
         break;

      case STISAP:
         CMCHKUNPKLOG(cmUnpkSpId, &sta.t.ssta.elmntId.sapId, mBuf, ELSIXXX, pst);
         break;

      default:
         break;
   }

   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &sta) );
}/* cmUnpkLsiStaReq */


/*
*
*       Fun:   cmPkLsiStaCfm 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiStaCfm 
(
Pst     *pst,
SiMngmt *sta
)
#else
PUBLIC S16 cmPkLsiStaCfm (pst, sta)
Pst     *pst;
SiMngmt *sta;
#endif
{
   Buffer *mBuf;
   /* si006.220, ADDED: add a return value */
   S16    ret1;

   TRC2(cmPkLsiStaCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   /* si006.220, MODIFIED: change code to pass pst to cmPkSiSsta */
   ret1 = cmPkSiSsta(sta, pst, mBuf);
   if (ret1 != ROK)
   {
      SPutMsg(mBuf); \
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
                 __LINE__, (ErrCls) ERRCLS_ADD_RES, ELSI021, (ErrVal)ret1, \
                   "Packing sta failure"); \
      RETVALUE(ret1); \
   }
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELSI022, pst); 
#endif
   CMCHKPKLOG(cmPkHeader,   &sta->hdr, mBuf, ELSI023, pst); 

   pst->event = (Event) EVTLSISTACFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiStaCfm */


/*
*
*       Fun:   cmUnpkLsiStaCfm 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiStaCfm 
(
LsiStaCfm  func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkLsiStaCfm (func, pst, mBuf)
LsiStaCfm  func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SiMngmt sta;
   /* si006.220, ADDED: added a return value */
   S16    ret1;

   TRC2(cmUnpkLsiStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELSI024, pst); 
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ELSI025, pst); 
#endif
   /* si006.220, MODIFIED: change code to pass pst to cmUnpkSiSsta */
   ret1 = cmUnpkSiSsta(&sta, pst, mBuf);
   if (ret1 != ROK)
   {
      SPutMsg(mBuf); \
      SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId, __FILE__, \
                 __LINE__, (ErrCls) ERRCLS_ADD_RES, ELSI026, (ErrVal)ret1, \
                   "Unpacking sta failure"); \
      RETVALUE(ret1); \
   }
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &sta) );
}/* cmUnpkLsiStaCfm */


/*
*
*       Fun:   cmPkLsiStsReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiStsReq 
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 cmPkLsiStsReq (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiStsReq)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiSts,    sts,       mBuf, ELSI027, pst);
   CMCHKPKLOG(cmPkHeader,   &sts->hdr, mBuf, ELSI028, pst); 
   CMCHKPKLOG(cmPkAction,   action,    mBuf, ELSI029, pst);

   pst->event = (Event) EVTLSISTSREQ;
   /* si001.220, ADDED: Changes for rolling upgrade */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   /* Fill interface version of the Layer Managers in post structure */
   pst->intfVer = LSIIFVER;
#endif
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiStsReq */


/*
*
*       Fun:   cmUnpkLsiStsReq 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiStsReq 
(
LsiStsReq func,
Pst    *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLsiStsReq (func, pst, mBuf)
LsiStsReq func;
Pst    *pst;
Buffer *mBuf;
#endif
{
   SiMngmt sts;
   Action  action;

   TRC2(cmUnpkLsiStsReq)

   CMCHKUNPKLOG(cmUnpkAction,  &action,   mBuf, ELSI030, pst);
   CMCHKUNPKLOG(cmUnpkHeader,  &sts.hdr, mBuf, ELSI031, pst); 
   CMCHKUNPKLOG(cmUnpkSiSts,   &sts,      mBuf, ELSI032, pst);

   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, action, &sts) );
}/* cmUnpkLsiStsReq */


/*
*
*       Fun:   cmPkLsiStsCfm 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiStsCfm 
(
Pst     *pst,
Action  action,
SiMngmt *sts
)
#else
PUBLIC S16 cmPkLsiStsCfm (pst, action, sts)
Pst     *pst;
Action  action;
SiMngmt *sts;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiStsCfm)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiSts,   sts,       mBuf, ELSI033, pst);
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELSI034, pst); 
#endif
   CMCHKPKLOG(cmPkHeader,  &sts->hdr, mBuf, ELSI035, pst); 
   CMCHKPKLOG(cmPkAction,  action,    mBuf, ELSI036, pst);

   pst->event = (Event) EVTLSISTSCFM;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiStsCfm */


/*
*
*       Fun:   cmUnpkLsiStsCfm
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiStsCfm
(
LsiStsCfm func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkLsiStsCfm (func, pst, mBuf)
LsiStsCfm func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SiMngmt sts;
   Action  action;

   TRC2(cmUnpkLsiStsCfm)

   CMCHKUNPKLOG(cmUnpkAction,  &action,   mBuf, ELSI037, pst);
   CMCHKUNPKLOG(cmUnpkHeader,  &sts.hdr, mBuf, ELSI038, pst); 
#if (SI_LMINT3 || SMSI_LMINT3)
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm, mBuf, ELSI039, pst); 
#endif
   CMCHKUNPKLOG(cmUnpkSiSts,   &sts,      mBuf, ELSI040, pst);

   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, action, &sts) );
}/* cmUnpkLsiStsCfm */


/*
*
*       Fun:   cmPkLsiStaInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiStaInd 
(
Pst     *pst,
SiMngmt *usta
)
#else
PUBLIC S16 cmPkLsiStaInd (pst, usta)
Pst     *pst;
SiMngmt *usta;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiStaInd)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiUsta, usta,       mBuf, ELSI041, pst);
   CMCHKPKLOG(cmPkHeader, &usta->hdr, mBuf, ELSI042, pst); 

   pst->event = (Event) EVTLSISTAIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiStaInd */


/*
*
*       Fun:   cmUnpkLsiStaInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiStaInd 
(
LsiStaInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkLsiStaInd (func, pst, mBuf)
LsiStaInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SiMngmt usta;

   TRC2(cmUnpkLsiStaInd)

   CMCHKUNPKLOG(cmUnpkHeader, &usta.hdr, mBuf, ELSI043, pst); 
   CMCHKUNPKLOG(cmUnpkSiUsta, &usta,      mBuf, ELSI044, pst);

   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &usta) );
}/* cmUnpkLsiStaInd */


/*
*
*       Fun:   cmPkLsiTrcInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiTrcInd 
(
Pst     *pst,
SiMngmt *trc
)
#else
PUBLIC S16 cmPkLsiTrcInd (pst, trc)
Pst     *pst;
SiMngmt *trc;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiTrcInd)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiTrc,  trc,       mBuf, ELSI045, pst);
   CMCHKPKLOG(cmPkHeader, &trc->hdr, mBuf, ELSI046, pst);

   pst->event = (Event) EVTLSITRCIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiTrcInd */


/*
*
*       Fun:   cmUnpkLsiTrcInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiTrcInd 
(
LsiTrcInd func,
Pst       *pst,
Buffer    *mBuf
)
#else
PUBLIC S16 cmUnpkLsiTrcInd (func, pst, mBuf)
LsiTrcInd func;
Pst       *pst;
Buffer    *mBuf;
#endif
{
   SiMngmt trc;

   TRC2(cmUnpkLsiTrcInd)

   CMCHKUNPKLOG(cmUnpkHeader, &trc.hdr, mBuf, ELSI047, pst);
   CMCHKUNPKLOG(cmUnpkSiTrc,  &trc,      mBuf, ELSI048, pst);
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &trc) );
}/* cmUnpkLsiTrcInd */


#ifdef SI_ACNT

/*
*
*       Fun:   cmPkLsiAcntInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLsiAcntInd 
(
Pst        *pst,
SiMngmt    *acnt
)
#else
PUBLIC S16 cmPkLsiAcntInd (pst, acnt)
Pst        *pst;
SiMngmt    *acnt;
#endif
{
   Buffer *mBuf;

   TRC2(cmPkLsiAcntInd)

   if (SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
      RETVALUE(RFAILED);

   CMCHKPKLOG(cmPkSiAcnt, acnt,       mBuf, ELSI049, pst);
   CMCHKPKLOG(cmPkHeader, &acnt->hdr, mBuf, ELSI050, pst);

   pst->event = (Event) EVTLSIACNTIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}/* cmPkLsiAcntInd */


/*
*
*       Fun:   cmUnpkLsiAcntInd 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLsiAcntInd 
(
LsiAcntInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkLsiAcntInd (func, pst, mBuf)
LsiAcntInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   SiMngmt acnt;

   TRC2(cmUnpkLsiAcntInd)

   CMCHKUNPKLOG(cmUnpkHeader, &acnt.hdr, mBuf, ELSI051, pst);
   CMCHKUNPKLOG(cmUnpkSiAcnt, &acnt,      mBuf, ELSI052, pst);
   (Void) SPutMsg(mBuf);

   RETVALUE( func(pst, &acnt) );
}/* cmUnpkLsiAcntInd */

#endif /* SI_ACNT */
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */
/* si007.220 - Modified: add LSIV2 and TDS_ROLL_UPGRADE_SUPPORT flags for this 
 * function.
 */
/* si006.220, MODIFIED: modified code to support rolling upgrade from LSIV1 
 * LSIV2 version
 */
#if (LSIV2 || LSIV3 || LSIV4 || defined(TDS_ROLL_UPGRADE_SUPPORT))

/*
*
*       Fun: cmPkSiSAPSta 
*
*       Desc:   
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkSiSAPSta 
(
SiSAPSta   *sta,
Buffer     *mBuf,
Pst        *pst
)
#else
PUBLIC S16 cmPkSiSAPSta (sta, mBuf, pst)
SiSAPSta   *sta;
Buffer     *mBuf;
Pst        *pst;
#endif
{
   CmIntfVer intfVer;     /* interface version */

   TRC2(cmPkSiSAPSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = LSIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   switch (intfVer)
   {
      case 0x0100:        /* interface version LSIV1 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPK(cmPkIntfVer,  sta->remIntfVer,    mBuf);
         CMCHKPK(cmPkIntfVer,  sta->selfIntfVer,   mBuf);
         CMCHKPK(cmPkBool,     sta->remIntfValid,  mBuf);
#endif
         break;

/* si025.220 - Modified: consider the  LSIV4 case */
/* si009.220 - Modified: consider the  LSIV3 case */
      case 0x0200:        /* interface version LSIV2 */
      case 0x0300:        /* interface version LSIV3 */
      case 0x0400:        /* interface version LSIV4 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPK(cmPkIntfVer,  sta->remIntfVer,    mBuf);
         CMCHKPK(cmPkIntfVer,  sta->selfIntfVer,   mBuf);
         CMCHKPK(cmPkBool,     sta->remIntfValid,  mBuf);
#endif
#if (LSIV2 || LSIV3 || LSIV4)
         CMCHKPK(SPkS16,       sta->state,         mBuf);
         CMCHKPK(cmPkSpId,     sta->spId,          mBuf);
         CMCHKPK(cmPkSuId,     sta->suId,          mBuf);
#endif /* LSIV2 || LSIV3 || LSIV4 */
         break;

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* end of switch */

   RETVALUE(ROK);
}/* cmPkSiSAPSta */


/*
*
*       Fun:   cmUnpkSiSAPSta 
*
*       Desc:  
*              
*       Ret:  ROK - ok; RFAILED - failed;  
*
*       Notes: none
*
*       File:  lsi.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkSiSAPSta 
(
SiSAPSta   *sta,
Buffer     *mBuf,
Pst        *pst
)
#else
PUBLIC S16 cmUnpkSiSAPSta (sta, mBuf, pst)
SiSAPSta   *sta;
Buffer     *mBuf;
Pst        *pst;
#endif
{
   /* si006.220, MODIFIED: modified code to support rolling upgrade from LSIV1
    * LSIV2 version
    */
   CmIntfVer intfVer;     /* interface version */

   TRC2(cmUnpkSiSAPSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = LSIIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (intfVer)
   {
      case 0x0100:
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(cmUnpkBool,     &sta->remIntfValid,  mBuf);
         CMCHKUNPK(cmUnpkIntfVer,  &sta->selfIntfVer,   mBuf);
         CMCHKUNPK(cmUnpkIntfVer,  &sta->remIntfVer,    mBuf);
#endif 
         break;
      
/* si025.220 - Modified: add LSIV4 flag */
/* si009.220 - Modified: add LSIV3 flag */
      case 0x0200:
      case 0x0300:
      case 0x0400:
#if (LSIV2 || LSIV3 || LSIV4)
         CMCHKUNPK(cmUnpkSuId,     &sta->suId,          mBuf);
         CMCHKUNPK(cmUnpkSpId,     &sta->spId,          mBuf);
         CMCHKUNPK(SUnpkS16,       &sta->state,         mBuf);
#endif /* LSIV2 || LSIV3 || LSIV4 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPK(cmUnpkBool,     &sta->remIntfValid,  mBuf);
         CMCHKUNPK(cmUnpkIntfVer,  &sta->selfIntfVer,   mBuf);
         CMCHKUNPK(cmUnpkIntfVer,  &sta->remIntfVer,    mBuf);
#endif 
         break;

       default:
          /* invaid interface version */
          RETVALUE(RINVIFVER);
   } /* end of switch */

   RETVALUE(ROK);
}/* cmUnpkSiSAPSta */
#endif /* LSIV2 || LSIV3 || LSIV4 || TDS_ROLL_UPGRADE_SUPPORT */
#endif /* LCLSI */

  
/********************************************************************30**
  
         End of file:     lsi.c@@/main/7 - Wed Mar 14 15:30:54 2001

*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
 
   
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rh   1. initial release.
1.2          ---      dvs  1. rev sync  
             ---      ym   1. cmPkSiSsta is corrected for packing the
                              transState in circuit status.
                           2. Break was missing in cmUnpkSiCntrl. 
1.2+         ---      ym   1. The order of fields in TmrCfg is corrected
                              in unpacking the structure.
                           2. Packing and unpacking functions are modified
                              for cirFlg field in siCirCfg.
                              Note that these changes are under LSI_PARAMETER.
1.3          ---      bn   1. text changes.
1.4          ---      bn   1. added pack/unpack of new circuit configuration
                              parameters.
1.4+         ---      ym   1. The packing/unpacking of diagnostics is corrected.
                           2. LSI interface packing/unpacking related to 
                              russian variant is corrected.

1.5          ---      ym   1. Added NTT variant related changes.
1.6          ---      bsp  1. Removed unpacking/packing of clli from SiGenCfg
             ---      bsp  1. Removed unpacking/packing of tmr from SiUstaDgnVal
/main/7      ---      hy   1. Removed packing/unpacking of dfltOpc from
                              SiNSAPCfg
                           2. Removed packing/unpacking of bearProf from
                              SiCirCfg1
                           3. Added packing/unpacking of availTest,trunkType and 
                              checkTable in interface configuration, Added slotId, 
                              ctrlMult in circuit configuration; Added 
                              mapFormat, mapType and mapPres in control structure; 
                              Added numCirUsed in accounting indication;
                              Added numNonCont counter in circuit 
                              statistics structure. 
                      bsp  1. Added packing/unpakcing for counters for 
                              ETSI ver 3 messages.
                      bsp  1. Added ANSI 95 flags         
                      hy   1. Added ITU97 and ETSI v3 flags.
                           2. Change flag SI_218_MSAP_COMP to SI_218_COMP
                      bsp  1. Put packing/unpacking of route related
                              structures under SI_218_COMP
                      sk   1. Putting compile option for numNonCont
                      hy   1. Change #if SI_218_COMP to #ifdef SI_218_COMP
                      bsp  1. Made functions PUBLIC as required by
                              the CTF environment.
                           2. Added SI_218_COMP in circuit configuration 
                              control block. 
                      hy   1. Corrected the warning for NT compilation.
          si001.220   hy   1. Fill the interface version of Layer Manager
                              in post structure when packing the request
                              type primitives.
                           2. Added packing/unpacking for additional fields 
                              used in the ISUP rollup.
                           3. Changes for bit vector implementation to support
                              the rolling upgrade across the same
                              specification family. It supports from:
                              ANS88 to ANS92 or vice versa
                              ANS92 to ANS95 or vice versa
                              ANS88 to ANS95 or vice versa
                              ITU to ITU97 or vice versa 
                              ETSI to ETSIV3 or vice versa
                           4. Added new function cmPkSiSAPSta and 
                              cmUnpkSiSAPSta 
          si004.220    mm  1. Corrected the variant flag for SS7_BELL in function
                              cmUnpkSiTmrCfg, cmUnpkSiPduSts for rolling upgrade 
                              feature.
          si006.220    hy  1. In function siPkSiSAPSta, cmUnpkSiSAPSta, added
                              the translation logic to support rolling
                              upgrade from LSIV1 to LSIV2 
                           2. Removed TDS_ROLL_UPGRADE_SUPPORT flag and pass
                              the pst structure when packing/unpacking 
                              SiSAPSta structure.
                           3. Added packing/unpacking for fields used in force
                              blocking request.
                           4. Corrected unpacking order in cmUnpkSiCntrl.
          si007.220    mm  1. Added code for packing/unpacking dpc of SiUstaDgnVal
                              in LSI_USTA_DGNVAL_DPC type.
                           2. Added LSIV2 and TDS_ROLL_UPGRADE_SUPPORT flag
          si008.220    mm  1. In function cmPkLsiStaReq and cmUnpkLsiStaReq, 
                              modified code so that only packing those available
                              fields to avoid segmentation fault.
                           2. In function cmUnpkSiSsta, modified code to
                              allocate memory for part number char array in case
                              of STSID.
          si009.220    mm  1. Added packing/unpacking link selector option field
                              and coresponding transaction function in function 
                              cmUnpksiGenCfg.
          si025.220    tz  1. Added packing/unpacking link selection option field
                              and link selection bits in interface packing and
                              unpacking.
                           2. Added LSIV4 flag for any LSIV3.
          si029.220    tz  1. Modified packing and unpacking of the statistics.
           si034220  rk    1. Added CHINA flag and switch where applicable.
   lsi_c_001.main_7 bn     1. corrected TDS_ROLL_UPGRADE_SUPPORT flag.

*********************************************************************91*/
