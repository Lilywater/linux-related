/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/



/********************************************************************20**
  
     Name:     Windows NT System Services
  
     Type:     C Source Code.
  
     Desc:     Management Interface
 
     File:     lns.c

     Sid:      lns.c 1.1  -  05/13/98 17:13:44
  
     Prg:      ag
  
*********************************************************************21*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */

#include "ss_err.h"        /* errors */
#include "ss_queue.h"      /* queues */
#include "ss_task.h"       /* tasking */
#include "ss_msg.h"        /* messaging */
#include "ss_mem.h"        /* memory management interface */
#include "ss_gen.h"        /* general */
#include "lns.h"           /* NTSS mgmt */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */

#include "ss_queue.x"      /* queues */
#include "ss_task.x"       /* tasking */
#include "ss_timer.x"      /* timers */
#include "ss_strm.x"       /* STREAMS */
#include "ss_msg.x"        /* messaging */
#include "ss_mem.x"        /* memory management interface */
#include "ss_drvr.x"       /* driver tasks */
#include "ss_gen.x"        /* general */
#include "lns.x"           /* NTSS management */


/* Extern variables */

/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

/* public variable declarations */


/* private variable declarations */

#ifdef NS_ENB_MGMT

#ifdef LCNSMILNS              /* loose coupled layer management */


/*
*     layer management interface packing functions
*/
/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsPkMiLnsStaCfm
(
Pst *pst,                 /* post structure */     
NsMngmt *sta              /* solicited status */
)
#else
PUBLIC S16 nsPkMiLnsStaCfm(pst, sta)
Pst *pst;                 /* post structure */     
NsMngmt *sta;             /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(nsPkMiLnsStaCfm)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   switch(sta->hdr.elmId.elmnt)
   {
      case STSID:
         CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELNS001, pst);
         break;
      case STSPOOL:
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsSPool.maxSize, mBuf, \
                                                                  ELNS002, pst);
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsSPool.crntSize, \
                                                            mBuf, ELNS003, pst);
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsSPool.minSize, mBuf,  \
                                                                  ELNS004, pst);
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsSPool.bufSize, mBuf, \
                                                                  ELNS005, pst);
         break;
      case STDPOOL:
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsDPool.maxSize, mBuf,  \
                                                          ELNS006, pst);
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsDPool.minSize, mBuf, \
                                                           ELNS007, pst);
         CMCHKPKLOG(cmPkSize, sta->t.ssta.s.nsDPool.crntSize, \
                                                            mBuf, ELNS008, pst);
         break;
      case STDQ: CMCHKPKLOG(SPkU32, sta->t.ssta.s.nsDq.size, mBuf, \
                                                           ELNS009, pst);
         break;
      case STENT:
         CMCHKPKLOG(SPkS16, sta->t.ssta.s.nsEnt.maxInst, mBuf, ELNS010, pst);
         CMCHKPKLOG(SPkS16, sta->t.ssta.s.nsEnt.nmbInst, mBuf, ELNS011, pst);
         break;
      default:
         SPutMsg(mBuf);

#if (ERRCLASS & ERRCLS_DEBUG)         
         LNSLOGERROR(pst->srcEnt, pst->srcInst, pst->srcProcId, 
                     ERRCLS_DEBUG, ELNS012, (ErrVal)sta->hdr.elmId.elmnt, 
                     "[NTSS]nsPkMiLnsStaCfm: Invalid header elmnt");
#endif
         RETVALUE(RFAILED);
   }
   
   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELNS013, pst);
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELNS014, pst);

   pst->event = EVTLNSSTACFM;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of nsPkMiLnsStaCfm */

 
/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsPkMiLnsStsCfm
(
Pst *pst,                 /* post structure */    
Action action,            /* action */
NsMngmt *sts              /* statistics */
)
#else
PUBLIC S16 nsPkMiLnsStsCfm(pst, action, sts)
Pst *pst;                 /* post structure */    
Action action;            /* action */
NsMngmt *sts;             /* statistics */
#endif
{
   Buffer *mBuf;          /* message buffer */
 
   TRC3(nsPkMiLnsStsCfm)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   switch(sts->hdr.elmId.elmnt)
   {
      case STLOOP:   
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsLoop.loopTmrCnt,  \
                                                      mBuf, ELNS015, pst);
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsLoop.loopNormCnt,  \
                                                      mBuf, ELNS016, pst);
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsLoop.loopPermCnt,  \
                                                      mBuf, ELNS017, pst);
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsLoop.loopIdleCnt, \
                                                      mBuf, ELNS018, pst);
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsLoop.loopActvCnt,  \
                                                      mBuf, ELNS019, pst);
         break;

      case STDQ:
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsDq.emptyCnt, mBuf, ELNS020, pst);
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsDq.notEmptyCnt, mBuf,  \
                                                               ELNS021, pst);
         break;

      case STENT:
         CMCHKPKLOG(cmPkCntr, sts->t.sts.s.nsEnt.actvCnt, mBuf, ELNS022, pst);
         break;

      default:
         SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         LNSLOGERROR(pst->srcEnt, pst->srcInst, pst->srcProcId, 
                     ERRCLS_DEBUG, ELNS023, (ErrVal)sts->hdr.elmId.elmnt, 
                     "[NTSS]nsPkMiLnsStsCfm: Invalid header elmnt");
#endif
         RETVALUE(RFAILED);
   }
   
   CMCHKPKLOG(cmPkAction, action, mBuf, ELNS024, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELNS025, pst);
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELNS026, pst);

   pst->event = EVTLNSSTSCFM;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of nsPkMiLnsStsCfm */




/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsPkMiLnsStaInd
(
Pst *pst,                 /* post structure */     
NsMngmt *sta              /* unsolicited status */
)
#else
PUBLIC S16 nsPkMiLnsStaInd(pst, sta)
Pst *pst;                 /* post structure */     
NsMngmt *sta;             /* unsolicited status */
#endif
{
   S16 i;                 /* counter */
   Buffer *mBuf;          /* message buffer */
 
   TRC3(nsPkMiLnsStaInd)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(SPkU16, sta->t.usta.evnt, mBuf, ELNS027, pst);
   for (i = 0; i < 8; i++)  
   {
      CMCHKPKLOG(SPkU8, sta->t.usta.evntParm[i], mBuf, ELNS028, pst);
   }

   CMCHKPKLOG(cmPkDateTime, &sta->t.usta.dt, mBuf, ELNS029, pst);
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELNS030, pst);

   pst->event = EVTLNSSTAIND;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of nsPkMiLnsStaInd */

  
/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function unpacks the status request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsUnpkMiLnsStaReq
(
Pst *pst,                       /* post */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 nsUnpkMiLnsStaReq(pst, mBuf)
Pst *pst;                       /* post */
Buffer *mBuf;                   /* message buffer */
#endif
{
   NsMngmt sta;               /* status */

   TRC3(nsUnpkMiLnsStaReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELNS031, pst);
   SPutMsg(mBuf);
   RETVALUE(NsMiLnsStaReq(pst, &sta));

} /* end of nsUnpkMiLnsStaReq */



  
/*
*
*       Fun:   Unpack Control Request
*
*       Desc:  This function unpacks the control request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsUnpkMiLnsCntrlReq
(
Pst *pst,                       /* post */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 nsUnpkMiLnsCntrlReq(pst, mBuf)
Pst *pst;                       /* post */
Buffer *mBuf;                   /* message buffer */
#endif
{
   NsMngmt cntrl;               /* control */

   TRC3(nsUnpkMiLnsCntrlReq)

   CMCHKUNPKLOG(cmUnpkHeader, &cntrl.hdr, mBuf, ELNS032, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ELNS033, pst);
   CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.action, mBuf, ELNS034, pst);
   CMCHKUNPKLOG(SUnpkS32, &cntrl.t.cntrl.subAction, mBuf, ELNS035, pst);
   CMCHKUNPKLOG(cmUnpkPst, &cntrl.t.cntrl.smPst, mBuf, ELNS036, pst);
   SPutMsg(mBuf);
   RETVALUE(NsMiLnsCntrlReq(pst, &cntrl));

} /* end of nsUnpkMiLnsCntrlReq */
  
  
/*
*
*       Fun:   Unpack Statistics Request
*
*       Desc:  This function unpacks the statistics request.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 nsUnpkMiLnsStsReq
(
Pst *pst,                       /* post */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 nsUnpkMiLnsStsReq(pst, mBuf)
Pst *pst;                       /* post */
Buffer *mBuf;                   /* message buffer */
#endif
{
   Action action;           /* action */
   NsMngmt sts;               /* statistics */

   TRC3(nsUnpkMiLnsStsReq)

   CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ELNS037, pst);
   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELNS038, pst);   

   SPutMsg(mBuf);
   RETVALUE(NsMiLnsStsReq(pst, action, &sts));

} /* end of nsUnpkMiLnsStsReq */
#endif /* LCNSMILNS */


#ifdef LCSMNSMILNS

/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to NTSS.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smPkMiLnsStaReq
(
Pst *pst,                   /* post structure */    
NsMngmt *sta                /* solicited status */
)
#else
PUBLIC S16 smPkMiLnsStaReq(pst, sta)
Pst *pst;                   /* post structure */    
NsMngmt *sta;               /* solicited status */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(smPkMiLnsStaReq)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELNS039, pst);
   pst->event = (Event)EVTLNSSTAREQ;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of smPkMiLnsStaReq(sta) */



/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request
*              primitive to NTSS.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smPkMiLnsCntrlReq
(
Pst *pst,                   /* post structure */    
NsMngmt *cntrl              /* control */
)
#else
PUBLIC S16 smPkMiLnsCntrlReq(pst, cntrl)
Pst *pst;                   /* post structure */    
NsMngmt *cntrl;             /* control */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(smPkMiLnsCntrlReq)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(cmPkPst, &cntrl->t.cntrl.smPst, mBuf, ELNS040, pst);
   CMCHKPKLOG(SPkS32, cntrl->t.cntrl.subAction, mBuf, ELNS041, pst);
   CMCHKPKLOG(SPkU8, cntrl->t.cntrl.action, mBuf, ELNS042, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt, mBuf, ELNS043, pst);
   CMCHKPKLOG(cmPkHeader, &cntrl->hdr, mBuf, ELNS044, pst);
   pst->event = (Event)EVTLNSCNTRLREQ;

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of smPkMiLnsCntrlReq */
 

/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to NTSS.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smPkMiLnsStsReq
(
Pst *pst,                   /* post structure */    
Action action,              /* action */
NsMngmt *sts                /* statistics */
)
#else
PUBLIC S16 smPkMiLnsStsReq(pst, action, sts)
Pst *pst;                   /* post structure */    
Action action;              /* action */
NsMngmt *sts;               /* statistics */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC3(smPkMiLnsStsReq)

   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELNS045, pst);
   CMCHKPKLOG(cmPkAction, action, mBuf, ELNS046, pst);
   pst->event = (Event)EVTLNSSTSREQ;

   RETVALUE(SPstTsk(pst, mBuf));

} /* end of smPkMiLnsStsReq(sts) */


/* Stack Manager unpacking functions */
  
/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function is used to unpack the status request
*              primitive to NTSS
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smUnpkMiLnsStaCfm
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smUnpkMiLnsStaCfm(pst, mBuf)
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   NsMngmt sta;             /* stauts confirm */
   Txt ptNmb[40];           /* part number */
   
   TRC3(smUnpkMiLnsStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELNS047, pst); 
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELNS048, pst);
   switch(sta.hdr.elmId.elmnt)
   {
      case STSID:
         /*
          * the following is due to the fact that the SystemId
          * structure has ptNmb defined as a pointer.
          * Therefore we need some space to unpack into...
          */
         sta.t.ssta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId, mBuf, ELNS049, pst);
         break;

      case STSPOOL:
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsSPool.bufSize, \
                                                          mBuf, ELNS050, pst);
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsSPool.minSize,\
                                                          mBuf, ELNS051, pst);
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsSPool.crntSize,\
                                                          mBuf, ELNS052, pst);
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsSPool.maxSize,\
                                                          mBuf, ELNS053, pst);
         break;

      case STDPOOL:
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsDPool.crntSize,\
                                                          mBuf, ELNS054, pst);
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsDPool.minSize,\
                                                          mBuf, ELNS055, pst);
         CMCHKUNPKLOG(cmUnpkSize, &sta.t.ssta.s.nsDPool.maxSize,\
                                                          mBuf, ELNS056, pst);
         break;

      case STDQ:
         CMCHKUNPKLOG(SUnpkU32, &sta.t.ssta.s.nsDq.size, mBuf, ELNS057, pst);
         break;

      case STENT:
         CMCHKUNPKLOG(SUnpkS16, &sta.t.ssta.s.nsEnt.nmbInst,\
                                                        mBuf, ELNS058, pst);
         CMCHKUNPKLOG(SUnpkS16, &sta.t.ssta.s.nsEnt.maxInst,\
                                                        mBuf, ELNS059, pst);
         break;

      default:
         SPutMsg(mBuf);
#if (ERRCLASS & ERRCLS_DEBUG)
         LNSLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                     ERRCLS_DEBUG, ELNS060, (ErrVal)sta.hdr.elmId.elmnt, 
                     "[NTSS] [SM] smUnpkMiLnsStaCfm: Invalid header elmnt");
#endif /* ERRCLASS & ERRCLS_DEBUG */

         RETVALUE(RFAILED);
   }
   
   SPutMsg(mBuf);
   RETVALUE(SmMiLnsStaCfm(pst, &sta));

} /* end of smUnpkMiLnsStaCfm */

  
/*
*
*       Fun:   Unpack Statistics Confirm
*
*       Desc:  This function is used to unpack the statistics confirm
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smUnpkMiLnsStsCfm
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smUnpkMiLnsStsCfm(pst, mBuf)
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   Action action;
   NsMngmt sts;

   TRC3(smUnpkMiLnsStsCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELNS061, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELNS062, pst);
   CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ELNS063, pst);
   switch(sts.hdr.elmId.elmnt)
   {
      case STLOOP:
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsLoop.loopTmrCnt, mBuf, \
                                                             ELNS064, pst);
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsLoop.loopNormCnt, mBuf, \
                                                             ELNS065, pst);
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsLoop.loopPermCnt, mBuf, \
                                                             ELNS066, pst);
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsLoop.loopIdleCnt, \
                                                          mBuf, ELNS067, pst);
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsLoop.loopActvCnt, \
                                                          mBuf, ELNS068, pst);
         break;

      case STDQ:
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsDq.notEmptyCnt, \
                                                      mBuf, ELNS069, pst);
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsDq.emptyCnt, \
                                                      mBuf, ELNS070, pst);
         break;

      case STENT:
         CMCHKUNPKLOG(cmUnpkCntr, &sts.t.sts.s.nsEnt.actvCnt, \
                                                      mBuf, ELNS071, pst);
         break;

      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         LNSLOGERROR(pst->dstEnt, pst->dstInst, pst->dstProcId, 
                     ERRCLS_DEBUG, ELNS072, (ErrVal)sts.hdr.elmId.elmnt, 
                     "[NTSS] [SM] smUnplMiLnsStsCfm: Invalid header elmnt");
#endif /* ERRCLASS & ERRCLS_DEBUG */
         SPutMsg(mBuf);
         RETVALUE(RFAILED);
         break;
   }

   SPutMsg(mBuf);
   RETVALUE(SmMiLnsStsCfm(pst, action, &sts)); 

} /* end of smUnpkMiLnsStsCfm */

  
/*
*
*       Fun:   Unpack Status Indication
*
*       Desc:  This function is used to unpack the status indication
*              primitive from NTSS.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lns.c
*
*/
  
#ifdef ANSI
PUBLIC S16 smUnpkMiLnsStaInd
(
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 smUnpkMiLnsStaInd(pst, mBuf)
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   NsMngmt sta;
   S16 i;
 
   TRC3(smUnpkMiLsdStaInd)
   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELNS073, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.usta.dt, mBuf, ELNS074, pst);
   for (i = 7; i >= 0; i--)  
   {
      CMCHKUNPKLOG(SUnpkU8, &sta.t.usta.evntParm[i], mBuf, ELNS075, pst);
   }
   CMCHKUNPKLOG(SUnpkU16, &sta.t.usta.evnt, mBuf, ELNS076, pst);
   SPutMsg(mBuf);
   RETVALUE(SmMiLnsStaInd(pst, &sta)); 

} /* end of smUnpkMiLnsStaInd */

#endif /* LCSMNSMILNS */
#endif /* NS_ENB_MGMT */


/********************************************************************30**
  
         End of file: lns.c 1.1  -  05/13/98 17:13:44
  
*********************************************************************31*/
  
  
/********************************************************************40**
  
        Notes: 
  
*********************************************************************41*/
  
/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      ag   1. initial release
  
*********************************************************************91*/
