/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     Message Router - external interface - mos
  
     Type:     C source file
  
     Desc:     Functions for MRS interface 
  
     File:     mrs.c
 
     Sid:      mrs.c@@/main/2 - Fri Feb  9 14:34:57 2001
  
     Prg:      rsk
  
*********************************************************************21*/
 

/* Header include files */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
 
#include "gen.h"           /* general */
#include "cm5.h"           /* common */
#include "ssi.h"           /* system services */
#include "cm_ftha.h"       /* common FTHA definitions */
#include "mrs.h"           /* mrs interface definitions */

#include "gen.x"           /* general */
#include "cm5.x"           /* common */
#include "ssi.x"           /* system services */
#include "cm_ftha.x"       /* common FTHA */
#include "mrs.x"           /* mrs interface definitions */

  
/* local defines */
 
/* local typedefs */
 
/* local externs */
 
/* forward references */
 
/* private variable declarations */
 
/* public variable declarations */


/*
 *     Mrs Interface - packing functions
 */


/*
 *
 *       Fun  : Pack Outbound Release Queue Inication
 *
 *       Desc : This function is used to pack a release queue
 *              indication
 *
 *       Ret  : ROK      - ok
 *
 *       Notes: None
 *
 *       File : mr_ptmrs.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkMrsLcRlsQInd 
(
Pst        *pst,
CmFthaRset *rset
)
#else
PUBLIC S16 cmPkMrsLcRlsQInd (pst, rset)
Pst        *pst;
CmFthaRset *rset;
#endif
{
   Buffer  *mBuf;
   S16     retVal;
   TRC3(cmPkMrsLcRlsQInd)

   retVal = SGetMsg(pst->region, pst->pool, &mBuf);
   if (retVal != ROK)
   {
      MRSLOGERROR(ERRCLS_ADD_RES, ERRMRSXXX, (ErrVal) retVal, "SGetMsg failed");
      RETVALUE(retVal);
   }

   CMCHKPKLOG(cmPkFthaRset,rset,mBuf,ERRMRSXXX,pst);
   pst->event = EVTMRSRLSQIND;
   SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkMrsLcRlsQInd */

   

/*
 *     Mrs Interface - unpacking functions
 */


/*
 *
 *       Fun  : Unpack Outbound Release Queue Inication
 *
 *       Desc : This function is used to unpack a release queue
 *              indication
 *
 *       Ret  : ROK      - ok
 *
 *       Notes: None
 *
 *       File : mr_ptmrs.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkMrsLcRlsQInd 
(
MrsLcRlsQInd func,
Pst        *pst,
Buffer     *mBuf
)
#else
PUBLIC S16 cmUnpkMrsLcRlsQInd (func, pst, mBuf)
MrsLcRlsQInd func;
Pst        *pst;
Buffer     *mBuf;
#endif
{
   CmFthaRset rset;

   TRC3(cmUnpkMrsLcRlsQInd)

   CMCHKUNPKLOG(cmUnpkFthaRset,&rset, mBuf, ERRMRSXXX,pst);

   /* call appropriate function */
   (*func)(pst, &rset);

   /* release the message buffer */
   SPutMsg(mBuf);

   RETVALUE(ROK);
} /* end of cmUnpkMrsLcRlsQInd */

  
/********************************************************************30**
  
         End of file:     mrs.c@@/main/2 - Fri Feb  9 14:34:57 2001
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------

*********************************************************************81*/
/*********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
 
/main/1        ---     ssk  1. Initial Release 
*********************************************************************91*/
