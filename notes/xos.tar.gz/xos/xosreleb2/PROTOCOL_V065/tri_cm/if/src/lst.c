/********************************************************************16**

        (c) COPYRIGHT 1989-2000 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:     Common LST Interface packing/unpacking functions
  
     Type:     Common Source File
  
     Desc:     Routines shared across the LST interface
 
     File:     lst.c

     Sid:      lst.c@@/main/2 - Fri Nov 17 10:33:51 2000
  
     Prg:      nj
  
*********************************************************************21*/
 


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system service interface */
#include "lst.h"           /* common lst */
#include "cm_ss7.h"        /* common ss7 */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system service interface */
#include "cm_ss7.x"        /* common ss7 */
#include "lst.x"           /* common lst */


/* local defines */

/* local typedefs */

/* local externs */
  
/* forward references */

/* local function definition */
#ifdef LCLST
PRIVATE S16  cmPkStEvCnt    ARGS((StEvCnt   *e,   Buffer *mBuf));
PRIVATE S16  cmUnpkStEvCnt  ARGS((StEvCnt   *e,   Buffer *mBuf));
#endif /* LCLST */

/* functions in other modules */

/* public variable declarations */

/* control variables for testing */

/* private variable declarations */

/*
 * support functions
 */

#ifdef LCLST

/*
*
*       Fun:    cmPkStEvCnt
*
*       Desc:   pack a TCAP counter/occurrence structure
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   lst.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkStEvCnt
(
StEvCnt   *e,
Buffer    *mBuf
)
#else
PRIVATE S16 cmPkStEvCnt(e, mBuf)
StEvCnt   *e;
Buffer    *mBuf;
#endif
{
   
   TRC2(cmPkStEvCnt)
      
   CMCHKPK(cmPkCntr,  e->cnt, mBuf);
   CMCHKPK(cmPkTicks, e->first, mBuf);

   RETVALUE(ROK);
} /* cmPkStEvCnt */


/*
*
*       Fun:    cmUnpkStEvCnt
*
*       Desc:   unpack a TCAP counter/occurrence structure
*
*       Ret:    ROK     - ok
*
*       Notes:  None
*
*       File:   lst.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkStEvCnt
(
StEvCnt  *e,
Buffer   *mBuf
)
#else
PRIVATE S16 cmUnpkStEvCnt(e, mBuf)
StEvCnt  *e;
Buffer   *mBuf;
#endif
{
   TRC2(cmUnpkStEvCnt)

   CMCHKUNPK(cmUnpkTicks, &e->first, mBuf);
   CMCHKUNPK(cmUnpkCntr,  &e->cnt,   mBuf);

   RETVALUE(ROK);
} /* cmUnpkStEvCnt */

/*
*
*       Fun:   Pack Configuration Request
*
*       Desc:  This function is used to pack the configuration request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstCfgReq
(
Pst       *pst,               /* post structure */
StMngmt   *cfg                /* configuration */
)
#else
PUBLIC S16 cmPkLstCfgReq(pst, cfg)
Pst       *pst;               /* post structure */
StMngmt   *cfg;               /* configuration */
#endif
{
   StGenCfg    *genCfg;
   StTUSapCfg  *tuCfg;
   StSPSapCfg  *spCfg;
   Buffer      *mBuf;

   TRC2(cmPkLstCfgReq)

   LST_GETMSG(pst, mBuf, ELST001);

   /* lst_c_001.main_2-Added- Interface Version */
   pst->intfVer = LSTIFVER;

   switch (cfg->hdr.elmId.elmnt)
   {
      case STGEN:

         genCfg = &cfg->t.cfg.s.genCfg;

         CMCHKPKLOG(cmPkPst, &genCfg->smPst,       mBuf, ELST002, pst);
         CMCHKPKLOG(SPkU8,    genCfg->errCntrlFlg, mBuf, ELST003, pst);
         CMCHKPKLOG(SPkU8,    genCfg->bitMapFlg,   mBuf, ELST004, pst);
         CMCHKPKLOG(SPkU32,   genCfg->hiDlgId,     mBuf, ELST005, pst);
         CMCHKPKLOG(SPkU32,   genCfg->loDlgId,     mBuf, ELST006, pst);
         CMCHKPKLOG(SPkU16,   genCfg->sapTimeRes,  mBuf, ELST007, pst);
         CMCHKPKLOG(SPkU16,   genCfg->timeRes,     mBuf, ELST008, pst);
         /*lst_c_001.main_2-Modified-supported increase in storage */ 
         switch(pst->intfVer)
         {
            case 0x0100:
               CMCHKPKLOG(SPkU16,(U16)genCfg->nmbBins, mBuf, ELST009, pst);
               CMCHKPKLOG(SPkU16,(U16)genCfg->nmbInvs, mBuf, ELST010, pst);
               CMCHKPKLOG(SPkU16,(U16)genCfg->nmbDlgs, mBuf, ELST011, pst);
               break;
          
            case 0x0200: 
               CMCHKPKLOG(SPkU32, genCfg->nmbBins, mBuf, ELST009, pst);
               CMCHKPKLOG(SPkU32, genCfg->nmbInvs, mBuf, ELST010, pst);
               CMCHKPKLOG(SPkU32, genCfg->nmbDlgs, mBuf, ELST011, pst);
               break;
            
            default:   
               RETVALUE(RFAILED); 
               break; 
          }    
         /* End of lst_c_001.main_2 */ 
    
         CMCHKPKLOG(SPkU16,   genCfg->nmbSaps,     mBuf, ELST012, pst);
         break;

      case STTCUSAP:

         tuCfg = &cfg->t.cfg.s.tuSapCfg;
         /* two new fields added in upper SAP configuration structure */
 /* st005.301 -Added -  Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer,   tuCfg->intfVer, mBuf, ELST013, pst);
         CMCHKPKLOG(SPkU8,         tuCfg->remIntfValid, mBuf, ELST014, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
       /* lst_c_001.main_2-Modified- supported increase in storage of nmbBins,
        * nmbDlgs, nmbInvs */ 
         switch(pst->intfVer)
         {
            case 0x0100: 
               CMCHKPKLOG(SPkU16, (U16)tuCfg->nmbBins, mBuf, ELST013, pst);
               CMCHKPKLOG(SPkU16, (U16)tuCfg->nmbInvs, mBuf, ELST014, pst);
               CMCHKPKLOG(SPkU16, (U16)tuCfg->nmbDlgs, mBuf, ELST015, pst);
               break;
            
            case 0x0200:  
               CMCHKPKLOG(SPkU32, tuCfg->nmbBins, mBuf, ELST013, pst);
               CMCHKPKLOG(SPkU32, tuCfg->nmbInvs, mBuf, ELST014, pst);
               CMCHKPKLOG(SPkU32, tuCfg->nmbDlgs, mBuf, ELST015, pst);
               break;
            default:
               RETVALUE(RFAILED); 
               break; 
          }    
   /* End of lst_c_001.main_2 */ 
         CMCHKPKLOG(SPkU32,        tuCfg->hiDlgId, mBuf, ELST016, pst);
         CMCHKPKLOG(SPkU32,        tuCfg->loDlgId, mBuf, ELST017, pst);

/* lst_c_003.main_2 - Addition - Added packing for Dialogue Hash bin Size */
#ifdef LSTV3          
         CMCHKPKLOG(SPkU32,        tuCfg->dlgHshSize, mBuf, ELSTXXX, pst);
#endif /* LSTV3 */

         CMCHKPKLOG(cmPkTmrCfg,   &tuCfg->t2,      mBuf, ELST018, pst);
         CMCHKPKLOG(cmPkTmrCfg,   &tuCfg->t1,      mBuf, ELST019, pst);
         CMCHKPKLOG(cmPkRoute,     tuCfg->tuRoute, mBuf, ELST020, pst);
         CMCHKPKLOG(cmPkPrior,     tuCfg->tuPrior, mBuf, ELST021, pst);
         CMCHKPKLOG(cmPkMemoryId, &tuCfg->tuMemId, mBuf, ELST022, pst);
         CMCHKPKLOG(cmPkSelector,  tuCfg->tuSel,   mBuf, ELST023, pst);
         CMCHKPKLOG(cmPkSwtch,     tuCfg->swtch,   mBuf, ELST024, pst);
         break;

      case STSPSAP:

         spCfg = &cfg->t.cfg.s.spSapCfg;
 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(cmPkIntfVer,  spCfg->intfVer, mBuf, ELST025, pst);
         CMCHKPKLOG(SPkU8,        spCfg->remIntfValid, mBuf, ELST026, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef SPT2
         CMCHKPKLOG(cmPkTmrCfg,   &spCfg->tIntTmr,  mBuf, ELST025, pst);
#endif /* SPT2 */
         CMCHKPKLOG(cmPkSsn,       spCfg->ssn,      mBuf, ELST026, pst);
         CMCHKPKLOG(cmPkTimer,     spCfg->spTmr,    mBuf, ELST027, pst);
         CMCHKPKLOG(cmPkSpId,      spCfg->spId,     mBuf, ELST028, pst);
         CMCHKPKLOG(cmPkRoute,     spCfg->spRoute,  mBuf, ELST029, pst);
         CMCHKPKLOG(cmPkPrior,     spCfg->spPrior,  mBuf, ELST030, pst);
         CMCHKPKLOG(cmPkInst,      spCfg->spInst,   mBuf, ELST031, pst);
         CMCHKPKLOG(cmPkEnt,       spCfg->spEnt,    mBuf, ELST032, pst);
         CMCHKPKLOG(cmPkProcId,    spCfg->spProcId, mBuf, ELST033, pst);
         CMCHKPKLOG(cmPkMemoryId, &spCfg->spMemId,  mBuf, ELST034, pst);
         CMCHKPKLOG(cmPkSelector,  spCfg->spSel,    mBuf, ELST035, pst);
         CMCHKPKLOG(cmPkSwtch,     spCfg->swtch,    mBuf, ELST036, pst);
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LSTLOGERROR(ERRCLS_DEBUG, ELST037, 0, "cmPkLstCfgReq: Failed"); 
#endif
         RETVALUE(RFAILED);
   }
   CMCHKPKLOG(cmPkHeader, &cfg->hdr, mBuf, ELST038, pst);

   pst->event = (Event)EVTLSTCFGREQ; /* event */

  /* lst_c_001.main_2-deleted- Following statements are removed as it
   * is maintained unconditionally */
 
  (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstCfgReq */


/*
*
*       Fun:   Unpack Configuration Request
*
*       Desc:  This function is used to Unpack Configuration Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstCfgReq
(
LstCfgReq  func,            /* Layer function to be called back */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstCfgReq(func, pst, mBuf)
LstCfgReq  func;            /* Layer function to be called back */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   StMngmt       cfg;       /* TCAP Configuration structure */
   StGenCfg     *genCfg;    /* Pointer to General configuration structure */
   StTUSapCfg   *tuCfg;     /* Pointer to TCAP Upper Sap Configuration */
   StSPSapCfg   *spCfg;     /* Pointer to TCAP Lower Sap Configuration */
   /* lst_c_001.main_2-Added- new variables nBins, nDlgs, nInvs */
   U16 nBins;               /* used to unpack bins */ 
   U16 nDlgs;               /* used to unpack Dialogues */ 
   U16 nInvs;               /* used to unpack Invokes */ 
   /* lst_c_002.main_2 - Addition */
   CmIntfVer intfVer;       /* interface version number */

   /* End of lst_c_001.main_2 */ 
   TRC3(cmUnpkLstCfgReq)

   genCfg = &cfg.t.cfg.s.genCfg;
   tuCfg  = &cfg.t.cfg.s.tuSapCfg;
   spCfg  = &cfg.t.cfg.s.spSapCfg;

   /* lst_c_002.main_2 - Modification */
   /* if rolling upgrade support is enabled, use interface version
    * as in pst-intfVer, else use self LST interface version number
    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LSTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG( cmUnpkHeader, &cfg.hdr, mBuf, ELST039, pst);

   switch (cfg.hdr.elmId.elmnt)
   {
      case STGEN:

         CMCHKUNPKLOG( SUnpkU16,  &genCfg->nmbSaps,     mBuf, ELST040, pst);
       /* lst_c_001.main_2-Modified- supported increase in storages */ 
         /* lst_c_002.main_2 - Modification */
         switch(intfVer)
         {
            case 0x0100:
               CMCHKUNPKLOG( SUnpkU16, &nDlgs, mBuf, ELST041, pst); 
               CMCHKUNPKLOG( SUnpkU16, &nInvs, mBuf, ELST042, pst); 
               CMCHKUNPKLOG( SUnpkU16, &nBins, mBuf, ELST043, pst); 
               genCfg->nmbDlgs = (U32) nDlgs;
               genCfg->nmbInvs = (U32) nInvs;   
               genCfg->nmbBins = (U32) nBins;
               break;
            
            case 0x200:  
               CMCHKUNPKLOG( SUnpkU32, &genCfg->nmbDlgs, mBuf, ELST041, pst); 
               CMCHKUNPKLOG( SUnpkU32, &genCfg->nmbInvs, mBuf, ELST042, pst); 
               CMCHKUNPKLOG( SUnpkU32, &genCfg->nmbBins, mBuf, ELST043, pst); 
               break;
       
            default:
               RETVALUE(RFAILED); 
               break; 
         }    
         CMCHKUNPKLOG( SUnpkU16,  &genCfg->timeRes,     mBuf, ELST044, pst); 
         CMCHKUNPKLOG( SUnpkU16,  &genCfg->sapTimeRes,  mBuf, ELST045, pst); 
         CMCHKUNPKLOG( SUnpkU32,  &genCfg->loDlgId,     mBuf, ELST046, pst); 
         CMCHKUNPKLOG( SUnpkU32,  &genCfg->hiDlgId,     mBuf, ELST047, pst); 
         CMCHKUNPKLOG( SUnpkU8,   &genCfg->bitMapFlg,   mBuf, ELST048, pst); 
         CMCHKUNPKLOG( SUnpkU8,   &genCfg->errCntrlFlg, mBuf, ELST049, pst); 
         CMCHKUNPKLOG( cmUnpkPst, &genCfg->smPst,       mBuf, ELST050, pst); 
         break;

      case STTCUSAP:

         CMCHKUNPKLOG( cmUnpkSwtch,    &tuCfg->swtch,   mBuf, ELST051, pst);
         CMCHKUNPKLOG( cmUnpkSelector, &tuCfg->tuSel,   mBuf, ELST052, pst); 
         CMCHKUNPKLOG( cmUnpkMemoryId, &tuCfg->tuMemId, mBuf, ELST053, pst); 
         CMCHKUNPKLOG( cmUnpkPrior,    &tuCfg->tuPrior, mBuf, ELST054, pst); 
         CMCHKUNPKLOG( cmUnpkRoute,    &tuCfg->tuRoute, mBuf, ELST055, pst); 
         CMCHKUNPKLOG( cmUnpkTmrCfg,   &tuCfg->t1,      mBuf, ELST056, pst); 
         CMCHKUNPKLOG( cmUnpkTmrCfg,   &tuCfg->t2,      mBuf, ELST057, pst); 

/* lst_c_003.main_2 - Addition - Added unpacking for Dialogue Hash bin Size */
#ifdef LSTV3          
         CMCHKUNPKLOG( SUnpkU32,       &tuCfg->dlgHshSize, mBuf, ELSTXXX, pst); 
#endif /* LSTV3 */
         
         CMCHKUNPKLOG( SUnpkU32,       &tuCfg->loDlgId, mBuf, ELST058, pst); 
         CMCHKUNPKLOG( SUnpkU32,       &tuCfg->hiDlgId, mBuf, ELST059, pst); 
         /*lst_c_001.main_2-Modified- supported increase in storage  */ 
         /*lst_c_002.main_2 - Modification */
         switch(intfVer)
         {
            case 0x0100:
               CMCHKUNPKLOG( SUnpkU16, &nDlgs, mBuf, ELST060, pst); 
               CMCHKUNPKLOG( SUnpkU16, &nInvs, mBuf, ELST061, pst); 
               CMCHKUNPKLOG( SUnpkU16, &nBins, mBuf, ELST062, pst); 
               tuCfg->nmbDlgs = (U32)nDlgs;
               tuCfg->nmbInvs = (U32)nInvs; 
               tuCfg->nmbBins = (U32)nBins;
               break;

            case 0x200:  
               CMCHKUNPKLOG( SUnpkU32, &tuCfg->nmbDlgs, mBuf, ELST060, pst); 
               CMCHKUNPKLOG( SUnpkU32, &tuCfg->nmbInvs, mBuf, ELST061, pst); 
               CMCHKUNPKLOG( SUnpkU32, &tuCfg->nmbBins, mBuf, ELST062, pst);
               break;
            
            default:
               RETVALUE(RFAILED); 
               break; 
         }    
         /* End of lst_c_001.main_2 */ 

/* st005.301 -Added- Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG(SUnpkU8,         &tuCfg->remIntfValid,
                                         mBuf, ELST061, pst);
         CMCHKUNPKLOG(SUnpkU16,        &tuCfg->intfVer, 
                                         mBuf, ELST062, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */ 
         break;

      case STSPSAP:
         CMCHKUNPKLOG( cmUnpkSwtch,    &spCfg->swtch,    mBuf, ELST063, pst);
         CMCHKUNPKLOG( cmUnpkSelector, &spCfg->spSel,    mBuf, ELST064, pst); 
         CMCHKUNPKLOG( cmUnpkMemoryId, &spCfg->spMemId,  mBuf, ELST065, pst); 
         CMCHKUNPKLOG( cmUnpkProcId,   &spCfg->spProcId, mBuf, ELST066, pst);
         CMCHKUNPKLOG( cmUnpkEnt,      &spCfg->spEnt,    mBuf, ELST067, pst); 
         CMCHKUNPKLOG( cmUnpkInst,     &spCfg->spInst,   mBuf, ELST068, pst); 
         CMCHKUNPKLOG( cmUnpkPrior,    &spCfg->spPrior,  mBuf, ELST069, pst); 
         CMCHKUNPKLOG( cmUnpkRoute,    &spCfg->spRoute,  mBuf, ELST070, pst); 
         CMCHKUNPKLOG( cmUnpkSpId,     &spCfg->spId,     mBuf, ELST071, pst); 
         CMCHKUNPKLOG( cmUnpkTimer,    &spCfg->spTmr,    mBuf, ELST072, pst); 
         CMCHKUNPKLOG( cmUnpkSsn,      &spCfg->ssn,      mBuf, ELST073, pst); 
#ifdef SPT2
         CMCHKUNPKLOG( cmUnpkTmrCfg,   &spCfg->tIntTmr,  mBuf, ELST074, pst); 
#endif /* SPT2 */

/* st005.301 -Added- Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKUNPKLOG( SUnpkU8,    &spCfg->remIntfValid, mBuf, ELST061, pst);
         CMCHKUNPKLOG( SUnpkU16,   &spCfg->intfVer,      mBuf, ELST062, pst);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT */ 
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LSTLOGERROR(ERRCLS_DEBUG, ELST075, 0, "cmUnpkLstCfgReq:Bad Elmnt Value");
#endif
        RETVALUE(RFAILED);
   }
   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cfg));
} /* end of cmUnpkLstCfgReq */


/*
*
*       Fun:   Pack UnConfiguration Request
*
*       Desc:  This function is used to pack the Unconfiguration request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstUcfgReq
(
Pst       *pst,               /* post structure */
StMngmt   *uCfg               /* unconfiguration */
)
#else
PUBLIC S16 cmPkLstUcfgReq(pst, uCfg)
Pst       *pst;               /* post structure */
StMngmt   *uCfg;              /* unconfiguration */
#endif
{
   Buffer      *mBuf;

   TRC2(cmPkLstUcfgReq)

   LST_GETMSG(pst, mBuf, ELST076);

   CMCHKPKLOG(cmPkHeader, &uCfg->hdr, mBuf, ELST077, pst);

   pst->event = (Event)EVTLSTUCFGREQ; /* event */

   /* st005.301 -Added- Rolling Upgrade feature */
   /* Put version information in Pst structure for rolling upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LSTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstUcfgReq */


/*
*
*       Fun:   Unpack UnConfiguration Request
*
*       Desc:  This function is used to Unpack UnConfiguration Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstUcfgReq
(
LstUcfgReq func,            /* Layer function to be called back */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstUcfgReq(func, pst, mBuf)
LstUcfgReq func;            /* Layer function to be called back */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   StMngmt   uCfg;
   
   TRC3(cmUnpkLstUcfgReq)

   CMCHKUNPKLOG( cmUnpkHeader, &uCfg.hdr, mBuf, ELST078, pst);

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &uCfg));
} /* end of cmUnpkLstUcfgReq */


/*
*
*       Fun:   Pack Status Request
*
*       Desc:  This function is used to pack the status request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstStaReq
(
Pst       *pst,               /* post structure */
StMngmt   *sta                /* solicited status */
)
#else
PUBLIC S16 cmPkLstStaReq(pst, sta)
Pst       *pst;               /* post structure */
StMngmt   *sta;               /* solicited status */
#endif
{
   Buffer   *mBuf;

   TRC3(cmPkLstStaReq)
 
   LST_GETMSG(pst, mBuf, ELST079);

   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELST080, pst);

   pst->event = (Event)EVTLSTSTAREQ; /* event */

   /* st005.301 -Added- Rolling Upgrade feature */
   /* Put version information in Pst structure for rolling upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LSTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstStaReq */


/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function is used to Unpack Status Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstStaReq
(
LstStaReq  func,            /* Layer function to be called back */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstStaReq(func, pst, mBuf)
LstStaReq  func;            /* Layer function to be called back */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   StMngmt   sta;
   
   TRC3(cmUnpkLstStaReq)

   CMCHKUNPKLOG( cmUnpkHeader, &sta.hdr, mBuf, ELST081, pst);

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sta));
} /* end of cmUnpkLstStaReq */


/*
*
*       Fun:   Pack Statistics Request
*
*       Desc:  This function is used to pack the statistics request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstStsReq
(
Pst       *pst,             /* post structure */
Action     action,          /* action */
StMngmt   *sts              /* statistics */
)
#else
PUBLIC S16 cmPkLstStsReq(pst, action, sts)
Pst       *pst;             /* post structure */
Action     action;          /* action */
StMngmt   *sts;             /* statistics */
#endif
{
   Buffer   *mBuf;

   TRC3(cmPkLstStsReq)

   LST_GETMSG(pst, mBuf, ELST082);

   /* date time and duration also need not be packed */
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELST083, pst);
   CMCHKPKLOG(cmPkAction, action,    mBuf, ELST084, pst);

   pst->event = (Event)EVTLSTSTSREQ; /* event */

   /* st005.301 -Added- Rolling Upgrade feature */
   /* Put version information in Pst structure for rolling upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LSTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstStsReq */


/*
*
*       Fun:   Unpack Statistics Request
*
*       Desc:  This function is used to Unpack Statistics Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstStsReq
(
LstStsReq  func,            /* Layer function to be called back */
Pst       *pst,             /* post */
Buffer    *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstStsReq(func, pst, mBuf)
LstStsReq  func;            /* Layer function to be called back */
Pst       *pst;             /* post */
Buffer    *mBuf;            /* message buffer */
#endif
{
   Action    action;
   StMngmt   sts;
   
   TRC3(cmUnpkLstStsReq)

   CMCHKUNPKLOG( cmUnpkAction, &action,  mBuf, ELST085, pst);
   CMCHKUNPKLOG( cmUnpkHeader, &sts.hdr, mBuf, ELST086, pst); 

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, action, &sts));
} /* end of cmUnpkLstStsReq */
  

/*
*
*       Fun:   Pack Control Request
*
*       Desc:  This function is used to pack the control request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstCntrlReq
(
Pst       *pst,               /* post structure */
StMngmt   *cntrl              /* control */
)
#else
PUBLIC S16 cmPkLstCntrlReq(pst, cntrl)
Pst       *pst;               /* post structure */
StMngmt   *cntrl;             /* control */
#endif
{
   Buffer      *mBuf;

   TRC3(cmPkLstCntrlReq)

   LST_GETMSG(pst, mBuf, ELST087);

#ifdef LST_LMINT3
   CMCHKPKLOG(SPkU32,        cntrl->t.cntrl.nmbCb,       mBuf, ELST088, pst);
   CMCHKPKLOG(SPkU8,         cntrl->t.cntrl.cbType,      mBuf, ELST089, pst);
   CMCHKPKLOG(cmPkTicks,     cntrl->t.cntrl.expTime,     mBuf, ELST090, pst);
#endif /* LST_LMINT3 */
   CMCHKPKLOG(cmPkProcId,    cntrl->t.cntrl.par.dstProcId, mBuf, ELST091, pst);
#ifdef DEBUGP
   CMCHKPKLOG(SPkU32,        cntrl->t.cntrl.dbg.dbgMask, mBuf, ELST092, pst);
#endif /* DEBUGP */
   CMCHKPKLOG(SPkU8,         cntrl->t.cntrl.subAction,   mBuf, ELST093, pst);
   CMCHKPKLOG(SPkU8,         cntrl->t.cntrl.action,      mBuf, ELST094, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt,          mBuf, ELST095, pst);
   CMCHKPKLOG(cmPkHeader,   &cntrl->hdr,                 mBuf, ELST096, pst);

   pst->event = (Event)EVTLSTCNTRLREQ; /* event */

   /* st005.301 -Added- Rolling Upgrade feature */
   /* Put version information in Pst structure for rolling upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   pst->intfVer = LSTIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstCntrlReq */


/*
*
*       Fun:   Unpack Control Request
*
*       Desc:  This function is used to Unpack Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstCntrlReq
(
LstCntrlReq  func,            /* Layer function to be called back */
Pst         *pst,             /* post */
Buffer      *mBuf             /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstCntrlReq(func, pst, mBuf)
LstCntrlReq  func;            /* Layer function to be called back */
Pst         *pst;             /* post */
Buffer      *mBuf;            /* message buffer */
#endif
{
   StMngmt cntrl;
   
   TRC3(cmUnpkLstCntrlReq)

   CMCHKUNPKLOG(cmUnpkHeader,   &cntrl.hdr,                 mBuf, ELST097, pst); 
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt,          mBuf, ELST098, pst); 
   CMCHKUNPKLOG(SUnpkU8,        &cntrl.t.cntrl.action,      mBuf, ELST099, pst); 
   CMCHKUNPKLOG(SUnpkU8,        &cntrl.t.cntrl.subAction,   mBuf, ELST100, pst); 
#ifdef DEBUGP
   CMCHKUNPKLOG(SUnpkU32,       &cntrl.t.cntrl.dbg.dbgMask, mBuf, ELST101, pst);
#endif /* DEBUGP */
   CMCHKUNPKLOG(cmUnpkProcId,   &cntrl.t.cntrl.par.dstProcId, mBuf, ELST102, pst);
#ifdef LST_LMINT3
   CMCHKPKLOG(cmUnpkTicks,      &cntrl.t.cntrl.expTime,     mBuf, ELST103, pst);
   CMCHKPKLOG(SUnpkU8,          &cntrl.t.cntrl.cbType,      mBuf, ELST104, pst);
   CMCHKPKLOG(SUnpkU32,         &cntrl.t.cntrl.nmbCb,       mBuf, ELST105, pst);
#endif /* LST_LMINT3 */

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cntrl));
} /* end of cmUnpkLstCntrlReq */


/*
*
*       Fun:   Pack Status Confirm
*
*       Desc:  This function is used to pack the status confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstStaCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sta            /* solicited status */
)
#else
PUBLIC S16 cmPkLstStaCfm(pst, sta)
Pst       *pst;           /* post structure */   
StMngmt   *sta;           /* solicited status */
#endif
{
   Buffer *mBuf;          /* message buffer */
   
   TRC3(cmPkLstStaCfm)

   LST_GETMSG(pst, mBuf, ELST106);

   switch (sta->hdr.elmId.elmnt)
   {
      case STTCUSAP:
      case STSPSAP:

 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPKLOG(SPkU16, sta->t.ssta.s.sapSta.remIntfVer, 
                                            mBuf, ELST107, pst);
         CMCHKPKLOG(SPkU16, sta->t.ssta.s.sapSta.selfIntfVer, 
                                            mBuf, ELST108, pst);

         CMCHKPKLOG(SPkU8,sta->t.ssta.s.sapSta.remIntfValid,
                                            mBuf, ELST014, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKPKLOG(SPkU8,     sta->t.ssta.s.sapSta.hlSt,  mBuf, ELST107, pst);
         CMCHKPKLOG(cmPkSwtch, sta->t.ssta.s.sapSta.swtch, mBuf, ELST108, pst);
       
         break;

      case STSID:
         CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELST109, pst);
         break;
   }

   CMCHKPKLOG( cmPkDateTime, &sta->t.ssta.dt, mBuf, ELST110, pst);

#ifdef LST_LMINT3
   CMCHKPKLOG( cmPkCmStatus, &sta->cfm,       mBuf, ELST111, pst);
#endif /* LST_LMINT3 */

   CMCHKPKLOG( cmPkHeader,   &sta->hdr,       mBuf, ELST112, pst);

   pst->event = EVTLSTSTACFM;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstStaCfm */


/*
*
*       Fun:   Unpack Status Request
*
*       Desc:  This function is used to unpack the status request
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstStaCfm
(
LstCfgReq  func,        /* Layer function to be called back */
Pst       *pst,         /* post structure */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstStaCfm(func, pst, mBuf)
LstCfgReq  func;        /* Layer function to be called back */
Pst       *pst;         /* post structure */
Buffer    *mBuf;        /* message buffer */
#endif
{
   StMngmt   sta;
   Txt       ptNmb[10];

   TRC3(cmUnpkLstStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader,   &sta.hdr,       mBuf, ELST113, pst); 

#ifdef LST_LMINT3
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm,       mBuf, ELST114, pst); 
#endif /* LST_LMINT3 */

   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELST115, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case STTCUSAP:
      case STSPSAP:

         CMCHKUNPKLOG(cmUnpkSwtch, &sta.t.ssta.s.sapSta.swtch, mBuf, ELST116, pst);
         CMCHKUNPKLOG(SUnpkU8,     &sta.t.ssta.s.sapSta.hlSt,  mBuf, ELST117, pst);

 /* st005.301 -Added- Rolling Upgrade feature */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         
         CMCHKUNPKLOG(SUnpkU8, &sta.t.ssta.s.sapSta.remIntfValid,
                                         mBuf, ELST061, pst);
         CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.sapSta.selfIntfVer,  
                                                        mBuf, ELST107, pst);
         CMCHKUNPKLOG(SUnpkU16, &sta.t.ssta.s.sapSta.remIntfVer, 
                                                        mBuf, ELST108, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;

      case STSID:
         sta.t.ssta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId,  mBuf, ELST118, pst);
         break;
   }
   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sta));
} /* end of cmUnpkLstStaCfm */
  

/*
*
*       Fun:   Pack Status Indication
*
*       Desc:  This function is used to pack the status indication
*              primitive to the layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstStaInd
(
Pst       *pst,           /* post structure */   
StMngmt   *usta           /* unsolicited status */
)
#else
PUBLIC S16 cmPkLstStaInd(pst, usta)
Pst       *pst;           /* post structure */   
StMngmt   *usta;          /* unsolicited status */
#endif
{
   Buffer *mBuf;
   
   TRC3(cmPkLstStaInd)

   LST_GETMSG(pst, mBuf, ELST119);

#ifdef LST_LMINT3
   CMCHKPKLOG( SPkU8,         usta->t.usta.evntParm2, mBuf, ELST120, pst);
   CMCHKPKLOG( SPkU8,         usta->t.usta.evntParm1, mBuf, ELST121, pst);
   CMCHKPKLOG( cmPkCmAlarm,  &usta->t.usta.alarm,     mBuf, ELST122, pst);
#else
   CMCHKPKLOG( cmPkTknStr64, &usta->t.usta.diag, mBuf, ELST123, pst);
   CMCHKPKLOG( cmPkStatus,    usta->t.usta.evnt, mBuf, ELST124, pst);
   CMCHKPKLOG( cmPkDateTime, &usta->t.usta.dt,   mBuf, ELST125, pst);
#endif /* LST_LMINT3 */
   
   CMCHKPKLOG( cmPkHeader, &usta->hdr, mBuf, ELST126, pst);

   pst->event = EVTLSTSTAIND;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstStaInd */


/*
*
*       Fun:   Unpack Status Indication
*
*       Desc:  This function is used to unpack the unsolicited status 
*              primitive.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstStaInd
(
LstCfgReq  func,        /* Layer function to be called back */
Pst       *pst,         /* post structure */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstStaInd(func, pst, mBuf)
LstCfgReq  func;        /* Layer function to be called back */
Pst       *pst;         /* post structure */
Buffer    *mBuf;        /* message buffer */
#endif
{
   StMngmt   usta;

   TRC3(cmUnpkLstStaInd)

   CMCHKUNPKLOG(cmUnpkHeader,   &usta.hdr,         mBuf, ELST127, pst);

#ifdef LST_LMINT3
   CMCHKUNPKLOG(cmUnpkCmAlarm,  &usta.t.usta.alarm,     mBuf, ELST128, pst);
   CMCHKUNPKLOG(SUnpkU8,        &usta.t.usta.evntParm1, mBuf, ELST129, pst);
   CMCHKUNPKLOG(SUnpkU8,        &usta.t.usta.evntParm2, mBuf, ELST130, pst);
#else
   CMCHKUNPKLOG(cmUnpkDateTime, &usta.t.usta.dt,   mBuf, ELST131, pst);
   CMCHKUNPKLOG(cmUnpkStatus,   &usta.t.usta.evnt, mBuf, ELST132, pst);
   CMCHKUNPKLOG(cmUnpkTknStr64, &usta.t.usta.diag, mBuf, ELST133, pst);
#endif /* LST_LMINT3 */

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &usta));
} /* end of cmUnpkLstStaInd */


/*
*
*       Fun:   Pack Statistics Confirm
*
*       Desc:  This function is used to pack the statistics confirm
*              primitive to layer management.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstStsCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *sts            /* statistics */
)
#else
PUBLIC S16 cmPkLstStsCfm(pst, sts)
Pst       *pst;           /* post structure */   
StMngmt   *sts;           /* statistics */
#endif
{
   Buffer      *mBuf;
   StSapSts    *s;        /* Pointer to Sap Statistics */
   Bool         ituFlag;
   
   TRC3(cmPkLstStsCfm)

   LST_GETMSG(pst, mBuf, ELST134);

   s = &sts->t.sts.sapSts;
 
   /* Set the protocol flag */
   switch(s->swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
#if (SS7_ETSI)
      case LST_SW_ETS96:
#endif
         ituFlag = TRUE;
         break;
 
      default:
         ituFlag = FALSE;
         break;
   }

   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmRETx, mBuf, ELST135, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->uxEcdTx,   mBuf, ELST136, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urErrTx,   mBuf, ELST137, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmRRTx, mBuf, ELST138, pst);

   if (ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->uxLoprTx,  mBuf, ELST139, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->uxLrspTx,  mBuf, ELST140, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->rlsInvTx,  mBuf, ELST141, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->rsrcInvTx, mBuf, ELST142, pst);
   }
   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmINTx, mBuf, ELST143, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urOprTx,   mBuf, ELST144, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->dupIdTx,   mBuf, ELST145, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->inEncTx, mBuf, ELST146, pst);
   }
#endif
   CMCHKPKLOG(cmPkStEvCnt, &s->uxErrTx,   mBuf, ELST147, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urIidRETx, mBuf, ELST148, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->uxResTx,   mBuf, ELST149, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urIidRRTx, mBuf, ELST150, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urLidTx,   mBuf, ELST151, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->bdCmpTx,   mBuf, ELST152, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inCmpTx,   mBuf, ELST153, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urCmpTx,   mBuf, ELST154, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->inDlgTx, mBuf, ELST155, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->msDlgTx, mBuf, ELST156, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->bdDlgTx, mBuf, ELST157, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->urDlgTx, mBuf, ELST158, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->prRlsTx, mBuf, ELST159, pst);
   }
#endif
   CMCHKPKLOG(cmPkStEvCnt, &s->rsrcLTx, mBuf, ELST160, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urTidTx, mBuf, ELST161, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->bdTrnTx, mBuf, ELST162, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inTrnTx, mBuf, ELST163, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urMsgTx, mBuf, ELST164, pst);

   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmRERx, mBuf, ELST165, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->uxEcdRx,   mBuf, ELST166, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urErrRx,   mBuf, ELST167, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmRRRx, mBuf, ELST168, pst);

   if (ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->uxLoprRx,  mBuf, ELST169, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->uxLrspRx,  mBuf, ELST170, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->rlsInvRx,  mBuf, ELST171, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->rsrcInvRx, mBuf, ELST172, pst);
   }
   CMCHKPKLOG(cmPkStEvCnt, &s->inPrmINRx, mBuf, ELST173, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urOprRx,   mBuf, ELST174, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->dupIdRx,   mBuf, ELST175, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->inEncRx, mBuf, ELST176, pst);
   }
#endif
   CMCHKPKLOG(cmPkStEvCnt, &s->uxErrRx,   mBuf, ELST177, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urIidRERx, mBuf, ELST178, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->uxResRx,   mBuf, ELST179, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urIidRRRx, mBuf, ELST180, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urLidRx,   mBuf, ELST181, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->bdCmpRx,   mBuf, ELST182, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inCmpRx,   mBuf, ELST183, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urCmpRx,   mBuf, ELST184, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKPKLOG(cmPkStEvCnt, &s->inDlgRx, mBuf, ELST185, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->msDlgRx, mBuf, ELST186, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->bdDlgRx, mBuf, ELST187, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->urDlgRx, mBuf, ELST188, pst);
      CMCHKPKLOG(cmPkStEvCnt, &s->prRlsRx, mBuf, ELST189, pst);
   }
#endif
   CMCHKPKLOG(cmPkStEvCnt, &s->rsrcLRx, mBuf, ELST190, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urTidRx, mBuf, ELST191, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->bdTrnRx, mBuf, ELST192, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->inTrnRx, mBuf, ELST193, pst);
   CMCHKPKLOG(cmPkStEvCnt, &s->urMsgRx, mBuf, ELST194, pst);

   CMCHKPKLOG(cmPkCntr, s->drop,    mBuf, ELST195, pst);

   CMCHKPKLOG(cmPkCntr, s->trnsId,  mBuf, ELST196, pst);
   CMCHKPKLOG(cmPkCntr, s->usedInv, mBuf, ELSTXXX, pst);
   CMCHKPKLOG(cmPkCntr, s->usedTrns, mBuf, ELSTXXX, pst);
   CMCHKPKLOG(cmPkCntr, s->actInv,  mBuf, ELST197, pst);
   CMCHKPKLOG(cmPkCntr, s->actTrns, mBuf, ELST198, pst);

   CMCHKPKLOG(cmPkCntr, s->rejRx, mBuf, ELST199, pst);
   CMCHKPKLOG(cmPkCntr, s->errRx, mBuf, ELST200, pst);
   CMCHKPKLOG(cmPkCntr, s->resRx, mBuf, ELST201, pst);
   CMCHKPKLOG(cmPkCntr, s->invRx, mBuf, ELST202, pst);
   CMCHKPKLOG(cmPkCntr, s->cmpRx, mBuf, ELST203, pst);
 
   CMCHKPKLOG(cmPkCntr, s->rejTx, mBuf, ELST204, pst);
   CMCHKPKLOG(cmPkCntr, s->errTx, mBuf, ELST205, pst);
   CMCHKPKLOG(cmPkCntr, s->resTx, mBuf, ELST206, pst);
   CMCHKPKLOG(cmPkCntr, s->invTx, mBuf, ELST207, pst);
   CMCHKPKLOG(cmPkCntr, s->cmpTx, mBuf, ELST208, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKPKLOG(cmPkCntr, s->rspRx, mBuf, ELST209, pst);
      CMCHKPKLOG(cmPkCntr, s->cnpRx, mBuf, ELST210, pst);
      CMCHKPKLOG(cmPkCntr, s->cwpRx, mBuf, ELST211, pst);
      CMCHKPKLOG(cmPkCntr, s->qnpRx, mBuf, ELST212, pst);
      CMCHKPKLOG(cmPkCntr, s->qwpRx, mBuf, ELST213, pst);

      CMCHKPKLOG(cmPkCntr, s->rspTx, mBuf, ELST214, pst);
      CMCHKPKLOG(cmPkCntr, s->cnpTx, mBuf, ELST215, pst);
      CMCHKPKLOG(cmPkCntr, s->cwpTx, mBuf, ELST216, pst);
      CMCHKPKLOG(cmPkCntr, s->qnpTx, mBuf, ELST217, pst);
      CMCHKPKLOG(cmPkCntr, s->qwpTx, mBuf, ELST218, pst);
   }
   else
#endif
   if (ituFlag)
   {
      CMCHKPKLOG(cmPkCntr, s->endRx, mBuf, ELST219, pst);
      CMCHKPKLOG(cmPkCntr, s->cntRx, mBuf, ELST220, pst);
      CMCHKPKLOG(cmPkCntr, s->bgnRx, mBuf, ELST221, pst);

      CMCHKPKLOG(cmPkCntr, s->endTx, mBuf, ELST222, pst);
      CMCHKPKLOG(cmPkCntr, s->cntTx, mBuf, ELST223, pst);
      CMCHKPKLOG(cmPkCntr, s->bgnTx, mBuf, ELST224, pst);
   }
   CMCHKPKLOG(cmPkCntr, s->abtRx, mBuf, ELST225, pst);
   CMCHKPKLOG(cmPkCntr, s->uniRx, mBuf, ELST226, pst);
   CMCHKPKLOG(cmPkCntr, s->abtTx, mBuf, ELST227, pst);
   CMCHKPKLOG(cmPkCntr, s->uniTx, mBuf, ELST228, pst);

   CMCHKPKLOG(cmPkCntr, s->msgRx, mBuf, ELST229, pst);
   CMCHKPKLOG(cmPkCntr, s->msgTx, mBuf, ELST230, pst);

   CMCHKPKLOG(cmPkTicks,    s->ticks, mBuf, ELST231, pst);
   CMCHKPKLOG(cmPkDateTime, &s->dt,   mBuf, ELST232, pst);
   CMCHKPKLOG(cmPkSwtch,    s->swtch, mBuf, ELST233, pst);

   CMCHKPKLOG(cmPkTicks,    sts->t.sts.duraT, mBuf, ELST234, pst);
   CMCHKPKLOG(cmPkDuration, &sts->t.sts.dura, mBuf, ELST235, pst);
   CMCHKPKLOG(cmPkTicks,    sts->t.sts.ticks, mBuf, ELST236, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt,   mBuf, ELST237, pst);

#ifdef LST_LMINT3
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm,        mBuf, ELST238, pst);
#endif /* LST_LMINT3 */

   CMCHKPKLOG(cmPkHeader,   &sts->hdr,        mBuf, ELST239, pst);
 
   pst->event = EVTLSTSTSCFM;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstStsCfm */


/*
*
*       Fun:   Unpack Statistics Confirm
*
*       Desc:  This function is used to unpack the statistics confirm
*              primitive to TCAP.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstStsCfm
(
LstCfgReq  func,        /* Layer function to be called back */
Pst       *pst,         /* post structure */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstStsCfm(func, pst, mBuf)
LstCfgReq  func;        /* Layer function to be called back */
Pst       *pst;         /* post structure */
Buffer    *mBuf;        /* message buffer */
#endif
{
   StMngmt   sts;
   StSapSts *s;
   Bool      ituFlag;

   TRC3(cmUnpkLstStsCfm)

   /* Initialize the management structure */
   cmZero((Data *)&sts, sizeof(StMngmt));

   s = &sts.t.sts.sapSts;

   CMCHKUNPKLOG(cmUnpkHeader,   &sts.hdr,         mBuf, ELST240, pst);

#ifdef LST_LMINT3
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm,       mBuf, ELST241, pst); 
#endif /* LST_LMINT3 */

   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt,    mBuf, ELST242, pst);
   CMCHKUNPKLOG(cmUnpkTicks,    &sts.t.sts.ticks, mBuf, ELST243, pst);
   CMCHKUNPKLOG(cmUnpkDuration, &sts.t.sts.dura,  mBuf, ELST244, pst);
   CMCHKUNPKLOG(cmUnpkTicks,    &sts.t.sts.duraT, mBuf, ELST245, pst);

   /* get switch type first */
   CMCHKUNPKLOG(cmUnpkSwtch,    &s->swtch,    mBuf, ELST246, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &s->dt,       mBuf, ELST247, pst);
   CMCHKUNPKLOG(cmUnpkTicks,    &s->ticks,    mBuf, ELST248, pst);

   /* Set the protocol flag */
   switch(s->swtch)
   {
      case LST_SW_ITU88:
      case LST_SW_ITU92:
      case LST_SW_ITU96:
#if (SS7_ETSI)
      case LST_SW_ETS96:
#endif
         ituFlag = TRUE;
         break;

      default:
         ituFlag = FALSE;
         break;
   }
   CMCHKUNPKLOG(cmUnpkCntr,     &s->msgTx,    mBuf, ELST249, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->msgRx,    mBuf, ELST250, pst);

   CMCHKUNPKLOG(cmUnpkCntr,     &s->uniTx,    mBuf, ELST251, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->abtTx,    mBuf, ELST252, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->uniRx,    mBuf, ELST253, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->abtRx,    mBuf, ELST254, pst);

   if (ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkCntr,  &s->bgnTx,    mBuf, ELST255, pst);
      CMCHKUNPKLOG(cmUnpkCntr,  &s->cntTx,    mBuf, ELST256, pst);
      CMCHKUNPKLOG(cmUnpkCntr,  &s->endTx,    mBuf, ELST257, pst);

      CMCHKUNPKLOG(cmUnpkCntr,  &s->bgnRx,    mBuf, ELST258, pst);
      CMCHKUNPKLOG(cmUnpkCntr,  &s->cntRx,    mBuf, ELST259, pst);
      CMCHKUNPKLOG(cmUnpkCntr,  &s->endRx,    mBuf, ELST260, pst);
   }
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   else
   {
      CMCHKUNPKLOG(cmUnpkCntr, &s->qwpTx, mBuf, ELST261, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->qnpTx, mBuf, ELST262, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->cwpTx, mBuf, ELST263, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->cnpTx, mBuf, ELST264, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->rspTx, mBuf, ELST265, pst);

      CMCHKUNPKLOG(cmUnpkCntr, &s->qwpRx, mBuf, ELST266, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->qnpRx, mBuf, ELST267, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->cwpRx, mBuf, ELST268, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->cnpRx, mBuf, ELST269, pst);
      CMCHKUNPKLOG(cmUnpkCntr, &s->rspRx, mBuf, ELST270, pst);
   }
#endif
   CMCHKUNPKLOG(cmUnpkCntr,     &s->cmpTx,    mBuf, ELST271, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->invTx,    mBuf, ELST272, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->resTx,    mBuf, ELST273, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->errTx,    mBuf, ELST274, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->rejTx,    mBuf, ELST275, pst);

   CMCHKUNPKLOG(cmUnpkCntr,     &s->cmpRx,    mBuf, ELST276, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->invRx,    mBuf, ELST277, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->resRx,    mBuf, ELST278, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->errRx,    mBuf, ELST279, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->rejRx,    mBuf, ELST280, pst);

   CMCHKUNPKLOG(cmUnpkCntr,     &s->actTrns,  mBuf, ELST281, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->actInv,   mBuf, ELST282, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->usedTrns,  mBuf, ELSTXXX, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->usedInv,  mBuf, ELSTXXX, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->trnsId,   mBuf, ELST283, pst);
   CMCHKUNPKLOG(cmUnpkCntr,     &s->drop,     mBuf, ELST284, pst);

   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urMsgRx,    mBuf, ELST285, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inTrnRx,    mBuf, ELST286, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->bdTrnRx,    mBuf, ELST287, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urTidRx,    mBuf, ELST288, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rsrcLRx,    mBuf, ELST289, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->prRlsRx, mBuf, ELST290, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->urDlgRx, mBuf, ELST291, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->bdDlgRx, mBuf, ELST292, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->msDlgRx, mBuf, ELST293, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->inDlgRx, mBuf, ELST294, pst);
   }
#endif
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urCmpRx,    mBuf, ELST295, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inCmpRx,    mBuf, ELST296, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->bdCmpRx,    mBuf, ELST297, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urLidRx,    mBuf, ELST298, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urIidRRRx,  mBuf, ELST299, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxResRx,    mBuf, ELST300, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urIidRERx,  mBuf, ELST301, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxErrRx,    mBuf, ELST302, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->inEncRx, mBuf, ELST303, pst);
   }
#endif
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->dupIdRx,    mBuf, ELST304, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urOprRx,    mBuf, ELST305, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmINRx,  mBuf, ELST306, pst);

   if (ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rsrcInvRx,  mBuf, ELST307, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rlsInvRx,   mBuf, ELST308, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxLrspRx,   mBuf, ELST309, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxLoprRx,   mBuf, ELST310, pst);
   }
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmRRRx,  mBuf, ELST311, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urErrRx,    mBuf, ELST312, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxEcdRx,    mBuf, ELST313, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmRERx,  mBuf, ELST314, pst);

   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urMsgTx,    mBuf, ELST315, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inTrnTx,    mBuf, ELST316, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->bdTrnTx,    mBuf, ELST317, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urTidTx,    mBuf, ELST318, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rsrcLTx,    mBuf, ELST319, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->prRlsTx, mBuf, ELST320, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->urDlgTx, mBuf, ELST321, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->bdDlgTx, mBuf, ELST322, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->msDlgTx, mBuf, ELST323, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->inDlgTx, mBuf, ELST324, pst);
   }
#endif
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urCmpTx,    mBuf, ELST325, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inCmpTx,    mBuf, ELST326, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->bdCmpTx,    mBuf, ELST327, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urLidTx,    mBuf, ELST328, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urIidRRTx,  mBuf, ELST329, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxResTx,    mBuf, ELST330, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urIidRETx,  mBuf, ELST331, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxErrTx,    mBuf, ELST332, pst);

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS96)
   if (!ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt, &s->inEncTx, mBuf, ELST333, pst);
   }
#endif
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->dupIdTx,    mBuf, ELST334, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urOprTx,    mBuf, ELST335, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmINTx,  mBuf, ELST336, pst);

   if (ituFlag)
   {
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rsrcInvTx,  mBuf, ELST337, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->rlsInvTx,   mBuf, ELST338, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxLrspTx,   mBuf, ELST339, pst);
      CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxLoprTx,   mBuf, ELST340, pst);
   }
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmRRTx,  mBuf, ELST341, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->urErrTx,    mBuf, ELST342, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->uxEcdTx,    mBuf, ELST343, pst);
   CMCHKUNPKLOG(cmUnpkStEvCnt,  &s->inPrmRETx,  mBuf, ELST344, pst);

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sts));
} /* end of cmUnpkLstStsCfm */


/*
*
*       Fun:   Pack Trace Indication
*
*       Desc:  This function is used to pack the trace indication
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstTrcInd
(
Pst       *pst,           /* post structure */   
StMngmt   *trc            /* trace */
)
#else
PUBLIC S16 cmPkLstTrcInd(pst, trc)
Pst       *pst;           /* post structure */   
StMngmt   *trc;           /* trace */
#endif
{
   Buffer *mBuf;          /* message buffer */
   U16     len;           /* Length of event */
   U16     i;             /* counter */

   TRC3(cmPkLstTrcInd)

   LST_GETMSG(pst, mBuf, ELST345);

   len = trc->t.trc.len;

   for (i = len; i > 0; i--)  
   {
      CMCHKPKLOG( SPkU8, trc->t.trc.evntParm[i-1], mBuf, ELST346, pst);
   }
   CMCHKPKLOG( SPkU16,        trc->t.trc.len,  mBuf, ELST347, pst);
   CMCHKPKLOG( SPkU16,        trc->t.trc.evnt, mBuf, ELST348, pst);
   CMCHKPKLOG( cmPkDateTime, &trc->t.trc.dt,   mBuf, ELST349, pst);
   CMCHKPKLOG( cmPkHeader,   &trc->hdr,        mBuf, ELST350, pst);

   pst->event = EVTLSTTRCIND;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstTrcInd */


/*
*
*       Fun:   Unpack Trace Indication
*
*       Desc:  This function is used to unpack the trace indication 
*              primitive to MTP level 2.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstTrcInd
(
LstCfgReq  func,        /* Layer function to be called back */
Pst       *pst,         /* post structure */
Buffer    *mBuf         /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstTrcInd(func, pst, mBuf)
LstCfgReq  func;        /* Layer function to be called back */
Pst       *pst;         /* post structure */
Buffer    *mBuf;        /* message buffer */
#endif
{
   StMngmt   trc;
   U16       i;

   TRC3(cmUnpkLstTrcInd)

   CMCHKUNPKLOG(cmUnpkHeader,   &trc.hdr,        mBuf, ELST351, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &trc.t.trc.dt,   mBuf, ELST352, pst);
   CMCHKUNPKLOG(SUnpkU16,       &trc.t.trc.evnt, mBuf, ELST353, pst);
   CMCHKUNPKLOG(SUnpkU16,       &trc.t.trc.len,  mBuf, ELST354, pst);
   for (i = 0; i < trc.t.trc.len; i++) 
   { 
      CMCHKUNPKLOG(SUnpkU8, &trc.t.trc.evntParm[i], mBuf, ELST355, pst);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &trc));
} /* end of cmUnpkLstTrcInd */


#ifdef LST_LMINT3
/*
*
*       Fun:   Pack Configuration Confirm
*
*       Desc:  This function is used to pack the Configuration Confirm
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstCfgCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* confirm structure */
)
#else
PUBLIC S16 cmPkLstCfgCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* confirm structure */
#endif
{
   Buffer *mBuf;          /* message buffer */

   TRC3(cmPkLstCfgCfm)

   LST_GETMSG(pst, mBuf, ELST356);

   CMCHKPKLOG( cmPkCmStatus, &cfm->cfm, mBuf, ELST357, pst);
   CMCHKPKLOG( cmPkHeader,   &cfm->hdr, mBuf, ELST358, pst);

   pst->event = EVTLSTCFGCFM;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstCfgCfm */


/*
*
*       Fun:   Unpack config confirmation
*
*       Desc:  This function is used to unpack the  config confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstCfgCfm
(
LstCfgReq  func,      /* Layer function to be called back */
Pst       *pst,
Buffer    *mBuf       /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstCfgCfm(func, pst, mBuf)
LstCfgReq  func;      /* Layer function to be called back */
Pst       *pst;
Buffer    *mBuf;      /* message buffer */
#endif
{
   StMngmt   cfm;
 
   TRC3(cmUnpkLstCfgCfm)
 
   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELST359, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELST360, pst);
 
   SPutMsg(mBuf);
 
   RETVALUE((*func)(pst, &cfm));
} /* end of cmUnpkLstCfgCfm */


/*
*
*       Fun:   Pack Control Confirm
*
*       Desc:  This function is used to pack the Control Confirm
*              primitive to layer management.
*
*       Ret:   None
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLstCntrlCfm
(
Pst       *pst,           /* post structure */   
StMngmt   *cfm            /* confirm structure */
)
#else
PUBLIC S16 cmPkLstCntrlCfm(pst, cfm)
Pst       *pst;           /* post structure */   
StMngmt   *cfm;           /* confirm structure */
#endif
{
   Buffer *mBuf;          /* message buffer */

   TRC3(cmPkLstCntrlCfm)

   LST_GETMSG(pst, mBuf, ELST361);

   CMCHKPKLOG( cmPkCmStatus, &cfm->cfm, mBuf, ELST362, pst);
   CMCHKPKLOG( cmPkHeader,   &cfm->hdr, mBuf, ELST363, pst);

   pst->event = EVTLSTCNTRLCFM;

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
} /* end of cmPkLstCntrlCfm */


/*
*
*       Fun:   Unpack control confirmation
*
*       Desc:  This function is used to unpack the  control confirm
*              primitive to layer manager.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  lst.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLstCntrlCfm
(
LstCfgReq  func,      /* Layer function to be called back */
Pst       *pst,
Buffer    *mBuf       /* message buffer */
)
#else
PUBLIC S16 cmUnpkLstCntrlCfm(func, pst, mBuf)
LstCfgReq  func;      /* Layer function to be called back */
Pst       *pst;
Buffer    *mBuf;      /* message buffer */
#endif
{
   StMngmt   cfm;
 
   TRC3(cmUnpkLstCntrlCfm)
 
   CMCHKUNPKLOG(cmUnpkHeader,   &cfm.hdr, mBuf, ELST364, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELST365, pst);
 
   SPutMsg(mBuf);
 
   RETVALUE((*func)(pst, &cfm));
} /* end of cmUnpkLstCntrlCfm */
#endif /* LST_LMINT3 */ 

#endif /* LCLST */


/********************************************************************30**
  
         End of file:     lst.c@@/main/2 - Fri Nov 17 10:33:51 2000
  
*********************************************************************31*/
  

/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/
  
/********************************************************************50**
  
*********************************************************************51*/
  

/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
 
*********************************************************************81*/
/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.1          ---      nj   1. initial release.
1.2          ---      nj   1. Fixed a bug in trace indication packing
1.3          ---      nj   1. Added packing/unpacking for group sap parameter
                              in control request
/main/2      ---      nj   1. Changes related to DFTHA
3.1+      st005.301   zr   1. Rolling Upgrade Feature
                           - Version info. packing unpacking cases added
                           - pst structure contains version info wherever 
                             applicable.
    lst_c_001.main_2  akp  1. code changes made in packing unpacking LstCfg 
                           functions, due to increase in storage
                           datatypes in some of fields in genCfg & TuSapCfg 
                           structure from U16 to U32.  
                           2. pst structure version information is maintained
                           unconditionally.
    lst_c_002.main_2  jz   1. code changes made to avoid overwriting interface
                           version in pst structure.
    lst_c_003.main_2  mkm  1. Added packing and unpacking of Dialogue Hash
                              Bin Size.
*********************************************************************91*/
