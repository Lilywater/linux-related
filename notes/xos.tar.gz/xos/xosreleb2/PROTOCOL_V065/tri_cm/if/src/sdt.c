/********************************************************************16**

        (c) COPYRIGHT 1989-1998 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**
  
     Name:     mtp level 2 - portable upper interface
  
     Type:     C source file
  
     Desc:     C source code for the MTP 2 upper interface packing/unpacking
               primitives.

     File:     sdt.c
  
     Sid:      sdt.c 1.1  -  08/25/98 18:01:54
  
     Prg:     sr 
  
*********************************************************************21*/
  

/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "sdt.h"           /* data link layer */

/* header/extern include files (.x) */
  
#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "sdt.x"           /* data link layer */

  
/* local defines */

/* local typedefs */
  
/* local externs */
  
/* forward references */


#ifdef LCSDT

/* packing functions */

#ifdef SDT2
 
/*  
*  
*       Fun:   Pack Data Link bind Confirmation
*   
*       Desc:  This function packs a bind confirmation for a loosely 
*              coupled Data Link interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  sdt.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 cmPkSdtBndCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
U8 status                   /* status */
)
#else
PUBLIC S16 cmPkSdtBndCfm(pst, suId, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
U8 status;                  /* status */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSdtBndCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(SPkU8, status, mBuf, ESDT001, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT002, pst);
   pst->event = EVTSDTBNDCFM;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtBndCfm */
#endif /* SDT2 */

/*  
*  
*       Fun:   Pack Data Link Connect Confirm
*   
*       Desc:  This function packs a connect confirm for a loosely coupled
*              Data Link interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  sdt.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 cmPkSdtConCfm
(
Pst *pst,                   /* post structure */
SuId suId                   /* service user id */
)
#else
PUBLIC S16 cmPkSdtConCfm(pst, suId)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
#endif
{
   Buffer *mBuf;            /* message buffer */

   TRC2(cmPkSdtConCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }

   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT003, pst);
   pst->event = EVTSDTCONCFM;
   RETVALUE(SPstTsk(pst, mBuf));

} /* end of cmPkSdtConCfm  */


/* 
* 
*       Fun:   Pack Data Link Data Confirmation
*  
*       Desc:  This function packs a data confirm for a loosely coupled
*              Data Link interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  sdt.c
* 
*/

#ifdef ANSI
PUBLIC S16 cmPkSdtDatCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Buffer *mBuf,               /* message buffer */
MtpStatus status,           /* status */
SeqU24 credit               /* credit */
)
#else
PUBLIC S16 cmPkSdtDatCfm(pst, suId, mBuf, status, credit)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Buffer *mBuf;               /* message buffer */
MtpStatus status;           /* status */
SeqU24 credit;              /* credit */
#endif
{
   TRC2(cmPkSdtDatCfm)
   CMCHKPKLOG(SPkU32, credit, mBuf, ESDT004, pst);
   CMCHKPKLOG(SPkU8, status, mBuf, ESDT005, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT006, pst);
   pst->event = EVTSDTDATCFM;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtDatCfm */


/* 
* 
*       Fun:   Pack Data Link Data Indication
*  
*       Desc:  This function packs a data indication for a loosely coupled
*              Data Link interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  sdt.c
* 
*/

#ifdef ANSI
PUBLIC S16 cmPkSdtDatInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmPkSdtDatInd(pst, suId, mBuf)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC2(cmPkSdtDatInd)
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT007, pst);
   pst->event = EVTSDTDATIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtDatInd */


/* 
* 
*       Fun:   Pack Data Link Disconnect Indication
*  
*       Desc:  This function packs a disconnect indication for a loosely coupled
*              Data Link interface
*  
*       Ret:   ROK      - ok
* 
*       Notes: None 
* 
*       File:  sdt.c
* 
*/
 
#ifdef ANSI
PUBLIC S16 cmPkSdtDiscInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Reason reason               /* reason */
)
#else
PUBLIC S16 cmPkSdtDiscInd(pst, suId, reason)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Reason reason;              /* reason */
#endif
{
   Buffer *mBuf;            /* message buffer */
 
   TRC2(cmPkSdtDiscInd)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
 
   CMCHKPKLOG(SPkS16, reason, mBuf, ESDT008, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT009, pst);
   pst->event = EVTSDTDISCIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtDiscInd */
 

/*  
*  
*       Fun:   Pack Data Link Flow Control Indication
*   
*       Desc:  This function packs a flow control indication for a loosely 
*              coupled Data Link interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  sdt.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 cmPkSdtFlcInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Action action               /* action */
)
#else
PUBLIC S16 cmPkSdtFlcInd(pst, suId, action)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Action action;              /* action */
#endif
{
   Buffer *mBuf;

   TRC2(sdPkUiSdtFlcInd)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(SPkS16, action, mBuf, ESDT010, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT011, pst);
   pst->event = EVTSDTFLCIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtFlcInd */


 
/*  
*  
*       Fun:   Pack Data Link Status Confirmation
*   
*       Desc:  This function packs a status confirmation for a loosely 
*              coupled Data Link interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  sdt.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 cmPkSdtStaCfm
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
Action action,              /* action */
SeqU24 status               /* status */
)
#else
PUBLIC S16 cmPkSdtStaCfm(pst, suId, action, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
Action action;              /* action */
SeqU24 status;              /* status */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSdtStaCfm)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(SPkU32, status, mBuf, ESDT012, pst);
   CMCHKPKLOG(SPkS16, action, mBuf, ESDT013, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT014, pst);
   pst->event = EVTSDTSTACFM;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtStaCfm */



 
/*  
*  
*       Fun:   Pack Data Link Status Indication
*   
*       Desc:  This function packs a status indication for a loosely 
*              coupled Data Link interface
*   
*       Ret:   ROK      - ok 
*  
*       Notes: None  
*  
*       File:  sdt.c
*  
*/ 
 
#ifdef ANSI
PUBLIC S16 cmPkSdtStaInd
(
Pst *pst,                   /* post structure */
SuId suId,                  /* service user id */
MtpStatus status            /* status */
)
#else
PUBLIC S16 cmPkSdtStaInd(pst, suId, status)
Pst *pst;                   /* post structure */
SuId suId;                  /* service user id */
MtpStatus status;           /* status */
#endif
{
   Buffer *mBuf;

   TRC2(cmPkSdtStaInd)
   if(SGetMsg(pst->region, pst->pool, &mBuf) != ROK)
   {
      RETVALUE(RFAILED);
   }
   CMCHKPKLOG(SPkU8, status, mBuf, ESDT015, pst);
   CMCHKPKLOG(SPkS16, suId, mBuf, ESDT016, pst);
   pst->event = EVTSDTSTAIND;
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtStaInd */


/* Unpacking functions */
  
/*
*
*       Fun:   Unpack Data Link Data Request
*
*       Desc:  This function is used to Unpack Data Link Data Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtDatReq
(
SdtDatReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtDatReq(func, pst, mBuf)
SdtDatReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   LnkNmb lnkNmb;           /* link number */

   TRC3(cmUnpkSdtDatReq)
   CMCHKUNPKLOG(SUnpkS16, &lnkNmb, mBuf, ESDT017, pst);
   RETVALUE((*func)(pst, lnkNmb, mBuf));
}  /* end of cmUnpkSdtDatReq */


/*
*
*       Fun:   Unpack Data Link Bind Request
*
*       Desc:  This function is used to Unpack Data Link Bind Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtBndReq
(
SdtBndReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtBndReq(func, pst, mBuf)
SdtBndReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   SuId suId;               /* service user id */
   SpId spId;               /* service provider id */

   TRC3(cmUnpkSdtBndReq)

   CMCHKUNPKLOG(SUnpkS16, &spId, mBuf, ESDT018, pst);
   CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESDT019, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, suId, spId));

} /* end of cmUnpkSdtBndReq */


  
/*
*
*       Fun:   Unpack Data Link Unbind Request
*
*       Desc:  This function is used to Unpack Data Link Unbind Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtUBndReq
(
SdtUBndReq func,            /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtUBndReq(func, pst, mBuf)
SdtUBndReq func;            /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   SuId suId;               /* service user id */
   Reason reason;           /* unbind reason */

   TRC3(cmUnpkSdtUBndReq)

   CMCHKUNPKLOG(SUnpkS16, &suId, mBuf, ESDT020, pst);
   CMCHKUNPKLOG(SUnpkS16, &reason, mBuf, ESDT021, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, suId, reason));
} /* end of cmUnpkSdtUBndReq */


  
/*
*
*       Fun:   Unpack Data Link Connect Request
*
*       Desc:  This function is used to Unpack Data Link Connect Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtConReq
(
SdtConReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtConReq(func, pst, mBuf)
SdtConReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   LnkNmb lnkNmb;           /* link number */
   MtpStatus status;        /* status */

   TRC3(cmUnpkSdtConReq)

   CMCHKUNPKLOG(SUnpkS16, &lnkNmb, mBuf, ESDT022, pst);
   CMCHKUNPKLOG(SUnpkU8, &status, mBuf, ESDT023, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, lnkNmb, status));
} /* end of cmUnpkSdtConReq */


  
/*
*
*       Fun:   Unpack Data Link Disconnect Request
*
*       Desc:  This function is used to Unpack Data Link Disconnect Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtDiscReq
(
SdtDiscReq func,            /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtDiscReq(func, pst, mBuf)
SdtDiscReq func;            /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   LnkNmb lnkNmb;           /* link number */
   Reason reason;           /* reason */

   TRC3(cmUnpkSdtDiscReq)
   CMCHKUNPKLOG(SUnpkS16, &lnkNmb, mBuf, ESDT024, pst);
   CMCHKUNPKLOG(SUnpkS16, &reason, mBuf, ESDT025, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, lnkNmb, reason));
} /* end of cmUnpkSdtDiscReq */


  
/*
*
*       Fun:   Unpack Data Link Flow Control Request
*
*       Desc:  This function is used to Unpack Data Link Flow Control Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtFlcReq
(
SdtFlcReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtFlcReq(func, pst, mBuf)
SdtFlcReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   LnkNmb lnkNmb;           /* link number */
   Action action;           /* action */

   TRC3(cmUnpkSdtFlcReq)
   CMCHKUNPKLOG(SUnpkS16, &lnkNmb, mBuf, ESDT026, pst);
   CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ESDT027, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, lnkNmb, action));
} /* end of cmUnpkSdtFlcReq */

  
/*
*
*       Fun:   Unpack Data Link Status Request
*
*       Desc:  This function is used to Unpack Data Link Status Request
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtStaReq
(
SdtStaReq func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message pointer */
)
#else
PUBLIC S16 cmUnpkSdtStaReq(func, pst, mBuf)
SdtStaReq func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message pointer */
#endif
{
   LnkNmb lnkNmb;           /* link number */
   Action action;           /* action */
   SeqU24 status;           /* status */

   TRC3(cmUnpkSdtStaReq)
   CMCHKUNPKLOG(SUnpkS16, &lnkNmb, mBuf, ESDT028, pst);
   CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ESDT029, pst);
   CMCHKUNPKLOG(SUnpkU32, &status, mBuf, ESDT030, pst);
   SPutMsg(mBuf);
   RETVALUE((*func)(pst, lnkNmb, action, status));
} /* end of cmUnpkSdtStaReq */

  
/*
*
*       Fun:   pack - Data Link Bind Request
*
*       Desc:  This function binds a MTP Level 3 Entity to the data link
*              Entity. 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtBndReq
(
Pst *pst,                   /* bind configuration */
SuId suId,                  /* service user id */
SpId spId                   /* service provider id */
)
#else
PUBLIC S16 cmPkSdtBndReq(pst, suId, spId)
Pst *pst;                   /* bind configuration */
SuId suId;                  /* service user id */
SpId spId;                  /* service provider id */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtBndReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT031, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, suId, mBuf, ESDT032, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT033, pst);
   pst->event = (Event) EVTSDTBNDREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtBndReq */


  
/*
*
*       Fun:   pack - Data Link Connect Request
*
*       Desc:  This function informs the Data Link Layer to bring the 
*              the physical link up. This function must
*              be confirmed by a SnLiSdtConCfm.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtConReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service priovider id */
MtpStatus status            /* status */ 
)
#else
PUBLIC S16 cmPkSdtConReq(pst, spId, status)
Pst *pst;                   /* post structure */
SpId spId;                  /* service priovider id */
MtpStatus status;           /* status */ 
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtConReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT034, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkU8, status, mBuf, ESDT035, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT036, pst);
   pst->event = (Event) EVTSDTCONREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtConReq */


  
/*
*
*       Fun:   pack - Data Link Data Request
*
*       Desc:  This function tells the MTP Level 2 to transmit data.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/

#ifdef ANSI
PUBLIC S16 cmPkSdtDatReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service priovider id */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmPkSdtDatReq(pst, spId, mBuf)
Pst *pst;                   /* post structure */
SpId spId;                  /* service priovider id */
Buffer *mBuf;               /* message buffer */
#endif
{
   TRC3(cmPkSdtDatReq)

   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT037, pst);
   pst->event = (Event) EVTSDTDATREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
}  /* end of cmPkSdtDatReq */


  
/*
*
*       Fun:   pack - Data Link Disconnect Request
*
*       Desc:  This function tells the MTP Level 2 to disconnect
*              the link. 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtDiscReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service priovider id */
Reason reason               /* reason */
)
#else
PUBLIC S16 cmPkSdtDiscReq(pst, spId, reason)
Pst *pst;                   /* post structure */
SpId spId;                  /* service priovider id */
Reason reason;              /* reason */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtDiscReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT038, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, reason, mBuf, ESDT039, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT040, pst);
   pst->event = (Event) EVTSDTDISCREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtDiscReq */


  
/*
*
*       Fun:   portable - Data Link Flow Control Request
*
*       Desc:  This function tells the MTP Level 2 to apply or not
*              apply flow control on a MTP Data physical Link.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtFlcReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service priovider id */
Action action               /* action */
)
#else
PUBLIC S16 cmPkSdtFlcReq(pst, spId, action)
Pst *pst;                   /* post structure */
SpId spId;                  /* service priovider id */
Action action;              /* action */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtFlcReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT041, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, action, mBuf, ESDT042, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT043, pst);
   pst->event = (Event) EVTSDTFLCREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtFlcReq */

  
/*
*
*       Fun:   pack - Data Link Status Request
*
*       Desc:  This function requests the status of signalling point.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtStaReq
(
Pst *pst,                   /* post structure */
SpId spId,                  /* service priovider id */
Action action,              /* action */
SeqU24 status               /* status */
)
#else
PUBLIC S16 cmPkSdtStaReq(pst, spId, action, status)
Pst *pst;                   /* post structure */
SpId spId;                  /* service priovider id */
Action action;              /* action */
SeqU24 status;              /* status */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtStaReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT044, (ErrVal) ret1 ,"SGetMsg failed");
      RETVALUE(ret1 );
   }
   CMCHKPKLOG( SPkU32, status, mBuf, ESDT045, pst);
   CMCHKPKLOG( SPkS16, action, mBuf, ESDT046, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT047, pst);
   pst->event = (Event) EVTSDTSTAREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtStaReq */


  
/*
*
*       Fun:   pack - Data Link UnBind Request
*
*       Desc:  This function unbinds a MTP Level 3 Entity to the data link
*              Entity. 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmPkSdtUBndReq
(
Pst *pst,                   /* bind configuration */
SpId spId,                  /* service priovider id */
Reason reason               /* unbind reason */
)
#else
PUBLIC S16 cmPkSdtUBndReq(pst, spId, reason)
Pst *pst;                   /* bind configuration */
SpId spId;                  /* service priovider id */
Reason reason;              /* unbind reason */
#endif
{
   Buffer *mBuf;            /* message buffer */
   S16 ret1;                 /* return value */

   TRC3(cmPkSdtUBndReq)

   ret1 = SGetMsg(pst->region, pst->pool, &mBuf);
   if (ret1 != ROK)
   {
      SDTLOGERROR(ERRCLS_ADD_RES, ESDT048, (ErrVal) ret1,"SGetMsg failed");
      RETVALUE(ret1);
   }
   CMCHKPKLOG( SPkS16, reason, mBuf, ESDT049, pst);
   CMCHKPKLOG( SPkS16, spId, mBuf, ESDT050, pst);
   pst->event = (Event) EVTSDTUBNDREQ;      /* event */
   RETVALUE(SPstTsk(pst, mBuf));
} /* end of cmPkSdtUBndReq */
  
/* 
*
*       Fun:   cmUnpkSdtDatInd
*
*       Desc:  Unpack Data Link Data Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtDatInd
(
SdtDatInd func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtDatInd(func, pst, mBuf)
SdtDatInd func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */

   TRC3(cmUnpkSdtDatInd)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT051, pst);
   (Void) (*func)(pst, suId, mBuf);
   RETVALUE(ROK);
} /* end of cmUnpkSdtDatInd */


/*
*
*       Fun:   cmUnpkSdtConCfm
*
*       Desc:  Unpack Data Link Connect Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
 
#ifdef ANSI
PUBLIC S16 cmUnpkSdtConCfm
(
SdtConCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtConCfm(func, pst, mBuf)
SdtConCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */

   TRC3(cmUnpkSdtConCfm)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT052, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId);
   RETVALUE(ROK);
} /* end of cmUnpkSdtConCfm */


  
/*
*
*       Fun:   cmUnpkSdtDatCfm
*
*       Desc:  Unpack Data Link Data Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtDatCfm
(
SdtDatCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtDatCfm(func, pst, mBuf)
SdtDatCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   MtpStatus status;        /* status information */
   SeqU24 credit;           /* credit indication */

   TRC3(cmUnpkSdtDatCfm)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT053, pst);
   CMCHKUNPKLOG( SUnpkU8, &status, mBuf, ESDT054, pst);
   CMCHKUNPKLOG( SUnpkU32, &credit, mBuf, ESDT055, pst);
   (Void) (*func)(pst, suId, mBuf, status, credit);
   RETVALUE(ROK);
} /* end of cmUnpkSdtDatCfm */

  
/*
*
*       Fun:   cmUnpkSdtDiscInd
*
*       Desc:  Unpack Data Link Disconnect Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtDiscInd
(
SdtDiscInd func,            /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtDiscInd(func, pst, mBuf)
SdtDiscInd func;            /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   Reason reason;           /* reason */

   TRC3(cmUnpkSdtDiscInd)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT056, pst);
   CMCHKUNPKLOG( SUnpkS16, &reason, mBuf, ESDT057, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, reason);
   RETVALUE(ROK);
} /* end of cmUnpkSdtDiscInd */

#ifdef SDT2
  
/*
*
*       Fun:   cmUnpkSdtFlcInd
*
*       Desc:  Unpack Data Link Flow Control Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtFlcInd
(
SdtFlcInd func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtFlcInd(func, pst, mBuf)
SdtFlcInd func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   Action action;           /* action */

   TRC3(cmUnpkSdtFlcInd)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT058, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ESDT059, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, action);
   RETVALUE(ROK);
} /* end of cmUnpkSdtFlcInd */


/*
*
*       Fun:   cmUnpkSdtBndCfm
*
*       Desc:  Unpack Data Link Bind confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtBndCfm
(
SdtBndCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtBndCfm(func, pst, mBuf)
SdtBndCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   U8 status;               /* status */

   TRC3(cmUnpkSdtBndCfm)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT060, pst);
   CMCHKUNPKLOG( SUnpkU8, &status, mBuf, ESDT061, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, status);
   RETVALUE(ROK);
} /* end of cmUnpkSdtBndCfm */

#endif /* SDT2 */

  
/*
*
*       Fun:   cmUnpkSdtStaInd
*
*       Desc:  Unpack Status Indication
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtStaInd
(
SdtStaInd func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtStaInd(func, pst, mBuf)
SdtStaInd func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   MtpStatus status;        /* status information */

   TRC3(cmUnpkSdtStaInd)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT062, pst);
   CMCHKUNPKLOG( SUnpkU8, &status, mBuf, ESDT063, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, status);
   RETVALUE(ROK);
} /* end of cmUnpkSdtStaInd */

  
/*
*
*       Fun:   cmUnpkSdtStaCfm
*
*       Desc:  Unpack Staus Confirm
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  sdt.c
*
*/
  
#ifdef ANSI
PUBLIC S16 cmUnpkSdtStaCfm
(
SdtStaCfm func,             /* primitive pointer */
Pst *pst,                   /* post structure */
Buffer *mBuf                /* message buffer */
)
#else
PUBLIC S16 cmUnpkSdtStaCfm(func, pst, mBuf)
SdtStaCfm func;             /* primitive pointer */
Pst *pst;                   /* post structure */
Buffer *mBuf;               /* message buffer */
#endif
{
   SuId suId;               /* service user id */
   Action action;           /* action */
   SeqU24 status;           /* status information */

   TRC3(cmUnpkSdtStaCfm)
   CMCHKUNPKLOG( SUnpkS16, &suId, mBuf, ESDT064, pst);
   CMCHKUNPKLOG( SUnpkS16, &action, mBuf, ESDT065, pst);
   CMCHKUNPKLOG( SUnpkU32, &status, mBuf, ESDT066, pst);
   (Void) SPutMsg(mBuf);
   (Void) (*func)(pst, suId, action, status);
   RETVALUE(ROK);
} /* end of cmUnpkSdtStaCfm */
#endif /* LCSDT */

/********************************************************************30**
  
         End of file: sdt.c 1.1  -  08/25/98 18:01:54
  
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      sr   1. initial release
                           2. naming convention for common pack/unpack 
                              functions changed to comply with tco
                           3. BndCfm unpacking order changed to make it 
                              reverse of BndCfm packing.
                           4. loosely coupled flags LCSDUISDT and LCSNLISDT 
                              are replaced by LCSDT.
                           5. removed extra LCSDT flags.
*********************************************************************91*/
