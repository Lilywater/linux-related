/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**

     Name:     Common Packing/Unpacking functions for the primitives at
               the LIT Interface

     Type:     C source file

     Desc:     Packing/Unpacking functions shared by M3UA and the LM

     File:     lit.c

     Sid:      lit.c@@/main/7 - Thu Apr  1 03:50:12 2004

     Prg:      nj, mrw

*********************************************************************21*/

/*
*     This software may be combined with the following TRILLIUM
*     software:
*
*     part no.                      description
*     --------    ----------------------------------------------
*     1000192     M3UA
*
*/

/* header include files (.h) */

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "cm5.h"           /* Common timer */
#include "cm_hash.h"       /* common hash */
#include "cm_tpt.h"        /* common transport addressing */
#include "cm_ss7.h"        /* common ss7 */
#include "sct.h"           /* SCT Interface */
#include "lit.h"           /* LIT Interface */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"           /* Common Timer */
#include "cm_hash.x"       /* common hash */
#include "cm_tpt.x"        /* common transport addressing */
#include "cm_ss7.x"        /* common ss7 */
#include "sct.x"           /* SCT Interface */
#ifdef IT_FTHA             
#include "sht.x"           /* SHT Interface header file */
#endif /* IT_FTHA */
#include "lit.x"           /* LIT Interface */


/* private function declarations */

#ifdef LCLIT

PRIVATE S16 cmPkItGenCfg ARGS ((ItGenCfg  *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItNwkCfg ARGS ((ItNwkCfg  *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItNSapCfg ARGS((ItNSapCfg *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItRtFilter ARGS((ItRtFilter  *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItRteCfg ARGS((ItRteCfg   *pkParam, Buffer  *mBuf));
PRIVATE S16 cmPkItPsCfg ARGS((ItPsCfg *pkParam, Buffer  *mBuf));
/* it011.106 - Added Pst param in cmPkItAssocCfg and cmPkItPspCfg */
PRIVATE S16 cmPkItAssocCfg ARGS((Pst *pst, ItAssocCfg  *pkParam, Buffer  *mBuf));


PRIVATE S16 cmPkItPspCfg ARGS((Pst *pst, ItPspCfg *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItSctSapCfg ARGS((ItSctSapCfg *pkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItGenCfg ARGS((ItGenCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItNwkCfg ARGS((ItNwkCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItNSapCfg ARGS((ItNSapCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItRtFilter ARGS((ItRtFilter *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItRteCfg ARGS((ItRteCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItPsCfg ARGS((ItPsCfg *unpkParam, Buffer *mBuf));
/* it011.106 - Added Pst param in cmUnpkItAssocCfg and cmUnpkItPspCfg */
PRIVATE S16 cmUnpkItAssocCfg ARGS((Pst *pst, ItAssocCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItPspCfg ARGS((Pst *pst, ItPspCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItSctSapCfg ARGS((ItSctSapCfg *unpkParam, Buffer *mBuf));
PRIVATE S16 cmPkItGenSta ARGS((ItGenSta *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItNSapSta ARGS((ItNSapSta *pkParam, Buffer *mBuf));
/* lit_c_002.main_7 - Defined new packing functions for PS status in solicited
 * status confirm. */
#ifdef LITV4
PRIVATE S16 cmPkItSstaPs ARGS((Pst *pst, ItSstaPs *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItSstaPsEndp ARGS((ItSstaPsEndp *pkParam, Buffer *mBuf));
#else /* LITV4 */
PRIVATE S16 cmPkItPsSta ARGS((ItPsSta *pkParam, Buffer *mBuf));
#endif /* LITV4 */
PRIVATE S16 cmPkItPsStaEndp ARGS((ItPsStaEndp *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItAssocSta ARGS((ItAssocSta *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItPspSta ARGS((ItPspSta *pkParam, Buffer *mBuf));
/* lit_c_002.main_7 - Added Pst param in cmPkItSctSapSta. */
PRIVATE S16 cmPkItSctSapSta ARGS((Pst *pst, ItSctSapSta *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItAtSta ARGS((ItAtSta *pkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItGenSta ARGS((ItGenSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItNSapSta ARGS((ItNSapSta *unpkParam, Buffer *mBuf));
/* lit_c_002.main_7 - Defined new unpacking functions for PS status in solicited
 * status confirm. */
#ifdef LITV4
PRIVATE S16 cmUnpkItSstaPs ARGS((ItSstaPs *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItSstaPsEndp ARGS((ItSstaPsEndp *unpkParam, Buffer *mBuf));
#else /* LITV4 */
PRIVATE S16 cmUnpkItPsSta ARGS((ItPsSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItPsStaEndp ARGS((ItPsStaEndp *unpkParam, Buffer *mBuf));
#endif /* LITV4 */
PRIVATE S16 cmUnpkItAssocSta ARGS((ItAssocSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItPspSta ARGS((ItPspSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItSctSapSta ARGS((ItSctSapSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItAtSta ARGS((ItAtSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmPkItM3uaSts ARGS((ItM3uaSts *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItMtp3Sts ARGS((ItMtp3Sts *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItDataSts ARGS((ItDataSts *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItDataErrSts ARGS((ItDataErrSts *pkParam, Buffer *mBuf));
/* lit_c_001.main_7 - New packing functions for association unavailability 
 * and congestion statistics. */
#if (defined(LITV3) || defined(LITV6))
PRIVATE S16 cmPkItUnavSts ARGS((ItUnavSts *pkParam, Buffer *mBuf));
#endif /* LITV3 || LITV6 */
#ifdef LITV3
PRIVATE S16 cmPkItCongSts ARGS((ItCongSts *pkParam, Buffer *mBuf));
#endif /* LITV3 */
PRIVATE S16 cmPkItGenSts ARGS((ItGenSts *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItNSapSts ARGS((ItNSapSts *pkParam, Buffer *mBuf));
PRIVATE S16 cmPkItSctSapSts ARGS((ItSctSapSts *pkParam, Buffer *mBuf));
/* lit_c_001.main_7 - Added pst parameter in cmPkItPspSts. */
PRIVATE S16 cmPkItPspSts ARGS((Pst *pst, ItPspSts *pkParam, Buffer *mBuf));
/* lit_c_004.main_7 - Added functions for packing PS sts. */
#ifdef LITV6
PRIVATE S16 cmPkItPsSts ARGS((Pst *pst, ItPsSts *pkParam, Buffer *mBuf));
#endif /* LITV6 */
PRIVATE S16 cmUnpkItM3uaSts ARGS((ItM3uaSts *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItMtp3Sts ARGS((ItMtp3Sts *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItDataSts ARGS((ItDataSts *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItDataErrSts ARGS((ItDataErrSts *unpkParam, Buffer *mBuf));
/* lit_c_001.main_7 - New unpacking functions for association unavailability 
 * and congestion statistics. */
#if (defined(LITV3) || defined(LITV6))
PRIVATE S16 cmUnpkItUnavSts ARGS((ItUnavSts *unpkParam, Buffer *mBuf));
#endif /* LITV3 || LITV6 */
#ifdef LITV3
PRIVATE S16 cmUnpkItCongSts ARGS((ItCongSts *unpkParam, Buffer *mBuf));
#endif /* LITV3 */
PRIVATE S16 cmUnpkItGenSts ARGS((ItGenSts *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItNSapSts ARGS((ItNSapSts *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItSctSapSts ARGS((ItSctSapSts *unpkParam, Buffer *mBuf));
/* lit_c_001.main_7 - Added pst parameter in cmUnpkItPspSts. */
PRIVATE S16 cmUnpkItPspSts ARGS((Pst *pst, ItPspSts *unpkParam, Buffer *mBuf));
/* lit_c_004.main_7 - Added functions for unpacking PS sts. */
#ifdef LITV6
PRIVATE S16 cmUnpkItPsSts ARGS((Pst *pst, ItPsSts *unpkParam, Buffer *mBuf));
#endif /* LITV6 */
PRIVATE S16 cmUnpkItRouteKey ARGS((ItRoutKey *unpkParam, Buffer *mBuf));
PRIVATE S16 cmPkItRkSta ARGS((ItRkSta *pkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItRkSta ARGS((ItRkSta *unpkParam, Buffer *mBuf));
PRIVATE S16 cmUnpkItPspRkIdSta ARGS((ItPspRkIdSta *unpkParam, Buffer *mBuf));
#endif



#ifdef LCLIT


/*
 *     support functions
 */

/* ***********************************************

      Packing Functions for Configuration Request

   **************************************** */


/*
*
*       Fun:   cmPkItGenCfg
*
*       Desc:  This function packs the M3UA general configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItGenCfg
(
ItGenCfg                 *pkParam,     /* M3UA general configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItGenCfg (pkParam, mBuf)
ItGenCfg                 *pkParam;     /* M3UA general configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItGenCfg)

   CMCHKPK(cmPkPst, &pkParam->smPst, mBuf);
   CMCHKPK(SPkS16, pkParam->timeRes, mBuf);

   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrSeqCntrl, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrDunaSettle, mBuf);
   CMCHKPK(SPkU8, pkParam->tmr.maxNmbRkTry, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrDrkm, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrDaud, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrAspM, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrAspDn, mBuf);
   CMCHKPK(SPkU8, pkParam->tmr.nmbAspUp1, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrAspUp2, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrAspUp1, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrHeartbeat, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrAsPend, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrMtp3Sta, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmr.tmrRestart, mBuf);
   CMCHKPK(SPkU32, pkParam->congLevel3, mBuf);
   CMCHKPK(SPkU32, pkParam->congLevel2, mBuf);
   CMCHKPK(SPkU32, pkParam->congLevel1, mBuf);
   CMCHKPK(SPkU32, pkParam->qSize, mBuf);
   CMCHKPK(SPkU8, pkParam->drstSupp, mBuf); 
   CMCHKPK(SPkU8, pkParam->drkmSupp, mBuf);
   CMCHKPK(SPkU32, pkParam->maxNmbSls, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbSlsLs, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbRndRbnLs, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbMsg, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbPsp, mBuf);
   /* - New field added for Maximum number of Local PS to be
    * configured at ASP/IPSP, if OG_RTE_ON_LPS_STA is defined */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   CMCHKPK(SPkU16, pkParam->maxNmbLps, mBuf);
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   CMCHKPK(SPkU16, pkParam->maxNmbPs, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbDpcEnt, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbRtEnt, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbNwk, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbSctSap, mBuf);
   CMCHKPK(SPkU16, pkParam->maxNmbNSap, mBuf);
   CMCHKPK(SPkU8, pkParam->dpcLrnFlag, mBuf);
   CMCHKPK(SPkU8, pkParam->nodeType, mBuf);

   RETVALUE(ROK);
}   /* cmPkItGenCfg */


/*
*
*       Fun:   cmPkItNwkCfg
*
*       Desc:  This function packs the M3UA network configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItNwkCfg
(
ItNwkCfg                 *pkParam,     /* M3UA network configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItNwkCfg (pkParam, mBuf)
ItNwkCfg                 *pkParam;     /* M3UA network configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16         idx;  /* index */
   TRC2(cmPkItNwkCfg)

   CMCHKPK(cmPkSwtch, pkParam->su2Swtch, mBuf);
   CMCHKPK(cmPkSwtch, pkParam->suSwtch, mBuf);
   CMCHKPK(SPkU8, pkParam->slsLen, mBuf);
   CMCHKPK(SPkU8, pkParam->dpcLen, mBuf);
   CMCHKPK(SPkU8, pkParam->ssf, mBuf);
   for (idx = LIT_MAX_PSP; idx > 0; idx--)
   {
      CMCHKPK(cmPkItNwkApp, pkParam->nwkApp[idx - 1], mBuf);
   }
   CMCHKPK(SPkU8, pkParam->nwkId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItNwkCfg */


/*
*
*       Fun:   cmPkItNSapCfg
*
*       Desc:  This function packs the M3UA Network SAP configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItNSapCfg
(
ItNSapCfg                *pkParam,     /* M3UA Network SAP configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItNSapCfg (pkParam, mBuf)
ItNSapCfg                *pkParam;     /* M3UA Network SAP configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItNSapCfg)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, pkParam->remIntfVer, mBuf);
   CMCHKPK(SPkU8, pkParam->remIntfValid, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#ifdef ITSG
   CMCHKPK(cmPkSuId, pkParam->mtp3SapId, mBuf);
   CMCHKPK(cmPkInst, pkParam->inst, mBuf);
   CMCHKPK(cmPkEnt, pkParam->ent, mBuf);
   CMCHKPK(cmPkProcId, pkParam->procId, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmrPrim, mBuf);
#endif /* ITSG */
   CMCHKPK(cmPkRoute, pkParam->route, mBuf);
   CMCHKPK(cmPkPriority, pkParam->prior, mBuf);
   CMCHKPK(cmPkMemoryId, &pkParam->mem, mBuf);
   CMCHKPK(cmPkSelector, pkParam->selector, mBuf);
   CMCHKPK(SPkU8, pkParam->suType, mBuf);
   CMCHKPK(SPkU8, pkParam->nwkId, mBuf);
   CMCHKPK(cmPkSpId, pkParam->sapId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItNSapCfg */


/*
*
*       Fun:   cmPkItRtFilter
*
*       Desc:  This function packs the M3UA routing filter
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItRtFilter
(
ItRtFilter               *pkParam,     /* M3UA routing filter */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItRtFilter (pkParam, mBuf)
ItRtFilter               *pkParam;     /* M3UA routing filter */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItRtFilter)

   CMCHKPK(cmPkItTrid, pkParam->tridEnd, mBuf);
   CMCHKPK(cmPkItTrid, pkParam->tridStart, mBuf);
   CMCHKPK(cmPkBool, pkParam->includeTrid, mBuf);
   CMCHKPK(cmPkSsn, pkParam->ssn, mBuf);
   CMCHKPK(cmPkBool, pkParam->includeSsn, mBuf);
   CMCHKPK(cmPkCic, pkParam->cicEnd, mBuf);
   CMCHKPK(cmPkCic, pkParam->cicStart, mBuf);
   CMCHKPK(cmPkBool, pkParam->includeCic, mBuf);
   CMCHKPK(cmPkSrvInfo, pkParam->sio, mBuf);
   CMCHKPK(cmPkSrvInfo, pkParam->sioMask, mBuf);
   CMCHKPK(cmPkLnkSel, pkParam->sls, mBuf);
   CMCHKPK(cmPkLnkSel, pkParam->slsMask, mBuf);
   CMCHKPK(cmPkDpc, pkParam->opc, mBuf);
   CMCHKPK(cmPkDpc, pkParam->opcMask, mBuf);
   CMCHKPK(cmPkDpc, pkParam->dpc, mBuf);
   CMCHKPK(cmPkDpc, pkParam->dpcMask, mBuf);

   RETVALUE(ROK);
}   /* cmPkItRtFilter */


/*
*
*       Fun:   cmPkItRteCfg
*
*       Desc:  This function packs the Routing entry
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItRteCfg
(
ItRteCfg                 *pkParam,     /* Routing entry */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItRteCfg (pkParam, mBuf)
ItRteCfg                 *pkParam;     /* Routing entry */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItRteCfg)

   CMCHKPK(cmPkBool, pkParam->noStatus, mBuf);
   CMCHKPK(cmPkSpId, pkParam->nSapId, mBuf);
   CMCHKPK(cmPkBool, pkParam->nSapIdPres, mBuf);
   CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);
   CMCHKPK(cmPkItRtFilter, &pkParam->rtFilter, mBuf);
   CMCHKPK(SPkU8, pkParam->rtType, mBuf);
   CMCHKPK(SPkU8, pkParam->nwkId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItRteCfg */


/*
*
*       Fun:   cmPkItPsCfg
*
*       Desc:  This function packs the Peer Server configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPsCfg
(
ItPsCfg                  *pkParam,     /* Peer Server configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPsCfg (pkParam, mBuf)
ItPsCfg                  *pkParam;     /* Peer Server configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 idx;

   TRC2(cmPkItPsCfg)

   CMCHKPK(cmPkBool, pkParam->lclFlag, mBuf);
   for (idx = pkParam->nmbPsp; idx > 0; idx--)
   {
      if (idx < (LIT_MAX_PSP + 1))
      {
         CMCHKPK(cmPkItPspId, pkParam->psp[idx-1], mBuf);
      }
   }

   CMCHKPK(SPkU16, pkParam->nmbPsp, mBuf);
   CMCHKPK(SPkU16, pkParam->nmbActPspReqd, mBuf);
   CMCHKPK(cmPkBool, pkParam->reqAvail, mBuf);
   CMCHKPK(SPkU8, pkParam->loadShareMode, mBuf);
   CMCHKPK(SPkU32, pkParam->routCtx, mBuf);
   CMCHKPK(SPkU8, pkParam->mode, mBuf);
   CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);
   CMCHKPK(SPkU8, pkParam->nwkId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPsCfg */


/*
*
*       Fun:   cmPkItAssocCfg
*
*       Desc:  This function packs the SCTP association configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItAssocCfg
(
Pst                      *pst,         /* post structure */
ItAssocCfg               *pkParam,     /* SCTP association configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItAssocCfg (pst, pkParam, mBuf)
Pst                      *pst;         /* post structure */
ItAssocCfg               *pkParam;     /* SCTP association configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkItAssocCfg)

   /* it011.106 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* it016.106 - Added support for inteface version LITV3 */
   /* it011.106 - Changes for making the TOS support RUG compliant 
    * as follows -
    * LITIFVER 0x0100 - TOS parameter not packed.
    * LITIFVER 0x0200 and later - TOS parameter packed if SCT3 flag defined. Packed 
    * bit vector to indicate if SCT3 flag is defined. */
   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      {
         CMCHKPK(cmPkSctStrmId, pkParam->locOutStrms, mBuf);
         CMCHKPK(cmPkSctNetAddrLst, &pkParam->dstAddrLst, mBuf);
         CMCHKPK(SPkU16, pkParam->dstPort, mBuf);
         CMCHKPK(cmPkCmNetAddr, &pkParam->priDstAddr, mBuf);
         break;
      }

      case 0x0200:     /* interface version LITV2 */
      case 0x0300:     /* interface version LITV3 */
      case 0x0400:     /* interface version LITV4 */
      case 0x0500:     /* interface version LITV5 */
      case 0x0600:     /* interface version LITV6 */
      {
         /* it011.106 - If rolling upgrade support is enabled, set bit 
          * corresponding to compile flag SCT3, if this flag is enabled */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector[1];    /* bit vector */

         /* initialize bitVector */
         bitVector[0] = 0x0000;

#ifdef SCT3
         bitVector[0] |= LIT_SCT3_BIT;
#endif /* SCT3 */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         /* it009.106 - Added packing of type of service parameter */
#ifdef SCT3
         CMCHKPK(cmPkSctTos, pkParam->tos, mBuf);
#endif /* SCT3 */
         CMCHKPK(cmPkSctStrmId, pkParam->locOutStrms, mBuf);
         CMCHKPK(cmPkSctNetAddrLst, &pkParam->dstAddrLst, mBuf);
         CMCHKPK(SPkU16, pkParam->dstPort, mBuf);
         CMCHKPK(cmPkCmNetAddr, &pkParam->priDstAddr, mBuf);
      
         /* it011.106 - pack bitVector if rolling upgrade support is enabled */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPK(SPkU16, (U16) bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

  
   RETVALUE(ROK);
}   /* cmPkItAssocCfg */


/*
*
*       Fun:   cmPkItPspCfg
*
*       Desc:  This function packs the Peer Server Process configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPspCfg
(
Pst                      *pst,         /* Peer Server Process configuration */
ItPspCfg                 *pkParam,     /* Peer Server Process configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPspCfg (pst, pkParam, mBuf)
Pst                      *pst;         /* Peer Server Process configuration */
ItPspCfg                 *pkParam;     /* Peer Server Process configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItPspCfg)

#if (defined(ITASP) && defined(SGVIEW))
   CMCHKPK(SPkU32, pkParam->sgId, mBuf);
#endif /* ITASP && SGVIEW */
#ifdef ITASP
    CMCHKPK(cmPkBool, pkParam->cfgForAllLps, mBuf);
    CMCHKPK(cmPkBool, pkParam->autostartstatus, mBuf);  
#endif
   /* it011.106 - Changed the macro from CMCHKPK to pass version 
    * information in pst structure to cmPkItAssocCfg. */
   CMCHKPKVERLOG(cmPkItAssocCfg, &pkParam->assocCfg, mBuf, ELITXXX, pst);
   CMCHKPK(SPkU8, pkParam->nwkId, mBuf);
   CMCHKPK(SPkU32, pkParam->selfAspId, mBuf);
   CMCHKPK(cmPkBool, pkParam->rxTxAspId, mBuf);
   CMCHKPK(cmPkBool, pkParam->nwkAppIncl, mBuf);
   CMCHKPK(SPkU8, pkParam->dfltLshareMode, mBuf);
   CMCHKPK(cmPkBool, pkParam->dynRegRkallwd, mBuf);
   CMCHKPK(SPkU8, pkParam->ipspMode, mBuf);
   CMCHKPK(SPkU8, pkParam->pspType, mBuf);
   CMCHKPK(cmPkItPspId, pkParam->pspId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPspCfg */


/*
*
*       Fun:   cmPkItSctSapCfg
*
*       Desc:  This function packs the SCT SAP configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItSctSapCfg
(
ItSctSapCfg              *pkParam,     /* SCT SAP configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItSctSapCfg (pkParam, mBuf)
ItSctSapCfg              *pkParam;     /* SCT SAP configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItSctSapCfg)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, pkParam->remIntfVer, mBuf);
   CMCHKPK(SPkU8, pkParam->remIntfValid, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKPK(cmPkSpId, pkParam->spId, mBuf);
   CMCHKPK(cmPkRoute, pkParam->route, mBuf);
   CMCHKPK(cmPkPriority, pkParam->prior, mBuf);
   CMCHKPK(cmPkInst, pkParam->inst, mBuf);
   CMCHKPK(cmPkEnt, pkParam->ent, mBuf);
   CMCHKPK(cmPkProcId, pkParam->procId, mBuf);
   CMCHKPK(cmPkMemoryId, &pkParam->mem, mBuf);
   CMCHKPK(cmPkSelector, pkParam->selector, mBuf);
   CMCHKPK(cmPkSctNetAddrLst, &pkParam->srcAddrLst, mBuf);
   CMCHKPK(SPkU16, pkParam->srcPort, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmrSta, mBuf);
   CMCHKPK(cmPkTmrCfg, &pkParam->tmrPrim, mBuf);
   CMCHKPK(cmPkSuId, pkParam->suId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItSctSapCfg */


/*
*
*       Fun:   cmPkLitCfgReq
*
*       Desc:  This function packs the Configuration Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitCfgReq
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *cfg          /* Configuration */
)
#else
PUBLIC S16 cmPkLitCfgReq (pst, cfg)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *cfg;         /* Configuration */
#endif
{
   Buffer       *mBuf;

   TRC2(cmPkLitCfgReq)

   LIT_GETMSG(pst, mBuf, ELIT001);

   switch (cfg->hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKPKLOG(cmPkItGenCfg, &(cfg->t.cfg.s.genCfg), mBuf, ELIT002, pst);
         break;

      case STITNWK:
         CMCHKPKLOG(cmPkItNwkCfg, &(cfg->t.cfg.s.nwkCfg), mBuf, ELIT003, pst);
         break;

      case STITNSAP:
         CMCHKPKLOG(cmPkItNSapCfg, &(cfg->t.cfg.s.nSapCfg), mBuf, ELIT004, pst);
         break;

      case STITROUT:
         CMCHKPKLOG(cmPkItRteCfg, &(cfg->t.cfg.s.rteCfg), mBuf, ELIT005, pst);
         break;

      case STITPS:
         CMCHKPKLOG(cmPkItPsCfg, &(cfg->t.cfg.s.psCfg), mBuf, ELIT006, pst);
         break;

      case STITPSP:
         /* it011.106 - Changed the macro to CMCHKPKVERLOG to pass pst 
          * structure for version information in cmPkItPspCfg. */
         CMCHKPKVERLOG(cmPkItPspCfg, &(cfg->t.cfg.s.pspCfg), mBuf, ELIT007, pst);
         break;
      
      case STITSCTSAP:
         CMCHKPKLOG(cmPkItSctSapCfg, &(cfg->t.cfg.s.sctSapCfg), mBuf, ELIT008, pst);
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT009, "cmPkLitCfgReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkHeader, &(cfg->hdr), mBuf, ELIT010, pst);

   pst->event = (Event)EVTLITCFGREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitCfgReq */


/*
*
*       Fun:   cmPkItRouteKey
*
*       Desc:  This function packs the M3UA routing Key
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItRouteKey
(
ItRoutKey               *pkParam,     /* M3UA routing Key */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItRouteKey (pkParam, mBuf)
ItRoutKey               *pkParam;     /* M3UA routing Key */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16         idx;  /* index */
   TRC2(cmPkItRouteKey)

   for (idx = LIT_MAX_CIC_IN_DRKM; idx > 0; idx--)
   {
      CMCHKPK(cmPkCic, pkParam->cicRange[idx - 1].cicEnd, mBuf);
      CMCHKPK(cmPkCic, pkParam->cicRange[idx - 1].cicStart, mBuf);
      CMCHKPK(cmPkDpc, pkParam->cicRange[idx - 1].opc, mBuf);
   }
   CMCHKPK(SPkU8, pkParam->nmbCic, mBuf);

   for (idx = LIT_MAX_SIO_IN_DRKM; idx > 0; idx--)
   {
      CMCHKPK(cmPkSsn, pkParam->sio[idx - 1], mBuf);
   }
   CMCHKPK(SPkU8, pkParam->nmbSio, mBuf);
   for (idx = LIT_MAX_OPC_IN_DRKM; idx > 0; idx--)
   {
      CMCHKPK(cmPkDpc, pkParam->opc[idx - 1], mBuf);
   }
   CMCHKPK(SPkU8, pkParam->nmbOpc, mBuf);
   CMCHKPK(cmPkDpc, pkParam->dpc, mBuf);

   RETVALUE(ROK);
}   /* cmPkItRouteKey */

/* ***********************************************

      Unpacking Functions for Configuration Request

   **************************************** */


/*
*
*       Fun:   cmUnpkItGenCfg
*
*       Desc:  This function unpacks the M3UA general configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItGenCfg
(
ItGenCfg                 *unpkParam,   /* M3UA general configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItGenCfg (unpkParam, mBuf)
ItGenCfg                 *unpkParam;   /* M3UA general configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItGenCfg)

   CMCHKUNPK(SUnpkU8, &unpkParam->nodeType, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->dpcLrnFlag, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbNSap, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbSctSap, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbNwk, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbRtEnt, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbDpcEnt, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbPs, mBuf);
   /* New field added for Maximum number of Local PS to be
    * configured at ASP/IPSP if OG_RTE_ON_LPS_STA is defined */
#if (defined(ITASP) && defined(OG_RTE_ON_LPS_STA))
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbLps, mBuf);
#endif /* ITASP && OG_RTE_ON_LPS_STA */
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbPsp, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbMsg, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbRndRbnLs, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->maxNmbSlsLs, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->maxNmbSls, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->drkmSupp, mBuf); 
   CMCHKUNPK(SUnpkU8, &unpkParam->drstSupp, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->qSize, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->congLevel1, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->congLevel2, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->congLevel3, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrRestart, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrMtp3Sta, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrAsPend, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrHeartbeat, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrAspUp1, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrAspUp2, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->tmr.nmbAspUp1, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrAspDn, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrAspM, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrDaud, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrDrkm, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->tmr.maxNmbRkTry, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrDunaSettle, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmr.tmrSeqCntrl, mBuf);
   CMCHKUNPK(SUnpkS16, &unpkParam->timeRes, mBuf);
   CMCHKUNPK(cmUnpkPst, &unpkParam->smPst, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItGenCfg */


/*
*
*       Fun:   cmUnpkItNwkCfg
*
*       Desc:  This function unpacks the M3UA network configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItNwkCfg
(
ItNwkCfg                 *unpkParam,   /* M3UA network configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItNwkCfg (unpkParam, mBuf)
ItNwkCfg                 *unpkParam;   /* M3UA network configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16         idx;  /* index */
   TRC2(cmUnpkItNwkCfg)

   CMCHKUNPK(SUnpkU8, &unpkParam->nwkId, mBuf);
   for (idx = 0; idx < LIT_MAX_PSP; idx++)
   {
      CMCHKUNPK(cmUnpkItNwkApp, &unpkParam->nwkApp[idx], mBuf);
   }
   CMCHKUNPK(SUnpkU8, &unpkParam->ssf, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->dpcLen, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->slsLen, mBuf);
   CMCHKUNPK(cmUnpkSwtch, &unpkParam->suSwtch, mBuf);
   CMCHKUNPK(cmUnpkSwtch, &unpkParam->su2Swtch, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItNwkCfg */


/*
*
*       Fun:   cmUnpkItNSapCfg
*
*       Desc:  This function unpacks the M3UA Network SAP configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItNSapCfg
(
ItNSapCfg                *unpkParam,   /* M3UA Network SAP configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItNSapCfg (unpkParam, mBuf)
ItNSapCfg                *unpkParam;   /* M3UA Network SAP configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItNSapCfg)

   CMCHKUNPK(cmUnpkSpId, &unpkParam->sapId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->nwkId, mBuf);

   CMCHKUNPK(SUnpkU8, &unpkParam->suType, mBuf);
   CMCHKUNPK(cmUnpkSelector, &unpkParam->selector, mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &unpkParam->mem, mBuf);
   CMCHKUNPK(cmUnpkPriority, &unpkParam->prior, mBuf);
   CMCHKUNPK(cmUnpkRoute, &unpkParam->route, mBuf);

#ifdef ITSG
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmrPrim, mBuf);
   CMCHKUNPK(cmUnpkProcId, &unpkParam->procId, mBuf);
   CMCHKUNPK(cmUnpkEnt, &unpkParam->ent, mBuf);
   CMCHKUNPK(cmUnpkInst, &unpkParam->inst, mBuf);
   CMCHKUNPK(cmUnpkSuId, &unpkParam->mtp3SapId, mBuf);
#endif /* ITSG */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8, &unpkParam->remIntfValid, mBuf);
   CMCHKUNPK(cmUnpkIntfVer, &unpkParam->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}   /* cmUnpkItNSapCfg */


/*
*
*       Fun:   cmUnpkItRtFilter
*
*       Desc:  This function unpacks the M3UA routing filter
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItRtFilter
(
ItRtFilter               *unpkParam,   /* M3UA routing filter */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItRtFilter (unpkParam, mBuf)
ItRtFilter               *unpkParam;   /* M3UA routing filter */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItRtFilter)

   CMCHKUNPK(cmUnpkDpc, &unpkParam->dpcMask, mBuf);
   CMCHKUNPK(cmUnpkDpc, &unpkParam->dpc, mBuf);
   CMCHKUNPK(cmUnpkDpc, &unpkParam->opcMask, mBuf);
   CMCHKUNPK(cmUnpkDpc, &unpkParam->opc, mBuf);
   CMCHKUNPK(cmUnpkLnkSel, &unpkParam->slsMask, mBuf);
   CMCHKUNPK(cmUnpkLnkSel, &unpkParam->sls, mBuf);
   CMCHKUNPK(cmUnpkSrvInfo, &unpkParam->sioMask, mBuf);
   CMCHKUNPK(cmUnpkSrvInfo, &unpkParam->sio, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->includeCic, mBuf);
   CMCHKUNPK(cmUnpkCic, &unpkParam->cicStart, mBuf);
   CMCHKUNPK(cmUnpkCic, &unpkParam->cicEnd, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->includeSsn, mBuf);
   CMCHKUNPK(cmUnpkSsn, &unpkParam->ssn, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->includeTrid, mBuf);
   CMCHKUNPK(cmUnpkItTrid, &unpkParam->tridStart, mBuf);
   CMCHKUNPK(cmUnpkItTrid, &unpkParam->tridEnd, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItRtFilter */

/*
*
*       Fun:   cmUnpkItRteCfg
*
*       Desc:  This function unpacks the Routing entry
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItRteCfg
(
ItRteCfg                 *unpkParam,   /* Routing entry */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItRteCfg (unpkParam, mBuf)
ItRteCfg                 *unpkParam;   /* Routing entry */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItRteCfg)

   CMCHKUNPK(SUnpkU8, &unpkParam->nwkId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->rtType, mBuf);
   CMCHKUNPK(cmUnpkItRtFilter, &unpkParam->rtFilter, mBuf);
   CMCHKUNPK(cmUnpkItPsId, &unpkParam->psId, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->nSapIdPres, mBuf);
   CMCHKUNPK(cmUnpkSpId, &unpkParam->nSapId, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->noStatus, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItRteCfg */


/*
*
*       Fun:   cmUnpkItPsCfg
*
*       Desc:  This function unpacks the Peer Server configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPsCfg
(
ItPsCfg                  *unpkParam,   /* Peer Server configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPsCfg (unpkParam, mBuf)
ItPsCfg                  *unpkParam;   /* Peer Server configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16 idx;

   TRC2(cmUnpkItPsCfg)

   CMCHKUNPK(SUnpkU8, &unpkParam->nwkId, mBuf);
   CMCHKUNPK(cmUnpkItPsId, &unpkParam->psId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->mode, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->routCtx, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->loadShareMode, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->reqAvail, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbActPspReqd, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbPsp, mBuf);

   for (idx = 0; idx < unpkParam->nmbPsp; idx++)
   {
      if (idx < LIT_MAX_PSP)
      {
         CMCHKUNPK(cmUnpkItPspId, &unpkParam->psp[idx], mBuf);
      }
   }
   CMCHKUNPK(cmUnpkBool, &unpkParam->lclFlag, mBuf);
   RETVALUE(ROK);
}   /* cmUnpkItPsCfg */


/*
*
*       Fun:   cmUnpkItAssocCfg
*
*       Desc:  This function unpacks the SCTP association configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItAssocCfg
(
Pst                      *pst,         /* post structure */
ItAssocCfg               *unpkParam,   /* SCTP association configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItAssocCfg (pst, unpkParam, mBuf)
Pst                      *pst;         /* post structure */
ItAssocCfg               *unpkParam;   /* SCTP association configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkItAssocCfg)

   /* it011.106 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* it016.106 - Added support for inteface version LITV3 */
   /* it011.106 - Changes for making the TOS support RUG compliant 
    * as follows -
    * LITIFVER 0x0100 - TOS parameter not unpacked. If SCT3 flag defined use 
    * default TOS value.
    * LITIFVER 0x0200 and later - Unpacked bit vector to indicate if SCT3 flag is 
    * defined. TOS parameter unpacked if SCT3 flag defined. */
   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      {
         CMCHKUNPK(cmUnpkCmNetAddr, &unpkParam->priDstAddr, mBuf);
         CMCHKUNPK(SUnpkU16, &unpkParam->dstPort, mBuf);
         CMCHKUNPK(cmUnpkSctNetAddrLst, &unpkParam->dstAddrLst, mBuf);
         CMCHKUNPK(cmUnpkSctStrmId, &unpkParam->locOutStrms, mBuf);
#ifdef SCT3
         unpkParam->tos = LITIF_VER2_CFGREQ_DEF_TOS_VAL;
#endif /* SCT3 */
         break;
      } /* case 0x0100 */

      case 0x0200:     /* interface version LITV2 */
      case 0x0300:     /* interface version LITV3 */
      case 0x0400:     /* interface version LITV4 */
      case 0x0500:     /* interface version LITV5 */
      case 0x0600:     /* interface version LITV6 */
      {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         U16 bitVector[1];           /* bit vector */
#ifndef SCT3
         U8 tempTos;            /* temporary var to unpack tos */
#endif /* SCT3 */

         /* if rolling upgrade support enabled, unpack bitVector */
         CMCHKUNPK(SUnpkU16, &bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         CMCHKUNPK(cmUnpkCmNetAddr, &unpkParam->priDstAddr, mBuf);
         CMCHKUNPK(SUnpkU16, &unpkParam->dstPort, mBuf);
         CMCHKUNPK(cmUnpkSctNetAddrLst, &unpkParam->dstAddrLst, mBuf);
         CMCHKUNPK(cmUnpkSctStrmId, &unpkParam->locOutStrms, mBuf);
         /* unpcak TOS if SCT3 flag is enabled and:
          *   1. rolling upgrade support enabled and bitVector indicates
          *      that the compile flag is enabled at originating side and
          *      hence field TOS was packed.
          *   2. no rolling upgrade support is enabled. In this case
          *      unpacking of field is solely based on SCT3 compile flag. */
#ifdef SCT3
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         if (bitVector[0] & LIT_SCT3_BIT)
         {
            CMCHKUNPK(cmUnpkSctTos, &unpkParam->tos, mBuf);
         }
         else
         {
            unpkParam->tos = LITIF_VER2_CFGREQ_DEF_TOS_VAL;
         }
#else
         CMCHKUNPK(cmUnpkSctTos, &unpkParam->tos, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* SCT3 */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
            /* compile flag SCT3 is not enabled at our side, unpack and 
             * ignore field if bitVector indicates its packed. */
         if (bitVector[0] & LIT_SCT3_BIT)
         {
            CMCHKUNPK(SUnpkU8, &tempTos, mBuf);
         }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* SCT3 */
         break;
      } /* case 0x0200, 0x0300 */

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
}   /* cmUnpkItAssocCfg */


/*
*
*       Fun:   cmUnpkItPspCfg
*
*       Desc:  This function unpacks the Peer Server Process configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPspCfg
(
Pst                      *pst,         /* post structure */
ItPspCfg                 *unpkParam,   /* Peer Server Process configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPspCfg (pst, unpkParam, mBuf)
Pst                      *pst;         /* post structure */
ItPspCfg                 *unpkParam;   /* Peer Server Process configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItPspCfg)

   CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->pspType, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->ipspMode, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->dynRegRkallwd, mBuf); 
   CMCHKUNPK(SUnpkU8, &unpkParam->dfltLshareMode, mBuf); 
   CMCHKUNPK(cmUnpkBool, &unpkParam->nwkAppIncl, mBuf);
   CMCHKUNPK(cmUnpkBool, &unpkParam->rxTxAspId, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->selfAspId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->nwkId, mBuf);
   /* it011.106 - Changed the macro from CMCHKUNPK to pass version 
    * information in pst structure to cmUnpkItAssocCfg. */
   CMCHKUNPKVERLOG(cmUnpkItAssocCfg, &unpkParam->assocCfg, mBuf, ELITXXX, pst);
#ifdef ITASP
    CMCHKUNPK(cmUnpkBool, &unpkParam->autostartstatus, mBuf);
    CMCHKUNPK(cmUnpkBool, &unpkParam->cfgForAllLps, mBuf);
#endif
#if (defined(ITASP) && defined(SGVIEW))
   CMCHKUNPK(SUnpkU32, &unpkParam->sgId, mBuf);
#endif /* ITASP && SGVIEW */
   
   RETVALUE(ROK);
}   /* cmUnpkItPspCfg */


/*
*
*       Fun:   cmUnpkItSctSapCfg
*
*       Desc:  This function unpacks the SCT SAP configuration
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItSctSapCfg
(
ItSctSapCfg              *unpkParam,     /* SCT SAP configuration */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItSctSapCfg (unpkParam, mBuf)
ItSctSapCfg              *unpkParam;     /* SCT SAP configuration */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItSctSapCfg)

   CMCHKUNPK(cmUnpkSuId, &unpkParam->suId, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmrPrim, mBuf);
   CMCHKUNPK(cmUnpkTmrCfg, &unpkParam->tmrSta, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->srcPort, mBuf);
   CMCHKUNPK(cmUnpkSctNetAddrLst, &unpkParam->srcAddrLst, mBuf);
   CMCHKUNPK(cmUnpkSelector, &unpkParam->selector, mBuf);
   CMCHKUNPK(cmUnpkMemoryId, &unpkParam->mem, mBuf);
   CMCHKUNPK(cmUnpkProcId, &unpkParam->procId, mBuf);
   CMCHKUNPK(cmUnpkEnt, &unpkParam->ent, mBuf);
   CMCHKUNPK(cmUnpkInst, &unpkParam->inst, mBuf);
   CMCHKUNPK(cmUnpkPriority, &unpkParam->prior, mBuf);
   CMCHKUNPK(cmUnpkRoute, &unpkParam->route, mBuf);
   CMCHKUNPK(cmUnpkSpId, &unpkParam->spId, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK(SUnpkU8, &unpkParam->remIntfValid, mBuf);
   CMCHKUNPK(cmUnpkIntfVer, &unpkParam->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}   /* cmUnpkItSctSapCfg */


/*
*
*       Fun:   cmUnpkLitCfgReq
*
*       Desc:  This function unpacks the Configuration Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitCfgReq
(
LitCfgReq                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitCfgReq (func, pst, mBuf)
LitCfgReq                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      cfg;          /* M3UA Managment Structure */

   TRC2(cmUnpkLitCfgReq)

   CMCHKUNPKLOG(cmUnpkHeader, &cfg.hdr, mBuf, ELIT011, pst);

   switch (cfg.hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKUNPKLOG(cmUnpkItGenCfg, &cfg.t.cfg.s.genCfg, mBuf, ELIT012, pst);
         break;

      case STITNWK:
         CMCHKUNPKLOG(cmUnpkItNwkCfg, &cfg.t.cfg.s.nwkCfg, mBuf, ELIT013, pst);
         break;

      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkItNSapCfg, &cfg.t.cfg.s.nSapCfg, mBuf, ELIT014, pst);
         break;

      case STITROUT:
         CMCHKUNPKLOG(cmUnpkItRteCfg, &cfg.t.cfg.s.rteCfg, mBuf, ELIT015, pst);
         break;

      case STITPS:
         CMCHKUNPKLOG(cmUnpkItPsCfg, &cfg.t.cfg.s.psCfg, mBuf, ELIT016, pst);
         break;

      case STITPSP:
         /* it011.106 - Changed the macro to CMCHKUNPKVERLOG to pass pst structure for version information in cmUnpkItPspCfg */
         CMCHKUNPKVERLOG(cmUnpkItPspCfg, &cfg.t.cfg.s.pspCfg, mBuf, ELIT017, pst);
         
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkItSctSapCfg, &cfg.t.cfg.s.sctSapCfg, mBuf, ELIT018, pst);
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT019, "cmUnpkLitCfgReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cfg));
}   /* cmUnpkLitCfgReq */


/* ***********************************************

      Packing Functions for Control Request

   **************************************** */


/*
*
*       Fun:   cmPkLitCntrlReq
*
*       Desc:  This function packs the Control Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitCntrlReq
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *cntrl        /* Control */
)
#else
PUBLIC S16 cmPkLitCntrlReq (pst, cntrl)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *cntrl;       /* Control */
#endif
{
   Buffer       *mBuf;
   U16           idx;
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkLitCntrlReq)

   LIT_GETMSG(pst, mBuf, ELIT020);

   /* lit_c_003.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (cntrl->t.cntrl.action)
   {
      case AENA:
      case ADISIMM:
         switch (cntrl->t.cntrl.subAction)
         {
            case SATRC:
               CMCHKPKLOG(SPkU32, cntrl->t.cntrl.t.trc.trcMask, mBuf, ELIT021, 
                          pst);
               break;

#ifdef DEBUGP
            case SADBG:
               CMCHKPKLOG(SPkU32, cntrl->t.cntrl.t.dbg.dbgMask, mBuf, ELIT022, 
                          pst);
               break;
#endif /* DEBUGP */
         }
         break;

      case ABND:
         /* fall through */
      case AEOPENR:
         CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.s.suId, mBuf, ELIT023, pst);
         break;

      case AUBND:
         switch (cntrl->hdr.elmId.elmnt)
         {
            case STITSCTSAP:
               CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.s.suId, mBuf, ELIT024, pst);
               break;

            case STITNSAP:
               CMCHKPKLOG(cmPkSpId, cntrl->t.cntrl.s.spId, mBuf, ELIT025, pst);
               break;
         }
         break;

      case ATERMINATE:
#ifdef IT_ABORT_ASSOC
         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.aspm.abrtFlag, mBuf, ELIT026, pst);
#endif /* IT_ABORT_ASSOC */
         /* fall through */
      case AESTABLISH:
         /* fall through */
      case AINH:
         /* fall through */
      case AUNINH:
         CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.t.aspm.sctSuId, mBuf, ELIT027,
                    pst);
         CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf, ELIT028, pst);
         break;

      case AASPAC:
         /* fall through */
      case AASPIA:
         /* fall through */
      case AASPUP:
         /* fall through */
      case AASPDN:
         for (idx = (LIT_MAX_INFO + 1); idx > 0; idx--)
         {
            CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.aspm.info[idx-1], mBuf, ELIT029,
                       pst);
         }

         for (idx = cntrl->t.cntrl.t.aspm.nmbPs; idx > 0; idx--)
         {
            CMCHKPKLOG(cmPkItPsId, cntrl->t.cntrl.t.aspm.psLst[idx-1], mBuf, 
                       ELIT030, pst);
         }

         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.aspm.nmbPs, mBuf, ELIT031, pst);
         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.aspm.autoCtx, mBuf, ELIT032, pst);
         CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.t.aspm.sctSuId, mBuf, ELIT033,
                    pst);
         CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf, ELIT034, pst);
         break;

      case ASCON:
         CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.t.cong.sctSuId, mBuf, ELIT035,
                    pst);
         CMCHKPKLOG(cmPkDpc, cntrl->t.cntrl.t.cong.conPc, mBuf, ELIT036, pst);
         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.cong.congLevel, mBuf, ELIT037, 
                    pst);
         CMCHKPKLOG(cmPkDpc, cntrl->t.cntrl.t.cong.dpc, mBuf, ELIT038, pst);
         CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.cong.nwkId, mBuf, ELIT039, pst);
         CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf, ELIT040, pst);
         break;

      case ADEL:
         switch (cntrl->hdr.elmId.elmnt)
         {
            case STITSCTSAP:
               CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.s.suId, mBuf, ELIT041, pst);
               break;

            case STITNSAP:
               CMCHKPKLOG(cmPkSpId, cntrl->t.cntrl.s.spId, mBuf, ELIT042, pst);
               break;

            case STITROUT:
               switch (cntrl->t.cntrl.t.rtEnt.indexType)
               {
                  case LIT_RTINDEX_PSID:
                     CMCHKPKLOG(cmPkItPsId, cntrl->t.cntrl.t.rtEnt.u.psId, 
                                mBuf, ELIT043, pst);
                     break;

                  case LIT_RTINDEX_DPC:
                     CMCHKPKLOG(cmPkDpc, cntrl->t.cntrl.t.rtEnt.u.dpc, mBuf, 
                                ELIT044, pst);
                     break;
                  case LIT_RTINDEX_ROUTECFG:
                     CMCHKPKLOG(cmPkItRteCfg, &(cntrl->t.cntrl.t.rtEnt.u.rteCfg), 
                                mBuf, ELIT045, pst);
                     break;
               }

               if (cntrl->t.cntrl.t.rtEnt.indexType != LIT_RTINDEX_ROUTECFG)
               {
                  CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.rtEnt.nwkId, mBuf, 
                             ELIT046, pst);
               }

               CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.rtEnt.indexType, mBuf, 
                          ELIT047, pst);
               break;

            case STITNWK:
               CMCHKPKLOG(SPkU8, cntrl->t.cntrl.s.nwkId, mBuf, ELIT048, pst);
               break;

            case STITPS:
               CMCHKPKLOG(cmPkItPsId, cntrl->t.cntrl.s.psId, mBuf, ELIT049, 
                          pst);
               break;

            case STITPSP:
               /* lit_c_003.main_7 - Changes for packing abrtFlag if intfVer is 0x0500
                * and later. */
               switch (intfVer)
               {
                  case 0x0100:     /* interface version LITV1 */
                  case 0x0200:     /* interface version LITV2 */
                  case 0x0300:     /* interface version LITV3 */
                  case 0x0400:     /* interface version LITV4 */
                  {
                     CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf, ELIT050, 
                                pst);
                     break;
                  }
                  case 0x0500:     /* interface version LITV5 */
                  case 0x0600:     /* interface version LITV6 */
                  {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     U16 bitVector[1];    /* bit vector */
            
                     /* initialize bitVector */
                     bitVector[0] = 0x0000;
            
#if (defined(LITV5) && defined(IT_ABORT_ASSOC))
                     bitVector[0] |= LIT_ABORT_ASSOC_BIT;
#endif /* LITV5 && IT_ABORT_ASSOC */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

#if (defined(LITV5) && defined(IT_ABORT_ASSOC))
                     CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.aspm.abrtFlag, mBuf, ELITXXX, pst);
#endif /* LITV5 && IT_ABORT_ASSOC */
                     CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf, ELITXXX, 
                                pst);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     CMCHKPK(SPkU16, (U16) bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
                     break;
                  }
               }
               break;
         }
         break;

      case ARKREG:
         {
            switch (cntrl->t.cntrl.t.dynRteKey.reqType)
            {
               case LIT_REG_REQ:
               {
                  for (idx = cntrl->t.cntrl.t.dynRteKey.rkm.rK.nmbRk; idx > 0; 
                                  idx--)
                  {
                     CMCHKPKLOG(SPkU8, 
                     cntrl->t.cntrl.t.dynRteKey.rkm.rK.routKey[idx - 1].mode,
                                     mBuf, ELIT051, pst);
                     CMCHKPKLOG(cmPkItPsId, 
                     cntrl->t.cntrl.t.dynRteKey.rkm.rK.routKey[idx - 1].psId,
                                     mBuf, ELIT052, pst);
                     CMCHKPKLOG(cmPkItRouteKey,
                     &cntrl->t.cntrl.t.dynRteKey.rkm.rK.routKey[idx - 1].rtKey,
                                     mBuf, ELIT053, pst);
                  }
                  CMCHKPKLOG(SPkU16, cntrl->t.cntrl.t.dynRteKey.rkm.rK.nmbRk, 
                             mBuf, ELIT054, pst);
                  CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.t.dynRteKey.sctSuId, mBuf,
                             ELIT055, pst);
                  CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.dynRteKey.reqType, mBuf,
                             ELIT056, pst);
                  CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf,
                                  ELIT057, pst);
               }
               break;
#if (ERRCLASS & ERRCLS_DEBUG)
               default:
               LITLOGERROR(ERRCLS_DEBUG, ELIT058, "cmPkLitCntrlReq: Failed");
               SPutMsg(mBuf);
               RETVALUE(RFAILED);
#endif
            }
         }
         break;

      case ARKDEREG:
         {
            switch (cntrl->t.cntrl.t.dynRteKey.reqType)
            {
               case LIT_DEREG_REQ:
               {
                  for (idx = cntrl->t.cntrl.t.dynRteKey.rkm.rC.nmbRCtx; idx > 0; 
                                  idx--)
                  {
                     CMCHKPKLOG(cmPkItPsId, 
                     cntrl->t.cntrl.t.dynRteKey.rkm.rC.rteCtxLst[idx - 1].psId,
                                     mBuf, ELIT059, pst);
                  }
                  CMCHKPKLOG(SPkU16, cntrl->t.cntrl.t.dynRteKey.rkm.rC.nmbRCtx,
                                   mBuf, ELIT060, pst);
                  CMCHKPKLOG(cmPkSuId, cntrl->t.cntrl.t.dynRteKey.sctSuId, mBuf,
                             ELIT061, pst);
                  CMCHKPKLOG(SPkU8, cntrl->t.cntrl.t.dynRteKey.reqType, mBuf,
                             ELIT062, pst);
                  CMCHKPKLOG(cmPkItPspId, cntrl->t.cntrl.s.pspId, mBuf,
                                  ELIT063, pst);
               }
               break;
#if (ERRCLASS & ERRCLS_DEBUG)
               default:
               LITLOGERROR(ERRCLS_DEBUG, ELIT064, "cmPkLitCntrlReq: Failed");
               SPutMsg(mBuf);
               RETVALUE(RFAILED);
#endif
            }
         }
         break;

      case ASHUTDOWN:
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         LITLOGERROR(ERRCLS_DEBUG, ELIT065, "cmPkLitCntrlReq: Failed");
         SPutMsg(mBuf);
         RETVALUE(RFAILED);
#endif
   }

   if ((cntrl->hdr.elmId.elmnt == STITGRNSAP) ||
       (cntrl->hdr.elmId.elmnt == STITGRSCTSAP))
   {
      CMCHKPKLOG(SPkU32, cntrl->t.cntrl.t.grp.parSize, mBuf, ELIT066, pst);
   }

   CMCHKPKLOG(cmPkAction, cntrl->t.cntrl.subAction, mBuf, ELIT067, pst);
   CMCHKPKLOG(cmPkAction, cntrl->t.cntrl.action, mBuf, ELIT068, pst);
   CMCHKPKLOG(cmPkDateTime, &cntrl->t.cntrl.dt, mBuf, ELIT069, pst);
   CMCHKPKLOG(cmPkHeader, &cntrl->hdr, mBuf, ELIT070, pst);

   pst->event = (Event)EVTLITCNTRLREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitCntrlReq */


/*
*
*       Fun:   cmUnpkItRouteKey
*
*       Desc:  This function unpacks the M3UA routing filter
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItRouteKey
(
ItRoutKey               *unpkParam,   /* M3UA routing Key */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItRouteKey (unpkParam, mBuf)
ItRoutKey               *unpkParam;   /* M3UA routing Key */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16         idx;  /* index */
   TRC2(cmUnpkItRouteKey)

   CMCHKUNPK(cmUnpkDpc, &unpkParam->dpc, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->nmbOpc, mBuf);
   for (idx = 0; idx < LIT_MAX_OPC_IN_DRKM; idx++)
   {
      CMCHKUNPK(cmUnpkDpc, &unpkParam->opc[idx], mBuf);
   }
   CMCHKUNPK(SUnpkU8, &unpkParam->nmbSio, mBuf);
   for (idx = 0; idx < LIT_MAX_SIO_IN_DRKM; idx++)
   {
      CMCHKUNPK(cmUnpkSrvInfo, &unpkParam->sio[idx], mBuf);
   }
   CMCHKUNPK(SUnpkU8, &unpkParam->nmbCic, mBuf);
   for (idx = 0; idx < LIT_MAX_CIC_IN_DRKM; idx++)
   {
      CMCHKUNPK(cmUnpkDpc, &unpkParam->cicRange[idx].opc, mBuf);
      CMCHKUNPK(cmUnpkCic, &unpkParam->cicRange[idx].cicStart, mBuf);
      CMCHKUNPK(cmUnpkCic, &unpkParam->cicRange[idx].cicEnd, mBuf);
   }
   RETVALUE(ROK);
}   /* cmUnpkItRouteKey */


/* ***********************************************

      Unpacking Functions for Control Request

   **************************************** */


/*
*
*       Fun:   cmUnpkLitCntrlReq
*
*       Desc:  This function unpacks the Control Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitCntrlReq
(
LitCntrlReq               func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitCntrlReq (func, pst, mBuf)
LitCntrlReq               func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt        cntrl;       /* Control */
   U16           idx;
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkLitCntrlReq)

   /* lit_c_003.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkHeader, &cntrl.hdr, mBuf, ELIT071, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &cntrl.t.cntrl.dt, mBuf, ELIT072, pst);
   CMCHKUNPKLOG(cmUnpkAction, &cntrl.t.cntrl.action, mBuf, ELIT073, pst);
   CMCHKUNPKLOG(cmUnpkAction, &cntrl.t.cntrl.subAction, mBuf, ELIT074, pst);

   if ((cntrl.hdr.elmId.elmnt == STITGRNSAP) ||
       (cntrl.hdr.elmId.elmnt == STITGRSCTSAP))
   {
      CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.t.grp.parSize, mBuf, ELIT075, pst);
   }

   switch (cntrl.t.cntrl.action)
   {
      case AENA:
      case ADISIMM:
         switch (cntrl.t.cntrl.subAction)
         {
            case SATRC:
               CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.t.trc.trcMask, mBuf, 
                            ELIT076, pst);
               break;

#ifdef DEBUGP
            case SADBG:
               CMCHKUNPKLOG(SUnpkU32, &cntrl.t.cntrl.t.dbg.dbgMask, mBuf, 
                            ELIT077, pst);
               break;
#endif /* DEBUGP */
         }
         break;

      case ABND:
         /* fall through */
      case AEOPENR:
         CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.s.suId, mBuf, ELIT078, pst);
         break;

      case AUBND:
         switch (cntrl.hdr.elmId.elmnt)
         {
            case STITSCTSAP:
               CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.s.suId, mBuf, ELIT079, 
                            pst);
               break;

            case STITNSAP:
               CMCHKUNPKLOG(cmUnpkSpId, &cntrl.t.cntrl.s.spId, mBuf, ELIT080, 
                            pst);
               break;
         }
         break;

      case AESTABLISH:
         /* fall through */
      case AINH:
         /* fall through */
      case AUNINH:
         switch (cntrl.hdr.elmId.elmnt)
         {
            case STITPSP:
               CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, 
                            ELIT081, pst);
              CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.aspm.sctSuId, mBuf,
                            ELIT082, pst);
               break;
         }
         break;
      case ATERMINATE:
         switch (cntrl.hdr.elmId.elmnt)
         {
            case STITPSP:
               CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, 
                            ELIT083, pst);
              CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.aspm.sctSuId, mBuf,
                            ELIT084, pst);
#ifdef IT_ABORT_ASSOC
               CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.abrtFlag, mBuf,
                            ELIT085, pst);
#endif /* IT_ABORT_ASSOC */
               break;
         }
         break;

      case AASPAC:
         /* fall through */
      case AASPIA:
         /* fall through */
      case AASPUP:
         /* fall through */
      case AASPDN:
         CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELIT086, 
                      pst);
         CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.aspm.sctSuId, mBuf, ELIT087,
                      pst); 
         CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.autoCtx, mBuf, ELIT088, 
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.nmbPs, mBuf, ELIT089, 
                      pst);

         for (idx = 0; idx < cntrl.t.cntrl.t.aspm.nmbPs; idx++)
         {
            CMCHKUNPKLOG(cmUnpkItPsId, &cntrl.t.cntrl.t.aspm.psLst[idx], mBuf,
                         ELIT090, pst);
         }

         for (idx = 0; idx < (LIT_MAX_INFO + 1); idx++)
         {
            CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.info[idx], mBuf, 
                         ELIT091, pst);
         }
         break;

      case ASCON:
         CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELIT092, 
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.cong.nwkId, mBuf, ELIT093, 
                      pst);
         CMCHKUNPKLOG(cmUnpkDpc, &cntrl.t.cntrl.t.cong.dpc, mBuf, ELIT094, 
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.cong.congLevel, mBuf, ELIT095, 
                      pst);
         CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.cong.sctSuId, mBuf, ELIT096,
                      pst); 
         break;
      
      case ADEL:
         switch (cntrl.hdr.elmId.elmnt)
         {
            case STITSCTSAP:
               CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.s.suId, mBuf, ELIT097, pst);
               break;

            case STITNSAP:
               CMCHKUNPKLOG(cmUnpkSpId, &cntrl.t.cntrl.s.spId, mBuf, ELIT098, pst);
               break;

            case STITROUT:
               CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.rtEnt.indexType, mBuf, ELIT099, pst);

               /* - Unpack nwkId here only if 
                             indexType != LIT_RTINDEX_ROUTECFG */
               if (cntrl.t.cntrl.t.rtEnt.indexType != 
                   LIT_RTINDEX_ROUTECFG)
               {
                  CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.rtEnt.nwkId, 
                               mBuf, ELIT100, pst);
               }

               switch (cntrl.t.cntrl.t.rtEnt.indexType)
               {
                  case LIT_RTINDEX_PSID:
                     CMCHKUNPKLOG(cmUnpkItPsId, &cntrl.t.cntrl.t.rtEnt.u.psId, mBuf, ELIT101, pst);
                     break;

                  case LIT_RTINDEX_DPC:
                     CMCHKUNPKLOG(cmUnpkDpc, &cntrl.t.cntrl.t.rtEnt.u.dpc, mBuf, ELIT102, pst);
                     break;
                  case LIT_RTINDEX_ROUTECFG:
                     CMCHKUNPKLOG(cmUnpkItRteCfg, &cntrl.t.cntrl.t.rtEnt.u.rteCfg, 
                                  mBuf, ELIT103, pst);
                     break;
               }
               break;

            case STITNWK:
               CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.s.nwkId, mBuf, ELIT104, pst);
               break;

            case STITPS:
               CMCHKUNPKLOG(cmUnpkItPsId, &cntrl.t.cntrl.s.psId, mBuf, ELIT105, pst);
               break;

            case STITPSP:
               /* lit_c_003.main_7 - Changes for unpacking abrtFlag if intfVer is 0x0500
                * and later. */
               switch (intfVer)
               {
                  case 0x0100:     /* interface version LITV1 */
                  case 0x0200:     /* interface version LITV2 */
                  case 0x0300:     /* interface version LITV3 */
                  case 0x0400:     /* interface version LITV4 */
                  {
                     CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELIT106, pst);
                     break;
                  }
                  case 0x0500:     /* interface version LITV5 */
                  case 0x0600:     /* interface version LITV6 */
                  {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     U16 bitVector[1];           /* bit vector */
#if !(defined(LITV5) && defined(IT_ABORT_ASSOC))
                     U8 tempAbrtFlag;        /* temporary var to unpack abrtFlag */
#endif

                     /* if rolling upgrade support enabled, unpack bitVector */
                     CMCHKUNPK(SUnpkU16, &bitVector[0], mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

                     CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELITXXX, pst);

#if (defined(LITV5) && defined(IT_ABORT_ASSOC))
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     if (bitVector[0] & LIT_ABORT_ASSOC_BIT)
                     {
                           CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.abrtFlag, mBuf,
                                        ELITXXX, pst);
                     }
                     else
                     {
                        cntrl.t.cntrl.t.aspm.abrtFlag = LITIF_VER5_CNTRLREQ_DEF_ABRTFLAG_VAL;
                     }
#else
                     CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.aspm.abrtFlag, mBuf,
                                  ELITXXX, pst);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#else /* LITV5 && IT_ABORT_ASSOC */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     /* compile flag IT_ABORT_ASSOC is not enabled at our side, unpack and 
                      * ignore field if bitVector indicates its packed. */
                     if (bitVector[0] & LIT_ABORT_ASSOC_BIT)
                     {
                        CMCHKUNPK(SUnpkU8, &tempAbrtFlag, mBuf);
                     }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
#endif /* LITV5 && IT_ABORT_ASSOC */
                     break;
                  }
               }
               break;

         }
         break;

      case ASHUTDOWN:
         break;
      case ARKREG:
         {
            CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELIT107, 
                      pst);
            CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.dynRteKey.reqType, 
                      mBuf, ELIT108, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.dynRteKey.sctSuId, 
                      mBuf, ELIT109, pst); 
            CMCHKUNPKLOG(SUnpkU16, &cntrl.t.cntrl.t.dynRteKey.rkm.rK.nmbRk, 
                      mBuf, ELIT110, pst);
            for (idx = 0; idx < cntrl.t.cntrl.t.dynRteKey.rkm.rK.nmbRk; idx++)
            {
                CMCHKUNPKLOG(cmUnpkItRouteKey,
                    &cntrl.t.cntrl.t.dynRteKey.rkm.rK.routKey[idx].rtKey,
                                     mBuf, ELIT111, pst);
                CMCHKUNPKLOG(cmUnpkItPsId,
                    &cntrl.t.cntrl.t.dynRteKey.rkm.rK.routKey[idx].psId,
                                     mBuf, ELIT112, pst);
                CMCHKUNPKLOG(SUnpkU8,
                    &cntrl.t.cntrl.t.dynRteKey.rkm.rK.routKey[idx].mode,
                                     mBuf, ELIT113, pst);
            }
         }
         break;
      case ARKDEREG:
         {
            CMCHKUNPKLOG(cmUnpkItPspId, &cntrl.t.cntrl.s.pspId, mBuf, ELIT114, 
                      pst);
            CMCHKUNPKLOG(SUnpkU8, &cntrl.t.cntrl.t.dynRteKey.reqType, 
                      mBuf, ELIT115, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &cntrl.t.cntrl.t.dynRteKey.sctSuId, 
                      mBuf, ELIT116, pst); 
            CMCHKUNPKLOG(SUnpkU16,
                    &cntrl.t.cntrl.t.dynRteKey.rkm.rC.nmbRCtx,
                                     mBuf, ELIT117, pst);
                    for (idx = 0; idx < cntrl.t.cntrl.t.dynRteKey.rkm.rC.nmbRCtx; 
                          idx++)
                    {
                        CMCHKUNPKLOG(cmUnpkItPsId,
                            &cntrl.t.cntrl.t.dynRteKey.rkm.rC.rteCtxLst[idx].psId,
                                             mBuf, ELIT118, pst);
                    }
                 }
                 break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:

         LITLOGERROR(ERRCLS_DEBUG, ELIT119, "cmUnpkLitCntrlReq: Failed");
         (Void)SPutMsg(mBuf);
         RETVALUE(RFAILED);
#endif
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cntrl));
}   /* cmUnpkLitCntrlReq */


/* ***********************************************

      Packing Functions for Status Request

   **************************************** */


/*
*
*       Fun:   cmPkItGenSta
*
*       Desc:  This function packs the General status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItGenSta
(
ItGenSta                 *pkParam,     /* General status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItGenSta (pkParam, mBuf)
ItGenSta                 *pkParam;     /* General status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItGenSta)

   CMCHKPK(SPkU32, pkParam->memAlloc, mBuf);
   CMCHKPK(SPkU32, pkParam->memSize, mBuf);

   RETVALUE(ROK);
}   /* cmPkItGenSta */


/*
*
*       Fun:   cmPkItNSapSta
*
*       Desc:  This function packs the Upper SAP status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItNSapSta
(
ItNSapSta                *pkParam,     /* Upper SAP status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItNSapSta (pkParam, mBuf)
ItNSapSta                *pkParam;     /* Upper SAP status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItNSapSta)

   CMCHKPK(SPkU8, pkParam->hlSt, mBuf);
   CMCHKPK(cmPkSpId, pkParam->remSapId, mBuf);
   CMCHKPK(cmPkSpId, pkParam->lclSapId, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKPK(cmPkIntfVer, pkParam->selfIntfVer, mBuf);
   CMCHKPK(SPkU8, pkParam->remIntfValid, mBuf);
   CMCHKPK(cmPkIntfVer, pkParam->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   RETVALUE(ROK);
}   /* cmPkItNSapSta */

#ifndef LITV4

/*
*
*       Fun:   cmPkItPsSta
*
*       Desc:  This function packs the Peer Server status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPsSta
(
ItPsSta                  *pkParam,     /* Peer Server status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPsSta (pkParam, mBuf)
ItPsSta                  *pkParam;     /* Peer Server status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16        idx;

   TRC2(cmPkItPsSta)

   for (idx = LIT_MAX_SEP; idx > 0; idx--)
   {
      CMCHKPK(cmPkItPsStaEndp, &pkParam->psStaEndp[idx-1], mBuf);
   }
   CMCHKPK(SPkU8, pkParam->asSt, mBuf);
   CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPsSta */
#endif /* ifndef LITV4 */


/*
*
*       Fun:   cmPkItPsStaEndp
*
*       Desc:  This function packs the Peer Server status per Endp.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPsStaEndp
(
ItPsStaEndp              *pkParam,     /* Peer Server per Endp status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPsStaEndp (pkParam, mBuf)
ItPsStaEndp              *pkParam;     /* Peer Server per Endp status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16        idx;

   TRC2(cmPkItPsStaEndp)

   for (idx = LIT_MAX_PSP; idx > 0; idx--)
   {
      CMCHKPK(SPkU8, pkParam->rteCtx[idx-1].mode, mBuf);
      CMCHKPK(SPkU8, pkParam->rteCtx[idx-1].rcValid, mBuf);
      CMCHKPK(SPkU32, pkParam->rteCtx[idx-1].rCtx, mBuf);
   }
   CMCHKPK(SPkU16, pkParam->nmbPspReg, mBuf);
   for (idx = pkParam->nmbAct; idx > 0; idx--)
   {
      CMCHKPK(cmPkItPspId, pkParam->actPsp[idx-1], mBuf);
   }
   CMCHKPK(SPkU16, pkParam->nmbAct, mBuf);

   for (idx = LIT_MAX_PSP; idx > 0; idx--)
   {
      CMCHKPK(SPkU8, pkParam->aspSt[idx-1], mBuf);
   }

   RETVALUE(ROK);
}   /* cmPkItPsStaEndp */

/* lit_c_002.main_7 - Changes for interface version LITV4 to pack
 * ItSstaPs structure. */
#ifdef LITV4

/*
*
*       Fun:   cmPkItSstaPs
*
*       Desc:  This function packs the Peer Server status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItSstaPs
(
Pst                      *pst,         /* post structure */
ItSstaPs                 *pkParam,     /* Peer Server status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItSstaPs (pst, pkParam, mBuf)
Pst                      *pst;         /* post structure */
ItSstaPs                 *pkParam;     /* Peer Server status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16        idx;
   CmIntfVer  intfVer;      /* interface version number */

   TRC2(cmPkItSstaPs)

   /* lit_c_002.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* lit_c_002.main_7 - Changes for new interface version LITV4 to pack
    * structure ItSstaPs in PS status confirm.
    * LITIFVER 0x0100, 0x0200, 0x0300 - Structure ItPsSta packed. 
    * Data for ItPsSta is derived from pkParam.
    * LITIFVER 0x0400 and later - Structure ItSstaPs packed if LITV4 defined.*/

   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      case 0x0200:     /* interface version LITV2 */
      case 0x0300:     /* interface version LITV3 */
      {
         /* lit_c_002.main_7 - Translation from PS status in ItSstaPs 
          * structure format to ItPsSta structure format. */

         ItPsStaEndp  psStaEndp;
         U16          idx1;
         ItPspId      pspId;

         for (idx = LIT_MAX_SEP; idx > 0; idx--)
         {
            for (idx1 = 0; idx1 > LIT_MAX_PSP; idx1++)
            {
               psStaEndp.aspSt[idx1] = LIT_ASP_UNSUPP;
               psStaEndp.rteCtx[idx1].rcValid = FALSE;
            }
            psStaEndp.nmbAct = pkParam->sstaPsEndp[idx].nmbAct;
            psStaEndp.nmbPspReg = pkParam->sstaPsEndp[idx].nmbPspReg;

            for (idx1 = 0; idx1 > psStaEndp.nmbAct; idx1++)
            {
               psStaEndp.actPsp[idx1] = pkParam->sstaPsEndp[idx].actPsp[idx1];
            }

            for (idx1 = 0; idx1 > pkParam->sstaPsEndp[idx].nmbPsp; idx1++)
            {
               pspId = pkParam->sstaPsEndp[idx].pspSt[idx1].pspId; 
               psStaEndp.aspSt[pspId] = pkParam->sstaPsEndp[idx].pspSt[idx1].aspSt;
               psStaEndp.rteCtx[pspId].rCtx    = pkParam->sstaPsEndp[idx].pspSt[idx1].rCtx;
               psStaEndp.rteCtx[pspId].rcValid = pkParam->sstaPsEndp[idx].pspSt[idx1].rcValid;
               psStaEndp.rteCtx[pspId].mode    = pkParam->sstaPsEndp[idx].pspSt[idx1].mode;
            }
            CMCHKPK(cmPkItPsStaEndp, &psStaEndp, mBuf);
         } /* for LIT_MAX_SEP */

         CMCHKPK(SPkU8, pkParam->asSt, mBuf);
         CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);
         break;
      }

      case 0x0400:     /* interface version LITV4 */
      case 0x0500:     /* interface version LITV5 */
      case 0x0600:     /* interface version LITV6 */
      {
         for (idx = LIT_MAX_SEP; idx > 0; idx--)
         {
            CMCHKPK(cmPkItSstaPsEndp, &pkParam->sstaPsEndp[idx-1], mBuf);
         }
         CMCHKPK(SPkU8, pkParam->asSt, mBuf);
         CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
}   /* cmPkItSstaPs */
#endif /* ifdef LITV4 */

#ifdef LITV4

/*
*
*       Fun:   cmPkItSstaPsEndp
*
*       Desc:  This function packs the Peer Server status per Endp.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItSstaPsEndp
(
ItSstaPsEndp             *pkParam,     /* Peer Server per Endp status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItSstaPsEndp (pkParam, mBuf)
ItSstaPsEndp             *pkParam;     /* Peer Server per Endp status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16        idx;

   TRC2(cmPkItSstaPsEndp)

   for (idx = pkParam->nmbPsp; idx > 0; idx--)
   {
      CMCHKPK(SPkU8, pkParam->pspSt[idx-1].mode, mBuf);
      CMCHKPK(SPkU8, pkParam->pspSt[idx-1].rcValid, mBuf);
      CMCHKPK(SPkU32, pkParam->pspSt[idx-1].rCtx, mBuf);
      CMCHKPK(SPkU8, pkParam->pspSt[idx-1].aspSt, mBuf);
      CMCHKPK(cmPkItPspId, pkParam->pspSt[idx-1].pspId, mBuf);
   }
   CMCHKPK(SPkU16, pkParam->nmbPsp, mBuf);
   CMCHKPK(SPkU16, pkParam->nmbPspReg, mBuf);
   for (idx = pkParam->nmbAct; idx > 0; idx--)
   {
      CMCHKPK(cmPkItPspId, pkParam->actPsp[idx-1], mBuf);
   }
   CMCHKPK(SPkU16, pkParam->nmbAct, mBuf);

   RETVALUE(ROK);
}   /* cmPkItSstaPsEndp */
#endif /* ifdef LITV4 */


/*
*
*       Fun:   cmPkItAssocSta
*
*       Desc:  This function packs the Association status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItAssocSta
(
ItAssocSta               *pkParam,     /* Association status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItAssocSta (pkParam, mBuf)
ItAssocSta               *pkParam;     /* Association status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmPkItAssocSta)

   for (idx = pkParam->nmbRegPs; idx > 0; idx--)
   {
      CMCHKPK(cmPkItPsId, pkParam->regPs[idx-1], mBuf);
   }

   CMCHKPK(SPkU16, pkParam->nmbRegPs, mBuf);
   
   for (idx = pkParam->nmbAct; idx > 0; idx--)
   {
      CMCHKPK(cmPkItPsId, pkParam->actPs[idx-1], mBuf);
   }

   CMCHKPK(SPkU16, pkParam->nmbAct, mBuf);
   CMCHKPK(SPkU8, pkParam->inhibited, mBuf);
   CMCHKPK(SPkU8, pkParam->readySetupSt, mBuf);
   CMCHKPK(SPkU8, pkParam->aspSt, mBuf);

   CMCHKPK(SPkU8, pkParam->hlSt, mBuf);
   CMCHKPK(cmPkUConnId, pkParam->spAssocId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItAssocSta */


/*
*
*       Fun:   cmPkItPspSta
*
*       Desc:  This function packs the Peer Server Process status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPspSta
(
ItPspSta                 *pkParam,     /* Peer Server Process status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPspSta (pkParam, mBuf)
ItPspSta                 *pkParam;     /* Peer Server Process status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16            idx;

   TRC2(cmPkItPspSta)

   for (idx = LIT_MAX_SEP; idx > 0; idx--)
   {
      CMCHKPK(cmPkItAssocSta, &pkParam->assocSta[idx-1], mBuf);
   }
   CMCHKPK(cmPkItPspId, pkParam->pspId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPspSta */


/*
*
*       Fun:   cmPkItSctSapSta
*
*       Desc:  This function packs the lower SAP status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItSctSapSta
(
Pst                      *pst,         /* post structure */
ItSctSapSta              *pkParam,     /* lower SAP status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItSctSapSta (pst, pkParam, mBuf)
Pst                      *pst;         /* post structure */
ItSctSapSta              *pkParam;     /* lower SAP status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkItSctSapSta)

   /* lit_c_002.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* lit_c_002.main_7 - Changes for new interface version LITV4 to pack
    * srcAddrLst in SCT SAP status.
    * LITIFVER 0x0100, 0x0200, 0x0300 - srcAddrLst not packed.
    * LITIFVER 0x0400 and later - srcAddrLst packed if LITV4 defined.*/
   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      case 0x0200:     /* interface version LITV2 */
      case 0x0300:     /* interface version LITV3 */
      {
         CMCHKPK(SPkU16, pkParam->nmbActAssoc, mBuf);
         CMCHKPK(cmPkUConnId, pkParam->spEndpId, mBuf);
         CMCHKPK(SPkU8, pkParam->hlSt, mBuf);
         CMCHKPK(cmPkSpId, pkParam->suId, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPK(cmPkIntfVer, pkParam->selfIntfVer, mBuf);
         CMCHKPK(SPkU8, pkParam->remIntfValid, mBuf);
         CMCHKPK(cmPkIntfVer, pkParam->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }

      case 0x0400:     /* interface version LITV4 */
      case 0x0500:     /* interface version LITV5 */
      case 0x0600:     /* interface version LITV6 */
      {
#ifdef LITV4
         CMCHKPK(cmPkSctNetAddrLst, &pkParam->srcAddrLst, mBuf);
#endif /* LITV4 */
         CMCHKPK(SPkU16, pkParam->nmbActAssoc, mBuf);
         CMCHKPK(cmPkUConnId, pkParam->spEndpId, mBuf);
         CMCHKPK(SPkU8, pkParam->hlSt, mBuf);
         CMCHKPK(cmPkSpId, pkParam->suId, mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
         CMCHKPK(cmPkIntfVer, pkParam->selfIntfVer, mBuf);
         CMCHKPK(SPkU8, pkParam->remIntfValid, mBuf);
         CMCHKPK(cmPkIntfVer, pkParam->remIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
}   /* cmPkItSctSapSta */


/*
*
*       Fun:   cmPkItAtSta
*
*       Desc:  This function packs the Address Translation status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItAtSta
(
ItAtSta                  *pkParam,     /* Address Translation status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItAtSta (pkParam, mBuf)
ItAtSta                  *pkParam;     /* Address Translation status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItAtSta)

   CMCHKPK(SPkU16, pkParam->nmbRout, mBuf);
   CMCHKPK(SPkU16, pkParam->nmbDpc, mBuf);

   RETVALUE(ROK);
}   /* cmPkItAtSta */


/*
*
*       Fun:   cmPkItRkSta
*
*       Desc:  This function packs the Routing Key status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItRkSta
(
ItRkSta                  *pkParam,     /* Rouitng Key status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItRkSta (pkParam, mBuf)
ItRkSta                  *pkParam;     /* Rouitng Key status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItRkSta)

   CMCHKPK(SPkU16, pkParam->nmbRkReg, mBuf);

   RETVALUE(ROK);
}   /* cmPkItSta */


/*
*
*       Fun:   cmPkItPspRkIdSta
*
*       Desc:  This function packs the PSP RK ID status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPspRkIdSta
(
ItPspRkIdSta             *pkParam,     /* PSP RK ID status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPspRkIdSta (pkParam, mBuf)
ItPspRkIdSta             *pkParam;     /* PSP RK ID status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16    idx;

   TRC2(cmPkItPspRkIdSta)

   for (idx = pkParam->nmbRkReqPend; idx > 0; idx--)
   {
      CMCHKPK(SPkU32, pkParam->lclRkId[idx-1], mBuf);
   }

   CMCHKPK(SPkU32, pkParam->nmbRkReqPend, mBuf);
   CMCHKPK(cmPkSuId, pkParam->sctSuId, mBuf);
   CMCHKPK(cmPkItPspId, pkParam->pspId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPspRkIdSta */

/*
*
*       Fun:   cmPkLitStaReq
*
*       Desc:  This function packs the Solicited Status Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitStaReq
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *sta          /* Status */
)
#else
PUBLIC S16 cmPkLitStaReq (pst, sta)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *sta;         /* Status */
#endif
{
   Buffer       *mBuf;

   TRC2(cmPkLitStaReq)

   LIT_GETMSG(pst, mBuf, ELIT120);

   switch (sta->hdr.elmId.elmnt)
   {
      case STITGEN:
      case STITSID:
      case STITADRTRAN:
      case STITRK:

         /* Don't Need to pack anything here */
         break;

      case STITNSAP:
         CMCHKPKLOG(cmPkSpId, sta->t.ssta.s.nSapSta.lclSapId, mBuf, ELIT121, pst);
         break;

      case STITPS:
         CMCHKPKLOG(cmPkItPsId, sta->t.ssta.s.psSta.psId, mBuf, ELIT122, pst);
         break;

      case STITPSP:
         CMCHKPKLOG(cmPkItPspId, sta->t.ssta.s.pspSta.pspId, mBuf,
            ELIT123, pst);
         break;

      case STITSCTSAP:
         CMCHKPKLOG(cmPkSpId, sta->t.ssta.s.sctSapSta.suId, mBuf,
            ELIT124, pst);
         break;

      case STITPSPRKID:
         /* it002.106 - Pack the sctSuId */
         CMCHKPKLOG(cmPkSuId, sta->t.ssta.s.pspRkIdSta.sctSuId, mBuf, 
            ELITXXX, pst);
         CMCHKPKLOG(cmPkItPspId, sta->t.ssta.s.pspRkIdSta.pspId, mBuf,
            ELIT125, pst);
         break;

      case STITNWK:
         CMCHKPKLOG(cmPkItNwkId, sta->t.ssta.s.nwkId, mBuf, ELIT126, pst);
         break;

      case STITAPC:
         CMCHKPKLOG(cmPkDpc, sta->t.ssta.s.dpcSta.dpc, mBuf, ELIT127, pst);
         CMCHKPKLOG(cmPkItNwkId, sta->t.ssta.s.dpcSta.nwkId, mBuf, ELIT128, pst);
         break;

      case STITROUT:
         CMCHKPKLOG(cmPkItRteCfg, &sta->t.ssta.s.rteSta, mBuf, ELIT129, pst);
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT130, "cmPkLitStaReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELIT131, pst);
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELIT132, pst);

   pst->event = (Event)EVTLITSTAREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitStaReq */


/* ***********************************************

      Unpacking Functions for Status Request

   **************************************** */


/*
*
*       Fun:   cmUnpkItGenSta
*
*       Desc:  This function unpacks the General status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItGenSta
(
ItGenSta                 *unpkParam,   /* General status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItGenSta (unpkParam, mBuf)
ItGenSta                 *unpkParam;   /* General status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItGenSta)

   CMCHKUNPK(SUnpkU32, &unpkParam->memSize, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->memAlloc, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItGenSta */


/*
*
*       Fun:   cmUnpkItNSapSta
*
*       Desc:  This function unpacks the Upper SAP status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItNSapSta
(
ItNSapSta                *unpkParam,   /* Upper SAP status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItNSapSta (unpkParam, mBuf)
ItNSapSta                *unpkParam;   /* Upper SAP status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItNSapSta)
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK( cmUnpkIntfVer, &unpkParam->remIntfVer, mBuf);
   CMCHKUNPK( SUnpkU8, &unpkParam->remIntfValid, mBuf);
   CMCHKUNPK( cmUnpkIntfVer, &unpkParam->selfIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPK(cmUnpkSpId, &unpkParam->lclSapId, mBuf);
   CMCHKUNPK(cmUnpkSpId, &unpkParam->remSapId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->hlSt, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItNSapSta */

#ifndef LITV4

/*
*
*       Fun:   cmUnpkItPsSta
*
*       Desc:  This function unpacks the Peer Server status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPsSta
(
ItPsSta                  *unpkParam,   /* Peer Server status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPsSta (unpkParam, mBuf)
ItPsSta                  *unpkParam;   /* Peer Server status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmUnpkItPsSta)

   CMCHKUNPK(cmUnpkItPsId, &unpkParam->psId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->asSt, mBuf);
   for (idx = 0; idx < LIT_MAX_SEP; idx++)
   {
      CMCHKUNPK(cmUnpkItPsStaEndp, &unpkParam->psStaEndp[idx], mBuf);
   }
   

   RETVALUE(ROK);
}   /* cmUnpkItPsSta */
#endif /* ifndef LITV4 */

#ifndef LITV4

/*
*
*       Fun:   cmUnpkItPsStaEndp
*
*       Desc:  This function unpacks the Peer Server status per Endp
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPsStaEndp
(
ItPsStaEndp              *unpkParam,   /* Peer Server per Endp status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPsStaEndp (unpkParam, mBuf)
ItPsStaEndp              *unpkParam;   /* Peer Server per Endp status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmUnpkItPsStaEndp)

   for (idx = 0; idx < LIT_MAX_PSP; idx++)
   {
      CMCHKUNPK(SUnpkU8, &unpkParam->aspSt[idx], mBuf);
   }
   
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbAct, mBuf);

   for (idx = 0; idx < unpkParam->nmbAct; idx++)
   {
      CMCHKUNPK(cmUnpkItPspId, &unpkParam->actPsp[idx], mBuf);
   }
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbPspReg, mBuf);

   for (idx = 0; idx < LIT_MAX_PSP; idx++)
   {
      CMCHKUNPK(SUnpkU32, &unpkParam->rteCtx[idx].rCtx, mBuf);
      CMCHKUNPK(SUnpkU8, &unpkParam->rteCtx[idx].rcValid, mBuf);
      CMCHKUNPK(SUnpkU8, &unpkParam->rteCtx[idx].mode, mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkItPsStaEndp */
#endif /* ifndef LITV4 */

/* lit_c_002.main_7 - Changes for interface version LITV4 to unpack
 * ItSstaPs structure. */
#ifdef LITV4

/*
*
*       Fun:   cmUnpkItSstaPs
*
*       Desc:  This function unpacks the Peer Server status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItSstaPs
(
ItSstaPs                 *unpkParam,   /* Peer Server status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItSstaPs (unpkParam, mBuf)
ItSstaPs                 *unpkParam;   /* Peer Server status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmUnpkItSstaPs)

   CMCHKUNPK(cmUnpkItPsId, &unpkParam->psId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->asSt, mBuf);
   for (idx = 0; idx < LIT_MAX_SEP; idx++)
   {
      CMCHKUNPK(cmUnpkItSstaPsEndp, &unpkParam->sstaPsEndp[idx], mBuf);
   }
   

   RETVALUE(ROK);
}   /* cmUnpkItSstaPs */
#endif /* ifdef LITV4 */

#ifdef LITV4

/*
*
*       Fun:   cmUnpkItSstaPsEndp
*
*       Desc:  This function unpacks the Peer Server status per Endp
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItSstaPsEndp
(
ItSstaPsEndp             *unpkParam,   /* Peer Server per Endp status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPsStaEndp (unpkParam, mBuf)
ItPsStaEndp              *unpkParam;   /* Peer Server per Endp status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmUnpkItPsStaEndp)

   CMCHKUNPK(SUnpkU16, &unpkParam->nmbAct, mBuf);

   for (idx = 0; idx < unpkParam->nmbAct; idx++)
   {
      CMCHKUNPK(cmUnpkItPspId, &unpkParam->actPsp[idx], mBuf);
   }
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbPspReg, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbPsp, mBuf);

   for (idx = 0; idx < unpkParam->nmbPsp; idx++)
   {
      CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspSt[idx].pspId, mBuf);
      CMCHKUNPK(SUnpkU8, &unpkParam->pspSt[idx].aspSt, mBuf);
      CMCHKUNPK(SUnpkU32, &unpkParam->pspSt[idx].rCtx, mBuf);
      CMCHKUNPK(SUnpkU8, &unpkParam->pspSt[idx].rcValid, mBuf);
      CMCHKUNPK(SUnpkU8, &unpkParam->pspSt[idx].mode, mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkItSstaPsEndp */
#endif /* ifdef LITV4 */


/*
*
*       Fun:   cmUnpkItAssocSta
*
*       Desc:  This function unpacks the Association status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItAssocSta
(
ItAssocSta               *unpkParam,   /* Association status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItAssocSta (unpkParam, mBuf)
ItAssocSta               *unpkParam;   /* Association status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16          idx;

   TRC2(cmUnpkItAssocSta)

   CMCHKUNPK(cmUnpkUConnId, &unpkParam->spAssocId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->hlSt, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->aspSt, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->readySetupSt, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->inhibited, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbAct, mBuf);

   for (idx = 0; idx < unpkParam->nmbAct; idx++)
   {
      CMCHKUNPK(cmUnpkItPsId, &unpkParam->actPs[idx], mBuf);
   }

   CMCHKUNPK(SUnpkU16, &unpkParam->nmbRegPs, mBuf);

   for (idx = 0; idx < unpkParam->nmbRegPs; idx++)
   {
      CMCHKUNPK(cmUnpkItPsId, &unpkParam->regPs[idx], mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkItAssocSta */

/*
*
*       Fun:   cmUnpkItPspSta
*
*       Desc:  This function unpacks the Peer Server Process status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPspSta
(
ItPspSta                 *unpkParam,   /* Peer Server Process status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPspSta (unpkParam, mBuf)
ItPspSta                 *unpkParam;   /* Peer Server Process status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16        idx;

   TRC2(cmUnpkItPspSta)

   CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspId, mBuf);
   for (idx = 0; idx < LIT_MAX_SEP; idx++)
   {
      CMCHKUNPK(cmUnpkItAssocSta, &unpkParam->assocSta[idx], mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkItPspSta */


/*
*
*       Fun:   cmUnpkItSctSapSta
*
*       Desc:  This function unpacks the lower SAP status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItSctSapSta
(
ItSctSapSta              *unpkParam,   /* lower SAP status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItSctSapSta (unpkParam, mBuf)
ItSctSapSta              *unpkParam;   /* lower SAP status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItSctSapSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CMCHKUNPK( cmUnpkIntfVer, &unpkParam->remIntfVer, mBuf);
   CMCHKUNPK( SUnpkU8, &unpkParam->remIntfValid, mBuf);
   CMCHKUNPK( cmUnpkIntfVer, &unpkParam->selfIntfVer, mBuf);
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CMCHKUNPK(cmUnpkSpId, &unpkParam->suId, mBuf);
   CMCHKUNPK(SUnpkU8, &unpkParam->hlSt, mBuf);
   CMCHKUNPK(cmUnpkUConnId, &unpkParam->spEndpId, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbActAssoc, mBuf);

   /* lit_c_002.main_7 - Changes for new interface version LITV4 to unpack
    * srcAddrLst in SCT SAP status. */
#ifdef LITV4
   CMCHKUNPK(cmUnpkSctNetAddrLst, &unpkParam->srcAddrLst, mBuf);
#endif /* LITV4 */

   RETVALUE(ROK);
}   /* cmUnpkItSctSapSta */


/*
*
*       Fun:   cmUnpkItAtSta
*
*       Desc:  This function unpacks the Address Translation status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItAtSta
(
ItAtSta                  *unpkParam,   /* Address Translation status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItAtSta (unpkParam, mBuf)
ItAtSta                  *unpkParam;   /* Address Translation status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItAtSta)

   CMCHKUNPK(SUnpkU16, &unpkParam->nmbDpc, mBuf);
   CMCHKUNPK(SUnpkU16, &unpkParam->nmbRout, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItAtSta */


/*
*
*       Fun:   cmUnpkItRkSta
*
*       Desc:  This function unpacks the routing key status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItRkSta
(
ItRkSta                  *unpkParam,   /* Routing Key status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItRkSta (unpkParam, mBuf)
ItRkSta                  *unpkParam;   /* Routing Key status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItRkSta)

   CMCHKUNPK(SUnpkU16, &unpkParam->nmbRkReg, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItRkSta */


/*
*
*       Fun:   cmUnpkItPspRkIdSta
*
*       Desc:  This function unpacks the PSP RK ID  status
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPspRkIdSta
(
ItPspRkIdSta             *unpkParam,   /* PSP RK ID status */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPspRkIdSta (unpkParam, mBuf)
ItPspRkIdSta             *unpkParam;   /* PSP RK ID status */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16    idx;    /* loop index */
   TRC2(cmUnpkItPspRkIdSta)

   CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspId, mBuf);
   CMCHKUNPK(cmUnpkSuId, &unpkParam->sctSuId, mBuf);
   CMCHKUNPK(SUnpkU32, &unpkParam->nmbRkReqPend, mBuf);
   for (idx = 0; idx < unpkParam->nmbRkReqPend; idx++)
   {
      CMCHKUNPK(SUnpkU32, &unpkParam->lclRkId[idx], mBuf);
   }

   RETVALUE(ROK);
}   /* cmUnpkItPspRkIdSta */


/*
*
*       Fun:   cmUnpkLitStaReq
*
*       Desc:  This function unpacks the Solicited status request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitStaReq
(
LitStaReq                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitStaReq (func, pst, mBuf)
LitStaReq                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      sta;          /* M3UA Managment Structure */

   TRC2(cmUnpkLitStaReq)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELIT133, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELIT134, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case STITGEN:
      case STITSID:
      case STITADRTRAN:
      case STITRK:

         /* Don't Need to unpack anything here */
         break;

      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &sta.t.ssta.s.nSapSta.lclSapId, mBuf,
            ELIT135, pst);
         break;

      case STITPS:
         CMCHKUNPKLOG(cmUnpkItPsId, &sta.t.ssta.s.psSta.psId, mBuf,
            ELIT136, pst);
         break;

      case STITPSP:
         CMCHKUNPKLOG(cmUnpkItPspId, &sta.t.ssta.s.pspSta.pspId, mBuf,
            ELIT137, pst);
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &sta.t.ssta.s.sctSapSta.suId, mBuf,
            ELIT138, pst);
         break;

      case STITPSPRKID:
         CMCHKUNPKLOG(cmUnpkItPspId, &sta.t.ssta.s.pspRkIdSta.pspId, mBuf,
            ELIT139, pst);
         /* it002.106 - Unpacking sctSuId */
         CMCHKUNPKLOG(cmUnpkSuId, &sta.t.ssta.s.pspRkIdSta.sctSuId, mBuf,
            ELITXXX, pst);
         break;

      case STITNWK:
         CMCHKUNPKLOG(cmUnpkItNwkId, &sta.t.ssta.s.nwkId, mBuf, ELIT140, pst);
         break;

      case STITAPC:
         CMCHKUNPKLOG(cmUnpkItNwkId, &sta.t.ssta.s.dpcSta.nwkId, mBuf, ELIT141, pst);
         CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.s.dpcSta.dpc, mBuf, ELIT142, pst);
         break;

      case STITROUT:
         CMCHKUNPKLOG(cmUnpkItRteCfg, &sta.t.ssta.s.rteSta, mBuf, ELIT143, pst);
         break;


      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT144, "cmUnpkLitStaReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sta));
}   /* cmUnpkLitStaReq */



/* ***********************************************

      Packing Functions for Status Confirm

   **************************************** */


/*
*
*       Fun:   cmPkLitStaCfm
*
*       Desc:  This function packs the Solicited Status Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitStaCfm
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *sta          /* Status */
)
#else
PUBLIC S16 cmPkLitStaCfm (pst, sta)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *sta;         /* Status */
#endif
{
   Buffer       *mBuf;

   TRC2(cmPkLitStaCfm)

   LIT_GETMSG(pst, mBuf, ELIT145);

   switch (sta->hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKPKLOG(cmPkItGenSta, &sta->t.ssta.s.genSta, mBuf, ELIT146, pst);
         break;

      case STITSID:
         CMCHKPKLOG(cmPkSystemId, &sta->t.ssta.s.sysId, mBuf, ELIT147, pst);
         break;

      case STITNSAP:
         CMCHKPKLOG(cmPkItNSapSta, &sta->t.ssta.s.nSapSta, mBuf, ELIT148, pst);
         break;

      case STITADRTRAN:
         CMCHKPKLOG(cmPkItAtSta, &sta->t.ssta.s.atSta, mBuf, ELIT149, pst);
         break;

      case STITPS:
         /* lit_c_002.main_7 - Changes to pack ItSstaPs structure. */
#ifdef LITV4
         CMCHKPKVERLOG(cmPkItSstaPs, &sta->t.ssta.s.psSta, mBuf, ELIT150, pst);
#else /* LITV4 */
         CMCHKPKLOG(cmPkItPsSta, &sta->t.ssta.s.psSta, mBuf, ELIT150, pst);
#endif /* LITV4 */
         break;

      case STITPSP:
         CMCHKPKLOG(cmPkItPspSta, &sta->t.ssta.s.pspSta, mBuf, ELIT151, pst);
         break;

      case STITSCTSAP:
         /* lit_c_002.main_7 - Changed the macro to CMCHKPKVERLOG to pass pst 
          * structure for version information in cmPkItSctSapSta. */
         CMCHKPKVERLOG(cmPkItSctSapSta, &sta->t.ssta.s.sctSapSta, mBuf, ELIT152, pst);
         break;
         
      case STITRK:
         CMCHKPKLOG(cmPkItRkSta, &sta->t.ssta.s.rkSta, mBuf, ELIT153, pst);
         break;

      case STITPSPRKID:
         CMCHKPKLOG(cmPkItPspRkIdSta, &sta->t.ssta.s.pspRkIdSta, mBuf,
                         ELIT154, pst);
         break;

      case STITNWK:
         CMCHKPKLOG(cmPkItNwkId, sta->t.ssta.s.nwkId, mBuf, ELIT155, pst);
         break;

      case STITAPC:
         CMCHKPKLOG(cmPkItCongLevel, sta->t.ssta.s.dpcSta.congLevel, mBuf, ELIT156, pst);
         CMCHKPKLOG(cmPkItDpcSta, sta->t.ssta.s.dpcSta.dpcSt, mBuf, ELIT157, pst);
         CMCHKPKLOG(cmPkDpc, sta->t.ssta.s.dpcSta.dpc, mBuf, ELIT158, pst);
         CMCHKPKLOG(cmPkItNwkId, sta->t.ssta.s.dpcSta.nwkId, mBuf, ELIT159, pst);
         break;

      case STITROUT:
         CMCHKPKLOG(cmPkItRteCfg, &sta->t.ssta.s.rteSta, mBuf, ELIT160, pst);
         break;

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT161, "cmPkLitStaCfm: Failed");
#endif
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkDateTime, &sta->t.ssta.dt, mBuf, ELIT162, pst);
   CMCHKPKLOG(cmPkCmStatus, &sta->cfm, mBuf, ELIT163, pst);
   CMCHKPKLOG(cmPkHeader, &sta->hdr, mBuf, ELIT164, pst);

   pst->event = (Event)EVTLITSTACFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitStaCfm */


/* ***********************************************

      Unpacking Functions for Status Confirm

   **************************************** */


/*
*
*       Fun:   cmUnpkLitStaCfm
*
*       Desc:  This function unpacks the Solicited Status Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitStaCfm
(
LitStaCfm                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitStaCfm (func, pst, mBuf)
LitStaCfm                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt        sta;         /* Status */
   Txt           ptNmb[8];

   TRC2(cmUnpkLitStaCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &sta.hdr, mBuf, ELIT165, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &sta.cfm, mBuf, ELIT166, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sta.t.ssta.dt, mBuf, ELIT167, pst);

   switch (sta.hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKUNPKLOG(cmUnpkItGenSta, &sta.t.ssta.s.genSta, mBuf, ELIT168, pst);
         break;

      case STITSID:
         sta.t.ssta.s.sysId.ptNmb = ptNmb;
         CMCHKUNPKLOG(cmUnpkSystemId, &sta.t.ssta.s.sysId, mBuf, ELIT169, pst);
         break;

      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkItNSapSta, &sta.t.ssta.s.nSapSta, mBuf, ELIT170, pst);
         break;

      case STITADRTRAN:
         CMCHKUNPKLOG(cmUnpkItAtSta, &sta.t.ssta.s.atSta, mBuf, ELIT171, pst);
         break;

      case STITPS:
         /* lit_c_002.main_7 - Changes to unpack ItSstaPs structure. */
#ifdef LITV4
         CMCHKUNPKLOG(cmUnpkItSstaPs, &sta.t.ssta.s.psSta, mBuf, ELIT172, pst);
#else /* LITV4 */
         CMCHKUNPKLOG(cmUnpkItPsSta, &sta.t.ssta.s.psSta, mBuf, ELIT172, pst);
#endif /* LITV4 */
         break;

      case STITPSP:
         CMCHKUNPKLOG(cmUnpkItPspSta, &sta.t.ssta.s.pspSta, mBuf, ELIT173, pst);
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkItSctSapSta, &sta.t.ssta.s.sctSapSta, mBuf, ELIT174, pst);
         break;

      case STITRK:
         CMCHKUNPKLOG(cmUnpkItRkSta, &sta.t.ssta.s.rkSta, mBuf, ELIT175, pst);
         break;

      case STITPSPRKID:
         CMCHKUNPKLOG(cmUnpkItPspRkIdSta, &sta.t.ssta.s.pspRkIdSta, mBuf,
                         ELIT176, pst);
         break;
      case STITNWK:
         CMCHKUNPKLOG(cmUnpkItNwkId, &sta.t.ssta.s.nwkId, mBuf, ELIT177, pst);
         break;

      case STITAPC:
         CMCHKUNPKLOG(cmUnpkItNwkId, &sta.t.ssta.s.dpcSta.nwkId, mBuf, ELIT178, pst);
         CMCHKUNPKLOG(cmUnpkDpc, &sta.t.ssta.s.dpcSta.dpc, mBuf, ELIT179, pst);
         CMCHKUNPKLOG(cmUnpkItDpcSta, &sta.t.ssta.s.dpcSta.dpcSt, mBuf, ELIT180, pst);
         CMCHKUNPKLOG(cmUnpkItCongLevel, &sta.t.ssta.s.dpcSta.congLevel, mBuf, ELIT181, pst);
         break;

      case STITROUT:
         CMCHKUNPKLOG(cmUnpkItRteCfg, &sta.t.ssta.s.rteSta, mBuf, ELIT182, pst);
         break;
      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT183, "cmUnpkLitStaCfm: Failed");
#endif
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sta));
}   /* cmUnpkLitStaCfm */


/* ***********************************************

      Packing Functions for Statistics Request

   **************************************** */


/*
*
*       Fun:   cmPkItM3uaSts
*
*       Desc:  This function packs the M3UA counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItM3uaSts
(
ItM3uaSts                *pkParam,     /* M3UA counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItM3uaSts (pkParam, mBuf)
ItM3uaSts                *pkParam;     /* M3UA counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItM3uaSts)

   CMCHKPK(cmPkStsCntr, pkParam->notify, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->err, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->hBeatAck, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->hBeat, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspIaAck, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspIa, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspAcAck, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspAc, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspDnAck, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspDn, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspUpAck, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->aspUp, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->deRegRsp, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->regRsp, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->deRegReq, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->regReq, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->drst, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dupu, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->scon, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->daud, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dava, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->duna, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->data, mBuf);

   RETVALUE(ROK);
}   /* cmPkItM3uaSts */


/*
*
*       Fun:   cmPkItMtp3Sts
*
*       Desc:  This function packs the MTP3 counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItMtp3Sts
(
ItMtp3Sts                *pkParam,     /* MTP3 counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItMtp3Sts (pkParam, mBuf)
ItMtp3Sts                *pkParam;     /* MTP3 counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItMtp3Sts)

   CMCHKPK(cmPkStsCntr, pkParam->upu, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->rstEnd, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->rstBeg, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->drst, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->cong, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->resume, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->pause, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->data, mBuf);

   RETVALUE(ROK);
}   /* cmPkItMtp3Sts */


/*
*
*       Fun:   cmPkItDataSts
*
*       Desc:  This function packs the data counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItDataSts
(
ItDataSts                *pkParam,     /* data counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItDataSts (pkParam, mBuf)
ItDataSts                *pkParam;     /* data counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItDataSts)

   CMCHKPK(cmPkStsCntr, pkParam->pduBytes, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->nPdus, mBuf);

   RETVALUE(ROK);
}   /* cmPkItDataSts */


/*
*
*       Fun:   cmPkItDataErrSts
*
*       Desc:  This function packs the data error counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItDataErrSts
(
ItDataErrSts             *pkParam,     /* data error counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItDataErrSts (pkParam, mBuf)
ItDataErrSts             *pkParam;     /* data error counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItDataErrSts)

   CMCHKPK(cmPkStsCntr, pkParam->dataQAsPend, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dataQCong, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropMmhFail, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropLoadShFail, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropNoNSapAvail, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropNoPspAvail, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropPcCong, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropPcUnavail, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->dropNoRoute, mBuf);

   RETVALUE(ROK);
}   /* cmPkItDataErrSts */

#if (defined(LITV3) || defined(LITV6))

/*
*
*       Fun:   cmPkItUnavSts
*
*       Desc:  This function packs unavailability statistics
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItUnavSts
(
ItUnavSts                *pkParam,     /* unavailability sts */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItUnavSts (pkParam, mBuf)
ItUnavSts                *pkParam;     /* unavailability sts */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItUnavSts)

   CMCHKPK(cmPkTicks, pkParam->durUnav, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->unav, mBuf);

   RETVALUE(ROK);
}   /* cmPkItUnavSts */
#endif /* LITV3 || LITV6 */

#ifdef LITV3

/*
*
*       Fun:   cmPkItCongSts
*
*       Desc:  This function packs the association congestion statistics
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItCongSts
(
ItCongSts                *pkParam,     /* assoc congestion sts */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItCongSts (pkParam, mBuf)
ItCongSts                *pkParam;     /* assoc congestion sts */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItCongSts)

   CMCHKPK(cmPkTicks, pkParam->durCong, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->cong3, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->cong2, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->cong1, mBuf);
   CMCHKPK(cmPkStsCntr, pkParam->cong, mBuf);

   RETVALUE(ROK);
}   /* cmPkItCongSts */
#endif /* LITV3 */


/*
*
*       Fun:   cmPkItGenSts
*
*       Desc:  This function packs the General statistics
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItGenSts
(
ItGenSts                 *pkParam,     /* General statistics */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItGenSts (pkParam, mBuf)
ItGenSts                 *pkParam;     /* General statistics */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItGenSts)

   CMCHKPK(cmPkItDataErrSts, &pkParam->upDataErrSts, mBuf);
   CMCHKPK(cmPkItDataErrSts, &pkParam->downDataErrSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->uiRxDataSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->uiTxDataSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->liRxDataSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->liTxDataSts, mBuf);
   CMCHKPK(cmPkItM3uaSts, &pkParam->rxM3uaSts, mBuf);
   CMCHKPK(cmPkItM3uaSts, &pkParam->txM3uaSts, mBuf);
   CMCHKPK(cmPkItMtp3Sts, &pkParam->rxMtp3Sts, mBuf);
   CMCHKPK(cmPkItMtp3Sts, &pkParam->txMtp3Sts, mBuf);
   CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);

   RETVALUE(ROK);
}   /* cmPkItGenSts */


/*
*
*       Fun:   cmPkItNSapSts
*
*       Desc:  This function packs the M3UA Statistics for SNTSAP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItNSapSts
(
ItNSapSts                *pkParam,     /* M3UA Statistics for SNTSAP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItNSapSts (pkParam, mBuf)
ItNSapSts                *pkParam;     /* M3UA Statistics for SNTSAP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItNSapSts)

   CMCHKPK(cmPkItDataErrSts, &pkParam->dataErrSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->rxDataSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->txDataSts, mBuf);
   CMCHKPK(cmPkItMtp3Sts, &pkParam->rxMtp3Sts, mBuf);
   CMCHKPK(cmPkItMtp3Sts, &pkParam->txMtp3Sts, mBuf);
   CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);
   CMCHKPK(cmPkSpId, pkParam->spId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItNSapSts */

/*
*
*       Fun:   cmPkItSctSapSts
*
*       Desc:  This function packs the M3UA Statistics for SCTSAP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItSctSapSts
(
ItSctSapSts              *pkParam,     /* M3UA Statistics for SCTSAP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItSctSapSts (pkParam, mBuf)
ItSctSapSts              *pkParam;     /* M3UA Statistics for SCTSAP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItSctSapSts)

   CMCHKPK(cmPkItDataSts, &pkParam->rxDataSts, mBuf);
   CMCHKPK(cmPkItDataSts, &pkParam->txDataSts, mBuf);
   CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);
   CMCHKPK(cmPkSuId, pkParam->suId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItSctSapSts */


/*
*
*       Fun:   cmPkItPspSts
*
*       Desc:  This function packs the M3UA Statistics for ASP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPspSts
(
Pst                      *pst,         /* post structure */
ItPspSts                 *pkParam,     /* M3UA Statistics for ASP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPspSts (pst, pkParam, mBuf)
Pst                      *pst;         /* post structure */
ItPspSts                 *pkParam;     /* M3UA Statistics for ASP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16    idx;    /* loop index */
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmPkItPspSts)
   
   /* lit_c_001.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* lit_c_001.main_7 - Changes for new interface version LITV3 to support
    * association congestion and unavailability statistics.
    * LITIFVER 0x0100, 0x0200 - unavSts and congSts not packed.
    * LITIFVER 0x0300 and later - unavSts and congSts packed if LITV3 defined.*/
   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      case 0x0200:     /* interface version LITV2 */
      {
         for (idx = LIT_MAX_SEP; idx > 0; idx--)
         {
            CMCHKPK(cmPkItDataErrSts, &pkParam->assocSts[idx-1].dataErrSts, mBuf);
            CMCHKPK(cmPkItDataSts, &pkParam->assocSts[idx-1].rxDataSts, mBuf);
            CMCHKPK(cmPkItDataSts, &pkParam->assocSts[idx-1].txDataSts, mBuf);
            CMCHKPK(cmPkItM3uaSts, &pkParam->assocSts[idx-1].rxM3uaSts, mBuf);
            CMCHKPK(cmPkItM3uaSts, &pkParam->assocSts[idx-1].txM3uaSts, mBuf);
         }
         CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);
         CMCHKPK(cmPkItPspId, pkParam->pspId, mBuf);
         break;
      }

      case 0x0300:     /* interface version LITV3 */
      case 0x0400:     /* interface version LITV4 */
      case 0x0500:     /* interface version LITV5 */
      case 0x0600:     /* interface version LITV6 */
      {
         for (idx = LIT_MAX_SEP; idx > 0; idx--)
         {
#ifdef LITV3
            CMCHKPK(cmPkItCongSts, &pkParam->assocSts[idx-1].congSts, mBuf);
            CMCHKPK(cmPkItUnavSts, &pkParam->assocSts[idx-1].unavSts, mBuf);
#endif /* LITV3 */
            CMCHKPK(cmPkItDataErrSts, &pkParam->assocSts[idx-1].dataErrSts, mBuf);
            CMCHKPK(cmPkItDataSts, &pkParam->assocSts[idx-1].rxDataSts, mBuf);
            CMCHKPK(cmPkItDataSts, &pkParam->assocSts[idx-1].txDataSts, mBuf);
            CMCHKPK(cmPkItM3uaSts, &pkParam->assocSts[idx-1].rxM3uaSts, mBuf);
            CMCHKPK(cmPkItM3uaSts, &pkParam->assocSts[idx-1].txM3uaSts, mBuf);
         }
         CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);
         CMCHKPK(cmPkItPspId, pkParam->pspId, mBuf);
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */


   RETVALUE(ROK);
}   /* cmPkItPspSts */

/* lit_c_004.main_7 - Added function for packing PS sts */
#ifdef LITV6

/*
*
*       Fun:   cmPkItPsSts
*
*       Desc:  This function packs the M3UA Statistics for PS
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmPkItPsSts
(
Pst                      *pst,         /* post structure */
ItPsSts                  *pkParam,     /* M3UA Statistics for PS */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmPkItPsSts (pst, pkParam, mBuf)
Pst                      *pst;         /* post structure */
ItPsSts                  *pkParam;     /* M3UA Statistics for PS */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmPkItPsSts)
   
   /* LITIFVER 0x0500 and earlier - psSts not packed.
    * LITIFVER 0x0600 and later - psSts packed if LITV6 defined.*/
   CMCHKPK(cmPkItUnavSts, &pkParam->unavSts, mBuf);
   CMCHKPK(cmPkItM3uaSts, &pkParam->rxM3uaSts, mBuf);
   CMCHKPK(cmPkItM3uaSts, &pkParam->txM3uaSts, mBuf);
   CMCHKPK(cmPkDateTime, &pkParam->dt, mBuf);
   CMCHKPK(cmPkItPsId, pkParam->psId, mBuf);

   RETVALUE(ROK);
}   /* cmPkItPsSts */

#endif /* LITV6 */


/*
*
*       Fun:   cmPkLitStsReq
*
*       Desc:  This function packs the Statistics Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitStsReq
(
Pst                      *pst,         /* Post Structure */
Action                    action,      /* Action */
ItMgmt                   *sts          /* Statistics */
)
#else
PUBLIC S16 cmPkLitStsReq (pst, action, sts)
Pst                      *pst;         /* Post Structure */
Action                    action;      /* Action */
ItMgmt                   *sts;         /* Statistics */
#endif
{
   Buffer       *mBuf;
   CmIntfVer     intfVer;      /* interface version number */

   TRC2(cmPkLitStsReq)

   LIT_GETMSG(pst, mBuf, ELIT184);

   /* lit_c_004.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (sts->hdr.elmId.elmnt)
   {
      case STITGEN:
         break;

      case STITNSAP:
         CMCHKPKLOG(cmPkSpId, sts->t.sts.u.sntSts.spId, mBuf, ELIT185, pst);
         break;

      case STITSCTSAP:
         CMCHKPKLOG(cmPkSuId, sts->t.sts.u.sctSts.suId, mBuf, ELIT186, pst);
         break;

      case STITPSP:
         CMCHKPKLOG(cmPkItPspId, sts->t.sts.u.pspSts.pspId, mBuf, ELIT187, pst);
         break;

      /* lit_c_004.main_7 - Changes for packing PS ID for PS statistics */
#ifdef LITV6
      case STITPS:
         switch (intfVer)
         {
            case 0x0600:     /* interface version LITV6 */
               CMCHKPKLOG(cmPkItPsId, sts->t.sts.u.psSts.psId, mBuf, ELITXXX, pst);
               break;

	    default:
#if (ERRCLASS & ERRCLS_DEBUG)
               LITLOGERROR(ERRCLS_DEBUG, ELIT188, "cmPkLitStsReq: Failed");
#endif
               RETVALUE(RFAILED);
	 }
	 break;
#endif /* LITV6 */
      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT188, "cmUnpkLitStsReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkDuration, &sts->t.sts.dura, mBuf, ELIT189, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELIT190, pst);
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELIT191, pst);
   CMCHKPKLOG(cmPkAction, action, mBuf, ELIT192, pst);

   pst->event = (Event)EVTLITSTSREQ; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitStsReq */


/* ***********************************************

      Packing Functions for Statistics Confirm

   **************************************** */


/*
*
*       Fun:   cmPkLitStsCfm
*
*       Desc:  This function packs the Statistics Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitStsCfm
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *sts          /* Statistics */
)
#else
PUBLIC S16 cmPkLitStsCfm (pst, sts)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *sts;         /* Statistics */
#endif
{
   Buffer       *mBuf;
   CmIntfVer     intfVer;      /* interface version number */

   TRC2(cmPkLitStsCfm)

   LIT_GETMSG(pst, mBuf, ELIT193);

   /* lit_c_004.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   switch (sts->hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKPKLOG(cmPkItGenSts, &sts->t.sts.u.genSts, mBuf, ELIT194, pst);
         break;

      case STITNSAP:
         CMCHKPKLOG(cmPkItNSapSts, &sts->t.sts.u.sntSts, mBuf, ELIT195, pst);
         break;

      case STITSCTSAP:
         CMCHKPKLOG(cmPkItSctSapSts, &sts->t.sts.u.sctSts, mBuf, ELIT196, pst);
         break;

      case STITPSP:
         /* lit_c_001.main_7 - Changed the macro name from CMCHKPKLOG to 
          * CMCHKPKVERLOG to include pst as a parameter for function cmPkItPspSts */
         CMCHKPKVERLOG(cmPkItPspSts, &sts->t.sts.u.pspSts, mBuf, ELIT197, pst);
         break;

      /* lit_c_004.main_7 - Changes for packing PS statistics */
#ifdef LITV6
      case STITPS:
         switch (intfVer)
         {
            case 0x0600:     /* interface version LITV6 */
               CMCHKPKVERLOG(cmPkItPsSts, &sts->t.sts.u.psSts, mBuf, ELITXXX, pst);
               break;

	    default:
#if (ERRCLASS & ERRCLS_DEBUG)
               LITLOGERROR(ERRCLS_DEBUG, ELIT198, "cmPkLitStsCfm: Failed");
#endif
               RETVALUE(RFAILED);
	       break;
	 }
	 break;
#endif /* LITV6 */
      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT198, "cmUnpkLitStsCfm: Failed");
#endif
         RETVALUE(RFAILED);
   }

   CMCHKPKLOG(cmPkDuration, &sts->t.sts.dura, mBuf, ELIT199, pst);
   CMCHKPKLOG(cmPkDateTime, &sts->t.sts.dt, mBuf, ELIT200, pst);
   CMCHKPKLOG(cmPkCmStatus, &sts->cfm, mBuf, ELIT201, pst);
   CMCHKPKLOG(cmPkHeader, &sts->hdr, mBuf, ELIT202, pst);

   pst->event = (Event)EVTLITSTSCFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitStsCfm */


/* ***********************************************

      Unpacking Functions for Statistics Request

   *********************************************** */


/*
*
*       Fun:   cmUnpkItM3uaSts
*
*       Desc:  This function unpacks the M3UA counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItM3uaSts
(
ItM3uaSts                *unpkParam,   /* M3UA counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItM3uaSts (unpkParam, mBuf)
ItM3uaSts                *unpkParam;   /* M3UA counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItM3uaSts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->data, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->duna, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dava, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->daud, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->scon, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dupu, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->drst, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->regReq, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->deRegReq, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->regRsp, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->deRegRsp, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspUp, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspUpAck, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspDn, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspDnAck, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspAc, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspAcAck, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspIa, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->aspIaAck, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->hBeat, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->hBeatAck, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->err, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->notify, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItM3uaSts */

/*
*
*       Fun:   cmUnpkItMtp3Sts
*
*       Desc:  This function unpacks the MTP3 counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItMtp3Sts
(
ItMtp3Sts                *unpkParam,   /* MTP3 counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItMtp3Sts (unpkParam, mBuf)
ItMtp3Sts                *unpkParam;   /* MTP3 counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItMtp3Sts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->data, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->pause, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->resume, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->cong, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->drst, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->rstBeg, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->rstEnd, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->upu, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItMtp3Sts */

/*
*
*       Fun:   cmUnpkItDataSts
*
*       Desc:  This function unpacks the data counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItDataSts
(
ItDataSts                *unpkParam,   /* data counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItDataSts (unpkParam, mBuf)
ItDataSts                *unpkParam;   /* data counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItDataSts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->nPdus, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->pduBytes, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItDataSts */


/*
*
*       Fun:   cmUnpkItDataErrSts
*
*       Desc:  This function unpacks the data error counters
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItDataErrSts
(
ItDataErrSts             *unpkParam,   /* data error counters */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItDataErrSts (unpkParam, mBuf)
ItDataErrSts             *unpkParam;   /* data error counters */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItDataErrSts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropNoRoute, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropPcUnavail, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropPcCong, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropNoPspAvail, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropNoNSapAvail, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropLoadShFail, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dropMmhFail, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dataQCong, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->dataQAsPend, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItDataErrSts */

#if (defined(LITV3) || defined(LITV6))

/*
*
*       Fun:   cmUnpkItUnavSts
*
*       Desc:  This function unpacks unavailability statistics.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItUnavSts
(
ItUnavSts                *unpkParam,   /* unavailability sts */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItUnavSts (unpkParam, mBuf)
ItUnavSts                *unpkParam;   /* unavaiability sts */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItUnavSts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->unav, mBuf);
   CMCHKUNPK(cmUnpkTicks, &unpkParam->durUnav, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItUnavSts */
#endif /* LITV3 || LITV6 */

#ifdef LITV3

/*
*
*       Fun:   cmUnpkItCongSts
*
*       Desc:  This function unpacks association congestion statistics.
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItCongSts
(
ItCongSts                *unpkParam,   /* assoc congestion sts */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItCongSts (unpkParam, mBuf)
ItCongSts                *unpkParam;   /* assoc congestion sts */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItCongSts)

   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->cong, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->cong1, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->cong2, mBuf);
   CMCHKUNPK(cmUnpkStsCntr, &unpkParam->cong3, mBuf);
   CMCHKUNPK(cmUnpkTicks, &unpkParam->durCong, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItCongSts */
#endif /* LITV3 */


/*
*
*       Fun:   cmUnpkItGenSts
*
*       Desc:  This function unpacks the General statistics
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItGenSts
(
ItGenSts                 *unpkParam,   /* General statistics */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItGenSts (unpkParam, mBuf)
ItGenSts                 *unpkParam;   /* General statistics */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItGenSts)

   CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
   CMCHKUNPK(cmUnpkItMtp3Sts, &unpkParam->txMtp3Sts, mBuf);
   CMCHKUNPK(cmUnpkItMtp3Sts, &unpkParam->rxMtp3Sts, mBuf);
   CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->txM3uaSts, mBuf);
   CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->rxM3uaSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->liTxDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->liRxDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->uiTxDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->uiRxDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataErrSts, &unpkParam->downDataErrSts, mBuf);
   CMCHKUNPK(cmUnpkItDataErrSts, &unpkParam->upDataErrSts, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItGenSts */


/*
*
*       Fun:   cmUnpkItNSapSts
*
*       Desc:  This function unpacks the M3UA Statistics for SNTSAP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItNSapSts
(
ItNSapSts                *unpkParam,   /* M3UA Statistics for SNTSAP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItNSapSts (unpkParam, mBuf)
ItNSapSts                *unpkParam;   /* M3UA Statistics for SNTSAP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItNSapSts)

   CMCHKUNPK(cmUnpkSpId, &unpkParam->spId, mBuf);
   CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
   CMCHKUNPK(cmUnpkItMtp3Sts, &unpkParam->txMtp3Sts, mBuf);
   CMCHKUNPK(cmUnpkItMtp3Sts, &unpkParam->rxMtp3Sts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->txDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->rxDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataErrSts, &unpkParam->dataErrSts, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItNSapSts */


/*
*
*       Fun:   cmUnpkItSctSapSts
*
*       Desc:  This function unpacks the M3UA Statistics for SNTSAP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItSctSapSts
(
ItSctSapSts              *unpkParam,   /* M3UA Statistics for SCTSAP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItSctSapSts (unpkParam, mBuf)
ItSctSapSts              *unpkParam;   /* M3UA Statistics for SCTSAP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItSctSapSts)

   CMCHKUNPK(cmUnpkSuId, &unpkParam->suId, mBuf);
   CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->txDataSts, mBuf);
   CMCHKUNPK(cmUnpkItDataSts, &unpkParam->rxDataSts, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItSctSapSts */


/*
*
*       Fun:   cmUnpkItPspSts
*
*       Desc:  This function unpacks the M3UA Statistics for ASP
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPspSts
(
Pst                      *pst,         /* post structure */
ItPspSts                 *unpkParam,   /* M3UA Statistics for ASP */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPspSts (pst, unpkParam, mBuf)
Pst                      *pst;         /* post structure */
ItPspSts                 *unpkParam;   /* M3UA Statistics for ASP */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   U16           idx;
   CmIntfVer intfVer;      /* interface version number */

   TRC2(cmUnpkItPspSts)

   /* lit_c_001.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   /* lit_c_001.main_7 - Changes for new interface version LITV3 to support
    * association congestion and unavailability statistics.
    * LITIFVER 0x0100, 0x0200 - unavSts and congSts not unpacked.
    * LITIFVER 0x0300 and later - unavSts and congSts unpacked if LITV3 defined.*/
   switch (intfVer)
   {
      case 0x0100:     /* interface version LITV1 */
      case 0x0200:     /* interface version LITV2 */
      {
         CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspId, mBuf);
         CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
         for (idx = 0; idx < LIT_MAX_SEP; idx++)
         {
            CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->assocSts[idx].txM3uaSts, mBuf);
            CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->assocSts[idx].rxM3uaSts, mBuf);
            CMCHKUNPK(cmUnpkItDataSts, &unpkParam->assocSts[idx].txDataSts, mBuf);
            CMCHKUNPK(cmUnpkItDataSts, &unpkParam->assocSts[idx].rxDataSts, mBuf);
            CMCHKUNPK(cmUnpkItDataErrSts, &unpkParam->assocSts[idx].dataErrSts, mBuf);
         }
         break;
      }

      case 0x0300:   /* interface version LITV3 */
      case 0x0400:   /* interface version LITV4 */
      case 0x0500:   /* interface version LITV5 */
      case 0x0600:   /* interface version LITV6 */
      {
         CMCHKUNPK(cmUnpkItPspId, &unpkParam->pspId, mBuf);
         CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
         for (idx = 0; idx < LIT_MAX_SEP; idx++)
         {
            CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->assocSts[idx].txM3uaSts, mBuf);
            CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->assocSts[idx].rxM3uaSts, mBuf);
            CMCHKUNPK(cmUnpkItDataSts, &unpkParam->assocSts[idx].txDataSts, mBuf);
            CMCHKUNPK(cmUnpkItDataSts, &unpkParam->assocSts[idx].rxDataSts, mBuf);
            CMCHKUNPK(cmUnpkItDataErrSts, &unpkParam->assocSts[idx].dataErrSts, mBuf);
#ifdef LITV3
            CMCHKUNPK(cmUnpkItUnavSts, &unpkParam->assocSts[idx].unavSts, mBuf);
            CMCHKUNPK(cmUnpkItCongSts, &unpkParam->assocSts[idx].congSts, mBuf);
#endif /* LITV3 */
         }
         break;
      }

      default:
         /* invalid interface version number */
         RETVALUE(RINVIFVER);
   } /* switch (intfVer) */

   RETVALUE(ROK);
}   /* cmUnpkItPspSts */

/* lit_c_004.main_7 - Added function for unpacking PS sts */
#ifdef LITV6

/*
*
*       Fun:   cmUnpkItPsSts
*
*       Desc:  This function unpacks the M3UA Statistics for PS
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PRIVATE S16 cmUnpkItPsSts
(
Pst                      *pst,         /* post structure */
ItPsSts                  *unpkParam,   /* M3UA Statistics for PS */
Buffer                   *mBuf         /* message buffer */
)
#else
PRIVATE S16 cmUnpkItPsSts (pst, unpkParam, mBuf)
Pst                      *pst;         /* post structure */
ItPsSts                  *unpkParam;   /* M3UA Statistics for PS */
Buffer                   *mBuf;        /* message buffer */
#endif
{
   TRC2(cmUnpkItPsSts)

   /* LITIFVER 0x0500 and earlier - psSts not unpacked.
    * LITIFVER 0x0600 and later - psSts unpacked if LITV6 defined.*/
   CMCHKUNPK(cmUnpkItPsId, &unpkParam->psId, mBuf);
   CMCHKUNPK(cmUnpkDateTime, &unpkParam->dt, mBuf);
   CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->txM3uaSts, mBuf);
   CMCHKUNPK(cmUnpkItM3uaSts, &unpkParam->rxM3uaSts, mBuf);
   CMCHKUNPK(cmUnpkItUnavSts, &unpkParam->unavSts, mBuf);

   RETVALUE(ROK);
}   /* cmUnpkItPsSts */
#endif /* LITV6 */


/*
*
*       Fun:   cmUnpkLitStsReq
*
*       Desc:  This function unpacks the Statistics Request
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitStsReq
(
LitStsReq                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitStsReq (func, pst, mBuf)
LitStsReq                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      sts;          /* M3UA Managment Structure */
   Action      action;       /* Action */
   CmIntfVer   intfVer;      /* interface version number */

   TRC2(cmUnpkLitStsReq)

   /* lit_c_004.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkAction, &action, mBuf, ELIT203, pst);
   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELIT204, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELIT205, pst);
   CMCHKUNPKLOG(cmUnpkDuration, &sts.t.sts.dura, mBuf, ELIT206, pst);

   switch (sts.hdr.elmId.elmnt)
   {
      case STITGEN:
         break;

      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &sts.t.sts.u.sntSts.spId, mBuf, ELIT207, pst);
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkSuId, &sts.t.sts.u.sctSts.suId, mBuf, ELIT208, pst);
         break;

      case STITPSP:
         CMCHKUNPKLOG(cmUnpkItPspId, &sts.t.sts.u.pspSts.pspId, mBuf, ELIT209, pst);
         break;

      /* lit_c_004.main_7 - Unpack PS ID for PS sts */
#ifdef LITV6
      case STITPS:
         switch (intfVer)
         {
            case 0x0600:     /* interface version LITV6 */
               CMCHKUNPKLOG(cmUnpkItPsId, &sts.t.sts.u.psSts.psId, mBuf, ELIT209, pst);
	       break;

	    default:
#if (ERRCLASS & ERRCLS_DEBUG)
               LITLOGERROR(ERRCLS_DEBUG, ELIT210, "cmUnpkLitStsReq: Failed");
#endif
               RETVALUE(RFAILED);
	 }
         break;
#endif /* LITV6 */

      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT210, "cmUnpkLitStsReq: Failed");
#endif
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, action, &sts));
}   /* cmUnpkLitStsReq */


/* ***********************************************

      Unpacking Functions for Statistics Confirm

   **************************************** */


/*
*
*       Fun:   cmUnpkLitStsCfm
*
*       Desc:  This function unpacks the Statistics Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitStsCfm
(
LitStsCfm                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitStsCfm (func, pst, mBuf)
LitStsCfm                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      sts;          /* M3UA Managment Structure */
   CmIntfVer   intfVer;      /* interface version number */

   TRC2(cmUnpkLitStsCfm)

   /* lit_c_004.main_7 - If rolling upgrade support is enabled, use interface 
    * version as in pst->intfVer, else use self LIT interface version 
    * number. */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   intfVer = pst->intfVer;
#else
   intfVer = (CmIntfVer) LITIFVER;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   CMCHKUNPKLOG(cmUnpkHeader, &sts.hdr, mBuf, ELIT211, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &sts.cfm, mBuf, ELIT212, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &sts.t.sts.dt, mBuf, ELIT213, pst);
   CMCHKUNPKLOG(cmUnpkDuration, &sts.t.sts.dura, mBuf, ELIT214, pst);

   switch (sts.hdr.elmId.elmnt)
   {
      case STITGEN:
         CMCHKUNPKLOG(cmUnpkItGenSts, &sts.t.sts.u.genSts, mBuf, ELIT215, pst);
         break;

      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkItNSapSts, &sts.t.sts.u.sntSts, mBuf, ELIT216, pst);
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkItSctSapSts, &sts.t.sts.u.sctSts, mBuf, ELIT217, pst);
         break;

      case STITPSP:
         /* lit_c_001.main_7 - Changed the macro name from CMCHKUNPKLOG to 
          * CMCHKUNPKVERLOG to include pst as a parameter for function cmUnpkItPspSts */
         CMCHKUNPKVERLOG(cmUnpkItPspSts, &sts.t.sts.u.pspSts, mBuf, ELIT218, pst);
         break;

      /* lit_c_004.main_7 - Changes for unpacking PS statistics */
#ifdef LITV6
      case STITPS:
         switch (intfVer)
         {
            case 0x0600:     /* interface version LITV6 */
               CMCHKPKVERLOG(cmUnpkItPsSts, &sts.t.sts.u.psSts, mBuf, ELITXXX, pst);
               break;

	    default:
#if (ERRCLASS & ERRCLS_DEBUG)
               LITLOGERROR(ERRCLS_DEBUG, ELITXXX, "cmUnpkLitStsCfm: Failed");
#endif
               RETVALUE(RFAILED);
	       break;
	 }
	 break;
#endif /* LITV6 */
      default:

#if (ERRCLASS & ERRCLS_DEBUG)
         LITLOGERROR(ERRCLS_DEBUG, ELIT219, "cmUnpkLitStsCfm: Failed");
#endif
         RETVALUE(RFAILED);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &sts));
}   /* cmUnpkLitStsCfm */


/* ***********************************************

      Packing Functions for Configuration Confirm

   **************************************** */


/*
*
*       Fun:   cmPkLitCfgCfm
*
*       Desc:  This function packs the Configuration Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitCfgCfm
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *cfm          /* Confirm */
)
#else
PUBLIC S16 cmPkLitCfgCfm (pst, cfm)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *cfm;         /* Confirm */
#endif
{
   Buffer       *mBuf;

   TRC2(cmPkLitCfgCfm)

   LIT_GETMSG(pst, mBuf, ELIT220);

   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELIT221, pst);
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELIT222, pst);

   pst->event = (Event)EVTLITCFGCFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitCfgCfm */


/* ***********************************************

      Unpacking Functions for Configuration Confirm

   **************************************** */


/*
*
*       Fun:   cmUnpkLitCfgCfm
*
*       Desc:  This function unpacks the Configuration Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitCfgCfm
(
LitCfgCfm                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitCfgCfm (func, pst, mBuf)
LitCfgCfm                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      cfm;          /* M3UA Managment Structure */

   TRC2(cmUnpkLitCfgCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELIT223, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELIT224, pst);

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cfm));
}   /* cmUnpkLitCfgCfm */


/* ***********************************************

      Packing Functions for Control Confirm

   **************************************** */


/*
*
*       Fun:   cmPkLitCntrlCfm
*
*       Desc:  This function packs the Control Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitCntrlCfm
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *cfm          /* Confirm */
)
#else
PUBLIC S16 cmPkLitCntrlCfm (pst, cfm)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *cfm;         /* Confirm */
#endif
{
   Buffer       *mBuf;
   U16           idx;

   TRC2(cmPkLitCntrlCfm)

   LIT_GETMSG(pst, mBuf, ELIT225);

   if ((cfm->hdr.elmId.elmnt == STITPSP) && (cfm->t.cntrl.action == ARKREG)) 
   {
      for (idx = cfm->t.cntrl.t.rkResp.nmbRtKey; idx > 0; idx--)
      {
         CMCHKPKLOG(cmPkItRouteKey, &cfm->t.cntrl.t.rkResp.rk[idx-1].rtKey, mBuf, ELIT226, pst);
         CMCHKPKLOG(SPkU32, cfm->t.cntrl.t.rkResp.rk[idx-1].localRkId, mBuf, ELIT227, pst);
      }
      CMCHKPKLOG(SPkU16, cfm->t.cntrl.t.rkResp.nmbRtKey, mBuf, ELIT228, pst);
   }
   CMCHKPKLOG(cmPkAction, cfm->t.cntrl.action, mBuf, ELIT229, pst);
   
   CMCHKPKLOG(cmPkCmStatus, &cfm->cfm, mBuf, ELIT230, pst);
   CMCHKPKLOG(cmPkHeader, &cfm->hdr, mBuf, ELIT231, pst);

   pst->event = (Event)EVTLITCNTRLCFM; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitCntrlCfm */


/* ***********************************************

      Unpacking Functions for Control Confirm

   **************************************** */


/*
*
*       Fun:   cmUnpkLitCntrlCfm
*
*       Desc:  This function unpacks the Control Confirm
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitCntrlCfm
(
LitCntrlCfm               func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitCntrlCfm (func, pst, mBuf)
LitCntrlCfm               func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      cfm;          /* M3UA Managment Structure */
   U16           idx;

   TRC2(cmUnpkLitCntrlCfm)

   CMCHKUNPKLOG(cmUnpkHeader, &cfm.hdr, mBuf, ELIT232, pst);
   CMCHKUNPKLOG(cmUnpkCmStatus, &cfm.cfm, mBuf, ELIT233, pst);

   CMCHKUNPKLOG(cmUnpkAction, &cfm.t.cntrl.action, mBuf, ELIT234, pst);

   if ((cfm.hdr.elmId.elmnt == STITPSP) && (cfm.t.cntrl.action == ARKREG)) 
   {
      CMCHKUNPKLOG(SUnpkU16, &cfm.t.cntrl.t.rkResp.nmbRtKey, mBuf, ELIT235, pst);
      for (idx = cfm.t.cntrl.t.rkResp.nmbRtKey; idx > 0; idx--)
      {
         CMCHKUNPKLOG(SUnpkU32, &cfm.t.cntrl.t.rkResp.rk[idx-1].localRkId, mBuf, ELIT236, pst);
         CMCHKUNPKLOG(cmUnpkItRouteKey, &cfm.t.cntrl.t.rkResp.rk[idx-1].rtKey, mBuf, ELIT237, pst);
      }
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &cfm));
}   /* cmUnpkLitCntrlCfm */


/* ***********************************************

      Packing Functions for Unsolicited Status Indication

   **************************************** */


/*
*
*       Fun:   cmPkLitStaInd
*
*       Desc:  This function packs the Unsolicited Status Indication
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitStaInd
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *usta         /* Alarm */
)
#else
PUBLIC S16 cmPkLitStaInd (pst, usta)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *usta;        /* Alarm */
#endif
{
   Buffer       *mBuf;
   U16           idx;

   TRC2(cmPkLitStaInd)

   LIT_GETMSG(pst, mBuf, ELIT238);

   switch (usta->t.usta.alarm.event)
   {
      case LIT_EVENT_ASPM:

         for (idx = usta->t.usta.t.aspm.nmbPs; idx > 0; idx--)
         {
            CMCHKPKLOG(cmPkItPsId, usta->t.usta.t.aspm.psLst[idx-1], mBuf, ELIT239, pst);
         }
         CMCHKPKLOG(SPkU8, usta->t.usta.t.aspm.nmbPs, mBuf, ELIT240, pst);
         for (idx = (LIT_MAX_INFO + 1); idx > 0; idx--)
         {
            CMCHKPKLOG(SPkU8, usta->t.usta.t.aspm.info[idx-1], mBuf, ELIT241, pst);
         }
         CMCHKPKLOG(SPkU8, usta->t.usta.t.aspm.tmType, mBuf, ELIT242, pst);
         CMCHKPKLOG(cmPkSuId, usta->t.usta.t.aspm.sctSuId, mBuf, ELIT243, pst);


         CMCHKPKLOG(SPkU16, usta->t.usta.t.aspm.msgType, mBuf, ELIT244, pst);
         break;

      case LIT_EVENT_NOTIFY:
         CMCHKPKLOG(cmPkSuId, usta->t.usta.t.ntfy.sctSuId, mBuf, ELIT245, pst);
         CMCHKPKLOG(SPkU32, usta->t.usta.t.ntfy.aspId, mBuf, ELIT246, pst);
         CMCHKPKLOG(cmPkBool, usta->t.usta.t.ntfy.aspIdPres, mBuf, 
                    ELIT247, pst);
         for (idx = usta->t.usta.t.ntfy.nmbPs; idx > 0; idx--)
         {
            CMCHKPKLOG(cmPkItPsId, usta->t.usta.t.ntfy.psLst[idx-1], mBuf, ELIT248, pst);
         }
         CMCHKPKLOG(SPkU8, usta->t.usta.t.ntfy.nmbPs, mBuf, ELIT249, pst);
         for (idx = (LIT_MAX_INFO + 1); idx > 0; idx--)
         {
            CMCHKPKLOG(SPkU8, usta->t.usta.t.ntfy.info[idx-1], mBuf, ELIT250, pst);
         }
         CMCHKPKLOG(SPkU8, usta->t.usta.t.ntfy.stInfo, mBuf, ELIT251, pst);
         CMCHKPKLOG(SPkU8, usta->t.usta.t.ntfy.stType, mBuf, ELIT252, pst);
         break;

      case LIT_EVENT_PC_AVAILABLE:
      case LIT_EVENT_PC_UNAVAILABLE:
      case LIT_EVENT_PC_CONGESTED:
      case LIT_EVENT_PC_RESTRICTED:
         CMCHKPKLOG(SPkU8, usta->t.usta.t.dpcEvt.p.congLevel, mBuf, ELIT253, 
                    pst);
         CMCHKPKLOG(SPkU8, usta->t.usta.t.dpcEvt.mask, mBuf, ELIT254, pst);
         CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, ELIT255, pst);
         break;
      
      case LIT_EVENT_PC_USER_PART_UNA:
         CMCHKPKLOG(SPkU8, usta->t.usta.t.dpcEvt.p.servInd, mBuf, ELIT256, pst);
         CMCHKPKLOG(SPkU8, usta->t.usta.t.dpcEvt.mask, mBuf, ELIT257, pst);
         CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, ELIT258, pst);
         break;
      
      case LIT_EVENT_ASP_DOWN:
      case LIT_EVENT_ASP_INACTIVE:
         /* it003.106 - Packing sctSuId */
         if (usta->hdr.elmId.elmnt == STITPSP)
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.aspm.sctSuId, mBuf, ELITXXX, 
                       pst);
            break;
         
         }
         /* else fall through */ 

      case LIT_EVENT_ASP_ACTIVE:
         if (usta->hdr.elmId.elmnt == STITPS)
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.psAspEvt.sctSuId, mBuf, ELIT259,
                       pst);
            CMCHKPKLOG(cmPkItPspId, usta->t.usta.t.psAspEvt.pspId, mBuf, 
                       ELIT260, pst);
         }
         break;
      case LIT_EVENT_RC_DELETED:
      case LIT_EVENT_RK_DEREGISTERED:
      case LIT_EVENT_RC_GENERATED: 
      case LIT_EVENT_DEREG_FAILURE: 
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.drkmEvt.sctSuId, mBuf, ELIT261,
                       pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT262, pst);
         }
         break;
      case LIT_EVENT_RK_REGISTERED:
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.drkmEvt.sctSuId, mBuf, ELIT263,
                       pst);
            CMCHKPKLOG(cmPkItPsId, usta->t.usta.t.drkmEvt.psId, mBuf, 
                       ELIT264, pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT265, pst);
            CMCHKPKLOG(cmPkItRouteKey, &(usta->t.usta.t.drkmEvt.rtKey), mBuf, 
                       ELIT266, pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT267, pst);
         }
         break;
      case LIT_EVENT_INV_LCLRKID:
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.drkmEvt.sctSuId, mBuf, ELIT268,
                       pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT269, pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT270, pst);
         }
         break;
      case LIT_EVENT_REG_FAILURE: 
         {
            CMCHKPKLOG(cmPkSuId, usta->t.usta.t.drkmEvt.sctSuId, mBuf, ELIT271,
                       pst);
            CMCHKPKLOG(SPkU32, usta->t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT272, pst);
         }
         break;
      case LIT_EVENT_M3UA_PROTO_ERROR:
         {
            switch (usta->t.usta.alarm.cause)
            {
               case LIT_CAUSE_DPC_STATUS_UNKNOWN:
               {
                  CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, 
                             ELIT273, pst);
               }
               default:
                 break;
            }
            /* it003.106 - Added break statement to prevent fallthrough */
            break;
         }

#ifdef LIT_RTE_ALARMS
      case LIT_EVENT_RTE_AVAIL:
      case LIT_EVENT_RTE_UNAVAIL:
         CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, ELIT274, pst);
         break;
#endif /* LIT_RTE_ALARMS */      

      /* it003.106 - Packed the missing fields. */
      case LIT_EVENT_ESTABLISH_OK:
      case LIT_EVENT_ESTABLISH_FAIL:
      case LIT_EVENT_SCT_COMM_DOWN:
      case LIT_EVENT_FLC_DROP:
      case LIT_EVENT_SCT_SEND_FAIL:
      case LIT_EVENT_ASPAC_FAIL:
      case LIT_EVENT_ASPIA_FAIL:
      case LIT_EVENT_ASPUP_FAIL:
      case LIT_EVENT_RK_TMOUT:
      case LIT_EVENT_SRCADDRLST_CHG:
      case LIT_EVENT_DSTADDRLST_CHG:
      case LIT_EVENT_PRIDSTADDR_CHG:
         CMCHKPKLOG(cmPkSuId, usta->t.usta.t.aspm.sctSuId, mBuf, ELITXXX, pst);
         break;

      /* it003.106 - Packed the missing fields. */
      case LIT_EVENT_NO_ROUTE_FOUND:
         CMCHKPKLOG(SPkU8, usta->t.usta.t.dpcEvt.p.servInd, mBuf, ELITXXX, pst);
         CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, ELITXXX, pst);
         break;

      /* it003.106 - Packed the missing fields. */
      case LIT_EVENT_DAUD_RXD:
         CMCHKPKLOG(cmPkDpc, usta->t.usta.t.dpcEvt.aPc, mBuf, ELITXXX, pst);
         break;

      /* it003.106 - Packed the missing fields. */
      case LIT_EVENT_PSP_REGD:
         CMCHKPKLOG(cmPkSuId, usta->t.usta.t.drkmEvt.sctSuId, mBuf, ELITXXX,
                       pst);
         CMCHKPKLOG(cmPkItPsId, usta->t.usta.t.drkmEvt.psId, mBuf, 
                       ELITXXX, pst);
         break;

   } /* End of switch on event */

   switch (usta->hdr.elmId.elmnt)
   {
      case STITNSAP:
         CMCHKPKLOG(cmPkSpId, usta->t.usta.s.spId, mBuf, ELIT275, pst);
         break;

      case STITSCTSAP:
         CMCHKPKLOG(cmPkSuId, usta->t.usta.s.suId, mBuf, ELIT276, pst);
         break;

      case STITPSP:
         CMCHKPKLOG(cmPkItPspId, usta->t.usta.s.pspId, mBuf, ELIT277, pst);
         break;

      case STITPS:
         CMCHKPKLOG(cmPkItPsId, usta->t.usta.s.psId, mBuf, ELIT278, pst);
         break;
      
      case STITNWK:
      case STITAPC:
         CMCHKPKLOG(SPkU8, usta->t.usta.s.nwkId, mBuf, ELIT279, pst);
         break;

#ifdef LIT_RTE_ALARMS
#ifdef SGVIEW
      case STITSG:
         CMCHKPKLOG(SPkU32, usta->t.usta.s.sgId, mBuf, ELIT280, pst);
         break;
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */

   }


   CMCHKPKLOG(cmPkCmAlarm, &usta->t.usta.alarm, mBuf, ELIT281, pst);
   CMCHKPKLOG(cmPkHeader, &usta->hdr, mBuf, ELIT282, pst);

   pst->event = (Event)EVTLITSTAIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitStaInd */


/* ***********************************************

      Unpacking Functions for Unsolicited Status Indication

   **************************************** */


/*
*
*       Fun:   cmUnpkLitStaInd
*
*       Desc:  This function unpacks the Unsolicited Status Indication
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitStaInd
(
LitStaInd                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitStaInd (func, pst, mBuf)
LitStaInd                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      usta;          /* M3UA Managment Structure */
   U16         idx;

   TRC2(cmUnpkLitStaInd)

   CMCHKUNPKLOG(cmUnpkHeader, &usta.hdr, mBuf, ELIT283, pst);
   CMCHKUNPKLOG(cmUnpkCmAlarm, &usta.t.usta.alarm, mBuf, ELIT284, pst);

   switch (usta.hdr.elmId.elmnt)
   {
      case STITNSAP:
         CMCHKUNPKLOG(cmUnpkSpId, &usta.t.usta.s.spId, mBuf, ELIT285, pst);
         break;

      case STITSCTSAP:
         CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.s.suId, mBuf, ELIT286, pst);
         break;

      case STITPSP:
         CMCHKUNPKLOG(cmUnpkItPspId, &usta.t.usta.s.pspId, mBuf, ELIT287, pst);
         break;

      case STITPS:
         CMCHKUNPKLOG(cmUnpkItPsId, &usta.t.usta.s.psId, mBuf, ELIT288, pst);
         break;
      
      case STITNWK:
      case STITAPC:
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.s.nwkId, mBuf, ELIT289, pst);
         break;
#ifdef LIT_RTE_ALARMS
#ifdef SGVIEW
      case STITSG:
         CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.s.sgId, mBuf, ELIT290, pst);
         break;
#endif /* SGVIEW */
#endif /* LIT_RTE_ALARMS */
   }

   switch (usta.t.usta.alarm.event)
   {
      case LIT_EVENT_ASPM:
         CMCHKUNPKLOG(SUnpkU16, &usta.t.usta.t.aspm.msgType, mBuf, ELIT291, 
                      pst);
         CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.aspm.sctSuId, mBuf, ELIT292,
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.aspm.tmType, mBuf, ELIT293, pst);

         for (idx = 0; idx < (LIT_MAX_INFO + 1); idx++)
         {
            CMCHKUNPKLOG(SUnpkS8, &usta.t.usta.t.aspm.info[idx], mBuf, ELIT294, 
                         pst);
         }
         
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.aspm.nmbPs, mBuf, ELIT295, pst);

         for (idx = 0; idx < usta.t.usta.t.aspm.nmbPs; idx++)
         {
            CMCHKUNPKLOG(cmUnpkItPsId, &usta.t.usta.t.aspm.psLst[idx], mBuf, 
                         ELIT296, pst);
         }

         break;

      case LIT_EVENT_NOTIFY:
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.ntfy.stType, mBuf, ELIT297, pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.ntfy.stInfo, mBuf, ELIT298, pst);

         for (idx = 0; idx < (LIT_MAX_INFO + 1); idx++)
         {
            CMCHKUNPKLOG(SUnpkS8, &usta.t.usta.t.ntfy.info[idx], mBuf, ELIT299, 
                         pst);
         }
         
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.ntfy.nmbPs, mBuf, ELIT300, pst);

         for (idx = 0; idx < usta.t.usta.t.ntfy.nmbPs; idx++)
         {
            CMCHKUNPKLOG(cmUnpkItPsId, &usta.t.usta.t.ntfy.psLst[idx], mBuf, 
                         ELIT301, pst);
         }
         CMCHKUNPKLOG(cmUnpkBool, &usta.t.usta.t.ntfy.aspIdPres, mBuf,
                      ELIT302, pst);
         CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.ntfy.aspId, mBuf, ELIT303, pst);
         CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.ntfy.sctSuId, mBuf, ELIT304,
                      pst);
         break;

      case LIT_EVENT_PC_AVAILABLE:
      case LIT_EVENT_PC_UNAVAILABLE:
      case LIT_EVENT_PC_CONGESTED:
      case LIT_EVENT_PC_RESTRICTED:
         CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, mBuf, ELIT305, pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.dpcEvt.mask, mBuf, ELIT306, 
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.dpcEvt.p.congLevel, mBuf, ELIT307,
                      pst);
         break;

      case LIT_EVENT_PC_USER_PART_UNA:
         CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, mBuf, ELIT308, pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.dpcEvt.mask, mBuf, ELIT309, 
                      pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.dpcEvt.p.servInd, mBuf, ELIT310, 
                      pst);
         break;

      case LIT_EVENT_ASP_DOWN:
      case LIT_EVENT_ASP_INACTIVE:
         /* it003.106 - Unpacking sctSuId */
         if (usta.hdr.elmId.elmnt == STITPSP)
         {
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.aspm.sctSuId, mBuf, 
                         ELITXXX, pst);
            break;
         
         }
         /* else fall through */ 

      case LIT_EVENT_ASP_ACTIVE:
         if (usta.hdr.elmId.elmnt == STITPS)
         {
            CMCHKUNPKLOG(cmUnpkItPspId, &usta.t.usta.t.psAspEvt.pspId, mBuf, 
                         ELIT311, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.psAspEvt.sctSuId, mBuf, 
                         ELIT312, pst);
         }
         break;
      /* DRKM Events */
      case LIT_EVENT_RC_DELETED:
      case LIT_EVENT_RK_DEREGISTERED:
      case LIT_EVENT_RC_GENERATED: 
      case LIT_EVENT_DEREG_FAILURE: 
         {
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT313, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.drkmEvt.sctSuId, mBuf, 
                         ELIT314, pst);
         }
         break;
      case LIT_EVENT_RK_REGISTERED:
         {
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT315, pst);
            CMCHKUNPKLOG(cmUnpkItRouteKey, &usta.t.usta.t.drkmEvt.rtKey, mBuf, 
                       ELIT316, pst);
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT317, pst);
            CMCHKUNPKLOG(cmUnpkItPsId, &usta.t.usta.t.drkmEvt.psId, mBuf, 
                       ELIT318, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.drkmEvt.sctSuId, mBuf, 
                         ELIT319, pst);
         }
         break;
      case LIT_EVENT_INV_LCLRKID:
         {
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.rteCtx, mBuf, 
                       ELIT320, pst);
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT321, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.drkmEvt.sctSuId, mBuf, 
                         ELIT322, pst);
         }
         break;
      case LIT_EVENT_REG_FAILURE: 
         {
            CMCHKUNPKLOG(SUnpkU32, &usta.t.usta.t.drkmEvt.lclRkId, mBuf, 
                       ELIT323, pst);
            CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.drkmEvt.sctSuId, mBuf, 
                         ELIT324, pst);
         }
         break;
      case LIT_EVENT_M3UA_PROTO_ERROR:
         {
            switch (usta.t.usta.alarm.cause)
            {
               case LIT_CAUSE_DPC_STATUS_UNKNOWN:
               {

                  CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, 
                               mBuf, ELIT325, pst);
               }
               default:
                 break;
            }
            /* it003.106 - Added break statement to prevent fallthrough */
            break;
         }

#ifdef LIT_RTE_ALARMS
      case LIT_EVENT_RTE_AVAIL:
      case LIT_EVENT_RTE_UNAVAIL:
         CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, mBuf, ELIT326, pst);
         break;
#endif /* LIT_RTE_ALARMS */

      /* it003.106 - Unpacked the missing fields. */
      case LIT_EVENT_ESTABLISH_OK:
      case LIT_EVENT_ESTABLISH_FAIL:
      case LIT_EVENT_SCT_COMM_DOWN:
      case LIT_EVENT_FLC_DROP:
      case LIT_EVENT_SCT_SEND_FAIL:
      case LIT_EVENT_ASPAC_FAIL:
      case LIT_EVENT_ASPIA_FAIL:
      case LIT_EVENT_ASPUP_FAIL:
      case LIT_EVENT_RK_TMOUT:
      case LIT_EVENT_SRCADDRLST_CHG:
      case LIT_EVENT_DSTADDRLST_CHG:
      case LIT_EVENT_PRIDSTADDR_CHG:
         CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.aspm.sctSuId, mBuf, ELITXXX,
                      pst);
         break;

      /* it003.106 - Unpacked the missing fields. */
      case LIT_EVENT_NO_ROUTE_FOUND:
         CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, mBuf, ELITXXX, pst);
         CMCHKUNPKLOG(SUnpkU8, &usta.t.usta.t.dpcEvt.p.servInd, mBuf, ELITXXX, 
                      pst);
         break;

      /* it003.106 - Unpacked the missing fields. */
      case LIT_EVENT_DAUD_RXD:
         CMCHKUNPKLOG(cmUnpkDpc, &usta.t.usta.t.dpcEvt.aPc, mBuf, ELITXXX, pst);
         break;

      /* it003.106 - Unpacked the missing fields. */
      case LIT_EVENT_PSP_REGD:
         CMCHKUNPKLOG(cmUnpkItPsId, &usta.t.usta.t.drkmEvt.psId, mBuf, 
                      ELITXXX, pst);
         CMCHKUNPKLOG(cmUnpkSuId, &usta.t.usta.t.drkmEvt.sctSuId, mBuf, 
                      ELITXXX, pst);
         break;

   } /* End of switch on event */

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &usta));
}   /* cmUnpkLitStaInd */


/*************************************************

      Packing Functions for Trace Indication

**************************************************/


/*
*
*       Fun:   cmPkLitTrcInd
*
*       Desc:  This function packs the Trace Indication
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLitTrcInd
(
Pst                      *pst,         /* Post Structure */
ItMgmt                   *trc         /* Alarm */
)
#else
PUBLIC S16 cmPkLitTrcInd (pst, trc)
Pst                      *pst;         /* Post Structure */
ItMgmt                   *trc;        /* Alarm */
#endif
{
   Buffer       *mBuf;
   U16           idx;

   TRC2(cmPkLitTrcInd)

   LIT_GETMSG(pst, mBuf, ELIT327);

   if (trc->t.trc.len > LIT_MAX_TRC_LEN)
   {
      trc->t.trc.len = LIT_MAX_TRC_LEN - 1;
   }

   for (idx = trc->t.trc.len; idx > 0; idx--)
   {
      CMCHKPKLOG(SPkU8, trc->t.trc.evntParm[idx-1], mBuf, ELIT328, pst);
   }

   CMCHKPKLOG(SPkU32, trc->t.trc.msgType, mBuf, ELIT329, pst); 
   CMCHKPKLOG(SPkU16, trc->t.trc.len, mBuf, ELIT330, pst);
   CMCHKPKLOG(SPkU16, trc->t.trc.evnt, mBuf, ELIT331, pst);
   CMCHKPKLOG(cmPkSuId, trc->t.trc.suId, mBuf, ELIT332, pst);
   CMCHKPKLOG(cmPkDateTime, &trc->t.trc.dt, mBuf, ELIT333, pst);
   CMCHKPKLOG(cmPkHeader, &trc->hdr, mBuf, ELIT334, pst);

   pst->event = (Event)EVTLITTRCIND; /* event */

   (Void)SPstTsk(pst, mBuf);

   RETVALUE(ROK);
}   /* cmPkLitTrcInd */


/* ***********************************************

      Unpacking Functions for Trace Indication

   **************************************** */


/*
*
*       Fun:   cmUnpkLitTrcInd
*
*       Desc:  This function unpacks the Trace Indication
*
*       Ret:   ROK
*
*       Notes: None
*
*       File:  lit.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLitTrcInd
(
LitTrcInd                 func,        /* Layer function to be called back */
Pst                      *pst,         /* Post Structure */
Buffer                   *mBuf         /* Message Buffer */
)
#else
PUBLIC S16 cmUnpkLitTrcInd (func, pst, mBuf)
LitTrcInd                 func;        /* Layer function to be called back */
Pst                      *pst;         /* Post Structure */
Buffer                   *mBuf;        /* Message Buffer */
#endif
{
   ItMgmt      trc;          /* M3UA Managment Structure */
   U16         idx;

   TRC2(cmUnpkLitTrcInd)

   CMCHKUNPKLOG(cmUnpkHeader, &trc.hdr, mBuf, ELIT335, pst);
   CMCHKUNPKLOG(cmUnpkDateTime, &trc.t.trc.dt, mBuf, ELIT336, pst);
   CMCHKUNPKLOG(cmUnpkSuId, &trc.t.trc.suId, mBuf, ELIT337, pst);
   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.evnt, mBuf, ELIT338, pst);
   CMCHKUNPKLOG(SUnpkU16, &trc.t.trc.len, mBuf, ELIT339, pst);
   CMCHKUNPKLOG(SUnpkU32, &trc.t.trc.msgType, mBuf, ELIT340, pst);

   for (idx = 0; idx < trc.t.trc.len; idx++)
   {
      CMCHKUNPKLOG(SUnpkU8, &trc.t.trc.evntParm[idx], mBuf, ELIT341, pst);
   }

   (Void)SPutMsg(mBuf);

   RETVALUE((*func)(pst, &trc));
}   /* cmUnpkLitTrcInd */

#endif /* LCLIT */


/********************************************************************30**

         End of file:     lit.c@@/main/7 - Thu Apr  1 03:50:12 2004

*********************************************************************31*/


/********************************************************************40**

        Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

        Revision history:

*********************************************************************61*/

/********************************************************************80**

*********************************************************************81*/

/********************************************************************90**

     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
/main/3      ---      nj   1. initial release.
/main/3      ---      nt   1. 'Defined but not used' warnings removed.
             ---      mrw  2. Updates to Release 1.2
/main/4      ---      sg   1. Routing, IPSP and Loadshare changes.
             ---      sg   2. Update to Release 1.3
/main/5      ---      sg   1. Update to Release 1.4
/main/5    it001.104  sg   1. Changes for Outgoing Message Routing based on
                              Local PS status at ASP/IPSP.
           it001.104  vt   2. Changes for new PSP config parameter,cfgForAllLps.
/main/5    it002.104  sg   1. Changes for SG Id, DPC Mask in ItUsta and 
                              cfgForAllLps.
/main/5    it003.104  cg   1. Added case for LIT_EVENT_ASP_ACTIVE in function
                              cmPkLitStaInd
/main/5    it004.104  cg   1. Added case for LIT_EVENT_ASP_ACTIVE in function
                              cmUnpkLitStaInd
                           2. Corrected function cmUnpkLitTrcInd for trc element 
            it007.104 cg   1. In cmPkLitCntrlCfm added code for rk pack
                           2. In cmUnpkLitCntrlCfm  added code for rk unPack
/main/5    it013.104  vt   1  it013.104 RC parameter has to be unpacked/unpacked                              in RC_DELETED as well

/main/5    it014.104  vt   1  it014.104 added to correctly send statistics to LM
/main/5    it018.104  vt   1  Packing/unpacking for some left out parameters 
                           2  Changes for Aborting an association 
/main/5    it022.104  uv   1  Packing/Unpacking for rte_alarm events 
                              and sgId
/main/6      ---      nt   1. Update to Release 1.5
/main/7      ---      rs   1. Update to release 1.6.
/main/7    it002.106  sg   1. Changes for packing and unpacking sctSuId for 
                              ItMiLitStaReq.
/main/7    it003.106  sg   1. Changes for packing and unpacking missing fields
                              for Unsolicited Status Indication.
/main/7    it009.106  sg   1. Added packing and unpacking of TOS param in 
                              ItAssocCfg.
/main/7    it011.106  sg   1. Changes for making the TOS parameter support 
                              RUG compliant.
lit_c_001.main_7      sg   1. Changes for packing and unpacking of association 
                              unavailability and congestion statistics for LIT 
                              interface version LITV3.
lit_c_002.main_7      sg   1. Changes for packing and unpacking of srcAddrLst 
                              in SCT SAP and ItSstaPs structure in Solicited 
                              status confirm for LIT interface version LITV4.
lit_c_003.main_7      sg   1. Changes for packing and unpacking of abrtFlag
                              for PSP Deletion control request for LIT
                              interface version LITV5.
lit_c_004.main_7      sg   1. Changes for packing and unpacking of PS
                              statistics under compilation flag LITV6.
*********************************************************************91*/
