/********************************************************************16**

                         (c) COPYRIGHT 1989-2003 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/

/********************************************************************20**

     Name:     common TCAP user PSF module function

     Type:     C include file

     Desc:     Structures, variables and typedefs required by the
               fault tolerant TCAP user.

     File:     cm_tupsf.c
  
     Sid:      cm_tupsf.c@@/main/3 - Fri Dec 10 17:55:22 2004
 
     Prg:      jz

*********************************************************************21*/

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */
  
#include "gen.h"           /* general */
#include "ssi.h"           /* system services */
#include "cm5.h"
#include "cm_ss7.h"        /* common ss7 */
#include "cm_err.h"        /* common error */
#include "cm_ftha.h"
#include "mrs.h"
#include "sht.h"
#include "cm_pftha.h"      /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#include "cm_tupsf.h"      /* common PSF */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm5.x"
#include "cm_ss7.x"        /* common SS7 Specific */
#include "cm_lib.x"        /* common SS7 Specific */
#include "cm_ftha.x"
#include "mrs.x"
#include "sht.x"
#include "cm_pftha.x"      /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#include "cm_tupsf.x"      /* common PSF */


/********************************************************************20**
  Initialization functions
*********************************************************************21*/


/*
 *
 *      Fun:   cmTuActvInit
 *
 *      Desc:  Initialization function for MAP PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef SS_MULTIPLE_PROCS
#ifdef ANSI
PUBLIC S16 cmTuActvInit
(
ProcId      proc, 
CmTuCb      *tuCb,              /* PSF control block */
Ent         entity,             /* entity        */
Inst        inst,               /* instance      */
Region      region,             /* memory region */
Reason      reason,              /* reason        */
Void        **xxCb
)
#else
PUBLIC S16 cmTuActvInit (proc, tuCb, entity, inst, region, reason,xxCb)
ProcId      proc;
CmTuCb      *tuCb;              /* PSF control block */
Ent         entity;             /* entity        */
Inst        inst;               /* instance      */
Region      region;             /* memory region */
Reason      reason;             /* reason        */
Void        **xxCb;
#endif
#else
#ifdef ANSI
PUBLIC S16 cmTuActvInit
(
CmTuCb      *tuCb,              /* PSF control block */
Ent         entity,             /* entity        */
Inst        inst,               /* instance      */
Region      region,             /* memory region */
Reason      reason              /* reason        */
)
#else
PUBLIC S16 cmTuActvInit (tuCb, entity, inst, region, reason)
CmTuCb      *tuCb;              /* PSF control block */
Ent         entity;             /* entity        */
Inst        inst;               /* instance      */
Region      region;             /* memory region */
Reason      reason;             /* reason        */
#endif
#endif
{
   U16          i;            /* counter   */
#ifdef SS_MULTIPLE_PROCS
   UNUSED(xxCb);
#endif

   TRC3 (cmTuActvInit)
 
   /* initialize init structure */
#ifdef SS_MULTIPLE_PROCS
   tuCb->init.procId  = proc;
#else
   tuCb->init.procId  = SFndProcId();
#endif
   tuCb->init.ent     = entity;
   tuCb->init.inst    = inst;
   tuCb->init.region  = region;
   tuCb->init.reason  = reason;
   tuCb->init.cfgDone = FALSE;
   tuCb->init.usta    = FALSE;
   tuCb->init.trc     = FALSE;

   tuCb->peerPst.dstProcId = 0;   
   tuCb->peerPst.dstEnt    = tuCb->init.ent;
   tuCb->peerPst.dstInst   = tuCb->init.inst;
   tuCb->peerPst.srcProcId = tuCb->init.procId;   
   tuCb->peerPst.srcEnt    = tuCb->init.ent;   
   tuCb->peerPst.srcInst   = tuCb->init.inst;   
   tuCb->peerPst.selector  = SEL_LC_NEW;     

   /* Init the selfPst structure */
   tuCb->selfPst.dstProcId = tuCb->init.procId;
   tuCb->selfPst.dstEnt    = tuCb->init.ent;  
   tuCb->selfPst.dstInst   = tuCb->init.inst;
   tuCb->selfPst.route     = RTESPEC; 
   tuCb->selfPst.prior     = PRIOR0;  
   tuCb->selfPst.srcProcId = tuCb->init.procId;   
   tuCb->selfPst.srcEnt    = tuCb->init.ent;   
   tuCb->selfPst.srcInst   = tuCb->init.inst;   
   tuCb->selfPst.selector  = SEL_LC_NEW;     

   tuCb->rsetCbLst             = NULLP;
   
   /* initialize timers */
   tuCb->tqCp.tmrLen = CMTUNUMENT;
   
   for (i = 0; i < CMTUNUMENT; i++)
   {
      tuCb->tq[i].first = (CmTimer *)NULLP;
      tuCb->tq[i].tail = (CmTimer *)NULLP;
   }

   /* Initialize system Id */
   tuCb->fn.tuGetSId(&tuCb->sysId);

   RETVALUE(ROK);
   
} /* cmTuActvInit */


/*
 *
 *      Fun:   cmTuInitRsetCb
 *
 *      Desc:  Initialize the resource set control block.
 *
 *      Ret:   Void
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuInitRsetCb
(
CmTuCb             *tuCb,     /* PSF control block */
CmFthaRsetId       id,        /* Rset Id            */
PTR                rsetCbP    /* pointer to rset Cb */  
)
#else
PUBLIC Void cmTuInitRsetCb (tuCb, id, rsetCbP)
CmTuCb             *tuCb;     /* PSF control block */
CmFthaRsetId       id;        /* Rset Id            */
PTR                rsetCbP;   /* pointer to rset Cb */  
#endif
{
   CmTuRsetCb    *rsetCb;

   TRC2 (cmTuInitRsetCb);


   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuInitRsetCb() : id = %d\n",id));
  
   rsetCb = (CmTuRsetCb *)rsetCbP;
    
   cmMemset ((U8 *)rsetCb,(U8) 0, sizeof (*rsetCb));

   rsetCb->acceptRTMsg     = FALSE; 
   rsetCb->rsetId          = id;
   rsetCb->state           = CMPFTHA_STATE_OOS;
   rsetCb->peerState       = CMPFTHA_PEER_DEAD;
   rsetCb->updState        = CMPFTHA_US_IDLE;
   rsetCb->cbHead          = NULLP;
   rsetCb->cbTail          = NULLP;
   rsetCb->nmbDlgMap       = 0;
   rsetCb->dlgCp           = NULLP;
   rsetCb->lastDlg.lastUpdHlEnt    = NULLP;
   rsetCb->lastDlg.currBin         = 0;
   rsetCb->lastInv.lastUpdHlEnt    = NULLP;
   rsetCb->lastInv.currBin         = 0;
   
   SInitQueue (&rsetCb->rtUpdHoldQ);
   SInitQueue (&rsetCb->tmrQ);
   /* record how many references from the resource set */
   if(rsetCb != (CmTuRsetCb *) NULLP)
   { 
      if(tuCb->rsetCbLst[id] == (CmTuRsetCb *)NULLP)
      {
         tuCb->rsetCbLst[id] = (CmTuRsetCb *)rsetCbP;
      }
   }      
   
   cmInitTimers (rsetCb->timer, CMTU_MAX_RSET_TMRS);
   
   RETVOID;
} /* cmTuInitRsetCb */

 
/*
 *
 *      Fun:   cmTuInitUpdStruct
 *
 *      Desc:  This function initializes the shared update data structure 
 *             to null values for a reource set.
 *
 *      Ret:   RETVOID
 *
 *      Notes: FIXIT - Check the semantic regarding critical resource set.
 *
 *      File:  cmTu_util.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuInitUpdStruct
(
CmTuCb              *tuCb,       /* PSF control block */
CmFthaRsetId        rsetId       /* Resource set Id */
)
#else
PUBLIC Void cmTuInitUpdStruct (tuCb, rsetId)
CmTuCb              *tuCb;       /* PSF control block */
CmFthaRsetId        rsetId;      /* Resource set Id */
#endif
{
   CmTuRsetCb       *rsetCb;    /* pointer to resource set Cb */
   U16              i;          /* index                      */

   TRC2 (cmTuInitUpdStruct)

   rsetCb = tuCb->rsetCbLst[rsetId];
   
   rsetCb->upd.updReq     = FALSE;

   rsetCb->upd.rsetCb.updReq = FALSE;
   rsetCb->upd.rsetCb.action = 0;
   rsetCb->upd.rsetCb.cb     = NULLP;

   rsetCb->upd.uiSap.size = 0;

   for (i = 0; i < CMTU_MAX_SAP_UPD_ENT; i++)
   {
      rsetCb->upd.uiSap.s[i].updReq = FALSE;
      rsetCb->upd.uiSap.s[i].action = 0;
      rsetCb->upd.uiSap.s[i].cb     = NULLP;
   }

   rsetCb->upd.liSap.size = 0;

   for (i = 0; i < CMTU_MAX_SAP_UPD_ENT; i++)
   {
      rsetCb->upd.liSap.s[i].updReq = FALSE;
      rsetCb->upd.liSap.s[i].action = 0;
      rsetCb->upd.liSap.s[i].cb     = NULLP;
   }

   rsetCb->upd.dlg.size = 0;

   for (i = 0; i < CMTU_MAX_DLG_UPD_ENT; i++)
   {
      rsetCb->upd.dlg.s[i].updReq = FALSE;
      rsetCb->upd.dlg.s[i].action = 0;
      rsetCb->upd.dlg.s[i].cb     = NULLP;
   }

   rsetCb->upd.inv.size   = 0;

   for (i = 0; i < CMTU_MAX_SAP_UPD_ENT; i++)
   {
      rsetCb->upd.inv.s[i].updReq = FALSE;
      rsetCb->upd.inv.s[i].action = 0;
      rsetCb->upd.inv.s[i].cb     = NULLP;
   }

#ifdef TDS_ROLL_UPGRADE_SUPPORT
   rsetCb->upd.verInfoCb.updReq = FALSE;
   rsetCb->upd.verInfoCb.cb.action = 0;
#endif

   RETVOID;
   
} /* cmTuInitUpdStruct */

/********************************************************************20**
  SM/SH interface functions
*********************************************************************21*/

/*
 *
 *      Fun:   cmTuProcShCntrl
 *
 *      Desc:  Process cntrl request from SH
 *
 *      Ret:   ROK     - successful,
 *
 *      Notes: 
 *
 *      File:  cmTu_bdy3.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuProcShCntrl
(
CmTuCb    *tuCb,              /* PSF control block */
Pst       *pst,               /* post */
CmTuMngmt *cntrlOrg           /* control structure*/
)
#else
PUBLIC S16 cmTuProcShCntrl(tuCb, pst, cntrlOrg)
CmTuCb    *tuCb;              /* PSF control block */
Pst       *pst;               /* post */
CmTuMngmt *cntrlOrg;          /* control structure */
#endif
{
   Pst           repPst;   /* Reply Post structure */
   CmTuMngmt     cntrl;    /* Management structure */
   CmFthaRsetId  rsetId;   /* Resource set Id */
   U16           reason;   /* Reason */

   TRC3 (cmTuProcShCntrl);

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuProcShCntrl() : action = %d\n",cntrlOrg->t.shCntrl.action));

   /* make a copy of the original structure */
   cmCopy ((U8 *)cntrlOrg, (U8 *)&cntrl, sizeof (CmTuMngmt));
   cntrl.cfm.status = LCM_PRIM_OK;
   cntrl.cfm.reason = LCM_REASON_NOT_APPL;

   cmTuBldReplyPst(tuCb, &repPst, &cntrl.hdr, pst);

   if ((tuCb->fn.tuChkCfg() != ROK) || (!tuCb->init.cfgDone))
   {
      reason = LCM_REASON_PRTLYRCFG_NOT_DONE;
      CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) reason,
                "cmTuProcShCntrl() : control request failed, cfg is incomplete");
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr,LCM_PRIM_NOK, reason);
      RETVALUE (ROK);
   }  
      
   reason = LCM_REASON_NOT_APPL;
   rsetId = cntrl.t.shCntrl.t.rsetPar.rsetId;

   if (cmTuCheckRetry (tuCb, cntrl.hdr.transId) == TRUE)
   {
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &tuCb->lastCfm.cfm.hdr,
                        tuCb->lastCfm.cfm.cfm.status, 
                        tuCb->lastCfm.cfm.cfm.reason);
      RETVALUE (ROK);
   }

   if ((reason = cmTuValidateShCntrl (tuCb, &cntrl)) != LCM_REASON_NOT_APPL)
   {
      CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) reason,
                "cmTuProcShCntrl() : control request failed");
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr,LCM_PRIM_NOK, reason);
      RETVALUE (ROK);
   }

   /* process the request */
   switch (cntrl.t.shCntrl.action)
   {
      case CMTU_AGO_ACT: 
      {                
         if ((reason = cmTuGoAct(tuCb, rsetId, 
              &cntrl.t.shCntrl.t.rsetPar.t.ga)) != CMTU_OK)
         {
            CMTULOGERROR_INT_PAR(ECMTU098, (ErrVal)rsetId,
               "cmTuProcShCntrl() : cmTuGoAct Failed");
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr,LCM_PRIM_NOK, 
                              CMTU_REASON_INT_FAILURE); 
            RETVALUE (ROK);
         }

         break;
      }
      case CMTU_AGO_SBY:  
      {
         if ((reason = cmTuGoSby(tuCb, rsetId, 
              &cntrl.t.shCntrl.t.rsetPar.t.gs)) != CMTU_OK) 
         {
            CMTULOGERROR_INT_PAR(ECMTU099,(ErrVal)rsetId,
                  "cmTuProcShCntrl() : cmTuGoSby Failed");
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                              LCM_PRIM_NOK, CMTU_REASON_INT_FAILURE); 
            RETVALUE (ROK);
         }

         break;
      }/* standby case */
      case CMTU_ASHUTDOWN: /* make the resource set OUT OF SERVICE */
      {
         cmTuGoOOS(tuCb, rsetId);

         break;   
      }
      case CMTU_AWARMSTART:        
      {
         /* Check if the operation is in progress */
         if (tuCb->pendOp.flag == TRUE)
         {  
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                              LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL);      
            RETVALUE (ROK);
         }

         /*
         ** Initialize the pending operation structure.  It is
         ** also used when we abort a operation. 
         */ 
         tuCb->pendOp.flag    = TRUE;  
         tuCb->pendOp.action  = cntrl.t.shCntrl.action;
         /* copying the reply post for deferred control confirms */
         cmMemcpy((U8 *)&tuCb->defLmPst,(U8 *)&repPst,sizeof(Pst));
         cmCopy ((U8 *)pst, (U8 *)&tuCb->pendOp.pst, sizeof (Pst));
         cmCopy ((U8 *)&cntrl.hdr,(U8 *)&tuCb->pendOp.hdr, sizeof (Header));

         /* Send the inital confirm */
         tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                           LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL);
               
         /* Start the work  */
         /* Do the preprocessing for SAMEPROC */

         /* No preprocessing (like in Peersync) is needed for Warmstart. */
         /* Start the updates */
         {
            reason = cmTuWarmStart(tuCb, rsetId);

            switch (reason)
            {
               case CMTU_PEND:
               {
                  tuCb->pendOp.flag = TRUE;  
                  cmTuPostContMsg (tuCb); 
                  RETVALUE (ROK);
               }
               case CMTU_ERR:
               {
                  cmTuAbortCurOp(tuCb, rsetId, &tuCb->pendOp); 
                  CMTULOGERROR_INT_PAR(ECMTU100, (ErrVal)rsetId,
                      "cmTuProcShCntrl() : cmTuWarmStart Failed");
                  tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                                    LCM_PRIM_NOK, CMTU_REASON_INT_FAILURE);
                  RETVALUE (ROK);
               }
               case CMTU_OK:
               {
                 break;
               }
            }/* switch */
         }/* for */
         /* return here to avoid sending Cfm in the end */
         RETVALUE (ROK);
      }
      case CMTU_ASYNCHRONIZE:
      {
         /* Check if the operation is in progress */
         if (tuCb->pendOp.flag == TRUE)
         {  
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                              LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL);      
            RETVALUE (ROK);
         }

         /*
         ** Initialize the pending operation structure.  It is
         ** also used when we abort a operation. The pendOp will
         ** always be true because we will be waiting for ACKs.
         */
         tuCb->pendOp.flag    = TRUE;  
         tuCb->pendOp.action  = cntrl.t.shCntrl.action;
         /* copying the reply post for deferred control confirms */
         cmMemcpy((U8 *)&tuCb->defLmPst,(U8 *)&repPst,sizeof(Pst));
         cmCopy ((U8 *)pst, (U8 *)&tuCb->pendOp.pst, sizeof (Pst));
         cmCopy ((U8 *)&cntrl.hdr,(U8 *)&tuCb->pendOp.hdr,sizeof (Header));

         /* Send the inital confirm */
         tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                           LCM_PRIM_OK_NDONE, LCM_REASON_NOT_APPL);
         /* Start the works */
         /* Start the updates */

         reason = cmTuSynchronize(tuCb, rsetId);

         switch (reason)
         {
            case CMTU_PEND:
            {
               tuCb->pendOp.flag = TRUE;
               cmTuPostContMsg (tuCb); 
               RETVALUE (ROK);
            } 
            case CMTU_ERR:
            {
               cmTuAbortCurOp(tuCb, rsetId, &tuCb->pendOp); 
               CMTULOGERROR_INT_PAR(ECMTU101, (ErrVal)rsetId,
               "cmTuProcShCntrl() : cmTuSynchronize Failed");
               tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                                 LCM_PRIM_NOK, CMTU_REASON_INT_FAILURE);
               RETVALUE (ROK);
            } 
            case CMTU_OK:
            {
               break;
            } 
         }

         /* return here to avoid sending Cfm in the end */
         RETVALUE (ROK);
      }
      case CMTU_ADIS_PEER_SAP:
      {

         tuCb->rsetCbLst[rsetId]->peerState = CMPFTHA_PEER_DEAD;
         break;
      }
      case CMTU_AABORT:                /* abort warmstart/controlled sw */
      {
         if (tuCb->pendOp.flag == TRUE)
         {
            cmTuAbortCurOp(tuCb, CMFTHA_RES_RSETID, &tuCb->pendOp); 
         }
         else
         {
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, 
                              LCM_PRIM_NOK, LCM_REASON_INVALID_STATE); 
            RETVALUE(ROK);
         }
         break;
      }
      default:
      {
         /* Will never come here */      
         RETVALUE(RFAILED);
      }
   } /* end switch */
   
   tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);

   RETVALUE (ROK);
}/* cmTuProcShCntrl*/


/*
 *
 *      Fun:   cmTuProcSmCntrl
 *
 *      Desc:  Process cntrl request from SM
 *
 *      Ret:   ROK     - successful,
 *
 *      Notes: 
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuProcSmCntrl
(
CmTuCb    *tuCb,              /* PSF control block */
Pst       *pst,               /* post */
CmTuMngmt *cntrlOrg           /* control structure*/
)
#else
PUBLIC S16 cmTuProcSmCntrl(tuCb, pst, cntrlOrg)
CmTuCb    *tuCb;              /* PSF control block */
Pst       *pst;               /* post */
CmTuMngmt *cntrlOrg;          /* control structure */
#endif
{
   Pst       repPst;   /* reply post */
   CmTuMngmt cntrl;    /* management structure */
   U16       reason;   /* reason */

   TRC3 (cmTuProcSmCntrl);

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuProcSmCntrl() : action = %d\n",cntrlOrg->t.cntrl.action));

   /* make a copy of the original structure.. */
   cmCopy ((U8 *)cntrlOrg, (U8 *)&cntrl, sizeof (CmTuMngmt));

   cntrl.cfm.status = LCM_PRIM_OK;
   cntrl.cfm.reason = LCM_REASON_NOT_APPL;

   cmTuBldReplyPst(tuCb, &repPst, &cntrl.hdr, pst);
   reason = LCM_REASON_NOT_APPL;

   if ((tuCb->fn.tuChkCfg() != ROK) || (!tuCb->init.cfgDone))
   {
      reason = LCM_REASON_PRTLYRCFG_NOT_DONE;
      CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) reason,
                "cmTuProcShCntrl() : control request failed, cfg is incomplete");
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr,LCM_PRIM_NOK, reason);
      RETVALUE (ROK);
   }  

   if ((reason = cmTuValidateSmCntrl (tuCb, &cntrl)) != LCM_REASON_NOT_APPL)
   {
      CMTULOGERROR_INT_PAR(ECMTU104, (ErrVal) 0,
                              "cmTuProcSmCntrl() : control request failed");
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, LCM_PRIM_NOK, reason);      
      RETVALUE (ROK);
   }

   switch(cntrl.hdr.elmId.elmnt)
   {
      case CMTUGEN:
         switch (cntrl.t.cntrl.action) 
         {
            case CMTU_ADISIMM:  
            {
               if (cntrl.t.cntrl.subAction == CMTU_SAUSTA)
               {
                  tuCb->init.usta = FALSE;
                  cmTuRunTimeUpd(tuCb, CMTU_PSF_CB, 
                                 CMPFTHA_UPDTYPE_NORMAL,
                                 CMPFTHA_ACTN_MOD, (Void *)tuCb);

               }
#ifdef DEBUGP
               else if (cntrl.t.cntrl.subAction == CMTU_SADBG)
               {
                  tuCb->init.dbgMask &= ~cntrl.t.cntrl.t.dbg.mask;
               }
#endif /* DEBUGP */
               else if (cntrl.t.cntrl.subAction == CMTU_SATRC)
               {
                  tuCb->rsetCbLst[CMFTHA_RES_RSETID]->trc = FALSE;
               }
               break;
            }
            case CMTU_AENA:  
            {
               if (cntrl.t.cntrl.subAction == CMTU_SAUSTA)
               {
                  tuCb->init.usta = TRUE;
                  cmTuRunTimeUpd(tuCb, CMTU_PSF_CB, 
                                 CMPFTHA_UPDTYPE_NORMAL,
                                 CMPFTHA_ACTN_MOD, (Void *)tuCb);
               }
#ifdef DEBUGP
               else if (cntrl.t.cntrl.subAction == CMTU_SADBG)
               {
                  tuCb->init.dbgMask |= cntrl.t.cntrl.t.dbg.mask;
               }
#endif /* DEBUGP */
               else if (cntrl.t.cntrl.subAction == CMTU_SATRC)
               {
                  tuCb->rsetCbLst[CMFTHA_RES_RSETID]->trc = TRUE;
               }                        
               break;
            }
            case CMTU_ASHUTDOWN:
            {
               cmTuShutDown(tuCb);
               break;
            }
            default:
            {
               /* control will never hit here becos of validation */
               break;
            }
         }
         break;

   }

   tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &cntrl.hdr, LCM_PRIM_OK, LCM_REASON_NOT_APPL);
   RETVALUE (ROK);
} /* cmTuProcSmCntrl */


/*
 *
 *      Fun:   cmTuGetRsetSta
 *
 *      Desc:  get the resource set status
 *
 *      Ret:   ROK
 *             
 *      Notes: 
 *
 *      File:  cm_tupsf.c
 * 
 */
#ifdef ANSI
PUBLIC S16 cmTuGetRsetSta 
(
CmTuCb           *tuCb,         /* PSF control block */
CmFthaRsetId     rsetId,        /* Resource set Id  */
CmTuRsetSta      *sta,          /* Status structure */
CmIntfVer        pifVer         /* peer interface version number supported  */
)
#else
PUBLIC S16 cmTuGetRsetSta (tuCb, rsetId, sta, pifVer)
CmTuCb           *tuCb;         /* PSF control block */
CmFthaRsetId     rsetId;        /* Resource set Id  */
CmTuRsetSta      *sta;          /* Status structure */
CmIntfVer        pifVer;        /* peer interface version number supported  */
#endif
{
   CmTuRsetCb    *rsetCb; /* resource set control block */

   TRC2 (cmTuGetRsetSta)
   
   rsetCb = tuCb->rsetCbLst[rsetId];

   if (NULLP == (CmTuRsetCb *)rsetCb)
   {
         CMTULOGERROR_INT_PAR( ECMTU118, (ErrVal)rsetId,
                        "cmTuGetRsetSta: Invalid resource set Id");

      RETVALUE (RFAILED);
   }
   sta->rsetId        = rsetId;
   sta->state         = rsetCb->state;
   sta->updState      = rsetCb->updState;
   sta->peerState     = rsetCb->peerState;
   sta->rtUpdSeqNmb   = rsetCb->rtUpdSeqNmb;
   sta->wsSeqNmb      = rsetCb->wsSeqNmb;
   sta->csSeqNmb      = rsetCb->csSeqNmb;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   sta->selfPifVerNum = pifVer;
   sta->remPifVerNum  = tuCb->peerPst.intfVer;
#else
   UNUSED(pifVer);
#endif
   
   RETVALUE (ROK);
   
} /* cmTuGetRsetSta */


/*
 *
 *      Fun:   cmTuGetRsetSts
 *
 *      Desc:  get the resource set statistics
 *
 *      Ret:   ROK
 *             
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 * 
 */
#ifdef ANSI
PUBLIC S16 cmTuGetRsetSts 
(
CmTuCb           *tuCb,         /* PSF control block */
CmFthaRsetId     rsetId,        /* Resource set Id      */
CmTuRsetSts        *sts,          /* Statistics structure */
Action           action         /* action               */
)
#else
PUBLIC S16 cmTuGetRsetSts (tuCb, rsetId, sts, action)
CmTuCb           *tuCb;         /* PSF control block */
CmFthaRsetId     rsetId;        /* Resource set Id      */
CmTuRsetSts        *sts;          /* Statistics structure */
Action           action;        /* action               */
#endif
{
   CmTuRsetCb    *rsetCb;  /* resource set control block */

   TRC2 (cmTuGetRsetSts)
   
   rsetCb = tuCb->rsetCbLst[rsetId];

   if (NULLP == (CmTuRsetCb *)rsetCb)
   {
         CMTULOGERROR_INT_PAR( ECMTU118, (ErrVal)rsetId,
                        "cmTuGetRsetSts: Invalid resource set Id");

      RETVALUE (RFAILED);
   }
   
   /* copy statistics information */
   cmMemcpy((U8 *)sts, (U8 *)&rsetCb->sts, sizeof(CmTuRsetSts));
   
   if (action == ZEROSTS)
   {
      /* clear statistics counter if so requested */
      cmMemset((U8 *)&rsetCb->sts, (U8) 0, sizeof(CmTuRsetSts));
   }
 
   RETVALUE (ROK);
   
} /* cmTuGetRsetSts */



/*
 *
 *      Fun:   cmTuValidateShCntrl
 *
 *      Desc:  This function validates the params for the control request.
 *
 *      Ret:  LCM_REASON_NOT_APPL (not an error)
 *            other errors to be returned to SM 
 *
 *      Notes: None.
 *
 *      File: cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuValidateShCntrl
(
CmTuCb    *tuCb,  /* PSF control block */
CmTuMngmt *cntrl  /* cntrl structure */
)
#else
PUBLIC S16 cmTuValidateShCntrl(tuCb, cntrl)
CmTuCb    *tuCb;  /* PSF control block */
CmTuMngmt *cntrl; /* cntrl structure */
#endif
{
   CmTuRsetCb *rsetCb;

   TRC2 (cmTuValidateShCntrl);

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
            "cmTuValidateShCntrl() : action = %d\n",cntrl->t.cntrl.action));
   
   if(cntrl->hdr.elmId.elmnt != CMTURSET)
   {
      CMTULOGERROR_DEBUG(ECMTU103, (ErrVal) 0,
                "cmTuProcShCntrl(): Invalid elmnt");
      RETVALUE (LCM_REASON_INVALID_ELMNT);
   }

   switch (cntrl->t.cntrl.action)
   {
      case CMTU_AGO_ACT: 
      case CMTU_AGO_SBY:  
      case CMTU_ASHUTDOWN:   
      {
         if (tuCb->pendOp.flag == TRUE)                  
         {
            RETVALUE (LCM_REASON_INVALID_STATE);
         }

         if(!(CMTU_IS_VALID_RSET(cntrl->t.shCntrl.t.rsetPar.rsetId)))
         {
            RETVALUE (LCM_REASON_INVALID_PAR_VAL);
         }

         break;
      }

      case CMTU_ASYNCHRONIZE:
      case CMTU_AWARMSTART:
      {

         if ((tuCb->pendOp.flag == TRUE) && 
             (tuCb->pendOp.hdr.transId != cntrl->hdr.transId))
         {
            RETVALUE (LCM_REASON_INVALID_STATE);
         }

         if(!(CMTU_IS_VALID_RSET(cntrl->t.shCntrl.t.rsetPar.rsetId)))
         {
            RETVALUE (LCM_REASON_INVALID_PAR_VAL);
         }

         rsetCb=tuCb->rsetCbLst[cntrl->t.shCntrl.t.rsetPar.rsetId];

         if (rsetCb->state != CMPFTHA_STATE_ACTIVE)
         {
            RETVALUE (LCM_REASON_INVALID_STATE);
         }
         if ((cntrl->t.cntrl.action == CMTU_ASYNCHRONIZE) && 
             (rsetCb->peerState == CMPFTHA_PEER_DEAD))
         {
            RETVALUE (LCM_REASON_INVALID_STATE);
         }

         break;
      }
      case CMTU_ADIS_PEER_SAP: 
      {
         if (tuCb->pendOp.flag == TRUE)                  
         {
            RETVALUE (LCM_REASON_INVALID_STATE);
         }

         break;
      }

      case CMTU_AABORT:
      {
         if (!((tuCb->pendOp.flag == TRUE) && 
            (cntrl->t.shCntrl.t.abort.transId == tuCb->pendOp.hdr.transId)))
         {
            RETVALUE (LCM_REASON_INVALID_PAR_VAL);
         }
         break;
      }
      default:
      {
         RETVALUE (LCM_REASON_INVALID_ACTION);
      }
   }
   RETVALUE (LCM_REASON_NOT_APPL);
} /* cmTuValidateShCntrl */



/*
 *
 *      Fun:   cmTuValidateSmCntrl
 *
 *      Desc:  This function validates the params for the control request.
 *
 *      Ret:  LCM_REASON_NOT_APPL (not an error)
 *            and other errors to be returned to SM 
 *
 *      Notes: None.
 *
 *      File: 
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuValidateSmCntrl
(
CmTuCb    *tuCb,        /* PSF control block */
CmTuMngmt *cntrl        /* cntrl structure */
)
#else
PUBLIC S16 cmTuValidateSmCntrl(tuCb, cntrl)
CmTuCb    *tuCb;        /* PSF control block */
CmTuMngmt *cntrl;       /* cntrl structure */
#endif
{
   TRC2 (cmTuValidateSmCntrl);

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuValidateSmCntrl() : action = %d\n",cntrl->t.cntrl.action));
   
   switch(cntrl->hdr.elmId.elmnt)
   {
      case CMTUGEN:   
      {
         switch (cntrl->t.cntrl.action)
         {
            case CMTU_ADISIMM:
            case CMTU_AENA:
            {
               switch (cntrl->t.cntrl.subAction)
               {
                  case CMTU_SAUSTA :
#ifdef DEBUGP
                  case CMTU_SADBG :
#endif
                  case CMTU_SATRC:
                  {
                     break;
                  }

                  default:
                  {
                     RETVALUE (LCM_REASON_INVALID_SUBACTION);
                  }
               }/* switch */            
               break;
            }
            case CMTU_ASHUTDOWN:
            {
               break;
            }
            default:
            {
               RETVALUE (LCM_REASON_INVALID_ACTION);
            }
            break;
         }
         break;
      }

      default : /* invalid case */
      {
         RETVALUE (LCM_REASON_INVALID_ELMNT);
      }
   }
   RETVALUE (LCM_REASON_NOT_APPL);
} /* cmTuValidateSmCntrl */


/*
 *
 *      Fun:   cmTuCheckRetry
 *
 *      Desc:  Check if the request from SH is a retry
 *
 *      Ret:   TRUE/FALSE
 *             
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 * 
 */
#ifdef ANSI
PUBLIC Bool cmTuCheckRetry 
(
CmTuCb *tuCb,       /* PSF control block */
TranId transId      /* Transaction Identifier */
)
#else
PUBLIC Bool cmTuCheckRetry (tuCb, transId)
CmTuCb *tuCb;       /* PSF control block */
TranId transId;     /* Transaction Identifier */
#endif
{
   TRC2 (cmTuCheckRetry);
   
   if ((tuCb->lastCfm.valid == TRUE) && 
       (tuCb->lastCfm.cfm.hdr.transId == transId))
   {
      RETVALUE (TRUE);
   }
   else
   {
      tuCb->lastCfm.valid = FALSE;
      RETVALUE (FALSE);
   }
} /* cmTuCheckRetry */


/*
 *
 *       Fun:   cmTuGoAct
 *
 *       Desc:  Make a resource set active
 *
 *       Ret:   ROK
 *              RFAILED
 *
 *       Notes: None
 *
 *       File:  cmTu_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuGoAct 
(
CmTuCb             *tuCb,      /* PSF control block */
CmFthaRsetId       rsetId,     /* resource set Id     */
CmFthaGoActPar     *par        /* go active parameter */
)
#else
PUBLIC S16 cmTuGoAct (tuCb, rsetId, par)
CmTuCb             *tuCb;      /* PSF control block */
CmFthaRsetId       rsetId;     /* resource set Id     */
CmFthaGoActPar     *par;       /* go active parameter */
#endif
{
   CmTuRsetCb      *rsetCb;     /* resource set Cb */
   QLen            qLen;        /* Queue Length    */
   
   TRC2(cmTuGoAct)
   
   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
            "cmTuGoAct (rsetId (%d))\n", rsetId));
   
   rsetCb = tuCb->rsetCbLst[rsetId];  /* get the resource set Cb */
   
   /* check and get the peer state */
   if (par->disPeerSap == TRUE)
   {
      rsetCb->peerState = CMPFTHA_PEER_DEAD;
   }
   else
   {
      rsetCb->peerState = CMPFTHA_PEER_ALIVE;
   }
   
   switch (rsetCb->state)  /* perform based on present state */
   {
      case CMPFTHA_STATE_OOS:
         CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
            "\nrset(%d) for OOS-ACT\n", rsetCb->rsetId));

         if (par->recovery == TRUE)
         {
            cmTuRecovery (tuCb, rsetCb);
            CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
                "\nStarting recovery for rset(%d) for OOS-ACT\n", rsetCb->rsetId));
         }

         tuCb->cookie = CMTU_HAVE_COOKIE;
         break;
         
      case CMPFTHA_STATE_STANDBY:
         CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
             "\nrset(%d) for SBY-ACT\n", rsetCb->rsetId));

         /* unconditionally flush the hold queue */
         if(SFndLenQueue(&rsetCb->rtUpdHoldQ , &qLen) == ROK)
         {
            if(SFlushQueue(&rsetCb->rtUpdHoldQ) != ROK)
            {
               CMTULOGERROR_DEBUG(ECMTU113,rsetId,"cmTuGoAct: SFlushQueue failed");
            }
         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTU114,rsetId,"cmTuGoAct: SFndLenQueue failed");
         }
         rsetCb->rtUpdSeqNmb -= qLen;

#if (ERRCLASS & ERRCLS_DEBUG)
         /*
          * We don't _really_ (but we do it) need to adjust the seqNum
          * for the following reason:
          *
          * If it is a CS, then we would have already received
          * all the segments of the last RT message and qLen should
          * be 0. 
          */

         /* Sanity check for above step */
         if ((rsetCb->peerState == CMPFTHA_PEER_ALIVE) && (qLen))
         {
            CMTULOGERROR_DEBUG (ECMTU115, rsetId, 
            "cmTuGoAct : qLen is non zero during CS ");
         }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

         /* Need to start recovery timer in this case */
         if(rsetCb->recovery)
         {
            cmTuRecovery(tuCb, rsetCb);
         }
         /* start bind timer and protocol timer */
         tuCb->fn.tuStartTimers();

         break;
         
      case CMPFTHA_STATE_ACTIVE:
         CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
             "\nrset(%d) for ACT-ACT\n", rsetCb->rsetId));
      
         if (rsetCb->updState == CMPFTHA_US_PEERSYNC_FIN)
         {
            /* Something went wrong in the peersync and we are made
               active again */
            tuCb->fn.tuStartTimers();
         }

         break;
         
      default:  /* unknown state */
      {
         CMTULOGERROR_DEBUG(ECMTU116,(ErrVal)rsetCb->state, 
                       "cmTuGoAct: Invalid protocol state");
         RETVALUE(CMTU_ERR);
      }
   } /* switch */
   
   if (rsetCb->peerState == CMPFTHA_PEER_DEAD)
   {
      /* reset sequence numbers */
      rsetCb->rtUpdSeqNmb   = 0;
      rsetCb->wsSeqNmb      = 0;
      rsetCb->csSeqNmb      = 0;
   
   }

   /* modify state & update state unconditionally */
   rsetCb->state    = CMPFTHA_STATE_ACTIVE;
   rsetCb->updState = CMPFTHA_US_IDLE;
   
   /* initialize  more parameters */
   rsetCb->bulkNextUpdType = CMPFTHA_INV_TT;
   rsetCb->rtNextUpdType   = CMPFTHA_INV_TT;
   rsetCb->bulkLastUpdIdx  = 0;
   rsetCb->rtLastUpdIdx    = 0;
   rsetCb->dlgCp           = NULLP;
   rsetCb->lastDlg.lastUpdHlEnt    = NULLP;
   rsetCb->lastDlg.currBin         = 0;
   rsetCb->lastInv.lastUpdHlEnt    = NULLP;
   rsetCb->lastInv.currBin         = 0;

   /* initialize shared data structure */
   cmTuInitUpdStruct(tuCb, rsetId);

   RETVALUE(CMTU_OK);
   
} /* cmTuGoAct */

  
/*
 *
 *       Fun:   cmTuGoSby
 *
 *       Desc:  Make a resource set standby
 *
 *       Ret:   ROK 
 *              RFAILED
 *
 *       Notes: None
 *
 *       File:  cmTu_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuGoSby 
(
CmTuCb             *tuCb,      /* PSF control block */
CmFthaRsetId       rsetId,     /* Resource set Id       */
CmFthaGoSbyPar     *par        /* Go Standby parameters */
)
#else
PUBLIC S16 cmTuGoSby (tuCb, rsetId, par)
CmTuCb             *tuCb;      /* PSF control block */
CmFthaRsetId       rsetId;     /* Resource set Id       */
CmFthaGoSbyPar     *par;       /* Go standby parameters */
#endif
{
   CmTuRsetCb        *rsetCb;     /* resource set Cb */
   
   TRC2(cmTuGoSby)
   
   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, "cmTuGoSby (rsetId (%d))\n", 
            rsetId));
   
   /* get the resource set Cb */
   rsetCb = tuCb->rsetCbLst[rsetId];     

   /* perform based on present state */
   switch (rsetCb->state)    
   {
      case CMPFTHA_STATE_OOS:   /* from out of service state */
      {
         /* nothing specific is required except the unconditional part */
         break;
      }
         
      case CMPFTHA_STATE_STANDBY:   /* from standby state only after CS */
      {
         rsetCb->acceptRTMsg = TRUE;

         tuCb->fn.tuCleanUp();

         break;
      }
      case CMPFTHA_STATE_ACTIVE:   /* from active state */
      {
         rsetCb->acceptRTMsg = TRUE; 
      
         /* in pure FTHA no matter critical/noncritical rset timers should
          * be stopped.
          */
         tuCb->fn.tuStopTimers();
         tuCb->fn.tuCleanUp();

         break;     
      }
      
      
      default:   /* unknown state */
      {
         CMTULOGERROR_DEBUG(ECMTU117, (ErrVal)rsetCb->state,
                    "cmTuGoSby: Invalid protocol state");

         RETVALUE(CMTU_ERR); 
      }
   } /* end switch */
   

   /* modify update state unconditionally */
   rsetCb->updState = CMPFTHA_US_IDLE;
   
   /* change resource set status */
   rsetCb->state = CMPFTHA_STATE_STANDBY; 
   
   /* If we are sby then it means there is a actv out there */
   rsetCb->peerState = CMPFTHA_PEER_ALIVE;
   
   /* unconditionally flush the hold queue */
   SFlushQueue(&rsetCb->rtUpdHoldQ);

   RETVALUE(CMTU_OK);
   
} /* cmTuGoSby */

  
/*
 *
 *      Fun:   cmTuGoOOS
 *
 *      Desc:  This function shuts down resource set
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmTu_bdy3.c
 *
 */

#ifdef ANSI
PUBLIC Void cmTuGoOOS
(
CmTuCb           *tuCb,       /* PSF control block */
CmFthaRsetId     rsetId       /* Resource set Id */
)
#else
PUBLIC Void cmTuGoOOS (tuCb, rsetId)
CmTuCb           *tuCb;       /* PSF control block */
CmFthaRsetId     rsetId;      /* Resource set Id */
#endif
{
   CmTuRsetCb         *rsetCb;       /* pointer to resource set Cb */

   TRC2 (cmTuGoOOS)

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf,"cmTuGoOOS() : rsetId = %d\n",
            rsetId));

   /* check if rsetCb list has been configured */
   if (tuCb->rsetCbLst == (CmTuRsetCb **)NULLP)
   {
         CMTULOGERROR_INT_PAR(ECMTU118, (ErrVal)0,
                        "cmTuGoOOS: rsetCb list hasn't been configured.");
   
      RETVOID;
   }

   /* Get the resource set */
   rsetCb = tuCb->rsetCbLst[rsetId];

   if (rsetCb != (CmTuRsetCb *)NULLP)
   {
      if(rsetCb->state == CMPFTHA_STATE_OOS)
      {
         RETVOID;
      }
      rsetCb->acceptRTMsg   = FALSE; 
      rsetCb->peerState     = CMPFTHA_PEER_DEAD;
      rsetCb->updState      = CMPFTHA_US_IDLE;
      rsetCb->rtUpdSeqNmb   = 0;
      rsetCb->wsSeqNmb      = 0;
      rsetCb->csSeqNmb      = 0;
      rsetCb->state         = CMPFTHA_STATE_OOS;
      (Void)SFlushQueue(&rsetCb->rtUpdHoldQ); 
      (Void)SFlushQueue(&rsetCb->tmrQ);

      tuCb->fn.tuStopTimers();
      /* clear all transient states */
      tuCb->fn.tuCleanUp();                
         
      cmTuInitUpdStruct(tuCb, rsetId);
 
      /* stop any timers */
      cmTuStopRsetCbTmr(tuCb, rsetCb, CMTU_TMR_ACK);
      cmTuStopRsetCbTmr(tuCb, rsetCb, CMTU_TMR_GRD);

   }
 
   RETVOID;
   
} /* cmTuGoOOS */

  
/*
 *
 *       Fun:   cmTuWarmStart
 *
 *       Desc:  Do Warmstart on the resource set
 *
 *       Ret:   CMTU_OK 
 *              CMTU_PEND 
 *              CMTU_ERR 
 *
 *       Notes: None
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuWarmStart 
(
CmTuCb           *tuCb,       /* PSF control block */
CmFthaRsetId      rsetId      /* resource set Id */
)
#else
PUBLIC S16 cmTuWarmStart (tuCb, rsetId)
CmTuCb           *tuCb;       /* PSF control block */
CmFthaRsetId      rsetId;     /* resource set Id */
#endif
{
   CmTuRsetCb     *rsetCb;    /* Pointer to resource set control block */
   Bool           innerLoop;  /* inner while loop status               */
   Bool           outerLoop;  /* outer while loop status               */
   Bool           pauseFlag;  /* Flag to decide if pause is required   */
   Bool           done;       /* warm state update status              */
   Buffer         *mBuf;      /* message buffer                        */
   MsgLen         mLen;       /* message length                        */
   S16            size;       /* size of the control block             */
   S16            ret;        /* return value                          */
   Bool           updFlag;    /* update flag for case CMTU_DLG_CB only */
   CmTuWsUpdRtSeq rtSeq;      /* RT Seq control block */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
   CmTuRtUpdVerInfoCb verInfoUpdCb;   /* Version info control block    */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   CmTuRtUpdPsfCb psfUpdCb;   /* update the PSF control block          */
   U16            nmbWSMsgs;  /* Number of Warm Start messages sent    */
   U16            maxWSMsgs;  /* Max. No. of WS Messages allowed       */
   PTR            sapCp;      /* temp SAP control block                */
   PTR            dlgCp;      /* temp dialogue control block           */
   PTR            invCp;      /* temp invoke control block             */

   TRC2 (cmTuWarmStart)

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, "cmTuWarmStart (rsetId (%d))\n", 
                                             rsetId));
 
   /* Get the pointer to resource set control block */
   rsetCb = tuCb->rsetCbLst[rsetId];

   if (rsetCb->updState != CMPFTHA_US_WARMSTART)
   {
      /* if this function is called first time then initialize shared update
         structure */

      cmTuInitUpdStruct(tuCb, rsetId);

      rsetCb->peerState      = CMPFTHA_PEER_ALIVE;
      rsetCb->wsSeqNmb       = 0;
      rsetCb->bulkLastUpdIdx = 0;
      rsetCb->dlgCp          = NULLP;
      rsetCb->lastDlg.lastUpdHlEnt   = (PTR)NULLP;
      rsetCb->lastDlg.currBin= 0;
      rsetCb->lastInv.lastUpdHlEnt   = (PTR)NULLP;
      rsetCb->lastInv.currBin= 0;
      rsetCb->updState       = CMPFTHA_US_WARMSTART;/* WS in progress */

      rsetCb->bulkNextUpdType = CMTU_RTSEQ_CB;    
   }

   /* initialize variables */
   outerLoop = TRUE;
   done      = FALSE;
   pauseFlag = TRUE; /* we can take a break if nmbWSMsgs exceed maxWSMsgs*/
   nmbWSMsgs = 0;    /* Not sent any message yet */
   maxWSMsgs = tuCb->genCfg.maxUpdMsgs;
   innerLoop = FALSE;
   mBuf = NULLP;
   mLen = 0;
   size = 0;
   ret = ROK;
   updFlag = FALSE;
   sapCp = NULLP;
   dlgCp = NULLP;
   invCp = NULLP;

   /* fill update message */
   while (outerLoop && !done)
   {
      /* allocate message buffer */
      if ((ret = (cmTuGetBuf(tuCb, rsetCb,
                          CMPFTHA_PROC_WARMSTART,
                          rsetCb->wsSeqNmb++,
                          CMPFTHA_FLAG_MORE,
                          &mBuf))) != ROK)
      {
         innerLoop = FALSE;
      }
      else
      {
         innerLoop = TRUE;
         nmbWSMsgs++;
      }

      while (innerLoop)
      {
         (Void)SFndLenMsg(mBuf, &mLen);

         size = tuCb->updSize[rsetCb->bulkNextUpdType];

         if ((mLen + size) > (MsgLen)tuCb->genCfg.maxUpdMsgSize)
         {
            innerLoop = FALSE;
         }
         else
         {
            switch (rsetCb->bulkNextUpdType)
            {
               case CMTU_RTSEQ_CB:       /* RT Seq Nmb Control block */
               {
                  rtSeq.rtSeqNmb = rsetCb->rtUpdSeqNmb;
                  rtSeq.recovery = rsetCb->recovery;
                  ret = cmTuPkRtSeq(tuCb, &tuCb->peerPst, (PTR)&rtSeq, mBuf);

#ifdef TDS_ROLL_UPGRADE_SUPPORT
                  rsetCb->bulkNextUpdType = CMTU_VERINFO_CB;
#else /* not TDS_ROLL_UPGRADE_SUPPORT */
                  rsetCb->bulkNextUpdType = CMTU_PROT_CB;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
                  rsetCb->bulkLastUpdIdx  = 0;
                  break;
               }

#ifdef TDS_ROLL_UPGRADE_SUPPORT
               case CMTU_VERINFO_CB:   /* version info control blocks */

                  /* pack all the intf ver info in StCb */
                  if (tuCb->numIntfInfo == NULLP)
                  {
                     CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, "cmTuWarmStart CMTU_VERINFO_CB, invalid counter\n")); 
                     break;
                  }
                  if (rsetCb->bulkLastUpdIdx < *(tuCb->numIntfInfo))
                  {
                     ShtVerInfo *verInfoCp;  /* ver info control block */
                     
                     verInfoCp = &((*tuCb->intfInfo)[rsetCb->bulkLastUpdIdx++]);

                     cmMemcpy((U8 *) &(verInfoUpdCb.verInfo),
                              (U8 *) verInfoCp, sizeof(ShtVerInfo));
                     verInfoUpdCb.action = CMPFTHA_ACTN_MOD;

                     ret = cmTuPkVerInfoCb(tuCb,&tuCb->peerPst,
                                           (PTR)&verInfoUpdCb, mBuf);
                  }

                  /* all info packed, move to next control block type */
                  if (rsetCb->bulkLastUpdIdx >= *(tuCb->numIntfInfo))
                  {
                     rsetCb->bulkNextUpdType = CMTU_PROT_CB;
                     rsetCb->bulkLastUpdIdx  = 0;
                  }
                  break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

               case CMTU_PROT_CB:  
                  ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                   CMPFTHA_ACTN_ADD, CMTU_PROTCB_TAB,  
                                   (PTR)(tuCb->fn.tuGetProtCb()), FALSE, mBuf);
                  rsetCb->bulkNextUpdType = CMTU_PSF_CB;
                  break;
                  
               case CMTU_PSF_CB:  
                  psfUpdCb.usta = tuCb->init.usta;
                  psfUpdCb.cookie = tuCb->cookie;
                  ret = cmTuPkPsfCb(tuCb,&tuCb->peerPst,
                                    (PTR)&psfUpdCb, mBuf);
                  rsetCb->bulkNextUpdType = CMTU_UISAP_CB;
                  break;

               case CMTU_UISAP_CB:   /* Upper sap control blocks */

                  updFlag   = TRUE;

                  while (updFlag)
                  {
                     /* Last SAP control block is updated completely
                        now update the next dialogue control block */

                     if (tuCb->fn.tuGetNextSapCb(rsetCb->bulkLastUpdIdx++, 
                                              rsetCb->bulkNextUpdType,
                                              &sapCp) == ROK)
                     {

                        ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                         CMPFTHA_ACTN_MOD, CMTU_UISAP_TAB,  
                                         (PTR)sapCp, FALSE, mBuf);

                     }
                     else
                     {
                        rsetCb->bulkNextUpdType = CMTU_LISAP_CB;
                        rsetCb->bulkLastUpdIdx  = 0;
                        /* Complete upper sap update */
                        updFlag       = FALSE;
                        pauseFlag     = FALSE;
                        sapCp         = NULLP;
                     }
                  }
                  break;

               case CMTU_LISAP_CB:   /* Lower sap control blocks */

                  updFlag   = TRUE;

                  while (updFlag)
                  {
                     /* Last SAP control block is updated completely
                        now update the next dialogue control block */

                     if (tuCb->fn.tuGetNextSapCb(rsetCb->bulkLastUpdIdx++, 
                                              rsetCb->bulkNextUpdType,
                                              &sapCp) == ROK)
                     { 
                        ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                            CMPFTHA_ACTN_MOD, CMTU_LISAP_TAB,
                                            (PTR)sapCp, FALSE, mBuf);

                     }
                     else
                     {
                        rsetCb->bulkNextUpdType = CMTU_WSDLG_CB;
                        rsetCb->bulkLastUpdIdx  = 0;
                        pauseFlag     = FALSE;

                        /* Take a break before start updating dynamic data
                         * structures */

                        innerLoop = FALSE;

                        /* Complete lower sap update for */
                        updFlag       = FALSE;
                     }
                  }

                  break;

               case CMTU_WSDLG_CB:   /* Dialogue control blocks */

                  /* If desceduling is because of update message size then it
                     should be of pause type */
                  
                  /* pauseFlag = TRUE; */
                  updFlag   = TRUE;

                  while (updFlag)
                  {
                     /* Last dialogue control block is updated completely
                        now update the next dialogue control block */
                     ret = ROK;

                     if (tuCb->genCfg.updAllDlg == TRUE)
                     {
                        /* If all the dialogues are required to be update, 
                         * call the callback function to search the dialogue
                         * from protocol layer's hash table
                         */
                        if (tuCb->fn.tuGetNextSapCb(rsetCb->bulkLastUpdIdx, 
                                                 CMTU_UISAP_CB,
                                                 &sapCp) == ROK)
                        { 
                           ret = tuCb->fn.tuGetNextDlg(sapCp, &rsetCb->lastDlg, &dlgCp);
                           if (ret !=ROK)
                           {
                              /* There are no more dlgs available for this sap */
                              /* Move to the next one */
                              rsetCb->bulkLastUpdIdx++;
                              rsetCb->lastDlg.lastUpdHlEnt   = (PTR)NULLP;
                              rsetCb->lastDlg.currBin= 0;
                              continue;
                           }
                        }
                        else
                        {
                           /* There is no next SAP. Hence updates should 
                              be stopped at this point. */
                           ret = RFAILED;
                        }
                     }
                     else
                     {
                        /* If only selective dialogues are required to be 
                         * update, all the common function to search the 
                         * dialogue from doubly linked list maintained in
                         * rSetCb.
                         */
                        ret = cmTuGetNextDlg(tuCb, &dlgCp);
                     }                   

                     if (ret == ROK)
                     {
                        ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                         CMPFTHA_ACTN_ADD, CMTU_WSDLG_TAB,
                                         (PTR)dlgCp, FALSE, mBuf);

                        /* Once we have packed dialogue parameteres
                        ** We need to make sure that we dont break 
                        ** before completing all the invokes within
                        */
                        pauseFlag = FALSE; 

                        rsetCb->dlgCp           = dlgCp;
                        rsetCb->bulkNextUpdType = CMTU_WSINV_CB;
                        updFlag                 = FALSE;
                     }
                     else
                     {
                        /* Complete dialogue hash list is updated for
                           the current sap */
                        updFlag       = FALSE;
                        pauseFlag     = FALSE;
                        rsetCb->dlgCp = NULLP;
                        innerLoop     = FALSE;
                        outerLoop     = FALSE;
                        done          = TRUE;
                        ret           = ROK;
                     }
                  }
                  break;
                  
               case CMTU_WSINV_CB:   /* Invoke control blocks */

                  /* If desceduling is because of update message size then it
                     should be of pause type */

                  /* pauseFlag = TRUE; */
                  dlgCp = rsetCb->dlgCp;

                  if (tuCb->fn.tuGetNextInv(dlgCp, &rsetCb->lastInv, &invCp) == ROK)
                  {

                     ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                      CMPFTHA_ACTN_ADD, CMTU_WSINV_TAB,
                                      (PTR)invCp, FALSE, mBuf);

                     rsetCb->lastInv.lastUpdHlEnt = (PTR)invCp;
                  }
                  else
                  {
                     /* Once we have packed all the invokes    
                     ** We can break;
                     */
                     pauseFlag = TRUE; 
                     rsetCb->lastInv.lastUpdHlEnt    = (PTR)NULLP;
                     rsetCb->lastInv.currBin= 0;
                     rsetCb->bulkNextUpdType = CMTU_WSDLG_CB;
                  }
                  break;

               default:
               {
                  CMTULOGERROR_DEBUG(ECMTU118, (ErrVal)rsetCb->bulkNextUpdType,
                                 "cmTuWarmStart: Invalid table type");

                  ret = RFAILED;
                  break;
               }

            } /* end switch */

         } /* end else */

         if (ret == RFAILED)
         {
             innerLoop = FALSE;
         }

      } /* end inner while */

      /* If no failure so far then send the update message */
      if (ret == ROK)
      {
         CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, "cmTuWarmStart(SeqNmb(%d), \
                  Done(%d))\n", rsetCb->wsSeqNmb-1, done));
         rsetCb->sts.txWS++;
         ret = cmTuSendPeerMsg(tuCb,rsetId,mBuf,done,CMPFTHA_PROC_WARMSTART);
         
         /* If warmstart is not completed then take a break here */
         if (done == FALSE)
         {
            /* take a pause or deschedule */
            /* dialogue is atomic and number of WS Msgs >= max configured */
            if ((pauseFlag == TRUE)  && (nmbWSMsgs >= maxWSMsgs))
            {
               RETVALUE(CMTU_PEND);
            }
         }
      }

      if (ret == RFAILED)
      {
         cmTuInitUpdStruct(tuCb, rsetId);
         rsetCb->updState  = CMPFTHA_US_IDLE;
         rsetCb->peerState = CMPFTHA_PEER_DEAD;
         RETVALUE(CMTU_ERR);
      }

   } /* end outer while */

   if (done == TRUE)
   {
      rsetCb->updState = CMPFTHA_US_WARMSTART_WAIT;

      /* start timer to wait for ack from peer */
      cmTuStartRsetCbTmr(tuCb, rsetCb, (U8)CMTU_TMR_ACK);
   }
      
   RETVALUE(CMTU_OK);
 
} /* cmTuWarmStart */

  
/*
 *
 *       Fun:   cmTuSynchronize
 *
 *       Desc:  Start PeerSync on the resource set
 *
 *       Ret:  CMTU_OK 
 *             CMTU_PEND 
 *             CMTU_ERR  
 *
 *       Notes: None
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuSynchronize 
(
CmTuCb           *tuCb,       /* PSF control block */
CmFthaRsetId     rsetId       /* Resource set Id */
)
#else
PUBLIC S16 cmTuSynchronize (tuCb, rsetId)
CmTuCb           *tuCb;       /* PSF control block */
CmFthaRsetId     rsetId;      /* Resource set Id */
#endif
{
   CmTuRsetCb    *rsetCb;      /* Rseource set control block            */
   PTR           sapCp;        /* SAP control block                     */
   PTR           dlgCp;        /* Dialogue control point                */
   PTR           invCp;        /* Invoke control point                  */
   Bool          innerLoop;    /* loop status                           */
   Bool          outerLoop;    /* loop status                           */
   Bool          updDone;      /* warm state update status              */
   Buffer        *mBuf;        /* message buffer                        */
   S16           ret;          /* return value                          */
   U16           nmbCSMsgs;    /* Number of controlled Switchover msgs  */
   U16           maxCSMsgs;    /* Number of controlled Switchover msgs  */
   MsgLen        mLen;         /* Message Length                        */
   S16           size;         /* message size                          */
   Bool          pauseFlag;    /* pause flag                            */

   TRC2(cmTuSynchronize)
           
   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuSynchronize() : rsetId = %d\n",rsetId));

   /* Get the pointer to resource set control block */
   rsetCb = tuCb->rsetCbLst[rsetId];

   /* Stop the timers */
   tuCb->fn.tuStopTimers ();

   if (rsetCb->updState == CMPFTHA_US_IDLE)
   {
      rsetCb->csSeqNmb        = 0;
      rsetCb->dlgCp           = NULLP;
      rsetCb->updState        = CMPFTHA_US_PEERSYNC; /* CS in progress */
   }

   /* initialize variables */
   outerLoop = TRUE;
   innerLoop = TRUE;
   updDone   = FALSE;
   nmbCSMsgs = 0;    
   mLen      = 0;
   pauseFlag = FALSE;
   ret       = ROK;
   maxCSMsgs = tuCb->genCfg.maxUpdMsgs;
   dlgCp     = NULLP;
   sapCp     = NULLP;
   invCp     = NULLP;
   mBuf      = NULLP;
   size      = 0;   

   rsetCb->bulkNextUpdType = CMTU_CSWDLG_CB;
   rsetCb->bulkLastUpdIdx  = 0; 
   rsetCb->lastDlg.lastUpdHlEnt = (PTR)NULLP;
   rsetCb->lastDlg.currBin= 0;
   rsetCb->lastInv.lastUpdHlEnt = (PTR)NULLP;
   rsetCb->lastInv.currBin= 0;

   while ((outerLoop == TRUE) && (updDone != TRUE))
   {
      /* allocate message buffer */
      if ((ret = (cmTuGetBuf(tuCb, rsetCb, CMPFTHA_PROC_PEERSYNC, 
                             rsetCb->csSeqNmb++, CMPFTHA_FLAG_MORE, 
                             &mBuf))) != ROK)
      {
         innerLoop = FALSE;
      }
      else
      {
         innerLoop = TRUE;
         nmbCSMsgs++;
      }

      while (innerLoop == TRUE)
      {
         switch (rsetCb->bulkNextUpdType)
         {
            case CMTU_CSWDLG_CB:   /* Dialogue control blocks */
            {
               {
                  /* If all the dialogues are required to be updated, 
                   * call the callback function to search the dialogue
                   * from protocol layer's hash table
                   */
                  if (tuCb->fn.tuGetNextSapCb(rsetCb->bulkLastUpdIdx, 
                                           CMTU_UISAP_CB,
                                           &sapCp) == ROK)
                  { 
                     ret = tuCb->fn.tuGetNextDlg(sapCp, &rsetCb->lastDlg, &dlgCp);
                     if (ret !=ROK)
                     {
                        /* There are no more dlgs available for this sap */
                        /* Move to the next one */
                        rsetCb->bulkLastUpdIdx++;
                        rsetCb->lastDlg.lastUpdHlEnt   = (PTR)NULLP;
                        rsetCb->lastDlg.currBin= 0;
                        continue;
                     }
                  }
                  else
                  {
                     /* There is no next SAP. Hence updates should 
                        be stopped at this point. */
                     ret = RFAILED;
                  }
                  
               }

               if (ret != ROK)
               {
                  /* We have completed CS for all the dialogues */
                  innerLoop     = FALSE;
                  outerLoop     = FALSE;
                  updDone       = TRUE;
                  rsetCb->dlgCp = NULLP;
                  rsetCb->bulkNextUpdType = 0;
                  rsetCb->lastDlg.lastUpdHlEnt = (PTR)NULLP;
                  rsetCb->lastDlg.currBin= 0;
                  rsetCb->lastInv.lastUpdHlEnt = (PTR)NULLP;
                  rsetCb->lastInv.currBin= 0;
                  ret           = ROK;

                  break;
               }

               /* this works for linked list */
               (Void)SFndLenMsg(mBuf, &mLen);
               size = tuCb->updSize[rsetCb->bulkNextUpdType];
               if ((mLen + size) >= (MsgLen)tuCb->genCfg.maxUpdMsgSize)
               {
                  innerLoop = FALSE;
                  break;
               }

               ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                CMPFTHA_ACTN_MOD, CMTU_CSWDLG_TAB,
                                (PTR)dlgCp, FALSE, mBuf);

               /* Once we have packed dialogue parameteres
                * We need to make sure that we dont break 
                * before completing all the invokes within
                */
               pauseFlag = FALSE; 

               rsetCb->dlgCp           = dlgCp;
               rsetCb->bulkNextUpdType = CMTU_CSWINV_CB;
               rsetCb->lastInv.lastUpdHlEnt = NULLP;
               rsetCb->lastInv.currBin = 0;

               break;
            }
            case CMTU_CSWINV_CB:   /* Invoke control blocks */
            {
               dlgCp = rsetCb->dlgCp;

               if (tuCb->fn.tuGetNextInv(dlgCp, &rsetCb->lastInv, &invCp) == ROK)
               {
                  /* this work for mbuf and Q */
                  (Void)SFndLenMsg(mBuf, &mLen);
                  size = tuCb->updSize[rsetCb->bulkNextUpdType];
                  if ((mLen + size) >= (MsgLen)tuCb->genCfg.maxUpdMsgSize)
                  {
                     /* This is not really an error. Just a
                        warning...since the cmpLst for MAP_SEC can be
                        huge and it is updated in one shot there is a
                        good chance for the update message to actually
                        overshoot the configured update message
                        size. Nothing can be done about it... */
                     CMTUDBGP(CMTU_DBGMASK_INTERNAL, 
                              (tuCb->init.prntBuf, 
                               "cmTuSynchronize():WARNING configure a higher value \
for maxUpdMsgSize\n")); 
                  }

                  ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                   CMPFTHA_ACTN_MOD, CMTU_CSWINV_TAB,
                                   (PTR)invCp, FALSE, mBuf);

                  rsetCb->lastInv.lastUpdHlEnt = (PTR)invCp;
               }
               else
               {
                  /* Once we have packed all the invokes    
                   ** We can break;
                   */
                  pauseFlag = TRUE; 
                  rsetCb->lastInv.lastUpdHlEnt = (PTR)NULLP;
                  rsetCb->lastInv.currBin = 0;
                  rsetCb->bulkNextUpdType = CMTU_CSWDLG_CB;
               }

               break;
            }

            default:
            {
               CMTULOGERROR_DEBUG( ECMTU118, (ErrVal)rsetCb->bulkNextUpdType,
                     "cmTuSynchronize: Invalid table type");

               ret = RFAILED;
               break;
            }
         }/* end of switch */

         if (ret == RFAILED)
         {
             innerLoop = FALSE;
         }

      } /* end inner while */
            
      if (ret == ROK)
      {
         rsetCb->sts.txCS++;
         ret = cmTuSendPeerMsg(tuCb,rsetId,mBuf,updDone,CMPFTHA_PROC_PEERSYNC);
         
      }
      else 
      {
         rsetCb->updState = CMPFTHA_US_IDLE;
         CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
                  "cmTuSynchronize(): failed, nmbCSMsgs=%d\n", nmbCSMsgs));
         RETVALUE(CMTU_ERR);
      }

   } /* end of outer while */

   if (updDone == TRUE)
   {
      rsetCb->updState = CMPFTHA_US_PEERSYNC_WAIT;

      /* start timer to wait for ack from peer */
      cmTuStartRsetCbTmr(tuCb, rsetCb, (U8)CMTU_TMR_ACK);
   }

   RETVALUE(CMTU_OK);

} /* cmTuSynchronize */


/*
 *
 *      Fun:   cmTuAbortCurOp
 *
 *      Desc:  This function aborts any ongoing WS, 
 *             CS operation on a resource set.
 *
 *      Ret:   Void
 *
 *      Notes: None.
 *
 *      File:  cmTu_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuAbortCurOp
(
CmTuCb       *tuCb,    /* common psf control block */
CmFthaRsetId rsetId,   /* Resource set Id */
CmTuPendOp   *pendOp   /* Pending operation */ 
)
#else
PUBLIC Void cmTuAbortCurOp (tuCb, rsetId, pendOp)
CmTuCb       *tuCb;    /* common psf control block */
CmFthaRsetId rsetId;   /* Resource set Id */
CmTuPendOp   *pendOp;  /* Pending operation */
#endif
{
   CmTuRsetCb *rsetCb;  /* resource set control block */
   
   TRC2 (cmTuAbortPendOp);

   CMTUDBGP (CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf,"cmTuAbortCurOp\n")); 

   pendOp->flag = FALSE;    
   
   rsetCb = tuCb->rsetCbLst[rsetId];
   /* reinit the seq num's */
   rsetCb->wsSeqNmb = rsetCb->csSeqNmb = 0;
   cmTuStopRsetCbTmr (tuCb, rsetCb, CMTU_TMR_ACK);

   if (pendOp->action == CMTU_AWARMSTART)
   {
      rsetCb->updState = CMPFTHA_US_IDLE;
   }
   else
   {
      /* This state will be cleared when the SG issues a
         GoAct. This is mandatory. */
      rsetCb->updState = CMPFTHA_US_PEERSYNC_FIN;
   }
   /* 
    * The resource set should not have anything in the bulk queue.
    * Note : resource set for whom the CS, WS operation 
    * has not been done are left untouched.
    */
   RETVOID;
} /* cmTuAbortCurOp */


/*
 *
 *      Fun:   cmTuPostContMsg
 *
 *      Desc:  Post a continue message to PSF
 *
 *      Ret:   Void
 *
 *      Notes: None
 *
 *      File:  zt_bdy3.c
 */   
#ifdef ANSI
PUBLIC Void cmTuPostContMsg
(
CmTuCb       *tuCb      /* PSF control block */
)
#else
PUBLIC Void cmTuPostContMsg (tuCb)
CmTuCb       *tuCb;      /* PSF control block */
#endif
{
   Buffer *mBuf;   /* Message Buffer */
   
   TRC2 (cmTuPostContMsg);

   CMTUDBGP (CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, "cmTuPostContMsg\n"));

   if ((SGetMsg (tuCb->peerPst.region, tuCb->peerPst.pool, &mBuf)) !=ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      CMTULOGERROR_ADD_RES(ECMTU112, 0, "cmTuPostContMsg : SGetMsg failed");
#endif
      RETVOID;
   }

   CmTuSiOubSchReq (tuCb, &tuCb->selfPst,mBuf);  

   RETVOID;
} /* cmTuPostContMsg */

/*
 *
 *       Fun:  cmTuRecovery
 *
 *       Desc: Start recovery if the active has failed.
 *
 *       Ret:  Void
 *
 *       Notes: the GUARD timer has to be started.
 *              - ACT goes down, SBY becomes ACT
 *              - WS, CS is done and the old copy is made ACT.
 *              - We should thus update recovery state.
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuRecovery 
(
CmTuCb     *tuCb,       /* common psf control block */
CmTuRsetCb *rsetCb      /* Resource set control block */
)
#else
PUBLIC Void cmTuRecovery (tuCb, rsetCb)
CmTuCb     *tuCb;       /* common psf control block */
CmTuRsetCb *rsetCb;     /* Resource set control block */
#endif
{
   TRC2 (cmTuRecovery);

   CMTUDBGP (CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
             "cmTuRecovery : rsetId %d\n", rsetCb->rsetId));
   /* Start the guard timer on the resource set */
   rsetCb->recovery = TRUE;
   cmTuStartRsetCbTmr (tuCb, rsetCb, CMTU_TMR_GRD);

   cmTuRunTimeUpd(tuCb, CMTU_RSET_CB, CMPFTHA_UPDTYPE_NORMAL,
                  CMPFTHA_ACTN_MOD, (Void *)rsetCb);
   cmTuUpdPeer(tuCb);

   RETVOID;
} /* cmTuRecovery */


/********************************************************************20**
  Protocol layer interface functions
*********************************************************************21*/

/*
 *
 *      Fun:   cmTuRunTimeUpd
 *
 *      Desc:  This function updates the shared data structure tuCb.upd
 *             with the control block information.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function is called by portable protocol layer whenever a
 *             control block is modified at runtime. By calling this function
 *             portable layer updates shared data strcuture with the control
 *             block information which could be accesed by PSF later
 *             to send update messages to standby protocol layer.
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuRunTimeUpd
(
CmTuCb    *tuCb,          /* PSF control block */
U8        cbType,         /* control block type                */
U8        updType,        /* Update Type                       */
U8        action,         /* action taken on the control block */
Void      *cbPtr          /* control block pointer             */
)
#else
PUBLIC S16 cmTuRunTimeUpd(tuCb, cbType, updType, action, cbPtr)
CmTuCb    *tuCb;          /* PSF control block */
U8        cbType;         /* control block type                */
U8        updType;        /* Update Type                       */
U8        action;         /* action taken on the control block */
Void      *cbPtr;         /* control block pointer             */
#endif
{
   CmTuRsetCb         *rsetCb;
   CmFthaRsetId       rsetId; 
   U16                i;

   TRC3 (cmTuRunTimeUpd)

   CMTUDBGP(DBGMASK_PLI, (tuCb->init.prntBuf,
            "cmTuRunTimeUpd:cbType(%d), action(%d)\n", cbType, action));

   if (!tuCb->init.cfgDone)
   {
      CMTULOGERROR_DEBUG(ECMTU076, (ErrVal)0,
                         "cmTuRunTimeUpd:PSF is not configured");
      RETVALUE(RFAILED);
   }    

   /* get the reserved resource set Id */
   rsetId = CMFTHA_RES_RSETID;
   rsetCb = tuCb->rsetCbLst[rsetId];

   /* Check if the call is made in an invalid state */
   if (rsetCb->state != CMPFTHA_STATE_ACTIVE)
   {
      RETVALUE (ROK);
   }

   /* If peer rset is disabled, no need to process the update request */
   if (rsetCb->peerState == CMPFTHA_PEER_DEAD)
   {
      RETVALUE(ROK);
   }
   
   switch(cbType)
   {
      case CMTU_PROT_CB:
         rsetCb->upd.protCb.updReq = TRUE;
         rsetCb->upd.protCb.action = action;
         rsetCb->upd.protCb.cb     = (PTR)cbPtr;
         break;

      case CMTU_PSF_CB:
         rsetCb->upd.psfCb.updReq = TRUE;
         rsetCb->upd.psfCb.action = action;
         rsetCb->upd.psfCb.cb     = (PTR)cbPtr;
         break;

      case CMTU_RSET_CB:

         if (!rsetCb->upd.rsetCb.updReq)
         {
            rsetCb->upd.rsetCb.updReq = TRUE;
            rsetCb->upd.rsetCb.action = action;
            rsetCb->upd.rsetCb.cb     = (PTR)cbPtr;
         }
         else
         {
            /* Second rsetCb update request, previous one isn't updated yet */
            CMTULOGERROR_DEBUG(ECMTU076, (ErrVal)cbType,
                           "cmTuRunTimeUpd:Previous rsetCb isn't updated yet");

            RETVALUE(RFAILED);
         }
         break;

      case CMTU_UISAP_CB:
      
         if (rsetCb->upd.uiSap.size < CMTU_MAX_SAP_UPD_ENT)
         {
            rsetCb->upd.uiSap.s[rsetCb->upd.uiSap.size].action = action;
            rsetCb->upd.uiSap.s[rsetCb->upd.uiSap.size].updReq = TRUE;
            rsetCb->upd.uiSap.s[rsetCb->upd.uiSap.size].cb = (PTR)cbPtr;
            rsetCb->upd.uiSap.size++;
         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTU078, (ErrVal)cbType,
                           "cmTuRunTimeUpd: #uiSapCb entries exceeded max");

            RETVALUE(RFAILED);
         }
         break;

      case CMTU_LISAP_CB:

         if (rsetCb->upd.liSap.size < CMTU_MAX_SAP_UPD_ENT)
         {
            rsetCb->upd.liSap.s[rsetCb->upd.liSap.size].action = action;
            rsetCb->upd.liSap.s[rsetCb->upd.liSap.size].updReq = TRUE;
            rsetCb->upd.liSap.s[rsetCb->upd.liSap.size].cb = (PTR)cbPtr;
            rsetCb->upd.liSap.size++;
         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTU079, (ErrVal)cbType,
                           "cmTuRunTimeUpd: #liSapCb entries exceeded max");

            RETVALUE(RFAILED);
         }
         break;

      case CMTU_DLG_CB:

         /* Check if the update is already present */
         for (i = 0; i < rsetCb->upd.dlg.size; i++)
         {
            if ((rsetCb->upd.dlg.s[i].updReq == TRUE) && 
                (rsetCb->upd.dlg.s[i].cb == (PTR) cbPtr) && 
                (rsetCb->upd.dlg.s[i].action == action))
               RETVALUE (ROK);
         }

         if (rsetCb->upd.dlg.size < CMTU_MAX_DLG_UPD_ENT)
         {
            rsetCb->upd.dlg.s[rsetCb->upd.dlg.size].action = action;
            rsetCb->upd.dlg.s[rsetCb->upd.dlg.size].updReq = TRUE;

            switch (action)
            {
               case CMPFTHA_ACTN_ADD:
               case CMPFTHA_ACTN_MOD:
               case CMPFTHA_ACTN_DEL:
                  break;
               default:
                  CMTULOGERROR_DEBUG(ECMTU080, (ErrVal)cbType,
                                     "cmTuRunTimeUpd: wrong action for dlg.");
                  RETVALUE(RFAILED);
            }
            rsetCb->upd.dlg.s[rsetCb->upd.dlg.size].cb = (PTR)cbPtr;
            rsetCb->upd.dlg.size++;

         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTU080, (ErrVal)cbType,
                           "cmTuRunTimeUpd: #dlg entries exceeded max");

            RETVALUE(RFAILED);
         }
         break;

      case CMTU_INV_CB:

         if (rsetCb->upd.inv.size < CMTU_MAX_INV_UPD_ENT)
         {
            rsetCb->upd.inv.s[rsetCb->upd.inv.size].action = action;
            rsetCb->upd.inv.s[rsetCb->upd.inv.size].updReq = TRUE;
            switch (action)
            {
               case CMPFTHA_ACTN_ADD:
                  break;
               case CMPFTHA_ACTN_MOD:
                  break;
               case CMPFTHA_ACTN_DEL:
                  break;
               default:
                  CMTULOGERROR_DEBUG(ECMTU080, (ErrVal)cbType,
                                     "cmTuRunTimeUpd: wrong action for inv.");
                  RETVALUE(RFAILED);
            }

            rsetCb->upd.inv.s[rsetCb->upd.inv.size].cb = (PTR)cbPtr;
            rsetCb->upd.inv.size++;
         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTU081, (ErrVal)cbType,
                           "cmTuRunTimeUpd: #inv entries exceeded max");

            RETVALUE(RFAILED);
         }
         break;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
      case CMTU_VERINFO_CB:

         if (rsetCb->upd.verInfoCb.updReq == FALSE)
         {
            rsetCb->upd.verInfoCb.updReq  = TRUE;  
            rsetCb->upd.verInfoCb.cb.action = action;
            cmMemcpy((U8 *) &rsetCb->upd.verInfoCb.cb.verInfo,
                     (U8 *) cbPtr, sizeof(ShtVerInfo));
         }
         else
         {
            CMTULOGERROR_DEBUG(ECMTUXXX, (ErrVal)cbType,
                       "cmTuRunTimeUpd: VerInfo RT update entries exceed 1");

            RETVALUE(RFAILED);
         }
         break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

      default:
      
         CMTULOGERROR_DEBUG(ECMTU082, (ErrVal)cbType,
                        "cmTuRunTimeUpd: Invalid cbType");

         RETVALUE(RFAILED);

   } /* end switch */

   /* mark shared data structure ready */
   rsetCb->upd.updReq = TRUE;

   RETVALUE(ROK);
   
} /* cmTuRunTimeUpd */


/*
 *
 *      Fun:   cmTuUpdPeer
 *
 *      Desc:  This function sends update messages to peer PSF at run
 *             time.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function is called by portable protocol layer in 
 *             a tightly coupled manner. Protocol layer must have updated 
 *             the shared update structure before calling this function. 
 *             This function will prepare the update messages and send 
 *             them to remote protocol layer PSF so that both can be in sync.
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuUpdPeer
(
CmTuCb    *tuCb           /* PSF control block */
)
#else
PUBLIC S16 cmTuUpdPeer(tuCb)
CmTuCb    *tuCb;          /* PSF control block */
#endif
{
   CmFthaRsetId  rsetId;        /* resource set Id            */
   CmTuRsetCb    *rsetCb;       /* resource set control block */
   Bool          innerLoop;     /* flag for inner while loop  */
   Bool          outerLoop;     /* flag for outer while loop  */
   Buffer        *mBuf;         /* message buffer             */
   MsgLen        mLen;          /* message length             */
   S16           size;          /* size of update block       */
   U16           lastIdx;       /* Last updated index         */
   U8            nextTyp;       /* Last updated type          */
   SystemId      sysId;         /* System Id                  */
   U8            tblType;       /* update message table type */
   U8            action;        /* action    */
   S16           ret;           /* return value               */
   U16           i;             /* loop counter */
   CmTuRtUpdPsfCb psfUpdCb;   /* update the PSF control block          */

   TRC3(cmTuUpdPeer)

   CMTUDBGP(DBGMASK_PLI, (tuCb->init.prntBuf, "cmTuUpdPeer:\n"));
   
   /* check if rsetCb list has been configured */
   if (tuCb->rsetCbLst == NULLP)
   {
      CMTULOGERROR_INT_PAR(ECMTU083, (ErrVal)0,
        "cmTuUpdPeer: rsetCb list hasn't been configured.\n");
      RETVALUE(RFAILED);
   }
   
   rsetId = CMFTHA_RES_RSETID;
   rsetCb = tuCb->rsetCbLst[rsetId];
   
   if (rsetCb == NULLP)
   {
      CMTULOGERROR_INT_PAR(ECMTU084, (ErrVal)0,
                        "cmTuUpdPeer: invalid rset Id\n");
      RETVALUE(RFAILED);
   }

   if (rsetCb->upd.updReq != TRUE)
   {
      /* This is possible as protocol layer does not make this call 
       * deep into the code. Most of the places this function is called 
       * just before returning from the primitive and it is not known if
       * the shared data structure has been updated at all.
       */
      RETVALUE(ROK);
   }

   rsetCb->rtNextUpdType = CMTU_RSET_CB;
   rsetCb->rtLastUpdIdx  = 0;

   /* Get the PSF software version information. This information is packed 
      into the update message header */
   tuCb->fn.tuGetSId(&sysId);

   outerLoop = TRUE;

   while (outerLoop)
   {
      /* allocate message buffer */
      if ((ret = cmTuGetBuf(tuCb, rsetCb,
                          CMPFTHA_PROC_RUNTIME, 
                          rsetCb->rtUpdSeqNmb++,
                          CMPFTHA_FLAG_MORE, 
                          &mBuf)) != ROK)
      {
         cmTuInitUpdStruct(tuCb, rsetId);
         tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, LCM_EVENT_UPDMSG_ERR, 
                           LCM_CAUSE_UNKNOWN);
         RETVALUE(RFAILED);
      }

      innerLoop = TRUE;
      while (innerLoop)
      {
         (Void)SFndLenMsg(mBuf, &mLen);

         size = tuCb->updSize[rsetCb->rtNextUpdType];

         if ((mLen + size) >= (MsgLen)tuCb->genCfg.maxUpdMsgSize)
         {
            innerLoop = FALSE;
         }
         else
         {
            lastIdx = rsetCb->rtLastUpdIdx;
            nextTyp = rsetCb->rtNextUpdType;

            switch (rsetCb->rtNextUpdType)
            {
               case CMTU_RSET_CB:       /* TCAP primary control block */
               {
                  CmTuRtUpdRsetCb rset;

                  if (rsetCb->upd.rsetCb.updReq)
                  {
                     rset.recovery = rsetCb->recovery;
                     ret = cmTuPkRsetCb(tuCb,&tuCb->peerPst,(PTR)&rset,mBuf);
                     rsetCb->upd.rsetCb.updReq = FALSE;
                  }
                  else
                  {
#ifdef TDS_ROLL_UPGRADE_SUPPORT
                     rsetCb->rtNextUpdType = CMTU_VERINFO_CB;
#else
                     rsetCb->rtNextUpdType = CMTU_PROT_CB; 
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

                  }
                  break;
               }

#ifdef TDS_ROLL_UPGRADE_SUPPORT
               case CMTU_VERINFO_CB:   /* version information control block */

                  if (rsetCb->upd.verInfoCb.updReq)
                  {

                     ret = cmTuPkVerInfoCb(tuCb,&tuCb->peerPst,
                                         (PTR)&rsetCb->upd.verInfoCb.cb, mBuf);

                     rsetCb->upd.verInfoCb.updReq = FALSE;
                  }
                  else
                  {
                     rsetCb->rtNextUpdType = CMTU_PROT_CB;
                  }
                  break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

               case CMTU_PROT_CB:
                  ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                   CMPFTHA_ACTN_ADD, CMTU_PROTCB_TAB,  
                                   (PTR)(tuCb->fn.tuGetProtCb()), FALSE, mBuf);
                  rsetCb->rtNextUpdType = CMTU_PSF_CB;
                  break;

               case CMTU_PSF_CB:
                  psfUpdCb.usta = tuCb->init.usta;
                  psfUpdCb.cookie = tuCb->cookie;
                  ret = cmTuPkPsfCb(tuCb,&tuCb->peerPst,
                                    (PTR)&psfUpdCb, mBuf);
                  rsetCb->rtNextUpdType = CMTU_UISAP_CB;
                  break;

               case CMTU_UISAP_CB:   /* Upper sap control block */
                 
                  if ((lastIdx < rsetCb->upd.uiSap.size) &&
                      (rsetCb->upd.uiSap.s[lastIdx].updReq))
                  {
                     ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                      rsetCb->upd.uiSap.s[lastIdx].action,
                                      CMTU_UISAP_TAB,  
                                      (PTR)rsetCb->upd.uiSap.s[lastIdx].cb, 
                                      TRUE, mBuf);

                     rsetCb->upd.uiSap.s[lastIdx].cb = NULLP;
             
                     rsetCb->upd.uiSap.s[lastIdx].updReq = FALSE;
                     rsetCb->rtLastUpdIdx++;
                  }
                  else
                  {
                     rsetCb->rtNextUpdType = CMTU_LISAP_CB;
                     rsetCb->rtLastUpdIdx  = 0;
                  }
                  break;

               case CMTU_LISAP_CB:   /* Lower sap control block */
                 
                  if ((lastIdx < rsetCb->upd.liSap.size) &&
                      (rsetCb->upd.liSap.s[lastIdx].updReq))
                  {
                     ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, 
                                      rsetCb->upd.liSap.s[lastIdx].action,
                                      CMTU_LISAP_TAB,  
                                      (PTR)rsetCb->upd.liSap.s[lastIdx].cb, 
                                      TRUE, mBuf);

                     rsetCb->upd.liSap.s[lastIdx].cb = NULLP;

                     rsetCb->upd.liSap.s[lastIdx].updReq = FALSE;
                     rsetCb->rtLastUpdIdx++;
                  }
                  else
                  {
                     rsetCb->rtNextUpdType = CMTU_DLG_CB;
                     rsetCb->rtLastUpdIdx  = 0;
                  }
                  break;


               case CMTU_DLG_CB:     /* Dialogue control block */

                  if ((lastIdx < rsetCb->upd.dlg.size) &&
                      (rsetCb->upd.dlg.s[lastIdx].updReq))
                  {
                     action = rsetCb->upd.dlg.s[lastIdx].action;
                     switch (action)
                     {
                        case CMPFTHA_ACTN_ADD:
                           tblType = CMTU_ADDDLG_TAB;
                           break;
                        case CMPFTHA_ACTN_MOD:
                           tblType = CMTU_MODDLG_TAB;
                           break;
                        case CMPFTHA_ACTN_DEL:
                           tblType = CMTU_DELDLG_TAB;
                           
                           /* If the update is to delete the dialogue, 
                            * then remove all the invoke control blocks 
                            * for this dialogue, from rsetCb->upd.inv.
                            */

                           /* Do we need to check if the invokes
                            * belong to the dlg? It does not seem to
                            * the case... */
                           for (i=0; i<rsetCb->upd.inv.size; i++)
                           {
                              rsetCb->upd.inv.s[i].updReq = FALSE;
                           }
                           break;
                        default:
                           {
                              /* Will never come here */      
                              RETVALUE(RFAILED);
                           }
                     } /* end switch action */
                     
                     ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, action, tblType,
                                      rsetCb->upd.dlg.s[lastIdx].cb, 
                                      TRUE, mBuf);

                     rsetCb->upd.dlg.s[lastIdx].cb = NULLP;


                     rsetCb->upd.dlg.s[lastIdx].updReq = FALSE;
                     rsetCb->rtLastUpdIdx++;
                  }
                  else
                  {
                     rsetCb->rtNextUpdType = CMTU_INV_CB;
                     rsetCb->rtLastUpdIdx  = 0;
                  }
                  break;

               case CMTU_INV_CB:   /* Invoke control block */

                  if ((lastIdx < rsetCb->upd.inv.size) &&
                      (rsetCb->upd.inv.s[lastIdx].updReq))
                  {
                     action = rsetCb->upd.inv.s[lastIdx].action;
                     switch (action)
                     {
                        case CMPFTHA_ACTN_ADD:
                           tblType = CMTU_ADDINV_TAB;
                           break;
                        case CMPFTHA_ACTN_MOD:
                           tblType = CMTU_MODINV_TAB;
                           break;
                        case CMPFTHA_ACTN_DEL:
                           tblType = CMTU_DELINV_TAB;
                           break;
                        default:
                        {
                           /* Will never come here */      
                           RETVALUE(RFAILED);
                        }
                     } /* end switch action */

                     ret = cmTuPkTuCb(tuCb, &tuCb->peerPst, action, tblType,
                                      rsetCb->upd.inv.s[lastIdx].cb, 
                                      TRUE, mBuf);

                     rsetCb->upd.inv.s[lastIdx].cb = NULLP;

                     rsetCb->upd.inv.s[lastIdx].updReq = FALSE;
                     rsetCb->rtLastUpdIdx++;
                  }
                  else
                  {
                     rsetCb->rtLastUpdIdx  = 0;
                     innerLoop = FALSE;
                     outerLoop = FALSE;
                  }
                  break;

               default:

                  CMTULOGERROR_DEBUG(ECMTU085, (ErrVal)rsetCb->rtNextUpdType,
                                 "cmTuUpdPeer: Invalid table type");

                  ret = RFAILED;

                  break;
            } /* end switch */

         } /* end else */

         if (ret == RFAILED)
         {
            innerLoop = FALSE;
         }

      } /* end inner while */

      if (ret == ROK)
      {
         /* send the message with proper more indication */
         rsetCb->sts.txRT++;
         ret = cmTuSendPeerMsg(tuCb, rsetId, mBuf, (Bool)(!outerLoop),
                               CMPFTHA_PROC_RUNTIME);
      }

      if (ret == RFAILED)
      {
         cmTuInitUpdStruct(tuCb, rsetId);
         tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, LCM_EVENT_UPDMSG_ERR, 
                           LCM_CAUSE_UNKNOWN);
         RETVALUE(RFAILED);
      }

      /* Note that rtUpdSeqNmb is incremented in case of failure also. This
       * is because even if the alarm doesn't reach LM, standby will be able
       * to detect out of sequence error later.
       */
      
   } /* end outer while */
   
   cmTuInitUpdStruct(tuCb, rsetId);

   RETVALUE(ROK);
   
} /* cmTuUpdPeer */


/*
 *
 *       Fun:  cmTuAddMapping
 *
 *       Desc: Add a mapping of the dialogue control block 
 *             to the resource set.
 *
 *       Ret:  Void
 *
 *       Notes: 
 *
 *       File: cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuAddMapping
(
CmTuCb        *tuCb,      /* PSF control block */
PTR           dlgCp       /* dialogue control block pointer */
)
#else
PUBLIC Void cmTuAddMapping (tuCb, dlgCp)
CmTuCb        *tuCb;      /* PSF control block */
PTR           dlgCp;      /* dialogue control block pointer */
#endif
{
   CmFthaRsetId     rsetId;   /* resource set Id                          */
   CmTuRsetCb       *rsetCb;  /* resource set control block               */
   CmPFthaRsetMap   *tuDlgMap; /* cb which embedded in dlg control blocks */

   TRC2 (cmTuAddMapping)

   if (!tuCb->init.cfgDone)
   {
      CMTULOGERROR_DEBUG(ECMTU076, (ErrVal)0,
                 "cmTuAddMapping: PSF is not configured");
      RETVOID;
   }

   rsetId = CMFTHA_RES_RSETID;

   CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, 
             "cmTuAddMapping (rsetId (%d))\n", rsetId));

   /* get the resource set control block */
   rsetCb = tuCb->rsetCbLst[rsetId];  

   tuDlgMap = (CmPFthaRsetMap *)(dlgCp + tuCb->offset);

   cmTuInsertDLL (tuCb, tuDlgMap, rsetCb);

   RETVOID;
   
} /* cmTuAddMapping */

  
/*
 *
 *       Fun:  cmTuDelMapping
 *
 *       Desc: Del mapping of the control block to the resource set.
 *             It is not possible to do a fool proof sanity check.
 *             I hope all hooks within protocol layer are sane.
 *
 *       Ret:  Void
 *
 *       Notes: 
 *
 *       File: cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuDelMapping 
(
CmTuCb      *tuCb,      /* PSF control block */
PTR         dlgCp       /* dialogue control block pointer */
)
#else
PUBLIC Void cmTuDelMapping (tuCb, dlgCp)
CmTuCb      *tuCb;      /* PSF control block */
PTR         dlgCp;      /* dialogue control block pointer */
#endif
{
   CmFthaRsetId     rsetId;     /* resource set Id                          */
   CmTuRsetCb       *rsetCb;    /* resource set control block               */
   CmPFthaRsetMap   *tuDlgMap;  /* cb which embedded in TCAP control blocks */

   TRC2 (cmTuDelMapping)

   if (!tuCb->init.cfgDone)
   {
      CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, 
             "cmTuDelMapping: PSF is not configured, if not SHUTDOWN case,\
 may cause problem"));

      RETVOID;
   }

   rsetId = CMFTHA_RES_RSETID;

   CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, 
             "cmTuDelMapping (rsetId (%d))\n", rsetId));

   rsetCb = tuCb->rsetCbLst[rsetId];

   tuDlgMap = (CmPFthaRsetMap *)(dlgCp + tuCb->offset);

   /*
   ** Adjust the recent warmstarted dialogue when the 
   ** warmstart is in progress 
   */

   if((rsetCb->updState == CMPFTHA_US_WARMSTART) && 
      (rsetCb->dlgCp == dlgCp))
   {
      if(tuDlgMap->prev != (CmPFthaRsetMap *)NULLP)
      {

         rsetCb->dlgCp = (PTR)tuDlgMap->prev - (PTR)tuCb->offset;
      }
      else
      {
         rsetCb->dlgCp = (PTR)NULLP;
      }
   }

   cmTuRemoveDLL (tuCb, tuDlgMap, rsetCb);

   RETVOID;
   
} /* cmTuDelMapping */


  
/*
*
*       Fun:   cmTuChkRsetStatus
*
*       Desc:  Check if protocol layer is capable of handling the message
*              for critical data. It is a sanity check.
*
*       Ret:   TRUE (if event can be processed)
*              FALSE (if event cannot be processed)
*
*       Notes: The aim is to ensure that requests meant for critical
*              data are not processed in the standby (in FTHA), because 
*              such processing will result in invalid *system* state. 

*
*       File:  cm_tupsf.c
*/

#ifdef ANSI
PUBLIC S16 cmTuChkRsetStatus
(
CmTuCb      *tuCb,               /* PSF control block */
Bool        critical             /* if critical */
)
#else
PUBLIC S16 cmTuChkRsetStatus(tuCb, critical)
CmTuCb      *tuCb;              /* PSF control block */
Bool        critical;           /* if critical */
#endif
{
   CmFthaRsetId   rsetId;  /* resource set id */

   TRC2 (cmTuChkRsetStatus);

   CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, "cmTuChkRsetStatus\n"));

#if (ERRCLASS & ERRCLS_DEBUG)    
   if (!tuCb->init.cfgDone)
   {
      CMTULOGERROR_DEBUG(ECMTU113, (ErrVal)0, 
                   "cmTuChkRsetStatus: PSF is not configured");
      RETVALUE(FALSE);
   }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */

   rsetId = CMFTHA_RES_RSETID;

   if (critical)
   {
      if ((tuCb->rsetCbLst[rsetId]->state == CMPFTHA_STATE_ACTIVE) && 
          (tuCb->rsetCbLst[rsetId]->updState != CMPFTHA_US_PEERSYNC) &&
          (tuCb->rsetCbLst[rsetId]->updState != CMPFTHA_US_PEERSYNC_WAIT) &&
          (tuCb->rsetCbLst[rsetId]->updState != CMPFTHA_US_PEERSYNC_FIN))
      {
         RETVALUE (TRUE);          
      }
   }
   else
   {
      if (tuCb->rsetCbLst[rsetId]->state == CMPFTHA_STATE_ACTIVE) 
      {
         RETVALUE (TRUE);          
      }
   }
   RETVALUE (FALSE);
} /* cmTuChkRsetStatus */


/********************************************************************20**
  peer interface functions
*********************************************************************21*/

/* outbound Peer interface functions */

/*
 *
 *      Fun:   cmTuSendPeerMsg
 *
 *      Desc:  This function sends the update message to peer PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cmTu_bdy3.c
 *
 */

#ifdef ANSI
PUBLIC S16 cmTuSendPeerMsg
(
CmTuCb       *tuCb,                /* PSF control block   */
CmFthaRsetId rsetId,               /* Resource set Id       */
Buffer       *mBuf,                /* message buffer               */
Bool         last,                 /* last message in the sequence */
U8           procType              /* Procedure RT/WS/CS           */
)
#else
PUBLIC S16 cmTuSendPeerMsg (tuCb, rsetId, mBuf, last,procType)
CmTuCb       *tuCb;                /* PSF control block   */
CmFthaRsetId rsetId;               /* Resource set Id       */
Buffer       *mBuf;                /* message buffer               */
Bool         last;                 /* last message in the sequence */
U8           procType;             /* Procedure RT/WS/CS           */
#endif
{
   S16          ret;     /* return value                */
   U8           flag;    /* More flag                */
   CmTuRsetCb   *rsetCb; /* resourse set control block */
#ifdef DEBUGP
   CmFthaSeqNum seqNum;  /* seqNum                   */
#endif /* DEBUGP */
  
   TRC2 (cmTuSendPeerMsg)

   /* Get the pointer to resource set control block */
   rsetCb = tuCb->rsetCbLst[rsetId];

   /* check if more byte needs to be updated */
   if (last == TRUE)
   {
      ret = cmPFthaUHGetFlag(mBuf,&flag);
     
      if(ret == ROK)
      {
         /* Setting that this is the last message */
         flag &= (~CMPFTHA_FLAG_MORE);

         ret = cmPFthaUHSetFlag(mBuf,flag);
      }
      
      if (ret != ROK)
      {
         CMTU_FREE_BUF(mBuf);
         RETVALUE(RFAILED);
      }
   }
     
   /* Add invalid table type in the last */
   if ((ret = SAddPstMsg((Data)CMPFTHA_INV_TT, mBuf)) != ROK)
   {
      CMTU_FREE_BUF(mBuf);
      RETVALUE(RFAILED);
   }
  
#ifdef DEBUGP
   cmPFthaUHGetSeqNum(mBuf,&seqNum);
   cmPFthaUHGetFlag(mBuf,&flag);

   CMTUDBGP (CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
      "cmTuSendPeerMsg:rsetId(%d) Type of Update(%d) SeqNum(%d) MoreFlg(%d)\n",
      rsetCb->rsetId,procType,seqNum,flag));
#endif /* DEBUGP */ 
   /*Modifing the peer Pst destination procId */ 
   tuCb->peerPst.dstProcId=rsetCb->rsetId;
   CmTuPiOubDatReq(tuCb, &tuCb->peerPst, mBuf);

   tuCb->peerPst.route = RTE_RT_UPD;
   SPstTsk(&tuCb->peerPst, mBuf);
   RETVALUE(ret);

} /* cmTuSendPeerMsg */


/*
 *
 *      Fun:   CmTuPiOubDatReq
 *
 *      Desc:  This function sends data request to peer TCAP PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 CmTuPiOubDatReq
(
CmTuCb         *tuCb,      /* PSF control block */
Pst            *pst,       /* post */
Buffer         *mBuf       /* message buffer */
)
#else
PUBLIC S16 CmTuPiOubDatReq(tuCb, pst, mBuf)
CmTuCb         *tuCb;      /* PSF control block */
Pst            *pst;       /* post */
Buffer         *mBuf;      /* message buffer */
#endif
{
   TRC3(CmTuPiOubDatReq)

   CMTUDBGP(DBGMASK_PI, (tuCb->init.prntBuf, "CmTuPiOubDatReq()\n"))
 
   /* post the message */
   pst->event = EVTZUPIDATREQ;
   if(tuCb->rsetCbLst[CMFTHA_RES_RSETID]->trc)
   {
      tuCb->fn.tuSendTrace(CMFTHA_RES_RSETID, CMTU_BUF_TX,mBuf);
   }

   RETVALUE(ROK);
} /* end of CmTuPiOubDatReq */


/*
 *
 *      Fun:   CmTuSiOubSchReq
 *
 *      Desc:  This function sends a self scheduling request to SCCP.       
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  zj_bdy1.c
 *
 */

#ifdef ANSI
PUBLIC  S16 CmTuSiOubSchReq
(
CmTuCb   *tuCb,           /* PSF control block */
Pst      *pst,            /* post structure */
Buffer   *mBuf            /* Message Buffer */
)
#else
PUBLIC  S16 CmTuSiOubSchReq(tuCb,pst,mBuf)
CmTuCb   *tuCb;           /* PSF control block */
Pst      *pst;            /* post structure */
Buffer   *mBuf;           /* Message Buffer */
#endif
{

   TRC2 (CmTuSiOubSchReq)
   CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, "CmTuSiOubSchReq\n"));

   pst->event = EVTZUSISCHREQ;

   /* post the message */
   RETVALUE( SPstTsk(pst, mBuf) );
      
} /* CmTuSiOubSchReq */


/*
 *
 *      Fun:   CmTuPiOubDatCfm
 *
 *      Desc:  This function sends data confirm to peer TCAP PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 CmTuPiOubDatCfm
(
CmTuCb       *tuCb,        /* PSF control block */
CmTuRsetCb   *rsetCb,      /* pointer resource set Cb */   
U8           status        /* status                  */
)
#else
PUBLIC S16 CmTuPiOubDatCfm(tuCb, rsetCb, status)
CmTuCb       *tuCb;        /* PSF control block */
CmTuRsetCb   *rsetCb;      /* pointer resource set Cb */
U8           status;       /* status                  */
#endif
{
   CmPFthaCfmHdr    hdr;        /* confirm message header */
   Buffer           *mBuf;      /* message buffer         */

   TRC3(CmTuPiOubDatCfm)

   CMTUDBGP(DBGMASK_PI, 
             (tuCb->init.prntBuf, "CmTuPiOubDatCfm:Status(%d)\n", status))
             
   hdr.mVer   = tuCb->sysId.mVer;
   hdr.mRev   = tuCb->sysId.mRev;
   hdr.bVer   = tuCb->sysId.bVer;
   hdr.rsetId = rsetCb->rsetId;   
   hdr.cfm    = status;          

   if (SGetMsg(tuCb->peerPst.region, tuCb->peerPst.pool, &mBuf) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      CMTULOGERROR_ADD_RES(ECMTU076, (ErrVal)0,
                        "CmTuPiOubDatCfm : SGetMsg failed");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
      RETVALUE(RFAILED);
   }
    
   /* pack parameters */
   if ((cmPFthaCHPk(&hdr, mBuf)) != ROK)
   {
#if (ERRCLASS & ERRCLS_INT_PAR)
      CMTULOGERROR_INT_PAR(ECMTU053, (ErrVal) 0,
                   "CmTuPiOubDatCfm : cmPFthaCHPk failed");
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */
      CMTU_FREE_BUF(mBuf);
      RETVALUE(RFAILED);
   }

   if ((SAddPstMsg ((Data)CMPFTHA_INV_TT, (mBuf))) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      CMTULOGERROR_ADD_RES(ECMTU118,0,
                   "CmTuPiOubDatCfm: cannot insert TT");
#endif /* (ERRCLASS & ERRCLS_ADD_RES) */
      CMTU_FREE_BUF(mBuf);
      RETVALUE(RFAILED);
   }

   /* post the message 
    * Fill the peer pst structure.
    * dstEnt, dstInst - will be filled by MR.
    * event - will be filled in the packing function
    * Remaining fields are already filled.
    */
   tuCb->peerPst.route = RTESPEC;
   tuCb->peerPst.event     = EVTZUPIDATCFM;

   if (rsetCb->trc)
   {
      tuCb->fn.tuSendTrace (rsetCb->rsetId, CMTU_BUF_TX, mBuf);
   }
   RETVALUE( SPstTsk(&tuCb->peerPst, mBuf) );
} /* end of CmTuPiOubDatCfm */

/* inbound Peer interface functions */


/*
 *
 *      Fun:   CmTuPiInbDatReq
 *
 *      Desc:  Peer interface inbound data request. This function processes 
 *             all update messages from the peer PSF.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
        File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 CmTuPiInbDatReq
(
CmTuCb       *tuCb,                   /* PSF control block */
Pst          *pst,                    /* post           */
Buffer       *mBuf                    /* message buffer */
)
#else
PUBLIC S16 CmTuPiInbDatReq (tuCb, pst, mBuf)
CmTuCb       *tuCb;                   /* PSF control block */
Pst          *pst;                    /* post           */
Buffer       *mBuf;                   /* message buffer */
#endif
{
   CmPFthaUpdHdr        uHdr;            /* update message header */
   CmTuRsetCb           *rsetCb;         /* pointer to rset Cb    */
   S16                  ret;             /* return value          */

   TRC3 (CmTuPiInbDatReq)

   tuCb->peerPst.dstProcId = pst->srcProcId;

   /* first unpack header from the message */
   if ((ret = cmPFthaUHUnpk(&uHdr, mBuf)) != ROK)
   {
      CMTU_FREE_BUF(mBuf);
      tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA,
                        LCM_EVENT_UPDMSG_ERR,LCM_CAUSE_UNKNOWN);

      CMTULOGERROR_INT_PAR(ECMTU053, (ErrVal) 0,
                     "CmTuPiInbDatReq: header unpacking failed ");

      RETVALUE(RFAILED);
   }

   CMTUDBGP(DBGMASK_PI, (tuCb->init.prntBuf,
    "InbDatReq:hdr.rsetId (%d) hdr.procType (%d) hdr.seqNum (%d) hdr.flag(%d)\n",
    uHdr.rsetId, uHdr.procType, uHdr.seqNum, uHdr.flag));

#ifndef TDS_ROLL_UPGRADE_SUPPORT
   /* match the versoin number */
   if ((uHdr.mVer != tuCb->sysId.mVer) ||
       (uHdr.mRev != tuCb->sysId.mRev) ||
       (uHdr.bVer != tuCb->sysId.bVer))
   {
      CMTU_FREE_BUF(mBuf);

      tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA,
                        LCM_EVENT_UPDMSG_ERR,LCM_CAUSE_UNKNOWN);

      CMTULOGERROR_INT_PAR(ECMTU054, (ErrVal) 0,
                     "CmTuPiInbDatReq: Invalid version number.");

      RETVALUE(RFAILED);      
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */
   
   /* validate the resource set id  */
   if (!(CMTU_IS_VALID_RSET(uHdr.rsetId)))
   {
      CMTU_FREE_BUF(mBuf);

      tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA,
                        LCM_EVENT_UPDMSG_ERR,LCM_CAUSE_UNKNOWN);

      CMTULOGERROR_DEBUG(ECMTU055, (ErrVal) 0,
                     "CmTuPiInbDatReq: Invalid rset.");

      RETVALUE(RFAILED);      
   }

   rsetCb = tuCb->rsetCbLst[uHdr.rsetId];
   
   /* send trace ,if trace flag was enabled */
   if (rsetCb->trc == TRUE)
   {
      tuCb->fn.tuSendTrace(uHdr.rsetId, CMTU_BUF_RX, mBuf);
   }

   /* check peer status */
   if (rsetCb->state != CMPFTHA_STATE_STANDBY)
   {
      CMTU_FREE_BUF(mBuf);
      CMTULOGERROR_INT_PAR(ECMTU056, (ErrVal) rsetCb->state,
                     "CmTuPiInbDatReq: Not Standby ");

      RETVALUE(RFAILED);
   }

   /* check peer status */
   if (rsetCb->peerState == CMPFTHA_PEER_DEAD)
   {
      CMTU_FREE_BUF(mBuf);

      CMTULOGERROR_INT_PAR(ECMTU057, (ErrVal) uHdr.rsetId,
                     "CmTuPiInbDatReq: rset peer is dead ");

      RETVALUE(RFAILED);
   }
   
   /* switch on update message type */
   switch (uHdr.procType)
   {
      case CMPFTHA_PROC_RUNTIME:  /* run time update message */

         /* check sequence number */
         if (uHdr.seqNum != rsetCb->rtUpdSeqNmb)
         {
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU061, (ErrVal)uHdr.seqNum,
              "CmTuPiInbDatReq: run time seqNum mismatch");

            /* send alarm */
            tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA,LCM_EVENT_SEQERR, 
                              LCM_CAUSE_UNKNOWN);

            /* No need to make the sap unbound. This will take care of 
             * sending further alarms if first one is lost.
             */
            RETVALUE(RFAILED);
         }

         /* Add message to run time hold queue */

         if ((ret = SQueueLast(mBuf, &rsetCb->rtUpdHoldQ)) != ROK)
         {
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU062, 0,
                  "InbDatReq(). SQueueLast  failed");

            RETVALUE(RFAILED);
         }

         /* if this was the last message then decode messages */
         if (!(uHdr.flag & CMPFTHA_FLAG_MORE))
         {
            while ((ret = SDequeueFirst(&mBuf, &rsetCb->rtUpdHoldQ))
                    == ROK)
            {
               if ((ret = cmTuDecUpdMsg(tuCb, pst, mBuf)) != ROK)
               {
                  tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, 
                                    LCM_EVENT_UPDMSG_ERR, LCM_CAUSE_UNKNOWN);

                  RETVALUE(RFAILED);
               }
            }
         }

         /* increment expected sequence number */
         rsetCb->rtUpdSeqNmb++;
         rsetCb->sts.rxRT++;
         break;
         
      case CMPFTHA_PROC_WARMSTART: /* warm start update message */

         if (rsetCb->updState == CMPFTHA_US_IDLE)
         {
            /* first warm start message */
            rsetCb->updState      = CMPFTHA_US_WARMSTART;
            rsetCb->acceptRTMsg   = TRUE; 

#ifdef TDS_ROLL_UPGRADE_SUPPORT
            /* this version number is used by standby to send confirms to
             * active after completion of warmstart or peersync procedures
            */
            tuCb->peerPst.intfVer = pst->intfVer;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         }
         else if (rsetCb->updState != CMPFTHA_US_WARMSTART)
         {
            /* this update message has come in abrupt state */
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU063,(ErrVal)rsetCb->updState,
                           "CmTuPiInbDatReq: Invalid updState");

            /* send negative confirm to active */
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);

            RETVALUE(RFAILED);
         }

         /* check sequence number */
         if (uHdr.seqNum != rsetCb->wsSeqNmb)
         {
            CMTUDBGP(DBGMASK_PI, (tuCb->init.prntBuf,
            "InbDatReq:RsetId(%d), Arrived SeqNmb(%d), Expected SeqNmb(%d)\n ",
                    uHdr.rsetId, uHdr.seqNum, rsetCb->wsSeqNmb));
   
            CMTU_FREE_BUF(mBuf);

            CMTULOGERROR_INT_PAR(ECMTU064, (ErrVal)uHdr.seqNum,
                           "CmTuPiInbDatReq: bulk upd seqNmb mismatch");

            /* send negative confirm to active */
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);

            RETVALUE(RFAILED);
         }

         if ((ret = cmTuDecUpdMsg(tuCb, pst, mBuf)) != ROK)
         {
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);

            RETVALUE(RFAILED);
         }

         /* increment expected sequence number */
         rsetCb->sts.rxWS++;
         rsetCb->wsSeqNmb++;

         /* now if this was the last message send positive confirm */
         if (!(uHdr.flag & CMPFTHA_FLAG_MORE))
         {
            rsetCb->sts.txWS++;
            rsetCb->updState = CMPFTHA_US_IDLE;
            rsetCb->wsSeqNmb = 0;

            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_OK);
         }
         break;

      case CMPFTHA_PROC_PEERSYNC: /* controlled switchover update message */

         if (rsetCb->updState == CMPFTHA_US_IDLE)
         {
            /* first Controlled switchover message */
            rsetCb->updState = CMPFTHA_US_PEERSYNC;
         }
         else if (rsetCb->updState != CMPFTHA_US_PEERSYNC)
         {
            /* this update message has come in abrupt state */
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU065, (ErrVal)rsetCb->updState,
                           "CmTuPiInbDatReq: Invalid updState");

            /* send negative confirm to active */
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);

            RETVALUE(RFAILED);
         }

         /* check sequence number */
         if (uHdr.seqNum != rsetCb->csSeqNmb)
         {
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU066, (ErrVal)uHdr.seqNum,
               "CmTuPiInbDatReq: bulk upd seqNmb mismatch");

            /* send negative confirm to active */
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);

            RETVALUE(RFAILED);
         }

         if ((ret = cmTuDecUpdMsg(tuCb, pst, mBuf)) != ROK)
         {
            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_NOK);
            RETVALUE(RFAILED);
         }

         /* increment expected sequence number */
         rsetCb->sts.rxCS++;
         rsetCb->csSeqNmb++;

         /* now if this was the last message send positive confirm */
         if (!(uHdr.flag & CMPFTHA_FLAG_MORE))
         {
            rsetCb->sts.txCS++;
            rsetCb->updState = CMPFTHA_US_PEERSYNC_FIN;
            rsetCb->csSeqNmb = 0;

            CmTuPiOubDatCfm(tuCb, rsetCb, CMPFTHA_CFM_OK);
         }
         break;

      default:

         CMTU_FREE_BUF(mBuf);
         CMTULOGERROR_INT_PAR(ECMTU071, (ErrVal) uHdr.procType,
                        "CmTuPiInbDatReq: Invalid message type");

         RETVALUE(RFAILED);

   } /* switch */

   RETVALUE(ROK);
   
} /* CmTuPiInbDatReq */


/*
 *
 *      Fun:   CmTuPiInbDatCfm
 *
 *      Desc:  Peer interface inbound data confirm. This function handles
 *             all data confirms from the peer PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 CmTuPiInbDatCfm
(
CmTuCb           *tuCb,             /* PSF control block */
Pst              *pst,              /* post                       */
Buffer           *mBuf              /* message Buffer             */
)
#else
PUBLIC S16 CmTuPiInbDatCfm (tuCb, pst, mBuf)
CmTuCb           *tuCb;            /* PSF control block */
Pst              *pst;              /* post                       */
Buffer           *mBuf;             /* message Buffer             */
#endif
{
   CmFthaRsetId rsetId;

   TRC3 (CmTuPiInbDatCfm)

   CMTUDBGP(DBGMASK_PI, (tuCb->init.prntBuf, "CmTuPiInbDatCfm() \n"));

   rsetId = CMFTHA_INV_RSETID;

   if ((cmPFthaCHGetRsetId (mBuf, &rsetId) == ROK) &&
       (CMTU_IS_VALID_RSET (rsetId)))
   {         
      if (tuCb->rsetCbLst[rsetId]->trc)
      {
         tuCb->fn.tuSendTrace (rsetId, CMTU_BUF_RX, mBuf);
      }
   }

   cmTuProcPeerCfmMsg (tuCb, mBuf);

   CMTU_FREE_BUF(mBuf);

   RETVALUE(ROK);
   
} /* CmTuPiInbDatCfm */


/*
 *
 *      Fun:   CmTuSiInbSchReq
 *
 *      Desc:  This function handles self scheduling event 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC S16 CmTuSiInbSchReq
(
CmTuCb       *tuCb,                 /* PSF control block */
Pst          *pst,                  /* post */
Buffer       *mBuf                  /* message buffer */
)
#else
PUBLIC S16 CmTuSiInbSchReq(tuCb, pst, mBuf)
CmTuCb       *tuCb;                 /* PSF control block */
Pst          *pst;                  /* post */
Buffer       *mBuf;                 /* message buffer */
#endif
{
   Pst           repPst;     /* Reply Post  */
   S16           reason;     /* reason      */
   CmFthaRsetId  rsetId;     /* resource set id */       

   TRC3(CmTuSiInbSchReq);

   UNUSED(pst);

   CMTUDBGP(DBGMASK_PI, 
          (tuCb->init.prntBuf, "CmTuPiInbSchReq\n"));

   CMTU_FREE_BUF(mBuf);
   cmTuBldReplyPst(tuCb, &repPst, &tuCb->pendOp.hdr, &tuCb->pendOp.pst);
   
   /* Is cntrl req aborted ?? */
   if (!tuCb->pendOp.flag)
      RETVALUE (ROK);

   rsetId = CMFTHA_RES_RSETID;

   switch (tuCb->pendOp.action)
   {
      case CMTU_AWARMSTART:

         reason = cmTuWarmStart(tuCb, rsetId);

         if (reason == CMTU_PEND)
         {
             cmTuPostContMsg(tuCb); 
             RETVALUE (ROK);
         }

         if (reason == CMTU_ERR)
         {
            cmTuAbortCurOp(tuCb, rsetId, &tuCb->pendOp); 

            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &tuCb->pendOp.hdr, 
                        LCM_PRIM_NOK, CMTU_REASON_INT_FAILURE);

            RETVALUE (ROK);
         }

         break;

      case CMTU_ASYNCHRONIZE:

         reason = cmTuSynchronize(tuCb, rsetId);

         if (reason == CMTU_PEND)
         {
            cmTuPostContMsg (tuCb); 
            RETVALUE (ROK);
         }

         if (reason == CMTU_ERR)
         {
            cmTuAbortCurOp(tuCb, rsetId, &tuCb->pendOp); 
            tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &tuCb->pendOp.hdr, 
                        LCM_PRIM_NOK, CMTU_REASON_INT_FAILURE);
            RETVALUE (ROK);
         }

         break;
      default:
         /* Something has gone wrong */
         CMTULOGERROR_INT_PAR(ECMTU072, (ErrVal)0,
                           "CmTuSiInbSchReq(). Invalid pending state");
         break;
   } /* end switch */

   RETVALUE(ROK);
} /* end of CmTuSiInbSchReq */

/********************************************************************20**
  packing and unpacking functions
*********************************************************************21*/

#ifndef TDS_FTHA_CUST_PKUNPK

/*
 *
 *      Fun:   cmTuPkStruct
 *
 *      Desc:  This function packs the structure in a platform 
 *             dependent way. 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function packs without worrying about platform 
 *             independence, simply to avoid packing overhead. As of
 *             now, we don't think peer will ever sit on a different
 *             type of platform.
 *
 *      File:  cm_tupsf.c
 *
 */ 
#ifdef ANSI 
PRIVATE S16 cmTuPkStruct 
(
CmTuCb *tuCb,                   /* PSF control block */
Pst    *pst,                    /* post */
U16     size,                   /* size of control block */
PTR     ptr,                    /* pointer to control block */
Buffer *mBuf                    /* message buffer */
)
#else
PRIVATE S16 cmTuPkStruct(tuCb, pst, size, ptr, mBuf)
CmTuCb *tuCb;                   /* PSF control block */
Pst    *pst;                    /* post */
U16     size;                   /* size of control block */
PTR     ptr;                    /* pointer to control block */
Buffer *mBuf;                   /* message buffer */
#endif
{
   S16  ret;          /* return value */

   TRC2(cmTuPkStruct)

   UNUSED(pst);

   /* Probably the layer has its own idiosyncranies
      while packing/unpacking */
   if (size == 0)
      RETVALUE (ROK); 

   if ((ret = SAddPstMsgMult((Data *)ptr, (MsgLen)size, mBuf)) != ROK)
   {
      /* cm_tupsf_c_002.main_3: the buffer deallocation removed to avoid double 
         deallocation in calling function on failure */


      CMTULOGERROR_DEBUG( ECMTU118, (ErrVal)0,
                     "cmTuPkStruct:SAddPstMsgMult Failed");

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmTuPkStruct */


/*
 *
 *      Fun:   cmTuUnpkStruct
 *
 *      Desc:  This function unpacks the structure in a  nonportable way.
 *              
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: This function unpacks without worrying about platform 
 *             independence, simply to avoid unpacking overhead. As of
 *             now , we don't think peer will ever sit on a different
 *             type of platform
 *
        File:  cm_tupsf.c
 *
 */ 
#ifdef ANSI 
PUBLIC  S16 cmTuUnpkStruct 
(
CmTuCb   *tuCb,                   /* PSF control block */
Pst      *pst,                    /* post */
U16       size,                   /* size of control block */
PTR       ptr,                    /* pointer to control block */
Buffer   *mBuf                    /* message buffer */
)
#else
PUBLIC  S16 cmTuUnpkStruct(tuCb, pst, size, ptr, mBuf)
CmTuCb   *tuCb;                   /* PSF control block */
Pst      *pst;                    /* post */
U16       size;                   /* size of control block */
PTR       ptr;                    /* pointer to control block */
Buffer   *mBuf;                   /* message buffer */
#endif
{
   S16   ret;          /* return value */

   TRC2(cmTuUnpkStruct)

   UNUSED(pst);

   /* The layers has its own way of pack/unpack */
   if (size == 0)
      RETVALUE (ROK);

   if ((ret = SRemPreMsgMult((Data *)ptr, (MsgLen)size, mBuf)) != ROK)
   {
      CMTU_FREE_BUF(mBuf);

      CMTULOGERROR_INT_PAR(ECMTU118, ERRZERO,
                          "cmTuUnpkStruct:SRemPreMsgMult Failed");

      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of cmTuUnpkStruct */
#endif /* TDS_FTHA_CUST_PKUNPK */


/*
 *
 *      Fun:   cmTuPkRtSeq
 *
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cmTu_bdy4.c
 *
 */
#ifdef ANSI
PUBLIC  S16 cmTuPkRtSeq
(
CmTuCb *tuCb,                   /* common psf control block */
Pst    *pst,                    /* post */
PTR     ptr,                    /* pointer to control block */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC  S16 cmTuPkRtSeq(tuCb, pst, ptr, mBuf)
CmTuCb *tuCb;                   /* common psf control block */
Pst    *pst;                    /* post */
PTR     ptr;                    /* pointer to control block */
Buffer *mBuf;                   /* message buffer */
#endif
{
   U8    tblType; /* update message table type */
   U16   size;    /* Update structure size */
   S16   ret;     /* return value */

   TRC2(cmTuPkRtSeq)

   CMTUDBGP(CMTU_DBGMASK_PACK, (tuCb->init.prntBuf, "cmTuPkRtSeq\n"));

   tblType = CMTU_RTSEQ_TAB;
   size    = sizeof(CmTuWsUpdRtSeq);

   /* pack table type */
   ret = SAddPstMsg((Data)tblType, mBuf);

   /* pack rset Id and rtSeqNmb */
   if(ret == ROK)
   {
      ret = cmTuPkStructFn(tuCb, pst, tblType, size, ptr, mBuf);
   }

   if (ret != ROK)
   {
      CMTU_FREE_BUF(mBuf);
   }
   RETVALUE(ret);

} /* end of cmTuPkRtSeq */


/*
 *
 *      Fun:   cmTuUnpkRtSeq
 *
 *      Desc:  This function unpacks RT Seq Nmb coming in the warmstart.
 *             This function also updates resource set data structures. 
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuUnpkRtSeq
(
CmTuCb   *tuCb,                   /* common psf control block */
Pst      *pst,                    /* post */
U8       tblType,                 /* table type */
Buffer   **pMsgBuf                /* message buffer */
)
#else
PUBLIC S16 cmTuUnpkRtSeq(tuCb, pst, tblType, pMsgBuf)
CmTuCb   *tuCb;                   /* common psf control block */
Pst      *pst;                    /* post */
U8       tblType;                 /* table type */
Buffer   **pMsgBuf;               /* message buffer */
#endif
{
   CmTuRsetCb    *rsetCb;    /* Pointer to resource set control block */
   U16            size;      /* Update control block size */
   S16            ret;       /* return value */
   CmTuWsUpdRtSeq updCb;     /* WS RtSeq update control block */
   Buffer         *mBuf;     /* message buffer */
   
   TRC2(cmTuUnpkRtSeq)

   size = sizeof(CmTuWsUpdRtSeq);
   mBuf = *pMsgBuf;

   if ((ret = cmTuUnpkStructFn(tuCb,pst,tblType,size,(PTR)&updCb,mBuf)) != ROK)
   {
      RETVALUE(ret);
   }

   CMTUDBGP(CMTU_DBGMASK_UNPACK, (tuCb->init.prntBuf,
    "cmTuUnpkRtSeq:recovery(%d) seqNmb(%d)\n",updCb.recovery,updCb.rtSeqNmb))

   rsetCb = tuCb->rsetCbLst[CMFTHA_RES_RSETID];
   rsetCb->rtUpdSeqNmb = updCb.rtSeqNmb;
   rsetCb->recovery    = updCb.recovery;  

   RETVALUE(ROK);
} /* end of cmTuUnpkRtSeq */



/*
 *
 *      Fun:   cmTuPkPsfCb
 *
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC  S16 cmTuPkPsfCb
(
CmTuCb *tuCb,                   /* common psf control block */
Pst    *pst,                    /* post */
PTR     ptr,                    /* pointer to control block */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC  S16 cmTuPkPsfCb(tuCb, pst, ptr, mBuf)
CmTuCb *tuCb;                   /* common psf control block */
Pst    *pst;                    /* post */
PTR     ptr;                    /* pointer to control block */
Buffer *mBuf;                   /* message buffer */
#endif
{
   U8    tblType; /* update message table type */
   U16   size;    /* Update structure size */
   S16   ret;     /* return value */

   TRC2(cmTuPkPsfCb)

   CMTUDBGP(CMTU_DBGMASK_PACK, (tuCb->init.prntBuf, "cmTuPkPsfCb\n"));

   tblType = CMTU_PSFCB_TAB; 
   size    = sizeof(CmTuRtUpdPsfCb);

   /* pack table type */
   ret = SAddPstMsg((Data)tblType, mBuf);

   /* pack rset Id and rtSeqNmb */
   if(ret == ROK)
   {
      ret = cmTuPkStructFn(tuCb, pst, tblType, size, ptr, mBuf);
   }

   if (ret != ROK)
   {
      CMTU_FREE_BUF(mBuf);
   }
   RETVALUE(ret);

} /* end of cmTuPkPsfCb */


/*
 *
 *      Fun:   cmTuUnpkPsfCb
 *
 *      Desc:  This function unpacks the PSF Cb.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuUnpkPsfCb
(
CmTuCb   *tuCb,                   /* common psf control block */
Pst      *pst,                    /* post */
U8       tblType,                 /* table type */
Buffer   **pMsgBuf                /* message buffer */
)
#else
PUBLIC S16 cmTuUnpkPsfCb(tuCb, pst, tblType, pMsgBuf)
CmTuCb   *tuCb;                   /* common psf control block */
Pst      *pst;                    /* post */
U8       tblType;                 /* table type */
Buffer   **pMsgBuf;               /* message buffer */
#endif
{
   U16             size;      /* Update control block size */
   S16             ret;       /* return value */
   CmTuRtUpdPsfCb  updCb;     /* WS RtSeq update control block */
   Buffer          *mBuf;     /* message buffer */
   
   TRC2(cmTuUnpkPsfCb)

   size = sizeof(CmTuRtUpdPsfCb);
   mBuf = *pMsgBuf;

   if ((ret = cmTuUnpkStructFn(tuCb,pst,tblType,size,(PTR)&updCb,mBuf)) != ROK)
   {
      RETVALUE(ret);
   }

   CMTUDBGP(CMTU_DBGMASK_UNPACK, (tuCb->init.prntBuf,
            "cmTuUnpkPsfCb:usta(%d)\n",updCb.usta))

   tuCb->init.usta = updCb.usta;  
   tuCb->cookie = (updCb.cookie==CMTU_HAVE_COOKIE)?CMTU_NO_COOKIE:CMTU_HAVE_COOKIE; 

   RETVALUE(ROK);
} /* end of cmTuUnpkPsfCb */


/*
 *
 *      Fun:   cmTuPkRsetCb
 *
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC  S16 cmTuPkRsetCb
(
CmTuCb *tuCb,                   /* common psf control block */
Pst    *pst,                    /* post */
PTR     ptr,                    /* pointer to control block */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC  S16 cmTuPkRsetCb(tuCb, pst, ptr, mBuf)
CmTuCb *tuCb;                   /* common psf control block */
Pst    *pst;                    /* post */
PTR     ptr;                    /* pointer to control block */
Buffer *mBuf;                   /* message buffer */
#endif
{
   U8    tblType; /* update message table type */
   U16   size;    /* Update structure size */
   S16   ret;     /* return value */

   TRC2(cmTuPkRsetCb)

   CMTUDBGP(CMTU_DBGMASK_PACK, (tuCb->init.prntBuf, "cmTuPkRsetCbNmb\n"));

   tblType = CMTU_RSET_TAB;
   size    = sizeof(CmTuRtUpdRsetCb);

   /* pack table type */
   ret = SAddPstMsg((Data)tblType, mBuf);

   /* pack rset Id and rtSeqNmb */
   if(ret == ROK)
   {
      ret = cmTuPkStructFn(tuCb, pst, tblType, size, ptr, mBuf);
   }

   if (ret != ROK)
   {
      CMTU_FREE_BUF(mBuf);
   }
   RETVALUE(ret);

} /* end of cmTuPkRsetCb */


/*
 *
 *      Fun:   cmTuUnpkRsetCb
 *
 *      Desc:  This function unpacks the rset Cb.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuUnpkRsetCb
(
CmTuCb   *tuCb,                   /* common psf control block */
Pst      *pst,                    /* post */
U8       tblType,                 /* table type */
Buffer   **pMsgBuf                /* message buffer */
)
#else
PUBLIC S16 cmTuUnpkRsetCb(tuCb, pst, tblType, pMsgBuf)
CmTuCb   *tuCb;                   /* common psf control block */
Pst      *pst;                    /* post */
U8       tblType;                 /* table type */
Buffer   **pMsgBuf;               /* message buffer */
#endif
{
   CmTuRsetCb      *rsetCb;   /* Pointer to resource set control block */
   U16             size;      /* Update control block size */
   S16             ret;       /* return value */
   CmTuRtUpdRsetCb updCb;     /* WS RtSeq update control block */
   Buffer          *mBuf;     /* message buffer */
   
   TRC2(cmTuUnpkRsetCb)

   size = sizeof(CmTuRtUpdRsetCb);
   mBuf = *pMsgBuf;

   if ((ret = cmTuUnpkStructFn(tuCb,pst,tblType,size,(PTR)&updCb,mBuf)) != ROK)
   {
      RETVALUE(ret);
   }

   CMTUDBGP(CMTU_DBGMASK_UNPACK, (tuCb->init.prntBuf,
            "cmTuUnpkRsetCb:recovery(%d)\n",updCb.recovery))

   rsetCb = tuCb->rsetCbLst[CMFTHA_RES_RSETID];
   rsetCb->recovery    = updCb.recovery;  

   RETVALUE(ROK);
} /* end of cmTuUnpkRsetCb */

#ifdef TDS_ROLL_UPGRADE_SUPPORT

/*
 *
 *      Fun:   cmTuPkVerInfoCb
 *
 *      Desc:  This function packs version info control block parameters to
 *             update message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuPkVerInfoCb
(
CmTuCb *tuCb,                   /* common psf control block */
Pst    *pst,                    /* post */
PTR     ptr,                    /* pointer to control block */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmTuPkVerInfoCb(tuCb, pst, ptr, mBuf)
CmTuCb *tuCb;                   /* common psf control block */
Pst    *pst;                    /* post */
PTR     ptr;                    /* pointer to control block */
Buffer *mBuf;                   /* message buffer */
#endif
{
   U8                  tblType; /* update message table type */
   U16                 size;    /* Update structure size */
   S16                 ret;     /* return value */

   TRC2(cmTuPkVerInfoCb)

   CMTUDBGP(CMTU_DBGMASK_PACK, (tuCb->init.prntBuf, "cmTuPkVerInfoCb:\n"));

   tblType = CMTU_VERINFO_TAB;
   size    = sizeof(CmTuRtUpdVerInfoCb);

   /* pack table type */
   ret = SAddPstMsg((Data)tblType, mBuf);

   if(ret == ROK)
   {
      ret = cmTuPkStructFn(tuCb, pst, tblType, size, (PTR)ptr, mBuf);
   }

   if (ret != ROK)
   {
      CMTU_FREE_BUF(mBuf);
   }

   RETVALUE(ret);

} /* end of cmTuPkVerInfoCb */


/*
 *
 *      Fun:   cmTuUnpkVerInfoCb
 *
 *      Desc:  This function unpacks ver info control block from the update 
 *             message. This function also updates ver info in protocol 
 *             control block with the received information
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuUnpkVerInfoCb
(
CmTuCb   *tuCb,                   /* common psf control block */
Pst      *pst,                    /* post */
U8       tblType,                 /* table type */
Buffer   **pMsgBuf                /* message buffer */
)
#else
PUBLIC S16 cmTuUnpkVerInfoCb(tuCb, pst, tblType, pMsgBuf)
CmTuCb   *tuCb;                   /* common psf control block */
Pst      *pst;                    /* post */
U8       tblType;                 /* table type */
Buffer   **pMsgBuf;               /* message buffer */
#endif
{
   CmTuRtUpdVerInfoCb updCb;   /* ver info update control block */
   U16                size;    /* Update structure size         */
   S16                ret;     /* return value                  */
   Buffer             *mBuf;   /* message Buffer                */
   CmStatus           status;  /* dummy parameter for SetVer    */
   S16                i;       /* counter for traversing ver info array  */

   TRC2(cmTuUnpkVerInfoCb)
 
   mBuf = *pMsgBuf;
   size = sizeof(CmTuRtUpdVerInfoCb);

   if ((ret = cmTuUnpkStructFn(tuCb,pst,tblType,size,(PTR)&updCb,mBuf)) != ROK)
   {
      RETVALUE(ret);
   }

   if (updCb.action == CMPFTHA_ACTN_DEL)
   {
      for (i = (*tuCb->numIntfInfo) - 1; i >= 0; i--)
      {
         if((*tuCb->intfInfo)[i].grpType == updCb.verInfo.grpType)
         {
            switch((*tuCb->intfInfo)[i].grpType)
            {
               case SHT_GRPTYPE_ALL:
                 if (((*tuCb->intfInfo)[i].dstProcId==updCb.verInfo.dstProcId) &&
                    ((*tuCb->intfInfo)[i].dstEnt.ent==updCb.verInfo.dstEnt.ent) &&
                    ((*tuCb->intfInfo)[i].dstEnt.inst==updCb.verInfo.dstEnt.inst))
                 {
                    /* delete the version information by copying the 
                     * last version info into current location */
                    cmMemcpy((U8 *) &(*tuCb->intfInfo)[i],
                             (U8 *) &(*tuCb->intfInfo)[(*tuCb->numIntfInfo)-1],
                             sizeof(ShtVerInfo));
                    (*tuCb->numIntfInfo)--;
                 }
                 break;
                             
               case SHT_GRPTYPE_ENT:
                 if (((*tuCb->intfInfo)[i].dstEnt.ent==updCb.verInfo.dstEnt.ent)&&
                    ((*tuCb->intfInfo)[i].dstEnt.inst==updCb.verInfo.dstEnt.inst))
                 {
                    /* delete the version information by copying the 
                     * last version info into current location */
                    cmMemcpy((U8 *) &(*tuCb->intfInfo)[i],
                             (U8 *) &(*tuCb->intfInfo)[(*tuCb->numIntfInfo)-1],
                             sizeof(ShtVerInfo));
                    (*tuCb->numIntfInfo)--;
                 }
                 break;
            } /* switch tuCb->numIntfInfo */
         } /* if tuCb->numIntfInfo */
      } /* for (i = 0) */
   }
   else
   {
      /* Set the interface version info in protocol layer data */
      tuCb->fn.tuUpdVer(&(updCb.verInfo), &status);

      if (status.reason != LCM_REASON_NOT_APPL)
         tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, 
                     LCM_EVENT_UPDMSG_ERR, LCM_CAUSE_VERSION_MISMATCH);
   }

   CMTUDBGP(CMTU_DBGMASK_UNPACK, (tuCb->init.prntBuf,
                               "cmTuUnpkVerInfoCb:IntfId(%d), IntfVer(%d)\n",
                               updCb.verInfo.intf.intfId, 
                               updCb.verInfo.intf.intfVer))

  RETVALUE(ROK);
} /* end of cmTuUnpkVerInfoCb */
#endif /* TDS_ROLL_UPGRADE_SUPPORT */


/*
 *
 *      Fun:   cmTuPkTuCb
 *
 *      Desc:  This function packs SAP control block parameters to update
 *             message.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None
 *
        File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuPkTuCb
(
CmTuCb *tuCb,                   /* common psf control block */
Pst    *pst,                    /* post */
U8      action,                 /* action taken */
U8      tblType,                /* update message table type */
PTR     ptr,                    /* pointer to control block */
Bool    rtUpd,                  /* if run time update */
Buffer *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmTuPkTuCb(tuCb, pst, action, tblType, ptr, rtUpd, mBuf)
CmTuCb *tuCb;                   /* common psf control block */
Pst    *pst;                    /* post */
U8      action;                 /* action taken */
U8      tblType;                /* update message table type */
PTR     ptr;                    /* pointer to control block */
Bool    rtUpd;                  /* if run time update */
Buffer *mBuf;                   /* message buffer */
#endif
{
   U8                  updCb[CMTU_MAX_UPD_STRUCT_SIZE];   /* update control block */
   U16                 size;    /* Update structure size */
   S16                 ret;     /* return value */

   TRC2(cmTuPkTuCb)

   CMTUDBGP(CMTU_DBGMASK_PACK, (tuCb->init.prntBuf,
            "cmTuPkTuCb:Action(%d), Type (%d)\n", action, tblType));

   size    = tuCb->updSize[tblType];
   ret = RFAILED;

   /* pack table type */
   if ((ret = SAddPstMsg((Data)tblType, mBuf)) != ROK)
   {
      CMTU_FREE_BUF(mBuf);
      RETVALUE(ret);
   }

   tuCb->fn.tuCpProtCbToUpd(action, ptr, (PTR)&updCb[0], tblType, mBuf);
   ret = cmTuPkStructFn(tuCb, pst, tblType, size, (PTR)&updCb[0], mBuf);
   if (ret != ROK)
   {
      CMTU_FREE_BUF(mBuf);
   }
   RETVALUE(ret);
} /* end of cmTuPkTuCb */


/*
 *
 *      Fun:   cmTuUnpkTuCb
 *
 *      Desc:  This function unpacks Lower sap control block from the update 
 *             message. This function also updates TCAP data structures
 *             with the received information
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuUnpkTuCb
(
CmTuCb   *tuCb,                   /* common psf control block */
Pst      *pst,                    /* post */
U8       tblType,                 /* table type */
Buffer   **pMsgBuf                /* message buffer */
)
#else
PUBLIC S16 cmTuUnpkTuCb(tuCb, pst, tblType, pMsgBuf)
CmTuCb   *tuCb;                   /* common psf control block */
Pst      *pst;                    /* post */
U8       tblType;                 /* table type */
Buffer   **pMsgBuf;               /* message buffer */
#endif
{
   U8               updCb[CMTU_MAX_UPD_STRUCT_SIZE];   /* update control block */
   S16              ret;     /* return value */
   U16              size;    /* Update structure size */
   
   TRC2(cmTuUnpkTuCb)

   size = tuCb->updSize[tblType];

   if ((ret = cmTuUnpkStructFn(tuCb,pst,tblType,size,(PTR)&updCb[0],*pMsgBuf)) != ROK)
      RETVALUE(ret);

   CMTUDBGP(CMTU_DBGMASK_UNPACK, (tuCb->init.prntBuf,
                        "cmTuUnpkTuCb: table type(%d), size(%d) \n",
                         tblType, size))

   /* buffer will be released outside of the function in failure case */
   RETVALUE(tuCb->fn.tuCpUpdCbToProt((PTR) &updCb[0], tblType, pMsgBuf));

} /* end of cmTuUnpkTuCb */


/********************************************************************20**
  Conversion functions
*********************************************************************21*/

/*
 *
 *     Fun  : Conversion Encode Function
 *
 *     Desc : Invoked by the System Agent to encode a control request to
 *            protocol layer. This function converts a System Agent control
 *            request into an protocol layer control request and dispatches it.
 *
 *     Ret  : ROK   - ok
 *
 *     Notes: This function interfaces with the new PSF.
 *
 *     File : cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC U32 cmTuCfnEncode
(
Pst           *pst,                     /* Pst                      */
Action        action,                   /* action                   */
Action        subAction,                /* subAction                */
CmFthaEntPar  *entPar,                  /* rset parameters          */
Header        *hdr,                     /* Header to be sent to PSF */
CmTuMngmt     *cntrl
)
#else
PUBLIC U32 cmTuCfnEncode (pst, action, subAction, entPar, hdr, cntrl)
Pst           *pst;                     /* Pst                      */
Action        action;                   /* action                   */
Action        subAction;                /* subAction                */
CmFthaEntPar  *entPar;                  /* rset parameters          */
Header        *hdr;                     /* Header to be sent to PSF */
CmTuMngmt     *cntrl;
#endif
{
   TRC3(cmTuCfnEncode);

   UNUSED(pst);

   /*
    * Convert System Agent control request 
    */
   cmMemcpy((U8 *)&cntrl->hdr, (U8 *)hdr, sizeof(Header));

   cntrl->hdr.elmId.elmnt            = CMTURSET;
   cntrl->t.shCntrl.subAction        = 0; /* unused */

   switch(action)
   {
      case CMFTHA_AGOACTIVE:
      {
         cntrl->t.shCntrl.action = CMTU_AGO_ACT;
         cmMemcpy ((U8 *)&cntrl->t.shCntrl.t.rsetPar.t.ga,
                   (U8 *)&entPar->rsetPar[CMFTHA_RES_RSETID].cntrlPar.gaPar,
                   sizeof (CmFthaGoActPar));
         break;
      }

      case CMFTHA_AGOSTANDBY:
      {
         cntrl->t.shCntrl.action = CMTU_AGO_SBY;
         cmMemcpy ((U8 *)&cntrl->t.shCntrl.t.rsetPar.t.gs,
                   (U8 *)&entPar->rsetPar[CMFTHA_RES_RSETID].cntrlPar.gsPar,
                   sizeof (CmFthaGoSbyPar));
         break;
      }

      case CMFTHA_ADIS_PEERSAP:
      {
         cntrl->t.shCntrl.action = CMTU_ADIS_PEER_SAP;
         break;
      }

      case CMFTHA_AWARMSTART:
      {
         cntrl->t.shCntrl.action = CMTU_AWARMSTART;
         break;
      }

      case CMFTHA_ASYNCHRONIZE:
      {
         cntrl->t.shCntrl.action = CMTU_ASYNCHRONIZE;
         break;
      }

      case CMFTHA_ASHUTDOWN:
      {
         cntrl->t.shCntrl.action = CMTU_ASHUTDOWN;
         break;
      }

      case CMFTHA_AABORT:
      {
         cntrl->t.shCntrl.action      = CMTU_AABORT;
         cntrl->t.shCntrl.t.abort.transId =
                  entPar->rsetPar[0].cntrlPar.abPar.transId;
         break;
      }

      default:
      {
         RETVALUE(RFAILED);
      }
   }

   if(action != CMFTHA_AABORT)
   {
      cntrl->t.shCntrl.t.rsetPar.rsetId = CMFTHA_RES_RSETID;
   }

   RETVALUE(ROK);
} /* end of cmTuCfnEncode */


/*
 *
 *     Fun  : Conversion Decode Function
 *
 *     Desc : Invoked by the System Agent to decode a confirm (control
 *            and status) that was received from the protocol layer.
 *
 *     Ret  : ROK   - ok
 *
 *     Notes: EntPar structure filling to be decided (??)
 *
 *     File : cm_tupsf.c
 * */
#ifdef ANSI
PUBLIC U32 cmTuCfnDecode
(
Pst           *pst,           /* Pst struct recv in confirm              */
Buffer        *mBuf,          /* incoming message                        */
TranId        transId,        /* transId (sent in the request)           */
CmStatus      *status,        /* Status in the message (to be filled up) */
CmFthaEntPar  *entPar,        /* Ent Params (to be returned)             */
CmTuMngmt     *cfm
)
#else
PUBLIC U32 cmTuCfnDecode (pst, mBuf, transId, status, entPar, cfm)
Pst           *pst;           /* Pst struct recv in confirm              */
Buffer        *mBuf;          /* incoming message                        */
TranId        transId;        /* transId (sent in the request)           */
CmStatus      *status;        /* Status in the message (to be filled up) */
CmFthaEntPar  *entPar;        /* Ent Params (to be returned)             */
CmTuMngmt     *cfm;
#endif
{
   TRC3(cmTuCfnDecode);

   UNUSED(entPar);

   /* First, unpack the message buffer - for control requests only */
   switch (pst->event)
   {
      case EVTTUMILTUCNTRLCFM:

         CMCHKUNPKLOG(cmUnpkHeader, &cfm->hdr, mBuf, ECMTU083, pst);
         CMCHKUNPKLOG(cmUnpkCmStatus, &cfm->cfm, mBuf, ECMTU084, pst);

         CMTU_FREE_BUF(mBuf);

         break;

      default:

         status->status = LCM_PRIM_NOK;
         status->reason = LCM_REASON_INVALID_MSGTYPE;
         /* cm_tupsf_c_002.main_3: added: buffer should be deallocated */
         CMTU_FREE_BUF(mBuf);

         RETVALUE (ROK);
         break;
   }

   /* 
    * Check the information the arrived in the reply. If the specified
    * transaction id does not match, this is a stray message, flag failure. 
    */
   if(cfm->hdr.transId != transId)
   {
      RETVALUE(RFAILED);
   }
   status->status = cfm->cfm.status;
   status->reason = cfm->cfm.reason;

   RETVALUE(ROK);
} /* end of cmTuCfnDecode */


/********************************************************************20**
  Support functions
*********************************************************************21*/

/*
 *
 *      Fun:   cmTuGetBuf
 *
 *      Desc:  This function gets a buffer for forming a update message.
 *             It also adds the required header into the buffer (if the 
 *             buffer is a new one).
 *
 *      Ret:   Buffer (if successfull)
 *             NULLP (in case of problems )
 *
 *      Notes: The returned buffer will already be part of the
 *             relevant queue.
 *
 *      File:  cm_tupsf.c 
 * */
#ifdef ANSI
PUBLIC S16 cmTuGetBuf
(
CmTuCb       *tuCb,   /* common psf control block */
CmTuRsetCb   *rsetCb, /* resource set control block */
U8           type,    /* update type                */
U16          sNum,    /* sequence number            */
U8           more,    /* more indication            */
Buffer       **mBuf   /* message buffer             */
)
#else
PUBLIC S16 cmTuGetBuf (tuCb, rsetCb, type, sNum, more, mBuf)
CmTuCb       *tuCb;   /* common psf control block */
CmTuRsetCb   *rsetCb; /* resource set control block */
U8           type;    /* update type                */
U16          sNum;    /* sequence number            */
U8           more;    /* more indication            */
Buffer       **mBuf;  /* message buffer             */
#endif
{  
   S16             ret;    /* return value   */
   CmPFthaUpdHdr   hdr;    /* message header */

   TRC2 (cmTuGetBuf)

   if ((ret = SGetMsg(tuCb->peerPst.region, tuCb->peerPst.pool, mBuf)) != ROK)
   {
#if (ERRCLASS & ERRCLS_ADD_RES)
      CMTULOGERROR_ADD_RES (ECMTU118, (ErrVal) 0, 
                          "cmTuGetBuf : SGetMsg failed");
#endif
      RETVALUE (ret);      
   }
    
   /* initialize the header */  
   cmMemset((U8 *)&hdr, (U8) 0, sizeof(CmPFthaUpdHdr));
   
   /* Form a header */
   hdr.mVer     = tuCb->sysId.mVer;
   hdr.mRev     = tuCb->sysId.mRev;
   hdr.bVer     = tuCb->sysId.bVer;
   hdr.rsetId   = rsetCb->rsetId;
   hdr.procType = type;
   hdr.seqNum   = sNum;
   hdr.flag     = more;

   if ((ret = cmPFthaUHPk(&hdr, *mBuf)) != ROK)
   {
      CMTULOGERROR_INT_PAR(ECMTU118, (ErrVal) 0,
                     "cmTuGetBuf: cmPFthaUHPk is failed");
      CMTU_FREE_BUF(*mBuf);
      RETVALUE (ret);
   }
   
   RETVALUE (ROK);
} /* cmTuGetBuf */


/*
*
*       Fun:   cmTuBldReplyPst
*
*       Desc:  This function prepares the post structure required for sending
*              management confirm
*
*       Ret:   RETVOID
*
*       Notes: None.
*
*       File:  cm_tupsf.c
*
*/
#ifdef ANSI
PUBLIC Void cmTuBldReplyPst
(
CmTuCb *tuCb,                    /* common psf control block */
Pst    *rPst,                    /* reply post */
Header *hdr,                     /* mgmt header */
Pst    *iPst                     /* incoming post */
)
#else
PUBLIC Void cmTuBldReplyPst(tuCb, rPst, hdr, iPst)
CmTuCb *tuCb;                     /* common psf control block */
Pst    *rPst;                    /* reply post */
Header *hdr;                     /* mgmt header */
Pst    *iPst;                    /* incoming post */
#endif
{
   TRC2(cmTuBldReplyPst)
 
   rPst->srcEnt    = tuCb->init.ent;
   rPst->srcInst   = tuCb->init.inst;
#ifdef SS_MULTIPLE_PROCS
   rPst->srcProcId = tuCb->init.procId;
#else
   rPst->srcProcId = SFndProcId();
#endif
   rPst->dstEnt    = iPst->srcEnt;
   rPst->dstInst   = iPst->srcInst;
   rPst->dstProcId = iPst->srcProcId;
   rPst->selector  = hdr->response.selector;
   rPst->prior     = hdr->response.prior;
   rPst->route     = hdr->response.route;
   rPst->region    = hdr->response.mem.region;
   rPst->pool      = hdr->response.mem.pool;
   rPst->intfVer   = iPst->intfVer;
 
   RETVOID;
   
} /* cmTuBldReplyPst */


/*
 *
 *       Fun:   cmTuInsertDLL
 *
 *       Desc:  Insert dlg MAP in the DLL (doubly link list)
 *
 *       Ret:   Void
 *
 *       Notes: 
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuInsertDLL 
(
CmTuCb          *tuCb,        /* PSF control block */
CmPFthaRsetMap  *dlgMap,      /* DLG MAP */
CmTuRsetCb      *rsetCb       /* Resource set control block */
)
#else
PUBLIC Void cmTuInsertDLL (tuCb, dlgMap, rsetCb)
CmTuCb          *tuCb;        /* PSF control block */
CmPFthaRsetMap  *dlgMap;      /* DLG MAP */
CmTuRsetCb      *rsetCb;      /* Resource set control block */
#endif
{
   CmPFthaRsetMap    *tmpDlgMap;    /* temporary pointer */

   TRC2 (cmTuInsertDLL)

   if (rsetCb->cbHead)
   {
      tmpDlgMap = rsetCb->cbTail;
      
      tmpDlgMap->next = dlgMap;
      dlgMap->prev    = tmpDlgMap;
      dlgMap->next    = NULLP;

      rsetCb->cbTail = dlgMap;
   }
   else
   {
      rsetCb->cbHead = dlgMap;
      rsetCb->cbTail = dlgMap;
      dlgMap->prev   = NULLP;
      dlgMap->next   = NULLP;
   }
   
   ++(rsetCb->nmbDlgMap);

   CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, 
             "cmTuInsertDLL (nmbDlgMap (%d))\n", rsetCb->nmbDlgMap));

   RETVOID;
   
} /* cmTuInsertDLL */


/*
 *
 *       Fun:   cmTuRemoveDLL
 *
 *       Desc:  Remove dlg MAP in the DLL (doubly link list)
 *
 *       Ret:   Void
 *
 *       Notes: 
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuRemoveDLL 
(
CmTuCb          *tuCb,        /* PSF control block */
CmPFthaRsetMap  *dlgMap,      /* DLG MAP */
CmTuRsetCb      *rsetCb       /* Resource set control block */
)
#else
PUBLIC Void cmTuRemoveDLL (tuCb, dlgMap, rsetCb)
CmTuCb          *tuCb;        /* PSF control block */
CmPFthaRsetMap  *dlgMap;      /* DLG MAP */
CmTuRsetCb      *rsetCb;      /* Resource set control block */
#endif
{
   TRC2 (cmTuRemoveDLL)

   if (dlgMap == rsetCb->cbHead)
   {
      rsetCb->cbHead = rsetCb->cbHead->next;
      if (rsetCb->cbHead != (CmPFthaRsetMap *)NULLP)
      {
         rsetCb->cbHead->prev = (CmPFthaRsetMap *)NULLP;
      }
      if(dlgMap == rsetCb->cbTail)
      {
         /* only one element */
         rsetCb->cbTail = NULLP;
      }
   }
   else if (dlgMap == rsetCb->cbTail)
   {
      rsetCb->cbTail = rsetCb->cbTail->prev;
      if (rsetCb->cbTail != (CmPFthaRsetMap *)NULLP)
      {
         rsetCb->cbTail->next = (CmPFthaRsetMap *)NULLP;
      }
   }
   else
   {
      if (dlgMap->prev != (CmPFthaRsetMap *)NULLP)
      {
         dlgMap->prev->next = dlgMap->next;
      }
         
      if (dlgMap->next != (CmPFthaRsetMap *)NULLP)
      {
         dlgMap->next->prev = dlgMap->prev;
      }
   }
   
   --(rsetCb->nmbDlgMap);

   CMTUDBGP (DBGMASK_PLI, (tuCb->init.prntBuf, 
             "cmTuRemoveDLL (nmbDlgMap (%d))\n", rsetCb->nmbDlgMap));

   RETVOID;
   
} /* cmTuRemoveDLL */


/*
 *
 *       Fun:  cmTuGetNextDlg
 *
 *       Desc: Get the next dialogue Cb in a resource set
 *
 *       Ret:  ROK
 *
 *       Notes: 
 *              
 *
 *       File: cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuGetNextDlg 
(
CmTuCb       *tuCb,           /* common psf control block */
PTR          *retDlgCp        /* return dialogue        */
)
#else
PUBLIC S16 cmTuGetNextDlg (tuCb, retDlgCp)
CmTuCb       *tuCb;            /* common psf control block */
PTR          *retDlgCp;        /* return dialogue        */
#endif
{
   CmTuRsetCb       *rsetCb;    /* pointer to resource set Cb */
   PTR              prevDlgCp;  /* previous dialogure control block */
   CmPFthaRsetMap   *tuDlgMap;       /* Rset Map structure */
   
   TRC2(cmTuGetNextDlg)
   
   rsetCb = tuCb->rsetCbLst[CMFTHA_RES_RSETID];

#if (ERRCLASS & ERRCLS_DEBUG) 
   /* error check on parameters */
   if (rsetCb == (CmTuRsetCb *)NULLP)
   {
      RETVALUE(RFAILED);
   }
#endif /*  (ERRCLASS & ERRCLS_DEBUG) */

   prevDlgCp = rsetCb->dlgCp;

   if (prevDlgCp != NULLP)
   {
      if (((CmPFthaRsetMap *)(prevDlgCp + tuCb->offset))->next == NULLP)
      {
         RETVALUE(RFAILED); /* no more dialogues */
      }
      else
      {
         tuDlgMap = ((CmPFthaRsetMap *)(prevDlgCp + tuCb->offset))->next;
      }
   }
   else
   {
      if (rsetCb->cbHead == NULLP)
      {
         RETVALUE(RFAILED); /* no dialogues */
      }
      else
      {
         tuDlgMap = rsetCb->cbHead;
      }
   }
   
   CMTU_GET_DLGCB(tuDlgMap, *retDlgCp);

   RETVALUE(ROK);   

} /* cmTuGetNextDlg */


/*
 *
 *      Fun:   cmTuDecUpdMsg
 *
 *      Desc:  This function decodes recieved update message. This function
 *             unpacks the table type and then calls the corresponding 
 *             table unpack function.
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: In all cases this function consumes the message buffer. Caller
 *             need not worry about freeing the message buffer
 *
 *      File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuDecUpdMsg
(
CmTuCb   *tuCb,                   /* PSF control block */
Pst      *pst,                    /* post structure */
Buffer   *mBuf                    /* message buffer */
)
#else
PUBLIC S16 cmTuDecUpdMsg(tuCb, pst, mBuf)
CmTuCb   *tuCb;                   /* PSF control block */
Pst      *pst;                    /* post structure */
Buffer   *mBuf;                   /* message buffer */
#endif
{
   U8    tblType;       /* table type */
   S16   rVal;          /* return value */

   TRC2(cmTuDecUpdMsg)

   if (mBuf == (Buffer *)NULLP)
   {
      CMTULOGERROR_DEBUG(ECMTU118, ERRZERO, "cmTuDecUpdMsg: Null mBuf");

      RETVALUE(RFAILED);
   }

   CMCHKUNPKLOG(SUnpkU8, &tblType, mBuf, ECMTU118, pst);

   while (tblType != CMPFTHA_INV_TT)
   {  
      switch(tblType)
      {
         case CMTU_UISAP_TAB:
         case CMTU_LISAP_TAB:
         case CMTU_ADDDLG_TAB:
         case CMTU_MODDLG_TAB:
         case CMTU_DELDLG_TAB:
         case CMTU_CSWDLG_TAB:
         case CMTU_ADDINV_TAB:
         case CMTU_MODINV_TAB:
         case CMTU_DELINV_TAB:
         case CMTU_CSWINV_TAB:
         case CMTU_PROTCB_TAB:
     case CMTU_WSDLG_TAB:
     case CMTU_WSINV_TAB:
            rVal = cmTuUnpkTuCb(tuCb, pst, tblType, &mBuf);
            break;

         case CMTU_RTSEQ_TAB:
            rVal = cmTuUnpkRtSeq(tuCb, pst, tblType, &mBuf);            
            break;

         case CMTU_RSET_TAB:
            rVal = cmTuUnpkRsetCb(tuCb, pst, tblType, &mBuf);            
            break;

         case CMTU_PSFCB_TAB:
            rVal = cmTuUnpkPsfCb(tuCb, pst, tblType, &mBuf);            
            break;

#ifdef TDS_ROLL_UPGRADE_SUPPORT
         case CMTU_VERINFO_TAB:
            rVal = cmTuUnpkVerInfoCb(tuCb, pst, tblType, &mBuf);            
            break;
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

         default:  /* we got invalid table type */
            CMTU_FREE_BUF(mBuf);
            CMTULOGERROR_INT_PAR(ECMTU118, tblType,
                                "cmTuDecUpdMsg(). Invalid table type");
            RETVALUE(RFAILED);
      } /* end switch tblType */

      if (rVal != ROK)
      {
          CMTU_FREE_BUF(mBuf);
          CMTULOGERROR_INT_PAR(ECMTU118, tblType,
                               "cmTuDecUpdMsg(). unpacking failure");
          RETVALUE(RFAILED);
      }
      /* decode the next type */
      CMCHKUNPKLOG(SUnpkU8, &tblType, mBuf, ECMTU118, pst);

   } /* end while */

   CMTU_FREE_BUF(mBuf);
   RETVALUE(ROK);
} /* end of cmTuDecUpdMsg */

  
/*
 *
 *       Fun:   cmTuProcPeerCfmMsg
 *
 *       Desc:  Process a message from the peer.
 *
 *       Ret:   CMTU_OK, CMTU_ERR
 *
 *       Notes: None.
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmTuProcPeerCfmMsg 
(
CmTuCb   *tuCb,      /* PSF control block */
Buffer   *mBuf       /* Message buffer */
)
#else
PUBLIC S16 cmTuProcPeerCfmMsg (tuCb, mBuf)
CmTuCb   *tuCb;      /* PSF control block */
Buffer   *mBuf;      /* Message buffer */
#endif
{
   CmTuRsetCb     *rsetCb;  /* Resource set control block */
   CmPFthaCfmHdr  hdr;      /* PFtha confirm header       */
   Pst            repPst;   /* Reply Post structure       */

   TRC2 (cmTuProcPeerCfmMsg);

   /* Do all validation initally so nothing is required later */
   if (cmTuRVACfmMsg (tuCb, mBuf, &hdr) != ROK)
   {
      /* No alarm needed. We will send NACK if real confirm is not received. */
      RETVALUE (CMTU_ERR);
   }

   CMTUDBGP(DBGMASK_PI, (tuCb->init.prntBuf, 
           "cmTuProcPeerCfmMsg() hdr.rsetId (%d) hdr.cfm (%d)\n",
           hdr.rsetId, hdr.cfm));
   /* 
   ** Once we come out of the above function..everything is ok and we
   ** shouldn't do any more error checks.
   */   

   rsetCb = tuCb->rsetCbLst[hdr.rsetId];

   if (rsetCb->updState == CMPFTHA_US_WARMSTART_WAIT)
   {
      rsetCb->sts.rxWS++;
   }
   else
   {
      rsetCb->sts.rxCS++;
   }
   
   if (hdr.cfm == CMPFTHA_CFM_OK)
   {
      /* Procedure was successfull for the resource set */
      if (rsetCb->updState == CMPFTHA_US_WARMSTART_WAIT)
      {
         rsetCb->updState = CMPFTHA_US_IDLE;
      }
      else
      {
         rsetCb->updState = CMPFTHA_US_PEERSYNC_FIN;
      }
      /* reinit the seq num's */
      rsetCb->wsSeqNmb = 0;
      rsetCb->csSeqNmb = 0;
      cmTuStopRsetCbTmr (tuCb, rsetCb, CMTU_TMR_ACK);

      /* We are done with the control request */
      tuCb->pendOp.flag = FALSE;
      cmTuBldReplyPst(tuCb, &repPst, &tuCb->pendOp.hdr, &tuCb->pendOp.pst);
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &tuCb->pendOp.hdr, 
                        LCM_PRIM_OK, LCM_REASON_NOT_APPL);
   }
   else
   {
      /* 
      ** The procedure was not successful. We should abort the current
      ** cntrl req operation and return NOK 
      */   
      cmTuAbortCurOp(tuCb, hdr.rsetId, &tuCb->pendOp); 
      tuCb->rsetCbLst[hdr.rsetId]->peerState = CMPFTHA_PEER_DEAD;
      cmTuBldReplyPst(tuCb, &repPst, &tuCb->pendOp.hdr, &tuCb->pendOp.pst);
      tuCb->fn.tuSendLmCfm(&repPst, TCNTRL, &tuCb->pendOp.hdr, 
                        LCM_PRIM_NOK, LCM_REASON_NEG_CFM);  
      
   }
   RETVALUE (CMTU_OK);
} /* cmTuProcPeerCfmMsg */


/*
 *
 *      Fun:   cmTuRVACfmMsg (Read Validate and Act)
 *
 *      Desc:  This function reads the header from the confirm message 
 *             and then validates it.
 *
 *      Ret:   FALSE : If the message cannot be porcessed.
 *             TRUE  : process the message.
 * 
 *      Notes:
 *
 *      File:  cm_tupsf.c 
 * 
 */
#ifdef ANSI
PUBLIC S16 cmTuRVACfmMsg
(
CmTuCb        *tuCb,         /* PSF control block */
Buffer        *mBuf,         /* Confirm message */
CmPFthaCfmHdr *hdr           /* Confirm Header - one per msg */
)
#else
PUBLIC S16 cmTuRVACfmMsg (tuCb, mBuf, hdr)
CmTuCb        *tuCb;         /* PSF control block */
Buffer        *mBuf;         /* Confirm message */
CmPFthaCfmHdr *hdr;          /* Confirm Header - one per msg */
#endif
{
   CmTuRsetCb *rsetCb; /* Resource set control block */

   TRC2 (cmTuRVACfmMsg);

   /* There has to be a pendOp before we recieve this message */
   if (tuCb->pendOp.flag != TRUE)
   {
      /*
       * This is a normal error. Can happen when the ACK arrives
       * after the operation has been aborted 
       */
      CMTULOGERROR_INT_PAR(ECMTU107,(ErrVal) 0,"cmTuRVACfmMsg(): Late msg");
      RETVALUE (RFAILED);
   }
        
   if ((cmPFthaCHUnpk (hdr, mBuf)) != ROK)
   {
      CMTULOGERROR_INT_PAR(ECMTU108,(ErrVal) 0,"cmTuRVACfmMsg(): Invalid msg");
      RETVALUE (RFAILED);
   }

   CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
           "cmTuRVACfmMsg() : rsetId = %d\n",hdr->rsetId));

#ifndef TDS_ROLL_UPGRADE_SUPPORT
   /* Match the version number */
   if ((hdr->mVer != tuCb->sysId.mVer) ||
       (hdr->mRev != tuCb->sysId.mRev) ||
       (hdr->bVer != tuCb->sysId.bVer))
   {
      tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, 
                        LCM_EVENT_UPDMSG_ERR, LCM_CAUSE_UNKNOWN);
      CMTULOGERROR_INT_PAR(ECMTU109,(ErrVal) 0,"cmTuRVACfmMsg(): Invalid ver");
      RETVALUE (RFAILED);
   }
#endif /* TDS_ROLL_UPGRADE_SUPPORT */

   if (!CMTU_IS_VALID_RSET (hdr->rsetId))
   {
      tuCb->fn.tuSendAlarm(LCM_CATEGORY_PSF_FTHA, 
                        LCM_EVENT_UPDMSG_ERR, LCM_CAUSE_UNKNOWN);
      CMTULOGERROR_INT_PAR(ECMTU110,(ErrVal)0,"cmTuRVACfmMsg: Invalid rsetId");
      RETVALUE (RFAILED);
   }

   rsetCb = tuCb->rsetCbLst[hdr->rsetId];

   if ((rsetCb->updState != CMPFTHA_US_WARMSTART_WAIT) &&
       (rsetCb->updState != CMPFTHA_US_PEERSYNC_WAIT))
   {
      /*
       * This is a normal error. Can happen when the ACK arrives
       * after the operation has been aborted 
       */
      CMTULOGERROR_INT_PAR(ECMTU111,(ErrVal) 0,
                 "cmTuRVACfmMsg: Invalid update state");
      RETVALUE (RFAILED);
   }
   RETVALUE (ROK);
} /* cmTuRVACfmMsg */

/*
 *
 *      Fun:   cmTuGenCfg
 *
 *      Desc:  General configuration function for PSF module. 
 *
 *      Ret:   ROK     - General configuration is successful
 *             RFAILED - General configuration failed
 *
 *      Notes: None
 *
 *      File:  zj_bdy2.c
 * 
 */
#ifdef ANSI
PUBLIC S16 cmTuGenCfg
(
CmTuCb         *tuCb,      /* common PSF control block */
CmTuGenCfg     *cfg,       /* general configuration structure */
U16            *reason     /* reason                          */
)
#else
PUBLIC S16 cmTuGenCfg (tuCb, cfg, reason)
CmTuCb         *tuCb;      /* common PSF control block */
CmTuGenCfg     *cfg;       /* general configuration structure */
U16            *reason;    /* reason                          */
#endif
{
   U32              maxCbSize;      /* maximum control block size */
   Size             memSize;        /* memory size                */
   U16              i;              /* counter                    */
   U16              nmbRsets;       /* number of resource sets    */
   S16              ret;            /* return value               */
   CmTuRsetCb       *rsetCb;        /* pointer rset Cb            */
   
   TRC2 (cmTuGenCfg)
   
   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, 
           "cmTuGenCfg() : cfgDone = %d\n",tuCb->init.cfgDone));

   /* initialization */
   ret       = LCM_REASON_NOT_APPL;
   maxCbSize = 0;
   
   for (i = 0; i < CMTU_MAXTABTYPE; i++)
   {
      if (tuCb->updSize[i] > (S16)maxCbSize)
      {
         maxCbSize = tuCb->updSize[i];
      }
   }

   /* max update message size should be atleast maxCbSize + update message
    * header size + sizeof(tblType)
    */
   if (cfg->maxUpdMsgSize < (maxCbSize + sizeof(CmPFthaUpdHdr) + 1))
   {
      CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_INVALID_PAR_VAL,
                "cmTuGenCfg() : invalid maxUpdMsgSize");
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   /* Update-Complete-Ack can not be disabled */
   if ((cfg->tUpdCompAck.enb == FALSE) || (cfg->tUpdCompAck.val == 0))
   {
      CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_INVALID_PAR_VAL,
                "cmTuGenCfg() : invalid tUpdCompAck");
      *reason = LCM_REASON_INVALID_PAR_VAL;
      RETVALUE(RFAILED);
   }

   if (tuCb->init.cfgDone == FALSE)
   {
      /* recovery timers can be disbled */
      if ((cfg->tRecovery.enb == TRUE) && (cfg->tRecovery.val == 0))
      {
         CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_INVALID_PAR_VAL,
                              "cmTuGenCfg() : invalid tRecovery");
         *reason = LCM_REASON_INVALID_PAR_VAL;
         RETVALUE(RFAILED);
      }

      /* First time general configuration */
      
      /* Replace the physical procId with reserved rset Id */

#ifndef SS_MULTIPLE_PROCS
      tuCb->init.procId = CMFTHA_RES_RSETID;
#endif

      /* Copy the configuration */
      cmMemcpy ((U8 *)&tuCb->genCfg, (U8 *)cfg, sizeof (CmTuGenCfg));
      /* initialize other fields */
      tuCb->genCfg.smPst.srcProcId = tuCb->init.procId;
      tuCb->genCfg.smPst.srcEnt    = tuCb->init.ent;
      tuCb->genCfg.smPst.srcInst   = tuCb->init.inst;

       
      /******** 1. Estimate the memory *******/ 
           
      {
         nmbRsets = 1;
         /* memory for resource set control blocks */
         memSize = nmbRsets * (sizeof(CmTuRsetCb *) + sizeof(CmTuRsetCb));
      }
      
      /* store this memory for later use */
      tuCb->maxMemSize = memSize;
      
      /********* 2. Allocate the memory ********/
      
      /* allocate the pool */
      if ((SGetSMem(tuCb->init.region, memSize, &tuCb->init.pool)) != ROK)
      {
         CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_MEM_NOAVAIL,
                              "cmTuGenCfg() : memory failure");
         *reason = LCM_REASON_MEM_NOAVAIL;   
         RETVALUE (RFAILED);
      }
      
      /* allocate rsetCb pointers */
      if ((SGetSBuf(tuCb->init.region,tuCb->init.pool,(Data**)&tuCb->rsetCbLst,
                    (sizeof (CmTuRsetCb *) * nmbRsets))) != ROK)
      {
         CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_MEM_NOAVAIL,
                              "cmTuGenCfg() : memory failure");
         SPutSMem (tuCb->init.region, tuCb->init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE (RFAILED);
      }

      /* initalize the pointers */
      for (i = 0; i < nmbRsets; i++)
      {
         tuCb->rsetCbLst[i] = (CmTuRsetCb *)NULLP;
      }
      

      /******** 3. Initialize the data structures ********/
      
      /* register the timers */
#ifdef SS_MULTIPLE_PROCS
      if ((tuCb->fn.tuRegTmr(tuCb->init.procId, tuCb->init.ent, 
                        tuCb->init.inst, (S16)cfg->timeRes)) != ROK)
#else
      if ((tuCb->fn.tuRegTmr(tuCb->init.ent, tuCb->init.inst,
                             (S16)cfg->timeRes)) != ROK)
#endif
      {
         CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal)LCM_REASON_REGTMR_FAIL,
                              "cmTuGenCfg() : timer registration failure");
         SPutSBuf(tuCb->init.region,tuCb->init.pool,(Data *)tuCb->rsetCbLst,
          (sizeof (CmTuRsetCb *) * nmbRsets));
         SPutSMem (tuCb->init.region, tuCb->init.pool);
         *reason = LCM_REASON_REGTMR_FAIL;
         RETVALUE (RFAILED);
      }

      /* The value of the reserved resource set id should always be zero. */
      if ((SGetSBuf(tuCb->init.region, tuCb->init.pool,
                    (Data**)&tuCb->rsetCbLst[CMFTHA_RES_RSETID], 
                    sizeof (CmTuRsetCb))) !=ROK)
      {
         CMTULOGERROR_INT_PAR(ECMTU097, (ErrVal) LCM_REASON_MEM_NOAVAIL,
                              "cmTuGenCfg() : memory failure");
#ifdef SS_MULTIPLE_PROCS
         tuCb->fn.tuDeregTmr(tuCb->init.procId, tuCb->init.ent, tuCb->init.inst,(S16)cfg->timeRes);
#else
         tuCb->fn.tuDeregTmr(tuCb->init.ent, tuCb->init.inst,(S16)cfg->timeRes);
#endif
         SPutSBuf(tuCb->init.region,tuCb->init.pool,(Data *)tuCb->rsetCbLst,
          (sizeof (CmTuRsetCb *) * nmbRsets));
         SPutSMem(tuCb->init.region, tuCb->init.pool);
         *reason = LCM_REASON_MEM_NOAVAIL;
         RETVALUE (RFAILED);
      }
         
      rsetCb        = tuCb->rsetCbLst[CMFTHA_RES_RSETID];
         
      cmTuInitRsetCb(tuCb, CMFTHA_RES_RSETID, (PTR)rsetCb);
         
      /* 
       * Fill the peer/self Pst structure - remaining fields are initialized
       * in actvInit and when the upd Msg is generated.
       */
      tuCb->peerPst.region = cfg->mem.region;
      tuCb->peerPst.pool   = cfg->mem.pool;
   
      tuCb->selfPst.region = cfg->mem.region;
      tuCb->selfPst.pool   = cfg->mem.pool;
   
      /* mark genCfg as done */
      tuCb->init.cfgDone = TRUE;
      
   }
   else
   {

      /* Re- configurable params of PSF-MAP general configuration */
      /* copy layer management post structure */
      cmMemcpy ((U8 *)&tuCb->genCfg.smPst, (U8 *)&cfg->smPst, sizeof(Pst));
      /* initialize other fields */
      tuCb->genCfg.smPst.srcProcId = tuCb->init.procId;
      tuCb->genCfg.smPst.srcEnt    = tuCb->init.ent;
      tuCb->genCfg.smPst.srcInst   = tuCb->init.inst;
   
      /* copy update completion timer */
      cmMemcpy((U8 *)&tuCb->genCfg.tUpdCompAck, (U8 *)&cfg->tUpdCompAck, 
            sizeof (TmrCfg));
         
      tuCb->genCfg.maxUpdMsgSize = cfg->maxUpdMsgSize;
      tuCb->genCfg.maxUpdMsgs    = cfg->maxUpdMsgs;

   }/* re-configuration */             
   
   *reason = LCM_REASON_NOT_APPL;
   RETVALUE (ROK);
   
} /* cmTuGenCfg */


/*
 *
 *      Fun:   cmTuShutDown
 *
 *      Desc:  This function shuts down MAP PSF
 *
 *      Ret:   ROK     - successful,
 *             RFAILED - failed.
 *
 *      Notes: None.
 *
 *      File:  cm_tupsf.c
 *
 */

#ifdef ANSI
PUBLIC Void cmTuShutDown
(
CmTuCb      *tuCb         /* PSF control block */
)
#else
PUBLIC Void cmTuShutDown (tuCb)
CmTuCb      *tuCb;        /* PSF control block */
#endif
{
   CmTuRsetCb         *rsetCb;   /* pointer to resource set Cb  */
   
   TRC2 (cmTuShutDown)

   CMTUDBGP(DBGMASK_MI, (tuCb->init.prntBuf, "cmTuShutDown() \n"));
      
   if (tuCb->init.cfgDone != TRUE)
   {
      RETVOID;
   }
   
   cmTuGoOOS(tuCb, CMFTHA_RES_RSETID);
   rsetCb = tuCb->rsetCbLst[CMFTHA_RES_RSETID];
   SPutSBuf(tuCb->init.region, tuCb->init.pool,
            (Data *)rsetCb, sizeof(CmTuRsetCb));

   SPutSBuf(tuCb->init.region, tuCb->init.pool,
            (Data *)tuCb->rsetCbLst, sizeof(CmTuRsetCb *));

   /* deregister timers */
#ifdef SS_MULTIPLE_PROCS
   tuCb->fn.tuDeregTmr(tuCb->init.procId, tuCb->init.ent, tuCb->init.inst, tuCb->genCfg.timeRes);
#else
   tuCb->fn.tuDeregTmr(tuCb->init.ent, tuCb->init.inst, tuCb->genCfg.timeRes);
#endif
   
   SPutSMem(tuCb->init.region, tuCb->init.pool); 
   
   /* call the initialization function of ZJ */
#ifdef SS_MULTIPLE_PROCS
   tuCb->fn.tuActvInit(tuCb->init.procId, tuCb->init.ent, tuCb->init.inst, tuCb->init.region, ASHUTDOWN, NULLP);
#else
   tuCb->fn.tuActvInit(tuCb->init.ent, tuCb->init.inst, tuCb->init.region, ASHUTDOWN);
#endif

   RETVOID;        
   
} /* cmTuShutDown */


/*
 *
 *       Fun:   cmTuRsetCbTmrEvnt
 *
 *       Desc:  Rset Cb timer expiry event handler.
 *
 *       Ret:   Void
 *
 *       Notes: None
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuRsetCbTmrEvnt
(
CmTuCb      *tuCb,           /* PSF control block */
CmTuRsetCb  *rsetCb,         /* control block pointer */
S16         evnt             /* event                 */
)
#else
PUBLIC Void cmTuRsetCbTmrEvnt (tuCb, rsetCb, evnt)
CmTuCb      *tuCb;           /* PSF control block */
CmTuRsetCb  *rsetCb;         /* control block pointer */
S16         evnt;            /* event                 */
#endif
{
 
   TRC2 (cmTuRsetCbTmrEvnt)
   
   CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
            "cmTuRsetCbTmrEvnt() : Rset Cb timer expiry, event = %d\n", evnt));

   switch (evnt)
   {
      case CMTU_TMR_ACK:
      
         switch (rsetCb->updState)
         {
            case CMPFTHA_US_WARMSTART_WAIT: /* We are in warm start */
               rsetCb->peerState = CMPFTHA_PEER_DEAD;
               
               /* fall through */
            case CMPFTHA_US_PEERSYNC_WAIT: /* We are in controlled switchover*/
               rsetCb->updState = CMPFTHA_US_IDLE;
               /* This is a failure case */
               tuCb->fn.tuSendLmCfm(&tuCb->defLmPst, TCNTRL, &tuCb->lastCfm.cfm.hdr,
                                 LCM_PRIM_NOK, LCM_REASON_UPDTMR_EXPIRED);
               cmTuAbortCurOp(tuCb, CMFTHA_RES_RSETID, &tuCb->pendOp); 
               break;
               
            default:     /* This should not happen */
               CMTULOGERROR_DEBUG(ECMTU118, (ErrVal)rsetCb->updState,
                                 "cmTuRsetCbTmrEvnt: Invalid event");
               break;
         }
         break;
      case  CMTU_TMR_GRD :
#if (ERRCLASS & ERRCLS_DEBUG)  
         if (rsetCb->state != CMPFTHA_STATE_ACTIVE)
         {
            CMTULOGERROR_DEBUG (ECMTU118, 0, 
              "cmTuRsetCbTmrEvnt : GRD timer expired in invalid state");
            RETVOID;
         }
#endif /* (ERRCLASS & ERRCLS_DEBUG) */ 
         CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
                  "\nStopping recovery timer \n"));
         rsetCb->recovery = FALSE;

         cmTuRunTimeUpd(tuCb, CMTU_RSET_CB, CMPFTHA_UPDTYPE_NORMAL,
                        CMPFTHA_ACTN_MOD, (Void *)rsetCb);
         cmTuUpdPeer(tuCb);

         break;
         
      default:
         
         CMTULOGERROR_DEBUG(ECMTU118, (ErrVal)rsetCb->updState,
                           "cmTuRsetCbTmrEvnt: Unexpected timer event");
      break;
      
   }/* switch */

   RETVOID;
   
} /* cmTuRsetCbTmrEvnt */


/*
 *
 *       Fun:   cmTuStartRsetCbTmr
 *
 *       Desc:  Start a timer for a resource set.
 *
 *       Ret:   Void
 *
 *       Notes: 
 *
 *       File:  cm_tupsf.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuStartRsetCbTmr 
(
CmTuCb        *tuCb,         /* common psf control block */
CmTuRsetCb    *rsetCb,       /* resource set control block */
U8            evnt           /* timer event                */
)
#else
PUBLIC Void cmTuStartRsetCbTmr (tuCb, rsetCb, evnt)
CmTuCb        *tuCb;         /* common psf control block */
CmTuRsetCb    *rsetCb;       /* resource set control block */
U8            evnt;          /* timer event                */
#endif
{
   CmTmrArg    arg;        /* timer argument */

   TRC2 (cmTuStartRsetCbTmr)

#if (ERRCLASS & ERRCLS_INT_PAR)
   if (rsetCb == NULLP)
   {
      CMTULOGERROR_INT_PAR(ECMTU118, (ErrVal)ERRZERO, 
                  "cmTuStartRsetCbTmr: Null Pointer");
      RETVOID;
   }
#endif /* (ERRCLASS & ERRCLS_INT_PAR) */

   arg.tq     = tuCb->tq;
   arg.tqCp   = &tuCb->tqCp;
   arg.timers = rsetCb->timer;
   arg.cb     = (PTR)rsetCb;
   arg.evnt   = evnt;
   arg.wait   = 0;
   arg.tNum   = NOTUSED;
   arg.max    = CMTUMAXTIMER;
   
   switch (evnt)
   {
      case CMTU_TMR_ACK :
      
         if (tuCb->genCfg.tUpdCompAck.enb  == TRUE)
         {
            CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
            "Starting the update ack  timer\n"));        
            arg.wait = tuCb->genCfg.tUpdCompAck.val;
         }
         break;
      case CMTU_TMR_GRD :
         if ((tuCb->genCfg.tRecovery.enb  == TRUE) && 
             (tuCb->genCfg.tRecovery.val > 0) )
         {
            CMTUDBGP(CMTU_DBGMASK_INTERNAL, (tuCb->init.prntBuf, 
                     "Starting the guard timer\n"));        
            arg.wait = tuCb->genCfg.tRecovery.val;
         }
         else
         {
            rsetCb->recovery = FALSE;
         }
         break;
   }
   
   if (arg.wait != 0)
   {
      cmPlcCbTq(&arg);
   }
      
   RETVOID;
   
} /* cmTuStartRsetCbTmr */


/*
 *
 *       Fun:  cmTuStopRsetCbTmr
 *
 *       Desc:  Stop specified timer for a resource set.
 *
 *       Ret:  Void
 *
 *       Notes: 
 *
 *       File:  cmTu_bdy3.c
 *
 */
#ifdef ANSI
PUBLIC Void cmTuStopRsetCbTmr 
(
CmTuCb        *tuCb,         /* common psf control block */
CmTuRsetCb    *rsetCb,       /* resource set control block */
U8            evnt           /* timer event                */
)
#else
PUBLIC Void cmTuStopRsetCbTmr (tuCb, rsetCb, evnt)
CmTuCb        *tuCb;         /* common psf control block */
CmTuRsetCb    *rsetCb;       /* resource set control block */
U8            evnt;          /* timer event                */
#endif
{
   U8          tNum;          /* index to search timer arry */
   CmTmrArg    arg;           /* timer argument             */

   TRC2 (cmTuStopRsetCbTmr)

   for (tNum = 0; tNum < CMTUMAXTIMER; tNum++)
   {
        
      if (rsetCb->timer[tNum].tmrEvnt == evnt)
      {
         arg.tq     = tuCb->tq;
         arg.tqCp   = &tuCb->tqCp;
         arg.timers = rsetCb->timer;
         arg.cb     = (PTR)rsetCb;
         arg.evnt   = evnt;
         arg.wait   = NOTUSED;
         arg.tNum   = tNum;
         arg.max    = CMTUMAXTIMER;
   
         /* call common function */
         cmRmvCbTq(&arg);
      }
   }
   
   RETVOID;
} /* cmTuStopRsetCbTmr */


/********************************************************************30**
  
         End of file:     cm_tupsf.c@@/main/3 - Fri Dec 10 17:55:22 2004
   
*********************************************************************31*/


/********************************************************************40**

   Notes:

*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/


/********************************************************************60**

   Revision history:

*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      jz   1. initial release.
/main/3      ---      kk   1. The PSF specific functions shall be accessed
                              through function pointers.
               2. PSF-CAP specific changes
cm_tupsf_c_001.main_3 st   1. SS_MULTIPLE_PROCS support to aid in 
                              internal testing.
cm_tupsf_c_002.main_3 dv   1. Removed warnings
			   2. Removed memory leaks
*********************************************************************91*/
