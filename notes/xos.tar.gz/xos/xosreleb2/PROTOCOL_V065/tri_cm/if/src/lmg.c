/********************************************************************16**

                         (c) COPYRIGHT 1989-2005 by 
                         Continuous Computing Corporation.
                         All rights reserved.

     This software is confidential and proprietary to Continuous Computing 
     Corporation (CCPU).  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written Software License 
     Agreement between CCPU and its licensee.

     CCPU warrants that for a period, as provided by the written
     Software License Agreement between CCPU and its licensee, this
     software will perform substantially to CCPU specifications as
     published at the time of shipment, exclusive of any updates or 
     upgrades, and the media used for delivery of this software will be 
     free from defects in materials and workmanship.  CCPU also warrants 
     that has the corporate authority to enter into and perform under the   
     Software License Agreement and it is the copyright owner of the software 
     as originally delivered to its licensee.

     CCPU MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE, SERVICE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL CCPU BE LIABLE FOR ANY INDIRECT, SPECIAL,
     CONSEQUENTIAL DAMAGES, OR PUNITIVE DAMAGES IN CONNECTION WITH OR ARISING
     OUT OF THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the use set
     forth in the written Software License Agreement between CCPU and
     its Licensee. Among other things, the use of this software
     may be limited to a particular type of Designated Equipment, as 
     defined in such Software License Agreement.
     Before any installation, use or transfer of this software, please
     consult the written Software License Agreement or contact CCPU at
     the location set forth below in order to confirm that you are
     engaging in a permissible use of the software.

                    Continuous Computing Corporation
                    9380, Carroll Park Drive
                    San Diego, CA-92121, USA

                    Tel: +1 (858) 882 8800
                    Fax: +1 (858) 777 3388

                    Email: support@trillium.com
                    Web: http://www.ccpu.com

*********************************************************************17*/


/********************************************************************20**
  
     Name:    MGCP
  
     Type:    C include file 
  
     Desc:    packing unpacking functions of lmg interface
 
     File:    lmg.c

     Sid:      lmg.c@@/main/1 - Wed Mar 30 08:37:19 2005
  
     Prg:     rrp
  
*********************************************************************21*/

#include "envopt.h"        /* environment options */
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */


#include "cm_tpt.h"        /* common transport defines */
#include "cm_tkns.h"       /* common tokens */
#include "cm_dns.h"        /* common DNS library defines */
#include "hit.h"           /* HI layer */

#include "cm_sdp.h"        /* SDP related constants */
#ifdef ZG
#include "cm_psfft.h"      /* common PSF defines */
#include "cm_ftha.h"       /* common DFT/HA defines */
#endif /* ZG */

#ifdef    GCP_PROV_SCTP
#include "sct.h"           /* SCTP Interface Defines */
#endif    /* GCP_PROV_SCTP */

#ifdef   GCP_PROV_MTP3
#include  "cm_ss7.h"       /* Common SS7 Defines */
#include  "snt.h"          /* MTP3 Interface Defines */
#endif   /* GCP_PROV_MTP3 */

#include "mgt.h"           /* MGT defines */
#include "lmg.h"           /* MG layer management defines */


/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_lib.x"

#include "cm_tpt.x"        /* common transport types */
#include "cm_tkns.x"       /* common tokens */
#ifdef ZG
#include "cm_ftha.x"       /* common DFT/HA types */
#include "cm_psfft.x"      /* common PSF types */
#endif /* ZG */
#include "hit.x"           /* HI layer */


#include "cm_mblk.x"       /* common mem block alloc */
#include "cm_sdp.x"        /* SDP related types */

#ifdef    GCP_PROV_SCTP
#include "sct.x"           /* SCTP Interface Structures */
#endif    /* GCP_PROV_SCTP */

#ifdef    GCP_PROV_MTP3 
#include  "cm_ss7.x"       /* Common SS7 Structure */
#include  "snt.x"          /* MTP3 Interface Structure */
#endif    /* GCP_PROV_MTP3 */


#include "mgt.x"           /* MGT types */
#include "lmg.x"           /* MG layer management types */

/* header include files (.h) */

/* local defines */

/* local typedefs */

/* local externs */

/* forward references */

/* functions in other modules */

/* public variable declarations */

/* private variable declarations */

/*
*     layer management interface packing functions
*/

#define cmPkMgNullElmnt cmPkTknU8
#define cmUnpkMgNullElmnt cmUnpkTknU8
#/* Packing/Unpacking Macros */
#define cmPkMacroTknStrOSXL(tknStr, mBuf) cmPkTknStrOSXL(tknStr, mBuf)
#define cmUnpkMacroTknStrOSXL(tknStr, ptr, mBuf) cmUnpkTknStrOSXL(tknStr, mBuf, ptr)
#define cmPkMacroTknBuf(val, mBuf) cmPkTknBuf(val, mBuf)
#define cmUnpkMacroTknBuf(val, mBuf) cmUnpkTknBuf(val, &mBuf)

#ifdef GCP_PROV_SCTP
#define cmPkMgEndpCntrl cmPkSctPort
#define cmUnpkMgEndpCntrl cmUnpkSctPort
#endif /* GCP_PROV_SCTP */
#ifdef LCLMG


/*
 *
 * 002.main_1: made rspAckEnb reconfigurable
 *
 *    Fun:    cmPkMgGenReCfg
 *
 *    Desc:    pack the structure MgGenReCfg
 *
 *    Ret:    ROK  -ok
 *
 *    Notes:    None
 *
 *    File:     lmg.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkMgGenReCfg
(
MgGenReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgGenReCfg(param ,mBuf)
MgGenReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgGenReCfg)

    CMCHKPK(SPkU8, param->rspAckEnb, mBuf);

    RETVALUE(ROK);
} /*end of function cmPkMgGenReCfg*/

/* 003.main_1: Add - Addition for pending limit can be configure by Layer Manager */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
/*
 *    Fun:    cmPkPendingLimit
 *
 *    Desc:    pack the structure MgMgcoPendingLimit
 *
 *    Ret:    ROK  -ok
 *
 *    Notes:    None
 *
 *    File:     lmg.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmPkPendingLimit
(
MgMgcoPendingLimit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkPendingLimit(param ,mBuf)
MgMgcoPendingLimit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkPendingLimit)
      
    CMCHKPK(SPkU32, param->mgcOriginatedPendingLimit,mBuf);  
    CMCHKPK(SPkU32, param->mgOriginatedPendingLimit,mBuf);  
    CMCHKPK(cmPkTknPres, &param->pres,mBuf);

    RETVALUE(ROK);
} /*end of function cmPkPendingLimit */
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */


/*
*
*    Fun:    cmPkMgGenCfg
*
*    Desc:    pack the structure MgGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgGenCfg
(
MgGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgGenCfg(param ,mBuf)
MgGenCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgGenCfg)
/* 003.main_1: Add - Addition for pending limit can be configure by Layer Manager */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
    CMCHKPK(cmPkPendingLimit, &param->limit,mBuf);
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */

#if(  defined(GCP_CH)  && defined(GCP_VER_1_5) ) 
#ifdef GCP_MGC
    CMCHKPK(cmPkTmrCfg, &param->maxMgcCmdTimeOut,mBuf);
#endif /*  GCP_MGC  */
#ifdef GCP_MG
    CMCHKPK(cmPkTmrCfg, &param->maxMgCmdTimeOut,mBuf);
#endif /*  GCP_MG  */
    CMCHKPK(SPkU16, param->numBinsTransIndRspCmdHl,mBuf);
    CMCHKPK(SPkU16, param->numBinsTransReqHl,mBuf);
    CMCHKPK(SPkU16, param->numBinsPeerCmdHl,mBuf);
#endif /* GCP_CH && GCP_VER_1_5   */
#ifdef CM_ABNF_MT_LIB
    CMCHKPK(cmPkTmrCfg, &param->edDecTmr,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->edEncTmr,mBuf);
    CMCHKPK(SPkU8, param->firstInst,mBuf);
    CMCHKPK(SPkU8, param->noEDInst,mBuf);
#endif /*  CM_ABNF_MT_LIB  */
    CMCHKPK(SPkU8, param->resOrder,mBuf);
    CMCHKPK(SPkU8, param->indicateRetx,mBuf);
    CMCHKPK(SPkU8, param->entType,mBuf);
    CMCHKPK(SPkU16, param->numBinsTptSrvrHl,mBuf);
    CMCHKPK(SPkU16, param->numBinsNameHl,mBuf);
    CMCHKPK(SPkU16, param->numBinsTxnIdHl,mBuf);
    CMCHKPK(SPkU32, param->maxBlkSize,mBuf);
    CMCHKPK(SPkU32, param->numBlks,mBuf);
#ifdef GCP_VER_1_3
    /* 002.main_1: made rspAckEnb reconfigurable */
    CMCHKPK(cmPkMgGenReCfg, &param->reCfg, mBuf);
#endif /*  GCP_VER_1_3  */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU32, param->timeResTTL,mBuf);
#endif /*    */
    CMCHKPK(SPkU32, param->timeRes,mBuf);
    CMCHKPK(cmPkPst, &param->lmPst,mBuf);
    CMCHKPK(SPkS16, param->resThLower,mBuf);
    CMCHKPK(SPkS16, param->resThUpper,mBuf);
    CMCHKPK(SPkU32, param->maxPeer,mBuf);
    CMCHKPK(SPkU32, param->maxTxn,mBuf);
    CMCHKPK(SPkU32, param->maxConn,mBuf);
    CMCHKPK(SPkU32, param->maxServers,mBuf);
    CMCHKPK(SPkU32, param->maxTSaps,mBuf);
    CMCHKPK(SPkU16, param->maxSSaps,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgGenCfg*/

/*
*
*    Fun:    cmPkMgDnsCfg
*
*    Desc:    pack the structure MgDnsCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDnsCfg
(
MgDnsCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDnsCfg(param ,mBuf)
MgDnsCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgDnsCfg)

 
    /* mg001.104  Packing only if DNS is enabled */
    /* mg002.104  corrected dnsAccesss parameter */
    if (param->dnsAccess != LMG_DNS_DISABLED)
    {
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
       CMCHKPK(SPkU32, param->ttl,mBuf);
#endif /*   defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) )   */
       CMCHKPK(SPkU16, param->maxRetxCnt,mBuf);
       CMCHKPK(cmPkTmrCfg, &param->dnsRslvTmr,mBuf);
       CMCHKPK(cmPkCmTptAddr, &param->dnsAddr,mBuf);
    }
    CMCHKPK(SPkU8, param->dnsAccess,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDnsCfg*/

/*
*
*    Fun:    cmPkMgTSAPReCfg
*
*    Desc:    pack the structure MgTSAPReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTSAPReCfg
(
MgTSAPReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTSAPReCfg(param ,mBuf)
MgTSAPReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTSAPReCfg)

#ifdef ZG
    CMCHKPK(SPkS16, param->spId,mBuf);
    CMCHKPK(cmPkPst, &param->dstPst,mBuf);
    CMCHKPK(SPkU8, param->changeOver,mBuf);
#endif /*  ZG  */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(cmPkTmrCfg, &param->idleTmr,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU16, param->defSuspThold,mBuf);
    CMCHKPK(SPkU16, param->defDisConThold,mBuf);
#endif /*    */
    CMCHKPK(cmPkCmTptParam, &param->tptParam,mBuf);
    CMCHKPK(SPkU32, param->tMax,mBuf);
    CMCHKPK(cmPkMgDnsCfg, &param->dnsCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTSAPReCfg*/
#ifdef GCP_PROV_MTP3

/*
*
*    Fun:    cmPkMgMtpNwCfg
*
*    Desc:    pack the structure MgMtpNwCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMtpNwCfg
(
MgMtpNwCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMtpNwCfg(param ,mBuf)
MgMtpNwCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMtpNwCfg)

    CMCHKPK(cmPkTmrCfg, &param->defRstEndTmr,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->defStatusEnqTmr,mBuf);
    CMCHKPK(SPkU32, param->maxBinsMgcoMtpHl,mBuf);
    CMCHKPK(SPkU8, param->sls,mBuf);
    CMCHKPK(SPkU8, param->subService,mBuf);
    CMCHKPK(SPkU8, param->pcLen,mBuf);
    CMCHKPK(SPkU8, param->upSwtch,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMtpNwCfg*/
#endif /* GCP_PROV_MTP3 */

/*
*
*    Fun:    cmPkMgTSAPCfg
*
*    Desc:    pack the structure MgTSAPCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTSAPCfg
(
MgTSAPCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTSAPCfg(param ,mBuf)
MgTSAPCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTSAPCfg)

#ifdef GCP_PROV_MTP3
    CMCHKPK(cmPkMgMtpNwCfg, &param->mgMtpNwCfg,mBuf);
#endif /*  GCP_PROV_MTP3  */
#ifdef GCP_PROV_SCTP
    CMCHKPK(SPkU32, param->numBinsAssocHl,mBuf);
#endif /*  GCP_PROV_SCTP  */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU16, param->remIntfVer,mBuf);
    CMCHKPK(SPkU8, param->remIntfValid,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKPK(cmPkMgTSAPReCfg, &param->reCfg,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->bndTmrCfg,mBuf);
    CMCHKPK(SPkU8, param->dstSel,mBuf);
    CMCHKPK(SPkU8, param->dstRoute,mBuf);
    CMCHKPK(SPkU8, param->dstPrior,mBuf);
    CMCHKPK(SPkU8, param->dstInst,mBuf);
    CMCHKPK(SPkU8, param->dstEnt,mBuf);
    CMCHKPK(SPkU16, param->dstProcId,mBuf);
    CMCHKPK(cmPkMemoryId, &param->memId,mBuf);
    CMCHKPK(SPkU8, param->provType,mBuf);
    CMCHKPK(SPkS16, param->spId,mBuf);
    CMCHKPK(SPkS16, param->tSAPId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTSAPCfg*/

/*
*
*    Fun:    cmPkMgSSAPReCfg
*
*    Desc:    pack the structure MgSSAPReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSSAPReCfg
(
MgSSAPReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSSAPReCfg(param ,mBuf)
MgSSAPReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSSAPReCfg)

    CMCHKPK(SPkU32, param->provRspDelay,mBuf);
#ifdef GCP_VER_1_3
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
#ifdef GCP_2705BIS
    CMCHKPK(cmPkTmrCfg, &param->txnTmoutTmr,mBuf);
#endif /*  GCP_2705BIS  */
#endif /*    */
#endif /*  GCP_VER_1_3  */
    CMCHKPK(cmPkTmrCfg, &param->atMostOnceTmr,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->provRspTmr,mBuf);
    CMCHKPK(cmPkTmrCfg, &param->initRetxTmr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSSAPReCfg*/

/*
*
*    Fun:    cmPkMgSSAPCfg
*
*    Desc:    pack the structure MgSSAPCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSSAPCfg
(
MgSSAPCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSSAPCfg(param ,mBuf)
MgSSAPCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSSAPCfg)
/* 004.main_1: GCP_ALLOW_LIMIT_CFG - This is introduced to configured the */
/*       limits for GCP message components exceeding which will be rejected */
#ifdef GCP_ALLOW_LIMIT_CFG
   CMCHKPK(cmPkTknU8, &param->maxNoOfCmdsPerActn, mBuf); 
   CMCHKPK(cmPkTknU8, &param->maxNoOfActnsPerTxn, mBuf); 
   CMCHKPK(cmPkTknU8, &param->maxNoOfTxnsPerMsg, mBuf); 
#endif /* GCP_ALLOW_LIMIT_CFG  */
 
#ifdef GCP_ALLOW_PROF_CFG
    CMCHKPK(cmPkMgProf, &param->profile,mBuf);
#endif /*  GCP_ALLOW_PROF_CFG  */

#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 
    CMCHKPK(SPkU8, param->chEnabled,mBuf);
#endif /*    */
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU16, param->dstProcId,mBuf);
    CMCHKPK(SPkU16, param->remIntfVer,mBuf);
    CMCHKPK(SPkU8, param->remIntfValid,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKPK(cmPkMgSSAPReCfg, &param->reCfg,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU32, param->minMgcoVersion,mBuf);
    CMCHKPK(SPkU32, param->maxMgcoVersion,mBuf);
#endif /*    */
#ifdef GCP_MG
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU32, param->mgcpVersion,mBuf);
#endif /*    */
    CMCHKPK(SPkU16, param->mwdTimer,mBuf);
    CMCHKPK(SPkU8, param->initReg,mBuf);
#endif /*  GCP_MG  */
    CMCHKPK(SPkU32, param->endTxnNum,mBuf);
    CMCHKPK(SPkU32, param->startTxnNum,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->userInfo,mBuf);
    CMCHKPK(SPkU8, param->protocol,mBuf);
    CMCHKPK(SPkU8, param->route,mBuf);
    CMCHKPK(SPkU8, param->prior,mBuf);
    CMCHKPK(cmPkMemoryId, &param->memId,mBuf);
    CMCHKPK(SPkU8, param->sel,mBuf);
    CMCHKPK(SPkS16, param->sSAPId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSSAPCfg*/

/* 004.main_1: Service change profile information */  
#ifdef GCP_ALLOW_PROF_CFG
/*
*
*    Fun:    cmPkMgProf
*
*    Desc:    pack the structure MgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgProf
(
MgProf *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgProf(param ,mBuf)
MgProf *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgProf)

    for (i=param->len -1;i>=0;i--)
    {
       CMCHKPK(SPkU8, param->profStr[i],mBuf);
    }
    CMCHKPK(SPkU16, param->len,mBuf);
    CMCHKPK(SPkU8, param->ver,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgProf*/
#endif /* GCP_ALLOW_PROF_CFG */

#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 

/*
*
*    Fun:    cmPkMgPeerReCfg
*
*    Desc:    pack the structure MgPeerReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerReCfg
(
MgPeerReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerReCfg(param ,mBuf)
MgPeerReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPeerReCfg)

    CMCHKPK(SPkU16, param->disconThold,mBuf);
    CMCHKPK(SPkU16, param->suspThold,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerReCfg*/
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */

/*
*
*    Fun:    cmPkMgNetAddrTbl
*
*    Desc:    pack the structure MgNetAddrTbl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgNetAddrTbl
(
MgNetAddrTbl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgNetAddrTbl(param ,mBuf)
MgNetAddrTbl *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgNetAddrTbl)

    for (i=param->count -1;i>=0;i--)
    {
       CMCHKPK(cmPkCmNetAddr, &param->netAddr[i], mBuf);
    }
    CMCHKPK(SPkU16, param->count,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgNetAddrTbl*/

/*
*
*    Fun:    cmPkMgPeerCfg
*
*    Desc:    pack the structure MgPeerCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerCfg
(
MgPeerCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerCfg(param ,mBuf)
MgPeerCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgPeerCfg)

#ifdef GCP_PROV_MTP3
    CMCHKPK(SPkU32, param->peerDpc,mBuf);
#endif /*  GCP_PROV_MTP3  */
#ifdef GCP_MG
    CMCHKPK(SPkS16, param->tsapId,mBuf);
#endif /*  GCP_MG  */

#ifdef GCP_PROV_SCTP
    /* lmg_c_001.main_1: TOS support changes */
#ifdef GCP_MG
    CMCHKPK(cmPkTknU8, &param->tos, mBuf);
#endif /*  GCP_MG  */
    CMCHKPK(cmPkSctStrmId, param->locOutStrms,mBuf);
#endif /*  GCP_PROV_SCTP  */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(cmPkMgPeerReCfg, &param->peerReCfg,mBuf);
    CMCHKPK(SPkU32, param->ttl,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
#ifdef GCP_MG
    CMCHKPK(SPkU8, param->useAHScheme,mBuf);
    CMCHKPK(SPkU16, param->mgcPriority,mBuf);
    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
#endif /*  GCP_MG  */
    CMCHKPK(cmPkMgMgcoMidStr, &param->mid,mBuf);
#endif /*    */
#ifdef GCP_MG
    CMCHKPK(SPkU8, param->transportType,mBuf);
#endif /*  GCP_MG  */
    CMCHKPK(SPkU16, param->mtuSize,mBuf);
    CMCHKPK(SPkS32, param->port,mBuf);
    for (i=CM_DNS_DNAME_LEN -1;i>=0;i--)
    {
       CMCHKPK(SPkU8, param->name[i],mBuf);
    }
    CMCHKPK(cmPkMgNetAddrTbl, &param->peerAddrTbl,mBuf);
    CMCHKPK(SPkS16, param->sSAPId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerCfg*/

/*
*
*    Fun:    cmPkMgGcpEntCfg
*
*    Desc:    pack the structure MgGcpEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgGcpEntCfg
(
MgGcpEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgGcpEntCfg(param ,mBuf)
MgGcpEntCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgGcpEntCfg)

    for (i=param->numPeer -1;i>=0;i--)
    {
       CMCHKPK(cmPkMgPeerCfg, &param->peerCfg[i], mBuf);
    }
    CMCHKPK(SPkU16, param->numPeer,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgGcpEntCfg*/
#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MGC

/*
*
*    Fun:    cmPkMgMtdGcpEntCfg
*
*    Desc:    pack the structure MgMtdGcpEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMtdGcpEntCfg
(
MgMtdGcpEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMtdGcpEntCfg(param ,mBuf)
MgMtdGcpEntCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgMtdGcpEntCfg)

    CMCHKPK(cmPkMgPeerCfg, &param->stdPeerCfg,mBuf);
    CMCHKPK(cmPkMgPeerCfg, &param->actPeerCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMtdGcpEntCfg*/
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
#endif /* ZG */
#ifdef GCP_PROV_SCTP

/*
*
*    Fun:    cmPkMgEndpCfg
*
*    Desc:    pack the structure MgEndpCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEndpCfg
(
MgEndpCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEndpCfg(param ,mBuf)
MgEndpCfg *param;
Buffer *mBuf;
#endif
{

    TRC3(cmPkMgEndpCfg)

    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
    CMCHKPK(cmPkSctPort, param->sctPort,mBuf);
    CMCHKPK(SPkS16, param->tSAPId,mBuf);
#ifdef GCP_MG
    /* lmg_c_001.main_1: TOS support changes */
    CMCHKPK(cmPkTknU8, &param->defaultTos, mBuf);
    CMCHKPK(SPkS16, param->sSAPId,mBuf);
#endif /*  GCP_MG  */
    RETVALUE(ROK);
} /*end of function cmPkMgEndpCfg*/

/*
*
*    Fun:    cmPkMgEndpLstCfg
*
*    Desc:    pack the structure MgEndpLstCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgEndpLstCfg
(
MgEndpLstCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgEndpLstCfg(param ,mBuf)
MgEndpLstCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgEndpLstCfg)

    for (i=0; i < param->count; i++)
    {
      CMCHKPK(cmPkMgEndpCfg, &param->endp[i],mBuf);
    }

    CMCHKPK(SPkU32, param->count,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgEndpLstCfg*/

/*
*
*    Fun:    cmPkMgAssocCfg
*
*    Desc:    pack the structure MgAssocCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAssocCfg
(
MgAssocCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAssocCfg(param ,mBuf)
MgAssocCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgAssocCfg)

    CMCHKPK(cmPkSctPort, param->remPort,mBuf);
    CMCHKPK(cmPkSctNetAddrLst, &param->srcAddrLst,mBuf);
    CMCHKPK(cmPkSctNetAddrLst, &param->dstAddrLst,mBuf);
    CMCHKPK(cmPkCmNetAddr, &param->priDstAddr,mBuf);
    CMCHKPK(cmPkSctStrmId, param->locOutStrms,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAssocCfg*/
#endif /* GCP_PROV_SCTP */

/*
*
*    Fun:    cmPkMgSrvrCfg
*
*    Desc:    pack the structure MgSrvrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSrvrCfg
(
MgSrvrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSrvrCfg(param ,mBuf)
MgSrvrCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSrvrCfg)

    CMCHKPK(cmPkCmTptAddr, &param->lclTptAddr,mBuf);
    CMCHKPK(cmPkCmTptParam, &param->tptParam,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
#endif /*    */
    CMCHKPK(SPkU8, param->transportType,mBuf);
    CMCHKPK(SPkU8, param->protocol,mBuf);
    CMCHKPK(SPkS16, param->tSAPId,mBuf);
    CMCHKPK(SPkS16, param->sSAPId,mBuf);
    CMCHKPK(SPkU8, param->isDefault,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSrvrCfg*/

/*
*
*    Fun:    cmPkMgTptSrvrCfg
*
*    Desc:    pack the structure MgTptSrvrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTptSrvrCfg
(
MgTptSrvrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTptSrvrCfg(param ,mBuf)
MgTptSrvrCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgTptSrvrCfg)

    for (i=param->count -1;i>=0;i--)
    {
       CMCHKPK(cmPkMgSrvrCfg, &param->srvr[i], mBuf);
    }
    CMCHKPK(SPkU16, param->count,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTptSrvrCfg*/

/*
*
*    Fun:    cmPkMgCfg
*
*    Desc:    pack the structure MgCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgCfg
(
MgCfg *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgCfg(param ,elmnt, mBuf)
MgCfg *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgCfg)

    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKPK(cmPkMgGcpEntCfg, &param->c.mgGcpEntCfg,mBuf);
          break;
       case  STGEN :
          CMCHKPK(cmPkMgGenCfg, &param->c.genCfg,mBuf);
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          CMCHKPK(cmPkMgEndpLstCfg, &param->c.endpCfg,mBuf);
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          CMCHKPK(cmPkMgTptSrvrCfg, &param->c.tptSrvrCfg,mBuf);
          break;
       case  STSSAP :
          CMCHKPK(cmPkMgSSAPCfg, &param->c.sSAPCfg,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkMgTSAPCfg, &param->c.tSAPCfg,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgCfg*/

/*
*
*    Fun:    cmPkMgDnsSts
*
*    Desc:    pack the structure MgDnsSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDnsSts
(
MgDnsSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDnsSts(param ,mBuf)
MgDnsSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgDnsSts)

    CMCHKPK(SPkU32, param->numAQueryFailed,mBuf);
    CMCHKPK(SPkU32, param->numAQueryTx,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDnsSts*/

/*
*
*    Fun:    cmPkMgTSAPSts
*
*    Desc:    pack the structure MgTSAPSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTSAPSts
(
MgTSAPSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTSAPSts(param ,mBuf)
MgTSAPSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTSAPSts)

    CMCHKPK(cmPkMgDnsSts, &param->dnsSts,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTSAPSts*/

/*
*
*    Fun:    cmPkMgPeerSts
*
*    Desc:    pack the structure MgPeerSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerSts
(
MgPeerSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerSts(param ,mBuf)
MgPeerSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPeerSts)

#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 

    /* lmg_c_005.main_1: Added error code counter */
    CMCHKPK(SPkU32, param->numErrorsMgcoPduSize,mBuf);
    CMCHKPK(SPkU32, param->numErrorsMgcoRsrcErr,mBuf);
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))    
    CMCHKPK(SPkU32, param->numErrorsMgcoTxnPendEx,mBuf);
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */    
    CMCHKPK(SPkU32, param->numErrorsMgcoReqRcvdBefReg,mBuf);
    CMCHKPK(SPkU32, param->numErrorsMgcoNotReady,mBuf);
#if (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN)) 
    CMCHKPK(SPkU32, param->numErrorsMgcoPkgUnsupp,mBuf);
#endif /* MGT_UNKNOWN_PKG_REJ && GCP_ASN */
    CMCHKPK(SPkU32, param->numErrorsMgcoVerUnSupp,mBuf);
    CMCHKPK(SPkU32, param->numErrorsMgcoProtErr,mBuf);
    CMCHKPK(SPkU32, param->numErrorsMgcoBadReq,mBuf);

    CMCHKPK(SPkU32, param->numTransPendRx,mBuf);
    CMCHKPK(SPkU32, param->numRespAckRx,mBuf);
    CMCHKPK(SPkU32, param->numServiceChgRx,mBuf);
    CMCHKPK(SPkU32, param->numTransRx,mBuf);
    CMCHKPK(SPkU32, param->numTransPendTx,mBuf);
    CMCHKPK(SPkU32, param->numRespAckTx,mBuf);
    CMCHKPK(SPkU32, param->numServiceChgTx,mBuf);
    CMCHKPK(SPkU32, param->numTransTx,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU32, param->numRsipRx,mBuf);
    CMCHKPK(SPkU32, param->numAuditConnRx,mBuf);
    CMCHKPK(SPkU32, param->numAuditEndPtRx,mBuf);
    CMCHKPK(SPkU32, param->numNotifyRx,mBuf);
    CMCHKPK(SPkU32, param->numRqntRx,mBuf);
    CMCHKPK(SPkU32, param->numDeleteRx,mBuf);
    CMCHKPK(SPkU32, param->numModifyRx,mBuf);
    CMCHKPK(SPkU32, param->numCreateRx,mBuf);
    CMCHKPK(SPkU32, param->numEpcfRx,mBuf);
    CMCHKPK(SPkU32, param->numRsipTx,mBuf);
    CMCHKPK(SPkU32, param->numAuditConnTx,mBuf);
    CMCHKPK(SPkU32, param->numAuditEndPtTx,mBuf);
    CMCHKPK(SPkU32, param->numNotifyTx,mBuf);
    CMCHKPK(SPkU32, param->numRqntTx,mBuf);
    CMCHKPK(SPkU32, param->numDeleteTx,mBuf);
    CMCHKPK(SPkU32, param->numModifyTx,mBuf);
    CMCHKPK(SPkU32, param->numCreateTx,mBuf);
    CMCHKPK(SPkU32, param->numEpcfTx,mBuf);
    CMCHKPK(SPkU32, param->numNonStdRx,mBuf);
    CMCHKPK(SPkU32, param->numNonStdTx,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
    CMCHKPK(SPkU32, param->numRspAckRspRx,mBuf);
    CMCHKPK(SPkU32, param->numRspAckRspTx,mBuf);
#endif /*  GCP_2705BIS  */
#endif /*  GCP_VER_1_3  */
#endif /*    */
    CMCHKPK(SPkU32, param->numErrors,mBuf);
    CMCHKPK(SPkU32, param->numRespFailedRx,mBuf);
    CMCHKPK(SPkU32, param->numRespRx,mBuf);
    CMCHKPK(SPkU32, param->numRespTx,mBuf);
    CMCHKPK(SPkU32, param->numMsgRx,mBuf);
    CMCHKPK(SPkU32, param->numMsgTx,mBuf);
    CMCHKPK(SPkS16, param->sSAPId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerSts*/

/*
*
*    Fun:    cmPkMgPeerEntSts
*
*    Desc:    pack the structure MgPeerEntSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerEntSts
(
MgPeerEntSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerEntSts(param ,mBuf)
MgPeerEntSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPeerEntSts)

    CMCHKPK(cmPkMgPeerSts, &param->peerSts,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKPK(SPkS16, param->sapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerEntSts*/

/*
*
*    Fun:    cmPkMgSts
*
*    Desc:    pack the structure MgSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSts
(
MgSts *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSts(param ,elmnt, mBuf)
MgSts *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSts)

    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKPK(cmPkMgPeerEntSts, &param->s.mgPeerEntSts,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkMgTSAPSts, &param->s.mgTSAPSts,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgSts*/

/*
*
*    Fun:    cmPkMgTSAPSta
*
*    Desc:    pack the structure MgTSAPSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTSAPSta
(
MgTSAPSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTSAPSta(param ,mBuf)
MgTSAPSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTSAPSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU16, param->remIntfVer,mBuf);
    CMCHKPK(SPkU16, param->selfIntfVer,mBuf);
    CMCHKPK(SPkU8, param->remIntfValid,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKPK(SPkU8, param->state,mBuf);
    CMCHKPK(SPkU16, param->numServers,mBuf);
    CMCHKPK(SPkU8, param->resCong,mBuf);
    CMCHKPK(SPkS16, param->tSapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTSAPSta*/

/*
*
*    Fun:    cmPkMgSSAPSta
*
*    Desc:    pack the structure MgSSAPSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSSAPSta
(
MgSSAPSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSSAPSta(param ,mBuf)
MgSSAPSta *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgSSAPSta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU16, param->remIntfVer,mBuf);
    CMCHKPK(SPkU16, param->selfIntfVer,mBuf);
    CMCHKPK(SPkU8, param->remIntfValid,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKPK(SPkU16, param->numTCPlosses,mBuf);
    CMCHKPK(SPkU16, param->numServers,mBuf);
    for (i=param->numAssocPeer -1;i>=0;i--)
    {
       CMCHKPK(cmPkMgPeerInfo, &param->peerInfo[i], mBuf);
    }
    CMCHKPK(SPkU8, param->more,mBuf);
    CMCHKPK(SPkU16, param->numAssocPeer,mBuf);
    CMCHKPK(SPkU8, param->state,mBuf);
    CMCHKPK(SPkS16, param->sapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSSAPSta*/

/*
*
*    Fun:    cmPkMgPeerSta
*
*    Desc:    pack the structure MgPeerSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerSta
(
MgPeerSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerSta(param ,mBuf)
MgPeerSta *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmPkMgPeerSta)
#ifdef   GCP_PROV_MTP3
    CMCHKPK(SPkU8, param->dpcStatus,mBuf);
    CMCHKPK(cmPkTknU32, &param->peerDpc,mBuf);

#endif   /* GCP_PROV_MTP3 */    

#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
#endif /*    */
    CMCHKPK(SPkU32, param->rttEstimate,mBuf);
    CMCHKPK(SPkU32, param->numPendIcTxn,mBuf);
    CMCHKPK(SPkU32, param->numPendOgTxn,mBuf);
    CMCHKPK(SPkU32, param->version,mBuf);
    CMCHKPK(SPkU8, param->transportType,mBuf);
    CMCHKPK(SPkU8, param->protocol,mBuf);
    CMCHKPK(SPkS16, param->sSapId,mBuf);
    CMCHKPK(SPkU8, param->peerState,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKPK(cmPkMgMgcoMidStr, &param->mid,mBuf);
#endif /*    */
    CMCHKPK(cmPkTknS32, &param->port,mBuf);
    CMCHKPK(cmPkMgNetAddrTbl, &param->peerAddrTbl,mBuf);
    if( param->namePres.pres == PRSNT_NODEF )
    {
       for (i=CM_DNS_DNAME_LEN -1;i>=0;i--)
       {
          CMCHKPK(SPkU8, param->name[i],mBuf);
       }
    }
    CMCHKPK(cmPkTknPres, &param->namePres,mBuf);
#ifdef GCP_USE_PEERID
    CMCHKPK(cmPkTknU32, &param->peerId,mBuf);
#endif /*  GCP_USE_PEERID  */
    RETVALUE(ROK);
} /*end of function cmPkMgPeerSta*/

/*
*
*    Fun:    cmPkMgTptSrvSta
*
*    Desc:    pack the structure MgTptSrvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTptSrvSta
(
MgTptSrvSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTptSrvSta(param ,mBuf)
MgTptSrvSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTptSrvSta)

    CMCHKPK(SPkU8, param->state,mBuf);
    CMCHKPK(cmPkCmTptAddr, &param->tptAddr,mBuf);
    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
    CMCHKPK(SPkU8, param->transportType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTptSrvSta*/
#ifdef GCP_PROV_SCTP

/*
*
*    Fun:    cmPkMgSctpEpSta
*
*    Desc:    pack the structure MgSctpEpSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSctpEpSta
(
MgSctpEpSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSctpEpSta(param ,mBuf)
MgSctpEpSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSctpEpSta)

    CMCHKPK(SPkU8, param->state,mBuf);
    CMCHKPK(SPkU8, param->encodingScheme,mBuf);
    CMCHKPK(cmPkSctPort, param->port,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgSctpEpSta*/
#endif /* GCP_PROV_SCTP */

/*
*
*    Fun:    cmPkMgSsta
*
*    Desc:    pack the structure MgSsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgSsta
(
MgSsta *param,
Elmnt elmnt,
S16 eventType,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgSsta(param ,elmnt, eventType, mBuf)
MgSsta *param;
Elmnt elmnt;
S16 eventType;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgSsta)

    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKPK(cmPkMgPeerSta, &param->s.mgPeerSta,mBuf);
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          CMCHKPK(cmPkMgSctpEpSta, &param->s.mgSctpEpSta,mBuf);
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          CMCHKPK(cmPkMgTptSrvSta, &param->s.mgTptSrvSta,mBuf);
          break;
       case  STSID :
          if( eventType == EVTLMGSTACFM )
          {
             CMCHKPK(cmPkSystemId, &param->s.systemId,mBuf);
          }
          break;
       case  STSSAP :
          CMCHKPK(cmPkMgSSAPSta, &param->s.mgSSAPSta,mBuf);
          break;
       case  STTSAP :
          CMCHKPK(cmPkMgTSAPSta, &param->s.mgTSAPSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgSsta*/

/*
*
*    Fun:    cmPkMgAddrInfo
*
*    Desc:    pack the structure MgAddrInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAddrInfo
(
MgAddrInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAddrInfo(param ,mBuf)
MgAddrInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgAddrInfo)

#ifdef GCP_PROV_MTP3
    CMCHKPK(cmPkTknU32, &param->peerDpc,mBuf);
#endif /*  GCP_PROV_MTP3  */
    CMCHKPK(cmPkTknS32, &param->port,mBuf);
    CMCHKPK(cmPkMgDName, &param->addr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAddrInfo*/

/*
*
*    Fun:    cmPkMgPeerCntrl
*
*    Desc:    pack the structure MgPeerCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgPeerCntrl
(
MgPeerCntrl *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgPeerCntrl(param ,action, mBuf)
MgPeerCntrl *param;
U8 action;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgPeerCntrl)

    switch( action )
    {
       case  AHANDOFF :
          CMCHKPK(cmPkMgAddrInfo, &param->u.handoffMgc,mBuf);
          break;
       case  AMATEDCFG_ADD :
          CMCHKPK(cmPkMgPeerInfo, &param->u.standbyPeer,mBuf);
          break;
       case  AMATEDCFG_RMV :
          CMCHKPK(cmPkMgPeerInfo, &param->u.standbyPeer,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(cmPkMgPeerInfo, &param->activePeer,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgPeerCntrl*/

/*
*
*    Fun:    cmPkMgParId
*
*    Desc:    pack the structure MgParId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgParId
(
MgParId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgParId(param ,mBuf)
MgParId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgParId)

    CMCHKPK(SPkS16, param->sapId,mBuf);
    CMCHKPK(SPkU8, param->parType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgParId*/

/*
*
*    Fun:    cmPkMgAlarmInfo
*
*    Desc:    pack the structure MgAlarmInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgAlarmInfo
(
MgAlarmInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgAlarmInfo(param ,mBuf)
MgAlarmInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgAlarmInfo)

    switch( param->type )
    {
       case  LMG_ALARMINFO_MATED_PEER :
          ret1 = cmPkMgPeerCntrl(&param->u.matedPairInfo, AMATEDCFG_ADD ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  LMG_ALARMINFO_MEM :
          CMCHKPK(cmPkMemoryId, &param->u.mem,mBuf);
          break;
       case  LMG_ALARMINFO_NONE :
          break;
       case  LMG_ALARMINFO_PAR :
          CMCHKPK(cmPkMgParId, &param->u.parId,mBuf);
          break;
       case  LMG_ALARMINFO_PEER :
          CMCHKPK(cmPkMgPeerInfo, &param->u.peerInfo,mBuf);
          break;
       case  LMG_ALARMINFO_PEER_STA :
          CMCHKPK(cmPkMgPeerSta, &param->u.peerSta,mBuf);
          break;
       case  LMG_ALARMINFO_SAP :
          CMCHKPK(SPkS16, param->u.sapId,mBuf);
          break;
       case  LMG_ALARMINFO_SRVR :
          CMCHKPK(cmPkMgTptSrvSta, &param->u.srvSta,mBuf);
          break;
       case  LMG_ALARMINFO_SSAP_STA :
          CMCHKPK(cmPkMgSSAPSta, &param->u.ssapSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
#ifdef GCP_VER_1_3
    CMCHKPK(SPkS16, param->sapId,mBuf);
#endif /*  GCP_VER_1_3  */
    CMCHKPK(SPkU8, param->type,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgAlarmInfo*/

/*
*
*    Fun:    cmPkMgUsta
*
*    Desc:    pack the structure MgUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgUsta
(
MgUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgUsta(param ,mBuf)
MgUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgUsta)

    CMCHKPK(cmPkMgAlarmInfo, &param->alarmInfo,mBuf);
    CMCHKPK(cmPkCmAlarm, &param->alarm,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgUsta*/

/*
*
*    Fun:    cmPkMgTrc
*
*    Desc:    pack the structure MgTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTrc
(
MgTrc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTrc(param ,mBuf)
MgTrc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTrc)

    CMCHKPK(SPkU16, param->evnt,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKPK(SPkS16, param->sapId,mBuf);
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgTrc*/

/*
*
*    Fun:    cmPkMgTptCntrl
*
*    Desc:    pack the structure MgTptCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTptCntrl
(
MgTptCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTptCntrl(param ,mBuf)
MgTptCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTptCntrl)

    CMCHKPK(cmPkCmTptAddr, &param->serverAddr,mBuf);
    CMCHKPK(SPkU8, param->transportType,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTptCntrl*/

/*
*
*    Fun:    cmPkMgTrcCntrl
*
*    Desc:    pack the structure MgTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgTrcCntrl
(
MgTrcCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgTrcCntrl(param ,mBuf)
MgTrcCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgTrcCntrl)

    CMCHKPK(SPkS16, param->trcLen,mBuf);
    CMCHKPK(cmPkMgPeerInfo, &param->peerInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgTrcCntrl*/

/*
*
*    Fun:    cmPkMgDbgCntrl
*
*    Desc:    pack the structure MgDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgDbgCntrl
(
MgDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgDbgCntrl(param ,mBuf)
MgDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmPkMgDbgCntrl)

    CMCHKPK(SPkU32, param->genDbgMask,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgDbgCntrl*/

/*
*
*    Fun:    cmPkMgCntrl
*
*    Desc:    pack the structure MgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgCntrl
(
MgCntrl *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgCntrl(param ,elmnt, mBuf)
MgCntrl *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgCntrl)

    switch( elmnt )
    {
       case  STGCPENT :
          switch( param->subAction )
          {
             case  SATRC :
                CMCHKPK(cmPkMgTrcCntrl, &param->s.trcCntrl,mBuf);
                break;
             default:
                CMCHKPK(cmPkMgPeerInfo, &param->s.peerInfo,mBuf);
                break;
          }
          break;
       case  STGCPENTCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
                CMCHKPK(cmPkMgGcpEntCfg, &param->s.mgGcpEntCfg,mBuf);
#endif /*  ZG  */
                break;
          }
          break;
       case  STGCPMG :
          switch( param->subAction )
          {
             default:
                break;
          }
          break;
       case  STGCPMGC :
          switch( param->subAction )
          {
             case  SAELMNT :
                ret1 = cmPkMgPeerCntrl(&param->s.peerCntrlInfo, param->action ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STGCPSRVRCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
                CMCHKPK(cmPkMgTptSrvrCfg, &param->s.tptSrvrCfg,mBuf);
#endif /*  ZG  */
                break;
          }
          break;
       case  STGEN :
          switch( param->subAction )
          {
             case  SADBG :
                CMCHKPK(cmPkMgDbgCntrl, &param->s.dbg,mBuf);
                break;
             case  SAELMNT :
                break;
             case  SATRC :
                CMCHKPK(cmPkMgTrcCntrl, &param->s.trcCntrl,mBuf);
                break;
             case  SAUSTA :
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STGRSSAP :
          switch( param->subAction )
          {
             default:
                switch( param->subAction )
                {
                   case  SAGR_DSTPROCID :
                      CMCHKPK(SPkU16, param->s.par.dstProcId,mBuf);
                      break;
                   case  SAGR_PRIORITY :
                      CMCHKPK(SPkU8, param->s.par.priority,mBuf);
                      break;
                   case  SAGR_ROUTE :
                      CMCHKPK(SPkU8, param->s.par.route,mBuf);
                      break;
                   default:
                      RETVALUE(RFAILED);
                }
                break;
          }
          break;
       case  STMTDGCPENTCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MGC
                CMCHKPK(cmPkMgMtdGcpEntCfg, &param->s.mtdGcpEntCfg,mBuf);
#endif /*  GCP_MGC  */
#endif /*  GCP_MGCO  */
#endif /*  ZG  */
                break;
          }
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          switch( param->subAction )
          {
             default:
                CMCHKPK(cmPkMgEndpCntrl, &param->s.endpCntrl,mBuf);
                break;
          }
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          switch( param->subAction )
          {
             case  SAELMNT :
                CMCHKPK(cmPkMgTptCntrl, &param->s.tptCntrl,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STSSAP :
          switch( param->subAction )
          {
             default:
                break;
          }
          break;
       case  STTSAP :
          switch( param->subAction )
          {
   			 case SATRC:		/* add by cdw on 2006-9-29 */
					CMCHKPK(cmPkMgTrcCntrl, &param->s.trcCntrl,mBuf);       
             default:
                break;
          }
          break;
	   case  STGRTSAP :   /* add by cdw on 2006-9-29 */
		  switch ( param->subAction )
		  {
			 case  SAGR_DSTPROCID :
				CMCHKPK(cmPkProcId, param->s.par.dstProcId,mBuf);
				break;
			 default:
				RETVALUE(RFAILED);
		  }	  
          break;	  
       default:
          RETVALUE(RFAILED);
    }
    CMCHKPK(SPkS16, param->spId,mBuf);
    CMCHKPK(SPkU8, param->subAction,mBuf);
    CMCHKPK(SPkU8, param->action,mBuf);
    CMCHKPK(cmPkDateTime, &param->dt,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKPK(SPkU8, param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmPkMgCntrl*/

/*
*
*    Fun:    cmPkMgMngmt
*
*    Desc:    pack the structure MgMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkMgMngmt
(
MgMngmt *param,
S16 eventType,
Ent entity,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkMgMngmt(param ,eventType, entity, mBuf)
MgMngmt *param;
S16 eventType;
Ent entity;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkMgMngmt)

    switch( eventType )
    {
       case  EVTLMGCFGREQ :
          ret1 = cmPkMgCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGCNTRLREQ :
          if( entity == ENTSM )
          {
             ret1 = cmPkMgCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
          }
          break;
       case  EVTLMGSTACFM :
          ret1 = cmPkMgSsta(&param->t.ssta, param->hdr.elmId.elmnt , eventType ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTAIND :
          CMCHKPK(cmPkMgUsta, &param->t.usta,mBuf);
          break;
       case  EVTLMGSTAREQ :
          ret1 = cmPkMgSsta(&param->t.ssta, param->hdr.elmId.elmnt , eventType ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTSCFM :
          ret1 = cmPkMgSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTSREQ :
          ret1 = cmPkMgSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGTRCIND :
          CMCHKPK(cmPkMgTrc, &param->t.trc,mBuf);
          break;
       default:
          break;
    }
    if( ( eventType != EVTLMGSTAIND )
      && ( eventType != EVTLMGTRCIND )
      && ( eventType != EVTLMGCFGREQ )
      && ( eventType != EVTLMGSTAREQ )
      && ( eventType != EVTLMGSTSREQ )
      && ( eventType != EVTLMGCNTRLREQ ))
      
    {
       CMCHKPK(cmPkCmStatus, &param->cfm,mBuf);
    }
    CMCHKPK(cmPkHeader, &param->hdr,mBuf);
    RETVALUE(ROK);
} /*end of function cmPkMgMngmt*/

/*
*
*    Fun:    cmPkLmgCfgReq
*
*    Desc:    pack the primitive LmgCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgCfgReq
(
Pst *pst,
MgMngmt *cfg
)
#else
PUBLIC S16 cmPkLmgCfgReq(pst, cfg)
Pst *pst;
MgMngmt *cfg;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgCfgReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG001, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(cfg, EVTLMGCFGREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG002, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGCFGREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  LMGIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgCfgReq*/

/*
*
*    Fun:    cmPkLmgCfgCfm
*
*    Desc:    pack the primitive LmgCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgCfgCfm
(
Pst *pst,
MgMngmt *cfg
)
#else
PUBLIC S16 cmPkLmgCfgCfm(pst, cfg)
Pst *pst;
MgMngmt *cfg;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgCfgCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG003, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(cfg, EVTLMGCFGCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG004, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGCFGCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgCfgCfm*/

/*
*
*    Fun:    cmPkLmgCntrlReq
*
*    Desc:    pack the primitive LmgCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgCntrlReq
(
Pst *pst,
MgMngmt *cntrl
)
#else
PUBLIC S16 cmPkLmgCntrlReq(pst, cntrl)
Pst *pst;
MgMngmt *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgCntrlReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG005, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(cntrl, EVTLMGCNTRLREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG006, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGCNTRLREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  LMGIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgCntrlReq*/

/*
*
*    Fun:    cmPkLmgCntrlCfm
*
*    Desc:    pack the primitive LmgCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgCntrlCfm
(
Pst *pst,
MgMngmt *cntrl
)
#else
PUBLIC S16 cmPkLmgCntrlCfm(pst, cntrl)
Pst *pst;
MgMngmt *cntrl;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgCntrlCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG007, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(cntrl, EVTLMGCNTRLCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG008, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGCNTRLCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgCntrlCfm*/

/*
*
*    Fun:    cmPkLmgStaReq
*
*    Desc:    pack the primitive LmgStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgStaReq
(
Pst *pst,
MgMngmt *sta
)
#else
PUBLIC S16 cmPkLmgStaReq(pst, sta)
Pst *pst;
MgMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgStaReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG009, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(sta, EVTLMGSTAREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG010, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGSTAREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  LMGIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgStaReq*/

/*
*
*    Fun:    cmPkLmgStaInd
*
*    Desc:    pack the primitive LmgStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgStaInd
(
Pst *pst,
MgMngmt *sta
)
#else
PUBLIC S16 cmPkLmgStaInd(pst, sta)
Pst *pst;
MgMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgStaInd)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG011, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(sta, EVTLMGSTAIND , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG012, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGSTAIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgStaInd*/

/*
*
*    Fun:    cmPkLmgStsReq
*
*    Desc:    pack the primitive LmgStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgStsReq
(
Pst *pst,
Action action,
MgMngmt *sts
)
#else
PUBLIC S16 cmPkLmgStsReq(pst, action, sts)
Pst *pst;
Action action;
MgMngmt *sts;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgStsReq)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG013, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(sts, EVTLMGSTSREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG014, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    CMCHKPKLOG(SPkS16, action, mBuf, ELMG015, pst);
    pst->event = (Event) EVTLMGSTSREQ;
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    pst->intfVer =  LMGIFVER;
#endif  /*TDS_ROLL_UPGRADE_SUPPORT */
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgStsReq*/

/*
*
*    Fun:    cmPkLmgStsCfm
*
*    Desc:    pack the primitive LmgStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgStsCfm
(
Pst *pst,
MgMngmt *sts
)
#else
PUBLIC S16 cmPkLmgStsCfm(pst, sts)
Pst *pst;
MgMngmt *sts;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgStsCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG016, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(sts, EVTLMGSTSCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG017, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGSTSCFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgStsCfm*/

/*
*
*    Fun:    cmPkLmgTrcInd
*
*    Desc:    pack the primitive LmgTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgTrcInd
(
Pst *pst,
MgMngmt *trc,
Buffer *mBuf
)
#else
PUBLIC S16 cmPkLmgTrcInd(pst, trc, mBuf)
Pst *pst;
MgMngmt *trc;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmPkLmgTrcInd)

    if(mBuf == NULLP)
    {
       if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
       {
#if (ERRCLASS & ERRCLS_ADD_RES)
          if(ret1 != ROK)
          {
             SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                   __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
                  (ErrVal)ELMG018, (ErrVal)0, "SGetMsg() failed");
          }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
          RETVALUE(ret1);
       }
    }
    ret1 = cmPkMgMngmt(trc, EVTLMGTRCIND , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG019, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGTRCIND;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgTrcInd*/


/*
 *
 * 002.main_1: made rspAckEnb reconfigurable
 *
 *    Fun:    cmUnpkMgGenReCfg
 *
 *    Desc:    unpack the structure mgGenReCfg
 *
 *    Ret:    ROK  -ok
 *
 *    Notes:    None
 *
 *    File:     lmg.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkMgGenReCfg
(
MgGenReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgGenReCfg(param ,mBuf)
MgGenReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgGenReCfg)

    CMCHKUNPK(SUnpkU8, &param->rspAckEnb, mBuf);

    RETVALUE(ROK);
} /*end of function cmUnpkMgGenReCfg*/

/* 003.main_1: Add - Addition for pending limit can be configure by Layer Manager */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
/*
 *    Fun:    cmUnpkPendingLimit
 *
 *    Desc:    pack the structure MgMgcoPendingLimit
 *
 *    Ret:    ROK  -ok
 *
 *    Notes:    None
 *
 *    File:     lmg.c
 *
 */
#ifdef ANSI
PUBLIC S16 cmUnpkPendingLimit
(
MgMgcoPendingLimit *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkPendingLimit(param ,mBuf)
MgMgcoPendingLimit *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkPendingLimit)
    
    CMCHKUNPK(cmUnpkTknPres, &param->pres,mBuf);
    CMCHKUNPK(SUnpkU32, &param->mgOriginatedPendingLimit,mBuf);
    CMCHKUNPK(SUnpkU32, &param->mgcOriginatedPendingLimit,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkPendingLimit */
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */



/*
*
*    Fun:    cmUnpkMgGenCfg
*
*    Desc:    unpack the structure mgGenCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgGenCfg
(
MgGenCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgGenCfg(param ,mBuf)
MgGenCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgGenCfg)

    CMCHKUNPK(SUnpkU16, &param->maxSSaps,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxTSaps,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxServers,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxConn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxTxn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxPeer,mBuf);
    CMCHKUNPK(SUnpkS16, &param->resThUpper,mBuf);
    CMCHKUNPK(SUnpkS16, &param->resThLower,mBuf);
    CMCHKUNPK(cmUnpkPst, &param->lmPst,mBuf);
    CMCHKUNPK(SUnpkU32, &param->timeRes,mBuf);
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->timeResTTL,mBuf);
#endif /*    */
#ifdef GCP_VER_1_3
    /* 002.main_1: made rspAckEnb reconfigurable */
    CMCHKUNPK(cmUnpkMgGenReCfg, &param->reCfg, mBuf);
#endif /*  GCP_VER_1_3  */
    CMCHKUNPK(SUnpkU32, &param->numBlks,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxBlkSize,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numBinsTxnIdHl,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numBinsNameHl,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numBinsTptSrvrHl,mBuf);
    CMCHKUNPK(SUnpkU8, &param->entType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->indicateRetx,mBuf);
    CMCHKUNPK(SUnpkU8, &param->resOrder,mBuf);
#ifdef CM_ABNF_MT_LIB
    CMCHKUNPK(SUnpkU8, &param->noEDInst,mBuf);
    CMCHKUNPK(SUnpkU8, &param->firstInst,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->edEncTmr,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->edDecTmr,mBuf);
#endif /*  CM_ABNF_MT_LIB  */
#if(  defined(GCP_CH)  && defined(GCP_VER_1_5) ) 
    CMCHKUNPK(SUnpkU16, &param->numBinsPeerCmdHl,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numBinsTransReqHl,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numBinsTransIndRspCmdHl,mBuf);
#ifdef GCP_MG
    CMCHKUNPK(cmUnpkTmrCfg, &param->maxMgCmdTimeOut,mBuf);
#endif /*  GCP_MG  */
#ifdef GCP_MGC
    CMCHKUNPK(cmUnpkTmrCfg, &param->maxMgcCmdTimeOut,mBuf);
#endif /*  GCP_MGC  */
#endif /* GCP_CH && GCP_VER_1_5   */
/* 003.main_1: Add - Addition for pending limit can be configure by Layer Manager */
#if (defined(GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))
    CMCHKUNPK(cmUnpkPendingLimit,  &param->limit, mBuf); 
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */    
    
    RETVALUE(ROK);
} /*end of function cmUnpkMgGenCfg*/

/*
*
*    Fun:    cmUnpkMgDnsCfg
*
*    Desc:    unpack the structure mgDnsCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDnsCfg
(
MgDnsCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDnsCfg(param ,mBuf)
MgDnsCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgDnsCfg)

    /* mg001.104  UnPacking only if DNS is enabled */
    /* mg002.104  corrected dnsAccesss parameter */
    CMCHKUNPK(SUnpkU8, &param->dnsAccess,mBuf);
    if (param->dnsAccess != LMG_DNS_DISABLED)
    {
       CMCHKUNPK(cmUnpkCmTptAddr, &param->dnsAddr,mBuf);
       CMCHKUNPK(cmUnpkTmrCfg, &param->dnsRslvTmr,mBuf);
       CMCHKUNPK(SUnpkU16, &param->maxRetxCnt,mBuf);
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
       CMCHKUNPK(SUnpkU32, &param->ttl,mBuf);
#endif /*   defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) )   */
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgDnsCfg*/

/*
*
*    Fun:    cmUnpkMgTSAPReCfg
*
*    Desc:    unpack the structure mgTSAPReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTSAPReCfg
(
MgTSAPReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTSAPReCfg(param ,mBuf)
MgTSAPReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTSAPReCfg)

    CMCHKUNPK(cmUnpkMgDnsCfg, &param->dnsCfg,mBuf);
    CMCHKUNPK(SUnpkU32, &param->tMax,mBuf);
    CMCHKUNPK(cmUnpkCmTptParam, &param->tptParam,mBuf);
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU16, &param->defDisConThold,mBuf);
    CMCHKUNPK(SUnpkU16, &param->defSuspThold,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(cmUnpkTmrCfg, &param->idleTmr,mBuf);
#endif /*    */
#ifdef ZG
    CMCHKUNPK(SUnpkU8, &param->changeOver,mBuf);
    CMCHKUNPK(cmUnpkPst, &param->dstPst,mBuf);
    CMCHKUNPK(SUnpkS16, &param->spId,mBuf);
#endif /*  ZG  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgTSAPReCfg*/
#ifdef GCP_PROV_MTP3

/*
*
*    Fun:    cmUnpkMgMtpNwCfg
*
*    Desc:    unpack the structure mgMtpNwCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMtpNwCfg
(
MgMtpNwCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMtpNwCfg(param ,mBuf)
MgMtpNwCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMtpNwCfg)

    CMCHKUNPK(SUnpkU8, &param->upSwtch,mBuf);
    CMCHKUNPK(SUnpkU8, &param->pcLen,mBuf);
    CMCHKUNPK(SUnpkU8, &param->subService,mBuf);
    CMCHKUNPK(SUnpkU8, &param->sls,mBuf);
    CMCHKUNPK(SUnpkU32, &param->maxBinsMgcoMtpHl,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->defStatusEnqTmr,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->defRstEndTmr,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMtpNwCfg*/
#endif /* GCP_PROV_MTP3 */

/*
*
*    Fun:    cmUnpkMgTSAPCfg
*
*    Desc:    unpack the structure mgTSAPCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTSAPCfg
(
MgTSAPCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTSAPCfg(param ,mBuf)
MgTSAPCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTSAPCfg)

    CMCHKUNPK(SUnpkS16, &param->tSAPId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->spId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->provType,mBuf);
    CMCHKUNPK(cmUnpkMemoryId, &param->memId,mBuf);
    CMCHKUNPK(SUnpkU16, &param->dstProcId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstEnt,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstInst,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstPrior,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstRoute,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dstSel,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->bndTmrCfg,mBuf);
    CMCHKUNPK(cmUnpkMgTSAPReCfg, &param->reCfg,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->remIntfValid,mBuf);
    CMCHKUNPK(SUnpkU16, &param->remIntfVer,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
#ifdef GCP_PROV_SCTP
    CMCHKUNPK(SUnpkU32, &param->numBinsAssocHl,mBuf);
#endif /*  GCP_PROV_SCTP  */
#ifdef GCP_PROV_MTP3
    CMCHKUNPK(cmUnpkMgMtpNwCfg, &param->mgMtpNwCfg,mBuf);
#endif /*  GCP_PROV_MTP3  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgTSAPCfg*/

/*
*
*    Fun:    cmUnpkMgSSAPReCfg
*
*    Desc:    unpack the structure mgSSAPReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSSAPReCfg
(
MgSSAPReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSSAPReCfg(param ,mBuf)
MgSSAPReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSSAPReCfg)

    CMCHKUNPK(cmUnpkTmrCfg, &param->initRetxTmr,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->provRspTmr,mBuf);
    CMCHKUNPK(cmUnpkTmrCfg, &param->atMostOnceTmr,mBuf);
#ifdef GCP_VER_1_3
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
#ifdef GCP_2705BIS
    CMCHKUNPK(cmUnpkTmrCfg, &param->txnTmoutTmr,mBuf);
#endif /*  GCP_2705BIS  */
#endif /*    */
#endif /*  GCP_VER_1_3  */
    CMCHKUNPK(SUnpkU32, &param->provRspDelay,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgSSAPReCfg*/

/*
*
*    Fun:    cmUnpkMgSSAPCfg
*
*    Desc:    unpack the structure mgSSAPCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSSAPCfg
(
MgSSAPCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSSAPCfg(param ,mBuf)
MgSSAPCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSSAPCfg)

    CMCHKUNPK(SUnpkS16, &param->sSAPId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->sel,mBuf);
    CMCHKUNPK(cmUnpkMemoryId, &param->memId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->prior,mBuf);
    CMCHKUNPK(SUnpkU8, &param->route,mBuf);
    CMCHKUNPK(SUnpkU8, &param->protocol,mBuf);
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->userInfo,mBuf);
    CMCHKUNPK(SUnpkU32, &param->startTxnNum,mBuf);
    CMCHKUNPK(SUnpkU32, &param->endTxnNum,mBuf);
#ifdef GCP_MG
    CMCHKUNPK(SUnpkU8, &param->initReg,mBuf);
    CMCHKUNPK(SUnpkU16, &param->mwdTimer,mBuf);
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->mgcpVersion,mBuf);
#endif /*    */
#endif /*  GCP_MG  */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->maxMgcoVersion,mBuf);
    CMCHKUNPK(SUnpkU32, &param->minMgcoVersion,mBuf);
#endif /*    */
    CMCHKUNPK(cmUnpkMgSSAPReCfg, &param->reCfg,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->remIntfValid,mBuf);
    CMCHKUNPK(SUnpkU16, &param->remIntfVer,mBuf);
    CMCHKUNPK(SUnpkU16, &param->dstProcId,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
#if(  defined(  GCP_CH)  && defined(  GCP_VER_1_5) ) 
    CMCHKUNPK(SUnpkU8, &param->chEnabled,mBuf);
#endif /*    */

#ifdef GCP_ALLOW_PROF_CFG
    CMCHKUNPK(cmUnpkMgProf, &param->profile,mBuf);
#endif /*  GCP_ALLOW_PROF_CFG  */
 
#ifdef GCP_ALLOW_LIMIT_CFG
    CMCHKUNPK(cmUnpkTknU8, &param->maxNoOfTxnsPerMsg,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->maxNoOfActnsPerTxn,mBuf);
    CMCHKUNPK(cmUnpkTknU8, &param->maxNoOfCmdsPerActn,mBuf);
#endif /* GCP_ALLOW_LIMIT_CFG  */
 
    RETVALUE(ROK);
} /*end of function cmUnpkMgSSAPCfg*/

/* 004.main_1: Service change profile information */  
#ifdef GCP_ALLOW_PROF_CFG
/*
*
*    Fun:    cmUnpkMgProf
*
*    Desc:    unpack the structure mgProf
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgProf
(
MgProf *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgProf(param ,mBuf)
MgProf *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgProf)

    CMCHKUNPK(SUnpkU8, &param->ver,mBuf);
    CMCHKUNPK(SUnpkU16, &param->len,mBuf);
    for (i=0;i<param->len ;i++)
    {
       CMCHKUNPK(SUnpkU8, &param->profStr[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgProf*/
#endif /* GCP_ALLOW_PROF_CFG */

#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 

/*
*
*    Fun:    cmUnpkMgPeerReCfg
*
*    Desc:    unpack the structure mgPeerReCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerReCfg
(
MgPeerReCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerReCfg(param ,mBuf)
MgPeerReCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPeerReCfg)

    CMCHKUNPK(SUnpkU16, &param->suspThold,mBuf);
    CMCHKUNPK(SUnpkU16, &param->disconThold,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerReCfg*/
#endif /* GCP_MGCP || TDS_ROLL_UPGRADE_SUPPORT */

/*
*
*    Fun:    cmUnpkMgNetAddrTbl
*
*    Desc:    unpack the structure mgNetAddrTbl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgNetAddrTbl
(
MgNetAddrTbl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgNetAddrTbl(param ,mBuf)
MgNetAddrTbl *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgNetAddrTbl)

    CMCHKUNPK(SUnpkU16, &param->count,mBuf);
    for (i=0;i<param->count ;i++)
    {
       CMCHKUNPK(cmUnpkCmNetAddr, &param->netAddr[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgNetAddrTbl*/

/*
*
*    Fun:    cmUnpkMgPeerCfg
*
*    Desc:    unpack the structure mgPeerCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerCfg
(
MgPeerCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerCfg(param ,mBuf)
MgPeerCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgPeerCfg)

    CMCHKUNPK(SUnpkS16, &param->sSAPId,mBuf);
    CMCHKUNPK(cmUnpkMgNetAddrTbl, &param->peerAddrTbl,mBuf);
    for (i=0;i<CM_DNS_DNAME_LEN ;i++)
    {
       CMCHKUNPK(SUnpkU8, &param->name[i], mBuf);
    }
    CMCHKUNPK(SUnpkS32, &param->port,mBuf);
    CMCHKUNPK(SUnpkU16, &param->mtuSize,mBuf);
#ifdef GCP_MG
    CMCHKUNPK(SUnpkU8, &param->transportType,mBuf);
#endif /*  GCP_MG  */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(cmUnpkMgMgcoMidStr, &param->mid,mBuf);
#ifdef GCP_MG
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
    CMCHKUNPK(SUnpkU16, &param->mgcPriority,mBuf);
    CMCHKUNPK(SUnpkU8, &param->useAHScheme,mBuf);
#endif /*  GCP_MG  */
#endif /*    */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->ttl,mBuf);
    CMCHKUNPK(cmUnpkMgPeerReCfg, &param->peerReCfg,mBuf);
#endif /*    */
#ifdef GCP_PROV_SCTP
    CMCHKUNPK(cmUnpkSctStrmId, &param->locOutStrms,mBuf);
    /* lmg_c_001.main_1: TOS support changes */
#ifdef GCP_MG
    CMCHKUNPK(cmUnpkTknU8, &param->tos, mBuf);
#endif /*  GCP_MG  */
#endif /*  GCP_PROV_SCTP  */

#ifdef GCP_MG
    CMCHKUNPK(SUnpkS16, &param->tsapId,mBuf);
#endif /*  GCP_MG  */
#ifdef GCP_PROV_MTP3
    CMCHKUNPK(SUnpkU32, &param->peerDpc,mBuf);
#endif /*  GCP_PROV_MTP3  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerCfg*/

/*
*
*    Fun:    cmUnpkMgGcpEntCfg
*
*    Desc:    unpack the structure mgGcpEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgGcpEntCfg
(
MgGcpEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgGcpEntCfg(param ,mBuf)
MgGcpEntCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgGcpEntCfg)

    CMCHKUNPK(SUnpkU16, &param->numPeer,mBuf);
    for (i=0;i<param->numPeer ;i++)
    {
       CMCHKUNPK(cmUnpkMgPeerCfg, &param->peerCfg[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgGcpEntCfg*/
#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MGC

/*
*
*    Fun:    cmUnpkMgMtdGcpEntCfg
*
*    Desc:    unpack the structure mgMtdGcpEntCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMtdGcpEntCfg
(
MgMtdGcpEntCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMtdGcpEntCfg(param ,mBuf)
MgMtdGcpEntCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgMtdGcpEntCfg)

    CMCHKUNPK(cmUnpkMgPeerCfg, &param->actPeerCfg,mBuf);
    CMCHKUNPK(cmUnpkMgPeerCfg, &param->stdPeerCfg,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgMtdGcpEntCfg*/
#endif /* GCP_MGC */
#endif /* GCP_MGCO */
#endif /* ZG */
#ifdef GCP_PROV_SCTP

/*
*
*    Fun:    cmUnpkMgEndpCfg
*
*    Desc:    unpack the structure mgEndpCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEndpCfg
(
MgEndpCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEndpCfg(param ,mBuf)
MgEndpCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgEndpCfg)

#ifdef GCP_MG
    CMCHKUNPK(SUnpkS16, &param->sSAPId,mBuf);
    /* lmg_c_001.main_1: TOS support changes */
    CMCHKUNPK(cmUnpkTknU8, &param->defaultTos, mBuf);
#endif /*  GCP_MG  */
    CMCHKUNPK(SUnpkS16, &param->tSAPId,mBuf);
    CMCHKUNPK(cmUnpkSctPort, &param->sctPort,mBuf);
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgEndpCfg*/

/*
*
*    Fun:    cmUnpkMgEndpLstCfg
*
*    Desc:    unpack the structure mgEndpLstCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgEndpLstCfg
(
MgEndpLstCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgEndpLstCfg(param ,mBuf)
MgEndpLstCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;

    TRC3(cmUnpkMgEndpLstCfg)

    CMCHKUNPK(SUnpkU32, &param->count,mBuf);

    for (i=param->count -1;i>=0;i--)
    {
       CMCHKUNPK(cmUnpkMgEndpCfg, (MgEndpCfg *)&param->endp[i],mBuf);
    }

    RETVALUE(ROK);
} /*end of function cmUnpkMgEndpLstCfg*/

/*
*
*    Fun:    cmUnpkMgAssocCfg
*
*    Desc:    unpack the structure mgAssocCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAssocCfg
(
MgAssocCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAssocCfg(param ,mBuf)
MgAssocCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgAssocCfg)

    CMCHKUNPK(cmUnpkSctStrmId, &param->locOutStrms,mBuf);
    CMCHKUNPK(cmUnpkCmNetAddr, &param->priDstAddr,mBuf);
    CMCHKUNPK(cmUnpkSctNetAddrLst, &param->dstAddrLst,mBuf);
    CMCHKUNPK(cmUnpkSctNetAddrLst, &param->srcAddrLst,mBuf);
    CMCHKUNPK(cmUnpkSctPort, &param->remPort,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgAssocCfg*/
#endif /* GCP_PROV_SCTP */

/*
*
*    Fun:    cmUnpkMgSrvrCfg
*
*    Desc:    unpack the structure mgSrvrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSrvrCfg
(
MgSrvrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSrvrCfg(param ,mBuf)
MgSrvrCfg *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSrvrCfg)

    CMCHKUNPK(SUnpkU8, &param->isDefault,mBuf);
    CMCHKUNPK(SUnpkS16, &param->sSAPId,mBuf);
    CMCHKUNPK(SUnpkS16, &param->tSAPId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->protocol,mBuf);
    CMCHKUNPK(SUnpkU8, &param->transportType,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
#endif /*    */
    CMCHKUNPK(cmUnpkCmTptParam, &param->tptParam,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->lclTptAddr,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgSrvrCfg*/

/*
*
*    Fun:    cmUnpkMgTptSrvrCfg
*
*    Desc:    unpack the structure mgTptSrvrCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTptSrvrCfg
(
MgTptSrvrCfg *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTptSrvrCfg(param ,mBuf)
MgTptSrvrCfg *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgTptSrvrCfg)

    CMCHKUNPK(SUnpkU16, &param->count,mBuf);
    for (i=0;i<param->count ;i++)
    {
       CMCHKUNPK(cmUnpkMgSrvrCfg, &param->srvr[i], mBuf);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgTptSrvrCfg*/

/*
*
*    Fun:    cmUnpkMgCfg
*
*    Desc:    unpack the structure MgCfg
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgCfg
(
MgCfg *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgCfg(param ,elmnt, mBuf)
MgCfg *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgCfg)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKUNPK(cmUnpkMgGcpEntCfg, &param->c.mgGcpEntCfg,mBuf);
          break;
       case  STGEN :
          CMCHKUNPK(cmUnpkMgGenCfg, &param->c.genCfg,mBuf);
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          CMCHKUNPK(cmUnpkMgEndpLstCfg, &param->c.endpCfg,mBuf);
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          CMCHKUNPK(cmUnpkMgTptSrvrCfg, &param->c.tptSrvrCfg,mBuf);
          break;
       case  STSSAP :
          CMCHKUNPK(cmUnpkMgSSAPCfg, &param->c.sSAPCfg,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkMgTSAPCfg, &param->c.tSAPCfg,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgCfg*/

/*
*
*    Fun:    cmUnpkMgDnsSts
*
*    Desc:    unpack the structure mgDnsSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDnsSts
(
MgDnsSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDnsSts(param ,mBuf)
MgDnsSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgDnsSts)

    CMCHKUNPK(SUnpkU32, &param->numAQueryTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numAQueryFailed,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgDnsSts*/

/*
*
*    Fun:    cmUnpkMgTSAPSts
*
*    Desc:    unpack the structure mgTSAPSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTSAPSts
(
MgTSAPSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTSAPSts(param ,mBuf)
MgTSAPSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTSAPSts)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(cmUnpkMgDnsSts, &param->dnsSts,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTSAPSts*/

/*
*
*    Fun:    cmUnpkMgPeerSts
*
*    Desc:    unpack the structure mgPeerSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerSts
(
MgPeerSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerSts(param ,mBuf)
MgPeerSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPeerSts)

    CMCHKUNPK(SUnpkS16, &param->sSAPId,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numMsgTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numMsgRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRespTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRespRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRespFailedRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numErrors,mBuf);
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
#ifdef GCP_VER_1_3
#ifdef GCP_2705BIS
    CMCHKUNPK(SUnpkU32, &param->numRspAckRspTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRspAckRspRx,mBuf);
#endif /*  GCP_2705BIS  */
#endif /*  GCP_VER_1_3  */
#endif /*    */
#if(  defined(  GCP_MGCP)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->numNonStdTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numNonStdRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numEpcfTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numCreateTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numModifyTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numDeleteTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRqntTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numNotifyTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numAuditEndPtTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numAuditConnTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRsipTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numEpcfRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numCreateRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numModifyRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numDeleteRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRqntRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numNotifyRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numAuditEndPtRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numAuditConnRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRsipRx,mBuf);
#endif /*    */
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU32, &param->numTransTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numServiceChgTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRespAckTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numTransPendTx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numTransRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numServiceChgRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numRespAckRx,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numTransPendRx,mBuf);
    
    /* lmg_c_005.main_1: Added error code counter */
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoBadReq,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoProtErr,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoVerUnSupp,mBuf);
#if (defined(MGT_UNKNOWN_PKG_REJ) && defined(GCP_ASN))    
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoPkgUnsupp,mBuf);
#endif /* MGT_UNKNOWN_PKG_REJ && GCP_ASN */    
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoNotReady,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoReqRcvdBefReg,mBuf);
#if (defined (GCP_VER_1_5) && defined (GCP_PKG_MGCO_ROOT))    
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoTxnPendEx,mBuf);
#endif /* GCP_VER_1_5 GCP_PKG_MGCO_ROOT */    
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoRsrcErr,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numErrorsMgcoPduSize,mBuf);

#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerSts*/

/*
*
*    Fun:    cmUnpkMgPeerEntSts
*
*    Desc:    unpack the structure mgPeerEntSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerEntSts
(
MgPeerEntSts *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerEntSts(param ,mBuf)
MgPeerEntSts *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPeerEntSts)

    CMCHKUNPK(SUnpkS16, &param->sapId,mBuf);
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKUNPK(cmUnpkMgPeerSts, &param->peerSts,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerEntSts*/

/*
*
*    Fun:    cmUnpkMgSts
*
*    Desc:    unpack the structure MgSts
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSts
(
MgSts *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSts(param ,elmnt, mBuf)
MgSts *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSts)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKUNPK(cmUnpkMgPeerEntSts, &param->s.mgPeerEntSts,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkMgTSAPSts, &param->s.mgTSAPSts,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSts*/

/*
*
*    Fun:    cmUnpkMgTSAPSta
*
*    Desc:    unpack the structure mgTSAPSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTSAPSta
(
MgTSAPSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTSAPSta(param ,mBuf)
MgTSAPSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTSAPSta)

    CMCHKUNPK(SUnpkS16, &param->tSapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->resCong,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numServers,mBuf);
    CMCHKUNPK(SUnpkU8, &param->state,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->remIntfValid,mBuf);
    CMCHKUNPK(SUnpkU16, &param->selfIntfVer,mBuf);
    CMCHKUNPK(SUnpkU16, &param->remIntfVer,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgTSAPSta*/

/*
*
*    Fun:    cmUnpkMgSSAPSta
*
*    Desc:    unpack the structure mgSSAPSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSSAPSta
(
MgSSAPSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSSAPSta(param ,mBuf)
MgSSAPSta *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgSSAPSta)

    CMCHKUNPK(SUnpkS16, &param->sapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->state,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numAssocPeer,mBuf);
    CMCHKUNPK(SUnpkU8, &param->more,mBuf);
    for (i=0;i<param->numAssocPeer ;i++)
    {
       CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo[i], mBuf);
    }
    CMCHKUNPK(SUnpkU16, &param->numServers,mBuf);
    CMCHKUNPK(SUnpkU16, &param->numTCPlosses,mBuf);
#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->remIntfValid,mBuf);
    CMCHKUNPK(SUnpkU16, &param->selfIntfVer,mBuf);
    CMCHKUNPK(SUnpkU16, &param->remIntfVer,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgSSAPSta*/

/*
*
*    Fun:    cmUnpkMgPeerSta
*
*    Desc:    unpack the structure mgPeerSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerSta
(
MgPeerSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerSta(param ,mBuf)
MgPeerSta *param;
Buffer *mBuf;
#endif
{
    Cntr i;
    TRC3(cmUnpkMgPeerSta)

#ifdef GCP_USE_PEERID
    CMCHKUNPK(cmUnpkTknU32, &param->peerId,mBuf);
#endif /*  GCP_USE_PEERID  */
    CMCHKUNPK(cmUnpkTknPres, &param->namePres,mBuf);
    if( param->namePres.pres == PRSNT_NODEF )
    {
       for (i=0;i<CM_DNS_DNAME_LEN ;i++)
       {
          CMCHKUNPK(SUnpkU8, &param->name[i], mBuf);
       }
    }
    CMCHKUNPK(cmUnpkMgNetAddrTbl, &param->peerAddrTbl,mBuf);
    CMCHKUNPK(cmUnpkTknS32, &param->port,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(cmUnpkMgMgcoMidStr, &param->mid,mBuf);
#endif /*    */
    CMCHKUNPK(SUnpkU8, &param->peerState,mBuf);
    CMCHKUNPK(SUnpkS16, &param->sSapId,mBuf);
    CMCHKUNPK(SUnpkU8, &param->protocol,mBuf);
    CMCHKUNPK(SUnpkU8, &param->transportType,mBuf);
    CMCHKUNPK(SUnpkU32, &param->version,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numPendOgTxn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->numPendIcTxn,mBuf);
    CMCHKUNPK(SUnpkU32, &param->rttEstimate,mBuf);
#if(  defined(  GCP_MGCO)  || defined(  TDS_ROLL_UPGRADE_SUPPORT) ) 
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
#ifdef   GCP_PROV_MTP3
    CMCHKUNPK(cmUnpkTknU32, &param->peerDpc,mBuf);
    CMCHKUNPK(SUnpkU8, &param->dpcStatus,mBuf);

#endif   /* GCP_PROV_MTP3 */    
#endif /*    */
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerSta*/

/*
*
*    Fun:    cmUnpkMgTptSrvSta
*
*    Desc:    unpack the structure mgTptSrvSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTptSrvSta
(
MgTptSrvSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTptSrvSta(param ,mBuf)
MgTptSrvSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTptSrvSta)

    CMCHKUNPK(SUnpkU8, &param->transportType,mBuf);
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->tptAddr,mBuf);
    CMCHKUNPK(SUnpkU8, &param->state,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTptSrvSta*/
#ifdef GCP_PROV_SCTP

/*
*
*    Fun:    cmUnpkMgSctpEpSta
*
*    Desc:    unpack the structure mgSctpEpSta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSctpEpSta
(
MgSctpEpSta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSctpEpSta(param ,mBuf)
MgSctpEpSta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSctpEpSta)

    CMCHKUNPK(cmUnpkSctPort, &param->port,mBuf);
    CMCHKUNPK(SUnpkU8, &param->encodingScheme,mBuf);
    CMCHKUNPK(SUnpkU8, &param->state,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgSctpEpSta*/
#endif /* GCP_PROV_SCTP */

/*
*
*    Fun:    cmUnpkMgSsta
*
*    Desc:    unpack the structure MgSsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgSsta
(
MgSsta *param,
Elmnt elmnt,
S16 eventType,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgSsta(param ,elmnt, eventType, mBuf)
MgSsta *param;
Elmnt elmnt;
S16 eventType;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgSsta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    switch( elmnt )
    {
       case  STGCPENT :
          CMCHKUNPK(cmUnpkMgPeerSta, &param->s.mgPeerSta,mBuf);
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          CMCHKUNPK(cmUnpkMgSctpEpSta, &param->s.mgSctpEpSta,mBuf);
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          CMCHKUNPK(cmUnpkMgTptSrvSta, &param->s.mgTptSrvSta,mBuf);
          break;
       case  STSID :
          if( eventType == EVTLMGSTACFM )
          {
             CMCHKUNPK(cmUnpkSystemId, &param->s.systemId,mBuf);
          }
          break;
       case  STSSAP :
          CMCHKUNPK(cmUnpkMgSSAPSta, &param->s.mgSSAPSta,mBuf);
          break;
       case  STTSAP :
          CMCHKUNPK(cmUnpkMgTSAPSta, &param->s.mgTSAPSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgSsta*/

/*
*
*    Fun:    cmUnpkMgAddrInfo
*
*    Desc:    unpack the structure mgAddrInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAddrInfo
(
MgAddrInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAddrInfo(param ,mBuf)
MgAddrInfo *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgAddrInfo)

    CMCHKUNPK(cmUnpkMgDName, &param->addr,mBuf);
    CMCHKUNPK(cmUnpkTknS32, &param->port,mBuf);
#ifdef GCP_PROV_MTP3
    CMCHKUNPK(cmUnpkTknU32, &param->peerDpc,mBuf);
#endif /*  GCP_PROV_MTP3  */
    RETVALUE(ROK);
} /*end of function cmUnpkMgAddrInfo*/

/*
*
*    Fun:    cmUnpkMgPeerCntrl
*
*    Desc:    unpack the structure MgPeerCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgPeerCntrl
(
MgPeerCntrl *param,
U8 action,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgPeerCntrl(param ,action, mBuf)
MgPeerCntrl *param;
U8 action;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgPeerCntrl)

    CMCHKUNPK(cmUnpkMgPeerInfo, &param->activePeer,mBuf);
    switch( action )
    {
       case  AHANDOFF :
          CMCHKUNPK(cmUnpkMgAddrInfo, &param->u.handoffMgc,mBuf);
          break;
       case  AMATEDCFG_ADD :
          CMCHKUNPK(cmUnpkMgPeerInfo, &param->u.standbyPeer,mBuf);
          break;
       case  AMATEDCFG_RMV :
          CMCHKUNPK(cmUnpkMgPeerInfo, &param->u.standbyPeer,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgPeerCntrl*/

/*
*
*    Fun:    cmUnpkMgParId
*
*    Desc:    unpack the structure mgParId
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgParId
(
MgParId *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgParId(param ,mBuf)
MgParId *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgParId)

    CMCHKUNPK(SUnpkU8, &param->parType,mBuf);
    CMCHKUNPK(SUnpkS16, &param->sapId,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgParId*/

/*
*
*    Fun:    cmUnpkMgAlarmInfo
*
*    Desc:    unpack the structure mgAlarmInfo
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgAlarmInfo
(
MgAlarmInfo *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgAlarmInfo(param ,mBuf)
MgAlarmInfo *param;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgAlarmInfo)

    CMCHKUNPK(SUnpkU8, &param->type,mBuf);
#ifdef GCP_VER_1_3
    CMCHKUNPK(SUnpkS16, &param->sapId,mBuf);
#endif /*  GCP_VER_1_3  */
    switch( param->type )
    {
       case  LMG_ALARMINFO_MATED_PEER :
          ret1 = cmUnpkMgPeerCntrl(&param->u.matedPairInfo, AMATEDCFG_ADD ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  LMG_ALARMINFO_MEM :
          CMCHKUNPK(cmUnpkMemoryId, &param->u.mem,mBuf);
          break;
       case  LMG_ALARMINFO_NONE :
          break;
       case  LMG_ALARMINFO_PAR :
          CMCHKUNPK(cmUnpkMgParId, &param->u.parId,mBuf);
          break;
       case  LMG_ALARMINFO_PEER :
          CMCHKUNPK(cmUnpkMgPeerInfo, &param->u.peerInfo,mBuf);
          break;
       case  LMG_ALARMINFO_PEER_STA :
          CMCHKUNPK(cmUnpkMgPeerSta, &param->u.peerSta,mBuf);
          break;
       case  LMG_ALARMINFO_SAP :
          CMCHKUNPK(SUnpkS16, &param->u.sapId,mBuf);
          break;
       case  LMG_ALARMINFO_SRVR :
          CMCHKUNPK(cmUnpkMgTptSrvSta, &param->u.srvSta,mBuf);
          break;
       case  LMG_ALARMINFO_SSAP_STA :
          CMCHKUNPK(cmUnpkMgSSAPSta, &param->u.ssapSta,mBuf);
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgAlarmInfo*/

/*
*
*    Fun:    cmUnpkMgUsta
*
*    Desc:    unpack the structure mgUsta
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgUsta
(
MgUsta *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgUsta(param ,mBuf)
MgUsta *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgUsta)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkCmAlarm, &param->alarm,mBuf);
    CMCHKUNPK(cmUnpkMgAlarmInfo, &param->alarmInfo,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgUsta*/

/*
*
*    Fun:    cmUnpkMgTrc
*
*    Desc:    unpack the structure mgTrc
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTrc
(
MgTrc *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTrc(param ,mBuf)
MgTrc *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTrc)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    CMCHKUNPK(SUnpkS16, &param->sapId,mBuf);
    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKUNPK(SUnpkU16, &param->evnt,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTrc*/

/*
*
*    Fun:    cmUnpkMgTptCntrl
*
*    Desc:    unpack the structure mgTptCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTptCntrl
(
MgTptCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTptCntrl(param ,mBuf)
MgTptCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTptCntrl)

    CMCHKUNPK(SUnpkU8, &param->transportType,mBuf);
    CMCHKUNPK(cmUnpkCmTptAddr, &param->serverAddr,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTptCntrl*/

/*
*
*    Fun:    cmUnpkMgTrcCntrl
*
*    Desc:    unpack the structure mgTrcCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgTrcCntrl
(
MgTrcCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgTrcCntrl(param ,mBuf)
MgTrcCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgTrcCntrl)

    CMCHKUNPK(cmUnpkMgPeerInfo, &param->peerInfo,mBuf);
    CMCHKUNPK(SUnpkS16, &param->trcLen,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgTrcCntrl*/

/*
*
*    Fun:    cmUnpkMgDbgCntrl
*
*    Desc:    unpack the structure mgDbgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgDbgCntrl
(
MgDbgCntrl *param,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgDbgCntrl(param ,mBuf)
MgDbgCntrl *param;
Buffer *mBuf;
#endif
{
    TRC3(cmUnpkMgDbgCntrl)

    CMCHKUNPK(SUnpkU32, &param->genDbgMask,mBuf);
    RETVALUE(ROK);
} /*end of function cmUnpkMgDbgCntrl*/

/*
*
*    Fun:    cmUnpkMgCntrl
*
*    Desc:    unpack the structure MgCntrl
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgCntrl
(
MgCntrl *param,
Elmnt elmnt,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgCntrl(param ,elmnt, mBuf)
MgCntrl *param;
Elmnt elmnt;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgCntrl)

#ifdef TDS_ROLL_UPGRADE_SUPPORT
    CMCHKUNPK(SUnpkU8, &param->bitVector,mBuf);
#endif /*  TDS_ROLL_UPGRADE_SUPPORT  */
    CMCHKUNPK(cmUnpkDateTime, &param->dt,mBuf);
    CMCHKUNPK(SUnpkU8, &param->action,mBuf);
    CMCHKUNPK(SUnpkU8, &param->subAction,mBuf);
    CMCHKUNPK(SUnpkS16, &param->spId,mBuf);
    switch( elmnt )
    {
       case  STGCPENT :
          switch( param->subAction )
          {
             case  SATRC :
                CMCHKUNPK(cmUnpkMgTrcCntrl, &param->s.trcCntrl,mBuf);
                break;
             default:
                CMCHKUNPK(cmUnpkMgPeerInfo, &param->s.peerInfo,mBuf);
                break;
          }
          break;
       case  STGCPENTCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
                CMCHKUNPK(cmUnpkMgGcpEntCfg, &param->s.mgGcpEntCfg,mBuf);
#endif /*  ZG  */
                break;
          }
          break;
       case  STGCPMG :
          switch( param->subAction )
          {
             default:
                break;
          }
          break;
       case  STGCPMGC :
          switch( param->subAction )
          {
             case  SAELMNT :
                ret1 = cmUnpkMgPeerCntrl(&param->s.peerCntrlInfo, param->action ,mBuf);
                if (ret1 != ROK)
                {
                   RETVALUE(RFAILED);
                }
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STGCPSRVRCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
                CMCHKUNPK(cmUnpkMgTptSrvrCfg, &param->s.tptSrvrCfg,mBuf);
#endif /*  ZG  */
                break;
          }
          break;
       case  STGEN :
          switch( param->subAction )
          {
             case  SADBG :
                CMCHKUNPK(cmUnpkMgDbgCntrl, &param->s.dbg,mBuf);
                break;
             case  SAELMNT :
                break;
             case  SATRC :
                CMCHKUNPK(cmUnpkMgTrcCntrl, &param->s.trcCntrl,mBuf);
                break;
             case  SAUSTA :
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STGRSSAP :
          switch( param->subAction )
          {
             default:
                switch( param->subAction )
                {
                   case  SAGR_DSTPROCID :
                      CMCHKUNPK(SUnpkU16, &param->s.par.dstProcId,mBuf);
                      break;
                   case  SAGR_PRIORITY :
                      CMCHKUNPK(SUnpkU8, &param->s.par.priority,mBuf);
                      break;
                   case  SAGR_ROUTE :
                      CMCHKUNPK(SUnpkU8, &param->s.par.route,mBuf);
                      break;
                   default:
                      RETVALUE(RFAILED);
                }
                break;
          }
          break;
       case  STMTDGCPENTCFG :
          switch( param->subAction )
          {
             default:
#ifdef ZG
#ifdef GCP_MGCO
#ifdef GCP_MGC
                CMCHKUNPK(cmUnpkMgMtdGcpEntCfg, &param->s.mtdGcpEntCfg,mBuf);
#endif /*  GCP_MGC  */
#endif /*  GCP_MGCO  */
#endif /*  ZG  */
                break;
          }
          break;
#ifdef GCP_PROV_SCTP
       case  STSCTPENDP :
          switch( param->subAction )
          {
             default:
                CMCHKUNPK(cmUnpkMgEndpCntrl, &param->s.endpCntrl,mBuf);
                break;
          }
          break;
#endif /*  GCP_PROV_SCTP  */
       case  STSERVER :
          switch( param->subAction )
          {
             case  SAELMNT :
                CMCHKUNPK(cmUnpkMgTptCntrl, &param->s.tptCntrl,mBuf);
                break;
             default:
                RETVALUE(RFAILED);
          }
          break;
       case  STSSAP :
          switch( param->subAction )
          {
             default:
                break;
          }
          break;
       case  STTSAP :
          switch( param->subAction )
          {
             case SATRC:		/* add by cdw on 2006-9-28 */
					CMCHKPK(cmPkMgTrcCntrl, &param->s.trcCntrl,mBuf);		
             default:
                break;
          }
		  break;
	   case  STGRTSAP :   /* add by cdw on 2006-9-28 */
		  switch ( param->subAction )
		  {
			 case  SAGR_DSTPROCID :
				CMCHKPK(cmPkProcId, param->s.par.dstProcId,mBuf);
				break;
			 default:
				RETVALUE(RFAILED);
		  }	  
          break;
       default:
          RETVALUE(RFAILED);
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgCntrl*/

/*
*
*    Fun:    cmUnpkMgMngmt
*
*    Desc:    unpack the structure MgMngmt
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkMgMngmt
(
MgMngmt *param,
S16 eventType,
Ent entity,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkMgMngmt(param ,eventType, entity, mBuf)
MgMngmt *param;
S16 eventType;
Ent entity;
Buffer *mBuf;
#endif
{
    S16 ret1;
    TRC3(cmUnpkMgMngmt)

    CMCHKUNPK(cmUnpkHeader, &param->hdr,mBuf);
    if( ( eventType != EVTLMGSTAIND )
      && ( eventType != EVTLMGTRCIND )
      && ( eventType != EVTLMGCFGREQ )
      && ( eventType != EVTLMGSTAREQ )
      && ( eventType != EVTLMGSTSREQ )
      && ( eventType != EVTLMGCNTRLREQ ))
      
      
      
    {
       CMCHKUNPK(cmUnpkCmStatus, &param->cfm,mBuf);
    }
    switch( eventType )
    {
       case  EVTLMGCFGREQ :
          ret1 = cmUnpkMgCfg(&param->t.cfg, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGCNTRLREQ :
          if( entity == ENTSM )
          {
             ret1 = cmUnpkMgCntrl(&param->t.cntrl, param->hdr.elmId.elmnt ,mBuf);
             if (ret1 != ROK)
             {
                RETVALUE(RFAILED);
             }
          }
          break;
       case  EVTLMGSTACFM :
          ret1 = cmUnpkMgSsta(&param->t.ssta, param->hdr.elmId.elmnt , eventType ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTAIND :
          CMCHKUNPK(cmUnpkMgUsta, &param->t.usta,mBuf);
          break;
       case  EVTLMGSTAREQ :
          ret1 = cmUnpkMgSsta(&param->t.ssta, param->hdr.elmId.elmnt , eventType ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTSCFM :
          ret1 = cmUnpkMgSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGSTSREQ :
          ret1 = cmUnpkMgSts(&param->t.sts, param->hdr.elmId.elmnt ,mBuf);
          if (ret1 != ROK)
          {
             RETVALUE(RFAILED);
          }
          break;
       case  EVTLMGTRCIND :
          CMCHKUNPK(cmUnpkMgTrc, &param->t.trc,mBuf);
          break;
       default:
          break;
    }
    RETVALUE(ROK);
} /*end of function cmUnpkMgMngmt*/

/*
*
*    Fun:    cmUnpkLmgCfgReq
*
*    Desc:    unpack the primitive LmgCfgReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgCfgReq
(
LmgCfgReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgCfgReq(func, pst, mBuf)
LmgCfgReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt cfg;
    
    TRC3(cmUnpkLmgCfgReq)

    ret1 = cmUnpkMgMngmt(&cfg, EVTLMGCFGREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG020, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cfg));
} /*end of function cmUnpkLmgCfgReq*/

/*
*
*    Fun:    cmUnpkLmgCfgCfm
*
*    Desc:    unpack the primitive LmgCfgCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgCfgCfm
(
LmgCfgCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgCfgCfm(func, pst, mBuf)
LmgCfgCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt cfg;
    
    TRC3(cmUnpkLmgCfgCfm)

    ret1 = cmUnpkMgMngmt(&cfg, EVTLMGCFGCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG021, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cfg));
} /*end of function cmUnpkLmgCfgCfm*/

/*
*
*    Fun:    cmUnpkLmgCntrlReq
*
*    Desc:    unpack the primitive LmgCntrlReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgCntrlReq
(
LmgCntrlReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgCntrlReq(func, pst, mBuf)
LmgCntrlReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt cntrl;
    
    TRC3(cmUnpkLmgCntrlReq)

    ret1 = cmUnpkMgMngmt(&cntrl, EVTLMGCNTRLREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG022, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cntrl));
} /*end of function cmUnpkLmgCntrlReq*/

/*
*
*    Fun:    cmUnpkLmgCntrlCfm
*
*    Desc:    unpack the primitive LmgCntrlCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgCntrlCfm
(
LmgCntrlCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgCntrlCfm(func, pst, mBuf)
LmgCntrlCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt cntrl;
    
    TRC3(cmUnpkLmgCntrlCfm)

    ret1 = cmUnpkMgMngmt(&cntrl, EVTLMGCNTRLCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG023, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &cntrl));
} /*end of function cmUnpkLmgCntrlCfm*/

/*
*
*    Fun:    cmUnpkLmgStaReq
*
*    Desc:    unpack the primitive LmgStaReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgStaReq
(
LmgStaReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgStaReq(func, pst, mBuf)
LmgStaReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt sta;
    
    TRC3(cmUnpkLmgStaReq)

	cmMemset((U8 *)&sta,0,sizeof(MgMngmt));		/* add by cdw on 2006-9-26 */
    ret1 = cmUnpkMgMngmt(&sta, EVTLMGSTAREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG024, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLmgStaReq*/

/*
*
*    Fun:    cmUnpkLmgStaInd
*
*    Desc:    unpack the primitive LmgStaInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgStaInd
(
LmgStaInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgStaInd(func, pst, mBuf)
LmgStaInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt sta;
    
    TRC3(cmUnpkLmgStaInd)
		
	cmMemset((U8 *)&sta,0,sizeof(MgMngmt));		/* add by cdw on 2006-9-26 */
    ret1 = cmUnpkMgMngmt(&sta, EVTLMGSTAIND , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG025, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLmgStaInd*/

/*
*
*    Fun:    cmUnpkLmgStsReq
*
*    Desc:    unpack the primitive LmgStsReq
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgStsReq
(
LmgStsReq func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgStsReq(func, pst, mBuf)
LmgStsReq func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    Action action;
    MgMngmt sts;
    
    TRC3(cmUnpkLmgStsReq)

    CMCHKUNPKLOG(SUnpkS16, &action, mBuf, ELMG026, pst);
    ret1 = cmUnpkMgMngmt(&sts, EVTLMGSTSREQ , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG027, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, action, &sts));
} /*end of function cmUnpkLmgStsReq*/

/*
*
*    Fun:    cmUnpkLmgStsCfm
*
*    Desc:    unpack the primitive LmgStsCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgStsCfm
(
LmgStsCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgStsCfm(func, pst, mBuf)
LmgStsCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt sts;
    
    TRC3(cmUnpkLmgStsCfm)

    ret1 = cmUnpkMgMngmt(&sts, EVTLMGSTSCFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG028, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sts));
} /*end of function cmUnpkLmgStsCfm*/

/*
*
*    Fun:    cmUnpkLmgTrcInd
*
*    Desc:    unpack the primitive LmgTrcInd
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgTrcInd
(
LmgTrcInd func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgTrcInd(func, pst, mBuf)
LmgTrcInd func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt trc;
    
    TRC3(cmUnpkLmgTrcInd)

    ret1 = cmUnpkMgMngmt(&trc, EVTLMGTRCIND , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG029, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    RETVALUE((*func)(pst, &trc, mBuf));
} /*end of function cmUnpkLmgTrcInd*/
/*
*
*    Fun:    cmPkLmgStaCfm
*
*    Desc:    pack the primitive LmgStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmPkLmgStaCfm
(
Pst *pst,
MgMngmt *sta
)
#else
PUBLIC S16 cmPkLmgStaCfm(pst, sta)
Pst *pst;
MgMngmt *sta;
#endif
{
    S16 ret1;
    Buffer *mBuf;
    mBuf = NULLP;
    TRC3(cmPkLmgStaCfm)

    if((ret1 = SGetMsg(pst->region, pst->pool, &mBuf)) != ROK)
    {
#if (ERRCLASS & ERRCLS_ADD_RES)
       if(ret1 != ROK)
       {
          SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
                __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
               (ErrVal)ELMG030, (ErrVal)0, "SGetMsg() failed");
       }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
       RETVALUE(ret1);
    }
    ret1 = cmPkMgMngmt(sta, EVTLMGSTACFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_ADD_RES)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->srcEnt, pst->srcInst, pst->srcProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_ADD_RES,
            (ErrVal)ELMG031, (ErrVal)ret1, "Packing failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_ADD_RES  */
    pst->event = (Event) EVTLMGSTACFM;
    RETVALUE(SPstTsk(pst,mBuf));
} /*end of function cmPkLmgStaCfm*/


/*
*
*    Fun:    cmUnpkLmgStaCfm
*
*    Desc:    unpack the primitive LmgStaCfm
*
*    Ret:    ROK  -ok
*
*    Notes:    None
*
*    File:     lmg.c
*
*/
#ifdef ANSI
PUBLIC S16 cmUnpkLmgStaCfm
(
LmgStaCfm func,
Pst *pst,
Buffer *mBuf
)
#else
PUBLIC S16 cmUnpkLmgStaCfm(func, pst, mBuf)
LmgStaCfm func;
Pst *pst;
Buffer *mBuf;
#endif
{
    S16 ret1;
    MgMngmt sta;
    Txt     ptNmb[32];
    
    TRC3(cmUnpkLmgStaCfm)
		
	cmMemset((U8 *)&sta,0,sizeof(MgMngmt));		/* add by cdw on 2006-9-26 */
    sta.t.ssta.s.systemId.ptNmb = ptNmb;
    ret1 = cmUnpkMgMngmt(&sta, EVTLMGSTACFM , pst->srcEnt ,mBuf);
#if(ERRCLASS & ERRCLS_DEBUG)
    if(ret1 != ROK)
    {
       SPutMsg(mBuf);
       SLogError(pst->dstEnt, pst->dstInst, pst->dstProcId,
             __FILE__, __LINE__, (ErrCls)ERRCLS_DEBUG,
            (ErrVal)ELMG032, (ErrVal)ret1, "Unpacking failure");
       RETVALUE( ret1 );
    }
#endif /*  ERRCLASS & ERRCLS_DEBUG   */
    SPutMsg(mBuf);
    RETVALUE((*func)(pst, &sta));
} /*end of function cmUnpkLmgStaCfm*/


#endif /* #ifdef LCLMG */

/********************************************************************30**
 
         End of file:     lmg.c@@/main/mgcp_rel_1.5_mnt/2 - Tue May 31 11:42:09 2005
 
*********************************************************************31*/
/********************************************************************40**
 
        Notes:
 
*********************************************************************41*/
/********************************************************************50**
 
*********************************************************************51*/

/********************************************************************60**
 
        Revision history:
 
*********************************************************************61*/

/********************************************************************90**
 
     ver       pat    init                  description
------------ -------- ---- ----------------------------------------------
1.1          ---      rrp  1.Initial release.
/main/4      ---       pk  2. Management interface for Release v 1.2
/main/4+               vj  1. Added user functions to remove crash 
                              in pack-unpack of systemId.              
             mg007.102 vj  1. Removed MgPeerInfo field from MgPeerSta
                              structure, and instead added 5 fields:- peerId, 
                              dname[], namePres, MgPeerAddrTbl & port.This is 
                              required since in MGCP, multiple adddress are 
                              possible for each domain name. Further, modified
                              the version number field in MgPeerSta from U8 to
                              U32.
             mg008.102 vj  1. For pack-unpack of MgSts, the element value for
                              obtaining TSAP stats should be STTSAP rather 
                              than STGEN.
             mg011.102 vj  1. In SSAP configuration, added a new field addrInfo
                              for MEGACO, as userInfo no longer provides 
                              address information in MEGACO path
                           2. In Peer configuration, added a "MgMgcoMidStr mid"
                              field for MEGACO. Further removed mIdPort field.
                           3. In MgPeerSta structure, added "MgMgcoMidStr mid"
                              field in case of MEGACO.
/main/2      ---      ra   1. GCP 1.3 release
/main/6      ---      ka   1. Changes for Release v 1.4
            mg001.104 ka   1. Avoided Packing and Unpacking of DNS paramenters
                              if not configured for DNS.
            mg002.104 ka   1. Corrected the dnsAccess parameter name to
                              param->dnsAccess to get around compilation
                              problems if the flag LCLMG is defined.
/main/1      ---      pk   1. GCP 1.5 release
/main/1    001.main_1 ra   1. Added TOS in Endpoint & Peer Cfg.
           002.main_1 ka   1. Made rspAckEnb as reconfigurable.
           003.main_1 ps   1. Made pending limit configurable 
     lmg_c_004.main_1 gk   1. GCP_ALLOW_LIMIT_CFG - This is introduced
                              to configured the limits for GCP message
                              components exceeding which will be rejected
                           2. Service change profile information
     lmg_c_005.main_1 gk   1. Added error code counter
*********************************************************************91*/
