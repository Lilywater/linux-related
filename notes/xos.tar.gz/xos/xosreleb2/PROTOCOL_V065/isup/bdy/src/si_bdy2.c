/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/

/********************************************************************20**

    Name:     ISUP - body 2

    Type:     C source file

    Desc:     C source code for ISUP Upper Layer, Lower Layer,
              System Service and Layer Management service user primitives
              supplied by TRILLIUM.

              Part 2: Support Functions;

    File:     ci_bdy2.c

    Sid:      ci_bdy2.c@@/main/38 - Wed Jul 25 13:20:35 2001
 
    Prg:      na

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif


************************************************************************/


/*
It is assumed that the following functions are provided in the system
services service provider file:

     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFlushQueue    Flush Queue
     SCatQueue      Concatenate Queue
     SFndLenQueue   Find Length of Queue

     SGetMsg        Get Message
     SPutMsg        Put Message
     SInitMsg       Initialize Message

     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SExamMsg       Examine Message
     SFndLenMsg     Find Length of Message
     SCopyMsgMsg    Copy Message to Message
     SCatMsg        Concatenate Message
     SSegMsg        Segment Message

     SChkRes        Check Resources
     SRegTmr        Register Activate Task - timer

*/



/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
*
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management */
#include "si_mf.h"            /* message functions */
#include "cm5.h"           /* timers */
#include "ci_db.h"         /* isup data base */
#include "cm_hash.h"       /* hash-list header */
#include "sit.h"           /* isup layer */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif

#include "si.h"            /* isup */
#include "si_err.h"        /* isup error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif

#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_lib.x"        /* common memory functions */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list header */
#include "lsi.x"           /* layer management */
#include "si_mf.x"         /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* isup data base */
#include "sit.x"           /* isup layer */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* common sht intf */
#endif

#include "si.x"            /* isup */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI 
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif

#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */

/* local defines */

/* local typedefs */
  
/* local externs */

/* forward references */
#if (ERRCLASS & ERRCLS_DEBUG)
PRIVATE S16 siValdtIncCirIntf ARGS((SiCon *siCon));
#endif
PRIVATE S16 siIncUNXMSG ARGS((SiCon *siCon));
PRIVATE S16 siIncUNXEVT ARGS((SiCon *siCon));
PRIVATE S16 siIncE00S03 ARGS((SiCon *siCon));
PRIVATE S16 siIncE01S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE02S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE03S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE04S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE05S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE06SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE08S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE08S01 ARGS((SiCon *siCon));
PRIVATE S16 siIncE09S01 ARGS((SiCon *siCon));
PRIVATE S16 siIncE10SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE11SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE12SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE13S03 ARGS((SiCon *siCon));
PRIVATE S16 siIncE14SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE15SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE17S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE17SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE17S06 ARGS((SiCon *siCon));
PRIVATE S16 siIncE17S07 ARGS((SiCon *siCon));
PRIVATE S16 siIncE18SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE18S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE18S01 ARGS((SiCon *siCon));
PRIVATE S16 siIncE18S06 ARGS((SiCon *siCon));
PRIVATE S16 siIncE18S08 ARGS((SiCon *siCon));
PRIVATE S16 siIncE19S05 ARGS((SiCon *siCon));
PRIVATE S16 siIncE20S01 ARGS((SiCon *siCon));
PRIVATE S16 siIncE21S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE21S05 ARGS((SiCon *siCon));
PRIVATE S16 siIncE22SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE26S02 ARGS((SiCon *siCon));
PRIVATE S16 siIncE26S03 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S01 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S02 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S03 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S05 ARGS((SiCon *siCon));
PRIVATE S16 siIncE27S07 ARGS((SiCon *siCon));
PRIVATE S16 siIncE28SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE28S07 ARGS((SiCon *siCon));
PRIVATE S16 siIncE29S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE29S06 ARGS((SiCon *siCon));
PRIVATE S16 siIncE29S07 ARGS((SiCon *siCon));
PRIVATE S16 siIncE29S08 ARGS((SiCon *siCon));
PRIVATE S16 siIncE30SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE31S04 ARGS((SiCon *siCon));
PRIVATE S16 siIncE31S05 ARGS((SiCon *siCon));
PRIVATE S16 siIncE32S05 ARGS((SiCon *siCon));
PRIVATE S16 siIncE33SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE34SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE35S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE36S00 ARGS((SiCon *siCon));
PRIVATE S16 siIncE36SND ARGS((SiCon *siCon));
PRIVATE S16 siIncE36S06 ARGS((SiCon *siCon));
PRIVATE S16 siIncE36S07 ARGS((SiCon *siCon));
PRIVATE S16 siIncE36S08 ARGS((SiCon *siCon));
PRIVATE S16 siIncE37S00 ARGS((SiCon *siCon));

/* public variable declarations */


/* connection matrix - incoming connections */

PFSIM siConInc[NMB_ICON_EVNT][NMB_IN_CON_ST] =
{
   /* Address Complete */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncE00S03,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Answer */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncE01S04,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Complete */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncE02S04,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Request */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncE03S04,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Rejected */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncE04S04,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Progress */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncE05S04,      /* 03  - waiting for Answer                 */
      siIncE05S04,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Confusion */
   {
      siIncE06SND,      /* 00  - idle                               */
      siIncE06SND,      /* 01  - waiting for Continuity             */
      siIncE06SND,      /* 02  - waiting for ACM                    */
      siIncE06SND,      /* 03  - waiting for Answer                 */
      siIncE06SND,      /* 04  - ICC answered                       */
      siIncE06SND,      /* 05  - ICC suspended                      */
      siIncE06SND,      /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Connect */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Continuity */
   {
      siIncE08S00,      /* 00  - idle                               */
      siIncE08S01,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Continuity check request */
   {
      siIncE09S01,      /* 00  - idle                               */
      siIncE09S01,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Accepted */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncE10SND,      /* 02  - waiting for ACM                    */
      siIncE10SND,      /* 03  - waiting for Answer                 */
      siIncE10SND,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Rejected */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncE11SND,      /* 02  - waiting for ACM                    */
      siIncE11SND,      /* 03  - waiting for Answer                 */
      siIncE11SND,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Request */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncE12SND,      /* 02  - waiting for ACM                    */
      siIncE12SND,      /* 03  - waiting for Answer                 */
      siIncE12SND,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Forward Transfer */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncE13S03,      /* 03  - waiting for Answer                 */
      siIncE13S03,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Information */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncE14SND,      /* 01  - waiting for Continuity             */
      siIncE14SND,      /* 02  - waiting for ACM                    */
      siIncE14SND,      /* 03  - waiting for Answer                 */
      siIncE14SND,      /* 04  - ICC answered                       */
      siIncE14SND,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Information Request */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncE15SND,      /* 01  - waiting for Continuity             */
      siIncE15SND,      /* 02  - waiting for ACM                    */
      siIncE15SND,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Initial Address */
   {
      siIncE16S00,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Release */
   {
      siIncE17S00,      /* 00  - idle                               */
      siIncE17SND,      /* 01  - waiting for Continuity             */
      siIncE17SND,      /* 02  - waiting for ACM                    */
      siIncE17SND,      /* 03  - waiting for Answer                 */
      siIncE17SND,      /* 04  - ICC answered                       */
      siIncE17SND,      /* 05  - ICC suspended                      */
      siIncE17S06,      /* 06  - waiting for Release Complete       */
      siIncE17S07,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Complete */
   {
      siIncE18S00,      /* 00  - idle                               */
      siIncE18S01,      /* 01  - waiting for Continuity             */
      siIncE18SND,      /* 02  - waiting for ACM                    */
      siIncE18SND,      /* 03  - waiting for Answer                 */
      siIncE18SND,      /* 04  - ICC answered                       */
      siIncE18SND,      /* 05  - ICC suspended                      */
      siIncE18S06,      /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - ICC Release Complete               */
      siIncE18S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Resume */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncE19S05,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Subsequent Address */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncE20S01,      /* 01  - waiting for Continuity             */
      siIncE20S01,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Suspend */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncE21S04,      /* 04  - ICC answered                       */
      siIncE21S05,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* User to User */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncE22SND,      /* 02  - waiting for ACM                    */
      siIncE22SND,      /* 03  - waiting for Answer                 */
      siIncE22SND,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reservation Message */
   {
      siIncE23S00,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIncUNXMSG,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reservation Acknowledge Message */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIncUNXMSG,      /* 03  - waiting for Answer                 */
      siIncUNXMSG,      /* 04  - ICC answered                       */
      siIncUNXMSG,      /* 05  - ICC suspended                      */
      siIncUNXMSG,      /* 06  - waiting for Release Complete       */
      siIncUNXMSG,      /* 07  - ICC Release Complete               */
      siIncUNXMSG,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Establishment Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncUNXEVT,      /* 02  - waiting for ACM                    */
      siIncUNXEVT,      /* 03  - waiting for Answer                 */
      siIncUNXEVT,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Establishment Response */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncE26S02,      /* 02  - waiting for ACM                    */
      siIncE26S03,      /* 03  - waiting for Answer                 */
      siIncUNXEVT,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Progress Status Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncE27S01,      /* 01  - waiting for Continuity             */
      siIncE27S02,      /* 02  - waiting for ACM                    */
      siIncE27S03,      /* 03  - waiting for Answer                 */
      siIncE27S04,      /* 04  - ICC answered                       */
      siIncE27S05,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncE27S07,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Request */
   {
      siIncE28SND,      /* 00  - idle                               */
      siIncE28SND,      /* 01  - waiting for Continuity             */
      siIncE28SND,      /* 02  - waiting for ACM                    */
      siIncE28SND,      /* 03  - waiting for Answer                 */
      siIncE28SND,      /* 04  - ICC answered                       */
      siIncE28SND,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncE28S07,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Response */
   {
      siIncE29S00,      /* 00  - idle                               */
      siIncE29S00,      /* 01  - waiting for Continuity             */
      siIncUNXEVT,      /* 02  - waiting for ACM                    */
      siIncUNXEVT,      /* 03  - waiting for Answer                 */
      siIncUNXEVT,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncE29S06,      /* 06  - waiting for Release Complete       */
      siIncE29S07,      /* 07  - ICC Release Complete               */
      siIncE29S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* User Information Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncE30SND,      /* 02  - waiting for ACM                    */
      siIncE30SND,      /* 03  - waiting for Answer                 */
      siIncE30SND,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Suspend Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncUNXEVT,      /* 02  - waiting for ACM                    */
      siIncUNXEVT,      /* 03  - waiting for Answer                 */
      siIncE31S04,      /* 04  - ICC answered                       */
      siIncE31S05,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Resume Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncUNXEVT,      /* 02  - waiting for ACM                    */
      siIncUNXEVT,      /* 03  - waiting for Answer                 */
      siIncUNXEVT,      /* 04  - ICC answered                       */
      siIncE32S05,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Request */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncE33SND,      /* 02  - waiting for ACM                    */
      siIncE33SND,      /* 03  - waiting for Answer                 */
      siIncE33SND,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Response */
   {
      siIncUNXEVT,      /* 00  - idle                               */
      siIncUNXEVT,      /* 01  - waiting for Continuity             */
      siIncE34SND,      /* 02  - waiting for ACM                    */
      siIncE34SND,      /* 03  - waiting for Answer                 */
      siIncE34SND,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Status Request */
   {
      siIncE35S00,      /* 00  - idle                               */
      siIncE35S00,      /* 01  - waiting for Continuity             */
      siIncUNXEVT,      /* 02  - waiting for ACM                    */
      siIncUNXEVT,      /* 03  - waiting for Answer                 */
      siIncUNXEVT,      /* 04  - ICC answered                       */
      siIncUNXEVT,      /* 05  - ICC suspended                      */
      siIncUNXEVT,      /* 06  - waiting for Release Complete       */
      siIncUNXEVT,      /* 07  - ICC Release Complete               */
      siIncUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reset Request */
   {
      siIncE36S00,      /* 00  - idle                               */
      siIncE36SND,      /* 01  - waiting for Continuity             */
      siIncE36SND,      /* 02  - waiting for ACM                    */
      siIncE36SND,      /* 03  - waiting for Answer                 */
      siIncE36SND,      /* 04  - ICC answered                       */
      siIncE36SND,      /* 05  - ICC suspended                      */
      siIncE36S06,      /* 06  - waiting for Release Complete       */
      siIncE36S07,      /* 07  - ICC Release Complete               */
      siIncE36S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Blocking Request */
   {
      siIncE37S00,      /* 00  - idle                               */
      siIncE37S00,      /* 01  - waiting for Continuity             */
      siIgnore,         /* 02  - waiting for ACM                    */
      siIgnore,         /* 03  - waiting for Answer                 */
      siIgnore,         /* 04  - ICC answered                       */
      siIgnore,         /* 05  - ICC suspended                      */
      siIgnore,         /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Loopback Acknowledgement */
   {
      siIncUNXMSG,      /* 00  - idle                               */
      siIncUNXMSG,      /* 01  - waiting for Continuity             */
      siIncUNXMSG,      /* 02  - waiting for ACM                    */
      siIgnore,         /* 03  - waiting for Answer                 */
      siIgnore,         /* 04  - ICC answered                       */
      siIgnore,         /* 05  - ICC suspended                      */
      siIgnore,         /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - ICC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   }

};



/*
*     support functions
*/

#if (ERRCLASS & ERRCLS_DEBUG)
/*
*
*       Fun:   siValdtIncCirIntf
*
*       Desc:  This function checks the con->incC.cir and
*              con->incC.cir->intfCb pointers
*
*       Ret:   ROK     - ok
*              RFAILED - failure
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siValdtIncCirIntf
(
SiCon *con 
)
#else
PRIVATE S16 siValdtIncCirIntf(con)
SiCon *con;
#endif
{
   TRC2(siValdtIncCirIntf)

   if (con->incC.cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Incoming circuit pointer missing; (conState = %#x)\n",
         con->incC.conState));  

      SILOGERROR(ERRCLS_DEBUG, ESI109, (ErrVal) 0, 
         "siValdtIncCirIntf() Failed, Incoming circuit pointer missing");
      RETVALUE(RFAILED);
   }
   if (con->incC.cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Interface control block pointer missing; (conState = %#x)\n",
         con->incC.conState));  

      SILOGERROR(ERRCLS_DEBUG, ESI110, (ErrVal) 0, 
       "siValdtIncCirIntf() Failed, Interface control block pointer missing");
      RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of siValdtIncCirIntf */
#endif 


  
/*
*
*       Fun:   siIgnore
*
*       Desc:  Input: Any ignorable Message
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 siIgnore
(
SiCon *con 
)
#else
PUBLIC S16 siIgnore(con)
SiCon *con;
#endif
{
   TRC2(siIgnore)
   UNUSED(con);

   SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf, "event Ignored\n"));  
   RETVALUE(ROK);
} /* end of siIgnore */
  
/*
*
*       Fun:   siIncUNXMSG
*
*       Desc:  Input: out of sequence message
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncUNXMSG
(
SiCon *con 
)
#else
PRIVATE S16 siIncUNXMSG(con)
SiCon *con;
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *mCb;
   SiCirCb   *cir;
   SpId      spId;
   U8       genRscFlg;  /* 0: Reset is not to be generated */
   Swtch    swtch;
   TRC2(siIncUNXMSG)

   tCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI111, (ErrVal) 0, 
                 "siIncUNXMSG() Failed, MTP3 control block pointer missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   mCb = con->mCallCb;
   genRscFlg = 0;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;

   switch (con->incC.conState)
   {
      case ST_IDLE:
      case ST_WTFORCONTIN:
      case ST_WTFORACM:
         genRscFlg = 1;
         break;


/* si047.220 : Modified - Generate reset if ACM/ANM has been received for which
               ACM/ANM has been sent */

      default:
         break;
   }
   /* si014.220, Addition: Notify maintenance for bell */

   /* 
    * generate local reset if
    * a) circuit is idle
    * b) waiting for a b/w message for the call
    */
   if (((con->incC.cir->transStat[SICIR_MTLOCST] == SICIR_ST_IDLE) &&
        (con->incC.cir->transStat[SICIR_HWLOCST] == SICIR_ST_IDLE)) &&
       (genRscFlg))
   {
      if (con->tCallCb == NULLP)
      {
         for (spId = 0; spId < (SpId)siCb.genCfg.nmbSaps; spId++)
         {
            tCb = SIUPSAP(spId);
            /* si016.220, Modify: added a NULLP check for tCb pointer */
            if ((tCb != NULLP) && (tCb->cfg.swtch == swtch))
               break;
         }
#if (ERRCLASS & ERRCLS_DEBUG)
         if (spId == (SpId)siCb.genCfg.nmbSaps)
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Can not find Upper SAP for swtch %d\n", swtch));  
            SILOGERROR(ERRCLS_DEBUG, ESI112, (ErrVal) 0, 
                       "siIncUNXMSG() Failed, invalid switch can't find tCb ");
            RETVALUE(ROK);
         }
#endif
         if (!con->key.k1.spInstId)
         {
            /* get Instance Id */
            if (siGetInstId(&con->key.k1.spInstId) != RFAILED)
            {
               con->tCallCb = tCb;
               siAddInst(&siCb.conHlCp, con);
            } 
            else
            {  
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "can not allocate spInstId\n"));  
            } 
         }
      }
      cir = con->incC.cir;
      cir->noRspFlgToLw = TRUE;
     
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection */
      if ((cir->ctrlMultiRateCir != NULLP) &&
          ((swtch == LSI_SW_ANS95) || (swtch == LSI_SW_ITU97) ||
          (swtch == LSI_SW_RUSS2000) || (swtch == LSI_SW_ITU2000) ||
           (swtch == LSI_SW_ETSIV3))) 
      {
         /* this is a non-single rate connection. respond a GRS with CAM for
          * ans95 or multiple RSC for itu97 and etsi v3
          */
         siGenMRateRsc(cir->ctrlMultiRateCir);
         RETVALUE(ROK);
      }
      else
#endif
      {              
         /* Generate RSC as if Reset request is received */
         siProcCirEvt(cir, SIT_STA_CIRRESREQ, FALSE);
         /* Generate a local reset */
         siGenCirEvt(cir, SIT_STA_CIRLOCRES);

      }
   }
   RETVALUE(ROK);
} /* end of siIncUNXMSG */

  
/*
*
*       Fun:   siIncUNXEVT
*
*       Desc:  Input: out of sequence event
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncUNXEVT
(
SiCon *con 
)
#else
PRIVATE S16 siIncUNXEVT(con)
SiCon *con;
#endif
{
   SiAllSdus ev;

   TRC2(siIncUNXEVT)

   UNUSED(ev);

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI113, (ErrVal) 0, 
                 "siIncUNXEVT() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Generate Alarm to Layer management */
   siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId,
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP, 
                 LSI_USTA_DGNVAL_NONE, NULLP);
   SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                  LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                  (CirId)con->incC.cirId, SI_ALRM_INV_EVENT);
   RETVALUE(RFAILED);
} /* end of siIncUNXEVT */

  
/*
*
*       Fun:   siIncE02S04
*
*       Desc:  Input: Call Modification Complete
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE02S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE02S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;                /* unrecognised parameters */

   TRC2(siIncE02S04)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI114, (ErrVal) 0, 
                 "siIncE02S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI115, (ErrVal) 0, 
                 "siIncE02S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir  == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with con\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI116, (ErrVal) 0, 
                 "siIncE02S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   /* unrecognised parameters in incoming message */
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* control of 'uBuf' is passed to call control */
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->tCallCb->cfg.swtch)
   {
      case LSI_SW_ITU:
         if ((con->pduSp->m.caModComp.callRef.eh.pres) &&(!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetLwrSCbPtr(cir))
                  != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->incC.dCallRef = con->pduSp->m.caModComp.callRef.callId.val;
               con->incC.phyDpc = 
                         (U32)con->pduSp->m.caModComp.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef is not present\n"));  
         } 
         break;

#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_ITU2000 
      case LSI_SW_ITU2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif /* if SS7_CHINA */
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch invalid %d\n", con->tCallCb->cfg.swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI117, (ErrVal) 0, 
                 "siIncE02S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }

   if (con->incC.cllModProc == TRUE)
   {
      con->incC.cllModProc = FALSE;

      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODCOMP, 
                (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);


      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                     con->key.k1.spInstId, con->incC.cirId, &ev.m.siCnStEvnt, 
                     MODCMPLT, uBuf);
   }
   else
      /* unexpected message */
      siIncUNXMSG(con);
   RETVALUE(ROK);
} /* end of siIncE02S04 */

  
/*
*
*       Fun:   siIncE03S04
*
*       Desc:  Input: Call Modification Request
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE03S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE03S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiPduHdr  pduHdr;
   SiAllSdus ev;
   SiAllPdus message;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE03S04)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI118, (ErrVal) 0, 
                 "siIncE03S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  

       SILOGERROR(ERRCLS_DEBUG, ESI119, (ErrVal) 0, 
                 "siIncE03S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI120, (ErrVal) 0, 
                 "siIncE03S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* control of 'uBuf' is passed to call control */
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->tCallCb->cfg.swtch)
   {
      case LSI_SW_ITU:
         if ((con->pduSp->m.caModReq.callRef.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetLwrSCbPtr(cir))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->incC.dCallRef = con->pduSp->m.caModReq.callRef.callId.val;
               con->incC.phyDpc = 
                              (U32) con->pduSp->m.caModReq.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  
         } 
         break;

#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_ITU2000 
      case LSI_SW_ITU2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif /* if SS7_CHINA */
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  
         SILOGERROR(ERRCLS_DEBUG, ESI121, (ErrVal) 0, 
                 "siIncE03S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }

   if (con->tCallCb->cfg.allCallMod)
   {
      con->incC.cllModProc = TRUE;
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREQ, 
               (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
               (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                  con->suInstId, con->key.k1.spInstId, con->incC.cirId,
                  &ev.m.siCnStEvnt, MODIFY, uBuf);
   }
   else
   {
      /* init modification reject */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_CALLMODREJ;

      MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREQ, (U8)
                MI_CALLMODREJ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &message,
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      siInsCallRef(cir, &message, pduHdr.msgType.val);

      /* send message */
      siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(pduHdr.msgType.val, 
                  con->tCallCb->cfg.swtch), NULLP);
   }
   RETVALUE(ROK);
} /* end of siIncE03S04 */

  
/*
*
*       Fun:   siIncE04S04
*
*       Desc:  Input: Call Modification Reject
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE04S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE04S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE04S04)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  
       SILOGERROR(ERRCLS_DEBUG, ESI122, (ErrVal) 0, 
                 "siIncE04S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  

       SILOGERROR(ERRCLS_DEBUG, ESI123, (ErrVal) 0, 
                 "siIncE04S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf; 

   switch (con->tCallCb->cfg.swtch)
   {
      case LSI_SW_ITU:
         if ((con->pduSp->m.caModRej.callRef.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->incC.dCallRef = con->pduSp->m.caModRej.callRef.callId.val;
               con->incC.phyDpc = 
                              (U32) con->pduSp->m.caModRej.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  
         }  
         break;
#ifdef SS7_ITU97 
      case LSI_SW_ITU97:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_ITU2000 
      case LSI_SW_ITU2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
         siIncUNXMSG(con);
         RETVALUE(ROK);
#endif /* if SS7_CHINA */
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI124, (ErrVal) 0, 
                 "siIncE04S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }

   if (con->incC.cllModProc == TRUE)
   {
      con->incC.cllModProc = FALSE;

      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREJ, 
                (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      /* passed the control of 'uBuf' to upper layer */
      con->mCallCb->mfMsgCtl.uBuf = NULLP;

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                     con->key.k1.spInstId, con->incC.cirId, &ev.m.siCnStEvnt, 
                     MODREJ, uBuf);
   }
   else
      /* unexpected message */
      siIncUNXMSG(con);
   RETVALUE(ROK);
} /* end of siIncE04S04 */

  
/*
*
*       Fun:   siIncE05S04
*
*       Desc:  Input: Call Progress
*              State: answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE05S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE05S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE05S04)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI125, (ErrVal) 0, 
                 "siIncE05S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI126, (ErrVal) 0, 
                 "siIncE05S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   {
      if ((con->pduSp->m.caProg.callRef.eh.pres) && (!con->incC.dCallRef))
      {  
         if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
               con->mCallCb->cfg.ssf)) != NULLP) &&
             (con->sCallCb->state == SI_BND))
         {
            con->exchCalRef = TRUE;
            con->incC.dCallRef = con->pduSp->m.caProg.callRef.callId.val;
            con->incC.phyDpc = (U32) con->pduSp->m.caProg.callRef.pntCde.val;
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
               "either can not get sCallCb 0x%lx or state not bound\n",
                     (U32 )con->sCallCb));
         } 
      } 
      else 
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "callRefA is not present\n"));  
      } 
   }

   switch (con->tCallCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000 
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         if ((con->pduSp->m.caProg.optBckCalInd.eh.pres) &&
             (con->pduSp->m.caProg.optBckCalInd.simpleSegmInd.pres) && 
             (con->pduSp->m.caProg.optBckCalInd.simpleSegmInd.val
                 == SSI_ADDSEGM))
         {
            /* start T36 Timer */
            siStartConTmr(TMR_T36I, con, con->tCallCb);
 
            con->incC.msgToSegm       = con->mCallCb->mfMsgCtl.mp;
            con->mCallCb->mfMsgCtl.mp = NULLP;
            con->incC.eventType       = MI_CALLPROG;
            siProcIncSegm             = TRUE;
            RETVALUE(ROK);
         }
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI127, (ErrVal) 0,
                 "siIncE05S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* initialize connect status event */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLPROG, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* pass the control of 'uBuf' to upper layer */
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                  con->suInstId, con->key.k1.spInstId, con->incC.cirId,
                  &ev.m.siCnStEvnt, PROGRESS, uBuf);
   RETVALUE(ROK);
} /* end of siIncE05S04 */


  
/*
*
*       Fun:   siIncE06SND
*
*       Desc:  Input: Confusion
*              State: idle through ICC suspended.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE06SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE06SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE06SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI128, (ErrVal) 0, 
                 "siIncE06SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf; 
   con->tCallCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);

   /* initialize siStaEvnt */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CONFUSION, (U8) SI_STAREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* send confusion to the upper layer */
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId,
                 con->suInstId, con->key.k1.spInstId, con->incC.cirId, FALSE,
                 SIT_STA_CONFUSION, &ev.m.siStaEvnt, uBuf);
   RETVALUE(ROK);
} /* end of siIncE06SND */
  
/*
*
*       Fun:   siIncE08S00
*
*       Desc:  Input: Continuity
*              State: Idle 
*
*       Ret:   ROK      - ok
*
*       Notes: This is possible if LPA req is not received for ANS92
*              case.
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE08S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE08S00(con)
SiCon *con;
#endif
{

   TRC2(siIncE08S00)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI129, (ErrVal) 0, 
                 "siIncE08S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
#endif
   {
      siIncUNXMSG(con);
   }
   RETVALUE(ROK);
} /* end of siIncE08S00 */

  
/*
*
*       Fun:   siIncE08S01
*
*       Desc:  Input: Continuity
*              State: Waiting for Continuity
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE08S01
(
SiCon *con 
)
#else
PRIVATE S16 siIncE08S01(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8        tmrNum;
   S16       ret;
   Bool      found;
   Buffer    *uBuf;

   TRC2(siIncE08S01)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI130, (ErrVal) 0, 
                 "siIncE08S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI131, (ErrVal) 0, 
                 "siIncE08S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* Stop T8 Timer */
   siStopConTmr(con, TMR_T8);
   /* Stop T34 if it exists */
   for (tmrNum = 0, found = FALSE; tmrNum < MAXSIMTIMER; tmrNum++)
   {
      if (con->timers[tmrNum].tmrEvnt == TMR_T34)
      {
         found = TRUE;
         siRmvConTq(con, tmrNum);
      }
   }

   if (con->pduSp->m.continuity.contInd.contInd.val == CONT_CHKSUCC)
   {
      /* initialize siStaEvnt */
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CONTINUITY, 
                (U8) SI_STAREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      SISTATECHNG(con->incC.conState , ST_WTFORACM);

      /* send continuity report to the upper layer */
      /* pass the control of 'uBuf' to upper layer */
      con->mCallCb->mfMsgCtl.uBuf = NULLP;
      SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                    con->key.k1.spInstId, con->incC.cirId, FALSE, 
                    SIT_STA_CONTREP, &ev.m.siStaEvnt, uBuf);
   }
   else
   {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate call. If so, should
       * clear the non controlling circuits. remove association 
       * and reset calProcState to idle for non cntrl ckt cb. The failure
       * procedure is applied only on the controlling circuit.
       * Keep the conn only on the controlling circuit.
       */
      if ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
          (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
      {              
         if (con->incC.cir->ctrlMultiRateCir != NULLP)
         {
            /* this is a non-single rate connection */
            if (siDelMRateLnk(&con->incC) != ROK)
            {
                SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "Break the linkage of ckts when recv COT failure for\
                    a non-single rate incoming call failed.\n"));
                RETVALUE(RFAILED);
            }

         }
      }         
#endif
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      {
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & INC))
         {
            siRmvConTq(con, tmrNum);
         }
      }
      
      switch(con->tCallCb->cfg.swtch)
      {
/* si022.220: modification - adding Bellcore option for the 
 * timer processing along with the ANSI variants. 
 * NOTE: for BELLCORE, T27 here corresponds to Tcot,l; 
 *       TCCRI here corresponds to Tcot,r
 */
#if ( SS7_ANS92 || SS7_ANS95 || SS7_BELL)
         case LSI_SW_ANS92:
         case LSI_SW_ANS95:
         case LSI_SW_BELL:
            if (found)
            {
               siStartConTmr(TMR_T27, con, con->tCallCb);
            }
            else
            {
               /* si020.220: Modification - modify code to allow TCCRI timer
                * being restarted in case of multiple COTs with failure being 
                * received.
                */
               siStartConTmr(TMR_TCCRI, con, con->tCallCb);
               con->tccriCnt = TRUE;
            }
            break;
#endif 
         default:
            siStartConTmr(TMR_T27, con, con->tCallCb);
            break;
      }
#ifndef SI_NEW_COT_PROC
      if (found)
#endif /* SI_NEW_COT_PROC */
      {
         /* initialize siStaEvnt */
         MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CONTINUITY, 
                   (U8) SI_STAREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);

         /* send continuity report to the upper layer */
         con->mCallCb->mfMsgCtl.uBuf = NULLP;
         SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                       con->key.k1.spInstId, con->incC.cirId, FALSE, 
                       SIT_STA_CONTREP, &ev.m.siStaEvnt, uBuf);
      }

      if (found)
      {
         /* RelInd is not sent for this case */ 
      }
      else
      {
#ifndef SI_NEW_COT_PROC
         /* initialize siRelEvnt */
         cmMemset((U8 *)&ev.m.siRelEvnt, (U8) NOTPRSNT, sizeof(SiRelEvnt));
         UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCRESCUNAVAIL, con->tCallCb);
         
         /* change the state */
         SISTATECHNG(con->incC.conState, ST_IDLE);
            
         SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId,
                       con->key.k1.spInstId, con->incC.cirId, &ev.m.siRelEvnt,
                       NULLP);  
#endif /* SI_NEW_COT_PROC */ 
      }
   }
   RETVALUE(ROK);
} /* end of siIncE08S01 */


  
/*
*
*       Fun:   siIncE09S01
*
*       Desc:  Input: Continuity Check Request
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE09S01
(
SiCon *con 
)
#else
PRIVATE S16 siIncE09S01(con)
SiCon *con;
#endif
{
   SiCirCb *cir;
   U32     ref;
   Buffer  *uBuf;

   TRC2(siIncE09S01)

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI135, (ErrVal) 0, 
                 "siIncE09S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif
   if (con->tCallCb == NULLP)
   {
      /* get pointer to the upper control block */
      con->tCallCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);

      /* get Instance Id */
      if (siGetInstId(&ref) != RFAILED)
      {
         con->key.k1.spInstId = ref;
         siAddInst(&siCb.conHlCp, con);
      } 
      else
      {  
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "can not get the instance Id\n"));  
      } 
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   if ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
   {           
      /* check if this is a non-single rate connection. */
      if (con->incC.cir->ctrlMultiRateCir != NULLP) 
      {
         /* it is a non-single rate connection. There is no way to get CCR
          * CCR is sent under two scenarioes:
          * 1) after a conitunity check failure
          * 2) sent on a idle state
          * For case 1), only single continuty-check failure procedure
          * is applied to the controlling ckt, non-controlling ckts are
          * idled. after received failed COT, the linkage was already broken.
          * For case 2), there no call exists.
          * treat it as unexpected message for non-single rate.
          */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                "rcvd CCR for an non-single rate call on ckt %#lx \n", 
                     con->incC.cirId)); 

         siIncUNXMSG(con);
         RETVALUE(ROK);
      }
   }
#endif

   /* stop TCCR and T27 timers */
   siStopConTmr(con, TMR_TCCRI);
   siStopConTmr(con, TMR_T27);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   switch(con->tCallCb->cfg.swtch)
   {
      case LSI_SW_ITU:
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         /* start T34. This is not started in ANSI until status request with
          * type loopback ack is received from upper layer 
          */
         siStartConTmr(TMR_T34, con, con->tCallCb);
         SISTATECHNG(con->incC.conState , ST_WTFORCONTIN);
         break;
   }
   /* if it is unequipped then also on getting CCR from remote
      end state should be made equipped.
   */
   if( (cir->transStat[SICIR_MTREMST] == SICIR_ST_UNEQPD  ) ||
       (cir->transStat[SICIR_HWREMST] == SICIR_ST_UNEQPD  ) 
     )
   {
      cir->transStat[SICIR_MTREMST] = SICIR_ST_IDLE;
      cir->transStat[SICIR_HWREMST] = SICIR_ST_IDLE;
   }

   /* send continuity check request to the upper layer */
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, FALSE, 
                 SIT_STA_CONTCHK, NULLP, uBuf);
   RETVALUE(ROK);
} /* end of siIncE09S01 */

  
/*
*
*       Fun:   siIncE10SND
*
*       Desc:  Input: Facility Accepted
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE10SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE10SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE10SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI136, (ErrVal) 0, 
                 "siIncE10SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI137, (ErrVal) 0, 
                 "siIncE10SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_FACACC, (U8) SI_FACREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitFacCfm(&con->tCallCb->pst, con->tCallCb->suId,
                 con->suInstId, con->key.k1.spInstId, con->incC.cirId,
                 SIT_FACACC, &ev.m.siFacEvnt, uBuf);

   RETVALUE(ROK);
} /* end of siIncE10SND */

  
/*
*
*       Fun:   siIncE11SND
*
*       Desc:  Input: Facility Rejected
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE11SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE11SND(con)
SiCon *con;
#endif
{
   SiAllSdus  ev;
   S16        ret;
   Buffer     *uBuf;

   TRC2(siIncE11SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI138, (ErrVal) 0, 
                 "siIncE11SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI139, (ErrVal) 0, 
                 "siIncE11SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_FACREJ, (U8) SI_FACREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
      /**** fall through ****/
      default:
         con->mCallCb->mfMsgCtl.uBuf = NULLP;
         SiUiSitFacCfm(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                       con->key.k1.spInstId, con->incC.cirId, SIT_FACREJ, 
                       &ev.m.siFacEvnt, uBuf);
         break;
   }
   RETVALUE(ROK);
} /* end of siIncE11SND */

  
/*
*
*       Fun:   siIncE12SND
*
*       Desc:  Input: Facility Request
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE12SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE12SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   U8        event;
   Buffer    *uBuf;

   TRC2(siIncE12SND)

   event = 0;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI140, (ErrVal) 0, 
                 "siIncE12SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI141, (ErrVal) 0, 
                 "siIncE12SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) con->evntType, (U8) SI_FACREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         switch (con->evntType)
         {
            case MI_FACIL:
               event = SIT_FACIL;
               break;
            case MI_FACREQ:
               event = SIT_FACREQ;
               break;
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "for ITU evenType is netiher FACIL/FACREQ\n"));  
               RETVALUE(ROK);
         }
         break;
      default:
         break;
   }

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitFacInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, event, 
                 &ev.m.siFacEvnt, uBuf);

   RETVALUE(ROK);
} /* end of siIncE12SND */

  
/*
*
*       Fun:   siIncE13S03
*
*       Desc:  Input: Forward Transfer
*              State: Waiting for Answer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE13S03
(
SiCon *con 
)
#else
PRIVATE S16 siIncE13S03(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE13S03)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI142, (ErrVal) 0, 
                 "siIncE13S03() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI143, (ErrVal) 0, 
                 "siIncE13S03() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_FWDTFER, (U8) SI_CNSTREQ,
               (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
               con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
               con->suInstId, con->key.k1.spInstId, con->incC.cirId,
               &ev.m.siCnStEvnt, FRWDTRSFR, uBuf);

   RETVALUE(ROK);
} /* end of siIncE13S03 */

  
/*
*
*       Fun:   siIncE14SND
*
*       Desc:  Input: Information
*              State: Establishing states
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE14SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE14SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   U8        tmrNum;
   Buffer    *uBuf;

   TRC2(siIncE14SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI144, (ErrVal) 0, 
                 "siIncE14SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI145, (ErrVal) 0, 
                 "siIncE14SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;


   /* check the timer T33 for solicited INF. If the timer is running, 
    * stop it
    */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt == TMR_T33I) &&
          (con->pduSp->m.info.infoInd.eh.pres) &&
          (con->pduSp->m.info.infoInd.solInfoInd.pres) &&
          (con->pduSp->m.info.infoInd.solInfoInd.val ==
           SOLINFO_SOLICIT))
          
      {
         siStopConTmr(con, TMR_T33I);
      }

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.info.callRefA.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->incC.dCallRef = con->pduSp->m.info.callRefA.callId.val;
               con->incC.phyDpc = con->pduSp->m.info.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.info.callRef.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->incC.dCallRef = con->pduSp->m.info.callRef.callId.val;
               con->incC.phyDpc = (U32) con->pduSp->m.info.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI147, (ErrVal) 0, 
                 "siIncE14SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_INFORMTN, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->incC.cirId, &ev.m.siCnStEvnt, 
                  INFORMATION, uBuf);

   RETVALUE(ROK);
} /* end of siIncE14SND */

  
/*
*
*       Fun:   siIncE15SND
*
*       Desc:  Input: Information Request
*              State: Answered and Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE15SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE15SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE15SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI148, (ErrVal) 0, 
                 "siIncE15SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI149, (ErrVal) 0, 
                 "siIncE15SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.info.callRefA.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->incC.dCallRef = con->pduSp->m.info.callRefA.callId.val;
               con->incC.phyDpc = con->pduSp->m.info.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif

#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.info.callRef.eh.pres) && (!con->incC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->incC.dCallRef = con->pduSp->m.info.callRef.callId.val;
               con->incC.phyDpc = (U32) con->pduSp->m.info.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI150, (ErrVal) 0, 
                 "siIncE15SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_INFOREQ, (U8) SI_CNSTREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
               con->suInstId, con->key.k1.spInstId, con->incC.cirId,
               &ev.m.siCnStEvnt, INFORMATREQ, uBuf);

   RETVALUE(ROK);
} /* end of siIncE15SND */

  
/*
*
*       Fun:   siIncE16S00
*
*       Desc:  Input: Initial Address
*              State: Connection Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 siIncE16S00
(
SiCon *con 
)
#else
PUBLIC S16 siIncE16S00(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;
   SiAllSdus  ev;
   SiAllPdus  allPdus;
   S16        ret;
   U32        ref;
   SiCauseDgn cause;
   Status     status;
   U8         tmrNum;
   SiPduHdr   pduHdr;
   Buffer     *uBuf;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   Bool     mulCallFlg;           /* non-single rate call flag */
   Bool     contiMRateCall;       /* contiguous non-single rate call */    
   U8       multiplier;           /* num of affected circuits */
   U8       transRate;            /* info transfer rate/trans med req*/ 
   U8       maxNumCir;            /* max num of affected circuits */
   U32      mapVal;               /* map format value */
#endif

   TRC2(siIncE16S00)

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI151, (ErrVal) 0, 
                 "siIncE16S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI152, (ErrVal) 0, 
                 "siIncE16S00() Failed, pointer to circuit missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   uBuf  = con->mCallCb->mfMsgCtl.uBuf;
   {
      /* check if continuity recheck was in process */ 
      if (con->tCallCb != NULLP)
      {
         /* if T27 is running, stop it */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if ((con->timers[tmrNum].tmrEvnt == TMR_T27) ||
                (con->timers[tmrNum].tmrEvnt == TMR_T34))
            {
               switch (con->timers[tmrNum].tmrEvnt)
               {
                  case TMR_T34:
                     siIncUNXMSG(con);
                     RETVALUE(ROK);
                     
                  case TMR_T27:
                     siRmvConTq(con, tmrNum);
   
                     /* Generate Release Confirmation to Upper Layer */
                     MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, 
                               (U8)SI_RELREQ, (ElmtHdr *) NULLP, 
                               (ElmtHdr *) &ev, (U8) NOTPRSNT,
                               con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   
                     SiUiSitRelCfm(&con->tCallCb->pst, con->tCallCb->suId,
                                   con->suInstId, con->key.k1.spInstId, 
                                   con->incC.cirId, &ev.m.siRelEvnt, NULLP);
                     SISTATECHNG(con->incC.cir->calProcStat, CALL_IDLE);
                     break;
               }
               break;
            }
      }
      else 
         /* get pointer to the upper control block */
         con->tCallCb = SIUPSAP(con->incC.cir->pIntfCb->cfg.sapId);
   }

   /* initialize cause/diagnostic element */
   MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
              &meCauseIndV, (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, 
              (U32) MF_ISUP);

   SChkRes(con->tCallCb->pst.region, con->tCallCb->pst.pool, &status);

   if ((status < siCb.genCfg.poolTrLower) ||
       ((status < siCb.genCfg.poolTrUpper) &&
        (con->pduSp->m.initAddr.cgPtyCat.cgPtyCat.val != CAT_PRIOR)))
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Resource crunch for non-priority call\n"));  
      switch (con->tCallCb->cfg.swtch)
      {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_Q767 || SS7_RUSSIA || SS7_CHINA)
            /* Generate Overload Message to Lower Layer */
            cause.causeVal.pres  = PRSNT_NODEF;
            cause.causeVal.val   = SIT_CCSWTCHCONG;
            cause.recommend.pres = NOTPRSNT;
            siGenRelLw(cir->cfg.cirId, con, &cause);
            RETVALUE(ROK);
#endif
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
         case LSI_SW_ITU:
            /* Generate Overload Message to Lower Layer */
            /* prepare Pdu header */
            pduHdr.eh.pres      = PRSNT_NODEF;
            pduHdr.msgType.pres = PRSNT_NODEF;
            pduHdr.msgType.val  = (U8) M_OVERLOAD;

            siGenPdu(con->mCallCb, &pduHdr, &allPdus, con->tCallCb->cfg.swtch,
                     cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                     siGetPriority(pduHdr.msgType.val, 
                        con->tCallCb->cfg.swtch), NULLP);

            /* clear incoming connection */
            siClearIncCon(con);
            RETVALUE(ROK);
      }
   }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* initialize the variable */
   mulCallFlg = FALSE;
   contiMRateCall = TRUE;
   multiplier = 0;
   transRate = 0;
   mapVal = 0;
   maxNumCir = 0;
   
   /* check if this is a non-single rate call, if so, check if it is a 
    * contiguous and get the number of affected circuits N
    */
   switch (con->tCallCb->cfg.swtch)
   {

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
         if (con->pduSp->m.initAddr.txMedReq.trMedReq.pres)
         {
            transRate = con->pduSp->m.initAddr.txMedReq.trMedReq.val;
         }
#if (ERRCLASS & ERRCLS_DEBUG)
         else   
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "transfer rate %d doesn't exist \n",
                    transRate));
            SILOGERROR(ERRCLS_DEBUG, ESI154, (ErrVal) 0,
                       "siIncE16S00() Failed, Transfer rate is not present.");
            RETVALUE(RFAILED);
         }  
#endif

         if (transRate > TMR_64KBITSPREF)
            mulCallFlg = TRUE;
         break;
#endif

      default:
         mulCallFlg = FALSE;
         break;
   }

   /* If this is a non-single rate call, process it. */
   if (mulCallFlg)
   {
      /* This is a non-single rate call. Get the required info for the 
       * further processing. Set the flow direction to FALSE (from lower).
       */
      ret = siGetMRateInfo(con, &(ev.m.siConEvnt), cir, 
                        &transRate, &multiplier, &maxNumCir, &mapVal,
                        &contiMRateCall, FALSE );
      if (ret == RNA)
      {
         /* means the map type is invalid, release the call */
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siGetMRateInfo() return failed\n"));

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &cir->cfg.cirId,
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP,
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE,
                        LCM_EVENT_LI_INV_EVT, LSI_CAUSE_UNEX_CAM, TRUE,
                        cir->cfg.cirId, SI_ALRM_NOCIRTO_ROUTE);

         /* release the call */
         cause.causeVal.pres = PRSNT_NODEF;
         cause.causeVal.val  = SIT_CCPROTERR;
         siGenRelLw(cir->cfg.cirId, con, &cause);
         RETVALUE(RFAILED);
      }

      if (ret == RFAILED)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siGetMRateInfo return failed \n"));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI155, (ErrVal) 0,
                    "siIncE16S00() Failed, fetch info failed.");
#endif
         siClearIncCon(con);
         RETVALUE(RFAILED);
      }

      /* Validate the affected circuits and build the linkage of the 
       * circuits */
      ret = siProcMRateIAM(con, &ev, multiplier, maxNumCir, transRate, 
                           mapVal, contiMRateCall);

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "Process the non-single rate incoming call failed\n"));
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI156, (ErrVal) 0,
           "siIncE16S00() Failed, non-single rate incomming call failed");
#endif
         /* check if need to clear the connection. If ISUP already sent a 
          * release message, we won't clear the conn here.
          */
         if (ret == RFAILED)
            siClearIncCon(con);
         RETVALUE(RFAILED);
      }   
   }           
   else
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
   {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if the circuit involved in other non-single rate call. This
       * could happened because ISUP receives incoming IAM on non-controlling
       * circuit. A dual seizure happened. In the function siChkMRateCtrlCkt(),
       * we allocate a siCon attached to this circuit. Here we determined 
       * which exchange should controll the call.
       */
      if ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
          (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
          (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
      {    
         if (cir->ctrlMultiRateCir != NULLP)
         {
            if (siChkDualinNonCtrl(con) != ROK)
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, 
                  "Discard the incoming message on ckt %#lx in siIncE16S00\n",
                   cir->cfg.cirId)); 
               siClearIncCon(con);
               RETVALUE(ROK);
            }   
         } /* else, normal single rate call procedure */
      }   
#endif

      if ((con->incC.cir->cfg.typeCntrl == OUTGOING) ||
          (con->incC.cir->calProcStat != CALL_IDLE))
      {
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "either ckt is outgoing or a call is there\n"));
         /* clear incoming connection */
         siClearIncCon(con);
         RETVALUE(ROK);
      }

      /* Sanity check on the affected circuit. The checking includes the
       * circuit blocking, unequipped states, etc.
       */
      ret = siSanChkIAMCkts(con, cir, &ev);

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
           "siSanChkIAMCkts returned failure on circuit with cirId(%#lx)\n", 
            cir->cfg.cirId));
         /* clear incoming connection */
         if (cir->siCon != NULLP)
            siClearIncCon(con);
         RETVALUE(ROK);
      }
   }

   con->incC.conPrcs = TRUE;
   SISTATECHNG(cir->calProcStat, INCBUSY);
   /* get Instance Id */
   if (siGetInstId(&ref) == RFAILED)
   {
      SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
           " Can not allocate a new spInst id\n")); 
 
      cause.causeVal.pres = PRSNT_NODEF;
      cause.causeVal.val  = SIT_CCRESCUNAVAIL;
      siGenRelLw(cir->cfg.cirId, con, &cause);
      RETVALUE(ROK);
   }
   con->key.k1.spInstId = ref;

   siAddInst(&siCb.conHlCp, con);
   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if (con->pduSp->m.initAddr.callRefA.eh.pres)
         {  
            if (((con->sCallCb = siGetLwrSCbPtr(cir))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->incC.dCallRef = con->pduSp->m.initAddr.callRefA.callId.val;
               con->incC.phyDpc   = con->pduSp->m.initAddr.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if (con->pduSp->m.initAddr.callRef.eh.pres)
         {  
            if (((con->sCallCb = siGetLwrSCbPtr(cir))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->incC.dCallRef = con->pduSp->m.initAddr.callRef.callId.val;
               con->incC.phyDpc = 
                              (U32) con->pduSp->m.initAddr.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI157, (ErrVal) 0, 
                    "siIncE16S00() Failed, invalid configuration switch");
         /* clear incoming connection */
         siClearIncCon(con);
         RETVALUE(ROK);
      
#endif
   }
   {
      if (con->pduSp->m.initAddr.fwdCallInd.end2EndMethInd.val > E2EMTH_NOMETH)
         con->end2end = TRUE;
      if (con->pduSp->m.initAddr.fwdCallInd.end2EndMethInd.val > 
          E2EMTH_PASSALNG)
         con->useSCCP = TRUE;
   }

   if (!con->tCallCb->cfg.sidPresInd)
   {
      if (con->pduSp->m.initAddr.cgPtyNum.eh.pres)
      {
         if (con->tCallCb->cfg.incSidPresRes)
            con->pduSp->m.initAddr.cgPtyNum.presRest.val = PRESREST;
      }
      else
         {
            if (con->tCallCb->cfg.reqOpt)
            {
               /* Generate Info Request */
               /* prepare Pdu header */
               pduHdr.eh.pres      = PRSNT_NODEF;
               pduHdr.msgType.pres = PRSNT_NODEF;
               pduHdr.msgType.val  = (U8) M_INFOREQ;
   
               /* initialize Info Request */
               MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_INFOREQ,
                         NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                         con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   
               siInsCallRef(cir, &allPdus, pduHdr.msgType.val);
   
               /* set information request indicators */
               allPdus.m.infoReq.infoReqInd.cgPtyAdReqInd.pres = PRSNT_NODEF;
               allPdus.m.infoReq.infoReqInd.cgPtyAdReqInd.val  = 
                                                             CGPRTYADDREQ_REQ;
   
               /* Start T33 Timer */
               siStartConTmr(TMR_T33I, con, con->tCallCb);
   
               /* send allPdus */
               siGenPdu(con->mCallCb, &pduHdr, &allPdus, 
                        con->tCallCb->cfg.swtch, cir->opc, cir->cfg.intfId, 
                        cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                        siGetPriority(pduHdr.msgType.val, 
                        con->tCallCb->cfg.swtch), NULLP);
            }
         }
   }
   else
   {
      con->pduSp->m.initAddr.cgPtyNum.presRest.pres = PRSNT_NODEF;
      con->pduSp->m.initAddr.cgPtyNum.presRest.val  = PRESREST;
   }

   /* initialize siConEvnt */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_INIADDR, (U8) SI_CONREQ,
             (ElmtHdr *)con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);


   {
      switch (con->pduSp->m.initAddr.natConInd.contChkInd.val)
      {
         case CONTCHK_NOTREQ:
            SISTATECHNG(con->incC.conState , ST_WTFORACM);
            break;
         case CONTCHK_REQ:
         case CONTCHK_PREV:
            /* Start T8 Timer */
            siStartConTmr(TMR_T8, con, con->tCallCb);   
            SISTATECHNG(con->incC.conState , ST_WTFORCONTIN);
            break;
         /* Treat default value case as "continuity check not required" */
         default:
            SISTATECHNG(con->incC.conState , ST_WTFORACM);
            break;
      }
   }
  
   switch(con->tCallCb->cfg.swtch)
   {

#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
     case LSI_SW_ITU:
       if ((con->pduSp->m.initAddr.opFwdCalInd.eh.pres) &&
           (con->pduSp->m.initAddr.opFwdCalInd.simpleSegmInd.pres) && 
           (con->pduSp->m.initAddr.opFwdCalInd.simpleSegmInd.val
            == SSI_ADDSEGM))
       {
          /* start T36 Timer */
          siStartConTmr(TMR_T36I, con, con->tCallCb);
         
          con->incC.msgToSegm         = con->mCallCb->mfMsgCtl.mp;
          con->mCallCb->mfMsgCtl.mp   = NULLP;
          con->mCallCb->mfMsgCtl.uBuf = uBuf;  /* reattach uBuf */
          con->incC.eventType         = MI_INIADDR;
          siProcIncSegm               = TRUE;
          RETVALUE(ROK);
       }

      default:
         break;
   }

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitConInd(&con->tCallCb->pst, con->tCallCb->suId, NULLD, ref,
                 con->incC.cirId, &ev.m.siConEvnt, uBuf);
   RETVALUE(ROK);
} /* end of siIncE16S00 */


  
/*
*
*       Fun:   siIncE17S00
*
*       Desc:  Input: Release
*              State: Idle and waiting for IAM 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE17S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE17S00(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   SiCirCb   *cir;
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;
   Swtch     swtch;

   TRC2(siIncE17S00)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI168, (ErrVal) 0, 
                 "siIncE17S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   /* Generate Release Complete Message to Lower Layer */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELCOMP;

   uBuf  = con->mCallCb->mfMsgCtl.uBuf;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;
   switch (swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                   (ElmtHdr *)NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                   swtch, (U32) MF_ISUP);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI169, (ErrVal) 0, 
                 "siIncE17S00() Failed, invalid configuration switch");
         /* clear incoming connection */
         siClearIncCon(con);
         RETVALUE(ROK);
#endif
   }

   {
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) &con->incC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }

   }

   if (con->tCallCb)
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & INC))
            siRmvConTq(con, tmrNum);
      
      /* Generate Release Indication to Upper Layer */
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELSE, (U8) SI_RELREQ,
                (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
                con->tCallCb->cfg.swtch, (U32) MF_ISUP);
      /* change state */
      SISTATECHNG(con->incC.conState , ST_WTFORRELRSP);
      con->incC.relResp  = TRUE;
      con->mCallCb->mfMsgCtl.uBuf = NULLP;
      SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId,
                    con->suInstId, con->key.k1.spInstId, con->incC.cirId, 
                    &ev.m.siRelEvnt, uBuf);
   }
   else
   {
      siGenPdu(con->mCallCb, &pduHdr, &allPdus, swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_RELSE, swtch), NULLP);
      siClearIncCon(con);
   }
   RETVALUE(ROK);
} /* end of siIncE17S00 */

  
/*
*
*       Fun:   siIncE17SND
*
*       Desc:  Input: Release
*              State: Waitnig for COT through Wt for Rel Complete.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE17SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE17SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE17SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI170, (ErrVal) 0, 
                 "siIncE17SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
       SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI171, (ErrVal) 0, 
                 "siIncE17SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
           (con->timers[tmrNum].tmrEvnt == TMR_TCRA) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T34)))
         siRmvConTq(con, tmrNum);

   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELSE, (U8) SI_RELREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   /* change state */
   SISTATECHNG(con->incC.conState , ST_WTFORRELRSP);
   con->incC.relResp  = TRUE;

   {
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) &con->incC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }
   }
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, &ev.m.siRelEvnt,
                 uBuf);
   RETVALUE(ROK);
} /* end of siIncE17SND */

  
/*
*
*       Fun:   siIncE17S06
*
*       Desc:  Input: Release
*              State: Wait for release complete
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE17S06
(
SiCon *con 
)
#else
PRIVATE S16 siIncE17S06(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   S16       ret;
   SiAllSdus ev;
   U8        tmrNum;
   Buffer    *uBuf;
   Swtch     swtch;

   TRC2(siIncE17S06)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI172, (ErrVal) 0, 
                 "siIncE17S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif
   uBuf  = con->mCallCb->mfMsgCtl.uBuf;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;
   {
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */      
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->incC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) & con->incC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }      
      }
   }
   /* Generate Release Complete Message to Lower Layer */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELCOMP;

   switch (swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         {
            U8    onlyRlc;

            onlyRlc = FALSE;
            switch (swtch)
            {
               case LSI_SW_ITU:
#ifdef SS7_ITU97
               case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
              case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
              case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
               case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
                  onlyRlc = TRUE; /* just response a RLC */ 
                  break;

               default:
                  break;
            }
            if (onlyRlc == TRUE)
            {
               MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                         (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, 
                         (U8) PRSNT_DEF, swtch, (U32) MF_ISUP);
               
               siGenPdu(con->mCallCb, &pduHdr, &allPdus, swtch,
                        cir->opc, cir->cfg.intfId, 
                        cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                        siGetPriority(M_RELCOMP, swtch), NULLP);
               RETVALUE(ROK);
               
            }
         }
         /* Stop all Timers */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                (con->timers[tmrNum].tmrEvnt & INC))
               siRmvConTq(con, tmrNum);

         /* change state */
         SISTATECHNG(con->incC.conState , ST_IDLE);

         if ((con->tCallCb) && (con->incC.relResp))
         {
            /* Generate Release Confirmation to Upper Layer */
            MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
                      (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);

            con->mCallCb->mfMsgCtl.uBuf = NULLP;
            SiUiSitRelCfm(&con->tCallCb->pst, con->tCallCb->suId,
                          con->suInstId, con->key.k1.spInstId, 
                          con->incC.cirId, &ev.m.siRelEvnt, uBuf);
            con->incC.relResp = FALSE;
         }
         
         MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                   (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                   swtch, (U32) MF_ISUP);
         
         siGenPdu(con->mCallCb, &pduHdr, &allPdus, swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_RELSE, swtch), NULLP);
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
         /* clear incoming connection */
         siClearIncCon(con);
#ifdef ZI
         ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
         ziUpdPeer();
#endif
         break;

         
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI173, (ErrVal) 0, 
                 "siIncE17S06() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   RETVALUE(ROK);
} /* end of siIncE17S06 */

  
/*
*
*       Fun:   siIncE17S07
*
*       Desc:  Input: Release
*              State: Waiting for RelResp.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE17S07
(
SiCon *con 
)
#else
PRIVATE S16 siIncE17S07(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE17S07)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI174, (ErrVal) 0, 
                 "siIncE17S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI175, (ErrVal) 0, 
                 "siIncE17S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   /* ISUP should accept REL from peer node while in waiting for release
    * response from CC. ISUP should send release indication for the subsequent
    * reception of release message. This is happened because release 
    * indication primitive between the CC and ISUP got lost. And peer node 
    * resends the REL on the protocal timer expiry.  
    */
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELSE, (U8) SI_RELREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   con->incC.relResp  = TRUE;

   {
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->incC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) & con->incC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->incC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }
   }
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, &ev.m.siRelEvnt,
                 uBuf);
   RETVALUE(ROK);
} /* end of siIncE17S07 */


  
/*
*
*       Fun:   siIncE18S00
*
*       Desc:  Input: Release Complete
*              State: Idle 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE18S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE18S00(con)
SiCon *con;
#endif
{
   U8     tmrNum;

   TRC2(siIncE18S00)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI179, (ErrVal) 0, 
                 "siIncE18S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);

      RETVALUE(ROK);
   }
#endif
   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* clear incoming connection */
   siClearIncCon(con);
   RETVALUE(ROK);
} /* end of siIncE18S00 */

  
/*
*
*       Fun:   siIncE18S01
*
*       Desc:  Input: Release Complete
*              State: Waiting for COT
*
*       Ret:   ROK      - ok
*
*       Notes: 'uBuf' is not processed here because this function in turn 
*              calls siIncE18SND where it will be processed.
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE18S01
(
SiCon *con 
)
#else
PRIVATE S16 siIncE18S01(con)
SiCon *con;
#endif
{
   U8     tmrNum;

   TRC2(siIncE18S01)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI180, (ErrVal) 0, 
                 "siIncE18S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI181, (ErrVal) 0, 
                 "siIncE18S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* Generate Status Indication to Upper Layer */
   SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId,
                 con->suInstId, con->key.k1.spInstId, con->incC.cirId, FALSE,
                 SIT_STA_STPCONTIN, NULLP, NULLP);

   siIncE18SND(con);
   RETVALUE(ROK);
} /* end of siIncE18S01 */

  
/*
*
*       Fun:   siIncE18SND
*
*       Desc:  Input: Release Complete
*              State: Waiting for ACM through Suspended.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE18SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE18SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   SiAllPdus message;
   U8        tmrNum;
   Status    status;
   SiPduHdr  pduHdr;
   S16       ret;
   U16       ustaCause;
   Buffer    *uBuf;

   TRC2(siIncE18SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI182, (ErrVal) 0, 
                 "siIncE18SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI183, (ErrVal) 0, 
                 "siIncE18SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) ||
          (con->timers[tmrNum].tmrEvnt == TMR_TCRA)))
         siRmvConTq(con, tmrNum);

   /* change state */
   SISTATECHNG(con->incC.conState  , ST_WTFORRLCRRS);
   con->incC.relResp   = TRUE;

   /* Generate Release */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   switch (con->tCallCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         /* Generate Release Indication to Upper Layer */
         MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELCOMP, 
                   (U8)SI_RELREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* initialize Release */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELCOMP, (U8)MI_RELSE,
                   (ElmtHdr *)con->pduSp, (ElmtHdr *)&message, (U8)PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI184, (ErrVal) 0, 
                    "siIncE18SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* if cause not present, initialize */
   if (message.m.release.causeDgn.eh.pres == NOTPRSNT)
   {
      MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP, 
                 (ElmtHdr *) &message.m.release.causeDgn, &meCauseIndV, 
                 (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
      message.m.release.causeDgn.causeVal.pres = PRSNT_NODEF;
      message.m.release.causeDgn.causeVal.val = SIT_CCTMPFAIL;
      message.m.release.causeDgn.recommend.pres = NOTPRSNT;
   }

   if (ev.m.siRelEvnt.causeDgn.eh.pres == NOTPRSNT)
   {
      MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP,
                 (ElmtHdr *) &ev.m.siRelEvnt.causeDgn, &meCauseIndV,
                 (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   }
   ev.m.siRelEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.causeVal.val  = SIT_CCPROTERR;
   ev.m.siRelEvnt.causeDgn.cdeStand.pres = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.cdeStand.val  = SIT_CSTD_CCITT;
   ev.m.siRelEvnt.causeDgn.location.pres = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.location.val  = con->tCallCb->cfg.relLocation;

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, &ev.m.siRelEvnt, 
                 uBuf);
   {
      SChkRes(con->tCallCb->pst.region, con->tCallCb->pst.pool, &status);

      if (status < siCb.genCfg.poolTrUpper)
      {
         ustaCause = LSI_CAUSE_CONG_LVL1;
         message.m.release.auCongLvl.eh.pres = PRSNT_NODEF;
         message.m.release.auCongLvl.auCongLvl.pres = PRSNT_NODEF;
         if (status < siCb.genCfg.poolTrLower)
         {
            message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
            ustaCause = LSI_CAUSE_CONG_LVL2;
         }
         else
            message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;

#if (SI_LMINT3 || SMSI_LMINT3)
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                    LSI_USTA_DGNVAL_INTF, (PTR) &con->incC.cir->key.k3.intfId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, LSI_USTA_DGNVAL_NONE, NULLP);
         siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL,
                  LSI_EVENT_REMOTE, ustaCause, TRUE);
#endif
      }
   }
   /* build copy of a Release Message */
   if ((ret = siBldMsg(con->mCallCb, con->incC.cir->cfg.cic, &pduHdr, &message,
                       con->mCallCb->pst.region, con->mCallCb->pst.pool,
                       &con->incC.rel, con->tCallCb->cfg.swtch, 
                       NULLP)) != ROK)
      con->incC.rel = NULLP;

   /* Start T1 Timer */
   siStartConTmr(TMR_T1I, con, con->tCallCb);
   /* Start T5 Timer */
   siStartConTmr(TMR_T5I, con, con->tCallCb);
   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            con->incC.cir->opc, con->incC.cir->cfg.intfId, 
            con->incC.cir->phyDpc, TRUE,
            con->incC.cir->cfg.cic, con->lnkSel, 
            siGetPriority(pduHdr.msgType.val, 
               con->tCallCb->cfg.swtch), NULLP);

   RETVALUE(ROK);
} /* end of siIncE18SND */

  
/*
*
*       Fun:   siIncE18S06
*
*       Desc:  Input: Release Complete
*              State: Waiting for Release Complete.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE18S06
(
SiCon *con 
)
#else
PRIVATE S16 siIncE18S06(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;
   SiCirCb   *cir;
   Pst      *pst;
   SuId     suId;
   SiInstId suInstId;
   SiInstId spInstId;
   CirId    cirId;
   U8       relRsp;

   TRC2(siIncE18S06)

   cir = con->incC.cir;
   relRsp = FALSE;
   /* si006.220, ADDED: added the initialization */
   uBuf = NULLP;
   pst = NULLP;
   suId = 0;
   suInstId = 0;
   spInstId = 0;
   cirId = con->incC.cirId;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI185, (ErrVal) 0, 
                 "siIncE18S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);
   /* change state */
   SISTATECHNG(con->incC.conState , ST_IDLE);
/* si003.220 Modification. Modified code so that all the initializations
 * should be done after checking the related pointers.
 */
   if ((con->incC.relResp) && (con->tCallCb))
   { 
      uBuf = con->mCallCb->mfMsgCtl.uBuf;
      pst = &con->tCallCb->pst;
      suId = con->tCallCb->suId;
      suInstId = con->suInstId;
      spInstId = con->key.k1.spInstId;
      cirId = con->incC.cirId;
   
      switch (con->tCallCb->cfg.swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            /* Generate Release Confirmation to Upper Layer */
            MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELCOMP, 
                  (U8) SI_RELREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev,
                  (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

            SILOGERROR(ERRCLS_DEBUG, ESI186, (ErrVal) 0, 
                 "siIncE16S06() Failed, invalid configuration switch");
            RETVALUE(ROK);
#endif
      }

      con->mCallCb->mfMsgCtl.uBuf = NULLP;
#ifdef ZI
   ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
      relRsp = con->incC.relResp;
   }
   else
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                             "either incC.relrsp %d or tcallcb 0x%lx  zero\n",
                             con->incC.relResp, (U32 )con->tCallCb));
      SISNDOLDLSISTAIND(&siCb.init.lmPst, con->incC.cir->cfg.cirId, RLC_RCVD);
   }

#ifdef IW
   if ((con->contCrm & SI_REL_UPLW) && (con->tCallCb))
   {
      pst = &con->tCallCb->pst;
      suId = con->tCallCb->suId;
      suInstId = con->suInstId;
      spInstId = con->key.k1.spInstId;
      cirId = con->incC.cirId;
      SiUiSitStaInd(pst, suId, suInstId, spInstId, cirId,
                    TRUE, SIT_STA_RLCIND, NULLP, NULLP);
   }
#endif

   con->incC.relResp = FALSE;
   /* IDLE the call processing state */
   SISTATECHNG(cir->calProcStat, CALL_IDLE); 
   /* clear incoming connection */
   siClearIncCon(con);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   if (relRsp)
   {
      SiUiSitRelCfm(pst, suId, suInstId, spInstId, cirId, &ev.m.siRelEvnt,
               uBuf);
   }

   RETVALUE(ROK);
} /* end of siIncE18S06 */

  
/*
*
*       Fun:   siIncE18S08
*
*       Desc:  Input: Release Complete
*              State: Waiting for RLC and RelResp
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE18S08
(
SiCon *con 
)
#else
PRIVATE S16 siIncE18S08(con)
SiCon *con;
#endif
{
   U8     tmrNum;

   TRC2(siIncE18S08)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI187, (ErrVal) 0, 
                 "siIncE18S08() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI188, (ErrVal) 0, 
                 "siIncE18S08() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) ||
          (con->timers[tmrNum].tmrEvnt == TMR_TCRA)))
         siRmvConTq(con, tmrNum);
   
   SISNDOLDLSISTAIND(&siCb.init.lmPst, con->incC.cir->cfg.cirId, RLC_RCVD);

   /* change state */
   SISTATECHNG(con->incC.conState , ST_WTFORRELRSP);
   con->incC.relResp  = FALSE;

#ifdef IW
   if ((con->contCrm & SI_REL_UPLW) && (con->tCallCb))
   {
      SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId,
                    con->key.k1.spInstId, con->incC.cirId,
                    TRUE, SIT_STA_RLCIND, NULLP, NULLP);
   }
#endif
   RETVALUE(ROK);
} /* end of siIncE18S08 */


  
/*
*
*       Fun:   siIncE19S05
*
*       Desc:  Input: Resume
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE19S05
(
SiCon *con 
)
#else
PRIVATE S16 siIncE19S05(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE19S05)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI192, (ErrVal) 0, 
                 "siIncE19S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI193, (ErrVal) 0, 
                 "siIncE19S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   /* Stop Timers  T6 */
   siStopConTmr(con, TMR_T6I);

/* si039.220 : Timer T2 should be stopped. Otherwise timer T2 
               will timeout and release the call
*/ 
   /* Stop Timers  T2 */
   siStopConTmr(con, TMR_T2I);

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RESUME, (U8) SI_RESREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   con->incC.suspDir &= FROM_UPR;

   /* if appropriate, change state to answered */
   if (!con->incC.suspDir)
      SISTATECHNG(con->incC.conState , ST_ANSWRD);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitResmInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->incC.cirId, &ev.m.siResmEvnt,
                  uBuf);

   RETVALUE(ROK);
} /* end of siIncE19S05 */

  
/*
*
*       Fun:   siIncE20S01
*
*       Desc:  Input: Subsequent Address
*              State: Waiting for Continuity
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE20S01
(
SiCon *con 
)
#else
PRIVATE S16 siIncE20S01(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE20S01)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI194, (ErrVal) 0, 
                 "siIncE20S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI195, (ErrVal) 0, 
                 "siIncE20S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif
   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_SUBADDR, (U8) SI_CNSTREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->incC.cirId, &ev.m.siCnStEvnt, 
                  SUBSADDR, uBuf);

   RETVALUE(ROK);
} /* end of siIncE20S01 */

  
/*
*
*       Fun:   siIncE21S04
*
*       Desc:  Input: Suspend
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE21S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE21S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE21S04)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI196, (ErrVal) 0, 
                 "siIncE21S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI197, (ErrVal) 0, 
                 "siIncE21S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

/* si026.220: Modification - modified code so that T6 or T2 timer is
 * started according to the suspend resume indication value.
 */
   /* if controlling exchange */
   if (!con->outC.conPrcs)
   {
      if (con->pduSp->m.suspend.suspResInd.susResInd.val == SR_NETINIT)
         /* Start T6 Timer */
         siStartConTmr(TMR_T6I, con, con->tCallCb);
      else
         /* Start T2 Timer */
         siStartConTmr(TMR_T2I, con, con->tCallCb);
   }

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_SUSPND, (U8) SI_SUSPREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   con->incC.suspDir |= FROM_LWR;
   /* change state to suspended */
   SISTATECHNG(con->incC.conState , ST_SUSP);

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitSuspInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->incC.cirId, &ev.m.siSuspEvnt, 
                  uBuf);

   RETVALUE(ROK);
} /* end of siIncE21S04 */

  
/*
*
*       Fun:   siIncE21S05
*
*       Desc:  Input: Suspend
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE21S05
(
SiCon *con 
)
#else
PRIVATE S16 siIncE21S05(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE21S05)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI198, (ErrVal) 0, 
                 "siIncE21S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI199, (ErrVal) 0, 
                 "siIncE21S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_SUSPND, (U8) SI_SUSPREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   if (!(con->incC.suspDir & FROM_LWR))
      con->incC.suspDir |= FROM_LWR;

   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitSuspInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->incC.cirId, &ev.m.siSuspEvnt, 
                  uBuf);

   RETVALUE(ROK);
} /* end of siIncE21S05 */

  
/*
*
*       Fun:   siIncE22SND
*
*       Desc:  Input: User to User 
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE22SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE22SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE22SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI200, (ErrVal) 0, 
                 "siIncE22SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI201, (ErrVal) 0, 
                 "siIncE22SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

#endif

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_USR2USR, (U8) SI_INFREQ,
            (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitDatInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->incC.cirId, &ev.m.siInfoEvnt, 
                 uBuf);

   RETVALUE(ROK);
} /* end of siIncE22SND */


  
/*
*
*       Fun:   siIncE23S00
*
*       Desc:  Input: Circuit Reservation
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PUBLIC S16 siIncE23S00
(
SiCon *con 
)
#else
PUBLIC S16 siIncE23S00(con)
SiCon *con;
#endif
{

   TRC2(siIncE23S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI202, (ErrVal) 0, 
                 "siIncE23S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   /* for all variatns except ansi 92 this message is invalid */
   if ((con->incC.cir->pIntfCb->cfg.swtch != LSI_SW_ANS92) && 
       (con->incC.cir->pIntfCb->cfg.swtch != LSI_SW_ANS95) &&
       (con->incC.cir->pIntfCb->cfg.swtch != LSI_SW_BELL))
   {
      siIncUNXMSG(con);
      RETVALUE (ROK);
   }

   RETVALUE(ROK);
} /* end of siIncE23S00 */

  
/*
*
*       Fun:   siIncE26S02
*
*       Desc:  Input: Connect Response
*              State: Waiting for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE26S02
(
SiCon *con 
)
#else
PRIVATE S16 siIncE26S02(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE26S02)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI207, (ErrVal) 0, 
                 "siIncE26S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI208, (ErrVal) 0, 
                 "siIncE26S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI209, (ErrVal) 0, 
                 "siIncE26S02() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->tCallCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         /* Generate Connect */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CONNCT;

         /* initialize Connect */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CONRSP, 
                   (U8) MI_CONNCT, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* change state to answered */
         SISTATECHNG(con->incC.conState , ST_ANSWRD);
         SISTATECHNG(con->incC.cir->calProcStat, INCBUSY);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI210, (ErrVal) 0, 
                 "siIncE26S02() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }
     
   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_ANSWER, con->tCallCb->cfg.swtch), uBuf);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* this is a non-single rate connection */
      if (siChgMRateState(cir, INCBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif
#ifdef ZI
   ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) con->incC.cir);
   ziUpdPeer(); 
#endif

   RETVALUE(ROK);
} /* end of siIncE26S02 */

  
/*
*
*       Fun:   siIncE26S03
*
*       Desc:  Input: Connect Response
*              State: Waiting for Answer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE26S03
(
SiCon *con 
)
#else
PRIVATE S16 siIncE26S03(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE26S03)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI211, (ErrVal) 0, 
                 "siIncE26S03() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI212, (ErrVal) 0, 
                 "siIncE26S03() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI213, (ErrVal) 0, 
                 "siIncE26S03() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   /* Generate Connect */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_ANSWER;

   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   /* initialize Connect */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CONRSP, (U8) MI_ANSWER,
            (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   SISTATECHNG(con->incC.conState, ST_ANSWRD);
   SISTATECHNG(con->incC.cir->calProcStat, INCBUSY);
   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_ANSWER, con->tCallCb->cfg.swtch), uBuf);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      /* this is a non-single rate connection */
      if (siChgMRateState(cir, INCBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif

#ifdef ZI
   if (ziCb.updateOption == ZI_UPD_UNANSWRD)
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_UPD_REQ, (PTR) con);
   else
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) con->incC.cir);
   ziUpdPeer(); 
#endif

   RETVALUE(ROK);
} /* end of siIncE26S03 */

  
/*
*
*       Fun:   siIncE27S01
*
*       Desc:  Input: Connection Progress Status request
*              State: Waiting for continuity
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S01
(
SiCon *con 
)
#else
PRIVATE S16 siIncE27S01(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   U8        tmrNum;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S01)
   UNUSED(ev);

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI215, (ErrVal) 0, 
                 "siIncE27S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI216, (ErrVal) 0, 
                 "siIncE27S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI217, (ErrVal) 0, 
                 "siIncE27S01() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   if (con->sCallCb == NULLP)
      con->exchCalRef = FALSE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;
  
   switch (con->evntType)
   {
/* si029.220: Modification - changed code so that CHARGE is also
 * applicable to INDIA variant */
#if (SS7_SINGTEL || SS7_INDIA)
      case CHARGE:
         if (con->tCallCb->cfg.swtch != LSI_SW_SINGTEL 
             && con->tCallCb->cfg.swtch != LSI_SW_INDIA)
         {
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Chagre Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CHARGE;

         /* initialize Charge message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                  (U8) MI_CHARGE, (ElmtHdr *) con->sduSp, 
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                  con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Addition - added SS7_SINGTEL flag */
#endif /* SS7_SINGTEL || SS7_INDIA */
      case INFORMATREQ:

         /* if T33 running, ignore */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (con->timers[tmrNum].tmrEvnt == TMR_T33I)
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "T33I running ignoring the event\n"));  
               RETVALUE(ROK);
            }

         /* Generate Info Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFOREQ;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                  (U8) MI_INFOREQ, (ElmtHdr *) con->sduSp, 
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                  con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* Start T33 Timer */
         siStartConTmr(TMR_T33I, con, con->tCallCb);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

      case INFORMATION:
         /* Generate Info Message */

         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;
         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8)MI_INFORMTN, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);
         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case IDENTREQ:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "swtch != ETSI/ITU/ITU97/ITU2000/RUSS2000/ETSIv3 for IDENTREQ event \
             therefore dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Request Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTREQ;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_IDENTREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *)
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch,
                   (U32) MF_ISUP);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(M_IDENTREQ, con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Modification - added SS7_INDIA flag */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3 or itu97/200, RUSS2000 or India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                       LSI_USTA_DGNVAL_SWTCH, (PTR) &con->tCallCb->cfg.swtch, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) &con->evntType, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        con->incC.cirId, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
   }

   RETVALUE(ROK);
} /* end of siIncE27S01 */

  
/*
*
*       Fun:   siIncE27S02
*
*       Desc:  Input: Connection Progress Status request
*              State: Waiting for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S02
(
SiCon *con 
)
#else
PRIVATE S16 siIncE27S02(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S02)
   UNUSED(ev);

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI219, (ErrVal) 0, 
                 "siIncE27S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI220, (ErrVal) 0, 
                 "siIncE27S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI221, (ErrVal) 0, 
                 "siIncE27S02() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   if (con->sCallCb == NULLP)
      con->exchCalRef = FALSE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->evntType)
   {
/* si029.220: Modification - added SS7_INDIA for charge info message */ 
#if (SS7_SINGTEL || SS7_INDIA)
      case CHARGE:
         if (con->tCallCb->cfg.swtch != LSI_SW_SINGTEL 
             && con->tCallCb->cfg.swtch != LSI_SW_INDIA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not SINGTEL or INDIA for CHARGE\n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Charge Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CHARGE;

         /* initialize Charge message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CHARGE, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Addition - added SINGTEL flag */
#endif /* SS7_SINGTEL || SS7_INDIA */

      case PROGRESS:
         /* Generate Progress */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLPROG;

         /* initialize ACM */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLPROG, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;


      case ADDRCMPLT:
         /* Generate ACM */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_ADDCOMP;

         /* initialize ACM */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_ADDCOMP, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         SISTATECHNG(con->incC.conState , ST_WTFORANSWR);

         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);

#ifdef ZI
         if (ziCb.updateOption == ZI_UPD_UNANSWRD)
         {
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
            ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
            ziUpdPeer();
         }
#endif
         break;

      case INFORMATREQ:
         /* if T33 running, ignore */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (con->timers[tmrNum].tmrEvnt == TMR_T33I)
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                 "T33I running ignoring the event\n"));  
               RETVALUE(ROK);
            } 

         /* Generate Info Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFOREQ;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_INFOREQ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* Start T33 Timer */
         siStartConTmr(TMR_T33I, con, con->tCallCb);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

      case INFORMATION:
         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;
         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8)MI_INFORMTN, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);
         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN,
                  con->tCallCb->cfg.swtch), uBuf);
         break;

 
      case EXIT:
         /* sends EXIT on demand, for interworking cases */
 
         /* Generate EXM */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_EXIT;
 
         switch (con->tCallCb->cfg.swtch)
         {
#ifdef SS7_ITU97
            case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
            case LSI_SW_ITU:
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "EXIT msg rcvd for non-ansi variants.Dumping\n"));  
               /* Generate Alarm to Layer management */
               siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                             LSI_USTA_DGNVAL_SWTCH, 
                             (PTR) &con->tCallCb->cfg.swtch, 
                             LSI_USTA_DGNVAL_EVENT, (PTR) &con->evntType, 
                             LSI_USTA_DGNVAL_NONE, NULLP);
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                              LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                              con->incC.cirId, SI_ALRM_INV_EVENT);
               RETVALUE(RFAILED);
 
#if (ERRCLASS & ERRCLS_DEBUG)
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

               SILOGERROR(ERRCLS_DEBUG, ESI224, (ErrVal) 0,
                        "siIncE27S02() Failed, invalid configuration switch");
               
               RETVALUE(ROK);
#endif
         }
 
         /* si011.220 - Modified: included SS7_BELL compile time flag */   
         break;
      case IDENTREQ:
         /* si029.220: Modification - added SS7_INDIA flag */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "swtch != ETSI/ITU/ETSIv3/ITU97/ITU2000/RUSS2000/INDIA for IDENTREQ event \
             therefore dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Request Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTREQ;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_IDENTREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *)
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch,
                   (U32) MF_ISUP);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(M_IDENTREQ, con->tCallCb->cfg.swtch), uBuf);
         break;
         
/* si029.220: Modification - added SS7_INDIA flag */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3, not itu 97 and not India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
         
      case APPTRANSPORT:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3/itu97/RUSS2000/ITU2000/India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Application Transport Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_APPTRAN;
 
         /* initialize Application Transport Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_APPTRAN, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_APPTRAN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                        LSI_USTA_DGNVAL_SWTCH, (PTR) &con->tCallCb->cfg.swtch, 
                        LSI_USTA_DGNVAL_EVENT, (PTR) &con->evntType, 
                        LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        con->incC.cirId, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of siIncE27S02 */

  
/*
*
*       Fun:   siIncE27S03
*
*       Desc:  Input: Connection Progress request
*              State: Waiting for Answer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S03
(
SiCon *con 
)
#else
PRIVATE S16 siIncE27S03(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiAllSdus ev;
   U8        tmrNum;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S03)
   UNUSED(ev);

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI225, (ErrVal) 0, 
                 "siIncE27S03() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI226, (ErrVal) 0, 
                 "siIncE27S03() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI227, (ErrVal) 0, 
                 "siIncE27S03() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->evntType)
   {

      case ADDRCMPLT:
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_ADDCOMP;

         /* initialize ACM */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_ADDCOMP, (ElmtHdr *) con->sduSp, (ElmtHdr *)
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch,
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* change state to Answered */
         SISTATECHNG(con->incC.conState , ST_WTFORANSWR);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(pduHdr.msgType.val,
                  con->tCallCb->cfg.swtch), uBuf);

         break;

      case PROGRESS:
         /* Generate Progress */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLPROG;

         /* initialize ACM */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLPROG, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

      case INFORMATREQ:
         /* if T33 running, ignore */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (con->timers[tmrNum].tmrEvnt == TMR_T33I)
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                 "T33I running ignoring the event\n"));  
               RETVALUE(ROK);
            } 
         /* Generate Info Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFOREQ;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_INFOREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* Start T33 Timer */
         siStartConTmr(TMR_T33I, con, con->tCallCb);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;
      
      case INFORMATION:
         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;
         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8)MI_INFORMTN, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);
         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN,
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case NETRESMGT:
         /* si029.220: Addition - added switchh INDIA */
         if ((con->tCallCb->cfg.swtch == LSI_SW_ITU) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSI) ||
             (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
         {
            /* Generate Network Resource Management */
            /* prepare Pdu header */
            pduHdr.eh.pres      = PRSNT_NODEF;
            pduHdr.msgType.pres = PRSNT_NODEF;
            pduHdr.msgType.val  = (U8) M_NETRESMGT;
            
            /* initialize Info Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                      (U8) MI_NETRESMGT, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                      &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                      (U32) MF_ISUP);
           
            /* send message */
            siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                     cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                     siGetPriority(pduHdr.msgType.val, 
                        con->tCallCb->cfg.swtch), uBuf);
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not itu/etsi for netresmgt event\n"));  
         } 
         break;

#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case LOOPPRVNT:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch is not ETSI or ITU97/2000, RUSS2000 for LOOPPRVNT\n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* si024.220: Modification - All parameters for LOP are optional,
          * should not drop the message in any case */
         if (con->sduSp->m.siCnStEvnt.loopPrvntInd.eh.pres != NOTPRSNT) 
         {
            /* check if loop prevention response */
            if (con->sduSp->m.siCnStEvnt.loopPrvntInd.loopPrvntType.val)
            {
               /* Turn off ECT timer */
               con->callTRef.tRefUsed = FALSE;
            }
            else /* loop prevention request */
            {
               if (con->sduSp->m.siCnStEvnt.calTrnsfrRef.eh.pres != NOTPRSNT)
               {
                  /* save transfer reference */
                  con->callTRef.tRefUsed = TRUE;
                  con->callTRef.tRefVal = 
                            con->sduSp->m.siCnStEvnt.calTrnsfrRef.callTrnsfr.val;
                  /* start ECT timer */
                  siStartConTmr(TMR_TECT, con, con->tCallCb);
               }
            }
         }

         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_LOOPPRVNT;

         /* initialize loop prevention message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_LOOPPRVNT, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

      case IDENTREQ:
         /* si029.220: Modification - added switch INDIA */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "swtch != ETSI/ITU/ETSIv3/ITU97/INDIA for IDENTREQ event \
             therefore dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Request Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTREQ;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_IDENTREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *)
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch,
                   (U32) MF_ISUP);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(M_IDENTREQ, con->tCallCb->cfg.swtch), uBuf);
         break;
/* si029.220: Modification - added switch INDIA */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3, not itu97 and not India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case APPTRANSPORT:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3/itu97/India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Application Transport Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_APPTRAN;
 
         /* initialize Application Transport Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_APPTRAN, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_APPTRAN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         siDropMsg(uBuf);
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->incC.cirId, 
                        LSI_USTA_DGNVAL_SWTCH, 
                        (PTR) & con->tCallCb->cfg.swtch, 
                        LSI_USTA_DGNVAL_EVENT, (PTR) & con->evntType, 
                        LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        con->incC.cirId, SI_ALRM_INV_EVENT);
         break;
   }
   RETVALUE(ROK);
} /* end of siIncE27S03 */

  
/*
*
*       Fun:   siIncE27S04
*
*       Desc:  Input: Connection Progress Status request
*              State: ANSWRD
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE27S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S04)
   UNUSED(ev);

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI230, (ErrVal) 0, 
                 "siIncE27S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI231, (ErrVal) 0, 
                 "siIncE27S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI232, (ErrVal) 0, 
                 "siIncE27S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   if (((con->sCallCb = siGetLwrSCbPtr(cir)) != NULLP) &&
       (con->sCallCb->state == SI_BND))
      con->exchCalRef = TRUE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->evntType)
   {

      case INFORMATREQ:
         siIncUNXEVT(con);
         RETVALUE(ROK);

      case INFORMATION:
         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8)SI_CNSTREQ, 
                   (U8)MI_INFORMTN, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         switch (con->tCallCb->cfg.swtch)
         {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_CHINA)
               if (con->exchCalRef == TRUE)
               {
                  message.m.info.callRefA.eh.pres     = PRSNT_NODEF;
                  message.m.info.callRefA.callId.pres = PRSNT_NODEF;
                  message.m.info.callRefA.pntCde.pres = PRSNT_NODEF;
                  if (con->outC.dCallRef)
                  {
                     message.m.info.callRefA.callId.val = con->outC.dCallRef;
                     message.m.info.callRefA.pntCde.val = con->outC.phyDpc;
                  }
                  else
                  {
                     message.m.info.callRefA.callId.val = con->key.k1.spInstId;
                     message.m.info.callRefA.pntCde.val = cir->opc;
                  }
               }
               else
                  message.m.info.callRefA.eh.pres = NOTPRSNT;
               break;
#endif
#ifdef SS7_ITU97
            case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
            case LSI_SW_ITU:
               if (con->exchCalRef == TRUE)
               {
                  message.m.info.callRef.eh.pres     = PRSNT_NODEF;
                  message.m.info.callRef.callId.pres = PRSNT_NODEF;
                  message.m.info.callRef.pntCde.pres = PRSNT_NODEF;
                  if (con->outC.dCallRef)
                  {
                     message.m.info.callRef.callId.val = con->outC.dCallRef;
                     message.m.info.callRef.pntCde.val = (S16)con->outC.phyDpc;
                  }
                  else
                  {
                     message.m.info.callRef.callId.val = con->key.k1.spInstId;
                     message.m.info.callRef.pntCde.val = (S16) cir->opc;
                  }
               }
               else
                  message.m.info.callRef.eh.pres       = NOTPRSNT;
               break;

#if (ERRCLASS & ERRCLS_DEBUG)
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

               SILOGERROR(ERRCLS_DEBUG, ESI233, (ErrVal) 0, 
                        "siOutE27S01() Failed, invalid configuration switch");
               RETVALUE(ROK);
#endif
         }

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_INFORMTN, con->tCallCb->cfg.swtch), uBuf);
         break;

      case MODIFY:
/* si034.220 : Drop Msg */	 
#ifdef SS7_CHINA
         if (con->tCallCb->cfg.swtch == LSI_SW_CHINA)
         {
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
#endif
         /* Generate Modification Request */
         /* prepare Pdu header            */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLMODREQ;

         /* initialize Modification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLMODREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

          /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* set call modification flag */
         con->incC.cllModProc = TRUE;

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
              cir->opc, cir->cfg.intfId, 
              cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_CALLMODREQ, con->tCallCb->cfg.swtch), uBuf);
         break;

      case MODCMPLT:
      case MODREJ:
/* si034.220: Modification - Drop CMRJ & CMC msgs in CHINA */
#ifdef SS7_CHINA
         if (con->tCallCb->cfg.swtch == LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "swtch==LSI_SW_CHINA for MODREJ/CMPLT event therefore dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
#endif

         /* prepare Pdu header */
         pduHdr.eh.pres       = PRSNT_NODEF;
         pduHdr.msgType.pres  = PRSNT_NODEF;
         con->incC.cllModProc = FALSE;
         if (con->evntType == MODCMPLT)
         {
            pduHdr.msgType.val = (U8) M_CALLMODCOMP;
            /* initialize Modification Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                    (U8) MI_CALLMODCOMP, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                    &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                    (U32) MF_ISUP);

            /* if required, insert call reference */
            siInsCallRef(cir, &message, pduHdr.msgType.val);
         }
         else
         {
            pduHdr.msgType.val = (U8) M_CALLMODREJ;
            /* initialize Modification Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                    (U8) MI_CALLMODREJ, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                    &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                    (U32) MF_ISUP);

            /* if required, insert call reference */
            siInsCallRef(cir, &message, pduHdr.msgType.val);
         }
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_CALLMODREJ, con->tCallCb->cfg.swtch), uBuf);
         break;

      case IDENTREQ:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "swtch != LSI_SW_ETSI/ITU/INDIA for IDENTREQ, therefore dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Request Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTREQ;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_IDENTREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_IDENTREQ, con->tCallCb->cfg.swtch), uBuf);
         break;

      case NETRESMGT:
         /* si029.220: Addition - added INDIA switch */
         if ((con->tCallCb->cfg.swtch == LSI_SW_ITU) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSI) ||
             (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
         {
            /* Generate Network Resource Management */
            /* prepare Pdu header */
            pduHdr.eh.pres      = PRSNT_NODEF;
            pduHdr.msgType.pres = PRSNT_NODEF;
            pduHdr.msgType.val  = (U8) M_NETRESMGT;
            
            /* initialize Info Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                      (U8) MI_NETRESMGT, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                      &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                      (U32) MF_ISUP);
            
            /* send message */
            siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                 cir->opc, cir->cfg.intfId, 
                 cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                 siGetPriority(M_NETRESMGT, con->tCallCb->cfg.swtch), uBuf);
            break;
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch neither itu nor etsi nor India for NETRESMGT\n"));  
         } 

#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case LOOPPRVNT:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
              "swtch != ETSI/ITU97/ETSIV3 for LOOPPRVNT event, dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* si024.220: Modification - All parameters for LOP are opotional,
          * should not drop the message in any case */
         if (con->sduSp->m.siCnStEvnt.loopPrvntInd.eh.pres != NOTPRSNT) 
         {
            /* check if loop prevention response */
            if (con->sduSp->m.siCnStEvnt.loopPrvntInd.loopPrvntType.val)
            {
               /* Turn off ECT timer */
               con->callTRef.tRefUsed = FALSE;
            }
            else /* loop prevention request */
            {
               if (con->sduSp->m.siCnStEvnt.calTrnsfrRef.eh.pres != NOTPRSNT)
               {
                  /* save transfer reference */
                  con->callTRef.tRefUsed = TRUE;
                  con->callTRef.tRefVal = 
                            con->sduSp->m.siCnStEvnt.calTrnsfrRef.callTrnsfr.val;
                  /* start ECT timer */
                  siStartConTmr(TMR_TECT, con, con->tCallCb);
               }
            }
         }

         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_LOOPPRVNT;
         /* initialize loop prevention message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                  (U8) MI_LOOPPRVNT, (ElmtHdr *) con->sduSp, 
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                  con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, 
                 cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                 siGetPriority(M_LOOPPRVNT, con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */


      case PROGRESS:
         /* Generate Progress */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLPROG;
         /* initialize CPG */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLPROG, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_CALLPROG, con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3 and not itu97 and not India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case APPTRANSPORT:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3/itu97/India\n"));  

            siIncUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Application Transport Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_APPTRAN;
 
         /* initialize Application Transport Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_APPTRAN, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_APPTRAN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */

/* si034.220: Modification - added CHINA switch */
#if SS7_CHINA
      case METPULSE:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not CHINA for METPULSE\n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Metering Pulse Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_METPULSE;

         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_METPULSE, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;
      case CLGPTCLR:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not CHINA for CLGPTCLR\n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Calling Party Clear Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CLGPTYCLR;
         
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_CLGPTYCLR, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
        
        /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;
      case OPERATOR:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not CHINA for OPERATOR\n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Operator Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_OPERATOR;

        MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_OPERATOR, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(pduHdr.msgType.val, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* if SS7_CHINA */
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->incC.cirId, 
                       LSI_USTA_DGNVAL_SWTCH, 
                       (PTR) & con->tCallCb->cfg.swtch, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) & con->evntType, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                        con->incC.cirId, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of siIncE27S04 */


  
/*
*
*       Fun:   siIncE27S05
*
*       Desc:  Input: Connection Progress Status request
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S05
(
SiCon *con
)
#else
PRIVATE S16 siIncE27S05(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S05)
   UNUSED(ev);

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI236, (ErrVal) 0,
                 "siIncE27S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI237, (ErrVal) 0,
                 "siIncE27S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI238, (ErrVal) 0,
                 "siIncE27S05() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   if (con->sCallCb == NULLP)
      con->exchCalRef = FALSE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->evntType)
   {

      case INFORMATION:

         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8)MI_INFORMTN, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN,
                  con->tCallCb->cfg.swtch), uBuf);

         break;

/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "swtch not etsiV3 or iru97 or India therefore event dumped\n"));
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         
         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                  (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
#endif

      default:
         RETVALUE(siIncUNXEVT(con));
   }

   RETVALUE(ROK);
} /* end of siIncE27S05 */

  
/*
*
*       Fun:   siIncE27S07
*
*       Desc:  Input: Connection Progress Status request
*              State: waiting for release response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE27S07
(
SiCon *con 
)
#else
PRIVATE S16 siIncE27S07(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE27S07)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI239, (ErrVal) 0, 
                 "siIncE27S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI240, (ErrVal) 0, 
                 "siIncE27S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI241, (ErrVal) 0, 
                 "siIncE27S07() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   if (((con->sCallCb = siGetLwrSCbPtr(cir)) != NULLP) &&
               (con->sCallCb->state == SI_BND))
      con->exchCalRef = TRUE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->evntType)
   {

      case IDENTREQ:
         /* si029.220: Addition - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch !itu/etsi/India for IDENTREQ \n"));  
            siIncUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Request Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTREQ;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_IDENTREQ, (ElmtHdr *) con->sduSp, (ElmtHdr *) 
                   &message, (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_IDENTREQ, con->tCallCb->cfg.swtch), uBuf);
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         siIncUNXEVT(con);
         break;
   }
   RETVALUE(ROK);
} /* end of siIncE27S07 */

  
/*
*
*       Fun:   siIncE28SND
*
*       Desc:  Input: Release Request
*              State: Waiting for COT through suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE28SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE28SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   Status    status;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   U8        tmrNum;
   Buffer    *uBuf;
   SiIntfCb   *siIntfCb;
   U16       ustaCause;

   TRC2(siIncE28SND)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI242, (ErrVal) 0, 
                 "siIncE28SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI243, (ErrVal) 0, 
                 "siIncE28SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI244, (ErrVal) 0, 
                 "siIncE28SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   
   /* Stop all other Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) || 
          (con->timers[tmrNum].tmrEvnt == TMR_T8)))
         siRmvConTq(con, tmrNum);
      
   /* Generate Release */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;
   /* initialize Release */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RELREQ, (U8) MI_RELSE,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* change state */
   SISTATECHNG(con->incC.conState , ST_WTFORRELCMP);
   con->incC.relResp  = TRUE;

   switch (con->tCallCb->cfg.swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         SChkRes(con->tCallCb->pst.region, con->tCallCb->pst.pool, &status);
         if (status < siCb.genCfg.poolTrUpper)
         {
            ustaCause = LSI_CAUSE_CONG_LVL1;
            /* check if congestion level param is already present,
             * if no, then prepare it. Otherwise, pass the param.
             */
            if (!message.m.release.auCongLvl.eh.pres)
            {
               message.m.release.auCongLvl.eh.pres        = PRSNT_NODEF;
               message.m.release.auCongLvl.auCongLvl.pres = PRSNT_NODEF;
               if (status < siCb.genCfg.poolTrLower)
               {
                  message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
                  ustaCause = LSI_CAUSE_CONG_LVL2;
               }
               else
                  message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;
            }
            else
               if (status < siCb.genCfg.poolTrLower)
                  ustaCause = LSI_CAUSE_CONG_LVL2;
#if (SI_LMINT3 || SMSI_LMINT3)
            siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->incC.cirId, 
                          LSI_USTA_DGNVAL_INTF, 
                          (PTR) &con->incC.cir->key.k3.intfId, 
                          LSI_USTA_DGNVAL_NONE, NULLP, 
                          LSI_USTA_DGNVAL_NONE, NULLP);
            siGenAlarmNew(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                          LSI_EVENT_REMOTE, ustaCause, TRUE);
#endif
         }
         break;

      default:
         break;
   }
   
   /* build copy of a Release Message */
   if ((ret = siBldMsg(con->mCallCb, con->incC.cir->cfg.cic, &pduHdr, 
                       &message, con->mCallCb->pst.region, 
                       con->mCallCb->pst.pool, &con->incC.rel, 
                       con->tCallCb->cfg.swtch, uBuf)) != ROK)
      con->incC.rel = NULLP;

   /* Start T1 Timer */
   siStartConTmr(TMR_T1I, con, con->tCallCb);
   /* Start T5 Timer */
   siStartConTmr(TMR_T5I, con, con->tCallCb);

   /* circuit is PAUSEd. set 'toBeRelsd' flag.
    * call will be released when MTP-3 link RESUMEs
    */
   siIntfCb = cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "siFindIntf failed for intfId %ld\n", cir->key.k3.intfId));  
      SILOGERROR(ERRCLS_DEBUG, ESI245, (ErrVal) cir->key.k3.intfId, 
                 "siIncE28SND() Failed, intf control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (siIntfCb->state == SI_INTF_UNAVAIL)) 
      con->incC.toBeRelsd = TRUE;
   else
      /* send message */
      siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_RELSE, con->tCallCb->cfg.swtch), uBuf);

   RETVALUE(ROK);
} /* end of siIncE28SND */


/*
*
*       Fun:   siIncE28S07
*
*       Desc:  Process release request when waiting for release response
*              
*       Ret:   ROK - ok; RFAILED - failed;
*
*       Notes: none
*
*       File:  ci_bdy2.c
*
*/
#ifdef ANSI
PRIVATE S16 siIncE28S07
(
SiCon *con
)
#else
PRIVATE S16 siIncE28S07 (con)
SiCon *con;
#endif
{
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   SiAllSdus ev;
   SiCirCb   *cir;
   SiIntfCb   *intfCb;
   S16       ret;
   U8        tmrNum;
   Swtch     swtch;

   TRC2(siIncE28S07)

   cir = con->incC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI246, (ErrVal) 0,
                 "siOutE28S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI247, (ErrVal) 0,
                 "siOutE28S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   /* we don't care about 'uBuf' here */
   siDropMsg(con->mCallCb->mfMsgCtl.uBuf);
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;

   /* don't remove the connection block until MTP-RESUME is received */
   if ((intfCb = con->incC.cir->pIntfCb) == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "Interface control block not found for intfId %ld\n",
           cir->key.k3.intfId));  
#if (ERRCLASS & ERRCLS_DEBUG)
      SILOGERROR(ERRCLS_DEBUG, ESI248, (ErrVal) cir->key.k3.intfId,
         "siIncE29S07() Failed, intf control block not found ");
#endif
      RETVALUE(RFAILED);
   }

   if (((intfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (intfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (con->incC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((con->timers[tmrNum].tmrEvnt & INC) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T34)))
            siRmvConTq(con, tmrNum);

      SISTATECHNG(con->incC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   else
   {
      /* stop all the timers in incoming half of connection */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      {
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
            (con->timers[tmrNum].tmrEvnt & OUTTYPE) )
            siRmvConTq(con, tmrNum);
      }

      /* Generate Release Complete Message to Lower Layer */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_RELCOMP;

      switch (swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                     (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                     swtch, (U32) MF_ISUP);
            
            siGenPdu(con->mCallCb, &pduHdr, &allPdus, swtch,
                 cir->opc, cir->cfg.intfId, 
                 cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                 siGetPriority(M_RELCOMP, swtch), NULLP);

            /* change state */
            SISTATECHNG(con->incC.conState , ST_IDLE);

            if ((con->tCallCb) && (con->incC.relResp))
            {
               /* Generate Release Confirmation to Upper Layer */
               MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
                        (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                        con->tCallCb->cfg.swtch, (U32) MF_ISUP);

               SiUiSitRelCfm(&con->tCallCb->pst, con->tCallCb->suId,
                           con->suInstId, con->key.k1.spInstId, 
                           con->incC.cirId, &ev.m.siRelEvnt, NULLP);

               con->incC.relResp = FALSE;
            }
#ifdef ZI
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
            
            /* clear incoming connection */
            siClearIncCon(con);
#ifdef ZI
            ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
            ziUpdPeer();
#endif
            break;
            
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf, "invalid switch %d\n",
                  swtch));  

            SILOGERROR(ERRCLS_DEBUG, ESI249, (ErrVal) 0, 
                     "siIncE28S07() Failed, invalid configuration switch");
            RETVALUE(ROK);
#endif
      }
   }

   RETVALUE(ROK);
} /* siIncE28S07 */

  
/*
*
*       Fun:   siIncE29S00
*
*       Desc:  Input: Release Response
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE29S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE29S00(con)
SiCon *con;
#endif
{
   U8     tmrNum;
   Buffer *uBuf;
   SiIntfCb *siIntfCb;

   TRC2(siIncE29S00)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI250, (ErrVal) 0, 
                 "siIncE29S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI251, (ErrVal) 0, 
                 "siIncE29S00() Failed, pointer to upper SAP missing");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   siIntfCb = con->incC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "siFindIntf failed for intfId %ld\n", 
           con->incC.cir->key.k3.intfId));  

      SILOGERROR(ERRCLS_DEBUG, ESI252, (ErrVal) con->incC.cir->key.k3.intfId,
         "siIncE29S00() Failed, intf control block not found ");
      /* clear incoming connection */
      siClearIncCon(con);
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (con->incC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((con->timers[tmrNum].tmrEvnt & INC) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T34)))
            siRmvConTq(con, tmrNum);

      SISTATECHNG(con->incC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
 
   /* if timer TCCR or T27 is running do not clear connection */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
   {
      if ((con->timers[tmrNum].tmrEvnt == TMR_TCCRI) ||
          (con->timers[tmrNum].tmrEvnt == TMR_T27))
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "since timer t27/tccri is running. connection not cleared\n"));  
         RETVALUE(ROK);
      } 
   }
   con->incC.relResp = FALSE;
      
   if (con->incC.conState == ST_IDLE)
      siClearIncCon(con);
   
   RETVALUE(ROK);
} /* end of siIncE29S00 */

  
/*
*
*       Fun:   siIncE29S06
*
*       Desc:  Input: Release Response
*              State: Waiting for release complete
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE29S06
(
SiCon *con 
)
#else
PRIVATE S16 siIncE29S06(con)
SiCon *con;
#endif
{
   U8     tmrNum;
   SiIntfCb *siIntfCb;

   TRC2(siIncE29S06)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI253, (ErrVal) 0, 
                 "siIncE29S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI254, (ErrVal) 0, 
                 "siIncE29S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   siIntfCb = con->incC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siFindIntf failed for intfId %ld\n", 
              con->incC.cir->key.k3.intfId));  

      SILOGERROR(ERRCLS_DEBUG, ESI255, (ErrVal) con->incC.cir->key.k3.intfId,
                 "siIncE29S06() Failed, intf control block not found ");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (con->incC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((con->timers[tmrNum].tmrEvnt & INC) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T34)))
            siRmvConTq(con, tmrNum);

      SISTATECHNG(con->incC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   con->incC.relResp = FALSE;
   RETVALUE(ROK);
} /* end of siIncE29S06 */

  
/*
*
*       Fun:   siIncE29S07
*
*       Desc:  Input: Release Response
*              State: Waiting for Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE29S07
(
SiCon *con 
)
#else
PRIVATE S16 siIncE29S07(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   U8        tmrNum;
   SiIntfCb *siIntfCb;

   TRC2(siIncE29S07)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI256, (ErrVal) 0, 
                 "siIncE29S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI257, (ErrVal) 0, 
                 "siIncE29S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }

   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI258, (ErrVal) 0, 
                 "siIncE29S07() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   /* don't remove the connection block until MTP-RESUME is received */
   siIntfCb = cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
          "sifindIntf failed for intfId %ld\n", cir->key.k3.intfId));  

      SILOGERROR(ERRCLS_DEBUG, ESI259, (ErrVal) cir->key.k3.intfId,
         "siIncE29S07() Failed, intf control block not found ");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (con->incC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((con->timers[tmrNum].tmrEvnt & INC) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T34)))
            siRmvConTq(con, tmrNum);

      SISTATECHNG(con->incC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   if (con->incC.relResp)
   {
      /* Generate Release Complete */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_RELCOMP;
      switch (con->tCallCb->cfg.swtch)
      {
#ifdef SS7_ITU97
         case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            /* initialize Release Complete */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RELRSP, 
                      (U8) MI_RELCOMP, (ElmtHdr *) con->sduSp, 
                      (ElmtHdr *)&message, (U8) PRSNT_NODEF,
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              "invalid switch %d\n", con->tCallCb->cfg.swtch));  

            SILOGERROR(ERRCLS_DEBUG, ESI260, (ErrVal) 0, 
                       "siIncE29S07() Failed, invalid configuration switch");
            RETVALUE(ROK);
#endif
      }
      /* change state to Idle */
      SISTATECHNG(con->incC.conState , ST_IDLE);
      con->incC.relResp  = FALSE;
      /* send message */
      siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_RELCOMP, con->tCallCb->cfg.swtch), NULLP);
   }

#ifdef ZI
   ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif

   siClearIncCon(con);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
} /* end of siIncE29S07 */

  
/*
*
*       Fun:   siIncE29S08
*
*       Desc:  Input: Release Response
*              State: Waiting for RLC and Release Resp
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE29S08
(
SiCon *con 
)
#else
PRIVATE S16 siIncE29S08(con)
SiCon *con;
#endif
{
   U8 tmrNum;
   SiIntfCb *siIntfCb;

   TRC2(siIncE29S08)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI261, (ErrVal) 0, 
                 "siIncE29S08() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI262, (ErrVal) 0, 
                 "siIncE29S08() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   siIntfCb = con->incC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
             "siFindIntf failed for intfId %ld\n", 
             con->incC.cir->key.k3.intfId));  

      SILOGERROR(ERRCLS_DEBUG, ESI263, (ErrVal) con->incC.cir->key.k3.intfId,
                 "siIncE29S08() Failed, intf control block not found ");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (con->incC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             ((con->timers[tmrNum].tmrEvnt & INC) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
              (con->timers[tmrNum].tmrEvnt == TMR_T34)))
            siRmvConTq(con, tmrNum);

      SISTATECHNG(con->incC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   con->incC.relResp = FALSE;
   /* change state */
   SISTATECHNG(con->incC.conState , ST_WTFORRELCMP);
   RETVALUE(ROK);
} /* end of siIncE29S08 */

  
/*
*
*       Fun:   siIncE30SND
*
*       Desc:  Input: User Information Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE30SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE30SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE30SND)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI264, (ErrVal) 0, 
                 "siIncE30SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI265, (ErrVal) 0, 
                 "siIncE30SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI266, (ErrVal) 0, 
                 "siIncE30SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;


   /* Generate User Info */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_USR2USR;

   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_INFREQ, (U8) MI_USR2USR,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);
      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic, &pduHdr, 
                                   &message, con->mCallCb->pst.region, 
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, con->lnkSel, FALSE, 
                        siGetPriority(M_USR2USR, con->tCallCb->cfg.swtch),
                     con->tCallCb->cfg.swtch);
      }
      else
         /* send message through MTP */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_USR2USR, con->tCallCb->cfg.swtch), uBuf);
   }
      
   RETVALUE(ROK);
} /* end of siIncE30SND */

  
/*
*
*       Fun:   siIncE31S04
*
*       Desc:  Input: Suspend Request
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE31S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE31S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE31S04)
   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI271, (ErrVal) 0, 
                 "siIncE31S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI272, (ErrVal) 0, 
                 "siIncE31S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI273, (ErrVal) 0, 
                 "siIncE31S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;


   /* set suspended flag value */
   con->incC.suspDir |= FROM_UPR;

   /* Generate Suspend */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_SUSPND;

   /* initialize Release Complete */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_SUSPREQ, (U8) MI_SUSPND,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* change state to suspended */
   SISTATECHNG(con->incC.conState , ST_SUSP);

   /* if controlling exchange */
   if (!con->outC.conPrcs)
      /* Start T2 Timer */
      siStartConTmr(TMR_T2I, con, con->tCallCb);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_SUSPND, con->tCallCb->cfg.swtch), uBuf);
   
   RETVALUE(ROK);
} /* end of siIncE31S04 */

  
/*
*
*       Fun:   siIncE31S05
*
*       Desc:  Input: Suspend Request
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE31S05
(
SiCon *con 
)
#else
PRIVATE S16 siIncE31S05(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE31S05)

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI274, (ErrVal) 0, 
                 "siIncE31S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI275, (ErrVal) 0, 
                 "siIncE31S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI276, (ErrVal) 0, 
                 "siIncE31S05() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->tCallCb->mfMsgCtl.uBuf;


   /* if already suspended from this direction, ignore */
   if (con->incC.suspDir & FROM_UPR)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Already suspended from this direciton . Dumping\n"));  
      RETVALUE(ROK);
   } 
   else
      con->incC.suspDir |= FROM_UPR;

   /* Generate Suspend */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_SUSPND;

   /* initialize Suspend */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_SUSPREQ, (U8) MI_SUSPND,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* if controlling exchange */
   if (!con->outC.conPrcs)
      /* Start T2 Timer */
      siStartConTmr(TMR_T2I, con, con->tCallCb);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_SUSPND, con->tCallCb->cfg.swtch), uBuf);
   
   RETVALUE(ROK);
} /* end of siIncE31S05 */

  
/*
*
*       Fun:   siIncE32S05
*
*       Desc:  Input: Resume Request
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE32S05
(
SiCon *con 
)
#else
PRIVATE S16 siIncE32S05(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siIncE32S05)
   cir = con->incC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI277, (ErrVal) 0, 
                 "siIncE32S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI278, (ErrVal) 0, 
                 "siIncE32S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI279, (ErrVal) 0, 
                 "siIncE32S05() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   /* Stop Timers  T2 */
   siStopConTmr(con, TMR_T2I);
   /* Generate Resume */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RESUME;

   /* initialize Resume */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RESREQ, (U8) MI_RESUME,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_RESUME, con->tCallCb->cfg.swtch), uBuf);

   /* if already suspended from this direction, ignore */
   if (con->incC.suspDir & FROM_UPR)
      con->incC.suspDir &= FROM_LWR;
   if (!con->incC.suspDir)
   {
      SISTATECHNG(con->incC.conState , ST_ANSWRD);
   }
   
   RETVALUE(ROK);
} /* end of siIncE32S05 */

  
/*
*
*       Fun:   siIncE33SND
*
*       Desc:  Input: Facility Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE33SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE33SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   U8        event;
   U8        msgType;
   Buffer    *uBuf;
   Priority  prior;

   TRC2(siIncE33SND)

   event   = 0;
   msgType = 0;
   cir     = con->incC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI280, (ErrVal) 0, 
                 "siIncE33SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI281, (ErrVal) 0, 
                 "siIncE33SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI282, (ErrVal) 0, 
                 "siIncE33SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   switch (con->tCallCb->cfg.swtch)
   {


/* si034.220 : Drop Msg */
#ifdef SS7_CHINA
      case LSI_SW_CHINA:
         siIncUNXEVT(con);
         RETVALUE(ROK);
#endif




#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         switch (con->evntType)
         {
            case SIT_FACIL:
               msgType = M_FACIL;
               event   = MI_FACIL;
               break;
            case SIT_FACREQ:
               msgType = M_FACREQ;
               event   = MI_FACREQ;
               break;
            default:
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "evenType %d neither FACIL/FACREQ\n", con->evntType));  
               siIncUNXEVT(con);
               RETVALUE(ROK);
         }
         break;

   }

   /* Generate Facility Request */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) msgType;

   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACREQ, (U8) event,
            (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   prior = siGetPriority(msgType, con->tCallCb->cfg.swtch);
   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);
      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic, &pduHdr,
                                   &message, con->mCallCb->pst.region,
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, con->lnkSel, FALSE, prior,
                     con->tCallCb->cfg.swtch);
      }
      else
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  prior, uBuf);
   }
   
   RETVALUE(ROK);
} /* end of siIncE33SND */

  
/*
*
*       Fun:   siIncE34SND
*
*       Desc:  Input: Facility Response
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE34SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE34SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   Buffer    *uBuf;
   Priority  prior;

   TRC2(siIncE34SND)
   cir = con->incC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI283, (ErrVal) 0, 
                 "siIncE34SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI284, (ErrVal) 0, 
                 "siIncE34SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI285, (ErrVal) 0, 
                 "siIncE34SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   if ((uBuf = con->tCallCb->mfMsgCtl.uBuf) != NULLP)
      con->tCallCb->mfMsgCtl.uBuf = NULLP;


   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   switch(con->tCallCb->cfg.swtch)
   {
            
      default:
         break;
   }

   switch (con->evntType)
   {
      case SIT_FACREJ:
         /* Generate Facility Reject */
         pduHdr.msgType.val = (U8) M_FACREJ;
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACRSP, 
                   (U8) MI_FACREJ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         break;

      case SIT_FACACC:
         /* Generate Facility Accept */
         pduHdr.msgType.val = (U8) M_FACACC;
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACRSP, 
                   (U8)MI_FACACC, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);
         break;
 
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         siIncUNXEVT(con);
         RETVALUE(ROK);
   }

   prior = siGetPriority(pduHdr.msgType.val, con->tCallCb->cfg.swtch);
   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);
      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic, &pduHdr,
                                   &message, con->mCallCb->pst.region,
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, con->lnkSel, FALSE, prior,
                     con->tCallCb->cfg.swtch);
      }
      else
         /* send message through MTP */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  prior, uBuf);
   }
   
   RETVALUE(ROK);
} /* end of siIncE34SND */

  
/*
*
*       Fun:   siIncE35S00
*
*       Desc:  Input: Status Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE35S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE35S00(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *uBuf;

   TRC2(siIncE35S00)

   cir = con->incC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI288, (ErrVal) 0, 
                 "siIncE35S00() Failed, pointer to MTP3 cb  missing");
      /* clear incoming connection */
      siClearIncCon(con);

      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI289, (ErrVal) 0, 
                 "siIncE35S00() Failed, pointer to circuit missing");
      /* clear incoming connection */
      siClearIncCon(con);

      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;

   /* get link selection value */
/* si009.220 - Modified: to pass cic into siGetLnkSel */   
   if (!con->lnkSel)
      /* si025.220: Modification - modify arguments in siGetLnkSel */
      siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);

   if (con->evntType == SIT_STA_LOOPBACKACK)
   {
      switch (con->tCallCb->cfg.swtch)
      {
/*si034.220 : Drop Msg */	 
#if SS7_CHINA
         case LSI_SW_CHINA:
#endif
#if (SS7_Q767 || SS7_RUSSIA || SS7_NTT || SS7_CHINA) 
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                   "for swtch Q767 or Russia or NTT. Dumping the event\n"));  
            /* clear incoming connection */
            siClearIncCon(con);
            RETVALUE(ROK);
#endif

          default:
            break;
      }
      /* Start t34 Timer */
      siStartConTmr(TMR_T34, con, con->tCallCb);   


      /* Generate Loopback Ack */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_LOOPBCKACK;
      SISTATECHNG(con->incC.conState  , ST_WTFORCONTIN);
      /* send message */
       siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_LOOPBCKACK, con->tCallCb->cfg.swtch), uBuf);
   }
   
   RETVALUE(ROK);
} /* end of siIncE35S00 */


  
/*
*
*       Fun:   siIncE36S00
*
*       Desc:  Input: Reset Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE36S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE36S00(con)
SiCon *con;
#endif
{
   U8        tmrNum;
   
   TRC2(siIncE36S00)

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* NOTE: if reset direction is FROM_UPR, connection will be cleared 
    * within circuit mntc. procedures state machine when RESET ACK is 
    * received 
    * if reset direction is FROM_LWR, maintain the connection till we 
    * receive a reset response and connection is cleared in circuit mntc. 
    * procedures state machine
    */
   con->incC.relResp = FALSE;

   RETVALUE(ROK);
} /* end of siIncE36S00 */

  
/*
*
*       Fun:   siIncE36SND
*
*       Desc:  Input: Reset Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE36SND
(
SiCon *con 
)
#else
PRIVATE S16 siIncE36SND(con)
SiCon *con;
#endif
{
   U8        tmrNum;

   TRC2(siIncE36SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI293, (ErrVal) 0, 
                 "siIncE36SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI294, (ErrVal) 0, 
                 "siIncE36SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) ||
           (con->timers[tmrNum].tmrEvnt == TMR_TCRA) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T34)))
         siRmvConTq(con, tmrNum);

   /* exchange of release primitives is unncessary in the new i/f 
    * maintain the conn. block till we receive a reset response/reset ack
    */
   con->incC.relResp = FALSE;
   RETVALUE(ROK);
} /* end of siIncE36SND */

  
/*
*
*       Fun:   siIncE36S06
*
*       Desc:  Input: Reset Request
*              State: Waiting for RLC
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE36S06
(
SiCon *con 
)
#else
PRIVATE S16 siIncE36S06(con)
SiCon *con;
#endif
{
   U8        tmrNum;

   TRC2(siIncE36S06)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
/* si026.220: Deletion - delete the ERROR LOG since this may be an
 * expected situation and program should not stop. For instance, 
 * when incoming connection is rejected by sending out REL message
 * to the network and ISUP is in waiting for REL Complete state. 
 * If the remote does not respond with RLC, the REL timer T5 may 
 * be expired, so this function is called.   
 */
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block till we receive a reset response/reset ack */
   con->incC.relResp = FALSE;
   RETVALUE(ROK);
} /* end of siIncE36S06 */

  
/*
*
*       Fun:   siIncE36S07
*
*       Desc:  Input: Reset Request
*              State: Waiting for Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE36S07
(
SiCon *con 
)
#else
PRIVATE S16 siIncE36S07(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siIncE36S07)

   /* Stop all Timers & clear the connection */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block until we receive reset response or reset ack */
   con->incC.relResp = FALSE;

   RETVALUE(ROK);
} /* end of siIncE36S07 */


  
/*
*
*       Fun:   siIncE36S08
*
*       Desc:  Input: Reset Request
*              State: Waiting for RLC and Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE36S08
(
SiCon *con 
)
#else
PRIVATE S16 siIncE36S08(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siIncE36S08)

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & INC))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block until we receive reset response or reset ack */
   con->incC.relResp = FALSE;
   RETVALUE(ROK);
} /* end of siIncE36S08 */


  
/*
*
*       Fun:   siIncE37S00
*
*       Desc:  Input: Block message
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE37S00
(
SiCon *con 
)
#else
PRIVATE S16 siIncE37S00(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8 tmrNum;
   S16 ret;
   Bool found;
   
   TRC2(siIncE37S00)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI296, (ErrVal) 0, 
                 "siIncE37S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif


   found = FALSE; 
   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
   { 
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & INC) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T27) ||
           (con->timers[tmrNum].tmrEvnt == TMR_T34) ||
           (con->timers[tmrNum].tmrEvnt == TMR_TCCRI)))
         siRmvConTq(con, tmrNum);
      else
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt == TMR_T8))
         {
            siRmvConTq(con, tmrNum);
            found = TRUE;
         }    
   }
   
   /* Stop continuity and go to idle */
   if ((found) && con->tCallCb )
   {
      /*  If T8 is running send release request to upper layer */
      /* initialize siRelEvnt */
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ, 
                NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF, 
                con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      ev.m.siRelEvnt.causeDgn.eh.pres        = PRSNT_NODEF;
      ev.m.siRelEvnt.causeDgn.causeVal.pres  = PRSNT_NODEF;
      ev.m.siRelEvnt.causeDgn.causeVal.val   = SIT_CCRESCUNAVAIL;
      ev.m.siRelEvnt.causeDgn.cdeStand.pres  = NOTPRSNT;
      ev.m.siRelEvnt.causeDgn.cdeStand.pres  = NOTPRSNT;
/* si040.220 - location.pres changed to PRSNT_NODEF as this is a case 
               of ISUP is not generating the release internally
               Also filled the location.val field.
*/
      ev.m.siRelEvnt.causeDgn.location.pres  = PRSNT_NODEF;
      ev.m.siRelEvnt.causeDgn.location.val  = con->tCallCb->cfg.relLocation;
      ev.m.siRelEvnt.causeDgn.recommend.pres = NOTPRSNT;
      ev.m.siRelEvnt.causeDgn.dgnVal.pres    = NOTPRSNT;
      SISTATECHNG(con->incC.conState  , ST_WTFORRELRSP);
      con->incC.relResp                      = FALSE;
 
      SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                    con->key.k1.spInstId, con->incC.cirId, &ev.m.siRelEvnt, 
                    NULLP);
   }
   else 
      /* Release the connection */
      siClearIncCon(con);

   RETVALUE(ROK);
} /* end of siIncE37S00 */

  
/*
*
*       Fun:   siIncE00S03
*
*       Desc:  Input: Addresss Complete message
*              State: waiting for answer state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE00S03
(
SiCon *con 
)
#else
PRIVATE S16 siIncE00S03(con)
SiCon *con;
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *mCb;
   U8       genRscFlg;  /* 0: Reset is not to be generated */
   Swtch    swtch;
   TRC2(siIncE00S03)

   tCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI297, (ErrVal) 0, 
                 "siIncUNXMSG() Failed, MTP3 control block pointer missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   mCb = con->mCallCb;
   genRscFlg = 0;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;

   switch (swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         siIncUNXMSG(con);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch invalid %d\n", con->tCallCb->cfg.swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI299, (ErrVal) 0,
                 "siIncE00S03() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }    
   RETVALUE(ROK);
} /* end of siIncE00S03 */

/*
*
*       Fun:   siIncE01S04
*
*       Desc:  Input: answer message
*              State: ICC answer state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy2.c
*
*/

#ifdef ANSI
PRIVATE S16 siIncE01S04
(
SiCon *con 
)
#else
PRIVATE S16 siIncE01S04(con)
SiCon *con;
#endif
{
   SiUpSAPCb *tCb;
   SiNSAPCb  *mCb;
   U8        genRscFlg;  /* 0: Reset is not to be generated */
   Swtch     swtch;
   TRC2(siIncE01S04)

   tCb = NULLP;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI300, (ErrVal) 0, 
                 "siIncUNXMSG() Failed, MTP3 control block pointer missing");
      RETVALUE(ROK);
   }
   if(siValdtIncCirIntf(con) != ROK)
      RETVALUE(ROK);
#endif

   mCb = con->mCallCb;
   genRscFlg = 0;
   swtch = con->incC.cir->pIntfCb->cfg.swtch;

   switch (swtch)
   {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#if SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#if SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         siIncUNXMSG(con);
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                    "swtch invalid %d\n", con->tCallCb->cfg.swtch));
         SILOGERROR(ERRCLS_DEBUG, ESI302, (ErrVal) 0,
                 "siIncE01S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }    
   RETVALUE(ROK);
} /* end of siIncE01S04 */


/********************************************************************30**
  
         End of file:     ci_bdy2.c@@/main/38 - Wed Jul 25 13:20:35 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0
 
1.2          ---  rhk   1. set relResp to true upon receipt of a RelReq
                           (siIncE26SND)
             ---  bn    2. add support for ansi

1.3          ---  jrl   1. remove includes for spt.h and spt.x
             ---  jrl   2. add siIncXXX prototypes
             ---  jrl   3. change all siIncXXX prototypes to PRIVATE

1.4          ---  rk    1. miscellaneous changes

1.5          ---  rk    1. miscellaneous changes

1.6          ---  bn    1. initialize CONG_LVL_2 type alarm to layer manager.

1.7          ---  bn    1. add support for ansi 92.
             ---  bn    2. changed timer routines to common functions.
             ---  bn    3. added include cm5.x and cm5.h.
             ---  bn    4. change return( to RETVALUE(

1.8          ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.9          ---  bn    1. corrected typo.

1.10         ---  bn    1. added siIncE36S06 and siIncE36S08.

1.11         ---  bn    1. added INITSDU in siIncE36S06.
             ---  bn    2. added siGenPdu in siIncE17S06.
             ---  bn    3. changed to support new interfaces.

1.12         ---  fmg   1. removed unused variables and siIncEXXSXX
             ---  bn    2. removed #ifdef SS7_ANS92 around siIncE23S00.


1.13         ---  bn    1. added functionality for continuity recheck 
                           procedures
             ---  bn    2. added support for Q.767 and Singapore Telecom.

1.14         ---  bn    1. text changes

1.15         ---  bn    1. si008.23

1.16         ---  bn    1. text changes

1.17         ---  bn    1. additions for Italian Q767.

1.18         ---  bn    1. chnaged SW_... to LSI_SW_...
             ---  bn    2. miscelenious changes.

1.19         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. corrected gcc compile warnings.

1.20         ---  bn    1. removed circuit profile validation.
             ---  bn    2. changed LSI_SW_CCITT to LSI_SW_ITU and 
                           LSI_SW_ANSI?? to LSI_SW_ANS??.

1.21         ---  bn    1. corrected siIncUNXMSG and added siIncE36S00
             ---  bn    2. necessary recovery actions placed in error scenarios
             ---  bn    3. misceleneous corrections.

1.22         ---  bn    1. corrected typo in siIncE09S01.
             ---  bn    2. corrected typo in siIncE29S01.
             ---  dm    3. corrected typo in siOutE16S00.
             ---  dm    4. corrected typo in siOutE16S10.

1.23         ---  pc    1. added ETSI variant for SI
             ---  bn    2. stopped generating release indication on reception
                           of release message while in state waiting for a


1.24         ---  bn    1. text change

1.25         ---  dm    1. added GT_FTZ variant for SI
             ---  dm    2. added segmentation
             ---  dm    3. corrected typo in siIncE17SND (added reset of 
                           T27 and T34) 
             ---  dm    4. corrected typo in siIncE08S01 (reset of T34 
                           instead of TCCR)
             ---  dm    5. moved state update in siIncE09S01 
             ---  dm    6. corrected typo in siIncE36SND (added reset of
                           T27 and T34)
             ---  dm    7. added event type in Facility primitives
             ---  dm    8. added include cm_ss7.x

1.26         ---  dm    1. changed state matrix by putting  siIncE36SND in 
                           states 9 and 10.

1.27         ---  dm    1. added case PROGRESS in siIncE27S04
             ---  dm    2. added siIncE05S04

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.28         ---      dm   1. corrected typo in siIncE14SND (si00x.210)
             ---      dm   2. corrected typo in siIncE27S04 (si00x.210)
             ---      dm   3. corrected typo in siIncE16S10 (si00x.210)
             ---      dm   4. corrected typo in siIncE09S08 (si00x.210)
             ---      dm   5. corrected typo in siIncE36SND (si00x.210)
             ---      dm   6. corrected typo in siIncE17S09 (si00x.210)
             ---      ao   7. added state change in siIncE08S01 to idle
                              when T34 is running
             ---      ao   8. Moved OPC from general config to upper SAP
                              config
             ---      dm   9. corrected bug in siIncE09S01
             ---      ao   10. added call of siInsCallRef to set call
                               reference
             ---      ao   11. added test if message is received from SCCP
                               to increment statistics on SCCP
             ---      ao   12. corrected gcc compile warnings.

1.28         ---      ao   1. moved start of T27 out of for loop 
                              (siIncE08S01). T27 was started and removed 
                              afterwards when processing the for loop
             ---      ao   2. Added status event to SiUiSitStaInd call 
                              when receiving a circuit reservation message
                              (siIncE23S00)
             ---      ao   3. added case EXIT in siIncE27S02
             ---      ao   4. fixed error in siIncE17S09, & was used
                              instead of ==
             ---      ao   5. added spInstId to release indication in 
                              siIncE17S09 and siIncE18S09
             ---      ao   6. added support of release request in state
                              wait for IAM and wait for COT and IAM.
             ---      ao   7. added stop of timer Tcra when releasing
                              a call.
             ---      ao   8. changed initializing of cgPtyNum in siIncE16S00
                              and siIncE16S10
             ---      ao   9. added initialization if cause event in E18SND
             ---      ao   10. added status indication for continuity recheck 
                               in siIncE08S01()
             ---      rh   11. added E36S07()
             ---      rh   12. changes in siIncUNXMSG

1.29         ---      rh   1. changes for call release handling functions to 
                              handle the new PAUSE/RESUME behaviour 
                           2. text changes
                           3. removed compilation warnings
1.29         ---      ao   1. Fixed problem with reference to uBuf for
                              tightly coupled mode.
             ---      ao   2. change recommend filed in CauseDgn structure to
                              NOTPRSNT for ANS88 and ANS92
             ---      ao   3. changed handling of presentation restriction
                              on incoming calls.
             ---      rh   1. correction to set 'relResp' flag to false
                              when connection receives a reset while waiting
                              for release response so that connection block 
                              can be cleared.
             ---      rh   1. Changes for handling reset request for stable 
                              calls from the upper layer when the DPC is 
                              PAUSEd.
             ---      rs   1. Added missing code for ITU/ETSI to set 
                              segmentation indicator for IAM case.             
1.30         ---      rs   1. Changed the checks for flwCntrl and congestion
                              (checks are now done using intfIdCb instead of 
                               cirCb)
                      rs   2. corrected the handling of presentation 
                              restriction on incoming calls.
                      rs   3. changed handling of SUS such that user initiated
                              suspend is not supported for ANSI.
                      rs   4. Modified siIncE17S06 for release collision
                              handling.
                      rs   5. Replaced errorind with release indication 
                               wherever applicable.
                      rs   1. Changes in Reset procedures related to release
                              primitive exchange.
1.31         ---      ym   1. Changes in siIncUNXMSG to avoid calling 
                              siGenCirEvt with null circuit.
                           2. Changes in siIncE08S01 related to checks on 
                              tccriCnt field in connection block.
             ---      ao   1. Added status filed to CGB when receiving
                              IAM on a hardware blocked circuit.
                      ao   2. Removed setting of presentation indicator
                              in IAM when the address is present.
             ---      rh   1. changes to use 'cbCfg' instead of 'sapCfg'
                              in ISUP NSAP control blocks when protocol
                              switch field needs to be accessed
             ---      ym   1. Changes related to Debug message printing
1.32         ---      ao   1. Added Russian variant
1.32+        ---      ym   1. Priority with which ANSWER, LPA and EXIT are sent
                              is corrected.
                           2. RelResp flg is reset for SITVER2 option.
                           3. Handling of information is added for 
                              cnStReq in siIncE27S04. 
                           4. Remote unequipped state is updated on 
                              getting IAM , CCR and CRM from peer.
                           5. COT failure is handled in idle state for
                              ANS92. This message is possible in idle when
                              LPA Req does not come from CC.
              ---      ym  1. Recommendation field in the cause element is 
                              marked NOTPRSNT.
                           2. In idle state the receipt of unexpected COT
                              is handled.
              ---      ym  1. The declaration of siIncE23S00 is moved
                              to si.x
                           2. The handling of CRM on a locally blocked
                              circuit is corrected. Earlier the con block
                              was released twice.
                           3. The handling of reset request is corrected when
                              SITVER2 is not defined.
              ---      ym  1. The suspend direction flag is properly updated.
                           2. PROGRESS handling is corrected in awt-acm state.
                           3. The handling of unexpected message is corrected.
                           4. UBLIndication to CC is generated on getting
                              on test IAM on a remotely blocked circuit.
              ---      ym  1. The changes related to continuity procedures.
                           2. Case for Q767 is added to handle CCR
                              after failure of continuity
                           3. The release clash is handled properly.
                           4. Proper indication is given to CC on getting
                              CFN in idle state. This is to take care of 
                              non connection related messages like CVT .
1.33         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
            si026.214 ym   1. The release confirm is generated after
                              runtime updation.
                           2. Information is updated properly in case
                              of release collision.
            si006.216 tz   1. Changed code in function siIncE16S00 to change
                              the circiut state to IDLE before gernerating 
                              StaInd to the call control to indicate the 
                              circuit is unblocked.
            si028.214 tz   1. Unblock indication is sent after making the
                              states changes.
                           2. DPC block access is removed in the handling
                              of iam.
            si034.214 tz   1. Changed code to remove T34 on receiving of
                              COT message. Depending on the situation,
                              timer T27 or TCCR, r is started.
            si036.214 tz   1. Changed code to send only StaInd to CC whenever
                              ISUP receives a COT message if the compile time
                              flag SI_NEW_COT_PROC is defined. When the flag
                              is not defined, for the first COT failure, ISUP
                              sends RelInd and for the second and later COT,
                              it sends StaInd to CC.
            si040.214 tz   1. Deleted code so that response to circuit
                              messages will be sent out to the lower layer.
1.35         ---      dvs  1. miscellaneous changes    
1.36         ---      ym   1. OUT define is changed to OUTTYPE for NT 
                              compilation.
                           2. NT compilation warnings are removed.

/main/37     ---      rrb  1. Modified code to use the OPC from the interface
                              control block instead of the "dfltOpc" field in
                              NSAP, while sending UCIC message for a non-
                              existent or unequipped circuit.
            si002.218 bsp  1. Correction for handling facility request msg

             ---      hy   1. Remove the codes to check the received 
                              information transfer capability in user service 
                              information of IAM with the configured value 
                              in the circuit "bearProf" in function
                              siIncE16S10
                           2. Change the codes in state matrix to support CPG
                              message in the "waiting for Answer" state
                           3. Added the codes to handle the ACM/ANM clash
                              for ANSI95 variant.
                           4. Added the codes to support 3 level congestion
                              in received REL message for ANS'95 variant.
                           5. Changed the codes not to overwrite the automatic
                              congestion level param if this param is present
                              when sending release message to network in 
                              function siIncE28SND.
                           6. Add codes to support the Facility Message
                              for ANS'95 variant in function siIncE12SND and
                              siIncE33SND
                           7. Implemented the release collision for variant
                              ANS'95 in function siIncE17S06.
                           8. Added codes to support LOP message for ITU97
                              and ETSI v3 variant.
                           9. Added codes to support pre-release message for
                              ETSI v3 variant, which including to add a 
                              function siIncE27S05.
                          10. Added codes to support application transport
                              meassage to ETSI v3 variant.
                          11. Changed codes to accept REL when waiting for 
                              release response from CC in siIncE17S07.
                          12. Changes to support non-single rate calls.
                          13. Removed the codes to check the varants for
                              case INFORMATREQ in siIncE27S01.
                          14. Deleted local variable mapVal in siIncE16S00
                              siIncE16S10.
                          15. Added error checking for transfer rate in 
                              non-single rate connection in siIncE16S00
                              and siIncE16S10.
                          16. Change the function name siValdtCirIntf to 
                              siValdtIncCirIntf.
                      bsp 17. Changed hash define names which were changed 
                              in sit.h to resolve clash between sit.h and int.h
                      hy  18. changes for removal of swtch and ssf field in
                              circuit control block.
                      bsp 19. Removed SITVER2 flag.
                          20. Procedure related changes to support APM and
                              PRI messages for ITU97.
                      hy  21. Changes for supported segmentation in 
                              ANS92 and ANS95.
                      bsp 22. Patch propagation related changes:
                              . Deleted codes for checking the transfer rate
                                parameter in IAM message in function 
                                siIncE16S10.
                              . Added codes to support the identification
                                request message from upper layer in function
                                siIncE27S01, siIncE27S02 and siIncE27S03
                              . Changed code in state matrix to support CPG
                                message in the "waiting for Answer" state
                              . Correction for information and information 
                                request message
                              . Added code to send LPA when the connection 
                                state is waiting for continuity and IAM.
                              . Called siChargeInfo whenever there was 
                                ConReq to take care of charging based on 
                                certain parameters
                      hy  23. Added the dual serzure handling between 
                              receiving CRM msg and non-single rate 
                              outgoing in siIncE23S00.
                          24. Remove supporting for swtch type for ITU97,
                              ETSIV3 in function siIncE02S04, siIncE03S04,
                              siIncE04S04.
                          25. Remove the #if 1 or #if 0 tags in the file.
                          26. Change the error log printings to assign the 
                              mulCallFlg to FALSE when swtch type is not
                              ans95/itu97/etsi v3 in siIncE16S00
                          27. Added a check to see if the connection block
                              is not NULLP before call the siClearIncCon
                              when siSanChkIAMCkts is returned failure in 
                              function siIncE16S00.
                          28. Added a run time check for the variant type
                              before calling function siChargeInfo.
                          29. Changed code to break instead of returning to 
                              calling function for each switch case in 
                              function siIncE01S04 and siIncE00S03
                          30. Moved the assignment of the local variables
                              to the top of if statement in siIncE18S06
                          31. Removed the local variable 'ret' in siIncUNXEVT
                          32. Removed the include of lrm.h.
/main/38     ---        hy  1. Modified the state matrix so that when a Release
                              Request is received in idle state, REL msg is sent
                              to the network, rather than the request being
                              treated as an unexpected event
                       hy  1. Added the case type for Bellcore variant in
                              function siIncE00S03 and siIncE01S04 to handle
                              the ACM or ANM collision cases.
                           2. Added a default case when swtch on the continuity
                              check indicator in function siIncE16S00
                      tz   1. Added code to send StaInd when RLC is received
                              and it is the RelUpLw case.
           si003.220  mm   1. In function siIncE18S06, modified code so that all
                              the initializations are done after checking the 
                              related pointers to avoid possible core dump.
           si006.220  hy   1. In function siIncE18S06, add initializations for 
                              the variables.
           si009.220  mm   1. In function siIncE35S00, modified code so that 
                              parameter cic could be passed into siGetLnkSel.
           si011.220  km   1. In function siIncE27S00, added SS7_BELL compile
                              time flag when generating the EXIT msg
           si014.220  km   1. Notify maintenance for unexpected message 
                              in Bell
           si016.220  tz   1. Modified code to check tCb SAP pointer not
                              NULLP before accessing the contents.
           si020.220  tz   1. Modified code to allow TCCRI timer being restarted
                              in case of multiple COT failures being received.
           si022.220  tz   1. Modified code to add timer processing for 
                              bellcore variant along with ANSI variants.
           si024.220  tz   1. Added TRFFCHGE cases for different call states.
                           2. Modified LOOPPRVNT so that LOP should always
                              be allowed to sent.
           si025.220  tz   1. Modified the arguments in siGetLnkSel call.
           si026.220  tz   1. Deleted ERROR LOG in function siIncE36S06. 
                           2. Modified code in siIncE21S04 so that T6 or
                              T2 may be started as per suspend resume 
                              indicator value.
           si029.220  tz   1. Modified code to allow charge info message to
                              be sent by Indian variant.
                           2. Added SS7_INDIA flag and LSI_SW_INDIA switch
                              where applicable.
           si034.220  rk   1. Added CHINA flag and switch where applicable.
                           2. For ANSI2000, handling of segmentation in IAM 
                              modified.
           si039.220  rk   1. In siIncE19S05, Timer T2 should be stopped. 
                              Otherwise timer T2 will timeout and release 
                              the call
           si040.220  rk   1. Changes made to identify all release generated by ISUP
                              by marking location.pres as PRSNT_DEF and in case of 
                              remote release, marking location.pres as PRSNT_NODEF.
           si042.220 bn    1. Added ITU2000 and Russian 2000 ISUP variants.
           si047.220   ng   1. Proper pointer type passed in SFndLenMsg
*********************************************************************91*/
