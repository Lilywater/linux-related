/********************************************************************16**

        (c) COPYRIGHT 1989-2001 by Trillium Digital Systems, Inc.
                          All rights reserved.

     This software is confidential and proprietary to Trillium
     Digital Systems, Inc.  No part of this software may be reproduced,
     stored, transmitted, disclosed or used in any form or by any means
     other than as expressly provided by the written license agreement
     between Trillium and its licensee.

     Trillium warrants that for a period, as provided by the written
     license agreement between Trillium and its licensee, this
     software will perform substantially to Trillium specifications as
     published at the time of shipment and the media used for delivery
     of this software will be free from defects in materials and
     workmanship.

     TRILLIUM MAKES NO OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING
     WITHOUT LIMITATION WARRANTIES OF MERCHANTABILITY OR FITNESS FOR
     A PARTICULAR PURPOSE WITH REGARD TO THIS SOFTWARE OR ANY RELATED
     MATERIALS.

     IN NO EVENT SHALL TRILLIUM BE LIABLE FOR ANY INDIRECT, SPECIAL,
     OR CONSEQUENTIAL DAMAGES IN CONNECTION WITH OR ARISING OUT OF
     THE USE OF, OR INABILITY TO USE, THIS SOFTWARE, WHETHER BASED
     ON BREACH OF CONTRACT, TORT (INCLUDING NEGLIGENCE), PRODUCT
     LIABILITY, OR OTHERWISE, AND WHETHER OR NOT IT HAS BEEN ADVISED
     OF THE POSSIBILITY OF SUCH DAMAGE.

                       Restricted Rights Legend

     This software and all related materials licensed hereby are
     classified as "restricted computer software" as defined in clause
     52.227-19 of the Federal Acquisition Regulation ("FAR") and were
     developed entirely at private expense for nongovernmental purposes,
     are commercial in nature and have been regularly used for
     nongovernmental purposes, and, to the extent not published and
     copyrighted, are trade secrets and confidential and are provided
     with all rights reserved under the copyright laws of the United
     States.  The Government's rights to the software and related
     materials are limited and restricted as provided in clause
     52.227-19 of the FAR.

                    IMPORTANT LIMITATION(S) ON USE

     The use of this software is limited to the Use set
     forth in the written License Agreement between Trillium and
     its Licensee. Among other things, the Use of this software
     may be limited to a particular type of Designated Equipment.
     Before any installation, use or transfer of this software, please
     consult the written License Agreement or contact Trillium at
     the location set forth below in order to confirm that you are
     engaging in a permissible Use of the software.

                    Trillium Digital Systems, Inc.
                  12100 Wilshire Boulevard, suite 1800
                    Los Angeles, CA 90025-7118, USA

                        Tel: +1 (310) 442-9222
                        Fax: +1 (310) 442-1162

                   Email: tech_support@trillium.com
                     Web: http://www.trillium.com

*********************************************************************17*/


/********************************************************************20**

    Name:     ISUP - body 3

    Type:     C source file

    Desc:     C source code for ISUP Upper Layer, Lower Layer,
              System Service and Layer Management service user primitives
              supplied by TRILLIUM.

              Part 3: Support Functions;

    File:     ci_bdy3.c

    Sid:      ci_bdy3.c@@/main/43 - Wed Jul 25 13:20:40 2001
 
    Prg:      na

*********************************************************************21*/


/************************************************************************

     Note: 

     This file has been extracted to support the following options:

     Option             Description
     ------    ------------------------------
#ifdef CCITT
               CCITT
#endif
#ifdef CCITT88
               CCITT 88
#endif
#ifdef CCITT92
               CCITT 92
#endif
 

************************************************************************/


/*
It is assumed that the following functions are provided in the system
services service provider file:

     SInitQueue     Initialize Queue
     SQueueFirst    Queue to First Place
     SQueueLast     Queue to Last Place
     SDequeueFirst  Dequeue from First Place
     SDequeueLast   Dequeue from Last Place
     SFlushQueue    Flush Queue
     SCatQueue      Concatenate Queue
     SFndLenQueue   Find Length of Queue

     SGetMsg        Get Message
     SPutMsg        Put Message
     SInitMsg       Initialize Message

     SAddPreMsg     Add Pre Message
     SAddPstMsg     Add Post Message
     SRemPreMsg     Remove Pre Message
     SRemPstMsg     Remove Post Message
     SExamMsg       Examine Message
     SFndLenMsg     Find Length of Message
     SCopyMsgMsg    Copy Message to Message
     SCatMsg        Concatenate Message
     SSegMsg        Segment Message

     SChkRes        Check Resources
     SRegTmr        Register Activate Task - timer

*/



/*
*     this software may be combined with the following TRILLIUM
*     software:
*
*     part no.             description
*     --------    ----------------------------------------------
* 
*/


/* header include files (.h) */

#include "envopt.h"        /* environment options */  
#include "envdep.h"        /* environment dependent */
#include "envind.h"        /* environment independent */

#include "gen.h"           /* general layer */
#include "ssi.h"           /* system services */
#include "lsi.h"           /* layer management */
#include "si_mf.h"         /* message functions */
#include "cm5.h"           /* timers */
#include "cm_lib.x"        /* memory functions header */
#include "ci_db.h"         /* isup data base */
#include "cm_hash.h"       /* hash-list header */
#include "sit.h"           /* isup */
#ifdef SI_SPT
#include "spt.h"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.h"           /* sht interface */
#endif
#include "si.h"            /* isup */
#include "si_err.h"        /* isup error */
#ifdef IW
#include "cm_atm.h"          /* common ATM defines                 */
#include "cm_cc.h"           /* Common Call Control Hash Defs      */
#include "rmt.h"             /* resource manager defines           */
#include "cct.h"             /* Call Control Interface Header      */
#include "liw.h"             /* ISUP PSIF Layer Management Headers */
#include "iw.h"              /* ISUP PSIF Hash Defines             */
#include "iw_err.h"          /* ISUP PSIF Error Defines            */
#include "iw_ptli.h"         /* o/g SIT i/f funcs. hash defs       */
#endif

#ifdef ZI
#include "cm_pftha.h"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.h"       /* common PSF */
#include "cm_psfft.h"      /* common PSF */
#endif
#include "lzi.h"           /* ISUP PSF management */
#include "zi.h"            /* ISUP PSF */
#include "zi_err.h"        /* ISUP PSF error codes */
#endif /* ZI */

/* header/extern include files (.x) */

#include "gen.x"           /* general layer */
#include "ssi.x"           /* system services */
#include "cm_ss7.x"        /* general SS7 layer */
#include "cm_hash.x"       /* hash-list header */
#include "lsi.x"           /* layer management */
#include "si_mf.x"         /* message functions */
#include "cm5.x"           /* timers */
#include "ci_db.x"         /* isup data base */
#include "sit.x"           /* isup layer */
#ifdef SI_SPT
#include "spt.x"           /* SCCP */
#endif
#ifdef SI_FTHA
#include "sht.x"           /* sht interface */
#endif
#include "si.x"            /* isup */

#ifdef IW
#include "cm_atm.x"          /* common ATM defines                  */
#include "cm_cc.x"           /* Common Call Control Typedefs        */
#include "rmt.x"             /* resource manager function decls.    */
#include "cct.x"             /* Call Control Interface              */
#include "liw.x"             /* ISUP PSIF Layer Management typedefs */
#include "iw.x"              /* ISUP PSIF Typedefs                  */
#endif
#ifdef ZI
#include "cm_pftha.x"      /* common PSF */
#ifdef TDS_CORE2
#include "cm_ftha.x"       /* common PSF */
#include "cm_psfft.x"      /* common PSF */
#endif

#include "lzi.x"           /* ISUP PSF management */
#include "zi.x"            /* ISUP PSF */
#endif /* ZI */


/* local defines */

/* local typedefs */
  
/* local externs */

/* forward references */

PRIVATE S16 siOutUNXMSG ARGS((SiCon *siCon));
PRIVATE S16 siOutUNXEVT ARGS((SiCon *siCon));
PRIVATE S16 siOutE00S02 ARGS((SiCon *siCon));
PRIVATE S16 siOutE01S02 ARGS((SiCon *siCon));
PRIVATE S16 siOutE01S03 ARGS((SiCon *siCon));
PRIVATE S16 siOutE02S04 ARGS((SiCon *siCon));
PRIVATE S16 siOutE03S04 ARGS((SiCon *siCon));
PRIVATE S16 siOutE04S04 ARGS((SiCon *siCon));
PRIVATE S16 siOutE05S01 ARGS((SiCon *siCon));
PRIVATE S16 siOutE05S02 ARGS((SiCon *siCon));
PRIVATE S16 siOutE05S03 ARGS((SiCon *siCon));
PRIVATE S16 siOutE06SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE07S02 ARGS((SiCon *siCon));
PRIVATE S16 siOutE10SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE11SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE12SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE14SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE15SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE16SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE16S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE17SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE17S06 ARGS((SiCon *siCon));
PRIVATE S16 siOutE17S07 ARGS((SiCon *siCon));
PRIVATE S16 siOutE18S01 ARGS((SiCon *siCon));
PRIVATE S16 siOutE18SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE18S06 ARGS((SiCon *siCon));
PRIVATE S16 siOutE18S08 ARGS((SiCon *siCon));
PRIVATE S16 siOutE19S05 ARGS((SiCon *siCon));
PRIVATE S16 siOutE21S04 ARGS((SiCon *siCon));
PRIVATE S16 siOutE21S05 ARGS((SiCon *siCon));
PRIVATE S16 siOutE22SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE23SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE25S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE27S01 ARGS((SiCon *siCon));
PRIVATE S16 siOutE27SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE27S06 ARGS((SiCon *siCon));
PRIVATE S16 siOutE28SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE28S07 ARGS((SiCon *siCon));
PRIVATE S16 siOutE29S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE29S06 ARGS((SiCon *siCon));
PRIVATE S16 siOutE29S07 ARGS((SiCon *siCon));
PRIVATE S16 siOutE29S08 ARGS((SiCon *siCon));
PRIVATE S16 siOutE30SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE31S04 ARGS((SiCon *siCon));
PRIVATE S16 siOutE31S05 ARGS((SiCon *siCon));
PRIVATE S16 siOutE32S05 ARGS((SiCon *siCon));
PRIVATE S16 siOutE33SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE34SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE35S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE35S01 ARGS((SiCon *siCon));
PRIVATE S16 siOutE36S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE36S06 ARGS((SiCon *siCon));
PRIVATE S16 siOutE36S07 ARGS((SiCon *siCon));
PRIVATE S16 siOutE36S08 ARGS((SiCon *siCon));
PRIVATE S16 siOutE36SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE37S00 ARGS((SiCon *siCon));
PRIVATE S16 siOutE37SND ARGS((SiCon *siCon));
PRIVATE S16 siOutE38SND ARGS((SiCon *siCon));

/* public variable declarations */


/* connection matrix - incoming connections */

PFSIM siConOut[NMB_ICON_EVNT][NMB_OUT_CON_ST] =
{
   /* Address Complete */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE00S02,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Answer */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE01S02,      /* 02  - waiting for ACM                    */
      siOutE01S03,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Complete */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutE02S04,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Request */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutE03S04,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Modification Rejected */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutE04S04,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Progress */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutE05S01,      /* 01  - waiting for Continuity             */
      siOutE05S02,      /* 02  - waiting for ACM                    */
      siOutE05S03,      /* 03  - waiting for Answer                 */
      siOutE05S03,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Confusion */
   {
      siOutE06SND,      /* 00  - idle                               */
      siOutE06SND,      /* 01  - waiting for Continuity             */
      siOutE06SND,      /* 02  - waiting for ACM                    */
      siOutE06SND,      /* 03  - waiting for Answer                 */
      siOutE06SND,      /* 04  - OCG answered                       */
      siOutE06SND,      /* 05  - OCG suspended                      */
      siOutE06SND,      /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Connect */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE07S02,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Continuity */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Continuity check request */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Accepted */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE10SND,      /* 02  - waiting for ACM                    */
      siOutE10SND,      /* 03  - waiting for Answer                 */
      siOutE10SND,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Rejected */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE11SND,      /* 02  - waiting for ACM                    */
      siOutE11SND,      /* 03  - waiting for Answer                 */
      siOutE11SND,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Request */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE12SND,      /* 02  - waiting for ACM                    */
      siOutE12SND,      /* 03  - waiting for Answer                 */
      siOutE12SND,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Forward Transfer */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Information */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutE14SND,      /* 01  - waiting for Continuity             */
      siOutE14SND,      /* 02  - waiting for ACM                    */
      siOutE14SND,      /* 03  - waiting for Answer                 */
      siOutE14SND,      /* 04  - OCG answered                       */
      siOutE14SND,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Information Request */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutE15SND,      /* 01  - waiting for Continuity             */
      siOutE15SND,      /* 02  - waiting for ACM                    */
      siOutE15SND,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Initial Address */
   {
      siOutE16S00,      /* 00  - idle                               */
      siOutE16SND,      /* 01  - waiting for Continuity             */
      siOutE16SND,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siOutUNXMSG,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Release */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutE17SND,      /* 01  - waiting for Continuity             */
      siOutE17SND,      /* 02  - waiting for ACM                    */
      siOutE17SND,      /* 03  - waiting for Answer                 */
      siOutE17SND,      /* 04  - OCG answered                       */
      siOutE17SND,      /* 05  - OCG suspended                      */
      siOutE17S06,      /* 06  - waiting for Release Complete       */
      siOutE17S07,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Complete */
   {
      siIgnore,         /* 00  - idle                               */
      siOutE18S01,      /* 01  - waiting for Continuity             */
      siOutE18SND,      /* 02  - waiting for ACM                    */
      siOutE18SND,      /* 03  - waiting for Answer                 */
      siOutE18SND,      /* 04  - OCG answered                       */
      siOutE18SND,      /* 05  - OCG suspended                      */
      siOutE18S06,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siOutE18S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Resume */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutE19S05,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Subsequent Address */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Suspend */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutE21S04,      /* 04  - OCG answered                       */
      siOutE21S05,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* User to User */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutE22SND,      /* 02  - waiting for ACM                    */
      siOutE22SND,      /* 03  - waiting for Answer                 */
      siOutE22SND,      /* 04  - OCG answered                       */
      siOutUNXMSG,      /* 05  - OCG suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - OCG Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reservation Message */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutE23SND,      /* 01  - waiting for Continuity             */
      siOutE23SND,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - ICC answered                       */
      siOutUNXMSG,      /* 05  - ICC suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - ICC Release Complete               */
      siOutUNXMSG,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reservation Acknowledge Message */
   {
      siOutUNXMSG,      /* 00  - idle                               */
      siOutUNXMSG,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siOutUNXMSG,      /* 03  - waiting for Answer                 */
      siOutUNXMSG,      /* 04  - ICC answered                       */
      siOutUNXMSG,      /* 05  - ICC suspended                      */
      siOutUNXMSG,      /* 06  - waiting for Release Complete       */
      siOutUNXMSG,      /* 07  - ICC Release Complete               */
      siOutUNXMSG,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Establishment Request */
   {
      siOutE25S00,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutUNXEVT,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Establishment Response */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutUNXEVT,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Connection Status Request */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutE27S01,      /* 01  - waiting for Continuity             */
      siOutE27S01,      /* 02  - waiting for ACM                    */
      siOutE27SND,      /* 03  - waiting for Answer                 */
      siOutE27SND,      /* 04  - OCG answered                       */
      siOutE27SND,      /* 05  - OCG suspended                      */
      siOutE27S06,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Request */
   {
      siOutE28SND,      /* 00  - idle                               */
      siOutE28SND,      /* 01  - waiting for Continuity             */
      siOutE28SND,      /* 02  - waiting for ACM                    */
      siOutE28SND,      /* 03  - waiting for Answer                 */
      siOutE28SND,      /* 04  - OCG answered                       */
      siOutE28SND,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutE28S07,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Release Response */
   {
      siOutE29S00,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutUNXEVT,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutE29S06,      /* 06  - waiting for Release Complete       */
      siOutE29S07,      /* 07  - OCG Release Complete               */
      siOutE29S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* User Information Request */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutE30SND,      /* 02  - waiting for ACM                    */
      siOutE30SND,      /* 03  - waiting for Answer                 */
      siOutE30SND,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Suspend Request */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutE31S04,      /* 04  - OCG answered                       */
      siOutE31S05,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Call Resume Request */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutUNXEVT,      /* 04  - OCG answered                       */
      siOutE32S05,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Request */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutE33SND,      /* 02  - waiting for ACM                    */
      siOutE33SND,      /* 03  - waiting for Answer                 */
      siOutE33SND,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Facility Response */
   {
      siOutUNXEVT,      /* 00  - idle                               */
      siOutUNXEVT,      /* 01  - waiting for Continuity             */
      siOutE34SND,      /* 02  - waiting for ACM                    */
      siOutE34SND,      /* 03  - waiting for Answer                 */
      siOutE34SND,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OCG suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Status Request */
   {
      siOutE35S00,      /* 00  - idle                               */
      siOutE35S01,      /* 01  - waiting for Continuity             */
      siOutUNXEVT,      /* 02  - waiting for ACM                    */
      siOutUNXEVT,      /* 03  - waiting for Answer                 */
      siOutUNXEVT,      /* 04  - OCG answered                       */
      siOutUNXEVT,      /* 05  - OGC suspended                      */
      siOutUNXEVT,      /* 06  - waiting for Release Complete       */
      siOutUNXEVT,      /* 07  - OCG Release Complete               */
      siOutUNXEVT,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Circuit Reset Request */
   {
      siOutE36S00,         /* 00  - idle                               */
      siOutE36SND,      /* 01  - waiting for Continuity             */
      siOutE36SND,      /* 02  - waiting for ACM                    */
      siOutE36SND,      /* 03  - waiting for Answer                 */
      siOutE36SND,      /* 04  - OCG answered                       */
      siOutE36SND,      /* 05  - OCG suspended                      */
      siOutE36S06,      /* 06  - waiting for Release Complete       */
      siOutE36S07,      /* 07  - OCG Release Complete               */
      siOutE36S08,      /* 08  - waiting for RLC and RelResp        */
   },

   /* Blocking Request */
   {
      siOutE37S00,      /* 00  - idle                               */
      siOutE37SND,      /* 01  - waiting for Continuity             */
      siOutE37SND,      /* 02  - waiting for ACM                    */
      siIgnore,         /* 03  - waiting for Answer                 */
      siIgnore,         /* 04  - OGC answered                       */
      siIgnore,         /* 05  - OGC suspended                      */
      siIgnore,         /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - OGC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   },

   /* Loopback Acknowledgement */
   {
      siOutE38SND,      /* 00  - idle                               */
      siOutE38SND,      /* 01  - waiting for Continuity             */
      siOutUNXMSG,      /* 02  - waiting for ACM                    */
      siIgnore,         /* 03  - waiting for Answer                 */
      siIgnore,         /* 04  - OGC answered                       */
      siIgnore,         /* 05  - OGC suspended                      */
      siIgnore,         /* 06  - waiting for Release Complete       */
      siIgnore,         /* 07  - OGC Release Complete               */
      siIgnore,         /* 08  - waiting for RLC and RelResp        */
   }
   
};   


/*
*     support functions
*/

  
/*
*
*       Fun:   siOutUNXMSG
*
*       Desc:  Input: out of sequence message
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutUNXMSG
(
SiCon *con 
)
#else
PRIVATE S16 siOutUNXMSG(con)
SiCon *con;
#endif
{
   SiNSAPCb   *dCb;
   SiCirCb    *cir;
   S16        ret;
   SiCauseDgn cause;
   U8       genRscFlg;  /* 0: Reset is not to be generated */

   TRC2(siOutUNXMSG)
   SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "Msg out of sequence !\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI303, (ErrVal) 0, 
                 "siOutUNXMSG() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->outC.cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Outgoing circuit pointer missing; (conState = %#x)\n",
         con->outC.conState));  

      SILOGERROR(ERRCLS_DEBUG, ESI304, (ErrVal) 0, 
         "siOutUNXMSG() Failed, Incoming circuit pointer missing");
      RETVALUE(RFAILED);
   }
   if (con->outC.cir->pIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
         "Interface control block pointer missing; (conState = %#x)\n",
         con->outC.conState));  

      SILOGERROR(ERRCLS_DEBUG, ESI305, (ErrVal) 0, 
         "siOutUNXMSG() Failed, Interface control block pointer missing");
      RETVALUE(RFAILED);
   }
#endif

   dCb = con->mCallCb;
   siChkContin(con);
   genRscFlg = 0;
   switch (con->outC.conState)
   {
      case ST_IDLE:
      case ST_WTFORCONTIN:
      case ST_WTFORACM:
         genRscFlg = 1;
         break;

      default:
         break;
   }
   if (genRscFlg)
   {
      cir = con->outC.cir;
      /* si020.220: Addition - add code to set the noRspFlgToLw
       * so that ISUP doesn't pass the response to network in case of CC
       * response.
       */
      cir->noRspFlgToLw = TRUE;

      if (con->outC.conState != ST_IDLE)
      {
         /* generate a reattempt indication if connection on the circuit has 
          * not received any backward messages required for call set up. 
          */
         MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
                 &meCauseIndV, (U8) PRSNT_DEF, 
                con->outC.cir->pIntfCb->cfg.swtch, (U32) MF_ISUP);

         cause.eh.pres       = PRSNT_NODEF;
         cause.causeVal.pres = PRSNT_NODEF;
         cause.causeVal.val  = SIT_CCREQUNAVAIL;
     
         /* generate reattempt indication */ 
         siGenReatInd(con->outC.cirId, con, &cause);
      }

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* check if this is a non-single rate connection */
      if ((cir->ctrlMultiRateCir != NULLP) &&
          ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) ||
           (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
           (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
           (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
           (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))) 
      {
         /* this is a non-single rate connection. respond a GRS with CAM for
          * ans95 or multiple RSC for itu97 and etsi v3
          */
         siGenMRateRsc(cir->ctrlMultiRateCir);
         RETVALUE(ROK);
      }
      else
#endif
      {              
         /* send an outgoing reset request */
         siProcCirEvt(cir, SIT_STA_CIRRESREQ, FALSE);
         /* generate local reset indication */
         siGenCirEvt(cir, SIT_STA_CIRLOCRES);

      }
   }

   RETVALUE(ROK);
} /* end of siOutUNXMSG */

  
/*
*
*       Fun:   siOutUNXEVT
*
*       Desc:  Input: out of sequence event
*              State: any state
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutUNXEVT
(
SiCon *con 
)
#else
PRIVATE S16 siOutUNXEVT(con)
SiCon *con;
#endif
{
   SiAllSdus ev;

   TRC2(siOutUNXEVT)
   UNUSED(ev);
   SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
       "Event out of sequence !\n"));  

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI306, (ErrVal) 0, 
                 "siOutUNXEVT() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
      /* Generate Alarm to Layer management */
      siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP, 
                    LSI_USTA_DGNVAL_NONE, NULLP);
      SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_INTERFACE, 
                     LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, TRUE, 
                     con->outC.cirId, SI_ALRM_INV_EVENT);
      RETVALUE(RFAILED);
} /* end of siOutUNXEVT */

  
/*
*
*       Fun:   siOutE00S02
*
*       Desc:  Input: Address Complete
*              State: waiting for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE00S02
(
SiCon *con 
)
#else
PRIVATE S16 siOutE00S02(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE00S02)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI307, (ErrVal) 0, 
                 "siOutE00S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI308, (ErrVal) 0, 
                 "siOutE00S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   /* Stop T7 */
   siStopConTmr(con, TMR_T7O);
   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->tCallCb->cfg.swtch)
   {

/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */

#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.addrComp.callRefA.eh.pres) &&
             (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) != NULLP) && 
                        (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef = TRUE;
               con->outC.dCallRef = con->pduSp->m.addrComp.callRefA.callId.val;
               con->outC.phyDpc = con->pduSp->m.addrComp.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif





#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000 
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000 
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.addrComp.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.addrComp.callRef.callId.val;
               con->outC.phyDpc = 
                                (U32)con->pduSp->m.addrComp.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         if ((con->pduSp->m.addrComp.optBckCalInd.eh.pres) &&
             (con->pduSp->m.addrComp.optBckCalInd.simpleSegmInd.pres) && 
             (con->pduSp->m.addrComp.optBckCalInd.simpleSegmInd.val
                == SSI_ADDSEGM) && 
             (con->tCallCb->cfg.swtch != LSI_SW_SINGTEL))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Additional segment expected.\n"));  
            /* start T36 Timer */
            siStartConTmr(TMR_T36O, con, con->tCallCb);

            con->outC.msgToSegm       = con->mCallCb->mfMsgCtl.mp;
            con->mCallCb->mfMsgCtl.mp = NULLP;
            con->outC.eventType       = MI_ADDCOMP;
            siProcIncSegm             = TRUE;

            RETVALUE(ROK);
         }
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI309, (ErrVal) 0, 
                 "siOutE00S02() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* initialize connect status event */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_ADDCOMP, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* change state to Waiting for Answer */
   SISTATECHNG(con->outC.conState , ST_WTFORANSWR);

   {
      /* if answer controlling exchange */
      if (!con->incC.conPrcs)
         /* Start T9 Timer */
         siStartConTmr(TMR_T9, con, con->tCallCb);
   }
   
   /* change circuit state to outgoing busy */
   SISTATECHNG(con->outC.cir->calProcStat, OUTBUSY);

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (con->outC.cir->ctrlMultiRateCir != NULLP)
   {
      if (siChgMRateState(con->outC.cir, OUTBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif
#ifdef ZI
   if (ziCb.updateOption == ZI_UPD_UNANSWRD)
   {
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
      ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) con->outC.cir);
      ziUpdPeer();
   }
#endif

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                  con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                  &ev.m.siCnStEvnt, ADDRCMPLT, uBuf);

   RETVALUE(ROK);
} /* end of siOutE00S02 */

  
/*
*
*       Fun:   siOutE01S02
*
*       Desc:  Input: Answer
*              State: waiting for Address Complete 
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE01S02
(
SiCon *con 
)
#else
PRIVATE S16 siOutE01S02(con)
SiCon *con;
#endif
{

   TRC2(siOutE01S02)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI310, (ErrVal) 0, 
                 "siOutE01S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI311, (ErrVal) 0, 
                 "siOutE01S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
/* si029.220: Modification - added INDIA switch */
   if ((con->tCallCb->cfg.swtch == LSI_SW_ITU) || 
       (con->tCallCb->cfg.swtch == LSI_SW_ITU97) || 
       (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) || 
       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) || 
       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) || 
       (con->tCallCb->cfg.swtch == LSI_SW_ETSI) || 
       (con->tCallCb->cfg.swtch == LSI_SW_INDIA) ||
       (con->tCallCb->cfg.swtch == LSI_SW_CHINA))
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch either itu/etsi/India/China. Dumping\n"));  
      siOutUNXMSG(con);
      RETVALUE(ROK);
   }


   RETVALUE(ROK);
} /* end of siOutE01S02 */

  
/*
*
*       Fun:   siOutE01S03
*
*       Desc:  Input: Answer
*              State: waiting for Answer
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE01S03
(
SiCon *con 
)
#else
PRIVATE S16 siOutE01S03(con)
SiCon *con;
#endif
{
   SiAllSdus  ev;
   S16        ret;
   Buffer     *uBuf;

   TRC2(siOutE01S03)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI312, (ErrVal) 0, 
                 "siOutE01S03() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI313, (ErrVal) 0, 
                 "siOutE01S03() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   {
      /* Stop T9 */
      siStopConTmr(con, TMR_T9);
   }

   switch (con->tCallCb->cfg.swtch)
   {

/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.answer.callRefA.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.answer.callRefA.callId.val;
               con->outC.phyDpc = con->pduSp->m.answer.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif




#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.answer.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.answer.callRef.callId.val;
               con->outC.phyDpc = (U32)con->pduSp->m.answer.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         if ((con->pduSp->m.answer.optBckCalInd.eh.pres) &&
             (con->pduSp->m.answer.optBckCalInd.simpleSegmInd.pres) && 
             (con->pduSp->m.answer.optBckCalInd.simpleSegmInd.val
                 == SSI_ADDSEGM) && 
             (con->tCallCb->cfg.swtch != LSI_SW_SINGTEL))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Additional segment expected.\n"));  
            /* start T36 Timer */
            siStartConTmr(TMR_T36O, con, con->tCallCb);
            con->outC.msgToSegm       = con->mCallCb->mfMsgCtl.mp;
            con->mCallCb->mfMsgCtl.mp = NULLP;
            con->outC.eventType       = MI_ANSWER;
            siProcIncSegm             = TRUE;

            RETVALUE(ROK);
         }
         break;



#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI314, (ErrVal) 0, 
                 "siOutE01S03() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* initialize connect event */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_ANSWER, (U8) SI_CONREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* change state to Answered */
   SISTATECHNG(con->outC.conState, ST_ANSWRD);
   /* change circuit state to outgoing busy */
   SISTATECHNG(con->outC.cir->calProcStat, OUTBUSY);
   
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (con->outC.cir->ctrlMultiRateCir != NULLP) 
   {
      /* this is a non-single rate connection */
      if (siChgMRateState(con->outC.cir, OUTBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif

   switch(con->tCallCb->cfg.swtch)
   {

      default:
         break;
   }

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

#if SI_ACNT
   if (siCb.init.acnt)
      SGetSysTime(&con->calDura);
#endif

#ifdef ZI
   if (ziCb.updateOption == ZI_UPD_UNANSWRD)
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_UPD_REQ, (PTR) con);
   else
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) con->outC.cir);
   ziUpdPeer();
#endif

   SiUiSitConCfm(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siConEvnt, 
                 uBuf);
   RETVALUE(ROK);
} /* end of siOutE01S03 */

  
/*
*
*       Fun:   siOutE02S04
*
*       Desc:  Input: Call Modification Complete
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE02S04
(
SiCon *con 
)
#else
PRIVATE S16 siOutE02S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE02S04)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI315, (ErrVal) 0, 
                 "siOutE02S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI316, (ErrVal) 0, 
                 "siOutE02S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif



/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
   if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
   { 
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch is itu97/etsi v3/India Dumping event\n"));
      RETVALUE(ROK);
   }
#endif

   switch (con->tCallCb->cfg.swtch)
   {



      case LSI_SW_ITU:
         if ((con->pduSp->m.caModComp.callRef.eh.pres) && 
             (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) != NULLP) && 
                (con->sCallCb->state == SI_BND))
            {
               con->outC.dCallRef = con->pduSp->m.caModComp.callRef.callId.val;
               con->outC.phyDpc = 
                               (U32)con->pduSp->m.caModComp.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI317, (ErrVal) 0, 
                 "siOutE02S02() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   if (con->outC.cllModProc == TRUE)
   {
      con->outC.cllModProc = FALSE;
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODCOMP, 
                (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      uBuf = con->mCallCb->mfMsgCtl.uBuf;
      con->mCallCb->mfMsgCtl.uBuf = NULLP;

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                     con->key.k1.spInstId, con->outC.cirId, &ev.m.siCnStEvnt, 
                     MODCMPLT, uBuf);
   }
   else
      /* unexpected message */
      siOutUNXMSG(con);

   RETVALUE(ROK);
} /* end of siOutE02S04 */

  
/*
*
*       Fun:   siOutE03S04
*
*       Desc:  Input: Call Modification Request
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE03S04
(
SiCon *con 
)
#else
PRIVATE S16 siOutE03S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiPduHdr  pduHdr;
   SiAllSdus ev;
   SiAllPdus message;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE03S04)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI318, (ErrVal) 0, 
                 "siOutE03S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI319, (ErrVal) 0, 
                 "siOutE03S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI320, (ErrVal) 0, 
                 "siOutE03S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif



/*si034.220 : Drop msg */
#if SS7_CHINA
  if (con->tCallCb->cfg.swtch == LSI_SW_CHINA)
   {
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
              "swtch == LSI_SW_CHINA therefore event dumped\n"));
      siOutUNXMSG(con);
      RETVALUE(ROK);
   }
#endif

/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_ETSIV3 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
   if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
       (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
   { 
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch is itu97/etsi v3/India Dumping event\n"));
      RETVALUE(ROK);
   }
#endif

   switch (con->tCallCb->cfg.swtch)
   {



      case LSI_SW_ITU:
         if ((con->pduSp->m.caModReq.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetLwrSCbPtr(cir)) != NULLP) &&
                (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.caModReq.callRef.callId.val;
               con->outC.phyDpc = 
                               (U32)con->pduSp->m.caModReq.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI321, (ErrVal) 0, 
                 "siOutE03S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   if (con->tCallCb->cfg.allCallMod)
   {
      con->outC.cllModProc = TRUE;
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREQ, 
                (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      uBuf = con->mCallCb->mfMsgCtl.uBuf;
      con->mCallCb->mfMsgCtl.uBuf = NULLP;

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                     con->key.k1.spInstId, con->outC.cirId, &ev.m.siCnStEvnt, 
                     MODIFY, uBuf);
   }
   else
   {
      /* init modification reject */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_CALLMODREJ;

      MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREQ, (U8)
                MI_CALLMODREJ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &message,
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      /* if required, insert call reference */
      siInsCallRef(cir, &message, pduHdr.msgType.val);

      /* send message */
      siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_CALLMODREJ, con->tCallCb->cfg.swtch), NULLP);
   }
   RETVALUE(ROK);
} /* end of siOutE03S04 */

  
/*
*
*       Fun:   siOutE04S04
*
*       Desc:  Input: Call Modification Reject
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE04S04
(
SiCon *con 
)
#else
PRIVATE S16 siOutE04S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE04S04)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI322, (ErrVal) 0, 
                 "siOutE04S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI323, (ErrVal) 0, 
                 "siOutE04S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif





/* si029.220: Modification - added INDIA switch */
#if (SS7_ITU97 || SS7_ETSIV3 || SS7_INDIA)
   if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
       (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
   { 
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch is itu97/etsi v3/India, Dumping event\n"));
      RETVALUE(ROK);
   }
#endif

   switch (con->tCallCb->cfg.swtch)
   {


      case LSI_SW_ITU:
         if ((con->pduSp->m.caModRej.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->outC.dCallRef = con->pduSp->m.caModRej.callRef.callId.val;
               con->outC.phyDpc = 
                               (U32)con->pduSp->m.caModRej.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI324, (ErrVal) 0, 
                 "siOutE04S04() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   if (con->outC.cllModProc == TRUE)
   {
      con->outC.cllModProc = FALSE;

      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLMODREJ, 
                (U8) SI_CNSTREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);

      uBuf = con->mCallCb->mfMsgCtl.uBuf;
      con->mCallCb->mfMsgCtl.uBuf = NULLP;

      SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                     con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                     &ev.m.siCnStEvnt, MODREJ, uBuf);
   }
   else
      /* unexpected message */
      siOutUNXMSG(con);
   RETVALUE(ROK);
} /* end of siOutE04S04 */

  
/*
*
*       Fun:   siOutE05S01
*
*       Desc:  Input: Call Progress Message
*              State: waiting for Continuity
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE05S01
(
SiCon *con
)
#else
PRIVATE S16 siOutE05S01(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;
   SiNSAPCb   *dCb;

   TRC2(siOutE05S01)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI325, (ErrVal) 0,
                 "siOutE05S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));

      SILOGERROR(ERRCLS_DEBUG, ESI326, (ErrVal) 0,
                 "siOutE05S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   dCb = con->mCallCb;
   cir = con->outC.cir;
      siOutUNXMSG(con);
   RETVALUE(ROK);
} /* end of siOutE05S01 */

  
/*
*
*       Fun:   siOutE05S02
*
*       Desc:  Input: Call Progress Message
*              State: waiting for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE05S02
(
SiCon *con 
)
#else
PRIVATE S16 siOutE05S02(con)
SiCon *con;
#endif
{

   TRC2(siOutE05S02)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI327, (ErrVal) 0, 
                 "siOutE05S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI328, (ErrVal) 0, 
                 "siOutE05S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   {
      /* For all other variants call the hdlr function the message */
      siOutE05S03(con);
   }
   RETVALUE(ROK);
} /* end of siOutE05S02 */

  
/*
*
*       Fun:   siOutE05S03
*
*       Desc:  Input: Call Progress
*              State: waiting for Answer and answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE05S03
(
SiCon *con 
)
#else
PRIVATE S16 siOutE05S03(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE05S03)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI329, (ErrVal) 0, 
                 "siOutE05S03() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI330, (ErrVal) 0, 
                 "siOutE05S03() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   if ((con->pduSp->m.caProg.callRef.eh.pres) && (!con->outC.dCallRef))
   {  
      if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
            con->mCallCb->cfg.ssf)) != NULLP) &&
                (con->sCallCb->state == SI_BND))
      {
         con->exchCalRef    = TRUE;
         con->outC.dCallRef = con->pduSp->m.caProg.callRef.callId.val;
         con->outC.phyDpc      = (U32) con->pduSp->m.caProg.callRef.pntCde.val;
      } 
      else
      {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
      } 
   } 
   else 
   {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

   } 

   switch (con->tCallCb->cfg.swtch)
   {








#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         if ((con->pduSp->m.caProg.optBckCalInd.eh.pres) &&
             (con->pduSp->m.caProg.optBckCalInd.simpleSegmInd.pres) && 
             (con->pduSp->m.caProg.optBckCalInd.simpleSegmInd.val
                 == SSI_ADDSEGM))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Additional segment expected.\n"));  
            /* start T36 Timer */
            siStartConTmr(TMR_T36O, con, con->tCallCb);
 
            con->outC.msgToSegm       = con->mCallCb->mfMsgCtl.mp;
            con->mCallCb->mfMsgCtl.mp = NULLP;
            con->outC.eventType       = MI_CALLPROG;
            siProcIncSegm             = TRUE;
            RETVALUE(ROK);
         }
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI331, (ErrVal) 0,
                 "siOutE05S03() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* initialize connect status event */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CALLPROG, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId,
                  con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                  &ev.m.siCnStEvnt, PROGRESS, uBuf);
   RETVALUE(ROK);
} /* end of siOutE05S03 */

  
/*
*
*       Fun:   siOutE06SND
*
*       Desc:  Input: Confusion
*              State: idle through ICC suspended.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE06SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE06SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE06SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI332, (ErrVal) 0, 
                 "siOutE06SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI333, (ErrVal) 0, 
                 "siOutE06SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif




   /* initialize siStaEvnt */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CONFUSION, (U8) SI_STAREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   
   /* send confusion to the upper layer */
   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, FALSE, 
                 SIT_STA_CONFUSION, &ev.m.siStaEvnt, uBuf);
   RETVALUE(ROK);
} /* end of siOutE06SND */

  
/*
*
*       Fun:   siOutE07S02
*
*       Desc:  Input: Connect
*              State: waiting for ACM
*
*       Ret:   ROK      - ok

*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE07S02
(
SiCon *con 
)
#else
PRIVATE S16 siOutE07S02(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE07S02)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI334, (ErrVal) 0, 
                 "siOutE07S02() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI335, (ErrVal) 0, 
                 "siOutE07S02() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop T7 */
   siStopConTmr(con, TMR_T7O);

   if ((con->pduSp->m.connect.callRef.eh.pres) && (!con->outC.dCallRef))
   {  
      if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
            con->mCallCb->cfg.ssf)) != NULLP) &&
                (con->sCallCb->state == SI_BND))
      {
         con->exchCalRef = TRUE;
         con->outC.dCallRef = con->pduSp->m.connect.callRef.callId.val;
         con->outC.phyDpc = (U32) con->pduSp->m.connect.callRef.pntCde.val;
      } 
      else
      {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
      } 
   } 
   else 
   {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

   } 

   switch (con->tCallCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         if ((con->pduSp->m.connect.optBckCalInd.eh.pres) &&
             (con->pduSp->m.connect.optBckCalInd.simpleSegmInd.pres) && 
             (con->pduSp->m.connect.optBckCalInd.simpleSegmInd.val
                 == SSI_ADDSEGM))
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Additional segment expected.\n"));  
            /* start T36 Timer */
            siStartConTmr(TMR_T36O, con, con->tCallCb);
 
            con->outC.msgToSegm       = con->mCallCb->mfMsgCtl.mp;
            con->mCallCb->mfMsgCtl.mp = NULLP;
            con->outC.eventType       = MI_CONNCT;
            siProcIncSegm             = TRUE;

            RETVALUE(ROK);
         }
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  
         SILOGERROR(ERRCLS_DEBUG, ESI336, (ErrVal) 0,
                 "siOutE07S02() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }
 
   /* initialize connect event */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_CONNCT, (U8) SI_CONREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* change state to Answered */
   SISTATECHNG(con->outC.conState, ST_ANSWRD);
   /* change circuit state to outgoing busy */
   SISTATECHNG(con->outC.cir->calProcStat, OUTBUSY);

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000  || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (con->outC.cir->ctrlMultiRateCir != NULLP) 
   {
      /* this is a non-single rate connection */
      if (siChgMRateState(con->outC.cir, OUTBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;


#if SI_ACNT
   if (siCb.init.acnt)
      SGetSysTime(&con->calDura);
#endif

#ifdef ZI
   ziRunTimeUpd(ZI_CON_CB, CMPFTHA_CREATE_REQ, (PTR) con);
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) con->outC.cir);
   ziUpdPeer();
#endif

   SiUiSitConCfm(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siConEvnt, 
                 uBuf);
   RETVALUE(ROK);
} /* end of siOutE07S02 */
  
/*
*
*       Fun:   siOutE10SND
*
*       Desc:  Input: Facility Accepted
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE10SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE10SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE10SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI337, (ErrVal) 0, 
                 "siOutE10SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI338, (ErrVal) 0, 
                 "siOutE10SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif



   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_FACACC, (U8) SI_FACREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitFacCfm(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, SIT_FACACC, 
                 &ev.m.siFacEvnt, uBuf);
   RETVALUE(ROK);
} /* end of siOutE10SND */

  
/*
*
*       Fun:   siOutE11SND
*
*       Desc:  Input: Facility Rejected
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE11SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE11SND(con)
SiCon *con;
#endif
{
   SiAllSdus  ev;
   S16        ret;
   Buffer     *uBuf;

   TRC2(siOutE11SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI339, (ErrVal) 0, 
                 "siOutE11SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI340, (ErrVal) 0, 
                 "siOutE11SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif


   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_FACREJ, (U8) SI_FACREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitFacCfm(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, SIT_FACREJ, 
                 &ev.m.siFacEvnt, uBuf);
   RETVALUE(ROK);
} /* end of siOutE11SND */

  
/*
*
*       Fun:   siOutE12SND
*
*       Desc:  Input: Facility Request
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE12SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE12SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   U8        event;
   Buffer    *uBuf;

   TRC2(siOutE12SND)
   event = 0;
   
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI341, (ErrVal) 0, 
                 "siOutE12SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI342, (ErrVal) 0, 
                 "siOutE12SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif



   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) con->evntType, (U8) SI_FACREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   switch(con->tCallCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         switch (con->evntType)
         {
            case MI_FACIL:
               event = SIT_FACIL;
               break;

            case MI_FACREQ:
               event = SIT_FACREQ;
               break;

            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid %d evntType.dumped\n", con->evntType));  
               RETVALUE(ROK);
         }
         break;

      default:
         break;
   }

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   SiUiSitFacInd(&con->tCallCb->pst, con->tCallCb->suId,
                 con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                 event, &ev.m.siFacEvnt, uBuf);

   RETVALUE(ROK);
} /* end of siOutE12SND */

  
/*
*
*       Fun:   siOutE14SND
*
*       Desc:  Input: Information
*              State: Establishing states
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE14SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE14SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   U8        tmrNum;
   Buffer    *uBuf;

   TRC2(siOutE14SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI343, (ErrVal) 0, 
                 "siOutE14SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI344, (ErrVal) 0, 
                 "siOutE14SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* check the timer T33 for solicited INF. If the timer is running, 
    * stop it
    */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt == TMR_T33O) &&
          (con->pduSp->m.info.infoInd.eh.pres) &&
          (con->pduSp->m.info.infoInd.solInfoInd.pres) &&
          (con->pduSp->m.info.infoInd.solInfoInd.val ==
           SOLINFO_SOLICIT))
          
      {
         siStopConTmr(con, TMR_T33O);
      }

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.info.callRefA.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) != NULLP) && 
                (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.info.callRefA.callId.val;
               con->outC.phyDpc      = con->pduSp->m.info.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.info.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) != NULLP) && 
                (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.info.callRef.callId.val;
               con->outC.phyDpc = (U32) con->pduSp->m.info.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI345, (ErrVal) 0, 
                 "siOutE14SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }
   /* Stop T33 */
   siStopConTmr(con, TMR_T33O);

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_INFORMTN, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->outC.cirId, &ev.m.siCnStEvnt, 
                  INFORMATION, uBuf);
   RETVALUE(ROK);
} /* end of siOutE14SND */

  
/*
*
*       Fun:   siOutE15SND
*
*       Desc:  Input: Information Request
*              State: Establishing states
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE15SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE15SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE15SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI346, (ErrVal) 0, 
                 "siOutE15SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI347, (ErrVal) 0, 
                 "siOutE15SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
         if ((con->pduSp->m.info.callRefA.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                  con->mCallCb->cfg.ssf)) 
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.info.callRefA.callId.val;
               con->outC.phyDpc      = con->pduSp->m.info.callRefA.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#endif

#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         if ((con->pduSp->m.info.callRef.eh.pres) && (!con->outC.dCallRef))
         {  
            if (((con->sCallCb = siGetSCbPtr(con->mCallCb->cfg.nwId,
                 con->mCallCb->cfg.ssf))
                 != NULLP) && (con->sCallCb->state == SI_BND))
            {
               con->exchCalRef    = TRUE;
               con->outC.dCallRef = con->pduSp->m.info.callRef.callId.val;
               con->outC.phyDpc = (U32) con->pduSp->m.info.callRef.pntCde.val;
            } 
            else
            {  
               SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "either sCallCb 0x%lx not found or state not bound\n",
                           (U32 )con->sCallCb));  
            } 
         } 
         else 
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "callRef not present\n"));  

         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI348, (ErrVal) 0, 
                 "siOutE15SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_INFOREQ, (U8) SI_CNSTREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   SiUiSitCnStInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->outC.cirId, &ev.m.siCnStEvnt, 
                  INFORMATREQ, uBuf);
   RETVALUE(ROK);
} /* end of siOutE15SND */
      
  
/*
*
*       Fun:   siOutE16S00
*
*       Desc:  Input: Initail Address Message
*              State: idle state 
*
*       Ret:   ROK      - ok
*
*       Notes: This message is possible if ISUP has already sent
*              a CCR and then IAM comes from the peer. 
*              
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE16S00
(
SiCon *con 
)
#else
PRIVATE S16 siOutE16S00(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;

   TRC2(siOutE16S00)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI349, (ErrVal) 0, 
                 "siOutE16S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI350, (ErrVal) 0, 
                 "siOutE16S00() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI351, (ErrVal) 0, 
                 "siOutE16S00() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   {
      /* Generate Status Indication to Upper Layer to stop continuity check */
      siChkContin(con);
      con->suInstId              = 0;
      SISTATECHNG(con->outC.cir->calProcStat, CALL_IDLE);
      if( ! con->incC.conPrcs )
      {
         con->outC.relResp = FALSE; /* This is to bypass the check in
                                     * siClearOutCon
                                     */ 
         if (con->key.k1.spInstId)  /* This is to avoid the double
                                     * insertion in siIncE16S00
                                     */
         {
            siDelInst(&siCb.conHlCp, con);
            con->key.k1.spInstId = 0;
         }
         con->incC.conPrcs          = TRUE;
         con->incC.cir              = cir;
         con->incC.cirId            = cir->cfg.cirId;
         siClearOutCon(con);
      }
      else
      {
         SiCon *prevcon;
         CirCon concpy;
 
         prevcon = con;
         siClearOutCon(prevcon);
         cir->siCon = NULLP;
         con = siGetIncCon(cir, prevcon->mCallCb); 
         if( con == NULLP )
         {
            SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
              "Can not allocate a connection block\n")); 
            RETVALUE(ROK);
         }
         cmMemcpy((U8 *)&concpy, (U8 *)&con->incC, sizeof(CirCon));
         cmMemcpy((U8 *)con, (U8 *)prevcon, sizeof(SiCon));
         cmMemcpy((U8 *)&con->incC, (U8 *)&concpy, sizeof(CirCon));
         /* si025.220 - Modification - modify arguments in siGetLnkSel */
         /* si009.220 - Modified: to pass cic into siGetLnkSel. */
         siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);
         cmMemset((U8 *)&prevcon->outC, 0, sizeof(CirCon));
      }
      cir->siCon                 = con;
      siIncE16S00(con);
   } 
   RETVALUE(ROK);
} /* end of siOutE16S00 */

  
/*
*
*       Fun:   siOutE16SND
*
*       Desc:  Input: Initail Address Message
*              State: Establishing states
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE16SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE16SND(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;
   SiCauseDgn cause;
   S16        ret;
   Bool       cirCtrlFlg;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   U8         transRate;      /* incoming IAM's transter rate */
   Bool       mulCallFlg;     /* incoming IAM is a non-single rate call flg */
   Bool       contiMRateCall; /* incoming IAM contiguous call flag */
#endif

   TRC2(siOutE16SND)
   cir = con->outC.cir;
   cirCtrlFlg = TRUE;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI352, (ErrVal) 0, 
                 "siOutE16SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI353, (ErrVal) 0, 
                 "siOutE16SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI354, (ErrVal) 0, 
                 "siOutE16SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   mulCallFlg = FALSE;
   contiMRateCall = TRUE;
   transRate = 0;
#endif

   if (cir->calProcStat == OUTBUSY)
   {
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      /* dual seizure is detected. Check if this happened between single rate 
       * and single rate calls or between non-single rate and single rate 
       * calls or between two non-single rate calls. Then determine which is 
       * the controlling end
       */ 
      
      switch (con->tCallCb->cfg.swtch)
      {

#ifdef SS7_ITU97
          case LSI_SW_ITU97:
             transRate = con->pduSp->m.initAddr.txMedReq.trMedReq.val;
             if (transRate > TMR_64KBITSPREF)
                mulCallFlg = TRUE;
             if (con->pduSp->m.initAddr.cirAsgnMap.eh.pres)
                contiMRateCall = FALSE;
             break;
#endif
#ifdef SS7_ITU2000
          case LSI_SW_ITU2000:
             transRate = con->pduSp->m.initAddr.txMedReq.trMedReq.val;
             if (transRate > TMR_64KBITSPREF)
                mulCallFlg = TRUE;
             if (con->pduSp->m.initAddr.cirAsgnMap.eh.pres)
                contiMRateCall = FALSE;
             break;
#endif
#ifdef SS7_RUSS2000
          case LSI_SW_RUSS2000:
             transRate = con->pduSp->m.initAddr.txMedReq.trMedReq.val;
             if (transRate > TMR_64KBITSPREF)
                mulCallFlg = TRUE;
             if (con->pduSp->m.initAddr.cirAsgnMap.eh.pres)
                contiMRateCall = FALSE;
             break;
#endif


          default:
             mulCallFlg = FALSE;
             break;
      }         
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

      /* determine which is the controlling end */
      switch (con->tCallCb->cfg.swtch)
      {
#ifdef SS7_ITU97
          case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
        case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
        case LSI_SW_RUSS2000:
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
             if (!mulCallFlg)
             {
                /* incoming is a single rate call. Check the type of outgoing
                 * call
                 */
                if (cir->ctrlMultiRateCir == NULLP)
                {
                   /* dual seizure between two single rate calls. Only check 
                    * the cir->cirCtl field to determine the controlling end
                    */
                   cirCtrlFlg = cir->cirCtl;
                }
                else
                {
                   /* Outgoing is a non-single rate call. Dual seizure between 
                    * a non-single rate call and single rate call. 
                    */
                  if ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) &&
                      (cir->cfg.ctrlMult != LSI_CIR_MRATE_CTRL)) 
                  {
                     /* For ans95, it uses "all-none" method to reslove the 
                      * dual seizure for this case. The default value
                      * of cirCtrlFlg is TRUE. Only if ctrlMult indicates
                      * need to accept incoming IAM, then reset cirCtrlFlg
                      * to FALSE.
                      */ 
                     cirCtrlFlg = FALSE;
                  }
                  if ((con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
                      (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
                       (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
                       (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))
                     /* For ITU97 and ETSI v 3, bigger N control. The outgoing 
                      * will always control. 
                      */
                     cirCtrlFlg = TRUE;
                }
             }
             else
             {
                /* dual seizure between two calls which incoming is a 
                 * non-single rate call. 
                 */
                if (siChkMultiDualSeiz(cir, cir, contiMRateCall, transRate) 
                    == INCOMING_CTRL) 
                {
                   /* need to accept the incoming IAM */
                   cirCtrlFlg = FALSE;
                }
                /* else, need to discard the incoming IAM */
             }
             break;
#endif
          default:
             cirCtrlFlg = cir->cirCtl;
             break;
       }             

      /* if not controlling circuit : rh */
      if (!cirCtrlFlg)
      {
         if ((con->pduSp->m.initAddr.cgPtyCat.cgPtyCat.val == CAT_PRIOR) ||
                (cir->siCon->outC.conState < ST_WTFORANSWR))
         {
            /* Status Indication to Upper Layer to stop continuity check */
            siChkContin(con);
            MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP, 
                       (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF, 
                       con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            cause.causeVal.pres = PRSNT_NODEF;
            cause.causeVal.val  = SIT_CCREQUNAVAIL;

            siGenReatInd(cir->cfg.cirId, con, &cause);

            con->suInstId              = 0;
            SISTATECHNG(con->outC.cir->calProcStat, CALL_IDLE);
            if( ! con->incC.conPrcs )
            {
               con->outC.relResp = FALSE; /* To bypass the check in the
                                           * siClearOutCon
                                           */
               con->incC.conPrcs          = TRUE;
               con->incC.cir              = cir;
               con->incC.cirId            = cir->cfg.cirId;
               siClearOutCon(con);
            }
            else
            {
               SiCon *prevcon;
               CirCon concpy;
               SiNSAPCb *nCb;

               prevcon = con;
               nCb = prevcon->mCallCb;
               siClearOutCon(prevcon);
               cir->siCon = NULLP;
               con = siGetIncCon(cir, nCb); 
               if( con == NULLP )
               {
                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    "Can not allocate a connection block\n")); 
                  RETVALUE(ROK);
               }
               cmMemcpy((U8 *)&concpy, (U8 *)&con->incC, sizeof(CirCon));
               cmMemcpy((U8 *)con, (U8 *)prevcon, sizeof(SiCon));
               cmMemcpy((U8 *)&con->incC, (U8 *)&concpy, sizeof(CirCon));
               /* si025.220 - Modification - modify arguments in siGetLnkSel */
               /* si009.220 - Modified: to pass cic into siGetLnkSel. */
               siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);
               cmMemset((U8 *)&prevcon->outC, 0, sizeof(CirCon));
            }
            cir->siCon                 = con;
            siIncE16S00(con);
         }
      } 
      else
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "IAM on controlling ckt with an outgoing non-idle con\n"));  
      } 
   } 
   else
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "IAM for incbusy ckt in non-idle case rcvd.Dumped\n"));  
   } 

   RETVALUE(ROK);
} /* end of siOutE16SND */


  
/*
*
*       Fun:   siOutE17SND
*
*       Desc:  Input: Release
*              State: Waiting for COT through Suspended.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE17SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE17SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE17SND)

/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
   if((con->mCallCb == NULLP) || (con->tCallCb == NULLP))
   {
/* si055.220 : Changed NULL to NULLP */
          siUpdErrSts(NULLP,LSI_STS_RELFAIL);
   }
#endif /* SI_LMINT3 , SMSI_LMINT3 */

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI359, (ErrVal) 0, 
                 "siOutE17SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI360, (ErrVal) 0, 
                 "siOutE17SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif



   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELSE, (U8) SI_RELREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

#if SI_ACNT
   /* if responsible for charging, generate bill */
   if ((con->outC.conState > ST_WTFORANSWR) && (con->charge))
      siGenBill(con);
#endif

   /* change state */
   SISTATECHNG(con->outC.conState , ST_WTFORRELRSP);
   con->outC.relResp  = TRUE;
   {  
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId,
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) & con->outC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }
   }
   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siRelEvnt,
                 uBuf);

   RETVALUE(ROK);
} /* end of siOutE17SND */

  
/*
*
*       Fun:   siOutE17S06
*
*       Desc:  Input: Release
*              State: Wait for release complete
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE17S06
(
SiCon *con 
)
#else
PRIVATE S16 siOutE17S06(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   S16       ret;
   SiAllSdus ev;
   U8        tmrNum;
   Buffer    *uBuf;

   TRC2(siOutE17S06)
   cir = con->outC.cir;

/* si054.220 : Added Code to update error counter */
#if(SI_LMINT3 || SMSI_LMINT3)
/* si055.220 : Changed NULL to NULLP */
   if((con->mCallCb == NULLP) || (con->tCallCb == NULLP) || (cir == NULLP))
   {
/* si055.220 : Changed NULL to NULLP */
          siUpdErrSts(NULLP,LSI_STS_RELFAIL);
   }
#endif /* SI_LMINT3 , SMSI_LMINT3 */

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI361, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI362, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI363, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   {
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) & con->outC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }
   }
   /* Generate Release Complete Message to Lower Layer */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELCOMP;

   switch (con->tCallCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         {
            U8    onlyRlc;

            onlyRlc = FALSE;
            switch (con->tCallCb->cfg.swtch)
            {
               case LSI_SW_ITU:
#if SS7_ITU97
               case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
              case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
              case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
               case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
/* si026.220: Addition - added ANSI'92 and BELLCORE cases here 
 * so that REL collision is processed in the same way as the 
 * incoming state machine function siIncE17S06.
 */
                  onlyRlc = TRUE; /* just response a RLC */ 
                  break;

               default:
                  break;
            }
            if (onlyRlc == TRUE)
            {
               MFINITPDU(&con->mCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                         (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, 
                         (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, 
                         (U32) MF_ISUP);
               
               siGenPdu(con->mCallCb, &pduHdr, &allPdus, 
                        con->tCallCb->cfg.swtch, cir->opc, cir->cfg.intfId, 
                        cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                        siGetPriority(M_RELCOMP, con->tCallCb->cfg.swtch), 
                        NULLP);
               RETVALUE(ROK);
               
            }
         }
         /* Stop all Timers */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
                (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
               siRmvConTq(con, tmrNum);
        
         if (con->outC.relResp)
         {
           /* Generate Release Confirmation to Upper Layer */
            MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
                      (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);

            uBuf = con->mCallCb->mfMsgCtl.uBuf;
            con->mCallCb->mfMsgCtl.uBuf = NULLP;

            SiUiSitRelCfm(&con->tCallCb->pst, con->tCallCb->suId, 
                          con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                          &ev.m.siRelEvnt, uBuf);
            con->outC.relResp              = FALSE;
         }

         /* initialize message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                   (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         /* generate message */
         siGenPdu(con->mCallCb, &pduHdr, &allPdus, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_RELCOMP,
                  con->tCallCb->cfg.swtch), NULLP);
#ifdef ZI
         ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
         /* clear outgoing connection */
         siClearOutCon(con);
#ifdef ZI
         ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
         ziUpdPeer();
#endif
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI364, (ErrVal) 0, 
                 "siOutE17S06() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   RETVALUE(ROK);
} /* end of siOutE17S06 */

  
/*
*
*       Fun:   siOutE17S07
*
*       Desc:  Input: Release
*              State: Waiting for Release RelResp.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE17S07
(
SiCon *con 
)
#else
PRIVATE S16 siOutE17S07(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE17S07)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI365, (ErrVal) 0, 
                 "siOutE17S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI366, (ErrVal) 0, 
                 "siOutE17S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* ISUP should accept REL from peer node while in waiting for release
    * response from CC. ISUP should send release indication for the subsequent
    * reception of release message. This is happened because release 
    * indication primitive between the CC and ISUP got lost. And peer node 
    * resends the REL on the protocal timer expiry.
    */
   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELSE, (U8) SI_RELREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   con->outC.relResp  = TRUE;
   {  
      if (con->pduSp->m.release.auCongLvl.eh.pres)
      {
         /* generate Alarm */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId,
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) & con->outC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         switch(con->pduSp->m.release.auCongLvl.auCongLvl.val)
         {
            case ACLVL_LVL1:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL1, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_1);
               break;
            case ACLVL_LVL2:
               SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                           LSI_EVENT_REMOTE, LSI_CAUSE_CONG_LVL2, TRUE, 
                           con->outC.cir->cfg.cirId, CONG_LVL_2);
               break;
         }
      }
   }
   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siRelEvnt,
                 uBuf);
   RETVALUE(ROK);
} /* end of siOutE17S07 */




  
/*
*
*       Fun:   siOutE18S01
*
*       Desc:  Input: Release Complete
*              State: Waiting for COT
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE18S01
(
SiCon *con 
)
#else
PRIVATE S16 siOutE18S01(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siOutE18S01)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI379, (ErrVal) 0, 
                 "siOutE18S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI380, (ErrVal) 0, 
                 "siOutE18S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);
   /* Generate Status Indication to Upper Layer to stop continuity check */
   SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, FALSE, 
                 SIT_STA_STPCONTIN, NULLP, NULLP);


   siOutE18SND(con);
   RETVALUE(ROK);
} /* end of siOutE18S01 */

  
/*
*
*       Fun:   siOutE18SND
*
*       Desc:  Input: Release Complete
*              State: Waiting for ACM through Suspended.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE18SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE18SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Status    status;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;
   U16       ustaCause;

   TRC2(siOutE18SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI381, (ErrVal) 0, 
                 "siOutE18SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI382, (ErrVal) 0, 
                 "siOutE18SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

#if SI_ACNT
   /* if responsible for charging, generate bill */
   if ((con->outC.conState > ST_WTFORANSWR) && (con->charge))
   { 
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "generating billing records\n"));  
      siGenBill(con);
   } 
#endif 

   /* change state */
   SISTATECHNG(con->outC.conState , ST_WTFORRLCRRS);
   con->outC.relResp  = TRUE;

   /* Generate Release */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   switch (con->tCallCb->cfg.swtch)
   {

#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
   case LSI_SW_ITU:
      /* Generate Release Indication to Upper Layer */
      MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELCOMP, (U8) SI_RELREQ,
                (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
                con->tCallCb->cfg.swtch, (U32) MF_ISUP);
      /* si042.220 changed how release message is initialized */
      /* initialize Release */
      MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELSE,
                (ElmtHdr *) NULLP, (ElmtHdr *) &message, (U8) PRSNT_DEF,
                con->tCallCb->cfg.swtch, (U32) MF_ISUP);
/*si047.220 Cause diagnose should intialized */
     message.m.release.causeDgn.eh.pres = NOTPRSNT;
      break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI383, (ErrVal) 0, 
                 "siOutE18SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   /* if cause not present, initialize */
   if (message.m.release.causeDgn.eh.pres == NOTPRSNT)
   {
      MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP, 
                 (ElmtHdr *) &message.m.release.causeDgn, &meCauseIndV, 
                 (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
      message.m.release.causeDgn.causeVal.pres = PRSNT_NODEF;
      message.m.release.causeDgn.causeVal.val  = SIT_CCPROTERR;
   }
   message.m.release.causeDgn.recommend.pres = NOTPRSNT;

   if (ev.m.siRelEvnt.causeDgn.eh.pres == NOTPRSNT)
   {
      MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP,
                 (ElmtHdr *) &ev.m.siRelEvnt.causeDgn, &meCauseIndV, 
                 (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   }
   ev.m.siRelEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.causeVal.val  = SIT_CCPROTERR;
   ev.m.siRelEvnt.causeDgn.cdeStand.pres = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.cdeStand.val  = SIT_CSTD_CCITT;
   ev.m.siRelEvnt.causeDgn.location.val = PRSNT_NODEF;
   ev.m.siRelEvnt.causeDgn.location.val = con->tCallCb->cfg.relLocation;

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId,
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siRelEvnt,
                 uBuf);
   {
      /* check resources */
      SChkRes(con->tCallCb->pst.region, con->tCallCb->pst.pool, &status);

      if (status < siCb.genCfg.poolTrUpper)
      {
         ustaCause = LSI_CAUSE_CONG_LVL1;
         message.m.release.auCongLvl.eh.pres          = PRSNT_NODEF;
         message.m.release.auCongLvl.auCongLvl.pres   = PRSNT_NODEF;
         if (status < siCb.genCfg.poolTrLower)
         {
            message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
            ustaCause = LSI_CAUSE_CONG_LVL2;
         }
         else
            message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;
         
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                       LSI_USTA_DGNVAL_INTF, 
                       (PTR) &con->outC.cir->key.k3.intfId, 
                       LSI_USTA_DGNVAL_NONE, NULLP, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LSI_EVENT_REMOTE, ustaCause, TRUE, 
                        con->outC.cir->cfg.cirId, CONG_LVL_2);
      }
   }

      /* build copy of a Release Message */
   if ((ret = siBldMsg(con->mCallCb, con->outC.cir->cfg.cic, &pduHdr, &message,
                       con->mCallCb->pst.region, con->mCallCb->pst.pool,
                       &con->outC.rel, con->tCallCb->cfg.swtch, NULLP)) 
            != ROK)
   {  
      con->outC.rel = NULLP;
   } 

   /* Start T1 Timer */
   siStartConTmr(TMR_T1O, con, con->tCallCb);
   /* Start T5 Timer */
   siStartConTmr(TMR_T5O, con, con->tCallCb);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            con->outC.cir->opc, con->outC.cir->cfg.intfId,
            con->outC.cir->phyDpc, TRUE,
            con->outC.cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_RELSE, con->tCallCb->cfg.swtch), NULLP);

   RETVALUE(ROK);
} /* end of siOutE18SND */

  
/*
*
*       Fun:   siOutE18S06
*
*       Desc:  Input: Release Complete
*              State: Waiting for Release Complete.
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE18S06
(
SiCon *con 
)
#else
PRIVATE S16 siOutE18S06(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   U8        tmrNum;
   S16       ret;
   Buffer    *uBuf;
   SiCirCb   *cir;
   Pst      *pst;
   SuId     suId;
   SiInstId suInstId;
   SiInstId spInstId;
   CirId    cirId;
   U8       relRsp;

   TRC2(siOutE18S06)

   cir = con->outC.cir;
   relRsp = FALSE;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI384, (ErrVal) 0, 
                 "siOutE18S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI385, (ErrVal) 0, 
                 "siOutE18S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* change state */
   SISTATECHNG(con->outC.conState , ST_IDLE);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   pst = &con->tCallCb->pst;
   suId = con->tCallCb->suId;
   suInstId = con->suInstId;
   spInstId = con->key.k1.spInstId;
   cirId = con->outC.cirId;

   if (con->outC.relResp)
   {
      switch (con->tCallCb->cfg.swtch)
      {


#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         /* Generate Release Confirmation to Upper Layer */
         MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RELCOMP, 
                   (U8) SI_RELREQ, (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, 
                   (U8) PRSNT_NODEF, con->tCallCb->cfg.swtch, 
                   (U32) MF_ISUP);
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
           "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI386, (ErrVal) 0, 
                 "siOutE18S06() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
      }

      con->mCallCb->mfMsgCtl.uBuf = NULLP;

/* si014.220, Deletion: Deleted code to update standby copy over here*/
      relRsp = con->outC.relResp;
   }
   else 
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "con->outC.relResp is not SET\n"));  
      SISNDOLDLSISTAIND(&siCb.init.lmPst, con->outC.cir->cfg.cirId, RLC_RCVD);
   } 

#ifdef IW
   if ((con->contCrm & SI_REL_UPLW) && (con->tCallCb))
   {
      SiUiSitStaInd(pst, suId, suInstId, spInstId, cirId,
                    TRUE, SIT_STA_RLCIND, NULLP, NULLP);
   }
#endif

   con->outC.relResp = FALSE;
   /* IDLE the call processing state */
   SISTATECHNG(cir->calProcStat, CALL_IDLE); 
/* si014.220, Addition: Moved code here to update standby copy */
#ifdef ZI
      ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
   /* clear outgoing connection */
   siClearOutCon(con);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif
   if (relRsp)
   {
      SiUiSitRelCfm(pst, suId, suInstId, spInstId, cirId, &ev.m.siRelEvnt,
               uBuf);
   }
   RETVALUE(ROK);
} /* end of siOutE18S06 */

  
/*
*
*       Fun:   siOutE18S08
*
*       Desc:  Input: Release Complete
*              State: Waiting for RLC and RelResp
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE18S08
(
SiCon *con 
)
#else
PRIVATE S16 siOutE18S08(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siOutE18S08)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI387, (ErrVal) 0, 
                 "siOutE18S08() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI388, (ErrVal) 0, 
                 "siOutE18S08() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   SISNDOLDLSISTAIND(&siCb.init.lmPst, con->outC.cir->cfg.cirId, RLC_RCVD);

   /* change state */
   SISTATECHNG(con->outC.conState , ST_WTFORRELRSP);
   con->outC.relResp  = FALSE;

#ifdef IW
   if ((con->contCrm & SI_REL_UPLW) && (con->tCallCb))
   {
      SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId,
                    con->key.k1.spInstId, con->outC.cirId,
                    TRUE, SIT_STA_RLCIND, NULLP, NULLP);
   }
#endif

   RETVALUE(ROK);
} /* end of siOutE18S08 */

  

  

  
/*
*
*       Fun:   siOutE19S05
*
*       Desc:  Input: Resume
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE19S05
(
SiCon *con 
)
#else
PRIVATE S16 siOutE19S05(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE19S05)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI397, (ErrVal) 0, 
                 "siOutE19S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI398, (ErrVal) 0, 
                 "siOutE19S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif


   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_RESUME, (U8) SI_RESREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   con->outC.suspDir &= FROM_UPR;
   /* Stop T6 */
   siStopConTmr(con, TMR_T6O);
   /* Stop T2 */
   siStopConTmr(con, TMR_T2O);
   /* if appropriate, change state to answered */
   if (!con->outC.suspDir)
   {  
      SISTATECHNG(con->outC.conState , ST_ANSWRD);
   } 

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitResmInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->outC.cirId, &ev.m.siResmEvnt,
                  uBuf);
   RETVALUE(ROK);
} /* end of siOutE19S05 */

  
/*
*
*       Fun:   siOutE21S04
*
*       Desc:  Input: Suspend
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE21S04
(
SiCon *con 
)
#else
PRIVATE S16 siOutE21S04(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE21S04)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI399, (ErrVal) 0, 
                 "siOutE21S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI400, (ErrVal) 0, 
                 "siOutE21S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif


   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_SUSPND, (U8) SI_SUSPREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   con->outC.suspDir |= FROM_LWR;

   /* change state to suspended */
   SISTATECHNG(con->outC.conState , ST_SUSP);

   /* if controlling exchange */
   if (!con->incC.conPrcs)
   {
      if (con->pduSp->m.suspend.suspResInd.susResInd.val == SR_NETINIT)
         /* Start T6 Timer */
         siStartConTmr(TMR_T6O, con, con->tCallCb);
      else
         /* Start T2 Timer */
         siStartConTmr(TMR_T2O, con, con->tCallCb);
   }
   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitSuspInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->outC.cirId, &ev.m.siSuspEvnt,
                  uBuf);

   RETVALUE(ROK);
} /* end of siOutE21S04 */

  
/*
*
*       Fun:   siOutE21S05
*
*       Desc:  Input: Suspend
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE21S05
(
SiCon *con 
)
#else
PRIVATE S16 siOutE21S05(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE21S05)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI401, (ErrVal) 0, 
                 "siOutE21S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI402, (ErrVal) 0, 
                 "siOutE21S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif


   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_SUSPND, (U8) SI_SUSPREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* set suspended flag value */
   if (!(con->outC.suspDir & FROM_LWR))
      con->outC.suspDir |= FROM_LWR;

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   /* if controlling exchange */
   if (!con->incC.conPrcs)
   {
      if (con->pduSp->m.suspend.suspResInd.susResInd.val == SR_NETINIT)
         /* Start T6 Timer */
         siStartConTmr(TMR_T6O, con, con->tCallCb);
      else
         /* Start T2 Timer */
         siStartConTmr(TMR_T2O, con, con->tCallCb);
   }
   SiUiSitSuspInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                  con->key.k1.spInstId, con->outC.cirId, &ev.m.siSuspEvnt,
                  uBuf);
   RETVALUE(ROK);
} /* end of siOutE21S05 */

  
/*
*
*       Fun:   siOutE22SND
*
*       Desc:  Input: User to User 
*              State: Establishing States and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE22SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE22SND(con)
SiCon *con;
#endif
{
   SiAllSdus ev;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE22SND)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI403, (ErrVal) 0, 
                 "siOutE22SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI404, (ErrVal) 0, 
                 "siOutE22SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif


   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) MI_USR2USR, (U8) SI_INFREQ,
             (ElmtHdr *) con->pduSp, (ElmtHdr *) &ev, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   uBuf = con->mCallCb->mfMsgCtl.uBuf;
   con->mCallCb->mfMsgCtl.uBuf = NULLP;
   SiUiSitDatInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
                 con->key.k1.spInstId, con->outC.cirId, &ev.m.siInfoEvnt, 
                 uBuf);
   RETVALUE(ROK);
} /* end of siOutE22SND */

  
/*
*
*       Fun:   siOutE23SND
*
*       Desc:  Input: circuit reservation message.
*              State: Establishing states
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE23SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE23SND(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;
   SiCauseDgn cause;
   S16        ret;
   Bool       cirCtrlFlg;

   TRC2(siOutE23SND)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI405, (ErrVal) 0, 
                 "siOutE23SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI406, (ErrVal) 0, 
                 "siOutE23SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI407, (ErrVal) 0, 
                 "siOutE23SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   cirCtrlFlg = cir->cirCtl;   /* by default */

   if (cir->calProcStat == OUTBUSY)
   {
      
      /* if not controlling circuit : rh */
      if (!cirCtrlFlg)
      {
         if (cir->siCon->outC.conState < ST_WTFORANSWR)
         {
            MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP, 
                       (ElmtHdr *) &cause, &meCauseIndV, (U8) PRSNT_DEF, 
                       con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            cause.causeVal.pres = PRSNT_NODEF;
            cause.causeVal.val  = SIT_CCREQUNAVAIL;

            siGenReatInd(cir->cfg.cirId, con, &cause);
 
            con->suInstId              = 0;
            SISTATECHNG(con->outC.cir->calProcStat, CALL_IDLE);
            if( ! con->incC.conPrcs )
            {
               con->incC.conPrcs          = TRUE;
               con->incC.cir              = cir;
               con->incC.cirId            = cir->cfg.cirId;
               siClearOutCon(con);
            }
            else
            {
               SiCon *prevcon;
               CirCon concpy;

               prevcon = con;
               siClearOutCon(prevcon);
               cir->siCon = NULLP;
               con = siGetIncCon(cir, prevcon->mCallCb); 
               if( con == NULLP )
               {
                  SIDBGP(SIDBGMASK_ERR, (siCb.init.prntBuf,
                    "Can not allocate a connection block\n")); 
                  RETVALUE(ROK);
               }
               cmMemcpy((U8 *)&concpy, (U8 *)&con->incC, sizeof(CirCon));
               cmMemcpy((U8 *)con, (U8 *)prevcon, sizeof(SiCon));
               cmMemcpy((U8 *)&con->incC, (U8 *)&concpy, sizeof(CirCon));
               /* si025.220 - Modification - modify arguments in siGetLnkSel */
               /* si009.220 - Modified: to pass cic into siGetLnkSel. */
               siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);
               cmMemset((U8 *)&prevcon->outC, 0, sizeof(CirCon));
            }
            cir->siCon                 = con;
            siIncE23S00(con);
         }
      } 
      else
      {  
         SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
             "CRM on ctrl ckt with an outgoing con. Discard incoming msg.\n"));  
      } 
   } 
   else
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
            "IAM for incbusy ckt in non-idle case rcvd.Dumped\n"));  
   } 

   RETVALUE(ROK);
} /* end of siOutE23SND */

  

  
/*
*
*       Fun:   siOutE25S00
*
*       Desc:  Input: Connect Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/
#ifdef ANSI
PRIVATE S16 siOutE25S00
(
SiCon *con 
)
#else
PRIVATE S16 siOutE25S00(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   SiAllSdus ev;
   S16       ret;
   Priority  prior;
   Buffer   *uBuf;
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   Bool     mulCallFlg;             /* non-single rate call flag */
   Bool     contiMRateCall;         /* contiguous non-single rate call */    
   U8       multiplier;             /* num of affected circuits */
   U8       transRate;              /* info transfer rate/trans med req*/ 
   U8       maxNumCir;              /* max num of affected circuits */
   U32      mapVal;                 /* CAM map value */
#endif
#ifdef SI_ACNT
   U8      i;
#endif

   TRC2(siOutE25S00)

   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI416, (ErrVal) 0, 
                 "siOutE25S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI417, (ErrVal) 0, 
                 "siOutE25S00() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI418, (ErrVal) 0, 
                 "siOutE25S00() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   uBuf = con->tCallCb->mfMsgCtl.uBuf;
#ifdef IW
   /* Call id is copied to store the association of the upper SAP
    * of PSIF to this connection. This information is used 
    * to handle the disable upper SAP request from LM . 
    * In that case cid is compared prior to clearing the connections.
    */
   con->cid = GetHiByte(GetHiWord(con->suInstId));
#endif

   {
      if ((con->sduSp->m.siConEvnt.fwdCallInd.end2EndMethInd.val > 
         E2EMTH_PASSALNG) && (siCb.genCfg.sccpSup))
      if (((con->sCallCb = siGetLwrSCbPtr(cir)) != NULLP) &&
                (con->sCallCb->state == SI_BND))
         con->exchCalRef = TRUE;

      if (con->sduSp->m.siConEvnt.fwdCallInd.end2EndMethInd.val > 
          E2EMTH_NOMETH)
         con->end2end = TRUE;
      if (con->sduSp->m.siConEvnt.fwdCallInd.end2EndMethInd.val > 
          E2EMTH_PASSALNG)
         con->useSCCP = TRUE;
   }
#if SI_ACNT
   if (con->charge)
   {
      con->dstAdr.length = con->sduSp->m.siConEvnt.cdPtyNum.addrSig.len;
      for (i = 0; i < con->dstAdr.length; i++)
         con->dstAdr.strg[i] = con->sduSp->m.siConEvnt.cdPtyNum.addrSig.val[i];
      if (con->sduSp->m.siConEvnt.cgPtyNum.eh.pres)
      {
         con->srcAdr.length = con->sduSp->m.siConEvnt.cgPtyNum.addrSig.len;
         for (i = 0; i < con->srcAdr.length; i++)
            con->srcAdr.strg[i] = 
                  con->sduSp->m.siConEvnt.cgPtyNum.addrSig.val[i];
      }
      else
         if (con->tCallCb->cfg.sid.length)
         {
            con->srcAdr.length = con->tCallCb->cfg.sid.length;
            for (i = 0; i < con->srcAdr.length; i++)
               con->srcAdr.strg[i] = con->tCallCb->cfg.sid.strg[i];
         }
   }
#endif /* SI_ACNT */

   switch (con->tCallCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         if (con->sduSp->m.siConEvnt.usr2UsrInfo.eh.pres)
         {
            SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "usr2usrInfo is present\n"));
            /* rationale: if this cfg param is zero, the intention is not to 
             * send this information at all */
            if (con->tCallCb->cfg.maxLenU2U == 0)
               con->sduSp->m.siConEvnt.usr2UsrInfo.eh.pres = NOTPRSNT;
            else
            {
               if (con->sduSp->m.siConEvnt.usr2UsrInfo.info.len >
                   con->tCallCb->cfg.maxLenU2U)
                  con->sduSp->m.siConEvnt.usr2UsrInfo.info.len = 
                           con->tCallCb->cfg.maxLenU2U;
            } 
         } 
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
              "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI420, (ErrVal) 0, 
                 "siOutE25S00() Failed, invalid configuration switch");
         RETVALUE(ROK);
      
#endif
   }
   /* Generate IAM */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_INIADDR;

   /* initialize IAM */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CONREQ, (U8) MI_INIADDR,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   if (con->outC.cir->cfg.contReq)
   {
      if (con->sduSp->m.siConEvnt.natConInd.contChkInd.val != CONTCHK_REQ)
      {
         /* Generate Status Indication to Upper Layer */
         SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId,
                       con->suInstId, con->key.k1.spInstId, con->outC.cirId,
                       FALSE, SIT_STA_CONTCHK, NULLP, NULLP);
      }
      con->sduSp->m.siConEvnt.natConInd.contChkInd.val = CONTCHK_REQ;
   }

   /* get link selection value */
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   if (!con->lnkSel)
      /* si025.220 - Modification - modify arguments in siGetLnkSel */
      siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);

   /* si015.220 - Need to initalize siRelEvnt */
   /* Generate Release Indication to Upper Layer */
   MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
            (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) NOTPRSNT,
            con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   UPDATECAUSE(ev.m.siRelEvnt.causeDgn, SIT_CCPROTERR,
              con->tCallCb);

   if (message.m.initAddr.cgPtyCat.cgPtyCat.val != CAT_PRIOR)
      prior = PRI_ZERO;
   else
      prior = PRI_ONE;

   switch (con->tCallCb->cfg.swtch)
   {
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
      case LSI_SW_ITU:
         /* send message */
         if ((ret = siGenPdu(con->mCallCb, &pduHdr, &message, 
                      con->tCallCb->cfg.swtch, cir->opc, cir->cfg.intfId, 
                      cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                      prior, uBuf)) != ROK)
         {
            if ((ret != RFAILED) && 
               ((message.m.initAddr.usr2UsrInfo.eh.pres) &&         
                ((S16) (ret - message.m.initAddr.usr2UsrInfo.info.len)
                 <= (S16) MAX_MSG_LEN)))
            {
               message.m.initAddr.usr2UsrInfo.eh.pres = NOTPRSNT;
               
               siGenPdu(con->mCallCb, &pduHdr, &message, 
                        con->tCallCb->cfg.swtch, cir->opc, 
                        cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                        con->lnkSel, prior, uBuf);
            }
            else
            {
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                 "either usr2usrInfo absent or present with huge length %d\n",
                            message.m.initAddr.usr2UsrInfo.info.len));  
               /* Generate Alarm to Layer management */
               SISNDOLDLSISTAIND(&siCb.init.lmPst, con->outC.cirId, 
                                 SI_ALRM_INV_MSGLEN);

               /* si015.220 - Already initialized siRelEvnt */

               /* send release indication to the upper layer */
               SiUiSitRelInd(&con->tCallCb->pst, con->tCallCb->suId, 
                             con->suInstId, con->key.k1.spInstId, 
                             con->outC.cirId, &ev.m.siRelEvnt, NULLP);
         
               RETVALUE(RFAILED);
            }
         }
         break;

#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI422, (ErrVal) 0, 
                 "siOutE25S00() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }
   
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)

   /* initialization */
   mulCallFlg = FALSE;
   contiMRateCall = TRUE;
   multiplier = 0;
   mapVal = 0;
   maxNumCir = 0;
   transRate = 0;
   
   /* check if this is a non-single rate call, if yes, set the mulCallFag
    * to TRUE.
    */
   switch (con->tCallCb->cfg.swtch)
   {

#if (SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case LSI_SW_ITU97:
      case LSI_SW_ITU2000:
      case LSI_SW_RUSS2000:
      case LSI_SW_ETSIV3:
         transRate = con->sduSp->m.siConEvnt.txMedReq.trMedReq.val;
         if (transRate > TMR_64KBITSPREF)
         {
            mulCallFlg = TRUE;
         }
         break;
#endif

      default:
         mulCallFlg = FALSE;
         break;
   }

   /* if this is a non-single rate call, get the required info to update the 
    * fields related to non-single rate call in controlling circuit and the 
    * associations between circuits
    */
   if (mulCallFlg)
   {
      /* Get the required info for the further processing. Set the flow 
       * direction to TRUE (from upper).
       */
      ret = siGetMRateInfo(con, &(con->sduSp->m.siConEvnt), cir, 
                           &transRate, &multiplier, 
                           &maxNumCir, &mapVal, &contiMRateCall, TRUE);

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                " siGeMRateInfo() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }

      /* Build the linkage and update the related fields */ 
      ret = siGenMRateLnk(con, mapVal, transRate, maxNumCir, contiMRateCall,
                          multiplier);

      if (ret != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                " siGenMRateLnk() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

   {
      switch (con->sduSp->m.siConEvnt.natConInd.contChkInd.val)
      {
         case CONTCHK_NOTREQ:
            SISTATECHNG(con->outC.conState , ST_WTFORACM);
            break;

         case CONTCHK_REQ:
         case CONTCHK_PREV:
            SISTATECHNG(con->outC.conState , ST_WTFORCONTIN);
            break;
      }
   }
   SISTATECHNG(con->outC.cir->calProcStat, OUTBUSY);
   con->outC.conPrcs          = TRUE;

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (cir->ctrlMultiRateCir != NULLP)
   {
      if (siChgMRateState(cir, OUTBUSY) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif
   /* Start T7 Timer */
   siStartConTmr(TMR_T7O, con, con->tCallCb);

   RETVALUE(ROK);
} /* end of siOutE25S00 */


  
/*
*
*       Fun:   siOutE27S01
*
*       Desc:  Input: Connection Progress Status request
*              State: Waiting for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE27S01
(
SiCon *con 
)
#else
PRIVATE S16 siOutE27S01(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;
   U8        tmrNum;


   TRC2(siOutE27S01)
   UNUSED(ev);

   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI428, (ErrVal) 0, 
                 "siOutE27S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI429, (ErrVal) 0, 
                 "siOutE27S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI430, (ErrVal) 0, 
                 "siOutE27S01() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   if (con->sCallCb == NULLP)
      con->exchCalRef = FALSE;
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->evntType)
   {
      case SUBSADDR:
         /* stop T7 */
         siStopConTmr(con, TMR_T7O);

         /* Generate SAM */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_SUBADDR;

         /* initialize SAM */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8)SI_CNSTREQ,
                   (U8) MI_SUBADDR, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* Start T7 Timer */
         siStartConTmr(TMR_T7O, con, con->tCallCb);

         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_SUBADDR,
                     con->tCallCb->cfg.swtch), uBuf);
         break;

/* si40.220: Addition - Added SUBDIRNUM case */
#ifdef SS7_ITU2000
      case SUBDIRNUM:
         if (con->tCallCb->cfg.swtch != LSI_SW_ITU2000)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "swtch not ITU2000 for SUBDIRNUM\n"));
            siOutUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Subsequent directory number Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_SUBDIRNUM;

         /* initialize Charge message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_SUBDIRNUM, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId,
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(pduHdr.msgType.val,
                     con->tCallCb->cfg.swtch), uBuf);
         break;

#endif
/* si024.220: Addition - Added CHAGEACK case */
      case INFORMATREQ:

         /* if T33 running, ignore */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (con->timers[tmrNum].tmrEvnt == TMR_T33O)
               RETVALUE(ROK);

          /* Generate Info Request */
          /* prepare Pdu header */
          pduHdr.eh.pres      = PRSNT_NODEF;
          pduHdr.msgType.pres = PRSNT_NODEF;
          pduHdr.msgType.val  = (U8) M_INFOREQ;

          /* initialize Info Request */
          MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8)SI_CNSTREQ, 
                    (U8)MI_INFOREQ, (ElmtHdr *) con->sduSp, 
                    (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                    con->tCallCb->cfg.swtch, (U32) MF_ISUP);

          /* if required, insert call reference */
          siInsCallRef(cir, &message, pduHdr.msgType.val);

          /* Start T33 Timer */
          siStartConTmr(TMR_T33O, con, con->tCallCb);
          /* send message */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                   cir->opc, cir->cfg.intfId,
                   cir->phyDpc, TRUE, cir->cfg.cic,
                   con->lnkSel, siGetPriority(M_INFOREQ,
                   con->tCallCb->cfg.swtch), uBuf);

          break;

      case INFORMATION:
         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8)SI_CNSTREQ, 
                   (U8)MI_INFORMTN, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         switch (con->tCallCb->cfg.swtch)
         {
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
#if (SS7_ANS88 || SS7_ANS92 || SS7_ANS95 || SS7_BELL || SS7_CHINA)
               if (con->exchCalRef == TRUE)
               {
                  message.m.info.callRefA.eh.pres     = PRSNT_NODEF;
                  message.m.info.callRefA.callId.pres = PRSNT_NODEF;
                  message.m.info.callRefA.pntCde.pres = PRSNT_NODEF;
                  if (con->outC.dCallRef)
                  {
                     message.m.info.callRefA.callId.val = con->outC.dCallRef;
                     message.m.info.callRefA.pntCde.val = con->outC.phyDpc;
                  }
                  else
                  {
                     message.m.info.callRefA.callId.val = con->key.k1.spInstId;
                     message.m.info.callRefA.pntCde.val = cir->opc;
                  }
               }
               else
                  message.m.info.callRefA.eh.pres = NOTPRSNT;
               break;
#endif

#if SS7_ITU97
            case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
           case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
           case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
            case LSI_SW_INDIA:
#endif
            case LSI_SW_ITU:
               if (con->exchCalRef == TRUE)
               {
                  message.m.info.callRef.eh.pres     = PRSNT_NODEF;
                  message.m.info.callRef.callId.pres = PRSNT_NODEF;
                  message.m.info.callRef.pntCde.pres = PRSNT_NODEF;
                  if (con->outC.dCallRef)
                  {
                     message.m.info.callRef.callId.val = con->outC.dCallRef;
                     message.m.info.callRef.pntCde.val = (S16)con->outC.phyDpc;
                  }
                  else
                  {
                     message.m.info.callRef.callId.val = con->key.k1.spInstId;
                     message.m.info.callRef.pntCde.val = (S16) cir->opc;
                  }
               }
               else
                  message.m.info.callRef.eh.pres       = NOTPRSNT;
               break;

#if (ERRCLASS & ERRCLS_DEBUG)
            default:
               SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

               SILOGERROR(ERRCLS_DEBUG, ESI431, (ErrVal) 0, 
                        "siOutE27S01() Failed, invalid configuration switch");
               RETVALUE(ROK);
#endif
         }

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;



      case IDENTRSP:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch neither ITU/ETSI/ITU2000/RUSS2000/ITU97/ETSIV3/INDIA/CHINA\n"));
            siOutUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Response Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTRSP;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_IDENTRSP, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, 
                  cir->cfg.cic, con->lnkSel,
                  siGetPriority(M_IDENTRSP, con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Modification - adde INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3 and not itu97 and not India\n"));  

            siOutUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
      case APPTRANSPORT:
         if (((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
              (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
              (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
              (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
              (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) ||
             (con->outC.conState == ST_WTFORCONTIN))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "swtch not etsi v3/itu97/Indida or not in WTFORACM \n"));  

            siOutUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Application Transport Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_APPTRAN;
 
         /* initialize Application Transport Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_APPTRAN, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_APPTRAN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI432, (ErrVal) con->outC.cirId,
                    "siOutE27S01() invalid event ");
#endif
         
         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId, 
                       LSI_USTA_DGNVAL_SWTCH, (PTR) & con->tCallCb->cfg.swtch, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) & con->evntType, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, FALSE, 
                        con->outC.cirId, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of siOutE27S01 */

  
/*
*
*       Fun:   siOutE27SND
*
*       Desc:  Input: Connection Progress Status request
*              State: Waiting for ANM through OCG suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE27SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE27SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   U8        tmrNum;
   SiAllPdus message;
   SiAllSdus ev;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE27SND)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI433, (ErrVal) 0, 
                 "siOutE27SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI434, (ErrVal) 0, 
                 "siOutE27SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI435, (ErrVal) 0, 
                 "siOutE27SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   if (con->sCallCb == NULLP)
      con->exchCalRef = FALSE;

   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->evntType)
   {
/* si024.220: Addition - Added CHAGEACK case */
      case INFORMATREQ:
         if (con->outC.conState >= ST_ANSWRD)
         {
            siOutUNXEVT(con);
            RETVALUE(ROK);
         }

         /* if T33 running, ignore */
         for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
            if (con->timers[tmrNum].tmrEvnt == TMR_T33O)
               RETVALUE(ROK);

         /* Generate Info Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFOREQ;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8)SI_CNSTREQ, 
                   (U8)MI_INFOREQ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* Start T33 Timer */
         siStartConTmr(TMR_T33O, con, con->tCallCb);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFOREQ, 
                     con->tCallCb->cfg.swtch), uBuf);
         break;

      case INFORMATION:

         /* Generate Info Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_INFORMTN;

         /* initialize Info Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8)MI_INFORMTN, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_INFORMTN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case FRWDTRSFR:
         /* Generate Fwd Trsfr */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_FWDTFER;

         /* initialize Fwrd Trnsfr */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_FWDTFER, (ElmtHdr *)con->sduSp, (ElmtHdr *)&message,
                   (U8)PRSNT_NODEF, con->tCallCb->cfg.swtch, (U32)MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_FWDTFER, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;

      case MODIFY:

/*si034.220 : Drop Msg */
#if SS7_CHINA
         if (con->tCallCb->cfg.swtch == LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                "swtch == LSI_SW_CHINA therefore event dumped\n"));
            siOutUNXMSG(con);
            RETVALUE(ROK);
         }
#endif

         /* Generate Modification Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLMODREQ;

         /* initialize Modification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLMODREQ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         switch (con->tCallCb->cfg.swtch)
         {

         }

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* set call modification flag */
         con->outC.cllModProc = TRUE;

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_CALLMODREQ, con->tCallCb->cfg.swtch), 
                  uBuf);
         break;

      case MODCMPLT:
      case MODREJ:
/*si034.220 : Drop msg */
#if SS7_CHINA
         if (con->tCallCb->cfg.swtch == LSI_SW_CHINA)
         {
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
              "swtch == LSI_SW_CHINA therefore event dumped\n"));
            siOutUNXMSG(con);
            RETVALUE(ROK);
         }
#endif

         /* prepare Pdu header */
         pduHdr.eh.pres       = PRSNT_NODEF;
         pduHdr.msgType.pres  = PRSNT_NODEF;
         con->outC.cllModProc = FALSE;

         if (con->evntType == MODCMPLT)
         {
            pduHdr.msgType.val = (U8) M_CALLMODCOMP;
            /* initialize Modification Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                      (U8) MI_CALLMODCOMP, (ElmtHdr *) con->sduSp, 
                      (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);

            /* if required, insert call reference */
            siInsCallRef(cir, &message, pduHdr.msgType.val);
         }
         else
         {
            pduHdr.msgType.val = (U8) M_CALLMODREJ;
            /* initialize Modification Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                      (U8) MI_CALLMODREJ, (ElmtHdr *) con->sduSp, 
                      (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);

            switch (con->tCallCb->cfg.swtch)
            {
            }

            /* if required, insert call reference */
            siInsCallRef(cir, &message, pduHdr.msgType.val);
         }
         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
              siGetPriority(M_CALLMODCOMP, con->tCallCb->cfg.swtch), uBuf);
         break;

      case NETRESMGT:
         /* si029.220: Addition - added INDIA switch */
         if ((con->tCallCb->cfg.swtch == LSI_SW_ITU) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
             (con->tCallCb->cfg.swtch == LSI_SW_ETSI) ||
             (con->tCallCb->cfg.swtch == LSI_SW_INDIA))
         {
            /* Generate Network Resource Management */
            /* prepare Pdu header */
            pduHdr.eh.pres      = PRSNT_NODEF;
            pduHdr.msgType.pres = PRSNT_NODEF;
            pduHdr.msgType.val  = (U8) M_NETRESMGT;
            
            /* initialize Info Request */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                      (U8) MI_NETRESMGT, (ElmtHdr *) con->sduSp, 
                      (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            
            /* send message */
            siGenPdu(con->mCallCb, &pduHdr, &message, 
                     con->tCallCb->cfg.swtch, cir->opc, 
                     cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                     con->lnkSel, siGetPriority(M_NETRESMGT, 
                     con->tCallCb->cfg.swtch), uBuf);

            break;
         }

      case IDENTRSP:
         /* si029.220: Addition - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch neither itu nor etsi\n"));  
            siOutUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Response Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTRSP;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_IDENTRSP, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_IDENTRSP, con->tCallCb->cfg.swtch), uBuf);
         break;

#if (SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
      case LOOPPRVNT:
         if (((con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97)) ||
             (con->outC.conState != ST_ANSWRD))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi or itu97 or constate not ANSWRD\n"));  

            siOutUNXEVT(con);
            RETVALUE(ROK);
         }
         /* si024.220: Modification - All parameters for LOP are optional,
          * should not drop the message in any case */
         if (con->sduSp->m.siCnStEvnt.loopPrvntInd.eh.pres != NOTPRSNT) 
         {
            /* check if loop prevention response */
            if (con->sduSp->m.siCnStEvnt.loopPrvntInd.loopPrvntType.val)
            {
               /* Turn off ECT timer */
               con->callTRef.tRefUsed = FALSE;
            }
            else /* loop prevention request */
            {
               if (con->sduSp->m.siCnStEvnt.calTrnsfrRef.eh.pres != NOTPRSNT)
               {
                  /* save transfer reference */
                  con->callTRef.tRefUsed = TRUE;
                  con->callTRef.tRefVal = 
                            con->sduSp->m.siCnStEvnt.calTrnsfrRef.callTrnsfr.val;
                  /* start ECT timer */
                  siStartConTmr(TMR_TECT, con, con->tCallCb);
               }
            }
         }

         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_LOOPPRVNT;

         /* initialize loop prevention message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                  (U8) MI_LOOPPRVNT, (ElmtHdr *) con->sduSp, 
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                  con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                 siGetPriority(M_LOOPPRVNT, con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSI || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */


      case PROGRESS:
         if ((con->outC.conState != ST_ANSWRD) &&
             (con->outC.conState != ST_WTFORANSWR)) 
         {
            MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_STAREQ,
                     (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                     con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            ev.m.siStaEvnt.causeDgn.eh.pres       = PRSNT_NODEF;
            ev.m.siStaEvnt.causeDgn.causeVal.pres = PRSNT_NODEF;
            ev.m.siStaEvnt.causeDgn.causeVal.val  = SIT_CCPROTERR;
 
            /* send error indication to the upper layer */
            SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId,
                          con->suInstId, con->key.k1.spInstId,
                          con->outC.cirId, FALSE, SIT_STA_ERRORIND, 
                          &ev.m.siStaEvnt, NULLP);
            RETVALUE(ROK);
         }
         /* Generate Progress */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CALLPROG;

         /* initialize CPG */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_CALLPROG, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if required, insert call reference */
         siInsCallRef(cir, &message, pduHdr.msgType.val);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_CALLPROG, con->tCallCb->cfg.swtch), uBuf);
         break;

/* si029.220: Modification - added INDIA switch */
#if (SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA)
      case PRERELEASE:
         if ((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch not etsi v3 and not itu97 and not India\n"));  

            siOutUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Pre-release Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_PRERELINF;
 
         /* initialize Pre-release Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_PRERELINF, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_PRERELINF, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
      case APPTRANSPORT:
         if (((con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
              (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
              (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
              (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
              (con->tCallCb->cfg.swtch != LSI_SW_INDIA)) ||
             (con->outC.conState == ST_SUSP))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "swtch not etsi v3/ itu97/India or in SUSPENDED state \n"));  

            siOutUNXEVT(con);
            RETVALUE(ROK);
         }

         /* Generate Application Transport Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_APPTRAN;
 
         /* initialize Application Transport Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_APPTRAN, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
 
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_APPTRAN, 
                  con->tCallCb->cfg.swtch), uBuf);
         break;
#endif /* SS7_ETSIV3 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_INDIA */

/* si034.220: Modification - added CHINA switch */
#if SS7_CHINA

      case METPULSE:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
          {
              SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                         "swtch not CHINA for METPULSE\n"));
              siOutUNXEVT(con);
              RETVALUE(ROK);
          }
         
	 /* Generate Metering Pulse Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_METPULSE;

         /* initialize Metering Pulse Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_METPULSE, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic, 
		  con->lnkSel, siGetPriority(pduHdr.msgType.val, 
		  con->tCallCb->cfg.swtch), uBuf);
           break;

      case CLGPTCLR:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
          {
              SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                         "swtch not CHINA for CLGPTCLR\n"));
              siOutUNXEVT(con);
              RETVALUE(ROK);
          }
         
	 /* Generate Calling party clear Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CLGPTYCLR;

         /* initialize Metering Pulse Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_CLGPTYCLR, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic, 
		  con->lnkSel, siGetPriority(pduHdr.msgType.val, 
		  con->tCallCb->cfg.swtch), uBuf);
           break;

      case OPERATOR:
         if (con->tCallCb->cfg.swtch != LSI_SW_CHINA)
          {
              SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                         "swtch not CHINA for OPERATOR\n"));
              siOutUNXEVT(con);
              RETVALUE(ROK);
          }
         
	 /* Generate Operator Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_OPERATOR;

         /* initialize Metering Pulse Message */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ,
                   (U8) MI_OPERATOR, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, cir->cfg.cic, 
		  con->lnkSel, siGetPriority(pduHdr.msgType.val, 
		  con->tCallCb->cfg.swtch), uBuf);
           break;
#endif /* if SS7_CHINA */
      default:
#if (ERRCLASS & ERRCLS_DEBUG)
         SILOGERROR(ERRCLS_DEBUG, ESI436, (ErrVal) con->outC.cirId,
                "siOutE27SND() invalid event ");
#endif

         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         /* Generate Alarm to Layer management */
         siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) & con->outC.cirId, 
                       LSI_USTA_DGNVAL_SWTCH, (PTR) & con->tCallCb->cfg.swtch, 
                       LSI_USTA_DGNVAL_EVENT, (PTR) & con->evntType, 
                       LSI_USTA_DGNVAL_NONE, NULLP);
         SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                        LCM_EVENT_UI_INV_EVT, LSI_CAUSE_INV_EVNT, FALSE, 
                        con->outC.cirId, SI_ALRM_INV_EVENT);
         RETVALUE(RFAILED);
   }
   RETVALUE(ROK);
} /* end of siOutE27SND */

  
/*
*
*       Fun:   siOutE27S06
*
*       Desc:  Input: Connection Progress Status request
*              State: Waiting for Release Complete
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE27S06
(
SiCon *con 
)
#else
PRIVATE S16 siOutE27S06(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE27S06)


   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI437, (ErrVal) 0, 
                 "siOutE27S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI438, (ErrVal) 0, 
                 "siOutE27S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI439, (ErrVal) 0, 
                 "siOutE27S06() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;
   switch (con->evntType)
   {
      case IDENTRSP:
         /* si029.220: Modification - added INDIA switch */
         if ((con->tCallCb->cfg.swtch != LSI_SW_ITU) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU97) &&
             (con->tCallCb->cfg.swtch != LSI_SW_RUSS2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ITU2000) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSIV3) &&
             (con->tCallCb->cfg.swtch != LSI_SW_ETSI) &&
             (con->tCallCb->cfg.swtch != LSI_SW_INDIA))
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "swtch neither itu nor etsi nor India nor China\n"));  
            siOutUNXEVT(con);
            RETVALUE(ROK);
         }
         /* Generate Identification Response Message */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_IDENTRSP;

         /* initialize Identification Request */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_CNSTREQ, 
                   (U8) MI_IDENTRSP, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF, 
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_IDENTRSP, con->tCallCb->cfg.swtch), uBuf);
         break;


      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         break;
   }
   RETVALUE(ROK);
} /* end of siOutE27S06 */

  
/*
*
*       Fun:   siOutE28SND
*
*       Desc:  Input: Release Request
*              State: Idle through suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE28SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE28SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   Status    status;
   SiPduHdr  pduHdr;
   S16       ret;
   U8        tmrNum;
   Buffer    *uBuf;
   SiIntfCb   *siIntfCb;
   U16       ustaCause;

   TRC2(siOutE28SND)
#if !(SI_LMINT3 || SMSI_LMINT3) 
   UNUSED(ustaCause);
#endif
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI441, (ErrVal) 0, 
                 "siOutE28SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI442, (ErrVal) 0, 
                 "siOutE28SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI443, (ErrVal) 0, 
                 "siOutE28SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;

   /* Stop all other Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          ((con->timers[tmrNum].tmrEvnt & OUTTYPE) ||
          (con->timers[tmrNum].tmrEvnt == TMR_T8)))
         siRmvConTq(con, tmrNum);
      
   /* Generate Release */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   /* initialize Release */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RELREQ, (U8) MI_RELSE,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

#if SI_ACNT
   /* if responsible for charging, generate bill */
   if ((con->outC.conState > ST_WTFORANSWR) && (con->charge))
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "Billing info generated\n"));  
      siGenBill(con);
   } 
#endif

   /* change state */
   SISTATECHNG(con->outC.conState , ST_WTFORRELCMP);
   con->outC.relResp  = TRUE;


   switch (con->tCallCb->cfg.swtch)
   {
/* the ans'92 and bellcore variant missed to prepare the ACL param, 
 * adding them 
 */
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif
      case LSI_SW_ITU:
         SChkRes(con->tCallCb->pst.region, con->tCallCb->pst.pool, &status);
         if (status < siCb.genCfg.poolTrUpper)
         {
            ustaCause = LSI_CAUSE_CONG_LVL1;
            /* check if congestion level param is already present,
             * if no, then prepare it. Otherwise, pass the param.
             */
             if (!message.m.release.auCongLvl.eh.pres)
             {                        
                message.m.release.auCongLvl.eh.pres          = PRSNT_NODEF;
                message.m.release.auCongLvl.auCongLvl.pres   = PRSNT_NODEF;
                if (status < siCb.genCfg.poolTrLower)
                {
                   ustaCause = LSI_CAUSE_CONG_LVL2;
                   message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL2;
                }
                else
                   message.m.release.auCongLvl.auCongLvl.val = ACLVL_LVL1;
             }
             else
                if (status < siCb.genCfg.poolTrLower)
                   ustaCause = LSI_CAUSE_CONG_LVL2;

             siInitUstaDgn(LSI_USTA_DGNVAL_CIRCUIT, (PTR) &con->outC.cirId, 
                           LSI_USTA_DGNVAL_INTF, 
                           (PTR) &con->outC.cir->key.k3.intfId,
                           LSI_USTA_DGNVAL_NONE, NULLP, 
                           LSI_USTA_DGNVAL_NONE, NULLP);
             SISNDLSISTAIND(&siCb.init.lmPst, LCM_CATEGORY_PROTOCOL, 
                            LSI_EVENT_REMOTE, ustaCause, TRUE, 
                            con->outC.cir->cfg.cirId, CONG_LVL_2);
         } 
         else
         {  
            SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "Resource crunch .\n"));  
                      
         } 
         break;


      default:
         break;
   }
   

   /* build copy of a Release Message */
   if ((ret = siBldMsg(con->mCallCb, con->outC.cir->cfg.cic, &pduHdr, 
                       &message, con->mCallCb->pst.region, 
                       con->mCallCb->pst.pool, &con->outC.rel, 
                       con->tCallCb->cfg.swtch, uBuf)) != ROK)
      con->outC.rel = NULLP;

   /* Start T1 Timer */
   siStartConTmr(TMR_T1O, con, con->tCallCb);
   /* Start T5 Timer */
   siStartConTmr(TMR_T5O, con, con->tCallCb);

   /*
    * circuit is PAUSEd. set 'toBeRelsd' flag.
    * call will be released when MTP-3 link RESUMEs
    */
   siIntfCb = cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI444, (ErrVal) cir->key.k3.intfId, 
                 "siOutE28SND() Failed, intf control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
        (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
        (siIntfCb->state == SI_INTF_UNAVAIL)) 
      con->outC.toBeRelsd = TRUE;
   else
      /* send message */
      siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
               siGetPriority(M_RELSE, con->tCallCb->cfg.swtch), uBuf);

   RETVALUE(ROK);
} /* end of siOutE28SND */

  
/*
*
*       Fun:   siOutE28S07
*
*       Desc:  Input: Release Request
*              State: Waiting for release response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/
#ifdef ANSI
PRIVATE S16 siOutE28S07
(
SiCon *con 
)
#else
PRIVATE S16 siOutE28S07(con)
SiCon *con;
#endif
{
   SiPduHdr  pduHdr;
   SiAllPdus allPdus;
   SiAllSdus ev;
   SiCirCb   *cir;
   SiIntfCb   *siIntfCb;
   S16       ret;
   U8        tmrNum;

   TRC2(siOutE28S07)

   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI445, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI446, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI447, (ErrVal) 0, 
                 "siOutE17S06() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   siDropMsg(con->mCallCb->mfMsgCtl.uBuf);
   con->mCallCb->mfMsgCtl.uBuf = NULLP;

   /* don't remove the connection block until MTP-RESUME is received */
   siIntfCb = cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI448, (ErrVal) con->outC.cir->key.k3.intfId, 
                 "siOutE29S07() Failed, intf control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
       (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
       (con->outC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      SISTATECHNG(con->outC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   else
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      {
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
               (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      }
         
      /* Generate Release Complete Message to Lower Layer */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_RELCOMP;

      switch (con->tCallCb->cfg.swtch)
      {
#ifdef SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            /* initialize message */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELCOMP,
                     (ElmtHdr *) NULLP, (ElmtHdr *) &allPdus, (U8) PRSNT_DEF,
                     con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            /* generate messare */
            siGenPdu(con->mCallCb, &pduHdr, &allPdus, con->tCallCb->cfg.swtch,
                     cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                     siGetPriority(M_RELCOMP, con->tCallCb->cfg.
                     swtch), NULLP);

            if (con->outC.relResp)
            {
            /* Generate Release Confirmation to Upper Layer */
               MFINITSDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) SI_RELREQ,
                        (ElmtHdr *) NULLP, (ElmtHdr *) &ev, (U8) PRSNT_DEF,
                        con->tCallCb->cfg.swtch, (U32) MF_ISUP);

               SiUiSitRelCfm(&con->tCallCb->pst, con->tCallCb->suId, 
                             con->suInstId, con->key.k1.spInstId, 
                             con->outC.cirId, &ev.m.siRelEvnt, NULLP);

               con->outC.relResp = FALSE;
            }
#ifdef ZI
            ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif
            /* clear outgoing connection */
            siClearOutCon(con);

#ifdef ZI
            ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
            ziUpdPeer();
#endif
            break;

#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                        "invalid switch %d\n", con->tCallCb->cfg.swtch));  

            SILOGERROR(ERRCLS_DEBUG, ESI449, (ErrVal) 0, 
                  "siOutE17S06() Failed, invalid configuration switch");
            RETVALUE(ROK);
#endif
      }
   }

   RETVALUE(ROK);
}


  
/*
*
*       Fun:   siOutE29S00
*
*       Desc:  Input: Release Response
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE29S00
(
SiCon *con 
)
#else
PRIVATE S16 siOutE29S00(con)
SiCon *con;
#endif
{
   U8 tmrNum;
   SiIntfCb   *siIntfCb;

   TRC2(siOutE29S00)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI458, (ErrVal) 0, 
                 "siOutE29S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI459, (ErrVal) 0, 
                 "siOutE29S00() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   siIntfCb = con->outC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI460, (ErrVal) con->outC.cir->key.k3.intfId, 
                 "siOutE29S00() Failed, interface control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
       (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
       (con->outC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      SISTATECHNG(con->outC.conState , ST_IDLE);
      RETVALUE(ROK);
   }

   con->outC.relResp = FALSE;
   siClearOutCon(con);
   RETVALUE(ROK);
} /* end of siOutE29S00 */

  
/*
*
*       Fun:   siOutE29S06
*
*       Desc:  Input: Release Response
*              State: Waiting for release complete
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE29S06
(
SiCon *con 
)
#else
PRIVATE S16 siOutE29S06(con)
SiCon *con;
#endif
{
   U8 tmrNum;
   SiIntfCb   *siIntfCb;

   TRC2(siOutE29S06)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI461, (ErrVal) 0, 
                 "siOutE29S06() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI462, (ErrVal) 0, 
                 "siOutE29S06() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   siIntfCb = con->outC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI463, (ErrVal) 0, 
                 "siOutE29S06() Failed, interface control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
       (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
       (con->outC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      SISTATECHNG(con->outC.conState , ST_IDLE);
      RETVALUE(ROK);
   }

   con->outC.relResp = FALSE;
   RETVALUE(ROK);
} /* end of siOutE29S06 */

  
/*
*
*       Fun:   siOutE29S07
*
*       Desc:  Input: Release Response
*              State: Waiting for Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE29S07
(
SiCon *con 
)
#else
PRIVATE S16 siOutE29S07(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   U8        tmrNum;
   SiIntfCb   *siIntfCb;

   TRC2(siOutE29S07)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI464, (ErrVal) 0, 
                 "siOutE29S07() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI465, (ErrVal) 0, 
                 "siOutE29S07() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI466, (ErrVal) 0, 
                 "siOutE29S07() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   /* don't remove the connection block until MTP-RESUME is received */
   siIntfCb = cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI467, (ErrVal) con->outC.cir->key.k3.intfId, 
                 "siOutE29S07() Failed, intf control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
       (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
       (con->outC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      SISTATECHNG(con->outC.conState , ST_IDLE);
      RETVALUE(ROK);
   }

   if (con->outC.relResp)
   {
      /* Generate Release Complete */
      /* prepare Pdu header */
      pduHdr.eh.pres      = PRSNT_NODEF;
      pduHdr.msgType.pres = PRSNT_NODEF;
      pduHdr.msgType.val  = (U8) M_RELCOMP;

      switch (con->tCallCb->cfg.swtch)
      {


#if SS7_ITU97
         case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
         case LSI_SW_INDIA:
#endif
/* si034.220: Addition - added CHINA case */
#ifdef SS7_CHINA 
      case LSI_SW_CHINA:
#endif /* if SS7_CHINA */
         case LSI_SW_ITU:
            /* initialize Release Complete */
            MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RELRSP, 
                      (U8) MI_RELCOMP, (ElmtHdr *) con->sduSp, 
                      (ElmtHdr *)&message, (U8) PRSNT_NODEF, 
                      con->tCallCb->cfg.swtch, (U32) MF_ISUP);
            break;
#if (ERRCLASS & ERRCLS_DEBUG)
         default:
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

            SILOGERROR(ERRCLS_DEBUG, ESI468, (ErrVal) 0, 
                 "siOutE29S07() Failed, invalid configuration switch");
            RETVALUE(ROK);
#endif
      }
      /* change state to Idle */
      SISTATECHNG(con->outC.conState , ST_IDLE);
      con->outC.relResp  = FALSE;

      /* send message */
       siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
               cir->opc, cir->cfg.intfId, 
               cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                siGetPriority(M_RELCOMP, con->tCallCb->cfg.swtch),
               con->tCallCb->mfMsgCtl.uBuf);
   }

#ifdef ZI
   ziRunTimeUpd(ZI_CON_CB, CMPFTHA_DELETE_REQ, (PTR) con);
#endif

   siClearOutCon(con);

#ifdef ZI
   ziRunTimeUpd(ZI_CIR_CB, CMPFTHA_UPD_REQ, (PTR) cir);
   ziUpdPeer();
#endif

   RETVALUE(ROK);
} /* end of siOutE29S07 */

  
/*
*
*       Fun:   siOutE29S08
*
*       Desc:  Input: Release Response
*              State: Waiting for RLC and Release Resp
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE29S08
(
SiCon *con 
)
#else
PRIVATE S16 siOutE29S08(con)
SiCon *con;
#endif
{
   U8 tmrNum;
   SiIntfCb   *siIntfCb;

   TRC2(siOutE29S08)
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI469, (ErrVal) 0, 
                 "siOutE29S08() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI470, (ErrVal) 0, 
                 "siOutE29S08() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif
   siIntfCb = con->outC.cir->pIntfCb;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (siIntfCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "   siFindIntf failed   \n"));  
      SILOGERROR(ERRCLS_DEBUG, ESI471, (ErrVal) con->outC.cir->key.k3.intfId, 
                 "siOutE29S08() Failed, interface control block not found");
      RETVALUE(RFAILED);
   }
#endif

   if (((siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTRAN) ||
       (siIntfCb->cfg.pauseActn == SI_PAUSE_CLRTMOUT)) &&
       (con->outC.toBeRelsd))
   {
      /* Stop all Timers */
      for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
         if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
             (con->timers[tmrNum].tmrEvnt & OUTTYPE)) 
            siRmvConTq(con, tmrNum);
      SISTATECHNG(con->outC.conState , ST_IDLE);
      RETVALUE(ROK);
   }
   con->outC.relResp = FALSE;

   /* change state */
   SISTATECHNG(con->outC.conState , ST_WTFORRELCMP);

   RETVALUE(ROK);
} /* end of siOutE29S08 */

  
/*
*
*       Fun:   siOutE30SND
*
*       Desc:  Input: User Information Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE30SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE30SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE30SND)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI472, (ErrVal) 0, 
                 "siOutE30SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SILOGERROR(ERRCLS_DEBUG, ESI473, (ErrVal) 0, 
                 "siOutE30SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI474, (ErrVal) 0, 
                 "siOutE30SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;

   /* Generate User Info */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_USR2USR;

   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_INFREQ, (U8) MI_USR2USR,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);
      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic, &pduHdr,
                                   &message, con->mCallCb->pst.region, 
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId,
                     cir->phyDpc, TRUE, con->lnkSel, FALSE,
                     siGetPriority(M_USR2USR, con->tCallCb->cfg.swtch),
                     con->tCallCb->cfg.swtch);
      }
      else
         /* send message through MTP */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic,
                  con->lnkSel, siGetPriority(M_USR2USR, 
                     con->tCallCb->cfg.swtch), uBuf);
   }
   RETVALUE(ROK);
} /* end of siOutE30SND */

  
/*
*
*       Fun:   siOutE31S04
*
*       Desc:  Input: Suspend Request
*              State: Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE31S04
(
SiCon *con 
)
#else
PRIVATE S16 siOutE31S04(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE31S04)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI479, (ErrVal) 0, 
                 "siOutE31S04() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI480, (ErrVal) 0, 
                 "siOutE31S04() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI481, (ErrVal) 0, 
                 "siOutE31S04() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;
   /* set suspended flag value */
   con->outC.suspDir  |= FROM_UPR;
   /* Generate Suspend */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_SUSPND;

   /* initialize Release Complete */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_SUSPREQ, (U8) MI_SUSPND,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);
 
   /* change state to suspended */
   SISTATECHNG(con->outC.conState , ST_SUSP);
   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_SUSPND, con->tCallCb->cfg.swtch), uBuf);

   RETVALUE(ROK);
} /* end of siOutE31S04 */

  
/*
*
*       Fun:   siOutE31S05
*
*       Desc:  Input: Suspend Request
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE31S05
(
SiCon *con 
)
#else
PRIVATE S16 siOutE31S05(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE31S05)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI482, (ErrVal) 0, 
                 "siOutE31S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI483, (ErrVal) 0, 
                 "siOutE31S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI484, (ErrVal) 0, 
                 "siOutE31S05() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;
   /* if already suspended from this direction, ignore */
   if (con->outC.suspDir & FROM_UPR)
   {  
      SIDBGP(SIDBGMASK_WARN, (siCb.init.prntBuf,
                      "suspDir is FROM_UPR\n"));  
      RETVALUE(ROK);
   } 
   else
      con->outC.suspDir |= FROM_UPR;

   /* Generate Suspend */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_SUSPND;
   /* initialize Suspend */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_SUSPREQ, (U8) MI_SUSPND,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);

   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_SUSPND, con->tCallCb->cfg.swtch), uBuf);

   RETVALUE(ROK);
} /* end of siOutE31S05 */

  
/*
*
*       Fun:   siOutE32S05
*
*       Desc:  Input: Resume Request
*              State: Suspended
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE32S05
(
SiCon *con 
)
#else
PRIVATE S16 siOutE32S05(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE32S05)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI485, (ErrVal) 0, 
                 "siOutE32S05() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI486, (ErrVal) 0, 
                 "siOutE32S05() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI487, (ErrVal) 0, 
                 "siOutE32S05() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;


   /* Generate Resume */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RESUME;

   /* initialize Resume */
   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_RESREQ, (U8) MI_RESUME,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if required, insert call reference */
   siInsCallRef(cir, &message, pduHdr.msgType.val);
 
   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            cir->opc, cir->cfg.intfId, 
            cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
            siGetPriority(M_RESUME, con->tCallCb->cfg.swtch), uBuf);

   /* if not suspended from this direction, ignore */
   if (con->outC.suspDir & FROM_UPR)
      con->outC.suspDir &= FROM_LWR;
   if (!con->outC.suspDir)
   {  
      SISTATECHNG(con->outC.conState , ST_ANSWRD);
   } 
   RETVALUE(ROK);
} /* end of siOutE32S05 */

  
/*
*
*       Fun:   siOutE33SND
*
*       Desc:  Input: Facility Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE33SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE33SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   U8        event;
   U8        msgType;
   Priority  prior;
   Buffer    *uBuf;

   TRC2(siOutE33SND)

   cir  = con->outC.cir;
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;
   event   = 0;
   msgType = 0;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI488, (ErrVal) 0, 
                 "siOutE33SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI489, (ErrVal) 0, 
                 "siOutE33SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI490, (ErrVal) 0, 
                 "siOutE33SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif

   switch (con->tCallCb->cfg.swtch)
   {
/* si034.220 : Drop Msg */
#if SS7_CHINA
      case LSI_SW_CHINA:
         siOutUNXEVT(con);
         RETVALUE(ROK);
#endif
#if SS7_ITU97
      case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
      case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
      case LSI_SW_RUSS2000:
#endif
/* si029.220: Addition - added INDIA case */
#ifdef SS7_INDIA 
      case LSI_SW_INDIA:
#endif
      case LSI_SW_ITU:
         switch (con->evntType)
         {
            case SIT_FACIL:
               msgType = M_FACIL;
               event   = MI_FACIL;
               break;
            case SIT_FACREQ:
               msgType = M_FACREQ;
               event   = MI_FACREQ;
               break;
            default:
               siOutUNXEVT(con);
               RETVALUE(ROK);
         }
         break;
#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "invalid switch %d\n", con->tCallCb->cfg.swtch));  

         SILOGERROR(ERRCLS_DEBUG, ESI491, (ErrVal) 0, 
                 "siOutE33SND() Failed, invalid configuration switch");
         RETVALUE(ROK);
#endif
   }

   prior = siGetPriority(msgType, con->tCallCb->cfg.swtch);
   /* Generate Facility Request */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) msgType;

   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACREQ, (U8) event,
             (ElmtHdr *) con->sduSp, (ElmtHdr *) &message, (U8) PRSNT_NODEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);
      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic,
                                   &pduHdr, &message,
                                   con->mCallCb->pst.region, 
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId,
                     cir->phyDpc, TRUE, con->lnkSel, FALSE, prior,
                     con->tCallCb->cfg.swtch);
      }
      else
         /* send message through MTP */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  prior, uBuf);
   }
   RETVALUE(ROK);
} /* end of siOutE33SND */

  
/*
*
*       Fun:   siOutE34SND
*
*       Desc:  Input: Facility Response
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE34SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE34SND(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   Buffer    *mBuf;
   S16       ret;
   Buffer    *uBuf;
   Priority  prior;

   TRC2(siOutE34SND)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI492, (ErrVal) 0, 
                 "siOutE34SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI493, (ErrVal) 0, 
                 "siOutE34SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI494, (ErrVal) 0, 
                 "siOutE34SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;


   switch(con->tCallCb->cfg.swtch)
   {
      default:
         break;
   }

   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   switch (con->evntType)
   {
      case SIT_FACREJ:
         /* Generate Facility Reject */
         pduHdr.msgType.val = (U8) M_FACREJ;

         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACRSP, 
                   (U8) MI_FACREJ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         break;

      case SIT_FACACC:
         /* Generate Facility Accept */
         pduHdr.msgType.val = (U8) M_FACACC;

         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_FACRSP, 
                   (U8) MI_FACACC, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);
         break;

      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         siOutUNXEVT(con);
         RETVALUE(ROK);
   }
   prior = siGetPriority(pduHdr.msgType.val, con->tCallCb->cfg.swtch);

   /* if SCCP to be used */
   if ((con->sCallCb) && (con->sCallCb->state == SI_BND) && (con->useSCCP))
   {
      /* send message through SCCP */
      siGenScPdu(con->sCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                 cir->opc, cir->cfg.intfId, cir->phyDpc, TRUE, FALSE, uBuf);

      if (!con->sccpUsed)
         con->sccpUsed = TRUE;
   }
   else      /* send message through MTP */
   {
      /* end to end */
      if (con->end2end)
      {
         /* build Passalong Message */
         if ((ret = siBldPsalngMsg(con->mCallCb, cir->cfg.cic, &pduHdr,
                                   &message, con->mCallCb->pst.region,
                                   con->mCallCb->pst.pool, &mBuf, 
                                   con->tCallCb->cfg.swtch, uBuf)) == ROK)
            /* send message */
             siSndMsg(con->mCallCb, mBuf, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, con->lnkSel, FALSE, prior,
                     con->tCallCb->cfg.swtch);
      }
      else
         /* send message through MTP */
          siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, prior,
                  uBuf);
   }
   RETVALUE(ROK);
} /* end of siOutE34SND */

  
/*
*
*       Fun:   siOutE35S00
*
*       Desc:  Input: Status Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE35S00
(
SiCon *con 
)
#else
PRIVATE S16 siOutE35S00(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;

   TRC2(siOutE35S00)

   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI497, (ErrVal) 0, 
                 "siOutE35S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI498, (ErrVal) 0, 
                 "siOutE35S00() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI499, (ErrVal) 0, 
                 "siOutE35S00() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;
   /* si009.220 - Modified: to pass cic into siGetLnkSel. */
   /* get link selection value */
   if (!con->lnkSel)
      /* si025.220 - Modification - modify arguments in siGetLnkSel */
      siGetLnkSel(con->mCallCb, &con->lnkSel, con->tCallCb->cfg.swtch, cir);

   switch (con->evntType)
   {
      case SIT_STA_CONTREP:
         /* Generate COT */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CONTINUITY;

         /* initialize COT */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_STAREQ, 
                  (U8) MI_CONTINUITY, (ElmtHdr *) con->sduSp, 
                  (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                  con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_CONTINUITY, con->tCallCb->cfg.swtch),
                  uBuf);

         if (con->sduSp->m.siStaEvnt.contInd.contInd.val != CONT_CHKFAIL)
            /* release connection */
            siClearOutCon(con);
         break;

      case SIT_STA_CONTCHK:
         /* Generate CCR */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CONTCHKREQ;

         /* initialize CCR from the received status event */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_STAREQ,
                   (U8) MI_CONTCHKREQ, (ElmtHdr *) con->sduSp,
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch, 
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel, 
                  siGetPriority(M_CONTCHKREQ, con->tCallCb->cfg.swtch), 
                  uBuf);
         break;


#if (ERRCLASS & ERRCLS_DEBUG)
      default:
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
            "invalid event %d 0x%x\n", con->evntType, con->evntType));  

         SILOGERROR(ERRCLS_DEBUG, ESI501, (ErrVal) 0, 
                 "siOutE35S00() Failed, invalid event");
         RETVALUE(ROK);
#endif
   }

   RETVALUE(ROK);
} /* end of siOutE35S00 */

  
/*
*
*       Fun:   siOutE35S01
*
*       Desc:  Input: Status Request
*              State: Waiting for COT Report
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE35S01
(
SiCon *con 
)
#else
PRIVATE S16 siOutE35S01(con)
SiCon *con;
#endif
{
   SiCirCb   *cir;
   SiAllPdus message;
   SiPduHdr  pduHdr;
   S16       ret;
   Buffer    *uBuf;
   U8        tmrNum;

   TRC2(siOutE35S01)
   cir = con->outC.cir;
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI502, (ErrVal) 0, 
                 "siOutE35S01() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI503, (ErrVal) 0, 
                 "siOutE35S01() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI504, (ErrVal) 0, 
                 "siOutE35S01() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   uBuf = con->tCallCb->mfMsgCtl.uBuf;
   con->tCallCb->mfMsgCtl.uBuf = NULLP;

   switch (con->evntType)
   {
      case SIT_STA_CONTREP:
         /* Generate COT */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CONTINUITY;

         /* initialize COT */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_STAREQ, 
                   (U8) MI_CONTINUITY, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);

         /* if continuity completed unsuccessfully */
         if (con->sduSp->m.siStaEvnt.contInd.contInd.val == CONT_CHKFAIL)
         {
            /* send message */
            siGenPdu(con->mCallCb, &pduHdr, &message, 
                     con->tCallCb->cfg.swtch, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, cir->cfg.cic, 
                     con->lnkSel, siGetPriority(M_CONTINUITY, 
                      con->tCallCb->cfg.swtch), uBuf);

            switch (con->tCallCb->cfg.swtch)
            {
#if SS7_ITU97
               case LSI_SW_ITU97:
#endif
#ifdef SS7_ITU2000
              case LSI_SW_ITU2000:
#endif
#ifdef SS7_RUSS2000
              case LSI_SW_RUSS2000:
#endif
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
                  /* check if this is a non-single rate call. If so, should
                   * clear the non controlling circuits. remove association 
                   * and reset calProcState to idle in non cntrl ckt cb.
                   */
                  if (con->outC.cir->ctrlMultiRateCir != NULLP)
                  {
                     /* this is a non-single rate connection */
                     if (siDelMRateLnk(&con->outC) != ROK)
                     {
                        SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                          "Break the linkage of non-single rate failed in\
                           siOutE35S01().\n"));
                        RETVALUE(RFAILED);
                     }

                  }           
                  /* FALL THROUGH */
#endif
               default:
                  for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
                  {
                     if (con->timers[tmrNum].tmrEvnt != TMR_NONE)
                        siRmvConTq(con, tmrNum);
                  }
                  SISTATECHNG(con->outC.conState , ST_IDLE);
                  /* suInstId is made null as it should be copied
                     from the CCR Req coming from CC */
                  con->suInstId = 0;

                  break;
            }
         }
         else
         {
            /* change state to Waiting for ACM */
            SISTATECHNG(con->outC.conState , ST_WTFORACM);

            /* send message */
            siGenPdu(con->mCallCb, &pduHdr, &message,
                     con->tCallCb->cfg.swtch, cir->opc, cir->cfg.intfId, 
                     cir->phyDpc, TRUE, cir->cfg.cic, 
                     con->lnkSel, siGetPriority(M_CONTINUITY,
                        con->tCallCb->cfg.swtch), uBuf);
         }
         break;

      case SIT_STA_CONTCHK:
         /* Generate Continuity Recheck Request */
         /* prepare Pdu header */
         pduHdr.eh.pres      = PRSNT_NODEF;
         pduHdr.msgType.pres = PRSNT_NODEF;
         pduHdr.msgType.val  = (U8) M_CONTCHKREQ;

         /* initialize COT */
         MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) SI_STAREQ, 
                   (U8) MI_CONTCHKREQ, (ElmtHdr *) con->sduSp, 
                   (ElmtHdr *) &message, (U8) PRSNT_NODEF,
                   con->tCallCb->cfg.swtch, (U32) MF_ISUP);


         /* send message */
         siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
                  cir->opc, cir->cfg.intfId, 
                  cir->phyDpc, TRUE, cir->cfg.cic, con->lnkSel,
                  siGetPriority(M_CONTCHKREQ, con->tCallCb->cfg.swtch), 
                  uBuf);
         break;
   }

   RETVALUE(ROK);
} /* end of siOutE35S01 */


  
/*
*
*       Fun:   siOutE36S00
*
*       Desc:  Input: Reset Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE36S00
(
SiCon *con 
)
#else
PRIVATE S16 siOutE36S00(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siOutE36S00)

   /* Stop all Timers and clear the connection */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* NOTE: if reset direction is FROM_UPR, connection will be cleared 
    * within circuit mntc. procedures state machine when RESET ACK is 
    * received 
    * if reset direction is FROM_LWR, maintain the connection till we 
    * receive a reset response and connection is cleared in circuit mntc. 
    * procedures state machine
    */
    con->outC.relResp = FALSE;
   /* Check if stop continuity is to be given */
   if (con->resDir == FROM_LWR)
      siChkContin(con);

   RETVALUE(ROK);
} /* end of siOutE36S00 */

  
/*
*
*       Fun:   siOutE36SND
*
*       Desc:  Input: Reset Request
*              State: Establishing and Answered
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE36SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE36SND(con)
SiCon *con;
#endif
{
   S16       ret;
   U8        tmrNum;
   U8       genRscFlg;  

   TRC2(siOutE36SND)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI509, (ErrVal) 0, 
                 "siOutE36SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI510, (ErrVal) 0, 
                 "siOutE36SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
#endif

   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

#if SI_ACNT
   /* if responsible for charging, generate bill */
   if ((con->outC.conState > ST_WTFORANSWR) && (con->charge))
   {  
      SIDBGP(SIDBGMASK_PROG, (siCb.init.prntBuf,
                      "generating billing record\n"));  
      siGenBill(con);
   } 
#endif
   genRscFlg = 0;
   switch (con->outC.conState)
   {
      case ST_IDLE:
      case ST_WTFORCONTIN:
      case ST_WTFORACM:
         if (con->resDir == FROM_LWR)
            genRscFlg = 1;
         break;

      default:
         break;
   }
   /* Check if stop continuity is to be given */
   if (con->resDir == FROM_LWR)
      siChkContin(con);
   if ((genRscFlg) && (con->outC.conState != ST_IDLE))
   {
      SiCauseDgn cause;

      MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
                 &meCauseIndV, (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, 
                (U32) MF_ISUP);

      cause.eh.pres       = PRSNT_NODEF;
      cause.causeVal.pres = PRSNT_NODEF;
      cause.causeVal.val  = SIT_CCREQUNAVAIL;
     
      /* generate reattempt indication */ 
      siGenReatInd(con->outC.cirId, con, &cause);
   }

   if (genRscFlg)
   {
      siClearOutCon(con);
      RETVALUE(ROK);
   }

   /* exchange of release primitives is unncessary in the new i/f 
    * maintain the conn. block till we receive a reset response/reset ack
    */
   SISTATECHNG(con->outC.cir->calProcStat, CALL_IDLE);
   con->outC.relResp = FALSE;

#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
   /* check if this is a non-single rate connection. If so, update the circuit
    * progress state for each affected non-controlling circuit
    */
   if (con->outC.cir->ctrlMultiRateCir != NULLP)
   {
      if (siChgMRateState(con->outC.cir, CALL_IDLE) != ROK)
      {
         SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                "siChgMRateState() is returned failure.\n")); 
         RETVALUE(RFAILED);
      }
   }           
#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */

   RETVALUE(ROK);
} /* end of siOutE36SND */

  
/*
*
*       Fun:   siOutE36S06
*
*       Desc:  Input: Reset Request
*              State: Waiting for RLC
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE36S06
(
SiCon *con 
)
#else
PRIVATE S16 siOutE36S06(con)
SiCon *con;
#endif
{
   U8        tmrNum;

   TRC2(siOutE36S06)

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI511, (ErrVal) 0, 
                 "siOutE36S06() Failed, pointer to upper cb  missing");
      RETVALUE(ROK);
   }
#endif
   /* Stop all Timers */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block till we receive a reset response/reset ack */
    con->outC.relResp = FALSE;

   RETVALUE(ROK);
} /* end of siOutE36S06 */

  
/*
*
*       Fun:   siOutE36S07
*
*       Desc:  Input: Reset Request
*              State: Waiting for Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE36S07
(
SiCon *con 
)
#else
PRIVATE S16 siOutE36S07(con)
SiCon *con;
#endif
{
   U8        tmrNum;

   TRC2(siOutE36S07)

   /* Stop all Timers & clear the connection */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block until we receive reset response or reset ack */
    con->outC.relResp = FALSE;

   RETVALUE(ROK);
} /* end of siOutE36S07 */


  
/*
*
*       Fun:   siOutE36S08
*
*       Desc:  Input: Reset Request
*              State: Waiting for RLC and Release Response
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE36S08
(
SiCon *con 
)
#else
PRIVATE S16 siOutE36S08(con)
SiCon *con;
#endif
{
   U8 tmrNum;

   TRC2(siOutE36S08)

   /* Stop all Timers & clear the connection */
   for (tmrNum = 0; tmrNum < MAXSIMTIMER; tmrNum++)
      if ((con->timers[tmrNum].tmrEvnt != TMR_NONE) &&
          (con->timers[tmrNum].tmrEvnt & OUTTYPE))
         siRmvConTq(con, tmrNum);

   /* maintain the conn. block until we receive reset response or reset ack */
    con->outC.relResp = FALSE;

   RETVALUE(ROK);
} /* end of siOutE36S08 */
 

/*
*
*       Fun:   siOutE37S00
*
*       Desc:  Input: Blocking Request
*              State: Idle
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/
 
#ifdef ANSI
PRIVATE S16 siOutE37S00
(
SiCon *con
)
#else
PRIVATE S16 siOutE37S00(con)
SiCon *con;
#endif
{
 
   TRC2(siOutE37S00)
 
#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI512, (ErrVal) 0, 
                 "siOutE37S00() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
#endif
   /* check if stop continuity is to be sent */
   siChkContin(con);

 
   RETVALUE(ROK);
} /* end of siOutE37S00 */

  
/*
*
*       Fun:   siOutE37SND
*
*       Desc:  Input: Blocking Request
*              State: Waiting for COT and for ACM
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE37SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE37SND(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;
   SiCauseDgn cause;
   SiAllPdus  message;
   SiPduHdr   pduHdr;
   S16        ret;

   TRC2(siOutE37SND)
   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI513, (ErrVal) 0, 
                 "siOutE37SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI514, (ErrVal) 0, 
                 "siOutE37SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI515, (ErrVal) 0, 
                 "siOutE37SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   /* Status Indication to Upper Layer to stop continuity check */
   siChkContin(con);

   MFINITELMT(&con->mCallCb->mfMsgCtl, ret, NULLP, (ElmtHdr *) &cause, 
              &meCauseIndV, (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, 
              (U32) MF_ISUP);

   cause.eh.pres       = PRSNT_NODEF;
   cause.causeVal.pres = PRSNT_NODEF;
   cause.causeVal.val  = SIT_CCREQUNAVAIL;

   /* generate Reattempt Indication */
   siGenReatInd(cir->cfg.cirId, con, &cause);

   /* Generate Release */
   /* prepare Pdu header */
   pduHdr.eh.pres      = PRSNT_NODEF;
   pduHdr.msgType.pres = PRSNT_NODEF;
   pduHdr.msgType.val  = (U8) M_RELSE;

   MFINITPDU(&con->tCallCb->mfMsgCtl, ret, (U8) 0, (U8) MI_RELSE,
             (ElmtHdr *) NULLP, (ElmtHdr *) &message, (U8) PRSNT_DEF,
             con->tCallCb->cfg.swtch, (U32) MF_ISUP);

   MFINITELMT(&con->tCallCb->mfMsgCtl, ret, NULLP,
              (ElmtHdr *) &message.m.release.causeDgn, &meCauseIndV,
              (U8) PRSNT_DEF, con->tCallCb->cfg.swtch, (U32) MF_ISUP);
   message.m.release.causeDgn.causeVal.pres = PRSNT_NODEF;

/* si027.220: modification - changed the cause value from protocol
 * error unspecified to normal unspecified since it is a normal 
 * event as per the specs */
   message.m.release.causeDgn.causeVal.val  = SIT_CCNORMUNSPEC;
   message.m.release.causeDgn.recommend.pres = NOTPRSNT;
 
   /* build copy of a Release Message */
   if ((ret = siBldMsg(con->mCallCb, con->outC.cir->cfg.cic, &pduHdr, &message,
                       con->mCallCb->pst.region, con->mCallCb->pst.pool,
                       &con->outC.rel, con->tCallCb->cfg.swtch, 
                       NULLP)) != ROK)
      con->outC.rel = NULLP;
 
   /* Start T1 Timer */
   siStartConTmr(TMR_T1O, con, con->tCallCb);
   /* Start T5 Timer */
   siStartConTmr(TMR_T5O, con, con->tCallCb);
 
   /* send message */
   siGenPdu(con->mCallCb, &pduHdr, &message, con->tCallCb->cfg.swtch,
            con->outC.cir->opc, con->outC.cir->cfg.intfId, 
            con->outC.cir->phyDpc, TRUE, con->outC.cir->cfg.cic, 
            con->lnkSel, siGetPriority(M_RELSE, con->tCallCb->cfg.swtch),
            NULLP);


   SISTATECHNG(con->outC.conState , ST_WTFORRELCMP);
   RETVALUE(ROK);
} /* end of siOutE37SND */


/*
*
*       Fun:   siOutE38SND
*
*       Desc:  Input: Loopback Acknowledgement
*              State: Idle, Waiting for COT, COT & CRA,
*                     COT have CRA
*
*       Ret:   ROK      - ok
*
*       Notes: None
*
*       File:  ci_bdy3.c
*
*/

#ifdef ANSI
PRIVATE S16 siOutE38SND
(
SiCon *con 
)
#else
PRIVATE S16 siOutE38SND(con)
SiCon *con;
#endif
{
   SiCirCb    *cir;

   TRC2(siOutE38SND)
   cir = con->outC.cir;

#if (ERRCLASS & ERRCLS_DEBUG)
   if (con->mCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "MTP3 control block pointer missing\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI516, (ErrVal) 0, 
                 "siOutE38SND() Failed, pointer to MTP3 cb  missing");
      RETVALUE(ROK);
   }
   if (con->tCallCb == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "upper SAP control block null\n"));  
 
      SILOGERROR(ERRCLS_DEBUG, ESI517, (ErrVal) 0, 
                 "siOutE38SND() Failed, pointer to upper SAP missing");
      RETVALUE(ROK);
   }
   if (cir == NULLP)
   {
      SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                      "no circuit associated with the connection\n"));  

      SILOGERROR(ERRCLS_DEBUG, ESI518, (ErrVal) 0, 
                 "siOutE38SND() Failed, pointer to circuit missing");
      RETVALUE(ROK);
   }
#endif
   switch (con->outC.conState)
   {
      case ST_IDLE:
      case ST_WTFORCONTIN:
#if (SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3)
         /* check if there is a non-single rate call going on. If so, LPA is 
          * not acceptable in this state. The reason is that LPA is responded
          * to the CCR message. CCR message can be exchanged in idle or wt for 
          * continuity check state. In the idle state, there is no non-single 
          * rate conn set up. In the wt for continuity state, ISUP should 
          * have already received a COT with failure before. When ISUP receives
          * a COT with failure, the linkage of non-single 
          * rate call is cleared. The continuity procedure is only on 
          * controlling ckt. This is an error case that receiving a LPA and 
          * the non-single rate call is still going on. 
          * Should treat this LPA as a unexpected message.  
          * A GRS with CAM is responded for ANS95 or multiple RSCs for ITU97 
          * and ETSI v3.
          * However, in state of SI_IDLE, ST_WTFORCONTIN, ST_WTFORCOTCRA, the
          * non-single rate coon has not been set up. 
          */
         if ((cir->ctrlMultiRateCir != NULLP) &&
             ((con->tCallCb->cfg.swtch == LSI_SW_ANS95) ||
              (con->tCallCb->cfg.swtch == LSI_SW_ITU97) ||
              (con->tCallCb->cfg.swtch == LSI_SW_ITU2000) ||
              (con->tCallCb->cfg.swtch == LSI_SW_RUSS2000) ||
              (con->tCallCb->cfg.swtch == LSI_SW_ETSIV3))) 
         {
            SIDBGP(SIDBGMASK_CERR, (siCb.init.prntBuf,
                   "rcvd LPA for an non-single rate call on ckt %#lx \n",
                    cir->cfg.cirId));

            siOutUNXMSG(con);
            RETVALUE(ROK);
         }   

#endif /* SS7_ANS95 || SS7_ITU97 || SS7_RUSS2000 || SS7_ITU2000 || SS7_ETSIV3 */
         /* Fall Through */
         /* Generate status indication for loop back ack */
         SiUiSitStaInd(&con->tCallCb->pst, con->tCallCb->suId, con->suInstId, 
            con->key.k1.spInstId, con->outC.cirId, FALSE, 
            SIT_STA_LOOPBACKACK, NULLP, NULLP);
         break;
      default:
        break;
   }
   RETVALUE(ROK);
} /* end of siOutE38SND */


/********************************************************************30**
  
         End of file:     ci_bdy3.c@@/main/43 - Wed Jul 25 13:20:40 2001
 
*********************************************************************31*/


/********************************************************************40**
  
        Notes:
  
*********************************************************************41*/

/********************************************************************50**

*********************************************************************51*/

   
/********************************************************************60**
  
        Revision history:
  
*********************************************************************61*/
  
/********************************************************************80**

  version    pat  init                   description
----------- ----- ----  ------------------------------------------------
1.1          ---  bn    1. initial release
             ---  jrl   2. trillium development system checkpoint (dvs)
                           at version: 1.0.0.0

1.2          ---  rhk   1. set relResp to true upon receipt of a RelReq
                           (siOutE26SND)
             ---  bn    2. add support for ansi

1.3          ---  jrl   1. remove includes for spt.h and spt.x
             ---  jrl   2. add siOutXXX prototypes
             ---  jrl   3. change all siOutXXX prototypes to PRIVATE

1.4          ---  rk    1. miscellaneous changes


1.5          ---  rk    1. miscellaneous changes

1.6          ---  bn    1. initialize CONG_LVL_2 type alarm to layer manager.

1.7          ---  bn    1. text changes.

1.8          ---  bn    1. cast MAX_MSG_LEN to U8 in siOutE23S00
             ---  bn    2. add if SS7_ANS88 around tmrNum, ret, ev and cir
                           in siOutE01S02

1.9          ---  bn    1. changed PRSNT_DEF to PRSNT_DEF in siOutE25SND.

1.10         ---  bn    1. add support for ansi 92.
             ---  bn    2. changed timer routines to common functions.
             ---  bn    3. added include cm5.x and cm5.h.
             ---  bn    4. change RETVALUE( to RETVALUE(

1.11         ---  bn    1. change ANS88 to SS7_ANS88, ANS92 to
                           SS7_ANS92

1.12         ---  bn    1. added case for continuity report in siOutE35S00.
             ---  bn    2. added full initialization of cause before generatinq
                           of reattempt indication.
             ---  bn    3. added siOutE36S06 and siOutE36S08.

1.13         ---  bn    1. initialize release event before generating
                           SiUiSitRelCfm in siOutE36s06..
             ---  bn    2. changed to support new interfaces.

1.14         ---  bn    1. add local variable SiAllSdus ev in siOutE24S09.

1.15         ---  bn    1. changed matrix to allow Release Req in idle state.
             ---  fmg   2. removed unused variables and siOutE09SND

1.16         ---  bn    1. added functionality for continuity recheck 
                           procedures
             ---  bn    2. added support for Q.767 and Singapore Telecom.

1.17         ---  bn    1. text changes

1.18         ---  bn    1. si008.23, si009.23
             ---  bn    2. added Italian Q.767 features.

1.19         ---  bn    1. text changes

1.20         ---  lc    1. miscellaneous changes

1.21         ---  bn    1. additions for Italian Q767.

1.22         ---  bn    1. chnaged SW_... to LSI_SW_...
             ---  bn    2. miscelenious changes.

1.23         ---  bn    1. changed ifdef SP to ifdef SI_SPT.
             ---  bn    2. corrected gcc compile warnings.

1.24         ---  bn    1. changed LSI_SW_CCITT to LSI_SW_ITU and 
                           LSI_SW_ANSI?? to LSI_SW_ANS??.

1.25         ---  bn    1. saved connection pointer in sir control block
                           in case of dual seizure in siOutE16SND.

1.26         ---  bn    1. necessary recovery actions placed in error scenarios
             ---  bn    2. misceleneous corrections.

1.27         ---  dm    1. corrected typo in siOutE16SND 
             ---  dm    2. substituted call clearing in siOutE37SND with call
                           releasing.

1.28         ---  pc    1. added ETSI variant for SI
             ---  bn    2. stopped generating release indication on reception
                           of release message while in state waiting for a

1.29         ---  bn    1. text change

1.30         ---  dm    1. added FTZ variant for SI
             ---  dm    2. added segmentation
             ---  dm    3. added event type in Facility primitives
             ---  dm    4. added TMR_TCCRO management in siOutE35S00
             ---  dm    5. added include cm_ss7.x

1.31         ---  dm    1. changed state matrix by putting  siOutE36SND in
                           states 9, 10, 11 and 12.
 
1.32         ---  dm    1. changed state matrix by putting  siOutE05S03 in
                           state 4
             ---  dm    2. added case PROGRESS in siOutE27SND, only for
                           the answered state.

*********************************************************************81*/

/********************************************************************90**
 
    ver       pat    init                  description
----------- -------- ---- -----------------------------------------------
1.33         ---      dm   1. corrected typo in siOutE36S08 
             ---      dm   2. corrected typo in siOutE27SND 
             ---      ao   3. corrected misplaced break
             ---      ao   4. Moved OPC from general config to upper SAP
                              config
             ---      ao   10. added call of siInsCallRef to set call
                               reference
             ---      ao   11. added test if message is received from SCCP
                               to increment statistics on SCCP
             ---      ao   12. corrected gcc compile warnings.

1.33         ---      ao   1. changed cause value in siOutE16SND from
                              CCRESCUNAVAIL to CCREQUNAVAIL when generating
                              a reattempt indication.
             ---      ao   2. added initialization if cause event in E18SND
             ---      rh   3. corrected error message in siOutE35S00()
             ---      rh   4. Added siOutE36S07()
             ---      rh   5. In siOutUNXMSG(), changes for issuing reattempt
                              indication when the call is waiting for backward 
                              messages to complete call-setup before sending
                              the release.

1.34         ---      rh   1. changes for call release handling functions to 
                              handle the new PAUSE/RESUME behaviour 
                           2. text changes
1.35         ---      ao   1. Fixed problem with reference to uBuf for
                              tightly coupled mode.
             ---      ao   2. change recommend filed in CauseDgn structure to
                              NOTPRSNT for ANS88 and ANS92
             ---      rh   1. correction to set 'relResp' flag to false
                              when connection receives a reset while waiting
                              for release response so that connection block 
                              can be cleared.
             ---      rh   1. Changes for handling reset request for stable 
                              calls from the upper layer when the DPC is 
                              PAUSEd.
1.35         ---      rs   1. Added Charge number to accounting for ANSI.  
                              Modifications to put the code related to 
                              accounting under SI_ACNT compile time flag.  
                           2. Added intialization of cir/uBuf/other in funcs 
                              E28S09, E28S10, E33SND, E03S02.
                           3. Changed the checks for flwCntrl and congestion
                              (checks are now done using intfIdCb instead of 
                               cirCb)
                      rs   4. Modified siOutE17S06 for release collision 
                              handling.
                      rs   5. Changed con->incC.cirId to con->outC.cirId in
                              siOutE25S00.
                      rs   6. Replaced errorind with release indication 
                               wherever applicable.
                      rs   7. Changed the Reset procedures releated to release
                              prinmitive exchange.

1.36         ---      rs   1. Unconditional initialisation of cause in 
                              siOutE37SND.
             ---      ym   1. Modifications for Debug prints.
                      ao   2. Added Russian variant
1.37         ---      rh   1. Removed the call to siOutUNXMSG() in siOutE37S00
                              This is because if a blocking comes on idle/dead
                              connection, it should be removed through some 
                              other means.
1.37+        ---      ym   1. Priority of RLC and Release message is corrected.
                           2. RelResp flg is reset for SITVER2 option.
                           3. RelResp flg is reset for SITVER2 option.
                           4. The state matrix is modified to correct the
                              interaction of CRM/CRA/REL and RSC.
              ---     ym   1. Recommendation field in the cause element is
                              marked NOTPRSNT.
                           2. The event structure for giving CRA 
                              indication is initialised properly.
              ---     ym   1. Connection control block is initialised 
                              properly in case of dual seizure.
                           2. Dual seizure cases involving CRM are 
                              handled.
                           3. The handling of reset request is corrected when
                              SITVER2 is not defined.
                           4. Glare condition in case of tandeming of con.
                              is handled in siOutE16SND, siOutE16S09,
                              siOutE23SND and siOutE23S09. 
                           5. cm_lib.x is included to get declaration of
                              cmMemset and cmMemcpy.
              ---       ym 1. Clash of CCR and incoming IAM is handled
                              properly .
                           2. Handling of suspend and suspReq is corrected
                              and corresponding stopping of timers in 
                              the resume and resreq related handling is
                              modified accordingly.
                           3. The suspend direction flag is properly updated.
                           4. uBuf handling is removed from siOutE37SND.
                           5. Sending reattempt ind. and RLC is corrected in
                              siOutE17S10.
                           6. The uBuf in mfMsgCtl is initialised properly.
                           7. The check regarding dropping user to user 
                              information is corrected.
                           8. The handling of unexpected message is corrected.
                           9. Reattempt indication is generated on getting
                              RSC in setup phase.
              ---      ym  1. The changes related to continuity procedures.
                           2. In handling of unexpected messages the stop
                              continuity is generated if state is idle or 
                              wtforcont and reattempt is not generated for
                              idle.
                           3. Stop Contin is sent to CC on getting BLO/CGB/REL/
                              RLC/RSC/unexpected message/IAM from controlling
                              exchange on idle outgoing circuit.
                           4. CONTCHKREQ is sent if CC has not sent the
                              continuity req in ConReq and configured value
                              of contReq is TRUE.
                           5. User2usr info is checked for !ANS88 case
                              instead of user2usr infoA.
                           6. The reattempt indication in handling of 
                              unexpected message is generated if state is
                              not idle.
                           7. Stopcontin is generated on getting RSC after
                              sending CCRReq.
                           8. Declaration of ret is unconditionally included
                              in siOutE36SND. 
                           9. outc.cirid is changed to outC.cirId in fn.
                              siOutE27S06. 
                           10. RLC is handled properly for ANS92 
                              variant in wtforcot state.
                           11. CPG is handled in await acm state
                              properly.
                           12. siGenAlarmNew is put under LMINT3 options.
                           13.The release clash is handled properly.
1.38         ---      ym   1. Changes related to addition of NTT variant in
                              ISUP.
         si026.214    ym   1. The release confirm is generated after
                              runtime updation.
                           2. The stop continuity indication is not sent
                              on getting release.
                           3. Information is updated properly in case
                              of release collision.
         si032.214    rrb  1. Corrected compilation warning.
         si034.214    tz   1. Changed code so that when the repeated
                              continuity check passes, we clear out
                              the connection and generate a release.
         si013.216    tz   1. Changed code to provide Bellcore support for
                              processing the received ANM when waiting for
                              the ACM.
         si041.214    tz   1. Changed code so that when reattemp indication
                              is generated to the upper layer, the
                              connection is removed. This is independent of
                              whether the SITVER2 is defined or not.
1.40         ---      dvs  1. miscellaneous changes
1.41         ---      ym   1. OUT define is changed to OUTTYPE for NT 
                              compilation.
/main/42     ---      hy   1. Changed codes to support Progress message from
                              upper layer in the "waiting for Answer" state
                              in function siOutE27SND
                           2. Added codes to support 3 level congestion of
                              received REL message for ans95 variant.
                           3. Changed codes not to overwrite the automatic 
                              congestion level param if this param is present
                              when sending release message from CC in 
                              function siOutE28SND.
                           4. Added codes to include the automatic congestion 
                              lever param if there is an overload condition 
                              when sending release message from CC in function
                              siOutE28S09 and siOutE28S10.
                           5. Added codes to support Facility Message for
                              ANS'95 variant in fuction siOutE12SND and 
                              siOutE33SND.
                           6. Implemented the release collision for ANS'95
                              variant in function siOutE17S06
                           7. Added codes to support LOP message for ITU97 and
                              ETSI v3 variant.
                           8. Added codes to support Pre-release message and 
                              application transport message for
                              ETSI v3 variant in fuction siOutE27SND and 
                              siOutE27S01
                           9. Changed codes to accept REL when waiting for 
                              release response from CC in siOutE17S07.
                          10. Changes to support non-single rate call.
                          11. change the code to use the right field for 
                              transfer rate for ANS95 in siOutE25S00 and 
                              siOutE25S10.
                          12. Added initialization cirCtrlFlg to TRUE 
                              in siOutE16SND and moved outside any defines.
                          13. Added a function siGenMRateLnk to build up
                              the linkage of affected circuit for outgoing
                              call set up.
                          14. Changes code to determine the multirate
                              connnection type call in siGenMRateLnk.
                          15. Added code to check the previous circuit
                              slotId if the circuit is unequipped when
                              linking the circuits for contiguous non-
                              single rate call in siGenMRateLnk for
                              ITU97 and ETSIV3.
                          16. Change the siChkContin function to a 
                              public funtion.
                      bsp 17. Changed hash define names which were changed 
                              in sit.h to resolve clash between sit.h and int.h
                      hy  18. changes for removal of swtch and ssf field in
                              circuit control block.
                      bsp 19. Removed SITVER2 flag
                          20. Enabled APM and PRI messages for ITU97.
                          21. Patch propogation related changes:
                              . Added codes to support identification response
                                message from upper layer in function
                                siOutE27S01
                              . Changed codes to support Progress message from
                                upper layer in the "waiting for Answer" state
                                in function siOutE27SND
                              . Corrected handling of information and
                                information request msgs
                              . Corrected dual siezure problem that was 
                                occuring in the hash list
                              . Corrected double insertion problem that was
                                occuring in the hash list  
                              . Called siChargeInfo whenever there was ConReq 
                                to take care of charging based on certain 
                                parameters
                          22. Changed code to not process CAM for ETSI ver 3
                          23. Deleted ANSI 88 from siOutE38SND in continuity 
                              related code
                      hy  24. Remove supporting for swtch type for ITU97,
                              ETSIV3 in function siOutE02S04, siOutE03S04,
                              siOutE04S04.
                          25. Modified the code to call siOutUNXEVT instead
                              of siOutUNXMSG for the events when the flow is 
                              from upper layer in the connection matrix 
                          26. Remove the #if 1 or #if 0 tags in the file.
                          27. Change the error log printings to assign the 
                              mulCallFlg to FALSE when swtch type is not
                              ans95/itu97/etsi v3 in siOutE25S00 and
                              siOutE16SND
                          28. Added a run time check for the variant type
                              before calling function siChargeInfo.
                          29. Fixed a bug in function siOutE16S09 to initialize
                              cirCtrlFlg to FALSE and move outside the any defines.
                          30. Corrected a typo of SS& for ANS95.
                          31. Modified the code to stop the timer TCCRO for
                              idle state when ISUP receives LPA in 
                              siOutE38SND.
                          32. Moved the assignment of the local variables
                              to the top of if statement in siOutE18S06
                          33. Added initialization for event and msgType
                              variables in siOutE33SND.
                          34. Removed the unused local variable 'ret' in 
                              siOutUNXEVT
                          35. Moved the local variable 'i' under SI_ACNT in 
                              siOutE25S00 and siOutE25S10
                          36. Removed the include of lrm.h.
/main/43     ---          hy  1. Modified the state matrix so that when a Release
                              Complete msg is received in idle state, it is
                              ignored
                           2. Modified state matrix to accept CFN in idle call
                              state
                        hy  1. Corrected the state for waiting for CRA and COT
                              msg in function siOutE35S09
                        tz  1. Added code to send StaInd when RLC is received and
                              it is RelUpLw case.
            si003.220   mm  1. In function siOutE17S09, siOutE17S10, siOutE17S11,
                               added code to check automatic congestion level
                               present.
            si007.220   mm  1. In function siOutE17S09, siOutE17S10, siOutE17S11,
                               correct code to check automatic congestion level
                               present to avoid possible core dump.
            si008.220   mm  1. In function siOutE35S00, modified circuit state 
                               into OUTBUSY so that after sending out CRM and 
                               receiving RSC and then sending out RLC, this 
                               circuit could be cleared into IDLE, which is able
                               to accept new calls.
            si009.220   hy  1. Modified the state matrix when handling the
                               blocking message after sending CRM and before
                               receiving CRA.
                        mm  2. Modified code so that when calling siGetLnkSel,
                               extra parameter cic will be passed in. 
            si014.220   km  1. Modified code in siOutE18S06 to update the 
                               standby copy with connection control block from
                               the correct place
            si015.202   sg  1. Initalize siRelEvnt on receiving IAM.
            si020.220   tz  1. Added code to set noRspFlgToLw in circuit.
            si024.220   tz  1. Added CHARGEACK case for SINGTEL variant.
                            2. Modified code so that LOOPPRVNT can always be 
                               processed.
            si025.220   tz  1. Modified arguments in siGetLnkSel call.
            si026.220   tz  1. Added ANSI92 and BELLCORE cases for procesing
                               the release collision in siOutE17S06.
            si027.220   tz  1. Changed the release cause value to normal
                               unspecified when receiving BLO message in
                               the state of waiting for ACM, etc.
            si029.220   tz  1. Added India flag and switch where applicable.
            si034220    rk  1. Added CHINA flag and switch where applicable.
            si040.220   rk  1. Changes made to identify all release generated by ISUP
                               by marking location.pres as PRSNT_DEF and in case of 
                               remote release, marking location.pres as PRSNT_NODEF.
           si042.220 bn    1. Added ITU2000 and Russian 2000 ISUP variants.
                           2. changed how release message is initialized in 
                              siOutE18SND
            si047.220   ng   1. Proper pointer type passed in SFndLenMsg
	   si054.220 vp     1 Added Code to update error counter
	   si055.220 vp     1 changed NULL to NULLP
*********************************************************************91*/
